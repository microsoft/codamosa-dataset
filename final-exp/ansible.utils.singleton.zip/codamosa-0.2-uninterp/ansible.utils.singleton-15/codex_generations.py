

# Generated at 2022-06-17 15:35:17.290430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert a is b

# Generated at 2022-06-17 15:35:20.478800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()


# Generated at 2022-06-17 15:35:25.361325
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:35:31.677911
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:35:36.892844
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    assert b.value == 1
    b.increment()
    assert a.value == 2
    assert b.value == 2


# Generated at 2022-06-17 15:35:40.949995
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:35:45.956958
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    t1 = Test(1)
    t2 = Test(2)
    assert t1.val == 1
    assert t2.val == 1
    assert t1 is t2

# Generated at 2022-06-17 15:35:49.462613
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a



# Generated at 2022-06-17 15:35:58.723176
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:36:00.944065
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:04.973939
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-17 15:36:06.537542
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-17 15:36:12.364516
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.test == 'test'
    assert t2.test == 'test'

# Generated at 2022-06-17 15:36:16.768276
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()

    assert a is b


# Generated at 2022-06-17 15:36:19.290115
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:36:20.832377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-17 15:36:27.258309
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'
    assert b.name == 'b'

# Generated at 2022-06-17 15:36:31.650987
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1

# Generated at 2022-06-17 15:36:37.489508
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1.a == 1
    assert a2.a == 1
    assert a1 is a2


# Generated at 2022-06-17 15:36:40.382782
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()


# Generated at 2022-06-17 15:36:49.248258
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1



# Generated at 2022-06-17 15:36:56.760870
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3


# Generated at 2022-06-17 15:36:58.684329
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-17 15:37:03.324435
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)

    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2
    assert t1 is t2

# Generated at 2022-06-17 15:37:05.770107
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:11.702885
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2

# Generated at 2022-06-17 15:37:17.991474
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3


# Generated at 2022-06-17 15:37:20.722142
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    assert Test() is Test()
    assert Test().x == 1

# Generated at 2022-06-17 15:37:24.481198
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    t1 = TestSingleton('t1')
    t2 = TestSingleton('t2')
    assert t1 is t2
    assert t1.name == 't2'
    assert t2.name == 't2'

# Generated at 2022-06-17 15:37:32.959683
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def incr(self):
            self.value += 1

    test_singleton = TestSingleton()
    test_singleton.incr()
    assert test_singleton.value == 1

    test_singleton_2 = TestSingleton()
    assert test_singleton_2.value == 1
    test_singleton_2.incr()
    assert test_singleton_2.value == 2

    assert test_singleton is test_singleton_2

# Generated at 2022-06-17 15:37:42.579019
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestClass()
    b = TestClass()
    assert a == b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:37:48.063096
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = Test(1, 2)
    t2 = Test(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2

# Generated at 2022-06-17 15:37:49.730484
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:37:58.240993
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2
    assert s1.a == 1
    assert s2.a == 1
    s1.a = 2
    assert s1.a == 2
    assert s2.a == 2
    s2.a = 3
    assert s1.a == 3
    assert s2.a == 3

# Generated at 2022-06-17 15:38:03.453068
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1
    b.value = 2
    assert a.value == 2
    assert b.value == 2


# Generated at 2022-06-17 15:38:05.224047
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:09.011622
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()
    assert Test() is not Test()


# Generated at 2022-06-17 15:38:12.167591
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:38:13.758088
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:20.692407
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = "test"

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.test == b.test
    a.test = "test2"
    assert a.test == b.test

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-17 15:38:31.396839
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1 is s2
    assert s1.value == 1
    assert s2.value == 1

# Generated at 2022-06-17 15:38:33.878686
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:38:43.207844
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_class_1 = TestClass(1)
    test_class_2 = TestClass(2)
    assert test_class_1.value == 1
    assert test_class_2.value == 1
    assert test_class_1 is test_class_2


# Generated at 2022-06-17 15:38:47.066099
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.arg == 1

# Generated at 2022-06-17 15:38:53.083434
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

# Generated at 2022-06-17 15:38:54.981793
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:58.695248
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:39:00.867162
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:39:03.624761
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b



# Generated at 2022-06-17 15:39:10.304875
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()

    assert a is b

    a.inc()
    assert a.value == 1
    assert b.value == 1

    b.inc()
    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-17 15:39:19.538224
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:39:24.285320
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test_singleton = TestSingleton()
    assert test_singleton.test == 'test'
    assert test_singleton is TestSingleton()

# Generated at 2022-06-17 15:39:29.649503
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class MyClass2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 2

    assert MyClass() is MyClass()
    assert MyClass2() is MyClass2()
    assert MyClass() is not MyClass2()
    assert MyClass().a == 1
    assert MyClass2().a == 2

# Generated at 2022-06-17 15:39:35.584221
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2



# Generated at 2022-06-17 15:39:38.690717
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2


# Generated at 2022-06-17 15:39:41.405844
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:39:48.641930
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'test'

    # Create an instance of TestSingleton
    test_singleton = TestSingleton()

    # Check that the instance is the same
    assert test_singleton is TestSingleton()
    assert test_singleton.value == 'test'



# Generated at 2022-06-17 15:39:53.319097
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:40:00.871771
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    # Create an instance of TestSingleton
    instance1 = TestSingleton()
    instance1.set_value(1)

    # Create another instance of TestSingleton
    instance2 = TestSingleton()

    # Check that instance1 and instance2 are the same object
    assert instance1 is instance2

    # Check that instance1 and instance2 have the same value
    assert instance1.get_value() == instance2.get_value()

# Generated at 2022-06-17 15:40:06.225733
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'a'
    assert b.name == 'a'

# Generated at 2022-06-17 15:40:17.302601
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a.x == b.x
    assert a is b

# Generated at 2022-06-17 15:40:23.212259
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:40:29.085617
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2


# Generated at 2022-06-17 15:40:34.180067
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    test_singleton = TestSingleton()
    assert test_singleton.value == 1
    test_singleton.value = 2
    assert test_singleton.value == 2
    test_singleton_2 = TestSingleton()
    assert test_singleton_2.value == 2

# Generated at 2022-06-17 15:40:38.291265
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

    assert t1 is t2



# Generated at 2022-06-17 15:40:41.579760
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2


# Generated at 2022-06-17 15:40:42.730819
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-17 15:40:49.287033
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = "test"

    t1 = Test()
    t2 = Test()
    assert t1 == t2
    assert t1.value == "test"
    assert t2.value == "test"
    t1.value = "test2"
    assert t1.value == "test2"
    assert t2.value == "test2"

# Generated at 2022-06-17 15:40:57.576255
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3

# Generated at 2022-06-17 15:41:01.930882
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1


# Generated at 2022-06-17 15:41:22.365388
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:41:30.512430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    test_singleton = TestSingleton()
    test_singleton.increment()
    assert test_singleton.value == 1

    test_singleton_2 = TestSingleton()
    assert test_singleton_2.value == 1

    test_singleton_2.increment()
    assert test_singleton_2.value == 2
    assert test_singleton.value == 2

# Generated at 2022-06-17 15:41:33.154558
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:41:38.924859
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-17 15:41:40.438938
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:45.527377
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:41:50.387114
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2
    b.x = 3
    assert a.x == 3
    assert b.x == 3



# Generated at 2022-06-17 15:41:55.349458
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.arg == 1
    assert t2.arg == 1

# Generated at 2022-06-17 15:41:59.324293
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1


# Generated at 2022-06-17 15:42:01.966693
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:42:44.135681
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2


# Generated at 2022-06-17 15:42:54.370919
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1
    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2
    t2.x = 3
    assert t1.x == 3
    assert t2.x == 3

# Generated at 2022-06-17 15:42:56.962982
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:43:01.943793
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.value == 0
    assert b.value == 0

    a.value = 1
    assert a.value == 1
    assert b.value == 1

    b.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:43:07.115536
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'
    assert b.name == 'b'


# Generated at 2022-06-17 15:43:11.687345
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)
    assert a == b
    assert a.x == 1
    assert b.x == 1
    assert a is b

# Generated at 2022-06-17 15:43:13.039705
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:15.554655
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = MyClass(1)
    b = MyClass(2)
    assert a is b
    assert a.value == b.value == 1

# Generated at 2022-06-17 15:43:19.826868
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:43:21.236021
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()


# Generated at 2022-06-17 15:44:34.385755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:44:38.645358
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:44:46.641514
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 'test_var'

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2
    assert test_singleton_1.test_var == 'test_var'
    assert test_singleton_2.test_var == 'test_var'

# Generated at 2022-06-17 15:44:51.396350
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.a == 1
    assert test2.a == 1

    test1.a = 2
    assert test1.a == 2
    assert test2.a == 2

# Generated at 2022-06-17 15:44:56.460741
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 == t2
    assert t1.value == 1
    assert t2.value == 1

    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:45:02.443289
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1



# Generated at 2022-06-17 15:45:06.040750
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

# Generated at 2022-06-17 15:45:10.691950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.value = 1
    assert b.value == 1


# Generated at 2022-06-17 15:45:15.415206
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a
