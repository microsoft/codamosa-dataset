

# Generated at 2022-06-12 04:14:31.900827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int = 0
    # c: int = b + 1
    # d: int = c + 1
    test_tree = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(10), type_comment='int')
    test_tree2 = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=ast.Num(0), type_comment='int')

# Generated at 2022-06-12 04:14:35.769432
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: ast.AST = ast.parse('a: int = 10', '', 'exec').body[0]
    transformer = VariablesAnnotationsTransformer()
    if(transformer.condition(a) == True):
        ast_result = transformer.action(a)
        assert ast_result.__class__.__name__ == 'Assign'

# Generated at 2022-06-12 04:14:37.823824
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test to check working of constrctor
    c = VariablesAnnotationsTransformer()
    assert c.target == (3,5)

# Generated at 2022-06-12 04:14:39.791496
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from py2typed import transform
    assert(transform(VariablesAnnotationsTransformer, 'b: int'))



# Generated at 2022-06-12 04:14:48.397793
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"
    assert VariablesAnnotationsTransformer.__qualname__ == "VariablesAnnotationsTransformer"

    parser = ast.parse("a: int = 10\n"
                       "b: int")
    ast.fix_missing_locations(parser)

    assert VariablesAnnotationsTransformer(ast.parse("a: int = 10\n"
                                                     "b: int")).transform() == [parser, False, []]
    assert VariablesAnnotationsTransformer(ast.parse("a: int = 10\n"
                                                     "b: int")).transform() == VariablesAnnotationsTransformer.transform(parser)

# Generated at 2022-06-12 04:14:52.291674
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    tree_str = """
a: int = 10
b: int
    """
    tree = ast.parse(tree_str)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(new_tree.tree) == str(ast.parse("a = 10"))

# Generated at 2022-06-12 04:14:55.536429
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a:int = 10\nb:int")
    assert type(tree) == ast.Module
    result = VariablesAnnotationsTransformer.transform(tree)
    assert len(result.src_nodes) == 0



# Generated at 2022-06-12 04:14:59.398025
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
    a: int = 10
    b: int
    """

    tree = ast3.parse(source)
    res = VariablesAnnotationsTransformer.transform(tree)

    target = """
    a = 10
    """

    target_tree = ast3.parse(target)

    assert res.tree.body == target_tree.body

# Generated at 2022-06-12 04:15:07.627272
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    ast_1 = ast.parse("""
a: int = 10
b: int
""", mode='exec')
    ast_1_expected = ast.parse("""
a = 10
""", mode='exec')
    result, _ = VariablesAnnotationsTransformer.transform(ast_1)
    result_str = astunparse.unparse(result)
    expected_str = astunparse.unparse(ast_1_expected)
    assert result_str == expected_str

# Generated at 2022-06-12 04:15:14.144889
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class VariablesAnnotationsTransformerTester(VariablesAnnotationsTransformer):
        def transform(self, tree):
            self.transform = super().transform
            return self.transform(tree)
    tree = ast.parse('''
    x:int = 10
    y:str = "hello"
''')
    tree1 = VariablesAnnotationsTransformerTester.transform(tree)
    assert tree1.tree.body[0].value.n == 10
    assert tree1.tree.body[1].value.s == 'hello'

# Generated at 2022-06-12 04:15:17.717546
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:15:19.017109
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Tests that a class 'VariablesAnnotationsTransformer' has been defined.
    pass


# Generated at 2022-06-12 04:15:26.318039
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    import textwrap
    target = textwrap.dedent('''\
            a: int = 10
            b: int
            ''')
    expected = textwrap.dedent('''\
            a = 10
            ''')

    tree_target = ast.parse(target)
    tree_expected = ast.parse(expected)


    tree_result, changed, messages = VariablesAnnotationsTransformer.transform(tree_target)

    assert(ast.dump(tree_result)==ast.dump(tree_expected))

# Generated at 2022-06-12 04:15:37.680989
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing if Variable Annotations are transformed correctly
    from flake8_annotations.tests.test_utils import run_test_for_transformer

    run_test_for_transformer(
        VariablesAnnotationsTransformer,
        "a: int = 10\nb: int\n\n@decorator()\nc: int\n",
        "a = 10\nb: int\n\n@decorator()\nc: int\n",
    )

# Generated at 2022-06-12 04:15:42.279075
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_object = VariablesAnnotationsTransformer()
    tree = ast.parse('a: int = 1+1')
    assert class_object.target==(3,5)
    assert class_object.transform(tree)[0].body.pop().value.right.n==1


# Generated at 2022-06-12 04:15:46.969711
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open("tests/fixtures/for-variable-annotations.py") as f:
        tree = ast.parse(f.read())

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree.changed

    with open("tests/fixtures/for-variable-annotations-transformed.py") as f:
        assert ast.dump(tree.tree) == f.read()

# Generated at 2022-06-12 04:15:49.786885
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  """
  Unit test for VariablesAnnotationsTransformer constructor
  """
  assert VariablesAnnotationsTransformer.target == (3, 5)



# Generated at 2022-06-12 04:15:51.733696
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import sys
    from . import test_Transformer

    # Setup
    input_code = "a: int = 10\nb: int"
    test = test_Transformer.TransformerUnitTest(input_code)
    VariablesAnnotationsTransformer.transform(test.tree)

    # Assert
    expected_code = "a = 10\n"
    assert test.code.strip() == expected_code

# Generated at 2022-06-12 04:15:55.017391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse("y: int = 2\ndef f(x: int, y: int) -> int: return x + y")
    assert test_tree == VariablesAnnotationsTransformer.transform(test_tree).tree

# Generated at 2022-06-12 04:15:57.251816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Tests the constructor of the VariablesAnnotationsTransformer class
    """
    VariablesAnnotationsTransformer()


# Generated at 2022-06-12 04:16:08.313507
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""\
    def foo(x: int):
        a: int = 10
        b: int
        c: int = foo(a)
        return a + b + c""")
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    tree2 = ast.parse("""\
    def foo(x):
        a = 10
        c = foo(a)
        return a + b + c""")
    tree2.body[0].body[1].value.args[0].ctx = 1
    tree2.body[0].body[1].value.args[0].id = 'a'

    assert ast.dump(new_tree.tree, include_attributes=True) == ast.dump(tree2, include_attributes=True)
    assert new_tree.tree_changed

# Generated at 2022-06-12 04:16:13.172914
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    expected = ast.parse('''
    def example():
        if True:
            return a
        a = 10
        return a
    ''')

    module = ast.parse('''
    def example() -> int:
        if True:
            return a
        a: int = 10
        return a
    ''')

    actual = VariablesAnnotationsTransformer.transform(module).tree
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 04:16:15.366505
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    VariablesAnnotationsTransformer(3, 5)
    """
    assert VariablesAnnotationsTransformer(3, 5)

# Generated at 2022-06-12 04:16:15.912384
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:16:19.574347
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__doc__ is not None
    assert VariablesAnnotationsTransformer.transform.__doc__ is not None
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert isinstance(VariablesAnnotationsTransformer(), VariablesAnnotationsTransformer)

# Generated at 2022-06-12 04:16:26.387939
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    old_code = '''
from typing import List

x: List[int]
y: int = 10
a: int = 3
b: List[int]
c: int = 2
    '''
    old_ast = parse(old_code)
    new_ast = VariablesAnnotationsTransformer().transform(old_ast)
    new_code = unparse(new_ast)
    assert new_code == '''
from typing import List

x =
y = 10
a = 3
b =
c = 2
    '''

# Generated at 2022-06-12 04:16:35.899046
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from ..utils.tree import to_src
    from .base import BaseTreeTransformer

    class InitAnnotationTransformer(BaseTreeTransformer):
        """
        Compiles:
            a: int = 10
            b: int
        To:
            a = 10
            b = None
        """
        target = (3, 6)
        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)

# Generated at 2022-06-12 04:16:37.040779
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:16:40.155674
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    expected_result = ast.parse('a = 10')
    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_result

# Generated at 2022-06-12 04:16:47.742775
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    transformer = VariablesAnnotationsTransformer(3, 5)
    input_ast = ast.parse("""
import typing

a: int = 10
b: typing.List[int]
c: typing.List[int] = [1,2,3]
""")

    expected_ast = ast.parse("""
import typing

a = 10
b = []
c = [1,2,3]
""")

    result = transformer.transform(input_ast)

    assert result.changed
    assert result.code == expected_ast
    assert result.warnings == ["Assignment outside of body"]

# Generated at 2022-06-12 04:16:54.670547
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        assert VariablesAnnotationsTransformer.target == (3, 5)
    except:
        raise AssertionError("target not correct")



# Generated at 2022-06-12 04:16:57.262089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a:int = 10')
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(tree)
    assert(astor.to_source(tree) == "a = 10")

# Generated at 2022-06-12 04:17:08.116374
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..tests.utils import compile_to_ast


# Generated at 2022-06-12 04:17:11.408402
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('a: int = 10')).tree == ast.parse('a = 10')
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('b: int')).tree == ast.parse('pass')

# Generated at 2022-06-12 04:17:19.536057
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..utils.helpers import parse, ast_to_code
    from .generic import GenericTransformer

    class Test:
        test_str: str

        def test_method(x: int) -> int:
            return x * x

    test_str: str = 'test'
    test_int: int = 10

    tree = parse(ast_to_code(ast.parse(Test.__annotations__['test_str'])) +
                 ast_to_code(ast.parse(Test.__annotations__['test_method'])) +
                 ast_to_code(ast.parse(ast_to_code(Test.__annotations__['test_int']))))

    tree_changed, _ = GenericTransformer.transform(tree, VariablesAnnotationsTransformer)
    assert tree_changed



# Generated at 2022-06-12 04:17:25.351943
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import variables_annotations

    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3,5), "Wrong transformer target"

    result = transformer.transform(variables_annotations.tree)

    assert result.tree_changed, "Transformation not changed tree"
    assert result.tree == variables_annotations.expected, "Transformer generates incorrect tree"

# Generated at 2022-06-12 04:17:28.498317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    f = '''a: int = 1
           a: int'''
    new_f = '''a = 1''' 
    result = VariablesAnnotationsTransformer.transform(f)   
    assert(result.src == new_f)

# Generated at 2022-06-12 04:17:38.457714
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    input = ast.Module([
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),  # type: ignore
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Constant(10),
                      simple=1),
        ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),  # type: ignore
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      simple=1)
    ])
    # a = 10

# Generated at 2022-06-12 04:17:42.968485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open('../tests/python/variables_annotations/variables-annotations.py') as f:
        src = f.read()

    # print(src)
    tree = ast.parse(src)
    # ast.fix_missing_locations(tree)

    res = VariablesAnnotationsTransformer.transform(tree)
    # res.tree.show()

# Generated at 2022-06-12 04:17:45.021827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    return
    node = ast.parse('a: int = 10')
    x = VariablesAnnotationsTransformer.transform(node)
    print(x)

# Generated at 2022-06-12 04:17:59.150038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTransformer

    constructor = BaseTransformer.constructor('VariablesAnnotationsTransformer')
    VariablesAnnotationsTransformerTest = constructor()
    test_tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result, tree_changed = VariablesAnnotationsTransformerTest.transform(test_tree)
    assert tree_changed == True
    

# Generated at 2022-06-12 04:18:01.947995
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''a: int = 10
b: int'''
    tree = ast.parse(code)

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(
        tree, True, [])



# Generated at 2022-06-12 04:18:03.266719
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Instantiating
    VariablesAnnotationsTransformer()
    # Nothing to test

# Generated at 2022-06-12 04:18:14.563819
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.parse("def add(a:int=10, b:int=20) -> int: return a+b")
    expected1 = ast.parse("def add(a,b) -> int: a = 10\n b = 20\n return a+b")

    node2 = ast.parse("def add(a:int=10, b:int) -> int: return a+b")
    expected2 = ast.parse("def add(a,b) -> int: a = 10\n return a+b")

    node3 = ast.parse("def add(a:int, b:int) -> int: return a+b")
    expected3 = ast.parse("def add(a,b) -> int: return a+b")


# Generated at 2022-06-12 04:18:21.536959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from . import run_transformer_on

    input_code = """
    def foo(a: int, b: float) -> str:
        a: int
        b: float
        return str(a) + str(b)
    """
    expected_code = """
    def foo(a: int, b: float) -> str:
        a = None
        b = None
        return str(a) + str(b)
    """
    run_transformer_on(VariablesAnnotationsTransformer, input_code,
                       expected_code)

# Generated at 2022-06-12 04:18:23.280930
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)

    assert isinstance(VariablesAnnotationsTransformer.transform(''), TransformationResult)

# Generated at 2022-06-12 04:18:24.541416
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_VariablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    assert(test_VariablesAnnotationsTransformer.target == (3,5))


# Generated at 2022-06-12 04:18:27.331927
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_in = ast.parse('''
            a: int = 10
            b: int
        ''')
    ast_out = ast.parse('''
            a = 10
        ''')
    assert VariablesAnnotationsTransformer.transform(ast_in) == ast_out

# Generated at 2022-06-12 04:18:30.385274
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    code = 'a: int = 10'
    tr = VariablesAnnotationsTransformer.transform(ast.parse(code))
    assert astor.to_source(tr.tree) == 'a = 10\n'


# Generated at 2022-06-12 04:18:39.661000
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typing
    import textwrap
    from typed_ast import ast3 as ast

    class_code = textwrap.dedent(r'''
            def constructor(self):
                a: int = 10
            ''')
    class_code = class_code.strip()
    class_ast = ast.parse(class_code)
    updated_class_ast = VariablesAnnotationsTransformer.transform(class_ast)

# Generated at 2022-06-12 04:18:58.688105
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:19:00.652685
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_utils import assert_transformation_result


# Generated at 2022-06-12 04:19:02.818485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing constructor
    transformer = VariablesAnnotationsTransformer()

    assert transformer.target== (3, 5)


# Generated at 2022-06-12 04:19:11.151726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer.transform(
        ast.AnnAssign(type_comment = "MyNode",
                      target = ast.Name(id = 'target', ctx = ast.Load(), type_comment = None),
                      annotation = ast.Str(s = 'string'),
                      value = ast.Str(s = 'string'),
                      simple=1))
    assert result.tree == ast.Assign(targets=[ast.Name(id = 'target', ctx = ast.Load(), type_comment = None)], value = ast.Str(s = 'string'), type_comment = ast.Str(s = 'string'))
    assert result.tree_changed is True
    assert result.errors == []


# Test for method: transform() in class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:19:16.007537
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = 3
    y = 5
    z = 7
    s = VariablesAnnotationsTransformer()
    assert s.target == (3, 5)
    assert s.transform(x) == (3, False, [])
    assert s.transform(y) == (5, False, [])
    assert s.transform(z) == (7, False, [])



# Generated at 2022-06-12 04:19:26.388381
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast_from_source
    from .test_transformer import TestTransformer

    class TestVariablesAnnotationsTransformer(TestTransformer):
        transformer_class = VariablesAnnotationsTransformer
        filename = 'test_VariablesAnnotationsTransformer.py'

        def test_variables_annotations(self):
            src = '''
a: int = 10
b: int
            '''
            expected = '''
a = 10
            '''

            tree = get_ast_from_source(src)
            transformed_tree = self.transform_and_check(tree, src, expected)

            warn(transformed_tree)

    test_VariablesAnnotationsTransformer = TestVariablesAnnotationsTransformer()
    # test_VariablesAnnotationsTransformer.enable_debug()

# Generated at 2022-06-12 04:19:28.468844
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import const


# Generated at 2022-06-12 04:19:34.514875
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import transform  # import required for test
    from typed_ast import ast3 as ast
    import textwrap
    code = textwrap.dedent("""
        a: int = 5
        b: int
        """)
    tree = ast.parse(code)
    tree_changed, new_code = transform(
        tree, VariablesAnnotationsTransformer)
    expected_code = textwrap.dedent("""
        a = 5
        """)
    assert new_code == expected_code

# Generated at 2022-06-12 04:19:44.902603
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Load()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Num(n=10)
    )
    b = ast.AnnAssign(
        target=ast.Name(id='b', ctx=ast.Load()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=None
    )

    input = ast.Module(body=[a, b])

    result = VariablesAnnotationsTransformer.transform(input)
    input.body = result.tree.body


# Generated at 2022-06-12 04:19:47.333771
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup
    ast_node = ast.AnnAssign()
    transformer = VariablesAnnotationsTransformer(ast_node)
    assert transformer

# Unit tests for method transform of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:20:31.085031
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from flake8_annotations.main import FileProcessor

    content = '''
    def f() -> None:
        a: int = 10
        b: int
    '''

    result = FileProcessor(content, '').run()
    assert len(result) == 2
    assert result[1].code == 'A001'
    assert result[1].line == 3
    assert result[1].column == 5
    assert result[0].code == 'A001'
    assert result[0].line == 4
    assert result[0].column == 5

# Generated at 2022-06-12 04:20:32.123587
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer()
    assert v.target == (3, 5)

# Generated at 2022-06-12 04:20:40.629459
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    class DummyNode(ast.AST):
        _fields = ()

    before = """
        a:int=10
        b:int
        if c:
            c:str
    """
    after = """
        a=10
        if c:
            c
    """

    tree = ast.parse(before)
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree).strip().replace(':None', '') == after.strip().replace(':None', '')

    before = """
        if c:
            c:str=10
    """
    after = """
        if c:
            c=10
    """

    tree = ast.parse(before)
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-12 04:20:42.794953
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5), "VariablesAnnotationsTransformer transformation must be applied at python 3.5"



# Generated at 2022-06-12 04:20:45.198933
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = "a: int = 10\nb: int"
    expected_code =  "a = 10"

    assert VariablesAnnotationsTransformer.test(input_code,expected_code)

# Generated at 2022-06-12 04:20:53.356840
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1:
    a:int = 10
    b:int
    c: int
    # Test case 2:
    d: int = 20
    # Test case 3:
    e: int = 30

    expected1 = '''a = 10
b
c'''
    expected2 = 'd = 20'
    expected3 = 'e = 30'

    # Test case 1:
    test = [a, b, c]
    class Test(VariablesAnnotationsTransformer):
        def __init__(self, tree: ast.AST):
            self.t = tree

        def transform_t(self) -> ast.AST:
            return self.transform(self.t)

    t = Test(test)
    t.transform_t()
    actual1 = t.t
    assert actual1 == expected1

    #

# Generated at 2022-06-12 04:20:56.219089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astunparse import unparse
    VariablesAnnotationsTransformer(ast.parse("a: int\n"))

# Unit test: run only if called directly
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-12 04:20:57.042219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int

# Generated at 2022-06-12 04:21:00.269196
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_before = ast.parse('''
a: int = 10
b: int
''')
    tree_after = ast.parse('''
a = 10
''')
    assert VariablesAnnotationsTransformer.transform(tree_before) == (tree_after, True, [])

# Generated at 2022-06-12 04:21:09.972309
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    def make_annassign(target: str, annotation: str, value: str) -> ast.AnnAssign:
        return ast.AnnAssign(target=ast.Name(id=target, ctx=ast.Store()),
                             annotation=ast.parse(annotation).body[0].value,
                             value=ast.parse(value).body[0].value,
                             simple=1)

    annassign_a = make_annassign('a', 'List[int]', '[]')
    annassign_b = make_annassign('b', 'int', 'None')

    tree = ast.parse('a: List[int] = []\nb: int')
    expected_tree = ast.parse('a = []\nb = None')

    # Test when nothing needs to be transformed
    result = VariablesAn

# Generated at 2022-06-12 04:22:55.675575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    var_annot_transformer = VariablesAnnotationsTransformer()
    assert var_annot_transformer.target == (3,5)

# Generated at 2022-06-12 04:23:03.998957
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int
    return a, b

# The FunctionDef node with the name of test_VariablesAnnotationsTransformer
# , the body of the function test_VariablesAnnotationsTransformer and the
# default arguments of the function test_VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:23:13.040394
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.AnnAssign(target=ast.Name('a', ctx=ast.Store()), annotation=ast.Name('int'), value=ast.Num(10))
    node2 = ast.Assign(targets=[node1.target], value=node1.value, type_comment=node1.annotation)
    node3 = ast.AnnAssign(target=ast.Name('b', ctx=ast.Store()), annotation=ast.Name('int'))
    node4 = ast.Expr(value=node3)

    class_node = ast.ClassDef(name='Test', body=[node1, node3, node4])
    module_node = ast.Module(body=[class_node])

    new_module_node = VariablesAnnotationsTransformer.transform(module_node).node
    assert new_module

# Generated at 2022-06-12 04:23:18.078980
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a:int=3')
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0].value, ast.AnnAssign)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(tree_changed, TransformationResult)
    assert isinstance(tree_changed.tree, ast.Module)
    assert tree_changed.tree_changed == True
    assert isinstance(tree_changed.tree.body[0], ast.Assign)

# Generated at 2022-06-12 04:23:26.070346
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import do_test
    do_test(VariablesAnnotationsTransformer,
            """
            a: int = 10
            """,
            """
            a = 10
            """)
    do_test(VariablesAnnotationsTransformer,
            """
            a: int
            """,
            """
            pass
            """)
    do_test(VariablesAnnotationsTransformer,
            """
            a: int = 10
            b: int
            """,
            """
            a = 10
            pass
            """)
    do_test(VariablesAnnotationsTransformer,
            """
            a: int = 10
            b: int
            c: int = 20
            """,
            """
            a = 10
            pass
            c = 20
            """)

# Generated at 2022-06-12 04:23:32.758307
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .unittransformer import UnitTransformer
    node = ast.parse("a: int = 10\nb: int")
    UnitTransformer(node, (3, 5)).transform()
    assert ast.dump(node) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-12 04:23:36.981032
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_ast

    assign = get_ast("a: int = 10")
    # assign = ast.parse("a: int = 10")
    assign2 = get_ast("b: int")
    expected = get_ast("a = 10")
    expected2 = get_ast("pass")
    VariablesAnnotationsTransformer.transform(assign)
    assert ast.dump(assign) == ast.dump(expected)
    VariablesAnnotationsTransformer.transform(assign2)
    assert ast.dump(assign2) == ast.dump(expected2)

# Generated at 2022-06-12 04:23:44.440887
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from _ast import Assign, Name, Load, Store, AugAssign, Add

    assign: Assign = ast.Assign(targets=[ast.Name(id='var_name', ctx=Store())],
                                value=ast.Name(id='var_value', ctx=Load()))
    # assign: int = 10
    assign_with_annotation: ast.AnnAssign = ast.AnnAssign(target=ast.Name(id='var_name', ctx=Store()),
                                                         annotation=ast.Name(id='int', ctx=Load()),
                                                         value=ast.Name(id='var_value', ctx=Load()))
    # var_name: int
    annotation_without_assign: ast.AnnAssign = ast.AnnAss

# Generated at 2022-06-12 04:23:45.569935
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:23:48.597402
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3,5)
    assert VariablesAnnotationsTransformer.transform('hello') == TransformationResult('hello', False, [])