

# Generated at 2022-06-12 04:14:19.626020
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.__name__ == "VariablesAnnotationsTransformer"
    assert issubclass(class_, BaseTransformer)


# Generated at 2022-06-12 04:14:20.485379
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:14:26.720711
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""

    from typed_ast import ast3 as ast

    source = """
    a: int = 10
    b: int
    c = 10
    """

    expected = """
    a = 10
    b = 0
    c = 10
    """

    tree = ast.parse(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert ast.dump(tree) == ast.dump(ast.parse(expected))


# Generated at 2022-06-12 04:14:36.514690
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from ..utils.tree import find
    from ..utils.helpers import warn

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)

# Generated at 2022-06-12 04:14:42.115902
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #Given
    t = ast.parse("a: int = 10\n"
        "b: int\n")
    transformer = VariablesAnnotationsTransformer()

    # When
    actual = transformer.transform(t)

    # Then
    expected = ast.parse("a = 10")

    assert ast.dump(expected) == ast.dump(actual.transformed)
    assert actual.transformed_count == 2
    assert actual.warnings == []

# Generated at 2022-06-12 04:14:45.180529
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
            c: int = 5""")
    exp = ast.parse("""
            c = 5""")
    assert VariablesAnnotationsTransformer.transform(tree)[0] == exp

# Generated at 2022-06-12 04:14:47.591694
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int\nc=a")
    assert (tree == VariablesAnnotationsTransformer.transform(tree).tree)

# Generated at 2022-06-12 04:14:56.485115
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    input_ast = ast3.AnnAssign(target=ast3.Name(id='a', ctx=ast3.Load()), annotation=ast3.Name(id='int', ctx=ast3.Load()), value=ast3.Num(n=10), simple=1)
    expected_output = ast3.Assign(targets=[ast3.Name(id='a', ctx=ast3.Store())], value=ast3.Name(id='int', ctx=ast3.Load()))
    output = VariablesAnnotationsTransformer.transform(input_ast)
    assert output.tree == expected_output
    assert output.tree_changed == True
    assert output.warnings == []

# Generated at 2022-06-12 04:14:57.413374
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer(3,5)

# Generated at 2022-06-12 04:15:00.898961
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_tree = ast.parse("""
    class Foo:
        def __init__(self, x: int = 5) -> None:
            pass

        def bar(self, a: int = 8):
            pass
    """)
    tree = VariablesAnnotationsTransformer.transform(input_tree)

# Test for AST generation for creation of the class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:15:07.146155
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import transform
    from ..utils.helpers import load_ast


# Generated at 2022-06-12 04:15:14.587505
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Assign, AnnAssign
    from ..types import TransformationResult
    tree = ast.Module(
            body=[
                Assign(targets=[
                        AnnAssign(target=ast.Name(
                            id='a', ctx=ast.Store()),
                            annotation=ast.Name(id='int', ctx=ast.Load()),
                            value=ast.Constant(value=10))],
                value=None, type_comment=None)],
            type_ignores=[])
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-12 04:15:21.764555
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astunparse import unparse
    from ast import parse
    from .unittest_transformer_util import should_not_change, should_raise_syntax_error

    should_raise_syntax_error(VariablesAnnotationsTransformer, "a:int=10")
    should_not_change(VariablesAnnotationsTransformer, "a=10")
    tree1 = parse("a:int = 10")
    VariablesAnnotationsTransformer.transform(tree1)
    tree2 = parse("def a():\n    a:int = 10")
    VariablesAnnotationsTransformer.transform(tree2)
    assert unparse(tree1) == "a = 10"
    assert unparse(tree2) == "def a():\n\n    a = 10"
    # TODO add more tests

# Generated at 2022-06-12 04:15:28.724697
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import print_tree
    from ..environment import Environment
    env = Environment(transformer_classes=[VariablesAnnotationsTransformer])
    test_code = """
a: int = 10
b: int
c: int = 15
    """
    expected_code = """
a = 10
c = 15
    """

    transformed_tree = env.transform(test_code)
    print(print_tree(transformed_tree))
    print(expected_code)
    assert print_tree(transformed_tree) == expected_code

# Generated at 2022-06-12 04:15:40.412476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    #   Input:
    #       a: int = 10
    #       b: int

    #   Expected output:
    #       a = 10
    tree = ast.parse('''
a: int = 10
b: int
    ''')

    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree is not None
    assert res.tree_changed is True
    assert len(res.messages) == 0
    assert res.tree.body[0].lineno == 1
    assert res.tree.body[0].col_offset == 0
    assert res.tree.body[0]._fields == ('targets', 'value')
    assert res.tree.body[0].targets[0].id == 'a'

# Generated at 2022-06-12 04:15:41.979213
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

# Generated at 2022-06-12 04:15:43.459524
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast


# Generated at 2022-06-12 04:15:45.668347
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup
    class_object = VariablesAnnotationsTransformer()

    # Assert
    assert isinstance(class_object, BaseTransformer)



# Generated at 2022-06-12 04:15:56.061576
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
        a: int = 10
        b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    result.new_tree.body == [ast.Expr(value=ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.Num(n=10),
        type_comment=ast.Name(id='int', ctx=ast.Load())
    ))]


# Generated at 2022-06-12 04:16:02.629334
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    from textwrap import dedent
    from ..exceptions import TransformError

    s = dedent('''\
    def foo(a: int, b: int) -> str:
        a: int = 10
        b: int = 10
        c: int
        return ""
    ''')
    expected_output = dedent('''\
    def foo(a, b):
        a = 10
        b = 10
        return ""
    ''')

    tree = ast.parse(s)

    try:
        tree = VariablesAnnotationsTransformer.transform(tree)
    except TransformError:
        assert False

    assert astunparse.unparse(tree) == expected_output

# Generated at 2022-06-12 04:16:10.310341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
   
    code_input = """
a: int = 10
b: int
"""
   
    tree = ast.parse(code_input)
    tree = VariablesAnnotationsTransformer.run(tree)
    result = generate_code(tree)
    print(result)
    assert code_input == result

# Generated at 2022-06-12 04:16:19.004373
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Constructing a node that has been modified correctly
    tree_instance = ast.Module(body=[ast.Import(names=[ast.alias(name='typed_ast', asname=None)]), ast.AnnAssign(target=ast.Name(id='a',
    ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Constant(value=10), simple=1), ast.AnnAssign(target=ast.Name(id='b',
    ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=None, simple=0)])

    # The expected node

# Generated at 2022-06-12 04:16:25.430921
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = ast.AnnAssign(target=ast.Name(id="myvar"), annotation=ast.Str(), value=ast.Str(s="Hello"))
    tree = ast.Module(body=[var])
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert(tree.body[0].target.id=="myvar")
    assert(tree.body[0].value.s=="Hello")
    assert(len(tree.body[0].decorator_list)==0)

# Generated at 2022-06-12 04:16:33.358176
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Function to test constructor of class VariablesAnnotationsTransformer.
    '''
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        import ast

    code = '''\
    x: int = 10
    y: int
    '''
    tree = ast.parse(code)
    transformer = VariablesAnnotationsTransformer()
    assert isinstance(transformer, VariablesAnnotationsTransformer)
    print('Success!')

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-12 04:16:39.245695
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_code = 'a: int = 10\nb: int'
    tree = ast.parse(test_code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    code = compile(tree, '<string>', 'exec')
    match_code = 'a = 10\nb = None'
    assert str(code) == match_code



# Generated at 2022-06-12 04:16:41.060236
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:16:44.723406
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vartran = VariablesAnnotationsTransformer()
    tree = ast.parse('a: int = 10')
    result = vartran.transform(tree)
    #assert result == ast.parse('a= 10'), "No se ha compilado correctamente VariablesAnnotationsTransformer"

# Generated at 2022-06-12 04:16:47.349789
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .variables_annotations_transformer_test import test_VariablesAnnotationsTransformer
    VariableVariableAnnotationsTransformer = VariablesAnnotationsTransformer
    test_VariablesAnnotationsTransformer(VariablesAnnotationsTransformer)

# Generated at 2022-06-12 04:16:51.346662
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_str = "a: int = 10"

    tree = ast.parse(test_str)
    node = VariablesAnnotationsTransformer.transform(tree)
    assert node.code == "a = 10"



# Generated at 2022-06-12 04:16:58.588739
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .context import Context
    from .line_numbering_transformer import LineNumberingTransformer
    
    source = '''
    a: int = 10
    '''
    tree = ast.parse(source)
    LineNumberingTransformer.transform(tree)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    #print(tree.body[0])
    assert(str(tree.body[0].targets[0].id) == "a")
    assert(len(tree.body[0].targets) == 1)
    assert(str(tree.body[0].targets[0].ctx) == "Store")
    assert(tree.body[0].value.n == 10)

# Generated at 2022-06-12 04:17:10.519180
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_utils import make_call, compare_source
    # Check that the constructor generates an object of type VariablesAnnotationsTransformer
    assert isinstance(VariablesAnnotationsTransformer(), VariablesAnnotationsTransformer)



# Generated at 2022-06-12 04:17:11.713716
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)

# Generated at 2022-06-12 04:17:14.290365
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..get_ast import get_ast
    asttree = get_ast('3.5')
    a = VariablesAnnotationsTransformer()
    a = a.transform(asttree)
    print(a)

# Generated at 2022-06-12 04:17:16.034585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.__doc__

# Generated at 2022-06-12 04:17:22.665974
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    
    a = ast.FunctionDef(name = 'functionname', 
                        args = ast.arguments(args = [],
                                             vararg = None,
                                             kwonlyargs = [],
                                             kw_defaults = [],
                                             kwarg = None,
                                             defaults = []),
                        body = [ast.AnnAssign(target = ast.Name(id = 'a',
                                                               ctx = ast.Store()),
                                              annotation = ast.Name(id = 'bool',
                                                                    ctx = ast.Load()),
                                              value = ast.Name(id = 'None',
                                                               ctx = ast.Load()),
                                              simple = 1)])
    b = ast.FunctionDef

# Generated at 2022-06-12 04:17:30.635461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..utils.source import Source
    from .. import transform

    source = Source(dedent('''\
    a: int = 10
    b: int = 20
    c: int
    '''), '<test>')
    tree = transform(ast.parse(source.read(), filename=source.path), [VariablesAnnotationsTransformer])
    expected = Source(dedent('''\
    # type: (int) -> int
    def f(a, b):
        return a + b
    '''), '<test>')
    assert ast.dump(ast.parse(expected.read(), filename=expected.path)) == ast.dump(tree)

# Generated at 2022-06-12 04:17:40.228412
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import load_ast

    tree = load_ast('''
    x: int = 10
    y: bool = True
    ''')

    tree = VariablesAnnotationsTransformer().visit(tree)

    assert (
        ast.dump(tree) ==
        "Module(body=[Assign(targets=[Name(id='x', ctx=Store(), annotation=Name(id='int', ctx=Load()), type_comment=None)], value=Num(n=10), type_comment=None), Assign(targets=[Name(id='y', ctx=Store(), annotation=Name(id='bool', ctx=Load()), type_comment=None)], value=NameConstant(value=True), type_comment=None)])"  # noqa: E501
    )

test

# Generated at 2022-06-12 04:17:41.361282
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:17:51.334506
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    # Test:
    #       a: int = 10
    #       b: int
    #
    # Should compiles to:
    #       a = 10
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                          annotation=ast.Name(id='int', ctx=ast.Load()),
                          value=ast.Num(n=10),
                          simple=1)
    node2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                          annotation=ast.Name(id='int', ctx=ast.Load()),
                          value=None,
                          simple=1)


    tree = ast.Module(body=[node1, node2])
    VariablesAnnotationsTransformer.transform

# Generated at 2022-06-12 04:17:54.489777
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer
    assert t.priority == 0
    assert t.target == (3, 5)
    assert t.transform is t.transform()

# Generated at 2022-06-12 04:18:20.114009
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from .base import BaseTransformer

    tree = ast.parse('a: int = 10\nb: int', mode='exec')
    result = VariablesAnnotationsTransformer.transform(tree)
    print(result.tree)
    print(result.tree_changed)
    print(result.extra_imports)
    print(result.extra_globals)
    print(isinstance(result.tree_changed, bool))
    print(result.tree.body[0].value)
    print(result.tree.body[1].value)
    assert result.tree.body[0].value == 10
    assert result.tree.body[1].value == None

# Generated at 2022-06-12 04:18:27.980910
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.FunctionDef(name='foo',body=[ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),annotation=None,value=ast.Num(n=10),simple=1)],args=ast.arguments(args=[],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),decorator_list=[],returns=None)

# Generated at 2022-06-12 04:18:29.665810
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert isinstance(t, VariablesAnnotationsTransformer)

# Generated at 2022-06-12 04:18:32.257340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test constructor
    obj = VariablesAnnotationsTransformer()
    assert obj.name == 'VariablesAnnotationsTransformer'
    assert obj.target == (3, 5)

# Generated at 2022-06-12 04:18:41.570818
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    from ..utils.tree import build_ast_tree_from_node
    from ..utils.helpers import get_ast_for_code
    from ..exceptions import NodeNotFound
    a = 'a: int = 10\nb: int'
    root = get_ast_for_code(a)
    root = build_ast_tree_from_node(root)

    a_ast = parse(a)
    print(a_ast)

    # Code is changed
    before_code = root.print_tree()
    transformed_result = VariablesAnnotationsTransformer.transform(a_ast)
    after_code = transformed_result.tree.print_tree()
    assert before_code != after_code

    # The transformation does not change the tree
    before_code = root.print_tree()


# Generated at 2022-06-12 04:18:52.170635
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    ast1 = ast.parse(
        '''
a: int = 10
b: int
        '''
    )
    ast2= ast.parse('''
    a=10
    ''')
    # tree=BaseTransformer.transform(ast1)
    x=VariablesAnnotationsTransformer()
    print(ast.dump(ast1))
    # print(ast.dump(VariablesAnnotationsTransformer.transform(ast1)))
    print(ast.dump(x.transform(ast1)))
    print(ast.dump(ast1))
    # print(TransformationResult.get_tree(x.transform(ast1)))

# Generated at 2022-06-12 04:18:55.705857
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)

    from ..utils.typing import get_type
    from .base import BaseTransformer
    assert get_type(t) is VariablesAnnotationsTransformer
    assert issubclass(get_type(t), BaseTransformer)

# Generated at 2022-06-12 04:18:59.242959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # arrange
    import astor
    from ..utils.helpers import str_ast

    s = '''
    a: int = 10
    '''

    expected = "a = 10"

    # act
    actual = str_ast(VariablesAnnotationsTransformer.transform(ast.parse(s)).tree)

    # assert
    assert astor.to_source(actual) == expected

# Generated at 2022-06-12 04:19:08.617351
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    initialCode = """
b: int = 8
    """
    expectedCode = """
    
    """
    tree = ast.parse(initialCode)
    transformed_tree = VariablesAnnotationsTransformer.transform(tree)
    transformed_tree = ast.fix_missing_locations(transformed_tree)
    code = compile(transformed_tree, filename="<ast>", mode='exec')
    exec(code)
    expected_tree = ast.parse(expectedCode)
    expected_tree = ast.fix_missing_locations(expected_tree)
    code = compile(expected_tree, filename="<ast>", mode='exec')
    exec(code)
    assert str(transformed_tree) == str(expected_tree)

# Generated at 2022-06-12 04:19:18.100519
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("test_VariablesAnnotationsTransformer")
    input_code = """
    def func(x: int):
        a: int = 10
        b: int
    """
    tree = ast.parse(input_code)
    t = VariablesAnnotationsTransformer()
    result = t.transform(tree)
    assigment_nodes = find(result.tree, ast.Assign)
    print_ast(assigment_nodes)
    assert len(assigment_nodes) == 1
    assert str(assigment_nodes[0].targets[0]).strip() == "a"
    assert str(assigment_nodes[0].value).strip() == "10"
    assert assigment_nodes[0].type_comment == "int"

# Generated at 2022-06-12 04:19:59.850455
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    
    class TestVariablesAnnotationsTransformer(unittest.TestCase):
        """Test the constructor of VariablesAnnotationsTransformer"""

        def test(self):
            self.assertIsInstance(VariablesAnnotationsTransformer(), BaseTransformer)

    unittest.main(verbosity=2)

# Generated at 2022-06-12 04:20:03.324921
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    t = VariablesAnnotationsTransformer()
    expected_tree = ast.parse('a = 10')
    assert get_as_string(t.transform(tree).tree) == get_as_string(expected_tree)

# Generated at 2022-06-12 04:20:10.776892
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from .typed_transformer import typed_transformer
    # given
    input_src = '''
#: type: ignore
a: int = 10
#: type: ignore
b: int = 100
#: type: ignore
c: int = 1000
'''
    expected_src = '''
a = 10
b = 100
c = 1000
'''
    # when
    tree = typed_transformer(input_src,
                             VariablesAnnotationsTransformer)
    # then
    result = astor.to_source(tree)
    assert result == expected_src

# Generated at 2022-06-12 04:20:11.580048
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:20:14.874053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
a: int = 10
b: int
"""
    expect = """
a = 10
"""
    tree = ast.parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    print(result)
    assert(str(tree) == expect)

# Generated at 2022-06-12 04:20:16.279698
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformerTest


# Generated at 2022-06-12 04:20:22.482863
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """
    import typing
    a: typing.List[int] = [1, 2, 3]
    """

    expected_code = """
    import typing
    a = [1, 2, 3]
    """

    tree = ast.parse(input_code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree[0]) == expected_code

# Generated at 2022-06-12 04:20:27.838084
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Example tree
    test_tree = ast.Module(body=[ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10), simple=1)])
    # test_tree from typed_astunparse
    test_tree_str = "a: int = 10\n"
    # class to test init
    class_to_test_init = VariablesAnnotationsTransformer()
    # Test 1: init
    assert class_to_test_init.target == (3, 5)

    # Test 2: transform - tree didn't change
    assert class_to_test_init.transform(test_tree).tree_changed is False
    # Test 3: transform - tree changed

# Generated at 2022-06-12 04:20:32.056859
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    prog = ast.parse('a:int = 10 \nb:int')
    res = VariablesAnnotationsTransformer.transform(prog)
    assert(res.new_tree.body[0].value.n == 10)
    assert(res.new_tree.body[0].targets[0].id == 'a')
    assert(len(res.new_tree.body) == 1)

# Generated at 2022-06-12 04:20:38.869340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transform_test_cases = [
        [
            'a: int = 10',
            'a = 10'
        ],
        [
            'a: int = 10\n'
            'b: int',
            'a = 10'
        ],
        [
            'a: int = 10\n'
            'b: int = 20',
            'a = 10\n'
            'b = 20'
        ]
    ]

    for expected_code, code in transform_test_cases:
        assert VariablesAnnotationsTransformer.transform_single(code) == \
               expected_code

# Generated at 2022-06-12 04:22:25.953233
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # pylint: disable=missing-type-doc,missing-return-type-doc,missing-return-doc
    code = '''
a: int = 10
    '''
    expected = '''
a = 10
    '''
    # pylint: disable=no-value-for-parameter
    tree = compile(code, '<test>', 'exec', ast.PyCF_ONLY_AST)
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.transformed_tree == compile(expected, '<test>', 'exec', ast.PyCF_ONLY_AST)

# Generated at 2022-06-12 04:22:32.800476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == \
"""Module(
    body=[Assign(
        targets=[
            Name(
                ctx=Store(),
                id='a',
                annotation=Name(
                    ctx=Load(),
                    id='int',
                    annotation=None,
                ),
            ),
        ],
        value=Constant(
            value=10,
        ),
        type_comment=Name(
            ctx=Load(),
            id='int',
            annotation=None,
        ),
    )],
    type_ignores=[],
)"""



# Generated at 2022-06-12 04:22:34.874081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert_source_equal(VariablesAnnotationsTransformer.transform(
        ast.parse('x: int = 10; y: int')).tree,
        ast.parse('x = 10;'))

# Generated at 2022-06-12 04:22:43.679554
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse("""a: int = 10""").body[0]
    b = ast.parse("""a: int""").body[0]
    c = ast.parse("""a""").body[0]

    assert (VariablesAnnotationsTransformer()
            .transform(ast.parse("""a: int = 10 + (1 + 2)"""))
            .tree.body[0] == ast.Assign(targets=[a.target], value=a.value))
    assert (VariablesAnnotationsTransformer()
            .transform(ast.parse("""a: int + 1"""))
            .tree.body == [])
    assert (VariablesAnnotationsTransformer()
            .transform(ast.parse("""a: int"""))
            .tree.body == [])

# Generated at 2022-06-12 04:22:45.465386
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # from ast import parse
    from node_visitor import dump
    from typed_ast import ast3
    from ..utils.helpers import indent


# Generated at 2022-06-12 04:22:49.056179
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer) \
           and isinstance(VariablesAnnotationsTransformer, object)

# Generated at 2022-06-12 04:22:50.081599
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform is not None

# Generated at 2022-06-12 04:22:51.199789
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-12 04:22:52.049264
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # TODO: Write tests
    pass

# Generated at 2022-06-12 04:22:57.381817
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..types import TransformationResult
    from ..utils.helpers import node_to_string

    tree = ast.parse("""
    def f(a: int = 10) -> int:
        pass
    """)
    res = VariablesAnnotationsTransformer.transform(tree)
    # Order of nodes is not guaranteed.
    expected_tree = ast.parse("""
    def f(a=10):
        pass
    """)
    assert node_to_string(res.tree) == node_to_string(expected_tree)
    assert res.changed == True