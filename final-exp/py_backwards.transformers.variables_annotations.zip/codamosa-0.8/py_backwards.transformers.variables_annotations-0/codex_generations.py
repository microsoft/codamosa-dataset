

# Generated at 2022-06-12 04:14:24.862932
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                         annotation=ast.Name(id='int', ctx=ast.Load()),
                         value=ast.Num(10),
                         simple=1)

    tree = ast.parse('a: int = 10')
    result, _ = VariablesAnnotationsTransformer.transform(tree)

    assert compare_ast(result, ast.parse('a = 10'))
    assert result.body[0] == node.value

# Generated at 2022-06-12 04:14:35.256040
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('# test file comment\n '
                     'def hi() -> None:\n'
                     '    a: int = 10 # a is an int\n'
                     '    \n'  # """"new line before b to test if impact the parser"""
                     '    b: int # b is an int\n')
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-12 04:14:42.974008
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..transpiler import Transpiler
    from typing import cast
    from .base import serialize_ast as sast

    t = Transpiler()

    code = '''
a: int = 10
b: int
'''
    expected_code = '''
a = 10
'''
    tree = ast.parse(code)
    result = t.transpile_tree(tree)
    assert sast(result.tree)== expected_code
    assert result.tree_changed
    assert result.warnings == []

# Generated at 2022-06-12 04:14:49.203852
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..visitor import transform
    from typed_ast import ast3
    from .stub_visitor import StubVisitor
    """Example for VariablesAnnotationsTransformer"""
    assert isinstance(transform(
        ast3.parse('a: int = 10'), [StubVisitor, VariablesAnnotationsTransformer]),
                       ast3.AST)
    assert isinstance(transform(
        ast3.parse('b: int'), [StubVisitor, VariablesAnnotationsTransformer]),
                       ast3.AST)

# Generated at 2022-06-12 04:14:55.145965
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse(textwrap.dedent("""
    a: int = 10
    b: int
    """))

    result = VariablesAnnotationsTransformer.transform(tree)
    assert len(result.tree.body) == 2
    assert isinstance(result.tree.body[0], ast.Assign)
    assert isinstance(result.tree.body[1], ast.AnnAssign)

# Generated at 2022-06-12 04:15:02.194461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for transformer
    from ..utils.tree import get_code_from_ast, transform_to_ast
    from .arguments import ArgumentsTransformer

    code = '''
name: str
value: int
my_tuple: Tuple[int]
my_list: List[int]
a: int = 10
b: int
'''
    tree = transform_to_ast(code)
    tree = transform_to_ast(ArgumentsTransformer.transform_code(code))
    tree = VariablesAnnotationsTransformer.transform_tree(tree)

    assert get_code_from_ast(tree).strip() == '''
name = None
value = None
my_tuple: Tuple[int] = None
my_list: List[int] = None
a = 10
b = None'''.strip()

# Generated at 2022-06-12 04:15:10.918341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10))
    # b: int
    node1 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()))
    assert VariablesAnnotationsTransformer.transform(node) == [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))]
    assert VariablesAnnotationsTransformer.transform

# Generated at 2022-06-12 04:15:17.054571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import get_tree
    import astor
    f = open("transformer/test_variables_annotations1.py", "r")
    x = astor.code_to_ast.parse_file(f)
    tree = get_tree(x)
    print(tree)
    VariablesAnnotationsTransformer.transform(tree)
    print(tree)
    return tree

# Generated at 2022-06-12 04:15:21.700067
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_changed = False
    tree = ast.parse('a: int = 10')
    v = VariablesAnnotationsTransformer()
    new_tree = v.transform(tree)
    assert new_tree is not None
    assert new_tree.body[0].value.n == 10
    assert new_tree.body[0].targets[0].id == 'a'

# Generated at 2022-06-12 04:15:22.986719
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    assert VariablesAnnotationsTransformer.transform(None) is not None

# Generated at 2022-06-12 04:15:27.461123
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .tests.transformer_test_class import run_test
    run_test(VariablesAnnotationsTransformer)

# Generated at 2022-06-12 04:15:35.845219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    target = (3, 5)
    tree = ast.parse('a: int = 10')
    assert hasattr(tree.body[0], 'annotation')
    assert not hasattr(tree.body[0], 'type_comment')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert not hasattr(result.tree.body[0], 'annotation')
    assert hasattr(result.tree.body[0], 'value')
    assert result.tree.body[0].value.elts[0].s == 10
    assert result.tree.body[0].value.elts[0].n == 10

# Generated at 2022-06-12 04:15:37.140616
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:15:44.992136
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .generator import generate, generate_from_text
    from .parser import parse
    from .unparser import unparse
    from .compare import compare_trees

    # a: int
    # b: int
    tree = parse("""
a: int
b: int
""")
    generated = generate(VariablesAnnotationsTransformer.transform(tree))
    assert compare_trees(tree, generated)

    # a: int = 10
    # b: int
    tree = parse("""
a: int = 10
b: int
""")
    generated = generate(VariablesAnnotationsTransformer.transform(tree))
    assert compare_trees(parse("""
a = 10
b: int
"""), generated)

# Generated at 2022-06-12 04:15:49.287637
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_x = "a: int"
    test_y = "b = 3"
    test = VariablesAnnotationsTransformer(test_x, test_y)
    assert test.test_x == "a: int"
    assert test.test_y == "b = 3"

# Generated at 2022-06-12 04:15:59.277581
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import make_module
    from ..utils.tree import print_tree
    from ..exceptions import NodeNotFound

    code = '''
    a: int = 10
    b: int
    '''
    tree = make_module(code, 3)
    for node in find(tree, ast.AnnAssign):
        parent, index = get_non_exp_parent_and_index(tree, node)
        try:
            assert node.target.elts[0].id == 'a'
        except (IndexError, AttributeError):
            assert node.target.id == 'b'
        assert parent.body[index].target.id == node.target.elts[0].id

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed

# Generated at 2022-06-12 04:16:02.393053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Initialize the VariablesAnnotationsTransformer
    t = VariablesAnnotationsTransformer()
    # Initialize the AST

# Generated at 2022-06-12 04:16:06.456700
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    sample_code = '''
        a: str = "hello"
    '''
    expected_code = '''
        a = "hello"
    '''
    tree = ast.parse(sample_code)
    tree_transformer = VariablesAnnotationsTransformer()
    tree_transformer.transform(tree)
    assert(astunparse.unparse(tree) == expected_code)

# Generated at 2022-06-12 04:16:12.335620
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    tree = ast.parse("""
a: int = 10
b: int = (1 // 2)
c: int
""")

    expected = ast.parse("""
a = 10
b = (1 // 2)

""")

    # Act
    transformer = VariablesAnnotationsTransformer()
    new_tree = transformer.transform(tree)

    # Assert
    assert ast.dump(new_tree.tree) == ast.dump(expected)
    assert transformer.get_warnings() == ["Assignment outside of body"]

# Generated at 2022-06-12 04:16:17.520531
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
x: int = 10
y: int = 20
z: int = 30
    """
    tree = ast.parse(code, mode='exec')
    expected_code = """
x = 10
y = 20
z = 30
    """

    VariablesAnnotationsTransformer.transform(tree)
    transformed_code = astor.to_source(tree)

    assert transformed_code == expected_code

# Generated at 2022-06-12 04:16:33.010476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .dunder_init import DunderInitTransformer
    from .typing_imports import TypingImportsTransformer
    from ..utils.ast_helper import get_ast, compare_asts, get_source

    tree = get_ast('x: int = 10')
    # transform typing imports
    ti_transformer = TypingImportsTransformer()
    tree = ti_transformer.transform(tree)
    # transform dunder init
    di_transformer = DunderInitTransformer()
    tree = di_transformer.transform(tree)
    # transform variable annotations
    va_transformer = VariablesAnnotationsTransformer()
    tree = va_transformer.transform(tree)
    # compare trees
    source = get_source(tree)

# Generated at 2022-06-12 04:16:42.967614
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class B:
        pass

    a = B()
    b = B()
    a.value = "any"
    a.annotation = "any"
    b.value = None
    b.annotation = "any"
    node_ast3 = ast.AnnAssign(targets=[a], value=b)
    node_ast2 = ast.Assign()
    assert node_ast3.targets is not None
    assert node_ast3.value is not None
    assert node_ast3.annotation is not None
    assert node_ast2.targets is None
    assert node_ast2.value is None
    assert node_ast2.annotation is None

# Generated at 2022-06-12 04:16:50.352381
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import helpers
    import typed_ast.ast3 as ast


# Generated at 2022-06-12 04:16:52.189269
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import suite_for_3_5 as suite_3_5


# Generated at 2022-06-12 04:16:56.565605
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("""
      def f(a : int) -> int:
        b: int
        c: int
        c = 100
        d: int = 200
        return a
    """, mode='exec'))[0] == ast.parse("""
      def f(a):
        c = 100
        d=200
        return a
    """, mode='exec')

# Generated at 2022-06-12 04:16:57.328032
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

# Generated at 2022-06-12 04:17:04.093660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Input:
        a: int = 10
        b: int
    Output:
        a = 10
    """
    input = '''a: int = 10\nb: int'''
    expected_output = ast.parse('''a = 10''')
    # Create an instance and call the constructor
    instance_of_VariablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    output = instance_of_VariablesAnnotationsTransformer.transform(ast.parse(input))
    assert output == expected_output

# Generated at 2022-06-12 04:17:09.234886
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    tree_changed, warnings = VariablesAnnotationsTransformer.transform(tree)

    assert tree_changed
    assert find(tree, ast.AnnAssign) == []
    assert find(tree, ast.annassign) == []
    assert isinstance(find(tree, ast.Assign)[0], ast.Assign)

# Generated at 2022-06-12 04:17:09.738999
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-12 04:17:17.631681
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typing import List
    from typed_ast import ast3

    tree = ast3.parse('a: int = 10')
    annotations = VariablesAnnotationsTransformer.transform(tree)

    assert isinstance(tree.body[0], ast3.Assign)
    assert isinstance(tree.body[0].targets[0], ast3.Name)
    assert tree.body[0].targets[0].id == 'a'
    assert isinstance(tree.body[0].value, ast3.Num)
    assert tree.body[0].value.n == 10
    assert tree.body[0].type_comment is None
    assert annotations == {'tree': tree, 'tree_changed': True, 'node_removed': []}

# Generated at 2022-06-12 04:17:24.371183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer(None)
    assert t.target == (3, 5)


# Generated at 2022-06-12 04:17:27.988905
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = """a:int = 10\nb:int"""
    expected_output = """a = 10"""
    test = BaseTransformer.test(input, expected_output, VariablesAnnotationsTransformer)
    assert test.test_and_get_result()[0]

# Generated at 2022-06-12 04:17:36.184946
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import to_tuple
    from ..utils.fixtures import annAssign, assign, body as body_, int_
    from ..utils.tree import get_non_exp_parent_and_index

    transformer = VariablesAnnotationsTransformer()
    tree = annAssign(int_, int_, 0)
    transformed_tree = transformer.transform(tree)
    target = annAssign(int_, int_, 0)
    parent, index = get_non_exp_parent_and_index(transformed_tree.tree, target)
    assert parent.body[index] == assign(0, int_)

# Generated at 2022-06-12 04:17:37.085268
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()


# Generated at 2022-06-12 04:17:40.422906
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
        a: int = 10
        b: int
    """
    expected = """
        a = 10
    """
    cls = VariablesAnnotationsTransformer()
    tree = ast.parse(source)
    result = cls.transform(tree)
    assert result.changed
    assert ast.dump(result.new_tree) == expected

# Generated at 2022-06-12 04:17:50.660060
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    from ..utils.helpers import compare_asts
    from ..utils.ast_builder import build_ast
    source1 = """
    a: int = 10
    b: int
    """
    source2 = """
    a = 10
    """
    source3 = """
    def foo(a: int):
        b: int = 10
    """
    source4 = """
    def foo(a):
        b = 10
    """
    source5 = """
    a: int = 10
    """
    source6 = """
    a = 10
    """
    source7 = """
    def foo(a: int):
        b: int = 10

    c: int
    """
    source8 = """
    def foo(a):
        b = 10

    c: int
    """

# Generated at 2022-06-12 04:17:55.480301
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int')) == \
        TransformationResult(ast.parse('a'), True, [])

    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')) == \
        TransformationResult(ast.parse('a = 10'), True, [])



# Generated at 2022-06-12 04:17:58.700886
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == str(ast.parse('a = 10'))
    assert(tree_changed)


# Generated at 2022-06-12 04:18:08.615950
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..context import Context
    from ..transformer_factory import TransformerFactory
    from ..utils.tree import dump

    src = """
    a: int = 10
    b: int
    """

    tree = ast.parse(src)
    module_name = 'a'
    ctx = Context(module_name, src)
    result, _ = TransformerFactory.transform_tree(ctx, tree)
    assert result.changes == 2

# Generated at 2022-06-12 04:18:12.938852
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    inp = ast.parse("""
a: int = 10
b: int
    """)
    outp = ast.parse("""
a = 10
b: int
    """)

    vs = VariablesAnnotationsTransformer()
    assert outp == vs.visit(inp)

# Generated at 2022-06-12 04:18:23.821217
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree: ast.AST = ast.parse('a: int = 10; b: int; c: int = 20')
    vat = VariablesAnnotationsTransformer()
    vat.transform(tree)

# Generated at 2022-06-12 04:18:29.764728
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test 1: Compile a: int = 10 to a = 10
    tree = ast.parse("""
    a: int = 10
    """)
    tree_changed, tree_new = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed
    expected = ast.Module(  # type: ignore
        body=[
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=10),
                type_comment="int"
            )
        ]
    )
    assert ast.dump(expected) == ast.dump(tree_new)

    # test 2: Compile b: int to {}
    tree = ast.parse("""
    b: int
    """)
    tree_changed, tree_new = VariablesAnnotations

# Generated at 2022-06-12 04:18:39.060930
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from pymba.ast_transforms.variables_annotations_transformer import VariablesAnnotationsTransformer
    import typed_ast.ast3 as ast
    from textwrap import dedent

    def test(input, wanted_output):
        transformer = VariablesAnnotationsTransformer()
        input_ast = ast.parse(dedent(input))
        wanted_output_ast = ast.parse(dedent(wanted_output))
        actual_output_ast = transformer.transform(input_ast).tree
        assert ast.dump(actual_output_ast) == ast.dump(wanted_output_ast)

    test('''
    def foo(a: int = 10, b: int):
        pass
    ''', '''
    def foo(a: int = 10, b: int):
        pass
    ''')

   

# Generated at 2022-06-12 04:18:45.102319
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse(
        """
        def func(a: int = 10, b: int) -> int:
            pass
        """
    )

    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(new_tree) == ast.dump(
        ast.parse(
            """
        def func(a = 10, b):
            pass
        """
        )
    )

# Generated at 2022-06-12 04:18:48.657619
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from src.ch2.section_1.transformation import VariablesAnnotationsTransformer
    from typed_ast import ast3 as ast
    node = ast.AnnAssign()
    VariablesAnnotationsTransformer(node)
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-12 04:18:52.074972
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('def x():\n a:int = 10')
    trans_obj = VariablesAnnotationsTransformer()
    trans_obj.transform(tree)



# Generated at 2022-06-12 04:18:57.868540
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test with one annotation
    tree = ast.parse("a: int = 10\nb: int")
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    # Test with no annotation
    trees = ast.parse("a = 10\nb")
    new_trees = VariablesAnnotationsTransformer.transform(trees)

    # Test with multiple annotations
    treess = ast.parse("a: int = 10\nb: int = 20")
    new_treess = VariablesAnnotationsTransformer.transform(treess)


# Generated at 2022-06-12 04:19:05.978526
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    f = lambda: None
    f.__code__ = type(lambda: None).__code__.__class__(
        0, 0, 0, 0, b'', (), (), (), '', '', 0, b'')
    f.__code__.co_argcount = 2
    f.__code__.co_varnames = ('self', 'foo')
    f.__annotations__ = {
        'foo': ast.parse("int").body[0].value
    }

    res = VariablesAnnotationsTransformer.transform(f)
    print(res)
    assert(res.tree.__annotations__ == {})

# Generated at 2022-06-12 04:19:12.448099
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.Module(body=[
        ast.AnnAssign(target=ast.Name('a',ast.Load()),
                      value=ast.Num(10),
                      annotation=ast.Name('int',ast.Load()),
                      simple=1),
        ast.AnnAssign(target=ast.Name('b',ast.Load()),
                      annotation=ast.Name('int',ast.Load()),
                      simple=1)
        ])

    # a = 10
    expected = ast.Module(body=[
        ast.Assign(targets=[ast.Name('a',ast.Load())],
                      value=ast.Num(10),
                      type_comment=ast.Name('int',ast.Load()))
        ])

    assert VariablesAnnotationsTransformer.transform

# Generated at 2022-06-12 04:19:13.896992
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)


# Generated at 2022-06-12 04:19:34.338288
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.run('a: int = 10\nb: int', {}) \
        == '''\
a = 10
'''



# Generated at 2022-06-12 04:19:38.566144
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_to_ast_tree
    tree = parse_to_ast_tree("a: int = 10")
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert(new_tree == "a = 10")

# Generated at 2022-06-12 04:19:44.034188
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.code_gen import to_source
    from astor import parse

    code = """
    a: int
    b: int = 1
    """

    expected_code = """
    a
    b = 1
    """

    tree = parse(code)

    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert to_source(new_tree.new_tree) == expected_code

# Generated at 2022-06-12 04:19:47.141151
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variablesAnnotationsTransformer = VariablesAnnotationsTransformer("")
    assert(isinstance(variablesAnnotationsTransformer,VariablesAnnotationsTransformer))
    assert(variablesAnnotationsTransformer.target == (3,5))


# Generated at 2022-06-12 04:19:51.925818
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typing import List
    tree = ast.parse(
        """
    a: int = 10
    b: int
    """)
    exp = ast.parse(
        """
    a = 10
    """)
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree == exp
    assert res.trees == []


# Generated at 2022-06-12 04:20:00.277347
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_test_files
    from .VariableAnnotationsTransformer import VariableAnnotationsTransformer
    from .VariableAnnotationsTransformer import VariablesAnnotationsTransformer
    import os
    import astunparse
    import io
    
    test_files = get_test_files(2, 5)
    test_files.extend(get_test_files(3, 5))
    for file in test_files:
        with open(file, 'r') as f:
            string = f.read()
        test_tree = ast.parse(string)
        VariableAnnotationsTransformer.transform(test_tree)
        new_tree = VariablesAnnotationsTransformer.transform(test_tree)

# Generated at 2022-06-12 04:20:09.816096
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import os
    import sys

    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))

    from ..utils.tree import string_to_ast

# Generated at 2022-06-12 04:20:14.286527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    class Test:
        def __init__(self, value: int = 10, flag: bool = False):
            pass
    """

    expected = """
    class Test:
        def __init__(self, value = 10, flag = False):
            pass
    """

    tree = ast.parse(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-12 04:20:22.881099
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Creates a test tree
    testCode = """
    x: int = 10
    y: int
    class x:
        def __init__(self, a, b: str="some string"):
            self.a = a
            self.b = b
    def someFunc(x: int) -> str:
        return 1
    """
    testTree = ast.parse(testCode)
    # Calls the transform method from the class to transform the tree
    result = VariablesAnnotationsTransformer.transform(
        ast.parse(testCode))
    assert(testCode == result.tree.__str__())
    assert(result.treeModified == True)

# Generated at 2022-06-12 04:20:25.841856
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # VariablesAnnotationsTransformer.transform(tree: ast.AST)
    line = ast.parse("a: int = 10", mode="exec")
    tree = VariablesAnnotationsTransformer.transform(line).tree
    assert str(tree) == "a = 10"
    line = ast.parse("a: int", mode="exec")
    tree = VariablesAnnotationsTransformer.transform(line).tree
    assert str(tree) == ""

# Generated at 2022-06-12 04:21:11.411339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import generate_code
    tree = ast.parse("""
x: int = 5
y: str
z: int
""")
    transf = VariablesAnnotationsTransformer()
    new_tree = transf.transform(tree)
    assert generate_code(new_tree.tree) == generate_code(ast.parse("""
x = 5
z: int
"""))

# Generated at 2022-06-12 04:21:15.377441
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # function defination
    def test(tree):
        node = ast.parse(tree)
        VariablesAnnotationsTransformer.transform(node)

    # case 1
    tree1 = """
    x: int = 1
    """

    test(tree1)

# Generated at 2022-06-12 04:21:18.547961
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ip = ast.parse('a: int = 10\nb: int')

    result1 = VariablesAnnotationsTransformer.generate_code(ip)
    result2 = VariablesAnnotationsTransformer.generate_code(ip)

    assert result1 == 'a = 10'
    assert result2 == 'a = 10'

# Generated at 2022-06-12 04:21:20.225032
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:21:22.308168
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int\n")
    assert isinstance(VariablesAnnotationsTransformer.transform(tree), 
                      TransformationResult)
    


# Generated at 2022-06-12 04:21:25.932267
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import compile_source

    code = '''a: int = 10
    b: int
    '''
    tree = compile_source(code, '<test>', 'exec')
    var_anno = VariablesAnnotationsTransformer()
    tree = var_anno.visit(tree)
    assert len(tree.body) == 1

# Generated at 2022-06-12 04:21:26.677862
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:21:33.075207
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                          annotation=ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                                                   value=None),
                          value=ast.Num(n=5))
    vat.transform(node1)

    assert node1.target == ast.Name(id='a', ctx=ast.Store())
    assert node1.annotation == ast.Name(id='b', ctx=ast.Store())
    assert node1.value == ast.Num(n=5)

# Generated at 2022-06-12 04:21:40.540908
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..ast import ASTWrapper
    from ..type_extracter.types import Type
    from .base import BaseTransformer

    # def test():
    #     x: int = 10
    #     y: int = 20
    #     z: int = 30
    #     return x + y + z


# Generated at 2022-06-12 04:21:47.889850
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import dump_node
    node = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()),
                         annotation=ast.Name(id="int", ctx=ast.Load()),
                         value=ast.Num(n=10), simple=1)
    expected = ast.Assign(targets=[ast.Name(id="a", ctx=ast.Store())],
                          value=ast.Num(n=10),
                          type_comment=ast.Name(id="int", ctx=ast.Load()))
    new_node = VariablesAnnotationsTransformer.transform(node).tree
    dump_node(expected)
    dump_node(new_node)
    assert expected == new_node

# Generated at 2022-06-12 04:23:28.319574
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:23:31.541232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_1 = ast.AnnAssign(
        target=None,
        annotation=None,
        value=None,
        simple=1
    )
    assert VariablesAnnotationsTransformer.transform(input_1) == True


# Generated at 2022-06-12 04:23:33.209383
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert 'Transform' in dir(VariablesAnnotationsTransformer)
    assert 'transform' in dir(VariablesAnnotationsTransformer)

# Generated at 2022-06-12 04:23:38.636838
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..types import TransformationResult

    mock_node_1: ast.AST = ast.parse('a: int = 10').body[0]
    mock_node_2: ast.AST = ast.parse('b: int').body[0]
    mock_node_3: ast.AST = ast.parse('c: int = 15').body[0]
    mock_tree: ast.AST = ast.parse('')
    mock_tree.body = [
        mock_node_1,
        mock_node_2,
        mock_node_3
    ]

    transformation_result = VariablesAnnotationsTransformer.transform(mock_tree)
    expected_transformed_result: ast.AST = ast.parse('')

# Generated at 2022-06-12 04:23:46.676538
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTransformer
    from .assignment_expressions_transformer import AssignmentExpressionsTransformer
    from .typing_annotation_transformer import TypingAnnotationTransformer
    from .class_typing_transformer import ClassTypingTransformer
    from .class_body_transformer import ClassBodyTransformer
    from .class_methods_transformer import ClassMethodsTransformer
    from .class_object_constructor_transformer import ClassObjectConstructorTransformer
    from .conditions_transformer import ConditionsTransformer
    from .functions_transformer import FunctionsTransformer
    from .list_comprehensions_transformer import ListComprehensionsTransformer
    from .list_comprehensions_transformer import ListComprehensionsTransformer
    from .loops_transformer import LoopsTransformer

# Generated at 2022-06-12 04:23:48.110489
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.AST())
    print('Test VariablesAnnotationsTransformer is finished')

# Generated at 2022-06-12 04:23:51.004979
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test transform
    source = parse("""
    a: int = 10
    """)
    tree = VariablesAnnotationsTransformer.transform(source).tree
    assert str(tree) == """
    a = 10
    """

# Generated at 2022-06-12 04:23:55.980234
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import make_tempfile

    source = """
a: int = 10
b: int
    """

    expected = make_tempfile("""
a = 10
    """)

    t = VariablesAnnotationsTransformer()
    result = t.transform(source)

    assert result.tree == expected
    assert result.transformed == True
    assert result.warnings == []

# Generated at 2022-06-12 04:24:04.039572
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTestTransformer
    from .mock_ast import MockAst

    # test 1
    code = """
    class Test:
        def func(a: int = 10,
                 b: int):
            pass
    """
    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    expected = """
    class Test:
        def func(a: int, b: int):
            a = 10
            pass
    """
    assert(BaseTestTransformer.compare_ast(expected, new_tree['tree']))

    # test 2
    code = """
    def func(a: int = 10,
             b: int):
        pass
    """
    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform

# Generated at 2022-06-12 04:24:13.217102
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast

    a = ast.AnnAssign()
    a.target = ast.Name(id="a", ctx=ast.Store())
    a.annotation = ast.Str(s="int")
    a.value = ast.Num(n=10)
    a.simple = 1

    b = ast.AnnAssign()
    b.target = ast.Name(id="b", ctx=ast.Store())
    b.annotation = ast.Str(s="int")
    b.value = None
    b.simple = 1

    stmt_list = [a, b]

    module = ast.Module()
    module.body = stmt_list

    result = VariablesAnnotationsTransformer.transform(module)
