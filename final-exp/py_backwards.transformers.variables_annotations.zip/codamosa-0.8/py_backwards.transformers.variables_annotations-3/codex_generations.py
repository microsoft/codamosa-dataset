

# Generated at 2022-06-12 04:14:19.900585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass


# Generated at 2022-06-12 04:14:22.007081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer()
    assert class_obj.target == (3, 5)


# Generated at 2022-06-12 04:14:32.595896
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Body is a list, should be a tuple
    tree = ast.parse('a: int = 10')
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10, kind=None), type_comment=Name(id='int', ctx=Load()))\n"

    # Body is a list, should be a tuple
    tree = ast.parse('a: int = 10\n'
                     'b: int\n'
                     'c = 11')
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-12 04:14:36.805358
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit tests for VariablesAnnotationsTransformer."""
    source_code = '''a: int = 10
b: int'''
    expected_code = '''a = 10'''
    tree = ast.parse(source_code)
    tree = VariablesAnnotationsTransformer.transform(tree=tree)

    # to_source converts the tree back to python syntax
    assert(to_source(tree) == expected_code)

# Generated at 2022-06-12 04:14:41.323029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_input = ast.parse("""
    def f():
        a: int = 10
        b: int
    """)

    expected_output = ast.parse("""
    def f():
        a = 10
    """)

    assert(VariablesAnnotationsTransformer.transform(test_input).tree == expected_output)

# Generated at 2022-06-12 04:14:48.442487
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # It should not warn when the target node is not found
    target_node = ast.Expr(value=ast.NameConstant(value=False))
    parent_node = ast.Module(body=[target_node])
    VariablesAnnotationsTransformer.transform(parent_node)
    
    # This test is suppose to fail
    target_node = ast.Expr(value=ast.NameConstant(value=False))
    parent_node = ast.Module(body=[target_node])
    assert(VariablesAnnotationsTransformer.transform(parent_node) == None)

# Generated at 2022-06-12 04:14:54.156657
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse("""
a: int = 10
b: int
""")

    transformer = VariablesAnnotationsTransformer(target_python_version=(3, 5))
    _, tree_changed, _ = transformer.transform(tree)
    assert tree_changed

    assert tree.body[0].__class__ == ast.Assign
    assert tree.body[1].__class__ == ast.Assign

# Generated at 2022-06-12 04:14:58.782025
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    f = VariablesAnnotationsTransformer()
    assert( isinstance(f, BaseTransformer) )
    assert( isinstance(f, VariablesAnnotationsTransformer) )
    assert( isinstance(f.target, tuple) )
    assert( f.target[0] == 3 )
    assert( f.target[1] == 5 )
    assert( f.transform != None )

# Generated at 2022-06-12 04:15:09.735269
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("b = 3"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 5"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 12"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 6"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("b: int"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("if a: int = 6: pass"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("elif b: int: pass"))
    assert VariablesAnnotationsTransformer.transform(ast.parse("else: int"))

# Generated at 2022-06-12 04:15:19.513796
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    prog = ast.Module(
        body=[ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=ast.Num(n=10))]
    )
    new_prog = VariablesAnnotationsTransformer.transform(prog)
    assert type(new_prog.tree) == ast.Module
    assert type(new_prog.tree.body[0]) == ast.Assign
    assert new_prog.tree.body[0].targets[0].id == 'a'
    assert new_prog.tree.body[0].value.n == 10
    assert new_prog.tree.body[0].type_comment.id == 'int'

# Generated at 2022-06-12 04:15:30.344342
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    # python3 code
    input_code = textwrap.dedent('''\
        def func1(a: str, b: int):
            return a+b
    ''')
    expected_code = textwrap.dedent('''\
        def func1(a, b):
            return a+b
    ''')

    # Act
    input_ast = ast.parse(input_code)
    VariablesAnnotationsTransformer.transform(input_ast)
    output_code = compile(input_ast, '', 'exec')

    # Assert
    assert input_code != output_code
    assert output_code == expected_code

# Generated at 2022-06-12 04:15:34.447321
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """
a: int = 10
b: int
    """

    expected_code = """
a = 10
"""

    tree = ast.parse(input_code)
    tree = VariablesAnnotationsTransformer.transform(tree)

    assert ast.dump(tree) == expected_code

# Generated at 2022-06-12 04:15:41.895592
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    def func(a: int, b: int) -> None:
        a: int = 10
    """
    expected = """
    def func(a: int, b: int) -> None:
        pass
    """
    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 04:15:42.679879
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert True

# Generated at 2022-06-12 04:15:47.011606
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("""x: int = 10""")).code == ""
    assert VariablesAnnotationsTransformer.transform(ast.parse("""x: str = 10""")).code == ""
    assert VariablesAnnotationsTransformer.transform(ast.parse("""x: int = 10\nx: int""")).code == ""

# Generated at 2022-06-12 04:15:57.524742
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .helpers import get_test_ast, get_test_text

    # Getting test text for VariablesAnnotationsTransformer.transform()
    str_input1 = open('test/test_files/VariablesAnnotationsTransformer_input1.txt', 'r').read()
    str_output1 = open('test/test_files/VariablesAnnotationsTransformer_output1.txt', 'r').read()

    # Getting test text for VariablesAnnotationsTransformer.transform()
    str_input2 = open('test/test_files/VariablesAnnotationsTransformer_input2.txt', 'r').read()
    str_output2 = open('test/test_files/VariablesAnnotationsTransformer_output2.txt', 'r').read()

    # Getting test text for VariablesAnnotationsTransformer.transform()
    str_input3

# Generated at 2022-06-12 04:16:06.709259
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import AnnAssign
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from ..types import TransformationResult
    a = 0
    b = 0
    node = AnnAssign(target = ast.Name(id = 'a', ctx = ast.Store()), annotation = ast.Name(id = 'int', ctx = ast.Load()), value = ast.Num(n = 10), simple = 1)
    assert node.__class__ == AnnAssign
    assert isinstance(node, ast.AST)
    assert isinstance(node, BaseTransformer)
    assert VariablesAnnotationsTransformer.transform(node).tree == None
    assert VariablesAnnotationsTransformer.transform(node).tree_changed

# Generated at 2022-06-12 04:16:08.765487
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer.transform(
        ast.parse('a: int = 10'))

    result_expected = ast.parse(
        'a = 10')

    assert ast.dump(result.tree) == ast.dump(result_expected)

# Generated at 2022-06-12 04:16:13.201567
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import dump

    class_ = VariablesAnnotationsTransformer
    tree = dump(generate_code('''
    a: int = 10
    b: int
    '''))

    print(class_.transform(tree).tree.body[1])
    print(class_.transform(dump(generate_code('''
    a: int = 10
    '''))).tree.body[1])

# Generated at 2022-06-12 04:16:22.048952
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast as pyast
    from .._helper import ast, transform
    var = ast(pyast.AnnAssign(target=pyast.Name(id='a', ctx=pyast.Store()), annotation=None,
                              value=pyast.Num(n=1), simple=1))
    tree = ast(pyast.Module(body=[var]))
    expected = ast(pyast.Module(body=[ast(pyast.Assign(targets=[pyast.Name(id='a', ctx=pyast.Store())],
                                              value=pyast.Num(n=1)))]))
    result = transform(VariablesAnnotationsTransformer.transform, tree)
    assert result == expected


# Generated at 2022-06-12 04:16:28.529152
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()
# test_VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:16:36.643088
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    cls = VariablesAnnotationsTransformer

    # No body
    tree = ast.parse('a: int = 10')
    desired = TransformationResult(tree, False, [])
    actual = cls.transform(tree)
    assert actual == desired

    # No annotation
    tree = ast.parse('def f():\n    a = 10')
    desired = TransformationResult(tree, False, [])
    actual = cls.transform(tree)
    assert actual == desired

    # Remove annotation
    tree = ast.parse('def f():\n    a: int = 10')
    tree.body[0].body[0] = cls.transform(tree.body[0].body[0]).ast
    desired = ast.parse('def f():\n    a = 10')
    assert tree

# Generated at 2022-06-12 04:16:39.200690
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    baseTransformer = BaseTransformer()
    assert isinstance (VariablesAnnotationsTransformer, object)


# Generated at 2022-06-12 04:16:46.961232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    node = ast.AnnAssign(target=ast.Name(id='x', ctx=ast3.Load()),
                         annotation=ast.Name(id='int', ctx=ast3.Load()),
                         value=ast.Num(n=10, kind=None))

    tree = ast.Module(body=[node])
    new_tree, _ = VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(new_tree))
    assert isinstance(new_tree.body[0], ast.Assign)
    assert isinstance(new_tree.body[0].value, ast.Num)

# Generated at 2022-06-12 04:16:54.108465
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  code = '''
a: int = 10
b: int
c: int = 10
  '''
  tree = ast.parse(code)
  t = VariablesAnnotationsTransformer()
  new_tree = t.visit(tree)
  # print(ast.dump(new_tree))
  # print(ast.dump(VariablesAnnotationsTransformer.transform(tree)[0]))
  assert((ast.dump(new_tree) == ast.dump(VariablesAnnotationsTransformer.transform(tree)[0])))

# Generated at 2022-06-12 04:16:57.742895
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast, parse
    from ..utils.helpers import dump_python_source

    tree: ast.Module = parse('a: int = 10\nb: int')

    VariablesAnnotationsTransformer.transform(tree)

    assert dump_python_source(tree) == 'a = 10\n'

# Generated at 2022-06-12 04:16:59.165819
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    pass

# Generated at 2022-06-12 04:17:04.093680
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.code_gen import to_source
    from ..utils.helpers import parse

    code = '''
        a: int = 10
        b: int
    '''

    tree = parse(code)
    result = to_source(tree)
    expected_result = '''
        a = 10

    '''

    print(result)
    assert result == expected_result

# Generated at 2022-06-12 04:17:10.754053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test origin Tree
    origin_tree = ast.parse(
        """
a: int = 10
b: int
        """
    )
    # test expected Tree
    expected_tree = ast.parse(
        """
a = 10
        """
    )

    # test actual Tree
    actual_tree = VariablesAnnotationsTransformer.transform(origin_tree).tree
    # check if the transform tree equals to expected tree
    assert ast.dump(actual_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:17:14.980627
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case n. 1
    tree = ast.parse('a: int = 10\nb: int', '', 'exec')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    result_code = compile(result.tree, '', 'exec')
    exec(result_code)
    assert a == 10


# Generated at 2022-06-12 04:17:27.949947
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    ast1 = ast.parse("a: int = 10\nb: int")

    t1 = VariablesAnnotationsTransformer()
    result = t1.transform(ast1)
    ast2 = ast.parse("a = 10")

    assert astor.to_source(result[0]) == astor.to_source(ast2)

# Generated at 2022-06-12 04:17:37.876860
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from mocked_ast import gen_ast
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn

    tree = gen_ast("""a: int = 10
    b: int
    """)
    result = TransformationResult(tree, False, [])
    assert (result.tree == tree and result.is_changed == False and result.messages == [])
    with pytest.raises(NodeNotFound):
        assert get_non_exp_parent_and_index(tree, result.tree.a)
    n = ast.Name(id='a',
                 ctx=ast.Load())

# Generated at 2022-06-12 04:17:41.360267
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
        a: int = 10
        b: int
    """)
    expected = ast.parse("""
        a = 10
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert node_to_str(tree) == node_to_str(expected)

# Generated at 2022-06-12 04:17:43.287727
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:17:45.621197
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import load_ast
    from .base import BaseTransformer


# Generated at 2022-06-12 04:17:48.010351
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3,5)


# Generated at 2022-06-12 04:17:54.818352
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    classExpVar = ast.ClassDef(name='example', body=[ast.Pass(), ast.AnnAssign(
        target=ast.Name(id='exampleVar1', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(10))]) # type: ast.ClassDef
    result_example = VariablesAnnotationsTransformer.transform(classExpVar)
    assert result_example.tree_changed == True
    assert result_example.tree.body[1].__class__ == ast.Assign

# Generated at 2022-06-12 04:18:01.133747
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name(id="a"), annotation=ast.Name(id="int"),
                         value=ast.Num(n=10))
    output = VariablesAnnotationsTransformer.transform(node)
    assert isinstance(output.transformed[0],ast.Assign)
    assert output.transformed[0].targets[0].id == "a"
    assert output.transformed[0].value.n == 10
    assert output.transformed[0].type_comment.id == "int"
    assert output.tree_changed == True



# Generated at 2022-06-12 04:18:04.593561
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass
#    # Example 1: Variable Assignment
    a: int
    b: int
    c: float

    # Example 2: Variable Assignment with Value
    a: int = 10
    b: float = 20.0
    c: str = "Hello World"

# Generated at 2022-06-12 04:18:09.283715
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')) == TransformationResult(ast.parse('a = 10'), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int')) == TransformationResult(ast.parse('pass'), False, [])

# Generated at 2022-06-12 04:18:36.069755
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    for class_name in ['VariablesAnnotationsTransformer']:
        if globals().get(class_name) is None:
            raise NotImplementedError(f'Class "{class_name}" is not implemented')
        globals()[class_name].__module__ = __name__

    name_found = False

# Generated at 2022-06-12 04:18:45.504948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open('tests/samples/class_variable.py') as sample:
        tree = ast.parse(sample.read())
        
    node1 = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store(), annotation=None),
        annotation=ast.Name(id='str', ctx=ast.Load(), annotation=None),
        value=ast.Str(s='Hello', kind=None, annotation=None),
        simple=0
    )
    node2 = ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store(), annotation=None)],
        value=ast.Str(s='Hello', kind=None, annotation=None),
        type_comment=ast.Name(id='str', ctx=ast.Load(), annotation=None)
    )

# Generated at 2022-06-12 04:18:49.630345
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse("""a: int = 1\n""")
    VariablesAnnotationsTransformer.transform(node)
    assert(ast.dump(node) == "Module([Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])")

# Generated at 2022-06-12 04:18:50.578649
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass
    #TODO: use sample test case

# Generated at 2022-06-12 04:18:51.937249
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:18:59.654055
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Dummy:
        def __init__(self):
            self.x = ""
            self.y = None
            self.z = False
            self.a = True
            self.b = 0
            self.c = 0
            self.d = 0

    code = astor.to_source(Dummy)
    parsed_tree = astor.parse_file(StringIO(code))
    assert parsed_tree.body[0].body[0].annotation is None
    assert parsed_tree.body[0].body[1].annotation is None
    assert parsed_tree.body[0].body[2].annotation is None
    assert parsed_tree.body[0].body[3].annotation is None
    assert parsed_tree.body[0].body[4].annotation is None

# Generated at 2022-06-12 04:19:09.291346
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    # Create an instance of Class VariablesAnnotationsTransformer
    ins = VariablesAnnotationsTransformer()
    # Create a new ast.AST() instance
    tree= ast.AST()
    # Create a new ast.Module() instance
    module = ast.Module()
    # Create a new ast.AnnAssign() instance
    annAssign = ast.AnnAssign()
    # Create a new ast.AnnAssign() instance
    annAssign2 = ast.AnnAssign()

    # Assign a value of a string to ast.AnnAssign().target.id
    annAssign.target.id = "a"
    # Assign a value of a string to ast.AnnAssign().annotation.id
    annAssign.annotation.id = "int"
    # Assign a value of a string to ast.

# Generated at 2022-06-12 04:19:15.965398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test that VariableAnnotationsTransformer class works as expected in the following cases:
        - Assignment outside of body
        - Only removing annotations
        - Inserting new Assign block
    """
    from typed_ast import ast3 as ast
    from ..utils.tree import dump

    tree = ast.parse("""
a: int = 10
b: int
c = 10
""")

    parent = ast.Module(body=[tree])

    tree = VariablesAnnotationsTransformer.transform(parent)

    dump(tree)


# Generated at 2022-06-12 04:19:18.411696
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3
    a = typed_ast.ast3.AnnAssign()
    b = VariablesAnnotationsTransformer()
    b.transform(a)

# Generated at 2022-06-12 04:19:26.560815
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    tree = ast.Module(body=[ast.AnnAssign(target=ast.Name('a', ast.Store()),
                                          annotation=ast.Name('int', ast.Load()),
                                          simple=1, value=ast.Num(10))])
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree) == TransformationResult(
        ast.Module(body=[ast.Assign(
            targets=[ast.Name('a', ast.Store())],
            value=ast.Num(10),
            type_comment=ast.Name('int', ast.Load())
        )]), True, []
    )

# Generated at 2022-06-12 04:20:11.028026
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    a = ast.parse('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(a)
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed
    assert isinstance(result.tree, ast.Module)
    assert len(result.tree.body)==1
    assert isinstance(result.tree.body[0], ast.Assign)
    assert len(result.tree.body[0].targets)==1
    assert isinstance(result.tree.body[0].targets[0], ast.Name)

# Generated at 2022-06-12 04:20:20.971623
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import source_to_tree
    from ..utils.helpers import assert_transformer_result
    from .variables_annotations import VariablesAnnotationsTransformer

    source = """
        a: int = 10
        b: int
    """
    expected_ast = """
        Module(body=[
            Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment='int'),
            AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)
        ])
    """
    tree = source_to_tree(source)
    assert_transformer_result(VariablesAnnotationsTransformer, tree, expected_ast, [3, 5])

# Generated at 2022-06-12 04:20:25.066817
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test = """
    a: int = 10
    b: int = a + 1
    """

    expected = """
    a = 10
    b = a + 1
    """
    #TODO:
    # Compiler return str:
    # <Program:None:2:0>
    # as opposed to ast.AST
    Compiler.parse(test)

# Generated at 2022-06-12 04:20:33.181888
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_func = ast.parse("""def test_func():
                                  a: int = 10
                                  b: int
                              """,
                           mode='exec')
    result = VariablesAnnotationsTransformer.transform(test_func)
    assert(len(result.warnings) == 0)
    assert(isinstance(result.tree, ast.Module))
    assert(isinstance(result.tree.body[0], ast.FunctionDef))
    assert(len(result.tree.body[0].body) == 2)
    assert(result.transformed)
    assert(isinstance(result.tree.body[0].body[0], ast.Assign))
    assert(isinstance(result.tree.body[0].body[1], ast.Assign))

# Generated at 2022-06-12 04:20:36.635683
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    node = ast.Assign(targets=[ast.Name(id='a')], value=ast.Constant(value=10), type_comment=ast.Name(id='int'))
    print(VariablesAnnotationsTransformer.transform(node))


# Generated at 2022-06-12 04:20:38.763266
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = VariablesAnnotationsTransformer()
    assert a.target == (3, 5)



# Generated at 2022-06-12 04:20:41.695965
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # arranges
    input_param = ast.parse("y: int\nz: int = 3")

    # act
    actual_result = VariablesAnnotationsTransformer.transform(input_param)

    # assert
    assert actual_result.tree == ast.parse("z = 3")

# Generated at 2022-06-12 04:20:44.955131
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10
                        b: int
                        c = 10""")
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree_changed.ast_tree) == "a = 10\n" + "c = 10\n"

# Generated at 2022-06-12 04:20:50.386756
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.transforms import VariablesAnnotationsTransformer
    from .transformer_test_common import check_transformations_on_files
    check_transformations_on_files(
        ast,
        VariablesAnnotationsTransformer,
        './test/test_samples/variables_annotations_transform_sample.py',
        './test/test_samples/variables_annotations_transform_out.py',
        'VariablesAnnotationsTransformer'
    )

# Generated at 2022-06-12 04:20:54.244252
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))
  VariablesAnnotationsTransformer.transform(ast.parse('a = 10; b = 20'))
  VariablesAnnotationsTransformer.transform(ast.parse('a = 10'))
  VariablesAnnotationsTransformer.transform(ast.parse('a: int'))

# Generated at 2022-06-12 04:22:37.595313
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.parse(
        'def foo(a: int, b: int) -> str:',
        mode='exec'
    )
    node1 = node1.body[0].body[0]

    node2 = ast.parse(
        'a: int = 10',
        mode='exec'
    )
    node2 = node2.body[0]

    node3 = ast.parse(
        'b: int',
        mode='exec'
    )
    node3 = node3.body[0]
    node = ast.Assign(targets=[node2.target], value=node2.value, type_comment=node2.annotation)
    node4 = ast.Assign(targets=[node3.target], type_comment=node3.annotation)


# Generated at 2022-06-12 04:22:42.705195
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = 'a: int = 10\nb: int'
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10)), Name(id='b', ctx=Store(), type_comment='int')])"

# Generated at 2022-06-12 04:22:43.572680
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast import parse


# Generated at 2022-06-12 04:22:49.102715
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    import astor
    from pythran.typed_ast import ast3 as typed_ast3
    from pythran.transformations import VariablesAnnotationsTransformer
    v = ast3.Variable(ast3.Name("a", ast3.Load(), None, None, None), None, None)
    a = ast3.AnnAssign(v, ast3.Name("int", ast3.Load(), None, None, None), ast3.Num(10), None, None)
    d = ast3.Module(astor.to_source(ast3.FunctionDef("f", None, None, [], [], [a], [], None)))

# Generated at 2022-06-12 04:22:53.906365
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    source = '''def func(a, b):
                    a: int = 10
                    b: int
               '''
    expected = '''def func(a, b):
                    a = 10
                    b
               '''
    tree = ast.parse(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-12 04:22:59.225948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    isinstance(tree, ast.Module)
    isinstance(tree.body[0], ast.Expr)
    isinstance(tree.body[0].value, ast.Num)
    isinstance(tree.body[1], ast.Assign)

# Generated at 2022-06-12 04:23:01.055541
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_object = VariablesAnnotationsTransformer()
    assert class_object.target == (3, 5)

# Generated at 2022-06-12 04:23:02.625740
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v_a = VariablesAnnotationsTransformer()
    assert v_a.target == (3, 5)

# Generated at 2022-06-12 04:23:07.615974
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='str', ctx=ast.Load()),
        value = ast.Str(s='hello'),
        simple=1,)
    tree = ast.Module(body=[var])

    v = VariablesAnnotationsTransformer()
    v.transform(tree)
    print(ast.dump(tree))

# Generated at 2022-06-12 04:23:16.138600
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import add_local_variable
    from . import get_variable_value
    from . import variables_annotations

    transformations = [add_local_variable, get_variable_value, variables_annotations]

    src = '''
        from typing import Any
        from typing import List
        x:Any = [10,20]
        y:List[int] = [10,20]
        z:Any = \"\"
    '''

    expected = '''
        from typing import Any
        from typing import List
        x = [10,20]
        y = [10,20]
        z = \"\"
    '''

    result = "\n".join(transformations_to_code(transformations, src))

    assert expected in result

if __name__ == '__main__':
    test_VariablesAnnotationsTrans