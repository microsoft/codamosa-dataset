

# Generated at 2022-06-12 04:14:25.644191
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Using a pre-defined class
    data = "a: int = 10\nb: int"
    expected = "a = 10"
    result = VariablesAnnotationsTransformer.transform(astor.parse_file(data))
    # Check if the returned node value is equal to the expected result
    assert(astor.to_source(result[0]) == expected)


# Generated at 2022-06-12 04:14:27.285869
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.visitor import transform
    from ..utils.helpers import ast_to_source


# Generated at 2022-06-12 04:14:32.174779
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse("a:int = 10")
    node = node.body[0]
    actual = VariablesAnnotationsTransformer.transform(node)
    expected = ast.parse("a = 10")
    expected = expected.body[0]
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 04:14:33.436324
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-12 04:14:34.734127
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vt = VariablesAnnotationsTransformer()
    assert vt.target == (3, 5)

# Generated at 2022-06-12 04:14:45.813619
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10))
    tree = ast.Module(body=[node1])
    # print(ast.dump(tree))
    result = VariablesAnnotationsTransformer.transform(tree)
    # print(ast.dump(result[0]))
    assert ast.dump(result[0]) == ast.dump(tree)
    assert result[1] is False
    assert result[2] == []
    
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), value=ast.Num(n=10), annotation=ast.parse('int').body[0].value)

# Generated at 2022-06-12 04:14:50.329850
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    import inspect
    import textwrap
    source_code_to_check = textwrap.dedent(inspect.getsource(VariablesAnnotationsTransformer))
    to_check = ast.parse(source_code_to_check)
    assert ast.dump(to_check) == ast.dump(ast.parse(source_code_to_check))

# Generated at 2022-06-12 04:14:51.749740
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))

# Generated at 2022-06-12 04:14:53.130112
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:14:54.021402
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert callable(VariablesAnnotationsTransformer.transform)

# Generated at 2022-06-12 04:15:02.679440
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    orig = ast.AnnAssign(target=ast.Name("a", ast.Load()),
                      annotation=ast.Name("int", ast.Load()),
                      value=ast.Num(10))
    # a = 10
    expected = ast.Assign(targets=[ast.Name("a", ast.Load())],
                      value=ast.Num(10),
                      type_comment=ast.Name("int", ast.Load()))
    VariablesAnnotationsTransformer.check_tree_transformation(orig, expected)

    # b: int
    orig = ast.AnnAssign(target=ast.Name("b", ast.Load()),
                      annotation=ast.Name("int", ast.Load()),
                      value=None)
    # Skip this case because we do not support it
    VariablesAn

# Generated at 2022-06-12 04:15:06.739202
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a :int = 10\nb :int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(ast.parse('a = 10'))

# Generated at 2022-06-12 04:15:07.697705
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer


# Generated at 2022-06-12 04:15:17.604618
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # arrange
    target = (3, 5)
    tree_4 = ast.parse("""a: int = 1
b, c = 2, 3
d = 4
e = 5
""")
    tree_5 = ast.parse("""a: int = 1
b, c = 2, 3
d: int
e: int
""")
    expected_result_tree_5 = ast.parse("""a = 1
b, c = 2, 3
e: int
""")
    # act
    result_tree_3 = VariablesAnnotationsTransformer.transform(tree_5)
    result_tree_4 = VariablesAnnotationsTransformer.transform(tree_5)
    # assert
    assert result_tree_3.version == 3
    assert result_tree_3.tree == expected_result_tree_5
    assert result

# Generated at 2022-06-12 04:15:22.148384
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Foo:
        def bar(self):
            a: int = 5
            b: int

    assert VariablesAnnotationsTransformer.transform(ast.parse(inspect.getsource(Foo))) == (
        'class Foo:\n'
        '    def bar(self):\n'
        '        a = 5\n'
        '        b\n'
    )

# Generated at 2022-06-12 04:15:25.710008
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test import generate_unformatted_code
    from .class_initializer_to_constructor import ClassInitializerToConstructorTransformer
    from .variables_annotations import VariablesAnnotationsTransformer


# Generated at 2022-06-12 04:15:30.659116
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .utils import get_test_data

    p = ast.parse(get_test_data('a.py', 'py3'))
    VariablesAnnotationsTransformer.transform(p)

    assert ast.dump(p) == "Module(body=[Expr(value=NameConstant(value=None))], type_ignores=[])\n"

# Generated at 2022-06-12 04:15:37.443994
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_program
    from ..utils.test_utils import get_test_prog_1_ast
    expected_output = """
a = 10
d = 'dfs'
f = 10.0
b = 10
c = 0
d = 10

"""
    actual_output = assert_program(get_test_prog_1_ast, VariablesAnnotationsTransformer)
    assert actual_output == expected_output

# Generated at 2022-06-12 04:15:41.814241
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from astunparse import dump
    from .variables_annotations import VariablesAnnotationsTransformer


# Generated at 2022-06-12 04:15:43.539690
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer()
    assert v.target == (3, 5)



# Generated at 2022-06-12 04:15:49.192604
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-12 04:15:51.644270
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer(None)
    assert transformer.deletes_tree is False
    assert transformer.creates_new_tree is False

# Generated at 2022-06-12 04:16:00.734868
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import unittest

    class VariablesAnnotationsTransformerTestCase(unittest.TestCase):
        def setUp(self):
            self.transformer = VariablesAnnotationsTransformer()

        def test_transform(self):
            tree = inspect.cleandoc(
                '''
                a: int = 10
                b: int
                ''')

            tree = ast.parse(tree)
            self.assertIsInstance(tree.body[0], ast.AnnAssign)
            self.assertIsInstance(tree.body[1], ast.AnnAssign)

            tree = self.transformer.transform(tree)
            self.assertIsInstance(tree.body[0], ast.Assign)
            self.assertIsInstance(tree.body[1], ast.Assign)

    unittest.main()

# Generated at 2022-06-12 04:16:08.368854
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    cls = VariablesAnnotationsTransformer()
    print(cls)

    s = """
a: int = 10
b: int
"""
    ast_tree = ast.parse(s)
    cls.transform(ast_tree)
    print(astor.to_source(ast_tree))

    s = """
a: int
b: int
"""
    ast_tree = ast.parse(s)
    cls.transform(ast_tree)
    print(astor.to_source(ast_tree))

    s = """
a: int = 10
b: int = 20
"""
    ast_tree = ast.parse(s)
    cls.transform(ast_tree)
    print(astor.to_source(ast_tree))

# Generated at 2022-06-12 04:16:12.198130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
a: int = 10
b: int
c: int = 20
    """
    expected_code = """
a = 10
c = 20
    """
    x = ast.parse(code)
    VariablesAnnotationsTransformer.transform(x)
    assert ast.dump(x, include_attributes=True) == expected_code


# Generated at 2022-06-12 04:16:15.731935
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class1 = ClassVisitor()
    class1.visit(ast.parse(inspect.getsource(VariablesAnnotationsTransformer)))
    assert(class1.name == "VariablesAnnotationsTransformer")
    assert(class1.extends == "BaseTransformer")


# Generated at 2022-06-12 04:16:25.684025
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    annt_assign = ast.AnnAssign(target=ast.Name(id='x'),
                                value=ast.Num(n=2),
                                annotation=ast.Subscript(value=ast.Name(id='int'),
                                                         slice=ast.Index(value=ast.Name(id='None')),
                                                         ctx=ast.Load()),
                                simple=1)

# Generated at 2022-06-12 04:16:28.290192
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_name = VariablesAnnotationsTransformer.__name__
    print('\nUnit test for class ' + class_name)

# Generated at 2022-06-12 04:16:32.181980
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Constructor for class VariablesAnnotationsTransformer does not
    # have inputs.
    vat = VariablesAnnotationsTransformer()
    # The target should be (3, 5)
    assert vat.target == (3, 5)

# Generated at 2022-06-12 04:16:35.478628
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
        a: int = 10
        b: int
        ''')
    expected = ast.parse('''
        a = 10
        ''')

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree.tree) == ast.dump(expected)

# Generated at 2022-06-12 04:16:49.421567
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_case_1 = "a: int = 10\nb: int"
    test_case_2 = "a: int\nb: int"
    correct_return_1 = "a = 10"
    correct_return_2 = ""

    #Unit test case 1:
    test_1 = VariablesAnnotationsTransformer().transform(test_case_1)
    assert test_1 == correct_return_1

    # Unit test case 2:
    test_2 = VariablesAnnotationsTransformer().transform(test_case_2)
    assert test_2 == correct_return_2

# Generated at 2022-06-12 04:16:54.108334
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree1 = ast.parse("""
    def f(a: int = 10, b: int):
        pass
    """)
    tree2 = ast.parse("""
    def f(a = 10, b):
        pass
    """)
    assert VariablesAnnotationsTransformer.transform(tree1).tree == tree2


# Generated at 2022-06-12 04:16:57.708043
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int\nc: int = 20')
    VariablesAnnotationsTransformer.transform(tree)
    expected = ast.parse('a = 10\nb = int\nc = 20')

    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 04:17:06.979379
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    a = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store(), annotation='int'),
                            ast.Name(id='b', ctx=ast.Store(), annotation='int')],
                   value=ast.Num(n=10))

    res = VariablesAnnotationsTransformer.transform(a)
    assert res.tree_changed
    assert not res.errors
    assert res.tree.value.n == 10
    assert not hasattr(res.tree.targets[0], 'annotation')
    assert res.tree.targets[1].annotation == 'int'


# Generated at 2022-06-12 04:17:08.778016
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test case for constructor of class VariablesAnnotationsTransformer"""
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-12 04:17:14.139050
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_source = '''
    a: int = 10
    b: int
    '''
    expected_output = '''
    \n    a = 10
    \n    \n    '''
    source_ast = ast.parse(input_source)
    tree_changed, new_ast = VariablesAnnotationsTransformer.transform(source_ast)
    assert tree_changed == True
    assert astor.to_source(new_ast) == expected_output

# Generated at 2022-06-12 04:17:21.493150
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    tree.body[0] = ast.AnnAssign(target = ast.Name(id = 'a',
                                                   annotation = ast.Name(id = 'int'),
                                                   ctx = ast.Store()
                                                   ),
                                 annotation = ast.Name(id = 'int'),
                                 value = ast.Num(n = 10)
                                 )
    tree1 = ast.parse('a: int')
    tree1.body[0] = ast.AnnAssign(target = ast.Name(id = 'a',
                                                    annotation = ast.Name(id = 'int'),
                                                    ctx = ast.Store()
                                                    ),
                                  annotation = ast.Name(id = 'int'),
                                  value = None
                                  )
    tree

# Generated at 2022-06-12 04:17:30.855768
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case:
    # a: int = 10
    # b: int

    # Expected result:
    # a = 10
    # b

    target = ast.parse(dedent('''
        a: int = 10
        b: int
    '''))

    target_ann_assign = target.body[0]
    assert isinstance(target_ann_assign, ast.AnnAssign)
    assert isinstance(target_ann_assign.target, ast.Name)
    assert isinstance(target_ann_assign.annotation, ast.Name)
    assert isinstance(target_ann_assign.value, ast.Num)

    target_ann_assign_2 = target.body[1]
    assert isinstance(target_ann_assign_2, ast.AnnAssign)

# Generated at 2022-06-12 04:17:33.802662
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_object = VariablesAnnotationsTransformer(3.5)
    assert class_object.target == (3,5)


# Generated at 2022-06-12 04:17:40.092250
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10; b:int")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result, TransformationResult) and \
        isinstance(result.tree, ast.AST)
    assert result.tree_changed is True
    assert result.warnings == []
    assert ast.dump(result.tree) == "Assign(targets=[Name(id='a', ctx=Store())],\
value=Num(n=10), type_comment=Name(id='int', ctx=Load()))"

# Generated at 2022-06-12 04:18:01.244097
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from .test_utils import assert_text_transformed
    from ..utils.helpers import warn
    from ..gotchas import PythonGotchas

    with warn.patch(PythonGotchas):
        assert_text_transformed(VariablesAnnotationsTransformer, """
            def foo():
                a: int = 10
                b: int
            """, """
            def foo():
                a = 10
            """)

# Generated at 2022-06-12 04:18:05.144774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer
    tree = ast.parse('a: int = 10\nb: int')
    assert t.transform(tree) == (
                        ast.parse('a = 10\nb: int'),
                        True,
                        [],
                    )



# Generated at 2022-06-12 04:18:12.942975
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10
                        b: int
                        c: int = 20
                        d: int
                        e: int = 30
                        e = 40
                        f = 40
                        g: int
                        h = 50
                        i: int""")
    VariablesAnnotationsTransformer.transform(tree)
    expected = ast.parse("""a = 10
                            
                            c = 20
                                e = 40
                                g
                                h = 50""")
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 04:18:13.480170
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	pass

# Generated at 2022-06-12 04:18:17.326435
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    line = "a: int = 10"
    expected_line = "a = 10"
    tree = ast.parse(line)
    tree_changed = VariablesAnnotationsTransformer.transform(tree).tree_changed
    assert tree_changed == True
    output = ast.unparse(tree)
    assert output == expected_line

# Generated at 2022-06-12 04:18:25.830531
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-12 04:18:28.632674
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..parser import from_source

    tree = from_source('x: int = 10')

    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert new_tree.code == 'x = 10\n'

# Generated at 2022-06-12 04:18:33.637382
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Simple unit test of VariablesAnnotationsTransformer
    """
    print("Test: Simple unit test of VariablesAnnotationsTransformer ...", end="")
    try:
        tree = ast.parse("a: int = 10\nb: int\n")
        transformed_tree = VariablesAnnotationsTransformer.transform(tree)
        print("passed")
    except:
        print("FAILED")



# Generated at 2022-06-12 04:18:35.435507
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass
    # assert VariablesAnnotationsTransformer.transform(3,5) == 3,5

# Generated at 2022-06-12 04:18:36.707008
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform


# Generated at 2022-06-12 04:19:18.140472
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    root = ast.parse('a: int = 10\nb: int')
    transformer = VariablesAnnotationsTransformer()
    transformed = transformer.transform(root)
    assert ast.dump(transformed.tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=10), type_comment=Name(id="int", ctx=Load())), Assign(targets=[Name(id="b", ctx=Store())], value=None, type_comment=Name(id="int", ctx=Load()))])'

# Generated at 2022-06-12 04:19:21.855395
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    _code = '''
annotation: int
a: int = 10
b: int
c: int
    '''
    _result = '''
annotation = int
a = 10
    '''
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform_code(_code) == _result

# Generated at 2022-06-12 04:19:32.124093
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_annot_assign_tree = ast.parse("""
    def func(a: int, \
    b: int = 10) -> int:
        pass
    """, mode = 'exec')
    test_annot_assign_tree2 = ast.parse("""
    a: int = 10
    b: int
    """, mode = "exec")
    test_annot_assign_tree3 = ast.parse("""
    def func(a: int, b: int = 10) -> int:
        a = 10
        b: int = 20
        pass
    """, mode = 'exec')
    base = VariablesAnnotationsTransformer()

    assert base.transform(test_annot_assign_tree) == (test_annot_assign_tree, False)


# Generated at 2022-06-12 04:19:39.394965
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
a: int = 10
b: int
c: int = 20
d: int''')

    transformer = VariablesAnnotationsTransformer()
    assert isinstance(transformer, VariablesAnnotationsTransformer)
    result = transformer.transform(tree)
    assert isinstance(result, TransformationResult)
    assert result.tree_changed is True

    expected_tree = ast.parse('''
a = 10
c = 20''')
    assert ast.dump(result.tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:19:48.523620
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    t = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(10), simple=1)

    t1 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                       annotation=ast.Name(id='int', ctx=ast.Load()), simple=1)

    t2 = ast.Module(body=[t, t1])
    transform_result = VariablesAnnotationsTransformer.transform(t2)

# Generated at 2022-06-12 04:19:51.854885
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #print(VariablesAnnotationsTransformer.__doc__)
    pass

if __name__ == "__main__":
    # A simple example
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-12 04:20:00.223092
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:20:09.814602
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3,5)

    from typed_ast import ast3
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
        
    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)
        @classmethod
        def transform(cls, tree: ast3.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-12 04:20:13.807401
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    from ..utils.helpers import ast_from_code

    code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = ast_from_code(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert astunparse.unparse(tree) == expected_code

# Generated at 2022-06-12 04:20:21.392829
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .helpers import assert_transformed

    assert_transformed(
        VariablesAnnotationsTransformer,
        """a: int = 10""",
        """a = 10"""
    )

    assert_transformed(
        VariablesAnnotationsTransformer,
        """a: int = 10\nb: int = 10""",
        """a = 10\nb = 10"""
    )

    assert_transformed(
        VariablesAnnotationsTransformer,
        """a: int = 10\nb: int""",
        """a = 10\nb = None"""
    )

# Generated at 2022-06-12 04:21:52.322110
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(VariablesAnnotationsTransformer, object)
    assert isinstance(VariablesAnnotationsTransformer.transform, object)
    assert callable(VariablesAnnotationsTransformer.transform)


# Generated at 2022-06-12 04:21:53.561360
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..refactor_imports import _test_transformer
    _test_transformer(VariablesAnnotationsTransformer)

# Generated at 2022-06-12 04:22:02.094297
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_asts, new_ast_node
    from astunparse import unparse
    from ast import parse as parse_func
    import sys


# Generated at 2022-06-12 04:22:10.009938
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testcase 1: simple case
    test1_tree = ast.parse("a: int = 0")
    result1 = VariablesAnnotationsTransformer.get_transformation_result(test1_tree)
    assert len(result1.tree.body) == 1
    assert type(result1.tree.body[0]) is ast.Assign
    assert type(result1.tree.body[0].value) is ast.Num

    # Testcase 2: Global a = None
    test2_tree = ast.parse("global a; a: int = 0")
    result2 = VariablesAnnotationsTransformer.get_transformation_result(test2_tree)
    assert len(result2.tree.body) == 2
    assert type(result2.tree.body[0]) is ast.Global

# Generated at 2022-06-12 04:22:18.429599
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from . import base
    from .base import test_ast_node

    class Tester(base.BaseTransformerTestCase):
        before = None
        after = None

        def test(self):
            self.check_transform(VariablesAnnotationsTransformer,
                                 self.before,
                                 self.after)

        def test_attach_comments(self):
            self.check_attach_comments(VariablesAnnotationsTransformer,
                                       self.before)

    class test_for_annotations_to_assign(Tester):
        before = """
            a: int = 1
            b = 2
            c: str
            d = True
        """
        after = """
            a = 1
            b = 2
            d = True
        """


# Generated at 2022-06-12 04:22:27.120923
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int'), value=ast.Num(10))
    parent = ast.Module(body=[node])

    transformation = VariablesAnnotationsTransformer.transform(parent)
    assert isinstance(transformation.tree, ast.Module)
    assert len(transformation.tree.body) == 1
    assert isinstance(transformation.tree.body[0], ast.Assign)

    # b: int
    node = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int'), value=None)
    parent = ast.Module(body=[node])

    transformation = VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:22:28.646800
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer()
    assert isinstance(class_obj, BaseTransformer)

# Generated at 2022-06-12 04:22:29.467926
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-12 04:22:36.413118
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast as pyast
    #Unit test for constructor of class VariablesAnnotationsTransformer
    class ListComp(pyast.AST):
        _fields = ('elt', 'generators')
        def __init__(self, elt, generators, lineno=0):
            self.elt = elt
            self.generators = generators
    class Generator(pyast.AST):
        _fields = ('elt', 'generators')
        def __init__(self, elt, generators, lineno=0):
            self.elt = elt
            self.generators = generators
    class Subscript(pyast.AST):
        _fields = ('value', 'slice', 'ctx')
        def __init__(self, value, slice, ctx=None):
            self.value = value
            self.slice = slice

# Generated at 2022-06-12 04:22:42.668058
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_v3 = ast.parse(""" a:int = 10;
                             b:int
                          """)
    assert VariablesAnnotationsTransformer.target == (3, 5)
    result = VariablesAnnotationsTransformer.transform(tree_v3)
    assert result.changed
    assert result.transformed_tree == ast.parse("""
                                                 a = 10;
                                                 b
                                                 """
                                                 )