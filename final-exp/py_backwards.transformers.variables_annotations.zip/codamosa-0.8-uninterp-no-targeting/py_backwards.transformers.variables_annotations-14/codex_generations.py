

# Generated at 2022-06-21 18:19:07.445091
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    node = ast.AnnAssign(target = ast.Name(id = "a"), annotation=ast.Name(id = "int"), value = ast.Num(n = 10), simple = 1)
    VariablesAnnotationsTransformer.transform(node)
    assert node.target == ast.Name(id = "a")
    assert node.annotation == ast.Name(id = "int")
    assert node.value == ast.Num(n = 10)

# Generated at 2022-06-21 18:19:09.528657
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:16.695926
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    a: int = 10
    b: int
    ''')
    transformer = VariablesAnnotationsTransformer()
    tree_changed, _, _ = transformer.transform(tree)
    assert tree_changed == True
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=10), type_comment=Name(id=\'int\', ctx=Load())), Assign(targets=[Name(id=\'b\', ctx=Store())], value=None, type_comment=Name(id=\'int\', ctx=Load()))])\n'

# Generated at 2022-06-21 18:19:21.202631
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    target_tree = ast.parse("""from typing import List
l: List[str] = []
i: int = 3
""")
    tree = VariablesAnnotationsTransformer.transform(target_tree)
    assert(tree.code == "from typing import List\nl = []\ni = 3")

# Generated at 2022-06-21 18:19:30.612639
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    transformCode = VariablesAnnotationsTransformer.transform

    assert transformCode('a: int = 10') == 'a = 10'
    assert transformCode('a:int = 10') == 'a = 10'
    assert transformCode('a: int=10') == 'a = 10'
    assert transformCode('a:int=10') == 'a = 10'

    # Variable without initialization
    assert transformCode('a: int') == 'a = None'
    assert transformCode('a:int') == 'a = None'

    # Variable with other annotations
    assert transformCode('a: int = 10 # comment') == 'a = 10'
    assert transformCode('a:int = 10 # comment') == 'a = 10'
    assert transformCode('a: int=10 # comment') == 'a = 10'

# Generated at 2022-06-21 18:19:37.136597
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import testutils
    source = testutils.build_source_tree('a: int = 10\nb: int')
    expected = testutils.build_source_tree('a = 10')
    result = VariablesAnnotationsTransformer.transform(source)
    testutils.compare_results(result, expected, [])

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:19:47.907340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    """Testing VariablesAnnotationsTransformer"""
    node = ast.AnnAssign(target = ast.Name(id = 'a', ctx = ast.Store()),
                         annotation = ast.Name(id = 'int', ctx = ast.Load()),
                         value = ast.Constant(value = 10),
                         simple = True)
    node2 = ast.AnnAssign(target = ast.Name(id = 'b', ctx = ast.Store()),
                          annotation = ast.Name(id = 'int', ctx = ast.Load()),
                          simple = True)
    body = [node, node2]
    tree = ast.Module(body = body)

# Generated at 2022-06-21 18:19:59.489297
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..parser import PythonParser
    from .test_helpers import create_file, compare_asts

    create_file('test_file.py', '''
a: int = 10
b: int
    ''')

    result = PythonParser.parse_file('test_file.py')
    assert result == [ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), simple=1, value=ast.Num(n=10)),
                      ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), simple=1, value=None)]


# Generated at 2022-06-21 18:20:01.181910
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)


# Generated at 2022-06-21 18:20:12.034492
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    from typed_ast import ast3, parse
    from ..utils.helpers import line_numbers_to_str

    tree = parse('a: int = 1\n')
    tree_copy = copy.deepcopy(tree)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert line_numbers_to_str(tree_copy) == line_numbers_to_str(result.tree)
    tree = parse('a: int\n')
    tree_copy = copy.deepcopy(tree)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert line_numbers_to_str(tree_copy) == line_numbers_to_str(result.tree)

# Generated at 2022-06-21 18:20:27.286444
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:39.106921
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
        '''
        def test():
            a: int = 10
            b: int
        '''
    )
    transformer = VariablesAnnotationsTransformer()
    res = transformer.transform(tree)
    assert len(res.warnings) == 0
    assert res.tree_changed == True
    assert res.new_modules == []

# Generated at 2022-06-21 18:20:43.866652
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
    a: int = 10
    b: int
    """
    expected_tree = ast.parse('''
    a = 10
    ''')
    tree = ast.parse(source)
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert result.tree == expected_tree

# Generated at 2022-06-21 18:20:47.120114
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test for variable annotations in Python 3
    """
    # The following code is Python 3 code for variable annotations

# Generated at 2022-06-21 18:20:57.474725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    class TestTransformer(VariablesAnnotationsTransformer):
        target = (3, 7)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)  # type: ignore


# Generated at 2022-06-21 18:21:07.898585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # First test
    string = """
    x: int = 5
    """
    tree = ast.parse(string)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store(), annotation=Name(id='int', ctx=Load()))], value=Num(n=5))])"

    # Second test
    tree = ast.parse(string)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store(), annotation=Name(id='int', ctx=Load()))], value=Num(n=5))])"

# Generated at 2022-06-21 18:21:10.601000
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer()
    assert class_obj.__class__.__name__ == 'VariablesAnnotationsTransformer'


# Generated at 2022-06-21 18:21:18.220537
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #  a: int = 10
    #  b: int
    # Should be equal to:
    #  a: int = 10
    #  b: int
    test_tree = ast.AnnAssign(target=ast.Name('a',
                                              ast.Load()),
                              annotation=ast.Name('int',
                                                  ast.Load()),
                              simple=1)
    d = VariablesAnnotationsTransformer(test_tree)
    assert d.tree is not None
    assert d.tree_changed == False

# Generated at 2022-06-21 18:21:28.662944
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_utils import should_not_change, should_change
    from .test_utils import load_python_tree
    from ..utils.helpers import is_same_python_node

    def assert_same_nodes(before, after):
        assert is_same_python_node(before, after), \
            "Before node is not the same after transformation"

    # assert_same_nodes
    tree = load_python_tree(should_not_change(VariablesAnnotationsTransformer, """
a = 10
b: int
    """))
    assert_same_nodes(tree, load_python_tree("""
a = 10
b: int
    """))

    # Should change

# Generated at 2022-06-21 18:21:39.773783
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..core import transform
    from ..utils.helpers import ast_print
    from ..utils.helpers import to_tuple
    from ..utils.trees import ast_equals

    class DummyTransformer(BaseTransformer):
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False
            return TransformationResult(tree, tree_changed, [])

    tree = ast.parse("""a: int = 10\nb:int\na""")
    tree_changed, tree, _ = transform(to_tuple(tree), [VariablesAnnotationsTransformer])
    print(ast_print(tree))
    tree = ast.parse("""a = 10\na""")
    assert ast_equals(tree, tree)

# Generated at 2022-06-21 18:21:47.174296
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)
    assert t.transform(1) == "Expected an instance of typed_ast.ast3.AST"


# Generated at 2022-06-21 18:21:52.658831
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    from ..utils import get_ast

    tree = get_ast("""
        a: int = 10
        b: int = 20
        c: int
        """)
    # When
    t = VariablesAnnotationsTransformer()
    result = t.transform(tree)
    # Then
    assert result.source == """
        a = 10
        b = 20
        c: int
        """

# Generated at 2022-06-21 18:21:53.294892
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert True

# Generated at 2022-06-21 18:21:57.975730
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Unit test to check the constructor of class VariablesAnnotationsTransformer
    '''
    tree = ast.parse('''
a: int = 10
b: int
''')
    t = VariablesAnnotationsTransformer()
    t.transform(tree)
    assert(t.target == (3, 5))

# Generated at 2022-06-21 18:22:09.160888
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import build_ast
    from ..utils.helpers import compare_trees
    from ..utils.tree.scope import SymbolScope
    from ..utils.tree.scope import WalkScope
    from ..utils.tree.scope import ScopedTree

    #Variable a: int = 10
    code1 = """
        x: int = 10
        y: int
    """

    #Variable a: int = 10
    code2 = """
        x = 10
        y: int
    """

    tree1 = build_ast(code1, 3)
    tree2 = build_ast(code2, 3)
    tree_changed, transformed_tree, _ = VariablesAnnotationsTransformer.transform(tree1)
    assert tree_changed
    compare_trees(tree1, transformed_tree)

# Generated at 2022-06-21 18:22:16.077765
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('a: int = 10\nb: int') #test_tree is like tree in base.py
    test_VariablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    result = test_VariablesAnnotationsTransformer.transform(test_tree)
    assert(result.tree.body[0].annotation is None)
    assert(result.tree.body[1].annotation is None)
    assert(result.tree.body[0].value.n == 10)
    assert(result.tree.body[1].value is None)
    assert(result.tree_changed)

# Test to see if the variable is not inside a body

# Generated at 2022-06-21 18:22:19.631267
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.name == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-21 18:22:26.204734
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    source = '''
    a: int = 10
    b: int
    '''
    module = ast.parse(source)
    tree = VariablesAnnotationsTransformer.transform(module)
    result_source = astor.to_source(tree.tree)
    expected_source = '''
    a = 10
    '''
    assert result_source == expected_source
    # assert expected_source == result_source
    # assert expected_source == result_source

# Generated at 2022-06-21 18:22:38.921575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations_transformer import tree

    # Initialize the tree
    tree = ast.parse(
        '''
        a: int = 10
        b: int
        '''
    )

    # Make an instance of VariablesAnnotationsTransformer to test
    test_case = VariablesAnnotationsTransformer()

    # Check if instance is an instance of BaseTransformer
    assert isinstance(test_case, BaseTransformer)

    # Check if instance has the right target
    assert test_case.target == (3, 5)

    # Check if instance has the right transform method
    result = test_case.transform(tree)


# Generated at 2022-06-21 18:22:47.888620
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    a1 = ast.AnnAssign(annotation=None,
                                 value=ast.Num(n=10),
                                 value_type=None,
                                 target=ast.Name(id='a',
                                                 ctx=ast.Store(),
                                                 type_comment=None),
                                 simple=1,
                                 type_comment=None)


# Generated at 2022-06-21 18:22:54.104805
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t is not None

# Generated at 2022-06-21 18:22:55.473874
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_class = VariablesAnnotationsTransformer()
    return test_class

# Generated at 2022-06-21 18:23:01.001559
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    input_code = '''
a: int = 10
b: int
    '''
    expected_code = '''
a = 10
    '''

    # When
    cr = compile_restricted(input_code, '<inline code>', 'exec', ast.PyCF_ONLY_AST)
    tree = cr.code
    res = VariablesAnnotationsTransformer.transform(tree)
    generated_code = codegen.to_source(res.tree)

    # Then
    assert expected_code == generated_code

# Generated at 2022-06-21 18:23:12.119199
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestTransformer:
        def __init__(self, test_tree, test_tree_changed, test_generated_code):
            self.test_tree = test_tree
            self.test_tree_changed = test_tree_changed
            self.test_generated_code = test_generated_code

        def transform(self, tree, tree_changed, generated_code):
            assert str(tree) == str(self.test_tree)
            assert tree_changed == self.test_tree_changed
            assert generated_code == self.test_generated_code

    tree = ast.parse("a: int = 10\nb: int\n")

    testTree = ast.parse("a = 10\nb: int\n")
    test_gen = []
    testTransformer = TestTransformer(testTree, True, test_gen)


# Generated at 2022-06-21 18:23:21.712065
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = {
        'body': [{
            'target': {
                'ctx': 'Store',
                'id': 'a'
            },
            'value': {
                'n': 10
            },
            'annotation': {
                'id': 'int'
            },
            'type': 'AnnAssign'
        }],
        'type': 'Module'
    }
    tree_result = ast.parse(str(VariablesAnnotationsTransformer.transform(ast.parse(str(tree))))).body[0]
    print("tree_result\n", ast.dump(tree_result))
    assert ast.dump(tree_result) == "Assign(targets=[Name(id='a', ctx=Store(), type_comment='int')], value=Num(n=10))"

# Generated at 2022-06-21 18:23:25.866529
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import transform, CstLintRuleSet

    tree = ast.parse('''
        a: int = 10
        b: int
        ''')
    result = transform(tree, CstLintRuleSet())

    assert not find(result.tree, ast.AnnAssign)

# Generated at 2022-06-21 18:23:34.524216
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from ..utils.parser import parse
    from ..utils.helpers import to_source
    from .base import BaseTransformer

    source = """
        from typing import Literal
        a: int = 10
        b: int
        c: int = 20
        d: Literal[1, 2] = 3
    """
    tree = parse(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    print(to_source(tree))

    assert to_source(tree) == """
from typing import Literal
from __future__ import annotations
a = 10
b = None
c = 20
d = 3
"""

# Generated at 2022-06-21 18:23:45.446950
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    from typing import List, Any
    class VariablesAnnotationsTransformer(BaseTransformer):
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False
            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)  # type: ignore


# Generated at 2022-06-21 18:23:50.239622
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer
    v_name = 'variables_annotations'
    assert class_obj.__module__ == 'transformers.variables'
    assert class_obj.__name__ == v_name.title().replace('_', '') + 'Transformer'
    assert getattr(class_obj, 'name') == v_name
    assert getattr(class_obj, 'target') == (3, 5)
    assert callable(getattr(class_obj, 'transform'))

# Generated at 2022-06-21 18:23:52.170609
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert isinstance(class_, object)

    # Instantiate class
    instance = class_()
    assert isinstance(instance, VariablesAnnotationsTransformer)


# Generated at 2022-06-21 18:24:13.254503
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(annotation=ast.Name(id='int', ctx=ast.Load()), target=ast.Name(id='a', ctx=ast.Store()), value=ast.Num(n=10))
    b = ast.AnnAssign(annotation=ast.Name(id='int', ctx=ast.Load()), target=ast.Name(id='b', ctx=ast.Store()), value=None)
    tree = ast.Module(body=[a, b])

# Generated at 2022-06-21 18:24:14.618231
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:15.496029
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:23.074628
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class C:
        def f(self, a: int = 10, b: int = 20) -> None:
            pass

    code = inspect.getsource(C.f)

    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(tree))
    # Original code
    # def f(self, a: int = 10, b: int = 20) -> None:
    #     pass
    # Transformed code
    # def f(self, a=10, b=20):
    #     pass

# Generated at 2022-06-21 18:24:28.867662
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
a: int = 10
b: int
    ''')

    expected_tree = ast.parse('''
a = 10
    ''')

    expected_tree_changed = True

    result = VariablesAnnotationsTransformer.transform(tree)
    print(result)
    assert result.tree == expected_tree
    assert result.tree_changed == expected_tree_changed
    assert result.warnings == []

# Generated at 2022-06-21 18:24:38.930454
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class A:
        """A test class"""
        a: int = 10
        b: int = 20

    module = ast.parse('import ast')
    module._fields = ('body',)  # type: ignore
    module.body = [A.a, A.b]  # type: ignore

    expect = ast.parse('''
import ast
a = 10
b = 20
''')
    expect._fields = ('body',)  # type: ignore
    expect.body = [A.a, A.b]  # type: ignore

    transform_result = VariablesAnnotationsTransformer.transform(module)

    assert transform_result.tree == expect
    assert transform_result.tree_changed == True
    assert transform_result.messages == []

# Generated at 2022-06-21 18:24:41.188508
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_object = VariablesAnnotationsTransformer()
    class_object.target = (3, 5)
    return class_object

# Generated at 2022-06-21 18:24:47.231275
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Unit test for constructor of class VariablesAnnotationsTransformer
    code = """a: int = 10"""
    t = ast.parse(code)
    variants = VariablesAnnotationsTransformer.transform(t)
    assert len(variants) == 1
    assert str(variants[0].node) == "a = 10"
    assert variants[0].changes == "Changed VariableAssignments."
    assert variants[0].name == "Assignments"

# Generated at 2022-06-21 18:24:47.797312
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    return

# Generated at 2022-06-21 18:24:50.419852
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('def foo():\na: int = 10')
    VariablesAnnotationsTransformer.transform(test_tree)

# Generated at 2022-06-21 18:25:17.984881
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Set up
    a = ast.parse('a: int = 10\nb: int').body
    b = ast.parse('a = 10').body

    # Exercise
    result = VariablesAnnotationsTransformer.transform(a)

    # Verify
    assert result == TransformationResult(b, True, [])


# Generated at 2022-06-21 18:25:23.089585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    program = """
import numpy as np
a: int = 10
b: int
bb:np.int32 = np.array([1,2,3])
"""
    expected = """
import numpy as np

a = 10
bb=np.array([1,2,3])
"""
    result = VariablesAnnotationsTransformer.transform(program)
    assert str(result) == expected

# Generated at 2022-06-21 18:25:24.789239
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert(vat.target == (3, 5))


# Generated at 2022-06-21 18:25:34.974658
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import make_tree, build_tree_string
    test_code= '''
    a: int = 10
    b: int
    '''
    test_tree = make_tree(test_code)
    print("Test code: " + test_code)
    print("Test parse tree: " + build_tree_string(test_tree))
    result = VariablesAnnotationsTransformer.transform(test_tree)
    print("Transformed parse tree: " + build_tree_string(result.tree))

# Generated at 2022-06-21 18:25:36.580598
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = VariablesAnnotationsTransformer()
    assert isinstance(a, VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:25:41.953509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
a: int = 10
b: int
"""
    expected = """
a = 10
"""

    module = ast.parse(source)
    new_module = VariablesAnnotationsTransformer.transform(module).new_tree
    assert ast.dump(new_module) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 18:25:45.234483
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import TreeTransformer
    from .. import compile_pipeline
    from ..types import PythonVersion

    pipeline = compile_pipeline(VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:25:54.067563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3
    from .base import BaseTransformer
    x = typed_ast.ast3.Name('x', typed_ast.ast3.Load())
    y = typed_ast.ast3.Num(1)
    z = typed_ast.ast3.Name('y', typed_ast.ast3.Load())
    func_def = typed_ast.ast3.FunctionDef('f', typed_ast.ast3.arguments(args=None, vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [typed_ast.ast3.AnnAssign(target=x, annotation=y, value=z)], [])
    tree = typed_ast.ast3.Module([func_def])

# Generated at 2022-06-21 18:26:01.370632
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # generates the AST tree from the text
    from ..utils.tree import source_to_ast, ast_to_source
    from .comments_to_type_comments import CommentsToTypeCommentsTransformer
    from .type_comments_to_annotations import TypeCommentsToAnnotationsTransformer

    expected = 'def f(x: int):\n    x = 5\n    y = 6\n    return x + y\n'
    initial = 'def f(x):\n    # type: (int) -> int\n    x = 5\n    y = 6\n    return x + y\n'
    tree = source_to_ast(initial)
    new_tree = CommentsToTypeCommentsTransformer.transform(tree).tree
    new_new_tree = TypeCommentsToAnnotationsTransformer.transform(new_tree).tree
    new

# Generated at 2022-06-21 18:26:06.374352
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    a: int = 10
    b: int
    ''')
    correct_tree = ast.parse('a = 10')
    t = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(t.tree) == ast.dump(correct_tree)
    assert t.tree_changed == True

# Generated at 2022-06-21 18:27:12.482426
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('\nVariablesAnnotationsTransformer testing')
    tree = ast.parse('a: int = 10\n'
                     'b: int')
    vat = VariablesAnnotationsTransformer()
    print('original tree:', ast.dump(tree))
    result = vat.transform(tree)
    print('after transformation:', ast.dump(result.tree))
    if result.tree_changed:
        print('test passed')
    else:
        print('test not passed')
    print('-----------------------------------------------')

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:27:23.747715
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Compile code
    code = 'a: int = 10\n' \
           'b: int\n' \
           
    tree = ast.parse(code)
    transformed_tree, modified, messages = VariablesAnnotationsTransformer.transform(tree)

    # Compare parsed and transformed ASTs
    assert_equal(modified, True, 'Transformed tree not correct')

# Generated at 2022-06-21 18:27:31.157517
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    print(result.tree_string)
    assert result.tree_string == 'None'

    tree = ast.parse('a: int = 20')
    result = VariablesAnnotationsTransformer.transform(tree)
    print(result.tree_string)
    assert result.tree_string == 'None\n    a = 20\n'

    tree = ast.parse('global a\na: int = 20')
    result = VariablesAnnotationsTransformer.transform(tree)
    print(result.tree_string)
    assert result.tree_string == 'global a\n\na = 20\n'



# Generated at 2022-06-21 18:27:34.104424
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print(VariablesAnnotationsTransformer.transform(
        ast.parse('a: int = 10'
                  '\nb: int')
    ))

# Generated at 2022-06-21 18:27:37.447495
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('''
a: int = 10
b: int
        ''')
    ).tree == ast.parse('a = 10')

# Generated at 2022-06-21 18:27:40.833372
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_string = 'a: int = 10'
    assert VariablesAnnotationsTransformer.transform(ast.parse(test_string)) == TransformationResult(ast.parse('a = 10'))

# Generated at 2022-06-21 18:27:44.877426
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("""
    a = 1
    a: int = 1
    """, mode='exec')) == \
        TransformationResult(ast.parse("""
    a = 1
    a = 1
    """, mode='exec'), True, [])



# Generated at 2022-06-21 18:27:54.948438
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    found = find(tree, ast.AnnAssign)
    parent, index = get_non_exp_parent_and_index(tree, found[0])
    assert parent.body[index].target.id == 'a'
    parent.body.pop(index)
    insert_at(index, parent, ast.Assign(targets=[found[0].target], value=found[0].value, type_comment=found[0].annotation))

# Generated at 2022-06-21 18:28:03.962123
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                         annotation=ast.Name(id='int', ctx=ast.Load()),
                         value=ast.Num(10),
                         simple=1)
    
    # a = 10
    expected = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                          value=ast.Num(10),
                          type_comment=ast.Name(id='int', ctx=ast.Load()))

    ast.fix_missing_locations(expected)

    assert VariablesAnnotationsTransformer.transform(node).tree == expected


# Generated at 2022-06-21 18:28:07.507032
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class T:
        """
        Compiles:
    
        a: int = 10
        b: int
        To:
        a = 10

        """
        transformer = VariablesAnnotationsTransformer
        tree = ast.parse("""
        
        a: int = 10
        b: int
        
        """)
        expected_tree = ast.parse("""
        a = 10
        
        """)
        code = """
        a = 10
        
        """