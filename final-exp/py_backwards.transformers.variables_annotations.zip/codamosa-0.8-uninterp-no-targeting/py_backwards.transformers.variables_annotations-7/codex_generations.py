

# Generated at 2022-06-21 18:19:06.656591
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    sample_code = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(sample_code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    correct_output = '''
    a = 10
    b
    '''
    output = ast.dump(new_tree.tree)
    assert output == correct_output

# Generated at 2022-06-21 18:19:14.387966
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a: int = 10\nb: int = 20')
    res = VariablesAnnotationsTransformer.transform(node)
    # res.tree should now contain ast.Assign(value=a), ast.Assign(value=b)
    assert len(res.tree.body) == 2
    assert isinstance(res.tree.body[0], ast.Assign)
    assert isinstance(res.tree.body[1], ast.Assign)
    assert res.tree_changed is True

# Generated at 2022-06-21 18:19:22.135758
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('''
a: int = 3
b: str = 'string'
    ''')
    result = VariablesAnnotationsTransformer.transform(test_tree)
    expected_tree = ast.parse('''
a = 3
b = 'string'
    ''')
    assert ast.dump(result.new_tree) == ast.dump(expected_tree)
    assert result.is_changed is True
    assert len(result.messages) == 0


test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:19:24.860461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a:int = 10")) == TransformationResult(ast.parse("a=10"), tree_changed=True, stats=[])

# Generated at 2022-06-21 18:19:30.989316
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """

    """
    tree = ast.parse("""a: int = 10
b: int
""")
    VariablesAnnotationsTransformer(tree).transform()
    assert ast.dump(tree) == ("""Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10), type_comment='int'
), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])
""")



# Generated at 2022-06-21 18:19:40.761046
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_source
    from .base import BaseTransformer
    from .for_loop import ForLoopTransformer
    from .while_loop import WhileLoopTransformer
    from .type_comment import TypeCommentTransformer


    source = """
    a: int = 10
    b: int
    c: int
    d: int = 0
    """

    expected = """a = 10
d = 0"""

    tree = parse_source(source)
    transformed_tree, tree_changed = BaseTransformer.transform(tree, [VariablesAnnotationsTransformer, TypeCommentTransformer])
    assert tree_changed == True
    assert ast.dump(transformed_tree) == expected

# Generated at 2022-06-21 18:19:44.703503
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a: int = 10')
    node_ = ast.parse('a = 10')

    assert list(VariablesAnnotationsTransformer.transform(node))[0].body == list(node_)

# Generated at 2022-06-21 18:19:46.141090
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    foo = VariablesAnnotationsTransformer()
    assert foo.target == (3, 5)

# Generated at 2022-06-21 18:19:57.254660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    sample = """
    x : int
    y : int = 13
    """

    res = VariablesAnnotationsTransformer.transform(ast.parse(sample))
    assert len(res.new_code) == 2
    assert res.tree_changed is True
    assert isinstance(res.new_code[0], ast.Assign)
    assert (
        ast.dump(res.new_code[0]) ==
        "Assign(targets=[Name(id='x', ctx=Store())], "
        "value=None, type_comment='int')\n")
    assert isinstance(res.new_code[1], ast.Assign)

# Generated at 2022-06-21 18:20:09.154827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10 -> a = 10
    a_annotation_10 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), value=ast.Constant(value = 10, kind = None), annotation = ast.Name(id = 'int', ctx = ast.Load()), simple = 1)
    a_assign_10 = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Constant(value = 10, kind = None), type_comment = ast.Name(id = 'int', ctx = ast.Load()))
    
    # b: int -> b = 10

# Generated at 2022-06-21 18:20:19.012458
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = "a: int=1"
    tree = ast.parse(code)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.getValue() == True
    print(astor.to_source(tree_changed.tree))


# Generated at 2022-06-21 18:20:19.966783
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:22.077625
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import parse_ast, round_trip
    var_tree = parse_ast('''
    a: int = 10
    b: int
    ''')
    new_tree = round_trip(var_tree, VariablesAnnotationsTransformer)
    new_tree_code = new_tree
    assert new_tree_code == 'a = 10\n'

# Generated at 2022-06-21 18:20:26.276965
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .annotations import AnnotationsTransformer

    code = '''
    a: int = 10
    b: int
    '''

    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert tree == ast.parse('a = 10')

# Generated at 2022-06-21 18:20:30.369695
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # creates an instance of class VariablesAnnotationsTransformer
    instance = VariablesAnnotationsTransformer()
    assert(isinstance(instance, VariablesAnnotationsTransformer))

# Unit test if the transform method removes a variable annotation

# Generated at 2022-06-21 18:20:32.579063
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer(3, 5).target == (3, 5)


# Generated at 2022-06-21 18:20:33.553202
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert inspect.isclass(VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:20:34.735601
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 18:20:40.123782
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # BEFORE
    tree = ast.parse("""
        a: int = 10
        b: int
        c: int = 15
        d: int
    """)
    # AFTER
    expected_tree = ast.parse("""
        a = 10
        c = 15
    """)

    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_tree

# Generated at 2022-06-21 18:20:41.355090
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:55.525645
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # create a python script
    script = '''a: int = 10
    b: int
    '''

    # generates AST from script
    tree = ast.parse(script)

    # apply VariablesAnnotationsTransformer
    result, tree_changed, error_message = VariablesAnnotationsTransformer.transform(tree)
    assert result is not None
    assert error_message == ''

    # if transform applied successfully, assert tree_changed == True
    assert tree_changed

    # assert code generated from AST is equal to current code
    assert astor.to_source(result) == 'a = 10\n'

    # check for empty error message
    assert error_message == ''

# Generated at 2022-06-21 18:20:56.815436
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    instance = VariablesAnnotationsTransformer()
    assert class_.transform == instance.transform

# Generated at 2022-06-21 18:20:58.267422
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None) is not None


# Generated at 2022-06-21 18:21:07.114356
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse("""
b: int
a: int = 10
""")
    result_tree_1, _, _ = VariablesAnnotationsTransformer.transform(test_tree)
    assert ast.dump(result_tree_1) == ast.dump(ast.parse("""
b = None
a = 10
"""))

    test_tree = ast.parse("""
a: int = 10
""")
    result_tree_2, _, _ = VariablesAnnotationsTransformer.transform(test_tree)
    assert ast.dump(result_tree_1) == ast.dump(result_tree_2)

# Generated at 2022-06-21 18:21:08.364279
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ... import find_and_replace


# Generated at 2022-06-21 18:21:17.565398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3,5)
    assert vat.transform(ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10), simple=1)) == TransformationResult(ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load())), True, [])

# Generated at 2022-06-21 18:21:21.545083
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import _ast
    import typed_ast.ast3 as ast
    code = """
a: int = 10
b: int
"""
    tree = ast.parse(code)
    # print(ast.dump(tree))
    VariablesAnnotationsTransformer.transform(tree)
    assert type(tree.body[0].value) is _ast.Name
    # print(ast.dump(tree))

# Generated at 2022-06-21 18:21:29.436065
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import dump
    from ..utils.helpers import generate_input_output

    for tree, expected in generate_input_output('test_VariablesAnnotationsTransformer'):
        v = VariablesAnnotationsTransformer()
        actual = dump(v.run_on_single_file(tree))
        try:
            assert actual == expected
        except AssertionError:
            # If the test fails, show the input and the expected output
            print(actual)
            print(expected)
            raise AssertionError

# Generated at 2022-06-21 18:21:30.050899
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:21:41.505672
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    a = ast.Expr(value= ast.Constant(value = 5))
    b = ast.AnnAssign(target = ast.Name(id = "a", ctx= ast.Store()), annotation = ast.Name(id = "int"))
    c = ast.Assign(targets = [ast.Name(id = "a", ctx = ast.Store())], value = ast.Constant(value = 5))
    tree = ast.Module(body = [a,b])
    # print(astor.to_source(tree))
    trans = VariablesAnnotationsTransformer()
    (tree, changed, errors) = trans.transform(tree)
    # print(astor.to_source(tree))
    assert tree == ast.Module(
        body = [a,c]
    )

# Generated at 2022-06-21 18:21:51.418448
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:22:02.435185
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from unittest import TestCase, mock
    from ..utils.tree import get_node_lineno

    class testcases(TestCase):
        def set_up(self, cls):
            cls.tree_changed = False

            cls.node = ast.AnnAssign()
            cls.node.target = ast.Name(id='a', ctx=ast.Store())
            cls.node.annotation = ast.Subscript(value=ast.Name(id='a', ctx=ast.Load()), slice=ast.Index(value=ast.Name(id='int', ctx=ast.Load())), ctx=ast.Load())
            cls.node.value = ast.Constant(value=10)

# Generated at 2022-06-21 18:22:11.508196
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
for i in range(10):
    a: int = 10
    b: int
    if(i>10):
        b = 10
    else:
        continue
'''
    initial_tree = ast.parse(code)

    expected_tree = ast.parse('''
for i in range(10):
    if(i>10):
        b = 10
    else:
        continue
''')
    transformed_tree = VariablesAnnotationsTransformer.transform(initial_tree)
    assert ast.dump(transformed_tree.tree) == ast.dump(expected_tree)
    assert transformed_tree.tree_changed == True



# Generated at 2022-06-21 18:22:15.717540
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
        a: int = 10
        b: str
    """

    expect = """
        a = 10
        b = None
    """

    result = VariablesAnnotationsTransformer.transform(None, code)

    # Compare to expected result
    assert result[0] == expect, 'Did not get expected result'
    assert result[1] == True, 'Did not get expected tree_changed'


# Generated at 2022-06-21 18:22:19.074720
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer.target == (3, 5)


# Generated at 2022-06-21 18:22:21.999004
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("Testing constructor of VariablesAnnotationsTransformer")
    VariablesAnnotationsTransformer()

# Unit tests for function transform of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:22:29.836721
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                        annotation=ast.Name(id='int', ctx=ast.Load()),
                        value=ast.Num(n=10), simple=1)
    assert VariablesAnnotationsTransformer.transform(var).result_tree == ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                                 value=ast.Num(n=10),
                                                 type_comment=ast.Name(id='int', ctx=ast.Load()))

# Generated at 2022-06-21 18:22:32.426343
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typing import List
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer), 'class VariablesAnnotationsTransformer should extend BaseTransformer class'


# Generated at 2022-06-21 18:22:42.091812
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestClass:
        # Test 1: assignment with type
        a: int = 10
        b: int

        # Test 2: assignment without type
        c = 14
        d = 32

        # Test 3: array
        e = [
            12,
            31
        ]

        # Test 4: array with type
        f: int = [
            12,
            31
        ]

        # Test 5: array with complex type
        g: str = [
            12,
            31
        ]


# Generated at 2022-06-21 18:22:46.569828
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	# Creating a VariablesAnnotationsTransformer object
	var = VariablesAnnotationsTransformer()
	# Creating a tree object for AST
	tree = ast.parse('y: int = 10\nx: int')
	print('\nAfter Transformation')
	# Applying the transform function and printing the transformed code
	print(astor.to_source(var.transform(tree)[0]))



# Generated at 2022-06-21 18:23:08.354539
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse(
            '''
            def foo():
                a: int = 10
                b: int
            '''
            )
    assert str(VariablesAnnotationsTransformer.transform(a)[0]) == '\n\ndef foo():\n    a = 10'

# Generated at 2022-06-21 18:23:09.220031
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:23:15.073417
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.AnnAssign(target=ast.Name(id='a'), annotation=ast.Name(id='int'), value=ast.Num(n=10))
    node2 = ast.AnnAssign(target=ast.Name(id='b'), annotation=ast.Name(id='int'))
    tree = ast.Module(body=[node1, node2])
    VariablesAnnotationsTransformer.transform(tree)

# To test:
# astunparse.unparse(tree)

# Generated at 2022-06-21 18:23:18.388189
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    node_target = ast.Name(id="x")
    node_annotation = ast.Name(id="int")
    node_value = ast.Num(n=1)
    tree = ast.Module(body = [ast.AnnAssign(target=node_target, annotation=node_annotation, value=node_value)])
    result = VariablesAnnotationsTransformer.transform(tree)
    # print(astor.to_source(result.tree))

    assert(isinstance(result.tree, ast.Module))
    assert(len(result.tree.body) == 1)
    assert(isinstance(result.tree.body[0], ast.Assign))
    assert(isinstance(result.tree.body[0].value, ast.Num))

# Generated at 2022-06-21 18:23:27.761827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import astor
    from typing import Any, List

    class TestVariablesAnnotationsTransformer(VariablesAnnotationsTransformer):
        def __init__(self, tree: ast.AST) -> None:
            super().__init__(tree)
            assert inspect.signature(self.transform) == inspect.signature(VariablesAnnotationsTransformer.transform)
            assert self.transform(tree) == VariablesAnnotationsTransformer.transform(tree)

    source = """
        def function():
            a: int = 10
            b: int
    """
    tree = ast.parse(source) # type: ast.Module
    TestVariablesAnnotationsTransformer(tree)

# Generated at 2022-06-21 18:23:29.795022
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(tree)

# Generated at 2022-06-21 18:23:32.313565
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_set import test_tree

    tree_changed = VariablesAnnotationsTransformer.transform(test_tree)
    assert tree_changed

# Generated at 2022-06-21 18:23:33.627143
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_ != None


# Generated at 2022-06-21 18:23:35.367896
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    r = VariablesAnnotationsTransformer()
    assert isinstance(r, VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:23:45.443888
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    source = """
        x: int = 10
        y: str
    """
    tree = ast.parse(source)

    expected_tree = """
        Assign(
            targets=[Name(
                id='x',
                ctx=Store(),
            )],
            value=Num(
                n=10,
            ),
            type_comment=Name(
                id='int',
                ctx=Load(),
            ),
        )
    """

    transformer = VariablesAnnotationsTransformer()

    result = transformer.transform(tree)

    assert len(transformer.warnings) == 0
    assert len(transformer.errors) == 0
    assert result.tree_changed == True
    assert ast.dump(tree) == expected_tree

# Generated at 2022-06-21 18:24:25.604559
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:30.046070
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform \
            (ast.parse('x: int = 10')) == \
           TransformationResult(None, True, [])

    assert VariablesAnnotationsTransformer.transform \
            (ast.parse('x: int')) == \
           TransformationResult(None, True, [])


# Generated at 2022-06-21 18:24:39.571767
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast_parser.parser import ASTParser
    from .mock_function_definitions import mock_function_definitions

    test_input = """def foo(a: int = 10, b: int) -> int:\n\tpass"""

    tree = ASTParser.parse(test_input)
    tree = VariablesAnnotationsTransformer.transform(tree)

    mock_function_definitions(tree)
    assert tree.body[1].body[1] == ast.Pass()
    assert tree.body[1].body[0] == ast.Assign(targets=[ast.Name(id='a', ctx=ast.Load())], value=ast.Num(n=10), type_comment='int')

# Generated at 2022-06-21 18:24:40.838369
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:42.277929
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-21 18:24:43.430135
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_tree


# Generated at 2022-06-21 18:24:44.225282
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:24:46.077664
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:48.402274
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.name == 'VariablesAnnotationsTransformer'
    assert class_.target == (3,5)



# Generated at 2022-06-21 18:24:53.876349
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse("""
a: int = 10
b: int
""")
    expected_output = ast.parse("""
a = 10
""")

    # When
    output = VariablesAnnotationsTransformer().visit(tree)

    # Then
    assert ast.dump(output) == ast.dump(expected_output)

# Generated at 2022-06-21 18:26:29.709758
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    
    source = ast.parse('a: int = 1')
    assert VariablesAnnotationsTransformer().transform(source) == ast.parse('a = 1')
    
    

# Generated at 2022-06-21 18:26:32.733959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """, mode='exec')
    assert (VariablesAnnotationsTransformer.transform(tree).tree != tree)

# Generated at 2022-06-21 18:26:34.932552
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from .transformers import python33_to_python34
    from .transformers import python34_to_python35


# Generated at 2022-06-21 18:26:38.447842
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test that this constructor works correctly"""
    tree = ast.parse("""
    def test():
        b: int = 10
        a: int
    """)
    VariablesAnnotationsTransformer(2).transform(tree)



# Generated at 2022-06-21 18:26:42.666651
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    code = \
        """\
a: int = 10
b: int
"""
    code_ast = ast.parse(code)
    assert isinstance(code_ast, ast.Module)
    result, _, _ = VariablesAnnotationsTransformer.transform(code_ast)
    assert isinstance(result, ast.Module)
    assert astunparse.unparse(result) == \
        """\
a = 10
"""

# Generated at 2022-06-21 18:26:47.718031
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_def = ast.ClassDef(name='Foo', body=[ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Store()), value=None)])
    result = VariablesAnnotationsTransformer.transform(class_def)
    assert len(result.tree.body) == 0
    assert result.tree_changed == True

# Generated at 2022-06-21 18:26:50.716827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_input = '''
a: int = 10
b: int
    '''

    expected_output = '''
a = 10
b
    '''
    assert VariablesAnnotationsTransformer.transform(parse(test_input)) == parse(expected_output)

# Generated at 2022-06-21 18:26:57.819121
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert list(find(new_tree.tree, ast.AnnAssign)) == []
    assert list(find(new_tree.tree, ast.Assign)) == [ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10),
        type_comment=ast.Name(id='int', ctx=ast.Load()))]

# Generated at 2022-06-21 18:27:03.268611
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a: int = 10')
    t = VariablesAnnotationsTransformer()
    result = t.transform(node)
    assert (result.tree.body[0].__class__ == ast.Assign)
    assert (repr(result.tree.body[0]) == repr(ast.parse('a = 10')))

# Generated at 2022-06-21 18:27:05.186512
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer()
    assert v.target == (3,5)

# Unit test of transform method