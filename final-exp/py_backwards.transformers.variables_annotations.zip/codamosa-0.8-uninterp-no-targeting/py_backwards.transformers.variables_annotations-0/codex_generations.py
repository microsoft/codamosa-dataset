

# Generated at 2022-06-21 18:19:08.722600
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('x: int = 10')
    expected_tree = ast.parse('x = 10')
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:19:10.325006
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform() == TransformationResult()

# Generated at 2022-06-21 18:19:21.353277
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    a: int = 10
    b: int
    c: int = 12 '''
    tree = ast.parse(code)
    n1 = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Num(n=10),
        simple=1)
    n2 = ast.AnnAssign(
        target=ast.Name(id='b', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=None,
        simple=0)

# Generated at 2022-06-21 18:19:24.963102
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))
    assert VariablesAnnotationsTransformer.transform(ast.parse('b: int'))
    # Change name of module here
# Unit testing with pytest

# Generated at 2022-06-21 18:19:32.517769
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Transform
    node = ast.parse('a: int = 10\nb: int').body
    assert len(node) == 2
    assert isinstance(node[0], ast.AnnAssign)
    assert node[0].annotation == ast.parse('int', mode='eval').body
    assert node[0].target.id == 'a'
    assert isinstance(node[0].value, ast.Num)
    assert node[0].value.n == 10
    assert isinstance(node[1], ast.AnnAssign)
    assert node[1].annotation == ast.parse('int', mode='eval').body
    assert node[1].target.id == 'b'
    assert node[1].value is None

    # Transform
    node = ast.parse('a: int = 10\nb: int').body
    VariablesAn

# Generated at 2022-06-21 18:19:38.527691
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    import typed_ast.ast3
    from ..utils.helpers import load_python_ast_tree
    tree = load_python_ast_tree('./tests/resources/python_files/test_VariablesAnnotationsTransformer.py')
    typed_ast.ast3.fix_missing_locations(tree)
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res is not None

# Generated at 2022-06-21 18:19:40.997909
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.dump import dump
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


# Generated at 2022-06-21 18:19:52.591863
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    cls = VariablesAnnotationsTransformer
    try:
        cls.transform.__annotations__
    except AttributeError:
        cls.transform.__annotations__ = {}
        cls.transform.__annotations__["return"] = TransformationResult
        cls.transform.__annotations__["tree"] = ast.AST
    cls = VariablesAnnotationsTransformer

    test_source = """
    a: int = 10
    b: int
    """
    test_ast = ast.parse(test_source)

# Generated at 2022-06-21 18:19:59.390490
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump_ast
    tree = ast.parse("""
a: int = 10
b: int
    """)

    # Remove a: int = 10
    rem_tree = ast.parse("""
b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert dump_ast(tree) == dump_ast(rem_tree)



# Generated at 2022-06-21 18:20:00.709786
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

# Generated at 2022-06-21 18:20:07.451947
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_test = ast.parse(test_code1)
    assert test_code1 == VariablesAnnotationsTransformer.transform(ast_test).get_code()

test_code1 = """a: str
b: int = 10
"""

# Generated at 2022-06-21 18:20:08.630333
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:20:11.388731
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vt = VariablesAnnotationsTransformer()
    assert vt.target == (3, 5)
    assert vt.transform is VariablesAnnotationsTransformer.transform


# Generated at 2022-06-21 18:20:12.773218
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    trans = VariablesAnnotationsTransformer()
    target=(3,5)
    assert trans.target == target

# Generated at 2022-06-21 18:20:20.586070
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    simple_test_string = '''class SimpleClass:
    a: int = 10
    b: int
    '''
    expected_test_string = '''class SimpleClass:
    a = 10
    b
    '''
    node = ast.parse(simple_test_string)
    node_transformed = VariablesAnnotationsTransformer.transform(node)
    assert ast.dump(node_transformed, annotate_fields=False) == expected_test_string

# Generated at 2022-06-21 18:20:31.786076
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..tests.utils import roundtrip
    from ..tests.tree import node_equals
    import unittest

    class ClassVariableAnnotationsTransformerTest(unittest.TestCase):
        def test(self):
            tree = roundtrip(
                """
a: int = 10
b: int
c: float = float(10)
d: float
                """)

            updated_tree = VariablesAnnotationsTransformer().transform(tree)


# Generated at 2022-06-21 18:20:38.098082
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..refactorers.tests.helpers import compile_and_compare, get_ast
    from ..utils.enums import Status

    ast1 = get_ast("a: int = 10\nb: int")
    ast2 = get_ast("a = 10")

    result = compile_and_compare(ast1, VariablesAnnotationsTransformer)

    assert result.status is Status.no_change
    assert result.ast == ast2

# Generated at 2022-06-21 18:20:48.733148
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from collections import OrderedDict

    expected_result = OrderedDict(
        [('test_file.py', {'tree_changed': True,
                           'warnings': [],
                           'errors': []})]
    )

    actual_result = OrderedDict()

    tree = ast.parse(
        """
a: int = 10
b: int
""",
         filename='test_file.py'
    )

    tree_changed, warnings, errors = VariablesAnnotationsTransformer.transform(tree)
    actual_result['test_file.py'] = {'tree_changed': tree_changed,
                                     'warnings': warnings,
                                     'errors': errors}

    assert actual_result == expected_result

# Generated at 2022-06-21 18:20:51.199087
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Tests that VariablesAnnotationsTransformer() works (constructor)
    """
    VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:20:53.117531
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = VariablesAnnotationsTransformer()
    assert var.target == (3,5)
    assert var.name == "VariablesAnnotationsTransformer"

# Generated at 2022-06-21 18:21:00.505166
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup
    class Test(VariablesAnnotationsTransformer):
        pass
    
    # Test
    assert Test().__class__.__name__ == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-21 18:21:11.775088
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create an instance of class VariablesAnnotationsTransformer
    variable_annotation_transformer = VariablesAnnotationsTransformer()

    # Define instance variable
    variable_annotation_transformer.target = (3, 5)

    # Define a test tree
    test_tree = ast.parse("""
    # test file for VariablesAnnotationsTransformer
    a: int = 10 
    """, 'exec', 'test')

    # Define the expected output tree
    output_tree = ast.parse("""
    # test file for VariablesAnnotationsTransformer
    a = 10 
    """, 'exec', 'test')

    # Get the actual output tree
    actual_tree, _, _ = variable_annotation_transformer.transform(test_tree)

    # Compare them
    assert ast.dump(actual_tree)

# Generated at 2022-06-21 18:21:13.583925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'



# Generated at 2022-06-21 18:21:22.291296
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Build AST
    # a: int = 10
    # b: int
    module = ast.Module([
        ast.AnnAssign(annotation=ast.Name(id='int', ctx=ast.Load()),
                      target=ast.Name(id='a', ctx=ast.Store()),
                      value=ast.Num(n=10)),
        ast.AnnAssign(annotation=ast.Name(id='int', ctx=ast.Load()),
                      target=ast.Name(id='b', ctx=ast.Store()),
                      value=None)
    ])

    # Run transformation
    tree_changed, new_tree = VariablesAnnotationsTransformer.run_it(module)
    assert tree_changed is True

# Generated at 2022-06-21 18:21:24.524386
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer(3, 5)


# Generated at 2022-06-21 18:21:28.373034
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import (
        AST,
        AnnAssign,
        Name,
        Assign,
        Num,
    )

    assert isinstance(VariablesAnnotationsTransformer(), VariablesAnnotationsTransformer)


# Generated at 2022-06-21 18:21:29.818212
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    trans_class = """
a: int = 10
b: int
    """

# Generated at 2022-06-21 18:21:35.780354
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer

    t = ast.parse("a: int = 10\nb: int")
    class_.transform(t)
    assert ast.dump(t) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-21 18:21:43.774694
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import assert_transformation_result

    tree = ast.parse('x: int = 10\n')
    expected = ast.parse('x = 10\n')

    assert_transformation_result(VariablesAnnotationsTransformer,
                                 tree,
                                 expected)

    tree = ast.parse('x: int\ny: int\n')
    expected = ast.parse('x\ny\n')

    assert_transformation_result(VariablesAnnotationsTransformer,
                                 tree,
                                 expected)

# Generated at 2022-06-21 18:21:48.673476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse("""\
    def f(a: int):
        b: int
        a = 10
        b = 20
        return""")
    res = VariablesAnnotationsTransformer.transform(a)
    b = ast.parse("""\
    def f(a):
        a = 10
        b = 20
        return""")
    assert res.tree == b

# Generated at 2022-06-21 18:22:09.223106
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code_1 = 'a: int = 10\nb: int'
    expected_output_code_1 = 'a = 10'

    input_tree_1 = astor.parse_file(StringIO(input_code_1))
    output_tree_1 = VariablesAnnotationsTransformer.transform(input_tree_1)[0]
    actual_output_code_1 = astor.to_source(output_tree_1)

    assert actual_output_code_1 == expected_output_code_1

    input_code_2 = 'a: int = 10\nb: int'
    expected_output_code_2 = 'a = 10'

    input_tree_2 = astor.parse_file(StringIO(input_code_2))

# Generated at 2022-06-21 18:22:10.222602
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:22:11.173334
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    raise NotImplementedError()

# Generated at 2022-06-21 18:22:14.055803
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse("""
a: int = 10
b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(node)
    assert ast.parse("""
a = 10
    """) == tree

# Generated at 2022-06-21 18:22:20.039420
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Note: This test might not work if the format of the output changes
    from .testutils import assert_transformation_result

    source = """
    from typing import List
    a: int
    b: List
    """
    expected = """
    from typing import List
    """

    assert_transformation_result(VariablesAnnotationsTransformer, source, expected)


# Generated at 2022-06-21 18:22:30.188794
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import compare_trees
    from ..utils.helpers import stringify
    from ..utils.helpers import parse
    from ..utils.helpers import parse_and_transform

    code = '''
    a: int
    '''

    expected = '''
    pass
    '''

    compare_trees(
        parse_and_transform(code, VariablesAnnotationsTransformer),
        parse(stringify(expected))
    )

    code = '''
    a: int = 1
    '''

    expected = '''
    a = 1
    '''

    compare_trees(
        parse_and_transform(code, VariablesAnnotationsTransformer),
        parse(stringify(expected))
    )


# Generated at 2022-06-21 18:22:30.774672
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert True

# Generated at 2022-06-21 18:22:43.588391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from typed_ast.ast3 import parse
    from ..trees import AST
    V = VariablesAnnotationsTransformer()
    class_definition_ast = parse('class foo:\n'
                                 '  x: int\n'
                                 '  a: int = 10\n'
                                 '  b: int\n'
                                 '  def __init__(self):\n'
                                 '    self.b = 10\n')
    class_definition_ast = AST.from_node(class_definition_ast)
    V.transform(class_definition_ast)
    result = astor.to_source(class_definition_ast.root)

# Generated at 2022-06-21 18:22:48.754497
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # sample code to test
    code = '''
a: int = 10
b: int = 20
c = 30
'''

    # expected output
    expected_code = '''
a = 10
b = 20
c = 30
'''

    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    generated_code = astor.to_source(new_tree)

    print(generated_code)

    assert generated_code == expected_code

# Generated at 2022-06-21 18:22:59.042038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_node = ast.parse(
        """
        def func(a: int = 10):
            b: int
        """
    )
    VariablesAnnotationsTransformer.transform(tree_node)

# Generated at 2022-06-21 18:23:23.643319
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)

    code = """
a: int = 10
b = 20
c = 30
        """

    tree = ast.parse(code)
    tree = transformer.visit(tree)
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign):
            assert False
    else:
        assert True

# Generated at 2022-06-21 18:23:34.310333
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('Unit test for constructor of class VariablesAnnotationsTransformer')
    tree = ast.parse('a: int = 10')
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == '<_ast.Module object at 0x7f77c83e0cd0>'
    assert tree_changed is True
    tree1 = ast.parse('a: int = 10; b: str = "hello"')
    tree_changed = VariablesAnnotationsTransformer.transform(tree1)
    assert str(tree1) == '<_ast.Module object at 0x7f77c83e0cd0>'
    assert tree_changed is True
    tree2 = ast.parse('a: int; b: str = "hello"')

# Generated at 2022-06-21 18:23:36.062329
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:23:38.423045
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class A:
        __args__ = []

    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"
    assert VariablesAnnotationsTransformer.transform.__name__ == "transform"
    assert VariablesAnnotationsTransformer.target == (3, 5)
    x = VariablesAnnotationsTransformer()
    assert x.__dict__ == A.__dict__
    assert x.__class__.__base__.__name__ == 'BaseTransformer'

# Generated at 2022-06-21 18:23:47.951243
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .annotation_transformer import AnnotationTransformer
    from .typevar_transformer import TypeVarTransformer
    from .generic_transformer import GenericTransformer
    from ..utils.helpers import serialize
    from ..utils.tree import tree


# Generated at 2022-06-21 18:23:56.957977
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.code_gen import to_source
    from .code_templates import (
        one_variable_annotation_assignment,
        one_variable_two_annotation_assignment,
        one_variable_one_annotation_two_assignment,
    )

    for test_input in [
        one_variable_annotation_assignment,
        one_variable_two_annotation_assignment,
        one_variable_one_annotation_two_assignment,
    ]:
        assert to_source(
            VariablesAnnotationsTransformer.transform(test_input).tree
        ) == '''\
a = 10'''

# Generated at 2022-06-21 18:23:58.451893
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer(None)


# Generated at 2022-06-21 18:24:00.261636
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.parsing import parse_ast
    from ..utils.tree import print_tree

# Generated at 2022-06-21 18:24:03.740760
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test object creation
    x = VariablesAnnotationsTransformer()
    # Test if object is of the right type
    if (isinstance(x, VariablesAnnotationsTransformer)):
        assert True
    else:
        assert False


# Generated at 2022-06-21 18:24:14.995385
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1
    tree = ast.parse("""
        a: int = 10
        b: int

        def test():
            a = 20
            b = 4
    """)
    target = ast.parse("""
        a = 10
        def test():
            a = 20
            b = 4
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert(len(result.warnings) == 0)
    assert isinstance(result.tree, ast.AST)
    assert ast.dump(target) == ast.dump(result.tree)
    assert result.tree_changed == True

    # Test case 2
    tree = ast.parse("""
        a: int = 10
        b: str = 7

        def test():
            a = 20
            b = 'string'
    """)

# Generated at 2022-06-21 18:25:00.197611
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import test_transformer_class
    test_transformer_class(VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:25:00.721945
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    return 0



# Generated at 2022-06-21 18:25:10.379164
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:25:14.489786
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
        a: int = 10
        b: int
    """)

    assert VariablesAnnotationsTransformer.apply(tree) == TransformationResult(
        ast.parse("""
        a = 10
        b: int
    """), True, [],)

# Generated at 2022-06-21 18:25:24.430171
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    target = ast.parse('a: str = "hello"\n'
                       'b: int = 10\n'
                       'c: str = "world"\n')

    result = VariablesAnnotationsTransformer.transform(target)
    assert result.tree == ast.parse('a = "hello"\n'
                                    'b = 10\n'
                                    'c = "world"\n')
    assert result.tree_changed

    target = ast.parse('a: str = "hello"'
                       'b: int = 10'
                       'c: str = "world"')

    result = VariablesAnnotationsTransformer.transform(target)
    assert result.tree == ast.parse('a = "hello"'
                                    'b = 10'
                                    'c = "world"')
    assert result.tree_changed

   

# Generated at 2022-06-21 18:25:25.027533
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:25:32.374770
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int'), value=ast.Num(n=10))
    mod = VariablesAnnotationsTransformer.transform(node)
    assert mod == transformationResult(
        body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int'))])

# Generated at 2022-06-21 18:25:36.454884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)
    tree = ast.parse(
       """
        a: int = 10
        b: int
        def f(a: str): pass
       """)
    transformer = VariablesAnnotationsTransformer.transform(tree)
    assert transformer.tree.body[0].attr == 'a'
    assert transformer.tree.body[1].value == 'a'

# Generated at 2022-06-21 18:25:38.479041
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:25:41.715947
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    return VariablesAnnotationsTransformer().transform(ast.AnnAssign(target=ast.Name("a", ast.Store()), annotation=ast.Name("int"), value=ast.Num(10)))

# Generated at 2022-06-21 18:27:37.611359
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    string = """
    a: int = 10
    b: int
    """
    tree = ast.parse(string)
    VariablesAnnotationsTransformer.transform(tree)
    with open('test_variables_annotations_transformer.py', 'w') as outfile:
        outfile.write(astor.to_source(tree))


# Generated at 2022-06-21 18:27:41.003002
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from typed_ast import ast3 as ast
    from python_to_python.transformers.python_versions import AllVersions


# Generated at 2022-06-21 18:27:47.073991
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..transformer import TransformerPipeline
    from ..utils.helpers import compare_source
    from ..utils import load_fixture

    src = load_fixture('variable_annotations_transformer_in.py')

    t = TransformerPipeline(VariablesAnnotationsTransformer())
    result = t.apply_to_file(src)

    target = load_fixture('variable_annotations_transformer_out.py')

    assert compare_source(result.source, target)
    assert result.tree_changed

# Generated at 2022-06-21 18:27:52.812282
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # VariablesAnnotationsTransformer(3.5)
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.transform.__name__ == 'transform'
    print('test_VariablesAnnotationsTransformer ok')


# Generated at 2022-06-21 18:27:54.010543
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_Anno_transformer = VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:27:56.741904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(open(__file__[:-2] + "py", "r").read())
    transformed = VariablesAnnotationsTransformer.transform(tree)
    exec(compile(transformed.tree, "test", "exec"))

# Generated at 2022-06-21 18:28:00.498360
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.code_gen import to_source

    source = '''
a: int = 10
b: int
    '''.strip()
    tree = generate_code(source)

    result = VariablesAnnotationsTransformer.transform(tree)

    assert to_source(result.tree.body) == "a = 10"
    assert result.tree_changed
    assert result.warnings == []

# Generated at 2022-06-21 18:28:04.820846
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..parser import parse

    result = VariablesAnnotationsTransformer.transform(parse(
        "a: int = 10\n"
        "b: int\n"
    ))

    result_str = "".join(str(n) for n in result._tree.body)

    assert result_str == "a = 10"

# Generated at 2022-06-21 18:28:07.036799
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test constructor of class VariablesAnnotationsTransformer"""
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'


if __name__ == '__main__':
    # Unit test of VariablesAnnotationsTransformer
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:28:11.311750
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    # Test for constructors with no parameters
    test_class = VariablesAnnotationsTransformer();
    assert test_class.target == (3, 5)


# Unit testing for method transform of class VariablesAnnotationsTransformer
# implemets the test case:
# a: int = 10