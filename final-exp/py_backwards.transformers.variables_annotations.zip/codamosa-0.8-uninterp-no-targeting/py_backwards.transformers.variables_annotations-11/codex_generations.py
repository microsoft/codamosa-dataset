

# Generated at 2022-06-21 18:19:00.437150
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  class_ = VariablesAnnotationsTransformer()
  assert isinstance(class_, BaseTransformer)
  assert class_.target == (3, 5)



# Generated at 2022-06-21 18:19:02.308875
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast3.AnnAssign(target=0, annotation=1, value=2)
    cx = VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:19:10.488907
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    print(transformer)
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Num(n=1), value=ast.Num(n=10))
    node2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Num(n=1))
    node3 = ast.AnnAssign(target=ast.Name(id='c', ctx=ast.Store()), annotation=ast.Num(n=1))
    body = ast.Expr(value=node1)
    module = ast.Module(body=[body])
    new_tree = module
    new_tree = transformer.transform(new_tree)

# Generated at 2022-06-21 18:19:17.349310
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

    filename = 'test'
    test_code = """
    a = 10
    a: int = 10

    """

    code = test_code
    code_ast = astor.code_to_ast.parse_tree(code, filename)

    expected_code = """
    a = 10
    a = 10

    """

    expected_code_ast = astor.code_to_ast.parse_tree(expected_code, filename)

    # Call the function to be tested
    result = VariablesAnnotationsTransformer.transform(code_ast)

    # Check if the result from the function is equal to the expected result
    assert astor.to_source(result.new_tree).strip() == astor.to_source(expected_code_ast).strip()

# Generated at 2022-06-21 18:19:20.645931
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = "a: int = 10\nb: int"
    tree = ast.parse(t)
    VariablesAnnotationsTransformer.transform(tree).tree_changed == True
    print(ast.dump(tree))

# Generated at 2022-06-21 18:19:26.228287
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    codes = [
        """
        a: int
        b: int
        """
    ]

    for code in codes:
        tree = ast.parse(code, mode="exec")
        expected = []

        for _ in range(2):
            tree = VariablesAnnotationsTransformer.transform(tree).tree

            actual = ast.dump(tree, include_attributes=True)

            assert actual == expected



# Generated at 2022-06-21 18:19:33.157905
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_tree

    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)

    assert_tree(t.transform(ast.parse('''
foo = "bar"
''')), '''
foo = "bar"
''')

    assert_tree(t.transform(ast.parse('''
foo: "bar" = "baz"
''')), '''
foo = "baz"
''')

    assert_tree(t.transform(ast.parse('''
foo: "bar"
''')), '''
''')

    assert_tree(t.transform(ast.parse('''
foo: "bar" = 10 + 10
''')), '''
foo = 10 + 10
''')


# Generated at 2022-06-21 18:19:37.403164
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree1 = ast.parse('a: int = 10')
    tree2 = ast.parse('a: int')
    assert isinstance(VariablesAnnotationsTransformer.transform(tree1), TransformationResult)
    assert isinstance(VariablesAnnotationsTransformer.transform(tree2), TransformationResult)

# Generated at 2022-06-21 18:19:41.561940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_file = open('tests/forUnitTests/Union.py', 'r')
    code_content = test_file.read()
    tree = ast.parse(code_content)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    print(new_tree)

    test_file.close()

# Generated at 2022-06-21 18:19:49.294399
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    from .base import BaseTransformer, TransformationResult
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.helpers import clean_ast

    source = """
            a : int = 10
            b : int
            """
    expected = """
    a = 10
    b
    """

    a = ast.parse(source)
    b = ast.parse(expected)

    transformer = VariablesAnnotationsTransformer()

    res = transformer.transform(a)
    assert clean_ast(res.tree) == b

# Generated at 2022-06-21 18:20:05.584056
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_base import generate_test_code

    # test for no annotation
    code = 'a = 10'
    tree_in = generate_test_code(code, ast_flag=True)
    tree_out = tree_in
    instance = VariablesAnnotationsTransformer()
    result = instance.transform(tree_in)
    assert result.tree == tree_out
    assert result.tree_changed == False

    # test for compatible annotation
    code = '''
    a: int = 10
    c: List[int] = [1,2,3]
    d: bool = True
    '''
    tree_in = generate_test_code(code, ast_flag=True)

# Generated at 2022-06-21 18:20:11.884577
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    class TestVisitor(ast.NodeVisitor):

        def __init__(self):
            self.called = False

        def visit_AnnAssign(self, node):
            self.called = True

    tree = ast.parse("""
a: int = 10
b: int
        """)
    VariablesAnnotationsTransformer.transform(tree)

    visitor = TestVisitor()
    visitor.visit(tree)
    assert visitor.called == False

# Generated at 2022-06-21 18:20:13.249431
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'


# Generated at 2022-06-21 18:20:14.364297
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:18.479449
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    code = "a: int = 10"
    tree = ast.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(result.tree) == "a = 10"

# Generated at 2022-06-21 18:20:26.230649
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from .identity_transformer import IdentityTransformer
    def test(code, expected_after):
        code_ast = ast.parse(code)
        code_ast = IdentityTransformer.transform(code_ast).tree
        code_ast = VariablesAnnotationsTransformer.transform(code_ast).tree
        assert ast.unparse(code_ast) == expected_after
    test("""
assert(a: int = 10)
assert(b: int)
""", """
assert(a = 10)
assert(b)
""")

# Generated at 2022-06-21 18:20:27.837573
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int
    t = VariablesAnnotationsTransformer(a)
    assert t.transform(a) == 'int'
    assert t.transform(b) == 'int'

# Generated at 2022-06-21 18:20:32.276509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected_result = ast.parse("a = 10")
    result = VariablesAnnotationsTransformer.transform(
        ast.parse("a: int = 10"))
    assert ast.dump(result[0]) == ast.dump(expected_result)



# Generated at 2022-06-21 18:20:35.866231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_string = "a: int = 10"
    node_tree = ast.parse(test_string)
    test_tree = VariablesAnnotationsTransformer.transform(node_tree)
    assert test_tree[2] == []

# Generated at 2022-06-21 18:20:39.612817
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Test(VariablesAnnotationsTransformer):
        def __init__(self, name):
            self.name = name

    test = Test('test')
    assert test.name == 'test'
    assert test.target == (3, 5)

# Generated at 2022-06-21 18:20:51.402864
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import generate_code_string
    from ..utils.tree import tree_from_code_string

    test_tree = tree_from_code_string('''
        a: int = 10
        b: int
    ''')

    transformer = VariablesAnnotationsTransformer(test_tree)

    after_transformation = generate_code_string(transformer.transformed)
    assert after_transformation.strip() == 'a = 10'

# Generated at 2022-06-21 18:20:55.749535
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    tree = astor.parse_file('./tests/samples/test_py3_VariablesAnnotations.py')
    tree_changed, errors = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert len(errors) == 0
# End of unit test

# Generated at 2022-06-21 18:20:59.949654
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_original = ast.parse("a: int = 10\na: int")
    tree_expected = ast.parse("a = 10")
    tree_transformed = VariablesAnnotationsTransformer.transform(tree_original).tree
    assert ast.dump(tree_transformed) == ast.dump(tree_expected)

# Generated at 2022-06-21 18:21:11.208559
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                          annotation=ast.Name(id='int', ctx=ast.Load()),
                          value=ast.Num(n=10))
    node2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                          annotation=ast.Name(id='int', ctx=ast.Load()),
                          value=None)

# Generated at 2022-06-21 18:21:18.098876
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int

for i in range(10):
    def f():
        pass
    """)
    expected_tree = ast.parse("""
for i in range(10):
    def f():
        pass
    a = 10
b: int
""")

    t = VariablesAnnotationsTransformer()
    actual_tree = t.run(tree)
    assert ast.dump(expected_tree) == ast.dump(actual_tree)

# Generated at 2022-06-21 18:21:23.566692
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for VariablesAnnotationsTransformer."""
    from typed_ast import ast3
    from ..utils.testing import assert_tree
    from ..utils.tree import get_ast

    code = """
    a: int = 10
    b: int
    """

    expected_after = """
    a = 10
    """

    ast_before = get_ast(code)
    ast_after = get_ast(expected_after)

    tree_changed, tree_after = VariablesAnnotationsTransformer.apply_to_ast(ast_before)
    assert_tree(ast_after, tree_after)
    assert tree_changed

# Generated at 2022-06-21 18:21:34.891302
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create an instance of the transformer
    transformer = VariablesAnnotationsTransformer()

    test_var_1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Load()),
                               value=ast.Num(n=10),
                               annotation=ast.Name(id='int', ctx=ast.Load()),
                               simple=1)
    test_var_2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Load()),
                               value=None,
                               annotation=ast.Name(id='int', ctx=ast.Load()),
                               simple=1)

# Generated at 2022-06-21 18:21:37.018330
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Construct instance of VariablesAnnotationsTransformer
    obj = VariablesAnnotationsTransformer()
    assert not obj.target
    assert obj.transform

# Generated at 2022-06-21 18:21:40.594070
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import collect_variables

    tree = ast.parse(collect_variables)

    assert ast.dump(VariablesAnnotationsTransformer.transform(tree).tree) == collect_variables

# Generated at 2022-06-21 18:21:45.269807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .ast_generator import generate_ast

    t = generate_ast('a: int = 10')
    assert(VariablesAnnotationsTransformer.transform(t)[1])

    t = generate_ast('a: int')
    assert(VariablesAnnotationsTransformer.transform(t)[1])

# Generated at 2022-06-21 18:22:04.259461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    # Test typing annotations inside variable declarations
    tree = ast.Module([ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10))])
    expected_tree = ast.Module([ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))])
    assert BaseTransformer.deep_equal(tree, VariablesAnnotationsTransformer.transform(tree).transformed_tree)

# Generated at 2022-06-21 18:22:09.504776
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """ Unit test for constructor of class VariablesAnnotationsTransformer """
    tree = ast.parse("a: int = 10")
    old_tree = tree
    result = VariablesAnnotationsTransformer.transform(tree)
    assert(result.new_tree == old_tree)
    assert(result.tree_changed)


# Generated at 2022-06-21 18:22:16.748721
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestTransformer(Transformer): 
        def visit_AnnAssign(self, node):
            if node.target.id == 'a':
                assert node.value.n == 10
                assert node.annotation == 'int'
            if node.target.id == 'b':
                assert node.value is None
                assert node.annotation == 'int'
        def visit_Assign(self, node):
            if node.targets[0].id == 'a':
                assert node.value.n == 10
                assert node.type_comment == 'int'
    code = '''a: int = 10
b: int'''
    tree = ast.parse(code)
    t = TestTransformer()
    t.visit(tree)

# Generated at 2022-06-21 18:22:25.244564
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    text = 'a: int = 10'
    tree = ast.parse(text)
    compiled = VariablesAnnotationsTransformer.transform(tree)
    assert text not in str(compiled)
    assert 'a = 10' in str(compiled)

    text = 'a: int'
    tree = ast.parse(text)
    compiled = VariablesAnnotationsTransformer.transform(tree)
    assert text not in str(compiled)
    assert 'a' in str(compiled)
    assert 'int' not in str(compiled)

# Generated at 2022-06-21 18:22:29.216594
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    transformer = VariablesAnnotationsTransformer()
    transformed_tree = transformer.transform(tree)
    assert transformed_tree.tree == ast.parse('a = 10')
    assert transformed_tree.tree_changed
    assert transformed_tree.warnings == []

# Generated at 2022-06-21 18:22:38.920577
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    input = ast.parse("""
        def fn():
            a: int = 10
            b: int
    """, mode="exec")

    # Act
    variable_annotation_transformer = VariablesAnnotationsTransformer()
    result = variable_annotation_transformer.transform(input)

    # Assert
    assert result.changed
    output = ast.parse("""
        def fn():
            a = 10
    """, mode="exec")
    assert ast.dump(result.new_tree) == ast.dump(output)

# Generated at 2022-06-21 18:22:45.616904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from .utils.fixtures import typed_ast_fixture

    code = dedent("""
            a: int = 10
            b: int
        """)

    tree = ast.parse(code)
    tree_changed, tree_after_transformation = VariablesAnnotationsTransformer.transform(
        tree)

    assert tree_changed
    assert typed_ast_fixture(tree_after_transformation) == ast.parse(dedent("""
            a = 10
            b = None
        """))

# Generated at 2022-06-21 18:22:46.760285
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:22:57.481467
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_test_program

    def parse_test_file():
        program = get_test_program('test_VariablesAnnotationsTransformer.py')
        tree = ast.parse(program)
        return tree

    # test comparison between 2 trees
    def test_equality(old_tree, new_tree):
        assert ast.dump(old_tree) == ast.dump(new_tree)

    # create an object of class VariablesAnnotationsTransformer
    obj = VariablesAnnotationsTransformer()
    # create 2 trees, the old one and the new one
    old_tree = parse_test_file()
    new_tree = parse_test_file()
    # call the transform method
    obj.transform(new_tree)
    # compare the 2 trees

# Generated at 2022-06-21 18:23:08.626595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import load_module_from_str

    module = ast.Module(body=[
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10), simple=1),
        ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      simple=1),
        ast.Print(values=[ast.Name(id='a', ctx=ast.Load())], nl=True)
    ])

# Generated at 2022-06-21 18:23:29.132553
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    classVariablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    print(classVariablesAnnotationsTransformer)


# Generated at 2022-06-21 18:23:31.998321
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == ast.parse("a = 10")

# Generated at 2022-06-21 18:23:33.072803
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:23:43.818064
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create an instance of VariablesAnnotationsTransformer
    VARIABLES_ANNOTATIONS_TRANSFORMER = VariablesAnnotationsTransformer()

    # Tests for transform function
    # Testing for valid input
    AST = ast.parse("a: int = 10; b: int;")
    AST_CHECK = ast.parse("a = 10;")

    NEW_AST = VARIABLES_ANNOTATIONS_TRANSFORMER.transform(AST)
    assert str(NEW_AST) == str(AST_CHECK)

    # Testing for invalid input
    AST = ast.parse("a = 10; b = 0")

    NEW_AST = VARIABLES_ANNOTATIONS_TRANSFORMER.transform(AST)
    assert str(NEW_AST) == str(AST)

# Generated at 2022-06-21 18:23:49.394439
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    from ..utils import dump_ast
    from .test_CodeToAst import compiles_to

    with open('tests/samples/VariableAnnotation.py') as file:
        script = file.read()

    with open('tests/samples/VariableAnnotation_after.py') as file:
        expected_result = file.read()

    tree = parse(script)
    dump_ast.dump_tree(tree)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compiles_to(expected_result, tree)

# Generated at 2022-06-21 18:23:51.490446
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Unit test that tests VariablesAnnotationsTransformer
    """
    # VariablesAnnotationsTransformer should exist
    assert VariablesAnnotationsTransformer


# Generated at 2022-06-21 18:23:58.105057
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast

    tree = ast.parse("""
a = 10
b = 20
z = 30
    """)

    node_to_test = tree.body[1]
    result = VariablesAnnotationsTransformer.transform(node_to_test)
    assert len(result.tree.body) == 1
    assert result.tree_changed == True
    assert result.messages == []


# Generated at 2022-06-21 18:23:59.609854
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.parse('a:\n    int = 2'))



# Generated at 2022-06-21 18:24:01.946021
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
   tree = ast.parse("a: int = 10")
   result = VariablesAnnotationsTransformer.transform(tree)
   assert ast.dump(result.tree) == ast.dump(ast.parse("a = 10"))

# Generated at 2022-06-21 18:24:08.245383
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Set up fixture
    whitelist = [3,4,5]
    start_node = ast.parse("a:int = 10")
    expected = ast.parse("a = 10")
    # Exercise System Under Test
    actual = VariablesAnnotationsTransformer(start_node, whitelist).transform()
    # Assert
    assert astunparse.unparse(expected) == astunparse.unparse(actual)

# Generated at 2022-06-21 18:24:52.120595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    # a: int = 10
    # b: int
    tree = ast.parse('a: int = 10\nb: int')
    # Act
    actual = VariablesAnnotationsTransformer.transform(tree).tree
    # Assert
    expected = ast.parse('a = 10')
    assert ast.dump(actual) == ast.dump(expected), \
        'Expected annotation assignment to be removed'

# Generated at 2022-06-21 18:24:53.963973
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:25:03.466660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast._ast3 import AnnAssign
    import astunparse
    import sys
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 8:
        foo = astunparse.unparse(VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10"))).strip()
        foo = ast.parse(foo)
        assert(isinstance(foo.body[0], AnnAssign))
        assert(foo.body[0].value is None)
        assert(foo.body[0].target.id == 'a')
        assert(foo.body[0].annotation.id == 'int')
        assert(not foo.body[0].simple)

# Generated at 2022-06-21 18:25:06.646213
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .attrs_transformer import AttrsTransformer
    from .classes_transformer import ClassesTransformer
    from ..utils.helpers import compare_asts
    from ..utils.ast_builder import build_ast

    transformer = VariablesAnnotationsTransformer(AttrsTransformer(ClassesTransformer()))

# Generated at 2022-06-21 18:25:10.521709
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_code = ast.parse(u"""
        a: int = 10
        b: int
    """)
    c = VariablesAnnotationsTransformer()
    c.transform(ast_code)

# Generated at 2022-06-21 18:25:20.841199
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTestTransformer
    from ..utils import (
        assert_transformation_result,
        load_example_local,
        get_test_data_path,
        remove_extra_locations,
    )
    from ..utils.visitor import compare_ast

    example_path = get_test_data_path('VariablesAnnotationsTransformer_in.py')

    example_out_path = get_test_data_path('VariablesAnnotationsTransformer_out.py')

    example_local_path = load_example_local(
        example_path,
        'typed_astunparse',
        'VariablesAnnotationsTransformer_in.py',
    )

    before_tree = ast.parse(example_local_path)

    with open(example_out_path) as f:
        after

# Generated at 2022-06-21 18:25:26.545073
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    input_tree = ast.parse("""
        class Class1:
            a: int = 10
            b: int
    """)
    expected_tree = ast.parse("""
        class Class1:
            a = 10
    """)
    VariablesAnnotationsTransformer.transform(input_tree)
    assert ast.dump(input_tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:25:29.182392
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)
    assert transformer.tree_changed == False


# Generated at 2022-06-21 18:25:32.170748
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Unit test for constructor of class VariablesAnnotationsTransformer
    """
    a = VariablesAnnotationsTransformer()
    return a


# Generated at 2022-06-21 18:25:35.732219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Constant(value='10'),
                      simple=1)) is not None

# Generated at 2022-06-21 18:27:24.330219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    VariablesAnnotationsTransformer.transform(tree)
    assert(len(find(tree, ast.AnnAssign)) == 0)
    assert(len(find(tree, ast.Assign)) == 1)
    assert(find(tree, ast.Assign)[0].targets[0].id == "a")
    assert(isinstance(find(tree, ast.Assign)[0], ast.Assign))

# Generated at 2022-06-21 18:27:25.320317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(0)

# Generated at 2022-06-21 18:27:27.594782
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")).code == 'a = 10'


# Generated at 2022-06-21 18:27:31.213159
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast.ast3 import AnnAssign, Assign, Name, Num, parse

    test_AST = parse("a: int = 10\nb: int")

    # Expected AST
    expected_AST = parse("a = 10\nb: int")

    # Actual AST
    actual_AST = VariablesAnnotationsTransformer.transform(test_AST)

    assert actual_AST == expected_AST

# Generated at 2022-06-21 18:27:41.819780
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.code_converter import code_converter
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''
    tree = code_converter(code)
    # tree = ast.parse(code)

    t = VariablesAnnotationsTransformer()
    actual_tree = t.transform(tree)

    expected_tree = ast.parse(expected_code)
    assert ast.dump(expected_tree) == ast.dump(actual_tree)


# Generated at 2022-06-21 18:27:46.906068
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code_str = '''
    def sum_test(x: int, y: int) -> int:
        a: int = 10
        b: str = "text"
        c = 15
        d: int
        d = 10
        return x + y
    '''
    tree = ast.parse(code_str)
    result_tree = VariablesAnnotationsTransformer().transform(tree)
    assert result_tree.tree_changed == True

# Generated at 2022-06-21 18:27:51.908803
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    transformer = VariablesAnnotationsTransformer()
    tree = ast.parse('a: int\nc: int = 10')
    transformer.transform(tree)
    res = ast.parse('c = 10')
    assert astunparse.unparse(res) == astunparse.unparse(tree)

# Generated at 2022-06-21 18:27:56.349766
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = [
            "a: int = 10\n",
            "b: int\n",
            "\n"
    ]
    expected_code = [
            "a = 10\n",
            "\n"
    ]
    tree = parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.new_code == expected_code
    assert result.tree_changed == True

# Generated at 2022-06-21 18:28:00.875432
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .utils import should_transform_to

    text_original = """
        a: int = 10
        b: int
    """
    text_expected = """
        a = 10
    """
    tree_original = ast.parse(text_original)  # type: ignore
    tree_expected = ast.parse(text_expected)  # type: ignore
    assert(should_transform_to(VariablesAnnotationsTransformer, tree_original, tree_expected))

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:28:08.247090
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    # AST generated from:
    #   a: int = 10
    #   b: int
    #
    tree = ast.Module(body=[
        ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=ast.Constant(value=10),
            simple=1
        ),
        ast.AnnAssign(
            target=ast.Name(id='b', ctx=ast.Store()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=None,
            simple=0
        )
    ])
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree