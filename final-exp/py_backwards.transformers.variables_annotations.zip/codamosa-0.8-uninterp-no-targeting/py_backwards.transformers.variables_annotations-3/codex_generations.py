

# Generated at 2022-06-21 18:19:10.233384
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast import parse
    from ..utils.helpers import get_ast_diff
    from pprint import pprint

    code_before = '''def test_code(a: int = 10, b: int):
        pass\n'''
    result = VariablesAnnotationsTransformer.transform(parse(code_before))
    code_after = compile(result.tree, '', 'exec')
    exec(code_after)
    code_after = code_after.co_consts[1]

    code_expected = '''def test_code(a = 10, b: int):
        pass\n'''

    assert code_expected == code_after
    pprint(get_ast_diff(code_before, code_after))


__all__ = ['VariablesAnnotationsTransformer']

# Generated at 2022-06-21 18:19:12.270427
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print(VariablesAnnotationsTransformer)
    assert VariablesAnnotationsTransformer.target == (3,5)

# Generated at 2022-06-21 18:19:19.711118
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    example = """
    a: int = 0
    b: int = 1

    def foo() -> int:
        return a + b
    """
    tree = parse(example)
    VariablesAnnotationsTransformer.transform(tree)

    expected = """
    a = 0
    b = 1

    def foo() -> int:
        return a + b
    """
    assert ast.dump(parse(expected)) == ast.dump(tree)

# Generated at 2022-06-21 18:19:28.492060
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor import to_source
    from ..types import CompilationResult

    module_ast = ast.parse('''
    def foo(a: int = 10,
            b: int = 20,):
        c: int
        d: int = 30
        e: int 
        e = 50

    ''')

    result = CompilationResult(module_ast, target_version=(3, 5))
    result = VariablesAnnotationsTransformer.transform(result)

    assert to_source(result.tree) == '''
    def foo(a = 10,
            b = 20,):
        c
        d = 30
        e
        e = 50

    '''

# Generated at 2022-06-21 18:19:40.407530
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Checks if the correct transformations are being done
    # Inserts the assignment node at the correct place
    # Checks if the tree has changed
    # Input code:
    # a: int = 10
    # b: int
    # Output code:
    # a = 10
    input_code = ast.parse("""\
a: int = 10
b: int
""")
    expected_code = ast.parse("""\
a = 10
""")
    test_1 = VariablesAnnotationsTransformer.transform(input_code)

    assert test_1.tree == expected_code
    assert test_1.tree_changed
    assert test_1.warnings == []

    # Test 2:
    # Checks if a warning is raised
    # Input code:
    # a: int = 10
    # b:

# Generated at 2022-06-21 18:19:46.092587
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    program = ast.parse('''
a: int = 10
b: int
    ''')

    transformer = VariablesAnnotationsTransformer
    assert isinstance(transformer, type)

    new_program = transformer.transform(program)
    assert new_program == ast.parse('''
a = 10
    ''')

# Generated at 2022-06-21 18:19:46.749567
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:52.254285
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    testVarAnnAssign = """
    a: int = 10
    b: int
    """

    testVarAnnAssignResult = """a = 10"""

    transAssign = VariablesAnnotationsTransformer.transform(ast.parse(testVarAnnAssign))
    assert ast.dump(transAssign.tree, include_attributes=True) == testVarAnnAssignResult


# Generated at 2022-06-21 18:19:56.606345
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse('a: int = 10')
    cls = VariablesAnnotationsTransformer.transform(module)
    assert(str(cls) == "TransformationResult(tree=<_ast.Module object at 0x7f3916e6f828>, tree_changed=True, logs=[])")

# Generated at 2022-06-21 18:20:01.903518
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    exp_tree = ast.parse("""
a = 10
b: int
""")
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert (ast.dump(exp_tree) == ast.dump(new_tree.tree))

# Generated at 2022-06-21 18:20:15.394038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing simple case
    ann_1 = ast.Name("int", ast.Load())
    ann_2 = ast.AnnAssign(target=ast.Name("a", ast.Store()), annotation = ann_1, value =  ast.Num(10), simple=0)
    ann_3 = ast.AnnAssign(target=ast.Name("b", ast.Store()), annotation = ann_1)
    module_1 = ast.Module([ann_2, ann_3])    
    # Testing edge case
    ann_4 = ast.Name("int", ast.Load())
    ann_5 = ast.AnnAssign(target=ast.Name("a", ast.Store()), annotation = ann_4, value =  ast.Num(10), simple=0)

# Generated at 2022-06-21 18:20:17.391491
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..transforms import Transform
    from ..utils.helpers import ast_to_str, parse


# Generated at 2022-06-21 18:20:26.785382
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    import random

    class TestTransformer(VariablesAnnotationsTransformer):

        def __init__(self, enable: bool) -> None:
            self._enable = enable

        def should_transform(self, node, parent) -> bool:
            return self._enable

        def transform(node: ast.AST, parent: ast.AST) -> ast.AST:
            return node

    # test if should_transform is working correctly
    for _ in range(10000):
        class Test(ast.AST):
            pass

        test = Test()
        tt = TestTransformer(random.choice([True, False]))
        assert tt.should_transform(test, None) == tt._enable

# Generated at 2022-06-21 18:20:28.659616
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # testing the constructor of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-21 18:20:29.269392
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:20:30.965095
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:41.750081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    node = ast.parse(
        """
        a: int = 10
        b: int
        """)
    node, not_changed = transformer.transform(node)
    assert len(node.body) == 2
    assert not not_changed
    node = ast.parse(
        """
        foo = 1
        bar: int = 2
        """)
    node, not_changed = transformer.transform(node)
    assert len(node.body) == 2
    assert not not_changed
    node = ast.parse(
        """
        foo = 1
        bar = 2
        """)
    node, not_changed = transformer.transform(node)
    assert len(node.body) == 2
    assert not not_changed



# Generated at 2022-06-21 18:20:43.101640
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None) != None


# Generated at 2022-06-21 18:20:45.824022
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("def f() -> None: a: float = 10"))

# Generated at 2022-06-21 18:20:47.305795
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('Testing VariablesAnnotationsTransformer!')


# Generated at 2022-06-21 18:20:56.325056
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = "a: int = 10"
    expected_code = "a = 10"
    tree = ast.parse(code)
    transformed_tree = VariablesAnnotationsTransformer.transform(tree)
    assert(ast.unparse(transformed_tree.tree).strip() == expected_code)


# Generated at 2022-06-21 18:21:05.289830
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from . import Visitor
    from ..utils import tree

    module = ast.parse("""
    a: int = 10
    b: int
    """)

    print("Original tree:", tree.str_ast(module))

    result = VariablesAnnotationsTransformer.transform(module)
    print("\nFinal tree:", tree.str_ast(result))

    Visitor().visit(result)

    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.Assign)
    assert isinstance(result.body[1], ast.Assign)

# Generated at 2022-06-21 18:21:09.462877
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print ("-----------------test_VariablesAnnotationsTransformer-----------------")
    from .transformer_test import transform_test_on_single_file
    from ..utils.helpers import compare_source

    result=transform_test_on_single_file(VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:21:14.276092
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    code = """
        a: int = 10
        b: int
    """
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)


# Generated at 2022-06-21 18:21:17.656390
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer."""

    # Test 1:
    import astor
    from typed_ast import ast3

# Generated at 2022-06-21 18:21:23.847684
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.code_gen import to_source
    from transforms.transforms.variables_annotations import VariablesAnnotationsTransformer as VAT
    from typed_ast import ast3 as ast
    from astor import parse
    from ..utils.helpers import get_node_tree

    testcode = "a:int = 10"
    outcode = "a = 10"

    tree = parse(testcode)
    expected_tree = parse(outcode)

    node_tree = get_node_tree(tree)
    expected_node_tree = get_node_tree(expected_tree)

    VAT.transform(node_tree)

    assert to_source(node_tree) == to_source(expected_node_tree)


# Generated at 2022-06-21 18:21:27.346907
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse("a:int = 10")
    result = VariablesAnnotationsTransformer.transform(test_tree)

    assert isinstance(result.tree, ast.AST)



# Generated at 2022-06-21 18:21:28.710071
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__init__() is not None



# Generated at 2022-06-21 18:21:33.770340
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:21:38.851214
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(tree)

    tree = ast.parse('a: int\nb: int')
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(tree)

# Generated at 2022-06-21 18:21:58.709766
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1: simple test
    tree = ast.AnnAssign(target=ast.Name(id='foo', ctx=ast.Store()),
                         annotation=ast.Name(id='str', ctx=ast.Store()),
                         value=None,
                         simple=1)
    expected_tree = ast.Assign(targets=[ast.Name(id='foo', ctx=ast.Store())],
                               value=None,
                               type_comment=ast.Name(id='str', ctx=ast.Store()))
    test_result = VariablesAnnotationsTransformer.transform(tree)
    assert(len(test_result.warnings) == 0)
    assert(test_result.tree == expected_tree)

    # Test 2: with value

# Generated at 2022-06-21 18:22:02.907790
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
c: int = 20
""").body
    expected = ast.parse("""
a = 10
c = 20
""").body
    result = VariablesAnnotationsTransformer().transform(tree)
    assert result.tree == expected

# Generated at 2022-06-21 18:22:03.462029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:22:13.827940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast

# Generated at 2022-06-21 18:22:25.244621
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.target == (3, 5)

    class_tree = ast.copy_location(
        ast.ClassDef(name='Test',
                     body=[ast.AnnAssign(target=ast.Name(id='target'),
                                         annotation=ast.Name(id='target_annotation'),
                                         value=ast.Num(n=10))],
                     decorator_list=[]),
        lineno=1,
        col_offset=0
    )


# Generated at 2022-06-21 18:22:28.573152
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    assert astor.code_gen.to_source(
        VariablesAnnotationsTransformer.transform(
            ast.parse('a: int = 10\nb: int')).tree) == "a = 10\n"

# Generated at 2022-06-21 18:22:29.568535
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-21 18:22:30.848748
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None) is not None

# Generated at 2022-06-21 18:22:38.319734
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # variables annotations
    input_code = '''
    a: int = 10
    b: int
    '''
    expected_output_code = '''
    a = 10
    '''
    output_code = VariablesAnnotationsTransformer.transform_code(input_code, 3.5)
    assert output_code == expected_output_code

# Generated at 2022-06-21 18:22:44.790053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast as pyast
    from typed_ast import ast3
    from ..utils import as_tuple
    from ..transforms.variables_annotations import VariablesAnnotationsTransformer
    from .test_base import BaseTransformerTest

    class Test(BaseTransformerTest):
        target_tree = as_tuple(pyast.parse("""
        a: int = 10
        b: int
        """))
        expected_tree = as_tuple(pyast.parse("""
        a = 10
        """))

    Test.check()

# Generated at 2022-06-21 18:23:10.265436
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    code = '''
    a: int = 10
    b: int
    '''

    tree = ast.parse(code)
    tree = VariablesAnnotationsTransformer.transform(tree)

    assert ast.dump(tree) == '''\
Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10, kind=None), type_comment=Name(id='int', ctx=Load())), Pass()])
'''

# Generated at 2022-06-21 18:23:12.411493
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert type(VariablesAnnotationsTransformer) == type
    assert type(VariablesAnnotationsTransformer) == type(BaseTransformer)

# Generated at 2022-06-21 18:23:13.623377
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert hasattr(VariablesAnnotationsTransformer, 'transform')


# Generated at 2022-06-21 18:23:20.225739
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    AST = ast.parse('''
a:int = 10
b:int
    ''')
    tree = VariablesAnnotationsTransformer.transform(AST)
    assert(len(tree.body) == 1)
    assert(isinstance(tree.body[0], ast.Assign))
    assert(tree.body[0].targets[0].id == 'a')
    assert(tree.body[0].value.n == 10)
    assert(tree.body[0].type_comment == 'int')

# Generated at 2022-06-21 18:23:23.644054
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    f = "a: int = 10"

    f_ast = ast.parse(f)
    f2_ast = ast.parse("a = 10")

    VariablesAnnotationsTransformer.transform(f_ast)

    assert (str(f_ast) == str(f2_ast))

# Generated at 2022-06-21 18:23:28.334249
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    mysource = '''
        a: int = 10
        b: int
    '''
    mytree = ast3.parse(mysource)
    tree_changed, newtree = VariablesAnnotationsTransformer.transform(mytree)
    assert(tree_changed)
    assert(newtree)

# Generated at 2022-06-21 18:23:33.842652
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""\
            a: int = 10
            b: int
        """)
    new_tree = VariablesAnnotationsTransformer().visit(tree)
    # new_tree = ast.parse("""\
    #         a = 10
    #     """)
    assert ast.dump(new_tree) == ast.dump(ast.parse("""\
            a = 10
        """))

# Generated at 2022-06-21 18:23:41.316723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    trans = VariablesAnnotationsTransformer()
    assert trans.target == (3, 5)
    assert trans.transform(ast.parse("a: int = 10\nb: int")).changed == True
    assert trans.transform(ast.parse("a: int")).changed == True
    assert trans.transform(ast.parse("a: int = 10")).changed == True
    assert trans.transform(ast.parse("a: int = 10 ; b: int")).changed == True

# Generated at 2022-06-21 18:23:44.116369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test function that test the constructor of class VariablesAnnotationsTransformer"""
    print("Testing constructor of class VariablesAnnotationsTransformer")
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-21 18:23:45.297756
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    varC = VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:24:28.567771
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
        a: int = 10
        b: int
        """
    expected_code = """
        a = 10
        """

    ast_tree = ast.parse(code)
    ast_tree = VariablesAnnotationsTransformer.transform(ast_tree)
    assert astor.to_source(ast_tree.tree).strip() == expected_code

# Generated at 2022-06-21 18:24:33.447022
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.python_files import get_all_files
    from .utils import transform_and_compare

    files = get_all_files(3, 5, './tests/data/', 'annotated_variables')
    transform_and_compare(files, VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:24:34.490559
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:38.633983
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """a: int = 10
b: int
"""
    tree = ast.parse(code)
    expected_result = """a = 10
"""
    result = VariablesAnnotationsTransformer.transform(tree).tree
    assert astor.to_source(result).strip() == expected_result

# Generated at 2022-06-21 18:24:42.784109
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
a: int = 10
b: int"""

    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    code_after_transform = ast.unparse(new_tree.tree)

    assert code_after_transform == "a = 10"

# Generated at 2022-06-21 18:24:47.952527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_VariablesAnnotationsTree = ast.parse(
        "import re\n"
        "a: int = 10\n"
        "b: int\n"
        "c: int = None\n"
        "def main():\n"
        "    a, b, c = 1, 2, 3\n"
    )
    p = VariablesAnnotationsTransfo

# Generated at 2022-06-21 18:24:53.757441
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"
    tree = ast.parse("a: int = 10 \n b: int")
    ast.fix_missing_locations(tree)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result[1]

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:24:57.211787
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = 0
    y = x + 1
    f = VariableAnnotationsTransformer()
    x = f.transform(3)
    assert x == 3
    y = f.transform(y)
    assert y == 4

# Generated at 2022-06-21 18:25:06.019007
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()))
    b = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()))
    tree = ast.FunctionDef(name='foo', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                           body=[a, b], decorator_list=[], returns=None)

    # Create an instance of class VariablesAnnotationsTransformer
    VariablesAnnotationsTransformer_instance = VariablesAnnotationsTransformer()
   

# Generated at 2022-06-21 18:25:12.657759
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer(None).tree == None
    assert VariablesAnnotationsTransformer(None).tree_changed == None
    assert VariablesAnnotationsTransformer(None).trees_changed == None
    assert VariablesAnnotationsTransformer(None).changed_trees == None
    assert VariablesAnnotationsTransformer(None).errors == None
    assert VariablesAnnotationsTransformer(None).warnings == None


# Generated at 2022-06-21 18:27:00.687039
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    
    # create an instance of class VariablesAnnotationsTransformer
    a = VariablesAnnotationsTransformer()

    # Example 1
    # initialize node
    expr = ast.parse('a: int = 10').body[0]
    result = a.transform(expr)
    assert(isinstance(result, TransformationResult))
    assert(result.tree_changed == True)
    assert(result.warnings == [])
    assert(isinstance(result.tree, ast.Assign))

    # Example 2
    # initialize node
    expr = ast.parse('b: int').body[0]
    result = a.transform(expr)
    assert(isinstance(result, TransformationResult))
    assert(result.tree_changed == True)
    assert(result.warnings == ['Assignment outside of body'])

# Generated at 2022-06-21 18:27:05.878854
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node=ast.AnnAssign(target=ast.Name(id='a',ctx=ast.Store()), annotation=ast.Name(id='int',ctx=ast.Load()), value=ast.Num(n=10), simple=1)
    root=ast.Module(body=[node])
    t=VariablesAnnotationsTransformer()
    t.transform(root)

# Generated at 2022-06-21 18:27:07.348138
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    va = VariablesAnnotationsTransformer()
    assert va is not None


# Generated at 2022-06-21 18:27:11.450716
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_code = 'def func():\n    a: int = 10\n    b: str'
    expected_code = 'def func():\n    a = 10\n    b = None'
    tree = ast.parse(test_code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_source(tree) == expected_code

# Generated at 2022-06-21 18:27:15.282323
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a: int = 10')
    VariablesAnnotationsTransformer.transform(node)
    expected_node = ast.parse('a = 10')
    assert expected_node == node

# Generated at 2022-06-21 18:27:25.927153
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from .test_utils import should_throw

    class _FakeTransformer(BaseTransformer):
        def visit_AnnAssign(self, node):
            return node

    transformer = _FakeTransformer()

    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), value=None, annotation=None)
    node_after = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), value=None, annotation=None)
    assert node == node_after

    tree = ast.parse('a: int = 2')
    tree_after = ast.parse('a: int = 2')
    assert tree == tree_after


# Generated at 2022-06-21 18:27:32.903879
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .functions import FunctionsAnnotationsTransformer as funAnno
    from .functions import InterfaceTransformer as interface
    from .interfaces import InterfacesTransformer as interFace
    from .classes import ClassesTransformer as classes
    source = """
    a:int = 10
    b:int
    c:int = 19
    def set_r(r: int):
        return "r is set"

    class A:
        a:int = 10
        b:int

        def set_r(r: int):
            return "r is set"
    """

    tree = ast.parse(source)
    tree = interface.transform(tree).tree
    tree = funAnno.transform(tree).tree
    tree = interFace.transform(tree).tree
    tree = classes.transform(tree).tree
    tree = VariablesAnnotations

# Generated at 2022-06-21 18:27:40.793160
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = """
    def func(a: str = None, b: bool = False, c: int = 10):
        a: int = 10
    """
    expected = """
    def func(a: str = None, b: bool = False, c: int = 10):
        pass
    """
    t = VariablesAnnotationsTransformer()
    g = ast.parse(input)
    res: TransformationResult = t.transform(g)
    assert ast.unparse(res.tree) == expected

# Generated at 2022-06-21 18:27:45.476516
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import ast_from_str
    code = ast_from_str('a: int = 1', 3)
    assert code.body[0].__class__.__name__ == "AnnAssign"
    code = VariablesAnnotationsTransformer.transform(code)
    assert code.body[0].__class__.__name__ == "Assign"

# Generated at 2022-06-21 18:27:48.737837
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("def k():\n    a: int = 10\n    b: int")).new_tree == ast.parse("def k():\n    a = 10")