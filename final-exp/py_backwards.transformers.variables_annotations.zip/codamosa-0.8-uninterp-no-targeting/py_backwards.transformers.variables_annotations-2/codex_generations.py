

# Generated at 2022-06-21 18:19:01.749267
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    file_path = 'tests/samples/typed_samples/typed_variables.py'
    with open(file_path) as f:
        tree = ast_parse(f.read())
        a = VariablesAnnotationsTransformer.transform(tree)
    assert a.tree_changed

# Generated at 2022-06-21 18:19:13.097240
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse('a: int = 10\nb: int\n').body[0]
    result = VariablesAnnotationsTransformer.transform(a)
    assert isinstance(result.node, ast.Assign)
    assert result.node.targets == [ast.Name(id='a', ctx=ast.Store())]
    assert result.node.value.n == 10
    assert result.node.type_comment == 'int'
    assert result.changed == True

    b = ast.parse('a: int = 10\nb: int = ast.parse(\'10\')\n').body[1]
    result = VariablesAnnotationsTransformer.transform(b)
    assert isinstance(result.node, ast.Assign)

# Generated at 2022-06-21 18:19:18.683811
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
        """
        a: int = 10
        b: int
        """
    )
    VariablesAnnotationsTransformer(tree).replace()

    expected = ast.parse(
        """
        a = 10
        """
    )
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-21 18:19:20.174696
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:26.725992
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor, typed_ast
    from ..utils.helpers import trim_docstring
    from .base import BaseAPITransformer
    # use a defined class
    class NodeTransformer(ast.NodeTransformer):
        pass
    # use a defined visitor
    class NodeVisitor(ast.NodeVisitor):
        pass
    class VariablesAnnotationsTransformer(
        BaseAPITransformer, NodeTransformer):
        pass

# Generated at 2022-06-21 18:19:31.991917
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('x: int = 10')
    transformed_tree, changed, _ = VariablesAnnotationsTransformer.transform(tree)
    assert(transformed_tree.body[0].value.n == 10)

# Generated at 2022-06-21 18:19:39.530656
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup code
    _tree = ast.parse('a: int = 10\nb: int\n')
    _expected = ast.parse('a = 10\n')

    # Test code
    _result = VariablesAnnotationsTransformer.transform(_tree)

    # Assertion
    assert _result.tree_changed
    assert _result.tree.body[0].type_comment == None
    assert ast.dump(_result.tree, include_attributes=True) == ast.dump(_expected, include_attributes=True)

    pass

# Generated at 2022-06-21 18:19:42.159590
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    variablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    print(variablesAnnotationsTransformer)

# Generated at 2022-06-21 18:19:53.117994
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transform
    from ..utils.helpers import ClassHelper, FuncHelper
    code_before = "a: int = 10\nb: int"
    code_after = "a = 10"
    assert_transform(VariablesAnnotationsTransformer, code_before, code_after)
    code_before = "a: int = 10\n"
    code_after = "a = 10"
    assert_transform(VariablesAnnotationsTransformer, code_before, code_after)
    code_before = "a: int"
    code_after = ""
    assert_transform(VariablesAnnotationsTransformer, code_before, code_after)
    code_before = "def f(a: int):\n    pass"
    code_after = "def f(a):\n    pass"

# Generated at 2022-06-21 18:20:04.965791
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a:int = 10
    x = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Constant(value=10, kind=None), simple=1)
    # b:int
    y = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=None, simple=0)

    mod = ast.Module(body=[x, y])

    assert isinstance(VariablesAnnotationsTransformer.transform(mod), TransformationResult)
    assert isinstance(VariablesAnnotationsTransformer.transform(mod).tree, ast.Module) # test if method returns ast

# Generated at 2022-06-21 18:20:10.745404
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	from ..utils.helpers import transform_from_input
	result = transform_from_input(VariablesAnnotationsTransformer,
								  'a: int = 1\nb: int\n'
								  )
	expected = """
	a = 1
	b: int
	""".strip()
	assert result == expected

# Generated at 2022-06-21 18:20:22.863934
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_name = VariablesAnnotationsTransformer.__name__
    # test 1
    trans = VariablesAnnotationsTransformer()
    tree = ast.parse('')
    output = trans.transform(tree)
    print(output)
    assert(output.tree == tree)
    assert(output.tree_changed == False)
    assert(output.changed_nodes == [])
    # test 2
    trans = VariablesAnnotationsTransformer()
    tree = ast.parse('a: int = 10')
    output = trans.transform(tree)
    print(output)
    assert(output.tree_changed == True)
    assert(output.changed_nodes == [])
    # test 3
    trans = VariablesAnnotationsTransformer()
    tree = ast.parse('a: int')

# Generated at 2022-06-21 18:20:23.846286
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:35.429716
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    A test for VariablesAnnotationsTransformer.
    '''
    import astor
    from ast import AnnAssign
    node = AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                     annotation=ast.Name(id='int', ctx=ast.Load()),
                     value=ast.Constant(value=10, kind=None),
                     simple=True)

# Generated at 2022-06-21 18:20:38.149187
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__qualname__ == "VariablesAnnotationsTransformer"
    assert VariablesAnnotationsTransformer.target == (3,5)


# Generated at 2022-06-21 18:20:43.459437
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int
    b = 10

    global_scope = globals()
    global_scope['a'] = a
    global_scope['b'] = b

    assert global_scope['a'] == 10
    assert global_scope['b'] == 10

    # Creates an instance of VariablesAnnotationsTransformer
    VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:20:48.605614
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_data_3_5 import variables_annotation_assign_node

    module = variables_annotation_assign_node
    module_changed, _ = VariablesAnnotationsTransformer.transform(module)
    assert module_changed

    assert str(module) == 'a = 10\n'

# Generated at 2022-06-21 18:20:57.042501
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    s = """
    import a
    a: int = 10
    b: int
    """
    # tree: Module(body=[...])
    tree = ast.parse(s)
    transformation_variables_annotations_transformer = VariablesAnnotationsTransformer.transform(tree)
    # transformation_variables_annotations_transformer: {'tree': <_ast.Module object at 0x10e0be898>, 'tree_changed': True, 'files': []}
    print(transformation_variables_annotations_transformer)
    assert transformation_variables_annotations_transformer['tree_changed'] == True


# Generated at 2022-06-21 18:21:07.810363
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('from typing import List, Union; A: List[Union[int, str, bool]]').body[0]
    ).tree == ast.parse('from typing import List, Union; A: List[Union[int, str, bool]]').body[0]

    assert VariablesAnnotationsTransformer.transform(
        ast.parse('from typing import List, Union; A: List[Union[int, str, bool]] = [1, "bc", True]').body[0]
    ).tree == ast.parse('from typing import List, Union; A = [1, "bc", True]').body[0]


# Generated at 2022-06-21 18:21:18.338020
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""print('test')\n""")
    class_def = ast.parse("""class Foo:\n    bar: int\n        """)
    fun_def = ast.parse("""def fun():\n    a: int\n        """)
    assign = ast.parse("""a: int = None\n        """)
    trans_assign = ast.parse("""a = None\n        """)
    assert VariablesAnnotationsTransformer.transform(tree).tree == tree
    assert VariablesAnnotationsTransformer.transform(class_def).tree == class_def
    assert VariablesAnnotationsTransformer.transform(fun_def).tree == fun_def
    assert VariablesAnnotationsTransformer.transform(assign).tree == trans_assign

# Generated at 2022-06-21 18:21:29.200597
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import AstFactory

    tree = AstFactory.parse("""
a: int = 1
b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    expected = AstFactory.parse("""
a = 1
    """)
    assert_ast(result.tree,expected,transformer=VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:21:30.570563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer()
    assert v.target == (3, 5)

# Generated at 2022-06-21 18:21:31.655196
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:21:37.810513
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	assert VariablesAnnotationsTransformer.__doc__ is not None

# Unit tests for class VariablesAnnotationsTransformer
from ..utils.helpers import compile_to_ast
from ..exceptions import InvalidPythonVersion
from ..PythonVersion import PythonVersion
from ..utils.tree import compare_trees
from ..utils.tree import tree_from_str
from ..utils.tree import tree_to_str

# Generated at 2022-06-21 18:21:41.152609
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()

    # Test if target is a tuple of two ints.
    assert variables_annotations_transformer.target == (3,5)


# Generated at 2022-06-21 18:21:42.929623
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    trans = VariablesAnnotationsTransformer()
    assert type(trans) == VariablesAnnotationsTransformer


# Generated at 2022-06-21 18:21:44.125564
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.target == (3, 5)


# Generated at 2022-06-21 18:21:50.910389
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    to test the VariablesAnnotationsTransformer class
    """
    dict_1 = {"__qualname__": "List", "lineno": 1, "col_offset": 0, "ctx": {"__class__": "Load", "id": "Load"}, "elts": [{"__class__": "Num", "n": 4, "lineno": 2, "col_offset": 4}], "lineno": 1, "col_offset": 0}
    object_1 = VariablesAnnotationsTransformer()
    print(object_1.transform(dict_1))

# Generated at 2022-06-21 18:21:52.332694
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"

# Generated at 2022-06-21 18:21:57.213087
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    test_tree = ast.parse('a: int = 3')
    test_visitor = VariablesAnnotationsTransformer()
    test_visitor.transform(test_tree)
    print('test_VariablesAnnotationsTransformer 1 OK')

# Generated at 2022-06-21 18:22:07.086269
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass
# Code for unit test


# Generated at 2022-06-21 18:22:15.749180
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import Generator
    from ..utils.helpers import get_code_object_from_function

    samples = [
        get_code_object_from_function(
            lambda: '''
            a: int = 10
            b: int
            '''
        ),
        get_code_object_from_function(
            lambda: '''
            a, b: int = 10
            c: int
            '''
        ),
        get_code_object_from_function(
            lambda: '''
            def f(a: str, *b: int, c: int, **d): pass
            '''
        )
    ]

# Generated at 2022-06-21 18:22:27.226600
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node_a = ast.AnnAssign(
    target=ast.Name(id='a',ctx=ast.Store()),
    annotation=ast.Name(id='int',ctx=ast.Store()),
    value=ast.Constant(value=10,kind=None),
    simple=1)
    node_b = ast.AnnAssign(
    target=ast.Name(id='b',ctx=ast.Store()),
    annotation=ast.Name(id='int',ctx=ast.Store()),
    value=None,
    simple=0)
    output = ast.Module(body=[node_a, node_b])

# Generated at 2022-06-21 18:22:34.524350
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse("a: int = 10")
    b = ast.parse("b: int")
    a = VariablesAnnotationsTransformer.transform(a)
    b = VariablesAnnotationsTransformer.transform(b)
    assert a.tree.body[0].value.lineno == 1
    assert a.tree_changed is True
    assert isinstance(b.tree, ast.Module)
    assert b.tree_changed is True

# Generated at 2022-06-21 18:22:39.564192
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

    vAT = VariablesAnnotationsTransformer()

    a = ast.fix_missing_locations(ast.parse(
        """a: int = 1
           b: int"""))

    assert astor.to_source(vAT.transform(a)) == \
             '           a = 1'

# Generated at 2022-06-21 18:22:47.407935
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import transform

    from .test_transformer import _test_transform, apply_transforms

    # To test the classes
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))

    from .test_transformer import (
        _test_transform,
    )

    tree = ast.parse("""
    a: int = 10
    b: int
    c = 20
    """)

    expected_tree = ast.parse("""
    a = 10
    c = 20
    """)

    tree = transform(tree, [VariablesAnnotationsTransformer])

    _test_transform(tree, expected_tree)

# Generated at 2022-06-21 18:22:48.899589
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

# Generated at 2022-06-21 18:22:51.424369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int; b: int = 5')
    assert tree == VariablesAnnotationsTransformer.transform(tree).tree

# Generated at 2022-06-21 18:23:00.580280
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create class VariablesAnnotationsTransformer
    vat = VariablesAnnotationsTransformer()

    # Create three VariableAnnotations
    a = ast.AnnAssign()
    b = ast.AnnAssign()
    c = ast.AnnAssign()

    # Set targets of three VariableAnnotations
    a.target = ast.Name('a', ast.Store())
    b.target = ast.Name('b', ast.Store())
    c.target = ast.Name('c', ast.Store())

    # Set values of three VariableAnnotations
    a.value = ast.Num(10)
    b.value = ast.Num(20)
    c.value = ast.Num(30)

    # Set annotations of three VariableAnnotations
    a.annotation = ast.Num(5)

# Generated at 2022-06-21 18:23:07.122554
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import to_source

    code = '''
    a: int
    b: int = 10
    '''
    tree = build_ast(code, 3, 5)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_source(result.tree) == code

# Generated at 2022-06-21 18:23:30.129108
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  a = ast.parse('a: int = 10')
  b = ast.parse('b: int')
  c = ast.parse('a = 10\nb = 0')
  d = ast.parse('int = 10\nint')
  VariablesAnnotationsTransformer.transform(a)
  assert a == c
  VariablesAnnotationsTransformer.transform(b)
  assert b == d

# Generated at 2022-06-21 18:23:31.552593
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-21 18:23:42.733485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Case 1:
    # a: int = 10
    # b: int
    # After transformation:
    # a = 10

    annAssign1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
                               simple=1, value=ast.Constant(value=10, kind=None))
    annAssign2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
                               simple=0, value=None)

# Generated at 2022-06-21 18:23:45.804534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert tree == ast.parse("""
    a = 10
    b: int
    """)

# Generated at 2022-06-21 18:23:55.755038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.Name(id='a', ctx=ast.Store())
    b = ast.Name(id='b', ctx=ast.Store())
    c = ast.Name(id='c', ctx=ast.Store())
    d = ast.Name(id='d', ctx=ast.Store())
    a_annot = ast.Name(id='int')
    b_annot = ast.Name(id='str')
    c_annot = ast.Name(id='bool')
    d_annot = ast.Name(id='list')
    a_value = ast.Num(n=10)
    b_value = ast.Str(s='value')
    c_value = ast.NameConstant(value=True)
    d_value = ast.List(elts=[], ctx=ast.Load())
    func

# Generated at 2022-06-21 18:23:59.688262
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    code_str = """
a: int = 10
b: int
    """
    tree = ast.parse(code_str)
    VariablesAnnotationsTransformer.transform(tree)
    assert (astor.to_source(tree) == """
a = 10
""")

# Generated at 2022-06-21 18:24:06.849265
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing_utils import str_ast, parse_ast
    from .type_comments import TypeCommentTransformer

    code = '''
    c: int
    d: int = 10
    g: int
    '''
    expected_result = '''
    c: int
    d: int = 10
    g: int
    '''
    result: ast.AST = VariablesAnnotationsTransformer.transform(
        TypeCommentTransformer.transform(parse_ast(code))[0])
    assert str_ast(result) == expected_result

# Generated at 2022-06-21 18:24:08.288758
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_inst = VariablesAnnotationsTransformer
    class_inst.transform()

# Generated at 2022-06-21 18:24:10.856260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == 'a = 10'

# Generated at 2022-06-21 18:24:22.028805
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit tests for class VariablesAnnotationsTransformer."""

    # Imports
    from ..utils.tree import compile_ast

    # Tests
    test_source_list = ['''
a: int = 10
b: int
c: int
b = 12
''',
    '''
d: int = 10
e: int
f: int
d = 12
e = 12
''',
    '''
a: str = "hello"
b: str
c: str
b = "12"
''',
    '''
a: bool = True
b: bool
c: bool
b = True
''',
    '''
a: bool = True
b: bool
c: list
b = True
c = [1,2,3]
''',]

# Generated at 2022-06-21 18:25:04.982475
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''Test function for constructor of class VariablesAnnotationsTransformer'''
    t1 = VariablesAnnotationsTransformer()
    assert t1.target == (3, 5)

# Generated at 2022-06-21 18:25:11.293624
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Tests constructor of class VariablesAnnotationsTransformer"""
    tree_path = os.path.join(os.path.dirname(__file__),
                             '../../examples/variables_annotation_example.py')
    with open(tree_path) as example_tree:
        tree = ast.parse(example_tree.read())
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True

# Generated at 2022-06-21 18:25:14.277228
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test for constructor
    a = VariablesAnnotationsTransformer()
    assert a is not None, "test for constructor of class VariablesAnnotationsTransformer is failed"


# Generated at 2022-06-21 18:25:20.323462
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import tree_to_str
    from .dataclasses import DataclassTransformer

    sample = '''
        from dataclasses import dataclass, field

        @dataclass
        class X:
            a: int
            b: int
            c: int = field(default=0)
            d: int = 10
    '''
    print(tree_to_str(DataclassTransformer.transform(sample)[0]))
    assert 1 == 1

# Generated at 2022-06-21 18:25:22.123497
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_transformer import compile_to_untyped_python

# Generated at 2022-06-21 18:25:30.269195
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Annotation is not compiled
    assert str(
        ast.parse('''
a: int = 10
b: int
''').body) == '[AnnAssign(target=Name(id=\'a\', ctx=Store()), annotation=Name(id=\'int\', ctx=Load()), value=Constant(value=10, kind=None), simple=1),\n AnnAssign(target=Name(id=\'b\', ctx=Store()), annotation=Name(id=\'int\', ctx=Load()), value=None, simple=0)]'

# Generated at 2022-06-21 18:25:33.995912
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # type: () -> None
    '''
    Checks if the constructor of VariablesAnnotationsTransformer works properly.
    '''
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.transform('') == TransformationResult('', False, [])



# Generated at 2022-06-21 18:25:36.505256
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    vart = VariablesAnnotationsTransformer()
    assert vart.transform(tree).tree_changed == True

# Generated at 2022-06-21 18:25:38.479956
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform()

# Generated at 2022-06-21 18:25:41.022626
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a:int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.changed == True
    assert result.code == b'\n'

# Generated at 2022-06-21 18:27:33.288789
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),  # type: ignore
                                 annotation=ast.Name(id='int', ctx=ast.Load()), # type: ignore
                                 value=None)
    b = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),  # type: ignore
                      annotation=ast.Name(id='int', ctx=ast.Load()), # type: ignore
                      value=ast.Num(n=10))
    c = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),  # type: ignore
                                 annotation=ast.Name(id='int', ctx=ast.Load()), # type: ignore
                                 value=None)



# Generated at 2022-06-21 18:27:41.269313
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # target is a static variable of type tuple
    assert isinstance(VariablesAnnotationsTransformer.target, tuple)
    # default_priority is a static variable of type int
    assert isinstance(VariablesAnnotationsTransformer.default_priority, int)
    # target_ast_version is a static variable of type tuple
    assert isinstance(VariablesAnnotationsTransformer.target_ast_version, tuple)
    # error_message is a static variable of type None
    assert isinstance(VariablesAnnotationsTransformer.error_message, None)


# Generated at 2022-06-21 18:27:44.957891
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = parse(
        """
        class Foo(object):
            a: int = 10
            b: int
    """)
    assert VariablesAnnotationsTransformer.transform(tree)


if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:27:45.485503
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:27:47.128071
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer
    assert vat.__module__ in vat.__qualname__

# Generated at 2022-06-21 18:27:50.509140
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:27:54.010141
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    root = ast.parse(
        'x: int = 10\n' +
        'y: int\n')
    transformer = VariablesAnnotationsTransformer()
    new_tree = transformer.transform(root)
    assert new_tree.tree == ast.parse('x = 10')

# Generated at 2022-06-21 18:27:55.185628
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:28:01.728985
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import Type
    from ..types import TransformationResult
    
    test_tree_1 = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store(), annotation=Type('a',int))],value=ast.Num(n=10),type_comment=Type('a',int))
    test_tree_2 = ast.Module(body=[test_tree_1])
    
    # call function
    result = VariablesAnnotationsTransformer.transform(test_tree_2)
    # unit test
    assert(result.tree == ast.Module(body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10))]
                                     , type_ignores=[Type('a',int)]))

# Generated at 2022-06-21 18:28:05.240186
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
        Test constructor of class VariablesAnnotationsTransformer
    """
    test_var = VariablesAnnotationsTransformer()
    assert test_var.target == (3, 5), 'Check target of VariablesAnnotationsTransformer'
    return True
