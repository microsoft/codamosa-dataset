

# Generated at 2022-06-21 18:19:00.437151
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse("""x: int = 10\ny""")
    res = VariablesAnnotationsTransformer.transform(node)
    node.body[0].target.ctx = ast.Store()
    assert res == TransformationResult(ast.parse("""x = 10\ny"""), True, [])

# Generated at 2022-06-21 18:19:07.104365
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    new_tree = VariablesAnnotationsTransformer().transform(tree).tree

    assert new_tree.body == [
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                   value=ast.Num(n=10),
                   type_comment=ast.Str(s='int')),
        ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                   value=None,
                   type_comment=ast.Str(s='int'))
    ]

# Generated at 2022-06-21 18:19:09.033562
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:14.066707
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_in = ast.parse('''
x:int = 10
y: int = 20
''', mode='exec')

    tree_out = ast.parse('''
x = 10
y = 20
''', mode='exec')

    res = VariablesAnnotationsTransformer.transform(tree_in)
    assert res.transformed == tree_out, 'should correctly transform tree'

# Generated at 2022-06-21 18:19:17.258134
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer()
    assert class_.target == (3, 5)
    assert class_.__class__.__name__ == "VariablesAnnotationsTransformer"

# Generated at 2022-06-21 18:19:27.925413
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import unittest
    import astunparse as ap

    class TestVariablesAnnotationsTransformer(unittest.TestCase):
        def test_simple_variable(self):
            a = """a: int = 10
            """
            tree = ast.parse(a)
            res = VariablesAnnotationsTransformer.transform(tree)
            expected = ap.unparse(ast.parse('a = 10'))
            self.assertEqual(ap.unparse(res.node), expected)

        def test_multiple_variable(self):
            a = """a: int = 10
                b: int = 20
            """
            tree = ast.parse(a)
            res = VariablesAnnotationsTransformer.transform(tree)
            expected = 'a = 10\nb = 20'

# Generated at 2022-06-21 18:19:39.858029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected_tree = ast.Module([
        ast.FunctionDef(
            'f',
            ast.arguments(
                posonlyargs=[],
                args=[],
                vararg=None,
                kwonlyargs=[],
                kwarg=None,
                defaults=[],
                kw_defaults=[],
            ),
            [
                ast.Expr(ast.Call(
                    ast.Name('print', ast.Load()),
                    [ast.Str('This is a string')],
                    []
                )),
                ast.Assign(
                    [ast.Name('a', ast.Store())],
                    ast.Num(10),
                )
            ],
            [],
            None
        )
    ])


# Generated at 2022-06-21 18:19:51.674652
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Initialize
    from ..utils.helpers import get_ast
    from ..utils.uast import dump, get_all_of_type
    from .class_definitions_transformer import ClassDefinitionsTransformer
    from .function_definitions_transformer import FunctionDefinitionsTransformer
    from .function_annotations_transformer import FunctionAnnotationsTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:54.333681
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    a = VariablesAnnotationsTransformer.__init__()
    assert (a is None)


# Generated at 2022-06-21 18:19:55.511899
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:20:05.585925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ''' 
    This unit test serves to test whether the VariablesAnnotationsTransformer class functions properly
    '''

    from typed_ast import ast3 as ast  
    code = "a: int = 10"  
    test_tree = ast.parse(code)
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(test_tree)  
    result = transformer.result
    result_code = compile(result, filename='<string>', mode='eval')
    exec(result_code)
    assert a == 10

# Generated at 2022-06-21 18:20:15.034498
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # The class VariablesAnnotationsTransformer is a class which contains a constructor with @classmethod

    a_assign_10 = ast.AnnAssign(target=ast.Name("a", ast.Store()),
                                annotation=ast.Name("int"),
                                value=ast.Num(10),
                                simple=1)
    b_assign_int = ast.AnnAssign(target=ast.Name("b", ast.Store()),
                                 annotation=ast.Name("int"),
                                 value=None,
                                 simple=0)
    test_body = [a_assign_10, b_assign_int]


# Generated at 2022-06-21 18:20:26.035542
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import unittest
    import sys
    import os
    import astunparse
    from typed_ast.ast3 import parse

    class TestMethods(unittest.TestCase):
        def test_1(self):
            input_string = "a: int = 10\nb: int"
            expected_output_string = "a = 10"
            tree = parse(input_string)
            new_tree = VariablesAnnotationsTransformer.transform(tree)

            self.assertEqual(astunparse.unparse(new_tree), expected_output_string)

        def test_2(self):
            input_string = "a: int = 10\nb = 10"
            expected_output_string = "a = 10\nb = 10"
            tree = parse(input_string)
            new_tree = VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:27.087089
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:30.369719
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from .test_BaseTransformer import _apply_transformer, _compare_ast


# Generated at 2022-06-21 18:20:34.734997
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.__doc__ == "Compiles:\n        a: int = 10\n        b: int\n    To:\n        a = 10\n\n    "

# Generated at 2022-06-21 18:20:46.358440
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    from ..utils.helpers import compare_node


# Generated at 2022-06-21 18:20:51.209282
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  """
  >>> VariablesAnnotationsTransformer.get_transformed("a: int = 10")
  "a = 10"
  """
  print(VariablesAnnotationsTransformer.get_transformed("a: int = 10"))

if __name__ == "__main__":
  import doctest
  doctest.testmod()

# Generated at 2022-06-21 18:20:55.076615
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    s = """
    a: int = 10
    b: int
    """
    module = ast.parse(s)

    assert VariablesAnnotationsTransformer.transform(module) == TransformationResult(
        ast.parse("""
        a = 10
        """), True, [])

# Generated at 2022-06-21 18:21:05.962509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Test whether the VariablesAnnotationsTransformer is working properly
    '''
    ####
    # Test that a: int = 10 is translated to a = 10
    ####
    var_annot_code_1 = 'a: int = 10'
    vartree_1 = ast.parse(var_annot_code_1)
    # Apply the transformation
    VariablesAnnotationsTransformer.apply(vartree_1)
    # Try the transformation and check if the transformation worked
    vartree_1_transformed = 'a = 10'
    assert_code_equivalence(vartree_1, vartree_1_transformed)

    ####
    # Test that b: int is translated to b = None
    ####
    var_annot_code_2 = 'b: int'
    vart

# Generated at 2022-06-21 18:21:11.727955
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:21:15.685616
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    my_transformer = VariablesAnnotationsTransformer()
    assert isinstance(my_transformer, VariablesAnnotationsTransformer)
    assert isinstance(my_transformer, BaseTransformer)

# Generated at 2022-06-21 18:21:18.714670
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .coverage_test_helper import coverage_test_helper
    coverage_test_helper(VariablesAnnotationsTransformer, './tests/fixtures/test_transformers/variable_annotations_transformer.py')

# Generated at 2022-06-21 18:21:21.314244
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    This test case tests the constructor of class VariablesAnnotationsTransformer
    """
    transformer_object = VariablesAnnotationsTransformer()
    assert transformer_object.target == (3, 5)


# Generated at 2022-06-21 18:21:24.793876
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test constructor of class VariablesAnnotationsTransformer
    """
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-21 18:21:29.762634
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    code = 'a: int = 10\nb: int'
    tree = ast.parse(code)
    expected_code = 'a = 10'
    expected_tree = ast.parse(expected_code)

    # Act
    result = VariablesAnnotationsTransformer.transform(tree)

    # Assert
    assert result.tree != expected_tree

# Generated at 2022-06-21 18:21:35.910150
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for transformations from tree to tree
    from typing import List, Dict

    from ..utils.helpers import cst_to_ast, print_ast
    from ..utils.tree import get_all_nodes_with_type, get_all_nodes_with_types

    from .base import BaseTransformer
    from .transformations import VariablesAnnotationsTransformer

    # Original tree
    cst_tree = cst_to_ast('''
        def foo():
            a : int = 10
            b: int
    ''')

    foo_body = get_all_nodes_with_type(
        cst_tree,
        ast.FunctionDef
    )[0].body  # type: List[ast.AST]

# Generated at 2022-06-21 18:21:46.460847
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    astree = ast.parse(
            '''
            a: int = 10
            b: int
            '''
        )

    result = VariablesAnnotationsTransformer.transform(astree)
    assert isinstance(result, TransformationResult)
    assert isinstance(result.tree, ast.Module)
    assert len(result.tree.body) == 2
    assert isinstance(result.tree.body[1], ast.Assign)
    assert isinstance(result.tree.body[1].value, ast.Num)
    assert result.tree.body[1].value.n == 10
    assert isinstance(result.tree.body[1].targets[0],ast.Name)
    assert result.tree.body[1].targets[0].id == 'a'

# Generated at 2022-06-21 18:21:57.257338
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:21:58.190505
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:22:09.021107
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)
    assert VariablesAnnotationsTransformer.transform(3, 5) == None

# Generated at 2022-06-21 18:22:16.883819
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test that VariablesAnnotationsTransformer works
    transformer = VariablesAnnotationsTransformer()
    test_ast_str = """
a: int = 10

if True:
    a: int = 20

b: int = 30
"""
    tree = ast.parse(test_ast_str)
    new_tree = transformer.transform(tree)

# Generated at 2022-06-21 18:22:21.048908
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')) == \
        TransformationResult(tree=ast.parse('a = 10'), tree_changed=True, warnings=())


# Generated at 2022-06-21 18:22:31.208155
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import apply_transformer
    import inspect
    import typed_ast.ast3 as ast

    source = inspect.getsource(VariablesAnnotationsTransformer)
    tree = ast.parse(source)
    tree = apply_transformer(tree, VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:22:35.933498
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import transform
    import sys


# Generated at 2022-06-21 18:22:45.934055
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils import prettify
    from ..exceptions import NoChangeRequiredException

    test_code = '''
a: int = 10
b: int
    '''

    expected_code = '''
a = 10
    '''
    
    
    tree = ast.parse(test_code)
    expected_tree = ast.parse(expected_code)

    try:
        transformer = VariablesAnnotationsTransformer()
        transformed_tree = transformer.transform(tree)
    except NoChangeRequiredException:
        print("No change required")

    print("Initial code:")
    print(prettify(astor.to_source(tree)))
    print("After transformation:")
    print(prettify(astor.to_source(transformed_tree.tree)))
    print("Expected:")
   

# Generated at 2022-06-21 18:22:48.410164
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer(): # pragma nocover
    class_ = VariablesAnnotationsTransformer()
    print(class_.validate())
    print(class_.validate(target=(3, 5)))


# Generated at 2022-06-21 18:22:51.224570
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    target = (3, 5)
    cls = VariablesAnnotationsTransformer(target)

    assert cls.target == target
    assert cls.transform((3, 5))

# Generated at 2022-06-21 18:22:59.476301
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert ast.dump(VariablesAnnotationsTransformer.transform(
        ast.parse("""
if true:
    a: str = 'a'
    b: str
    """)
    ).tree) == "Module(body=[If(test=NameConstant(value=True), body=[], orelse=[])])"
    assert ast.dump(VariablesAnnotationsTransformer.transform(
        ast.parse("""
if true:
    a: str = 'a'
    b: str = 'b'
    """)
    ).tree) == "Module(body=[If(test=NameConstant(value=True), body=[], orelse=[])])"

# Generated at 2022-06-21 18:23:05.406231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .utils import should_not_change
    import inspect
    import ast

    tree = ast.parse(inspect.getsource(test_VariablesAnnotationsTransformer))
    transformer = VariablesAnnotationsTransformer()
    new_tree = transformer.transform(tree)

    should_not_change(tree, new_tree)

# Generated at 2022-06-21 18:23:25.944429
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import run_transformer_on_single_file

    run_transformer_on_single_file(VariablesAnnotationsTransformer, __file__)

# Generated at 2022-06-21 18:23:36.640731
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    class DummyNode(ast.AST):
        pass

    tree=ast.Module(body=[ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store(), lineno=1, col_offset=0),
        annotation=ast.Name(id='int', ctx=ast.Load(), lineno=1, col_offset=3),
        value=ast.Num(n=10, lineno=1, col_offset=8),
        simple=1, lineno=1, col_offset=0)])

# Generated at 2022-06-21 18:23:45.840372
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    from typed_ast import ast3 as ast
    from ..utils.testing import get_code_from_ast
    node = ast.AnnAssign(annotation=ast.parse('int').body[0].value, target=ast.Name(id='a', ctx=ast.Store()),
                         value=ast.Num(n=10), simple=1)
    expected_code = 'a = 10\n'

    # When
    result = VariablesAnnotationsTransformer.transform(node)
    node = result.tree
    code = get_code_from_ast(node)

    # Then
    assert code == expected_code
    assert result.tree_changed == True
    assert result.warnings == []

# Generated at 2022-06-21 18:23:48.651698
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer
    import astor
    code = 'a: int = 10'
    tree = ast.parse(code)
    result = vat.transform(tree)
    assert astor.to_source(result.tree) == 'a = 10'

# Generated at 2022-06-21 18:23:59.439285
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..compile import to_source
    from ..exceptions import UntransformableTypeError
    from .. import compile as compile_
    from .test_transformer import tree_assertions
    from .test_transformer import build_transformed_tree_assertions
    from ..types import TransformerOptions

    source = 'a: int = 10'

    tree_assertions(VariablesAnnotationsTransformer, source, [])

    # TODO: check if it is not used in transform
    with pytest.raises(UntransformableTypeError):
        compile_(source, 3, 5)

    tree_assertions(VariablesAnnotationsTransformer, 'b: int', [])

    source = '''
    a: int = 10
    b: int
    '''

# Generated at 2022-06-21 18:24:02.226570
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """v:"" = 1"""
    tree = ast.parse(code, mode='eval')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert(isinstance(tree, ast.AST))

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:24:03.919481
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat == VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:24:15.119725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_name = 'VariablesAnnotationsTransformer'
    x = VariablesAnnotationsTransformer()
    assert isinstance(x, VariablesAnnotationsTransformer)
    assert str(x.__class__) == f'<class \'py2ts.transformers.annotations.{class_name}\'>'
    assert x.__doc__ == f'Compiles:\n\t\ta: int = 10\n\t\tb: int\nTo:\n\t\ta = 10\n'
    assert x.target == (3, 5)
    assert x.transform.__name__ == 'transform'
    assert x.transform.__doc__.strip() == f'This function compiles code from Python {x.target[0]}.{x.target[1]} to Python 3.8'


# Unit testing

# Generated at 2022-06-21 18:24:21.320960
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Tests class & functions in the file.
    module = ast.parse('a: int = 10\n'
                       'b: int\n')
    transformed = VariablesAnnotationsTransformer.transform(module)
    expected = ast.parse('a = 10\n')

    a = ast.dump(transformed.tree)
    b = ast.dump(expected)
    print(a)
    print(b)
    assert a == b

# Generated at 2022-06-21 18:24:22.530093
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:25:05.697460
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from typed_ast import ast3 as ast
    node = astor.parse('''
        a: int = 10
        b: int
        ''').body
    tr = VariablesAnnotationsTransformer()
    assert tr.transform(tree=node) is not None
    assert node is not None

# Generated at 2022-06-21 18:25:12.323561
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''\
    a: "Annotation"
    a = 5
    b: "Annotation" = 5
    ''')
    expected_tree = ast.parse('''\
    a = 5
    a = 5
    b = 5
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed is True
    assert result.tree == expected_tree

# Generated at 2022-06-21 18:25:22.464828
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    # Test case 1
    test_tree_1 = astor.parse_file('''a: int = 10
        b: int
        ''', mode='exec')
    new_transformer = VariablesAnnotationsTransformer()
    new_transform = new_transformer.transform(test_tree_1)
    expected_tree = astor.parse_file('''a = 10
        ''', mode='exec')
    assert astor.to_source(expected_tree) == astor.to_source(new_transform.tree)

    # Test case 2
    test_tree_2 = astor.parse_file('''if True:
        a: int = 10
        b: int
        ''', mode='exec')
    new_transform = new_transformer.transform(test_tree_2)
   

# Generated at 2022-06-21 18:25:26.086691
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Test:
        def test_func(self, a: int, b: int):
            a: int = 10
            b: int
            return a + b
    test = Test()
    assert test.test_func(1,1) == 11


# Generated at 2022-06-21 18:25:29.286708
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("""
a: int = 10
b: int
""", mode='exec')).changed


# Generated at 2022-06-21 18:25:37.497103
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Should not change the tree at all
    tree = ast.parse("""
    a: int = 10
    b = 20
    c: str
    def d():
        pass
    class F:
        pass
    """)
    t = VariablesAnnotationsTransformer()
    out = t.transform(tree)
    print(ast.dump(out))

    # Should change the tree for all definitions of variables
    tree = ast.parse("""
    a: int = 10
    b: int
    def d():
        pass
    class F:
        pass
    """)
    t = VariablesAnnotationsTransformer()
    out = t.transform(tree)
    print(ast.dump(out))

    # Should change the tree for all definitions of variables

# Generated at 2022-06-21 18:25:41.440124
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.transformer_utils import run
    run(VariablesAnnotationsTransformer, ast.parse(
        r"""
a: int = 10
b: int
    """), expected=ast.parse(
        r"""
a = 10
    """))

# Generated at 2022-06-21 18:25:50.437635
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from textx.scoping.tools import get_children_of_type
    from textx.scoping.providers import FQN, ModelPath
    from .helpers import compile, get_model_by_name, compare_ast

    should_be_compiled = """
    class C:
        a: int = 1
        b: int
        c: str
          = 'c'

    class D:
        a: int = 2  # should be deleted
    """

    model = compile(should_be_compiled, debug=True)
    c = get_model_by_name(model, 'C')
    d = get_model_by_name(model, 'D')

    assert get_children_of_type(c, 'Assign').__len__() == 2

# Generated at 2022-06-21 18:25:54.224960
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    x: int = 10
    y = 20
    """
    tree = ast.parse(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    compiled = compile(tree, '', 'exec')
    print(compiled)
    assert compiled == 'x = 10\ny = 20\n'

# Generated at 2022-06-21 18:25:56.913915
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse('my_field: int = 10')
    tree_changed = True
    result = module
    assert (VariablesAnnotationsTransformer.transform(
        module) == TransformationResult(result, tree_changed, []))

# Generated at 2022-06-21 18:27:40.156232
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:27:43.958720
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    result = ast.dump(VariablesAnnotationsTransformer.transform(tree).tree)
    expected = ast.dump(ast.parse("a = 10\nb"))
    assert result == expected


# Generated at 2022-06-21 18:27:50.417359
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    from ast import parse, dump
    source = inspect.getsource(test_VariablesAnnotationsTransformer)
    source_ast = parse(source)
    target_ast = ast.parse("")
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(source_ast)
    assert dump(target_ast) == dump(result.tree)
    assert result.tree_changed == True
    assert result.warnings == []
    assert result.errors == []

# Generated at 2022-06-21 18:27:53.978113
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected = TransformationResult(
        tree=ast.parse(
            'a = 10'),
        changed=True,
        messages=[])

    assert VariablesAnnotationsTransformer.transform(
        tree=ast.parse(
            'a: int = 10')) == expected


# Generated at 2022-06-21 18:27:58.284890
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse('a: int').body[0]
    assert x.__class__.__name__ == 'AnnAssign'
    y = ast.parse('a: int = 10').body[0]
    assert y.__class__.__name__ == 'AnnAssign'
    z = ast.parse('a: int = 10\nb: int').body[1]
    assert z.__class__.__name__ == 'Assign'

# Generated at 2022-06-21 18:28:04.357393
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_code = """
    a: int = 10
    b: float
    if c:
        c: float = 4.4
    """
    tree = ast.parse(test_code)
    assert isinstance(tree, ast.Module)
    transformed = VariablesAnnotationsTransformer.transform(tree)
    assert len(transformed.new_code) == 1
    assert transformed.new_code[0].body[0].__class__.__name__ == 'Assign'

# Generated at 2022-06-21 18:28:05.837690
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a:int = 1
    b:int
    test_string = "a"
    assert VariablesAnnotationsTransformer.transform(test_string) == ('a', False, [])

# Generated at 2022-06-21 18:28:08.505663
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing for the constructor of VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"
    assert VariablesAnnotationsTransformer.__doc__ == "Compiles:\n        a: int = 10\n        b: int\n    To:\n        a = 10\n\n    "


# Generated at 2022-06-21 18:28:16.795312
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse('''
x: int = 5
if x == 5:
    y: int = 10
    print(y)
z: int
print(x, y, z)
    ''')

    # When
    result = VariablesAnnotationsTransformer.transform(tree)

    # Then
    assert str(result.tree) == '''
x = 5
if x == 5:
    y = 10
    print(y)
print(x, y, z)
'''

# Generated at 2022-06-21 18:28:21.878167
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformed_tree, tree_changed = VariablesAnnotationsTransformer.transform(
        ast.parse('a: int = 10'))
    print(ast.dump(transformed_tree))
    assert ast.dump(transformed_tree) == "Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))"
    assert tree_changed is True