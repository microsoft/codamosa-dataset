

# Generated at 2022-06-21 18:19:06.252493
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform('') == (None, False)

# Generated at 2022-06-21 18:19:16.260557
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test transform: removes AnnAssign node and
    # replaces Target with NodeAnnotation if value is not None
    input_node = ast.parse('a: int = 5').body[0]
    result = VariablesAnnotationsTransformer.transform(input_node)
    assert isinstance(result.new_tree, ast.Assign)

    input_node = ast.parse('b: int').body[0]
    result = VariablesAnnotationsTransformer.transform(input_node)
    assert isinstance(result.new_tree, ast.Assign)

    # test that warning is raised when assignment is outside of the body
    input_tree = ast.parse('a: int = 5')
    input_node = input_tree.body[0]
    result = VariablesAnnotationsTransformer.transform(input_node)

# Generated at 2022-06-21 18:19:26.525415
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import should_not_change
    import astor

    @should_not_change
    def check(code):
        tree = ast.parse(code)
        new_tree = VariablesAnnotationsTransformer.transform(tree)
        print(astor.to_source(new_tree.tree))
        assert astor.to_source(new_tree.tree) == code

    check('''a: int = 10''')
    check('''a , b : int = 10''')
    check('''a: int = a''')
    check('''a: int = 10; b: int = 20''')
    check('''a: int = 10
             b: int = 20''')

# Generated at 2022-06-21 18:19:30.065153
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    class B:
        def __init__(self):
            self.a: int
            self.b: int
    '''
    tree = ast.parse(code)
    tree_changed, newtree = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed

# Generated at 2022-06-21 18:19:36.698109
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""
    source = '''
a: str = "hello"
'''

    expected = '''
a = "hello"
'''
    tree = ast.parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree, include_attributes=False) == expected

# Generated at 2022-06-21 18:19:39.213496
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    obj = VariablesAnnotationsTransformer()
    assert obj.__class__ == VariablesAnnotationsTransformer
    assert issubclass(obj.__class__, BaseTransformer)

# Generated at 2022-06-21 18:19:45.752084
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("'a: int = 10'")
    assert tree.body[0].value == "a: int = 10"

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree.body[0].value == "a = 10"

    result = VariablesAnnotationsTransformer.transform(result.tree)
    assert result.tree.body[0].value == "a = 10"

# Generated at 2022-06-21 18:19:56.714516
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_name = VariablesAnnotationsTransformer.__name__
    # Unit test for __init__ method of class VariablesAnnotationsTransformer
    def test_init():
        try:
            VariablesAnnotationsTransformer()
            print('[{}] test_init passed'.format(class_name))
        except Exception:
            print('[{}] test_init failed'.format(class_name))
    test_init()
    # Unit test for transform method of class VariablesAnnotationsTransformer
    def test_transform():
        
        def test_1():
            var_annotation = 'a: int'
            tree = ast.parse(var_annotation)
            result = VariablesAnnotationsTransformer.transform(tree)

            expected_tree = ast.parse(var_annotation)


# Generated at 2022-06-21 18:20:06.202209
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTestTransformer
    from unittest import TestCase
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..exceptions import PartialApplicationError
    from ..types import TransformationResult
    class MyTestCase(BaseTestTransformer, TestCase):
        transformer = VariablesAnnotationsTransformer
        file_path = __file__
        s = """\
        a: bool = True
        # comment
        b: int = 10
        """
        tree = ast.parse(s)
    MyTestCase.test_transform_to_tree()



# Generated at 2022-06-21 18:20:06.784570
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:20:14.343307
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .Transformer import Transformer
    import astunparse
    import typed_ast.ast3 as ast
    class A:
        pass
    tree = ast.parse("a: int = 10")
    t = Transformer()
    t.register_transformer(VariablesAnnotationsTransformer)
    new_tree = t.transform(tree)
    as_code = astunparse.unparse(new_tree)
    assert as_code == "a = 10"

# Generated at 2022-06-21 18:20:25.629302
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Transforms variable
    x = ast.parse("x: int = 2").body[0]
    assert isinstance(VariablesAnnotationsTransformer.transform(x), TransformationResult)

    # Raises error for function
    def f(x): pass
    f = ast.parse(inspect.getsource(f)).body[0]
    try:
        assert VariablesAnnotationsTransformer.transform(f)
    except NodeNotFound:
        assert True
    except:
        assert False

    # Transforms variable in another file
    with open('/Users/josh/PycharmProjects/typy/tests/fixtures/variables-annotations/annotations-with-assign.py', 'r') as file:
        tree = ast.parse(file.read())

# Generated at 2022-06-21 18:20:30.648960
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Tests correctness of constructor of class VariablesAnnotationsTransformer
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer.target == (3, 5)
    assert variables_annotations_transformer.name == 'VariablesAnnotationsTransformer'


# Generated at 2022-06-21 18:20:34.521005
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        '''
a: int = 10
b: int
        '''.strip()) == {
            'code': '''a = 10\n''',
            'tree_changed': True
        }

# Generated at 2022-06-21 18:20:38.704256
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	x = 5
	y = 7

	a: int = 10
	b: int


# Generated at 2022-06-21 18:20:43.459772
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

    my_tree = astor.parse("""
    a: int = 10
    b: int
    """)
    modification_tree = VariablesAnnotationsTransformer.transform(my_tree)
    result = astor.to_source(modification_tree.tree)
    assert result == "a = 10"

# Generated at 2022-06-21 18:20:54.286110
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result1 = VariablesAnnotationsTransformer(
        'a: int = 10\nb: int\n').transform()
    result2 = VariablesAnnotationsTransformer(
        'for i in range(3):\n    a: int = 10\nb: int\n').transform()
    assert result1 == (
        'a = 10\n',
        True,
        [],
    )
    assert result2 == (
        'for i in range(3):\n    pass\na = 10\n',
        True,
        [
        'for i in range(3):\n    a = 10\nb = None\n'
        ],
    )
    print('test_VariablesAnnotationsTransformer ok')

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:21:01.790232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..types import TransformationResult
    from ..utils.helpers import compile_source, code_equal
    code_before = 'a: int = 10\nb: int\n'
    code_after = 'a = 10\n'
    transform_result: TransformationResult = VariablesAnnotationsTransformer.transform(compile_source(code_before, 'test', 'exec'))
    assert code_equal(transform_result.transformed_ast, compile_source(code_after, 'test', 'exec'))
test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:21:07.998998
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert_tree_equals(VariablesAnnotationsTransformer.transform('a: int = 10').tree,
                       ast.Module(body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                                  value=ast.Num(n=10),
                                                  type_comment=ast.Name(id='int', ctx=ast.Load()))]))

# Generated at 2022-06-21 18:21:17.853884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import pytest
    from astor.code_gen import to_source
    from astor.source_repr import SourceRepresentation
    from .examples import (VARIABLES_ANNOTATIONS_IN)

    tree = ast.parse(VARIABLES_ANNOTATIONS_IN)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.code == SourceRepresentation(tree)

    tree = ast.parse(VARIABLES_ANNOTATIONS_IN)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.code == SourceRepresentation(tree).replace(
        "a: int = 10", "a = 10"
    )

# Generated at 2022-06-21 18:21:30.239204
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
# Python program to find whether a number is Armstrong number or not.

# number of digits


num = int(input("Enter a number: "))

sum = 0
temp = num
while temp > 0:
   digit = temp % 10
   sum += digit ** 3
   temp //= 10

if num == sum:
   print(num,"is an Armstrong number")
else:
   print(num,"is not an Armstrong number")'''
    parser = ast.parse(code)
    assert VariablesAnnotationsTransformer.transform(parser)

# Generated at 2022-06-21 18:21:30.576462
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:21:34.365438
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import ast_to_str
    from typed_ast import ast3 as ast

    trans = VariablesAnnotationsTransformer()
    assert (ast_to_str(trans.transform(ast.parse('''
foo_bar: str = 'Foo'
baz: int = 10 
''')).tree) == ast_to_str(ast.parse('''
foo_bar = 'Foo'
baz = 10
'''))), 'Invalid conversion'



# Generated at 2022-06-21 18:21:36.337352
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer()
    assert class_.target == (3, 5)

# Generated at 2022-06-21 18:21:38.248231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer()
    assert v is not None

# Generated at 2022-06-21 18:21:46.368693
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    from ..utils.helpers import compare_asts
    code = '''a: int = 10
              b: int
'''
    tree = parse(code)
    print(dir(tree))
    print(dir(ast))
    print(dir(ast.Name))
    #tree = ast.parse(code)
    new = VariablesAnnotationsTransformer.transform(tree).tree
    assert_str = '''a = 10
'''
    a = compare_asts(new, assert_str)
    print(a)
    print('test_VariablesAnnotationsTransformer PASSED')

# Generated at 2022-06-21 18:21:47.751918
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert inspect.isclass(VariablesAnnotationsTransformer)


# Generated at 2022-06-21 18:21:48.938926
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer()
    assert not hasattr(class_, 'tree')
    assert class_.target == (3, 5)


# Generated at 2022-06-21 18:21:53.080278
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("x: int")
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree == ast.parse("")


tree = ast.parse("x: int = 1")
tree = VariablesAnnotationsTransformer.transform(tree)
assert tree == ast.parse("x = 1")

# Generated at 2022-06-21 18:21:58.826619
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    program = '''
    x: int = 10
    y: int
    '''
    testing_ast = ast.parse(program)
    # expected_ast = ast.parse(program)
    result = VariablesAnnotationsTransformer.transform(testing_ast)
    print(result)
    
test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:22:11.888473
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    src = '''
    a: int = 10
    b: int
    '''
    expected_result = '''
    a = 10
    '''
    tree = ast.parse(src)
    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.src == expected_result
    assert str(result.tree) == expected_result

# Generated at 2022-06-21 18:22:13.098760
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)

# Generated at 2022-06-21 18:22:16.107249
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = inspect.getsource(VariablesAnnotationsTransformer)
    tree = ast.parse(source)
    module = VariablesAnnotationsTransformer(source, tree)
    e = module.source_code[19]
    assert(e == '# Unit test for constructor of class VariablesAnnotationsTransformer')

# Generated at 2022-06-21 18:22:17.374116
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:22:28.528818
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Constant(value=10), type_comment='int')
    b = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()))
    x = ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()), value=ast.Constant(value=10),
                      annotation=ast.Name(id='int', ctx=ast.Load()))
    y = ast.AnnAssign(target=ast.Name(id='y', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()))

    tree

# Generated at 2022-06-21 18:22:32.144738
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    expected = ast.parse("""
a = 10
""")
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:22:44.633615
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    from ..utils.tree import find
    from ..utils.helpers import c
    from ..utils.helpers import equal_asts
    from .base import BaseTransformer
    from .variablesAnnotations import VariablesAnnotationsTransformer
    from ..types import TransformationResult

    tree = ast.parse(c("""
    a: int = 10
    b: int = 10 + (20 - 10)
    c: int = 10 + (20 - 10) + (40 - 20)
    d: int = 10 + (20 - 10) + (40 - 20) + (80 - 40)
    """))
    assert isinstance(tree, ast.Module)
    for node in find(tree, ast.AnnAssign):
        transformer = VariablesAnnotationsTransformer()
        class_name = transformer.__class__.__name__


# Generated at 2022-06-21 18:22:54.586188
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import assert_node_equal
    def check(s1, s2):
        tree = ast.parse(s1)
        tree1 = ast.parse(s2)
        t = ast.fix_missing_locations(VariablesAnnotationsTransformer.transform(tree).tree)
        assert_node_equal(t, tree1)
    s1 = """
a: int = 10
b: int
if a:
    b: str = "Hello"
else:
    c: int
    c = 15
    f: int
    f = c
    """
    s2 = """
a = 10
if a:
    b = "Hello"
else:
    c = 15
    f = c
    """
    check(s1, s2)


# Generated at 2022-06-21 18:22:59.005578
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    import textwrap
    from typed_ast.ast3 import AnnAssign, Call, Name, Str

    code = textwrap.dedent("""
    a: int = 10
    b: int
    """)

    tree = ast.parse(code)
    var = VariablesAnnotationsTransformer()
    assert var is not None

# Generated at 2022-06-21 18:23:10.611062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("\n\n====================\nStarting Test for VariablesAnnotationsTransformer\n")
    c = VariablesAnnotationsTransformer()
    tree = ast.parse("a: int = 10\nb: int")
    res = VariablesAnnotationsTransformer.transform(tree)
    # res[0].body[0].__class__.__name__  # should be Assign
    # res[0].body[0].targets[0].__class__.__name__  # should be Name
    # res[0].body[0].targets[0].id  # should be a
    # res[0].body[0].value.__class__.__name__  # should be Num
    # res[0].body[0].value.n  # should be 10
    # res[0].body[1] 

# Generated at 2022-06-21 18:23:39.505331
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test node of type AnnAssign
    node = ast.AnnAssign()
    node.target = ast.Name()
    node.value = ast.Num()
    node.annotation = ast.Str()

    # Test VariablesAnnotationsTransformer.transform
    result = VariablesAnnotationsTransformer.transform(node)
    assert result.tree_changed == True
    assert len(result.errors) == 0
    assert isinstance(result.tree, ast.Assign)
    assert isinstance(result.tree.targets[0], ast.Name)
    assert isinstance(result.tree.value, ast.Num)
    assert isinstance(result.tree.type_comment, ast.Str)

# Generated at 2022-06-21 18:23:41.801848
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    tree = ast.parse('a: int = 10\nb: int')
    node = tree.body[0]

    assert isinstance(node, ast.AnnAssign)
    assert transformer.target == (3, 5)

    # Annotated assignment is removed
    res = transformer.transform(tree)
    assert node not in res.tree.body

# Generated at 2022-06-21 18:23:46.157791
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = ast.parse('a: int = 10; b: int')
    # Show before transformation
    print(ast.dump(input))

    result = VariablesAnnotationsTransformer.transform(input)
    print(ast.dump(result.tree))
    # Show before transformation
    # print(ast.dump(result.tree))

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:23:49.807224
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open("tests/examples/golang/variables_annotations.go") as f:
        tree = ast.parse(f.read())
        transformer = VariablesAnnotationsTransformer()
        new_tree = transformer.transform(tree)
        assert new_tree.body[1].name == "_" and new_tree.body[2].value.endswith("10")

# Generated at 2022-06-21 18:23:52.750817
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse("""
a: int = 10
b: int
    """)

    # When
    result = VariablesAnnotationsTransformer.transform(tree)

    # Then
    assert_ast_equals_source(
        result.tree,
        """
a = 10
        """)



# Generated at 2022-06-21 18:24:02.087356
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    import sys
    import os.path
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))
    from typed_ast import ast3 as ast
    from utils import get_ast
    from checkers.base import BaseChecker
    from checkers.type_checker import TypeChecker
    import pytest
    import textwrap

    @BaseChecker.register
    class TestChecker(TypeChecker):
        pass

    test_tree = get_ast("""
        a: int = 10
        b: int
    """)
    expected_tree = get_ast("""
        a = 10
    """)

    # Act

# Generated at 2022-06-21 18:24:04.358129
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import last_transformations
    assert isinstance(VariablesAnnotationsTransformer, last_transformations) is True

# Generated at 2022-06-21 18:24:07.778595
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:24:12.104775
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Tests constructor of class VariablesAnnotationsTransformer
    """
    expected_target = (3, 5)
    actual_target = VariablesAnnotationsTransformer.target
    assert actual_target == expected_target, f"expected: {expected_target}, actual: {actual_target}"

# Generated at 2022-06-21 18:24:14.911624
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # assert 1 == 1
    a = 1
    assert a == 1
    a: int = 1
    assert a == 1


# Generated at 2022-06-21 18:25:00.166762
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: str = "hello"
    b: str = "world"
    """)
    tree_changed, new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert new_tree is not None

# Generated at 2022-06-21 18:25:02.308851
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	a = ast.parse('a: int = 10\nb:int')
	VariablesAnnotationsTransformer.transform(a)
	assert str(a) == 'a = 10'

# Generated at 2022-06-21 18:25:02.811603
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:25:05.178905
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast._ast3 as typed_ast
    ast_tree=typed_ast.parse('a:int = 10')
    result = VariablesAnnotationsTransformer.transform(ast_tree)
    print(result.tree)


# Generated at 2022-06-21 18:25:15.896733
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astunparse import unparse
    import typing
    import astor
    from .utils import compile_source
    from .base import BaseTransformer

    code = '''
x: str = 'a'
y: str
z: int
    '''
    tree = compile_source(code, "exec", mode="eval")
    result = VariablesAnnotationsTransformer.transform(tree)

    source = unparse(tree).strip()
    print(source)
    assert source=="x = 'a'\n"
    source = unparse(result.tree).strip()
    print(source)
    assert source == "x = 'a'\n"
    assert result.tree_changed == True
    assert BaseTransformer.check_equal(tree,result.tree)
    assert BaseTransformer.node_visited_count == 0

# Generated at 2022-06-21 18:25:17.452324
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:25:20.418029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    before = ast.parse("a: int = 10")
    after = ast.parse("a = 10")
    vat = VariablesAnnotationsTransformer()
    assert vat.transform(before).tree == after


# Generated at 2022-06-21 18:25:31.329993
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #Transforms:
            # a: int = 10
            # b: int
    #To:
            # a = 10
    #and
            # a = 5
    #To:
            # a = 5

    i = ast.parse(
        textwrap.dedent('''\
        a: int = 10

        b: int
        ''')
    )

    o = ast.parse(
        textwrap.dedent('''\
        a = 10

        ''')
    )

    i2 = ast.parse(
        textwrap.dedent('''\
        a = 5
        ''')
    )

    o2 = ast.parse(
        textwrap.dedent('''\
        a = 5
        ''')
    )

    assert VariablesAnnotationsTransformer.transform

# Generated at 2022-06-21 18:25:33.876123
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_variable = VariablesAnnotationsTransformer()
    assert type(class_variable) == VariablesAnnotationsTransformer
    assert isinstance(class_variable, BaseTransformer)


# Generated at 2022-06-21 18:25:36.662527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("Testing VariablesAnnotationsTransformer constructor")
    assert VariablesAnnotationsTransformer.target == (3, 5)
    print("Passed VariablesAnnotationsTransformer constructor test")


# Generated at 2022-06-21 18:27:27.988948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    src = """
a: int = 10
b: int
    """
    expected_result = """
a = 10
    """
    mod = ast.parse(src)
    new_mod = VariablesAnnotationsTransformer.transform(mod)
    assert ast.dump(new_mod.tree, False) == expected_result

# Generated at 2022-06-21 18:27:36.168858
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    for ver in VariablesAnnotationsTransformer.target:
        tree = ast.parse(
            textwrap.dedent('''\
            a: int = 10
            b: int
            '''),
            'file.py',
            f'exec',
            version=ver,
        )

        VariablesAnnotationsTransformer.validate(tree)
        result = VariablesAnnotationsTransformer.transform(tree)
        assert result.tree_changed is True
        assert result.warnings == []
        assert ast.dump(tree) == ast.dump(result.tree)

# Generated at 2022-06-21 18:27:39.179918
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Constructor for class VariablesAnnotationsTransformer
    VariablesAnnotationsTransformer()
    # Done testing constructor for class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:27:42.857398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("def a():\n    b: int")
    VariablesAnnotationsTransformer.transform(tree)
    tree = ast.parse("def a():\n    b: int = 10")
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-21 18:27:47.351774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    block = ast.Assign(targets=[ast.AnnAssign(target=ast.Name("a", ast.Load()),
                                              annotation=ast.Name("int", ast.Load()),
                                              value=ast.Num(10),
                                              simple=1)])
    # Test VariablesAnnotationsTransformer.transform function
    assert VariablesAnnotationsTransformer.transform(block)

# Generated at 2022-06-21 18:27:52.077643
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a:int')
    tree_out = ast.parse("a")
    assert VariablesAnnotationsTransformer.transform(tree) == (tree_out, True, [])
    b = ast.parse("b:int")
    print(b)



# Generated at 2022-06-21 18:27:59.655834
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('testing VariablesAnnotationsTransformer')
    from cst.ast_transforms import BaseTransformer

    from cst.utils.text_utils import recast_code
    from cst.utils.helpers import get_code
    from cst.matchers import FunctionMatcher, AssignTarget, Name
    from cst.matchers import Assign, Name

    # add the ability to run unit tests for this class
    # similar to the way that cst compiles cst
    ast1 = recast_code('''
        a: int = 0
        b: int = 1
        c: float = 0.0
        d: int = 2
    ''')
    a = next(ast1.body[0].targets)
    b = next(ast1.body[1].targets)
    c = next

# Generated at 2022-06-21 18:28:05.090737
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    from ..utils.source import Source
    from .. import settings
    from ..exceptions import InvalidArgumentError

    wrong_node = ast.Constant(value=1)

    # check if an exception will be raised for wrong node
    with pytest.raises(InvalidArgumentError):
        VariablesAnnotationsTransformer.transform(wrong_node)

    # check if the code will be transformed
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')).tree ==\
        ast.parse('a = 10')

    # check if settings accept_typing is True
    settings.accept_typing = True
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')).tree ==\
        ast.parse('a: int = 10')

# Generated at 2022-06-21 18:28:06.877722
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)
    # assert VariablesAnnotationsTransformer.transform(ast.parse("from abc import ABC")) == TransformationResult(None, None, [])

# Generated at 2022-06-21 18:28:07.780469
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    unittest.main()