

# Generated at 2022-06-21 18:19:13.589485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    import sys

    variable_annotation_before = '''
    abc: int
    xyz: int = 1
    '''

    variable_annotation_after = '''
    abc = __type__
    xyz = 1
    '''
    tree_before = ast.parse(variable_annotation_before)
    tree_after = ast.parse(variable_annotation_after)
    transformer = VariablesAnnotationsTransformer()
    tree_transformed = transformer.transform(tree_before)[0]
    assert astunparse.unparse(tree_transformed) == astunparse.unparse(tree_after)

# Generated at 2022-06-21 18:19:21.618619
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from ..utils.helpers import build_ast
    source = inspect.cleandoc('''
    a: int = 10
    b: str = "string"
    ''')
    exp = inspect.cleandoc('''
    a = 10
    b = "string"
    ''')
    tree = build_ast(source, 3, 5)
    VariablesAnnotationsTransformer.transform(tree).prune()
    assert dump(tree) == exp

# Generated at 2022-06-21 18:19:23.471069
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    obj = VariablesAnnotationsTransformer()
    assert obj.target == (3, 5)



# Generated at 2022-06-21 18:19:27.399414
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.is_applicable(
        (3, 5),
    ) is True
    assert VariablesAnnotationsTransformer.is_applicable(
        (3, 4),
    ) is False


# Generated at 2022-06-21 18:19:30.494001
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer."""

    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-21 18:19:36.230141
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    code = "a: int = 10"
    tree = ast.parse(code)
    x = VariablesAnnotationsTransformer.transform(tree)
    assert x.tree_changed == True
    assert x.tree == ast.parse("a = 10")

# Generated at 2022-06-21 18:19:38.438022
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform("a: int \n b: int") == [
        "a\n b"
    ]

# Generated at 2022-06-21 18:19:40.383111
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # unit test for constructor of class VariablesAnnotationsTransformer
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)

# Generated at 2022-06-21 18:19:44.904543
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        ast.parse('a: int = 10', '<test>', mode='exec')
    except SyntaxError:
        assert False, "No SyntaxError was expected"
    else:
        assert True


# Generated at 2022-06-21 18:19:55.846744
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1: no transformation
    tree = ast.parse('a: int = 3')
    result, changed = VariablesAnnotationsTransformer.transform(tree)
    assert changed == False
    assert ast.dump(result) == ast.dump(tree)
    # Test case 2: transformation
    tree = ast.parse('a: int = 3')
    result, changed = VariablesAnnotationsTransformer.transform(tree)
    assert changed == True
    assert ast.dump(result) == ast.dump('a = 3')
    # Test case 3: no transformation
    tree = ast.parse('b: int')
    result, changed = VariablesAnnotationsTransformer.transform(tree)
    assert changed == False
    assert ast.dump(result) == ast.dump(tree)
    # Test case 4: transformation
    tree = ast.parse

# Generated at 2022-06-21 18:20:11.116970
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    node_1 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), simple=1)
    node_2 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='string', ctx=ast.Load()), value=ast.Constant(value="hello", kind=None), simple=0)
    ast_node = ast.Module(body=[node_1, node_2])
    tree = VariablesAnnotationsTransformer.transform(ast_node)
    print(astor.to_source(tree))
    '''

# Generated at 2022-06-21 18:20:21.463919
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import annotate_variables_in_ast

    code = '''
    a: str = "Hello"
    b: str = "World"
    c: int
    c = 10
    '''
    tree = ast.parse(code)
    tree = annotate_variables_in_ast(tree)
    tree = VariablesAnnotationsTransformer.transform(tree)

    code_out = ""
    code_out += "a = 'Hello'" + '\n'
    code_out += "b = 'World'" + '\n'
    code_out += "c = 10" + '\n'

    assert ast.dump(tree) == code_out

# Generated at 2022-06-21 18:20:32.833942
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from . import untest
    untest.assert_correct_transformation(
        VariablesAnnotationsTransformer,
        ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=ast.Num(n=10),
            simple=1),
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Num(n=10),
            type_comment=ast.Name(id='int', ctx=ast.Load()))
    )


# Generated at 2022-06-21 18:20:36.012487
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:43.065212
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # assert VariablesAnnotationsTransformer.transform('') == '', 'should return empty string'
    # assert VariablesAnnotationsTransformer.transform('  a = b = 10') == '  a = 10', 'should remove extra assignment'
    # assert VariablesAnnotationsTransformer.transform('  a = 10\nb = 10') == '  a = 10\nb = 10', 'should only remove extra assignment when target is different'
    pass


if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:20:43.665422
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:20:53.775608
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''a: int = 10
    b: int''')
    tree_changed, tree, messages = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert messages == []
    assert ast.dump(tree) == "Assign(targets=[Name(id='a', ctx=Store())], \
    value=Constant(value=10, kind=None), type_comment=Name(id='int', ctx=Load()))"
    assert ast.dump(tree.body[1]) == "Assign(targets=[Name(id='b', ctx=Store())], \
    value=None, type_comment=Name(id='int', ctx=Load()))"

# Generated at 2022-06-21 18:21:03.611571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    type_explicit = ast.parse("""a: int = 10\nb: int""").body  # type: ignore
    type_implicit = ast.parse("""a = 10\nb""").body  # type: ignore
    # Get type of the targeted node
    assert isinstance(type_explicit[0], ast.AnnAssign)
    assert isinstance(type_explicit[1], ast.AnnAssign)
    assert isinstance(type_implicit[0], ast.Assign)
    assert isinstance(type_implicit[1], ast.Assign)
    assert VariablesAnnotationsTransformer.transform(type_explicit) == (type_implicit, True, [])

# Generated at 2022-06-21 18:21:12.724521
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    # Intialization
    src = "a: int = 10\n" \
        "b: int\n"
    tree = astor.parse_file(StringIO(src))
    transformer = VariablesAnnotationsTransformer()

    # Actual result
    actual_result = transformer.transform(tree)

    # Expected result
    exp_src = "a = 10\n" \
        "b\n"
    exp_tree = astor.parse_file(StringIO(exp_src))
    expected_result = TransformationResult(exp_tree, True, [])

    assert actual_result.tree == expected_result.tree
    assert actual_result.tree_changed == expected_result.tree_changed

# Generated at 2022-06-21 18:21:20.699501
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_1 = ast.Module(body=[
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation = ast.Constant(value=10), value=None),
        ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation = ast.Constant(value=10), value=None)
        ])
    print(ast.dump(tree_1))
    tree_2 = VariablesAnnotationsTransformer.transform(tree_1)
    print(ast.dump(tree_2.tree))

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:21:32.630778
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  '''Unit test for constructor of class VariablesAnnotationsTransformer'''
  class VariablesAnnotationsTransformerTester(VariablesAnnotationsTransformer):
    '''Tester for VariablesAnnotationsTransformer'''
    def __init__(self):
      self.target = (1, 1)
  vartrans = VariablesAnnotationsTransformerTester()
  return True

print('Testing constructor of class VariablesAnnotationsTransformer...', \
      end = '')
assert test_VariablesAnnotationsTransformer()
print('Done.')


# Generated at 2022-06-21 18:21:33.232863
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-21 18:21:35.926623
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing variables annotations class
    VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int"))

# Generated at 2022-06-21 18:21:43.886354
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.source_repr import pretty_source
    from ..utils.testing import get_test_cases

    # Read test cases from file
    cases = get_test_cases(globals(), can_print=True)

    for c in cases:
        # skip this case
        if c.id == "1": continue
        # Transform tree
        result, changed = VariablesAnnotationsTransformer.transform(c.tree)
        #print(pretty_source(result))
        # Compare results
        assert pretty_source(result) == c.expected

# Generated at 2022-06-21 18:21:54.597033
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(target=ast.Name('a', ast.Store()),
                                                annotation=ast.Name('int',ast.Load()),
                                                value=ast.Constant(10, value=10),
                                                simple=1)
    b = ast.AnnAssign(target=ast.Name('b', ast.Store()),
                                                annotation=ast.Name('int', ast.Load()),
                                                value=None,
                                                simple=1)
    test_tree = ast.Module(body=[a, b])
    result = VariablesAnnotationsTransformer.transform(test_tree)

# Generated at 2022-06-21 18:21:57.432031
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    program_tree = ast.parse("""a: int = 10\nb: int""")
    _, is_changed, _ = VariablesAnnotationsTransformer.transform(program_tree)
    assert is_changed == True

# Generated at 2022-06-21 18:22:00.137613
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create a new VariablesAnnotationsTransformer Object
    obj1 = VariablesAnnotationsTransformer()

    # Test the output of the constructor
    assert obj1


# Generated at 2022-06-21 18:22:01.208994
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print(VariablesAnnotationsTransformer.__name__)

# Generated at 2022-06-21 18:22:07.432835
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_helpers import tree_from

    # Case: a: int = 10, b: int
    tree = tree_from("""
        def f():
            a: int = 10
            b: int
    """)
    VariablesAnnotationsTransformer.transform(tree) == tree_from("""
        def f():
            a = 10
    """)


# Generated at 2022-06-21 18:22:15.965514
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import ast
    import re
    from ..utils.helpers import convert_to_ast, dump_code


# Generated at 2022-06-21 18:22:27.806453
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)
    x = None
    tree = x
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree) is None


# Generated at 2022-06-21 18:22:40.629936
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    import typed_astunparse
    text_to_compile = '''
text: str = "hello"
n: int
'''
    compare_with = '''
text = "hello"
'''
    # compile the code into an AST
    root_node = typed_astunparse.ast3.parse(text_to_compile)
    # apply the transformation
    new_root_node = VariablesAnnotationsTransformer().visit(root_node)
    # print out the result of the transformation
    print(astor.to_source(new_root_node))
    # text is the resulting code after the transformation has been applied
    text = astor.to_source(new_root_node)
    # check to make sure the transformation applied correctly
    assert text == compare_with
    # print if the

# Generated at 2022-06-21 18:22:43.991841
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
        def a(b: int = 10, c: str = 20) -> None:
            d: int = 10
            e = 20
            f: int

    ''')
    tree, _, _ = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-21 18:22:51.722555
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    class T(VariablesAnnotationsTransformer):
        pass

    a = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),value=ast.Num(n=10),simple=1)
    b = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), simple=1)

    inp = ast.Module(body=[a, b])

# Generated at 2022-06-21 18:22:58.401562
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_astunparse as astunparse
    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)
    expected_code = """
    a = 10
    """
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.removed_imports == []
    assert astunparse.unparse(result.tree) == expected_code
    # return


# Generated at 2022-06-21 18:23:09.931012
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create a small tree
    nodeA = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int',ctx=ast.Load()), value=ast.Num(10))
    nodeB = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int',ctx=ast.Load()), value=None)

    # Create the module
    tree = ast.Module(body=[nodeA, nodeB])

    # Change the tree
    res = VariablesAnnotationsTransformer.transform(tree)
    res_tree = res[0]

    # Check
    expanded_body = res_tree.body
    assert len(expanded_body) == 2

# Generated at 2022-06-21 18:23:15.719081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    import astor
    test_tree = astor.parse_file('./tests/files/typed_variables.py')

    # Act
    result = VariablesAnnotationsTransformer.transform(test_tree)

    # Assert
    assert(result.changed)

    import inspect
    assert(inspect.getsource(VariablesAnnotationsTransformer.transform) == inspect.getsource(test_VariablesAnnotationsTransformer))


# Generated at 2022-06-21 18:23:20.690065
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_transform, get_test_data

    src = get_test_data('expr/expr_variables_annotation_3.5.py')
    expected = get_test_data('expr/expr_variables_annotation_3.txt')

    assert_transform(VariablesAnnotationsTransformer, src, expected)

# Generated at 2022-06-21 18:23:29.795408
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()

    tree: ast.Module = ast.parse('a: int = 10\nb: int')
    tree_changed, _ = transformer.transform(tree)

    # Note that the type comment is omitted to avoid having to parse it
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10)), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None)])"

    # transform returns the tuple (tree, tree_changed, module_deps)
    assert tree_changed is True

# Generated at 2022-06-21 18:23:36.542461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.tree.body[0].value.n == 10
    tree = ast.parse('a: int\nb:int\n')
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.tree.body[0].annotation
    assert new_tree.tree.body[1].annotation

# Generated at 2022-06-21 18:23:58.886941
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(dedent('''
            a: int = 10
            b: int
    '''))
    tree_changed, _, _ = VariablesAnnotationsTransformer.transform(tree)
    assert(tree_changed)


# Generated at 2022-06-21 18:24:00.965151
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    assert "int" not in str(VariablesAnnotationsTransformer.transform(tree))


# Generated at 2022-06-21 18:24:06.945779
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .transform import Transform
    from ..types import TARGET_TO_VERSION_MAP

    for version in TARGET_TO_VERSION_MAP[3]:
        res = Transform(version).transform_source(
            'a: int = 10\n'
            'b: int'
        , None, False, False)
        print(res)
        assert res == 'a = 10\nb: int\n'

# Generated at 2022-06-21 18:24:11.083308
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # given
    code = "a: int = 10\nb: int"
    expected_output = "a = 10"
    transformations_result = VariablesAnnotationsTransformer().transform(code)
    # when
    result = transformations_result.visitor.output
    # then
    assert result == expected_output

# Generated at 2022-06-21 18:24:16.663038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    code = """
    a: int = 10
    b: int = 30
    """
    expected = """
    a = 10
    b = 30
    """
    
    tree = ast.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert(astunparse.unparse(result.tree) == expected)

# Generated at 2022-06-21 18:24:20.013816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)
    assert VariablesAnnotationsTransformer.target == (3,5)


# Generated at 2022-06-21 18:24:29.618622
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    VariablesAnnotationsTransformer(
        target = (3, 5)
        transform = {
            1. Get the AST tree
            2. Search the AST tree for a class AnnAssign
            3. For the first node
                3.1. Get the position and parent of the node
                3.2. Delete the node
                3.3. If the value is not None 
                    3.3.1 Add an assignment at the index
                    3.3.2. The target is the old targets
                    3.3.3. The value is the old value
                    3.3.4. The type_comment is the old annotation
            4. Return the result
        }
    )
    """
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-21 18:24:30.960012
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:24:35.010389
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int
    c: int = 20
    d: str = "string"
    e: int = c + 1
    f: int = d.split()

# Generated at 2022-06-21 18:24:40.370049
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    In this test we test that there is no AnnAssign node in the transformed ast
    '''
    ast1= ast.parse("a: int = 10\nb: int")
    result = VariablesAnnotationsTransformer.transform(ast1)
    for node in result.transformed_tree.body:
        if isinstance(node, ast.AnnAssign):
            raise Exception('There should be no AnnAssign node')
        else:
            continue

# Generated at 2022-06-21 18:25:24.522132
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_input = "a:int = 12"

    test_output = "a = 12"

    assert VariablesAnnotationsTransformer.transform(test_input) == (test_output)

# Generated at 2022-06-21 18:25:34.796386
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    a: int = 1
    if True:
        b: int = 2
        c: int
    ''')
    v = VariablesAnnotationsTransformer()
    v.transform(tree)

    print(ast.dump(tree))

# Generated at 2022-06-21 18:25:40.671390
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
from typing import NamedTuple

Point = NamedTuple('Point', [('x', int), ('y', int)])
    '''
    module_name = 'dummy'

    tree = ast.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert eval(compile(result.tree, filename=module_name, mode="exec")) == Point   # type: ignore

# Generated at 2022-06-21 18:25:47.245919
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation_result
    from typed_ast import ast3 as ast

    code = "def foo(a: int = 10, b: int = 10, c: int = 10):\n    c: int = 10"
    tree = ast.parse(code)

    expected_code = "def foo(a = 10, b = 10, c = 10):\n    c = 10\n"
    expected_tree = ast.parse(expected_code)

    assert_transformation_result(VariablesAnnotationsTransformer, tree, expected_tree, expected_code)

# Generated at 2022-06-21 18:25:53.133937
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.target == (3, 5), \
        'VariablesAnnotationsTransformer.target should be (3, 5).'
    assert class_.transform is not None, \
        'VariablesAnnotationsTransformer.transform should not be None.'
    from_python_version, to_python_version = class_.target
    assert from_python_version <= sys.version_info.major <= \
           to_python_version, \
        'Python version does not match the target version of the transformer.'

# Generated at 2022-06-21 18:26:00.032497
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test converting a variable with type annotation to
       variable without type annotation.

       a: int = 10
       b: int
    """
    test_node = ast.AnnAssign(target=ast.Name("a", ast.Store()),
                                 annotation=ast.Name("int", ast.Load()),
                                 value=ast.Num(10))
    new_node = VariablesAnnotationsTransformer.transform(test_node)
    assert isinstance(new_node, ast.Assign)
    assert new_node.targets == [ast.Name("a", ast.Store())]
    assert isinstance(new_node.annotation, ast.Name)
    assert new_node.value == ast.Num(10)

# Generated at 2022-06-21 18:26:01.372210
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:26:08.327508
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Initialization of mock tree
    tree = ast.parse("""a: int = 10
    b: int
    c: int = my_func()""")

    tree_after_transformation = ast.parse("""a = 10
    c = my_func()""")

    # Initialization of class VariablesAnnotationsTransformer
    transformer = VariablesAnnotationsTransformer()

    # Test of method transform
    assert transformer.transform(tree) == (ast.dump(tree_after_transformation), True, [])



# Generated at 2022-06-21 18:26:09.687138
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    example = "a: int = 10"
    expected_output = "a = 10"
    actual_output = VariablesAnnotationsTransformer.transform(example)
    assert(actual_output.name == expected_output)

# Generated at 2022-06-21 18:26:13.867083
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Basic case of removing a variable with annotation
    tree1 = ast.parse('a: int = 10')
    assert VariablesAnnotationsTransformer.transform(tree1).tree == \
        ast.parse('a = 10')

    # Basic case of removing a variable with no value and annotation
    tree2 = ast.parse('a: int')
    assert VariablesAnnotationsTransformer.transform(tree2).tree == \
        ast.parse('')

    # Assignment outside of body of function
    tree3 = ast.parse('a: int = 10\ndef foo():\n    pass')
    assert VariablesAnnotationsTransformer.transform(tree3).tree == \
        ast.parse('a = 10\ndef foo():\n    pass')

# Generated at 2022-06-21 18:27:55.186692
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10; b: int;')  # type: ignore
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Assign)

# Generated at 2022-06-21 18:28:00.493048
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse("""
l1: List[int]
l1 = []
a: int
a = 10
b = a
a = 100
b = a""")
    VariablesAnnotationsTransformer.transform(test_tree)
    result = astor.to_source(test_tree)
    print(result)
    assert result == """
l1 = []
a = 10
b = a
a = 100
b = a"""

# Generated at 2022-06-21 18:28:05.116756
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module_node = ast.parse("""a: int = 10""")
    trans = VariablesAnnotationsTransformer()
    new_module_node, changed, message = trans.transform(module_node)
    assert changed
    assert "a = 10" in ast.dump(new_module_node)
    print(ast.dump(new_module_node))


# Generated at 2022-06-21 18:28:06.444966
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert VariablesAnnotationsTransformer.transform("a:int=10\nb:int") == 'a=10'

# Generated at 2022-06-21 18:28:08.335919
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    instance = VariablesAnnotationsTransformer("tree")
    assert isinstance(instance, VariablesAnnotationsTransformer)


# Generated at 2022-06-21 18:28:14.969932
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # given
    tree = ast.parse('a: int = 10')
    # when
    result = VariablesAnnotationsTransformer.transform(tree)
    # then
    assert ast.dump(result.tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=10), type_comment=Name(id="int", ctx=Load()))])'

# Generated at 2022-06-21 18:28:18.268675
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.__class__.__name__ == "VariablesAnnotationsTransformer"
    assert t.target == (3, 5)


# Generated at 2022-06-21 18:28:24.347116
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for transforming variables annotations for Python version 3.5
    def test_variables_annotations_3_5():
        # Transform the code
        code = "a: int = 10 \nb: int"
        tree = ast.parse(code)
        new_code = VariablesAnnotationsTransformer.transform(tree)

        # Check the results
        assert new_code.tree_changed == True
        assert new_code.result == "a = 10 \n"
    test_variables_annotations_3_5()

# Generated at 2022-06-21 18:28:30.928334
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Store()), value=ast.Num(n=10), simple=1)
    b = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Store()), value=None, simple=0)
    r = ast.Assign(targets=[a.target], value=a.value, type_comment=a.annotation)
    assert r == VariablesAnnotationsTransformer.transform(a).update
    assert None == VariablesAnnotationsTransformer.transform(b).update

# Generated at 2022-06-21 18:28:36.712161
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10\nb: int = 15\n""")
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert(type(new_tree.tree)) == ast.Module
    assert(type(new_tree.tree.body[0])) == ast.Assign
    assert(type(new_tree.tree.body[1].value)) == ast.Constant
    assert(new_tree.tree.body[1].value.value == 10)
    assert(new_tree.tree.body[1].value.kind == None)
    assert(type(new_tree.tree.body[2])) == ast.Assign
    assert(type(new_tree.tree.body[2].value)) == ast.Constant