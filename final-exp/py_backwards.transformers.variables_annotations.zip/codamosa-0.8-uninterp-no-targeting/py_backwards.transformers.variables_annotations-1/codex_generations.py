

# Generated at 2022-06-21 18:19:09.997692
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import ast
    import typed_ast.ast3 as typed_ast
    from typed_ast import ast3 as ast
    from python_to_python.transformers.variables_annotations import VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:13.750563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb:int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert not result.tree_changed
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed



# Generated at 2022-06-21 18:19:21.772217
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = ast.Variable(name='a')
    int_type = ast.Name(id='int')
    ten = ast.Integer(10)
    ten_value = ast.Assign(targets=[v],
                           value=ten)
    int_annotation = ast.AnnAssign(target=v,
                                   annotation=int_type)
    annassign_to_value = VariablesAnnotationsTransformer.transform(int_annotation)
    assert annassign_to_value == TransformationResult(ten_value, True, [])

# Generated at 2022-06-21 18:19:26.466122
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = '''
        a: int = 10
        b: int
    '''

    expected_code = '''
        a = 10
    '''

    tree = ast.parse(input_code)
    VariablesAnnotationsTransformer.transform(tree)

    assert astor.to_source(tree).strip() == expected_code

# Generated at 2022-06-21 18:19:27.889333
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:34.656567
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = """
    a: int = 10
    b = 10
    """
    expected = """
    a = 10
    b = 10
    """
    assert VariablesAnnotationsTransformer.transform(input) == expected

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:19:40.829882
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import node_from_str
    from ..utils.tree import convert_to_json

    node = node_from_str('from typing import List\n'
                         'a: List[int] = list(range(5))')
    expected = node_from_str('from typing import List\n'
                             'a = list(range(5))')
    result, _ = VariablesAnnotationsTransformer.transform(node)

    assert convert_to_json(expected) == convert_to_json(result)

# Generated at 2022-06-21 18:19:44.145078
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    with pytest.raises(Exception):
        VariablesAnnotationsTransformer()
    '''
    assert VariablesAnnotationsTransformer(None)


# Generated at 2022-06-21 18:19:49.915039
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    code_after_transformation = ast.dump(VariablesAnnotationsTransformer.transform(tree).tree)
    # check if function works
    assert code_after_transformation == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))])"

# Generated at 2022-06-21 18:19:57.298419
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    from ..utils.helpers import compare_asts

    code = """\
    def f(a : int = 10, b : str = 'abc'):
        b = 'abc'
        c : int
    """

    ast1 = astunparse.unparse(ast.parse(code))
    res = VariablesAnnotationsTransformer.transform(ast.parse(code))
    ast2 = astunparse.unparse(res.tree)

    compare_asts(code, ast1, ast2)

# Generated at 2022-06-21 18:20:04.670909
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class1 = VariablesAnnotationsTransformer()
    res = class1.transform(build_ast('a: int = 10\nb: int\n'))
    assert(res.tree_changed == True)
    assert(res.tree.body[1].__class__ == ast.Assign)


# Generated at 2022-06-21 18:20:06.735975
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()

    assert(transformer.target == (3, 5))


# Generated at 2022-06-21 18:20:09.168772
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Testing the constructor of class VariablesAnnotationsTransformer
    """
    VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:20:16.226968
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Tests VariablesAnnotationsTransformer class"""
    # def fn1(a: int):
    #     a: int = 10
    tree = ast.parse('''
    def fn1(a: int):
        a: int = 10
    ''')

    assert tree.body[0].type_comment == 'int'
    assert tree.body[0].body[0].target.annotation == ast.parse('int').body[0].value
    assert tree.body[0].body[0].annotation == ast.parse('int').body[0].value

    assert tree.body[0].body[0].value == ast.Num(10)


# Generated at 2022-06-21 18:20:17.665327
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor


# Generated at 2022-06-21 18:20:19.786207
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a : int = 10
    b : int
    # result:
    # a = 10
    # b
    # which should be same as original code

# Generated at 2022-06-21 18:20:24.780803
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse, to_source
    from ..exceptions import NodeNotFound

    tree = parse('a: int = 10; b: int;')
    VariablesAnnotationsTransformer.transform(tree)
    assert to_source(tree) == 'a = 10;\n'

# Generated at 2022-06-21 18:20:28.817776
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import parse

    code = '''
    a: str
    b: bool = "abc"
    '''
    tree = parse(code)

    tree2 = VariablesAnnotationsTransformer.run_pipeline(tree)

    assert len(tree2.body) == 2

# Generated at 2022-06-21 18:20:39.428445
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import load_python_module_from_string, print_python_code
    from ..tree_transformations import transform_tree

    source = """
    import typing

    a: int = 10
    b: str = "abc"
    """

    module = load_python_module_from_string(source, 'test')
    print_python_code(module)

    assert len(module.body) == 3

    transform_tree(module, VariablesAnnotationsTransformer())

    assert len(module.body) == 2
    print_python_code(module)

    assert module.body[0].value.value == 10
    assert module.body[1].value.s == "abc"

# Generated at 2022-06-21 18:20:40.904435
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:49.470721
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    tree = ast.parse('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    code = astor.to_source(tree)
    assert code == 'a = 10'
    if __name__ == "__main__":
        print(code)

# Generated at 2022-06-21 18:20:59.903537
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class DummyNoChangesTransformer(BaseTransformer):

        def transform(self, node):
            return node

    class DummyTransformer(BaseTransformer):

        def transform(self, node):
            return ('TEST_VALUE', True, ['TEST_CHANGE'])

    with pytest.raises(ValueError):
        VariablesAnnotationsTransformer([])

    # [DummyTransformer]
    instance = VariablesAnnotationsTransformer([DummyTransformer()])
    assert instance.transformers == [DummyTransformer()]
    assert instance.transformers[0].__class__.__name__ == 'DummyTransformer'

    # [DummyTransformer, DummyNoChangesTransformer]
    instance = VariablesAnnotationsTransformer([DummyTransformer(),
                                                DummyNoChangesTransformer()])
   

# Generated at 2022-06-21 18:21:06.773333
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class C:
        a: int = 10
        b: int
        i: int = 0
        j: int

        def __init__(self, x: int, y: int):
            self.i = x
            self.j = y

    source = inspect.getsource(C)
    m = ast.parse(source)
    result = VariablesAnnotationsTransformer.transform(m)
    assert result.tree_changed
    assert not result.warnings

# Generated at 2022-06-21 18:21:16.231450
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create a Variable Annotation
    a: int = 10
    b: int
    # Create a Expected Assign Statement
    test_expected_assign = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],value=ast.Num(n=10), type_comment=ast.Subscript(value=ast.Name(id='int', ctx=ast.Load()),slice=ast.Index(value=ast.Num(n=1)), ctx=ast.Load()))

    result = VariablesAnnotationsTransformer.transform(b)
    # Check that result equals to test_expected_assign
    assert result.tree == test_expected_assign

# Generated at 2022-06-21 18:21:17.105894
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:21:18.704894
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)


# Generated at 2022-06-21 18:21:23.360896
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .sample_asts import sample_ast_variables_annotations as test
    test_VariablesAnnotationsTransformer.test_ast = test
    test_VariablesAnnotationsTransformer.VariablesAnnotationsTransformer = VariablesAnnotationsTransformer
    # The sample AST is valid python 3.5 code, so before applying the transformation, we parse it
    # in order to obtain an AST object
    tree = ast.parse(test)  # type: ignore
    # We then apply the transformation
    trans = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-21 18:21:31.654881
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10
    b: int
    """)
    v = VariablesAnnotationsTransformer()
    result, changed = v.transform(tree)
    assert changed
    assert(ast.dump(result)=="Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Expr(value=Name(id='b', ctx=Load(), annotation=Name(id='int', ctx=Load())))])")

# Generated at 2022-06-21 18:21:43.267533
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from astor.source_repr import Source
    transformer = VariablesAnnotationsTransformer()
    # Test ClassDef node

# Generated at 2022-06-21 18:21:45.409406
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_transformer = VariablesAnnotationsTransformer()
    assert issubclass(test_transformer.__class__, BaseTransformer)


# Generated at 2022-06-21 18:22:04.807028
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    test_ast = ast.Module(
        body=[
            ast.AnnAssign(
                target=ast.Name(id='a', ctx=ast.Store()),
                annotation=ast.Name(id='int', ctx=ast.Load()),
                value=ast.Num(n=10),
                simple=1),
            ast.AnnAssign(
                target=ast.Name(id='b', ctx=ast.Store()),
                annotation=ast.Name(id='int', ctx=ast.Load()),
                value=None,
                simple=0)
        ])

# Generated at 2022-06-21 18:22:14.736149
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import transform_and_test
    from ..utils.test_utils import get_errors
    from ..utils.test_utils import get_test_file_content
    import astor

    # test case 1
    test_file = 'VariableAnnotationTransformer.py'
    content = get_test_file_content(test_file)
    content = transform_and_test(VariablesAnnotationsTransformer,
                                 test_file,
                                 content)
    errors = get_errors(VariablesAnnotationsTransformer, astor.code_to_ast.parse_file(test_file))
    assert len(errors) == 0, 'There should be no errors'
    assert content is not None, 'Content should not be None'
    assert content != '', 'Content should not be empty'

    # test case 2

# Generated at 2022-06-21 18:22:20.349964
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
a: int = 10
b: int
"""
    c = ast.parse(code)
    transformed, _, _ = VariablesAnnotationsTransformer.transform(c)
    modified_code = """
a = 10
"""
    assert(ast.dump(transformed) == ast.dump(ast.parse(modified_code)))

# Generated at 2022-06-21 18:22:24.035531
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''a:int = 1\nb:int''')
    expected = ast.parse('''a = 1\nb = None''')
    actual = VariablesAnnotationsTransformer.transform(tree)
    assert actual == expected

# Generated at 2022-06-21 18:22:25.052324
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:22:33.001013
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test program
    test_code = \
"""
a: int = 10
b: int
"""

    # Transform program and get new tree
    tree = ast.parse(test_code)
    tree = VariablesAnnotationsTransformer.transform(tree)

    # Get new code
    with open('/home/matt.bai/Desktop/test_py.py', 'w') as f:
        f.write(astunparse.unparse(tree.tree))

    # Print new code
    print(astunparse.unparse(tree.tree))

test_VariablesAnnotationsTransformer()


# Generated at 2022-06-21 18:22:41.457992
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code_from = """
    x: int
    x = 10
    y: int = 10
    """

    code_to = """
    x = 10
    y = 10
    """

    tree_from = ast.parse(code_from)
    tree_to = ast.parse(code_to)

    result, modified = VariablesAnnotationsTransformer.transform(tree_from)

    assert modified
    assert ast.dump(tree_to) == ast.dump(result)

# Generated at 2022-06-21 18:22:50.822112
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("Testing VariablesAnnotationsTransformer class...")
    try:
        s = 'from typing import List\n' \
            'from random import randint\n' \
            'a: int = randint(5,5)\n' \
            'b: List[int] = [4,4]\n' \
            'c = randint(2,2)\n' \
            'd = [2, 2]\n'
        tree = ast.parse(s)
        print("Original AST:")
        print(astor.to_source(tree))
        out = VariablesAnnotationsTransformer.transform(tree)
        print("New AST:")
        print(astor.to_source(out))
        print("")
    except Exception as err:
        print("Exception:")
        print(err)


# Generated at 2022-06-21 18:22:56.825525
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    # a: int = 10
    # b: int
    # will be the tree to be tested
    target = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()), annotation=ast.Name(id="int", ctx=ast.Load()), simple=1, value=ast.Num(n=10))
    # a = 10
    # will be the expected output
    expected = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))
    assert VariablesAnnotationsTransformer.transform(target).transformed_tree == expected
    
    # Test 2
    # c: int
    # will be

# Generated at 2022-06-21 18:23:07.212132
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_name = 'VariablesAnnotationsTransformer'
    input_code = '''
                 a: str = 'q'
                 b: str
                 '''
    expected_code = '''
                    a = 'q'
                    '''

    from ..transpile import transpile
    from ..types import TreeResult

    result: TreeResult = transpile(input_code)
    assert result.errors == [], \
        f'{class_name} found errors when there should\'t be any.'
    assert result.code == expected_code, \
        f'{class_name} didn\'t handle the code as expected.\n' \
        f'Input Code: {input_code}\n' \
        f'Expected Code: {expected_code},\n' \
        f'Result: {result.code}'

# Generated at 2022-06-21 18:23:28.261445
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.transform("a: int = 10\nb: int") == "a = 10"

# Generated at 2022-06-21 18:23:34.096694
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('''

a: int = 10
b: int
c: int = 20
d: int = 40

''')
    r = VariablesAnnotationsTransformer.transform(test_tree)
    assert isinstance(r.tree, ast.Module)
    assert len(r.tree.body) == 2
    assert isinstance(r.tree.body[0], ast.Assign)


# Generated at 2022-06-21 18:23:36.592594
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.constructor is VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:23:39.415665
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:23:48.266638
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import variable_annotations
    tree = ast.parse("a: int = 10\n"
                     "b: str\n"
                     "c: str = '10'")
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.tree.body[0].body[0].value.n == 10
    assert new_tree.tree.body[0].body[1].value.s == '10'
    assert new_tree.tree.body[0].body[1].targets[0].id == 'c'
    assert isinstance(new_tree.tree.body[0].body[1], ast.Assign)
    assert new_tree.tree.body[0].body[1].type_comment is None
    assert new_tree.tree.body[0].body[2]

# Generated at 2022-06-21 18:23:49.282104
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(1) == 1

# Generated at 2022-06-21 18:23:51.146193
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)
# test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:23:55.270960
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed and result.tree.body[0].value.n == 10

# Generated at 2022-06-21 18:23:56.635785
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.id == 'variables_annotations'

# Generated at 2022-06-21 18:24:00.667938
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse(
    '''
    from typing import List, Dict, Tuple, Any
    a: int = 10
    b: int
    ''')

    cls = VariablesAnnotationsTransformer()
    cls.transform(test_tree)
    print(test_tree)



# Generated at 2022-06-21 18:24:43.961563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class B(ast.AST):
        _fields = ('target', 'op', 'value', 'type', 'type_comment')

    assert VariablesAnnotationsTransformer.transform(B(target=a,value=10,type=None,type_comment=int)) == B(target=a,value=10,type=None,type_comment=int)

# Generated at 2022-06-21 18:24:45.801677
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:24:56.625184
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), 
                                    annotation=ast.Name(id='int', ctx=ast.Load()), 
                                    value=ast.Num(n=10), simple=1)
    node_target = ast.Name(id='a')
    node_value = ast.Num(n=10)
    node_annotation = ast.Name(id='int')
    assert VariablesAnnotationsTransformer.transform(ast_node).result[0].targets[0] == node_target
    assert VariablesAnnotationsTransformer.transform(ast_node).result[0].value == node_value
    assert VariablesAnnotationsTransformer.transform(ast_node).result[0].type_comment == node_annotation

# Generated at 2022-06-21 18:25:00.506071
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Test the constructor of class VariablesAnnotationsTransformer
    '''
    #Test the init method
    x = VariablesAnnotationsTransformer()
    assert(x.target == (3, 5))
    assert(x.name == "VariablesAnnotationsTransformer")


# Generated at 2022-06-21 18:25:01.957516
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse('a: int = 10')
    assert VariablesAnnotationsTransformer.transform(x)

# Generated at 2022-06-21 18:25:03.116896
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import transform
    import typed_astunparse


# Generated at 2022-06-21 18:25:13.468056
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(target=ast.Name("name", ast.Store), annotation=None, value=None, simple=1)
    b = ast.AnnAssign(target=ast.Name("name", ast.Store), annotation=None, value=None, simple=0)
    c = ast.AnnAssign(target=ast.Name("name", ast.Store), annotation=None, value=None, simple=0)
    d = ast.AnnAssign(target=ast.Name("name", ast.Store), annotation=None, value=None, simple=0)
    e = ast.AnnAssign(target=ast.Name("name", ast.Store), annotation=None, value=None, simple=0)

# Generated at 2022-06-21 18:25:20.556725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import convert
    from ..utils.tree import stringify

    code = '''
    a: int = 10
    b: int
    '''

    tree = convert(code, to_version=(3, 5))
    tree = VariablesAnnotationsTransformer.transform(tree)

    expected_code = '''
    a = 10
    '''

    expected_tree = convert(expected_code, to_version=(3, 5))
    assert stringify(tree.tree) == stringify(expected_tree)

# Generated at 2022-06-21 18:25:31.473717
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class ASTExampleTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
            c: str = 'abc'
            d: str = 'abc'
            e: str = 'abc'
            f: str = 'abc'
            g: str = 'abc'
        To:
            a = 10
            b = None
            c = 'abc'
            d = 'abc'
            e = 'abc'
            f = 'abc'
            g = 'abc'
        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-21 18:25:33.398776
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer."""
    assert VariablesAnnotationsTransformer.__doc__ is not None



# Generated at 2022-06-21 18:27:20.327201
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:27:24.784546
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typing import cast
    from typed_ast import ast3
    from ..utils.helpers import get_type
    from ..utils.tree import find

    # creates a new AST object and returns it
    tree = ast.parse('a: int = 10')

    assert get_type(find(tree, ast.AnnAssign)[0]) == ast3.AnnAssign

    assert VariablesAnnotationsTransformer.transform(tree).tree_changed
    assert get_type(find(tree, ast.Assign)[0]) == ast3.Assign
    assert get_type(find(tree, ast.AnnAssign)[0]) == TypeError

# Generated at 2022-06-21 18:27:30.486219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup
    tree = ast.parse("a : int = 10\nb : int")
    cls_object = VariablesAnnotationsTransformer()

    # Exercise
    result = cls_object.transform(tree)

    # Verify
    assert(isinstance(result, TransformationResult))
    assert(len(result.tree.body) == 2)
    assert(isinstance(result.tree.body[0], ast.Assign))
    assert(isinstance(result.tree.body[1], ast.AnnAssign))


# Generated at 2022-06-21 18:27:33.018175
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.codegen import to_source
    from ..transformer import apply_transforms


# Generated at 2022-06-21 18:27:38.159264
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse(
        'x: str\nb: str = "hello"'
    )
    result = VariablesAnnotationsTransformer.transform(node)
    assert result.tree.body[0].value.s == 'hello'
    assert result.tree.body[0].targets[0].id == 'b'

# Generated at 2022-06-21 18:27:46.589079
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import sys

    if sys.version_info < (3, 5):
        print('importing typed_ast.ast3 as ast')
        import typed_ast.ast3 as ast
    else:
        print('importing ast')
        import ast
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=ast.Num(n=10))
    print(ast.dump(node))
    x = VariablesAnnotationsTransformer(node)
    print(x.target)
    x.transform()
    print(x.transformed)

# Generated at 2022-06-21 18:27:56.528432
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    #Test case 1 : Assignment outside of body
    tree = ast.parse("a : int = 10\nb : int")
    tr = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(tr.tree) == "a = 10\nb"

    #Test case 2 : 
    tree = ast.parse("a: int = 10\nb: int\nif a>5 : \n\tb=5")
    tr = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(tr.tree) == "a = 10\nb\nif a > 5:\n    b = 5"
    
    #Test case 3 : 

# Generated at 2022-06-21 18:28:05.759228
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import print_ast, parse_to_ast
    from typing import Union
    from ast import AST
    from ..utils.helpers import print_debug
    from ..exceptions import NodeNotFound
    from ..utils.tree import find
    from ..types import TransformationResult

    class VariablesAnnotationsTransformer:
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)  # type: ignore

# Generated at 2022-06-21 18:28:08.794250
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    import ast

    tree = parse('a: int = 10\nb: int')
    tree2 = parse('a = 10')
    x = VariablesAnnotationsTransformer(tree)
    assert ast.dump(x.tree, annotate_fields=False, include_attributes=True) == ast.dump(tree2, annotate_fields=False, include_attributes=True)


# Generated at 2022-06-21 18:28:10.655447
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    varAnn = VariablesAnnotationsTransformer()
    assert varAnn != None
