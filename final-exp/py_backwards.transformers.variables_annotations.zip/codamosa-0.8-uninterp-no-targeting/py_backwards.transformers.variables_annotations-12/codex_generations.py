

# Generated at 2022-06-21 18:19:06.359041
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:19:13.190938
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    get_tree = ast.parse("""
        a: int = 10
        b: int = 10
        """, filename='<string>', mode='eval')
    test_tree = ast.parse("""
        a = 10
        b = 10
        """, filename='<string>', mode='eval')

    assert VariablesAnnotationsTransformer.transform(get_tree) == test_tree

# Generated at 2022-06-21 18:19:23.005077
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    
    def compile_source(source: str) -> ast.AST:
        source = source.strip()
        return parse(source)
    
    globals = [
        'a: int = 20',
        'b: int'
    ]
    
    source = '[%s]\n' % ',\n '.join(globals)

    globals = compile_source(source)

    assert isinstance(globals, ast.List)
    
    VariablesAnnotationsTransformer.transform(globals)

    for node in globals.elts:
        assert not isinstance(node, ast.AnnAssign)

# Generated at 2022-06-21 18:19:28.066433
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    target = ast.parse("""
    a: Union[str, int] = 10
    b: str
    """).body
    expected = ast.parse("""
    a = 10
    """).body

    # Act
    nodes = VariablesAnnotationsTransformer.transform(target)
    actual = nodes.new_nodes

    # Assert
    assert actual == expected

# Generated at 2022-06-21 18:19:40.232806
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.python_source_code_line_to_ast_node import PythonSourceCodeLineToAstNode
    from ..utils.tree import show_structure
    from ..utils.helpers import chk_eq


    test_code = '''
x: int = 10
y: int
    '''
    expected_code = '''
x = 10
    '''
    ast_root = PythonSourceCodeLineToAstNode(test_code).get_ast()
    expected_ast = PythonSourceCodeLineToAstNode(expected_code).get_ast()
    # print(show_structure(ast_root))

    res = VariablesAnnotationsTransformer.transform(ast_root)
    output_ast = res.output
    # print(show_structure(output_ast))


# Generated at 2022-06-21 18:19:46.305459
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer(): 
    #
    # The following code should be compiled to:
    # a = 10
    #
    test_code = """
a: int = 10
    """
    tree = ast.parse(test_code)
    assert str(tree) == test_code
    tree = VariablesAnnotationsTransformer.transform(tree).tree
  
    assert str(tree) == "a = 10"

# Generated at 2022-06-21 18:19:48.655169
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse


# Generated at 2022-06-21 18:20:00.190543
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''a: int = 10
    b: int = 20
    c: List[int] = [1, 2, 3]
    d: None = None
    e: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-21 18:20:05.026986
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("""
    if True:
        a: int = 10
        b: int
    """, mode='exec')) == TransformationResult(
        ast.parse("""
        if True:
            a = 10
        """, mode='exec'), True, [])

# Generated at 2022-06-21 18:20:07.074641
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5)


# Generated at 2022-06-21 18:20:12.331875
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    assert VariablesAnnotationsTransformer.transform(tree) == \
            (ast.parse('a = 10'), True, [])

# Generated at 2022-06-21 18:20:13.209317
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:16.109803
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """a: int = 10
              b = 15
              c: int
              """

    module_node = ast.parse(code)
    new_module_node = VariablesAnnotationsTransformer.transform(module_node)

    assert isinstance(new_module_node, TransformationResult)


# Generated at 2022-06-21 18:20:26.742247
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..utils.helpers import create_module

    def test_transformer(annotations):
        mod = create_module(ast3.parse(annotations))
        mod = VariablesAnnotationsTransformer.run_pipeline(mod)
        exec(compile(mod, filename="<ast>", mode="exec"), {})

    test_transformer("""
    a: int = 10
    b: int
    c: int = 10
    """)
    test_transformer("""
    a = 10
    b: int
    c = 10
    """)
    test_transformer("""
    a = 10
    b: int
    c = 10
    d: int
    """)

# Generated at 2022-06-21 18:20:30.478369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = 'a: int = 10\nb: int\n'
    tr = VariablesAnnotationsTransformer()
    result = tr.transform(code)
    assert result.result == 'a = 10\n'

# Generated at 2022-06-21 18:20:31.613660
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:20:42.677016
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # create a class
    class_name = ast.Name(id='test_class', ctx=ast.Load())
    class_bases = []
    class_body = [
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(10))
    ]
    class_decorator_list = []
    class_s = ast.ClassDef(name='test_class', bases=class_bases, keywords=[], body=class_body, decorator_list=class_decorator_list)

    tree = ast.Module(body=[class_s])

    tree_changed = VariablesAnnotationsTransformer.transform(tree)

    # print(ast.dump(tree))
   

# Generated at 2022-06-21 18:20:45.360585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_anno = VariablesAnnotationsTransformer()
    assert (var_anno.target == (3, 5))

# Generated at 2022-06-21 18:20:47.252550
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert isinstance(t, VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:20:48.403145
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformed_code = VariablesAnnotationsTransformer.transform([3])
    assert transformed_code == b"""'3'\n"""


# Generated at 2022-06-21 18:21:04.284143
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at

    # Test 1: Compile following code
    """
        def func():
            a: int
            b: int
            c: int
            a = 2 + 3
            b = a + 10
    """

    # To:

    """
        def func():
            a = 2 + 3
            b = a + 10
    """
    module = ast.parse('def func():\n    a: int\n    b: int\n    a = 2 + 3\n    b = a + 10')
    cls = VariablesAnnotationsTransformer()
    etalon = ast.parse('def func():\n    a = 2 + 3\n    b = a + 10')
    res

# Generated at 2022-06-21 18:21:08.241118
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = 'a: int = 10'
    tr = VariablesAnnotationsTransformer()
    tree = ast.parse(source)
    result = tr.transform(tree)
    assert result.tree_changed == True
    output = astor.to_source(result.tree).strip()
    assert output == 'a = 10'

# Generated at 2022-06-21 18:21:16.716340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    sample_code = '''
    num1: int = 1
    num2: int = 2
    num3 = 1 + 2
    '''
    expected_code = '''
    num1 = 1
    num2 = 2
    num3 = 1 + 2
    '''
    tree = ast.parse(sample_code)
    expected_tree = ast.parse(expected_code)
    VariablesAnnotationsTransformer().transform(tree)
    assert astor.to_source(tree) == astor.to_source(expected_tree)

# Generated at 2022-06-21 18:21:23.748786
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_string_1 = """
        a: int = 10
        b: int
    """
    expected_output_1 = """
        a = 10

    """

    input_tree = ast.parse(input_string_1)
    transformed_tree = VariablesAnnotationsTransformer.transform(input_tree)

    assert ast.dump(transformed_tree.tree) == ast.dump(ast.parse(expected_output_1))

    input_string_2 = """
        a: int = foo()
        b: int
    """
    expected_output_2 = """
        a = foo()

    """

    input_tree = ast.parse(input_string_2)
    transformed_tree = VariablesAnnotationsTransformer.transform(input_tree)


# Generated at 2022-06-21 18:21:26.448320
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    print(variablesAnnotationsTransformer)
    assert variablesAnnotationsTransformer


# Generated at 2022-06-21 18:21:37.018589
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import source_to_ast
    from ..variables_annotations import VariablesAnnotationsTransformer
    # test case 1
    src = """
    a: int = 10
    b = 1 #type: int
    """
    expected = """
    a = 10
    b = 1 
    """
    tree = source_to_ast(src)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))
    # test case 2
    src = """
    from dataclasses import dataclass, field
    @dataclass
    class A:
        a: int = 1
        b: str = 'hello'
    """

# Generated at 2022-06-21 18:21:44.707469
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    from ..utils.tree import dump_ast
    from ..transformations.variablesannotations import VariablesAnnotationsTransformer

    code = """
    x: int = 10
    y: str = 'some'
    """

    tree = ast.parse(code)
    res, tree_changed, errors = VariablesAnnotationsTransformer.transform(tree)

    assert code.strip() == dump_ast(res).strip()
    assert tree_changed
    assert not errors


# Generated at 2022-06-21 18:21:48.819026
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == \
           ast.parse("a = 10")
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: float = 20")) == \
           ast.parse("a = 10\nb = 20")

# Generated at 2022-06-21 18:21:53.340166
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_string = 'a: int = 10'
    desired_output = 'a = 10'
    input_ast = ast.parse(input_string)
    output_ast = VariablesAnnotationsTransformer().transform(input_ast)[0]
    assert ast.dump(output_ast) == ast.dump(ast.parse(desired_output))


# Generated at 2022-06-21 18:21:55.076038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer



# Generated at 2022-06-21 18:22:11.266099
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    assert isinstance(tree.body[0], ast.AnnAssign)
    tree_t = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(tree_t.tree, ast.Module)
    assert len(tree_t.tree.body) == 2
    assert isinstance(tree_t.tree.body[0], ast.Assign)
    assert isinstance(tree_t.tree.body[1], ast.Pass)

# Generated at 2022-06-21 18:22:14.128630
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10
                        b: int = 20""")
    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(
        ast.parse("""a = 10
                     b = 20"""), True, [])

# Generated at 2022-06-21 18:22:23.972476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  class Node:
    pass
  node = Node()
  node.target = 1
  node.value = 1
  node.annotation = 1
  class Node_1:
    pass
  node_1 = Node_1()
  node_1.body = [node]
  node_1.type_ignores = []
  node_1.prec = 1
  class Node_2:
    pass
  node_2 = Node_2()
  node_2.tree = node_1
  node_2.tree_changed = True
  node_2.type_ignores = []
  assert VariablesAnnotationsTransformer.transform(node_1) == node_2

# Generated at 2022-06-21 18:22:25.721981
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert type(transformer) == VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:22:30.406699
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import astpretty

    # turns:
    #   a: int = 10
    # into:
    #   a = 10
    source = '''a: int = 10'''
    tree = ast.parse(source)
    astpretty.pprint(tree)
    VariablesAnnotationsTransformer.transform(tree)
    print(inspect.getsource(tree))

# Generated at 2022-06-21 18:22:32.295635
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'


# Generated at 2022-06-21 18:22:39.232375
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(ast.parse('a = 10'), tree_changed=True, extra_imports=[]), 'Class VariablesAnnotationsTransformer should return the correct output'


# Generated at 2022-06-21 18:22:47.147184
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse("a: int = 10")
    test_transformer = VariablesAnnotationsTransformer()
    test_transformer.tree = test_tree
    test_transformationResult = test_transformer.transform()
    assert(test_transformationResult.was_changed() == True)
    assert(test_transformationResult.get_transformed_ast())
    assert(test_transformationResult.get_result_tree().body[0].value == 10)
    assert(test_transformationResult.get_result_tree().body[0].type_comment == 'int')
    assert(test_transformationResult.get_result_tree().body[0].targets[0].id == 'a')

# Generated at 2022-06-21 18:22:57.807601
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    actualCode = ast.Module(body=[
            ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                          annotation=ast.Name(id='int', ctx=ast.Load()),
                          value=ast.Num(n=10),
                          simple=1),
            ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                          annotation=ast.Name(id='int', ctx=ast.Load()),
                          simple=1)
        ])
    # a = 10
    # b

# Generated at 2022-06-21 18:22:59.691917
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int
    b: float = 10
    c: dict = 10 # type: dict
    d: str = "10"
    return a,b,c,d

# Generated at 2022-06-21 18:23:27.877078
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_parser import parse
    from ..utils.helpers import assert_equal
    from ..utils.ast_helpers import to_source
    from .base import BaseTransformer

    to_parse = '''
    a: int
    a = 10
    '''
    tree = parse(to_parse)
    result = VariablesAnnotationsTransformer.transform(tree)

    expected_tree = parse('''
    a = 10
    ''')
    assert_equal(result.tree, expected_tree)
    assert_equal(result.tree_changed, True)
    assert_equal(result.errors, [])

# Generated at 2022-06-21 18:23:35.879378
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_node_name

    tree = ast.parse('''
    class TestClass:
        def __init__(self, a: int = 20):
             self.a = a
        def func(self, b: int):
            a = b
        def func2(self, c: int, d: int = 40):
            a = c + d
        def __repr__(self):
            return (f'{self.a}')
    ''')

    x = VariablesAnnotationsTransformer()
    x.transform(tree)
    assert get_node_name(tree) == 'Module'

# Generated at 2022-06-21 18:23:37.544507
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from reprocess import processor
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from ..utils.helpers import str2ast, str2code
    from ..utils.source_helpers import ast2source


# Generated at 2022-06-21 18:23:43.989816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from .annotation_transformer import AnnotationTransformer

    tree = ast.parse('a: int = 10\nb: str = \'Hello!\'')
    AnnotationTransformer.transform(tree)
    print_tree(tree)
    print('----------------')
    VariablesAnnotationsTransformer.transform(tree)
    print_tree(tree)

# Generated at 2022-06-21 18:23:48.868934
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    ast1 = ast.AnnAssign(target = ast.Name(id = 'a', ctx = ast.Store()),
                         annotation = ast.Name(id ='int', ctx = ast.Load()),
                         value = ast.Num(n = 1),
                        )
    ast2 = ast.Assign(targets = [ast.Name(id = 'a', ctx = ast.Store())],
                   value = ast.Num(n = 1),
                   type_comment = None)
    assert VariablesAnnotationsTransformer.transform(ast1).new_tree == ast2

# Generated at 2022-06-21 18:23:53.902711
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name(id="a",ctx=ast.Store()),
                                 value=ast.Num(n=10),
                                 annotation=ast.Name(id="int",ctx=ast.Load()))
    assert VariablesAnnotationsTransformer.transform(node) == TransformationResult(ast.Assign(targets=[ast.Name(id="a",ctx=ast.Store())],
                                                                            value=ast.Num(n=10),
                                                                            type_comment=ast.Name(id="int",ctx=ast.Load())),
                                                                         True, [])

# Generated at 2022-06-21 18:23:58.059843
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = ast.parse("""
a: int = 10
b: int
""")
    tree = VariablesAnnotationsTransformer.transform(input).tree
    assert ast.dump(tree) == ast.dump(ast.parse("""
a = 10
b = None
""", mode='eval'))

# Generated at 2022-06-21 18:24:00.187059
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int"))
    #assert result.has_changed is True


# Generated at 2022-06-21 18:24:01.957918
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """ Unit test for VariablesAnnotationsTransformer.
    """

    from astor.source_repr import to_source


# Generated at 2022-06-21 18:24:04.296773
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = VariablesAnnotationsTransformer()
    assert(var.target == (3, 5))

# Generated at 2022-06-21 18:24:44.374773
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-21 18:24:48.676170
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class MyVariablesAnnotationsTransformer(VariablesAnnotationsTransformer):
        """Initializes class inherited from VariablesAnnotationsTransformer"""
    result = MyVariablesAnnotationsTransformer()
    assert result.target == (3, 5), "target is not (3, 5)"

# Generated at 2022-06-21 18:24:55.312353
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    import astunparse as unparser
    
    code = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(code)
    t = VariablesAnnotationsTransformer()
    result = t.transform(tree)
    print(unparser.unparse(result.value))

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-21 18:25:01.190340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_test_case_as_ast, transform_and_compare_ast
    from ..utils.helpers import random_string
    from . import VariablesAnnotationsTransformer

    tree = get_test_case_as_ast('test_VariablesAnnotationsTransformer')
    transformer = VariablesAnnotationsTransformer

    tree, changed = transformer.transform(tree)
    transform_and_compare_ast(tree, 'test_VariablesAnnotationsTransformer_after_transform')

# Generated at 2022-06-21 18:25:02.457727
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .transformer_config import get_transformer
    t = get_transformer(VariablesAnnotationsTransformer)

# Generated at 2022-06-21 18:25:04.440199
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    def create_tree():
        return ast.parse("""
        a: int = 10
        b: int
        """)
    VariablesAnnotationsTransformer.transform(create_tree())

# Generated at 2022-06-21 18:25:06.169647
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test = VariablesAnnotationsTransformer()
    assert test.target == (3, 5)



# Generated at 2022-06-21 18:25:12.475287
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
variable_a: int = 10
variable_b: int
    """
    expected = """
variable_a = 10
    """
    tree = ast.parse(source)
    tree = VariablesAnnotationsTransformer.transform(tree)
    tree = ast.fix_missing_locations(tree)
    output = compile(tree, filename="<ast>", mode="exec")
    assert output == expected

# Generated at 2022-06-21 18:25:13.383637
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:25:23.638078
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_helpers import *

    from .annotations_import_fixer import AnnotationsImportFixer
    from .annotations_pyi_import_fixer import AnnotationsPyiImportFixer
    from ..structures import Tree

    import inspect
    tt = inspect.currentframe().f_code.co_filename

    # Test case 1
    tree = Tree.parse(tt[0], '''
    a: int = 10
    b: int
    ''')
    result = AnnotationsImportFixer.transform(tree)
    result = AnnotationsPyiImportFixer.transform(tree)
    result = VariablesAnnotationsTransformer.transform(result)
    assert_equal_structure(result.tree, """
    a = 10
    """)

    # Test case 2

# Generated at 2022-06-21 18:27:14.780521
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..grammar import n
    from ..utils import parse
    a = n.annotation_stmt
    assignment_a = a(target=n.name(id="a"), annotation=n.name(id="int"), value=n.number(value="10"))
    assignment_b = a(target=n.name(id="b"), annotation=n.name(id="int"))
    program = n.program(body=[assignment_a, assignment_b])
    result = VariablesAnnotationsTransformer.transform(parse(program))
    assert len(result.tree.body) == 2
    assert isinstance(result.tree.body[0], ast.Assign)
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[0].value.value == '10'

# Generated at 2022-06-21 18:27:19.119334
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Example(ast.AST):
        _fields = ()

    class Example2(ast.AST):
        _fields = ()

    # set up tree
    tree = Example2()
    tree.body = []
    subtree = Example()
    tree.body.append(subtree)
    sub_subtree = ast.Assign()
    sub_subtree.targets = [ast.Name(id='a')]
    sub_subtree.value = ast.NameConstant(value=False)
    sub_subtree.type_comment = '# type: int'
    subtree.body = [sub_subtree]

    # set up transformer
    transformer = VariablesAnnotationsTransformer()

    # check that passing the class gives no error
    t = transformer.transform(tree)

    # check that the change happened

# Generated at 2022-06-21 18:27:20.325089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)


# Generated at 2022-06-21 18:27:30.052904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from itertools import combinations
    from ..utils.tree import get_tree, get_node_at
    from ..utils.helpers import make_tree_node
    from .identity import IdentityTransformer

    tree = get_tree('test', IdentityTransformer)
    node = get_node_at(tree, 4)


# Generated at 2022-06-21 18:27:34.303327
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.target == (3, 5)
    assert class_.transform.__module__ == "typed_astunparse._compat26_27.transformers.annotations"
    assert class_.transform.__name__ == "transform"



# Generated at 2022-06-21 18:27:36.750512
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing the constructor of the class
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)


# Generated at 2022-06-21 18:27:43.803573
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = '''
    import typing
    a: int = 10
    b: int = 20
    c: int
    d = "str"
    '''

    # When
    res = VariablesAnnotationsTransformer.transform_code(code)

    # Then
    assert 'a = 10' in res
    assert 'b = 20' in res
    assert 'c' in res
    assert 'd = "str"' in res



# Generated at 2022-06-21 18:27:51.406335
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse('''
        a: int = 10
        b: int
        def fun(c: int) -> int:
            return c
    ''')

    expected = ast.parse('''
        a = 10
        def fun(c: int) -> int:
            return c
    ''')

    # When
    tr = VariablesAnnotationsTransformer.transform(tree)

    # Then
    assert tr.tree != tree
    assert tr.tree == expected
    assert tr.tree_changed == True
    assert tr.refactors == []

# Generated at 2022-06-21 18:27:53.802534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3,5)

# Unit tests for transform method of class VariablesAnnotationsTransformer

# Generated at 2022-06-21 18:27:59.206732
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """

    Arrange
    >>> import typed_ast.ast3 as ast
    >>> import astor
    >>> import astor.code_gen
    >>> tree = ast.parse('''z: int = 10''')
    >>> print(astor.to_source(tree))
    z: int = 10

    Act
    >>> variant = VariablesAnnotationsTransformer()
    >>> result = variant.transform(tree)

    Assert
    >>> tree = result.tree
    >>> print(astor.to_source(tree))
    z = 10
    """
    pass