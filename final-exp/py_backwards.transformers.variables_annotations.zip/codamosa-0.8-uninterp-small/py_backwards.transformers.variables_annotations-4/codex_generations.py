

# Generated at 2022-06-25 22:52:49.149970
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer(target= (3, 5)) 


# Generated at 2022-06-25 22:52:52.477118
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    string_input = '''a: int'''
    string_output = '''a '''
    tree_input = ast.parse(string_input)
    tree_output = ast.parse(string_output)
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    result = variables_annotations_transformer.transform(tree_input)
    assert result == tree_output

# Generated at 2022-06-25 22:52:54.032066
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    variables_annotations_transformer_0.transform("file.py", "my_py_file.py")

# Generated at 2022-06-25 22:53:00.282913
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(variables_annotations_transformer_0, VariablesAnnotationsTransformer), \
        "Failed to create an instance of VariablesAnnotationsTransformer"

    assert isinstance(variables_annotations_transformer_0.target, tuple), \
        "Failed to set target of VariablesAnnotationsTransformer"

    assert variables_annotations_transformer_0.target == (3,5), \
        "Failed to set target of VariablesAnnotationsTransformer"


# Generated at 2022-06-25 22:53:01.148394
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:53:03.545382
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()



# Generated at 2022-06-25 22:53:05.892655
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(0)


# Generated at 2022-06-25 22:53:06.609830
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 22:53:07.622862
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:09.415762
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:53:18.537230
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ....codegen.targets.python_ast import PythonAstCodeGenerator
    import ast
    tree = ast.parse('a: int = 10\nb: int')
    original_tree = tree
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.tree is not original_tree
    assert len(result.tree.body) == 2
    assert isinstance(result.tree.body[0], ast.Assign)
    assert result.tree.body[0].lineno == 1
    assert len(result.tree.body[1].body) == 0

# Unit tests for method transform() of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:53:25.455487
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    test_code = """
        a: int = 10
        b: int
    """
    expected_code = """
        a = 10
    """
    tree = ast.parse(test_code)
    result = transformer.transform(tree)
    codeobj = compile(result.tree, '', 'exec')
    exec(codeobj)
    assert result.tree._fields == ('body', 'type_ignores')
    assert result.tree.body[0]._fields == ('target', 'value', 'type_comment')
    assert result.tree_changed is True
    assert result.warnings == []
    assert codeobj == compile(expected_code, '', 'exec')

# Generated at 2022-06-25 22:53:33.266705
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    "Testing constructor of class VariablesAnnotationsTransformer in file variables_annotations_transformer.py"
    node = ast.AnnAssign(target=ast.Name("a", None), annotation=ast.parse("int", "<string>", "eval").body[0].value, value=ast.Num(10))
    expected_result = ast.Assign(targets=[ast.Name("a", None)], value=ast.Num(10), type_comment=ast.parse("int", "<string>", "eval").body[0].value)
    result = VariablesAnnotationsTransformer.transform(node)
    assert expected_result == result.tree


# Generated at 2022-06-25 22:53:36.045581
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_annotations_transformer = VariablesAnnotationsTransformer()
    assert var_annotations_transformer.target == (3, 5)

# Generated at 2022-06-25 22:53:42.515158
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test with an Assign node in the body of an FunctionDef
    node = ast.FunctionDef(
        name='a',
        args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
        body=[ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store(), annotation=ast.parse('int').body[0])),
              ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store(), annotation=ast.parse('int').body[0]))],
        decorator_list=[],
        returns=None,
        type_comment=None
    )

# Generated at 2022-06-25 22:53:43.310247
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:52.975617
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    import inspect
    import textwrap

    # Class under test
    class_under_test = VariablesAnnotationsTransformer

    ###########################################################################
    # type_comment tests
    ###########################################################################
    def test_type_comment():
        # Mocked tree
        mocked_tree = ast.parse(textwrap.dedent(
        '''
        from typing import List, Dict, Union
        a: int = 10
        b: Union[int, str] = "yes"
        c = 20
        d: List[Dict[int, str]]

        def do_something(arg: int) -> str:
            return "test"
        '''))

        # Expected result

# Generated at 2022-06-25 22:53:54.153741
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_to_ast


# Generated at 2022-06-25 22:53:55.842212
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer();
    assert transformer.tuple_version == (3, 5)

# Generated at 2022-06-25 22:54:01.162857
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .class_transformer import ClassTransformer
    from .dunder_methods_transformer import DunderMethodsTransformer
    from .with_statement_transformer import WithStatementTransformer
    from .decorator_transformer import DecoratorTransformer
    from .variable_annotations_transformer import VariablesAnnotationsTransformer


# Generated at 2022-06-25 22:54:10.309825
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .helpers import assert_transformation

    # target = (3, 5)
    tree = ast.parse("a: int = 10")
    new_tree = ast.parse("a = 10")
    VariablesAnnotationsTransformer_test = VariablesAnnotationsTransformer()
    assert_transformation(VariablesAnnotationsTransformer_test, tree, new_tree, 3, 5)


# Generated at 2022-06-25 22:54:11.975826
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:12.899877
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:20.218344
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.get_transformed_code('a: int = 10\nb: int') == 'a = 10\n'
    assert VariablesAnnotationsTransformer.get_transformed_code('a: int\nb: int') == 'a\nb\n'
    assert VariablesAnnotationsTransformer.get_transformed_code('a: int = "abcd"\nb: int') == 'a = "abcd"\nb\n'
    assert VariablesAnnotationsTransformer.get_transformed_code('a: int = 10\nb: int = 5') == 'a = 10\nb = 5\n'

# Generated at 2022-06-25 22:54:22.067006
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTransformer
    
    BaseTransformer.__init_subclass__.assert_called_once()



# Generated at 2022-06-25 22:54:25.937302
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    from ..utils.helpers import get_tree_str
    source = """
        x: int = 10
        x: int
    """
    expected = """
        x = 10
    """
    tree = parse(source)
    result = VariablesAnnotationsTransformer().transform(tree)
    assert get_tree_str(result.tree) == expected

# Generated at 2022-06-25 22:54:28.980723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    converter = VariablesAnnotationsTransformer()
    result = converter.transform(tree)
    result[0] == "a = 10"

# Generated at 2022-06-25 22:54:32.452246
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import print_tree

    text = """
    def foo():
        x: int = 10
        return x
        """
    tree = ast.parse(text)
    print_tree(tree)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    print_tree(tree)

# Generated at 2022-06-25 22:54:37.675046
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_python
    
    code = """
a: int = 10
b: int
"""
    tree = parse_python(code)
    tree = VariablesAnnotationsTransformer().transform(tree).tree
    code = astor.to_source(tree)
    # a = 10
    # b: int
    print(code)

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:54:43.361068
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.fake import FakeTree, FakeParent, FakeTarget

    parent = FakeParent()
    node = ast.AnnAssign(target = FakeTarget(), annotation=FakeTarget())
    node_2 = ast.Assign(targets=[FakeTarget()], value=FakeTarget(), type_comment=FakeTarget())
    VariablesAnnotationsTransformer.transform(FakeTree(parent, node, node_2))
    assert parent.body.pop(0) == node_2
    assert parent.body.pop(0) == node_2

# Generated at 2022-06-25 22:55:00.854789
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    from .. import transform
    from .split_variables_declarations import test_SplitVariablesDeclarationsTransformer
    from .split_variables_declarations import SplitVariablesDeclarationsTransformer
    from .remove_annotation import test_RemoveAnnotationTransformer
    from .remove_annotation import RemoveAnnotationTransformer

    #test class constructor
    assert VariablesAnnotationsTransformer.target == (3,5)

    #test transform method
    test_code = 'def foo(a:int) -> list: a:int = 10 return a'
    expected_code = 'def foo(a): a = 10 return a'

    test_ast = ast.parse(test_code)
    expected_ast = ast.parse(expected_code)

    #test transform method

# Generated at 2022-06-25 22:55:08.686959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..errors import TransformationError
    from ..utils.source import Source
    from .base import PythonToPythonTransformer

    src = Source("""
        a: int = 10
        b: int
    """)
    transformer = VariablesAnnotationsTransformer()
    assert repr(transformer) == 'VariablesAnnotationsTransformer'
    assert transformer.transform(transformer, src) == TransformationResult(src, tree_changed=True, new_imports=[])
    assert transformer.transform(transformer, src) == TransformationResult(src, tree_changed=False, new_imports=[])
    src = Source("""
        a = 10: int
    """)
    assert transformer.transform(transformer, src) == TransformationError(src, err_text='Assignment outside of body', new_imports=[])

# Generated at 2022-06-25 22:55:11.264390
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = "a: int = 10\nb: int"
    tree = ast.parse(code)
    new_tree, _, _ = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree) == "Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment='int')"

# Generated at 2022-06-25 22:55:15.227396
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = """#!/usr/bin/env python3
    a: int = 10
    b: int
    """
    result = """#!/usr/bin/env python3
    a = 10
    """
    check_result(VariablesAnnotationsTransformer, input, result)

# Generated at 2022-06-25 22:55:18.076854
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__doc__, "No docstring found"

# Generated at 2022-06-25 22:55:18.785005
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 22:55:23.016432
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """\
a: int = 10
b: int
c: int = 10 + 10
"""
    expected_code = """\
a = 10
b = None
c = 10 + 10
"""
    module, _ = VariablesAnnotationsTransformer.transform(ast.parse(input_code))

    assert ast.dump(module) == expected_code

# Generated at 2022-06-25 22:55:30.656831
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_helpers import parse_tree

    tree = parse_tree("a: int = 10\nb: int")

    assert tree == ast.Module(body=[ast.AnnAssign(target=ast.Name(id='a',
                                                             ctx=ast.Store()),
                                                 annotation=ast.Name(id='int',
                                                                     ctx=ast.Load()),
                                                 value=ast.Num(n=10),
                                                 simple=1),
                                    ast.AnnAssign(target=ast.Name(id='b',
                                                             ctx=ast.Store()),
                                                 annotation=ast.Name(id='int',
                                                                     ctx=ast.Load()),
                                                 value=None,
                                                 simple=0)])


#

# Generated at 2022-06-25 22:55:39.076812
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print(VariablesAnnotationsTransformer.__doc__)
    tree = ast.parse("from typing import List, Dict\na: int = 10\nb: Dict = {'a': 10}")
    print(ast.dump(tree, include_attributes=True))
    print('--------------------')
    result = VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(result.tree, include_attributes=True))

#test_VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:55:44.915087
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_variables import test_variables_1
    tree = ast.parse(test_variables_1)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert CompatTo36.transform(new_tree.tree).body == [ast.Assign(targets=[ast.Name(id='a', ctx=CompatTo36.load())], value=ast.Num(n=10))]

# Generated at 2022-06-25 22:56:12.237815
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """ Unit and integration test for VariablesAnnotationsTransformer.transform """

    # Create an instance of VariablesAnnotationsTransformer
    vat = VariablesAnnotationsTransformer()
    assert isinstance(vat, VariablesAnnotationsTransformer)

    # test for example 1
    example_input_1 = ast.parse("""
    a: int = 10
    b: int
    """, mode='exec')
    example_output_1 = ast.parse("""
    a = 10
    """, mode='exec')
    expected_output = str(example_output_1).strip()
    example_input = example_input_1
    actual_output = str(vat.transform(example_input)[0]).strip()
    assert expected_output == actual_output

    # test for example 2
    example_input_2 = ast.parse

# Generated at 2022-06-25 22:56:14.628951
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int = b = 20\nc = 30")
    VariablesAnnotationsTransformer.transform(tree)
    
# Test for the transform function

# Generated at 2022-06-25 22:56:18.395929
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test first case, where the class works well
    # Because the annotation is not None
    tree = ast.parse('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    # Test if the transformation is successful
    assert result.tree_changed

    # Test second case, where the class works well
    # Because the annotation is None
    tree = ast.parse('a: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    # Test if the transformation is successful
    assert result.tree_changed

# Generated at 2022-06-25 22:56:19.175228
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:56:23.693732
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_text = """
a: int = 10
b: int
    """
    expected_output = """
a = 10"""
    tree = ast.parse(input_text)
    assert str(tree).strip() == input_text.strip()
    tree = VariablesAnnotationsTransformer(tree).transform()
    assert str(tree).strip() == expected_output.strip()

# Generated at 2022-06-25 22:56:28.080250
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        (ast.parse("""
variable1 = 1
variable2: int = 1
variable3 = 1
variable4: int = 1
variable6 = 1
        """))) == (
            (ast.parse("""
variable1 = 1
variable2 = 1
variable3 = 1
variable4 = 1
variable6 = 1
        """)))

# Generated at 2022-06-25 22:56:29.210642
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)

# Generated at 2022-06-25 22:56:34.539380
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transform

    transform = assert_transform(VariablesAnnotationsTransformer,
        """
a: int = 10
b: int
        """, """
a = 10
        """)

    transform = assert_transform(VariablesAnnotationsTransformer,
        """
a: int = 10
b: int
a = 20
        """, """
a = 10
a = 20
        """)

# Generated at 2022-06-25 22:56:42.109123
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Tree before:
        a: int = 10
        b: int
    Tree after:
        a = 10
    """
    tree = ast.Module(
        body=[
            ast.AnnAssign(
                target=ast.Name(id='a',
                                ctx=ast.Store()),
                annotation=ast.Name(id='int', ctx=ast.Store()),
                value=ast.Num(n=10),
                simple=1
            ),
            ast.AnnAssign(
                target=ast.Name(id='b', ctx=ast.Store()),
                annotation=ast.Name(id='int', ctx=ast.Store()),
                value=None,
                simple=0
            )
        ]
    )

# Generated at 2022-06-25 22:56:42.563824
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:57:33.931260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse("""
a: int = 10
b: int
"""
                  )
        )



# Generated at 2022-06-25 22:57:38.531864
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = "a: int = 10\nb: int"
    expected_code = "a = 10"
    # Making a new instance of VariablesAnnotationsTransformer
    transformer = VariablesAnnotationsTransformer()
    # Calling the transform function from VariablesAnnotationsTransformer
    result = transformer.transform(input_code)
    # Checking if the result is correct
    assert result == expected_code

# Generated at 2022-06-25 22:57:39.572731
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #TODO: write unit test for VariablesAnnotationsTransformer
    pass

# Generated at 2022-06-25 22:57:46.791670
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("a: int = 10\nb: int")
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(new_tree.tree, ast.Module)
    assert new_tree.tree_changed is True
    assert len(new_tree.log) == 0

    # Test 2
    tree = ast.parse("a: int = 10\nb: int = 20")
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(new_tree.tree, ast.Module)
    assert new_tree.tree_changed is True
    assert len(new_tree.log) == 0

    # Test 3
    tree = ast.parse("if a:\n    a: int = 10")
    new_tree = VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:57:54.769323
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.AnnAssign(target = ast.Name(id = "a",  # type: ignore
                                            ctx = ast.Store()),
                          annotation = ast.Name(id = "int",  # type: ignore
                                                ctx = ast.Load()),
                          value = ast.Num(n = 0),
                          simple = 1)
    tree1 = node1
    
    expected_tree1 = ast.Assign(targets=[ast.Name(id="a",
                                                 ctx=ast.Store())],
                                value=ast.Num(n=0),
                                type_comment=ast.Name(id="int",
                                                      ctx=ast.Load()))
    

# Generated at 2022-06-25 22:58:00.707205
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    root = ast.parse(textwrap.dedent('''
    a: int = 10
    '''))

    result = VariablesAnnotationsTransformer.transform(root)
    assert result.changed is True
    assert len(result.warnings) == 0
    assert ast.dump(result.tree, include_attributes=True) == ast.dump(
        ast.parse(textwrap.dedent('''
        a = 10
        ''')), include_attributes=True)

# Generated at 2022-06-25 22:58:02.487848
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer()
    assert(isinstance(class_obj, VariablesAnnotationsTransformer))


# Generated at 2022-06-25 22:58:04.575864
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer(ast.parse("a:int = 10", mode="eval")).tree() == ast.parse("a=10", mode="eval")

# Generated at 2022-06-25 22:58:12.362570
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree_parser import TreeParser
    from ..transformers.as_kwargs import AsKwArgsTransformer
    from ..transformers.assert_raises import AssertRaisesTransformer
    from ..transformers.variables_annotations import VariablesAnnotationsTransformer

    pars = TreeParser()
    tree = pars.parse('aa: int = 10')
    test1 = TreeParser.dump(tree)

    tree2 = AsKwArgsTransformer.transform(tree)[0]
    test2 = TreeParser.dump(tree2)

    tree3 = AssertRaisesTransformer.transform(tree2)[0]
    test3 = TreeParser.dump(tree3)

    tree4 = VariablesAnnotationsTransformer.transform(tree3)[0]
    test4 = TreeParser.dump(tree4)
    assert test1

# Generated at 2022-06-25 22:58:13.499968
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:00:09.006456
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test for transform method in class VariablesAnnotationsTransformer
    from typed_ast import ast3 as ast
    node1= ast.parse("""
    a: int = 10
    b: int
    """)
    node2 = ast.parse("""
    a = 10
    """)
    trans = VariablesAnnotationsTransformer()
    result1 = trans.transform(node1)
    result2 = ast.parse(str(result1.tree))
    assert(ast.dump(node2) == ast.dump(result2))

# Generated at 2022-06-25 23:00:10.530725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    a: int = 10
    b: int

    # When
    VariablesAnnotationsTransformer.transform(tree)

    # Then
    assert a == 10

# Generated at 2022-06-25 23:00:14.880664
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..types import TransformationResult
    from typed_ast import ast3 as ast
    from .transformer_helpers import apply
    import sys

    code_before_transformation = """
    a: int = 10
    b: int
    """
    tree_before_transformation = ast.parse(code_before_transformation)
    result = VariablesAnnotationsTransformer._transform(tree_before_transformation)
    code_after_transformation = apply(result.tree)
    assert(code_after_transformation == "a = 10\nb: int\n")

# Generated at 2022-06-25 23:00:22.062992
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ...utils.testing import all_eq
    from ...utils.helpers import make_annotated_assignment

    test_cases: List[Tuple[Optional[ast.AST], bool]] = [
        (ast.parse('a = 10'), False),
        (make_annotated_assignment('a: int = 10'), True),
        (make_annotated_assignment('a: int'), True),
        (ast.parse('a, b: int = 10, 20'), True),
    ]
    for i, test_case in enumerate(test_cases):
        code, expected = test_case
        res = VariablesAnnotationsTransformer.transform(code)
        source = compile(res, '<test>', 'exec').co_code.__source__

# Generated at 2022-06-25 23:00:26.775466
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast import parse as ast_parse
    from .base import BaseUnitTestTransformer

    tree = ast_parse('''
a: int = 10
b: int
    ''')
    result_tree = ast_parse('''
a = 10
    ''')

    class TestVariablesAnnotationsTransformer(BaseUnitTestTransformer):
        target = (3, 5)
        transformer = VariablesAnnotationsTransformer

    TestVariablesAnnotationsTransformer.check(tree, result_tree)

# Generated at 2022-06-25 23:00:27.927135
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vart = ast.parse("a: int = 10")

# Generated at 2022-06-25 23:00:31.074552
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert astunparse.unparse(new_tree.tree) == """
a = 10
"""

# Generated at 2022-06-25 23:00:33.277809
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump


# Generated at 2022-06-25 23:00:36.307368
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''a: int = 10''')
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(new_tree, TransformationResult) and ast.dump(new_tree.tree) == ast.dump(ast.parse('''
a = 10
'''))

# Generated at 2022-06-25 23:00:45.272264
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from ..transformations.variables_annotations import VariablesAnnotationsTransformer
    import re
    from .base import PassesTestTransformer
    from ..exceptions import MultipleTransformationException

    class TestTransformer(PassesTestTransformer):
        """PassesTestTransformer is a class used for unit testing the
        tranformer.
        This class creates a tree and applies the transformation, and then
        checks whether the output tree is equal to the expected tree.

        Methods
        -------
        transform(self, tree, *args, **kwargs)
            Applies the transformation to the input tree and
            checks if the resulting tree is equal to the expected tree
        """

        def test_method(self, *args, **kwargs):
            # Given
            expected_