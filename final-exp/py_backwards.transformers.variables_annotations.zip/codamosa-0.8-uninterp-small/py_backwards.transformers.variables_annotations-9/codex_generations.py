

# Generated at 2022-06-25 22:52:49.620507
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer_0.target == (3, 5)


# Generated at 2022-06-25 22:52:50.639038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-25 22:52:53.120532
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int\n"))
    assert transformer.tree_changed
    assert transformer.is_callable is False
    assert transformer.new_functions == []
    assert transformer.offset == 0

# Generated at 2022-06-25 22:52:54.237608
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:52:55.999477
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test the constructor of class VariablesAnnotationsTransformer
    variables_annotations_transformer = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:52:57.746685
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    test_case_0()

# Generated at 2022-06-25 22:53:01.109408
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("------------------------------ test_VariablesAnnotationsTransformer() ------------------------------")
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert(variables_annotations_transformer_0 is not None)
    print("Done!")

# Generated at 2022-06-25 22:53:05.437166
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert VariablesAnnotationsTransformer == type(variables_annotations_transformer_0)
    assert variables_annotations_transformer_0.target == (3, 5)



# Generated at 2022-06-25 22:53:09.543008
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    parsed_ast = ast.parse("a: int = 10")
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer() # Constructor test
    try:
        VariablesAnnotationsTransformer.transform(parsed_ast)
    except:
        pass


# Generated at 2022-06-25 22:53:11.049889
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        VariablesAnnotationsTransformer()
        assert True
    except:
        assert False
        

# Generated at 2022-06-25 22:53:18.013478
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_node_as_string, parse_file_to_ast
    ast_str1 = "f: int = 0"
    ast1 = transform_code(ast_str1)
    ast_str2 = "f = 0"
    ast2 = parse_file_to_ast(ast_str2)
    assert get_node_as_string(ast1) == get_node_as_string(ast2)

# Generated at 2022-06-25 22:53:23.311281
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import compare_ast
    from ..utils.tree import build_ast

    source = """
    a: int = 10
    f()
    with open('test') as f:
        b: str
        g()
    """
    expected = """
    a = 10
    f()
    with open('test') as f:
        g()
    """

    tree = build_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-25 22:53:27.216748
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = \
'''
a: int = 10
b: int
'''
    expected = \
'''
a = 10
'''
    tree = ast.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    new_code = str(result)
    assert new_code == expected
    assert result.tree_changed

# Generated at 2022-06-25 22:53:37.287405
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.visitor import AstNodeVisitor
    from .. import settings
    import sys

    class PrintVisitor(AstNodeVisitor):
        def visit_Assign(self, node, parent):
            if len(node.targets) == 1:
                target = node.targets[0]
                print(target.id, ' = ', node.value.n)
            else:
                print('not supported yet')

    settings.target_version = (3, 5)
    src = '''
a: int = 10
b: int
c, d: int = 20, 30
    '''
    root = ast.parse(src)
    VariablesAnnotationsTransformer.transform(root)
    PrintVisitor().visit(root)


if __name__ == '__main__':
    test_VariablesAn

# Generated at 2022-06-25 22:53:38.639418
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast_pprint import dump_ast


# Generated at 2022-06-25 22:53:43.310197
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import source_to_tree
    from ..utils.helpers import get_code
    from .base import print_transformation_result

    print(get_code(__file__))
    print('-------------------------------------')

    node = source_to_tree(get_code(__file__))
    print_transformation_result(VariablesAnnotationsTransformer.transform(node))

# Generated at 2022-06-25 22:53:51.055528
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import astor
    from ..visitors.annotation_visitor import AnnotationVisitor
    file_path = inspect.getfile(inspect.currentframe())
    file_ast = ast.parse(open(file_path, 'r').read())
    annotation_ast = AnnotationVisitor().visit(file_ast)
    annotation_ast = astor.to_source(annotation_ast)
    result = VariablesAnnotationsTransformer.transform(file_ast)
    result.apply()
    modified_file_ast = astor.to_source(file_ast)
    assert(modified_file_ast == annotation_ast)

# Generated at 2022-06-25 22:54:00.048901
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import tempfile
    from ..utils.helpers import replace_in_file
    from .utils import assert_compilation

    def assert_compilation_without_annotations(before: str, after: str):
        with tempfile.NamedTemporaryFile('w', suffix='.py') as fp:
            fp.write(before)
            fp.flush()

            assert_compilation(
                before,
                after,
                [fp.name],
                transformers=[VariablesAnnotationsTransformer],
                ignore_warnings=['Assignment outside of body']
            )

    # When the assignment doesn't have type annotation
    # Then the transformation doesn't change the code

# Generated at 2022-06-25 22:54:05.575693
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find

    example = """a: int = 10
                b: int
                c: int = 10
                d: int = 9
                """

    tree = ast.parse(example)
    transformed_tree = VariablesAnnotationsTransformer.transform(tree).tree

    result = """a = 10
                c = 10
                d = 9
                """

    assert transformed_tree.body == ast.parse(result).body
    # assert VariablesAnnotationsTransformer.transform(tree).tree == result

# Generated at 2022-06-25 22:54:14.495629
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_code = """
a: int = 10
b: int
"""
    new_variable_annotations_transformer = VariablesAnnotationsTransformer()
    tree = ast.parse(test_code)
    new_variable_annotations_transformer.transform(tree)
    print(ast.dump(tree))
    expected_result = "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment='int'), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment='int')])"
    print(expected_result)
    assert ast.dump(tree) == expected_result

# Generated at 2022-06-25 22:54:26.880527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    source = """def test_func1(a):
    b = 10
    c: int = 20
    d: int
    e: int
    f: int
    if True:
        g: int = 30
        h: int
        h = 40
    a: int = 50"""
    expected = """def test_func1(a):
    b = 10
    c = 20
    d: int
    e: int
    f: int
    if True:
        g = 30
        h: int
        h = 40
    a = 50"""
    tree = ast.parse(source)
    new = VariablesAnnotationsTransformer().transform(tree)
    assert ast.unparse(new.tree) == expected

    # Test for no changes

# Generated at 2022-06-25 22:54:36.954628
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:40.215044
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Instantiating VariablesAnnotationsTransformer with expression to be transformed as input
    vat = VariablesAnnotationsTransformer(ast.parse('a: int = 5'))
    # Asserting that the expression is transformed to expected value 
    assert vat.to_ast() == ast.parse('a = 5')

# Generated at 2022-06-25 22:54:45.448864
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from unittest import TestCase
    from ..utils import run_with_errors

    class VariableAnnotationsTransformerTest(TestCase):

        def test_variable(self):
            tree = ast.parse('a: int = 2')
            expected_tree = ast.parse('a = 2')
            result = run_with_errors(VariablesAnnotationsTransformer.transform, tree)
            self.assertEqual(result.tree, expected_tree)

    test = VariableAnnotationsTransformerTest()
    test.test_variable()

# Generated at 2022-06-25 22:54:48.544940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	tree = ast.parse("a: int = 10\nb: int = 5\nc: int = 15", mode='exec')
	transformed_tree = VariablesAnnotationsTransformer.transform(tree)
	assert(ast.dump(transformed_tree.tree) == ast.dump(ast.parse("a = 10\nb = 5\nc = 15", mode='exec')))

# Generated at 2022-06-25 22:54:58.138184
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Get code to compile with VariablesAnnotationsTransformer()
    code = '''a: int = 10
    b: int
    def foo(x: int) -> int:
        return x + 1'''
    # Compile code and run test
    assert VariablesAnnotationsTransformer.run_test(code) == \
        '''a = 10
    b = None
    def foo(x):
        return x + 1'''


# Generated at 2022-06-25 22:55:02.674647
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
        "a: int = 10\nb: int")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.new_tree.body[0] == ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))

# Generated at 2022-06-25 22:55:06.933268
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        result = VariablesAnnotationsTransformer.transform(tree=ast.parse("a: int = 10\nb: int"))
        assert str(result.tree.body[0].value) == "10"
        assert str(result.tree.body[1]) == "b: int"
    except Exception:
        raise Exception("Test for constructor of 'VariablesAnnotationsTransformer' failed")


# Generated at 2022-06-25 22:55:12.262611
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 1 is annotated Variable, so not simple node, but Expression. 
    # The AST representation of annotation is same as assignment (Assign)
    # but longer
    input_tree = ast.parse("a: int = 1")
    expected_tree = ast.parse("a = 1")
    res = VariablesAnnotationsTransformer.transform(input_tree)
    assert res.result_tree == expected_tree
    assert res.changed == True

    # Test for the number of modified nodes
    input_tree = ast.parse("a, b: int = 1, 2")
    expected_tree = ast.parse("a, b = 1, 2")
    res = VariablesAnnotationsTransformer.transform(input_tree)
    assert res.result_tree == expected_tree

# Generated at 2022-06-25 22:55:24.426619
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse

    class TestTransformer(VariablesAnnotationsTransformer):
        pass

    tests = [
        ('a: int = 10\n', 'a = 10\n'),
        ('a: int\n', ''),
        ('a: int = 10\n', 'a = 10\n'),
        ('x: int = 1\na: int = 10\n', 'x = 1\na = 10\n')
    ]
    for i, (given, expected) in enumerate(tests):
        tree = ast.parse(given)
        result, tree_changed = TestTransformer.transform(tree)
        given_text = astunparse.unparse(result).replace('\n\n', '\n')
        if given_text != expected:
            print(i)
            print(given)

# Generated at 2022-06-25 22:55:34.406070
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3,5)

# Generated at 2022-06-25 22:55:47.244588
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # First Example:
    # b: int = 10
    # c: int
    # d : int = 12
    # main: int
    #  ->
    # b = 10
    # d = 12
    ast1 = ast_parse("""
b: int = 10
c: int
d: int = 12
main: int
""", mode='exec')
    VariablesAnnotationsTransformer.transform(ast1)

# Generated at 2022-06-25 22:55:48.201176
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:55:51.896281
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = 'a: int = 10'
    tree = ast.parse(code)

    res = VariablesAnnotationsTransformer.transform(tree)
    tree = res.tree
    assert_equal(len(tree.body),1)
    assert_equal(ast.dump(tree),'''Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))])''')

# Generated at 2022-06-25 22:56:01.664909
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_first_expression
    from ..transformations.VariablesAnnotationsTransformer import VariablesAnnotationsTransformer
    """class A:
        a: int = 10
        b: int
    """
    tree = ast.parse("""class A:
        a: int = 10
        b: int
    """)
    a = get_first_expression(tree)
    ann_assign_exists = any(isinstance(n, ast.AnnAssign) for n in a.body)
    VariablesAnnotationsTransformer.transform(tree)
    b = get_first_expression(tree)
    changed_ann_assign_exists = any(isinstance(n, ast.AnnAssign) for n in b.body)
    assert ann_assign

# Generated at 2022-06-25 22:56:09.762450
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """a: int = 10
              b: int
              c: int = 20
              d: int = 30
              e: int
           """
    from typed_ast import ast3
    from sortedcontainers import SortedList
    from typed_ast import ast3 as ast
    import astunparse
    import sys
    import os
    sys.path.append(os.path.abspath('../typed_astunparse'))
    import typed_astunparse

    tree = ast3.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    expected_code = """a = 10\nd = 30\ne = None"""
    assert typed_astunparse.dump(result.transformed_tree) == expected_code

# Generated at 2022-06-25 22:56:15.058980
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
        a: int = 10
        b: int
        print(a)
        print(b)
    """)

    # print(ast.dump(tree))
    expected = ast.parse("""
        a = 10
        print(a)
        print(b)
    """)
    # print(ast.dump(expected))

    VariablesAnnotationsTransformer.transform(tree)

    assert(ast.dump(tree) == ast.dump(expected))



# Generated at 2022-06-25 22:56:18.714442
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(ast.parse('a = 10'))

# Generated at 2022-06-25 22:56:27.781254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vars = ast.FunctionDef(name='test',
                           body=[ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                                               annotation=ast.Name(id='int', ctx=ast.Load()),
                                               value=ast.Num(n=10),
                                               simple=1),
                                 ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                                            value=ast.Num(n=10))],
                           returns=None,
                           args=ast.arguments(args=[], vararg=None, kwonlyargs=[],
                                              kw_defaults=[], kwarg=None, defaults=[]),
                           decorator_list=[],
                           type_comment=None)

# Generated at 2022-06-25 22:56:28.907779
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange

    # Act
    VariablesAnnotationsTransformer()

    # Assert

# Generated at 2022-06-25 22:56:52.896017
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open('tests/data/variables_annotations.py', 'r') as f:
        tree = ast.parse(f.read())
        new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    with open('tests/data/variables_annotations_result.py', 'r') as f:
        assert f.read() == ast.unparse(new_tree)

# Generated at 2022-06-25 22:56:58.591510
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import assert_tree

    tree = ast.parse("""
a: int = 10
b: str = "hi"
c: str
""")

    VariablesAnnotationsTransformer.transform(tree)

    assert_tree(tree, """
Assign(
    targets=[Name(id='a', ctx=Store())],
    value=Constant(value=10, kind=None),
    type_comment=' int ')
Assign(
    targets=[Name(id='b', ctx=Store())],
    value=Constant(value="hi", kind=None),
    type_comment=' str ')
""")

# Generated at 2022-06-25 22:57:03.040300
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as ast

    test_tree = ast.Module(body=[ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10), simple=1)])

    result = VariablesAnnotationsTransformer()
    result.transform(test_tree)

# Generated at 2022-06-25 22:57:10.111654
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # given
    code = '''a: int = 10
        b: int'''

    module = ast.parse(code)

    # when
    VariablesAnnotationsTransformer.transform(module)

    # then
    assert module.body == [
        ast.Assign(
            targets=[ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Constant(value=10, kind=None), simple=1)],
            value=ast.Constant(value=10, kind=None),
            type_comment=ast.Name(id='int', ctx=ast.Load())
        )]

# Generated at 2022-06-25 22:57:10.974899
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-25 22:57:11.395223
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 22:57:19.132978
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node
    from ..utils.fixtures import EXAMPLE_TYPES_ANNOTATIONS

    transformed_tree = VariablesAnnotationsTransformer.transform(
        get_node(EXAMPLE_TYPES_ANNOTATIONS))

    # Check that the "transformation_result" flag is True
    assert transformed_tree.transformation_result == True

# Generated at 2022-06-25 22:57:26.722278
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var0 = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()), annotation=ast.Name(id="int", ctx=ast.Load()), value=None)
    var1 = ast.AnnAssign(target=ast.Name(id="b", ctx=ast.Store()), annotation=ast.Name(id="int", ctx=ast.Load()), value=None)
    assign = ast.Assign(targets=[ast.Name(id="c", ctx=ast.Store())], value=ast.Num(n=10))
    tree = ast.Module(body=[var0, var1, assign])
    assert tree == VariablesAnnotationsTransformer.transform(tree).tree

# Generated at 2022-06-25 22:57:28.830025
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """a: int = 10
    b: int
    """

    expected_code = """a = 10
    """
    t = VariablesAnnotationsTransformer()
    t.transform_code(code)
    assert t.transformed_code == expected_code

# Generated at 2022-06-25 22:57:31.786168
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    simple_tree = ast.parse('''def foo():
    a: int = 10
    b: int
    c: int

if __name__ == '__main__':
    foo()
''')

    tree_changed = VariablesAnnotationsTransformer.transform(tree = simple_tree)
    assert str(simple_tree) == "def foo():\n    a = 10\n    b\n    c\n\nif __name__ == '__main__':\n    foo()\n"
    assert tree_changed == True

# Generated at 2022-06-25 22:58:17.129582
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test =  ast.parse("""def f(a: int = 10,\nb: int):\n    return a + b""")
    res = ast.parse("""def f(a: int = 10,\nb: int):\n    return a + b""")
    tree_changed, changes = VariablesAnnotationsTransformer.transform(test)
    assert(res == tree_changed)

# Generated at 2022-06-25 22:58:21.504026
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	x = "a: int = 10"
	expected_y = ast.parse("""a = 10""").body[0]
	transformed = VariablesAnnotationsTransformer.transform(ast.parse(x))
	y = transformed.tree.body[0]
	assert(ast.dump(y) == ast.dump(expected_y))

# Generated at 2022-06-25 22:58:22.220760
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print(VariablesAnnotationsTransformer)

# Generated at 2022-06-25 22:58:28.451222
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    VariablesAnnotationsTransformer.transform(tree)
    assert(len(tree.body)==1)
    assert(isinstance(tree.body[0],ast.Assign))
    assert(isinstance(tree.body[0].targets[0],ast.Name))
    assert(tree.body[0].targets[0].id=="a")
    assert(isinstance(tree.body[0].value,ast.Num))
    assert(tree.body[0].value.n==10)
    assert(tree.body[0].type_comment=="int")

# Generated at 2022-06-25 22:58:32.313273
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer
    assert class_.target == (3, 5)
    assert class_.transform(ast.parse(
        'a: int = 10\n'
        'b: int\n'
        'c: str = "three"'
    )) == TransformationResult(ast.parse(
        'a = 10\n'
        'c = "three"'
    ), True, [])

# Generated at 2022-06-25 22:58:33.807986
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:39.363634
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .helpers import compile_to_ast, dump_tree

    source = """
a = 1
b = 2
c = 3
d = 4
e = 5
f = 6
a: int = 10
b: int
    """
    tree = compile_to_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert dump_tree(tree) == dump_tree(compile_to_ast("""
a = 1
b = 2
c = 3
d = 4
e = 5
f = 6
a = 10
    """))

# Generated at 2022-06-25 22:58:45.456874
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("Testing class VariablesAnnotationsTransformer")
    test_tree = ast.parse("""
    a: int = 10
    b: int
    """, 'test_file.py')

    new_tree = VariablesAnnotationsTransformer.transform(test_tree).new_tree

    # Assert body of file contains 2 assignments
    assert len(new_tree.body) == 2

    # Assert first assignment is of the form 'a = 10'
    assert str(new_tree.body[0]) == "_Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))"

    # Assert second assignment is of the form 'b = ...'

# Generated at 2022-06-25 22:58:51.789528
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    t = VariablesAnnotationsTransformer()

    # Act
    a: int = 10
    b: int
    c: int
    ast_tree = ast.parse('a: int = 10\nb: int\nc: int')
    transformed_tree = t.transform(ast_tree)

    # Assert
    assert isinstance(transformed_tree.tree, ast.Module)
    assert len(transformed_tree.tree.body) == 3

    assert isinstance(transformed_tree.tree.body[0], ast.Assign)
    assert isinstance(transformed_tree.tree.body[0].targets[0], ast.Name)
    assert transformed_tree.tree.body[0].targets[0].id == 'a'

# Generated at 2022-06-25 22:58:58.634136
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import dump_tree
    from ..utils.tree import parse_tree
    from ..utils.helpers import get_tree_string
    from ..utils.helpers import compare_trees
    file_path_input = 'tests/fixtures/input/VariablesAnnotationsTransformer.py'
    file_path_transformed = 'tests/fixtures/transformed/VariablesAnnotationsTransformer_transformed.py'
    _input = get_tree_string(file_path_input)
    _transformed = get_tree_string(file_path_transformed)
    tree = parse_tree(3, 5, file_path_input)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    _output = dump_tree(tree)
    assert compare_trees(_transformed, _output)

# Generated at 2022-06-25 23:00:53.907450
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    
    a = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10),
                      simple=1)
    b = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=None,
                      simple=0)

    tree = ast.Module([a,b])

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result is not None

    node = result.tree.body[0]
    assert isinstance(node, ast.Assign)
   

# Generated at 2022-06-25 23:01:00.100445
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input='''
    class Test:
        def __init__(self):
            a: int = 10
            b: int
    '''
    expect='''
    class Test:
        def __init__(self):
            a = 10
    '''
    tree = ast.parse(input)
    node = tree.body[0].body[0]
    actual = VariablesAnnotationsTransformer.transform(node)
    assert ast.dump(actual.tree) == ast.dump(ast.parse(expect).body[0].body[0])
    assert actual.tree_changed is True
    assert len(actual.new_imports) == 0

# Generated at 2022-06-25 23:01:02.542006
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astextensions import parse
    from ..transformation.variablesannotations import VariablesAnnotationsTransformer

    src = """
    a: int = 10
    b: int
    """
    tree = parse(src)
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-25 23:01:05.771401
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    def test_VariablesAnnotationsTransformer():
        from typed_ast import ast3 as ast
        ll = ast.parse("a: int = 10\nb:int")
        t = VariablesAnnotationsTransformer()
        t.transform(ll)
        assert str(t.tree) == str(ast.parse("a = 10\nb"))

# Generated at 2022-06-25 23:01:08.278255
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = '''\
    a: int = 10
    b: int\
    '''

    expected_code = '''\
    a = 10\
    '''
    pass

# Generated at 2022-06-25 23:01:08.963479
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:01:11.495118
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """ Unit test for constructor of class VariablesAnnotationsTransformer """
    tranf = VariablesAnnotationsTransformer()
    assert isinstance(tranf, BaseTransformer)


# Generated at 2022-06-25 23:01:16.119823
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse("""
    a: int = 10
    b: int
    """, mode='exec')
    assert len(list(find(node, ast.AnnAssign))) == 2
    VariablesAnnotationsTransformer(target=(3, 5)).visit(node)
    assert len(list(find(node, ast.AnnAssign))) == 0
    assert len(list(find(node, ast.Assign))) == 1
    assert len(list(find(node, ast.Name))) == 2
    assert len(list(find(node, ast.expr))) == 1

# Generated at 2022-06-25 23:01:20.645000
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import assertAST
    from ..utils.test_utils import create_test_context
    from .constant_folding import ConstantFoldingTransformer

    assertAST(VariablesAnnotationsTransformer.transform(
        ast.parse('''
        a: int = 10
        def b():
            c: int
            pass
        '''),
        create_test_context(3, 5, [ConstantFoldingTransformer]))) == \
        '''
        a = 10
        def b():
            pass
        '''

# Generated at 2022-06-25 23:01:24.957039
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test that compiler can handle an addition of an annotation in
    any line.
    """
    tree = ast.parse('a: int= 10\nb: int\n')
    tree_changed, warnings = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == 'Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=10), type_comment=\'int\')\n'
    assert len(warnings) == 0
