

# Generated at 2022-06-25 22:52:46.737137
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:52:49.846285
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = '''
    from typing import List, Union

    a: int = 10
    '''
    output_code = '''
    from typing import List, Union


    a = 10
    '''
    result = VariablesAnnotationsTransformer.transform(input_code)
    assert result.content == output_code



# Generated at 2022-06-25 22:52:51.504039
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    root = ast.parse("a: int = 10\nb: int")
    tree_changed = VariablesAnnotationsTransformer.transform(root)
    assert tree_changed

# Generated at 2022-06-25 22:52:54.780612
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    variables_annotations_transformer_0.LHS = variables_annotations_transformer_0
    (variables_annotations_transformer_0.LHS, variables_annotations_transformer_0.RHS) = (variables_annotations_transformer_0.RHS, variables_annotations_transformer_0.LHS)


# Generated at 2022-06-25 22:52:56.516975
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer(tree)

# Generated at 2022-06-25 22:53:04.821280
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_1 = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer_1.target == (3, 5)
    assert variables_annotations_transformer_1.transform != None

# unit tests for transform method
    def test_case_1():
        v1 = VariablesAnnotationsTransformer()
        tree = ast.parse("from __future__ import annotations"
                         "x: int = 1")
        res = v1.transform(tree)
        assert res == TransformationResult(ast.parse("x = 1"), tree_changed=True, errors=[])

# Generated at 2022-06-25 22:53:05.894066
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert (VariablesAnnotationsTransformer.target == (3, 5))


# Generated at 2022-06-25 22:53:06.964042
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    abc = 2


# Generated at 2022-06-25 22:53:10.846887
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    inp_code  = """
a: int = 10
b: int
    """
    try:
        variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    except:
        print("Test cases for constructor of class VariablesAnnotationsTransformer failed")
        print("")

# Generated at 2022-06-25 22:53:11.996646
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert (VariablesAnnotationsTransformer())


# Generated at 2022-06-25 22:53:19.750244
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = ast.AnnAssign(
                target = ast.Name('a', ast.Store()),
                annotation = ast.Name('int', ast.Load()),
                value = ast.Constant(10, kind = None),
                simple = 0)
    assert VariablesAnnotationsTransformer.transform(var) == \
           (ast.Assign(
                targets = [ast.Name('a', ast.Store())],
                value = ast.Constant(10, kind = None),
                type_comment = ast.Name('int', ast.Load())), True, [])

# Generated at 2022-06-25 22:53:22.844376
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(tree)
    assert len(transformer.warnings) == 0
    assert transformer.result is not None
    assert transformer.tree_changed == True


# Generated at 2022-06-25 22:53:26.344555
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"
    assert VariablesAnnotationsTransformer.__doc__ == "Compiles:\n        a: int = 10\n        b: int\n    To:\n        a = 10\n\n    "


# Generated at 2022-06-25 22:53:30.615751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """x: bool = True"""
    expected_code = """x = True"""

    output_code = VariablesAnnotationsTransformer.transform(ast.parse(input_code)).tree

    assert ast.dump(output_code) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-25 22:53:39.602561
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestClass():
        def __init__(self):
            self.a = 0
            self.b = 1
            self.c = 2

        def test_method_1(self, x: int = 10):
            return self.b

        def test_method_2(self, x: int = 20, y: int = 30):
            self.c = x + y

        def test_method_3(self, x: int = 30, y: int = 40, z: int = 50):
            self.a = x
            self.test_method_2()

    test_class = TestClass()

    # Test test_class.test_method_1()
    try:
        test_class.test_method_1()
    except Exception:
        assert False
    else:
        assert True

    # Test test_class

# Generated at 2022-06-25 22:53:46.267888
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class DummyNode(ast.AST):
        _fields = ()
        _attributes = ()
    input_node = ast.AnnAssign(
        target=None,
        annotation=None,
        value=None,
        simple=0,
        type_comment=None
    )
    expected_output = TransformationResult(
        tree=DummyNode(),
        tree_changed=False,
        added_imports=[]
    )
    actual_output = VariablesAnnotationsTransformer.transform(input_node)
    assert actual_output == expected_output

# Generated at 2022-06-25 22:53:51.172321
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node_data = {'target': ast.Name(id='a'), 'annotation': ast.Name(id='int'), 'value': ast.Num(n=10)} 
    tree_node = ast.AnnAssign(**node_data)

    res = VariablesAnnotationsTransformer.transform(tree_node)
    assert res.tree is not None
    assert res.tree_changed is True
    assert res.errors == []

# Generated at 2022-06-25 22:54:00.850879
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:01.652728
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:05.436004
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    f = open("./test/test-data/test_VariablesAnnotationsTransformer.py", "r")
    lines = f.read()
    node = ast.parse(lines)
    refactored_node = VariablesAnnotationsTransformer.transform(node)
    assert refactored_node.tree != None
    assert refactored_node.tree_changed == True
    assert refactored_node.msgs != []

# Generated at 2022-06-25 22:54:12.799130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.spam_module import ast_parse_and_transform


# Generated at 2022-06-25 22:54:21.109667
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(str(VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10"))) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Str(s='int'))])")
    assert(str(VariablesAnnotationsTransformer.transform(ast.parse("a: int"))) == "Module(body=[])")


if __name__ == "__main__":
    string = "a: int = 10"
    print(VariablesAnnotationsTransformer.transform(ast.parse(string)))
    string = "a: int"
    print(VariablesAnnotationsTransformer.transform(ast.parse(string)))

# Generated at 2022-06-25 22:54:22.310947
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer is not None


# Generated at 2022-06-25 22:54:23.467982
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = VariablesAnnotationsTransformer()
    assert x.target == (3, 5)

# Generated at 2022-06-25 22:54:28.705089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create class VariablesAnnotationsTransformer
    var_anno = VariablesAnnotationsTransformer()

    # Create parse tree for python code
    tree = ast.parse("""x: int = 10 \ny: int""")

    # Transform the parse tree
    transformed_tree = var_anno.transform(tree)

    # Check whether the tree has changed
    assert transformed_tree.has_changed

    # Check whether the transformation is correct
    assert ast.dump(transformed_tree.tree) == \
        "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=10))])"

# Generated at 2022-06-25 22:54:29.909236
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:31.404094
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer()
    assert isinstance(result, BaseTransformer)



# Generated at 2022-06-25 22:54:34.606605
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''This is the test for the constructor of the class VariablesAnnotationsTransformer.'''
    m = VariablesAnnotationsTransformer()
    assert isinstance(m, VariablesAnnotationsTransformer)


# Generated at 2022-06-25 22:54:41.682707
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open("test/resource/variables_annotations_before.py", 'r') as f:
        before = ast.parse(f.read())

    with open("test/resource/variables_annotations_after.py", 'r') as f:
        after = ast.parse(f.read())

    expected = []
    for node in before.body:
        if isinstance(node, ast.AnnAssign):
            expected.append({"message": "Annotation",
                             "line": node.lineno, "column": node.col_offset})

    result = VariablesAnnotationsTransformer.transform(before)
    assert result.tree == after
    assert result.warnings == expected

# Generated at 2022-06-25 22:54:46.010882
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast as pylint_ast
    from ..utils.tree import convert
    from ..utils.helpers import infer_type

    annotation_assign = pylint_ast.parse('a: int = 10').body[0]
    inferred_type = infer_type(convert(annotation_assign))

    assert VariablesAnnotationsTransformer.transform(annotation_assign) == TransformationResult(inferred_type, True, [])

# Generated at 2022-06-25 22:55:00.439422
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.nodes import node_to_tuple
    example_1 = ast.parse('a: int = 10')
    example_2 = ast.parse('b: int')
    var_obj = VariablesAnnotationsTransformer()
    assert node_to_tuple(example_1) == node_to_tuple(var_obj.transform(example_1).tree)
    assert node_to_tuple(example_2) == node_to_tuple(var_obj.transform(example_2).tree)

# Generated at 2022-06-25 22:55:01.545534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer(3,5) is not None

# Generated at 2022-06-25 22:55:05.847101
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    tree_before = ast.parse('''
if a is not None:
    b: int
    c: int = 10
    ''')
    tree_after = ast.parse('''
if a is not None:
    c = 10
    ''')
    transformer.transform(tree_before)
    assert tree_before == tree_after

# Generated at 2022-06-25 22:55:11.744757
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTransformerTest
    from ..binder import Binder
    from ..utils.ast_extensions import fix_missing_locations

    class TestTransformer(BaseTransformerTest):
        @classmethod
        def _prepare(cls, tree, module_aliases):
            cls.tree = fix_missing_locations(tree)
            cls.binder = Binder(module_aliases)

        @classmethod
        def _transform(cls):
            cls.transformer = VariablesAnnotationsTransformer(cls.tree,
                                                              cls.binder)
            cls.result = cls.transformer.transform()

    # Test simple assignment with annotation
    code = 'a: int = 10'
    tree = ast.parse(code)

# Generated at 2022-06-25 22:55:14.055691
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse("a: int = 10\nb: int")
    ).tree == ast.parse("b = None\na = 10")


# Generated at 2022-06-25 22:55:22.169446
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1: Assignment outside of body
    import astor
    transformer = VariablesAnnotationsTransformer
    test_code = 'a: int = 10'
    tree = astor.parse_file(test_code)

    result = transformer.transform(tree)
    expected = ('None\n')

    assert astor.to_source(result[0]) == expected

    # Test 2: Assignment inside of body
    test_code = 'if True:\n    a: int = 10'
    tree = astor.parse_file(test_code)

    result = transformer.transform(tree)
    expected = ('if True:\n    a = 10\n')

    assert astor.to_source(result[0]) == expected

    # Test 3: Assignment with no value
    test_code = 'b: int'
    tree = astor

# Generated at 2022-06-25 22:55:22.978068
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:55:29.233376
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.testutils import compare_trees
    
    tree = ast.parse("""
        a: int = 10
        b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    compare_trees(result,
                  '''
                  Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load()))
                  '''
    )
    assert result.success == True

# Generated at 2022-06-25 22:55:42.081907
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import _test_transform
    from .clean import CleanUpFunctionDefDefaultsTransformer
    from ..utils.helpers import remove_all_comments

    # Test that e does not have an annotation
    tree = _test_transform(VariablesAnnotationsTransformer, '''
    def func():
        a: int = 10
        b: int = 20
        a = 15
        c = a + b
        d = a / b
    ''')
    assert (remove_all_comments(tree) == remove_all_comments("""
    def func():
        a = 10
        b = 20
        a = 15
        c = a + b
        d = a / b

    """))

    # Test that e has an annotation, and is annotated

# Generated at 2022-06-25 22:55:47.234223
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_test_case_as_dict, assert_as_same

    test_case = get_test_case_as_dict(
        test_module='test_module', test_name='test_VariablesAnnotationsTransformer')

    assert_as_same(
        test_case,
        VariablesAnnotationsTransformer.transform,
        VariablesAnnotationsTransformer.create_autofix_patch)

# Generated at 2022-06-25 22:56:13.723349
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    test_tree = ast.parse("""
        def func(a: int, b: int):
            c: int = 10
    """)

    new_tree, _, _ = VariablesAnnotationsTransformer.transform(test_tree)
    assert ast.dump(new_tree) == textwrap.dedent("""
        def func(a: int, b: int):
            c = 10
    """).strip()
    # Test 2
    test_tree = ast.parse("""
        def func(a: int, b: int):
            pass
    """)

    new_tree, _, _ = VariablesAnnotationsTransformer.transform(test_tree)

# Generated at 2022-06-25 22:56:17.172905
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a:int=10')
    body = [tree.body[0]]
    assert isinstance(tree.body[0],ast.AnnAssign)
    assert tree.body[0].annotation == ast.parse('int').body[0].value
    assert tree.body[0].target == ast.parse('a').body[0].targets[0]
    assert tree.body[0].value == ast.parse('10').body[0].value


# Generated at 2022-06-25 22:56:21.875576
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_1 = ast.parse("""a: int = 10
                b: int""")
    ast_2 = ast.parse("""a = 10""")
    #ast_3 = ast.parse("""def example():
    #                    a: int
    #                """)

    assert VariablesAnnotationsTransformer.transform(
        ast_1).tree == ast_2

# Generated at 2022-06-25 22:56:22.785561
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:56:24.594639
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert isinstance(transformer, BaseTransformer)
    

# Generated at 2022-06-25 22:56:31.895424
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.pytest_helpers import validate_transformer
    # Simple test
    validate_transformer(VariablesAnnotationsTransformer, '''
        a: int = 10
        b: int
    ''')
    # Test more complex case
    validate_transformer(VariablesAnnotationsTransformer, '''
            a: int = 10
            b: int
            c: int = 20
    ''')
    # Test with None value
    validate_transformer(VariablesAnnotationsTransformer, '''
            a: int = 10
            b: int
            c: int = None
    ''')

# Generated at 2022-06-25 22:56:39.815574
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_source
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    # Start by creating an instance of the required class
    a = VariablesAnnotationsTransformer()
    # Now that the instance of the class has been created,
    # it can be tested.
    # First, the __init__ method, which has no return value
    # and only serves to initialize the class.
    # There is nothing that can be asserted
    # The classmethod transform() is what will be tested
    # See the following link for more information
    # https://github.com/python/mypy/blob/master/mypy/nodes.py
    # To test the transform() method, a tree needs to be created.
    # The

# Generated at 2022-06-25 22:56:45.838253
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.Module([ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Load()),
                                     annotation=ast.Name(id='int', ctx=ast.Load()),
                                     value=ast.Constant(value=10),
                                     simple=1)], type_ignores=[])
    assert ast.dump(node) == "Module(body=[AnnAssign(target=Name(id='x', ctx=Load()), annotation=Name(id='int', ctx=Load()), value=Constant(value=10), simple=1)], type_ignores=[])"

# Generated at 2022-06-25 22:56:47.227594
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  class_test = VariablesAnnotationsTransformer()
  assert class_test.target == (3, 5)


# Generated at 2022-06-25 22:56:50.101539
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import transform_code
    from .annotation_transformer import AnnotationTransformer
    from .keywords import KeywordsTransformer
    from .builtin_transformer import BuiltinTransformer

    # First transform the code to fit Python 3.7

# Generated at 2022-06-25 22:57:38.947223
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    input = ast.parse("""
name: str = 'A'
age: int = 10
""")
    assert VariablesAnnotationsTransformer.transform(input)

# Generated at 2022-06-25 22:57:44.381126
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing class VariablesAnnotationsTransformer.
    tree = ast.parse('a:int=10\nb:int')
    assert str(VariablesAnnotationsTransformer.transform(tree).tree_before) == 'Module(body=[AnnAssign(target=Name(id="a", ctx=Store()), annotation=Name(id="int", ctx=Load()), value=Num(n=10), simple=1), Assign(targets=[Name(id="b", ctx=Store())], value=Name(id="int", ctx=Load()))])'


# Generated at 2022-06-25 22:57:45.887796
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # constructor
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-25 22:57:53.405594
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast,sys,inspect
    from pythran.typed_ast import ast3 as typed_ast
    
    class Dummy:
        def method0(self):
            a: int = 10
            b: int
    class_name = "Dummy"
    
    class_ast = ast.parse(inspect.getsource(sys.modules[__name__]))
    class_node = [n for n in class_ast.body if isinstance(n,ast.ClassDef) and n.name == class_name][0]
    method_node = [n for n in class_node.body if isinstance(n,ast.FunctionDef) and n.name == 'method0'][0]

    transformer = VariablesAnnotationsTransformer()
    m = transformer.transform(method_node)


# Generated at 2022-06-25 22:57:55.990877
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a=VariablesAnnotationsTransformer(3,5)


#Unit test for transform Function.

# Generated at 2022-06-25 22:57:56.577265
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:05.153094
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_utils import should_not_change, should_change
    from .test_utils import dump, load
    should_not_change(__file__, '''
    def foo(a):
        pass
    ''')
    should_change(__file__, '''
    def foo(a: int = 10):
        print(a)
    ''', '''
    def foo(a: int = 10):
        print(a)
    ''')

    should_change(__file__, '''
    def foo(a: int):
        pass
    ''', '''
    def foo(a: int):
        pass
    ''')


# Generated at 2022-06-25 22:58:06.866112
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test = VariablesAnnotationsTransformer()
    assert test.target == (3, 5)


# Generated at 2022-06-25 22:58:14.342929
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Test function for VariablesAnnotationsTransformer
    tree is the AST of
    a: int = 10
    b: int
    '''

# Generated at 2022-06-25 22:58:22.304590
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import compare_ast
    from .array_literal_transformer import ArrayLiteralTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer


# Generated at 2022-06-25 23:00:15.573922
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import make_tree

    code_str = '''
    from my_package import *
    a: int = 10
    b: int
    '''
    tree = make_tree(code_str)

    assert len(find(tree, ast.AnnAssign)) == 2

    VariablesAnnotationsTransformer.transform(tree)

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Expr)) == 1

# Generated at 2022-06-25 23:00:20.120934
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    sample_code = """
a: int = 10
b: int
    """
    AST_before = ast.parse(sample_code)
    AST_after = ast.parse('a = 10\nb')
    tree_changed = True
    #Test constructor
    test = VariablesAnnotationsTransformer()

    assert test.target == (3, 5)
    assert test.transform(AST_before) == TransformationResult(AST_after, tree_changed, [])

# Generated at 2022-06-25 23:00:21.647387
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Example tree
    node = ast.parse('a: int = 10')

    # Unit test
    VariablesAnnotationsTransformer.transform(node)

# Generated at 2022-06-25 23:00:28.456322
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # First unit test
    # Method transforms
    # a: int = 10
    # b: int
    # To
    # a = 10
    # b = None
    from typed_ast import ast3 as ast
    from copy import deepcopy
    tree = ast.parse("""
        a: int = 10
        b: int
    """)
    original_tree = deepcopy(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(new_tree) == ast.dump(ast.parse("""
    a = 10
    b = None
    """))
    assert original_tree == tree
    # Second unit test
    # Method transforms
    # a: int
    # To
    # a = None
    tree = ast.parse("a: int")
    new_tree

# Generated at 2022-06-25 23:00:33.786111
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''\
a: int  = 5
b: str = "ABC"
c: str
d: int = 10''') #type: ast.Module
    transformer = VariablesAnnotationsTransformer()
    transformer.transform(tree)
    # print(astunparse.unparse(tree))
    assert astunparse.unparse(tree) == 'a = 5\nb = \"ABC\"\nc = None  # type: str\nd = 10\n'

# Generated at 2022-06-25 23:00:41.757240
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.AnnAssign(target=ast.Name(id="VARIABLE_NAME",
                                          ctx=ast.Store,
                                          annotation=None,
                                          type_comment=None),
                          annotation=ast.Name(id="TYPE_NAME",
                                              ctx=ast.Load,
                                              annotation=None,
                                              type_comment=None),
                          value=None,
                          simple=2)

# Generated at 2022-06-25 23:00:43.245138
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:00:44.611602
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert BaseTransformer.__base__ is object


# Generated at 2022-06-25 23:00:50.462752
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.parse("def function():\n\tx: int = 10"))
    VariablesAnnotationsTransformer.transform(ast.parse("def function():\n\tx: int = 10\n\ty: int = 10"))
    VariablesAnnotationsTransformer.transform(ast.parse("def function():\n\tx: int"))
    VariablesAnnotationsTransformer.transform(ast.parse("def function():\n\tx: int\n\ty: int\n\t"))
    VariablesAnnotationsTransformer.transform(ast.parse("def function():\n\tis_dog: bool = animal.is_dog()"))

# Generated at 2022-06-25 23:00:51.599188
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
     assert isinstance(VariablesAnnotationsTransformer, object)
