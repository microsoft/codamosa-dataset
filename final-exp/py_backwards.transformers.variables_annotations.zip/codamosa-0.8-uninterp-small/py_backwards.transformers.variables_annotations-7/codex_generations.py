

# Generated at 2022-06-25 22:52:49.087808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer()



# Generated at 2022-06-25 22:52:49.806660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass


# Generated at 2022-06-25 22:52:50.541312
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer


# Generated at 2022-06-25 22:52:52.282364
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_ = VariablesAnnotationsTransformer()
    assert(variables_annotations_transformer_.target == (3, 5))

# Generated at 2022-06-25 22:52:53.206582
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()



# Generated at 2022-06-25 22:53:01.724369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_0 = ast.parse('a: int\nb: str\n', "exec")
    tree_0 = VariablesAnnotationsTransformer.transform(tree_0)
    assert tree_0.stats[0].targets[0].id == "a"
    assert tree_0.stats[1].targets[0].id == "b"
    tree_1 = ast.parse('a: int = 10\nb: str = "hello"\n', "exec")
    tree_1 = VariablesAnnotationsTransformer.transform(tree_1)
    assert tree_1.stats[0].targets[0].id == "a"
    assert tree_1.stats[1].targets[0].id == "b"

# Generated at 2022-06-25 22:53:04.222637
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_1 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:53:05.906129
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert hasattr(VariablesAnnotationsTransformer, "__init__")


# Generated at 2022-06-25 22:53:07.758335
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert hasattr(VariablesAnnotationsTransformer, "transform"), "Class VariablesAnnotationsTransformer lacks transform method"

# Generated at 2022-06-25 22:53:08.303273
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 22:53:14.738484
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import assert_transform, get_test_tree

    tree = get_test_tree('''
    a: int = 10
    b: int
    ''')
    expected_tree = get_test_tree('''
    a = 10
    b: int
    ''')
    assert_transform(VariablesAnnotationsTransformer, tree, expected_tree)

# Generated at 2022-06-25 22:53:21.158730
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v0 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
         simple=1)
    v1 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
         simple=0)
    assert VariablesAnnotationsTransformer.transform(v0) == TransformationResult(ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())], value=None, type_comment=ast.Name(id='int', ctx=ast.Load())), True,
        [])

# Generated at 2022-06-25 22:53:22.229101
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:53:26.401807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10\n""")

    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                annotation=ast.Name(id='int', ctx=ast.Load()),
                value=ast.Constant(value=10),
                simple=1)
    tree_changed = True
    pass

# Generated at 2022-06-25 22:53:31.324195
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    source = '''a: str
b: str = 10
c = 1
'''
    tree = astor.parse_tree(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree).strip() == 'a\nb = 10\nc = 1'

# Generated at 2022-06-25 22:53:32.208362
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:53:36.985366
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse("a: int = 10\nb: int")

    VariablesAnnotationsTransformer.transform(tree)

    # "a = 10"
    expected_tree = ast.parse("a = 10")

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-25 22:53:37.477728
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:53:43.115697
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astor.code_gen import to_source
    from .helpers import build_module

    source = '''a: int = 10\nb: int'''
    expected_source = '''a = 10'''
    module = build_module(source, target=(3, 5,))

    res = VariablesAnnotationsTransformer.transform(module)
    assert res.tree is not None
    assert res.tree_changed
    assert res.additional_imports == []
    assert to_source(res.tree) == expected_source

# Generated at 2022-06-25 22:53:46.446062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = "a: int = 10\nb: int"
    tree = ast.parse(code)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree == ast.parse("a = 10")

# Generated at 2022-06-25 22:53:54.319384
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    new_tree, changed = VariablesAnnotationsTransformer.transform(tree)
    expected = ast.parse('a = 10')
    assert ast.dump(new_tree) == ast.dump(expected)

# Generated at 2022-06-25 22:54:03.228049
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x: int = 10
    y: int = 20

    k = VariablesAnnotationsTransformer()

    # x and y are variables
    assert k.is_variable(x) == True
    assert k.is_variable(y) == True

    # x and y are not functions
    assert k.is_function(x) == False
    assert k.is_function(y) == False

    # test for target
    assert k.target == (3, 5)

    # test for transformation
    def function(a: int, b: int):
        c: int = 30

        if c > a:
            return b

    # tree is an ast object
    tree = ast.parse(function)

    # test for transform
    assert k.transform(tree) == True

# Generated at 2022-06-25 22:54:09.762206
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import unittest

    class TestExpressionReplacer(unittest.TestCase):
        def test_no_error(self):
            import astor
            from ..utils.helpers import replace_if_expression
            code = '''
            class A:
                    def foo(self, i: int) -> int:
                        if i == 10:
                            return i
                        elif i == 20:
                            return i
                        else:
                            return i
            '''
            class_a = astor.code_to_ast(code).body[0]
            assert not replace_if_expression(class_a)

    unittest.main()

# Generated at 2022-06-25 22:54:11.077508
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None) == None




# Generated at 2022-06-25 22:54:21.241071
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from unittest.mock import MagicMock
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import create_ast

    # Initialize transformer
    node = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()),
                         annotation=ast.Name(id="int"),
                         value=ast.Num(10),
                         simple=1)
    tree = MagicMock()
    find_patch = 'pythran.transformations.variables.annotations.find'
    find_mock = MagicMock()
    find_mock.return_value = [node]
    with patch(find_patch, new=find_mock):
        variables_annotations_transformer = VariablesAnnotationsTransformer(tree)

    #

# Generated at 2022-06-25 22:54:23.392547
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..import tree_transformers
    from .pull_annotations_to_assignment import PullAnnotationsToAssignmentTransformer

# Generated at 2022-06-25 22:54:27.002370
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse('a: int = 10\nb: int = 10')
    # When
    result = VariablesAnnotationsTransformer.transform(tree)
    # Then
    # This will test for function name and for return value of function
    assert result == ("""\n
a = 10\n""", True, [])


# Generated at 2022-06-25 22:54:37.109400
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1: with one variable
    a = ast.AnnAssign(annotation=ast.Subscript(
        value=ast.Name(id='List',
                       ctx=ast.Load()),
        slice=ast.Index(value=ast.Name(id='int',
                                       ctx=ast.Load())),
        ctx=ast.Load()),
                      target=ast.Name(id='a',
                                      ctx=ast.Store()),
                      value=ast.List(elts=[ast.Num(n=1)],
                                     ctx=ast.Load()),
                      simple=1)

# Generated at 2022-06-25 22:54:37.902336
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:43.282032
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    def f() -> int:
        a: int = 10
        b: int = 20
        c: int
        return b
    """
    )

    expected = ast.parse("""
    def f():
        a = 10
        b = 20
        return b
    """
    )
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(expected)
    assert result.changed == True

# Generated at 2022-06-25 22:54:53.844699
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import tree_from_str
    from .base import BaseTransformer


# Generated at 2022-06-25 22:55:02.189948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse(
        """
        class Test:
            def __init__(self, a: int = 10, b: int):
                self.a = a
                self.b = b
                c: int = 20
                print(c)
        """
    )
    VariablesAnnotationsTransformer.transform(module)

# Generated at 2022-06-25 22:55:03.425251
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)



# Generated at 2022-06-25 22:55:06.970118
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import print_tree
    node: ast.AST = ast.parse('''
    a: int = 10
    b: int
    ''', mode='exec')
    trans = VariablesAnnotationsTransformer()
    res = trans.transform(node)
    print(print_tree(res))
    assert(res)



# Generated at 2022-06-25 22:55:10.582423
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast # noqa

    class DummyParent(ast.AST):
        _fields = ('body',)
        body = [ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                              annotation=ast.parse('int', mode='eval'),
                              value=ast.Constant(value=None),
                              simple=0,
                              ),
                ]

# Generated at 2022-06-25 22:55:22.438321
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from . import helpers
    import textwrap
    from . import var_ann_test

    example = textwrap.dedent("""
    def foo(a: int = 10, b: int = '12') -> str:
        pass
    """)

    """
    NOTE: The following test does not work because typed_ast does not offer
    a good API for working with the AST. There are some helper functions in
    typed_ast\converter.py and type_comment.py as well as in typed_ast\ast3.py
    in the explore() function.
    """
    tree = helpers.parse_module(example)
    assert isinstance(tree, ast3.Module)
    assert tree.type_ignores == []

    assert isinstance(tree.body[0], ast3.FunctionDef)

# Generated at 2022-06-25 22:55:26.054941
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    module = ast.parse("""\
a: int = 10
b: int""", mode='exec')
    expected = ast.parse("""\
a = 10""", mode='exec')

    assert(VariablesAnnotationsTransformer.transform(module).tree == expected)

# Generated at 2022-06-25 22:55:28.962744
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer."""

# Generated at 2022-06-25 22:55:41.888385
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    class A(ast.AST):
        def __init__(self, r):
            self.r = r
            super().__init__()


# Generated at 2022-06-25 22:55:45.235107
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # pylint: disable=line-too-long
    # Test for constructor
    var = VariablesAnnotationsTransformer()
    assert isinstance(var, VariablesAnnotationsTransformer)
    # pylint: enable=line-too-long


# Generated at 2022-06-25 22:56:09.268640
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('''from typing import List
a: List[int] = [1, 2]
b: List[float]
c: str = "3"
''')
    expected_tree = ast.parse('''from typing import List
a = [1, 2]
b = List[float]
c = "3"
''')
    transformed_tree, _, _ = VariablesAnnotationsTransformer.transform(test_tree)
    assert transformed_tree == expected_tree

# Generated at 2022-06-25 22:56:11.499517
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("test_VariablesAnnotationsTransformer()")
    my_class = VariablesAnnotationsTransformer()
    print("Type: ", type(my_class))


# Generated at 2022-06-25 22:56:14.276790
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    s = 'x: int = 1'
    tree = ast.parse(s)
    out = str(VariablesAnnotationsTransformer.transform(tree))
    assert out == 'x = 1'

# Generated at 2022-06-25 22:56:15.627260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vt = VariablesAnnotationsTransformer()
    assert hasattr(vt, 'target') == True


# Generated at 2022-06-25 22:56:21.648903
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .parser import Parser
    from .transformer import transform
    import astunparse

    class A:
        v1: int = 10
        v2: str
        v3: bool


    transformed_tree = transform(Parser.parse_text(astunparse.unparse(ast.parse(inspect.getsource(A)))))

# Generated at 2022-06-25 22:56:31.116029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Unit test for VariablesAnnotationsTransformer class
    """
    # Given
    code = ast.parse(dedent(
        """
        def test():
            a: int = 10
            b: int
            c: int
        """
    ))
    # When
    result = VariablesAnnotationsTransformer.transform(code)
    # Then
    tree = result.tree
    print(ast.dump(tree))
    assert result.tree_changed

# Generated at 2022-06-25 22:56:35.215668
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_code     = '''a: int = 10\nb: int'''
    tree_expected = '''a = 10'''
    tree_actual = ast.parse(tree_code)
    tree_expected = ast.parse(tree_expected)
    tree_actual = VariablesAnnotationsTransformer.transform(tree_actual)

    assert tree_actual.code

# Generated at 2022-06-25 22:56:41.156136
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Case 1: type annotations for variables
    #      a: int = 10   ->      a = 10
    #      b: int        ->      b
    tree = ast.parse("a: int = 10\nb: int")
    transformer = VariablesAnnotationsTransformer()
    actual_result = transformer.transform(tree)
    expected_tree = ast.parse("a = 10\nb")
    assert actual_result.changed == True, "Transform does not work as excepted"
    assert str(expected_tree) == str(actual_result.tree), "Transform does not work as excepted"


# Generated at 2022-06-25 22:56:41.905079
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:56:46.492170
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    # a: int = 10
    # b: int
    tree = ast.parse("a: int = 10\nb: int\n", mode='exec')

    var_annotations_transformer = VariablesAnnotationsTransformer()
    result = var_annotations_transformer.transform(tree)
    assert(str(result.tree) == "a = 10\nb: int\n")
    assert(result.changed)

# Generated at 2022-06-25 22:57:42.638021
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("""a: int = 1 \nb: int \n""")

    assert tree == ast.parse("""a = 1 \nb = 2 \n""")

    tree = ast.parse(
        """def bar():        
            a: int = 1
            b: int
            print(a)
        """)

    assert tree == ast.parse(
        """def bar():        
            a = 1
            b = 2
            print(a)
        """)

# Generated at 2022-06-25 22:57:49.325957
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for VariablesAnnotationsTransformer."""
    # Only run this test under Python 3.5 or higher
    if sys.version_info < (3, 5):
        return

    from ..utils.source import source_to_unicode
    from .utils import compare_ast, compile_to_ast

    tree = compile_to_ast('''
    a: int = 10
    b: int
    ''')

    # convert to Python3.5 code
    VariablesAnnotationsTransformer.transform(tree)

    compare_ast(
        source_to_unicode(
            '''
        a = 10
        '''
        ),
        tree
    )

# Generated at 2022-06-25 22:57:55.613426
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-25 22:57:58.195091
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-25 22:58:01.867419
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert type(VariablesAnnotationsTransformer) is not type(BaseTransformer)
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert isinstance(VariablesAnnotationsTransformer.transform, classmethod)
    assert len(VariablesAnnotationsTransformer.transform.__code__.co_varnames) == 2

# Generated at 2022-06-25 22:58:06.866253
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('VAR: int = 10')
    tree_changed = VariablesAnnotationsTransformer.transform(node)
    assert isinstance(tree_changed, TransformationResult)
    # print(astor.to_source(tree_changed))
    assert astor.to_source(tree_changed.tree) == 'VAR = 10\n'
    assert tree_changed.tree_changed == True
    assert tree_changed.unresolved_variables == []

# Generated at 2022-06-25 22:58:14.342080
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import astor
    from ..utils.helpers import get_func_source
    expected_source = inspect.cleandoc(
        """   def foo():
        x: int
        a: int = 10
    """)
    source = inspect.cleandoc(
        """   def foo():
        x: int = 4
        a: int = 10
    """)
    r = astor.to_source(ast.parse(source))
    assert r == source
    ast_tree = ast.parse(source)
    print(astor.to_source(ast_tree))
    tree = ast_tree
    trans = VariablesAnnotationsTransformer
    res = trans.transform(tree)
    assert res.tree_changed
    r = astor.to_source(tree)
    assert r == expected_source


# Generated at 2022-06-25 22:58:22.313904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transform = VariablesAnnotationsTransformer.transform
    # Test against a simple example
    tree = ast.parse('a: int = 10\nb: int')
    new_tree, tree_changed, _ = transform(tree)
    assert tree_changed == True
    assert ast.dump(new_tree) == ast.dump(ast.parse('a = 10\n'))

    # Test if the compiler only changes the assignment outside of the body
    tree = ast.parse('def f():\n    a: int = 10')
    new_tree, tree_changed, _ = transform(tree)
    assert tree_changed == False
    assert ast.dump(tree) == ast.dump(new_tree)

    # Test if the compiler only changes the assignment outside of the body
    tree = ast.parse('def f():\n    a: int')


# Generated at 2022-06-25 22:58:25.768266
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import ast_parse
    from .transform import transform

    tree = ast_parse('a: int = 10\nb: int')
    new_tree = transform(tree, VariablesAnnotationsTransformer)
    expected = ast_parse('a = 10')
    assert ast.dump(new_tree) == ast.dump(expected)

# Generated at 2022-06-25 22:58:27.291927
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    x = VariablesAnnotationsTransformer.transform(tree)
    assert(x.changed == True)

# Generated at 2022-06-25 23:00:23.051953
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variable_annotation_transformer = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 23:00:23.836724
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:00:24.729266
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    cls = VariablesAnnotationsTransformer()
    assert cls.anotate is False

# Generated at 2022-06-25 23:00:31.308902
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..test_utils import roundtrip_unparse

    # TODO: replace with AnnotationAssign node once typed-ast supports it
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                         annotation=ast.Name(id='int', ctx=ast.Load()),
                         value=ast.Num(n=42))

    # TODO: replace with Assign node once typed-ast supports it
    expect = """
a = 42
    """
    tree = ast.Module([node])
    print(astor.to_source(tree))

    res = roundtrip_unparse(tree, VariablesAnnotationsTransformer)
    print(res)
    assert res == expect

# Generated at 2022-06-25 23:00:37.370746
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test class VariablesAnnotationsTransformer.

    Arguments
    ---------
        None
    """
    # Test importing of modules
    import ctypes
    ctypes.CDLL("libc.so.6", use_errno=True)


    # Test constructor of class VariablesAnnotationsTransformer
    a = VariablesAnnotationsTransformer()

    # Test method transform of class VariablesAnnotationsTransformer
    @VariablesAnnotationsTransformer.transform
    def _(a: int = 10, b: int = 20, c: int = 30):
        pass

# Program to test class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:00:45.832673
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = "a: int = 10; b: int; c: str = 'cd'"
    tree = ast.parse(input_code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=10), type_comment="int"), Assign(targets=[Name(id="b", ctx=Store())], value=NameConstant(value=None), type_comment="int"), Assign(targets=[Name(id="c", ctx=Store())], value=Str(s="cd"), type_comment="str")])'


# Generated at 2022-06-25 23:00:46.892032
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-25 23:00:49.472726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code_to_test = """# test code
a: int = 10
b: int
"""
    tree = ast.parse(code_to_test)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == """# test code
pass"""

# Generated at 2022-06-25 23:00:50.462020
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:00:58.249833
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    last = ast.AnnAssign(target=ast.Name(id='n1', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
                             value=None, simple=0)
    n2 = ast.AnnAssign(target=ast.Name(id='n2', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
                        value=ast.Num(n=1), simple=0)
    ast_5_5 = ast.Module(body=[last, n2])
    ast_3_5 = ast.Module(body=[last, n2])