

# Generated at 2022-06-25 22:52:44.630494
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    except NameError:
        rai

# Generated at 2022-06-25 22:52:46.077454
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:52:48.369570
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_1 = ast.parse('')
    tree_2 = ast.parse('')
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree_1)
    assert result.code == tree_2


# Generated at 2022-06-25 22:52:50.113088
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Constructor of class VariablesAnnotationsTransformer without parameter
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()

# Ad-hoc test for method transform

# Generated at 2022-06-25 22:52:54.202487
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert isinstance(variables_annotations_transformer_0, BaseTransformer)
    assert isinstance(variables_annotations_transformer_0, ast.AST)

# Generated at 2022-06-25 22:52:55.666827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_1 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:52:57.028325
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  variables_annotations_transformer_0 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:52:58.602292
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Unit test for constructor
    test_case_0()

# Generated at 2022-06-25 22:52:59.470552
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:03.116029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_0 = ast.parse("a: int = 10\nb: int")
    tree_changed_0, _, _ = VariablesAnnotationsTransformer.transform(ast_0)
    assert tree_changed_0

# Generated at 2022-06-25 22:53:11.452347
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer is not None


# Generated at 2022-06-25 22:53:15.085807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    result = variables_annotations_transformer_0.transform(tree)
    assert hasattr(result, 'tree')
    assert hasattr(result, 'changed')
    assert hasattr(result, 'messages')

# Generated at 2022-06-25 22:53:16.118243
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer



# Generated at 2022-06-25 22:53:18.083189
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert (variables_annotations_transformer_0.target == (3, 5))

# Generated at 2022-06-25 22:53:19.874312
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variable_annotations_transformer = VariablesAnnotationsTransformer()
    assert variable_annotations_transformer.target == (3, 5)


# Generated at 2022-06-25 22:53:20.926861
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:22.573422
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer()
    assert class_.target == (3, 5)


# Generated at 2022-06-25 22:53:23.985114
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:53:25.414206
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:53:26.835119
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:53:40.296647
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_source
    from ..utils.visitor import generate_ast

    source = generate_source(
        '''
        a: int = 10
        b: int
        '''
    )

    tree = generate_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree)
    code_obj = compile(tree, '<string>', 'exec')
    eval(code_obj)

    if not isinstance(a, int):
        raise ValueError('Variable `a` should be an int')
    if not isinstance(b, int):
        raise ValueError('Variable `b` should be an int')

    if a != 10:
        raise ValueError('Variable `a` should equal to 10')

# Generated at 2022-06-25 22:53:42.960585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import_ast = ast.parse("")
    transformer = VariablesAnnotationsTransformer(import_ast)
    assert transformer.target == (3, 5)
    assert transformer.transform(import_ast) is not None


# Generated at 2022-06-25 22:53:50.061573
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test class VariablesAnnotationsTransformer
    """
    from ..utils.helpers import scan
    from ..utils.context import Context
    from textwrap import dedent

    print('=== test_VariablesAnnotationsTransformer ===')

    source = dedent('''
    a: int = 10
    b: int
    ''')

    expected = dedent('''
    a = 10

    ''')

    result, num_changes = scan(source, VariablesAnnotationsTransformer)
    assert num_changes == 2
    assert result == expected

# Generated at 2022-06-25 22:53:53.463138
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer.transform
    assert t(ast.parse('a: int')) == t(ast.parse('a'))
    assert t(ast.parse('a: int = 10')) == t(ast.parse('a = 10'))

# Generated at 2022-06-25 22:54:00.850699
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import render_module
    from .. import transformers
    tree = ast.parse('a: int = 10\nb: int')
    new_tree, _, _ = VariablesAnnotationsTransformer.transform(tree)
    code = render_module(new_tree)
    assert code == 'a = 10'
    # Test calling all transformers at once
    tree = ast.parse('a: int = 10\nb: int')
    tree, _, _ = transformers.transform(tree, target=(3, 5))
    code = render_module(tree)
    assert code == 'a = 10'

# Generated at 2022-06-25 22:54:03.600797
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer(): # Unit test for VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.transform(ast.parse("a:int=10; b:int; c: int = 12", "<test>", "exec")) == TransformationResult(ast.parse("a=10; b; c = 12", "<test>", "exec"), True, [])

# Generated at 2022-06-25 22:54:07.698134
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = '''
a: int = 10
b: int
c = 20
    '''
    expected = '''
a = 10
c = 20
    '''
    # When
    result = VariablesAnnotationsTransformer.transform(code)

    # Then
    assert result.changed
    assert result.code == expected



# Generated at 2022-06-25 22:54:12.453347
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # When I have code without annotations
    code = 'a = 3'

    # And I run it through the constructor of class VariablesAnnotationsTransformer
    a = VariablesAnnotationsTransformer(code)

    # Then the code should be equal to 'a = 3'
    assert a.code == 'a = 3'


# Generated at 2022-06-25 22:54:14.496217
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int
    c: int = 10
    d: int
    e: int = 10
    f: int

# Generated at 2022-06-25 22:54:23.391129
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    from utils.helpers import debug_ast

    a = ast.AnnAssign(target=ast.Name('a', ast.Store()),
                      annotation=ast.Name('int', ast.Load()),
                      value=ast.Constant(10),
                      simple=1)
    b = ast.AnnAssign(target=ast.Name('b', ast.Store()),
                      annotation=ast.Name('int', ast.Load()),
                      value=None,
                      simple=0)
    body

# Generated at 2022-06-25 22:54:35.302652
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    construct = VariablesAnnotationsTransformer()

    assert construct.__class__.__name__ == "VariablesAnnotationsTransformer"
    assert construct.target == (3, 5)


# Generated at 2022-06-25 22:54:36.953187
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tester = VariablesAnnotationsTransformer()
    assert tester.target == (3,5)


# Generated at 2022-06-25 22:54:39.565413
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import tree_from_str
    tree = tree_from_str('''
        a: int = 10
        b: int
    ''')
    print(VariablesAnnotationsTransformer.transform(tree))

# Generated at 2022-06-25 22:54:47.309883
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
        """
from typing import Dict
from datetime import datetime
a: Dict[str, Dict[str, Dict[str, str]]] = {}
b: Dict[str, Dict[str, Dict[str, str]]]
        """
    )

    changed_tree = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(changed_tree.tree, ast.Module)
    assert len(changed_tree.tree.body) == 4
    assert isinstance(changed_tree.tree.body[0], ast.ImportFrom)
    assert isinstance(changed_tree.tree.body[1], ast.ImportFrom)
    assert isinstance(changed_tree.tree.body[2], ast.Assign)

# Generated at 2022-06-25 22:54:52.716249
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    # Test the constructor of VariablesAnnotationsTransformer
    test_instance = VariablesAnnotationsTransformer()
    assert test_instance.__class__.__name__ == "VariablesAnnotationsTransformer"
    assert isinstance(test_instance, BaseTransformer) == True


if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:55:01.081412
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    import numpy as np
    from transformations.utils.ast_helpers import ast_to_source

    # Node Before:
    #   a: int = 10
    before = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Num(n=10, ctx=ast.Load()),
        simple=1
    )

    # Node After:
    #   a = 10
    after = ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.Num(n=10, ctx=ast.Load())
    )

    # Test that the node after is equivalent to the node before


# Generated at 2022-06-25 22:55:07.194938
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse("""def foo():
        a: int = 10
        b: int""")

    target = (3, 5)

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree.body[0].body == [ast.Assign(targets=[ast.Name('a', ast.Store())], value=ast.Constant(10, kind=None), type_comment=ast.Name('int', ast.Load()))]
    assert result.tree_changed == True
    assert target == (3, 5)

# Generated at 2022-06-25 22:55:11.000604
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """def test():
        d: int"""
    assert(VariablesAnnotationsTransformer.transform(ast.parse(code)).code ==
            """def test():
    pass""")
    code = """def test():
        d: int
        d = 10"""
    assert(VariablesAnnotationsTransformer.transform(ast.parse(code)).code ==
            """def test():
    d = 10""")

# Generated at 2022-06-25 22:55:21.609748
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_base import BaseTransformerTest
    class Test(BaseTransformerTest):
        target = VariablesAnnotationsTransformer
        input = """a: int = 10"""
        expected_output = "a = 10"
        expected_errors = []
        expected_warnings = []
    o = Test()
    o.test_transform()
    class Test(BaseTransformerTest):
        target = VariablesAnnotationsTransformer
        input = """a: int = 10\nb: int"""
        expected_output = "a = 10"
        expected_errors = []
        expected_warnings = ['Assignment outside of body']
    o = Test()
    o.test_transform()

# Generated at 2022-06-25 22:55:24.932469
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(VariablesAnnotationsTransformer.transform(
        ast.parse("""
        x: int
        y: int = 10
        """)
    ) == (
        ast.parse("""
        x
        y = 10
        """),
        True,
        [],
    ))

# Generated at 2022-06-25 22:55:47.920020
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected = []
    variables_annotations = [
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10),
                      simple=1)]
    actual = []
    actual.append(VariablesAnnotationsTransformer.transform(variables_annotations)[0])
    assert expected == actual

# Generated at 2022-06-25 22:55:53.466398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node_one = ast.parse('a: int = 10')
    node_two = ast.parse('b: int')

    transformer = VariablesAnnotationsTransformer()
    x = ast.FunctionDef(args=ast.arguments(args=[],vararg=None,
                                kwonlyargs=[], kw_defaults=[], kwarg=None,
                                defaults=[]),body=[node_one, node_two], decorator_list=[])

    result = transformer.transform(x)
    assert result._tree_changed == True and result._tree.body[0].body[0].value.n == 10 and result._tree.body[0].body[1].value is None


# Generated at 2022-06-25 22:55:58.236995
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10""")
    expected_transformed_tree = ast.parse("""a = 10""")
    transformed_tree, tree_changed, _ = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert transformed_tree == expected_transformed_tree

# Generated at 2022-06-25 22:56:03.119637
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_string = """
        a: int = 10
        b: int
        """
    og_module = ast.parse(input_string)
    module = copy.deepcopy(og_module)

    VariablesAnnotationsTransformer.transform(module)

    assert_equal(str(module), """\
a = 10
""")
    assert_equal(ast.dump(module), ast.dump(og_module))

# Generated at 2022-06-25 22:56:08.830679
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import test_helpers
    from .test_utils import run_transformer_test
    import textwrap
    before = textwrap.dedent('''\
        a: int = 10
        b: int
    ''')
    after = textwrap.dedent('''\
        a = 10
    ''')
    run_transformer_test(test_helpers.parse_to_ast_object(before),
                         test_helpers.parse_to_ast_object(after),
                         [VariablesAnnotationsTransformer])

# Generated at 2022-06-25 22:56:17.975591
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # BEFORE:
    # a: int = 10
    # b: int
    mod = ast.Module(body=[
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10)),
        ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=None)
    ])

    # AFTER:
    # a = 10

# Generated at 2022-06-25 22:56:23.652887
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    input_code = "a: int = 10\n" \
                 "b: int"
    input_ast = ast.parse(input_code)

    expected_code = "a = 10\n" \
                    "b"
    expected_ast = ast.parse(expected_code)

    # Act
    actual_ast = VariablesAnnotationsTransformer.transform(input_ast).tree

    # Assert
    assert ast.dump(actual_ast) == ast.dump(expected_ast)

# Generated at 2022-06-25 22:56:27.484274
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = ast.parse('''
        a: int = 10
        b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(t)
    assert ast.dump(result.tree) == ast.dump(
        ast.parse('''
            a = 10
        ''')
    )

# Generated at 2022-06-25 22:56:36.339563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_string = """
a: int = 10
b: int = 11
c: int = 12
d = 20
e = 21
f = 22
        """
    tree = ast.parse(ast_string)
    tree = VariablesAnnotationsTransformer.transform(tree).tree


# Generated at 2022-06-25 22:56:37.644345
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert hasattr(VariablesAnnotationsTransformer, 'transform')
    assert callable(VariablesAnnotationsTransformer.transform)

# Generated at 2022-06-25 22:57:29.699978
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    source = 'a: int = 10\nb: int'
    tree = ast.parse(source)
    transformer = VariablesAnnotationsTransformer()
    transformed_ast, tree_changed = transformer.transform(tree)
    assert tree_changed == True
    source_transformed = 'a = 10\nb'
    assert ast.dump(transformed_ast) == ast.dump(ast.parse(source_transformed))
    # Test Negative
    source = 'a = 10\nb'
    tree = ast.parse(source)
    transformer = VariablesAnnotationsTransformer()
    transformed_ast, tree_changed = transformer.transform(tree)
    assert tree_changed == False
    source_transformed = 'a = 10\nb'
    assert ast.dump(transformed_ast) == ast

# Generated at 2022-06-25 22:57:30.944128
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert callable(VariablesAnnotationsTransformer)

# Generated at 2022-06-25 22:57:39.675051
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('x: int = 0')
    t = VariablesAnnotationsTransformer()
    result = t.transform(tree)

    assert isinstance(result, TransformationResult)
    assert result.tree_changed
    assert len(result.issues) == 0
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree, ast.Module)

    tree = ast.parse('x: int')
    t = VariablesAnnotationsTransformer()
    result = t.transform(tree)

    assert isinstance(result, TransformationResult)
    assert result.tree_changed
    assert len(result.issues) == 0
    assert isinstance(result.tree, ast.AST)
    assert isinstance(result.tree, ast.Module)


# Generated at 2022-06-25 22:57:41.673122
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:57:45.464879
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    new_tree = VariablesAnnotationsTransformer.transform(tree).new_tree

    assert ast.dump(new_tree) == 'Module(body=[Assign(targets=[Name(id=\"a\", ctx=Store())], value=Num(n=10), type_comment=Constant(value=\"int\", kind=None))])'


# Generated at 2022-06-25 22:57:53.055042
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..utils.helpers import to_source
    from ..utils.tree import compare_ast

    # Test 1 - Constructor
    tree = ast3.parse('''
        b: int = 10
        c: int
        ''')
    transformer = VariablesAnnotationsTransformer(tree)
    assert transformer is not None

    # Test 2 - Compile the source with annotation
    tree = ast3.parse('''
        b: int = 10
        c: int
        ''')
    transformer = VariablesAnnotationsTransformer(tree)
    new_tree = transformer.transform()

    expected_tree = ast3.parse('''
        b = 10
        ''')


# Generated at 2022-06-25 22:57:58.727136
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """ i: int = 10
               j: int
               """
    tree = ast.parse(code)
    expected = ast.parse("""i = 10""")
    transformer = VariablesAnnotationsTransformer()
    res = transformer.transform(tree)
    assert ast.dump(res.tree) == ast.dump(expected)

# Generated at 2022-06-25 22:57:59.453287
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:00.238941
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:04.882614
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    before = get_ast('''a: str = "hi"''')
    after = get_ast('''a = "hi"''')
    var = VariablesAnnotationsTransformer()
    transformed_code = var.transform(before)
    assert not transformed_code.tree_changed
    assert_equals(transformed_code.tree, after)

# Generated at 2022-06-25 22:59:53.584601
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:00:01.188072
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test target not matches
    with pytest.raises(NotImplementedError):
        VariablesAnnotationsTransformer.transform(None, (3, 4))

    # test tree not changed
    code = 'a = 0'
    tree = ast.parse(code)
    transformed_tree = VariablesAnnotationsTransformer.transform(tree)
    assert transformed_tree.tree == tree

    # test tree changed
    code = 'a: int = 0'
    tree = ast.parse(code)
    removed_tree = ast.parse('a = 0')
    transformed_tree = VariablesAnnotationsTransformer.transform(tree)
    assert transformed_tree.tree == removed_tree

    code = 'a: int'
    tree = ast.parse(code)
    removed_tree = ast.parse('\n')
    transformed_tree

# Generated at 2022-06-25 23:00:03.870194
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = ast.parse('a: int = 10')
    t2 = VariablesAnnotationsTransformer.transform(t)
    t3 = ast.parse('a = 10')
    assert t3.body[0].__dict__ == t2.tree.body[0].__dict__

# Generated at 2022-06-25 23:00:09.639024
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """a: int = 10
    b: int"""
    node = ast.parse(code, 'test', 'exec')

    result = VariablesAnnotationsTransformer.apply_on(node)

    assert(len(result.tree.body) == 2)
    assert(isinstance(result.tree.body[0], ast.Assign))
    assert(isinstance(result.tree.body[1], ast.Assign))
    assert(result.tree.body[0].targets[0].id == 'a')
    assert(result.tree.body[1].targets[0].id == 'b')

# Generated at 2022-06-25 23:00:13.779888
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int\nc: bool', mode='exec')
    transformer = VariablesAnnotationsTransformer()
    new_tree, changed = transformer.transform(tree)
    codeobj = compile(new_tree, '<test>', 'exec')
    globals = {}
    locals = {}
    exec(codeobj, globals, locals)
    assert changed == True
    assert locals['a'] == 10
    assert locals['b'] == None
    assert locals['c'] == False

# Generated at 2022-06-25 23:00:19.223164
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    from astunparse import dump as dump_reparse
    sample = """
            x: int = 10
            """
    ast_tree = ast.parse(sample)
    expected_tree = ast.parse("""
    x = 10
    """)
    tree_changed, _, _ = VariablesAnnotationsTransformer.transform(ast_tree)
    assert tree_changed
    assert dump(ast_tree) == dump(expected_tree)
    assert dump_reparse(ast_tree) == dump_reparse(expected_tree)

# Generated at 2022-06-25 23:00:20.774507
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    c = VariablesAnnotationsTransformer()
    assert isinstance(c, VariablesAnnotationsTransformer)
    assert c.target == (3, 5)


# Generated at 2022-06-25 23:00:21.346904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 23:00:23.875422
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('''
a: int = 10
b: int
        ''')
    ).transformed == ast.parse('''
a = 10
    ''')



# Generated at 2022-06-25 23:00:27.270942
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("Testing VariablesAnnotationsTransformer")
    tree = ast.parse("x: int = 10")
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(tree, ast.AST)
    assert isinstance(tree.body[0], ast.Assign)

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()