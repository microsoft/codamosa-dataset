

# Generated at 2022-06-25 22:52:46.380305
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert(variables_annotations_transformer.target == (3, 5))


# Generated at 2022-06-25 22:52:47.715164
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert isinstance(t, BaseTransformer)


# Generated at 2022-06-25 22:52:49.182567
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert type(variables_annotations_transformer) == VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:52:50.965903
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        assert variables_annotations_transformer_0
    except NameError:
        pytest.fail("Object not defined. Check test_case_0")


# Generated at 2022-06-25 22:52:51.849030
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)


# Generated at 2022-06-25 22:52:53.457990
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer is not None

# Generated at 2022-06-25 22:52:54.586973
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-25 22:52:57.216073
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    assert variables_annotations_transformer_0.transform(tree) == \
        TransformationResult(ast.parse("a = 10\n"), True, [])

# Generated at 2022-06-25 22:53:00.069431
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_annot_t = VariablesAnnotationsTransformer()
    var_annot_t = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:53:01.268751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_1 = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:05.970023
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('name:str = "bob"')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result.tree.body[0], ast.Assign)

# Generated at 2022-06-25 22:53:12.542595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import transform_and_reimport
    from .test_transformers import TEST_CODE_3
    result = transform_and_reimport(VariablesAnnotationsTransformer, TEST_CODE_3)
    assert 'def main():' in str(result)
    assert 'def foo():' in str(result)
    assert 'def super_long_function_name():' in str(result)
    assert '"hello"' in str(result)
    assert 'a = 10' in str(result)
    assert 'b' not in str(result)

# Generated at 2022-06-25 22:53:13.996722
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    instance = VariablesAnnotationsTransformer()
    assert instance.target == (3,5)


# Generated at 2022-06-25 22:53:15.960510
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #Tests for constructor
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5)

# Generated at 2022-06-25 22:53:20.470323
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_program = """\
                def test(a:int = 10, b :int = 20) -> int:
                    return a+b
                """
    expected_program = """\
                def test(a=10,b=20):
                    return a+b
                """
    with open('test.py', 'w') as file:
        file.write(input_program)
    actual_program = VariablesAnnotationsTransformer.transform_file('test.py', [])
    assert(str(actual_program) == expected_program)

# Generated at 2022-06-25 22:53:24.242352
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer."""
    module = ast.parse('a: int\nb: int = 10\n')
    tree = VariablesAnnotationsTransformer.transform(module)
    assert (ast.dump(tree) == '<_ast.Module object at 0x7fd9b9a2a710>')

# Generated at 2022-06-25 22:53:32.671372
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..utils import compile_backend
    code = "a: int = 3"
    node = ast3.parse(code, mode='exec')
    ast3.fix_missing_locations(node)
    tree_changed, errors, node, code = compile_backend(node, code,
                                                       backend='VariablesAnnotationsTransformer')
    assert errors == []
    assert tree_changed == True
# ============================================================================================

# ============================================================================================
"""
The purpose of the ClassDefTransformer is to transform the class definition:
    class A:
        x: int
    To an empty class definition
    class A:
        pass
"""



# Generated at 2022-06-25 22:53:34.054090
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-25 22:53:41.808012
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  # Creating instance of VariablesAnnotationsTransformer
  var_annotations_transformer = VariablesAnnotationsTransformer()
  # Creating instance of ast.AnnAssign
  node = ast.AnnAssign(
      target=ast.Name(id='a', ctx=ast.Store()),
      annotation=ast.Name(id='int', ctx=ast.Load()),
      value=ast.Num(n=10))
  # Creating instance of ast.Module
  tree = ast.Module(body=[node])
  # Testing if the output of transform function is equal to ast.Module
  assert isinstance(var_annotations_transformer.transform(tree)[0], ast.Module)
  # Testing if the output of transform function is equal to ast.Expr

# Generated at 2022-06-25 22:53:45.929075
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse("""
x: int
x: int = 42
    """)
    tree = VariablesAnnotationsTransformer.transform(module)
    assert(ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=42))])")

# Generated at 2022-06-25 22:54:00.048131
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:54:06.496715
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import __main__ as main
    import ast
    import re
    from pathlib import Path

    if not hasattr(main, '__file__'):
        raise ImportError('__main__ did not have __file__ attribute')

    if not hasattr(main, '__loader__'):
        raise ImportError('__main__ did not have __loader__ attribute')

    if not isinstance(main.__loader__, Path):
        raise TypeError('__main__.__loader__ was not a pathlib path')

    path = str(main.__loader__.absolute())
    if not re.search(r"BreadPy\\transformers", path):
        raise ValueError('Program appears to not be running from inside of BreadPy')

    f = open(path, 'r')

    f.readline()
    f.read

# Generated at 2022-06-25 22:54:09.163490
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(x)
    assert ast.dump(tree) == ast.dump(ast.parse('a = 10'))



# Generated at 2022-06-25 22:54:10.363772
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-25 22:54:19.523409
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import pytest
    import sys
    import pathlib
    sys.path.append(str(pathlib.Path(__file__).parent.parent))
    from ..utils.helpers import parse_ast

    tests = [
        ('a: int = 10', 'a = 10'),
        ('a: int = 10\nb: int', '')
    ]

    for code, expected_code in tests:
        tree = parse_ast(code)
        tr = VariablesAnnotationsTransformer.transform(tree)
        assert tr.tree is not None
        assert tr.error_log == []
        assert True if tr.changed else False

        assert expected_code == astor.to_source(tr.tree)

# Generated at 2022-06-25 22:54:25.253784
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_to_ast
    from ..visitors.class_visitor import ClassVisitor
    from .ann_to_typehints_transformer import AnnToTypehintsTransformer

    code = """
    a: int = 10
    b: int
    """

    tree = parse_to_ast(code)
    ClassVisitor().visit(tree)
    AnnToTypehintsTransformer.transform(tree)
    VariablesAnnotationsTransformer.transform(tree)

    assert code == compile(tree, '', 'exec')

# Generated at 2022-06-25 22:54:31.121009
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    tree = astor.parse_file("../example/explicit_annotation.py")
    
    print("Before transform: \n")
    print(astor.to_source(tree))

    trans = VariablesAnnotationsTransformer()
    new_tree = trans.transform(tree)

    print("After transform: \n")
    print(astor.to_source(new_tree))

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:54:40.102317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(annotation=ast.Name(id='int', ctx=ast.Load()),
                      target=ast.Name(id='a', ctx=ast.Store()),
                      value=ast.Num(n=10))
    b = ast.AnnAssign(annotation=ast.Name(id='int', ctx=ast.Load()),
                      target=ast.Name(id='b', ctx=ast.Store()))

    # expected
    a_exp = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))

# Generated at 2022-06-25 22:54:42.629792
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')

    transformer = VariablesAnnotationsTransformer()
    transformed = transformer.transform(tree)
    #print(transformed.tree.body[0])

# Generated at 2022-06-25 22:54:45.244177
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''a: int\nb: int = 10''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == ast.parse('''a: int\nb = 10''')


# Generated at 2022-06-25 22:55:01.307497
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10), simple=1)
    node2 = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))
    print(astor.to_source(node1))
    print(astor.to_source(node2))

# Generated at 2022-06-25 22:55:03.464082
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_test = VariablesAnnotationsTransformer()
    assert class_test.target == (3, 5)
    assert hasattr(class_test, 'transform')

# Generated at 2022-06-25 22:55:04.270899
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:55:09.140740
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    # Sample code
    code = """a: int = 10
b: int"""

    # Expected output
    expected_code = """a = 10"""

    # Convert the code to an AST
    tree = ast.parse(code)

    # Apply the transformation
    result = VariablesAnnotationsTransformer.transform(tree)
    new_tree = result.tree

    # Convert the AST to code
    output = astunparse.unparse(new_tree)

    # Compare the output with the expected output
    assert output == expected_code

# Generated at 2022-06-25 22:55:20.868863
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    a: int = 1
    b: str = 2
    c: A = 1
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-25 22:55:24.192248
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Tests that the constructor of an instance of  VariablesAnnotationsTransformer works as expected"""
    transformer = VariablesAnnotationsTransformer()
    assert (transformer.target == (3, 5)) is True

# Unit tests for transform method of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:55:25.311519
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer(3,5) is not None

# Generated at 2022-06-25 22:55:31.605018
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # here we mannually construct a simple AST tree with one assignment
    parent = ast.Module(body=[
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10), simple=1)
    ])
    # then we pass the AST tree to the above VariablesAnnotationsTransformer
    res, _, _ = VariablesAnnotationsTransformer.transform(parent)
    # finally, we check the result
    assert (isinstance(res.body[0], ast.Assign))
    assert (res.body[0].targets[0].id == 'a')
    assert (res.body[0].type_comment == 'int')

# Generated at 2022-06-25 22:55:44.282967
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import random
    n = random.randint(1, 3)
    a = ast.parse("a : int = 10")
    b = a.body[0]
    assert isinstance(b, ast.AnnAssign)
    a = ast.parse("a: int")
    b = a.body[0]
    assert isinstance(b, ast.AnnAssign)
    a = ast.parse("a : int = 10; a : int;")
    b = a.body[0]
    assert isinstance(b, ast.AnnAssign)
    assert b.annotation.id == 'int'
    a = ast.parse("a : int = 10\na : int")
    assert a.body[0].annotation.id == 'int'
    assert a.body[1].annotation.id == 'int'


# Generated at 2022-06-25 22:55:49.933193
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = ast.parse('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(source).tree

    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=10)), AnnAssign(target=Name(id=\'b\', ctx=Store()), annotation=NameConstant(value=int), value=None, simple=1)])'

# Generated at 2022-06-25 22:56:16.088333
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    code = "a: int = 10"
    node = ast.parse(code)
    assert isinstance(node, ast.Module)
    node = VariablesAnnotationsTransformer.transform(node).tree
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Assign)
    assert isinstance(node.body[0].targets[0], ast.Name)
    assert node.body[0].targets[0].id == "a"
    assert isinstance(node.body[0].value, ast.Num)
    assert node.body[0].value.n == 10
    assert node.body[0].type_comment == "int"

# Generated at 2022-06-25 22:56:26.242812
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    # test simple case with one variable
    var_assign = ast.parse(
        textwrap.dedent("""
            a: int = 10
        """),
        mode='eval'
    )
    vart = VariablesAnnotationsTransformer()
    result = vart.transform(var_assign)
    assert isinstance(result.tree, ast.AST)

    # test case with multiple variables
    var_assign = ast.parse(
        textwrap.dedent("""
            a: int = 10
            b: int = 5
        """),
        mode='eval'
    )
    vart = VariablesAnnotationsTransformer()
    result = vart.transform(var_assign)
    assert isinstance(result.tree, ast.AST)

    # test case with no annotation
    var_assign = ast

# Generated at 2022-06-25 22:56:30.989820
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import ast_to_str

    # a: int = 2
    tree = ast.parse("a: int = 2")

    # a = 2
    expected = ast.parse("a = 2")

    res = VariablesAnnotationsTransformer.transform(tree)

    assert res
    assert ast_to_str(expected) == ast_to_str(res)

# Generated at 2022-06-25 22:56:39.185733
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test removing variable annotations
    node = ast.parse("a:int = 1\nb:int")
    t = VariablesAnnotationsTransformer()
    new_tree = t.transform(node)
    assert(str(new_tree) == "a = 1\n")

    # Test removing variable annotations and typed_dict initializations
    node = ast.parse("a:int = 1\nb:int")
    t = VariablesAnnotationsTransformer()
    new_tree = t.transform(node)
    assert(str(new_tree) == "a = 1\n")

    # Test removing variable annotations and typed_dict initializations
    node = ast.parse("a:int = 1\nd:typing.Dict[bool, int] = {True: 1, False: 0}")
    t = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:56:39.952479
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:56:47.402331
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 30
    b = 40
    c: int = 50
    e = 60
    statement = ast.parse('a: int = 30\nb = 40\nc: int = 50\ne = 60')
    assert isinstance(statement, ast.Module)
    assert isinstance(statement.body[0], ast.AnnAssign)
    assert isinstance(statement.body[1], ast.Assign)
    assert isinstance(statement.body[2], ast.AnnAssign)
    assert isinstance(statement.body[3], ast.Assign)
    assert statement.body[0].target.id == 'a'
    assert statement.body[1].targets[0].id == 'b'
    assert statement.body[2].target.id == 'c'

# Generated at 2022-06-25 22:56:48.733713
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    r = VariablesAnnotationsTransformer(3, 5)
    assert r.target == (3, 5)


# Generated at 2022-06-25 22:56:50.789938
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    test_variables = transformer.transform()
    assert_equals(test_variables.code, 'a = 10\n')

# Generated at 2022-06-25 22:56:54.716250
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Creation of an instance of the class VariablesAnnotationsTransformer
    test_instance_VariablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    assert test_instance_VariablesAnnotationsTransformer.target == (3, 5), "The target should be (3, 5)"
    assert test_instance_VariablesAnnotationsTransformer.target_python_version == (3, 5), "The target_python_version should be (3, 5)"

# Generated at 2022-06-25 22:57:02.000350
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("""x: int""").body[0]) == \
    TransformationResult(ast.parse("""x: int"""), False, [])

    assert VariablesAnnotationsTransformer.transform(ast.parse("""x: int = 42""").body[0]) == \
    TransformationResult(ast.parse("""x = 42"""), True, [])

    assert VariablesAnnotationsTransformer.transform(ast.parse("""a: int; b:int""").body[0]) == \
    TransformationResult(ast.parse("""a: int; b:int"""), False, [])


# Generated at 2022-06-25 22:57:58.068478
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from unittest import TestCase
    import astor
    from typed_ast import ast3 as ast


# Generated at 2022-06-25 22:58:02.313165
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\n'
                     'b: int\n')

    transformer = VariablesAnnotationsTransformer()
    (program, tree_changed) = transformer.transform(tree)

    # Check if tree changed
    assert (tree_changed == True)

    # Check if tree was updated
    assert(ast.dump(program) == ast.dump(ast.parse('a = 10\n')))

# Generated at 2022-06-25 22:58:05.814959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int = 20
c = 30
""")
    transform = VariablesAnnotationsTransformer.transform(tree)
    assert transform.tree_changed
    assert str(transform.tree) == tree.body[0].__str__() == "c = 30"



# Generated at 2022-06-25 22:58:13.714130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")).tree_changed == True
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")).tree_changed == False
    assert VariablesAnnotationsTransformer.transform(ast.parse("b: str = 10")).tree_changed == True
    assert VariablesAnnotationsTransformer.transform(ast.parse("b: str")).tree_changed == False
    assert VariablesAnnotationsTransformer.transform(ast.parse("c: float = 10")).tree_changed == True
    assert VariablesAnnotationsTransformer.transform(ast.parse("c: float")).tree_changed == False
    assert VariablesAnnotationsTransformer.transform(ast.parse("d: bool = False")).tree_changed == True

# Generated at 2022-06-25 22:58:18.461604
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    code = '''
    try:
        a: int = 10
        b: int
    except:
        pass
    '''
    tree = ast.parse(code)
    transform = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(transform[0]) == '''
    try:
        a = 10
        b: int
    except:
        pass
    '''


# Unit test if an annotated variable is outside of a body

# Generated at 2022-06-25 22:58:26.424355
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..pipeline import TransformationPipeline
    from ..utils.source import Source
    import ast as pyast
    import typed_ast.ast3 as typed_pyast

    class Dummy(pyast.AST):
        _fields = ()
        _attributes = ()

        def __init__(self):
            pass

    source = Source("""
    from typing import List
    x: int = 10
    y: List[int] = [1, 2, 3]
    z: str
    """)

    expected_tree = TransformationPipeline(source, [VariablesAnnotationsTransformer()]).transform()

    # pyre-fixme[11]: Annotation `typed_pyast.Module` is not defined as a type.
    expected_tree = expected_tree  # type: ignore

# Generated at 2022-06-25 22:58:27.157891
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:35.130221
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #tests assignment of three variables with annotations
    var_targets = [
        ast.Name(id="var_int", ctx=ast.Store()),
        ast.Name(id="var_float", ctx=ast.Store()),
        ast.Name(id="var_str", ctx=ast.Store()),
    ]
    ann_assign = ast.AnnAssign(
                                target=var_targets,
                                annotation=ast.Str(s='int'),
                                value=ast.Num(n=10),
                                simple=1,
                            )

    #value is None so will be b: int instead of b: int = 10
    var_tan = ast.Name(id="var_int", ctx=ast.Store())

# Generated at 2022-06-25 22:58:36.711401
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:42.978232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test source
    src_1: str = '''
    a:int
    a = 1
    '''
    src_2: str = '''
    def func():
        a: int = 1
        b: int
        a = 1
    '''
    src_3: str = '''
    a: int = 1
    b: int = 2
    '''
    # Test ASTs
    ast_1: ast.Module = ast.parse(src_1)
    ast_2: ast.Module = ast.parse(src_2)
    ast_3: ast.Module = ast.parse(src_3)
    # Test expected AST
    expected_ast_1: ast.Module = ast.parse("""
    a = 1
    """)
    expected_ast_2: ast.Module = ast.parse

# Generated at 2022-06-25 23:00:37.283427
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign()
    my_transformer = VariablesAnnotationsTransformer()
    assert my_transformer.target == (3,5)
    assert isinstance(my_transformer, BaseTransformer)
    assert isinstance(my_transformer.transform(a)[0], ast.AnnAssign)


# Generated at 2022-06-25 23:00:43.630406
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    inp = "a : int = 10\n" \
            "b : int = 20\n" \
            "c : int = 30\n"

    out = "a = 10\n" \
            "b = 20\n" \
            "c = 30\n"

    transformer = VariablesAnnotationsTransformer()

    res = transformer.transform(inp)

    assert res.code == out
    assert res.tree != None
    assert res.tree_changed == True
    assert res.messages == []

# Generated at 2022-06-25 23:00:45.336043
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Check that the class of the object is correct
    assert type(VariablesAnnotationsTransformer()) == VariablesAnnotationsTransformer


# Generated at 2022-06-25 23:00:52.694902
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    import copy

    tree_1 = ast.AnnAssign(target=ast.Name(id='var1', ctx=ast.Store()),
                           annotation=ast.Name(id='str', ctx=ast.Load()))
    tree_2 = ast.AnnAssign(target=ast.Name(id='var2', ctx=ast.Store()),
                           annotation=ast.Name(id='str', ctx=ast.Load()))
    tree_3 = ast.AnnAssign(target=ast.Name(id='var3', ctx=ast.Store()),
                           annotation=ast.Name(id='str', ctx=ast.Load()))
    tree = ast.Module([tree_1, tree_2, tree_3])
    assert VariablesAnnotationsTransformer

# Generated at 2022-06-25 23:01:00.159415
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import TransformationResult

    from typed_ast import ast3 as ast

    from .base import BaseTransformer

    from .helpers import FileBasedTest

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)  #

# Generated at 2022-06-25 23:01:01.161346
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)



# Generated at 2022-06-25 23:01:02.289557
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import check_transformer

    check_transformer(VariablesAnnotationsTransformer)

# Generated at 2022-06-25 23:01:04.079433
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_helper import parse_code
    from ..utils.tree import to_code
    from .transformers import to_typed_ast


# Generated at 2022-06-25 23:01:08.737224
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import convert
    import astunparse
    import sys

    tree = convert('''
a: int = 10
b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)

    if sys.version_info[1] == 4:
        assert astunparse.unparse(tree) == 'a = 10\n'
    else:
        assert astunparse.unparse(tree) == 'a: int\na = 10\n'

# Generated at 2022-06-25 23:01:10.701607
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5)

# Unit tests for method transform of class VariablesAnnotationsTransformer