

# Generated at 2022-06-25 22:52:51.241212
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert(variables_annotations_transformer != None)


# Generated at 2022-06-25 22:53:00.296339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    test_tree1 = ast.parse("a: int = 10\nb: int")
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    transformed_tree1 = variables_annotations_transformer.transform(test_tree1)
    expected_tree1 = ast.parse("a = 10")
    assert ast.dump(expected_tree1) == ast.dump(transformed_tree1.transformed_tree)
    assert transformed_tree1.tree_changed
    assert len(transformed_tree1.errors) == 0

    # Test 2
    test_tree2 = ast.parse("a: int = 10\n\nb: int")
    variables_annotations_transformer = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:06.448233
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert (type(variables_annotations_transformer_0.from_version) == tuple)
    assert (variables_annotations_transformer_0.from_version == (3, 5))
    assert (type(variables_annotations_transformer_0.target) == tuple)
    assert (variables_annotations_transformer_0.target == (3, 5))


# Generated at 2022-06-25 22:53:07.806590
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer is VariablesAnnotationsTransformer(object)

# Generated at 2022-06-25 22:53:12.430707
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:53:13.238674
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:53:14.385998
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert callable(VariablesAnnotationsTransformer().transform)


# Generated at 2022-06-25 22:53:15.718931
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:19.272529
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    # tree_copy = copy.copy(tree)
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.changed == True
    assert str(res.tree) == "a = 10\n"

# Generated at 2022-06-25 22:53:20.852597
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Constructor for class VariablesAnnotationsTransformer"""
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:53:26.879809
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = VariablesAnnotationsTransformer()
    assert(x is not None)


# Generated at 2022-06-25 22:53:36.986375
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    import ast
    import typed_ast.ast3 as typed_ast

    ast_0 = ast.parse('a: int = 10')
    typed_ast.ast3.fix_missing_locations(ast_0)
    typed_ast_ast_0 = typed_ast.ast3.copy_location(typed_ast.AST(), ast_0)
    typed_ast.ast3.walk(typed_ast_ast_0)

    transformationResult = VariablesAnnotationsTransformer.transform(typed_ast_ast_0)
    
    assert type(transformationResult) is TransformationResult
    assert isinstance(transformationResult.tree, typed_ast.ast3.Module)
    assert type(transformationResult.tree.body[0]) is typed_ast.ast3.Assign

# Generated at 2022-06-25 22:53:43.421012
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    line_1 = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()), annotation=ast.Name(id="int", ctx=ast.Load()), value=ast.Num(n=10), simple=1)
    line_2 = ast.AnnAssign(target=ast.Name(id="b", ctx=ast.Store()), annotation=ast.Name(id="int", ctx=ast.Load()))

    lines_1 = [line_1, line_2]
    lines_2 = [line_2]

    VariablesAnnotationsTransformer.transform(lines_1)
    VariablesAnnotationsTransformer.transform(lines_2)

# Generated at 2022-06-25 22:53:45.535363
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    assert(isinstance(VariablesAnnotationsTransformer.transform(tree), TransformationResult))

# Generated at 2022-06-25 22:53:46.637249
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(VariablesAnnotationsTransformer() is not None)

# Generated at 2022-06-25 22:53:55.379780
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = "my_data: int = 15"
    tree = ast.parse(code)
    assert VariablesAnnotationsTransformer.transform(tree).tree_to_str() == "my_data = 15"

    code = "my_data: int = 15\nmy_data_2: int = 16"
    tree = ast.parse(code)
    assert VariablesAnnotationsTransformer.transform(tree).tree_to_str() == "my_data = 15\nmy_data_2 = 16"

    code = "my_data: str\nmy_data_2: str"
    tree = ast.parse(code)
    assert VariablesAnnotationsTransformer.transform(tree).tree_to_str() == "my_data\nmy_data_2"

# Generated at 2022-06-25 22:53:57.845502
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    except Exception:
        print('Error while constructing VariablesAnnotationsTransformer')


# Generated at 2022-06-25 22:54:03.696177
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # AST: Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))])
    node_assign = ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.Num(n=10)
    )
    module = ast.Module(body=[node_assign])
    assert module == VariablesAnnotationsTransformer.transform(module).tree


# Generated at 2022-06-25 22:54:05.109693
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    trans1 = VariablesAnnotationsTransformer()
    assert trans1.target == (3, 5)


# Generated at 2022-06-25 22:54:06.823808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    pass


# Generated at 2022-06-25 22:54:17.118775
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print(VariablesAnnotationsTransformer)
    print(VariablesAnnotationsTransformer.target)
    print(VariablesAnnotationsTransformer.transform)

# Generated at 2022-06-25 22:54:17.703290
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass



# Generated at 2022-06-25 22:54:20.665564
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer_0.__class__.__name__ == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-25 22:54:22.194647
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with pytest.raises(TypeError):
        VariablesAnnotationsTransformer(3)


# Generated at 2022-06-25 22:54:23.350779
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()


# Generated at 2022-06-25 22:54:29.120362
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert_instance(variables_annotations_transformer_0, VariablesAnnotationsTransformer)
    assert_instance(variables_annotations_transformer_0.target, tuple)
    assert_equal(variables_annotations_transformer_0.target, (3, 5))
    assert_instance(variables_annotations_transformer_0.transform, MethodType)
    assert_equal(variables_annotations_transformer_0.transform.__qualname__, 'VariablesAnnotationsTransformer.transform')
    assert_instance(VariablesAnnotationsTransformer.transform, staticmethod)
    assert_equal(VariablesAnnotationsTransformer.transform.__qualname__, 'VariablesAnnotationsTransformer.transform')


# Generated at 2022-06-25 22:54:30.311568
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer_0 = VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:54:31.811928
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(variables_annotations_transformer_0, VariablesAnnotationsTransformer)


# Generated at 2022-06-25 22:54:34.048213
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert str(VariablesAnnotationsTransformer.__name__) == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-25 22:54:34.876655
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass


# Generated at 2022-06-25 22:54:46.851575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
    """
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    print(result.tree)
    print(result.tree_changed)
    print(result.warnings)

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-25 22:54:48.593079
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = ast.parse('a: int = 10')
    output = ast.parse('a = 10')
    assert VariablesAnnotationsTransformer.transform(tree=input) == (output, True, [])

# Generated at 2022-06-25 22:54:54.334007
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Constructor should not return any errors
    cls = VariablesAnnotationsTransformer

    # tree structure should be of type AST
    tree = ast.parse('a: int = 10')
    assert isinstance(cls.transform(tree).tree, ast.AST)

    # tree structure should be of type AST even with bad input
    tree = ast.parse('a: int = 10')
    assert isinstance(cls.transform(tree).tree, ast.AST)

# Generated at 2022-06-25 22:54:54.871269
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 22:54:59.821845
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # create a VariablesAnnotationsTransformer
    t = VariablesAnnotationsTransformer()
    # parse the script which contains a variable annotation
    tree = ast.parse(
        'a: int = 10')
    # transform the tree
    new_tree = t.transform(tree).tree
    # make sure the annotation of the variable was removed
    assert_equals('a = 10\n',
                  ast.unparse(new_tree))

# Generated at 2022-06-25 22:55:07.738107
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                   value=ast.Constant(value=10, kind=None),
                   type_comment='int')
    y = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                   value=ast.Name(id='c', ctx=ast.Load()),
                   type_comment='int')
    z = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()))

    mod = ast.Module(body=[x, y, z])
    result = VariablesAnnotationsTransformer.transform(mod)


# Generated at 2022-06-25 22:55:11.213317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    value = ast.parse('a: int = 10')
    expected = ast.parse('a = 10')
    res = VariablesAnnotationsTransformer.transform(value)
    assert res.changed
    assert ast.dump(res.tree) == ast.dump(expected)
#Unit test for method transform of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:55:19.939520
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..utils.helpers import generate_code
    source = '''
a: int = 10
b: int = 15
c = 10
d = 15
    '''
    expected = '''
a = 10
b = 15
c = 10
d = 15
    '''
    tree = ast3.parse(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == expected

# Generated at 2022-06-25 22:55:24.269855
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse(
        """
a: int = 10
b: int
""")

    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree_changed
    assert res.warnings == []

    assert res.tree == ast.parse(
        """
a = 10
""")

# Generated at 2022-06-25 22:55:28.136279
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
        tree = ast.parse('a: int = 10\nb: int')
        tree = VariablesAnnotationsTransformer.transform(tree)
        assert repr(tree.body[0]) == repr(ast.parse('a = 10').body[0])
        assert repr(tree.body[1]) == repr(ast.parse('b').body[0])

# Generated at 2022-06-25 22:55:51.769088
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_builder import AstBuilder
    code = '''
        # hello world
        a: int = 10
        b: int
    '''
    transformer = VariablesAnnotationsTransformer()

    # First test that it compiles with the right version
    transformer.transform(AstBuilder.parse(code, (3, 5)))

    # Second test that it doesn't compile with the wrong version
    with pytest.raises(ValueError) as e:
        transformer.transform(AstBuilder.parse(code, (3, 6)))
        assert str(e) == 'Invalid Python version. Expected: 3.5'


# Generated at 2022-06-25 22:55:52.243107
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:55:54.809963
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test for constructor of class VariablesAnnotationsTransformer"""
    print("Testing for constructor of class VariablesAnnotationsTransformer")
    a = VariablesAnnotationsTransformer()
    assert a.target == (3, 5)


# Generated at 2022-06-25 22:56:05.028369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_a = ast.AnnAssign(target=ast.Name(id = "a", ctx = ast.Store()),
                          annotation = ast.Name(id = "int", ctx = ast.Store()),
                          value = ast.Num(10), simple = 1)

    var_b = ast.AnnAssign(target=ast.Name(id = "b", ctx = ast.Store()),
                          annotation = ast.Name(id = "int", ctx = ast.Store()),
                          value = None, simple = 0)


# Generated at 2022-06-25 22:56:13.146946
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:56:22.587432
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .base import BaseTestTransformer
    from ..types import Tree

    class TestVariablesAnnotationsTransformer(BaseTestTransformer):
        transformer = VariablesAnnotationsTransformer

    # Test tree:
    #
    # class Foo:
    #   x: int = 10
    #
    # f = Foo()
    #
    # def bar():
    #   a: int
    #
    #
    test_tree = Tree()

# Generated at 2022-06-25 22:56:27.061871
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Tests to see that the correct AST is returned
    :return: None
    """
    from typed_ast import ast3 as ast
    from astunparse import unparse
    import astor

    constr = VariablesAnnotationsTransformer._construct_instance_and_transform()
    assert constr.__class__.__name__ == "VariablesAnnotationsTransformer"



# Generated at 2022-06-25 22:56:35.961374
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse("""\
a: int
b: int = 10
c: int
d: int
e: int = 10
    """)

    # Change node
    result = VariablesAnnotationsTransformer().transform(
        node)

    # Check if the change was correctly made
    assert result.tree_changed == True
    assert result.messages == []
    assert len(result.tree.body) == 3
    assert result.tree.body[0].__class__.__name__ == 'Assign'
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[1].__class__.__name__ == 'Assign'
    assert result.tree.body[1].targets[0].id == 'b'
    assert result.tree.body

# Generated at 2022-06-25 22:56:44.219279
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    #Test for variable with a value assigned to it
    test_ast = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                             annotation=ast.Name(id='int'),
                             value=ast.Name(id='10'),
                             simple=1)

    result = VariablesAnnotationsTransformer.transform(test_ast)
    assert(result.tree == ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                     value=ast.Name(id='10'),
                                     type_comment=ast.Name(id='int')))
    assert(result.tree_changed)

    # Test for variable without value assigned to it

# Generated at 2022-06-25 22:56:46.712739
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse('''
    a: int = 10
    b: int
    ''')
    b = ast.parse('''
    a = 10
    ''')

    assert (VariablesAnnotationsTransformer.transform(a).tree == b)

# Generated at 2022-06-25 22:57:42.948767
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import transform
    from .transformers.test_helpers import assert_transformation_result

    transformation_result = transform(
        tree=ast.parse('x: int\n42'),
        transformers=[VariablesAnnotationsTransformer],
    )
    assert_transformation_result(
        transformation_result,
        expected_tree=ast.parse('42'),
        expected_code='42',
        expected_warnings=[],
    )

    transformation_result = transform(
        tree=ast.parse('x: int = 42\n42'),
        transformers=[VariablesAnnotationsTransformer],
    )

# Generated at 2022-06-25 22:57:44.249892
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    base_transformer_instance = BaseTransformer()
    assert base_transformer_instance.target == (2, 7)

# Generated at 2022-06-25 22:57:47.037764
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """

    tree = ast.parse(input_code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert str(result.tree) == expected_code

# Generated at 2022-06-25 22:57:49.209051
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    c = VariablesAnnotationsTransformer()
    assert c.version == (3, 7)


# Generated at 2022-06-25 22:57:55.613332
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import test_transform
    from ..errors import Untransformable


# Generated at 2022-06-25 22:58:02.244091
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import assign
    from ..utils.helpers import get_node
    from ..utils.tree import get_ast

    x = 'def f(a:int=3,b:int=4):\n\treturn a+b\n'

    # get a tree
    t = get_ast(x)

    # node
    node = get_node(t, assign)

    # transformations
    tr = VariablesAnnotationsTransformer.transform(t)

    # check results
    assert tr.tree_changed == True
    assert tr.tree != t

# Generated at 2022-06-25 22:58:04.338697
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..exceptions import NodeNotFound

    t = VariablesAnnotationsTransformer()
    assert t.target == (3,5)


# Generated at 2022-06-25 22:58:09.896951
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup
    tree_original = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_expected = ast.parse("""
    a = 10
    """)

    # Exercise
    transformer = VariablesAnnotationsTransformer()
    results = transformer.transform(tree_original)

    # Verify
    assert results.tree_transformed == tree_expected
    assert results.tree_changed == True
    assert results.expected_code == ['a: int = 10', 'b: int']

    # Cleanup - none necessary

# Generated at 2022-06-25 22:58:11.496839
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert inspect.isclass(VariablesAnnotationsTransformer)

# Unit tests for transform method of class VariablesAnnotationsTransformer

# Generated at 2022-06-25 22:58:15.379964
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    import textwrap
    from ..utils.helpers import deep_copy
    from ..utils.tree import parse

    tree = parse(textwrap.dedent("""
        a: int = 10
        b: int
        c = 11
    """))
    tree_copy = deep_copy(tree)

    result = VariablesAnnotationsTransformer().transform(tree)

    assert result.changed

    assert tree_copy != result.tree

# Generated at 2022-06-25 23:00:08.932031
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast.ast3 import AnnAssign
    from ..compiler import compile
    from .base import transform
    from .generator import GeneratorTransformer
    from .function_annotations import FunctionAnnotationsTransformer

    code = """
    a: int = 10
    b: int
    """

    transform(code, [VariablesAnnotationsTransformer])

    assert len(GeneratorTransformer.__subclasses__()) == 1
    assert len(FunctionAnnotationsTransformer.__subclasses__()) == 1
    assert len(VariablesAnnotationsTransformer.__subclasses__()) == 1

    tree = compile(code, "<test>", "exec")

    assert len(find(tree, AnnAssign)) == 2

    # annotations are removed

# Generated at 2022-06-25 23:00:10.039708
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert isinstance(t, BaseTransformer)



# Generated at 2022-06-25 23:00:15.008182
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import utils
    from .. import nodes
    code = """
        a: int = 10
        b: int
        """
    ast_tree = utils.parse_code(code)
    expected_ast_tree = utils.parse_code("""
        a = 10
        """)
    transformer = ast.NodeTransformer()
    # filter out Assignments to variables
    transformer.visit_Assign = functools.partial(nodes.visit_Assign, filter_out=True)
    VariablesAnnotationsTransformer.apply_to_ast(ast_tree)
    assert nodes.equivalent_asts(ast_tree, expected_ast_tree) is True

# Generated at 2022-06-25 23:00:16.430366
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse('#!/u/bin/env python3.5\na: int = 10\nb: int')
    assert VariablesAnnotationsTransformer.transform(x).tree_changed

# Generated at 2022-06-25 23:00:16.811808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-25 23:00:22.461339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    import sys
    given_code = """
        class Main():
            def __init__(self):
                self.x : int = 10
                self.y : int
    """
    tree = ast.parse(given_code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    code = astunparse.unparse(tree)
    expected_code = """
        class Main():
            def __init__(self):
                self.x = 10
    """
    assert code == expected_code

# Generated at 2022-06-25 23:00:29.642684
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Variables:
    #    a: int = 10
    #    b: int
    # 
    # To:
    #    a = 10
    #    b = None
    tree = ast.parse(
        'a: int = 10\n'
        'b: int'
    )

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 2

    assert isinstance(tree.body[0], ast.AnnAssign)
    assert isinstance(tree.body[0].target, ast.Name)
    assert tree.body[0].target.id == 'a'
    assert tree.body[0].annotation.id == 'int'
    assert isinstance(tree.body[0].value, ast.Constant)
    assert tree.body[0].value.value == 10



# Generated at 2022-06-25 23:00:33.748957
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import render_and_parse
    code = """
        a: int = 10
        b: int
    """
    expected = """
        a = 10
    """
    tree = render_and_parse(code)
    tree = VariablesAnnotationsTransformer.transform(tree)

    assert(expected == astor.to_source(tree.node))

# Generated at 2022-06-25 23:00:41.755125
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..py2to3.utils.helpers import parse_code
    from .variable_annotations import VariableAnnotationsTransformer

    # Test both together
    tree = parse_code('''
    def foo(a: int = 10, b) -> str:
        b: int = 10
        return str(a+b)
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert isinstance(result.new_tree.body[0].args.defaults[0], ast.Num)
    assert isinstance(result.new_tree.body[0].body[0], ast.Assign)

    # Test single construct
    tree = parse_code('''
    bar: int = 10
    ''')


# Generated at 2022-06-25 23:00:49.803736
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from astunparse import unparse
    from typed_ast import ast3 as ast

    a = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10),
                      simple=1,
                      type_comment=None)

    input_ast = ast.Module(body=[a])
    output_ast = ast.Module(body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))])

    tree = VariablesAnnotationsTransformer.transform(input_ast)