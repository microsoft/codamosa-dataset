

# Generated at 2022-06-23 23:21:05.907064
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer
    class TestTree():
        AST = ast.AnnAssign(target=ast.Name(id='a', ctx=0),
                            annotation=ast.Str(s='hello'),
                            value=ast.Str(s='world'))
        TREE_CHANGED = True

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:21:12.194591
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test case for constructor of VariablesAnnotationsTransformer.

        - Input:  a: int = 10
        - Output: a = 10
    """
    input_code = 'a: int = 10'
    output = 'a = 10'
    tree = ast.parse(input_code)
    expected_tree = ast.parse(output)
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)

    assert result.tree.body[0].value == expected_tree.body[0].value

# Generated at 2022-06-23 23:21:16.381634
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import tempfile
    code = """
a: int = 10
b: int
    """
    result = """
a = 10
    """
    with tempfile.NamedTemporaryFile(suffix='.py') as f:
        f.write(code.encode('utf-8'))
        f.seek(0)
        transformed, did_change, _ = VariablesAnnotationsTransformer.transform_file(f.name)
        assert transformed == result
        assert did_change

# Generated at 2022-06-23 23:21:19.445627
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_anno_transformer = VariablesAnnotationsTransformer()
    code = "a: int = 10\nb: int"
    tree = ast.parse(code)
    result = var_anno_transformer.transform(tree)
    assert result.tree_changed == True
    assert astor.to_source(result.tree).strip() == "a = 10"

# Generated at 2022-06-23 23:21:28.193566
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from random import randint

    tree = ast.Module()
    tree.body.append(ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Constant(randint(0, 100))))
    tree.body.append(ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=None))


    vat = VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(vat.tree))
    print(ast.dump(vat.logs[0].tree_before))

# Generated at 2022-06-23 23:21:32.885334
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_node

    from typed_ast import ast3 as ast
    from typed_ast.transforms import transform
    from typed_ast.transforms.annotations import VariablesAnnotationsTransformer

    code1 = '''\
a: int = 10
b: int
'''

# Generated at 2022-06-23 23:21:35.688468
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse("def f():\n a: int = 10\n")
    a2 = VariablesAnnotationsTransformer().transform(a)
    assert(ast.dump(a) == ast.dump(a2))

# Generated at 2022-06-23 23:21:41.540921
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast import parse
    from typed_ast import ast3
    node = ast3.parse("""a: int = 10
                          b: int
                          c: bool
                          d: str = '3'""")
    node_changed = ast3.parse("""a = 10
                                 b: int
                                 c: bool
                                 d = '3'""")
    object = VariablesAnnotationsTransformer()
    result = object.transform(node)
    assert(result.tree == node_changed and result.tree_changed == True)

# Generated at 2022-06-23 23:21:42.693660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Check whether the object is created or not
    VariablesAnnotationsTransformer()


# Generated at 2022-06-23 23:21:52.096287
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_dict = {'body': [{'_astname': 'AnnAssign', 'annotation': {'id': 'int'}, 'simple': 1, 'target': {'id': 'a'}, 'value': {'n': 10}, 'type_comment': None}], 'type_ignores': [], 'type': 'Module'}
    tree = ast.parse(tree_dict)
    VarAnnTrans = VariablesAnnotationsTransformer()
    result = VarAnnTrans.transform(tree)
    result_dict = ast.dump(result.tree)

# Generated at 2022-06-23 23:21:53.839322
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    a: int = 1
    # print(isinstance(t, BaseTransformer))
    # print(t.target)
    pass

# Generated at 2022-06-23 23:22:00.093483
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import parse
    from ..process import transform_module

    source = '''
a: int = 10
b: int
c: int = (1, 2, 3)
    '''

    tree_before = parse(source)
    tree_after = transform_module(VariablesAnnotationsTransformer, source)

    assert tree_before != tree_after
    assert tree_after == parse('''
a = 10
b = None
c = (1, 2, 3)
    ''')



# Generated at 2022-06-23 23:22:03.891361
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Successful instantiation of VariablesAnnotationsTransformer
    sample_transformer = VariablesAnnotationsTransformer()
    assert isinstance(sample_transformer, VariablesAnnotationsTransformer)
    assert isinstance(sample_transformer, BaseTransformer)



# Generated at 2022-06-23 23:22:12.251788
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_ast = ast.parse("""
i:int
j:int
i = j:int
i:int = 10
p:int = 10
x:int = 10
r:int = 10
""")
    result = VariablesAnnotationsTransformer.transform(test_ast)
    assert result.tree_changed == True
    assert result.tree_to_str() == """
i = j
i = 10
p = 10
x = 10
r = 10
"""
    assert result.warnings_info == [('Assignment outside of body',
                                    {'filename': '<unknown>', 'lineno': 2,
                                    'offset': None})]

# Generated at 2022-06-23 23:22:16.149465
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from asttokens import ASTTokens

    code = "a: int = 10\nb: int"
    tree = ast.parse(code)
    print("Created tree")
    tree2 = VariablesAnnotationsTransformer.transform(tree)
    atok = ASTToke

# Generated at 2022-06-23 23:22:23.631340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    t1 = ast3.AnnAssign(target=ast3.Name(id='a'), value=ast3.Num(n=10))
    t2 = ast3.AnnAssign(target=ast3.Name(id='b'), annotation=ast3.Name(id='int'))
    t3 = ast3.AnnAssign(target=ast3.Name(id='c'), annotation=ast3.Name(id='int'), value=ast3.Num(n=20))
    t4 = ast3.AnnAssign(target=ast3.Name(id='d'), annotation=ast3.Name(id='int'))

# Generated at 2022-06-23 23:22:25.211677
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:22:31.140180
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .transformer_test_utils import compare_to_expected
    compare_to_expected(__file__, 'a: int = 10', 'a = 10', VariablesAnnotationsTransformer)
    compare_to_expected(__file__, 'a: int \n b: int = 10', 'b = 10', VariablesAnnotationsTransformer)


if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:22:39.207624
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  # Defining the AST
  node = ast.AnnAssign(
    target = ast.Name(
      id = 'a',
      ctx = ast.Store()),
    annotation = ast.Name(
      id = 'int',
      ctx = ast.Load()),
    value = ast.Num(
      n = 10),
    simple = 1)

  # Defining the expected AST
  expected_node = ast.Assign(
    targets = [ast.Name(
      id = 'a',
      ctx = ast.Store())],
    value = ast.Num(
      n = 10),
    type_comment = ast.Name(
      id = 'int',
      ctx = ast.Load()))

  # Testing
  res_node = VariablesAnnotationsTransformer.transform(node)

  assert res_node

# Generated at 2022-06-23 23:22:40.817804
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.parse("x :int = 1"))
    assert True

# Generated at 2022-06-23 23:22:44.103952
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('a: int = 10\nb: int = 20')
    result = VariablesAnnotationsTransformer.transform(test_tree)
    assert(not result.tree_changed)

# Generated at 2022-06-23 23:22:46.242706
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)
    assert transformer.transform == VariablesAnnotationsTransformer.transform

# Generated at 2022-06-23 23:22:47.913492
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer._variables_annotations_transformer_test == "test"


# Generated at 2022-06-23 23:22:53.382091
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
   class_ = VariablesAnnotationsTransformer(
       VariablesAnnotationsTransformer.transform,
       VariablesAnnotationsTransformer.target,
       VariablesAnnotationsTransformer.get_name()
   )
   assert class_.func == VariablesAnnotationsTransformer.transform
   assert class_.target == VariablesAnnotationsTransformer.target
   assert class_.get_name() == VariablesAnnotationsTransformer.get_name()

# Testing the functionality of the VariablesAnnotationsTransformer for
# a single node

# Generated at 2022-06-23 23:22:57.130362
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_modules = [
        ast.parse("a: int = 10\nb: int"),
        ast.parse("a: int = 10\nb: int\nif True:\n    b: str = 'hi'")
    ]

    for module in test_modules:
        tree_changed = VariablesAnnotationsTransformer.transform(module)
        assert tree_changed

# Generated at 2022-06-23 23:23:03.568058
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Sample of code to be translated
    code = """
        a:int = 10
        b:int
        """
    # Expecting the following AST:
    expected_ast = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                   value=ast.Constant(value=10, kind=None),
                   type_comment=ast.Name(id='int', ctx=ast.Load())),
    ])
    # Getting the AST and making sure that it matches the expected AST.
    assert ast.dump(VariablesAnnotationsTransformer.transform(ast.parse(code))
                    .tree) == ast.dump(expected_ast)

# Generated at 2022-06-23 23:23:09.702210
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3
    from .base import BaseTransformerTest
    class Test(BaseTransformerTest):
        target_class = VariablesAnnotationsTransformer
        def test(self):
            tree = typed_ast.ast3.parse(
                """
a : int = 10
b: int
            """
            )
            node = tree.body[0]
            self.check(
                node,
                tree.body[0],
                """
a = 10
            """
            )

# Generated at 2022-06-23 23:23:11.659301
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ta = VariablesAnnotationsTransformer()
    assert ta.target == (3, 5)

# Generated at 2022-06-23 23:23:18.094007
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    class C:
        x: int = None
    '''
    tree = ast.parse(dedent(code))
    trans = VariablesAnnotationsTransformer(tree)
    (result, tree_changed, error) = trans.transform()
    assert tree_changed == True
    assert_equals = deep_equals(result, tree)  # type: ignore
    assert assert_equals == True
    #assert error == ''

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:23:22.498495
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = "a: int = 10"
    correct_code = "a = 10"
    print("========= Input Code: =========")
    print(input_code)
    print("========= Expected Output: =========")
    print(correct_code)
    check_tree(input_code, correct_code)
    # check_tree(input_code, 'test')

# Generated at 2022-06-23 23:23:24.910339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert Transformer is VariablesAnnotationsTransformer
    instance = VariablesAnnotationsTransformer()
    assert isinstance(instance, VariablesAnnotationsTransformer)
    assert isinstance(instance, BaseTransformer)

# Generated at 2022-06-23 23:23:28.589933
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .test_helpers import assert_program_equal, get_ast

    assert_program_equal(
        get_ast('''
a: int = 10
b: int
    '''),

        get_ast('''
a = 10
        ''')
    )

# Generated at 2022-06-23 23:23:35.758823
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import ast_format
    from typed_ast import ast3
    from .variables_transformer import VariablesTransformer

    tree = ast3.parse('''
x: int = 10
a: str = "hello"
b: str
    ''')
    result = VariablesAnnotationsTransformer().transform(tree)

    assert ast_format(result) == ast_format(ast3.parse('''
x = 10
a = "hello"
    '''))

# Generated at 2022-06-23 23:23:39.469415
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    def test():
        a: int = 10
        b: int

        c = a + b

    tree = ast.parse(test.__code__.co_consts[0].co_consts[0])
    assert VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-23 23:23:40.821678
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-23 23:23:52.093224
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    classA = ast.ClassDef(name='A',
                          body=[ast.AnnAssign(target=ast.Name(id='a',
                                                              ctx=ast.Store()),
                                              annotation=ast.Num(n=10),
                                              value=ast.Num(n=10))],
                          decorator_list=[])
    treeA = ast.Module(body=[classA])

    treeA_new = VariablesAnnotationsTransformer.transform(treeA)

    assert(isinstance(treeA_new.tree.body[0].body[0], ast.Assign))


# Generated at 2022-06-23 23:23:54.850894
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer()
    assert class_obj.target == (3, 5), "transformed variable incorrect"


# Generated at 2022-06-23 23:23:56.833418
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_nodes

# Generated at 2022-06-23 23:23:57.478457
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert True

# Generated at 2022-06-23 23:24:05.399130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from . import build_ast
    tree = build_ast("class HelloWorld:\n  c:int\n  a:int = 10\n  b:int")
    v = VariablesAnnotationsTransformer()

    tree_ret = v.transform(tree)
    assert ast.dump(tree_ret.tree) == "Module(body=[ClassDef(name='HelloWorld', bases=[], keywords=[], body=[], decorator_list=[], type_comment=None), Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10, kind=None), type_comment='int')])"

# Generated at 2022-06-23 23:24:11.039864
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # To test the constructor of class VariablesAnnotationsTransformer
    x = VariablesAnnotationsTransformer()
    assert isinstance(x, VariablesAnnotationsTransformer)

    # To test the function transform() of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == (ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("b: int")) == (ast.parse("# empty line"), True, [])

# Generated at 2022-06-23 23:24:21.820978
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .. import transforms
    from ..transforms.fixers import base
    from ..transforms.fixers.base import BaseTransformer

    try:
        assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)
    except AssertionError:
        print("Error: class VariablesAnnotationsTransformer does not inherit from BaseTransformer.")
        sys.exit(1)

    # Test that attributes are defined
    try:
        VariablesAnnotationsTransformer.target
    except AttributeError:
        print("Error: target attribute is not defined in VariablesAnnotationsTransformer.")
        sys.exit(1)

    try:
        VariablesAnnotationsTransformer.transform
    except AttributeError:
        print("Error: transform method is not defined in VariablesAnnotationsTransformer.")
       

# Generated at 2022-06-23 23:24:26.479827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Compiles:
        # a: int = 10
        # b: int
    # To:
        # a = 10
    tree = ast.parse('a: int = 10\nb: int')
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree) == TransformationResult(ast.parse('a = 10'), True, [])


# Generated at 2022-06-23 23:24:33.576551
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    def add(a: int, b: int) -> int:
        c: int = 10
        return a + b + c
    '''
    expected = '''
    def add(a, b):
        c = 10
        return a + b + c'''

    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree.tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:24:37.054966
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    testTree = ast.parse("""
a : int = 10
b : int
c : int = 10 + d
d : int = b
    """)
    assert VariablesAnnotationsTransformer.transform(testTree) == (ast.parse("""
a = 10
# b: int
c = 10 + d
d = b
    """), True, [])

# Generated at 2022-06-23 23:24:42.204674
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    o = VariablesAnnotationsTransformer()
    inputTree = """
    class Test(object):
        def __init__(self):
            self.a: int = 10
            self.b: int
    """
    expectedTree = """
    class Test(object):
        def __init__(self):
            self.a = 10

    """
    outputTree = o.transform(inputTree)
    assert outputTree == expectedTree

# Generated at 2022-06-23 23:24:49.050614
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse("def foo(): pass")
    x2 = VariablesAnnotationsTransformer.transform(x)
    assert x.body == x2.body
    x = ast.parse("a: int = 10")
    x2 = VariablesAnnotationsTransformer.transform(x)
    assert x.body == x2.body
    x = ast.parse("b: int")
    x2 = VariablesAnnotationsTransformer.transform(x)
    assert x.body == x2.body

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:24:59.008479
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    __version__: str = '1.0'
    __doc__: str = "This is a module"
    x: int
    """)
    new_tree, tree_changed, _ = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True, "The tree should have changed"
    assert len(new_tree.body) == 1, "The body should have only one statement"
    assert type(new_tree.body[0]) == ast.Assign, "The statement should be of type assign"
    assert new_tree.body[0].targets[0].id == '__version__', "The target var should be __version__"
    assert new_tree.body[0].value.s == '1.0', "The value should be 1.0"

# Generated at 2022-06-23 23:25:05.457387
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test transform
    import typed_ast.ast3
    from ..utils.tree import ast_to_str
    # testing module
    module_ast = typed_ast.ast3.parse(
        'from lib.one import a, b\n'
        '\n'
        'def foo():\n'
        '    a: int = 10\n'
        '    b: int'
        , "test.py")

    print(ast_to_str(module_ast))

    VariablesAnnotationsTransformer.transform(module_ast)

    assert ast_to_str(module_ast) == 'from lib.one import a, b\n' \
                                    '\n' \
                                    'def foo():\n' \
                                    '    a = 10'

# Generated at 2022-06-23 23:25:12.388442
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	from typed_ast import ast3 as ast
	from ..utils.tree import get_root
	from .variable_initialization_transformer import VariableInitializationTransformer
	from .variables_annotations_transformer import VariablesAnnotationsTransformer
	from .variables_annotations_to_comments_transformer import VariablesAnnotationsToCommentsTransformer
	from .variables_to_input_transformer import VariablesToInputTransformer
	from .variables_types_to_comments_transformer import VariablesTypesToCommentsTransformer
	from .print_statements_transformer import PrintStatementsTransformer
	from .comments_to_print_transformer import CommentsToPrintTransformer
	from .indentation_transformer import IndentationTransformer
	from ..types import TransformationResult

# Generated at 2022-06-23 23:25:13.205067
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    assert VariablesAnnotationsTransformer



# Generated at 2022-06-23 23:25:19.710488
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test without type annotations
    node_a = ast.Expr(value=ast.Constant(10, kind=None))
    node_b = ast.Expr(value=ast.Constant(20, kind=None))
    node_c = ast.Expr(value=ast.Constant(30, kind=None))
    node_d = ast.Expr(value=ast.Constant(40, kind=None))
    node_x = ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),  # type: ignore
                           value=node_a.value,  # type: ignore
                           annotation=None,
                           simple=1)

# Generated at 2022-06-23 23:25:23.148989
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import compare_trees
    from ..exceptions import InvalidNodeType
    import pytest
    from ..main import main

# Generated at 2022-06-23 23:25:27.535177
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
name: str = 'test_name'
age: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree == ast.parse('''name = 'test_name'
age: int
    ''')
    assert result.tree_changed == True

# Generated at 2022-06-23 23:25:29.547547
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(VariablesAnnotationsTransformer,ast.parse('a: int = 10')) == ast.parse('a=10')

# Generated at 2022-06-23 23:25:30.458320
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

# Generated at 2022-06-23 23:25:35.279197
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer
    assert transformer.target == (3, 5)

    tree = ast.parse("""
a: int = 10
b: int
    """)
    transformed, tree_changed = transformer.transform(tree)
    assert tree_changed
    assert ast.dump(transformed) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10), type_comment=Str(s='int'))])"

# Generated at 2022-06-23 23:25:37.173575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import parse


# Generated at 2022-06-23 23:25:42.521578
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    test_code = 'a: int = 10 \nb: int'
    expected_code = 'a = 10 \nb = 10'

    # Act
    actual_code = VariablesAnnotationsTransformer.transform(test_code)

    # Assert
    assert (actual_code == expected_code)



# Generated at 2022-06-23 23:25:51.306064
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node1 = ast.AnnAssign(
        target = ast.Name(id = 'a', ctx = ast.Store()),
        annotation = ast.Name(id = 'int', ctx = ast.Load()),
        value = ast.Num(n = 10),
        simple = 1
    )
    node2 = ast.AnnAssign(
        target = ast.Name(id = 'b', ctx = ast.Store()),
        annotation = ast.Name(id = 'int', ctx = ast.Load()),
        value = None,
        simple = 0
    )
    node3 = ast.Name(
        id = 'a',
        ctx = ast.Load()
    )
    node4 = ast.Name(
        id = 'b',
        ctx = ast.Load()
    )
    node5

# Generated at 2022-06-23 23:26:02.249425
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for constructor of class VariablesAnnotationsTransformer"""

    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_source

    # Construct the AST
    mod = ast.Module()

# Generated at 2022-06-23 23:26:11.185683
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    class Test:
        def __init__(self, name: str = "a") -> None:
            self.name = name
        def test(self) -> None:
            a: int = 10
            b = 20
        def test2(self) -> int:
            a: int
            a = 10
            b = 30
            return a
    ''')
    actual = VariablesAnnotationsTransformer.transform(tree).tree
    expected = ast.parse('''
    class Test:
        def __init__(self, name: str = "a") -> None:
            self.name = name
        def test(self) -> None:
            pass
        def test2(self) -> int:
            a = 10
            b = 30
            return a
    ''')

   

# Generated at 2022-06-23 23:26:18.809033
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                      annotation=ast.Name(id='int', ctx=ast.Load()),
                      value=ast.Num(n=10))
    ) == TransformationResult(
        tree=ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                        value=ast.Num(n=10)),
        tree_changed=True,
        additional_nodes=[]
    )

# Generated at 2022-06-23 23:26:28.767165
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse("""
a: int = 10
b: int
c: str = \"s\"
    """)
    var = VariablesAnnotationsTransformer()
    # When
    tr = var.transform(tree)
    # Then
    assert tr.tree_changed

# Generated at 2022-06-23 23:26:35.957884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: ast.Module
    a = ast.parse('''a:str = "string"''')
    b = VariablesAnnotationsTransformer().transform(a)
    assert b.tree == ast.parse('''a = "string"''')
    assert b.tree_changed == True

    # Check for case when the node isn't in the body
    a = ast.parse('''b = 10\na:str = "string"''')
    b = VariablesAnnotationsTransformer().transform(a)
    assert b.tree == ast.parse('''b = 10\na = "string"''')
    assert b.tree_changed == True

# Generated at 2022-06-23 23:26:38.246360
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ in globals()
    assert VariablesAnnotationsTransformer.transform.__name__ in globals()

# Generated at 2022-06-23 23:26:43.216971
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_parameter
    from . import VariableAnnotationTransformer
    from ..utils.testing import get_transformer_result

    # This test checks if the constructor of VariablesAnnotationsTransformer properly handles type errors and unexpected parameters
    # If a call fails, an exception is raised and the test fails
    try:
        VariableAnnotationTransformer(get_parameter(True))
    except TypeError:
        pass



# Generated at 2022-06-23 23:26:48.887003
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from types import ModuleType
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    
    code = '''
    def foo(a: int):
        print(a)
    '''
    tree = astor.parse_file(code)
    tree = BaseTransformer.transform(tree)
    tree = VariablesAnnotationsTransformer.transform(tree)
    mod = ModuleType('__main__')
    exec(compile(tree, '', 'exec'), mod.__dict__)
    assert mod.__dict__['foo']


# Generated at 2022-06-23 23:26:52.375804
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10\nb: int')) == TransformationResult(ast.parse('a = 10\nb'), True, [])

# Generated at 2022-06-23 23:26:55.973568
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    a: int = 10
    b: int
    """
    out = """
    a = 10
    """
    transformer = VariablesAnnotationsTransformer()
    results = transformer.transform(code)
    assert results.tree == out

# Generated at 2022-06-23 23:27:02.093829
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse('a: int = 12')
    transformed_module, _, _ = VariablesAnnotationsTransformer.transform(module)

    assert isinstance(transformed_module, ast.Module)
    assert isinstance(transformed_module.body[0], ast.Assign)
    assert isinstance(transformed_module.body[0].targets[0], ast.Name)
    assert transformed_module.body[0].targets[0].id == 'a'
    assert isinstance(transformed_module.body[0].value, ast.Num)
    assert transformed_module.body[0].value.n == 12

# Generated at 2022-06-23 23:27:06.552156
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected_tree = ast.parse('a = 10')
    tree = ast.parse('a: int = 10')
    assert (VariablesAnnotationsTransformer().transform(tree) ==
            TransformationResult(result=expected_tree,
                                 tree_changed=True,
                                 warnings=[]))



# Generated at 2022-06-23 23:27:15.790554
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast as pyast
    py_node = pyast.FunctionDef(
        'foo',
        pyast.arguments(args=[
            pyast.arg(arg='bar', annotation=pyast.Name(id='int'))],
            defaults=[], vararg=None, kwarg=None,
            kwonlyargs=[], kw_defaults=[], type_comment=None),
        [pyast.AnnAssign(
            target=pyast.Name(id='bar', ctx=pyast.Store()),
            annotation=pyast.Name(id='int'), value=pyast.Num(n=1))],
        [],
        None, None, None)
    tree = pyast.Module(body=[py_node])

# Generated at 2022-06-23 23:27:20.242280
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test VariablesAnnotationsTransformer"""
    # import ast
    # from astunparse import unparse

    # tree = ast.parse("a: int = 10\nb: int")
    # VariablesAnnotationsTransformer.transform(tree)

    # print(unparse(tree))
    pass

# Generated at 2022-06-23 23:27:22.363204
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)



# Generated at 2022-06-23 23:27:26.588883
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast)
# Test case:
# a: int = 10
# b: int
# c: int = 3
# d: int
# e = 4
# def foo(a, b, c, d, e):
#     pass

# Generated at 2022-06-23 23:27:38.320597
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:27:42.089275
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    class VariablesAnnotationsTransformerTest(VariablesAnnotationsTransformer):
        def __init__(self):
            self.node = ast.AnnAssign()
            self.target = (3, 5)

    assert VariablesAnnotationsTransformerTest.transform(None)

# Generated at 2022-06-23 23:27:51.086081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                         annotation=ast.Name(id='int', ctx=ast.Load()),
                         value = ast.Num(n=10),
                         simple=1)
    parent = ast.Module(body=[node])
    tree = VariablesAnnotationsTransformer.transform(parent)
    assert len(tree[0].body) == 1
    assert isinstance(tree[0].body[0], ast.Assign)
    assert isinstance(tree[0].body[0].targets[0], ast.Name)
    assert isinstance(tree[0].body[0].value, ast.Num)

# Generated at 2022-06-23 23:27:55.737304
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import format

    source = '''
a: int = 10
b: int
'''

    result = '''
a = 10
'''

    tree = ast.parse(source)
    vat = VariablesAnnotationsTransformer()
    vat.transform(tree)
    result_source = format.unparse(tree)
    assert result_source == result

# Generated at 2022-06-23 23:27:59.496701
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    ast.parse('a: int = number\nb: str', mode='eval')
    assert ast.parse('a = number\nb', mode='eval') == VariablesAnnotationsTransformer.transform(ast.parse('a: int = number\nb: str', mode='eval'))

# Generated at 2022-06-23 23:28:02.142082
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\n')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert(isinstance(result.result[0], ast.Assign))

# Generated at 2022-06-23 23:28:11.414643
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import compile_src

    # Test 1: test transform
    src = """
    x: int = 10
    """
    expected = """
    x = 10
    """
    with VariablesAnnotationsTransformer.at_version(*VariablesAnnotationsTransformer.target):
        tree = compile_src(src, '<test>', 'exec')
        assert expected == src_from_tree(tree)

    # Test 2: test transform when no assignments
    src = """
    x: int
    """
    expected = """
    x
    """
    with VariablesAnnotationsTransformer.at_version(*VariablesAnnotationsTransformer.target):
        tree = compile_src(src, '<test>', 'exec')
        assert expected == src_from_tree(tree)

# Generated at 2022-06-23 23:28:14.471181
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)
    res = VariablesAnnotationsTransformer.transform(tree)

    expected_code = """
    a = 10
    """

    assert astor.to_source(res.tree) == expected_code
    assert res.tree_changed is True

# Generated at 2022-06-23 23:28:16.554206
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test = '''a: int = 10'''
    result = '''a = 10'''
    assert py2py(test, VariablesAnnotationsTransformer) == result

# Generated at 2022-06-23 23:28:26.458017
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree1 = ast.parse("""
    a: int = 10
    b: int
    """)
    tree2 = ast.parse("""
    a = 10
    """)
    tree3 = ast.parse("""
    a: int
    """)
    tree4 = ast.parse("""
    a = 10
    b = 20
    """)
    tree5 = ast.parse("""
    def f():
        a: int = 10
    """)
    tree6 = ast.parse("""
    a = 10
    a = 20
    """)
    tree7 = ast.parse("""
    a = 10
    b = 20
    """)
    tree8 = ast.parse("""
    def f():
        a: int = 10
    """)

# Generated at 2022-06-23 23:28:34.682550
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Simple case:
    # a: int = 10
    # b: int
    # is converted to:
    # a = 10
    node1 = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()),
                          annotation=ast.parse("int", mode="eval").body[0],
                          value=ast.Num(10))
    node2 = ast.AnnAssign(target=ast.Name(id="b", ctx=ast.Store()),
                          annotation=ast.parse("int", mode="eval").body[0],
                          value=None)
    code = ast.Module(body=[node1, node2])
    assert VariablesAnnotationsTransformer.transform(code).tree == ast.parse("\n\na = 10")

    # Example from docs:
    #

# Generated at 2022-06-23 23:28:38.137301
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	tree = ast.parse('a:int = 10\nb:int')
	newtree = VariablesAnnotationsTransformer.transform(tree).tree
	compare_code = "a = 10\nb"
	assert astor.to_source(newtree)==compare_code

# Generated at 2022-06-23 23:28:46.937109
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test One
    test_one = VariablesAnnotationsTransformer()
    assert test_one.tree(ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                                       annotation=ast.Name(id='int', ctx=ast.Load())))
    assert type(test_one.tree) ==  ast.AnnAssign

    # Test Two
    test_two = VariablesAnnotationsTransformer()
    assert test_two.transform(ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                                            annotation=ast.Name(id='int', ctx=ast.Load()))) == TransformationResult
    assert type(test_two.transform) ==  TransformationResult

# Generated at 2022-06-23 23:28:53.395100
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast
    import textwrap
    import typed_ast.ast3
    # INITIAL CODE
    before = textwrap.dedent('''
        def f(a:int,b:str) -> int:
            if True:
                c:str =""
                d:int =1
                e:list[str] =[]
            return 1
        ''')
    # CODE TO BE TRANSFORMED
    expected = textwrap.dedent('''
        def f(a,b):
            if True:
                c =""
                d =1
                e =[]
            return 1
        ''')
    # TREE OF CODE TO BE TRANSFORMED
    code_to_transform = ast.parse(before)
    # TREE OF EXPECTED CODE
    expected_code = ast.parse(expected)
   

# Generated at 2022-06-23 23:28:57.353234
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    tree = astor.parse_file('tests/samples/typed_samples/typed_variables_annotations.py')
    tree = VariablesAnnotationsTransformer.transform(tree)
    print (astor.to_source(tree))


# Generated at 2022-06-23 23:28:59.521313
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.parser import parse, compare_source

# Generated at 2022-06-23 23:29:05.627546
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    test_tree = ast.parse("""a:int = 10
b:int = 20
c:int = a + b""")
    example_node = ast.AnnAssign(target=ast.Name(id="a"), annotation=ast.Name(id="int"), value=ast.Constant(10, kind=None), simple=1)
    #Constructor test
    obj = VariablesAnnotationsTransformer()
    assert(VariablesAnnotationsTransformer.target == (3,5))
    assert(obj.tree is None)
    #transform test
    res = VariablesAnnotationsTransformer.transform(test_tree)
    assert(res.tree_changed is True)
    assert(res.new_imports == [])

# Generated at 2022-06-23 23:29:12.694013
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse("""a: int = 10\n
                        b: int\n""")
    transformer = VariablesAnnotationsTransformer()

    # When
    result = transformer.transform(tree)
    result_tree = result.tree
    result_changed = result.changed

    # Then
    test_tree = ast.parse("""a = 10\n""")
    assert ast.dump(result_tree) == ast.dump(test_tree)
    assert result_changed

# Generated at 2022-06-23 23:29:18.706053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None).new_tree == None
    tree = ast.parse("a: int = 10")

    result = VariablesAnnotationsTransformer.transform(tree)
    new_ast = result.new_tree
    assert type(new_ast.body[0].value) == ast.Num
    assert new_ast.body[0].value.n == 10

# Generated at 2022-06-23 23:29:20.085999
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-23 23:29:25.947979
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'

# Unit testing for transform function of class VariablesAnnotationsTransformer
if __name__ == '__main__':
    print("Testing for transform function of class VariablesAnnotationsTransformer")
    code_path = '../examples/code.py'
    current_ast = ast.parse(open(code_path).read())
    VariablesAnnotationsTransformer.transform(current_ast)

# Generated at 2022-06-23 23:29:28.913135
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.transform(ast.parse("""
            a: int = 10
            b: int = 20
            c: int
            """)) == TransformationResult(ast.parse("""
            a = 10
            b = 20
            """))

# Generated at 2022-06-23 23:29:33.723500
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass
# class VariablesAnnotationsTransformerTests(unittest.TestCase):
#     def test_VariablesAnnotationsTransformer(self):
#         """
#             Test class VariablesAnnotationsTransformer.
#         """
#         # VariablesAnnotationsTransformer.transform(node)

# Generated at 2022-06-23 23:29:35.675578
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-23 23:29:38.966217
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    testString = "a: int = 10\nb: int"
    root = ast.parse(testString)
    tree = VariablesAnnotationsTransformer.transform(root).new_tree
    print(ast.dump(tree))

# Generated at 2022-06-23 23:29:43.990503
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    a: int = 10
    b: int
    ''')

    output = VariablesAnnotationsTransformer.transform(tree)
    expected_output = ast.parse('''
    a = 10
    global b
    ''')
    assert ast.dump(output.tree) == ast.dump(expected_output)



# Generated at 2022-06-23 23:29:45.923140
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:29:48.571605
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class A:
        b: int = 10
    class B:
        c: int

# Generated at 2022-06-23 23:29:57.843731
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import run_transformer

    code = '''
a: int = 10
b: int
    '''
    result = run_transformer(VariablesAnnotationsTransformer, code)

    assert isinstance(result, TransformationResult)

    tree = result.tree

    assert isinstance(tree, ast.Module)

    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Assign)

    assert isinstance(tree.body[0].targets[0], ast.Name)
    assert isinstance(tree.body[1].targets[0], ast.Name)

    assert tree.body[0].targets[0].id == 'a'

# Generated at 2022-06-23 23:29:59.473436
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    cls = VariablesAnnotationsTransformer
    VariablesAnnotationsTransformer.transform(tree) == 'tree'

# Generated at 2022-06-23 23:30:10.133063
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node_a = ast.Name(id='a', ctx=ast.Load())
    node_b = ast.Name(id='b', ctx=ast.Load())
    node_c = ast.Name(id='c', ctx=ast.Load())
    node_int = ast.Name(id='int', ctx=ast.Load())
    node_10 = ast.Constant(value=10)
    node_11 = ast.Constant(value=11)

    node_a_ann = ast.AnnAssign(target=node_a, annotation=node_int,
                               simple=1, value=node_10)
    node_b_ann = ast.AnnAssign(target=node_b, annotation=node_int,
                               simple=0)

# Generated at 2022-06-23 23:30:20.266977
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ass_clas = VariablesAnnotationsTransformer()
    assert isinstance(ass_clas, VariablesAnnotationsTransformer)


if __name__ == "__main__":
    # Unit test for transform method
    assign = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                           annotation=ast.Name(id='int', ctx=ast.Load()),
                           value=ast.Num(n=10),
                           simple=1,
                           )
    assign2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                            annotation=ast.Name(id='int', ctx=ast.Load()),
                            simple=1,
                            )

# Generated at 2022-06-23 23:30:30.453224
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .test_utils import make_call, make_name
    from .test_utils import parse_tree
    from ..types import TransformationResult

    a: ast.AST = ast.Name('a', ast.Store())
    b: ast.AST = ast.Name('b', ast.Store())
    c: ast.AST = ast.Name('c', ast.Store())
    d: ast.AST = ast.Name('d', ast.Store())
    e: ast.AST = ast.Name('e', ast.Load())


# Generated at 2022-06-23 23:30:33.034227
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .typing import TypingTransformer


# Generated at 2022-06-23 23:30:39.189942
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import convert
    from ..types import CodeFragment
    from ..exceptions import ASTUnsupportedVersion

    try:
        transpiled_value = convert(CodeFragment(
            '''
            a: int
            b: str = "hello"
            '''
        ),(3, 5), (3, 6))
    except ASTUnsupportedVersion as e:
        print(e)
    else:
        assert transpiled_value[0] == CodeFragment(
        '''
        a
        b = "hello"
        ''')
    try:
        transpiled_value = convert(CodeFragment(
            '''
            a: int
            b: str = "hello"
            '''
        ),(3, 5), (3, 7))
    except ASTUnsupportedVersion as e:
        print

# Generated at 2022-06-23 23:30:49.723243
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int

""")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal(ast.dump(result.tree), 'Module(\n    Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=10), type_comment=Name(id=\'int\', ctx=Load())),\n    Assign(targets=[Name(id=\'b\', ctx=Store())], value=None, type_comment=Name(id=\'int\', ctx=Load())),\n)')
    assert_equal(result.tree_changed, True)
    assert_equal(result.warnings, [])


# Generated at 2022-06-23 23:30:50.763434
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3,5)
   

# Generated at 2022-06-23 23:31:00.573869
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import build_tree, print_tree

    tree = build_tree(ast.Module, [
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Store()), value=ast.Num(n=10)),
        ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Store()), value=None)
    ])

    trans = VariablesAnnotationsTransformer()
    out = trans.transform(tree)

    print(out)
    assert len(out.tree.body) == 2

# Generated at 2022-06-23 23:31:03.277566
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from tests.utils import generate_dummy_node_tree
    # test that it successfully throws an error with a wrong version