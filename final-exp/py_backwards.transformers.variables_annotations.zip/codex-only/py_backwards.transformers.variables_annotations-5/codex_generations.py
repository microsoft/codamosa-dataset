

# Generated at 2022-06-23 23:21:07.937776
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .variables_annotation_transformer import VariablesAnnotationsTransformer
    from ..utils import get_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:21:12.152460
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    code = """
a: int = 10
b: int
"""
    tree = ast.parse(code)
    t.transform(tree)
    expected_result = ast.parse("""
a = 10
""")
    assert ast.dump(tree) == ast.dump(expected_result)

# Generated at 2022-06-23 23:21:14.319585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_class = VariablesAnnotationsTransformer
    test_instance = test_class()
    assert test_instance.target == (3, 5)


# Generated at 2022-06-23 23:21:15.597666
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import source_to_nodes, nodes_to_source

# Generated at 2022-06-23 23:21:16.279966
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(1) == None

# Generated at 2022-06-23 23:21:19.222489
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5)
    assert vat.transform("a: int") == "a"
    assert vat.transform("a: int = 10") == "a = 10"
    assert vat.transform("b: int") == "b"

# Generated at 2022-06-23 23:21:22.285632
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import get_tree_string
    from ..utils.helpers import compile_snippet

    tree = compile_snippet('a: int')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert get_tree_string(tree) == ''

# Generated at 2022-06-23 23:21:26.493120
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    strings = [
        "a : int = 10\nb: int"
    ]

    for test in strings:
        tree = ast.parse(test)
        VariablesAnnotationsTransformer.transform(tree)
        print(ast.dump(tree))

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:21:28.357794
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int")).ast_changed == True


# Generated at 2022-06-23 23:21:33.776409
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    annotation_list = []
    n = ast.AnnAssign(annotation=annotation_list)
    n.value = None
    node_list = [n]

    # Act
    result = VariablesAnnotationsTransformer.transform(node_list)

    # Assert
    assert node_list == result[0]
    assert result[1] == True
    assert result[2] == []

# Generated at 2022-06-23 23:21:37.655610
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)

    expected = """
    a = 10
    """

    VariablesAnnotationsTransformer.transform(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:21:38.203133
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:21:41.274166
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    run_test(VariablesAnnotationsTransformer, "test/data/variables_annotations_test.py", "test/data/variables_annotations_result.py")

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:21:45.404073
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3, 5)
    x = VariablesAnnotationsTransformer.transform("a: int = 10")
    x = VariablesAnnotationsTransformer.transform("b: int")
    assert x is None

# Generated at 2022-06-23 23:21:50.857485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    transformed_tree = VariablesAnnotationsTransformer.transform(tree)
    transformed_tree_expected = ast.parse("a = 10")
    assert twisted.trial.unittest.SynchronousTestCase.assertEqual(transformed_tree.modified_tree, transformed_tree_expected)
#
# tree = ast.parse("a: int = 10")
# print(astor.to_source(tree))

# Generated at 2022-06-23 23:21:58.850841
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1
    test_case_1 = '''
        a: int = 10   # check
        b: int        # check
    '''
    tree_1 = ast.parse(test_case_1)
    tree_1 = VariablesAnnotationsTransformer(3, 5).visit(tree_1)
    expected_code_1 = '''
        a = 10   # check
    '''
    assert ast.dump(tree_1) == ast.dump(ast.parse(expected_code_1))

    # Test case 2
    test_case_2 = '''
        a: int = 10   # check
        b: int        # check
        a = b
    '''
    tree_2 = ast.parse(test_case_2)

# Generated at 2022-06-23 23:22:03.455619
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  t = ast.parse('a: int = 1')
  print(VariablesAnnotationsTransformer.transform(t).tree)
  t = ast.parse('b: int')
  print(VariablesAnnotationsTransformer.transform(t).tree)

if __name__ == "__main__":
  test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:22:08.320602
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import generate_module_and_type_store

    m, t = generate_module_and_type_store("""
            def f():
                a: int = 10  # type: ignore
                b: int

        """)
    assert str(m) == """
        def f():
            a = 10  # type: ignore
    """

# Generated at 2022-06-23 23:22:11.665305
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a = 10').body[0]
    assert node.__class__.__name__ == 'AnnAssign'
    tree = VariablesAnnotationsTransformer.transform(node)
    assert tree.changed is True


# Generated at 2022-06-23 23:22:15.631278
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer([ast.AnnAssign(target=ast.Name(id='a',ctx=ast.Store()),annotation=ast.Name(id='int',ctx=ast.Load()),value=ast.Num(n=10))])
    assert t.transform(ast.Module())

# Generated at 2022-06-23 23:22:17.965233
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transform

    assert_transform(VariablesAnnotationsTransformer,
    """
    def function():
        a: int = 10
        b: int
    """,
    """
    def function():
        a = 10
    """)

# Generated at 2022-06-23 23:22:18.367591
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:22:25.290428
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Transformation:
    #     In:
    #         a: int = 10
    #         b: int
    #     Out:
    #         a = 10
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_files',
                           'test_variables_annotations_transformer_res.py')) as f:
        expected_res = f.read()
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_files',
                           'test_variables_annotations_transformer.py')) as f:
        tree = ast.parse(f.read(), type_comments=True)
    transformed_tree = VariablesAnnotationsTransformer.transform(tree)


# Generated at 2022-06-23 23:22:27.753314
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from ..utils import dump
    from ..main import transform_code
    node = ast.parse('a: int = 10')
    out = transform_code(node, {VariablesAnnotationsTransformer})
    expected = ast.parse('a = 10')
    assert dump(out) == dump(expected)


# Generated at 2022-06-23 23:22:29.010673
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer is not None


# Generated at 2022-06-23 23:22:30.620186
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from tests.fixtures import transformer_test
    transformer = VariablesAnnotationsTransformer()
    transformer_test(transformer)

# Generated at 2022-06-23 23:22:34.301649
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
            a: int = 10
            b: int
        """

    tree = ast.parse(code)
    result, changed, messages = VariablesAnnotationsTransformer.transform(tree)
    assert changed, 'Tree should have been changed'
    assert codes(result) == "a = 10"

# Generated at 2022-06-23 23:22:43.525977
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:22:48.989419
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import cst
    cst.t_ast_name()
    assert cst.t_ast_name() == "ast"
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    r = VariablesAnnotationsTransformer.transform(tree)
    assert r.tree.body[0].__class__.__name__ == "Assign"

# Generated at 2022-06-23 23:22:53.916378
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a,b = ast.parse("""a: int = 10\n b : int\n""").body
    vart = VariablesAnnotationsTransformer()
    vart.transform(a)
    vart.transform(b)
    assert a == ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Constant(value=10), type_comment=ast.Constant(value=int))
    assert b == ast.Expr(value=ast.NameConstant(value=None))

# Generated at 2022-06-23 23:22:54.649753
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:22:55.694824
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_object = VariablesAnnotationsTransformer()



# Generated at 2022-06-23 23:23:00.847114
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10', mode='exec')
    tree_changed, warnings = VariablesAnnotationsTransformer.transform(tree)
    assert type(tree_changed) == ast.Module
    assert len(warnings) == 0
    for node in ast.walk(tree_changed):
        if type(node) == ast.AnnAssign:
            assert False
        if type(node) == ast.Assign:
            assert node.targets[0].id == 'a'
            assert node.value.n == 10


# Generated at 2022-06-23 23:23:09.042692
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import dump, parse

    src = 'a: int = 10'
    expected_ast = parse(src)
    ast_tree = parse(src)
    res, changed, errors = VariablesAnnotationsTransformer.transform(ast_tree)
    assert not changed
    assert not errors
    assert dump(res) == dump(expected_ast)

    # Test wrong type
    src = 'a,b = 10, 20'
    ast_tree = parse(src)
    res, changed, errors = VariablesAnnotationsTransformer.transform(ast_tree)
    assert not changed
    assert not errors
    assert dump(res) == dump(ast_tree)


# Generated at 2022-06-23 23:23:10.432114
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = VariablesAnnotationsTransformer()



# Generated at 2022-06-23 23:23:18.093198
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import transform
    from ..types import Module
    from astunparse import unparse
    from .test_utils import compare_ast

    code = '''
a: int = 10
b: int
'''
    original_tree = ast.parse(code)
    tree = original_tree.body[0]
    Module.original_source = code
    Module.tree = original_tree

    compare_ast(VariablesAnnotationsTransformer.transform(tree), '''
a = 10
''')
    compare_ast(unparse(ast.parse(code)), '''
a: int = 10
b: int
''')

# Generated at 2022-06-23 23:23:18.631255
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert True

# Generated at 2022-06-23 23:23:22.372981
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse(
    """
    a: int = 10
    b: int
    """
    )
    y = ast.parse(
    """
    a = 10
    """
    )
    z = VariablesAnnotationsTransformer.transform(x)
    assert y == z[0]

# Generated at 2022-06-23 23:23:28.574879
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from textwrap import dedent
    from darglint.config import Config
    from darglint.parser import Parser

    config = Config()
    parser = Parser()
    tree = parser.parse(dedent(
        """
        def test_func(a: int = 10, b: int):
            pass
        """
    ))
    transformer = VariablesAnnotationsTransformer(config)
    assert transformer.transform(tree) == TransformationResult(
        get_ast(dedent(
            """
            def test_func(a = 10, b):
                pass
            """
        )),
        True,
        []
    )

# Generated at 2022-06-23 23:23:35.759800
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test for the VariablesAnnotationsTransformer class."""
    # Test for class constructor
    assert VariablesAnnotationsTransformer.__name__ == \
           "VariablesAnnotationsTransformer"
    assert VariablesAnnotationsTransformer.__doc__ is not None
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.fast_forward == \
           BaseTransformer.fast_forward
    assert VariablesAnnotationsTransformer.transform is not None


# Generated at 2022-06-23 23:23:37.847198
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    v = VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:23:40.246319
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_builder import build_ast
    from ..utils.tree import ast2source
    from .declarations_transformer import DeclarationsTransformer


# Generated at 2022-06-23 23:23:48.392196
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_ast_from_file

    tree = get_ast_from_file('tests/samples/3.5/variables_annotations.py')
    transformer = VariablesAnnotationsTransformer()
    new_tree = transformer.transform(tree)

    assert new_tree.body[0].value.value == 10
    assert isinstance(new_tree.body[0], ast.Assign)

    assert isinstance(new_tree.body[-1], ast.Expr)
    assert isinstance(new_tree.body[-1].value, ast.Name)

# Generated at 2022-06-23 23:23:59.921398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #preparing input for constructor
    input1 = ast.AnnAssign(target = ast.Name(id = 'a', ctx = ast.Store()), annotation = ast.Name(id = 'int', ctx = ast.Load()), value = ast.Constant(value = 10, kind = None), simple = 0)
    input2 = ast.AnnAssign(target = ast.Name(id = 'b', ctx = ast.Store()), annotation = ast.Name(id = 'int', ctx = ast.Load()), value = None, simple = 0)
    #preparing expected output

# Generated at 2022-06-23 23:24:08.798768
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    im = ast.Import(names=[ast.alias(name='datetime', asname='datetime')])
    c = [ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation = ast.Name(id = "int", ctx = ast.Load()), value = ast.Num(n = 10), simple = 1), ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation = ast.Name(id = "int", ctx = ast.Load()), value = None, simple = 0)]
    f = ast.FunctionDef(name='f', body=c, args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]))

# Generated at 2022-06-23 23:24:18.057232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import transformer_test

    def test_variables(module):
        assert isinstance(module.body[0].targets[0], ast.Name)
        assert module.body[0].targets[0].id == 'a'
        assert module.body[0].value.n == 10
        assert isinstance(module.body[1].targets[0], ast.Name)
        assert module.body[1].targets[0].id == 'b'
        assert module.body[1].value is None

    transformer_test(VariablesAnnotationsTransformer, 'a: int = 10\nb: int',
                     test_variables)


# Generated at 2022-06-23 23:24:23.144460
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(str(VariablesAnnotationsTransformer.transform(ast.parse("""a: int = 10"""))) ==
"""
Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))
""")

assert(str(VariablesAnnotationsTransformer.transform(ast.parse("""a: int"""))) ==
"""
""")

# Generated at 2022-06-23 23:24:25.911152
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse("a: int = 10")
    ) == TransformationResult(
        ast.parse("a = 10"),
        True,
        []
    )

# Generated at 2022-06-23 23:24:36.230407
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Tests that code like the following:
        # a: int = 10
        # b: int
    # Is transformed to:
        # a = 10

    class TestTransformationResult:
        def __init__(self, tree, tree_changed, messages):
            self.tree = tree
            self.tree_changed = tree_changed
            self.messages = messages

        def __eq__(self, other):
            return (self.tree == other.tree and
                    self.tree_changed == other.tree_changed and
                    self.messages == other.messages)
    
    code_string = 'a: int = 10\nb: int'
    tree = ast.parse(code_string)
    tree_changed = True
    messages = []


# Generated at 2022-06-23 23:24:41.868364
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3

    tree = ast3.parse("""
    a: int = 10
    b: int
    """)

    expected_tree = ast3.parse ("""
    a = 10
    """)

    transformer = VariablesAnnotationsTransformer()

    # Act
    actual_tree, tree_changed = transformer.transform(tree)

    # Assert
    assert tree_changed
    assert ast3.dump(actual_tree, include_attributes=True) == ast3.dump(expected_tree, include_attributes=True)

# Generated at 2022-06-23 23:24:48.918925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test for constructor of class VariablesAnnotationsTransformer"""
    import inspect
    import ast
    import sys
    import os
    sys.path.insert(0, os.path.abspath(inspect.getfile(inspect.currentframe())))
    import py2typed3
    res = py2typed3.run('test.test_input.test_input_6')

    # Checking the values of the object attributes of class VariablesAnnotationsTransformer
    assert isinstance(res.tree, ast.AST)
    assert res.tree_changed == False
    assert res.nodes == []



# Generated at 2022-06-23 23:24:55.721780
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    module = ast.Module([
        ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),  # type: ignore
            annotation=ast.Num(n=1),
            value=ast.Num(n=2),
        )
    ])

    new_tree = VariablesAnnotationsTransformer(3.5).visit(module)
    assert isinstance(new_tree.body[0], ast.Assign)

# Generated at 2022-06-23 23:24:56.305459
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:24:58.752808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  subtree = ast.parse('a: int = 10\nb: int = 11')
  subtree2 = ast.parse('a = 10')
  t = VariablesAnnotationsTransformer()
  assert t.transform(subtree) == (subtree2, True, [])

# Generated at 2022-06-23 23:25:01.681560
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ...test_transformer import run_test_transform
    from ..transformers.nodes import IfStatementTransformer
    from ..transformers.nodes import StringFormatTransformer


# Generated at 2022-06-23 23:25:03.068827
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = VariablesAnnotationsTransformer(None, None)

# Generated at 2022-06-23 23:25:09.427610
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import sys
    import io
    import astunparse

    code = """
        a: int = 10
        b: int
    """
    expected_code = """
        a = 10
    """

    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    f = io.StringIO()
    sys.stdout = f
    astunparse.unparse(new_tree)
    output = f.getvalue()

    assert output == expected_code

# Generated at 2022-06-23 23:25:15.748891
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = """
b = 1
c = 2
while b < c:
    b += 1
    while b < c:
        a: int
"""
    expected_output = """
b = 1
c = 2
while b < c:
    b += 1
    while b < c:
        pass
"""
    tree = ast.parse(input)
    VariablesAnnotationsTransformer.transform(tree)
    actual_output = ast.unparse(tree)
    assert expected_output == actual_output

# Generated at 2022-06-23 23:25:16.893569
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast  # type: ignore

# Generated at 2022-06-23 23:25:17.691492
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:25:23.159732
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # It should add parent to the class VariablesAnnotationsTransformer
    a1 = VariablesAnnotationsTransformer()
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)
    assert isinstance(a1, BaseTransformer)

# Generated at 2022-06-23 23:25:28.692501
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    from ..utils.source import source_to_code

    code1 = source_to_code('''
    a: int = 10
    b: int
    ''')

    code2 = source_to_code('''
    a = 10
    ''')
    tree = ast.parse(code1)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert code2 == astor.to_source(tree)



# Generated at 2022-06-23 23:25:30.279526
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer"


# Generated at 2022-06-23 23:25:35.155220
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """ Tests transform method of VariablesAnnotationsTransformer
    """
    from ..utils.source import source_to_tree
    from ..utils.helpers import print_tree
    from .for_if_transformer import ForIfTransformer
    source = 'a: int=10'
    tree = source_to_tree(source)
    print_tree(tree)
    ForIfTransformer().transform(tree)
    print_tree(tree)
    VariablesAnnotationsTransformer().transform(tree)
    print_tree(tree)

# Generated at 2022-06-23 23:25:37.022207
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None) is None


# Generated at 2022-06-23 23:25:40.517190
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    test_obj = VariablesAnnotationsTransformer()
    incorrect_obj = VariablesAnnotationsTransformer("Hello", "World")

    



# Generated at 2022-06-23 23:25:43.406509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    constructor = VariablesAnnotationsTransformer
    assert constructor.target == (3, 5)
    assert isinstance(constructor.transform(ast.parse('')), TransformationResult)

# Generated at 2022-06-23 23:25:47.014296
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
        """
        a: int = 10
        b: int
        """
    )
    expected = ast.parse(
        """
        a = 10   
        """
    )

    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree) == expected

# Generated at 2022-06-23 23:25:49.718127
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Testing for constructor
    obj = VariablesAnnotationsTransformer()

    assert obj.target == (3, 5), f"Should be (3, 5), got {obj.target}"


# Generated at 2022-06-23 23:25:53.322139
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree.body[0].value.n == 10
    assert isinstance(result.tree.body[0], ast.Assign)
    assert isinstance(result.tree.body[1], ast.Pass)

# Generated at 2022-06-23 23:25:59.547538
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_test_data, parse_test_data

    def test(test_data: str) -> bool:
        tree = parse_test_data(test_data, to_new_style=True)
        VariablesAnnotationsTransformer.transform(tree)
        return tree == parse_test_data(test_data, to_new_style=True)

    assert test(get_test_data('test/samples/variables_annotations_1.py'))

# Generated at 2022-06-23 23:26:04.398920
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    # Check constructor of class VariablesAnnotationsTransformer
    inp = "stock = 'AAPL'\nprice: float = 100\nprint(stock)"
    out = "stock = 'AAPL'\nprint(stock)"
    assert VariablesAnnotationsTransformer.change(inp) == out


# Generated at 2022-06-23 23:26:07.682795
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import check_equal
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer

    check_equal(isinstance(VariablesAnnotationsTransformer(), BaseTransformer), True)

# Generated at 2022-06-23 23:26:10.461285
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-23 23:26:11.666366
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)

# Generated at 2022-06-23 23:26:22.355627
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = load_example("ann_assign_example")
    a = VariablesAnnotationsTransformer()
    b = a.transform(tree)
    s = dump_tree(b.tree)
    s_expected = '''Module(body=[
    Assign(targets=[Name(id='a', ctx=Store(), annotation=None)], value=Num(n=10)),
    Assign(targets=[Name(id='b', ctx=Store(), annotation=None)], value=Num(n=20))])'''
    assert s_expected == s

if __name__ == "__main__":
    import sys
    from . import load_example

    fail_count, tests = 0, 0
    for name, func in globals().items():
        if name.startswith('test_'):
            print

# Generated at 2022-06-23 23:26:22.972728
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:26:31.681421
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    # Arrange
    class_data = [
        ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), value=ast.Constant(value=10, kind=None)),
        ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), value=ast.Constant(value=10, kind=None))
    ]

    class_func_data = [
        ast.FunctionDef(name='my_function', body=class_data, args=ast.arguments(args=[],
                                                                                vararg=None,
                                                                                kwonlyargs=[],
                                                                                kwarg=None,
                                                                                defaults=[],
                                                                                kw_defaults=[]))
    ]

    class_

# Generated at 2022-06-23 23:26:33.345026
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_root
    from ..utils.helpers import compare_trees


# Generated at 2022-06-23 23:26:36.291767
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    program_ast = ast.parse('a: int = 10\nb: int')
    new_program_ast, changed, messages = VariablesAnnotationsTransformer.transform(program_ast)
    return new_program_ast, changed, messages



# Generated at 2022-06-23 23:26:38.593527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test if we can initialize an object of the class VariablesAnnotationsTransformer
    a = VariablesAnnotationsTransformer()
    assert a



# Generated at 2022-06-23 23:26:40.670157
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')).tree == ast.parse('a = 10')

# Generated at 2022-06-23 23:26:45.750603
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """
        a: int = 10
        b: int
    """
    expected_code = """
        a = 10
    """
    tree = ast.parse(input_code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert ast.dump(ast.fix_missing_locations(result.new_tree)) == expected_code

# Generated at 2022-06-23 23:26:55.922085
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_base import compile_func
    from typed_ast import ast3 as ast
    from ..utils.helpers import dump
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    test_input = """
    def a(x: int, y: List[int], z: List[int] = []):
        pass
    """
    test_output = """
    def a(x, y, z = []):
        pass
    """
    tree = compile_func(test_input, "test", "exec")
    func = find(tree, ast.FunctionDef)[0]
    vat = VariablesAnnotationsTransformer.transform(tree)
    assert dump(vat.tree) == test_output
    vat.tree = tree

# Generated at 2022-06-23 23:26:59.664885
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    expected_tree = ast.parse('a = 10')

    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(expected_tree) == ast.dump(new_tree)

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:27:05.013509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast import parse
    from textwrap import dedent
    from typed_ast import ast3 as ast
    from lark import Lark

    t = VariablesAnnotationsTransformer()

    assert t.target == (3, 5)

    code = dedent('''\
        def foo():
            a: int = 10
            b: int
    ''')

    tree = parse(code, mode='exec')

    t.transform(tree)

# Generated at 2022-06-23 23:27:08.555723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int\n')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == 'a = 10\n'

# Generated at 2022-06-23 23:27:11.964128
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
    def add(a: int = 10, b: int):
        a: int = 10
    """

    tree = ast.parse(source)
    VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:27:18.024376
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code= "a: int = 10 \nb: int"
    expected_code= "a = 10"
    res = VariablesAnnotationsTransformer.transform(astor.parse_file(input_code))
    assert(astor.to_source(res.new_tree)==expected_code)


if __name__ == "__main__":
    VariablesAnnotationsTransformer.transform()

# Generated at 2022-06-23 23:27:24.766285
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    compiler = VariablesAnnotationsTransformer()

    # Test when a value is assigned for a variable
    """Compiles:
        a: int = 10
    To:
        a = 10
    """
    tree = ast.parse('a: int = 10')
    new_tree, changed, flags = compiler.transform(tree)
    assert changed
    assert len(new_tree.body) == 1
    assert isinstance(new_tree.body[0], ast.Assign)
    assert new_tree.body[0].targets[0].id == 'a'
    assert isinstance(new_tree.body[0].value, ast.Num)
    assert new_tree.body[0].value.n == 10
    assert new_tree.body[0].type_comment is None

    # Test when a value is assigned for a variable

# Generated at 2022-06-23 23:27:36.669251
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils import dump

    code = """
from typing import Dict, List

a: int = 10
b: List[int] = [1, 2, 3]
"""
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)


# Generated at 2022-06-23 23:27:40.275152
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('Unit test for constructor of class VariablesAnnotationsTransformer')
    tree = ast.parse('a: int = 10\nb: int')
    VariablesAnnotationsTransformer.transform(tree)
    assert(str(tree)=='a = 10\n')
    print('Done!')

# Generated at 2022-06-23 23:27:46.739068
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from ..types import TransformationResult

    tree = ast.parse('a: int = 10\n b: int')
    transformer = VariablesAnnotationsTransformer(tree)
    result = transformer.transform()
    assert isinstance(result, TransformationResult)
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].type_comment.id == 'int'

# Generated at 2022-06-23 23:27:55.408925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with VariablesAnnotationsTransformer.patch():
        import astor
        test1 = ast.parse('a: int = 10')
        VariablesAnnotationsTransformer.transform(test1)
        assert astor.to_source(test1) == 'a = 10'
        test2 = ast.parse('a: int')
        VariablesAnnotationsTransformer.transform(test2)
        assert astor.to_source(test2) == 'a'
        test3 = ast.parse('a: int = 10\nb: int\nc: int = 20')
        VariablesAnnotationsTransformer.transform(test3)
        assert astor.to_source(test3) == 'a = 10\nc = 20'

# Generated at 2022-06-23 23:28:00.299306
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree: ast.Module = ast.parse('''
        a: int = 10
        b: int
        c: int = 20.0
        d: int = 'ciao'
    ''')
    VariablesAnnotationsTransformer.transform(tree)

    # When
    class_transformer = VariablesAnnotationsTransformer()

    # Then
    assert class_transformer is not None

# Generated at 2022-06-23 23:28:04.259433
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(module)

    expect = ast.parse("""
    a = 10
    """)

    assert ast.dump(result.node) == ast.dump(expect)

# Generated at 2022-06-23 23:28:12.586750
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    sample_input =  """
                    a: int = 10
                    b: int = 20
                    """
    expected_output = """
                    a = 10
                    b = 20
                    """
    t = VariablesAnnotationsTransformer()
    tree = ast.parse(sample_input, "", "exec")
    t.transform(tree)
    expected_tree = ast.parse(expected_output, "", "exec")
    print(ast.dump(tree))
    print(ast.dump(expected_tree))
    assert ast.dump(tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)
    print("Test Passed")

# Generated at 2022-06-23 23:28:21.397282
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from .base import BaseTransformer
    import astor
    a = ast3.AnnAssign(target=ast3.Name(id='a',
                                   ctx=ast3.Load()),
                      annotation=ast3.Name(id='int',
                                     ctx=ast3.Load()),
                      value=ast3.Num(n=10),
                      simple=1)
    c = ast3.Assign(targets=[ast3.Name(id='a',
                                       ctx =ast3.Load())],
                      value=ast3.Num(n=10),
                      type_comment=ast3.Name(id='int',
                                     ctx=ast3.Load()))

# Generated at 2022-06-23 23:28:26.373963
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import numpy
    input_code = """import numpy
a: int = 10
b: int"""
    expected_code = """import numpy
a = 10"""
    tree = ast.parse(input_code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-23 23:28:30.810219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    code = 'a: int = 10\nb: int'
    tree = ast.parse(code)
    expected_code = 'a = 10\nb: int'
    transformed_tree, tree_changed, _ = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(transformed_tree).strip() == expected_code
    assert tree_changed



# Generated at 2022-06-23 23:28:33.493805
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree).new_tree == ast.parse("a = 10")

# Generated at 2022-06-23 23:28:35.701300
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vannotransformer = VariablesAnnotationsTransformer()
    assert vannotransformer.target == (3, 5)


# Generated at 2022-06-23 23:28:42.978336
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor  # type: ignore
    from ..utils.helpers import get_func_body

    # Assignments
    tree = astor.parse("""
        a: int = 10
        b: int
    """)
    expected = astor.parse("""
        def __test__():
            a = 10
    """)
    body = get_func_body(VariablesAnnotationsTransformer.transform(tree=tree).tree)
    assert astor.to_source(body[0]) == astor.to_source(expected.body[0].body[0])



# Generated at 2022-06-23 23:28:47.931800
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  # Code Before Transformation
  code_before = '''
name: str = ""
print(name)
'''
  # Code After Transformation
  code_after = '''
name = ""
print(name)
'''
  # Perform AST Transformation
  result, msg = VariablesAnnotationsTransformer.transform(code_before)
  # Assert the result of transformation
  assert(code_after == result)



# Generated at 2022-06-23 23:28:58.246654
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test_case1: a: int = 10, b: int
    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10))
    node2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=None)
    test_case1 = ast.Module(body=[node1, node2])

    tree_changed, new_tree = VariablesAnnotationsTransformer.transform(test_case1)
    assert tree_changed

# Generated at 2022-06-23 23:29:00.305134
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code_in = '''
a: int = 10
b: int
'''
    code_out = '''
a = 10
'''
    assert VariablesAnnotationsTransformer.run_test_function(code_in, code_out)

# Generated at 2022-06-23 23:29:03.212765
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    imported = VariablesAnnotationsTransformer.transform(tree)
    assert imported.tree == ast.parse("""
            a = 10
            b = """)
    assert imported.changed == True
    assert imported.warnings == []


# Generated at 2022-06-23 23:29:14.260010
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import generate_source
    from .StatementsOrderTransformer import StatementsOrderTransformer

    tree = ast.parse(generate_source(
        '''
        a: int = 10
        b: int
        '''
    ))

# Generated at 2022-06-23 23:29:17.820036
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(
        ast.parse("""
        def func(a:int):
            a: int = 10
            b: int
        """)
    )

# Generated at 2022-06-23 23:29:23.880057
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.visitor import visit_tree
    from ..utils.helpers import full_repr
    from .base import PRINT_TRANSFORMED_TREE
    from ..visitors.tree_visitor import TreeEditorVisitor
    from ..utils.helpers import run_transformer

    code = '''
a: int = 1
b: int
c: int = 3
    '''
    tree = ast.parse(code)
    run_transformer(VariablesAnnotationsTransformer, tree, print_tree=True)

    expected_tree = ast.parse('''
a = 1
c = 3
    ''')

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 3

# Generated at 2022-06-23 23:29:33.482652
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_string = "a:int = 10"
    tree = ast.parse(test_string)
    trans = VariablesAnnotationsTransformer.transform(tree)
    assert len(trans.tree.body) == 1
    assert isinstance(trans.tree.body[0], ast.Assign)
    assert len(trans.tree.body[0].targets) == 1
    assert isinstance(trans.tree.body[0].targets[0], ast.Name)
    assert trans.tree.body[0].targets[0].id == "a"
    assert isinstance(trans.tree.body[0].value, ast.Num)
    assert trans.tree.body[0].value.n == 10
    assert trans.tree.body[0].type_comment == "int"

# Generated at 2022-06-23 23:29:35.410912
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print ("test 1")
    t = VariablesAnnotationsTransformer()
    assert t

# Generated at 2022-06-23 23:29:44.894809
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from astunparse import unparse
    from .utils import roundtrip
    for old_tree in [ast.parse('''
a: str = "asdf"
b: int
c: float = "asdf"
''')]:
        tree_changed, new_tree, _ = VariablesAnnotationsTransformer.transform(old_tree)
        if tree_changed:
            print(unparse(new_tree))
            assert roundtrip(new_tree) == roundtrip(ast.parse('a = "asdf"\nc: float = "asdf"'))

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:29:48.335087
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	
	a = 'a: int = 10' # code snippet which we want to convert
	final_str = VariablesAnnotationsTransformer.transform(a)
	print(final_str)

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:29:57.696954
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # This code has no type annotations
    code = "a = 10"
    parsed = ast.parse(code)

    new_node = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()),
                             annotation=ast.Name(id="int", ctx=ast.Load()),
                             value=ast.Num(n=10),
                             simple=1)
    # This code has no annotations
    code2 = "a = 10"
    parsed2 = ast.parse(code2)
    # Insert the annotation node into the original code
    parsed.body.insert(0, new_node)
    # check that the node we added is at the top of the parsed code
    assert (ast.dump(parsed.body[0])) == (ast.dump(new_node))

   

# Generated at 2022-06-23 23:30:07.901371
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    inp = '''
from typing import List

a: int = 10
b: int = 20
c = 30
d = 40
'''

    out = '''
from typing import List

a = 10
d = 40
'''

    tree = ast.parse(inp)

    t = VariablesAnnotationsTransformer()
    new_tree = t.transform(tree)

    assert ast.dump(new_tree.tree, include_attributes=False) == ast.dump(ast.parse(out), include_attributes=False)

    # Type checks
    #assert isinstance(new_tree, TransformationResult)
    assert isinstance(new_tree.tree, ast.Module)
    assert new_tree.tree_changed == True
    #assert isinstance(new_tree.messages, list)

# Generated at 2022-06-23 23:30:08.475431
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:16.318863
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t_node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store(), annotation=ast.Str('int')),
                           annotation=ast.Str('int'),
                           value=ast.Num(n=10),
                           simple=1)

    tree = ast.parse('a: int = 10\nb: int ')
    trans = VariablesAnnotationsTransformer()
    new_tree = trans.transform(tree)
    new_t_node = new_tree.body[0]
    assert type(new_t_node) == ast.Assign



# Generated at 2022-06-23 23:30:18.112471
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformation = VariablesAnnotationsTransformer(3, 5)

# Generated at 2022-06-23 23:30:21.386753
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    local_ctx = z3.Context()
    transformer = VariablesAnnotationsTransformer(local_ctx)
    assert transformer.transform(tree)


# Generated at 2022-06-23 23:30:23.018416
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3,5)
    

# Generated at 2022-06-23 23:30:30.234474
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transforms_tree()
    assert VariablesAnnotationsTransformer.transforms_tree(x=1)

# Generated at 2022-06-23 23:30:33.742738
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestVariablesAnnotationsTransformer:
        def test_transformation(self):
            tree = ast.parse("""
            a: int = 10
            b: int
            """)
            VariablesAnnotationsTransformer.transform(tree)

            assert str(tree) == """
            a = 10
            """

# Generated at 2022-06-23 23:30:36.162089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    v = ast.parse('a: int = 5')
    trans = VariablesAnnotationsTransformer()
    ans = trans.transform(v)
    assert isinstance(ans.tree, ast.AST)


# Generated at 2022-06-23 23:30:38.279232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .test_helpers import test_transform


# Generated at 2022-06-23 23:30:40.738807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3, 5)



# Generated at 2022-06-23 23:30:43.976871
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int\n')
    tree_transformed = VariablesAnnotationsTransformer.transform(tree)
    variable_node = tree_transformed.tree.body[0]

# Generated at 2022-06-23 23:30:49.238982
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  trans = VariablesAnnotationsTransformer()
  assert trans.target == (3, 5)
  bad_tree = ast.parse('a: int = 10\nb: int', '', 'exec')
  test_tree = ast.parse('a: int = 10')
  test_trans = VariablesAnnotationsTransformer.transform(test_tree)
  assert bad_tree != test_trans

# Generated at 2022-06-23 23:30:50.305647
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:55.310891
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .ast_converter import Py2PyConverter
    from .ast_analyzer import ASTAnalyzer
    from .ast_converter import Py2PyConverter
    from .ast_analyzer import ASTAnalyzer
    from .type_converter import Py2TypeConverter

    converter = Py2PyConverter(target=VariablesAnnotationsTransformer.target)
    converter.add_transformer(VariablesAnnotationsTransformer)

    analyzer = ASTAnalyzer(Py2TypeConverter())
    analyzer.add_transformer(VariableTypesCollector)
    analyzer.add_transformer(TypeAnnotationsAdder)

    analyzer.add_transformer(ClassDefinitionsCollector)
    analyzer.add_transformer(ClassArgumentsCollector)

# Generated at 2022-06-23 23:31:03.885372
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                        annotation=ast.Name(id='str', ctx=ast.Store()),
                        value=ast.Str(s='hello'), simple=1)
    assert isinstance(var, ast.AnnAssign)
    var_str = ast.parse('a:str = \'hello\'')
    assert isinstance(var_str, ast.AnnAssign)
    var_int = ast.parse('a:int = 10')
    assert isinstance(var_int, ast.AnnAssign)


# Generated at 2022-06-23 23:31:11.021798
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from ..transformers.VariablesAnnotationsTransformer import VariablesAnnotationsTransformer

    a: ast.AnnAssign = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Num(n=10),
        simple=1)
    b: ast.AnnAssign = ast.AnnAssign(
        target=ast.Name(id='b', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=None,
        simple=0)
    module = ast.Module([a,b])

    VariablesAnnotationsTransformer.transform(module)
   