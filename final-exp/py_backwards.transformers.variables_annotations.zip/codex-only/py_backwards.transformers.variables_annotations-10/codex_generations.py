

# Generated at 2022-06-23 23:21:11.568915
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import pprint_ast

    print('AST before:')
    print('------------')
    pprint_ast(ast.parse(
        '''def a ():
            a: int = 10
            b: int
        '''
    ))

    print('\nAST after:')
    print('------------')
    result = VariablesAnnotationsTransformer.transform(ast.parse(
        '''def a ():
            a: int = 10
            b: int
        '''
    ))
    pprint_ast(result.new_tree)

# Generated at 2022-06-23 23:21:15.350807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('a: int = 10\nb: int')
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree == typed_ast.ast3.parse('a = 10\nb')
    assert isinstance(tree_changed, TransformationResult)

# Generated at 2022-06-23 23:21:18.719850
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
        unit = ast.parse('''foo: int
foo: int = 1
bar: int = 2
foo: int = 3''')
        target = ast.parse('''foo: int

bar = 2
foo = 3''')
        assert VariablesAnnotationsTransformer.transform(unit)[0] == target


# Generated at 2022-06-23 23:21:21.506189
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    expected_output = ast.parse("a = 10")
    input_code = ast.parse("a: int = 10")

    result = VariablesAnnotationsTransformer.transform(input_code)

    assert result.tree == expected_output
    assert result.tree_changed == True
    assert result.removed_nodes == []

# Generated at 2022-06-23 23:21:22.966475
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .transformer_test_template import _test_transformer
    _test_transformer(VariablesAnnotationsTransformer)

# Generated at 2022-06-23 23:21:27.555958
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    with open('tests/code/VariableAnnotations.py') as f:
        tree = ast.parse(f.read())

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree is not None
    assert tree.changed is True

    expected_code = dedent(
        """\
        def example(
            a: int,
            b: int,
            c: int,
            x: float,
            y: float,
            z: float,
        ) -> float:
            a = 2
            b = 5
            c = 10
            d = a + b + c
            e = a * b * c
            x = 1.0
            y = 1.0
            z = 1.0
            xyz = x + y + z + d + e
            return xyz
    """
    )


# Generated at 2022-06-23 23:21:28.441168
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:21:30.751369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tester = VariablesAnnotationsTransformer()
    assert tester.target == (3, 5)



# Generated at 2022-06-23 23:21:33.006667
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # create a object form class VariablesAnnotationsTransformer
    VariablesAnnotationsTransformer1 = VariablesAnnotationsTransformer()
    print(VariablesAnnotationsTransformer1)

# Generated at 2022-06-23 23:21:35.828303
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformed_tree = VariablesAnnotationsTransformer.transform(ast.parse("a: int\nb: float = 10\n"))
    assert transformed_tree == ast.parse("a\nb = 10")

# Generated at 2022-06-23 23:21:38.829580
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed is True
    assert str(result.tree) == 'a = 10\n'

# Generated at 2022-06-23 23:21:41.999356
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    target = ast.parse("""
        a: int = 10
        b: int
        """)

    # When
    result = VariablesAnnotationsTransformer.transform(target)

    # Then
    expected = ast.parse("""
        a = 10
        b = None
        """)
    print(result, expected)
    assert ast.dump(result.tree) == ast.dump(expected)

# Generated at 2022-06-23 23:21:45.827201
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  a = ast.parse('''
  a: int = 10
  b: int
  ''')

  tree_transformed = TransformationResult(ast.parse('''
  a = 10
  '''), True, [])
  
  assert VariablesAnnotationsTransformer.transform(a) == tree_transformed

# Generated at 2022-06-23 23:21:50.550062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                         annotation=ast.Name(id='int', ctx=ast.Load()),
                         value=ast.Num(n=10), simple=1)
    class_ = VariablesAnnotationsTransformer()
    class_.transform(node)

# Generated at 2022-06-23 23:21:53.824914
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ... import run_main_func
    import astor

    source = """
a: int = 10
b: int
    """

    result = run_main_func(
        VariablesAnnotationsTransformer.transform, source, 3)

    answer = """
a = 10
    """

    assert result == answer

# Generated at 2022-06-23 23:21:54.755994
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer



# Generated at 2022-06-23 23:21:57.150804
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("x: int = 10")
    expected = ast.parse("x = 10")
    VariablesAnnotationsTransformer.test(tree, expected)

# Generated at 2022-06-23 23:22:07.529231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .context import ExampleAST
    from .utils import debug_tree
    from .utils import dump_tree
    from .utils import load_tree
    from .utils import print_tree

    # Tests for transform(self)

    # a: int = 10
    # b: int

# Generated at 2022-06-23 23:22:11.332203
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Unit tests for function VariablesAnnotationsTransformer.transform
import ast as pyast
from typing import List
from ..utils.helpers import node_to_string
from ..utils.tree import tree_to_str
from ..utils.context import Context


# Generated at 2022-06-23 23:22:12.349144
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:22:18.711523
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import AST, parse
    from .stubs import ast_to_code
    import sys

    # VARIABLES_ANNOTATIONS = True
    sys.modules['typed_ast'].VariableAnnotationsTransformer.VARIABLES_ANNOTATIONS = True
    node = parse("""
    a: int = 10
    b: int
    """).body
    expected_node = parse("""
    a = 10
    """)
    assert ast_to_code(node, 'Python35') == ast_to_code(expected_node)



# Generated at 2022-06-23 23:22:28.303746
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Expected output for input_code
    expected_code = \
'''if a == 1:
  c = 10
else:
  c = 20'''
    # The input code
    input_code = \
'''if a == 1:
  c: int = 10  # Comment
else:
  c: int = 20  # Comment'''
    # The expected output
    expected_ast = ast.parse(expected_code)
    expected_code = astor.to_source(expected_ast)
    # Parse the input code into an AST
    input_ast = ast.parse(input_code)
    # The AST before running the transformer
    print('AST before the transformation:\n\n')
    print(astor.to_source(input_ast))
    print('\n')
    # Create an instance of the

# Generated at 2022-06-23 23:22:36.950328
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name("a", ast.Store()), annotation = ast.Name("int"), value = ast.Num(10))
    assert isinstance(node, ast.AST)
    assert isinstance(node, ast.AnnAssign)
    assert isinstance(node.target, ast.Name)
    assert isinstance(node.target.id, str)
    assert node.target.id == "a"
    assert isinstance(node.target.ctx, ast.Store)
    assert node.target.ctx == ast.Store()
    assert isinstance(node.annotation, ast.Name)
    assert isinstance(node.annotation.id, str)
    assert node.annotation.id == "int"
    assert node.annotation.ctx == ast.Load()

# Generated at 2022-06-23 23:22:46.978359
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..types import PythonFile
    import typed_ast.ast3 as ast

    node1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation =ast.Name(id='int', ctx=ast.Load()), value=ast.Num(10), simple=1, type_comment=None)
    node2 = ast.Assign(targets=[ast.Name(id='c', ctx=ast.Store())], value=ast.Num(12), type_comment=None)
    node3 = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=None, type_comment=None)

# Generated at 2022-06-23 23:22:52.851423
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import source_to_code
    from astunparse import unparse
    from .code_writer import CodeWriter

    source = """
    a: int = 10
    b: int
    def foo(c: int):
        d: int
    """
    node = source_to_code(source)
    VariablesAnnotationsTransformer.apply_to_ast(node)
    writer = CodeWriter()
    writer.visit(node)
    print(writer.code)

    print(unparse(node))

# Generated at 2022-06-23 23:22:56.122113
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected = ast.parse('a = 10')
    given = ast.parse('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(given)
    assert ast.dump(expected) == ast.dump(result.tree)
    # print(ast2str(expected))
    # print(result.tree)

# Generated at 2022-06-23 23:22:56.893483
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int = 10
    b: int

# Generated at 2022-06-23 23:22:59.941830
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10
                        b: int 
                        x:int =5
                        y:int =6""")
    expected_tree = ast.parse("""a = 10
                        x =5
                        y =6""")
    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_tree

# Generated at 2022-06-23 23:23:08.631255
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test setup
    import sys
    from python_to_python.transformers.variable_annotations import VariablesAnnotationsTransformer, TransformationResult
    from typed_ast import ast3 as ast

    # When
    result = VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))

    # Then
    assert result == TransformationResult(ast.parse('a = 10'), True, [])

    # When
    result = VariablesAnnotationsTransformer.transform(ast.parse('a: int'))

    # Then
    assert result == TransformationResult(ast.parse('a = None'), True, [])

    # When
    result = VariablesAnnotationsTransformer.transform(ast.parse('a'))

    # Then
    assert result == TransformationResult(ast.parse('a'), False, [])

    # When
   

# Generated at 2022-06-23 23:23:18.589068
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Unit test for @classmethod VariablesAnnotationsTransformer.transform
    """
    # Test case 1
    tree1 = ast.parse("""
        assert a == 'hello'

        def foo():
            a: str = 'hello'
            b: str = 'hi'
            c = 'world'
    """)

    expected1 = ast.parse("""
        assert a == 'hello'

        def foo():
            a = 'hello'
            b = 'hi'
            c = 'world'
    """)

    result = VariablesAnnotationsTransformer.transform(tree1)

    assert expected1 == result.tree

    # Test case 2

# Generated at 2022-06-23 23:23:22.665571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from .base import BaseTransformer

    code = '''
        def foo(x: int) -> None:
            x = 10
            y: int
    '''

    tree = ast3.parse(code)
    assert isinstance(VariablesAnnotationsTransformer.transform(tree), BaseTransformer)

# Generated at 2022-06-23 23:23:23.826422
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(isinstance(VariablesAnnotationsTransformer(),
                      VariablesAnnotationsTransformer))

# Generated at 2022-06-23 23:23:24.643571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert 1 == 1, "Test not implemented"

# Generated at 2022-06-23 23:23:27.667339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    source = """
    a: int
    a = 10
    """

    expected = """
    a = 10
    """

    # When
    result = VariablesAnnotationsTransformer.transform(source)

    # Then
    assert result.new_source == expected
    assert result.tree_changed == True

# Generated at 2022-06-23 23:23:36.112126
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.Module([ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                                                 annotation=ast.Name(id='int', ctx=ast.Load()),
                                                 value=ast.Num(n=10))])
    result = VariablesAnnotationsTransformer.transform(node)

    new_node = result.new_node
    assert new_node.body[0].value.n == 10
    assert new_node.body[0].targets[0].id == 'a'
    assert new_node.body[0].annotation == None

# Generated at 2022-06-23 23:23:37.002436
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:23:47.329669
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from language_formatters_preprocessor.utils.helpers import get_ast
    import ast
    import StringIO
    code = StringIO.StringIO('''
    a:int = 5
    b:int
    ''')
    tree = get_ast(code)
    original_tree = tree
    res = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-23 23:23:49.254381
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign()
    assert(VariablesAnnotationsTransformer.transform(a))

# Generated at 2022-06-23 23:24:00.870037
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import load_and_run_transformer
    from .annotations_transformer import AnnotationsTransformer

    module_str = [
        '# comment',
        '# comment2',
        'foo: int = 10',
        'bar: int'
    ]
    module_ast = parse('\n'.join(module_str)).body[0]
    transformed_module_ast = load_and_run_transformer(
        AnnotationsTransformer, module_ast)
    transformed_module_ast = load_and_run_transformer(
        VariablesAnnotationsTransformer, transformed_module_ast)

    assert isinstance(transformed_module_ast, ast.Module)
    assert len(transformed_module_ast.body) == 2

# Generated at 2022-06-23 23:24:04.253881
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import dump
    from ..utils.tree import build

    tree = ast.parse('a: int = 10\n'
                     'b: int')
    VariablesAnnotationsTransformer.transform(build(tree))

# Generated at 2022-06-23 23:24:05.275710
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # TODO: Make a unit test using assert()
    pass

# Generated at 2022-06-23 23:24:09.937057
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    node = ast.parse('a: int', mode='eval').body
    assert VariablesAnnotationsTransformer.transform(node) is None
    assert node.body[0].__class__ == ast.AnnAssign
    node = ast.parse('a: int = 10', mode='eval').body
    assert VariablesAnnotationsTransformer.transform(node) is None
    assert node.body[0].__class__ == ast.Assign

# Generated at 2022-06-23 23:24:13.140644
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    stmt = "a: int = 10"
    tree = ast.parse(stmt).body[0]
    print(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-23 23:24:14.124529
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:24:23.296080
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..runner import Runner
    from ..types import Target
    from ..utils.helpers import is_equal_code
    import os

    source_code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    path = os.path.dirname(os.path.abspath(__file__))
    target = Target(path=path, module_name='test')

    result = Runner(
        target=target,
        source_code=source_code,
        transformer=VariablesAnnotationsTransformer,
    ).run()
    assert is_equal_code(result.code, expected_code)



# Generated at 2022-06-23 23:24:29.098270
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    s = """
    a: int = 10
    b = 3
    """
    t = ast.parse(s)
    c = VariablesAnnotationsTransformer.transform(t)
    assert c.tree_changed
    assert c.report == []
    expected_tree_str = """
    a = 10
    b = 3
    """
    assert astor.to_source(c.ast) == expected_tree_str
    assert c.verifier_errors == []

if __name__ == "__main__":
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:24:38.849496
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # The code below is written in python3.6 style in order to be validated.

    '''
    class Temp:
        a: int = 10
        b: int
    '''

    a = 10

    class Temp:
        b = None


# Generated at 2022-06-23 23:24:47.159044
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse('a: int = 10\nb: int')
    transformed = VariablesAnnotationsTransformer().transform(x)
    assert transformed.tree.body[0].value is None
    assert isinstance(transformed.tree.body[0].target, ast.Name)
    assert transformed.tree.body[0].target.id == 'a'
    assert isinstance(transformed.tree.body[1], ast.Assign)
    assert transformed.tree.body[1].targets[0].id == 'b'
    assert transformed.tree.body[1].value.n == 10
    assert transformed.tree.body[1].value.ctx == ast.Load
    assert transformed.tree.body[1].type_comment == 'int'
    assert transformed.tree_changed

# Generated at 2022-06-23 23:24:48.828728
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    from typed_ast import ast3


# Generated at 2022-06-23 23:24:50.261547
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.parse("a: int"))

# Generated at 2022-06-23 23:24:59.701709
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Test for Variables Annotations Transformer"""
    from .test_helpers import (transform,
                               assert_equal_ignoring_locations,
                               get_first_node)
    from ..utils.helpers import suppress_warnings
    original_body = """
            a: int = 10
            b: int
        """
    expected_body = """
            a = 10
        """

    tree = transform(VariablesAnnotationsTransformer, original_body)

    assert_equal_ignoring_locations(get_first_node(expected_body), tree)

    with suppress_warnings():
        tree = transform(VariablesAnnotationsTransformer, 'a: int')

    assert_equal_ignoring_locations(get_first_node(''), tree)

# Generated at 2022-06-23 23:25:04.819617
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
        a: int = 10
        b: int = 20
        c: int
    """
    expected_code = """
        a = 10
        b = 20
        c = None
    """

    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(new_tree) == expected_code

# Generated at 2022-06-23 23:25:07.632399
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # all these tests assume that the source is the new version
    # so we need to check that the target is the old version
    assert VariablesAnnotationsTransformer.target == (3, 5)



# Generated at 2022-06-23 23:25:15.355161
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import build_ast
    tree = ast.parse('def foo(a: int = 10, b:bool = False):\n    x:int = 9\n    d:int\n')
    assert isinstance(tree, ast.Module)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.changed == True
    assert isinstance(tree, ast.Module)
    # print(build_ast(tree))
    # print(build_ast(new_tree.tree))

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:25:25.494342
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # code = """
    # def f():
    #     a: int = 10
    #     b: int
    # """
    # tree = ast.parse(code)
    # VariablesAnnotationsTransformer.transform(tree)
    # assert ast.dump(tree) == \
    # """Module(body=[FunctionDef(name='f', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10, kind=None), type_comment='int')], decorator_list=[], returns=None)])"""
    raise NotImplementedError()

# Generated at 2022-06-23 23:25:32.846041
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..lib.to_python import to_python
    from string import Template
    from .test_base_transformer import test_template

    template = Template(test_template)

    for version in [(i, f) for i in range(3, 4) for f in range(0, 10)]:
        # ensure the way to convert the class is still valid.
        python_code = to_python(template.substitute(version=version, transformer='VariablesAnnotationsTransformer'))
        exec(python_code)

        # execute the constructed test
        exec(template.substitute(version=version, transformer='VariablesAnnotationsTransformer'), locals(), globals())

# Generated at 2022-06-23 23:25:37.539838
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astunparse
    from ..utils.helpers import get_ast

    code = 'a: int = 10'
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert astunparse.unparse(tree) == 'a = 10'

# Generated at 2022-06-23 23:25:45.074854
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_changed
    from typed_ast.ast3 import parse

    source = '''
a: int
b: int = 10
c: int = 10 + 10
    '''
    tree = parse(source)
    node_changed = get_node_changed(tree,
                                    VariablesAnnotationsTransformer)

    assert len(node_changed) == 2
    assert node_changed[0].target.id == 'b'
    assert node_changed[1].target.id == 'c'

# Generated at 2022-06-23 23:25:48.176461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    text = 'a: int'
    tree = ast.parse(text)
    VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(tree))

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:25:51.925648
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_test_tree

    tree = get_test_tree('variable_annotations')
    transformed_tree, _, _ = VariablesAnnotationsTransformer.transform(tree)
    assert str(transformed_tree) == 'def f():\n    a = 10\n    b\n    c = 20\n    d = 30'

# Generated at 2022-06-23 23:25:57.757908
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
a: int = 10
b: int
c: List[int] = []
d: List[int] = list()
e: List[int] = list([1, 2, 3])
f: int = 1
g: int = 1 + 2
h: int = 1 and 2
i: int = 4 * 4 + 1
j: int = 4 * (4 + 1)
k: int = a * b + c * d
l: int = (1 + 2) * (3 + 4)
''')
    t = VariablesAnnotationsTransformer()
    t_result = t.transform(tree)

# Generated at 2022-06-23 23:26:03.069998
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x = ast.parse('x: int = 10')
    transformed_tree, changed, errors= VariablesAnnotationsTransformer.transform(x)
    assert(isinstance(transformed_tree, ast.AST))
    assert(changed)
    assert(errors==[])
    assert(len(ast.dump(transformed_tree))==5)

# Generated at 2022-06-23 23:26:04.397174
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert(VariablesAnnotationsTransformer.__name__ == "VariablesAnnotationsTransformer")

# Generated at 2022-06-23 23:26:12.455120
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # build test case
    from typed_ast import ast3 as ast
    from .base import BaseTransformer, TransformationResult
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.tree import get_str_from_ast, is_ast_equal
    from ..utils.helpers import Assert, AssertList
    
    code = """
        a: int = 10
        b: int
    """

    expected_output_code = """
    a = 10
    """

    class_node = ast.parse(code)

    # perform test
    actual_result = VariablesAnnotationsTransformer.transform(class_node)
    actual_output_ast = actual_result.tree
    
    actual_output_code = get_str_from_ast(actual_output_ast)

# Generated at 2022-06-23 23:26:15.386366
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.get_name() == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.is_active() == True


# Generated at 2022-06-23 23:26:25.536069
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testutils import TreeWalker
    from pathlib import Path

    # Test 1.
    code = """\
    a: int = 10
    b: int
    """
    new_code = """\
    a = 10
    """
    tree = TreeWalker(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(new_tree) == new_code

    # Test 2.
    code = """\
    def f() -> int:
        a: int = 10
    """
    new_code = """\
    def f() -> int:
        a = 10
    """
    tree = TreeWalker(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(new_tree) == new_code

    # Test 3.


# Generated at 2022-06-23 23:26:28.151806
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_VariablesAnnotationsTransformer = VariablesAnnotationsTransformer()
    assert class_VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-23 23:26:30.293077
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    instance = VariablesAnnotationsTransformer()
    assert isinstance(instance, VariablesAnnotationsTransformer)
    

# Generated at 2022-06-23 23:26:39.115183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('import typing\n'
                     'def f(x: int, y: int = 10) -> int:\n'
                     '    a: int = 10\n'
                     '    b: int\n'
                     '    return a + b + x\n')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.transformed_tree == ast.parse('import typing\n'
                                                'def f(x, y = 10) -> int:\n'
                                                '    a = 10\n'
                                                '    b\n'
                                                '    return a + b + x\n')
    assert result.tree_changed == True
    assert result.errors == []

# Generated at 2022-06-23 23:26:42.271398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int', '', 'exec')
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    target = ast.parse('a = 10\n', '', 'exec')
    assert result.tree == target

# Generated at 2022-06-23 23:26:43.968426
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_ = VariablesAnnotationsTransformer()

    # Test instance methods
    assert(isinstance(class_.transform(ast.AST()), TransformationResult))

# Generated at 2022-06-23 23:26:50.698554
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # define the class to be tested
    VariablesAnnotationsTransformer = VariablesAnnotationsTransformer
    # define the class to be tested
    target = (3, 5)
    # define the expected result after transforming the tree
    # for test case 4
    expectedResult4 = TransformationResult(
        tree=ast.parse('a = 10'),
        treeChanged=True,
        warnings=[]
    )
    # define the expected result after transforming the tree
    # for test case 5
    expectedResult5 = TransformationResult(
        tree=ast.parse('pass'),
        treeChanged=True,
        warnings=[]
    )
    # define the expected result after transforming the tree
    # for test case 6

# Generated at 2022-06-23 23:26:52.073949
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(None) == None



# Generated at 2022-06-23 23:26:53.448758
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('test: VariablesAnnotationsTransformer is initialized')


# Generated at 2022-06-23 23:26:54.587180
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__=='VariablesAnnotationsTransformer'

# Generated at 2022-06-23 23:26:57.944724
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #@test {"output": "a = 10\nb = 20", "skip": true}
    print(VariablesAnnotationsTransformer.transform(ast.parse(
        '''
        a: int = 10
        b: int = 20
        '''
    )))

# Generated at 2022-06-23 23:27:00.525836
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = "a: int = 10\nb: int"
    expected_code = "a = 10"
    result = VariablesAnnotationsTransformer.transform(ast.parse(input_code))
    assert str(result.tree) == expected_code

# Generated at 2022-06-23 23:27:02.277872
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_code
    from typed_ast import ast3
    from ..utils.check import check_equal_ast

# Generated at 2022-06-23 23:27:10.315084
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
a: int = 1
b: int
c: int
            ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    print(ast.dump(result.tree))
    assert 'AnnAssign' not in ast.dump(result.tree)
    assert 'AnnAssign' not in result.log
    assert 'Assign' in ast.dump(result.tree)
    assert 'Assign' not in result.log
    assert 'int' not in ast.dump(result.tree)
    assert 'int' in result.log

# Generated at 2022-06-23 23:27:18.010052
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result.tree.body[0], ast.Assign)
    assert isinstance(result.tree.body[0].targets[0], ast.Name)
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[0].value.n == 10

tree = ast.parse("a: int = 10")
result = VariablesAnnotationsTransformer.transform(tree)
print(ast.dump(result.tree))

tree = ast.parse("a: int = 10\nb: int = 15\nc: int = 20\nd: int = 25")
result = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-23 23:27:26.693817
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    # sample input
    raw_ast_string = \
    """
    a: int = 10
    b: int
    """
    # corresponding AST
    ast_node = astor.code_to_ast.parse(raw_ast_string)
    want = \
    """
    a = 10
    """
    # desired AST
    want_ast = astor.code_to_ast.parse(want)
    got = VariablesAnnotationsTransformer.transform(ast_node)
    assert astor.to_source(got.tree) == astor.to_source(want_ast)

# Generated at 2022-06-23 23:27:32.203738
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_code = """\
    x: bool = True
    y = False
    """
    expected = """\
    x = True
    y = False
    """

    tree = ast.parse(test_code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.as_string() == expected

# Generated at 2022-06-23 23:27:35.183055
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(VariablesAnnotationsTransformer(), BaseTransformer) == True
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer) == True


# Generated at 2022-06-23 23:27:44.532919
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    def check(code: str, expected_result: str) -> None:
        tree = ast.parse(code)
        result = VariablesAnnotationsTransformer.transform(tree)
        assert result.tree_changed
        assert ast.dump(result.tree) == expected_result

    check('''a: int = 10''', '''a = 10''')

    # Ignore type comments
    check('''a: int
b: float
x: int = 10
f()
''', '''a
b
x = 10
f()
''')

    # Ignore modules
    check('''import a: int
f()
''', '''import a
f()
''')

    # Ignore type comments
    check('''a: int
f()
''', '''a
f()
''')



# Generated at 2022-06-23 23:27:47.701551
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10\nb: int'))
    expected_ast = ast.parse('a = 10')
    assert result.tree == expected_ast

# Generated at 2022-06-23 23:27:57.223910
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:27:59.198170
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.transform(None).tree == None

# Generated at 2022-06-23 23:28:03.868703
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module1 = ast.parse("a: int = 10")
    module2 = ast.parse("b: int")
    module1 = VariablesAnnotationsTransformer.transform(module1)
    module2 = VariablesAnnotationsTransformer.transform(module2)
    assert(module1.tree.body[0].value.n == 10)
    assert(module2.tree.body[0] == None)

# Generated at 2022-06-23 23:28:06.890723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''a: int = 10'''
    expected_code = '''a = 10'''
    assert VariablesAnnotationsTransformer.apply_transformation(code) == \
        {'code': expected_code, 'tree_changed': True}

# Generated at 2022-06-23 23:28:08.270720
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Creating test objects
    tree = ast.parse("a: int = 10")
    transformer = VariablesAnnotationsTransformer()
    # Testing if class VariablesAnnotationsTransformer is inherited from clas

# Generated at 2022-06-23 23:28:11.086183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert str(VariablesAnnotationsTransformer()) == "< VariablesAnnotationsTransformer (versions: ['>=3.5'])>"

# Generated at 2022-06-23 23:28:19.091816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from astunparse import unparse
    from astor.source_repr import dump_tree, pretty_tree
    from ..logger import create_logger
    from ..main import (
        PY_VERSIONS,
        Transformation,
        run_transformation,
        get_default_config,
    )
    from ..utils import get_ast
    import pytest

    logger = create_logger('root')
    config = get_default_config()
    config.logger = logger

    # Test 1 from above
    code = (
        'a: int = 10\n'
        'b: int\n'
    )
    transformed = (
        'a = 10\n'
        'b\n'
    )

    # Run test 1

# Generated at 2022-06-23 23:28:24.704612
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    a: int
    a = 10
    b: int = 11
    '''
    tree = ast.parse(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    fixed_code = astor.to_source(tree.node)
    assert fixed_code == '''
    a: int
    a = 10
    b = 11
    '''

# Generated at 2022-06-23 23:28:31.433211
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    testTree = ast.parse('''
a: int = 1
b: int
c: int
d: int = 2
e: int
''')
    testTransformer = VariablesAnnotationsTransformer.transform(testTree)
    result = ast.dump(testTransformer.tree)
    expected = '''
Module(body=[
    Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1), type_comment=Name(id='int', ctx=Load())),
    Assign(targets=[Name(id='d', ctx=Store())], value=Num(n=2), type_comment=Name(id='int', ctx=Load()))])
'''
    assert result == expected

# Generated at 2022-06-23 23:28:38.553074
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = ast.parse("a: int = 10")
    t_transformed, changed = VariablesAnnotationsTransformer.transform(t)
    # test if the old value is correct
    for node in t.body:
        assert isinstance(node, ast.AnnAssign)
        assert node.annotation.id == "int"
        assert node.value.n == 10
    # test if the new value is correct
    for node in t_transformed.body:
        assert isinstance(node, ast.Assign)
        assert node.value.n == 10
    assert changed

# Generated at 2022-06-23 23:28:48.057935
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Unit test for VariablesAnnotationsTransformer"""
    from pprint import pprint
    from ..utils.helpers import print_ast
    from ..visitors.class_collector import ClassCollector
    from ..visitors.function_collector import FunctionCollector
    from ..visitors.function_def_collector import FunctionDefCollector
    from ..visitors.arguments_collector import ArgumentCollector
    from ..visitors.assignment_target_collector import AssignmentTargetCollector
    from ..visitors.assignment_value_collector import AssignmentValueCollector
    from ..visitors.keyword_collector import KeywordCollector
    from ..visitors.type_comment_collector import TypeCommentCollector
    from ..visitors.name_collector import NameCollector
    from ..visitors.param_collector import ParamCollector

# Generated at 2022-06-23 23:28:58.247222
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Case 1: a: int = 10
    code_str = "a: int = 10"
    code = ast.parse(code_str)
    tree = VariablesAnnotationsTransformer.transform(code)
    assert isinstance(tree, TransformationResult)
    assert tree.tree_changed is True
    # print(ast.dump(tree.tree))
    assert "AnnAssign(target=Name(id='a', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=Num(n=10), simple=1)" == ast.dump(tree.tree)

    # Case 2: a: int
    code_str = "a: int"
    code = ast.parse(code_str)
    tree = VariablesAnnotationsTransformer.transform(code)
    assert isinstance(tree, TransformationResult)

# Generated at 2022-06-23 23:29:06.435445
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    class Transform:
        target = (2,7)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed = True
                parent.body.pop(index)  # type: ignore

                if node.value is not None:
                    insert_at(index, parent,
                              ast.Assign(targets=[node.target],  # type: ignore
                                         value=node.value,
                                         type_comment=node.annotation))

# Generated at 2022-06-23 23:29:07.045972
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:29:15.284814
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .context import Context
    from .transformer_helpers import transformer_setup
    from .transformer_helpers import run_test_tree

    input_string = '''
    a: int
    b: int = 10
    '''

    expected_output = '''
    from typed_ast import ast3 as ast
    import typing as tp
    def f():
        a = 10

    '''

    tree = transformer_setup(input_string, [VariablesAnnotationsTransformer])
    assert run_test_tree(Context(tree, ''), expected_output)

# Generated at 2022-06-23 23:29:25.744597
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestCase(unittest.TestCase):
        def test_VariablesAnnotationsTransformer_on_annassign(self):
            '''test VariablesAnnotationsTransformer on an annassign node'''
            node = ast.AnnAssign(target = ast.Name(id='a', ctx=ast.Store()),
                                 annotation = ast.Name(id='int', ctx=ast.Load()),
                                 value = ast.Num(n=10))
            expected = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                  value = ast.Num(n=10),
                                  type_comment = ast.Name(id='int', ctx=ast.Load()))

            actual = VariablesAnnotationsTransformer.transform(node)

            self.assertTrue

# Generated at 2022-06-23 23:29:34.124325
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
    a: int = 10
    """
    expected = """
    a = 10
    """

    # Parse into an AST.
    tree = ast.parse(source)

    # Apply transformation.
    transformer = VariablesAnnotationsTransformer()
    new_tree = transformer.transform(tree)

    # Verify that the ASTs are equivalent modulo ordering of siblings
    # (same as `unittest.TestCase.assertCountEqual`).
    result = ast.dump(new_tree)
    assert result == expected

if __name__ == "__main__":
    # Run the unit tests in this file.
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:29:36.817725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # given
    class_ = VariablesAnnotationsTransformer
    # when
    x = 5
    # then
    assert class_.target == (3,5)

# Generated at 2022-06-23 23:29:42.588184
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer.transform(
        ast.parse(
            textwrap.dedent("""
            a: int = 10
            b: int
            """)))
    expected = ast.parse(
        textwrap.dedent("""
        a = 10
        """))
    assert ast.dump(result.tree, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-23 23:29:47.309702
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    tree1 = ast3.parse("""\
x: int = 10
""")
    tree2 = ast3.parse("""\
x = 10
""")
    tree = VariablesAnnotationsTransformer.transform(tree1)
    assert tree2 == tree.tree
    assert tree.tree_changed

# Generated at 2022-06-23 23:29:49.458107
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(VariablesAnnotationsTransformer, object)

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:29:58.572457
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import case_insensitive_compare
    from ..utils import get_type_hint
    from .type_casts import TypeCastTransformer
    from .import_transformer import ImportTransformer
    import ast


    # Test variable declaration and assignment
    code = '''def foo(a: int = 10):
        return a'''

    tree = ast.parse(code)
    trans = VariablesAnnotationsTransformer.transform(tree)
    new_code = ast.unparse(trans.tree)
    assert case_insensitive_compare(new_code, '''def foo(a=10):
        return a''')

    # Test variable declaration and no assignment
    code = '''def foo(a: int, b: int = 10):
        return a + b'''


# Generated at 2022-06-23 23:29:59.434879
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:00.486236
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:05.722821
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_ast = ast.parse_str('''
a: int = 10
b: int
c: int
''')
    VariableAnnotationsTransformer.transform(var_ast)
    desugared_var_ast = ast.parse_str('''
a = 10
c = None
''')
    assert var_ast == desugared_var_ast

# Generated at 2022-06-23 23:30:07.958825
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign()
    an = VariablesAnnotationsTransformer(None)
    assert(an.target == (3, 5))

# Generated at 2022-06-23 23:30:10.768394
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
    a: int = 10
    b: str
    '''
    node = ast.parse(code)
    VariablesAnnotationsTransformer.transform(node)

# Generated at 2022-06-23 23:30:20.834755
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import transform
    from .base import BaseTransformer
    
    # Test for transform function
    # 
    class TestVariablesAnnotationsTransformer(VariablesAnnotationsTransformer):
        def transform(self, tree: ast.AST) -> TransformationResult:
            # print("transform")
            return super().transform(tree)
    # 
    tree = ast.parse('''
    class test():
        def test(self):
            a:int = 10
            b:int
    ''')
    
    result = transform(tree, TestVariablesAnnotationsTransformer)
    # print("result:\n", ast.dump(result.tree))
    assert result.tree.body[0].body[0].name == "test"

# Generated at 2022-06-23 23:30:25.934632
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a:int = 10\nb:int", '<string>', 'eval', _feature_version=sys.version_info.major)
    tree = VariablesAnnotationsTransformer.transform(tree)

    assert str(tree.body[0].value) == str(ast.Num(n=10))
    assert str(tree.body[1]) == "AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), " \
                                "value=None, simple=0)"

# Generated at 2022-06-23 23:30:32.573359
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import setup_test
    from ..utils.helpers import assert_equal_ignore_ws, assert_code_equal

    # Given
    source = '''
        def f():
            a: int = 10
            b: int
    '''
    expected = '''
        def f():
            a = 10
    '''

    # When
    module, _ = setup_test(source, VariablesAnnotationsTransformer)
    actual = module.body[0].body

    # Then
    assert_equal_ignore_ws(actual, expected)
    assert_code_equal(module, expected)

# Generated at 2022-06-23 23:30:35.376801
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)
    t = VariablesAnnotationsTransformer()
    # Should return <class '__main__.VariablesAnnotationsTransformer'>
    print(t.transform(t))


# Generated at 2022-06-23 23:30:40.462010
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import build_tree
    from ..utils.helpers import get_ast_root

    source = '''def foo():
    a: int
'''
    tree = build_tree(source, 'test_VariablesAnnotationsTransformer')
    result = VariablesAnnotationsTransformer().transform(tree)
    print(ast.dump(result.tree))
    assert ast.dump(result.tree) == \
        "Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None, type_comment=None)], type_ignores=[])"

# Generated at 2022-06-23 23:30:42.389984
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'



# Generated at 2022-06-23 23:30:43.449324
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:47.538177
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.AnnAssign(target=ast.Name(id="a", ctx=ast.Store()),
                      annotation=ast.Name(id="int", ctx=ast.Load()),
                      value=ast.Num(n=10),
                      simple=1)
    b = ast.AnnAssign(target=ast.Name(id="b", ctx=ast.Store()),
                      annotation=ast.Name(id="int", ctx=ast.Load()),
                      value=None,
                      simple=0)
    tree = ast.Module(body=[a, b])
    # print(ast.dump(tree))

# Generated at 2022-06-23 23:30:50.996601
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree_string = """a: int = 10\nb: int"""
    tree = ast.parse(tree_string, mode='exec')
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == """a = 10"""

# Generated at 2022-06-23 23:30:57.516684
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10")
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree.body[0].value.n == 10
    assert res.tree_changed == True
    assert res.warnings == []
    # Test for case of assignment outside of body i.e. a = 10
    tree = ast.parse("a = 10")
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree.body[0].value.n == 10
    assert res.tree_changed == True
    assert res.warnings == ['Assignment outside of body']
    # Test for case of assignment outside of body i.e. a, b: int = [1, 2]
    tree = ast.parse("a, b: int = [1, 2]")

# Generated at 2022-06-23 23:31:02.749416
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from typed_ast import ast3 as ast
    code_str = '''
    b: int
    c: str = "app"
    '''
    tree = ast.parse(code_str)
    i_transformer = VariablesAnnotationsTransformer()
    i_transformer.transform(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-23 23:31:11.034648
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    res = VariablesAnnotationsTransformer.transform(ast.parse("a:int = 10\n b:int\n"))
    ans = ast.parse("a = 10\n")
    f1 = ast.Module(body =[
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Num(n=10),
            type_comment=ast.Name(id='int', ctx=ast.Load())
        )
    ])
    assert ast.dump(f1) == ast.dump(res.tree)
    assert ast.dump(f1) == ast.dump(ans)