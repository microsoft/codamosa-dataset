

# Generated at 2022-06-23 23:21:11.229534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from ..utils.tree import build_ast
    from ..utils.transformer_utils import tree_to_str, transformer_test_helper
    from ..utils.helpers import get_random_string
    import random
    import copy

    # Test that transformer only works on Python version it targets
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.target_python() == (3, 5)

    # Ensure all subclasses have transform method
    assert hasattr(VariablesAnnotationsTransformer, 'transform')

    tree = build_ast('''
a: int = 10
b: int
c: int = a + b
''')

    tree_copy = copy.deepcopy(tree)

# Generated at 2022-06-23 23:21:14.126043
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse('a: int = 10', mode='exec')
    assert VariablesAnnotationsTransformer.transform(a)
    a = ast.parse('a: int', mode='exec')
    assert VariablesAnnotationsTransformer.transform(a)

# Generated at 2022-06-23 23:21:14.859035
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:21:16.588060
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('''
            a: int = 10
            b: int''')) == TransformationResult(ast.parse(
        '''
        a = 10
        '''), True, [])


# Generated at 2022-06-23 23:21:17.395774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.transform({}) is None

# Generated at 2022-06-23 23:21:19.129622
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    variables_annotations_transformer = VariablesAnnotationsTransformer()
    assert variables_annotations_transformer.__class__ == VariablesAnnotationsTransformer


# Generated at 2022-06-23 23:21:24.258920
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

   class A():
      def __init__(self,node,_parent,_index,_tree): 
         self.node = node
         self._parent = _parent
         self._index = _index
         self._tree = _tree

      def transform(self): 
         if self.node == None :
            pass
         elif isinstance(self.node, ast.Assign) :
            self.transform_Assign(self.node)
         elif isinstance(self.node, ast.AnnAssign) :
            self.transform_AnnAssign(self.node)
         elif isinstance(self.node, ast.Expr) :
            self.transform_Expr(self.node)
         elif isinstance(self.node, ast.Load) :
            self.transform_Load(self.node)
         el

# Generated at 2022-06-23 23:21:25.185678
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:21:34.662107
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    some_var = ast.Name(id="some_var",
                        ctx=ast.Load(),
                        annotation=ast.Name(id="Integer",
                                            ctx=ast.Load()))
    x_assign = ast.AnnAssign(target=ast.Name(id="x",
                                             ctx=ast.Store()),
                             annotation=ast.Name(id="String",
                                                 ctx=ast.Load()),
                             value=some_var)
    y = ast.AnnAssign(target=ast.Name(id="y",
                                      ctx=ast.Store()),
                      annotation=ast.Name(id="String",
                                          ctx=ast.Load()),
                      value=None)

# Generated at 2022-06-23 23:21:37.310281
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('Testing constructor of class VariablesAnnotationsTransformer')
    new_transformer = VariablesAnnotationsTransformer()
    print('Done!')


# Generated at 2022-06-23 23:21:37.871440
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:21:39.388033
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-23 23:21:44.227813
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_1 = ast.parse("""
    a: int = 10
    b: int
    c: int = 10 + 10
    def x(d: int = 10) -> int:
        return d
    """)

    tree_result_1 = ast.parse("""
    a = 10
    c = 10 + 10
    def x(d):
        return d
    """)

    assert test_1 == tree_result_1


# Generated at 2022-06-23 23:21:53.358991
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #Test1: Test assignment with annotation
    node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                         annotation=ast.Name(id='int', ctx=ast.Load()),
                         value=ast.Num(n=10), simple=1)
    assert NodeNotFound in VariablesAnnotationsTransformer.transform(node).exceptions

    #Test2: Test assignment without annotation
    node = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store(), annotation=ast.Name(id='int', ctx=ast.Load()))],
                      value=ast.Num(n=10))
    result = VariablesAnnotationsTransformer.transform(node)

# Generated at 2022-06-23 23:21:56.721726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """x: int = 10"""
    tree = astor.parse_file(StringIO(code))
    tree = VariablesAnnotationsTransformer.transform(tree)
    code = astor.to_source(tree)
    assert code == """x = 10"""

# Generated at 2022-06-23 23:22:07.125160
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Create a class that represents Python3 code
    foo = ast.Name(id='foo', ctx=ast.Load())
    bar = ast.Name(id='bar', ctx=ast.Load())
    baz = ast.Name(id='baz', ctx=ast.Load())
    target = ast.Tuple(elts=[foo, bar], ctx=ast.Store())
    value = ast.List(elts=[baz], ctx=ast.Load())
    a_node = ast.AnnAssign(target=target, value=value, annotation=None)
    tree = ast.AST(a_node)
    # Pass it to the constructor of class VariablesAnnotationsTransformer
    VariablesAnnotationsTransformer.transform(tree)
    # Print the result of the transformer to see if it is as expected

# Generated at 2022-06-23 23:22:16.730803
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("\n\n---- Begin Test ----\n")

    # Test 1: a: int = 10
    #         b: int
    code = '''a: int = 10\nb: int'''
    expected_code = '''a = 10'''
    tree = ast.parse(code)
    tree2 = ast.parse(expected_code)
    tree_tran = VariablesAnnotationsTransformer.transform(tree)
    tree_tran2= tree_tran[0]
    assert ast.dump(tree_tran2) == ast.dump(tree2)

    print("---- End Test ----\n")

# Test case
#code = '''a: int = 10\nb: int'''
#expected_code = '''a = 10'''

#tree = ast.parse(code)
#tree

# Generated at 2022-06-23 23:22:20.515254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        return

    tree = ast3.parse('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree)

    assert_equals(1, len(tree.body))
    assert_equals('a', tree.body[0].targets[0].id)
    assert_equals(10, tree.body[0].value.n)

# Generated at 2022-06-23 23:22:21.867070
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class1 = VariablesAnnotationsTransformer()
    assert class1.target == (3, 5)

# Generated at 2022-06-23 23:22:27.502735
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    transformer = VariablesAnnotationsTransformer(tree)
    tree = transformer.transform()
    expected = ast.parse('a = 10')
    assert(ast.dump(tree, include_attributes=True) ==
           ast.dump(expected, include_attributes=True))

# Generated at 2022-06-23 23:22:29.492217
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_obj = VariablesAnnotationsTransformer()
    assert class_obj.target == (3, 5)


# Generated at 2022-06-23 23:22:37.945277
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast
    from .test_helpers import roundtrip
    t = VariablesAnnotationsTransformer()

    code = "a: int = 10"
    tree = roundtrip(code, ast3)
    updated_tree, tree_changed, messages = t.transform(tree)
    assert_equal(tree_changed, True)
    assert_equal(messages, [])
    new_code = astor.to_source(updated_tree)
    assert_equal(new_code, "a = 10")
    new_tree = roundtrip(new_code, ast3)
    assert_equal(updated_tree, new_tree)

    code = "b = 10"
    tree = roundtrip(code, ast3)
    updated_tree, tree_changed, messages = t.transform(tree)
   

# Generated at 2022-06-23 23:22:42.038316
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    from .. import transform
    from ..transformer import VariableAnnotationTransformer
    from ..annotation import annotate

    tree = transform('''
        class Test(object):
            def test(self):
                a: int = 10
                b: int
    ''', (VariableAnnotationTransformer,))

    expected_tree = '''
        class Test(object):
            def test(self):
                a = 10
                b
    '''

    assert annotate(expected_tree) == annotate(tree)

# Generated at 2022-06-23 23:22:45.786294
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import ast
    import sys
    expected_code = inspect.getsource(sys.modules[__name__])
    code = inspect.getsource(VariablesAnnotationsTransformer)
    assert code == expected_code, 'Source code changed'

# Generated at 2022-06-23 23:22:46.381729
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:22:49.030120
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10; b: int')
    VariablesAnnotationsTransformer.transform(tree)
    expected = 'a = 10'
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:22:49.869816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer



# Generated at 2022-06-23 23:22:57.830180
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import inspect
    import sys
    import unittest
    from textwrap import dedent

    from typed_ast import ast3 as ast
    from typed_ast import parse

    class TestVariablesAnnotationsTransformer(unittest.TestCase):
        def assertASTEqual(self, _ast1, _ast2):
            self.assertEqual(
                inspect.cleandoc(_ast1), inspect.cleandoc(_ast2))

        def test(self):
            code = dedent('''
                a: int = 10
                b: int
            ''')

            expected = dedent('''
                a = 10
            ''')

            tree = parse(code, mode='exec')

            # Type check tree
            result = VariablesAnnotationsTransformer.transform(tree)


# Generated at 2022-06-23 23:23:01.272237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = ast.parse('class A:\n a:int=10')
    transformer = VariablesAnnotationsTransformer(t)
    result = transformer.transform()
    assert result[0] == result[1]
    assert ast.dump(result[0]) == ast.dump(ast.parse('class A:\n a = 10'))


# Generated at 2022-06-23 23:23:02.656719
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    changed = False

# Generated at 2022-06-23 23:23:07.657716
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a:int = 10')
    result = VariablesAnnotationsTransformer.transform(node)
    assert result.new_tree.body[0].value == 10
    assert not result.tree_changed
    node = ast.parse('a:int')
    result = VariablesAnnotationsTransformer.transform(node)
    assert not result.new_tree.body
    assert result.tree_changed

# Generated at 2022-06-23 23:23:14.908185
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import typed_ast.ast3 as ast

    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10), type_comment=Str(s='int')), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Str(s='int'), value=None)])"""

# Generated at 2022-06-23 23:23:23.672233
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vart = VariablesAnnotationsTransformer()

    # Test initialisation of class object
    assert vart.target == (3,5)

    # Test tree manipulation using VariablesAnnotationsTransformer
    line_number, col_number = (2, 3)
    tree, code = vart.get_ast(code=dedent('''
    a: int = 10
    b: int
    '''), line_number=line_number, col_number=col_number)
    # Test get_ast method of VariablesAnnotationsTransformer
    assert code == 'a: int = 10\nb: int'

    new_tree, changed = vart.transform(tree)
    # Test if tree has changed
    assert changed is True

    new_code = vart.dump_python_code(new_tree)
    # Test if tree

# Generated at 2022-06-23 23:23:28.283412
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_case_1 = ast.parse("""
a: int = 10
b: int
c: int = 20
""")
    test_case_2 = ast.parse("""
    a: str
    """)
    assert VariablesAnnotationsTransformer.transform(test_case_1).tree == ast.parse("""
a = 10
c = 20
""")
    assert VariablesAnnotationsTransformer.transform(test_case_2).tree == ast.parse("""
    """)

# Generated at 2022-06-23 23:23:37.321466
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1:
    test_code_1 = """
    a: int = 10
    b: int
    c = 10
    """
    test_ast_1 = ast.parse(test_code_1)
    expected_ast_1 = ast.parse("""
    a = 10
    c = 10
    """)
    VariablesAnnotationsTransformer.transform(test_ast_1)
    assert test_ast_1 == expected_ast_1

# Keep this code at the end to prevent circular imports.
from . import ALL_TRANSFORMERS  # type: ignore
ALL_TRANSFORMERS.append(VariablesAnnotationsTransformer)

# Generated at 2022-06-23 23:23:47.851820
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    tree = ast.parse(ttext) # parse the text corresponding to the variable tree_str
    assert type(tree)==ast.Module
    assert type(tree.body[1])==ast.AnnAssign
    assert type(tree.body[2])==ast.AnnAssign
    assert type(tree.body[3])==ast.Assign
    # created instance of the class under test
    instance = VariablesAnnotationsTransformer()
    # call the method under test with the variable tree as the argument
    assert instance.transform(tree)==(tree, True, [])
    assert type(tree.body[1])==ast.Assign
    assert type(tree.body[2])==ast.Assign
    assert type(tree.body[3])==ast.Assign
# end of test



# Generated at 2022-06-23 23:23:52.837103
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected_input = ast.parse("a: int = 10")
    expected_output = ast.parse("a = 10")
    actual_output = VariablesAnnotationsTransformer.transform(expected_input)
    assert ast.dump(actual_output.tree, include_attributes=True) == ast.dump(expected_output, include_attributes=True)

# Generated at 2022-06-23 23:24:04.172407
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:24:08.633442
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class TestClass:
        """
        Test class for VariablesAnnotationsTransformer.
        """

        def __init__(self):
            self.nodes = """
            a: int = 10
            b: int = 20
            """

            self.expected = """
            a = 10
            b = 20
            """

            self.transformer = VariablesAnnotationsTransformer()


# unit test for VariablesAnnotationsTransformer.transform function.

# Generated at 2022-06-23 23:24:09.701491
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import ast


# Generated at 2022-06-23 23:24:12.404229
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert(transformer.target == (3, 5)) # test that target version is 3.5
    assert(transformer.transform)

# Generated at 2022-06-23 23:24:18.409930
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
    """
    a: int = 10
    b: int
    """)

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    expected_tree = ast.parse(
    """
    a = 10
    """)

    assert ast.dump(new_tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)

# Generated at 2022-06-23 23:24:23.145629
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import os
    import sys
    sys.path.append(os.getcwd())
    from ..main import main
    import astunparse

    tree = ast.parse("from typing import List\n"
                     "x: List[int] = [1, 2, 3]\n")
    main(tree)
    astunparse.unparse(tree)

# Generated at 2022-06-23 23:24:31.384538
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    a1 = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Constant(value=10),
        simple=1)

    # b: int
    a2 = ast.AnnAssign(
        target=ast.Name(id='b', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=None,
        simple=0)

    # c = 10
    a3 = ast.Assign(
        targets=[ast.Name(id='c', ctx=ast.Store())],
        value=ast.Constant(value=10))

    # t

# Generated at 2022-06-23 23:24:39.817940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = \
'''
# type: ignore
a: int = 10
'''
    expected_code = \
'''
a = 10
'''

    VariablesAnnotationsTransformer.transform(ast.parse(code))
    assert astor.to_source(ast.parse(code)) == expected_code

    code = \
'''
# type: ignore
a: int = 10

b: int

c: int
'''
    expected_code = \
'''
a = 10

b = int

c = int
'''

    VariablesAnnotationsTransformer.transform(ast.parse(code))
    assert astor.to_source(ast.parse(code)) == expected_code

# Generated at 2022-06-23 23:24:43.247623
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse(
        """
a: int = 10
        """, mode='exec')
    b = ast.parse(
        """
a = 10        
        """, mode='exec')
    assert VariablesAnnotationsTransformer.transform(a).tree == b

# Generated at 2022-06-23 23:24:53.387841
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test transform case 1:
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    expected_tree = ast.parse("""
    a = 10 
    """)
    tree_changed, source_ast, error_messages = VariablesAnnotationsTransformer.transform(tree)
    assert error_messages == []
    assert tree_changed == True
    assert ast.dump(expected_tree) == ast.dump(source_ast)

    # Test transform case 2:
    tree = ast.parse("""
    a: int = 10
    b: int
    print("hello")
    """)
    expected_tree = ast.parse("""
    a = 10 
    print("hello")
    """)
    tree_changed, source_ast, error_messages = Variables

# Generated at 2022-06-23 23:24:56.852860
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    obj = VariablesAnnotationsTransformer()
    res = obj.transform(tree)

    assert len(res.warnings) == 1
    assert res.tree_changed == True

# Generated at 2022-06-23 23:25:02.137018
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class AnnotatedClass:
        a: int = 10
        b: int
        c = None

    class AnnotatedClassType:
        a: int = 10
        b: int
        c = None

    tree = ast.parse(inspect.getsource(AnnotatedClass))

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed is True
    assert ast.dump(AnnotatedClassType) == ast.dump(result.tree)

# Generated at 2022-06-23 23:25:04.531939
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert True


if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:25:14.569653
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    # a: int = 10
    # b: int
    tree = ast.AnnAssign(annotation=ast.Name(id='int'),
                         target=ast.Name(id='a'),
                         value=ast.Num(10),
                         simple=1)
    parent = ast.Module(body=[tree])
    tree2 = ast.AnnAssign(annotation=ast.Name(id='int'),
                          target=ast.Name(id='b'),
                          simple=1)
    insert_at(1, parent, tree2)

    # Act
    result = VariablesAnnotationsTransformer.transform(parent)

    # Assert
    # a = 10

# Generated at 2022-06-23 23:25:17.709611
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""\
a: int = 10
b: int
""")

    node = ast.AnnAssign(annotation=ast.Name(id='int'))
    adapted_tree = VariablesAnnotationsTransformer.transform(tree)

    assert adapted_tree.tree == ast.parse("""
a = 10
""")

# Generated at 2022-06-23 23:25:29.492267
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import fake_location
    import astor

    assert astor.to_source(VariablesAnnotationsTransformer.transform(
        ast.parse('''a: int = 10''')).tree).strip() == astor.to_source(
        ast.parse('''a = 10''')).strip()

    assert astor.to_source(VariablesAnnotationsTransformer.transform(
        ast.parse('''a: int''')).tree).strip() == astor.to_source(
        ast.parse('''a''')).strip()


# Generated at 2022-06-23 23:25:32.014987
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print('Testing constructor of class VariablesAnnotationsTransformer')

    instance = VariablesAnnotationsTransformer()
    assert isinstance(instance, VariablesAnnotationsTransformer)

    print('Passed!')


# Generated at 2022-06-23 23:25:36.709019
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.parse('''
        a: int = 10
        b: int
        ''')) == \
        TransformationResult(ast.parse('''
        a = 10
        '''), tree_changed=True, nodes_changed=[])

# Generated at 2022-06-23 23:25:40.617520
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Assume
    tree = ast.parse('a: int = 10')
    # Action
    vat = VariablesAnnotationsTransformer.transform(tree)
    # Assert
    assert(vat.tree == ast.parse('a = 10'))

# Generated at 2022-06-23 23:25:43.442947
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.codegen import codegen
    from ..utils.test import test_transformer, _test_warn


# Generated at 2022-06-23 23:25:49.433562
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.test_utils import assertEqualAST
    from ..utils.test_utils import generate_random_ast
    import random

    python_version = random.randint(3, 10)
    if python_version == 10:
        return
    tree = generate_random_ast(python_version).body
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assertEqualAST(VariablesAnnotationsTransformer.target, tree)
    assert tree_changed



# Generated at 2022-06-23 23:25:52.077989
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.__class__.__name__ == "VariablesAnnotationsTransformer"
    assert isinstance(t, BaseTransformer)
    assert t.target == (3,5)
    
    

# Generated at 2022-06-23 23:25:54.014901
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import line_numbers


# Generated at 2022-06-23 23:26:05.025151
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int', mode='exec')
    assert str(tree) == '<Module(body=[AnnAssign(target=<Name(id=a, ctx=Store())>, annotation=<Name(id=int, ctx=Load())>, value=<Num(n=10)>, simple=1), AnnAssign(target=<Name(id=b, ctx=Store())>, annotation=<Name(id=int, ctx=Load())>, value=None, simple=1)])>'
    result = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-23 23:26:06.854009
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__bases__[0].__name__ == 'BaseTransformer'

# Generated at 2022-06-23 23:26:13.710000
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    import inspect
    from textwrap import dedent
    from ast_helper import ast_to_code, get_ast

    source = dedent("""
        def fun(a: int = 10, b: int):
            while a > 0:
                a -= 1
                b -= 1
            a *= 2
            b *= 2
    """)
    expected = dedent("""
        def fun(a = 10, b):
            while a > 0:
                a -= 1
                b -= 1
            a *= 2
            b *= 2
    """)
    mod = ast_to_code(ast.parse(source))
    mod = VariablesAnnotationsTransformer.transform(mod)
    assert ast_to_code(mod) == expected


# Generated at 2022-06-23 23:26:22.795205
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """
a: int = 10
b: int
c: int = 20
d: int
e: int = 30
f: int
    """
    expected = """
a = 10
b = None
c = 20
d = None
e = 30
f = None
    """
    tree = ast.parse(source, mode='exec')
    transformer = VariablesAnnotationsTransformer()
    transformed, is_changed = transformer.transform(tree)

    actual = ast.dump(transformed)
    assert expected.split() == actual.split()
    assert is_changed == True
    assert transformer.target == (3, 5)

# Generated at 2022-06-23 23:26:25.192228
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        '''
        a: int = 10
        b: int
        '''
    ) == '''
        a = 10
        '''

# Generated at 2022-06-23 23:26:25.767024
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:26:32.513182
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test when tree is changed
    tree = astor.parse_file('tests/fixtures/compiler/variables_annotation_transformer.py')
    expected_tree = astor.parse_file('tests/fixtures/compiler/variables_annotation_transformer_expected.py')
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree == expected_tree

    # # Test when tree is not changed
    # tree = astor.parse_file('tests/fixtures/compiler/variables_annotation_transformer_expected.py')
    # res = VariablesAnnotationsTransformer.transform(tree)
    # assert res.tree == expected_tree

# Generated at 2022-06-23 23:26:33.573731
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer(ast.parse('a=10', mode='eval'), 3) is not None

# Generated at 2022-06-23 23:26:39.855796
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = '''
    a: int = 10
    b: int

    # type: ignore
    c: int = 11

    def __init__(self):
        d: int = 12'''
    expected = '''
    a = 10

    # type: ignore
    c: int = 11

    def __init__(self):
        d = 12'''
    # When
    res = VariablesAnnotationsTransformer.run_test(code)
    # Then
    assert res == expected

# Generated at 2022-06-23 23:26:46.945863
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Set up test
    code = "a:int = 10"
    old_tree = ast.parse(code)
    old_tree_changed = False

    # Set up expected results
    expected_tree = ast.parse("a=10")
    expected_tree_changed = True

    # Run unit test
    transformer = VariablesAnnotationsTransformer()
    tree_changed, tree = transformer.transform(old_tree)

    # Check test results
    assert(tree_changed == expected_tree_changed), "tree_changed is incorrect"
    assert(str(tree) == str(expected_tree)), "tree is incorrect"

# Generated at 2022-06-23 23:26:57.093328
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Instantiating VariablesAnnotationsTransformer
    vat = VariablesAnnotationsTransformer()

    assert vat.target == (3, 5)

    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)

    assert isinstance(vat, BaseTransformer)

    assert isinstance(vat, VariablesAnnotationsTransformer)


# Generated at 2022-06-23 23:26:59.022258
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from .type_comments import TypeCommentsTransformer
    from .functions_to_nums import FunctionsToNumsTransformer


# Generated at 2022-06-23 23:27:04.449418
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""class C:\n  def __init__(self, a: int = 10, b: int):\n    pass""")
    tree_changed = ast.parse("""class C:\n  def __init__(self, a = 10, b):\n    pass""")
    VariablesAnnotationsTransformer().transform(tree)
    assert ast.dump(tree) == ast.dump(tree_changed)


# Generated at 2022-06-23 23:27:14.530471
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    module = ast.parse("""a: int = 10\nb: int""")
    assert [n.__class__.__name__ for n in find(module, ast.AnnAssign)] == ['AnnAssign', 'AnnAssign']
    assert [n.__class__.__name__ for n in find(module, ast.Assign)] == []
    assert [n.__class__.__name__ for n in find(module, ast.Name)] == ['Name', 'Name','Name','Name','Name','Name','Name','Name','Name','Name','Name','Name']
    result,changed = VariablesAnnotationsTransformer.transform(module)
    assert changed
    assert [n.__class__.__name__ for n in find(result, ast.AnnAssign)] == []

# Generated at 2022-06-23 23:27:17.923621
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert len(VariablesAnnotationsTransformer.transform(ast.parse("x: int")).code) > 1


# Generated at 2022-06-23 23:27:24.665951
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import NodeTransformer
    from typed_ast.ast3 import parse
    from ..visitor import Visitor
    import inspect
    import ast
    import os

    module = parse('''
    def foo(a: int, b: int) -> int:
        b = 2
        return a + b
    ''')

    tree = module
    test = NodeTransformer()
    test.visit(tree)

    assert(len(tree.body) == 1)
    assert(len(tree.body[0].body.body) == 2)
    body = tree.body[0].body.body
    assert type(body[0]) == ast.AnnAssign
    assert type(body[1]) == ast.Return

    # call the function foo
    test2 = VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:27:27.424686
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3,5), "target variable should be (3,5)"

# Generated at 2022-06-23 23:27:38.759577
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
        Input:
            a: int = 10
            b: int
        Expected Output:
            a = 10
        """
    a = ast.Name(id='a')
    b = ast.Name(id='b')
    annotation1 = ast.Name(id='int')
    value1 = ast.Constant(value=10, kind=None)
    annotation2 = ast.Name(id='int')
    value2 = None

    Assign1 = ast.AnnAssign(target=a, value=value1, annotation=annotation1)
    Assign2 = ast.AnnAssign(target=b, value=value2, annotation=annotation2)

    module = ast.Module(body=[Assign1, Assign2])
    module = VariablesAnnotationsTransformer.transform(module)

    # output = tree

# Generated at 2022-06-23 23:27:49.351975
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Dict, Num, Name, Expr, List, load
    from ast_helper import dump_tree, load_tree, assert_tree
    from io import StringIO

    ast_tree = load('a: int = 10\n')
    ast_tree = load_tree(ast_tree)
    tree = VariablesAnnotationsTransformer.transform(ast_tree)
    assert tree.tree_changed == True
    assert tree.failed_transformations == []
    assert_tree(tree.transformed_tree, Expr(value=Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10))))


    ast_tree = load('a: int\n')

# Generated at 2022-06-23 23:27:54.719413
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # GIVEN
    # a: int = 10
    # b: int
    # WHEN
    # The constructor of class VariablesAnnotationsTransformer is called
    transformer = VariablesAnnotationsTransformer()
    # THEN
    # The object __class__ and target variables are initialized
    assert transformer.__class__.__name__ == 'VariablesAnnotationsTransformer'
    assert transformer.target == (3, 5)

# Generated at 2022-06-23 23:28:00.641858
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
        >>> a = 1
        >>> b = 2
        >>> c = a + b
        >>> c
        3
        >>> d, e = a, b
        >>> d, e
        (1, 2)
        >>>
    """
    code = textwrap.dedent(inspect.cleandoc(test_VariablesAnnotationsTransformer.__doc__))
    tree = ast.parse(code)
    assert ast.dump(tree) == ast.dump(VariablesAnnotationsTransformer.run(tree))

# Generated at 2022-06-23 23:28:03.580319
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
a: int = 10
b: int
"""
    ast_tree = ast.parse(textwrap.dedent(code))
    res = VariablesAnnotationsTransformer.transform(ast_tree)


# Generated at 2022-06-23 23:28:13.291134
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: list = []
""")
    instance = VariablesAnnotationsTransformer()
    new_tree, is_changed = instance.transform(tree)
    assert isinstance(new_tree, ast.AST)
    assert is_changed == True
    assert ast.dump(new_tree) == dedent("""\
    Module(body=[
        AnnAssign(annotation=Name(id='int', ctx=Load()), target=Name(id='a', ctx=Store()), value=Num(n=10), simple=1),
        Assign(targets=[Name(id='b', ctx=Store())], value=List(elts=[], ctx=Load()), type_comment=Name(id='list', ctx=Load()))
        ])""")



# Generated at 2022-06-23 23:28:15.053665
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t0 = VariablesAnnotationsTransformer()
    assert t0.target == (3, 5)


# Generated at 2022-06-23 23:28:17.592263
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """
a: int = 10
b: int
"""
    expected_output = """
a = 10
"""
    transformer = VariablesAnnotationsTransformer()
    assert transformer.code_equal(input_code, expected_output)

# Generated at 2022-06-23 23:28:27.517409
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a_int = ast.Name(id='a', ctx=ast.Load())
    a_int.annotation = ast.Name('int', ast.Load())
    a_int_val = ast.Constant(value = 10)
    a_assign = ast.AnnAssign(target = a_int, annotation = 'int', value = a_int_val)
    b_int = ast.Name(id='b', ctx=ast.Load())
    b_int.annotation = ast.Name('int', ast.Load())
    b_assign = ast.AnnAssign(target = b_int, annotation = 'int')
    body = [a_assign, b_assign]
    funcdef = ast.FunctionDef(name = 'foo', body = body)
    funcdef.decorator_list = []


# Generated at 2022-06-23 23:28:32.831685
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    tran = VariablesAnnotationsTransformer()
    tran.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10, kind=None), type_comment='int'), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment='int')])"

# Generated at 2022-06-23 23:28:37.219168
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = ast.parse('a: int = 10')
    tree = ast.parse('a: int')
    target = ast.parse('a')

    assert VariablesAnnotationsTransformer.transform(code) == TransformationResult(target, True, [])

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(tree, False, [])

# Generated at 2022-06-23 23:28:39.460226
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(VariablesAnnotationsTransformer, object)
    assert issubclass(
        VariablesAnnotationsTransformer,
        BaseTransformer)



# Generated at 2022-06-23 23:28:41.126839
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5)

# Generated at 2022-06-23 23:28:45.236659
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a:int=10')) == TransformationResult(ast.parse('a=10'), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse('a:int')) == TransformationResult(ast.parse(''), True, [])

# Generated at 2022-06-23 23:28:53.511502
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Compiles:
    #     a: int = 10
    #     b: int

    # To:
    #     a = 10

    comp_args = ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])

# Generated at 2022-06-23 23:28:58.146861
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
	tree_of_code = ast.parse("a: int = 10, b: int")
	class_object = VariablesAnnotationsTransformer()
	result = class_object.transform(tree_of_code)
	if(result.tree_changed == True):
		print("Test of constructor passed")
	else :
		print("Test of constructor failed")

# Generated at 2022-06-23 23:29:02.349673
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(ast.parse("a=10"))
    assert result.tree_changed == True
    assert result.warnings == []

# Generated at 2022-06-23 23:29:03.822440
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    trans = VariablesAnnotationsTransformer
    trans.transform(ast.parse("a: int = 10"))



# Generated at 2022-06-23 23:29:07.146579
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    filename = 'test.py'
    test_code = 'a = 10'
    tree = ast.parse(test_code)

    output = VariablesAnnotationsTransformer.transform(tree)
    assert output.tree.body[0].value.n == 10
    assert output.tree.body[0].targets[0].id == 'a'


# Generated at 2022-06-23 23:29:09.775328
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Check constructors
    assert VariablesAnnotationsTransformer.transform is not None
    assert VariablesAnnotationsTransformer.target is not None

# Unit test

# Generated at 2022-06-23 23:29:21.463575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    assert VariablesAnnotationsTransformer.transform(ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Num(n=10), simple=1)) == \
           TransformationResult(
               ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],  # type: ignore
                          value=ast.Num(n=10),
                          type_comment=getattr(ast.Name(id='int', ctx=ast.Load()), 's')),
               True, [])

    # b: int

# Generated at 2022-06-23 23:29:24.403097
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_tree = ast.parse('a: int = 10')
    expected_tree = ast.parse('a = 10')

    assert VariablesAnnotationsTransformer().get_transformed_ast(ast_tree) == expected_tree

# Generated at 2022-06-23 23:29:26.592545
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3,5)
    assert isinstance(vat.transform, types.MethodType)


# Generated at 2022-06-23 23:29:28.026374
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.parse('a: int = 10')
    assert VariablesAnnotationsTransformer.transform(node)

# Generated at 2022-06-23 23:29:28.854189
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:29:29.316057
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:29:33.676287
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    print("Testing VariablesAnnotationsTransformer...")
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_text
    from ..backends.python.transformers.transformations.variable_declaration import VariableDeclarationTransformer


# Generated at 2022-06-23 23:29:42.684197
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import make_function_tree
    from ..utils.helpers import get_node

    tree = make_function_tree('''
        a: int = 10
        b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)
    assert not get_node(tree, ast.AnnAssign)
    assert get_node(tree, ast.Assign)
    assert get_node(tree, ast.Assign, 2).value.n == 10
    assert get_node(tree, ast.Assign, 2).targets[0].id == 'a'


if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:29:50.123254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int 
""")
    new_tree = ast.parse("""
a = 10
""")
    transformer = VariablesAnnotationsTransformer()
    # check if the transformer is operating on the correct target
    assert transformer.target == (3, 5)
    # check if the class is a subclass of BaseTransformer
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)
    # check if the transformer is able to generate the correct tree
    assert transformer.transform(tree).new_tree == new_tree

# Generated at 2022-06-23 23:29:53.535467
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Construct an object of class VariablesAnnotationsTransformer
    obj = VariablesAnnotationsTransformer()
    # Check if the object is an instance of class VariablesAnnotationsTransformer
    assert isinstance(obj, VariablesAnnotationsTransformer)

# Generated at 2022-06-23 23:29:58.062808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    node = ast.parse("""a: int = 10
            b: int = 20
            c: int = 30
            d = 40""")
    node = VariablesAnnotationsTransformer.transform(node)
    print(astor.to_source(node))
    assert astor.to_source(node) == """a = 10
            b = 20
            c = 30
            d = 40"""

# Generated at 2022-06-23 23:29:59.787798
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    nt = VariablesAnnotationsTransformer()
    assert nt.target == (3, 5)
    assert nt.transform is nt.__class__.transform


# Generated at 2022-06-23 23:30:04.185642
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree: ast.Module = ast.parse("a: int = 10")
    # assert str(tree.body[0]) == "a : int = 10"  # annotation is ignored
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree.body[0]) == "a = 10"

# Generated at 2022-06-23 23:30:12.515249
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class_name = VariablesAnnotationsTransformer.__name__
    result = VariablesAnnotationsTransformer.transform(test_tree)
    ast.fix_missing_locations(result)
    code_gen = compile(result, filename="<ast>", mode="exec")
    exec(code_gen)

    # check if the number of test cases failed is zero
    assert Test.failed == 0, f"{Test.failed} test cases failed in {class_name}."


test_tree = ast.parse("""
a: int = 10
b: int
a = 10
a = 10
""")

Test.run_tests()

# Generated at 2022-06-23 23:30:21.052594
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import create_module
    from ..utils.tree import pretty

    transformer = VariablesAnnotationsTransformer(ast.parse(''))

    module = create_module(
        ['a: int = 10',
         'b: int'])

    transformed, _ = transformer.transform(module)

    assert pretty(transformed) == '''\
Module(body=[
    Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10)),
    Assign(targets=[Name(id='b', ctx=Store())], value=None),
])
'''

# Generated at 2022-06-23 23:30:27.074805
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    from ..types import TransformationResult
    from typed_ast import ast3 as ast

    # Arrange
    tree = ast.parse("a: int = 10")

    # Act
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    
    # Assert
    assert type(result) == TransformationResult
    assert result.current_tree == ast.parse("a = 10")

# Generated at 2022-06-23 23:30:35.180641
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # GIVEN
    node_1_1 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                             annotation=ast.Name(id='int', ctx=ast.Load()),
                             value=ast.Num(1))
    node_1_2 = ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()),
                             annotation=ast.Name(id='int', ctx=ast.Load()),
                             value=ast.Num(2))
    node_1_3 = ast.AnnAssign(target=ast.Name(id='c', ctx=ast.Store()),
                             annotation=ast.Name(id='int', ctx=ast.Load()),
                             value=ast.Num(3))
   

# Generated at 2022-06-23 23:30:42.199267
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("x: int = 10\ny: str = 'abc'")
    transformer = VariablesAnnotationsTransformer()
    transformed_tree = transformer.transform(tree)

    assert ast.dump(transformed_tree.tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=10), type_comment='int'), Assign(targets=[Name(id='y', ctx=Store())], value=Str(s='abc'), type_comment='str')])"



# Generated at 2022-06-23 23:30:44.630987
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    result = VariablesAnnotationsTransformer([3, 5])
    assert isinstance(result, VariablesAnnotationsTransformer)


# Generated at 2022-06-23 23:30:46.046324
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))

# Generated at 2022-06-23 23:30:49.237215
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1: creating an instance of class VariablesAnnotationsTransformer
    test1 = VariablesAnnotationsTransformer('test1')
    assert test1.name == 'test1'



# Generated at 2022-06-23 23:30:52.030015
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse("a: int = 10\nb: int")

    res = VariablesAnnotationsTransformer.transform(a)
    assert res.tree == ast.parse("a = 10")

# Generated at 2022-06-23 23:30:55.895041
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse(
    """
    def f():
        a: int = 10
        b: int
    """
    )
    expected_tree = ast.parse(
    """
    def f():
        a = 10
        b = int
    """
    )
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree).changed
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:30:57.562713
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert isinstance(vat, BaseTransformer)
    assert vat.target == (3, 5)

# Generated at 2022-06-23 23:31:05.807265
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_test_case
    from ..utils.ast_builder import AstBuilder
    from ..visitors import ClassVisitor
    from ..exceptions import NodeNotFound

    for test in get_test_case(__file__, 'VariableAnnotationsTransformer_test_case.txt'):
        try:
            node = ast.parse(test['code'])
            node = AstBuilder(ClassVisitor(VariablesAnnotationsTransformer)).visit(node)
            assert str(node) == test['expected']
        except NodeNotFound:
            assert str(test['code']) == test['expected']