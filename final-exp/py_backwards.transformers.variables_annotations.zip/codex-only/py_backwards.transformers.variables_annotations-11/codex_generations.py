

# Generated at 2022-06-23 23:21:14.011238
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import is_equivalent_ast
    import typed_ast.ast3 as ast
    x = ast.Assign(
        targets=[
            ast.Name(id='__pyck_exp_0', ctx=ast.Store())
        ],
        value=ast.Num(n=1),
        type_comment=None
    )
    y = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=x,
        simple=1
    )
    z = ast.Module(
        body=[
            y
        ]
    )

# Generated at 2022-06-23 23:21:20.767683
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    try:
        assert (VariablesAnnotationsTransformer().transform("") == None)
    except:
        raise Exception("Fail")
    try:
        assert (VariablesAnnotationsTransformer("").transform("") == None)
    except:
        raise Exception("Fail")
    try:
        assert (VariablesAnnotationsTransformer(3, 4).transform("") == None)
    except:
        raise Exception("Fail")
    try:
        assert (VariablesAnnotationsTransformer().transform("") == None)
    except:
        raise Exception("Fail")
    try:
        assert (VariablesAnnotationsTransformer(3, 4).transform("") == None)
    except:
        raise Exception("Fail")
    try:
        assert (VariablesAnnotationsTransformer(3, 4).target == None)
    except:
        raise Exception

# Generated at 2022-06-23 23:21:21.418776
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass



# Generated at 2022-06-23 23:21:25.970186
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    one_node = ast.AnnAssign(
        target=ast.Name(id='a', ctx=ast.Store()),
        annotation=ast.Name(id='int', ctx=ast.Load()),
        value=ast.Num(n=10))
    two_nodes = ast.Module(body=[one_node, one_node])
    result = VariablesAnnotationsTransformer.transform(two_nodes)
    if result.tree_changed is not True:
        raise AssertionError(
            f'result.tree_changed is {result.tree_changed}, should be True')

# Generated at 2022-06-23 23:21:27.150553
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_annote = VariablesAnnotationsTransformer()
    assert var_annote.transform

# Generated at 2022-06-23 23:21:36.857837
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import transform
    from ..utils.ast_factory import fake_module, fake_assign, fake_ann_assign
    from ..utils.helpers import assert_ast_equals

    fake_module_1 = fake_module([fake_assign('a', '10'),
                                 fake_ann_assign('b', 'int', 'c')])
    expected_module_1 = fake_module([fake_assign('a', '10'),
                                     fake_assign('b', 'c')])
    assert_ast_equals(transform(fake_module_1,
                                VariablesAnnotationsTransformer),
                      expected_module_1)

    fake_module_2 = fake_module([fake_assign('a', '10'),
                                 fake_ann_assign('b', 'int')])
   

# Generated at 2022-06-23 23:21:41.004453
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_string = """a: int = 10
                      b: int"""

    expected_output = """a = 10
                        b: int"""

    tree = ast.parse(input_string)
    result, tree_changed, warnings = VariablesAnnotationsTransformer.transform(tree)

    assert result == ast.parse(expected_output), "VariablesAnnotationsTransformer failed."

# Generated at 2022-06-23 23:21:43.520272
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # IndentationError: unexpected indent
    # assert VariablesAnnotationsTransformer.target == (3.5)

    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'

# Generated at 2022-06-23 23:21:45.687124
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer({'a': 10, 'b': 20}) == \
           {'a': 10, 'b': 20}

# Generated at 2022-06-23 23:21:47.003119
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)

# Generated at 2022-06-23 23:21:48.685126
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    ass = ast.Assign()
    vat.transform(ass)

# Generated at 2022-06-23 23:21:53.593706
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    node = ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                            annotation=ast.Name(id='int', ctx=ast.Load()),
                            value=ast.Num(n=1),
                            simple=1)
    
    # This will also check BaseTransformer's constructor
    assert VariablesAnnotationsTransformer.transform(node) == \
                        TransformationResult(None, True, None)

# Generated at 2022-06-23 23:22:03.356521
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int') # Annotation on a is removed
    tree_ = ast.parse('a = 10\nb: int')
    assert VariablesAnnotationsTransformer.transform(tree) == \
        TransformationResult(tree_, tree_changed=True, type_comments=[])

    tree = ast.parse('a: int\nb: int\nc: int') # No assignment so annotations are left alone
    tree_ = ast.parse('a: int\nb: int\nc: int')
    assert VariablesAnnotationsTransformer.transform(tree) == \
        TransformationResult(tree_, tree_changed=False, type_comments=[])

    tree = ast.parse('a = 10') # No annotation
    tree_ = ast.parse('a = 10')
    assert VariablesAnnotationsTransformer.transform

# Generated at 2022-06-23 23:22:04.315755
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:22:08.030959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10 \nb: int")
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed

if __name__ == '__main__':
    test_VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:22:09.071696
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer


# Generated at 2022-06-23 23:22:12.348891
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = """
a: str = 10
b: int
"""
    expected_output = """
a = 10

"""
    output = str(VariablesAnnotationsTransformer.transform(input_code))
    assert expected_output in output

# Generated at 2022-06-23 23:22:20.741390
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse("a: int = 10")
    a_node = a.body[0]
    assert isinstance(a_node, ast.AnnAssign)
    assert isinstance(a_node.target, ast.Name)
    assert isinstance(a_node.value, ast.Num)
    assert isinstance(a_node.annotation, ast.Name)

    # a: int = 10 -> a = 10
    b = VariablesAnnotationsTransformer.transform(a)
    b_node = b.body[0]
    assert isinstance(b_node, ast.Assign)
    assert isinstance(b_node.targets[0], ast.Name)
    assert isinstance(b_node.value, ast.Num)
    assert len(b_node.type_comment) > 0

    # a

# Generated at 2022-06-23 23:22:21.493558
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:22:24.817247
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert not VariablesAnnotationsTransformer.can_be_applied_to((2, 7))
    assert not VariablesAnnotationsTransformer.can_be_applied_to((3, 3))



# Generated at 2022-06-23 23:22:34.638778
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test all code paths in transform method of class VariablesAnnotationsTransformer
    """
    tree = ast.parse("from typing import List; x: List[int] = [1, 2];")
    assert not VariablesAnnotationsTransformer.transformed(tree, 3)
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed
    tree = ast.parse("from typing import List; x: List[int] = [1, 2];")
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree_changed
    assert not res.errors
    tree = ast.parse("x: int = 10")
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree_changed
    assert not res.errors
    tree = ast.parse("y: str")

# Generated at 2022-06-23 23:22:41.823163
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int = 10")
    t = VariablesAnnotationsTransformer.transform(tree)
    assert(str(t.tree) == "a = 10\nb = 10")
    assert(not t.tree_changed)
    assert(len(t.warnings) == 0)

    tree = ast.parse("a: int = 10\nb: int")
    t = VariablesAnnotationsTransformer.transform(tree)
    assert(str(t.tree) == "a = 10")
    assert(t.tree_changed)
    assert(len(t.warnings) == 0)

# Generated at 2022-06-23 23:22:45.548017
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .python_to_python_types_transformer import PythonToPythonTypesTransformer
    from .class_transformer import ClassTransformer
    from ..internal.pipeline import TransformerPipeline
    import astunparse


# Generated at 2022-06-23 23:22:50.325873
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse("""a: int = 10""")
    result = VariablesAnnotationsTransformer.transform(test_tree)
    assert str((result.modified_tree)) == str(ast.parse("""a = 10"""))
    test_tree = ast.parse("""b: int""")
    result = VariablesAnnotationsTransformer.transform(test_tree)
    assert str((result.modified_tree)) == str(ast.parse("""None"""))

# Generated at 2022-06-23 23:22:51.398139
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    # Test if class was created
    try:
        VariablesAnnotationsTransformer()
        assert True
    except:
        assert False

# Generated at 2022-06-23 23:22:58.066261
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.transformer = VariablesAnnotationsTransformer()
            self.tree = ast.parse('a: int = 1; b: int; c: int = 2')

        def test_transform(self):
            result = self.transformer.transform(self.tree)
            self.assertIsInstance(result, TransformationResult)
            self.assertIsInstance(result.tree, ast.Module)
            self.assertTrue(result.tree_changed)

# Generated at 2022-06-23 23:23:05.759519
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Unit test for class VariablesAnnotationsTransformer.
    '''

    # Create instances of class VariablesAnnotationsTransformer
    vartransformer = VariablesAnnotationsTransformer()
    assert(isinstance(vartransformer, VariablesAnnotationsTransformer))

    assert(isinstance(vartransformer.__class__, type))

    # Testing of method transform
    # Create an object for parsed code
    class_code = "b: int\na: int = 10\n"

    class_ast = ast.parse(class_code)
    assert(isinstance(class_ast, ast.AST))

    # Transform the parsed code
    class_transformation = vartransformer.transform(class_ast)
    assert(isinstance(class_transformation, TransformationResult))

    # Print the result of transformation
    print

# Generated at 2022-06-23 23:23:15.904648
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """Testing VariablesAnnotationsTransformer class"""
    print_info("Testing VariablesAnnotationsTransformer class", __file__)
    test_result = False
    t = VariablesAnnotationsTransformer()
    tree = t.transform(ast.parse(
        '''a: int = 10
        b: int
        b = 10
        b = 20
        b: str = "abc"
        myList = [1, 2, 3]
        myList = [1, 2, 3]'''))
    if tree.body[0].value.value == 10:
        if tree.body[1].targets[0].id == "b":
            if tree.body[2].value.value == 20:
                test_result = True
    print_result(test_result)

# Generated at 2022-06-23 23:23:16.775852
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

# Generated at 2022-06-23 23:23:21.861243
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = ast.parse(input_code)
    transformed_tree, tree_changed, code_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert expected_code == astor.to_source(transformed_tree)


# Generated at 2022-06-23 23:23:26.970601
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import dump, load
    d = {'a: int': 'a', 'b: int': 'b', 'c: int': 'c', 'd: int': 'd'}
    for k in d:
        tree = load(k)
        new_tree, changed, errors = VariablesAnnotationsTransformer.transform(tree)
        if not errors:
            assert dump(new_tree) == d[k]
            assert changed == True
        else:
            assert False


# Generated at 2022-06-23 23:23:32.208983
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from unittest import TestCase
    from ..utils.helpers import get_tree_and_type_comment
    from ..utils.tree import compare_trees
    from ..utils.helpers import get_source_from_node
    from ..utils.tree import get_ast_from_source
    from ..errors import TypeCommentSyntaxError
    import astor

# Generated at 2022-06-23 23:23:39.902798
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = "a:int = 10 \n b:int"
    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(new_tree.new_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Num(n=10)), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=None)])"
    assert new_tree.tree_changed == True

# Generated at 2022-06-23 23:23:44.195195
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import compile_and_compare

    code = '''
    a: int = 10
    b : int

    '''
    correct_code = '''
    a = 10

    '''
    compile_and_compare(code, correct_code, [VariablesAnnotationsTransformer])

# Generated at 2022-06-23 23:23:45.515722
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:23:50.657062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # test for method transform on class VariablesAnnotationsTransformer
    tree = ast.parse('''
c: int
a: int = 10
b: int
''')

    assert VariablesAnnotationsTransformer.transform(tree).transformed_tree == ast.parse('''
c: int
a = 10
b: int
''')

# Generated at 2022-06-23 23:23:58.670399
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ast import parse
    from .transformations import TransformationPipeline

    #Unit test for class VariablesAnnotationsTransformer
    code = '''
    def myfunc(a: int = 10, b: int):
        return a
        '''

    test_tree = parse(code)
    assert isinstance(test_tree, ast.Module)
    x = TransformationPipeline([VariablesAnnotationsTransformer()])
    x.apply_transformation(test_tree)
    print(ast.dump(test_tree))


# Generated at 2022-06-23 23:24:06.855015
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    #a: int
    #b: int
    node = ast.FunctionDef(name='hello_world', args=ast.arguments(
        posonlyargs=[],
        args=[],
        kwonlyargs=[],
        annotations={'a': ast.Name(id='int'), 'b': ast.Name(id='int')},
        vararg=None,
        kwarg=None))


    result_code: bytes
    result_code = compile(node, filename='<ast>', mode='exec')
    assert result_code is not None
    tt = ast.parse(result_code)
    assert tt is not None
    assert isinstance(tt, ast.FunctionDef)

# Generated at 2022-06-23 23:24:17.184376
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    # Before
    code_before = '''
    a: int = 10
    b: int
    '''
    # After
    code_after = '''
    a = 10
    '''
    # Constructor test
    obj = VariablesAnnotationsTransformer()
    # Code before
    root_node_before = astor.parse_file(dedent(code_before))
    # Code after
    root_node_after = astor.parse_file(dedent(code_after))
    # Transform
    result = VariablesAnnotationsTransformer.transform(root_node_before)
    # Compare
    assert ast.dump(root_node_after) == ast.dump(result.tree)
    # Result test
    assert result.tree != root_node_before

# Generated at 2022-06-23 23:24:22.574476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    node=ast.parse("""
import typing
a: int = 10
b: typing.List[int] = [1, 2, 3]
""")

    node=VariablesAnnotationsTransformer.run_on_node(node)

    assert(astor.to_source(node).strip()=="""import typing
a = 10
b = [1, 2, 3]""")

# Generated at 2022-06-23 23:24:24.038547
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:24:28.814083
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    a = ast.parse('a: int = 10')
    b = ast.parse('b: int')

    tree = ast.Module(body=[a, b])

    result = VariablesAnnotationsTransformer.transform(tree)
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.Assign)
    assert isinstance(result.body[1], ast.AnnAssign)
    assert result.tree_changed



# Generated at 2022-06-23 23:24:35.790845
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_from_str
    from ..utils.tree import print_ast
    s = """def test(a: int, b: int) -> None:
    a: int = 1
    b = 2
"""
    m = generate_from_str(s, mode="exec")
    print_ast.print_ast(m)
    result = VariablesAnnotationsTransformer.transform(m)
    print_ast.print_ast(m)
    assert result.tree_changed == True
    assert result.log == []

# Generated at 2022-06-23 23:24:41.515726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int', mode='exec')
    assert ast.dump(VariablesAnnotationsTransformer.transform(tree).tree) ==\
        "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Str(s='int')), " \
        "AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), " \
        "value=None, simple=1)])"

# Generated at 2022-06-23 23:24:44.624186
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)
    tree = ast.parse('''a: int = 10''')
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == TransformationResult(tree, True, [])

# Generated at 2022-06-23 23:24:48.650971
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert type(result.new_tree.body[0]) == ast.Assign and \
        type(result.new_tree.body[0].value) == ast.Num


# Generated at 2022-06-23 23:24:58.675419
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import compare_ast
    from ..utils import get_ast_for_string
    from ..utils.helpers import get_all_nodes_of_type

    # Test 1: Simple
    ast1 = get_ast_for_string('''
a: str = 'hello'
b: int
c: str
    ''')
    expected_ast1 = get_ast_for_string('''
a = 'hello'
b = None
c = None
    ''')
    ast1, transformed_ammount_ast1 = VariablesAnnotationsTransformer.transform(ast1)
    assert transformed_ammount_ast1 == 2 and compare_ast(ast1, expected_ast1, VariablesAnnotationsTransformer)

    # Test 2: Complex

# Generated at 2022-06-23 23:25:06.975225
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    file = 'test_files/test_code.py'
    with open(file, 'r') as source:
        source_code = source.read().encode()
    tree1 = ast.parse(source_code)

    # When - run macro
    result = VariablesAnnotationsTransformer.transform(tree1)

    # Then - make sure tree has desired modifications
    with open('test_files/test_code_output.py', 'r') as source:
        expected_result = ast.parse(source.read().encode())

    assert ast.dump(result.tree) == ast.dump(expected_result)

# Generated at 2022-06-23 23:25:15.700762
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor

    tree = astor.parse_file('''
    from typing import Optional

    a: int = 10
    b: Optional[int] = None
    c = 10
    d: int
    ''')

    expected = astor.parse_file('''
    from typing import Optional

    a = 10
    b = None
    c = 10
    d: int
    ''')

    cls = VariablesAnnotationsTransformer
    assert cls.target == (3, 5)

    result, tree_changed = cls.transform(tree)
    assert tree_changed is True
    assert astor.to_source(result) == astor.to_source(expected)


# Generated at 2022-06-23 23:25:20.256769
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ptn = '''
        a: int = 10
        b: int
    '''
    result = VariablesAnnotationsTransformer.transform(ast.parse(ptn))

    assert type(result) == TransformationResult
    assert str(result) == '''
        a = 10
        b: int
    '''

# Generated at 2022-06-23 23:25:21.305199
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:25:23.843805
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils import get_ast
    from ..utils.compare_asts import compare_asts


# Generated at 2022-06-23 23:25:28.895632
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10", "<string>")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == ast.parse("a = 10", "<string>")
    tree = ast.parse("a: int", "<string>")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == ast.parse("", "<string>")

# Generated at 2022-06-23 23:25:35.154509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1
    input_str = """
    a: int = 10
    b: int
    """
    expected_output = """
    a = 10
    """

    output = BaseTransformer.compile_string(input_str,
                                            VariablesAnnotationsTransformer)
    assert output == expected_output

    # Test case 2
    input_str = """
    a = 10
    b: int
    """
    expected_output = """
    a = 10
    """

    output = BaseTransformer.compile_string(input_str,
                                            VariablesAnnotationsTransformer)
    assert output == expected_output

# Generated at 2022-06-23 23:25:40.316037
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse('''
a: int = 10''')
    tree = VariablesAnnotationsTransformer.transform(a).tree
    assert tree.body[0].value.targets[0].id == 'a'
    assert tree.body[0].value.value.n == 10

# Generated at 2022-06-23 23:25:41.978191
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3, 5)



# Generated at 2022-06-23 23:25:47.097877
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Setup
    input = """
    class Foo:
        def __init__(self, a: int = 10, b: int):
            pass
    """
    expected_output = """
    class Foo:
        def __init__(self, b: int):
            a = 10
    """

    # Exercise
    actual_output = VariablesAnnotationsTransformer.transform(input)

    # Verify
    assert expected_output == actual_output

# Generated at 2022-06-23 23:25:54.963880
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast.ast3 import Module, AnnAssign, Name, Constant, FunctionDef
    from typed_ast.ast3 import arguments, arg
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound


# Generated at 2022-06-23 23:26:01.575248
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Initialize
    code = """
    a: int = 10
    b: int
    """
    expected = """
    a = 10
    """
    # Run code and check result
    tree = ast.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 23:26:03.773680
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
  my_class = VariablesAnnotationsTransformer()
  assert my_class.target == (3,5)


# Generated at 2022-06-23 23:26:12.128113
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.ast_helpers import get_node_target
    from .variables import VariablesTransformer
    from .base import Compiler
    from ast_helper import parse_ast, print_ast

    transformer = VariablesAnnotationsTransformer()
    target_node = get_node_target(transformer)

    code = """
    def func():
        a: int = 5
        b: int
        print(a, b)
    """
    name = 'sin'
    ast_tree = parse_ast(code)
    compiler = Compiler(ast_tree)
    compiler.add_transformer(VariablesTransformer)
    compiler.add_transformer(transformer)
    transformed = compiler.compile()
    assert print_ast(transformed.tree) == print_ast(target_node)

# Generated at 2022-06-23 23:26:14.973408
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("def foo():\n\ta: int = 10")).tree_to_str() == "def foo():\n\ta = 10"

# Generated at 2022-06-23 23:26:20.517925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: int = 10
    b: int
    """)

    expected_tree = ast.parse("""
    a = 10
    """)

    transformer = VariablesAnnotationsTransformer()
    actual_tree, _ = transformer.apply(tree)

    assert ast.dump(actual_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:26:21.821516
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform is \
    VariablesAnnotationsTransformer.transform

# Generated at 2022-06-23 23:26:23.490255
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    '''
    Test constructor of class VariablesAnnotationsTransformer
    '''
    VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:26:30.491872
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Initialize
    from .. import TransformVisitor

    from typed_ast import ast3 as ast

    from ..utils.tree import find

    input_text = '''\
    from typing import List, Tuple
    from typing import Dict
    
    
    def foo(a: int, b: str) -> List[Tuple[int, str]]:
        '''

    tree = ast.parse(input_text)

    # Test
    new_tree = TransformVisitor().visit(tree)

    # Verify
    assert len(find(new_tree, ast.AnnAssign)) == 0

# Generated at 2022-06-23 23:26:38.944881
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .. import compile
    from . import PlaceholderTransformer, VariablesTransformer

    code = '''
        a: int = 10
        b: int
    '''
    placeholders = [PlaceholderTransformer]
    variables = [VariablesTransformer]
    annotations = [VariablesAnnotationsTransformer]
    transformers = placeholders + variables + annotations

    tree = compile(code, output='ast')
    tree = PlaceholderTransformer.transform(tree).tree
    tree = VariablesTransformer.transform(tree).tree
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    expected = """
        a = 10
    """
    assert compile(expected, output='ast') == tree

# Generated at 2022-06-23 23:26:48.006790
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a = ast.parse('a: int = 10\nb: int')
    tree, _ = VariablesAnnotationsTransformer.transform(a)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].targets[0], ast.Name)
    assert tree.body[0].targets[0].id == 'a'
    assert isinstance(tree.body[0].value, ast.Num)
    assert tree.body[0].value.n == 10
    assert isinstance(tree.body[1], ast.Assign)
    assert isinstance(tree.body[1].targets[0], ast.Name)
    assert tree.body[1].targets

# Generated at 2022-06-23 23:26:55.781217
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.source import source_to_node

    source = source_to_node('''
    a: int = 10
    b: int = 20
    c: str = 'test'
    ''')

    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(source)
    target = source_to_node('''
    a = 10
    b = 20
    c = 'test'
    ''')

    assert result.node == target
    assert result.tree_changed == True
    assert result.targets == []

# Generated at 2022-06-23 23:27:03.145851
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import get_root, get_node

    a_code = """
    a: int = 1
    b: int = 2
    """
    tree = ast.parse(a_code)
    tree = get_root(tree)

    assert(isinstance(tree, ast.Module))
    assert(len(tree.body) == 2)
    assert(isinstance(tree.body[0], ast.AnnAssign))
    assert(isinstance(tree.body[1], ast.AnnAssign))

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert(isinstance(tree, ast.Module))
    assert(len(tree.body) == 2)
    assert(isinstance(tree.body[0], ast.Assign))

# Generated at 2022-06-23 23:27:05.287629
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test for constructor of class VariablesAnnotationsTransformer
    """
    transformer = VariablesAnnotationsTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:27:08.405624
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    var_anno_tran = VariablesAnnotationsTransformer(3, 5)

    assert var_anno_tran.target == (3, 5)



# Generated at 2022-06-23 23:27:16.409694
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from unittest.mock import Mock
    from ..utils.tree import find
    import ast

    tree_mock = Mock()
    node_mock = Mock()
    node_mock.target = 'a'
    node_mock.annotation = 'int'
    node_mock.value = 10

    tree_mock.body = [node_mock]

    result = VariablesAnnotationsTransformer.transform(tree_mock)

    assert(type(result.tree) == ast.Module)
    assert(len(result.tree.body) == 1)
    assert(type(result.tree.body[0]) == ast.Assign)

# Partial unit test for transformation of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:27:22.797529
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_tree = ast.parse('a: int = 10')
    test_init = VariablesAnnotationsTransformer()
    assert test_init.transform(test_tree) == (ast.parse('a = 10'), True, [])

    test_tree = ast.parse('b: int')
    test_init = VariablesAnnotationsTransformer()
    assert test_init.transform(test_tree) == (test_tree, False, [])

# Generated at 2022-06-23 23:27:24.395822
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert issubclass(VariablesAnnotationsTransformer, BaseTransformer)


# Generated at 2022-06-23 23:27:25.940171
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.target == (3,5)


# Generated at 2022-06-23 23:27:30.051038
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    vat = VariablesAnnotationsTransformer()
    assert vat.target == (3, 5)
    vat.transform(ast.parse('a = 1')) # Should throw NodeNotFound exception because there are no annotations in the tree


# Generated at 2022-06-23 23:27:40.175465
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
a: int = 10
b: int
    """.strip()
    tree = ast.parse(code)
    transformer = VariablesAnnotationsTransformer()
    tree_changed = transformer.transform(tree)
    assert transformer.target == (3, 5)
    assert tree_changed == True
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store(), annotation=Name(id='int', ctx=Load()))], value=Num(n=10, type_comment=None), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None)])"

# Generated at 2022-06-23 23:27:50.708319
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    testNode = ast.AnnAssign(lineno=2, col_offset=0,
            target=ast.Name(lineno=2, col_offset=0, id='a', ctx=ast.Store()),
            annotation=ast.Name(lineno=2, col_offset=2, id='int', ctx=ast.Load()),
            value=ast.Num(lineno=2, col_offset=11, n=10), simple=1)
    # Act
    actual = VariablesAnnotationsTransformer.transform(testNode)
    # Assert

# Generated at 2022-06-23 23:27:57.564413
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(
        ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                      annotation=ast.parse('int', mode='eval').body,
                      value=ast.Num(n=10),
                      simple=1)) == TransformationResult(
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=10),
                   type_comment=ast.parse('int', mode='eval').body), True, [])

# Generated at 2022-06-23 23:28:03.292154
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import dump
    from typed_ast import ast3

    tree = ast3.parse("""
    a: int = 10
    b: int
    """)
    new_tree, _, _ = VariablesAnnotationsTransformer.transform(tree)
    assert dump(new_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-23 23:28:13.032914
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int", mode='eval')
    t = VariablesAnnotationsTransformer()
    res = t.transform(tree)
    assert len(res.tree.body) == 2
    assert isinstance(res.tree.body[0], ast.Assign)
    assert len(res.tree.body[0].targets) == 1
    assert res.tree.body[0].targets[0].id == 'a'
    assert isinstance(res.tree.body[0].value, ast.Num)
    assert isinstance(res.tree.body[1], ast.Expr)
    assert isinstance(res.tree.body[1].value, ast.Name)
    assert res.tree.body[1].value.id == 'b'

# Generated at 2022-06-23 23:28:21.527941
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..unparser import Unparser
    import textwrap
    class Test:
        def __init__(self):
            self.a: int = 10
            self.b: int
    tree = ast.parse(textwrap.dedent("""
        class Test:
            def __init__(self):
                self.a: int = 10
                self.b: int
    """))
    VariablesAnnotationsTransformer.transform(tree)
    unparser = Unparser(tree)
    assert str(unparser) == textwrap.dedent("""\
        class Test:
            def __init__(self: object) -> None:
                self.a = 10
    """)

# Generated at 2022-06-23 23:28:23.030875
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert isinstance(VariablesAnnotationsTransformer, object)


# Generated at 2022-06-23 23:28:27.017464
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from .test_helpers import assert_transformed
    from ..utils import parse

    source = '''
        a: int = 10
        b: int
    '''

    expected = '''
        a = 10
    '''

    assert_transformed(VariablesAnnotationsTransformer, source, expected)

# Generated at 2022-06-23 23:28:35.127216
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    test_case_1 = ast.Module(body=[ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                                                 annotation=ast.Name(id='str', ctx=ast.Store()),
                                                 value=ast.Str(s='"hello"'))])
    tree_changed, new_tree = VariablesAnnotationsTransformer.transform(tree=test_case_1)
    assert tree_changed == True
    assert new_tree == ast.Module(body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                   value=ast.Str(s='"hello"'),
                                                   type_comment=ast.Name(id='str', ctx=ast.Store()))])

# Generated at 2022-06-23 23:28:43.493765
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    a: int=10
    b: int
    c = None
    d: int="Hello"

    # test ast.AnnAssign
    assert get_non_exp_parent_and_index(ast.parse("a: int=10"),ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10))) != None
    assert get_non_exp_parent_and_index(ast.parse("a: int=10"), ast.AnnAssign(target=ast.Name(id='b', ctx=ast.Store()), annotation=ast.Name(id='int', ctx=ast.Load()), value=ast.Num(n=10))) == None
    assert get_non_exp

# Generated at 2022-06-23 23:28:50.270773
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    null_expr = ast.Expr(value=ast.NameConstant(value=None), type_comment=None)
    target = ast.AnnAssign(target=ast.Name(id='m', ctx=ast.Store()), annotation=None, value=null_expr, type_comment=ast.Str(s='int'))
    result = ast.Assign(targets=[ast.Name(id='m', ctx=ast.Store())], value=null_expr, type_comment=ast.Str(s='int'))

    assert(VariablesAnnotationsTransformer.transform(target)[1][0] == result)

# Generated at 2022-06-23 23:28:57.366578
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""a: int = 10\nb: int""")
    res = VariablesAnnotationsTransformer.transform(tree)
    assert res.tree_changed == True
    assert ast.dump(res.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store(), annotation=Name(id='int', ctx=Load()))], value=Num(n=10), type_comment=None), Name(id='b', ctx=Store(), annotation=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-23 23:29:05.628289
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code_one = "a: int = 10\nb: int"
    expected_one = "a = 10"

    tree_one = ast.parse(code_one)
    new_tree_one = VariablesAnnotationsTransformer.transform(tree_one)
    assert astor.to_source(new_tree_one.tree) == expected_one

    code_two = "a: int = 10\nb: int = 20\nc: int = 30"
    expected_two = "a = 10\nb = 20\nc = 30"
    tree_two = ast.parse(code_two)
    new_tree_two = VariablesAnnotationsTransformer.transform(tree_two)
    assert astor.to_source(new_tree_two.tree) == expected_two

# Generated at 2022-06-23 23:29:10.866800
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..context import Context
    # a
    node = ast.AnnAssign()
    node_ = ast.AnnAssign(target = ast.Name(id = 'a', ctx = ast.Store()))
    node__ = ast.AnnAssign(target = ast.Name(id = 'a', ctx = ast.Store()), value = ast.Num(n = 10))
    # b
    node_3 = ast.AnnAssign()
    node_3_ = ast.AnnAssign(target = ast.Name(id = 'b', ctx = ast.Store()))
    node_3__ = ast.AnnAssign(target = ast.Name(id = 'b', ctx = ast.Store()), value = None)
    # c
    node_7 = ast.AnnAssign()

# Generated at 2022-06-23 23:29:19.588343
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():

    ####################################################################################################################
    # Check transform() works if it has two arguments and neither one is None or Config type
    ####################################################################################################################
    assert type(VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))) == TransformationResult
    ####################################################################################################################

    ####################################################################################################################
    # Check transform() works if it has two arguments and the first one is None
    ####################################################################################################################
    # assert type(VariablesAnnotationsTransformer.transform(None,None)) == TransformationResult
    ####################################################################################################################

# Generated at 2022-06-23 23:29:20.643149
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:29:21.990768
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    comp = VariablesAnnotationsTransformer()
    assert comp.target == (3, 5)

# Generated at 2022-06-23 23:29:30.229188
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    assignment_node = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()),
                                    annotation=ast.Name(id='int'),
                                    value=ast.Num(10))

    # a = 10
    assignment_node_desired = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                         value=ast.Num(10),
                                         type_comment=ast.Name(id='int'))

    # func() -> int:

# Generated at 2022-06-23 23:29:34.265238
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('''
    a: int = 10
    b: int
    ''')
    expected = ast.parse('''
    a = 10
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected

# Generated at 2022-06-23 23:29:36.530052
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input_code = "a:int"
    print(VariablesAnnotationsTransformer.transform(ast.parse(input_code)))

# Generated at 2022-06-23 23:29:43.462512
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = """a: int = 10
                b: int
                """
    expected_tree = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],  # type: ignore
                        value=ast.Num(n=10),
                        type_comment=ast.Str(s='int'))
    ])
    tree = ast.parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected_tree

# Generated at 2022-06-23 23:29:49.741771
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t1 = ast.parse('a:int = 10')
    t2 = ast.parse('b:int')
    

# Generated at 2022-06-23 23:29:58.745977
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils import tree

    # a: int = 10
    # b: int = 20

# Generated at 2022-06-23 23:30:01.844933
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    expected_value = TransformationResult(ast.parse('a = 10') ,True , [])
    actual_value = VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10'))
    assert expected_value == actual_value


# Generated at 2022-06-23 23:30:07.713355
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    x1 = ast.parse("""
        a: int = 10
        """)
    y1 = ast.parse("""
        a = 10
        """)
    assert VariablesAnnotationsTransformer.transform(x1[0]).tree == y1

    x2 = ast.parse("""
        a: int
        """)
    assert VariablesAnnotationsTransformer.transform(x2[0]).tree == x2

# Generated at 2022-06-23 23:30:11.717577
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    source = 'a: int = 10'
    expected = 'a = 10'

    tree = ast.parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    result.tree_modified.assert_equivalent_to(expected)

# Generated at 2022-06-23 23:30:19.905332
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    String = ast.Str

    class_ = ast.ClassDef(name='A', body=[
        ast.AnnAssign(target=ast.Name(id='a',
                                      ctx=ast.Store()),
                      annotation=String(),
                      value=String()),
        ast.AnnAssign(target=ast.Name(id='b',
                                      ctx=ast.Store()),
                      annotation=String(),
                      value=None)],  # type: ignore
        type_comments=[])
    tree = ast.Module(body=[class_], type_ignores=[])

    assert VariablesAnnotationsTransformer.transform(tree).changed
    print(tree)

# Generated at 2022-06-23 23:30:22.105247
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    """
    Test the constructor of class VariablesAnnotationsTransformer
    """
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-23 23:30:22.685611
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    pass

# Generated at 2022-06-23 23:30:26.266751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: int
    a: int = 10
    """)

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(ast.parse("""
    a = 10
    """), True, [])

# Generated at 2022-06-23 23:30:32.164404
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # type: () -> None
    from . import get_test_data
    from ..utils.helpers import generate_module
    from ..utils.debug import debug_ast_pretty

    test_data = get_test_data(__file__, 'data/variables_annotations.py')
    tree = generate_module(test_data)
    debug_ast_pretty(tree)
    # The following line raises no exception and prints no warning.
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-23 23:30:33.025937
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:33.815401
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    VariablesAnnotationsTransformer()

# Generated at 2022-06-23 23:30:41.367090
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-23 23:30:50.112355
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    for version in VariablesAnnotationsTransformer.target:
        tree = ast.parse('''
from typing import List

a: int = 10
b: int
c: List[int]
d: List[int] = [] 
''')  # type: ignore
        output = VariablesAnnotationsTransformer.transform(tree)
        assert output.tree_changed
        assert isinstance(output.tree, ast.Module)
        output_string = astunparse.unparse(output.tree)
        assert output_string == '''
from typing import List
a = 10

b
c
d = []

'''  # type: ignore

# Generated at 2022-06-23 23:30:55.045000
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    ast_1: ast.AST = ast.parse('''
if i:
    a: int = 10
    b: int
    d: int = 100
    c: int = 10
    e: int

if y:
    f: int = 10
    g: int
    b: int
    h: int
    i: int

''')

    ast_2: ast.AST = ast.parse('''
if i:
    a = 10
    b
    d = 100
    c = 10
    e

if y:
    f = 10
    g
    b
    h = 10
    i

''')
    assert ast.dump(VariablesAnnotationsTransformer.transform(ast_1).tree) == ast.dump(ast_2)

# Generated at 2022-06-23 23:31:05.667575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    class Node:
        def __init__(self, body=None):
            self.body = body.ast.Assign(
                    targets=[ast.AnnAssign(
                        target=body.ast.Name(id='a'),
                        annotation=body.ast.Name(id='int'),
                        value=body.ast.Num(n=10)
                    )],
                    value=None
                )
    a = body.ast.Num(n=10)
    t = Transformer(body.ast.Ast(body.ast.Module(body=Node())), [VariablesAnnotationsTransformer()])
    t.transform()
    print(ast.dump(t.tree))