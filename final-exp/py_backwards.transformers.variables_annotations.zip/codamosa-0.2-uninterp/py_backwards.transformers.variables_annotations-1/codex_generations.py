

# Generated at 2022-06-18 00:41:19.630875
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor


# Generated at 2022-06-18 00:41:28.338982
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:41:38.487954
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:41:44.083329
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''

    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:41:54.377663
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    #   a: int = 10
    #   b: int
    # To:
    #   a = 10
    #   b: int
    tree = ast.parse('a: int = 10\nb: int')
    expected_tree = ast.parse('a = 10\nb: int')
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

    # Test 2:
    #   a: int = 10
    #   b: int
    # To:
    #   a = 10
    #   b: int
    tree = ast.parse('a: int = 10\nb: int')
    expected_tree = ast.parse('a = 10\nb: int')
    VariablesAnnotationsTransformer.transform(tree)
   

# Generated at 2022-06-18 00:42:04.247206
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.ast_builder import build_ast
    from ..utils.tree import find
    from ..utils.helpers import get_non_exp_parent_and_index
    from ..utils.helpers import assert_equal_ast
    from ..utils.ast_builder import build_ast
    from ..utils.tree import find
    from ..utils.helpers import get_non_exp_parent_and_index
    from ..utils.helpers import assert_equal_ast
    from ..utils.ast_builder import build_ast
    from ..utils.tree import find
    from ..utils.helpers import get_non_exp_parent_and_index
    from ..utils.helpers import assert_equal_ast
    from ..utils.ast_builder import build_ast

# Generated at 2022-06-18 00:42:08.010678
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    expected = get_ast('''
        a = 10
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected

# Generated at 2022-06-18 00:42:13.510561
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:42:19.175302
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    tree = parse_ast("""
a: int = 10
b: int
    """)

    expected_tree = parse_ast("""
a = 10
    """)

    assert_equal_ast(VariablesAnnotationsTransformer.transform(tree).tree, expected_tree)

# Generated at 2022-06-18 00:42:29.159935
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:40.781260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:49.252396
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:42:52.365673
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import load_ast

    tree = load_ast('''
    a: int = 10
    b: int
    ''')

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.tree.body[0].value.n == 10
    assert new_tree.tree.body[1].value is None

# Generated at 2022-06-18 00:42:58.931612
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:43:08.401804
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    VariablesAnnotationsTransformer.transform(tree)

    assert tree.body[0].__class__ == ast.Assign
    assert tree.body[0].targets[0].__class__ == ast.Name
    assert tree.body[0].targets[0].id == 'a'
    assert tree.body[0].value.__class__ == ast.Num
    assert tree.body[0].value.n == 10
    assert tree.body[0].type_comment == 'int'

    assert tree.body[1].__class__ == ast.Assign
    assert tree.body[1].targets[0].__class__ == ast.Name

# Generated at 2022-06-18 00:43:12.718350
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:43:17.448948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            print(node)

    tree = get_ast('a: int = 10')
    print(to_code(tree))
    VariablesAnnotationsTransformer.transform(tree)
    print(to_code(tree))
    Visitor().visit(tree)

# Generated at 2022-06-18 00:43:25.198680
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast_from_source
    from ..utils.tree import compare_ast

    source = """
    a: int = 10
    b: int
    """

    expected = """
    a = 10
    """

    tree = get_ast_from_source(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    expected = get_ast_from_source(expected)

    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:43:35.135001
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:43:40.006660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    input = """
    a: int = 10
    b: int
    """
    expected = """
    a = 10
    """
    tree = ast.parse(input)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == expected

# Generated at 2022-06-18 00:43:50.125977
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_ast_node
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_body
    from ..utils.helpers import get_ast_node_value

# Generated at 2022-06-18 00:43:55.686907
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse('''
a: int = 10
b: int
    ''')
    # a = 10
    expected_tree = ast.parse('''
a = 10
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.warnings == []

# Generated at 2022-06-18 00:44:03.096738
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:07.549387
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_all_nodes
    from ..utils.code_gen import to_source

    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert to_source(tree) == """
    a = 10
    """
    assert get_node_name(get_all_nodes(tree)[0]) == 'Assign'

# Generated at 2022-06-18 00:44:11.640808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:22.347956
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:30.087919
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_diff

    code = """
    a: int = 10
    b: int
    """
    expected = """
    a = 10
    """
    tree = parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(new_tree.tree) == expected
    assert new_tree.tree_changed
    assert get_ast_diff(tree, new_tree.tree)

# Generated at 2022-06-18 00:44:36.240178
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.compare import compare_asts

    code = """
    a: int = 10
    b: int
    """
    expected = """
    a = 10
    """

    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert compare_asts(dump(new_tree.tree), dump(get_ast(expected)))

# Generated at 2022-06-18 00:44:46.313146
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import get_code
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_ctx
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_children
    from ..utils.helpers import get_

# Generated at 2022-06-18 00:44:54.010957
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree == ast.parse("""
    a = 10
    """)

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree == ast.parse("""
    a = 10
    """)

# Generated at 2022-06-18 00:45:13.223553
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import compare_trees
    from ..utils.tree import build_ast
    from ..utils.source import Source
    from ..utils.helpers import get_ast

    source = Source("""
    a: int = 10
    b: int
    """)

    expected_tree = get_ast(source)
    expected_tree.body[0].value = None
    expected_tree.body[1] = ast.Assign(targets=[expected_tree.body[1].target],
                                       value=None,
                                       type_comment=expected_tree.body[1].annotation)

    tree = build_ast(source)
    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed
    assert compare_trees(result.new_tree, expected_tree)

# Generated at 2022-06-18 00:45:16.945311
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:45:20.791211
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_ast
    from ..utils.helpers import compare_ast
    from ..utils.helpers import get_ast_diff


# Generated at 2022-06-18 00:45:26.666089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:45:35.352472
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            print(node.target)
            print(node.annotation)
            print(node.value)

    class Transformer(NodeTransformerVisitor):
        def visit_AnnAssign(self, node):
            return ast.Assign(targets=[node.target],  # type: ignore
                              value=node.value,
                              type_comment=node.annotation)


# Generated at 2022-06-18 00:45:43.226666
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_trees
    from ..utils.source import generate_code
    from ..utils.source import dedent_source

    source = dedent_source("""
    a: int = 10
    b: int
    """)
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert generate_code(tree) == dedent_source("""
    a = 10
    """)

# Generated at 2022-06-18 00:45:51.810919
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue
        tree_changed = True
        parent.body.pop

# Generated at 2022-06-18 00:45:59.197826
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_node_names
    from .base import BaseTransformer
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:46:10.112534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import get_all_of_class
    from ..utils.code_gen import to_source
    from ..utils.source import Source
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import find
    from ..utils.helpers import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..utils.code_gen import to_source
    from ..utils.source import Source
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import find
    from ..utils.helpers import get_non_exp_parent_and_index
    from ..utils.tree import insert_at

# Generated at 2022-06-18 00:46:20.326816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:42.884446
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:46:52.230018
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_ast
    from ..utils.helpers import get_code_and_ast
    from ..utils.helpers import get_ast_and_code
    from ..utils.helpers import get_ast_and_source
    from ..utils.helpers import get_source_and_ast
    from ..utils.helpers import get_source_and_code
    from ..utils.helpers import get_code_and_source
    from ..utils.helpers import get_source
    from ..utils.helpers import get_ast_and_tree
    from ..utils.helpers import get_tree_and_ast
    from ..utils.helpers import get_source_and_tree

# Generated at 2022-06-18 00:46:56.408596
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:47:03.187610
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_names
    from ..utils.tree import find
    from ..utils.source import source_to_tree
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    source = '''
    a: int = 10
    b: int
    '''
    tree = source_to_tree(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_node_names(tree) == ['Module', 'Assign', 'Assign']
    assert find(tree, ast.AnnAssign) == []

# Generated at 2022-06-18 00:47:07.082169
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    assert to_code(VariablesAnnotationsTransformer.transform(tree).tree) == 'a = 10'

# Generated at 2022-06-18 00:47:13.078137
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:47:20.566232
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import dump_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import dump_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import dump_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import dump_ast
    from ..utils.tree import find, get_

# Generated at 2022-06-18 00:47:24.862070
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == '''
a = 10
    '''

# Generated at 2022-06-18 00:47:34.324273
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str

# Generated at 2022-06-18 00:47:44.082568
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_code
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_value
    from ..utils.ast_helpers import get_ast_node_type
    from ..utils.ast_helpers import get_ast_node_lineno
    from ..utils.ast_helpers import get_ast_node_col_offset
    from ..utils.ast_helpers import get_ast_node_end_lineno
    from ..utils.ast_helpers import get_ast_node_end_col_offset
    from ..utils.ast_helpers import get_ast_node_parent

# Generated at 2022-06-18 00:48:25.543547
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_name
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            self.generic_visit(node)

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    visitor = TestVisitor()
    visitor.visit(tree)

    assert get_node_name(tree.body[0]) == 'Assign'
    assert get_node_name(tree.body[1]) == 'Assign'

# Generated at 2022-06-18 00:48:33.251709
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent_source

    source = dedent_source("""
    a: int = 10
    b: int
    """)
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, dedent_source("""
    a = 10
    """))
    assert generate_code(tree) == dedent_source("""
    a = 10
    """)

# Generated at 2022-06-18 00:48:37.672751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_code
    from .base import BaseTransformer

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:43.866575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import print_tree
    from ..utils.source import source_to_tree

    source = """
    a: int = 10
    b: int
    """
    tree = source_to_tree(source)
    print_tree(tree)
    result = VariablesAnnotationsTransformer.transform(tree)
    print_tree(result.tree)
    assert result.tree_changed
    assert get_node_of_type(result.tree, ast.AnnAssign) is None
    assert get_node_of_type(result.tree, ast.Assign) is not None

# Generated at 2022-06-18 00:48:50.609080
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..types import TransformationResult

    tree = ast.parse("""
    a: int = 10
    b: int
    """)

    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:48:59.301178
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:03.684696
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:49:10.996027
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:17.913287
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:26.067502
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_by_path

    tree = ast.parse("""
a: int = 10
b: int
    """)

    transformer = VariablesAnnotationsTransformer()
    new_tree = transformer.transform(tree)

    assert get_node_name(get_node_by_path(new_tree, [0])) == 'Assign'
    assert get_node_name(get_node_by_path(new_tree, [1])) == 'Assign'

# Generated at 2022-06-18 00:51:08.178657
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.test_utils import get_test_cases
    from ..utils.tree import parse_ast

    test_cases = get_test_cases(__file__, 'VariablesAnnotationsTransformer')

    for test_case in test_cases:
        tree = parse_ast(test_case.input)
        VariablesAnnotationsTransformer.transform(tree)
        assert_equal_ast(test_case.expected, tree)

# Generated at 2022-06-18 00:51:17.453157
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent_source

    source = dedent_source("""
    a: int = 10
    b: int
    """)
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert compare_ast(tree, dedent_source("""
    a = 10
    """))
    assert generate_code(tree) == dedent_source("""
    a = 10
    """)