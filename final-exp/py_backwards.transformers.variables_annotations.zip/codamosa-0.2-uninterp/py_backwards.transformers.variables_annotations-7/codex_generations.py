

# Generated at 2022-06-18 00:41:23.183358
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:41:28.870488
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast("""
    a = 10
    """))

    assert generate_code(tree) == "a = 10"

# Generated at 2022-06-18 00:41:38.967157
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:44.253496
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    tree = parse_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    expected = parse_ast('''
    a = 10
    ''')

    assert_equal_ast(result.tree, expected)

# Generated at 2022-06-18 00:41:49.297786
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    # When
    result = VariablesAnnotationsTransformer.transform(ast.parse(code))
    # Then
    assert expected_code == astor.to_source(result.tree)

# Generated at 2022-06-18 00:41:54.103877
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    source = """
    a: int = 10
    b: int
    """
    expected = """
    a = 10
    """
    tree = get_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert expected == astor.to_source(new_tree)

# Generated at 2022-06-18 00:42:04.246854
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:42:07.751758
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:42:17.921254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int = 10',
                          'a = 10')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int\nb: int = 10',
                          'a\nb = 10')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int = 10\nb: int',
                          'a = 10\nb')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int = 10\nb: int = 20',
                          'a = 10\nb = 20')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int\nb: int',
                          'a\nb')

# Generated at 2022-06-18 00:42:27.442254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:39.198474
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:50.476009
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    tree = parse_ast("""
    a: int = 10
    b: int
    """)
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index) 

# Generated at 2022-06-18 00:42:54.955439
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == parse("""
    a = 10
    """)

# Generated at 2022-06-18 00:42:58.880526
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('a: int = 10')
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:43:04.310291
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:13.670642
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'
    assert result.tree_changed
    assert result.warnings == []

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'
    assert result.tree_changed
    assert result.warnings == []


# Generated at 2022-06-18 00:43:16.330062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:43:22.368575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_to_ast

    code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(tree, expected_code)

# Generated at 2022-06-18 00:43:30.431634
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:32.823094
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast

    code = """
    a: int = 10
    b: int
    """

    tree = parse_code_to_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:43.630904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent

    source = dedent('''
    a: int = 10
    b: int
    ''')
    expected = dedent('''
    a = 10
    ''')

    tree = get_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(generate_code(new_tree), expected)

# Generated at 2022-06-18 00:43:47.614870
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None
    assert result.tree_changed
    assert result.messages == []

# Generated at 2022-06-18 00:43:56.871174
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:04.070399
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import compare_trees
    from ..utils.tree import build_ast
    from ..utils.codegen import to_source

    code = """
    a: int = 10
    b: int
    """
    tree = build_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_trees(build_ast(code), tree) == True
    assert to_source(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:44:13.845850
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import get_test_case_as_ast, assert_ast_equal
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import find

    test_case = get_test_case_as_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(test_case)

    assert_ast_equal(result.tree, '''
        a = 10
    ''')

    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1
    assert get_ast_node_name(find(result.tree, ast.Assign)[0].targets[0]) == 'Name'
    assert get_

# Generated at 2022-06-18 00:44:19.268528
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    tree = parse_to_ast("""
    a: int = 10
    b: int
    """)

    expected_tree = parse_to_ast("""
    a = 10
    """)

    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == generate_code(expected_tree)

# Generated at 2022-06-18 00:44:26.496534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''

    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast(expected_code))
    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:44:32.843759
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:44:41.092909
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..utils.tree import insert_at
    from ..utils.source import source_to_unicode
    from ..utils.compare import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode
    from ..utils.compare import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find


# Generated at 2022-06-18 00:44:52.199212
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_parent_index
    from ..utils.helpers import get_ast_node_parent_field

# Generated at 2022-06-18 00:45:00.720175
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('a: int = 10')
    assert len(find(tree, ast.AnnAssign)) == 1
    VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:45:04.990755
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.tree == get_ast('''
    a = 10
    ''')

# Generated at 2022-06-18 00:45:15.159480
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:23.962756
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:30.779840
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import get_source

    tree = get_ast(get_source('3.5', 'variables_annotations'))
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(get_ast(get_source('3.5', 'variables_annotations_expected')), new_tree)
    assert generate_code(new_tree) == get_source('3.5', 'variables_annotations_expected')

# Generated at 2022-06-18 00:45:36.598634
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_type_comment
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_ctx
    from ..utils.helpers import get_ast_node_body

# Generated at 2022-06-18 00:45:47.636955
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:55.975864
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:01.544227
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert find(tree, ast.AnnAssign) == []
    assert find(tree, ast.Assign) == [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=10), type_comment=ast.Name(id='int', ctx=ast.Load()))]

# Generated at 2022-06-18 00:46:06.596653
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:46:15.461331
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        VariablesAnnotationsTransformer,
        """
        a: int = 10
        b: int
        """,
        """
        a = 10
        """
    )

# Generated at 2022-06-18 00:46:22.657626
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:46:27.589237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    expected_tree = get_ast('''
        a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:46:34.504417
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    input_code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = ast.parse(input_code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert expected_code == astor.to_source(result.tree)

    # Test 2
    input_code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = ast.parse(input_code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert expected_code == astor.to_source(result.tree)

# Generated at 2022-06-18 00:46:41.808131
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:46.838589
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast

    tree = parse_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree == parse_ast('''
    a = 10
    ''')

# Generated at 2022-06-18 00:46:56.078803
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compat import StringIO
    from ..utils.source_code import SourceCode
    from ..utils.transform import transform

    source_code = SourceCode(
        path='test.py',
        code=StringIO(
            '''
            a: int = 10
            b: int
            '''
        )
    )

    tree = get_ast(source_code)
    tree = transform(tree, VariablesAnnotationsTransformer)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:46:56.820754
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:47:03.581621
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_source

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = get_ast(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert not result.errors
    assert compare_ast(result.tree, get_ast(expected))
    assert generate_source(result.tree) == expected

# Generated at 2022-06-18 00:47:06.477963
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('a: int = 10')
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == 'a = 10'

# Generated at 2022-06-18 00:47:27.284571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:35.743760
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:47:44.877578
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source

# Generated at 2022-06-18 00:47:47.858248
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees


# Generated at 2022-06-18 00:47:52.837987
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code_str
    from ..utils.tree import parse_to_ast

    code = """
    a: int = 10
    b: int
    """
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code_str(tree) == 'a = 10'

# Generated at 2022-06-18 00:47:58.298399
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all
    from ..utils.source import get_source

    tree = get_ast(get_source('test_files/test_VariablesAnnotationsTransformer.py'))
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:48:04.352861
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    class TestVisitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            assert node.target.id == 'a'
            assert node.annotation.id == 'int'
            assert node.value.n == 10
            assert node.simple == 1

    class TestTransformer(NodeTransformerVisitor):
        def visit_AnnAssign(self, node):
            node.target.id = 'b'
            node.annotation.id = 'float'
            node.value.n = 20


# Generated at 2022-06-18 00:48:12.917866
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    tree = parse_ast('a: int = 10\nb: int')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast3.AnnAssign)) == 0
    assert len(find(tree, ast3.Assign)) == 1
    assert len(find(tree, ast3.Name)) == 2

# Generated at 2022-06-18 00:48:17.596748
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    VariablesAnnotationsTransformer.transform(tree)

    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:48:24.010256
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed == True

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed == True

    # Test 3
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed == True

# Generated at 2022-06-18 00:48:51.018699
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import TransformationError

    # Test case 1:
    #   a: int = 10
    #   b: int
    #   c: int = 20
    #   d: int
    #   e: int = 30
    #   f: int
    #   g: int = 40
    #   h: int
    #   i: int = 50
    #   j: int
    #   k: int = 60
    #   l: int
    #   m: int = 70
    #   n: int
    #   o: int = 80
    #   p: int
    #   q: int = 90
    #   r: int
    #

# Generated at 2022-06-18 00:48:56.935305
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:49:07.076926
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:49:14.952112
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:19.476996
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import get_tree_string
    from ..utils.helpers import get_tree_hash
    from ..utils.helpers import get_tree_hash_without_comments
    from ..utils.helpers import get_tree_hash_without_comments_and_newlines
    from ..utils.helpers import get_tree_hash_without_newlines
    from ..utils.helpers import get_tree_hash_without_newlines_and_comments
    from ..utils.helpers import get_tree_hash_without_newlines_and_comments_and_indentation
    from ..utils.helpers import get_tree_hash_without_newlines_and_indentation

# Generated at 2022-06-18 00:49:23.616873
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:49:27.463659
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:49:33.945542
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    transformer = VariablesAnnotationsTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)

    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:49:38.849052
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import compare_trees

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed

    tree = get_ast('''
    a = 10
    ''')

    assert compare_trees(result.tree, tree)

# Generated at 2022-06-18 00:49:45.177553
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:50:47.544948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = """
a: int = 10
b: int
    """
    expected_code = """
a = 10
    """
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(new_tree, get_ast(expected_code))
    assert len(find(new_tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:50:53.162175
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_test_data

    code = get_test_data('test_variables_annotations.py')
    tree = ast.parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(new_tree.tree) == get_test_data('test_variables_annotations_transformed.py')

# Generated at 2022-06-18 00:50:56.576590
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("b: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:51:00.632112
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:51:04.235300
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    assert to_code(tree) == code

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:51:08.582220
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:51:15.188900
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)

    assert to_code(tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:51:21.556627
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot