

# Generated at 2022-06-18 00:41:20.851962
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:29.478113
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_names
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_assign, ast_name, ast_num, ast_str, ast_arg, ast_arguments, ast_keyword, ast_alias, ast_withitem, ast_with, ast_excepthandler, ast_raise, ast_try, ast_comprehension, ast_listcomp, ast_setcomp, ast_dictcomp, ast_generatorexp, ast_yield, ast_yieldfrom, ast_compare, ast_delete, ast_copy_location, ast_annassign, ast_assert, ast_import, ast_importfrom, ast_global, ast_nonlocal, ast_exec, ast_if

# Generated at 2022-06-18 00:41:39.632537
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.ast_helpers import get_value_from_annassign
    from ..utils.ast_helpers import get_target_from_annassign
    from ..utils.ast_helpers import get_annotation_from_annassign
    from ..utils.ast_helpers import get_type_comment_from_assign
    from ..utils.ast_helpers import get_value_from_assign
    from ..utils.ast_helpers import get_target_from_assign

    # Test for a: int = 10
    tree = get_ast("a: int = 10")
    node = find(tree, ast.AnnAssign)

# Generated at 2022-06-18 00:41:48.357568
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent

    source = dedent('''
    def foo():
        a: int = 10
        b: int
    ''')
    expected_source = dedent('''
    def foo():
        a = 10
    ''')
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, get_ast(expected_source))
    assert generate_code(tree) == expected_source

# Generated at 2022-06-18 00:41:57.754689
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:01.803042
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast

    tree = parse_ast("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == parse_ast("""
    a = 10
    """)

# Generated at 2022-06-18 00:42:08.567125
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse("""
a: int = 10
b: int
""")
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])"

# Generated at 2022-06-18 00:42:13.549912
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    expected_tree = get_ast("""
    a = 10
    """)

    assert compare_trees(VariablesAnnotationsTransformer.transform(tree).tree, expected_tree)

# Generated at 2022-06-18 00:42:23.471053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert tree_to_str(result.tree) == 'a = 10'

    tree = get_ast('a: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert tree_to_str(result.tree) == ''

    tree = get_ast('a: int = 10\nb: int = 20')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert tree_to_str(result.tree) == 'a = 10\nb = 20'

# Generated at 2022-06-18 00:42:33.051576
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_type_name
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue



# Generated at 2022-06-18 00:42:43.218106
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:49.460931
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    source = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(source)
    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:54.217607
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Input:
    #   a: int = 10
    #   b: int
    # Output:
    #   a = 10
    #   b = None
    tree = ast.parse("""
a: int = 10
b: int
""")
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10)), Assign(targets=[Name(id='b', ctx=Store())], value=NameConstant(value=None))])"

    # Test 2:
    # Input:
    #   a: int = 10
    #   b: int
    # Output:
    #   a = 10
    #   b = None

# Generated at 2022-06-18 00:43:04.185341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTrans

# Generated at 2022-06-18 00:43:06.926627
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:12.661499
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:43:20.091720
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree

# Generated at 2022-06-18 00:43:29.224333
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_all_nodes
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast

    source = """
    a: int = 10
    b: int
    """

    tree = get_ast_from_source(source)
    assert get_node_name(tree) == 'Module'
    assert len(get_all_nodes(tree)) == 3

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert get_node_name(result.tree) == 'Module'
    assert len(get_all_nodes(result.tree)) == 2


# Generated at 2022-06-18 00:43:34.001128
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:37.633884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import get_ast_str

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.warnings == []
    assert result.errors == []

    assert get_ast_str(result.tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:46.093643
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    tree = parse_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(result.tree, parse_ast('''
    a = 10
    '''))

# Generated at 2022-06-18 00:43:50.922191
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:59.128546
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:44:03.992156
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_tree

    code = """
    a: int = 10
    b: int
    """
    tree = parse_tree(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:44:10.053316
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []

    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:44:11.492819
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    t = VariablesAnnotationsTransformer()
    assert t.target == (3, 5)


# Generated at 2022-06-18 00:44:18.577839
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:29.079849
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..exceptions import NodeNotFound

    source = source_to_unicode("""
    a: int = 10
    b: int
    """)
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree,
                       source_to_unicode("""
    a = 10
    b: int
    """)
                       )

    source = source_to_unicode("""
    a: int = 10
    b: int
    """)
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree)


# Generated at 2022-06-18 00:44:35.326603
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:44:40.072664
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerV

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    NodeTransformerV().visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:44:56.844537
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code
    from ..utils.source import generate_code

# Generated at 2022-06-18 00:45:07.666231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_names
    from ..utils.tree import find
    from ..utils.context import Context
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:15.395463
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert ast.dump(tree) == '''
    Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None)])
    '''

# Generated at 2022-06-18 00:45:23.985092
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.ast_helpers import get_node_name
    from ..utils.ast_helpers import get_node_type
    from ..utils.ast_helpers import get_node_value
    from ..utils.ast_helpers import get_node_target
    from ..utils.ast_helpers import get_node_annotation
    from ..utils.ast_helpers import get_node_type_comment
    from ..utils.ast_helpers import get_node_body
    from ..utils.ast_helpers import get_node_type_comment
    from ..utils.ast_helpers import get_node_value
    from ..utils.ast_helpers import get_node_target
    from ..utils.ast_helpers import get_node

# Generated at 2022-06-18 00:45:33.667026
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import get_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_comments_and_docstrings

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''

    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert get_code_without_imports(tree) == get_code_without_imports(expected_code)
    assert get_code_without_comments_and_docstrings(tree) == get_code_without_comments_and_docstrings(expected_code)
    assert get_code(tree) == get

# Generated at 2022-06-18 00:45:40.730153
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import compare_asts

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    expected_tree = get_ast("""
    a = 10
    """)

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)

    assert compare_asts(tree, expected_tree)

# Generated at 2022-06-18 00:45:46.452525
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:45:49.563476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert code == compile(tree, '', 'exec')

# Generated at 2022-06-18 00:45:57.572583
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import print_tree
    from ..utils.source import generate_code
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import get_ast_node_at_line
    from ..utils.source import get_ast_node_at_offset
    from ..utils.source import get_line_at_offset
    from ..utils.source import get_offset_at_line
    from ..utils.source import get_line_at_offset
    from ..utils.source import get_offset_at_line
    from ..utils.source import get_line_at_offset
    from ..utils.source import get_offset_at_line
    from ..utils.source import get_line_

# Generated at 2022-06-18 00:46:02.414815
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
        a: int = 10
        b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == "a = 10"

# Generated at 2022-06-18 00:46:27.232009
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''

    tree = parse_ast(code)
    expected_tree = parse_ast(expected_code)

    VariablesAnnotationsTransformer.transform(tree)

    assert_equal_ast(tree, expected_tree)

# Generated at 2022-06-18 00:46:33.640553
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_asts
    from ..utils.source import generate_source

    source = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1
    assert compare_asts(generate_source(tree), 'a = 10')

# Generated at 2022-06-18 00:46:40.865123
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_tree
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''

    tree = get_ast(code)
    print_tree(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    print_tree(new_tree)
    assert compare_ast(new_tree, get_ast(expected_code))
    assert to_code(new_tree) == expected_code

# Generated at 2022-06-18 00:46:50.702290
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)
    assert get_node_by_path(tree, 'body.0').__class__ == ast.Assign
    assert get_node_by_path(tree, 'body.0.targets.0').__class__ == ast.Name
    assert get_node_by_path(tree, 'body.0.targets.0.id') == 'a'
    assert get_node_by_path(tree, 'body.0.value').__class__ == ast.Num
    assert get_node_by

# Generated at 2022-06-18 00:46:55.279340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert str(tree) == "a = 10\n"

# Generated at 2022-06-18 00:47:02.923284
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    expected_tree = ast.parse("""
    a = 10
    """)
    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_tree

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    expected_tree = ast.parse("""
    a = 10
    """)
    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_tree

    # Test 3
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    expected_tree = ast.parse("""
    a = 10
    """)

# Generated at 2022-06-18 00:47:09.843158
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..utils.tree import find
    from ..utils.helpers import warn
    from ..utils.tree import find
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..utils.tree import find
    from ..utils.helpers import warn
    from ..utils.tree import find

# Generated at 2022-06-18 00:47:14.987567
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.source import get_source

    source = get_source(VariablesAnnotationsTransformer)
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    compare_ast(tree, get_ast(source))

# Generated at 2022-06-18 00:47:19.348479
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast

    tree = parse("""
    a: int = 10
    b: int
    """)
    print_ast(tree)
    tree = VariablesAnnotationsTransformer.transform(tree)
    print_ast(tree)
    assert to_code(tree) == "a = 10\n"

# Generated at 2022-06-18 00:47:29.562915
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:19.233362
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .VariablesAnnotationsTransformer import VariablesAnnotationsTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:24.865455
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import find
    from ..utils.ast_helpers import get_node_name

    code = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1
    assert get_node_name(get_node_of_type(tree, ast.Assign)) == 'a'

# Generated at 2022-06-18 00:48:34.002585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import ast_to_str
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_

# Generated at 2022-06-18 00:48:40.049575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from .base import BaseTransformer
    from ..utils.tree import find

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10'
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:48:44.549497
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:48.244060
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = """
    a: int = 10
    b: int
    """
    tree = parse_to_ast(code)
    new_tree, changed = VariablesAnnotationsTransformer.transform(tree)
    assert changed
    assert generate_code(new_tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:48:54.119378
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:48:58.172219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    # When
    actual_code = VariablesAnnotationsTransformer.transform(code)
    # Then
    assert actual_code == expected_code

# Generated at 2022-06-18 00:49:02.479079
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast

    code = """
    a: int = 10
    b: int
    """

    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(tree).strip() == """
    a = 10
    """

# Generated at 2022-06-18 00:49:06.304279
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == "a = 10\n"

# Generated at 2022-06-18 00:50:57.110421
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:51:00.667141
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:51:10.112338
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_imports
    from ..utils.helpers import get_code_without_docstrings
    from ..utils.helpers import get_code_without_docstrings_and_imports
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_docstring
    from ..utils.helpers import get_docstring_without_imports
    from ..utils.helpers import get_docstring_without_

# Generated at 2022-06-18 00:51:19.580688
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_ctx
    from ..utils.helpers import get_ast_node_body
    from ..utils.helpers import get_ast_node_orelse