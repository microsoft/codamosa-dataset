

# Generated at 2022-06-18 00:41:28.658807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == ''

    tree = get_ast('a: int = 10\nb: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:41:34.451595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:41:45.455576
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.helpers import get_node_name

# Generated at 2022-06-18 00:41:54.870128
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:59.734263
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    dump(tree)
    result = VariablesAnnotationsTransformer.transform(tree)
    dump(result.tree)
    assert result.tree_changed
    assert len(result.messages) == 0

# Generated at 2022-06-18 00:42:02.870592
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_string
    from ..utils.tree import to_string

    tree = parse_string('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_string(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:10.892911
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to

# Generated at 2022-06-18 00:42:14.127519
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:24.237283
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import compare_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_indentation
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_indentation_and_new_lines
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_indentation_and

# Generated at 2022-06-18 00:42:29.299122
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast

    tree = parse('''
    a: int = 10
    b: int
    ''')

    print_ast(tree)
    print(to_code(tree))
    print(VariablesAnnotationsTransformer.transform(tree))

# Generated at 2022-06-18 00:42:34.656440
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)
    assert dump(tree) == '''
    Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])
    '''

# Generated at 2022-06-18 00:42:42.872685
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1:
    # Input:
    # a: int = 10
    # b: int
    # Output:
    # a = 10
    # b: int
    tree = ast.parse("a: int = 10\nb: int")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].annotation.id == 'int'

    # Test case 2:
    # Input:
    # a: int = 10
    # b: int = 20
    # Output:
    # a = 10
    # b = 20
    tree = ast.parse("a: int = 10\nb: int = 20")

# Generated at 2022-06-18 00:42:51.564632
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import generate_code_from_ast
    from ..utils.source import dedent_source


# Generated at 2022-06-18 00:43:01.210707
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_asts

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    print_ast(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    print_ast(new_tree)

    assert compare_asts(new_tree, get_ast('''
        a = 10
    '''))

    assert to_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:43:10.999067
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node
    from ..utils.tree import find
    from ..utils.compat import Literal
    from ..utils.source import source_to_unicode
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..types import TransformationResult
    import astor

    # Test 1:
    # a: int = 10
    # b: int
    # To:
    # a = 10
    # b: int
    source = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(source)
    tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:43:16.821908
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(new_tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:19.941664
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:43:25.018108
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert tree.body[0].value.value == 10
    assert tree.body[1].value is None

# Generated at 2022-06-18 00:43:35.135470
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:43:42.586676
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)

    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:52.421753
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    VariablesAnnotationsTransformer.transform(tree)

    assert tree.body[0].__class__.__name__ == 'Assign'
    assert tree.body[1].__class__.__name__ == 'Expr'

# Generated at 2022-06-18 00:43:59.610935
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:05.416361
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_ast_node

    source = """
    a: int = 10
    b: int
    """
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_source_from_ast(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:44:12.518034
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_code

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    transformer = VariablesAnnotationsTransformer()

    # Act
    result = transformer.transform(tree)

    # Assert
    assert get_code(result.tree) == expected_code

# Generated at 2022-06-18 00:44:19.141109
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:24.932737
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:35.062815
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_type_by_path
    from ..utils.tree import get_node_value_by_path
    from ..utils.tree import get_node_lineno_by_path
    from ..utils.tree import get_node_col_offset_by_path
    from ..utils.tree import get_node_end_lineno_by_path
    from ..utils.tree import get_node_end_col_offset_by_path
    from ..utils.tree import get_node_parent_by_path
    from ..utils.tree import get_node_parent_type_by_path
    from ..utils.tree import get_node_parent_value_by_path

# Generated at 2022-06-18 00:44:42.520053
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..utils.compare import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..utils.compare import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.tree import get_non_exp_parent

# Generated at 2022-06-18 00:44:50.054180
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            self.generic_visit(node)

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10'
    assert Visitor().visit(tree) is None

# Generated at 2022-06-18 00:44:57.204785
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_type
    from ..utils.tree import find
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from .base import BaseTransformer

    tree = ast.parse("""
a: int = 10
b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed == True
    assert result.new_nodes == []
    assert get_node_type(result.tree) == ast.Module
    assert len(result.tree.body) == 2
    assert get_node_type(result.tree.body[0]) == ast.Assign
    assert get_node_type(result.tree.body[1]) == ast.Assign
    assert get_node

# Generated at 2022-06-18 00:45:15.865419
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:24.198796
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_parent_index
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:45:28.230781
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
a: int = 10
b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == """
a = 10
    """

# Generated at 2022-06-18 00:45:36.241391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:42.214342
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_str

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_str(result.tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:45:47.950235
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_asts

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    VariablesAnnotationsTransformer.transform(tree)

    assert compare_asts(tree, get_ast("""
    a = 10
    """))

# Generated at 2022-06-18 00:45:53.688727
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import get_ast
    from ..utils.source import get_source

    source = get_source(VariablesAnnotationsTransformer)
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)

    expected = get_ast('''
    def foo(a: int, b: int):
        a = 10
        b = 20
    ''')

    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:45:56.690992
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree

    tree = get_ast('a: int = 10')
    print_tree(tree)
    print_tree(VariablesAnnotationsTransformer.transform(tree).tree)


# Generated at 2022-06-18 00:46:03.133625
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # a: int = 10
    # b: int
    # To:
    # a = 10
    # b = None
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    expected_tree = ast.parse("""
    a = 10
    b = None
    """)
    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_tree

    # Test 2:
    # a: int = 10
    # b: int = 20
    # To:
    # a = 10
    # b = 20
    tree = ast.parse("""
    a: int = 10
    b: int = 20
    """)
    expected_tree = ast.parse("""
    a = 10
    b = 20
    """)

# Generated at 2022-06-18 00:46:08.654875
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import compare_ast
    from ..utils.ast_builder import build_ast

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''

    tree = build_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(new_tree.tree, expected_code)

# Generated at 2022-06-18 00:46:31.785907
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.tree import compare_ast

    code = """
a: int = 10
b: int
    """
    expected_code = """
a = 10
    """
    expected_ast = get_ast(expected_code)
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(result.new_tree, expected_ast)
    assert get_code(result.new_tree) == expected_code

# Generated at 2022-06-18 00:46:40.865809
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.helpers import parse_code_to_ast

# Generated at 2022-06-18 00:46:47.131226
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''

    tree = get_ast(code)
    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:46:57.447042
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_type
    from ..utils.ast_helpers import get_ast_node_value
    from ..utils.ast_helpers import get_ast_node_lineno
    from ..utils.ast_helpers import get_ast_node_col_offset
    from ..utils.ast_helpers import get_ast_node_end_lineno
    from ..utils.ast_helpers import get_ast_node_end_col_offset
    from ..utils.ast_helpers import get_ast_node_children
    from ..utils.ast_helpers import get_ast_node_parent

# Generated at 2022-06-18 00:47:05.905256
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index

    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:47:11.638066
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    tree = ast.parse("""
a: int = 10
b: int
""")
    expected_tree = ast.parse("""
a = 10
""")

    # Act
    actual_tree = VariablesAnnotationsTransformer.transform(tree)

    # Assert
    assert ast.dump(actual_tree.tree) == ast.dump(expected_tree)

# Generated at 2022-06-18 00:47:15.817100
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_tree

    tree = get_tree('''
    a: int = 10
    b: int
    ''')
    print_tree(tree)
    tree = VariablesAnnotationsTransformer.transform(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:47:22.460671
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:47:27.877205
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_asts
    from ..utils.source import generate_source

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert generate_source(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:47:33.472527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.compare import compare_asts

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = get_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_asts(to_code(new_tree), expected)

# Generated at 2022-06-18 00:48:14.324747
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import get_ast


# Generated at 2022-06-18 00:48:22.325781
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:30.773041
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor
    from ..types import TransformationResult

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            self.generic_visit(node)
            return node

    tree = parse("""
        a: int = 10
        b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert to_code(result.tree) == """
        a = 10
    """
    visitor = Visitor()
    visitor.visit(result.tree)
    assert visitor.result is None

# Generated at 2022-06-18 00:48:40.685412
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_lineno_col_offset
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:43.771819
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_src(tree.tree) == 'a = 10'

# Generated at 2022-06-18 00:48:50.556921
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_type
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:59.276667
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:07.847862
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:49:11.394309
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.__name__ == 'VariablesAnnotationsTransformer'
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.transform.__name__ == 'transform'


# Generated at 2022-06-18 00:49:18.167759
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_node_type

    tree = parse_to_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert generate_code(tree) == 'a = 10\n'

    tree = parse_to_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert generate_code(tree) == 'a = 10\n'


# Generated at 2022-06-18 00:51:09.472197
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor

    tree = get_ast('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert find(tree, ast.AnnAssign) == []
    assert find(tree, ast.Assign) != []
    assert find(tree, ast.Assign)[0].targets[0].id == 'a'
    assert find(tree, ast.Assign)[0].value.n == 10
    assert find(tree, ast.Assign)[0].type_comment == 'int'

# Generated at 2022-06-18 00:51:19.504963
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    import astunparse
    import sys
    import io
    import unittest

    class TestVariablesAnnotationsTransformer(unittest.TestCase):
        """Test class for VariablesAnnotationsTransformer"""

        def test_transform(self):
            """Test method transform"""
            tree = get_ast('''
            a: int = 10
            b: int
            ''')
            tree_changed = False
