

# Generated at 2022-06-18 00:41:23.017596
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')) == TransformationResult(ast.parse('a = 10'), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int')) == TransformationResult(ast.parse(''), True, [])

# Generated at 2022-06-18 00:41:26.520022
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    expected_tree = ast.parse("""
a = 10
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-18 00:41:33.659043
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            raise Exception('AnnAssign node found')

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)
    TestVisitor().visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:41:45.455361
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_annotation
    from ..utils.tree import get_node_body
    from ..utils.tree import get_node_body_length
    from ..utils.tree import get_node_body_item
    from ..utils.tree import get_node_body_item_name
    from ..utils.tree import get_node_body_item_type
    from ..utils.tree import get_node_body_item

# Generated at 2022-06-18 00:41:49.654642
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse("""
a: int = 10
b: int
""")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree == ast.parse("""
a = 10
""")

# Generated at 2022-06-18 00:41:55.064774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(new_tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:42:00.181401
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''

    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:02.891501
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree == ast.parse('a = 10')

# Generated at 2022-06-18 00:42:10.893675
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:12.022308
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast


# Generated at 2022-06-18 00:42:21.892733
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import get_source

    source = get_source(VariablesAnnotationsTransformer)
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert not find(tree, ast.AnnAssign)
    assert compare_ast(tree, get_ast('''
    def f(a: int = 10, b: int):
        pass
    '''))

# Generated at 2022-06-18 00:42:24.903491
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True


# Generated at 2022-06-18 00:42:31.209884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    tree = parse("""
    a: int = 10
    b: int
    """)

    expected_tree = parse("""
    a = 10
    """)

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(ast_to_str(new_tree.tree), ast_to_str(expected_tree))

# Generated at 2022-06-18 00:42:40.566656
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
   

# Generated at 2022-06-18 00:42:45.092577
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int = 10',
                          'a = 10')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int',
                          '')

# Generated at 2022-06-18 00:42:50.511135
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    source = '''
    a: int = 10
    b: int
    '''
    tree = parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:42:57.958765
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_code(code) == get_code_from_ast(tree)

# Generated at 2022-06-18 00:43:07.513777
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:12.554564
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10\n"

# Generated at 2022-06-18 00:43:20.044534
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:28.619110
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    expected = get_ast('''
    a = 10
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert compare_trees(result.tree, expected)

# Generated at 2022-06-18 00:43:37.024723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert find_all(new_tree.tree, ast.AnnAssign) == []
    assert find_all(new_tree.tree, ast.Assign) == [
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                   value=ast.Num(n=10),
                   type_comment=ast.Name(id='int', ctx=ast.Load()))
    ]

# Generated at 2022-06-18 00:43:39.036810
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for the constructor of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:43:47.924161
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:57.066726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_tree
    from ..utils.helpers import get_tree_from_code
    from ..utils.helpers import get_tree_from_ast
    from ..utils.helpers import get_ast_from_tree
    from ..utils.helpers import get_code_from_tree
    from ..utils.helpers import get_tree_from_code
    from ..utils.helpers import get_ast_from_tree
    from ..utils.helpers import get_tree_from_ast

# Generated at 2022-06-18 00:44:03.427397
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:44:08.881972
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_str

    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_str(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:44:16.251093
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:27.109237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_target
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_annotation
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_body
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type_comment

# Generated at 2022-06-18 00:44:34.294632
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)

    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 1
    assert astor.to_source(tree).strip() == 'a = 10'

# Generated at 2022-06-18 00:44:48.526400
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
a: int = 10
b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:51.924513
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree == parse('''
    a = 10
    ''')

# Generated at 2022-06-18 00:45:01.241913
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:11.834603
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:18.026161
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.errors == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:45:22.761183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.ast_builder import build_ast

    tree = build_ast("""
    a: int = 10
    b: int
    """)

    expected_tree = build_ast("""
    a = 10
    """)

    VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(tree, expected_tree)

# Generated at 2022-06-18 00:45:31.814130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed is True
    assert len(result.errors) == 0

    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1

    assert compare_ast(result.tree, get_ast('''
    a = 10
    ''')) is True


# Generated at 2022-06-18 00:45:38.425284
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source

# Generated at 2022-06-18 00:45:44.892345
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''
    tree = parse_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(result.tree, expected)

# Generated at 2022-06-18 00:45:47.833785
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast_from_text
    from ..utils.tree import compare_ast


# Generated at 2022-06-18 00:46:09.050666
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    ast_tree = get_ast('a: int = 10')
    trans = VariablesAnnotationsTransformer()
    result = trans.transform(ast_tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:46:17.392223
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.new_code == """
    a = 10
    """
    assert result.warnings == []
    assert result.errors == []


# Generated at 2022-06-18 00:46:21.710538
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast
    from ..utils.visitor import print_ast

    code = '''
    a: int = 10
    b: int
    '''

    tree = parse_ast(code)
    print_ast(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    print_ast(new_tree.tree)
    assert generate_code(new_tree.tree) == 'a = 10\n'

# Generated at 2022-06-18 00:46:27.096332
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:46:34.003981
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_trees

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_code_to_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert compare_trees(new_tree, parse_code_to_ast('a = 10'))
    assert generate_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:46:41.629373
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:46:48.968873
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == ''

# Generated at 2022-06-18 00:46:57.117183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    code = """
        a: int = 10
        b: int
    """
    expected_code = """
        a = 10
    """

    tree = get_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert compare_ast(new_tree, get_ast(expected_code))
    assert to_code(new_tree) == expected_code

# Generated at 2022-06-18 00:47:01.122036
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    expected = get_ast('''
        a = 10
    ''')

    assert VariablesAnnotationsTransformer.transform(tree).tree == expected

# Generated at 2022-06-18 00:47:08.401842
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from ..transformers.base import BaseTransformer
    from ..transformers.variables_annotations import VariablesAnnotationsTransformer
    from typed_ast import ast3 as ast
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue
        tree_changed = True
        parent

# Generated at 2022-06-18 00:47:51.639620
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:47:58.085644
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_target
    from ..utils.tree import get_node_annotation
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_type_comment

    # Test 1: Test for the constructor of class VariablesAnnotationsTransformer
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed = False

# Generated at 2022-06-18 00:48:01.390342
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
        a: int = 10
        b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree.tree) == """
        a = 10
    """

# Generated at 2022-06-18 00:48:12.490933
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:20.912307
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_names
    from ..utils.tree import get_node_by_name
    from ..utils.tree import get_node_names_by_type
    from ..utils.tree import get_node_names_by_type_and_value
    from ..utils.tree import get_node_names_by_value
    from ..utils.tree import get_node_names_by_value_and_type
    from ..utils.tree import get_node_names_by_value_and_type_and_parent
    from ..utils.tree import get_node_names_by_value_and_type_and_parent_and_index
    from ..utils.tree import get_node_names_by_value_and_type_and_parent_and_index_

# Generated at 2022-06-18 00:48:26.457172
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:36.228177
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import ast_to_str
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_

# Generated at 2022-06-18 00:48:45.382726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:54.494568
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_children
    from ..utils.helpers import get_node_child_count
    from ..utils.helpers import get_node_child_index
    from ..utils.helpers import get

# Generated at 2022-06-18 00:48:57.719614
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import ast_to_str
    from ..utils.helpers import get_ast_from_source
    from ..utils.helpers import get_source_from_ast


# Generated at 2022-06-18 00:50:46.741832
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:50:53.414744
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import print_ast

    code = """
a: int = 10
b: int
    """
    tree = get_ast(code)
    print_ast(tree)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    print_ast(tree)
    assert to_code(tree) == """
a = 10
    """

# Generated at 2022-06-18 00:51:01.995062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:51:05.705437
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import compare_ast


# Generated at 2022-06-18 00:51:14.462143
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    tree = parse_ast(get_source(VariablesAnnotationsTransformer))
    assert isinstance(tree, ast.Module)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result, TransformationResult)

    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 2
    assert len(find(result.tree, ast.Name)) == 4
    assert len(find(result.tree, ast.NameConstant)) == 2

# Generated at 2022-06-18 00:51:18.792035
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import get_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(result.tree) == 'a = 10'