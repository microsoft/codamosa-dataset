

# Generated at 2022-06-18 00:41:16.681751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(ast.parse("""
a = 10
    """), True, [])

# Generated at 2022-06-18 00:41:23.526814
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_node
    from ..utils.source import source_to_code
    from ..utils.source import source_to_astor
    from ..utils.source import source_to_asttokens
    from ..utils.source import source_to_token_list
    from ..utils.source import source_to_ast_str
    from ..utils.source import source_to_ast_repr
    from ..utils.source import source_to_ast_pretty
    from ..utils.source import source_to_ast_pretty_repr
   

# Generated at 2022-06-18 00:41:27.634282
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:41:37.423079
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to

# Generated at 2022-06-18 00:41:47.871564
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Input:
    # a: int = 10
    # b: int
    # Output:
    # a = 10
    # b = None
    tree = ast.parse("a: int = 10\nb: int")
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

    # Test 2:
    # Input:
    # a: int = 10
    # b: int
    # Output:
    # a = 10
    # b = None
    tree = ast.parse("a: int = 10\nb: int")
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)

# Generated at 2022-06-18 00:41:55.210800
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast("""
a: int = 10
b: int
    """)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.changed
    assert len(find(tree_changed.tree, ast.AnnAssign)) == 0
    assert len(find(tree_changed.tree, ast.Assign)) == 2
    assert compare_ast(tree_changed.tree, """
a = 10
b = None
    """)

# Generated at 2022-06-18 00:41:58.530889
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(
        parse("""
        a = 10
        """), True, [])

# Generated at 2022-06-18 00:42:06.877123
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    tree = ast.parse("""
    a: int = 10
    b: int
    """)

    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:42:16.777521
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.tree import find
    from ..utils.tree import find_all
    from ..utils.tree import find_parent
    from ..utils.tree import find_parents
    from ..utils.tree import find_all_parents
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..utils.tree import remove_at
    from ..utils.tree import replace_at
    from ..utils.tree import get_parent
    from ..utils.tree import get_parents
    from ..utils.tree import get_all_parents
    from ..utils.tree import get_non_

# Generated at 2022-06-18 00:42:21.352551
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)

    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:33.333029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Input:
    # a: int = 10
    # b: int
    # Output:
    # a = 10
    tree = ast.parse("a: int = 10\nb: int")
    expected_tree = ast.parse("a = 10")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(expected_tree)
    assert result.tree_changed == True
    assert result.warnings == []

    # Test 2:
    # Input:
    # a: int = 10
    # b: int
    # Output:
    # a = 10
    tree = ast.parse("a: int = 10\nb: int")
    expected_tree = ast.parse("a = 10")
    result = VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:42:37.786831
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_type, get_node_value
    from ..utils.tree import get_node_type_and_value
    from ..utils.tree import get_node_type_and_value_by_index
    from ..utils.tree import get_node_type_and_value_by_index_and_key
    from ..utils.tree import get_node_type_and_value_by_key

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed == True
    assert get_node_type(result.tree, 0) == 'Assign'

# Generated at 2022-06-18 00:42:40.453568
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast


# Generated at 2022-06-18 00:42:51.092622
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_types
    from ..utils.tree import find
    from ..types import TransformationResult
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.AnnAssign):
                try:
                    parent, index = get_non_exp_parent_and_index(tree, node)
                except NodeNotFound:
                    warn('Assignment outside of body')
                    continue

                tree_changed

# Generated at 2022-06-18 00:43:02.631494
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:13.235128
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_names
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_imports
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_imports_and_blank_lines
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_imports_and_blank_lines_and_indentation
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_imports_and_

# Generated at 2022-06-18 00:43:17.448536
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = """
a: int = 10
b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(ast.parse("""
a = 10
    """), tree)

# Generated at 2022-06-18 00:43:24.791602
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:43:29.337064
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast('''
        a = 10
    '''))

    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:43:31.571839
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == "a = 10"

# Generated at 2022-06-18 00:43:42.343147
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:43:49.227604
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

# Generated at 2022-06-18 00:43:54.882733
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:58.835362
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
a: int = 10
b: int
'''
    expected_code = '''
a = 10
'''

    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, get_ast(expected_code))

# Generated at 2022-06-18 00:44:05.218523
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''

    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(to_code(new_tree), expected_code)

# Generated at 2022-06-18 00:44:10.442538
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:15.405685
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.tree import get_ast_str

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    expected_tree = get_ast(expected_code)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:44:26.009263
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:29.776158
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    expected_tree = ast.parse("""
a = 10
""")
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-18 00:44:33.311808
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('''
a: int = 10
b: int
    ''')) == TransformationResult(ast.parse('''
a = 10
    '''), True, [])

# Generated at 2022-06-18 00:44:47.501901
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:53.508937
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find

    tree = parse_ast("""
    a: int = 10
    b: int
    """)

    assert len(find(tree, ast.AnnAssign)) == 2

    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert len(find(new_tree.tree, ast.AnnAssign)) == 0
    assert len(find(new_tree.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:45:02.357982
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast
    from ..utils.source import Source
    from ..utils.helpers import get_ast_diff

    source = Source("""
    a: int = 10
    b: int
    """)

    tree = parse_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert generate_code(new_tree) == "a = 10\n"

    # Test that the transformer is idempotent
    new_tree_2 = VariablesAnnotationsTransformer.transform(new_tree).tree
    assert get_ast_diff(new_tree, new_tree_2) == []

# Generated at 2022-06-18 00:45:12.950146
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    dump(tree)
    print(get_code(tree))
    print(get_code_from_ast(tree))
    print(get_ast_from_code(code))
    print(get_code_from_ast(get_ast_from_code(code)))
    print(get_ast_from_code(get_code_from_ast(tree)))

# Generated at 2022-06-18 00:45:22.972147
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    class DummyTransformer(BaseTransformer):
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    assert isinstance(VariablesAnnotationsTransformer, type)
    assert isinstance(VariablesAnnotationsTransformer.transform, classmethod)
    assert isinstance

# Generated at 2022-06-18 00:45:31.848960
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_ast_from_code_and_back
    from ..utils.helpers import get_code_and_back_from_ast
    from ..utils.helpers import get_code_and_back_from_code
    from ..utils.helpers import get_ast_and_back_from_code
    from ..utils.helpers import get_ast_and_back_from_ast

    code = '''
a: int = 10
b: int
    '''
    ast_tree = get_ast(code)

# Generated at 2022-06-18 00:45:38.425368
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from ..transformers.base import BaseTransformer
    from ..transformers.variables_annotations import VariablesAnnotationsTransformer
    from typed_ast import ast3 as ast
    tree = get_ast('a: int = 10')
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue
        tree_changed = True
        parent.body.pop(index)  # type:

# Generated at 2022-06-18 00:45:48.298832
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:45:56.570628
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_children
    from ..utils.helpers import get_node_siblings
    from ..utils.helpers import get_node_previous_sibling

# Generated at 2022-06-18 00:46:03.168357
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = """
    a: int = 10
    b: int
    """

    expected_code = """
    a = 10
    """

    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast(expected_code))
    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:46:27.868216
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree_changed == True
    assert tree_changed.nodes_changed == []
    assert len(find(tree_changed.tree, ast.AnnAssign)) == 0
    assert len(find(tree_changed.tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:46:32.171372
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert str(tree) == '''
        a = 10
    '''

# Generated at 2022-06-18 00:46:41.053609
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:50.878892
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:57.347945
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:47:03.987223
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:10.573540
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:19.228477
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code_from_node
    from ..utils.source import get_source_code_from_node_list
    from ..utils.source import get_source_code_from_node_list_list
    from ..utils.source import get_source_code_from_node_list_list_list
    from ..utils.source import get_source_code_from_node_list_list_list_list
    from ..utils.source import get_source_code_from_node_list_list_list_list_list
    from ..utils.source import get_

# Generated at 2022-06-18 00:47:29.418844
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_ast_node_name
    from ..utils.tree import get_ast_node_type
    from ..utils.tree import get_ast_node_type_name
    from ..utils.tree import get_ast_node_value
    from ..utils.tree import get_ast_node_lineno
    from ..utils.tree import get_ast_node_col_offset
    from ..utils.tree import get_ast_node_end_lineno
    from ..utils.tree import get_ast_node_end_col_offset
    from ..utils.tree import get_ast_node_body
    from ..utils.tree import get_ast_node_orelse
    from ..utils.tree import get_ast_node_type_comment

# Generated at 2022-06-18 00:47:37.521168
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            print(node.target.id)
            print(node.annotation.id)
            print(node.value.n)

    class TestTransformer(NodeTransformerVisitor):
        def visit_AnnAssign(self, node):
            node.annotation = ast.Name(id='str', ctx=ast.Load())
            return node

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:48:23.809711
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import assert_equal_ast

    tree = ast.parse("""
a: int = 10
b: int
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(get_node_by_path(tree, 'body.0'),
                     ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                value=ast.Num(n=10),
                                type_comment=ast.Name(id='int', ctx=ast.Load())))

# Generated at 2022-06-18 00:48:31.297644
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_node_at_line
    from ..utils.tree import get_node_line_number

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == """
    a = 10
    """
    assert get_node_line_number(get_ast_node_at_line(tree, 2)) == 2

# Generated at 2022-06-18 00:48:40.968376
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:45.445494
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:48:50.817268
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    class Visitor(NodeVisitor):
        def visit_Assign(self, node):
            assert node.targets[0].id == 'a'
            assert node.value.n == 10
            assert node.type_comment == 'int'

    Visitor().visit(tree)

    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:59.397630
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    assert to_code(tree) == '''
    a: int = 10
    b: int
    '''

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == '''
    a = 10
    '''

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == '''
    a = 10
    '''


# Generated at 2022-06-18 00:49:07.900278
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert to_code(result.tree) == 'a = 10'

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert to_code(result.tree) == 'a = 10'


# Generated at 2022-06-18 00:49:14.312974
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree.body[0].value.n == 10
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[0].type_comment == 'int'
    assert result.tree.body[1].value is None
    assert result.tree.body[1].targets[0].id == 'b'
    assert result.tree.body[1].type_comment == 'int'

# Generated at 2022-06-18 00:49:16.801872
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Expr)

# Generated at 2022-06-18 00:49:26.255260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_children
    from ..utils.helpers import get_ast_node_child_count

# Generated at 2022-06-18 00:51:14.153703
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_imports
    from ..utils.helpers import get_ast_without_imports
    from ..utils.helpers import get_ast_without_comments_and_docstrings
    from ..utils.helpers import get_ast_without_comments_and_docstrings_and_imports
    from ..utils.helpers import get_ast_without_comments_and_docstrings_and_imports_and_blank_lines