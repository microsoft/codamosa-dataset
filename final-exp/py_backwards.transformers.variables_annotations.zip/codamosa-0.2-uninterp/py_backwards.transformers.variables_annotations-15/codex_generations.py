

# Generated at 2022-06-18 00:41:25.745637
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:41:32.761872
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..utils.helpers import warn
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..utils.helpers import warn
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult

# Generated at 2022-06-18 00:41:42.432871
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_indentation
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_indentation_and_new_lines
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_indentation_and_new_lines_and_spaces

# Generated at 2022-06-18 00:41:48.703678
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""
    a: int = 10
    b: int
    """)
    expected_ast = parse_ast(source)
    actual_ast = VariablesAnnotationsTransformer.transform(parse_ast(source))
    assert_equal_ast(expected_ast, actual_ast)

# Generated at 2022-06-18 00:41:57.918661
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:02.841579
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_target
    from ..utils.helpers import get_node_annotation
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_body
    from ..utils.helpers import get_node_body_length
    from ..utils.helpers import get_node_body_index
    from ..utils.helpers import get_node_body_item
    from ..utils.helpers import get_node_body_item_type
    from ..utils.helpers import get_node_

# Generated at 2022-06-18 00:42:10.863237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import TransformationError

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    transformer = VariablesAnnotationsTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)

    assert to_code(tree) == 'a = 10'

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    transformer = VariablesAnnotationsTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)

    assert to_code(tree) == 'a = 10'


# Generated at 2022-06-18 00:42:15.014427
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.tree import find_all

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    assert len(find_all(tree, ast.AnnAssign)) == 2

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:42:18.916202
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:28.882167
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from ..utils.helpers import get_ast
    import astunparse
    import astor
    import sys
    import os
    import io
    import contextlib
    import unittest

    class TestVariablesAnnotationsTransformer(unittest.TestCase):
        """Test class for VariablesAnnotationsTransformer"""

        def test_transform(self):
            """Test method transform"""

# Generated at 2022-06-18 00:42:40.416892
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Test case:
    # a: int = 10
    # b: int
    #
    # Expected output:
    # a = 10
    #
    # Actual output:
    # a = 10
    test_code_1 = '''
a: int = 10
b: int
'''
    expected_output_1 = '''
a = 10
'''
    tree_1 = ast.parse(test_code_1)
    result_1 = VariablesAnnotationsTransformer.transform(tree_1)
    assert ast.unparse(result_1.tree) == expected_output_1

    # Test 2:
    # Test case:
    # a: int = 10
    # b: int
    #
    # Expected output:
    # a = 10
    #
    #

# Generated at 2022-06-18 00:42:51.093138
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:43:02.640227
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports_and_formatting
    from ..utils.helpers import get_code_without_formatting
    from ..utils.helpers import get_code_without_comments_and_formatting
    from ..utils.helpers import get_code_without_comments_imports_and_formatting
    from ..utils.helpers import get_code_without_comments_imports_and_formatting_and_newlines
    from ..utils.helpers import get_code_without_comments_imports_and_newlines
    from ..utils.helpers import get_code_without_comments_formatting_and_newlines

# Generated at 2022-06-18 00:43:13.236580
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:17.033931
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10\nb: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\nb'

# Generated at 2022-06-18 00:43:25.764031
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast
    from ..utils.source import Source
    from ..utils.helpers import get_ast_diff

    source = Source('''
a: int = 10
b: int
    ''')
    tree = parse_to_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(new_tree.tree) == 'a = 10\n'
    assert get_ast_diff(tree, new_tree.tree) == []

# Generated at 2022-06-18 00:43:31.539720
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(new_tree.tree) == 'a = 10'

# Generated at 2022-06-18 00:43:37.576341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for transform method
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed, _ = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])"

# Generated at 2022-06-18 00:43:46.793215
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert tree.body[0].__class__ == ast.Assign
    assert tree.body[0].targets[0].__class__ == ast.Name
    assert tree.body[0].targets[0].id == 'a'
    assert tree.body[0].value.__class__ == ast.Num
    assert tree.body[0].value.n == 10
    assert tree.body[0].type_comment == 'int'

    assert tree.body[1].__class__ == ast.Assign
    assert tree.body[1].targets[0].__class__ == ast.Name

# Generated at 2022-06-18 00:43:52.464944
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:06.703106
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:15.462340
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:26.047971
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_types
    from ..utils.tree import find
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.context import Context
    from ..exceptions import TransformationError
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    class TestTransformer(BaseTransformer):
        def visit_AnnAssign(self, node):
            return ast.Assign(targets=[node.target], value=node.value, type_comment=node.annotation)


# Generated at 2022-06-18 00:44:36.125166
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:44:43.173741
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:52.958450
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import warn
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import warn
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import warn
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at

# Generated at 2022-06-18 00:44:54.448855
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-18 00:45:04.792942
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import find
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer


# Generated at 2022-06-18 00:45:11.275408
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import get_node_name

    code = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_node_name(get_node_of_type(tree, ast.AnnAssign)) == 'AnnAssign'

# Generated at 2022-06-18 00:45:16.796992
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast

    code = """
    a: int = 10
    b: int
    """
    tree = parse(code)
    print_ast(tree)
    result = VariablesAnnotationsTransformer.transform(tree)
    print_ast(result.tree)
    assert to_code(result.tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:33.780925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = """
    a: int = 10
    b: int
    """
    tree = ast.parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.errors == []
    assert ast.dump(result.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])"

# Generated at 2022-06-18 00:45:39.356009
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast

    tree = get_ast('a: int = 10')
    print_ast(tree)
    print(to_code(tree))
    VariablesAnnotationsTransformer.transform(tree)
    print_ast(tree)
    print(to_code(tree))

# Generated at 2022-06-18 00:45:48.932908
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:53.016569
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree_changed == True
    assert tree_changed.tree == get_ast("""
    a = 10
    """)

# Generated at 2022-06-18 00:45:58.193400
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast
    from ..utils.compare import compare_ast

    code = '''
a: int = 10
b: int
'''
    expected_code = '''
a = 10
'''

    tree = parse_code_to_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree
    generated_code = generate_code(new_tree)

    assert compare_ast(expected_code, generated_code)

# Generated at 2022-06-18 00:46:04.906013
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    expected_code = """
    a = 10
    """
    expected_tree = get_ast(expected_code)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:46:15.613670
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:21.482871
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_node_names
    from ..utils.helpers import get_node_types

    test_code = '''
    a: int = 10
    b: int
    '''

    tree = get_ast(test_code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert get_node_names(result.tree) == ['Assign']
    assert get_node_types(result.tree) == ['Assign']

# Generated at 2022-06-18 00:46:30.270991
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_children
    from ..utils.helpers import get_ast_node_attr
    from ..utils.helpers import get

# Generated at 2022-06-18 00:46:36.359541
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    tree = parse_to_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:47:02.726489
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import visit_all_nodes
    from ..utils.visitor import visit_all_nodes_with_type
    from ..utils.visitor import visit_all_nodes_with_types
    from ..utils.visitor import visit_all_nodes_with_types_and_attrs
    from ..utils.visitor import visit_all_nodes_with_types_and_attrs_and_values
    from ..utils.visitor import visit_all_nodes_with_types_and_values
    from ..utils.visitor import visit_all_nodes_with_types_or_attrs
    from ..utils.visitor import visit_all_nodes

# Generated at 2022-06-18 00:47:09.745599
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:19.218940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_lineno_col_offset
    from ..utils.tree import find
    from ..utils.ast_compare import compare_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_ast_from_source
    from ..utils.source import get_ast_from_source_tree
    from ..utils.source import get_source_from_source_tree
    from ..utils.source import get_source_from_source_tree_and_ast
    from ..utils.source import get_source_from_source_tree_and_ast_and_source
    from ..utils.source import get_source_tree_from_source
    from ..utils.source import get

# Generated at 2022-06-18 00:47:24.912556
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:47:34.360321
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_non_exp_parent_and_index

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:47:42.606593
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int = 10',
                          'a = 10')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int\nb: int = 10',
                          'a\nb = 10')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int = 10\nb: int',
                          'a = 10\nb')
    assert_transformation(VariablesAnnotationsTransformer,
                          'a: int\nb: int',
                          'a\nb')

# Generated at 2022-06-18 00:47:53.076449
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_asts
    from ..utils.source import generate_source

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree_changed
    assert len(tree_changed.errors) == 0

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree_changed
    assert len(tree_changed.errors) == 0


# Generated at 2022-06-18 00:47:59.792030
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_lineno
    from ..utils.tree import get_node_col_offset
    from ..utils.tree import get_node_end_lineno
    from ..utils.tree import get_node_end_col_offset
    from ..utils.tree import get_node_parent
    from ..utils.tree import get_node_children
    from ..utils.tree import get_node_attr
    from ..utils.tree import get_node_attributes
    from ..utils.tree import get_node_attribute_names
    from ..utils.tree import get_node_attribute_values

# Generated at 2022-06-18 00:48:07.326698
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:48:12.531010
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = '''
    a: int = 10
    b: int
    '''

    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree.body[0].value.n == 10
    assert tree.body[1].value is None

# Generated at 2022-06-18 00:48:56.944788
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source('a: int = 10')
    tree = get_ast(source)
    assert len(find(tree, ast.AnnAssign)) == 1

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert get_source_from_ast(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:49:07.076901
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code

# Generated at 2022-06-18 00:49:14.940083
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:17.803052
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            raise Exception('AnnAssign should not be present')

    tree = parse('a: int = 10')
    VariablesAnnotationsTransformer.transform(tree)
    Visitor().visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:49:28.014677
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..types import TransformationResult

    class TestTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:32.762001
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree == parse('''
    a = 10
    ''')

# Generated at 2022-06-18 00:49:38.656869
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import TransformationError

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    assert to_code(tree) == 'a: int = 10\nb: int\n'

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:49:43.543620
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_trees
    from ..utils.source import generate_source

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_trees(tree, get_ast(expected))
    assert generate_source(tree) == expected

# Generated at 2022-06-18 00:49:50.365671
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    tree = get_ast(get_source('3.5', 'variables_annotations'))
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.warnings) == 0
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 3

# Generated at 2022-06-18 00:49:59.051018
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False
