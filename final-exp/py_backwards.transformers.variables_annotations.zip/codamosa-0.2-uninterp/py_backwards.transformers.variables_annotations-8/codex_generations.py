

# Generated at 2022-06-18 00:41:27.042964
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:31.708839
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.errors) == 0

    assert compare_ast(result.tree, get_ast('''
        a = 10
    '''))

# Generated at 2022-06-18 00:41:39.055496
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    expected_tree = get_ast(expected_code)
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert compare_ast(result.tree, expected_tree)

# Generated at 2022-06-18 00:41:49.495693
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    tree = ast.parse("a: int = 10")
    assert isinstance(tree, ast.AST)
    assert isinstance(tree.body[0], ast.AnnAssign)
    assert isinstance(tree.body[0].target, ast.Name)
    assert isinstance(tree.body[0].annotation, ast.Name)
    assert isinstance(tree.body[0].value, ast.Num)
    assert isinstance(tree.body[0].simple, int)
    assert isinstance(tree.body[0].type_comment, ast.Name)
    assert isinstance(tree.body[0].lineno, int)
    assert isinstance(tree.body[0].col_offset, int)

# Generated at 2022-06-18 00:41:58.246994
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_asts
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_line_number

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    print_ast(tree)
    print(to_code(tree))
    result = VariablesAnnotationsTransformer.transform(tree)
    print_ast(result.tree)
    print(to_code(result.tree))
    assert result.tree_changed
    assert compare_asts(result.tree, get_ast("""
    a = 10
    """))

# Generated at 2022-06-18 00:42:05.628605
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.ast_helpers import get_node_name

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 2
    assert get_node_name(find(tree, ast.Assign)[0]) == 'a'
    assert get_node_name(find(tree, ast.Assign)[1]) == 'b'

# Generated at 2022-06-18 00:42:10.567868
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:42:13.816369
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:42:19.002135
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.visitor import dump
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_source_and_ast

    # Test 1

# Generated at 2022-06-18 00:42:28.972774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:36.509054
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:42.561042
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast
    from ..utils.tree import compare_source

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    expected = get_ast("""
    a = 10
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.tree, expected)
    assert compare_source(ast_to_str(result.tree), ast_to_str(expected))

# Generated at 2022-06-18 00:42:49.654470
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str

    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast_to_str(result.tree) == 'a = 10'

    tree = get_ast('a: int')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast_to_str(result.tree) == ''

# Generated at 2022-06-18 00:42:52.750135
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    tree = parse_ast("""
    a: int = 10
    b: int
    """)

    expected_tree = parse_ast("""
    a = 10
    """)

    assert_equal_ast(VariablesAnnotationsTransformer.transform(tree).tree, expected_tree)

# Generated at 2022-06-18 00:42:58.155567
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:06.025570
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent_source

    source = dedent_source("""
    a: int = 10
    b: int
    """)
    expected_source = dedent_source("""
    a = 10
    """)

    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    generated_source = generate_code(tree)

    assert compare_ast(get_ast(expected_source), tree)
    assert expected_source == generated_source

# Generated at 2022-06-18 00:43:14.741903
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:43:20.826204
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:29.661300
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:43:34.257347
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:42.862859
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''

    tree = parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert code == tree.body[0].value.s

# Generated at 2022-06-18 00:43:44.734856
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:43:55.994224
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_children
    from ..utils.helpers import get_ast_node_attr
    from ..utils.helpers import get

# Generated at 2022-06-18 00:44:03.795850
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1
    assert astor.to_source(tree).strip() == 'a = 10'

# Generated at 2022-06-18 00:44:13.845193
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_imports_and_format
    from ..utils.helpers import get_ast_without_imports
    from ..utils.helpers import get_ast_without_imports_and_format
    from ..utils.helpers import get_ast_without_format
    from ..utils.helpers import get_code_without_format
    from ..utils.helpers import get_ast_without_imports_and_format
    from ..utils.helpers import get_code_without_imports_and_format
    from ..utils.helpers import get_ast_without_format


# Generated at 2022-06-18 00:44:19.268786
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:26.861586
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_code

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(result.tree, get_ast('''
    a = 10
    '''))
    assert_equal_ast(result.tree, get_ast(get_code(result.tree)))

# Generated at 2022-06-18 00:44:32.439396
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    new_tree, changed = VariablesAnnotationsTransformer.transform(tree)
    assert changed
    assert generate_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:44:40.742300
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_children
    from ..utils.helpers import get_node_siblings
    from ..utils.helpers import get_node_prev_sibling

# Generated at 2022-06-18 00:44:51.754625
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:11.366167
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast
    from ..utils.tree import compare_source
    from ..utils.tree import compare_source_with_ast

    source = """
a: int = 10
b: int
"""
    expected_ast = """
Module(body=[
    Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Str(s='int')),
    AnnAssign(target=Name(id='b', ctx=Store()), annotation=Str(s='int'), value=None)])
"""
    expected_source = """
a = 10
b: int
"""

    tree = parse(source)
    new_tree = VariablesAnnotationsTrans

# Generated at 2022-06-18 00:45:15.494234
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    expected_tree = get_ast('''
        a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-18 00:45:20.631438
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:28.141028
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    transformer = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    transformer.visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:30.510525
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:45:36.013436
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound

    tree = get_ast('a: int = 10')
    node = find(tree, ast.AnnAssign)
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent.body[index].target.id == 'a'
    assert parent.body[index].value.n == 10
    assert parent.body[index].annotation.id == 'int'
    assert parent.body[index].value.n == 10
    assert parent.body[index].value.n == 10

# Generated at 2022-06-18 00:45:46.996635
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast
    from ..utils.tree import compare_source
    from ..utils.tree import compare_source_after_transformation

    # Test 1:
    # Input:
    # a: int = 10
    # b: int
    # Output:
    # a = 10
    # b = None
    tree = get_ast("""
a: int = 10
b: int
""")
    expected_tree = get_ast("""
a = 10
b = None
""")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert compare_ast(result.new_tree, expected_tree)

# Generated at 2022-06-18 00:45:55.364191
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:02.708035
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast
    from ..utils.source import Source
    from ..utils.helpers import get_ast_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_for_ast_node
    from ..utils.helpers import get_ast_node_for_code
    from ..utils.helpers import get_ast_node_for_code_and_type
    from ..utils.helpers import get_ast_node_for_code_and_type_and_field
    from ..utils.helpers import get_ast_node_for_code_and_type_and_field_and_value
    from ..utils.helpers import get_ast_node_for_code_and_type_and

# Generated at 2022-06-18 00:46:13.366559
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert dump(tree) == '''
    Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load()))])
    '''

    tree = get_ast('''
    a: int = 10
    b: int
    c: int = 20
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:46:36.730670
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:46:39.448595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert str(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:46:42.253084
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

# Generated at 2022-06-18 00:46:51.765034
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:57.925798
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:47:06.311773
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:12.595260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:47:15.776542
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:47:22.398834
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:31.850975
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:15.699254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(expected_code, tree)

# Generated at 2022-06-18 00:48:20.022530
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
        a: int = 10
        b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
        a = 10
    """

# Generated at 2022-06-18 00:48:27.226391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_lineno
    from ..utils.tree import get_node_by_lineno
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import get_node_source_code
    from ..utils.source import get_node_source_code_no_leading_space
    from ..utils.source import get_node_source_code_no_trailing_space
    from ..utils.source import get_node_source_code_no_leading_or_trailing_space
    from ..utils.source import get_node_source_code_no_leading_or_trailing_space_no_newline
    from ..utils.source import get_node_source_code_no

# Generated at 2022-06-18 00:48:31.872330
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert str(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:48:37.658206
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_ast
    from ..utils.tree import compare_ast

    code = '''
a: int = 10
b: int
    '''
    expected = '''
a = 10
    '''
    tree = parse_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(new_tree.tree, expected)

# Generated at 2022-06-18 00:48:46.426718
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitors import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    tree = get_ast('a: int = 10')
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:48:49.967604
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed
    assert len(find_all(result.tree, ast.AnnAssign)) == 0
    assert len(find_all(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:48:55.010392
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:59.348922
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree_changed == True
    assert tree_changed.tree.body[0].value.n == 10
    assert tree_changed.tree.body[1].value == None

# Generated at 2022-06-18 00:49:02.288896
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree == ast.parse("""
a = 10
""")

# Generated at 2022-06-18 00:50:56.016456
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.helpers import get_ast
    import astunparse

    # Test 1
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert astunparse.unparse(result.tree) == "a = 10\n"

    # Test 2

# Generated at 2022-06-18 00:51:03.523017
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:51:09.473433
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10\nb: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\nb'

# Generated at 2022-06-18 00:51:19.531101
# Unit test for constructor of class VariablesAnnotationsTransformer