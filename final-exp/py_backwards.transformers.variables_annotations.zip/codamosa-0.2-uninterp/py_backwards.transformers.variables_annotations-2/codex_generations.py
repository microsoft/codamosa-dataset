

# Generated at 2022-06-18 00:41:23.634822
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == parse("""
    a = 10
    """)
    assert result.tree_changed
    assert result.warnings == []

# Generated at 2022-06-18 00:41:28.365183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    code = '''
a: int = 10
b: int
    '''
    expected = '''
a = 10
    '''
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:41:38.532292
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:42.903816
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
a: int = 10
b: int
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:41:48.478660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:41:56.081518
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_str
    from ..utils.visitor import NodeVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    class Visitor(NodeVisitor):
        def visit_Assign(self, node):
            assert node.targets[0].id == 'a'
            assert node.value.n == 10
            assert node.type_comment == 'int'

    Visitor().visit(tree)

# Generated at 2022-06-18 00:42:05.540041
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_children
    from ..utils.helpers import get_node_child_count
    from ..utils.helpers import get_node_child_index
   

# Generated at 2022-06-18 00:42:14.284389
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:20.738213
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    print_ast(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    print(to_code(new_tree.tree))
    assert to_code(new_tree.tree) == 'a = 10\n'

# Generated at 2022-06-18 00:42:30.838613
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import TransformationError

    # Test 1
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    # Test 2
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    # Test 3

# Generated at 2022-06-18 00:42:37.940316
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:42:44.306675
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:49.338054
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10\n'

# Generated at 2022-06-18 00:42:54.172184
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:01.210667
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.tree import find

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """
    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:43:10.999742
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:17.790215
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)

    expected_code = """
    a = 10
    """
    expected_tree = get_ast(expected_code)

    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:43:25.763612
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    assert to_code(tree) == "a: int = 10\nb: int"

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:43:33.159543
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse('a: int = 10\nb: int')
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:43:39.490723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.helpers import get_code
    from ..utils.helpers import get_ast_code
    from ..utils.helpers import get_code_ast
    from ..utils.helpers import get_ast_code_ast
    from ..utils.helpers import get_code_ast_code
    from ..utils.helpers import get_ast_code_ast_code
    from ..utils.helpers import get_code_ast_code_ast
    from ..utils.helpers import get_ast_code_ast_code_ast
    from ..utils.helpers import get_code_ast_code_ast_code
    from ..utils.helpers import get_ast_code_ast_code_ast_code

# Generated at 2022-06-18 00:43:47.951499
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:57.066464
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:06.700798
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type

    # Test 1
    tree = parse_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(result.tree, """
    a = 10
    """)

    # Test 2
    tree = parse_ast("""
    a: int = 10
    b: int
    c: int = 20
    """)
    result = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:44:15.462630
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import ast_to_code
    from ..utils.tree import find
    from ..utils.tree import find_all
    from ..utils.tree import find_parent
    from ..utils.tree import find_parents
    from ..utils.tree import find_parent_and_index
    from ..utils.tree import find_parent_and_index_of_child
    from ..utils.tree import find_parent_and_index_of_node
    from ..utils.tree import find_parent_and_index_of_node_in_parent
    from ..utils.tree import find_parent_and_index_of_parent
    from ..utils.tree import find_parent_and_index_of_parent_in_parent
    from ..utils.tree import find_parent

# Generated at 2022-06-18 00:44:18.223094
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == \
           TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:44:19.948609
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:44:25.783833
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:44:35.889343
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_as_string
    from ..utils.tree import get_root

    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    root = get_root(tree)
    assert get_node_as_string(root) == "Module(body=[AnnAssign(target=Name(id='a', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=Num(n=10), simple=1), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=0)])"
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:44:43.024643
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(get_ast('''
    a = 10
    '''), True, [])

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(get_ast('''
    a = 10
    '''), True, [])


# Generated at 2022-06-18 00:44:51.208341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.context import Context
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_code_to_ast(code)
    visitor = NodeTransformerVisitor(Context(tree=tree))
    visitor.visit(tree)
    assert generate_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:45:09.713638
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1
    assert compare_ast(result.tree, get_ast(generate_code(result.tree)))

# Generated at 2022-06-18 00:45:17.372220
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:45:22.344788
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to

# Generated at 2022-06-18 00:45:30.618485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_asts

    code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = get_ast(code)
    print_ast(tree)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    print_ast(new_tree.tree)
    assert compare_asts(new_tree.tree, get_ast(expected_code))
    assert to_code(new_tree.tree) == expected_code

# Generated at 2022-06-18 00:45:36.290957
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_ast_diff
    from ..utils.source import Source
    from ..utils.helpers import get_ast_diff
    from ..utils.tree import parse_to_ast

    source = Source("""
    a: int = 10
    b: int
    """)
    expected_source = Source("""
    a = 10
    """)
    tree = parse_to_ast(source)
    expected_tree = parse_to_ast(expected_source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert get_ast_diff(result.tree, expected_tree) == []

# Generated at 2022-06-18 00:45:47.278183
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            print(node.target.id)
            print(node.annotation.id)
            print(node.value.n)

    class TestTransformer(NodeTransformerVisitor):
        def visit_AnnAssign(self, node):
            return ast.Assign(targets=[node.target], value=node.value, type_comment=node.annotation)

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    # Test visitor
    TestVisitor().vis

# Generated at 2022-06-18 00:45:53.308074
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert compare_ast(to_code(new_tree), expected_code)

# Generated at 2022-06-18 00:46:01.877459
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_name
    from ..utils.visitor import NodeVisitor

    tree = get_ast('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree)

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            assert False

    Visitor().visit(tree)

    assert get_node_name(tree) == 'Module'
    assert get_node_name(tree.body[0]) == 'Assign'
    assert get_node_name(tree.body[0].targets[0]) == 'Name'
    assert get_node_name(tree.body[0].value) == 'Num'

# Generated at 2022-06-18 00:46:06.898641
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    new_tree, tree_changed, _ = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:46:12.420812
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:46:38.231623
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_asts

    source = '''
        a: int = 10
        b: int
    '''

    expected = '''
        a = 10
    '''

    tree = get_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_asts(new_tree, get_ast(expected))
    assert len(find(new_tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:46:48.800199
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast, compare_asts
    from ..utils.tree import get_node_at_index
    from ..utils.source import get_source

    tree = get_ast(get_source('3.5', 'variables_annotations'))
    node = get_node_at_index(tree, 0)
    assert isinstance(node, ast.AnnAssign)

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    node = get_node_at_index(new_tree, 0)
    assert isinstance(node, ast.Assign)
    assert compare_asts(new_tree, get_ast(get_source('3.5', 'variables_annotations_transformed')))

# Generated at 2022-06-18 00:46:53.159939
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(new_tree) == 'a = 10\n'

# Generated at 2022-06-18 00:47:01.751563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_ast_diff
    from ..utils.helpers import get_ast_str

    code = """
    a: int = 10
    b: int
    """

    expected_code = """
    a = 10
    """

    tree = parse_to_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert get_ast_str(new_tree.tree) == get_ast_str(parse_to_ast(expected_code))
    assert get_ast_diff(new_tree.tree, parse_to_ast(expected_code)) == []

# Generated at 2022-06-18 00:47:03.946462
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('a: int = 10')
    assert to_code(VariablesAnnotationsTransformer.transform(tree).tree) == 'a = 10'

# Generated at 2022-06-18 00:47:10.531367
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:17.858687
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerV

    class TestTransformer(NodeTransformerV):
        def visit_AnnAssign(self, node):
            return ast.Assign(targets=[node.target], value=node.value, type_comment=node.annotation)

    tree = parse("""
    a: int = 10
    b: int
    """)

    print_tree(tree)
    print_tree(TestTransformer().visit(tree))
    print_tree(VariablesAnnotationsTransformer.transform(tree).tree)

# Generated at 2022-06-18 00:47:27.446767
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = '''
    a: int = 10
    b: int
    '''
    tree = ast.parse(code)
    # When
    result = VariablesAnnotationsTransformer.transform(tree)
    # Then
    assert result.tree_changed
    assert result.warnings == []
    assert result.errors == []
    assert ast.dump(result.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None)])"

# Generated at 2022-06-18 00:47:35.880130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:42.648602
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:48:25.315991
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.errors == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:48:29.393433
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    expected_tree = ast.parse("""
a = 10
    """)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-18 00:48:38.606701
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    tree = get_ast('a: int = 10')
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:48:42.003936
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:48:45.628145
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(VariablesAnnotationsTransformer,
                          """
                          a: int = 10
                          b: int
                          """,
                          """
                          a = 10
                          """)

# Generated at 2022-06-18 00:48:54.573662
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:01.872920
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:49:06.592265
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:49:10.625322
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:49:17.662599
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:51:03.620638
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    expected_tree = get_ast(expected_code)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:51:08.129268
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:51:14.117174
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:51:20.356417
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent

    source = dedent('''
    a: int = 10
    b: int
    ''')
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, dedent('''
    a = 10
    '''))
    assert generate_code(tree) == dedent('''
    a = 10
    ''')