

# Generated at 2022-06-18 00:41:14.949130
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Test that the constructor of class VariablesAnnotationsTransformer
    # is working properly
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)


# Generated at 2022-06-18 00:41:19.926688
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    VariablesAnnotationsTransformer.transform(tree)

    assert get_node_by_path(tree, 'body.0.value.n') == 10
    assert get_node_by_path(tree, 'body.1.value') is None

# Generated at 2022-06-18 00:41:28.623967
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:34.397016
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    expected_tree = get_ast('''
    a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:41:43.948032
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Name)) == 2
    assert len(find(tree, ast.NameConstant)) == 1

    try:
        get_ast_node_name(tree)
    except NodeNotFound:
        assert False

# Generated at 2022-06-18 00:41:54.300224
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string
    from ..utils.helpers import get_ast_as_string

# Generated at 2022-06-18 00:42:01.722116
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            self.generic_visit(node)
            print(node.target.id)

    tree = parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == """
    a = 10
    """
    Visitor().visit(result.tree)

# Generated at 2022-06-18 00:42:06.881435
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed
    assert len(result.warnings) == 0

    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:42:11.057659
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:16.648384
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node
    from ..utils.tree import print_tree

    tree = get_node("""
    a: int = 10
    b: int
    """)

    print_tree(tree)

    result = VariablesAnnotationsTransformer.transform(tree)
    print_tree(result.tree)

    assert result.tree_changed == True
    assert result.warnings == []

# Generated at 2022-06-18 00:42:28.833621
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import assert_equal_ast
    from ..utils.helpers import assert_equal_source
    from ..utils.helpers import assert_equal_types
    from ..utils.helpers import assert_equal_annotation
    from ..utils.helpers import assert_equal_lineno
    from ..utils.helpers import assert_equal_col_offset
    from ..utils.helpers import assert_equal_end_lineno
    from ..utils.helpers import assert_equal_end_col_offset
    from ..utils.helpers import assert_equal_ctx
    from ..utils.helpers import assert_equal_value
    from ..utils.helpers import assert_equal_elts
    from ..utils.helpers import assert_equal_s

# Generated at 2022-06-18 00:42:34.412941
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_asts

    test_code = '''
        a: int = 10
        b: int
    '''

    expected_code = '''
        a = 10
    '''

    tree = get_ast(test_code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_asts(tree, get_ast(expected_code))

# Generated at 2022-06-18 00:42:42.698656
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:49.336999
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(tree, expected_code)

# Generated at 2022-06-18 00:42:52.215461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:43:00.434272
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''

    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    expected_tree = get_ast(expected_code)

    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:43:10.368098
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:43:16.816802
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:21.841367
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_test_data

    code = get_test_data('test_data/variables_annotations.py')
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-18 00:43:28.652317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.tree.body[0].value.n == 10
    assert new_tree.tree.body[1].value is None
    assert new_tree.tree.body[0].targets[0].id == 'a'
    assert new_tree.tree.body[1].targets[0].id == 'b'

# Generated at 2022-06-18 00:43:36.310613
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import get_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:40.032995
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(
        parse("""
        a = 10
        """), True, [])

# Generated at 2022-06-18 00:43:48.526973
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:43:57.426732
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_ast
    from ..utils.helpers import get_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:06.725595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, find_one
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_

# Generated at 2022-06-18 00:44:12.286756
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:44:19.026437
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:44:26.269270
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_as_module
    from ..utils.visitor import print_tree

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_code_as_module(code)
    print_tree(tree)
    tree = VariablesAnnotationsTransformer.transform(tree)
    print_tree(tree)
    print(generate_code(tree))

test_VariablesAnnotationsTransformer()

# Generated at 2022-06-18 00:44:34.541669
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_AnnAssign(self, node):
            print(node.target.id)
            print(node.annotation)
            print(node.value)
            print(node.simple)

    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == "a = 10"
    Visitor().visit(tree)

# Generated at 2022-06-18 00:44:39.152759
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ignore_whitespaces
    from ..utils.tree import parse_to_ast

    tree = parse_to_ast("""
    a: int = 10
    b: int
    """)
    expected_tree = parse_to_ast("""
    a = 10
    """)

    assert_equal_ignore_whitespaces(VariablesAnnotationsTransformer.transform(tree).tree, expected_tree)

# Generated at 2022-06-18 00:44:54.320050
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..exceptions import InvalidInput

    source = source_to_unicode("""
    a: int = 10
    b: int
    """)
    tree = get_ast(source)

    expected_tree = get_ast(source_to_unicode("""
    a = 10
    """))

    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:45:00.944464
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_module
    from ..utils.visitor import print_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_module(code)
    print_ast(tree)
    print(generate_code(tree))
    VariablesAnnotationsTransformer.transform(tree)
    print_ast(tree)
    print(generate_code(tree))

# Generated at 2022-06-18 00:45:06.233606
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:45:13.801757
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree_expected = get_ast("""
    a = 10
    """)

    tree_transformed = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree_transformed.tree, tree_expected)
    assert tree_transformed.tree_changed == True
    assert tree_transformed.warnings == []

# Generated at 2022-06-18 00:45:17.051480
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast("""
        a: int = 10
        b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:45:22.541884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, get_ast('a = 10'))

# Generated at 2022-06-18 00:45:26.709547
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(VariablesAnnotationsTransformer,
                          """
                          a: int = 10
                          b: int
                          """,
                          """
                          a = 10
                          """)

# Generated at 2022-06-18 00:45:35.380165
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import node_to_str
    from ..utils.tree import find
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    import astor
    import textwrap
    import unittest

    class TestVariablesAnnotationsTransformer(unittest.TestCase):
        def test_transform(self):
            code = textwrap.dedent('''
                def f(a: int = 10, b: int):
                    pass
            ''')
            tree = ast.parse(code)
            tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:45:46.239137
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:53.265508
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..types import TransformationResult

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result, TransformationResult)
    assert result.tree_changed == True
    assert result.new_nodes == []
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1


# Generated at 2022-06-18 00:46:20.528585
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_target
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_type_comment

# Generated at 2022-06-18 00:46:29.971673
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_types_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get_all_nodes_from_ast
    from ..utils.tree import get

# Generated at 2022-06-18 00:46:37.303328
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, get_ast(expected))

# Generated at 2022-06-18 00:46:43.831788
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
        a: int = 10
        b: int
    '''

    tree = parse(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_src(tree) == 'a = 10'

# Generated at 2022-06-18 00:46:53.327519
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast
    from ..utils.helpers import get_source
    from ..utils.helpers import get_source_from_ast
    from ..utils.helpers import assert_source_equal
    from ..utils.helpers import assert_source_not_equal
    from ..utils.helpers import assert_source_equal_ignore_ws
    from ..utils.helpers import assert_source_not_equal_ignore_ws
    from ..utils.helpers import assert_source_equal_ignore_ws_and_sc
    from ..utils.helpers import assert_source_not_equal_ignore_ws_and_sc
    from ..utils.helpers import assert_source_equal_ignore_sc

# Generated at 2022-06-18 00:47:02.701861
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_tree
    from ..utils.helpers import get_tree_from_code
    from ..utils.helpers import get_tree_from_ast
    from ..utils.helpers import get_ast_from_tree
    from ..utils.helpers import get_code_from_tree
    from ..utils.helpers import get_tree_from_code
    from ..utils.helpers import get_ast_from_tree
    from ..utils.helpers import get_tree_from_ast

# Generated at 2022-06-18 00:47:09.704089
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast
    from ..utils.tree import compare_source
    from ..utils.tree import get_ast
    from ..utils.tree import get_source
    from ..utils.tree import tree_to_str

    code = """
    a: int = 10
    b: int
    """
    tree = parse_code_to_ast(code)
    assert tree_to_str(tree) == ast_to_str(tree)
    assert get_source(tree) == code
    assert get_ast(code) == tree
    assert compare_source(tree, code)
    assert compare_ast(tree, get_ast(code))

    result = VariablesAnnotationsTransformer.transform

# Generated at 2022-06-18 00:47:15.619717
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('a: int = 10')
    assert len(find(tree, ast.AnnAssign)) == 1

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:47:18.795527
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:47:24.700129
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert compare_ast(tree, get_ast(expected))

# Generated at 2022-06-18 00:48:12.443992
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:48:14.196648
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:48:18.960300
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(tree) == 'a = 10\n'
    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:48:26.928745
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue
        tree_changed = True
        parent.body.pop(index)  # type: ignore

# Generated at 2022-06-18 00:48:36.646505
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:41.012436
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code_str
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code_str(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:45.766666
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
a: int = 10
b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].targets[0].id == 'b'

# Generated at 2022-06-18 00:48:50.966450
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:59.463626
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:02.704558
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert code == compile(tree, '', 'exec')

# Generated at 2022-06-18 00:50:50.893428
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..types import TransformationResult
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..exceptions import NodeNotFound
    import astor

    # Test 1:
    # Compiles:
    #     a: int = 10
    #     b: int
    # To:
    #     a = 10
    #     b = None
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed = False
    tree_changed, tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert astor.to_source(tree)

# Generated at 2022-06-18 00:50:58.723559
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_

# Generated at 2022-06-18 00:51:05.325943
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.errors) == 0

    a = get_node_by_path(result.tree, ['Module', 'body', 0])
    assert isinstance(a, ast.Assign)
    assert a.targets[0].id == 'a'
    assert a.value.n == 10
    assert a.type_comment == 'int'

    b = get_node_by_path(result.tree, ['Module', 'body', 1])
   

# Generated at 2022-06-18 00:51:13.906064
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    tree = get_ast('a: int = 10\nb: int')
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue
        tree_changed = True
        parent.body.pop(index)  # type: ignore
