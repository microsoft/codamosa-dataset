

# Generated at 2022-06-18 00:41:26.238646
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.helpers import assert_equal
    from ..utils.helpers import assert_true
    from ..utils.helpers import assert_false
    from ..utils.helpers import assert_not_equal
    from ..utils.helpers import assert_is_instance
    from ..utils.helpers import assert_is_not_none
    from ..utils.helpers import assert_is_none
    from ..utils.helpers import assert_is
    from ..utils.helpers import assert_is_not
    from ..utils.helpers import assert_in
    from ..utils.helpers import assert_not_in
    from ..utils.helpers import assert_greater
    from ..utils.helpers import assert_greater_equal
   

# Generated at 2022-06-18 00:41:29.973720
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:41:35.771080
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:41:42.761543
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
    a: int = 10
    b: int
    ''')
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Name)) == 2

# Generated at 2022-06-18 00:41:49.421845
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(find_all(result.tree, ast.AnnAssign)) == 0
    assert len(find_all(result.tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:41:56.411540
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast_to_str(new_tree.tree) == '''
a = 10
    '''
    assert compare_ast(new_tree.tree, get_ast(ast_to_str(new_tree.tree)))

# Generated at 2022-06-18 00:42:01.152006
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:06.353629
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_tree

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert dump_tree(result.tree) == dump_tree(get_ast('''
    a = 10
    '''))

# Generated at 2022-06-18 00:42:10.671145
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:14.133342
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:20.239433
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    expected_tree = get_ast('''
    a = 10
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected_tree

# Generated at 2022-06-18 00:42:30.406929
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:39.841597
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:42:47.116889
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import check_equivalent
    from ..utils.source import generate_code
    from ..utils.source import dedent

    tree = get_ast(dedent('''
    a: int = 10
    b: int
    '''))

    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert check_equivalent(generate_code(new_tree), dedent('''
    a = 10
    '''))

# Generated at 2022-06-18 00:42:49.965040
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:42:54.813391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_str

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_str(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:01.594734
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import assert_equal_ast

    code = '''
    a: int = 10
    b: int
    '''

    expected_code = '''
    a = 10
    '''

    tree = parse_to_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(result.tree, expected_code)

# Generated at 2022-06-18 00:43:11.185134
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVis

# Generated at 2022-06-18 00:43:20.275971
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse("a: int = 10\nb: int")
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed == True
    assert ast.dump(VariablesAnnotationsTransformer.transform(tree).tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:43:25.674372
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_str
    from ..utils.visitor import NodeTransformer

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformer().visit(tree)
    assert to_str(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:38.029060
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.helpers import parse_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..utils.helpers import parse_ast
    from ..utils.tree import find, get_non_exp_parent

# Generated at 2022-06-18 00:43:44.353877
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:46.465081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:48.059186
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse


# Generated at 2022-06-18 00:43:57.129014
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:04.071079
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
a: int = 10
b: int
'''
    tree = get_ast(code)
    transformer = VariablesAnnotationsTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)
    assert to_code(tree) == '''
a = 10
'''

# Generated at 2022-06-18 00:44:13.846591
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    import astor
    import os
    import sys

    # Test 1:
    # Test for the constructor of class VariablesAnnotationsTransformer
    # Input:
    #   - N/A
    # Output:
    #   - N/A
    # Description:
    #   - Test if the constructor of class VariablesAnnotationsTransformer
    #     is working properly
    def test_1():
        # Create an instance of class VariablesAnnotationsTransformer
        transformer = VariablesAnnotationsTransformer()

        # Check if the instance is

# Generated at 2022-06-18 00:44:16.482633
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        VariablesAnnotationsTransformer,
        """
        a: int = 10
        b: int
        """,
        """
        a = 10
        """
    )

# Generated at 2022-06-18 00:44:25.871579
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Assign)
    assert tree.body[0].targets[0].id == 'a'
    assert tree.body[1].targets[0].id == 'b'
    assert tree.body[0].value.n == 10
    assert tree.body[1].value is None

# Generated at 2022-06-18 00:44:36.022765
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_type_comment
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_parent_name
    from ..utils.helpers import get_node_parent_type

# Generated at 2022-06-18 00:44:48.853904
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    assert VariablesAnnotationsTransformer.transform(tree).tree_changed

# Generated at 2022-06-18 00:44:53.691128
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    a: int = 10
    b: int
    """
    tree = get_ast(source)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:03.277861
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import generate_code_from_ast
    from ..utils.source import dedent_source
    from ..utils.source import indent_source

    source = dedent_source("""
    a: int = 10
    b: int
    """)

    expected_source = dedent_source("""
    a = 10
    """)

    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast(expected_source))
    assert generate_code_from_ast(tree) == generate_code(expected_source)

# Generated at 2022-06-18 00:45:09.529563
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:45:13.388533
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    expected_tree = ast.parse("""
a = 10
b: int
    """)
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert result.tree == expected_tree

# Generated at 2022-06-18 00:45:23.104162
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:31.881593
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import print_tree
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source_helpers import get_source_from_ast

    source = """
    a: int = 10
    b: int
    """
    tree = get_ast_from_source(source)
    print_tree(tree)
    assert len(get_node_of_type(tree, ast.AnnAssign)) == 2
    VariablesAnnotationsTransformer.transform(tree)
    print_tree(tree)
    assert len(get_node_of_type(tree, ast.AnnAssign)) == 0
    assert len(get_node_of_type(tree, ast.Assign)) == 1
    assert get_source

# Generated at 2022-06-18 00:45:38.425237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeVisitor

    tree = get_ast('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == ''

    tree = get_ast('a: int = 10\nb: int')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int = 10\nb: int = 20')
    tree = VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:45:48.298725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:56.570915
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:46:19.470917
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:46:27.458317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import ast_to_str
    from ..utils.helpers import get_code
    from ..utils.helpers import get_ast_str

    code = get_code(__file__, '../examples/variables_annotations.py')
    tree = parse_code_to_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast_to_str(result.tree) == get_ast_str(__file__, '../examples/variables_annotations_transformed.py')

# Generated at 2022-06-18 00:46:35.046752
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from utils.tree import find, get_non_exp_parent_and_index, insert_at
    from utils.helpers import warn
    from types import TransformationResult
    from exceptions import NodeNotFound
    from base import BaseTransformer

# Generated at 2022-06-18 00:46:42.030643
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    # Test 1: Test the constructor
    tree = parse_ast("""
    a: int = 10
    b: int
    """)
    tree_changed = False
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == tree_changed
    assert result.messages == []

    # Test 2: Test the transform method
    tree = parse_ast("""
    a: int = 10
    b: int
    """)


# Generated at 2022-06-18 00:46:46.742848
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:46:57.208488
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..exceptions import NodeNotFound

# Generated at 2022-06-18 00:47:01.162091
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed is True
    assert result.warnings == []
    assert result.tree == get_ast('a = 10')

# Generated at 2022-06-18 00:47:03.331850
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []

# Generated at 2022-06-18 00:47:08.401536
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert get_code_from_ast(tree_changed.tree) == 'a = 10'

# Generated at 2022-06-18 00:47:14.086654
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == parse('''
    a = 10
    ''')

# Generated at 2022-06-18 00:47:52.974725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:47:57.431774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import assert_equal_ignore_whitespaces

    code = '''
        a: int = 10
        b: int
    '''

    expected_code = '''
        a = 10
    '''

    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ignore_whitespaces(expected_code, tree)

# Generated at 2022-06-18 00:48:01.896925
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import Visitor

    class Visitor(Visitor):
        def visit_AnnAssign(self, node):
            raise Exception('AnnAssign node found')

    tree = parse('a: int = 10')
    VariablesAnnotationsTransformer.transform(tree)
    Visitor().visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:12.804608
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:15.858231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(VariablesAnnotationsTransformer,
        """
        a: int = 10
        b: int
        """,
        """
        a = 10
        """
    )

# Generated at 2022-06-18 00:48:23.609470
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_type_name
    from ..utils.tree import find
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import source_to_tokens
    from ..utils.source import tokens_to_source
    from ..utils.source import tree_to_tokens
    from ..utils.source import tokens_to_tree
    from ..utils.source import get_ast_node_at_line
    from ..utils.source import get_ast_node_at_pos
    from ..utils.source import get_line_at_pos
    from ..utils.source import get_pos_at_line
    from ..utils.source import get_pos_at_line_col


# Generated at 2022-06-18 00:48:30.231026
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import generate_code
    from ..utils.tree import find_all
    from ..utils.testing import assert_code_equal

    tree = ast.parse('a: int = 10\nb: int')
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert_code_equal(generate_code(result.tree), 'a = 10')
    assert len(find_all(result.tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:48:37.977104
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    code = '''
    a: int = 10
    b: int
    '''

    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)

    assert get_code(tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:48:44.820755
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = get_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(generate_code(new_tree), expected)
    assert len(find(new_tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:48:51.197435
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:50:39.262948
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:50:41.474429
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int")) == TransformationResult(ast.parse("a = 10\nb"), True, [])

# Generated at 2022-06-18 00:50:44.189683
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree == ast.parse("""
a = 10
""")

# Generated at 2022-06-18 00:50:50.313508
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source

    source = get_source(VariablesAnnotationsTransformer)
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:50:58.177363
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_ctx
    from ..utils.helpers import get_ast_node_annotation
    from ..utils.helpers import get_ast_node_type_comment

# Generated at 2022-06-18 00:51:05.037607
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:51:07.977246
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)

    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:51:13.694231
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == "a = 10"

# Generated at 2022-06-18 00:51:16.521339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import get_body_of_function
    from ..utils.code_gen import to_source
