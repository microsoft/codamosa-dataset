

# Generated at 2022-06-18 00:41:28.442339
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_type
    from ..utils.tree import get_body
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import source_to_tokens
    from ..utils.source import tokens_to_source
    from ..utils.source import tokens_to_tree
    from ..utils.source import tree_to_tokens
    from ..utils.source import get_ast_node_name
    from ..utils.source import get_ast_node_type
    from ..utils.source import get_ast_node_lineno
    from ..utils.source import get_ast_node_col_offset
    from ..utils.source import get_ast_node_end_lineno
    from ..utils.source import get_

# Generated at 2022-06-18 00:41:38.574093
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:43.819331
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)

    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:41:54.183484
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:58.929099
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:42:08.011202
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.tree import find
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.tree import find

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    code = '''
    a: int = 10
    b: int
    c: int = 20
    '''
    tree = get_ast(code)

# Generated at 2022-06-18 00:42:15.819341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_tree
    from ..utils.tree import find
    from ..exceptions import NodeNotFound

    tree = get_tree('''
    a: int = 10
    b: int
    ''')

    assert len(find(tree, ast.AnnAssign)) == 2

    result = VariablesAnnotationsTransformer.transform(tree)

    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:42:25.180041
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:30.835519
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:42:40.229215
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:52.117287
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_types
    from ..utils.tree import get_node_by_path

    tree = ast.parse("""
a: int = 10
b: int
    """)

    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)

    assert result.tree_changed is True
    assert get_node_types(result.tree) == ['Module', 'Assign', 'Assign']
    assert get_node_by_path(result.tree, [0, 0, 0]).id == 'a'
    assert get_node_by_path(result.tree, [0, 0, 1]).n == 10
    assert get_node_by_path(result.tree, [0, 1, 0]).id == 'b'
   

# Generated at 2022-06-18 00:43:03.480195
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_ast_node_name
    from ..utils.tree import get_ast_node_type
    from ..utils.tree import get_ast_node_value
    from ..utils.tree import get_ast_node_lineno
    from ..utils.tree import get_ast_node_col_offset
    from ..utils.tree import get_ast_node_end_lineno
    from ..utils.tree import get_ast_node_end_col_offset
    from ..utils.tree import get_ast_node_type_comment
    from ..utils.tree import get_ast_node_body
    from ..utils.tree import get_ast_node_orelse
    from ..utils.tree import get_ast_node_finalbody

# Generated at 2022-06-18 00:43:13.308398
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name, get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_type_comment
    from ..utils.helpers import get_ast_node_body
    from ..utils.helpers import get_ast_node_orelse
    from ..utils.helpers import get_ast_node

# Generated at 2022-06-18 00:43:21.319323
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast_str
    from ..utils.helpers import get_ast_str_from_file
    from ..utils.helpers import get_ast_from_file
    from ..utils.helpers import get_ast_from_str
    from ..utils.helpers import get_ast_str_from_str
    from ..utils.helpers import get_ast_from_file
    from ..utils.helpers import get_ast_str_from_file
    from ..utils.helpers import get_ast_from_str
    from ..utils.helpers import get_ast_str_from_str
    from ..utils.helpers import get_ast_from_file
    from ..utils.helpers import get_

# Generated at 2022-06-18 00:43:27.216308
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:36.779342
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    tree = parse_ast(get_source(VariablesAnnotationsTransformer))
    assert len(find(tree, ast.AnnAssign)) == 1
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Assign)) == 1
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:43:46.351484
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index
    from ..utils.helpers import compare_trees
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:52.793403
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_ast
    from ..utils.tree import compare_ast

    code = '''
    a: int = 10
    b: int
    '''

    expected = '''
    a = 10
    '''

    tree = parse_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert compare_ast(new_tree.tree, parse_ast(expected))

# Generated at 2022-06-18 00:43:58.703237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_trees
    from ..utils.source import source_to_tree
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    source = '''
    a: int = 10
    b: int
    '''
    tree = source_to_tree(source)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_trees(tree, get_ast('''
    a = 10
    '''))

# Generated at 2022-06-18 00:44:03.633661
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree.body[0].value.n == 10
    assert tree.body[1].value is None

# Generated at 2022-06-18 00:44:12.247432
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert to_code(result.tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:44:15.996851
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:20.380773
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:44:24.755126
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert code == tree.body[0].value.s

# Generated at 2022-06-18 00:44:30.379981
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

    tree = get_ast('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == ''

# Generated at 2022-06-18 00:44:35.106521
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.source import get_source

    source = get_source(VariablesAnnotationsTransformer)
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:44:42.550675
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_tree_changed
    from ..utils.helpers import get_warnings
    from ..utils.helpers import get_result
    from ..utils.helpers import get_result_changed
    from ..utils.helpers import get_result_warnings
    from ..utils.helpers import get_result_tree
    from ..utils.helpers import get_result_tree_changed
    from ..utils.helpers import get_result_tree_warnings
    from ..utils.helpers import get_result_tree_source


# Generated at 2022-06-18 00:44:48.306394
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)

    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:56.175943
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:02.563498
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import visit_and_replace

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    new_tree = visit_and_replace(tree, VariablesAnnotationsTransformer)
    assert to_code(new_tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:15.908701
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:45:21.871894
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = """
a: int = 10
b: int
    """
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.errors == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:45:30.234636
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.tree import find
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.tree import find

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:35.268050
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_ast
    from ..utils.helpers import get_ast_diff
    from ..utils.helpers import get_ast_str

    code = """
    a: int = 10
    b: int
    """
    tree = parse_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    expected_code = """
    a = 10
    """
    expected_tree = parse_ast(expected_code)
    assert get_ast_str(new_tree.tree) == get_ast_str(expected_tree)
    assert get_ast_diff(new_tree.tree, expected_tree) == []

# Generated at 2022-06-18 00:45:41.330652
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:45:46.629490
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:45:51.089523
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert str(tree) == "a = 10\n"

# Generated at 2022-06-18 00:45:54.021441
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.tree == ast.parse("""
a = 10
    """)

# Generated at 2022-06-18 00:45:59.090542
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:46:06.349174
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert compare_ast(get_ast(expected), new_tree.tree)

# Generated at 2022-06-18 00:46:31.065681
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast
    from ..utils.ast_helpers import get_ast_node_by_path
    from ..utils.code_compare import assert_code_equal

    code = """
    a: int = 10
    b: int
    """
    tree = parse_to_ast(code)
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert_code_equal(generate_code(result.tree), "a = 10")
    assert result.tree_changed == True
    assert result.warnings == []
    assert result.errors == []

# Generated at 2022-06-18 00:46:40.610298
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode

# Generated at 2022-06-18 00:46:48.462045
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import load_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_trees

    tree = load_ast('3.5', '''
    a: int = 10
    b: int
    ''')

    print_tree(tree)
    print('\n')

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    print_tree(new_tree)

    assert compare_trees(new_tree, load_ast('3.5', '''
    a = 10
    '''))

# Generated at 2022-06-18 00:46:57.239377
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:01.660691
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    tree = parse_ast('''
    a: int = 10
    b: int
    ''')

    expected = parse_ast('''
    a = 10
    ''')

    assert_equal_ast(VariablesAnnotationsTransformer.transform(tree).tree, expected)

# Generated at 2022-06-18 00:47:06.055971
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast

    code = '''
a: int = 10
b: int
    '''

    expected_code = '''
a = 10
    '''

    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(expected_code, new_tree)

# Generated at 2022-06-18 00:47:16.164580
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:47:22.664980
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound

    tree = get_ast('a: int = 10')
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:47:32.152505
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast

    source = source_to_unicode('''
    def f():
        a: int = 10
        b: int
    ''')
    tree = source_to_ast(source)
    print_tree(tree)

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    print_tree(tree)

    assert get_node_name(tree.body[0].body[0]) == 'Assign'

# Generated at 2022-06-18 00:47:38.089728
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    class Visitor(NodeVisitor):
        def visit_Assign(self, node):
            assert node.targets[0].id == 'a'
            assert node.value.n == 10
            assert node.type_comment == 'int'

    Visitor().visit(tree)
    assert dump(tree) == '''
        a = 10
        b: int
    '''

# Generated at 2022-06-18 00:48:25.634796
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:32.868256
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import print_ast

    code = """
    a: int = 10
    b: int
    """

    tree = get_ast(code)
    print_ast(tree)
    print('\n')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    print_ast(tree)
    print('\n')
    print(to_code(tree))

# Generated at 2022-06-18 00:48:41.894574
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_node_list
    from ..utils.source import get_source_from_node_list_list
    from ..utils.source import get_source_from_node_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list_list_list
    from ..utils.source import get_

# Generated at 2022-06-18 00:48:46.305014
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    VariablesAnnotationsTransformer.transform(tree)

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:48:56.042253
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:49:01.318261
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast
    from ..utils.tree import get_node_at_line
    import astor

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)

    assert astor.to_source(get_node_at_line(tree, 2)) == 'a = 10'
    assert astor.to_source(get_node_at_line(tree, 3)) == 'b: int'

# Generated at 2022-06-18 00:49:05.573275
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree == get_ast("""
    a = 10
    """)

# Generated at 2022-06-18 00:49:10.720333
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:49:17.726940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    import astor
    import textwrap
    import unittest
    import sys
    import os
    import io
    import contextlib

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old


# Generated at 2022-06-18 00:49:23.518469
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10\n"

# Generated at 2022-06-18 00:51:13.103391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees
    from ..utils.tree import get_node_by_path

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    expected_tree = get_ast('''
    a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)

    assert compare_trees(tree, expected_tree)
    assert get_node_by_path(tree, 'body', 0, 'value', 'n') == 10
    assert get_node_by_path(tree, 'body', 0, 'targets', 0, 'id') == 'a'

# Generated at 2022-06-18 00:51:20.602033
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_formatted
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_formatted_and_imports
    from ..utils.helpers import get_code_without_comments_and_docstrings_and_blank_lines_and_formatted_and_imports_and_parentheses