

# Generated at 2022-06-18 00:41:25.368766
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:41:31.140254
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find_all, find_all_by_type

    tree = parse_ast("""
    a: int = 10
    b: int
    """)

    # Test that the class is able to transform the tree
    VariablesAnnotationsTransformer.transform(tree)

    # Test that the class actually transformed the tree
    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all_by_type(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:41:35.728746
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    tree = ast.parse("a: int = 10\nb: int")
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)
    assert transformer.transform(tree) == TransformationResult(ast.parse("a = 10\nb"), True, [])

# Generated at 2022-06-18 00:41:42.713403
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.compare import compare_asts

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    expected_tree = get_ast('''
        a = 10
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert compare_asts(result.tree, expected_tree)
    assert result.tree_changed
    assert to_code(result.tree) == to_code(expected_tree)

# Generated at 2022-06-18 00:41:48.316670
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:41:57.733544
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast

    source = source_to_unicode('''
    a: int = 10
    b: int
    ''')
    tree = source_to_ast(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed is True
    assert len(result.messages) == 0

# Generated at 2022-06-18 00:42:02.503988
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:42:10.717591
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_text
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_parent_field
    from ..utils.helpers import get_node_child_nodes
    from ..utils.helpers import get_node_fields
    from ..utils.helpers import get_

# Generated at 2022-06-18 00:42:16.092651
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed, new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed == True
    assert ast.dump(new_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])"

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed, new_tree

# Generated at 2022-06-18 00:42:19.052308
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == "a = 10\n"

# Generated at 2022-06-18 00:42:30.112670
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent

    source = dedent('''
    a: int = 10
    b: int
    ''')

    expected_source = dedent('''
    a = 10
    ''')

    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    generated_source = generate_code(tree)

    assert compare_ast(get_ast(expected_source), tree)
    assert generated_source == expected_source

# Generated at 2022-06-18 00:42:39.566143
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:42:43.353431
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    assert VariablesAnnotationsTransformer.transform(tree).tree_changed

# Generated at 2022-06-18 00:42:49.543742
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree_changed = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"
    assert tree_changed

# Generated at 2022-06-18 00:42:51.988991
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:43:01.731751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent_source

    source = dedent_source("""
    a: int = 10
    b: int
    """)

    expected_source = dedent_source("""
    a = 10
    """)

    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree)

    assert compare_ast(tree, get_ast(expected_source))
    assert generate_code(tree) == expected_source

# Generated at 2022-06-18 00:43:04.310220
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = """
    a: int = 10
    b: int
    """
    tree = parse(code)
    VariablesAnnotationsTransformer.transform(tree)

# Generated at 2022-06-18 00:43:13.670171
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:43:16.027845
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')) == TransformationResult(ast.parse('a = 10'), True, [])

# Generated at 2022-06-18 00:43:20.871301
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    tree = parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10\n'

# Generated at 2022-06-18 00:43:27.267485
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump

# Generated at 2022-06-18 00:43:36.810979
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:43.327595
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast('''
        a = 10
    '''))

    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:43:48.490587
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(new_tree.tree, get_ast(expected_code))
    assert to_code(new_tree.tree) == expected_code

# Generated at 2022-06-18 00:43:55.496341
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert tree_changed.changed
    assert len(tree_changed.errors) == 0

    tree_changed = generate_code(tree_changed.tree)
    assert tree_changed == 'a = 10'

# Generated at 2022-06-18 00:44:04.379015
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = None'

# Generated at 2022-06-18 00:44:14.172209
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code

# Generated at 2022-06-18 00:44:16.997395
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert code == compile(tree, '', 'exec')

# Generated at 2022-06-18 00:44:27.947873
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("a: int = 10\nb: int")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None
    assert result.tree_changed is True
    assert result.warnings == []

    # Test 2
    tree = ast.parse("a: int = 10\nb: int = 20")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value.n == 20
    assert result.tree_changed is True
    assert result.warnings == []

    # Test 3

# Generated at 2022-06-18 00:44:37.617294
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:44:54.214959
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(tree) == '''Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), AnnAssign(target=Name(id='b', ctx=Store()), annotation=Name(id='int', ctx=Load()), value=None, simple=1)])'''

# Generated at 2022-06-18 00:44:58.314749
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transform

    tree = ast.parse("""
a: int = 10
b: int
    """)

    expected = ast.parse("""
a = 10
    """)

    assert_transform(VariablesAnnotationsTransformer, tree, expected)

# Generated at 2022-06-18 00:45:03.461648
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:45:09.332830
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''

    tree = parse_to_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:45:15.618660
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
a: int = 10
b: int
c: int = 20
    '''
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)

    expected_code = '''
a = 10
c = 20
    '''
    expected_tree = parse_ast(expected_code)

    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:45:24.087023
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:29.482080
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    expected_tree = get_ast("""
    a = 10
    """)

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree.tree, expected_tree)

# Generated at 2022-06-18 00:45:33.526788
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_ast_from_text
    from ..utils.tree import compare_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    expected_tree = get_ast_from_text('''
    a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:45:36.599509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree)

    assert len(find_all(tree, ast.AnnAssign)) == 0
    assert len(find_all(tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:45:47.637294
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:10.427900
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:46:20.526978
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations_transformer import VariablesAnnotationsTransformer
    from ..utils.helpers import get_ast
    import astor
    import sys
    import os
    import astunparse
    import io
    import sys
    import astor
    import os
    import astunparse
    import io
    import sys
    import astor
    import os
    import astunparse
    import io
    import sys
    import astor
    import os
    import astunparse
    import io
   

# Generated at 2022-06-18 00:46:29.973095
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import get_ast_str
    from ..utils.tree import get_ast_code
    from ..utils.tree import get_ast_code_no_ws
    from ..utils.tree import get_ast_code_no_ws_no_nl
    from ..utils.tree import get_ast_code_no_ws_no_nl_no_semicolon
    from ..utils.tree import get_ast_code_no_ws_no_nl_no_semicolon_no_colon
    from ..utils.tree import get_ast_code_no_ws_no_nl_no_semicolon_no_colon_no_comma

# Generated at 2022-06-18 00:46:36.686523
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert new_tree.tree.body[0].value.n == 10
    assert new_tree.tree.body[1].value is None

# Generated at 2022-06-18 00:46:40.840280
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import get_test_case
    from ..utils.tree import get_ast

    test_case = get_test_case(__file__, 'test_VariablesAnnotationsTransformer.py')
    tree = get_ast(test_case)

    expected_tree = get_ast(test_case, '_expected')

    assert_transformation_result(VariablesAnnotationsTransformer, tree, expected_tree)

# Generated at 2022-06-18 00:46:50.701908
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:51.953349
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_ast
    from ..utils.tree import compare_ast


# Generated at 2022-06-18 00:46:55.520842
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:47:03.018132
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:47:07.665995
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_ast

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    print_tree(tree)
    VariablesAnnotationsTransformer.transform(tree)
    print_tree(tree)
    assert code == print_tree(tree)

# Generated at 2022-06-18 00:47:51.634414
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_ast

    code = """
    a: int = 10
    b: int
    """

    expected_code = """
    a = 10
    """

    tree = parse_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert_equal_ast(tree, expected_code)

# Generated at 2022-06-18 00:47:54.528843
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
a: int = 10
b: int
""")
    expected_tree = ast.parse("""
a = 10
""")
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-18 00:48:02.436910
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.tree import find_all
    from ..utils.tree import find_all_ast_types
    from ..utils.tree import find_all_ast_types_and_names
    from ..utils.tree import find_all_ast_types_and_names_and_values
    from ..utils.tree import find_all_ast_types_and_names_and_values_and_targets
    from ..utils.tree import find_all_ast_types_and_names_and_values_and_targets_and_orelse
    from ..utils.tree import find_all_ast_types_and_names_and_values_and_targets_and_orelse_and_finalbody

# Generated at 2022-06-18 00:48:06.257891
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:48:12.574868
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_test_data
    from ..utils.tree import parse_ast
    from ..utils.codegen import to_source

    source = get_test_data('test_variables_annotations.py')
    tree = parse_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_source(new_tree.tree) == source

# Generated at 2022-06-18 00:48:20.983129
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..exceptions import NodeNotFound

    source = source_to_unicode('''
    a: int = 10
    b: int
    ''')
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree,
                       get_ast('''
                       a = 10
                       '''))

    source = source_to_unicode('''
    a: int = 10
    b: int
    ''')
    tree = get_ast(source)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare

# Generated at 2022-06-18 00:48:25.344030
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = get_ast(source)
    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    assert to_code(tree) == expected

# Generated at 2022-06-18 00:48:28.845754
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:48:34.067297
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    expected_tree = get_ast('''
        a = 10
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert compare_trees(result.tree, expected_tree)

# Generated at 2022-06-18 00:48:39.023911
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)

    assert to_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:50:20.546199
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:50:26.205078
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    assert to_code(tree) == '''
    a: int = 10
    b: int
    '''

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:50:30.145751
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert str(tree) == "a = 10\n"

# Generated at 2022-06-18 00:50:31.563695
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:50:35.735897
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

    tree = get_ast('a: int')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a'

# Generated at 2022-06-18 00:50:40.628330
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value == None
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[1].targets[0].id == 'b'
    assert result.tree.body[0].type_comment == 'int'
    assert result.tree.body[1].type_comment == 'int'
    assert result.tree.body[0].__class__.__name__ == 'Assign'
    assert result.tree.body[1].__

# Generated at 2022-06-18 00:50:49.987373
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:50:57.790538
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source_without_comments

    tree = get_ast('a: int = 10')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert get_source(tree) == get_source_without_comments('a = 10')
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

    tree = get_ast('a: int')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert get_source(tree) == get_source_without_comments('a')
    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:51:04.782575
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_type_name
    from ..utils.visitor import NodeVisitor
    from ..utils.source import get_source

    tree = get_ast(get_source('3.5', 'variables_annotations'))
    assert tree is not None

    class TestVisitor(NodeVisitor):
        def visit_AnnAssign(self, node: ast.AnnAssign):
            raise Exception('AnnAssign node should not be present')

    TestVisitor().visit(tree)

    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree is not None


# Generated at 2022-06-18 00:51:06.566889
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    code = """
a: int = 10
b: int
"""
    tree = get_ast(code)
    assert VariablesAnnotationsTransformer.transform(tree).tree_changed