

# Generated at 2022-06-18 00:41:23.182922
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_as_string
    from ..utils.tree import get_ast
    from ..utils.helpers import get_node_as_string
    from ..utils.tree import get_ast

    code = '''
a: int = 10
b: int
    '''
    tree = get_ast(code)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert get_node_as_string(result.tree) == '''
a = 10
    '''

# Generated at 2022-06-18 00:41:26.681829
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int = 10')) == TransformationResult(ast.parse('a = 10'), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse('a: int')) == TransformationResult(ast.parse(''), True, [])

# Generated at 2022-06-18 00:41:31.815768
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    expected_tree = get_ast('''
        a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:41:38.443715
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_type_and_name

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    expected_tree = get_ast('''
    a = 10
    ''')

    VariablesAnnotationsTransformer.transform(tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:41:48.555288
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = parse_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(new_tree.tree, parse_ast(expected_code))
    assert generate_code(new_tree.tree) == expected_code.strip()
    assert dump(new_tree.tree) == dump(parse_ast(expected_code))
    assert new_tree.tree_changed
    assert new_tree.new_imports == []

# Generated at 2022-06-18 00:41:57.892189
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:59.509393
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:42:05.223449
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import get_ast_diff
    from ..utils.source import Source

    source = Source("""
    a: int = 10
    b: int
    """)
    tree = parse_to_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert get_ast_diff(tree, new_tree) == ""

# Generated at 2022-06-18 00:42:13.883143
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_type
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path

# Generated at 2022-06-18 00:42:24.025749
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # a: int = 10
    # b: int
    # To:
    # a = 10
    # b = None
    code = 'a: int = 10\nb: int'
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=NameConstant(value=None), type_comment=Name(id='int', ctx=Load()))])"

    # Test 2:
    # a: int = 10
    # b: int

# Generated at 2022-06-18 00:42:30.156393
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    code = """
    a: int = 10
    b: int
    """
    tree = parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert code == tree.body[0].value.s  # type: ignore

# Generated at 2022-06-18 00:42:39.604627
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.source import get_source
    from ..utils.source import get_source_and_node
    from ..utils.source import get_source_and_node_and_parent
    from ..utils.source import get_source_and_node_and_parent_and_index
    from ..utils.source import get_source_and_node_and_parent_and_index_and_tree
    from ..utils.source import get_source_and_node_and_parent_and_tree
    from ..utils.source import get_source_and_node_and_tree
    from ..utils.source import get_source_and_tree

# Generated at 2022-06-18 00:42:46.192779
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert compare_ast(tree, generate_code(tree))

# Generated at 2022-06-18 00:42:51.536509
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:43:00.762484
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    expected_tree = get_ast('''
    a = 10
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert compare_ast(tree, expected_tree)
    assert to_code(tree) == to_code(expected_tree)

# Generated at 2022-06-18 00:43:10.644225
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:15.192153
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == "a = 10"

# Generated at 2022-06-18 00:43:26.094790
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:35.824134
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:40.978546
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    tree = ast.parse("""
a: int = 10
b: int
""")
    # When
    result = VariablesAnnotationsTransformer.transform(tree)
    # Then
    assert result.tree_changed
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:43:56.131748
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast
    from ..utils.tree import get_node_at_line

    code = '''
    a: int = 10
    b: int
    '''

    tree = parse_code_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\n'

    code = '''
    a: int = 10
    b: int
    '''

    tree = parse_code_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\n'

    code = '''
    a: int = 10
    b: int
    '''


# Generated at 2022-06-18 00:44:06.288723
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_lineno_col_offset
    from ..utils.tree import find
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import source_to_tokens
    from ..utils.source import tokens_to_source
    from ..utils.source import tokens_to_tree
    from ..utils.source import tree_to_tokens
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_tokens
    from ..utils.source import get_source_from_tokens
    from ..utils.source import get_source_from_tokens
    from ..utils.source import get_source_from

# Generated at 2022-06-18 00:44:11.299810
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast

    code = '''
a: int = 10
b: int
    '''
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:14.597162
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code

    tree = parse('''
        a: int = 10
        b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:24.933052
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_target
    from ..utils.tree import get_node_annotation
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_body
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_body
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_type_comment

# Generated at 2022-06-18 00:44:30.171309
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(tree, get_ast('''
        a = 10
    '''))

# Generated at 2022-06-18 00:44:35.326290
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:44:45.400489
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import get_node_source_code
    from ..utils.source import get_node_source_code_after_transformation
    from ..utils.source import get_node_source_code_before_transformation
    from ..utils.source import get_node_source_code_after_transformation
    from ..utils.source import get_node_source_code_before_transformation
    from ..utils.source import get_node_source_code_after_transformation
    from ..utils.source import get_node_source_code_before_transformation

# Generated at 2022-06-18 00:44:54.766150
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:01.069927
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.compare import compare_asts

    source = """
a: int = 10
b: int
"""
    expected = """
a = 10
"""
    tree = get_ast(source)
    new_tree = VariablesAnnotationsTransformer.transform(tree)

    assert compare_asts(dump_ast(new_tree.tree), expected)

# Generated at 2022-06-18 00:45:14.993219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert astor.to_source(tree) == '''
    a = 10
    '''
    assert len(find_all(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:45:18.528067
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(ast.parse("a = 10\nb: int"), True, [])

# Generated at 2022-06-18 00:45:25.899883
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    #   a: int = 10
    #   b: int
    # To:
    #   a = 10
    #   b = None
    tree = ast.parse("""
a: int = 10
b: int
""")
    expected_tree = ast.parse("""
a = 10
b = None
""")
    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

    # Test 2:
    #   a: int = 10
    #   b: int
    # To:
    #   a = 10
    #   b = None
    tree = ast.parse("""
a: int = 10
b: int
""")
   

# Generated at 2022-06-18 00:45:34.868884
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast_node_by_path
    from ..utils.helpers import get_code
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_code
    from ..utils.tree import get_ast_node_by_path
    from ..utils.helpers import get_code
    from ..utils.tree import get_ast_node_by_path
    from ..utils.helpers import get_code
    from ..utils.tree import get_ast_node_by_path
    from ..utils.helpers import get_code
    from ..utils.tree import get_ast_node_by_path
    from ..utils.helpers import get_code
    from ..utils.tree import get_ast_node_by_path

# Generated at 2022-06-18 00:45:43.362804
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    expected_tree = get_ast('''
    a = 10
    ''')

    assert compare_ast(tree, expected_tree)
    assert len(find(tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:45:50.995996
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import get_node_name
    from ..utils.code_gen import to_source

    code = """
    a: int = 10
    b: int
    """

    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)

    assert to_source(tree) == "a = 10\n"

    node = get_node_of_class(tree, ast.AnnAssign)
    assert node is None

    node = get_node_of_class(tree, ast.Assign)
    assert node is not None
    assert get_node_name(node) == "Assign"

# Generated at 2022-06-18 00:45:58.664317
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:05.986822
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    assert to_code(tree) == "a: int = 10\nb: int"

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)

    assert to_code(tree) == "a = 10"

# Generated at 2022-06-18 00:46:16.998006
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    tree = get_ast('a: int = 10\nb: int')
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:46:20.803565
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''

    tree = parse_to_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:46:41.590665
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast


# Generated at 2022-06-18 00:46:45.952774
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_ast

    tree = load_example_ast('annotations')
    expected = load_example_ast('annotations_expected')

    assert_transformation_result(VariablesAnnotationsTransformer, tree, expected)

# Generated at 2022-06-18 00:46:56.590622
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:59.262184
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert str(tree) == "a = 10"

# Generated at 2022-06-18 00:47:03.346788
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    import astor
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..exceptions import NodeNotFound

    tree = get_ast('a: int = 10\nb: int')
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert astor.to_source(tree).strip() == 'a = 10'

# Generated at 2022-06-18 00:47:05.714391
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code

# Generated at 2022-06-18 00:47:13.162807
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast
    from ..utils.visitor import Visitor

    class TestVisitor(Visitor):
        def visit_AnnAssign(self, node):
            raise Exception('AnnAssign node found')

    tree = parse_to_ast(generate_code(
        '''
        a: int = 10
        b: int
        '''
    ))

    VariablesAnnotationsTransformer.transform(tree)

    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:47:18.134087
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
a: int = 10
b: int
    '''
    expected_code = '''
a = 10
    '''
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(new_tree, get_ast(expected_code))

# Generated at 2022-06-18 00:47:28.295989
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_target
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert get_node_type(tree) == 'Module'

# Generated at 2022-06-18 00:47:36.595142
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:18.999691
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:48:26.970977
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..exceptions import NodeNotFound

    # Test 1
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

    # Test 2
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

    # Test 3
    tree = get_ast("""
    a: int = 10
    b: int
    """)

# Generated at 2022-06-18 00:48:33.362999
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
        a: int = 10
        b: int
    ''')
    tree = get_ast(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:48:42.193571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:49.847499
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import generate_code
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:54.418098
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10'

# Generated at 2022-06-18 00:48:57.134940
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:49:07.076160
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..utils.source import source_to_tree_to_source
    from ..utils.source import tree_to_source_to_tree
    from ..utils.source import source_to_tree_to_source_to_tree
    from ..utils.source import source_to_tree_to_source_to_tree_to_source
    from ..utils.source import source_to_tree_to_source_to_tree_to_source_to_tree
    from ..utils.source import source_to_tree_to_source_to_tree_to_source_to_tree_to

# Generated at 2022-06-18 00:49:12.570446
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_code_to_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    code = generate_code(tree)
    assert code == 'a = 10'

# Generated at 2022-06-18 00:49:14.540724
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:51:02.460973
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    assert len(find_all(tree, ast.AnnAssign)) == 2

    result = VariablesAnnotationsTransformer.transform(tree)

    assert len(find_all(result.tree, ast.AnnAssign)) == 0
    assert len(find_all(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:51:12.893114
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_imports_and_comments
    from ..utils.helpers import get_code_without_comments
    from ..utils.helpers import get_code_without_comments_and_docstrings
    from ..utils.helpers import get_code_without_docstrings
    from ..utils.helpers import get_code_without_docstrings_and_comments
    from ..utils.helpers import get_docstring
    from ..utils.helpers import get_docstrings
    from ..utils.helpers import get_imports
    from ..utils.helpers import get_module_name


# Generated at 2022-06-18 00:51:15.189084
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    tree = ast.parse('a: int = 10')
    transformer = VariablesAnnotationsTransformer()
    assert transformer.transform(tree)
