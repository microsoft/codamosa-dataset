

# Generated at 2022-06-18 00:41:22.244651
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast

    code = '''
a: int = 10
b: int
    '''
    expected_code = '''
a = 10
    '''
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert compare_ast(expected_code, new_tree)

# Generated at 2022-06-18 00:41:30.190033
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:41:40.436081
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_type
    from ..utils.helpers import get_ast_node_value
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset
    from ..utils.helpers import get_ast_node_end_lineno
    from ..utils.helpers import get_ast_node_end_col_offset
    from ..utils.helpers import get_ast_node_parent
    from ..utils.helpers import get_ast_node_parent_index
    from ..utils.helpers import get_ast_node_child_count

# Generated at 2022-06-18 00:41:50.964047
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_type
    from ..utils.tree import find
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .base import TransformationResult
    from .variables_annotations import VariablesAnnotationsTransformer

    # Test for constructor of class VariablesAnnotationsTransformer
    def test_constructor():
        assert VariablesAnnotationsTransformer.target == (3, 5)

    # Test for method transform of class VariablesAnnotationsTransformer
    def test_transform():
        tree = source_to_tree("""
        a: int = 10
        b: int
        """)
        result = VariablesAnnotationsTrans

# Generated at 2022-06-18 00:41:54.494124
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert tree.code == """
    a = 10
    """

# Generated at 2022-06-18 00:42:04.289076
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    expected_tree = ast.parse("""
    a = 10
    """)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(tree) == ast.dump(expected_tree)

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int = 20
    """)
    expected_tree = ast.parse("""
    a = 10
    b = 20
    """)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert ast.dump(tree) == ast.dump(expected_tree)

    # Test 3

# Generated at 2022-06-18 00:42:08.836624
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:19.346846
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast
    from ..utils.tree import compare_source
    from ..utils.tree import compare_source_with_ast
    from ..utils.tree import get_source
    from ..utils.tree import get_source_with_ast
    from ..utils.tree import get_ast_with_source
    from ..utils.tree import get_source_with_ast_and_source
    from ..utils.tree import get_ast_with_source_and_ast
    from ..utils.tree import get_source_with_ast_and_source_and_ast
    from ..utils.tree import get_ast_with_source_and_ast_and_source
    from ..utils.tree import get_source_with

# Generated at 2022-06-18 00:42:29.353783
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_target
    from ..utils.tree import get_node_annotation
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_body
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_value

# Generated at 2022-06-18 00:42:34.892393
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import compare_asts

    code = """
    a: int = 10
    b: int
    """
    expected_code = """
    a = 10
    """
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_asts(to_code(new_tree.tree), expected_code)

# Generated at 2022-06-18 00:42:39.323399
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1: test for the constructor of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.target == (3, 5)

# Generated at 2022-06-18 00:42:46.365823
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_names
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    assert get_node_names(tree) == ['Module', 'AnnAssign', 'AnnAssign']
    VariablesAnnotationsTransformer.transform(tree)
    assert get_node_names(tree) == ['Module', 'Assign', 'AnnAssign']

# Generated at 2022-06-18 00:42:49.040209
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_str

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert to_str(tree) == 'a = 10'

# Generated at 2022-06-18 00:42:50.213120
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:42:58.832613
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import get_source

    code = """
    a: int = 10
    b: int
    """
    tree = parse_code_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, parse_code_to_ast("""
    a = 10
    """))
    assert get_source(tree) == "a = 10"

# Generated at 2022-06-18 00:43:08.320113
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree_changed = False
    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type:

# Generated at 2022-06-18 00:43:10.832951
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer.target == (3, 5)


# Generated at 2022-06-18 00:43:17.051082
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:25.108898
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    code = """
        a: int = 10
        b: int
    """

    expected_code = """
        a = 10
    """

    tree = get_ast(code)
    expected_tree = get_ast(expected_code)

    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)

    assert compare_trees(result.tree, expected_tree)

# Generated at 2022-06-18 00:43:27.538142
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor
    assert VariablesAnnotationsTransformer.target == (3, 5)
    assert VariablesAnnotationsTransformer.transform(None) == TransformationResult(None, False, [])


# Generated at 2022-06-18 00:43:38.866766
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer


    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:47.816616
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:43:56.969423
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import get_ast_str
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import get_ast_str
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from ..utils.tree import get

# Generated at 2022-06-18 00:44:03.427709
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Given
    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    # When
    result = VariablesAnnotationsTransformer.transform(code)
    # Then
    assert result.code == expected_code
    assert result.tree_changed == True
    assert result.warnings == ['Assignment outside of body']

# Generated at 2022-06-18 00:44:09.503725
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_as_string
    from ..utils.tree import get_ast

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_node_as_string(tree) == "a = 10"

# Generated at 2022-06-18 00:44:14.098219
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:44:24.357731
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1
    tree = ast.parse('a: int = 10')
    expected_tree = ast.parse('a = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(expected_tree)
    assert result.tree_changed == True
    assert result.warnings == []

    # Test case 2
    tree = ast.parse('a: int')
    expected_tree = ast.parse('a')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(expected_tree)
    assert result.tree_changed == True
    assert result.warnings == []

    # Test case 3
    tree = ast.parse('a: int = 10\nb: int')
    expected_

# Generated at 2022-06-18 00:44:34.496815
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.visitor import NodeVisitor
    from ..utils.source import get_source

    source = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_source(tree) == 'a = 10\n'

    source = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert get_source(tree) == 'a = 10\n'

    source = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(source)

# Generated at 2022-06-18 00:44:42.123703
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.new_code == ['a = 10']
    assert result.warnings == []

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True

# Generated at 2022-06-18 00:44:45.602596
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert str(tree) == "a = 10"

# Generated at 2022-06-18 00:45:04.546318
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:14.874405
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.compare import compare_ast

    tree = get_ast('''
        a: int = 10
        b: int
    ''')

    tree_changed = VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(dump(tree_changed.tree),
                       '''
        Module(body=[
            Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Str(s='int')),
            Assign(targets=[Name(id='b', ctx=Store())], value=NameConstant(value=None), type_comment=Str(s='int'))
        ])
                       ''')

# Generated at 2022-06-18 00:45:22.192691
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = VariablesAnnotationsTransformer.transform(tree).tree

    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 2

    assert compare_ast(tree, '''
    a = 10
    b = None
    ''')

# Generated at 2022-06-18 00:45:28.140370
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:45:30.421018
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:45:36.289430
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:45:47.278649
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.tree import find_all
    from ..utils.tree import find_all_by_type

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == """
    a = 10
    """

    tree = get_ast("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree) == """
    a = 10
    """

    tree = get_ast("""
    a: int = 10
    b: int = 20
    """)
    tree = Variables

# Generated at 2022-06-18 00:45:56.887597
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:03.257935
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:46:09.449973
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.compare import compare_asts

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    expected_tree = get_ast('''
    a = 10
    ''')

    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert compare_asts(to_code(new_tree.tree), to_code(expected_tree))

# Generated at 2022-06-18 00:46:33.613676
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    code = '''
a: int = 10
b: int
    '''
    tree = ast.parse(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=10), type_comment=Name(id='int', ctx=Load())), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Name(id='int', ctx=Load()))])"

# Generated at 2022-06-18 00:46:38.401849
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == "a = 10"

# Generated at 2022-06-18 00:46:42.664312
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # a: int = 10
    # b: int
    tree = ast.parse('a: int = 10\nb: int')
    # a = 10
    expected_tree = ast.parse('a = 10')
    assert VariablesAnnotationsTransformer.transform(tree).tree == expected_tree

# Generated at 2022-06-18 00:46:47.437280
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast("""
        a: int = 10
        b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(tree.tree) == "a = 10"

# Generated at 2022-06-18 00:46:52.229476
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(new_tree) == 'a = 10'

# Generated at 2022-06-18 00:47:02.165265
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:09.293029
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import get_node_name, get_node_type
    tree = get_ast('''
        a: int = 10
        b: int
    ''')
    transformer = VariablesAnnotationsTransformer()
    tree = transformer.transform(tree)
    assert get_node_name(tree) == 'Module'
    assert get_node_type(tree) == 'Module'
    assert get_node_name(tree.body[0]) == 'Assign'
    assert get_node_type(tree.body[0]) == 'Assign'
    assert get_node_name(tree.body[0].targets[0]) == 'Name'
    assert get_node_type(tree.body[0].targets[0]) == 'Name'


# Generated at 2022-06-18 00:47:19.167033
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import find
    from ..utils.tree import find_all
    from ..utils.tree import find_all_by_type
    from ..utils.tree import find_by_type
    from ..utils.tree import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..utils.tree import node_to_str
    from ..utils.tree import remove_from_parent
    from ..utils.tree import replace_node
    from ..utils.tree import set_parent
    from ..utils.tree import set_parents
    from ..utils.tree import tree_to_str
    from ..utils.tree import visit_tree
    from ..utils.tree import visit_tree_postorder

# Generated at 2022-06-18 00:47:29.381255
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    # Test 1
    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10'

    # Test 2
    code = '''
    a: int = 10
    b: int
    c: int = 20
    '''
    tree = parse_to_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10\nc = 20'

    # Test 3

# Generated at 2022-06-18 00:47:37.490464
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:48:21.959937
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:24.009322
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..exceptions import TransformationError


# Generated at 2022-06-18 00:48:33.107821
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_name
    from ..types import TransformationResult

    # Act
    tree = ast.parse("""
a: int = 10
b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)

    # Assert
    assert result.tree_changed
    assert len(result.warnings) == 0
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1
    assert get_node_name(find(result.tree, ast.Assign)[0].targets[0]) == 'Name'

# Generated at 2022-06-18 00:48:37.112489
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for transform method
    tree = ast.parse("""
a: int = 10
b: int
""")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree == ast.parse("""
a = 10
""")

# Generated at 2022-06-18 00:48:41.821315
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree_changed = VariablesAnnotationsTransformer.transform(tree)

    assert compare_ast(tree_changed.tree, get_ast('''
    a = 10
    '''))

# Generated at 2022-06-18 00:48:46.744119
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = '''
    a: int = 10
    b: int
    '''

    tree = get_ast(code)
    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:48:53.147758
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_code
    from ..utils.tree import get_ast
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.context import Context
    from ..exceptions import TransformationError
    from ..transformers.variables_annotations import VariablesAnnotationsTransformer

    code = get_code('''
    a: int = 10
    b: int
    ''')
    tree = get_ast(code)
    ctx = Context()
    visitor = NodeTransformerVisitor(ctx)
    visitor.visit(tree)
    assert ctx.tree == tree
    assert ctx.code == code
    assert ctx.tree != ast.parse(code)

# Generated at 2022-06-18 00:48:57.085318
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(
        parse("""
    a = 10
    """), True, [])

# Generated at 2022-06-18 00:49:04.817859
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    code = '''
a: int = 10
b: int
    '''
    expected_code = '''
a = 10
    '''
    tree = get_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert compare_ast(to_code(new_tree), expected_code)

# Generated at 2022-06-18 00:49:10.627589
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    tree = get_ast('a: int = 10')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result, TransformationResult)
    assert result.tree_changed == True
    assert result.new_nodes == []
    assert find(result.tree, ast.AnnAssign) == []
    assert find(result.tree, ast.Assign) != []

# Generated at 2022-06-18 00:51:01.993757
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:51:12.579423
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source

# Generated at 2022-06-18 00:51:17.823022
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 2