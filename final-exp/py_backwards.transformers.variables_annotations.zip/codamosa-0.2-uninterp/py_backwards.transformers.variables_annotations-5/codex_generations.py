

# Generated at 2022-06-18 00:41:26.842726
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.tree import parse
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
    a: int = 10
    b: int
    ''')

    expected = source_to_unicode('''
    a = 10
    ''')

    tree = parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert_equal_ast(result.tree, expected)

# Generated at 2022-06-18 00:41:33.332743
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_node_by_path
    from ..utils.helpers import get_code
    from ..utils.source import Source
    from ..utils.context import Context
    from ..exceptions import NodeNotFound

    source = Source("""
    def foo(a: int = 10, b: int) -> int:
        return a + b
    """)
    context = Context(source)
    tree = context.tree

    # Test for constructor of class VariablesAnnotationsTransformer
    transformer = VariablesAnnotationsTransformer()
    assert transformer.target == (3, 5)

    # Test for method transform
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.messages == []

    # Test for method

# Generated at 2022-06-18 00:41:36.771263
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == parse("""
    a = 10
    """)

# Generated at 2022-06-18 00:41:41.951702
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree).tree
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:41:52.614327
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int\n")) == TransformationResult(ast.parse("a = 10"), True, [])

# Generated at 2022-06-18 00:42:00.227505
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=10, kind=None), type_comment=Constant(value='int', kind=None)), Assign(targets=[Name(id='b', ctx=Store())], value=None, type_comment=Constant(value='int', kind=None))])"

# Generated at 2022-06-18 00:42:08.197511
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..utils.helpers import get_node_type
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import Vari

# Generated at 2022-06-18 00:42:18.531260
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..exceptions import NodeNotFound
    from ..types import TransformationResult
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

    source = '''
    a: int = 10
    b: int
    '''
    tree = parse(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0
    assert len(find(result.tree, ast.AnnAssign)) == 0

# Generated at 2022-06-18 00:42:28.473957
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:42:32.911137
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_to_ast

    tree = parse_to_ast("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert generate_code(result.tree) == 'a = 10\n'

# Generated at 2022-06-18 00:42:43.129147
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    import astunparse
    import astor
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astun

# Generated at 2022-06-18 00:42:46.908171
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1:
    # Test for the constructor of class VariablesAnnotationsTransformer
    # Input:
    #   - None
    # Output:
    #   - An instance of class VariablesAnnotationsTransformer
    assert VariablesAnnotationsTransformer() is not None


# Generated at 2022-06-18 00:42:53.030086
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:42:59.028571
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    result = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(result) == """
    a = 10
    """

# Generated at 2022-06-18 00:43:08.481565
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_as_string
    from ..utils.tree import get_node_by_path
    from ..utils.tree import get_node_by_path_and_check_type
    from ..utils.tree import get_node_by_path_and_check_type_and_value
    from ..utils.tree import get_node_by_path_and_check_type_and_value_and_annotation
    from ..utils.tree import get_node_by_path_and_check_type_and_value_and_annotation_and_target
    from ..utils.tree import get_node_by_path_and_check_type_and_value_and_annotation_and_target_and_ctx
    from ..utils.tree import get_node_by_path_and_check_type

# Generated at 2022-06-18 00:43:12.241528
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    VariablesAnnotationsTransformer.transform(tree)

    assert tree == parse("""
    a = 10
    """)

# Generated at 2022-06-18 00:43:15.951994
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10")) == TransformationResult(ast.parse("a = 10"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int")) == TransformationResult(ast.parse(""), True, [])

# Generated at 2022-06-18 00:43:26.926226
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_type_name
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import get_node_type_name
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type_name
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type_name
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type_name
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type_name
    from ..utils.tree import get_node_name
    from ..utils.tree import get_node_type_name

# Generated at 2022-06-18 00:43:32.277499
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    tree = get_ast('''
a: int = 10
b: int
''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(result.tree) == 'a = 10\n'

# Generated at 2022-06-18 00:43:36.901529
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.compare import compare_asts
    from ..utils.source import Source
    from ..exceptions import InvalidInput

    source = Source('''
    a: int = 10
    b: int
    ''')
    expected_tree = get_ast('''
    a = 10
    ''')

    tree = get_ast(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert compare_asts(result.new_tree, expected_tree)
    assert to_code(result.new_tree) == to_code(expected_tree)

    source = Source('''
    a: int = 10
    b: int
    ''')
    expected

# Generated at 2022-06-18 00:43:46.636054
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.helpers import get_ast_from_code
    from ..utils.tree import to_code

    code = '''
    a: int = 10
    b: int
    '''
    tree = get_ast(code)
    new_tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_code(new_tree.tree) == '''
    a = 10
    '''

# Generated at 2022-06-18 00:43:56.273446
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNot

# Generated at 2022-06-18 00:44:04.492375
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test case 1
    tree = ast.parse("""
a: int = 10
b: int
    """)
    expected = ast.parse("""
a = 10
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected

    # Test case 2
    tree = ast.parse("""
a: int = 10
b: int
    """)
    expected = ast.parse("""
a = 10
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree == expected

# Generated at 2022-06-18 00:44:11.143018
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = parse('''
    def foo():
        a: int = 10
        b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == '''
    def foo():
        a = 10
    '''

# Generated at 2022-06-18 00:44:14.990452
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import ast_to_str

    code = """
        a: int = 10
        b: int
    """
    tree = parse_code_to_ast(code)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert ast_to_str(tree) == "a = 10"

# Generated at 2022-06-18 00:44:19.863094
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('a: int = 10')
    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)
    assert to_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:44:30.313032
# Unit test for constructor of class VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:44:39.412719
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.tree import find_all
    from ..utils.tree import find_all_by_type
    from ..utils.tree import find_all_by_name
    from ..utils.tree import find_all_by_type_and_name
    from ..utils.tree import find_all_by_type_and_attr
    from ..utils.tree import find_all_by_type_and_attr_value
    from ..utils.tree import find_all_by_type_and_attr_value_and_name
    from ..utils.tree import find_all_by_type_and_attr_value_and_attr
    from ..utils.tree import find_all_by_type_and_attr_value_and_attr_value

# Generated at 2022-06-18 00:44:46.353109
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)

    assert result.tree_changed
    assert len(result.messages) == 0
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 2

# Generated at 2022-06-18 00:44:55.373607
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:45:10.222701
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import print_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    print_ast(tree)
    print(to_code(tree))
    print(to_code(VariablesAnnotationsTransformer.transform(tree).tree))

# Generated at 2022-06-18 00:45:17.649887
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_ast
    from ..utils.tree import find
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_non_exp_parent_and_index
    from ..types import TransformationResult
    from .base import BaseTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer
    from .variables_annotations import VariablesAnnotationsTransformer

# Generated at 2022-06-18 00:45:22.573890
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == 'a = 10\n'

# Generated at 2022-06-18 00:45:28.528256
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = get_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(expected_code, tree)

# Generated at 2022-06-18 00:45:36.413062
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    a: int = 10
    b: int
    """)

    tree_changed = False

    for node in find(tree, ast.AnnAssign):
        try:
            parent, index = get_non_exp_parent_and_index(tree, node)
        except NodeNotFound:
            warn('Assignment outside of body')
            continue

        tree_changed = True
        parent.body.pop(index)  # type: ignore


# Generated at 2022-06-18 00:45:47.439162
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.helpers import get_code
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_ctx
    from ..utils.helpers import get_node_parent
    from ..utils.helpers import get_node_children
    from ..utils.helpers import get_node_attr

# Generated at 2022-06-18 00:45:52.105379
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    a: int = 10
    b: int
    """
    tree = get_ast(code)
    NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:45:59.480889
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test for constructor of class VariablesAnnotationsTransformer
    tree = ast.parse("a: int = 10\nb: int")
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.AnnAssign)
    assert isinstance(tree.body[1], ast.AnnAssign)
    assert isinstance(tree.body[0].target, ast.Name)
    assert isinstance(tree.body[0].target.ctx, ast.Store)
    assert isinstance(tree.body[0].target.id, str)
    assert isinstance(tree.body[0].annotation, ast.Name)
    assert isinstance(tree.body[0].annotation.ctx, ast.Load)
    assert isinstance(tree.body[0].annotation.id, str)
    assert isinstance

# Generated at 2022-06-18 00:46:07.534545
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import get_test_case_parser
    from ..utils.tree import get_ast

    parser = get_test_case_parser()
    test_cases = parser.get_test_cases_for_transform(VariablesAnnotationsTransformer)

    for test_case in test_cases:
        tree = get_ast(test_case.before)
        result = VariablesAnnotationsTransformer.transform(tree)
        assert_transformation_result(test_case, result)

# Generated at 2022-06-18 00:46:14.599176
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(find_all(result.tree, ast.AnnAssign)) == 0
    assert len(find_all(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:46:40.745411
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_code_to_ast
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''
    tree = parse_code_to_ast(code)
    new_tree = NodeTransformerVisitor(VariablesAnnotationsTransformer).visit(tree)
    assert compare_ast(new_tree, parse_code_to_ast(expected_code))
    assert generate_code(new_tree) == expected_code

# Generated at 2022-06-18 00:46:50.640894
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:46:57.545551
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.source import get_source
    from ..utils.source import get_source

    tree = get_ast(get_source('a: int = 10'))
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 1

    tree = get_ast(get_source('a: int'))
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert len(find(tree, ast.AnnAssign)) == 0
    assert len(find(tree, ast.Assign)) == 0

# Generated at 2022-06-18 00:47:04.077995
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent_source

    source = dedent_source("""
    def foo(a: int = 10, b: int):
        pass
    """)

    expected_source = dedent_source("""
    def foo(a = 10, b):
        pass
    """)

    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    generated_code = generate_code(tree)
    compare_ast(generated_code, expected_source)

# Generated at 2022-06-18 00:47:08.285295
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast('''
    a: int = 10
    b: int
    ''')

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []

    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1] is None

# Generated at 2022-06-18 00:47:19.007306
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:47:24.285185
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_ast
    from ..utils.helpers import get_source

    source = get_source(VariablesAnnotationsTransformer)
    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    assert compare_ast(tree, get_ast(source))

# Generated at 2022-06-18 00:47:33.818227
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from typed_ast import ast3 as ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..utils.helpers import warn
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)


# Generated at 2022-06-18 00:47:43.583411
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find, get_non_exp_parent_and_index, insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer

    class VariablesAnnotationsTransformer(BaseTransformer):
        """Compiles:
            a: int = 10
            b: int
        To:
            a = 10

        """
        target = (3, 5)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False


# Generated at 2022-06-18 00:47:51.205962
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..types import TransformationResult

    tree = get_ast('''
    a: int = 10
    b: int
    ''')
    result = VariablesAnnotationsTransformer.transform(tree)
    assert isinstance(result, TransformationResult)
    assert len(find(result.tree, ast.AnnAssign)) == 0
    assert len(find(result.tree, ast.Assign)) == 1

# Generated at 2022-06-18 00:48:35.084812
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    assert VariablesAnnotationsTransformer.transform(tree) == TransformationResult(get_ast("""
    a = 10
    """), True, [])

# Generated at 2022-06-18 00:48:44.134543
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int")) == TransformationResult(ast.parse("a = 10\nb: int"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int\n")) == TransformationResult(ast.parse("a = 10\nb: int\n"), True, [])
    assert VariablesAnnotationsTransformer.transform(ast.parse("a: int = 10\nb: int\n\n")) == TransformationResult(ast.parse("a = 10\nb: int\n\n"), True, [])

# Generated at 2022-06-18 00:48:49.668182
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_code
    from ..utils.source import dedent

    source = dedent('''
    a: int = 10
    b: int
    ''')

    expected_source = dedent('''
    a = 10
    ''')

    tree = get_ast(source)
    VariablesAnnotationsTransformer.transform(tree)
    generated_code = generate_code(tree)
    assert compare_ast(get_ast(expected_source), get_ast(generated_code))

# Generated at 2022-06-18 00:48:54.678293
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse

    tree = parse("""
    a: int = 10
    b: int
    """)

    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.n == 10
    assert result.tree.body[1].value is None

# Generated at 2022-06-18 00:48:59.705461
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import compare_trees

    code = '''
    a: int = 10
    b: int
    '''
    expected_code = '''
    a = 10
    '''

    tree = get_ast(code)
    expected_tree = get_ast(expected_code)

    transformer = VariablesAnnotationsTransformer()
    result = transformer.transform(tree)

    assert compare_trees(result.tree, expected_tree)

# Generated at 2022-06-18 00:49:02.577924
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    tree = ast.parse("a: int = 10\nb: int")
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.tree == ast.parse("a = 10")

# Generated at 2022-06-18 00:49:06.412671
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.tree import parse_ast

    code = '''
    a: int = 10
    b: int
    '''
    tree = parse_ast(code)
    VariablesAnnotationsTransformer.transform(tree)
    assert generate_code(tree) == 'a = 10'

# Generated at 2022-06-18 00:49:11.922237
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast
    from ..utils.tree import find
    from ..utils.compare import compare_ast
    from ..utils.source import generate_source

    source = '''
    a: int = 10
    b: int
    '''
    expected = '''
    a = 10
    '''
    tree = get_ast(source)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0
    assert compare_ast(generate_source(result.tree), expected)

# Generated at 2022-06-18 00:49:18.473417
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    # Test 1
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.tree == ast.parse("""
    a = 10
    """)

    # Test 2
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_changed
    assert result.tree == ast.parse("""
    a = 10
    """)

    # Test 3
    tree = ast.parse("""
    a: int = 10
    b: int
    """)
    result = VariablesAnnotationsTransformer.transform(tree)
    assert result.tree_

# Generated at 2022-06-18 00:49:22.880294
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import to_str
    tree = parse("""
    a: int = 10
    b: int
    """)
    tree = VariablesAnnotationsTransformer.transform(tree)
    assert to_str(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:51:06.268545
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_code
    from ..utils.visitor import NodeTransformerVisitor

    tree = get_ast("""
    a: int = 10
    b: int
    """)

    visitor = NodeTransformerVisitor(VariablesAnnotationsTransformer)
    visitor.visit(tree)

    assert to_code(tree) == """
    a = 10
    """

# Generated at 2022-06-18 00:51:13.863636
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse_code_to_ast
    from ..utils.tree import find
    from ..utils.helpers import get_non_exp_parent_and_index
    from ..utils.tree import insert_at
    from ..types import TransformationResult
    from ..exceptions import NodeNotFound
    from .base import BaseTransformer
    from .VariablesAnnotationsTransformer import VariablesAnnotationsTransformer

    tree = parse_code_to_ast("""
    a: int = 10
    b: int
    """)

    tree_changed = False


# Generated at 2022-06-18 00:51:20.994172
# Unit test for constructor of class VariablesAnnotationsTransformer
def test_VariablesAnnotationsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_node_name
    from ..utils.tree import get_node_type
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_target
    from ..utils.tree import get_node_annotation
    from ..utils.tree import get_node_value
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_targets
    from ..utils.tree import get_node_body
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type_comment
    from ..utils.tree import get_node_type_comment