

# Generated at 2022-06-23 11:28:44.053748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventories = InventoryManager(loader=loader, sources=['tests/fixtures/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventories)
    play_source = dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("fileglob","*/test*.yml") }}')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 11:28:55.010566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModule_run(object):
        def __init__(self, module_args=None, **kwargs):
            self.module_args = module_args
            self.params = {'wantlist': True}
            self.basedir = 'foo'
            self.noop = False
            self.args = ['foo.txt', 'bar.txt']
            self.ds = []

    class Ansvar(object):
        def get(self, arg, arg1):
            return arg1

    ansvar = Ansvar()

    inst = LookupModule_run()
    inst.get_basedir = LookupModule.get_basedir
    inst.find_file_in_search_path = LookupModule.find_file_in_search_path
    inst.ds = ansvar

# Generated at 2022-06-23 11:29:05.526443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    lookup_module = LookupModule()
    current_working_directory = os.getcwd()
    temp_folder = tempfile.mkdtemp()
    os.chdir(temp_folder)
    try:
        lookup_module.set_options(direct=dict(key='value'))
        filepath = os.path.join(temp_folder, 'file')
        open(filepath, 'w').close()
        ret = lookup_module.run(['file'], {'ansible_search_path': [temp_folder]})
        assert ret == [filepath]
        ret = lookup_module.run(['file'])
        assert ret == [filepath]
        ret = lookup_module.run(['nothing'])
        assert ret == []
    finally:
        os.ch

# Generated at 2022-06-23 11:29:07.509844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(['/ansible/test/data/ansible_fileglob/*.yaml'])


# Generated at 2022-06-23 11:29:09.386861
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:29:13.689000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import ansible.plugins
    loader = ansible.plugins.loader.LookupModuleLoader()
    lookup_instance = loader.get('fileglob', basedir=os.getcwd(), runner=None, registry=None)
    assert isinstance(lookup_instance, LookupModule) == True

# Generated at 2022-06-23 11:29:24.474811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestVars(object):
        def __init__(self, ansible_search_path=[]):
            self.ansible_search_path = ansible_search_path

    def get_basedir_mock(self, variables):
        return "/foo/bar/baz"

    lookup = LookupModule()

    arguments = ["*.txt"]
    assertions = [
        "/foo/bar/baz/roles/my_role/files/my_globbed_file.txt"
    ]

    real_glob = glob.glob

    # Mock the glob.glob call
    def glob_mock(path):
        return assertions

    glob.glob = glob_mock

    # Mock get_basedir

# Generated at 2022-06-23 11:29:30.411509
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # First, check if this creates correctly an object of the class LookupModule
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert isinstance(lm, LookupBase)

    # Check if the run method of the class LookupModule is correct
    # If a file is found, it returns a list with one element, the absolute path of the file.
    # The path is a string.
    # If a file is not found it returns an empty list.
    ret = lm.run(['fileglob_test.py'])
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert isinstance(ret[0], str)
    assert (ret[0] == os.path.abspath('fileglob_test.py'))
    # If the file is

# Generated at 2022-06-23 11:29:31.359391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:29:34.312736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(AnsibleFileNotFound):
        terms = ['/etc/passwd']
        LookupModule().run(terms, variables=None)

# Generated at 2022-06-23 11:29:35.117514
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:29:38.517557
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # returns the LookupModule class
    cls = LookupModule(*[None],**{})
    assert isinstance(cls, LookupModule)
    # returns the LookupBase class
    cls = LookupBase(*[None],**{})
    assert isinstance(cls, LookupBase)

# Generated at 2022-06-23 11:29:48.811029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dwim = 'dwimmed_path'
    term_file = 'term_file'
    results = [
        os.path.join(dwim, term_file),
        os.path.join(dwim, os.path.join('sub', term_file)),
    ]

    class MockedGlob(object):
        def glob(self, pattern):
            return results

    mock_glob = MockedGlob()

    class MockedLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, alias, paths):
            return dwim

        def get_basedir(self, variables):
            return dwim

        def __getattribute__(self, name):
            if name == 'glob':
                return mock_glob.glob
            return object.__

# Generated at 2022-06-23 11:29:53.100694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(["*.txt"], variables={"ansible_search_path": [os.path.dirname(__file__)]})
    assert results == [os.path.join(os.path.dirname(__file__), "needle.txt")]

# Generated at 2022-06-23 11:29:54.706443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin != None
    assert lookup_plugin.run != None

# Generated at 2022-06-23 11:29:55.968576
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert lookup_module != None



# Generated at 2022-06-23 11:29:57.876732
# Unit test for constructor of class LookupModule
def test_LookupModule():
  try:
    lookup = LookupModule()
    assert True
  except:
    assert False

# Generated at 2022-06-23 11:29:58.831332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:30:04.416496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for run method of class LookupModule
    # Returns a string list of paths joined by commas,
    # or an empty list if no file is found

    test_var_type = "fileglob"
    test_var_value = "path/to/the/file"
    test_var_value_2 = "path/to/the/other/file"
    test_var_value_3 = "some/*/path/to/other/file"

    # Passing case for empty argument
    result = LookupModule().run( [], dict() )
    assert type(result) is list
    assert len(result) == 0

    # Passing case for valid argument
    result = LookupModule().run( [test_var_value], dict() )
    assert type(result) is list
    assert len(result) == 0



# Generated at 2022-06-23 11:30:10.260931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['/tmp/*']) == []
    assert LookupModule().run(['/tmp/*.tmp']) == []
    assert LookupModule().run(['/tmp/*.tmp', '/tmp/*']) == []
    assert LookupModule().run(['/tmp/*.tmp', '/tmp/*']) == []
    assert LookupModule().run(['/tmp/*.tmp', '/tmp/*']) == []

# Generated at 2022-06-23 11:30:15.594411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['abc', 'xyz'], {'abc': 'pqr', 'xyz': 'qux'}, wantlist=True) == ['pqr', 'qux']

# Generated at 2022-06-23 11:30:17.102639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:30:17.698794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:30:25.976149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: The following functions/variables are not tested:
    #         - find_file_in_search_path
    #         - get_basedir
    import os
    import glob
    import shutil
    import tempfile
    from ansible.plugins.lookup import LookupBase

    class DummyVariables(object):
        def __init__(self):
            self.path = os.path.abspath(os.path.join(os.getcwd(), 'lookup_plugins', 'tests', 'files'))
            self.files_path = os.path.join(self.path, 'files')
            self.files_path2 = os.path.join(self.path, 'files2')
            self.files_path3 = os.path.join(self.path, 'files3')
            self.files

# Generated at 2022-06-23 11:30:31.612597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # Test to see if lookup_module is a instance of the class LookupBase
    assert isinstance(lookup_module, LookupBase)
    # Test to see if lookup_module is a instance of the class LookupModule
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:30:42.974546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    b_spath = to_bytes(os.path.dirname(__file__), errors='surrogate_or_strict')
    b_file = to_bytes('../../lookup_plugins/fileglob.py', errors='surrogate_or_strict')
    b_ret = to_bytes(os.path.join(b_spath, b_file), errors='surrogate_or_strict')
    b_term = to_bytes('../../lookup_plugins/fileglob.py', errors='surrogate_or_strict')

    lu = LookupModule()
    ret = lu.run([b_term], variables={'ansible_search_path': [b_spath]})

# Generated at 2022-06-23 11:30:54.641230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create an instance of LookupModule
    my_lookup = LookupModule()

    # create a fake variable 'ansible_search_path' in variables dictionary
    fake_variables = {'ansible_search_path':['/tmp/dummy/']}

    # create a dictionary with fake parameters
    # real parameters are '_raw_params', 'variables', and 'wantlist'
    fake_parameters = {'_raw_params':'test.file', 'variables':fake_variables, 'wantlist':False}

    # create a dummy file and store it in /tmp/dummy/test.file
    open('/tmp/dummy/test.file', 'w').close()

    # execute the run method - it should return a list of all test.file(s) in /tmp/dummy/
    list_of

# Generated at 2022-06-23 11:30:57.748268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/ansible/files/test.txt']
    variables = dict()
    variables['ansible_search_path'] = ['/ansible/files', '/ansible/files/files']
    obj = LookupModule()
    assert obj.run(terms, variables) == terms

# Generated at 2022-06-23 11:31:02.185043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['/home/mqtt/scripts/*.sh']
    result = module.run(terms, variables={'ansible_env': {'ANSIBLE_LOOKUP_PLUGINS': 'ansible/plugins/lookup'}})
    assert result == ['/home/mqtt/scripts/ansible.sh'], result

# Generated at 2022-06-23 11:31:02.731570
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:31:07.304644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [u"test.txt", u"/home/user/test.txt", u"/home/user/test*.txt"]
    result = lookup_module.run(terms)
    print("Result: %s" % result)

# Generated at 2022-06-23 11:31:08.309754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 11:31:13.986618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # _lookup_plugin_cache initialized in ansible/plugins/__init__.py
    # if 'fileglob' not in _lookup_plugin_cache:
    #    _lookup_plugin_cache['fileglob'] = LookupModule()
    # lookup_plugin_cache['fileglob'].run(terms)
    assert False

# Generated at 2022-06-23 11:31:21.238656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    lookup_module = LookupModule()
    terms = [to_text('fileglob.yml'), to_text('fileglob.py')]
    # mocked glob.glob function which always return something
    def glob_mock(path):
        return [to_bytes('mock'), to_bytes('mock')]
    builtins.glob = glob_mock
    # mocked os.path.isfile function which always return True
    def isfile_mock(path):
        return True
    builtins.os.path.isfile = isfile_mock
    # mocked os.path.basename function which always return something

# Generated at 2022-06-23 11:31:23.994843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test 1: no file
    # test 2: file with no directory
    # test 3: file with directory

# Generated at 2022-06-23 11:31:34.745861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    import os
    import sys
    import unittest
    import ansible.parsing.vault

    if sys.version_info.major == 2:
        FILEDIR = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'plugins', 'lookup', 'test')
    else:
        FILEDIR = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'plugins', 'lookup', 'test')


# Generated at 2022-06-23 11:31:36.161784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lkup = LookupModule()
    assert isinstance(lkup, LookupModule)


# Generated at 2022-06-23 11:31:37.041238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:31:39.415363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_result = LookupModule().run(['./sample.txt'], {}, wantlist=True)
    assert lookup_result == ['./sample.txt']

# Generated at 2022-06-23 11:31:45.762899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor
    module_name = 'fileglob'
    if module_name not in LookupBase.lookup_loader:
        raise AssertionError('Lookup plugin "%s" not found in lookup plugin path' % module_name)
    lookup_plugin_class = LookupBase.lookup_loader.get(module_name)
    lm = lookup_plugin_class()
    assert lm._loader is not None
    assert lm._templar is not None


# Generated at 2022-06-23 11:31:56.769005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Creates a test environment with a file and tests the file is detected
    """
    import tempfile
    import os
    import shutil
    import AnsibleModule

    tmpdir = tempfile.mkdtemp()
    test_path = os.path.join(tmpdir, "test.txt")
    open(test_path, 'a').close()

    assert os.path.isfile(test_path)

    module = AnsibleModule.AnsibleModule(argument_spec={})
    lu_obj = LookupModule()

    result = lu_obj.run([test_path], dict(file_root=tmpdir), wantlist=True)

    shutil.rmtree(tmpdir)

    assert len(result) == 1
    assert result == [test_path]


# Generated at 2022-06-23 11:32:05.058186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    v = {}
    v['ansible_basedir'] = '/home/'
    v['ansible_search_path'] = []
    v['ansible_search_path'].append('/home/')
    v['ansible_search_path'].append('/home/files')
    v['hostvars'] = {}

    look = LookupModule()
    res = look.run(['*'], v)

    assert res == []

    lookup_result1 = [u'sample1.txt', u'file1.txt']
    lookup_result2 = [u'file1.txt']
    lookup_result3 = []
    lookup_result4 = [u'file1.txt']

    v['ansible_search_path'] = []
    v['ansible_search_path'].append('/home/')


# Generated at 2022-06-23 11:32:14.014823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["*.txt"], variables={
        'ansible_search_path': ['/']
    }) == []
    assert lookup.run(["/etc/*.conf"], variables={
        'ansible_search_path': ['/']
    }) == ["/etc/hosts.conf"]
    assert lookup.run(["/etc/hosts.conf", "/etc/*.conf"], variables={
        'ansible_search_path': ['/']
    }) == ["/etc/hosts.conf", "/etc/hosts.conf"]

# Generated at 2022-06-23 11:32:22.604864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda x: '.'
    terms = ['file1', 'file2']
    variables = {'ansible_search_path': '/dir1'}
    ret = l.run(terms, variables)
    assert len(ret) == 2
    assert ret[0] == './file1'
    assert ret[1] == './file2'
    variables['ansible_search_path'] = '/dir2'
    ret = l.run(terms, variables)
    assert len(ret) == 2
    assert ret[0] == './file1'
    assert ret[1] == './file2'

# Generated at 2022-06-23 11:32:23.365989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.run([], [])
    assert True

# Generated at 2022-06-23 11:32:23.866551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:32:31.590112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange
    print("Testing run method of LookupModule")
    basedir = "/Users/kongweikun/Documents/DevOps/Admin/ansible_admin/ansible-2.8.0/lib/ansible/plugins/lookup/"
    module = LookupModule(basedir=basedir)
    terms = ["*"]
    variables = None

    # act
    ret = module.run(terms=terms, variables=variables)

    # assert

# Generated at 2022-06-23 11:32:39.040422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = MockTemplar()
    terms = [u'/my/path/foo.txt', u'/my/path/dir/bar.txt']
    variables = {
        u'ansible_search_path': [u'/my/path', u'/other/path']
    }
    globbed = lookup.run(terms=terms, variables=variables, wantlist=True)
    assert globbed == [
        u'/my/path/foo.txt',
        u'/my/path/dir/bar.txt',
        u'/other/path/foo.txt'
    ]


# Generated at 2022-06-23 11:32:42.406917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    path = "/home/tutorial/ansible/"
    test_m = LookupModule()
    assert test_m.run([path]) == ["/home/tutorial/ansible/fileglob.py", "/home/tutorial/ansible/fileglob.pyc"]

# Generated at 2022-06-23 11:32:49.704104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test case for LookupModule method run"""
    # Create an object of class LookupModule
    lookup_module =  LookupModule()

    # Check condition when directory is passed
    assert lookup_module.run(['/file/path'], {}) == []

    # Check condition when file is passed
    assert lookup_module.run(['file_path'], {}) == []

# Run the unit tests
if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 11:32:50.298308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:32:52.382502
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(['/my/path/*.txt']) == ['/my/path/*.txt']

# Generated at 2022-06-23 11:33:03.612663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # from __future__ import print_function
    from ansible.parsing.dataloader import DataLoader

    lu = LookupModule()

    cwd = os.path.dirname(__file__)
    loader = DataLoader()

    # Initialize empty variables
    variables = {}

    # Test with relative path and glob
    result = lu.run(['relative/*.py'], variables=variables, loader=loader)
    if result != [os.path.join(cwd, 'relative/lookup_fileglob.py')]:
        print("||| test_LookupModule_run: relative/glob: FAILED")

    # Test with relative path and no glob
    result = lu.run(['relative/lookup_fileglob.py'], variables=variables, loader=loader)
   

# Generated at 2022-06-23 11:33:10.725620
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    from ansible.plugins.loader import lookup_loader

    l = LookupModule()

    paths = ['/Users/michael-dehaan/test', '/Users/michael-dehaan/test-test', '/Users/michael-dehaan/test-test-test']
    variables = {'ansible_search_path': paths, 'name': 'test'}

    terms = ['test']
    result = l.run(terms=terms, variables=variables)

    assert result == ['/Users/michael-dehaan/test/test']

# Generated at 2022-06-23 11:33:13.012256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule'''
    lookup = LookupModule()
    assert lookup.run is not None
    assert lookup.run_term is None

# Generated at 2022-06-23 11:33:20.599916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ###############################################################################################
    #
    # Fileglob term is file and directory
    #
    ###############################################################################################
    # File exists in directory
    terms = ["/usr/local/lib/libpython3.6m.so.1.0", "/usr/local/lib/libpython3.6m.so.1.0/fileglob.py"]
    result = lookup_module.run(terms, {'ansible_search_path': ['/usr/local/lib/fileglob.py']})
    assert result == []
    # File does not exists in directory

# Generated at 2022-06-23 11:33:31.709307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["/test/path/*.txt"], {"role_path": "/roles"}, wantlist=True) == []
    assert lookup.run(["/test/path/*.txt"], {"role_path": "/test"}, wantlist=True) == []
    assert lookup.run(["/test/path/*.txt"], {"ansible_search_path": "/roles"}, wantlist=True) == []
    assert lookup.run(["/test/path/*.txt"], {"ansible_search_path": "/test"}, wantlist=True) == []
    assert lookup.run(["/test/path/*.txt"], {"ansible_search_path": ["/test"]}, wantlist=True) == []

# Generated at 2022-06-23 11:33:40.127840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    basedir = os.path.dirname(__file__)
    test_dir = os.path.join(basedir, 'unit-test-fixtures', 'fileglob')
    class FakeVariables(dict):
        pass
    def get_basedir(variables=None):
        return test_dir
    def find_file_in_search_path(variables, directory, path):
        return '../files'
    lookup = LookupModule()
    lookup.get_basedir = get_basedir
    lookup.find_file_in_search_path = find_file_in_search_path

# Generated at 2022-06-23 11:33:44.701378
# Unit test for constructor of class LookupModule
def test_LookupModule():
 
    # Create instance of class LookupModule
    lookup = LookupModule()

    # Test function run
    result = lookup.run(['/path/to/file'], variables={})

    # Assert the result
    assert result == []

# Generated at 2022-06-23 11:33:54.521546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.run(['../files/test1.txt'], {'files': 'files'}) # Existing file
    l.run(['../files/test2.txt'], {'files': 'files'}) # Non-existing file

    # No such directory
    try:
        l.run(['../files/no_such_dir/test1.txt'], {'files': 'files'})
    except AnsibleFileNotFound:
        pass
    else:
        assert False, "Should raise AnsibleFileNotFound"

    # Inexistent pattern
    l.run(['../files/test*.inexistent'], {'files': 'files'})

# Generated at 2022-06-23 11:33:56.844693
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.name == 'fileglob'

# Generated at 2022-06-23 11:33:58.310399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    res = LookupModule()

# Generated at 2022-06-23 11:34:02.637070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_path = "/tmp/foo"
    test_term = "file.*"
    terms = [test_term]
    variables = None
    lookup = LookupModule()
    result = lookup.run(terms, variables)
    assert result == []

# Generated at 2022-06-23 11:34:09.506680
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['*.txt', '*.md']
    variables = {
        'ansible_search_path': [
            '/path/to/directory',
            '/path/to/another/directory',
            '/path/to/parent/directory'
        ]
    }
    lookup_module = LookupModule()

    assert lookup_module.run(terms, variables) == \
        ['/path/to/directory/file.txt', '/path/to/another/directory/file.txt', '/path/to/parent/directory/file.md']

# Generated at 2022-06-23 11:34:10.976271
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule().run([]) == []

# Generated at 2022-06-23 11:34:11.549227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:34:12.869677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:34:19.758631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import tempfile
    import traceback

    class AnsibleModule:

        def __init__(self):
            self.params = {}

        def fail_json(self, **args):
            raise Exception(args)

    class AnsibleFileNotFound(Exception):
        pass

    def _ansible_tmpdir_lookup(**kwargs):
        #for compatability with Ansible's _ansible_tmpdir() function, added at Ansible 2.5
        #See Ansible/ansible/utils/_text.py
        return tempfile.gettempdir()

    class TwNullIO:
        # Python 3.x does not have "file" built-in
        name = None
        def write(self, *args, **kwargs):
            pass

    # Suppress "no handlers could be found for logger

# Generated at 2022-06-23 11:34:29.848961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with simple good case
    terms = ['/test/test.txt']
    test_lookup = LookupModule()
    result = test_lookup.run(terms)
    assert result == ['/test/test.txt']

    # Test with simple bad case
    terms = ['/test/test_bad.txt']
    test_lookup = LookupModule()
    result = test_lookup.run(terms)
    assert result == []

    # Test including a directory
    terms = ['/test/test_include_dir']
    test_lookup = LookupModule()
    result = test_lookup.run(terms)
    assert result == ['/test/test_include_dir/test1.txt', '/test/test_include_dir/test_in_folder/test2.txt']

    # Test not including

# Generated at 2022-06-23 11:34:35.058175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test no arguments
    with pytest.raises(AnsibleFileNotFound):
        module.run([], dict())

    # Test no files found
    assert module.run(['no_such_file'], dict()) == []

    # Test one file found
    assert module.run(['no_such_file', 'no_such_file'], dict()) == []

# Generated at 2022-06-23 11:34:37.180486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:34:37.733765
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:34:38.340045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:34:44.537432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    args['terms'] = '/opt/stackstorm/packs/orca/actions/setup_rtm_server.sh'
    args['_terms'] = '/opt/stackstorm/packs/orca/actions/setup_rtm_server.sh'
    args['VariableManager'] = 'test_variable_manager'
    args['play_context'] = 'test_play_context'

    lookup = LookupModule()
    lookup.run(args)

# Generated at 2022-06-23 11:34:51.426465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A sample test, simple use of the 'fileglob' lookup
    terms = ["/path/to/*"]
    variables = {"play_hosts":"wazig1.datadist"}, {"play_hosts":"wazig2.datadist"}

    ret = LookupModule().run(terms, variables, wantlist=True)
    print("run(): " + ret)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:35:03.120644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.common.files import missing_files
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import lookup_loader

    dummy_lookup_instance = lookup_loader.get('fileglob', class_only=True)

    assert dummy_lookup_instance._error_messages['file_not_found'] == 'could not find file in lookup: %(path)s'

    assert dummy_lookup_instance._error_messages['file_not_absolute'] == 'file paths must be absolute: %(path)s'

    assert dummy_lookup_instance._error_messages['file_not_found_or_file_targets'].startswith('could not find or access')

    assert dummy_lookup_

# Generated at 2022-06-23 11:35:05.471353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    assert lookup_module._templar is not None


# Generated at 2022-06-23 11:35:10.498984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule._templar = None

    # test non-existent file
    assert lookupModule.run(['nonexistent/file']) == []

    # test existing file
    assert lookupModule.run(['../test_utils.py']) == ['../test_utils.py']

    # test existing directory
    assert lookupModule.run(['../test/test_utils']) == []

# Generated at 2022-06-23 11:35:15.328927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run method returns a list which can be
    # 1 element long or empty. Hence we need to test it in one of
    # two cases.
    test_lookup = LookupModule()
    test_terms = ["/home/testuser/test1.txt", "/home/testuser/test2.txt"]
    assert test_lookup.run(test_terms) == []
    test_terms = ["/Users/testuser/test1.txt", "/Users/testuser/test2.txt"]
    assert test_lookup.run(test_terms) == ['/Users/testuser/test1.txt', '/Users/testuser/test2.txt']

# Generated at 2022-06-23 11:35:26.180012
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources='')
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

    terms = ['/my/path/*.txt']
    current_path = os.path.dirname(os.path.realpath(__file__))
    basedir = os.path.join(current_path, 'lookup_plugins/fileglob')
    expected_return_value = [os.path.join(basedir, 'files/fooapp/bar')]

# Generated at 2022-06-23 11:35:27.915138
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Test constructor with lookup initialisation

# Generated at 2022-06-23 11:35:33.394766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup = LookupModule()
    lookup.get_basedir = lambda x: '/home/user/toto'

    # Run
    terms = ['toto']
    output = lookup.run(terms)

    # Asserts
    assert output[0] == '/home/user/toto/files/toto'
    assert output[1] == '/home/user/toto/toto'



# Generated at 2022-06-23 11:35:40.235249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    LKM = LookupModule()

    # create mock object for variables
    variables = dict()
    variables['ansible_search_path'] = ['/some_directory/some_path']
    variables['some_path'] = True

    # mock method find_file_in_search_path
    LKM.find_file_in_search_path = lambda x,y,z: '/some_directory/some_path'

    # mock self.get_basedir(variables)
    LKM.get_basedir = lambda x: '/some_directory/some_path'

    # mock self.get_basedir(variables)
    os.path.isfile = lambda x: True

    # mock glob.glob
    def mock_glob(glob_str):
        ret

# Generated at 2022-06-23 11:35:42.443210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.find_file_in_search_path({}, 'files', '/my/path') == '/my/path'

# Generated at 2022-06-23 11:35:43.817215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:35:44.931875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:35:48.373302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run() == []
    assert LookupModule().run() == []
    assert LookupModule().run(["*"]) == []
    assert LookupModule().run(["*.txt"]) == []
    assert LookupModule().run(["/nonexistent"]) == []

# Generated at 2022-06-23 11:35:50.882670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 11:35:52.320072
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    pass

# Generated at 2022-06-23 11:35:53.696718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule(None, None) is not None)

# Generated at 2022-06-23 11:35:58.132675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    results = module.run(["/etc/passwd"])
    assert isinstance(results, list), "results is not a list"
    assert len(results) > 0, "empty results list"

# Generated at 2022-06-23 11:36:10.572792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check for correct globbing on a file in the current directory.
    lookup_module = LookupModule()
    basedir = os.path.dirname(__file__)
    result = lookup_module.run([os.path.join(basedir, '*.py')], {})
    assert isinstance(result, list)
    assert len(result) == 1
    assert 'test_fileglob.py' in result[0]

    # Check that the right exception is raised when we try to glob a path that doesn't exist.
    # Note: This code could be in the tests directory, so we can't be sure what directory it will be run from.
    # Instead, we use a path that is almost certain to fail.
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:36:12.751739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None).run([]) is not None

# Generated at 2022-06-23 11:36:21.687065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()

    class Options(object):
        ansible_inventory = "test/fixtures/ans_inv.py"

    class Options2(object):
        ansible_inventory = "test/ansible_test/test_inv.py"

    class Options3(object):
        ansible_inventory = "test/ansible_test/nocontent_inv.py"

    # Testing run() using different combinations of args
    assert f.run([], variables={}) == []
    assert f.run(terms=['file'], variables={'hostvars':{}}) == []
    assert f.run(terms=['file'], variables={}, runner_options=Options()) == []

# Generated at 2022-06-23 11:36:22.288562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:36:25.754732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  Variables to be used
    terms = []
    variables = {}
    terms.append('test_var')
    os.environ['ANSIBLE_VAR_test_var'] = 'test_value'
    # Init of class LookupModule
    L = LookupModule()
    assert L.run(terms, variables, **{})[0] == 'test_value'

# Generated at 2022-06-23 11:36:26.691974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lkp = LookupModule()
    assert hasattr(lkp, 'run')

# Generated at 2022-06-23 11:36:32.371935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Tests for file
    assert lookup.run(terms=['/my/path/*.txt'], variables={}) == []
    # Tests for file
    assert lookup.run(terms=['/my/path/*.txt'], variables={'my': {'path': '/my/path'}}) == []
    # Tests for file
    assert lookup.run(terms=['/my/path/*.txt'], variables={'my': {'path': 'c:/my/path'}}) == []
    # Tests for file
    assert lookup.run(terms=['/my/path/*.txt'], variables={'my': {'path': 'c:/my/path/'}}) == []
    # Tests for file

# Generated at 2022-06-23 11:36:44.020378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_mock = AnsibleMock(LookupModule)
    module_mock.run('playbooks/files/fooapp/*')
    _call_args, _call_kwargs = module_mock.run.call_args
    assert _call_args == ('playbooks/files/fooapp/*',)
    assert _call_kwargs == {}
    module_mock.run('playbooks/files/fooapp/*', kwarg1='value1', kwarg2='value2', variables={'ansible_search_path': []})
    _call_args, _call_kwargs = module_mock.run.call_args
    assert _call_args == ('playbooks/files/fooapp/*',)

# Generated at 2022-06-23 11:36:48.018732
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    lookup = LookupModule()

    terms = ['*.txt']
    # Execute
    ret = lookup.run(terms, variable_manager.get_vars())


    # Assert
    assert type(ret) is list

# Generated at 2022-06-23 11:36:49.682532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-23 11:37:00.057167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import glob
    import tempfile

    tempdir = tempfile.mkdtemp()
    f1 = open(os.path.join(tempdir, 'test_file.txt'), 'w')
    f1.write("test1")
    f1.close()

    f2 = open(os.path.join(tempdir, 'test_file_2.txt'), 'w')
    f2.write("test2")
    f2.close()

    f3 = open(os.path.join(tempdir, 'test_file_3.txt'), 'w')
    f3.write("test3")
    f3.close()

    f4 = open(os.path.join(tempdir, 'test_file_4.txt'), 'w')
    f4.write("test4")
    f4

# Generated at 2022-06-23 11:37:03.367853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    terms = ['/my/path/*.txt']
    # test for function run in class LookupModule
    mod.run(terms)

# Generated at 2022-06-23 11:37:05.525259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    f = lookup.run(['/tmp/test_LookupModule_backups/*'])
    assert type(f) == list
    f = lookup.run(['/tmp/test_LookupModule_backups/*'], wantlist=False)
    assert type(f) == str



# Generated at 2022-06-23 11:37:14.141666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()

    # Create a Mock variable object so we can set 'ansible_search_path' variable
    variables = {}
    variable_obj = MagicMock()
    variable_obj.get_vars.return_value = variables
    variable_obj.get_vars.return_value['ansible_search_path'] = ["/tmp/ansible"]

    # Create a Mock templar object so we can get the basedir
    templar_obj = MagicMock()
    templar_obj.basedir = "/home/user"

    # Set the variable and templar objects
    lookup_obj.set_options(variable_objects=[variable_obj], templar=templar_obj)

    # Mock the copy of the file.

# Generated at 2022-06-23 11:37:15.397853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:37:20.972973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Ensure that the LookupModule.run method returns the expected results.
    """
    lookup_obj = LookupModule()

    # Test a non-existing directory
    test_dir = '/path/that/does/not/exist'
    assert lookup_obj.run([test_dir]) == [], \
        "The expected result for '{0}' is not {1}".format(
            test_dir, []
        )

    # Test a directory that does exist
    test_dir = 'tests/lookup_plugins/FileglobTest/'

# Generated at 2022-06-23 11:37:22.664534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert 'AnsibleLookupError' not in lookup_module
    assert 'LookupBase' in lookup_module


# Generated at 2022-06-23 11:37:24.067024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:37:25.852168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule
    lookup = LookupModule()
    assert lookup
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:37:33.132591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Create a temprary folder to store files to be lookupped
    #   In this case, files have the following structure
    #   test.txt
    #   folder1
    #       file1.txt
    #       file2.txt
    #       folder2
    #           file3.txt
    #           file4.txt
    #   folderx
    #       filex1.txt
    #       filex2.txt
    import tempfile
    readme_dir = tempfile.mkdtemp()
    readme_file = tempfile.NamedTemporaryFile(dir=readme_dir, mode='w')
    readme_file.write('test')


# Generated at 2022-06-23 11:37:34.614765
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup1 = LookupModule()
    assert lookup1 is not None

# Generated at 2022-06-23 11:37:35.982503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 11:37:36.552788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:37:37.817573
# Unit test for constructor of class LookupModule
def test_LookupModule():
    path=LookupModule()
    files=path.run("*")

# Generated at 2022-06-23 11:37:38.664410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(self="foo") == []

# Generated at 2022-06-23 11:37:40.831862
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_cls = LookupModule()
    assert lookup_cls != None


# Generated at 2022-06-23 11:37:42.249524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-23 11:37:44.038957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(None, ['/tmp/does_not_exist/foo.txt']) == []

# Generated at 2022-06-23 11:37:45.582718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l != None


# Generated at 2022-06-23 11:37:51.152878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup = LookupModule()
    results = lookup.run(['/playbooks/files/fooapp/*'], {'ansible_search_path': ['/playbooks/files/fooapp/']})
    assert results == ['/playbooks/files/fooapp/a.yml']

# Generated at 2022-06-23 11:38:00.800589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    modules = ['ansible.builtin.fileglob']
    # path to the test code file, which contain code to test run method
    test_file_path = '/home/vagrant/ansible/tests/unit/lookup_plugins/test_fileglob.py'
    # create a fake module
    module = AnsibleModule(argument_spec={'param': {'type': 'str', 'required': True}},
                           supports_check_mode=True,
                           check_invalid_arguments=False)
    # parse args as strings to avoid type error
    module.params['param'] = to_text(test_file_path, nonstring='passthru', errors='surrogate_or_strict')
    # create a fake controller
    controller = AnsibleController()
    # create lookup object

# Generated at 2022-06-23 11:38:05.894376
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # constructor: LookupModule()
  lookup_module = LookupModule()
  assert lookup_module.run(terms=['/root/tasks/main.yml', 'role.yml']) == ['/root/tasks/main.yml', 'role.yml']

# Generated at 2022-06-23 11:38:06.506062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()
    assert test_object is not None

# Generated at 2022-06-23 11:38:07.663081
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 11:38:10.575763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    
    # test constructor
    assert lookup._templates == {}
    assert lookup._basedir == os.path.realpath(os.path.expanduser('~'))

# Generated at 2022-06-23 11:38:17.217969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test lookup module initialization
    lookup_module = LookupModule()

    # Test if the environment variables are set in the constructor
    assert(lookup_module.get_basedir(None) is not None)

    # Test if lookup plugin can be accessed.
    assert(lookup_module.run(["*"], {"ansible_search_path": ["./"]}) is not None)

# Generated at 2022-06-23 11:38:18.504558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_runner(DummyRunner())
    l.run([], dict(ansible_lookup_plugin_dirs=['./lookup_plugins']))

# Generated at 2022-06-23 11:38:22.649688
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule = __import__('lookup_plugins.fileglob').lookup_plugins.fileglob.LookupModule

    # This method test case for two params and the values are given

    lookup = LookupModule()
    p1 = "test.txt"

    ret = lookup.run(
                p1
                )
    print(ret)

# Generated at 2022-06-23 11:38:28.560266
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_cases = [
        dict(
            terms=[
                '/foo/*.txt',
                '/bar/*.txt'],
            paths=[
                '/foo',
                '/bar']),
        dict(
            terms=['/foo/*.txt'],
            paths=['/foo']),
        dict(
            terms=['*.txt'],
            paths=['/bar/files', '/bar'])
    ]

    for test_case in test_cases:
        lookup_module = LookupModule()
        paths = []
        for term in test_case.get("terms"):
            term_file = os.path.basename(term)
            if term_file != term:
                paths.append(lookup_module.find_file_in_search_path({}, 'files', os.path.dirname(term)))

# Generated at 2022-06-23 11:38:29.473851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == type(LookupModule())

# Generated at 2022-06-23 11:38:31.418327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm != None

# Generated at 2022-06-23 11:38:37.963310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import shutil
    # setup a temp directory
    tempdir = tempfile.mkdtemp()
    # setup a temp file in the temp dir
    tempfile1 = tempfile.NamedTemporaryFile(mode='w+b', suffix=".tmp", prefix="tmp", dir=tempdir)
    tempfile1.write(b"hello world!")
    tempfile1.seek(0)
    # setup a temp file in the temp dir
    tempfile2 = tempfile.NamedTemporaryFile(mode='w+b', suffix=".tmp", prefix="tmp", dir=tempdir)
    tempfile2.write(b"hello world!")
    tempfile2.seek(0)
    # create another directory
    tempdir2 = tempfile.mkdtemp(dir=tempdir)
    # setup a temp file