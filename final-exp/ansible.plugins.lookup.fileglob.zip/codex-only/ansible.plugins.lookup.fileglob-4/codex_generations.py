

# Generated at 2022-06-23 11:28:36.024524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["C:\\Program Files (x86)\\Test\\Ansible\\bin\\ansible.exe"]
    lookup.run(terms)

# Generated at 2022-06-23 11:28:38.643587
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, '__len__')
    x = LookupModule()
    assert x.run

# Generated at 2022-06-23 11:28:47.487554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # AnsibleModule type is defined in module_utils.basic.AnsibleModule
    # This is used to pass ansible arguments to LookupModule.run
    ansible_module = 0
    # Parse json_data
    json_string = '''
    {
      "ansible_loop_var": "item",
      "ansible_managed": "<ansible.builtin.fileglob>",
      "item": "/home/mentha/install.log"
    }
    '''
    json_data = json.loads(json_string)
    #
    lookup_module_instance = LookupModule(ansible_module)
    lookup_module_instance.run(json_data, variables=None, wantlist=True)

# Generated at 2022-06-23 11:28:48.124775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:28:54.473180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = {'wantlist': False}
    terms = ['/etc/hosts']
    variables = {'ansible_search_path': ['/etc']}
    lookup = LookupModule()
    assert lookup.run(terms, variables, **kwargs) == terms
    terms = ['abcd', 'xyz.txt']
    assert lookup.run(terms, variables, **kwargs) == []

# Generated at 2022-06-23 11:29:03.244512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("***** test_LookupModule_run *****")
    # create a lookup module and pass it a basic variable
    lookup_module = LookupModule()
    terms = ['/my/path/*.txt', '*.html']
    basic_variables = { 'ansible_search_path': ['/my/path'] }
    print("NOTE: this test needs to be updated to reflect the results found by run()")
    ret = lookup_module.run(terms, variables=basic_variables, **{})
    print("ret: '{0}'".format(ret))

# initialize the test environment

# Generated at 2022-06-23 11:29:04.122791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 11:29:06.125602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:29:07.421291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run()
    assert l is not None

# Generated at 2022-06-23 11:29:13.730189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_obj.set_loader(None)
    lookup_obj.set_basedir(os.path.join(os.getcwd(), "tests/unit/support"))
    terms = ["*.png"]
    want = ["foo.png"]
    got = lookup_obj.run(terms, variables={"ansible_search_path":
                                           [os.getcwd() + "/tests/unit/support"]})

    assert got == want

# Generated at 2022-06-23 11:29:14.500205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:29:15.768915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x.run([], []) == []

# Generated at 2022-06-23 11:29:26.204257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a temporary class that inherits from LookupModule
    class TempClass(LookupModule):
        def find_file_in_search_path(self, variables, path, path_type):
            return path
        def get_basedir(self, variables):
            return '/'

    # Create an instance of the TempClass and run method
    # `run` of the LookupModule class with valid arguments
    results = TempClass().run(terms=['a', 'b'], variables={})
    assert results == []

    term_results = ['c', 'd']
    glob.glob = lambda x: term_results
    results = TempClass().run(terms=['c', 'd'], variables={})
    assert results == term_results


# Generated at 2022-06-23 11:29:27.229044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.run(['/my/path/*.txt'])
    return True

# Generated at 2022-06-23 11:29:28.548500
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-23 11:29:38.224140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test LookupModule.run method'''
    lm = LookupModule()
    LookupBase.get_basedir = lambda x, y: "/home/deployer/provisioner/ansible/"
    os.path.exists = lambda x: False
    assert lm.run(["provisioner.yml"],{"ansible_search_path": ["/home/deployer/ansible/","/etc/ansible/"]})  == []
    assert lm.run(["/home/deployer/provisioner/ansible/provisioner.yml"],{"ansible_search_path": ["/home/deployer/ansible/","/etc/ansible/"]})  == ["/home/deployer/provisioner/ansible/provisioner.yml"]

# Generated at 2022-06-23 11:29:39.439408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    print ("Testing class constructor")
    assert lookupModule

# Generated at 2022-06-23 11:29:40.306982
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:29:42.136334
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # assert LookupModule.__metaclass__ == type
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:29:45.672495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    md = LookupModule()
    # fixture 1
    # calls Python's "glob" library
    a = md.run(['/my/path/*.txt'])
    assert a[0] == '/my/path/file.txt'

# Generated at 2022-06-23 11:29:48.623751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/my/path/*.txt']
    result = lookup.run(terms)
    assert(result == [])


# Generated at 2022-06-23 11:29:49.587816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 11:29:51.690128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['*.txt']
    ls = LookupModule()

    result = ls.run(terms)

    print(result)

# Generated at 2022-06-23 11:29:53.018025
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    assert module is not None

# Generated at 2022-06-23 11:29:55.228125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    result = test_object.run(['/my/path/*.txt'], {}, wantlist=True)

    assert result is not None

# Generated at 2022-06-23 11:29:56.271398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:30:04.076880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)

    cwd = os.path.dirname(os.path.realpath(__file__))
    os.chdir(cwd)

    terms = ['./files/foo.txt']
    assert lookup.run(terms) == ['files/foo.txt']

    terms = ['./files/no_such_file.txt']
    assert lookup.run(terms) == []

    terms = ['./files/no_such_file.txt']
    assert lookup.run(terms) == []

# Generated at 2022-06-23 11:30:05.849387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 11:30:14.018866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:30:19.985639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of our class
    lookup_instance = LookupModule()

    # Try to do a file lookup for a list of files
    paths = lookup_instance.run([u"*.txt"], use_cache=False)

    # Check the result
    assert paths is not None
    assert len(paths) > 0
    assert type(paths) == list
    # Check the first item in the list
    assert type(paths[0]) == str

# Generated at 2022-06-23 11:30:27.458635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In this test we mock get_basedir function and find_file_in_search_path function
    # in order to test run() method we need a mock os module too
    from unittest.mock import Mock, patch
    from ansible.plugins.lookup.fileglob import LookupModule

    # Mocking os module
    mock_os = Mock()
    mock_os.path.isfile.return_value = True
    mock_os.path.join.return_value = '/fake/path/to/file/'
    mock_os.path.basename.return_value = 'my_file'
    mock_os.path.dirname.return_value = 'my_dir'
    mock_os.path.isdir.return_value = True
    mock_os.path.sep = '/'

    # Creating

# Generated at 2022-06-23 11:30:32.092391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'_terms': ['/my/path/*.txt']})
    result = lookup_module.run()

    assert result is not None and isinstance(result, list)
    assert result == [] or isinstance(result[0], str)

# Generated at 2022-06-23 11:30:34.138631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:30:35.837673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms=['/root/*']
    l = LookupModule()
    l.run(terms)

# Generated at 2022-06-23 11:30:39.774831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_dict = {}
    test_dict['ansible_search_path'] = "/playbooks/files"
    test_LookupModule = LookupModule()
    result = test_LookupModule.run(['*.txt'], test_dict)
    assert result != None

# Generated at 2022-06-23 11:30:41.157658
# Unit test for constructor of class LookupModule
def test_LookupModule():
  ansible = __import__('ansible')
  x = LookupModule()

# Generated at 2022-06-23 11:30:43.147068
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_test = LookupModule()
    lookup_test.run(terms=['fileglob.yml'])

# Generated at 2022-06-23 11:30:45.859880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.basedir = '/var/lib/ansible'
    lookup.run(['./ansible/modules'], {}, wantlist=True)

# Generated at 2022-06-23 11:30:47.812844
# Unit test for constructor of class LookupModule
def test_LookupModule():
    source = LookupModule()
    assert isinstance(source, LookupModule)

# Generated at 2022-06-23 11:30:54.455517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    try:
        lookup_module.run(["test_*"], None)
    except AnsibleFileNotFound as e:
        assert "Could not find or access 'test_*'" in e.args[0]
    assert lookup_module.run(["test_*"], {"ansible_search_path": ["./test/files/lookup_plugins/fileglob"]}) == ["test_FileglobVariable.py"]

# Generated at 2022-06-23 11:30:57.022519
# Unit test for constructor of class LookupModule
def test_LookupModule():
    temp_path = '/playbooks/files/fooapp/*'
    lookup_module = LookupModule()
    lookup_module.run(terms=temp_path, variables=None)
    assert True

# Generated at 2022-06-23 11:31:04.717274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes
    from ansible.compat.six import string_types
    lookup = LookupModule()

    # We return a list of strings or AnsibleUnsafeText
    returned = lookup.run(['/tmp/fileglob*'], dict(ansible_search_path = ['/tmp/']))
    assert isinstance(returned, list)
    assert len(returned) == 0
    for entry in returned: assert isinstance(entry, string_types) or isinstance(entry, AnsibleUnsafeText)

    # We return a list of unicode strings or AnsibleUnsafeText

# Generated at 2022-06-23 11:31:11.753300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/ansible/test.txt']
    expected_results = ['/etc/ansible/test.txt']
    lookup_module = LookupModule()
    results = lookup_module.run(terms)
    if results != expected_results:
        raise Exception('Expected: %s, but results are: %s' % (expected_results, results))
    else:
        print('Got expected results: %s' % results)


# Generated at 2022-06-23 11:31:19.010063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_params = dict(
            basedir=os.getcwd(),
            # FIXME: lookup to call module_utils
            runner=dict(
                basedir=os.getcwd(),
                config=dict(
                    config_file=os.devnull
                )
            )
        )
        lookup = LookupModule()
        lookup.set_options(lookup_params)
        result = lookup.run(["README.rst"], dict())
        assert result == []
    except:
        pass

# Generated at 2022-06-23 11:31:19.936885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 11:31:20.591418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)

# Generated at 2022-06-23 11:31:26.964448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Create a mocked AnsibleVariable, with fake paths and basedir
    ansiblevar = object()
    ansiblevar.__getitem__ = lambda s, k: {'ansible_search_path': ['test/files', 'test/files/files'],
                                           'ansible_basedir': 'test/files'}.get(k)

    # Create a mocked AnsibleModule, with fake call params, and ansiblevar returned by the get_option method
    ansiblemod = object()
    ansiblemod.params = {'wantlist': True}
    ansiblemod.get_option = lambda s, k: {'wantlist': True}.get(k)

    # Create a mocked Context, with fake basedir, vars and lookups
    context = object()

# Generated at 2022-06-23 11:31:28.880214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert(isinstance(c, LookupBase))
    pass

# Generated at 2022-06-23 11:31:34.699675
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create an instance of the class LookupModule
    lookmod = LookupModule()

    # run method run() of class LookupModule
    terms = ["*.conf"]
    print("\n\n---TEST---")
    print("\tterms", terms)
    print("\tret: ", lookmod.run(terms))
    print("\n\n")


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:31:40.794194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes, to_text
    module = LookupModule()
    terms = ['*/*.py']
    variables = {}
    ret = module.run(terms, variables)
    assert ret == ['/home/vagrant/ansible/tests/unit/plugins/lookup/files/a2/b2/file_to_glob.py']


# Generated at 2022-06-23 11:31:47.298851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ku = LookupModule()
    v = {}
    assert ku
    assert ku.run(terms=['/etc/*'], variables={'ansible_search_path':['/etc/']})
    assert ku.run(terms=['/playbooks/files/*'], variables={'ansible_search_path':['/playbooks/files']})
    assert ku.run(terms=['/playbooks/files/*'], variables={'ansible_search_path':['/playbooks/files'], 'files':['/files']})

# Generated at 2022-06-23 11:31:48.377531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:31:52.339686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    input_val = ["foo", "bar"]
    test_class = LookupModule()
    result_val = test_class.run(input_val)
    assert result_val == []
    assert type(result_val) == list

# Generated at 2022-06-23 11:31:52.945221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-23 11:31:54.742697
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule.__doc__ is not None

# Generated at 2022-06-23 11:31:56.859384
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'
    assert LookupModule._lookup_name == 'fileglob'

# Generated at 2022-06-23 11:31:58.914250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters: terms, variables=None, **kwargs
    l = LookupModule()
    l.run('anaconda')

# Generated at 2022-06-23 11:32:06.451712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    import ansible.plugins.lookup.fileglob

    test_class = ansible.plugins.lookup.fileglob.LookupModule
    global_path_of_current_file = os.path.dirname(os.path.realpath(__file__))

    class TestFileglob(unittest.TestCase):
        def setUp(self):
            self.test_class_instance = test_class()


# Generated at 2022-06-23 11:32:17.240245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Return results for the parameters: term, variables

# Generated at 2022-06-23 11:32:26.681229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_obj = LookupModule()

    basedir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'hacking')

    os.environ['ANSIBLE_LOOKUP_PLUGINS'] = os.path.join(basedir, 'test', 'support/lookup_plugins')
    os.environ['ANSIBLE_CONFIG'] = os.path.join(basedir, 'test', 'integration/ansible.cfg')

    terms = [u'test*.yml']


# Generated at 2022-06-23 11:32:36.674723
# Unit test for constructor of class LookupModule
def test_LookupModule():

    print('Creating LookupModule object with current dir')
    l = LookupModule()
    print(l)
    print('Creating LookupModule object from current dir with os.walk')
    for root, dirs, files in os.walk('.'):
        for name in files:
            print(name)
            path = os.path.join(root, name)
            print(path)
            l = LookupModule(path)
            print(l)
    print('Creating LookupModule object from current dir with glob')
    for path in glob.glob('*'):
        print(path)
        l = LookupModule(path)
        print(l)
    print('Creating LookupModule object from current dir with glob')
    for path in glob.glob('/tmp/ansible', '*'):
        print(path)

# Generated at 2022-06-23 11:32:37.986106
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO:  Test LookupModule() constructor
    pass


# Generated at 2022-06-23 11:32:38.528416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:32:38.878457
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:32:42.616061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Configure the test data
  terms = ['/test/test1.txt','/test/test2.txt']
  # Execute the run function
  instance = LookupModule()
  result = instance.run(terms)
  # Verify the result
  assert result == ['/test/test1.txt', '/test/test2.txt']

# Generated at 2022-06-23 11:32:45.600604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print()
    lookup1 = LookupModule()
    print(lookup1)
    print()

# Generated at 2022-06-23 11:32:47.487898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:32:48.903148
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Calls constructor of class LookupModule"""
    lookup = LookupModule()

# Generated at 2022-06-23 11:32:49.888966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-23 11:32:52.183625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.find_file_in_search_path({}, 'files', '/my/path') == '/my/path'

# Generated at 2022-06-23 11:33:03.425275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if 'TRAVIS' not in os.environ: # skip for travis due to file permissions
        # check for methods that test for only one term
        looker = LookupModule()
        # check for LookupError due to empty source
        try:
            assert looker.run([]) == []
        except AnsibleFileNotFound:
            pass
        # check for LookupError due to non-exist file
        try:
            assert looker.run(['/non/existing/file']) == []
        except AnsibleFileNotFound:
            pass
        # check for LookupError due to directory instead of file
        try:
            assert looker.run(['/usr/']) == []
        except AnsibleFileNotFound:
            pass
        # check for files exist but without a match

# Generated at 2022-06-23 11:33:04.738635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x != None

# Generated at 2022-06-23 11:33:14.217675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLookupModule(LookupModule):

        def __init__(self, *args, **kwargs):
            self.ret = []
            self.test_args = args
            self.test_kwargs = kwargs

        def glob(self, pattern):
            self.pattern = pattern
            return self.ret

        def isfile(self, pattern):
            self.pattern = pattern
            return True

    search_path1 = b'/a/b/c/d'
    search_path2 = b'A/B/C/D'
    search_path3 = b'/B/C/D/E'
    path1 = b'a/b/1.txt'
    path2 = b'/A/B/2.txt'
    path3 = b'/B/C/3.txt'

# Generated at 2022-06-23 11:33:19.252959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate an instance of Ansible class
    # First argument is the config_file path
    # Second argument is a list of paths to search for roles
    # Third argument is a list of search paths where the module will look for data
    config_path = './ansible.cfg'
    ansible = Ansible(config_path)

    # Create an instance of class LookupModule
    lookup = LookupModule(ansible)

    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:33:21.800391
# Unit test for constructor of class LookupModule
def test_LookupModule():
  t = LookupModule()
  ret = t.run(["/my/path/*.txt"], {})
  assert ret == []

# Generated at 2022-06-23 11:33:26.645449
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=unused-argument, no-value-for-parameter
    lookup_module = LookupModule('test', 'src', 'dst', 'test', 'tmp')
    assert lookup_module.params == {'warning': True}

# Generated at 2022-06-23 11:33:29.059870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = glob.glob
    assert type(lookup) is type(glob.glob), "lookup is not the same as glob.glob"

# Generated at 2022-06-23 11:33:37.449014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['*'], {'hostvars': {'host1': {}, 'host2': {}}}, variables={}, wantlist=False, basedir='/', **{'_raw_params': None})
    assert len(result) == 0

    result = LookupModule().run(['*'], {'hostvars': {'host1': {}, 'host2': {}}}, variables={}, wantlist=True, basedir='/', **{'_raw_params': None})
    assert len(result) == 0

    result = LookupModule().run(['.*'], {'hostvars': {'host1': {}, 'host2': {}}}, variables={}, wantlist=False, basedir='/', **{'_raw_params': None})
    assert len(result) == 0

   

# Generated at 2022-06-23 11:33:38.203111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:33:41.400096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup = LookupModule()
    terms = ['/my/path/*.txt']

    # Act
    lookup.run(terms=terms)

    # Assert
    assert True

# Generated at 2022-06-23 11:33:48.600468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    assert(test_lookup.run(terms=['*.py'], variables={'path':'/Users/shahzad/Projects/Ansible'}) == [])
    assert(len(test_lookup.run(terms='*.py', variables={'path':'/Users/shahzad/Projects/Ansible'})) == 0)

# Generated at 2022-06-23 11:33:49.580883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 11:33:58.332065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_class = LookupModule()

    test_terms = ['ansible.cfg']
    variables = {'role_paths': ['/home/ec2-user/ansible-role-test-fileglob/']}
    test_result = lookup_class.run(terms=test_terms, variables=variables)
    assert test_result == ['/home/ec2-user/ansible-role-test-fileglob/ansible.cfg']

    test_terms = ['ansible.cfg']
    variables = {'ansible_search_path': ['/home/ec2-user/']}
    test_result = lookup_class.run(terms=test_terms, variables=variables)
    assert test_result == ['/home/ec2-user/ansible.cfg']


# Generated at 2022-06-23 11:33:59.503367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule())

# Generated at 2022-06-23 11:34:10.200277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader

    filegen = lookup_loader.get('fileglob', class_only=True)()
    filegen.set_options({u'_ansible_check_mode': False,
                         u'_ansible_debug': False,
                         u'_ansible_diff': False,
                         u'_ansible_no_log': False,
                         u'_ansible_no_log_warnings': False})

    test_dir = filegen.find_file_in_search_path({u'ansible_search_path': [u'/home/test/a/b/c']}, u'files', u'.')
    test_dir_2

# Generated at 2022-06-23 11:34:12.093464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    is_file_glob = lm.run(['file.py'])
    assert is_file_glob

# Generated at 2022-06-23 11:34:15.704577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with open('test_file.txt', 'w') as fh:
        fh.write('test')
    assert len(LookupModule().run(['test_file.txt'])) == 1
    if os.path.exists('test_file.txt'):
        os.remove('test_file.txt')

# Generated at 2022-06-23 11:34:17.891883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert isinstance(lookup_mod, LookupModule)

# Generated at 2022-06-23 11:34:20.243675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.path.exists(LookupModule().run('*.py', {}))

# Generated at 2022-06-23 11:34:26.637333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    import ansible.plugins.lookup.fileglob

    input_terms = ['.txt']
    expected_result = ['.txt']

    lookup = ansible.plugins.lookup.fileglob.LookupModule()

    # Act
    result = lookup.run(input_terms)

    # Assert
    assert result == expected_result, 'Expected %s, got %s' % (expected_result, result)

# Generated at 2022-06-23 11:34:28.316812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Test method run of class LookupModule

# Generated at 2022-06-23 11:34:29.473090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:34:30.787163
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:34:40.680269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = os.path

# Generated at 2022-06-23 11:34:46.103742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test with no file match
    term = '/my/path/*.txt'
    result = lookup.run([term])
    assert result == []

    # Test with file match
    term = 'test.txt'
    result = lookup.run([term])
    assert result == [term]

# Generated at 2022-06-23 11:34:48.589871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # assert isinstance(LookupModule(), object)
    assert issubclass(LookupModule, object)
    return


# Generated at 2022-06-23 11:34:49.329750
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    assert module is not None

# Generated at 2022-06-23 11:34:57.752302
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:35:01.096677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Set a valid searchpath
    lookup.set_options({'_ansible_searchpath': '/my/path'})
    x = lookup.run(['../somefile.txt'], variables={})
    print(x)

# Generated at 2022-06-23 11:35:01.671138
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # boolean test for LookupModule
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:35:04.071532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        c = LookupModule()
    except NameError:
        print("cant create class")

# Generated at 2022-06-23 11:35:07.321172
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_instance = None
    try:
        lookup_instance = LookupModule()
    except Exception as e:
        raise AssertionError("Unexpected exception raised when creating LookupModule class instance: %s" % e)

    assert lookup_instance is not None

# Generated at 2022-06-23 11:35:10.864728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list_of_paths = lookup_module.run(terms = ['/test_file_dir/test_file.txt'])
    assert(list_of_paths[0] == '/test_file_dir/test_file.txt')

# Generated at 2022-06-23 11:35:18.210658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(['/my/path/*.txt'])
    assert lm.run(['/my/path/*.txt'], variables={'role_path': '/my/path'})
    assert lm.run(['/my/path/*.txt'], variables={'ansible_basedir': '/my/path'})
    assert lm.run(['/my/path/*.txt'], variables={'role_path': '/my/path', 'ansible_basedir': '/my/path'})

# Generated at 2022-06-23 11:35:28.103120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=["apollo.txt"], variables=dict(ansible_search_path=["/test/test_dir/test_dir2"]))
    assert set(result) == set(["/test/test_dir/test_dir2/files/apollo.txt"])

    result = lookup_module.run(terms=["/apollo.txt"], variables=dict(ansible_search_path=["/test/test_dir/test_dir2"]))
    assert set(result) == set(["/apollo.txt"])

    result = lookup_module.run(terms=["/not_there.txt"], variables=dict(ansible_search_path=["/test/test_dir/test_dir2"]))
    assert result == []

# Generated at 2022-06-23 11:35:37.491440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test ansible.plugins.lookup.fileglob LookupModule.run"""

    lookup = LookupModule()

    # Test that if no paths match, we get an empty list
    assert [] == lookup.run(['doesnotexist.txt'], variables={
        'ansible_search_path': ['/foo', '/bar'],
    })

    # Test that we find a file in a single path
    assert ['/foo/match.txt'] == lookup.run(['match.txt'], variables={
        'ansible_search_path': ['/foo'],
    })

    # Test that we find a file in the first of many paths
    assert ['/foo/match.txt'] == lookup.run(['match.txt'], variables={
        'ansible_search_path': ['/foo', '/bar'],
    })



# Generated at 2022-06-23 11:35:46.061190
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import pytest
    from ansible.parsing.dataloader import DataLoader

    options = {
        '_ansible_check_mode': False,
        '_ansible_debug': False,
        '_ansible_diff': True,
        '_ansible_verbosity': 1,
    }
    loader = DataLoader()

    terms = ['/my/path/*.txt']
    variables = {}
    lookup = LookupModule(loader=loader, **options)

    with pytest.raises(Exception) as exec:
        result = lookup.run(terms, variables)

# Generated at 2022-06-23 11:35:54.274762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy
    from ansible.parsing.dataloader import DataLoader

    lookup_module = LookupModule()

    # test for directory
    dl = DataLoader()
    test_dir = os.path.dirname(__file__)

    assert lookup_module.run(terms=['*'], variables={'ansible_search_path': [test_dir]}) == [to_text(os.path.join(test_dir, 'fileglob_plugin.py'))]

    # test for file
    assert lookup_module.run(terms=['fileglob_plugin.py'], variables={'ansible_search_path': [test_dir]}) == [to_text(os.path.join(test_dir, 'fileglob_plugin.py'))]
   

# Generated at 2022-06-23 11:36:04.454441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Case 1
    # Normal Case #1
    # Input:
    #       terms = ['/path/to/search/*.txt']
    #       variables = None
    # Expected Output:
    #       ret = ['/path/to/search/file1.txt', '/path/to/search/file2.txt', ...]
    # 
    # Actual Output:
    #       ret = FILL_IN
    #
    # Test Pass/Fail
    #       assert - FILL_IN
    # Test Complete: FILL_IN
    # 
    
    
    # Case 2
    # Normal Case #2
    # Input:
    #       terms = ['/path/to/search/file1.txt', '/path/to/search/file2.txt']
    #       variables

# Generated at 2022-06-23 11:36:05.302633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup
    assert lookup.run(None) is None

# Generated at 2022-06-23 11:36:08.530551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test whether the lookup_plugin constructor returns a object of LookupModule class
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:36:12.327315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    expected = ['./roles/test_role/files/test_list.txt']
    assert list(LookupModule().run(terms='test_list.txt', variables={'role_path': './roles/test_role'})) == expected


# Generated at 2022-06-23 11:36:20.276458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert ["/my/path/foo.txt", "/my/path/bar.txt"] == lookup.run(['/my/path/*.txt'], {})
    assert [] == lookup.run(['/my/path/*.txt'], {'ansible_search_path': []})
    assert ["/my/path/foo.txt", "/my/path/bar.txt"] == lookup.run(['/my/path/*.txt'], {'ansible_search_path': ['/my']})
    assert ["/my/path/foo.txt", "/my/path/bar.txt"] == lookup.run(['/my/path/*.txt'], {'ansible_search_path': ['/my/path']})

# Generated at 2022-06-23 11:36:31.023491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _params = {"basedir": "/Users/robert/Code/ansible_extra_modules/ansible/", "terms": ["molecule.yml"]}
    _instance = LookupModule()
    assert _instance.run(**_params) == ['/Users/robert/Code/ansible_extra_modules/ansible/molecule.yml']

    _params = {"basedir": "/Users/robert/Code/ansible_extra_modules/ansible/", "terms": ["molecule.y*"]}
    _instance = LookupModule()
    assert _instance.run(**_params) == ['/Users/robert/Code/ansible_extra_modules/ansible/molecule.yml']


# Generated at 2022-06-23 11:36:42.448163
# Unit test for constructor of class LookupModule
def test_LookupModule():

    if (sys.version_info > (3, 0)):
        assertRaisesRegex = self.assertRaisesRegexp
    else:
        assertRaisesRegex = self.assertRaisesRegex

    module = LookupModule()
    assert not hasattr(module, 'run')

    module = LookupModule(loader=DictDataLoader({}))
    assert not hasattr(module, 'run')

    module = LookupModule(loader=DictDataLoader({'_terms': []}))
    assert hasattr(module, 'run')

    assertRaisesRegex(AnsibleLookupError, "with_fileglob expects at least one path", module.run, [])


# Generated at 2022-06-23 11:36:45.010787
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    test_terms = ["/my/path/*.txt", "my/other/path/*.txt"]
    #lookup.run(test_terms)

# Generated at 2022-06-23 11:36:48.226785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.find_file_in_search_path = lambda self, variables, term, *args, **kwargs: '/path'
    assert ['file1', 'file2'] == LookupModule().run([
                                    "file1",
                                    "file2"
                                ])



# Generated at 2022-06-23 11:36:59.400096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ LookupModule - run() """
    # Testing empty messages
    check_results = []
    check_results.append(["Finds files from the search path given a file", [], {'ansible_search_path': ['test/', 'test1/']},
                                                                           ['test/file'], {'_ansible_check_mode': False, '_ansible_no_log': False, 'ansible_search_path': ['test/', 'test1/'], 'wantlist': False},
                                                                           'test/file'])

# Generated at 2022-06-23 11:37:10.662659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVars(object):
        def __init__(self, searchpath=None):
            if not searchpath:
                searchpath = [os.getcwd()]
                searchpath.append('/etc')
            self.ansible_search_path = searchpath

    # Test for success
    mock_vars = MockVars()
    lookup_module = LookupModule()
    terms = ["hosts"]
    res = lookup_module.run(terms, mock_vars, wantlist=True)
    assert terms[0] in res

    # Test for failure
    lookup_module = LookupModule()
    terms = ["hosts_nonexistent"]
    res = lookup_module.run(terms, mock_vars, wantlist=True)
    assert not res

# Generated at 2022-06-23 11:37:12.239273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:37:23.041851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testing files in ansible base directory (which is ansible/lookup
    test_lookupModule = LookupModule()

    # test if file in the directory exists
    result = test_lookupModule.run(['simple.py'],{'ansible_search_path':['.']})
    assert result == ['simple.py']

    # test for a file with different directory
    result = test_lookupModule.run(['simple.py'],{'ansible_search_path':['/etc/ansible']})
    assert result == []

    # test for a file with different directory
    result = test_lookupModule.run(['simple'],{'ansible_search_path':['/etc/ansible']})
    assert result == []

    # test for an invalid file
    result = test_lookupModule.run

# Generated at 2022-06-23 11:37:24.662304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create test environment
    lookup = LookupModule()
    lookup.set_options({})
    result = lookup.run(terms=['a*.sh'], variables=None, wantlist=True)
    assert(result == ['a.sh'])

# Generated at 2022-06-23 11:37:33.851933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    module = LookupModule()
    terms = [
        '/home/user/ansible/roles/test-role/tasks/main.yml',
        'unittest.txt',
    ]
    variables = dict(
        ansible_search_path=['/home/user/ansible/roles'],
    )

    # run
    result = module.run(terms, variables, wantlist=False)

    # assert
    assert result[0] == '/home/user/ansible/roles/test-role/tasks/main.yml'
    assert result[1] == '/home/user/ansible/roles/unittest.txt'

# Generated at 2022-06-23 11:37:42.229382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_terms(terms, result_expected):
        results = LookupModule().run(terms, None)
        assert results == result_expected

    # test dir/file pattern
    test_terms(["does/not/exist"], [])
    test_terms(["/does/not/exist"], [])
    test_terms(["./does/not/exist"], [])
    test_terms(["does/not/exist.txt"], [])
    test_terms(["does/not/exist*"], [])
    test_terms(["does*/not/exist*"], [])

    # test file pattern
    test_terms(["tests/unit/lookup_plugins/fileglob/files/a"], ["tests/unit/lookup_plugins/fileglob/files/a"])

# Generated at 2022-06-23 11:37:52.781686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Test of class LookupModule')
    # test args
    print('Test args')
    from ansible import context
    from ansible.context import CLIContext
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

# Generated at 2022-06-23 11:38:01.470582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(LookupModule, '/path/to/one_file', variables = None, wantlist=True) == ['/path/to/one_file']
    assert LookupModule.run(LookupModule, ['/path/to/one_file'], variables = None, wantlist=True) == ['/path/to/one_file']
    assert LookupModule.run(LookupModule, ['one_file', 'one_dir/two_file'], variables = None, wantlist=True) == ['one_file']
    assert LookupModule.run(LookupModule, ['one_dir/two_file', 'one_dir/two_dir/three_file'], variables = None, wantlist=True) == ['one_dir/two_file']

# Generated at 2022-06-23 11:38:12.686864
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a single file
    lm = LookupModule()
    terms = ['./test/testfile.txt']
    ret = lm.run(terms, None)
    assert ret == ['./test/testfile.txt']

    # Test with a single non-existant file
    lm = LookupModule()
    terms = ['./test/doesnotexist.txt']
    ret = lm.run(terms, None)
    assert ret == []

    # Test with multiple files
    lm = LookupModule()
    terms = ['./test/testfile*.txt']
    ret = lm.run(terms, None)
    assert ret == ['./test/testfile.txt', './test/testfile2.txt', './test/testfile3.txt']

    # Test with a non-

# Generated at 2022-06-23 11:38:13.869107
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:38:18.025650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu.run(['test/test.txt']) == ['test/test.txt']
    assert lu.run(['test/test*.txt']) == ['test/test1.txt', 'test/test2.txt', 'test/test3.txt']

# Generated at 2022-06-23 11:38:29.033996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C

    C.HOST_KEY_CHECKING = False
    C.ANSIBLE_SSH_RETRIES = 0
    C.ANSIBLE_SSH_CONTROL_PATH = "/tmp/%%h-%%r"
    C.ANSIBLE_LOCAL_TEMP = "/tmp"
    C.ANSIBLE_PIPELINING = False

    l = LookupModule()
    import sys
    sys.path.append("/home/qe/git/ansible/lib/ansible/plugins/lookup")
    import fileglob
    x = fileglob.LookupModule()
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

# Generated at 2022-06-23 11:38:29.615203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:38:40.113505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping

    from ansible.plugins.loader import lookup_loader, filter_loader
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lookup_plugins'))
    lookup_loader._lookups.update(filter_loader._lookups)

    class Void():
        def __init__(self):
            self.settings = {}

    loader = DataLoader()
    host = Host()
    group = Group()