

# Generated at 2022-06-23 11:28:36.513060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-23 11:28:38.344900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert type(lm) == LookupModule

# Generated at 2022-06-23 11:28:38.978301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return glob.glob

# Generated at 2022-06-23 11:28:40.615274
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cLookupModule = LookupModule()
    assert cLookupModule

# Generated at 2022-06-23 11:28:41.607268
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:28:49.709339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # Create an instance of LookupModule
    lookup_obj = LookupModule()

    # Check for positive test case
    assert lookup_obj.run(['*.yml'], {'ansible_basedir': '/srv/project/'}) == []

# Generated at 2022-06-23 11:28:53.271534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    first_term = ['test_path']
    variables={}
    LookupModule.run(first_term,variables,"")


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:29:04.325229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    kwargs = {}
    kwargs['variables'] = {}
    kwargs['variables']['ansible_search_path'] = []
    kwargs['variables']['ansible_search_path'].append('/tmp')
    kwargs['variables']['ansible_search_path'].append('/tmp/ansible')
    kwargs['variables']['ansible_search_path'].append('/tmp/ansible2')
    kwargs['variables']['ansible_search_path'].append('/tmp/ansible3')
    lm = LookupModule()
    lm.get_basedir = MagicMock()
    lm.get_basedir.return_value = '/tmp'
    lm.find_file_in

# Generated at 2022-06-23 11:29:07.300214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testobj = LookupModule()
    results = testobj.run(terms=['*.m'], variables=None, **{})
    print(results)


# Generated at 2022-06-23 11:29:08.787161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(isinstance(lookup, LookupModule))

# Generated at 2022-06-23 11:29:16.286986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    ret =  lookup_module.run(['.*txt'], variables=[])

if __name__ == "__main__":
    lookup_module = LookupModule()
    print("lookup_module:",lookup_module)
    print("lookup_module.run:",lookup_module.run)
    print("lookup_module.run(['.*txt'], variables=None):",lookup_module.run(['.*txt'], variables=None))
    print("lookup_module.run(['.*txt'], variables=[]):", lookup_module.run(['.*txt'], variables=[]))
    #test_LookupModule()

# Generated at 2022-06-23 11:29:18.997245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=['a','b/c','d/e/f'])
    l.run(terms=[''])

# Generated at 2022-06-23 11:29:19.727554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:29:22.293574
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# test_strlist_to_list is a unit test function for function srtlist_to_list

# Generated at 2022-06-23 11:29:23.799710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:29:24.808881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 11:29:25.780671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test constructing LookupModule")


# Generated at 2022-06-23 11:29:35.895109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Method run() of the LookupModule class is the method that finds all the files specified in the lookup method
    from a file. This method is used extensively in Ansible playbooks, modules, etc.
    """

    # Initialize the LookupModule
    lookup_module = LookupModule()

    # First, create a temporary directory for testing.
    # Store it in a variable so it can be deleted later
    test_dir = tempfile.mkdtemp()
    base_dir = test_dir + "/" + "lookup_dir"

    # Create the lookup_dir folder which is the base directory
    # In this test, it is also created in the temporary directory
    # created earlier
    os.mkdir(base_dir)

    # Create a file in the lookup_dir folder and write a line to it.
    # The name of the file

# Generated at 2022-06-23 11:29:42.551619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert Callables.mock_lookup_injector.call_count == 0
    assert Callables.mock_glob.call_count == 0

    assert LookupModule(_loader=MockLoader(), basedir=MockBasedir()).run(terms=['/home/foo/*.txt', '/home/bar/*.txt'], inject={}, variables={}) == ['file/home/foo/1.txt', 'file/home/foo/2.txt', 'file/home/bar/1.txt', 'file/home/bar/2.txt']

    assert Callables.mock_glob.call_count == 1
    assert Callables.mock_glob.call_args_list[0][0][0] == "/home/foo/*.txt"
    assert Callables.mock_glob.call_args_

# Generated at 2022-06-23 11:29:45.626408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Arrange
    terms = ['filetest']
   
    # Act
    lm = LookupModule()
    lm.run(terms)
    
    # Assert
    assert lm != None

# Generated at 2022-06-23 11:29:55.503488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # for fileglob, the following is equivalent:
    #    some_dir/file_glob_pattern
    #    file_glob_pattern
    # but the result will be different from find, which will iterate all files
    # in the directory.  So we test both.
    assert set(lm.run(['some_dir/test_*.txt'])) == set(['some_dir/test_one.txt', 'some_dir/test_two.txt'])
    assert set(lm.run(['test_*.txt'])) == set(['test_one.txt', 'test_two.txt'])


# Generated at 2022-06-23 11:29:56.594049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 11:30:00.070998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["/tmp", "/path/to/*.conf"]
    variables = {}
    kwargs = {}
    results = module.run(terms=terms, variables=variables, **kwargs)
    print(results)

# Generated at 2022-06-23 11:30:07.376208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()
    test_term_1 = '*.txt'
    test_term_2 = '/my/path/*.txt'
    test_variables = {}
    # test 1
    result = test_lookup_module.run([test_term_1])
    assert result == []
    # test 2
    result = test_lookup_module.run([test_term_2], variables=test_variables)
    assert result == ['/my/path/hello.txt']

# Generated at 2022-06-23 11:30:08.708099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:30:11.265900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/my/path/*.txt']
    wantlist = True
    result = lookup_module.run(terms, wantlist=wantlist)
    print(result)

# Generated at 2022-06-23 11:30:19.091161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    options = {'basedir': './test/unit/lookup_plugins/fileglob'}
    gl = LookupModule(**options)
    gl.run_terms = ["test"]

    # Paths are not valid
    assert gl.run_terms == []

    # Test with no paths
    options = {'basedir': '.'}
    gl = LookupModule(**options)
    gl.run_terms = ["test"]

    # Paths are not valid
    assert gl.run_terms == []

# Generated at 2022-06-23 11:30:29.795704
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """
        def __init__(self):
            super(ResultCallback, self).__init__()
            self.results = []
            self.count = 0

# Generated at 2022-06-23 11:30:30.782877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:30:41.743837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.getcwd() == os.path.dirname(os.path.realpath(__file__))
    assert os.path.basename(os.path.dirname(os.path.realpath(__file__))) == 'lookup_plugins'

    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests', os.environ.get('ANSIBLE_DATA_DIR', 'data')), 'r') as fobj:
        data_list = fobj.readlines()

    assert len(data_list) == 3
    assert data_list[0].replace('\n', '') == 'lookup_plugins/data/foo'
    assert data_list[1].replace('\n', '') == 'lookup_plugins/data/foo.txt'


# Generated at 2022-06-23 11:30:47.124281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test_LookupModule")
    my_module = LookupModule()
    # I don't suppose there is a better way of determining the module's
    # base path than this
    path = os.path.split(os.getcwd())[0]
    assert my_module.get_basedir(
        dict()) == os.path.join(path, 'lookup_plugins')
    assert my_module.get_basedir(
        dict(ansible_lookup_plugins='/some/other/place')) == '/some/other/place'



# Generated at 2022-06-23 11:30:49.769674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _LookupModule = LookupModule()
    print("Constructed")
    return _LookupModule


# Generated at 2022-06-23 11:30:51.136888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:30:52.692135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:31:00.369734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    modules_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules')
    results = module.run(terms=['*'], variables={'ansible_search_path': [modules_dir]})
    assert os.path.exists(os.path.join(modules_dir, results[0]))
    assert len(results) == len(os.listdir(modules_dir))
    # There is a file named '*' in test/lib/ansible/modules/extras
    results = module.run(terms=['*'], variables={'ansible_search_path': [modules_dir+'/extras']})

# Generated at 2022-06-23 11:31:12.028334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create new instance of LookupModule class with
    # ansible.module_utils._text.to_bytes and
    # ansible.module_utils._text.to_text mocks

    glob_mock = Mock(return_value=['files/test_files/1.out'])
    fileglob_class_mock = Mock()
    fileglob_class_mock.configure_mock(**{
        'find_file_in_search_path.return_value': 'files',
        'get_basedir.return_value': None,
        'glob.glob.return_value': ['files/test_files/1.out'],
        'to_text.return_value': 'files/test_files/1.out'
    })

    # Run method run of LookupModule with
    #

# Generated at 2022-06-23 11:31:21.906034
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # verify this class is a subclass of LookupBase
    assert issubclass(LookupModule, LookupBase)

    # Create a new instance of LookupModule class
    my_test_class = LookupModule()

    # unit tests for methods:
    #    get_basedir
    #    find_file_in_search_path
    my_basedir = my_test_class.get_basedir({"roles_path": ["/a/dir","/etc/dir2"]})
    assert my_basedir == "/a/dir"
    my_basedir = my_test_class.get_basedir({"roles_path": ["/etc/dir2","/a/dir"]})
    assert my_basedir == "/a/dir"

# Generated at 2022-06-23 11:31:32.729843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # empty term:
    result = LookupModule().run([''])
    assert(result == [])

    # non existing file:
    result = LookupModule().run(['/does/not/exist'])
    assert(result == [])

    # existing file:
    result = LookupModule().run(['/usr/share/python-docs-3.4/python.1.gz'])
    assert(result == ['/usr/share/python-docs-3.4/python.1.gz'])

    # existing file, with a directory:
    result = LookupModule().run(['/usr/share/python-docs-3.4/python.1.gz'])
    assert(result == ['/usr/share/python-docs-3.4/python.1.gz'])

    # another existing file, with

# Generated at 2022-06-23 11:31:33.351563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:31:36.222621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    lookup = LookupModule()
    variables = None
    terms = ["/Users/thulasi/Ansible-Test/README.md"]
    result = lookup.run(terms,variables)
    #print("result",result)
    assert result[0]

# Generated at 2022-06-23 11:31:45.839902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    temp_dir = tempfile.mkdtemp()
    file1 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    file1.close()
    file2 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    file2.close()
    file3 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    file3.close()
    my_class = LookupModule()
    my_terms = ["foo", os.path.join(temp_dir, "*")]
    result = my_class.run(my_terms)
    os.remove(file1.name)
    os.remove(file2.name)
    os.remove(file3.name)
    os.rmdir(temp_dir)
   

# Generated at 2022-06-23 11:31:48.210461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except:
        assert False, "Unit test for constructor of class LookupModule failed."


# Generated at 2022-06-23 11:31:53.673288
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        'a',
        'b',
        'c/d/e',
        'c/d/f',
        'c/d/g',
        'c/d/h',
        'c/d/i',
        'c/d/j',
        'j',
        'k'
    ]

    variables = { 'ansible_search_path': [
        '/test/path/a',
        '/test/path/b',
        '/test/path/c',
        '/test/path/d',
        '/test/path/e'
    ] }

    # The 'g' and 'h' items are skipped because they are directories.

# Generated at 2022-06-23 11:32:02.659439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure that fileglob lookup is working correctly
    lookup = LookupModule()

    # Test with a pattern not matching any files
    terms = ['invalid_pattern']
    cwd = os.path.dirname(__file__)
    lookup.set_basedir(cwd)
    files = lookup.run(terms, {})
    assert len(files) == 0

    # Test with a pattern matching 1 file
    terms = ['*.py']
    files = lookup.run(terms, {})
    assert len(files) == 1
    # Check that we are in the correct directory and the correct file pattern is returned
    assert os.path.dirname(files[0]) == cwd
    assert os.path.basename(files[0]) == 'fileglob_lookup_plugin_test.py'

    # Test with a

# Generated at 2022-06-23 11:32:03.404988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test

# Generated at 2022-06-23 11:32:09.225134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    test_dir = tempfile.mkdtemp()
    test_filename_one = os.path.join(test_dir, 'one.txt')
    test_filename_two = os.path.join(test_dir, 'two.txt')

    # create test files
    open(test_filename_one, 'a').close()
    open(test_filename_two, 'a').close()

    test_param_one = 'one.txt'
    test_param_two = '*.txt'

# Generated at 2022-06-23 11:32:11.911223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 11:32:21.089305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Create temporary file
    temp_txt_path = '../plugins/lookup/unit_test.txt'
    with open(temp_txt_path, "w") as temp_txt:
        temp_txt.close()

    # Create test objects
    lu = LookupModule()
    var_mgr = VariableManager()
    loader = DataLoader()

    # Create variables for the lookup module
    task_vars = dict()
    task_vars['ansible_search_path'] = os.path.split(os.path.realpath(__file__))[0]

    # Run unit test

# Generated at 2022-06-23 11:32:31.473854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test module run with valid and invalid string
    from ansible_collections.ansible.lookup_plugins.tests.unit.plugins.lookup.fixtures import LookupModule as TestModule
    from ansible_collections.ansible.lookup_plugins.tests.unit.plugins.lookup.fixtures import TestLookupModule as BaseClass

    for term in ['data_*.txt', 'data_*.invalid']:
        tester = TestModule(basedir="data")
        output = tester.run(terms=[term], variables={'ansible_search_path':['data', 'data/files', 'data/files/invalid']})
        assert isinstance(output, list)
        assert len(output) == 2

        # Empty list
        # tester = TestModule(basedir="data")
        # output = tester.

# Generated at 2022-06-23 11:32:33.153595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)


# Generated at 2022-06-23 11:32:37.530992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Tests for the LookupModule.run method
    """
    #Creating an instance of LookupModule class
    look = LookupModule()

    #Creating a dictionary which contains path of files
    result = look.run(terms=['myFile.txt'], variables={})
    assert result == []


#if __name__ == '__main__':
#    test_LookupModule_run()

# Generated at 2022-06-23 11:32:38.399323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-23 11:32:41.674801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    terms = ['test.txt']
    variables = {}
    variables['ansible_search_path'] = ["/test_path"]
    result = lookup.run(terms, variables, wantlist=True)
    assert(len(result) == 1)

# Generated at 2022-06-23 11:32:49.291499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_list = ['foo.txt', '/tmp/bar.txt', '*.txt', '/tmp/my.txt', 'my.txt']
    #return actual_result_1, actual_result_2, actual_result_3, actual_result_4, actual_result_5
    return LookupModule().run(terms_list,
                            variables={'ansible_search_path': ['/root/test/test_LookupModule_run/x', '/root/test/test_LookupModule_run/y']})

# Generated at 2022-06-23 11:32:53.661551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for fileglob for matching a pattern
    lookup_runner = LookupModule()
    lookup_runner.basedir = "test/test_lookup/"
    terms = ["test_fileglob.txt"]
    result = lookup_runner.run(terms)
    assert result == ["test/test_lookup/test_fileglob.txt"]
    print(result)

# Generated at 2022-06-23 11:33:04.621149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import mk_boolean
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    p = Play()
    d = dict(
        foo = dict(
            bar = dict(
                baz = 'xyz'
            )
        )
    )

    host = '127.0.0.1'

    inventory = InventoryManager(loader=DataLoader(), sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)

    pb = p.get_vars()
   

# Generated at 2022-06-23 11:33:06.131062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:33:15.209781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    variable_manager._extra_vars = {'ansible_search_path': ['/my/path']}

# Generated at 2022-06-23 11:33:20.856907
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule constructor")
    L = LookupModule()
    print(L)
    assert L is not None
    print("Testing LookupModule constructor: PASS")
    print("Testing LookupModule run() method")
    print("Testing LookupModule run() method: PASS")
    print("Testing LookupModule run() method: END")



# Generated at 2022-06-23 11:33:23.616395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    test_lookup.set_loader('test_loader')
    assert test_lookup

# Generated at 2022-06-23 11:33:27.084390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule - run"""
    l = LookupModule()
    assert l.run(( ' ',)) == []
    assert l.run(( '',)) == []
    assert l.run(( 'foo',)) == []
    assert l.run(( 'foo/*.foo',)) == []

# Generated at 2022-06-23 11:33:29.228702
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({})
    assert lookup_plugin.get_options() == {}

# Generated at 2022-06-23 11:33:30.683989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {'_terms': '/my/path/*.txt'}
    lm = LookupModule()
    lm.run(data)

# Generated at 2022-06-23 11:33:32.111032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.run([], {}, wantlist=False)

# Generated at 2022-06-23 11:33:32.774864
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:33:39.405194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(["LookupModule.py"], variables={"ansible_search_path":["."]}) == ["LookupModule.py"]
    assert l.run(["test_LookupModule_run.py"], variables={"ansible_search_path":["."]}) == ["test_LookupModule_run.py"]
    assert l.run(["notarealfile.py"], variables={"ansible_search_path":["."]}) == []
    assert l.run(["notarealfile.py"], variables={"ansible_search_path":["."]}) == []

# Generated at 2022-06-23 11:33:45.664630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test for constructor of class LookupModule
    test_file = os.path.dirname(os.path.realpath(__file__))
    test_lookup = LookupModule()
    test_lookup.find_file_in_search_path(test_file, 'files', '../')
    assert isinstance(test_lookup, LookupModule)

# Generated at 2022-06-23 11:33:56.503337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = open("/tmp/test_fileglob_0.txt", "w+")
    f.close()
    f = open("/tmp/test_fileglob_1.txt", "w+")
    f.close()
    f = open("/tmp/test_fileglob_2.txt", "w+")
    f.close()
    # case: return empty list
    terms = ["/tmp/fileglob_test_not_exist.txt"]
    expected_result = []
    assert expected_result == LookupModule().run(terms)
    # case: return list with a single file matched
    terms = ["/tmp/test_fileglob_[0-2].txt"]

# Generated at 2022-06-23 11:33:58.160826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj is not None

# Generated at 2022-06-23 11:33:59.353935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-23 11:34:10.072076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=E0602
    global LookupModule
    
    # Prepare test
    class MockLookupBase(object):
        def find_file_in_search_path(self, variables, file_name, path_name):
            if path_name == '/my/path':
                return 'my/path/'
            elif path_name == '/playbooks/files/fooapp':
                return 'playbooks/files/fooapp/'
            else:
                return None
        def get_basedir(self, variables):
            return '/etc/'
    LookupModule.LookupBase = MockLookupBase
    lookup_module = LookupModule()
    terms = ['/my/path/*.txt', '/playbooks/files/fooapp/*']

# Generated at 2022-06-23 11:34:10.620049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:34:11.501928
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:34:14.834701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(['*.py'], variables={})
    # return list only contains files in current directory which end with .py
    for f in ret:
        assert f.endswith('.py')
        assert os.path.isfile(f)

# Generated at 2022-06-23 11:34:15.662700
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lum = LookupModule()
    assert lum is not None

# Generated at 2022-06-23 11:34:19.461105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = 'fileglob.py'
    lookup_module = LookupModule()

    # first test in case filename is given
    result = lookup_module.run([ret])
    assert ret in result

# Generated at 2022-06-23 11:34:22.276102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test creating an instance of LookupModule
    lookup_plugin = LookupModule()
    assert lookup_plugin



# Generated at 2022-06-23 11:34:25.848522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing LookupModule constructor')
    lookup_module = LookupModule('/src/ansible/shipping_ansible/ship/library')
    # Need a better test for this
    assert lookup_module is not None


# Generated at 2022-06-23 11:34:26.455217
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:34:30.007667
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    if not lookup:
        raise Exception('LookupModule not returned')
    if not isinstance(lookup, LookupModule):
        raise Exception('LookupModule instance not returned')

# Generated at 2022-06-23 11:34:31.361673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert(isinstance(L, LookupModule))

# Generated at 2022-06-23 11:34:41.079569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}

# Generated at 2022-06-23 11:34:52.333218
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestVariables(dict):
        def get(self, key, *args, **kwargs):
            return super(TestVariables, self).get(key, *args, **kwargs)

    module = LookupModule()
    # Test for error of LookupBase
    assert module.run(['test.txt'], TestVariables(ansible_search_path=['/test/dir'])) == []

    # Test for find pattern with dirname
    assert module.run(['path/test.txt'], TestVariables(ansible_search_path=['/test/dir'])) == []

    # Test for find pattern with filename
    assert module.run(['test.txt'], TestVariables(ansible_search_path=['/test/dir'])) == []

# Generated at 2022-06-23 11:34:54.016963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tmp = LookupModule()
    assert tmp

# Generated at 2022-06-23 11:34:56.180435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:34:58.938185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # When
    result = lm.run(['/my/path/*.txt'])
    # Then
    assert result is not None

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:35:03.047320
# Unit test for constructor of class LookupModule
def test_LookupModule():

    os.environ['ANSIBLE_CONFIG'] = 'tests/ansible.cfg'
    os.environ['ANSIBLE_DATA_DIR'] ='test/testdata'

    lookup = LookupModule()
    t = "/testdata/testfile.txt"
    results = lookup.run([t])
    assert results == ['/test/testdata/testfile.txt'], results

# Generated at 2022-06-23 11:35:09.474038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Execute the run method with the parameters it was expecting - terms and variables
    terms = ['/etc/ansible/foobar']
    variables = {
        'ansible_search_path': ['.', '~/playbooks/library', '~/playbooks/filter_plugins'],
        'playbook_dir': '/tmp/ansible/playbooks'
    }
    ret = lookup.run(terms, variables)
    assert ret == ['/etc/ansible/foobar']

# Generated at 2022-06-23 11:35:11.896582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    print (lm.run(['*']))

# Generated at 2022-06-23 11:35:18.010477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lc = LookupModule()
    terms = ["hosts"]
    variables = { 'ansible_search_path': ["/home/ansible/playbook"] }
    assert lc.run(terms, variables, wantlist=True) == ["/home/ansible/playbook/hosts"]

    # file not found
    assert lc.run([ 'localhost' ], variables, wantlist=True) == []

# Generated at 2022-06-23 11:35:27.927588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unicode import to_bytes

    test_object = LookupModule()

# Generated at 2022-06-23 11:35:37.340333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import shutil
    from tempfile import mkdtemp
    from ansible.plugins.lookup import LookupModule


# Generated at 2022-06-23 11:35:42.443619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = {'ansible_search_path': ['/home/gawor']}
    lookup = LookupModule()
    paths = lookup.run(terms=['*.txt'], variables=hostvars)
    assert paths == ['/home/gawor/ansible.txt']

# Generated at 2022-06-23 11:35:44.213687
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # If no exception is raised here, the constructor is okay.
    pass

# Generated at 2022-06-23 11:35:45.327107
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 11:35:55.034107
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('fileglob', basedir=None, variables=None)

    expected_results = ['/my/path/file1.txt', '/my/path/file2.txt', '/my/path/file3.txt']
    assert lookup.run(['/my/path/*.txt']) == expected_results, lookup.run(['/my/path/*.txt'])
    expected_results = ['/my/path/sub1/sub2/sub3/sub4/file4.txt', '/my/path/sub1/sub2/sub3/sub4/file5.txt']

# Generated at 2022-06-23 11:36:01.252473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["*.txt", "/some/folder/*.txt"]
    variables = {'ansible_search_path': ['/some/folder']}
    ret = lookup.run(terms, variables, wantlist=True)
    assert ret is not None
    assert len(ret) > 0
    assert ret[0].split('/')[-1] == "test1.txt"

# Generated at 2022-06-23 11:36:12.168601
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile

    test_dir = os.path.realpath(os.path.dirname(__file__))

    global_test_dir = tempfile.mkdtemp()
    global_module_path = os.path.join(global_test_dir, 'plugins', 'lookup', 'fileglob')
    os.makedirs(global_module_path)
    global_mytest_path = os.path.join(global_test_dir, 'mytest')
    os.makedirs(global_mytest_path)

    local_modules_path = os.path.join(global_test_dir, 'roles', 'test_role', 'plugins', 'lookup', 'fileglob')
    os.makedirs(local_modules_path)

# Generated at 2022-06-23 11:36:17.562705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        ['/path/to/file/bar.txt', '/path/to/file/foo.txt'],
        {'noop': False, 'ansible_search_path': ['path/to/file']}
    )
    assert '/path/to/file/bar.txt' in ret
    assert '/path/to/file/foo.txt' in ret

# Generated at 2022-06-23 11:36:28.896660
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1: lookup fileglob
    test_term = '/tmp/test1.py'
    lm = LookupModule()
    ret = lm.run(terms=[test_term])
    assert len(ret) == 1
    assert ret[0] == test_term

    # Test case 2: lookup fileglob
    test_term = 'test2.py'
    lm = LookupModule()
    ret = lm.run(terms=[test_term])
    assert len(ret) == 1
    assert ret[0] == test_term

    # Test case 3: lookup fileglob
    test_term = '/tmp/test3.py'
    lm = LookupModule()
    ret = lm.run(terms=[test_term])
    assert len(ret) == 0

# Generated at 2022-06-23 11:36:31.181783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 11:36:36.461073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_basedir(None) == '.'
    terms = ['myfile', 'mydir/myfile']
    variables = {'ansible_search_path': ['../files/foo', 'files']}
    assert l.run(terms, variables) == []



# Generated at 2022-06-23 11:36:42.447779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test case 1
    # Test without search path
    # Test without fileglob
    terms = ["file."]
    res = lookup_module.run(terms)
    assert res == []

    # Test case 2
    # Test with search path
    # Test without fileglob
    terms = ["file.txt"]
    res = lookup_module.run(terms)
    assert res == []

# Generated at 2022-06-23 11:36:49.299160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test filesglob in a sub directory
    assert ['fileglob-test.txt'] == lookup_module.run([
        lookup_module._loader.path_dwim_relative('./plugins/lookup-tests/fileglob-test/fileglob-test.txt')],
        dict(ansible_search_path='lookup_plugins'))

    # Test fileglob for files in the root directory
    assert ['fileglob-test.txt'] == lookup_module.run([
        lookup_module._loader.path_dwim_relative('./plugins/lookup-tests/fileglob-test.txt')],
        dict(ansible_search_path='lookup_plugins'))

    # Test fileglob for a directory
    assert [] == lookup_module.run

# Generated at 2022-06-23 11:36:59.867002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # files exist in search paths 
    terms = ["test.txt", "test.sh"]
    variables = {
        "ansible_search_path": ['/test']
    }
    assert lookup_module.run(terms, variables) == ['/test/files/test.txt', '/test/files/test.sh']
    # files exist in search paths, with matched basedir
    terms = ["test.txt"]
    variables = {
        "ansible_search_path": ['/test'],
        "_ansible_basedir": "/test/files"
    }
    assert lookup_module.run(terms, variables) == ['/test/files/test.txt']
    # files exist in search paths, with unmatched basedir
    terms = ["test.txt"]

# Generated at 2022-06-23 11:37:01.311060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule) > 0
# Test the LookupModule class

# Generated at 2022-06-23 11:37:03.367928
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-23 11:37:05.566259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor of LookupModule
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-23 11:37:06.570867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-23 11:37:11.901033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['tests/fileglob.txt']) == ['/tmp/ansible/tests/fileglob.txt']


# # Unit test for method run of class LookupModule
# def test_LookupModule_run_with_wantlist_false():
#     assert LookupModule().run(['tests/fileglob.txt'], wantlist=False) == '/tmp/ansible/tests/fileglob.txt'

# Generated at 2022-06-23 11:37:13.144808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 11:37:23.840832
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # original fileglob lookup from ansible
    lookup_fileglob = LookupModule()

    # create custom lookup for testing
    class LookupModuleForTest(LookupModule):
        def __init__(self):
            self.run_was_called = False

        def run(self, terms, variables=None, **kwargs):
            self.run_was_called = True
            return lookup_fileglob.run(terms, variables, **kwargs)

    # create instance of custom lookup
    lookup_fileglob_test = LookupModuleForTest()

    # call run of custom lookup

# Generated at 2022-06-23 11:37:26.418446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['/test/files/*.txt'], None) == []
    assert LookupModule().run(['my_test.txt'], None) == []

# Generated at 2022-06-23 11:37:29.252880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/my/path/*.txt']
    assert lookup.run(terms) == ['/my/path/*.txt']

# Generated at 2022-06-23 11:37:39.308594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.lookup.fileglob import LookupModule
    f = LookupModule()
    terms = []
    path = "tests/test_lookup/fileglob_test"
    for fname in os.listdir(path):
        full_path = os.path.join(path, fname)
        if os.path.isfile(full_path):
            terms.append(full_path)

    variables = {
        'ansible_search_path': ['tests/test_lookup/fileglob_test'],
    }
    assert f.run(terms, variables=variables, wantlist=True) == terms

    terms = []
    path = "tests/test_lookup/fileglob_test"
    for fname in os.listdir(path):
        full_path = os.path

# Generated at 2022-06-23 11:37:49.089963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Creating a lookup module object
    lookup_module = LookupModule()
    # Creating a Mock class of class LookupBase
    mock_lookup_base = MockLookupBase()
    lookup_module.set_loader(mock_lookup_base)
    # Creating a list of arguments to be passed to method run
    term = ["/home/ansible/test/testfile.txt", "/home/ansible/test/testfile1.txt"]
    variables = {"ansible_search_path":"/home/ansible/test"}
    # Performing unit test
    assert lookup_module.run(term,variables) == ["/home/ansible/test/testfile.txt","/home/ansible/test/testfile1.txt"]

# Generated at 2022-06-23 11:37:52.163290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    terms = ['test']
    # Test
    ret = t.run(terms, variables=None , **{})

    assert ret == []

# Generated at 2022-06-23 11:37:53.751755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run('/playbooks/files/fooapp/*') == []

# Generated at 2022-06-23 11:37:57.898712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.module_utils.six import StringIO

    lookup = LookupModule()
    path = ['~/test.md']
    if sys.version_info[0] == 3:
        path = [os.path.expanduser(p) for p in path]
    result = lookup.run(path)
    assert result == path

# Generated at 2022-06-23 11:37:58.971064
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:38:10.779296
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 1
    terms=['pattern'],
    lookup_module_case_1 = LookupModule()
    result_lookup_module_case_1 = lookup_module_case_1.run(terms)

    # Case 2
    terms=['pattern'],
    lookup_module_case_2 = LookupModule()
    result_lookup_module_case_2 = lookup_module_case_2.run(terms)

    # Case 3
    terms=[],
    lookup_module_case_3 = LookupModule()
    result_lookup_module_case_3 = lookup_module_case_3.run(terms)

    # Case 4
    terms=[''],
    lookup_module_case_4 = LookupModule()
    result_lookup_module_case_4 = lookup_module_case_4.run

# Generated at 2022-06-23 11:38:14.468153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()
    paths = test_module.run(terms=['/usr/local/*'], variables={})
    assert paths == []

# Generated at 2022-06-23 11:38:22.887560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that we can get a list of file paths from a user-defined search path
    # when the user passes a relative path to the fileglob lookup.
    import ansible.plugins.lookup.fileglob as fileglob
    reload(fileglob)
    mylookup = fileglob.LookupModule()
    mylookup.get_basedir = lambda variables: '/test/roles/myrole'
    mylookup.find_file_in_search_path = lambda variables, dirname, path: '/test/roles/myrole/files/'
    assert mylookup.run(['myfile.txt'], {}, {}) == ['/test/roles/myrole/files/myfile.txt']

# Generated at 2022-06-23 11:38:34.108539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock class LookupBase
    class LookupBaseMock:

        class AnsibleFileNotFoundException(Exception):
            pass

        def get_basedir(self, variables):
            return 'basedir'

        def find_file_in_search_path(self, variables, subdir, basedir=None):
            return 'found_path'

        def _loader(self, terms, variables=None, **kwargs):
            return terms
    # mock os, glob
    import os
    import glob
    os.path.join = lambda x: x
    glob.glob = lambda x: x

    # test run
    lookup_module = LookupModule(LookupBaseMock())
    assert lookup_module.run(["test"]) == ['basedir/test', 'found_path/test']
    assert lookup_module.run

# Generated at 2022-06-23 11:38:38.607932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyLookupBase(LookupBase):
        def get_basedir(self, variables):
            return '/path/to/dir'

        def find_file_in_search_path(self, variables, dirname, path):
            return '/path/to/dir/sub/subsub'

    lookup_module = DummyLookupBase()
    assert lookup_module.run(['/my/path/*.txt']) == []
    assert lookup_module.run(['*.txt']) == []
    assert lookup_module.run(['subsub/file.txt']) == [u'/path/to/dir/sub/subsub/file.txt']