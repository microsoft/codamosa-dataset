

# Generated at 2022-06-23 11:28:34.279071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:28:40.042774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    fh = StringIO()
    setattr(builtins, 'open', lambda n, m: fh)
    plugin = LookupModule()
    results = plugin.run(["/test.txt"], dict())
    assert(len(results) > 0)


# Generated at 2022-06-23 11:28:43.636048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1: Expected result: ['lookup_plugins/tests/test.txt']
    assert(LookupModule(None).run('{"lookup_plugins/tests/test.txt"}') == ['lookup_plugins/tests/test.txt'])

# Generated at 2022-06-23 11:28:51.327477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/my/path/*.txt']
    # It is not possible to test for glob.glob('/my/path/*.txt').
    # It is necessary to mock glob.glob() instead.
    # It is necessary to mock find_file_in_search_path in order to be
    # able to mock glob.glob()
    def mocked_find_file_in_search_path(variables, look_for, path):
        if look_for == 'files':
            return path
        else:
            return ''

    # It is necessary to mock sys.path in order to return a 'files' subdirectory

# Generated at 2022-06-23 11:28:57.866208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'_terms': ['/ansible/test/files/*.txt']})
    assert isinstance(l.run(terms=None, variables={}), list)

    l.set_options({'_terms': ['/ansible/test/files/*.md']})
    assert isinstance(l.run(terms=None, variables={}), list)

# Generated at 2022-06-23 11:28:59.121908
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:29:07.455391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test simple call
    test_variables = {"var1": "foo"}
    test_term_list = ["*.yml"]
    test_result_list = ['./test/lookup_plugins/fileglob/file1.yml',
                        './test/lookup_plugins/fileglob/file2.yml']
    test_lookup_result = LookupModule().run(test_term_list, test_variables)
    assert test_result_list == test_lookup_result

    # Test file in a directory
    test_variables = {"var1": "foo"}
    test_term_list = ["dir/file*.yml"]

# Generated at 2022-06-23 11:29:16.525285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-23 11:29:18.274578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Change to this directory
    l = LookupModule()
    l.run(["qrs.txt"], None)

# Generated at 2022-06-23 11:29:19.723161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert instance


# Generated at 2022-06-23 11:29:24.474902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the test case
    terms = ['/path/*.txt']

    # create an instance of the LookupModule class
    p = LookupModule()

    # call the run method
    results = p.run(terms)

    # check the results
    assert isinstance(results, list)

# Generated at 2022-06-23 11:29:30.411449
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking environment variables
    os.environ["ANSIBLE_SEARCH_PATH"] = "./test/test_lookup_plugins/files"

    # Setting up object under test
    # Does not raise exception
    look = LookupModule()

    # Call of run method
    # Does not raise exception
    ret = look.run(terms=["*"])
    assert ret == ["./test/test_lookup_plugins/files/lookup_file.txt"]

    ret = look.run(terms=["lookup_*.*"])
    assert ret == ["./test/test_lookup_plugins/files/lookup_file.txt"]

    ret = look.run(terms=["lookup_file.txt"])

# Generated at 2022-06-23 11:29:32.478331
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = LookupModule()
    assert isinstance(d, LookupBase)


# Generated at 2022-06-23 11:29:36.817070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTerms(object):
        def __iter__(self):
            return iter(['/my/path/1.txt', '/my/path/2.txt'])
    class MockVariables(object):
        def __init__(self):
            self.ansible_search_path = ['/my/path/']
    mock_terms = MockTerms()
    mock_variables = MockVariables()
    test_object = LookupModule()
    assert test_object.run(mock_terms, mock_variables) == [u'/my/path/1.txt', u'/my/path/2.txt']

# Generated at 2022-06-23 11:29:43.061355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/usr/share/*.txt', '/usr/share/data/foo.txt']
    vars = dict()
    files = lookup.run(terms, vars)
    for term in terms:
        for f in files:
            if f.endswith('.txt'):
                assert f.startswith('/usr/share/')
            else:
                assert f == '/usr/share/data/foo.txt'

# Generated at 2022-06-23 11:29:43.695827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:29:52.756305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Setup
    lookup_path = '/test/path/one/two'
    search_path = "/"

    # Exercise
    lookup_obj = LookupModule()

    # Verification
    assert lookup_obj.get_basedir({'ansible_search_path': search_path}) == search_path
    assert lookup_obj.find_file_in_search_path({'ansible_search_path': search_path}, 'files', lookup_path) == '', 'expected empty string on file not found, got %s' % lookup_obj.find_file_in_search_path({'ansible_search_path': search_path}, 'files', lookup_path)

# Generated at 2022-06-23 11:29:53.279679
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule

# Generated at 2022-06-23 11:30:00.029838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test LookupModule.run()"""

    # LookupModule.run() with existing files
    lookup_plugin = LookupModule()
    file_existing = "/bin/true"
    assert(lookup_plugin.run([file_existing], variables={}) == [file_existing])

    # LookupModule.run() with non-existing files
    lookup_plugin = LookupModule()
    file_not_existing = "/bin/non-existing"
    assert(lookup_plugin.run([file_not_existing], variables={}) == [])

# Generated at 2022-06-23 11:30:00.405438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:30:01.053046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:30:04.318479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Strings are passed as arguments to the LookupModule constructor
    lookup = LookupModule(terms = ['ansible'], variables = {'ansible_search_path': ['home/admin']}, wantlist = False)
    assert lookup
    lookup = LookupModule(terms = ['ansible'], variables = {'ansible_search_path': ['home/admin']}, wantlist = True)
    assert lookup


# Generated at 2022-06-23 11:30:05.720823
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 11:30:08.269463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = LookupModule().run(['./test_lookup_plugin/ansible'])
    assert 'test_lookup_plugin/ansible/test1.txt' in results

# Generated at 2022-06-23 11:30:15.186642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Double quote in file name:')
    lookup_module = LookupModule()
    ret = lookup_module.run(['"myfile.txt"'],{'ansible_search_path':['fileglob_test/test_folder']})
    assert ret == ['fileglob_test/test_folder/myfile.txt']

    print('Single quote in file name:')
    lookup_module = LookupModule()
    ret = lookup_module.run(["'myfile.txt'"],{'ansible_search_path':['fileglob_test/test_folder']})
    assert ret == ['fileglob_test/test_folder/myfile.txt']

    print('all files:')
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:30:22.471333
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # When term is path/file
    terms = ['/usr/local/*.txt']
    t = LookupModule().run(terms)
    assert t == []

    # When term is file
    terms = ['*.txt']
    t = LookupModule().run(terms)
    assert t == []

    # When term is file and paths not None
    terms = ['*.txt']
    variables = {
        'ansible_search_path' : ['/usr/local'],
    }
    t = LookupModule().run(terms, variables)
    assert t == []

# Generated at 2022-06-23 11:30:30.640334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # this tests that fileglob is not returning duplicate results
    # when run against absolute paths
    lookup = LookupModule()
    results = lookup.run(["/usr/share/*"], variables={'ansible_search_path': ['/usr/share/foo']})
    assert "/usr/share/foo/bar" in results
    assert "/usr/share/index.html" in results
    assert "/usr/share/index.csv" in results
    assert "/usr/share/index.html" in results
    assert "/usr/share/index.csv" in results
    assert len(results) == 4

# Generated at 2022-06-23 11:30:41.546956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from io import StringIO
    from ansible.errors import AnsibleLookupError

    # test empty term
    lookup = LookupModule()
    try:
        lookup.run([], dict(), wantlist=True)
    except(AnsibleLookupError) as e:
        assert(e.args[0] == "with_fileglob requires one or more paths")

    # test glob error
    terms = ["/platform/nonexist"]
    lookup = LookupModule()
    try:
        lookup.run(terms, dict(), wantlist=True)
    except(AnsibleLookupError) as e:
        assert(e.args[0] == "/platform/nonexist: [Errno 2] No such file or directory: '/platform/nonexist'")

    # test glob list

# Generated at 2022-06-23 11:30:42.787781
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None

# Generated at 2022-06-23 11:30:44.330616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 11:30:49.052010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    ret = module.run(['*'], variables={'ansible_search_path': ['playbooks']})
    assert('playbooks/test.yml' in ret)
    assert('playbooks/fileglob_test.yml' in ret)

# Generated at 2022-06-23 11:30:51.038686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["/etc/hosts"]) == ["/etc/hosts"]

# Generated at 2022-06-23 11:30:53.726640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    jl = LookupModule()
    assert jl.run('test') == []

if __name__ == '__main__':
     test_LookupModule()

# Generated at 2022-06-23 11:31:00.939769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term1 = "/my/path/*.txt"
    term2 = "/my/path/file.txt"
    term3 = "file.txt"
    term4 = "*.txt"
    terms = [term1, term2, term3, term4]

    # Test without 'wantlist' parameter
    ret = lookup_module.run(terms, variables=None)
    assert isinstance(ret, list)
    assert len(ret) == 0

    # Test with an array of files matching pattern
    txt_file1 = "/my/path/a.txt"
    txt_file2 = "/my/path/b.txt"
    txt_file3 = "/my/path/c.txt"

# Generated at 2022-06-23 11:31:03.202635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' in locals()

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:31:06.397345
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("In " + __file__)
    # Test constructor
    lookup = LookupModule()
    print("Passed constructor test for LookupModule")


# Generated at 2022-06-23 11:31:09.509552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up parameter list
    args = dict()
    args['terms'] = 'file*'
    args['variables'] = dict()
    args['variables']['ansible_search_path'] = ['.', '..', '../..']
    args['variables']['files'] = 'files'
    args['variables']['ansible_basedir'] = '.'
    
    useobj = LookupModule()
    res = useobj.run(**args)
    assert 'fileglob_test.py' in res
    assert 'fileglob_test.pyc' not in res
    

# Generated at 2022-06-23 11:31:19.855495
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create required input for test_data
    test_data_input = {
        'test_string': 'test.txt',
        'test_path': 'my/path/test.txt',
        'test_base_path': '/a/base/path',
        'test_search_path': ['p1', 'p2'],
        'test_file_list': ['t1.txt', 't2.txt', 't3.txt'],
    }

    def __mock_get_basedir(variables):
        return test_data_input['test_base_path']

    def __mock_find_file_in_search_path(variables, filetype, filename):
        if filename == "my":
            return "/a/path"
        if filename == "files":
            return "/files/path"


# Generated at 2022-06-23 11:31:30.086163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #instantiate the class with a empty dir
    lookup = LookupModule()
    #create a directory for testing
    temp_dir = tempfile.mkdtemp()
    #create a file for testing and close the handle
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    #test with a single file in the dir
    result = lookup.run([temp_file.name], variables={'ansible_search_path': temp_dir})
    assert result == [temp_file.name], "result %r should be %r"%(result, [temp_file.name])


    #test with a single file in search path
    result = lookup.run([temp_file.name], variables={'ansible_search_path': temp_dir})

# Generated at 2022-06-23 11:31:39.905595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.hostvars import HostVars
    from ansible.utils.listify import listify_lookup_plugin_terms
    hostvars = HostVars(dict())
    print("On statut is {0}".format(hostvars))
    # Define the path that you want to scan
    # TODO : PUT the path in a global variable
    terms = '/home/serge/tmp/test_ansible_lookup_fileglob/*.txt'
    #terms = '/home/serge/tmp/test_ansible_lookup_fileglob'
    #terms = listify_lookup_plugin_terms(terms, templar=None, loader=None, fail_on_undefined=True)
    print("On statut is {0}".format(terms))
    # Initial

# Generated at 2022-06-23 11:31:40.890195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(),LookupModule)

# Generated at 2022-06-23 11:31:49.104270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a simple class to simulate the variables
    class Variables(object):
        def __init__(self, ansible_search_path, ansible_hostname):
            self.ansible_search_path = ansible_search_path
            self.ansible_hostname = ansible_hostname

    # Create a simple class to simulate the module_utils.path
    class Path(object):
        def __init__(self, basedir):
            self.basedir = basedir
            self.mtime = 0.0
            self.size = 0.0

    # Create a simple class to simulate the module_utils.search_path

# Generated at 2022-06-23 11:31:53.912985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #lookup = LookupModule()
    #test_module = AnsibleModule(
    #    argument_spec = dict(
    #        _terms=dict(type='list', required=True),
    #    )
    #)
    #lookup.run(['.'], test_module)
    pass

# Generated at 2022-06-23 11:31:54.887020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:32:03.610415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test whether the run() method of class LookupModule works as expected."""

    # imports
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # create a lookup plugin object
    basedir = "/Users/stefan/git/ansible/test/test_data"
    lookup_plugin = lookup_loader.get('fileglob', basedir=basedir, runner=None, variables=dict(ansible_search_path=["/Users/stefan/git/ansible/test/test_data/roles/cart/files"]))
    # call run() method against first entry in list of term of class LookupModule

# Generated at 2022-06-23 11:32:04.677354
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None


# Generated at 2022-06-23 11:32:07.916444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    print("test_LookupModule passed")


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:32:18.170358
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import shutil
    import tempfile
    import glob
    import textwrap

    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor

    class LookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):

            ret = []
            for term in terms:
                term_file = os.path.basename(term)
                found_paths = []

# Generated at 2022-06-23 11:32:20.042768
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule.__name__ == 'LookupModule'

# Generated at 2022-06-23 11:32:21.121643
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-23 11:32:25.343870
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # assert class exists
    try:
        from ansible.plugins.lookup import LookupModule
    except ImportError:
        raise AssertionError("Unable to import class LookupModule from module ansible.plugins.lookup")

    # assert class can be instantiated
    lookup = LookupModule()
    assert lookup

    # assert class has method run
    assert lookup.run

# Generated at 2022-06-23 11:32:27.817786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myclass = LookupModule()
    assert myclass.run(terms=['/tmp/test.txt'], variables={'ansible_search_path': ['/tmp']}) == ['/tmp/test.txt']

# Generated at 2022-06-23 11:32:31.124930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(['a', 'b', 'c'], {}, wantlist = True)
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-23 11:32:31.718626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0

# Generated at 2022-06-23 11:32:32.668410
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:32:41.179419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock

    class VarManager():
        _vars = dict(
            ansible_search_path=['/my/path/1', '/my/path/2'],
        )

        def set_variable(self, k, v):
            self._vars[k] = v

        def __getitem__(self, item):
            return self._vars[item]

    class LookupModuleTest(LookupModule):
        def find_file_in_search_path(self, variables=None, var='', paths=None):
            return '.'

        def get_basedir(self, variables):
            return '.'

    l = LookupModuleTest()
    assert l.get_basedir(None) == '.'

    x = VarManager()
    l.set_loader(mock.Mock())
    l

# Generated at 2022-06-23 11:32:42.476402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tester = LookupModule()
    # test basic constructor
    assert(tester)


# Generated at 2022-06-23 11:32:43.345825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:32:53.655609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import mock
    from ansible.plugins.lookup import LookupModule

    lookup_module = LookupModule()

    with mock.patch('os.path.join') as mock_path_join:
        assert lookup_module.run(['present'], None, wantlist=True) == []
        assert lookup_module.run(['present'], None, wantlist=False) == ''
        mock_path_join.assert_not_called()

    with mock.patch('os.path.join') as mock_path_join:
        mock_path_join.return_value = 'present'
        with mock.patch('glob.glob') as mock_glob:
            with mock.patch('os.path.isfile') as mock_isfile:
                mock_glob.return_value = ('present',)


# Generated at 2022-06-23 11:33:00.019571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ["ANSIBLE_CONFIG"] = "./ansible.cfg"
    lookup = LookupModule()
    terms = ["ansible.cfg"]
    variables = {}
    result = lookup.run(terms, variables, wantlist=False)
    #print result
    #assert result[0] == "./ansible.cfg"
    assert "ansible.cfg" in result

# Generated at 2022-06-23 11:33:03.864492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert len(lm.run(["ansible.cfg"])) > 0
    assert len(lm.run(["/etc/passwd"])) == 0
    assert len(lm.run(["/etc/passwd", "ansible.cfg"])) > 0

# Generated at 2022-06-23 11:33:06.988917
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    # - create a fileglob
    # - create a file
    # - create a directory

    # Act
    #  - look into the fileglob
    #  - look into the directory

    # Assert
    assert False

# Generated at 2022-06-23 11:33:08.242198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 11:33:11.663424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    #for a simple non-existing file
    assert module.run(["/test/test"], variables={"ansible_basedir": "/tmp"}) == []
    #for a non existing path
    assert module.run(["/test/test/test"], variables={"ansible_basedir": "/tmp"}) == []
    #for a simple existing file
    assert module.run(["/tmp/test"], variables={"ansible_basedir": "/tmp"}) == ["/tmp/test"]
    terms = [
        "/tmp/test1",
        "/tmp/test2",
        "/tmp/test3",
    ]
    assert module.run(terms, variables={"ansible_basedir": "/tmp"}) == ["/tmp/test1", "/tmp/test2", "/tmp/test3"]


# Generated at 2022-06-23 11:33:12.919076
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:33:19.870042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for valid class initialization
    lookup_obj = LookupModule()

    # Test for exceptions raised
    class Foo(object):
        pass
    args = Foo()
    args.terms = ["localhost"]
    args.variables = {"ansible_search_path": ["."]}
    args.wantlist = False
    try:
        NoneType = type(None)
        lookup_obj.run(args.terms, args.variables, wantlist=args.wantlist)
    except Exception:
        assert False
    args.wantlist = NoneType
    try:
        lookup_obj.run(args.terms, args.variables)
    except Exception:
        assert False

# Generated at 2022-06-23 11:33:22.224909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tp = LookupModule()
    assert isinstance(tp, LookupModule)


# Generated at 2022-06-23 11:33:23.515596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    return True

# Generated at 2022-06-23 11:33:25.169404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_basedir(None) == '.'

# Generated at 2022-06-23 11:33:35.222145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3, string_types

    test_lookup_module_obj = LookupModule()
    assert test_lookup_module_obj is not None
    assert isinstance(test_lookup_module_obj, LookupModule) is True

    # test run()
    assert test_lookup_module_obj.run('foo.bar') is None

    # test find_file_in_search_path()
    assert test_lookup_module_obj.find_file_in_search_path({}, 'files', 'foo.bar') is None
    assert test_lookup_module_obj.find_file_in_search_path({'ansible_search_path': []}, 'files', 'foo.bar') is None
    assert test_lookup_module_obj.find_file_

# Generated at 2022-06-23 11:33:42.762294
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Here we have a file test.txt in ./test_directory/
    test_txt_path = os.path.join(os.path.dirname(__file__), 'test_directory', 'test.txt')
    # For windows paths, we need to convert them to unicode
    if os.name == 'nt':
        test_txt_path = to_text(test_txt_path)
    test_txt_path_folder = os.path.join(os.path.dirname(__file__), 'test_directory')
    if os.name == 'nt':
        test_txt_path_folder = to_text(test_txt_path_folder)
    try:
        os.remove(test_txt_path)
    except:
        pass


# Generated at 2022-06-23 11:33:44.649265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:33:48.193015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    ret = lm.run(['./test/data/hello.txt'])
    assert ret[0] == './test/data/hello.txt'

# Generated at 2022-06-23 11:33:49.579639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-23 11:33:58.847130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_1 = ['/tests/files/foo.txt', '/tests/files/bar.txt']
    variables_1 = {'ansible_search_path': ['/tests/files', '/']}

    expected_1 = ['/tests/files/foo.txt', '/tests/files/bar.txt']

    terms_2 = ['foo.txt', 'bar.txt']
    variables_2 = {'ansible_search_path': ['/tests/files', '/']}

    expected_2 = ['/tests/files/foo.txt', '/tests/files/bar.txt']

    lm1 = LookupModule()
    lm2 = LookupModule()

    result_1 = lm1.run(terms_1, variables_1)
    result_2 = lm2.run(terms_2, variables_2)



# Generated at 2022-06-23 11:34:08.066697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()

    class Arguments():
        def __init__(self):
            self.terms = ["/my/path/*.txt"]
            self.variables = None

    globbed = [u'/my/path/one.txt', u'/my/path/two.txt']

    terms = [u'/my/path/*.txt']

    def test_glob(pattern):
        return globbed

    setattr(test_object, "run", test_glob)

    # We are using test_object to check if returned result of method run() is equal to the list globbed
    assert test_object.run(terms) == globbed

# Generated at 2022-06-23 11:34:16.076339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    item = 'test_item'
    term_file = 'test_item'
    found_paths = ['/test/path', '/test/path/to/file']
    term_results = ['test_item_result']
    ret = []
    ansible_search_path = ['/test/path']

    lookup_obj = LookupModule()
    setattr(lookup_obj, 'find_file_in_search_path', lambda variables, term, term_file: found_paths)
    setattr(lookup_obj, 'get_basedir', lambda variables: ansible_search_path)
    setattr(lookup_obj, 'get_basedir', lambda variables: ansible_search_path)
    setattr(glob, 'glob', lambda x: term_results)

# Generated at 2022-06-23 11:34:18.060627
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup)
    assert(lookup.run)

# Generated at 2022-06-23 11:34:21.643438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    constructor test
    :return:
    """
    l = LookupModule()
    l.run(["package.spec"])

# Generated at 2022-06-23 11:34:24.064407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = LookupModule()
    ret = looker.run(["file_to_find.txt"], {})
    assert isinstance(ret, list)

# Generated at 2022-06-23 11:34:25.066676
# Unit test for constructor of class LookupModule
def test_LookupModule():
   assert LookupModule('')

# Generated at 2022-06-23 11:34:33.850440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A file /tmp/foobar.txt exists and /tmp/foo* does not
    arg1 = ['/tmp/foo*', '/tmp/foobar.txt']
    arg2 = {'_original_file': '/usr/local/ansible/playbooks/hacking/test_docs_file_lookup.yml', 'playbook_dir': '/usr/local/ansible/playbooks', 'vars': {'ansible_search_path': ['/usr/local/ansible/playbooks/tests']}}
    lk = LookupModule()
    ret = lk.run(arg1, variables=arg2)
    assert ret == ['/tmp/foobar.txt']

    # Test that the 'files' path is correctly dwimmed
    arg1 = ['test.txt']

# Generated at 2022-06-23 11:34:42.854404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['ANSIBLE_RETRY_FILES_ENABLED'] = "0"
    print("_____ 1")
    # Test with existing files
    testlookup = LookupModule()
    testlookup.set_options({'wantlist': True})
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    testfile1 = open('file1.txt','w')
    testfile1.write("test")
    testfile1.close()
    testfile2 = open('file2.txt','w')
    testfile2.write("test")
    testfile2.close()
    testfile3 = open('file3.txt','w')
    testfile3.write("test")
    testfile3.close()

# Generated at 2022-06-23 11:34:53.653937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.plugins.loader import lookup_loader

    # test method run of LookupModule with terms contains file name without path
    lookup_instance = lookup_loader.get('fileglob',basedir='/home/user/ansible/myansible',Loader=None,VaultSecret='12345',vars={'foo': 'bar'},templar=None)
    lookup_instance._loader._module_finder._module_cache = {'stat': ['path', '/usr/lib/python2.7/dist-packages', 'stat.pyc']}
    ret = lookup_instance.run(['/etc/ansible/hosts'])

# Generated at 2022-06-23 11:35:04.837918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_path = os.path.dirname(os.path.abspath(__file__))
    test_data_path = os.path.join(module_path, "../../../test/unit/lookup_plugins/")
    mylookup = LookupModule()

    terms = [os.path.join(test_data_path, "testfile.txt")]
    assert mylookup.run(terms) == [os.path.join(test_data_path, "testfile.txt")]

    terms = [os.path.join(test_data_path, "*.txt")]
    assert mylookup.run(terms) == [os.path.join(test_data_path, "testfile.txt")]


# Generated at 2022-06-23 11:35:07.325142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.run(terms=['/tmp/foo.txt'], inject={'ansible_search_path': ['/tmp']})

# Generated at 2022-06-23 11:35:08.308774
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert lk

# Generated at 2022-06-23 11:35:15.630757
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin = LookupModule()
    assert plugin.run(['./test'], {'ansible_basedir': './tests'}) == ['test']
    assert plugin.run(['./test/foo.txt'], {'ansible_basedir': './tests'}) == []
    assert plugin.run(['./tests/test'], {'ansible_basedir': './tests'}) == ['tests/test']
    assert plugin.run(['./tests/test/foo.txt'], {'ansible_basedir': './tests'}) == []
    assert plugin.run(['./tests/foo.txt'], {'ansible_basedir': './tests'}) == ['tests/foo.txt']
    assert plugin.run(['./testt'], {'ansible_basedir': './tests'}) == []


# Generated at 2022-06-23 11:35:17.857393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:35:21.723116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    result = lm.run(["/etc/redhat-release"])
    assert len(result) > 1
    assert all([os.path.isfile(file) for file in result])

# Generated at 2022-06-23 11:35:26.095181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Create LookupModule object
    lm = LookupModule()
    
    # Create variables and run method
    variables = {"ansible_search_path": ['/etc/fooapp/']}
    ret = lm.run(['/etc/fooapp/'], variables)
    
    # Verify result
    assert ret == ['/etc/fooapp']

# Generated at 2022-06-23 11:35:27.527523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # TODO: Add test
    assert False

# Generated at 2022-06-23 11:35:33.749807
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Build test object
    lookup_obj = LookupModule()

    # Build test dictionary
    lookup_terms = ['*.txt']
    items = dict(test_file='test_file.txt')
    variables = dict(ansible_search_path='/ansible/lookup/test/')

    # Perform test
    response = lookup_obj.run(lookup_terms, variables, wantlist=True)

    # Assert test
    assert "test_file.txt" in response

# Generated at 2022-06-23 11:35:40.396348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # build list of paths to look for and test against
    search_path_list = [
        '/path/to/file.txt',
        '/path/to/file/*',
        'file.txt',
        'file.txt*',
        'file.txt?'
    ]
    # build kwargs dictionary to be passed to method run
    kwargs = {'wantlist': False}
    # build variables dictionary
    variables = {}
    # build temporary directory, file, and path definition
    import tempfile
    tmpdir = tempfile.mkdtemp()
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmppath = tmpfile.name
    # Put file in path

# Generated at 2022-06-23 11:35:46.256882
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    dirs = lookup.get_basedir(None)
    assert dirs
    dirs1 = lookup.run([], None)
    assert dirs1 == []
    dirs2 = lookup.run([], {"ansible_search_path": dirs})
    assert dirs2 == []
    dirs3 = lookup.run(["*"], {"ansible_search_path": dirs})
    assert dirs3 == []

# Generated at 2022-06-23 11:35:55.590033
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:36:04.868477
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test object
    lookup_obj = LookupModule()

    # Create a test variable
    arg_terms = ["test_dir/*.txt", "*.txt", "test_dir/test1.txt"]
    arg_file_content = "LookupModule result output"
    arg_file_name = "/tmp/ansible_test.tmp"
    arg_search_path = ["/tmp", "/var/log"]

    # Create a test file
    # Ansible creates the file /tmp/ansible_test.tmp when run
    # This test creates the file /tmp/test_dir/test1.txt when run
    test_file = open(arg_file_name,"w")
    test_file.write(arg_file_content)
    test_file.close()

    # Create a test file
    # Ansible creates

# Generated at 2022-06-23 11:36:06.095528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert str(type(l)) == "<class 'ansible.plugins.lookup.fileglob.LookupModule'>"

# Generated at 2022-06-23 11:36:12.286953
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #
    from ansible.parsing.dataloader import DataLoader

    lookup_obj = LookupModule()
    loader_obj = DataLoader()

    # run(self, terms, inject=None, **kwargs)
    terms = ['/etc/hosts']
    lookup_obj.run(terms)

    variables = {}
    lookup_obj.run(terms, variables)

# Generated at 2022-06-23 11:36:14.477800
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:36:16.517079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    terms = ['/var/*', '/var/log/nginx/access.log']
    f.run(terms)

# Generated at 2022-06-23 11:36:18.607199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'docs' in repr(LookupModule)


# Generated at 2022-06-23 11:36:19.230900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:36:21.471966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule()
    l = LookupModule()
    module.exit_json(changed=False)

# Generated at 2022-06-23 11:36:31.873557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with filename
    # testfile exists in path /Users/jonas/git/ansible/test/units/files/testfile
    ret = LookupModule().run(['testfile'], variables={'ansible_search_path': '/Users/jonas/git/ansible/test/units/files'})
    assert '/Users/jonas/git/ansible/test/units/files/testfile' in ret

    # Testing with filepath
    # testdir/testfile exists in path /Users/jonas/git/ansible/test/units/files/testdir
    ret = LookupModule().run(['testdir/testfile'], variables={'ansible_search_path': '/Users/jonas/git/ansible/test/units/files'})

# Generated at 2022-06-23 11:36:39.235053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This function tests LookupModule.run method
    """
    mock_self = type('test', (object,), {'find_file_in_search_path': lambda self, variables, kind, path: os.path.join(path.replace('/my/path/', ''), 'test')})
    results = mock_self.run(mock_self, ['/my/path/test'], {})

    assert results == ['test']

# Generated at 2022-06-23 11:36:44.020534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock variables
    variables = {'ansible_search_path': ['/playbooks/fooapp/files/']}

    # create instance of LookupModule class and call run method
    lookup_module = LookupModule()
    result = lookup_module.run(['*.conf'], variables)

    # test result
    assert result == []


# Generated at 2022-06-23 11:36:51.506977
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert(os.chdir(os.path.dirname(os.path.realpath(__file__))))
    print(os.getcwd())

    # create test files
    os.mkdir('files')
    os.mkdir('lookups')
    os.mkdir('lookups/files')
    with open('files/test.txt', 'w') as fd:
        fd.write('foobar')
    with open('lookups/files/test2.txt', 'w') as fd:
        fd.write('foobar')

    result = LookupModule().run(['*.txt'], {'ansible_search_path': ['lookups']})

    # remove test files
    os.remove('files/test.txt')
    os.remove('lookups/files/test2.txt')
    os

# Generated at 2022-06-23 11:36:54.160645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing LookupModule')
    lm = LookupModule()
    assert lm


# Generated at 2022-06-23 11:36:56.418471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = global_objects['lookup_plugin'](loader=None, variables=None)
    assert lm


# Generated at 2022-06-23 11:36:57.361332
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    return module

# Generated at 2022-06-23 11:36:58.621042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:36:59.481507
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()

# Generated at 2022-06-23 11:37:01.755335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run([], {}) == [], "test 1"

# Generated at 2022-06-23 11:37:12.310263
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import shutil

    class Args(object):
        """
        Class to hold lookup plugin arguments
        """
        def __init__(self, **kargs):
            self.__dict__.update(kargs)

        def __getattr__(self, key):
            return None

        def __setattr__(self, key, value):
            self.__dict__[key] = value

    import tempfile
    import os

    # Testing the fileglob plugin
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create 6 files in temporary directory
    file_a = "%s/file_a.txt" % temp_dir
    file_b = "%s/file_b.txt" % temp_dir
    file_c = "%s/file_c.txt" % temp_dir


# Generated at 2022-06-23 11:37:23.042667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)


# Generated at 2022-06-23 11:37:26.042782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for the constructor of class LookupModule
    """
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-23 11:37:27.417585
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module)



# Generated at 2022-06-23 11:37:35.934165
# Unit test for method run of class LookupModule
def test_LookupModule_run(): 

    terms = '/home/yusufs*'
    variables={}
    kwargs={}
    lookupModule = LookupModule()
    results = lookupModule.run(terms, variables, **kwargs)
    assert isinstance(results, list)
    assert '/home/yusufsah' in results

    terms = '/home/yusufsah'
    variables={}
    kwargs={}
    lookupModule = LookupModule()
    results = lookupModule.run(terms, variables, **kwargs)
    assert isinstance(results, list)
    assert '/home/yusufsah' in results

# Generated at 2022-06-23 11:37:38.503546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.basedir = '.'
    terms = ['m*']
    variables = {}
    ret = lookup_module.run(terms, variables)
    print(ret)

# Generated at 2022-06-23 11:37:42.637444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(terms=['/my/path/*.txt'])
    res = LookupModule().run(terms=args['terms'])
    assert res == ['/my/path/*.txt']
    assert res is not None
    assert isinstance(res, list)

# Generated at 2022-06-23 11:37:45.155093
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_module = LookupModule()
    assert test_lookup_module is not None
    assert isinstance(test_lookup_module, LookupModule)

# Generated at 2022-06-23 11:37:54.693817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['*.txt']
    lookup_base = LookupBase()
    variables = {}
    result = LookupModule(loader=None, templar=None).run(terms=terms,variables=variables,wantlist=True, convert_data=True)
    assert result == []

    # Add *.txt files to ansible_search_path
    variables["ansible_search_path"] = ["/playbooks/files/fooapp/"]
    result = LookupModule(loader=None, templar=None).run(terms=terms, variables=variables, convert_data=True)
    assert result == []

    result = LookupModule(loader=None, templar=None).run(terms=terms, variables=variables, wantlist=True, convert_data=True)
    assert result == []

    result = Lookup

# Generated at 2022-06-23 11:37:59.225370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert type(lookup_module) is LookupModule
    assert hasattr(lookup_module, '_handle_aliases')
    assert hasattr(lookup_module, '_lookup_args')
    assert hasattr(lookup_module, '_lookup_opts')
    assert hasattr(lookup_module, 'run')


# Generated at 2022-06-23 11:38:00.256365
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 11:38:02.463291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module.run(['test'], variables=None))

# Generated at 2022-06-23 11:38:04.935849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run(['/test/testfile.txt'], variables={'ansible_search_path': '/test'})
    assert result

# Generated at 2022-06-23 11:38:09.934051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run() == [], 'Returned list must be empty if no args given to the run method'
    assert lookup.run(['/etc/hosts']) == ['/etc/hosts'], 'Result not as expected'

# Generated at 2022-06-23 11:38:14.294402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert (LookupModule().run(['test_term'], {})) is None
    assert (LookupModule().run(['test_term'], {})) == []

# Generated at 2022-06-23 11:38:14.915812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:38:16.781256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule(loader=None, variable_manager=None, loader_class=None)
    assert lookup is not None

# Generated at 2022-06-23 11:38:19.213371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_path = "ansible.plugins.lookup.fileglob"
    lookup_instance = LookupModule()
    assert type(lookup_instance) is type(LookupModule)

# Generated at 2022-06-23 11:38:19.760408
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert LookupModule()

# Generated at 2022-06-23 11:38:28.653298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # In python 3 os.path.join() returns a string of type 'str' while in python 2 it returns a string of type 'unicode'.
    # To avoid failures, we convert the 'str' type python 3 string to 'unicode' type by prefixing 'u' before the string.
    assert LookupModule().run(terms=u'/my/path/*.txt', variables={}) == []
    assert LookupModule().run(terms=[u'/my/path/*.txt'], variables={}) == []
    assert LookupModule().run(terms=[u'/my/path', u'*.txt'], variables={}) == []

# Generated at 2022-06-23 11:38:30.253921
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:38:40.716558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_tuple = (None, None)
    mock_finder = mock_tuple[1]
    mock_loader = mock_tuple[1]
    mock_inventory = mock_tuple[1]
    mock_variable_manager = mock_tuple[1]
    def side_effect_create_loader(*args, **kwargs):
        return mock_loader
    def side_effect_create_inventory(*args, **kwargs):
        return mock_inventory
    def side_effect_create_variable_manager(*args, **kwargs):
        return mock_variable_manager
    mock_finder.create_loader.side_effect = side_effect_create_