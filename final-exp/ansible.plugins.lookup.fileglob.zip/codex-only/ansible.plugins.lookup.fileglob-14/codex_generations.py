

# Generated at 2022-06-23 11:28:36.917034
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:28:47.014284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var1 = {'ansible_search_path':['/home/dummy/path','/home/dummy/other/path'], 'ansible_basedir':'/home/dummy/ansible/dir'}
    term1 = '/home/dummy/ansible/dir/myfile'
    term2 = 'myfile'
    term3 = '/home/dummy/ansible/dir/mydir/*.txt'
    term4 = 'mydir/*.txt'
    l1 = LookupModule()
    
    #Test case 1, Term1 found in 1st search path
    list1 = l1.run([term1],var1)
    assert list1 == ['/home/dummy/path/myfile']

    #Test case 2, Term2 file found in ansible_basedir

# Generated at 2022-06-23 11:28:58.916564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a fake module
    class FakeVarsModule:
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self, loader=None, play=None, task=None, host=None):
            return self._vars

        def get_vars_files(self):
            return []

    # Create the test fixture for the LookupModule
    lookup_module = LookupModule()

    base_path = "/role/files"

    terms = ["first.txt", "*.txt", "/sec?nd/third.txt"]


# Generated at 2022-06-23 11:29:02.407745
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_obj = LookupModule()
    terms = ['test/files/shell/*.sh']
    terms_result = ['test/files/shell/test1.sh']

    assert lookup_obj.run(terms) == terms_result

# Generated at 2022-06-23 11:29:09.506271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    # Test the case when there is no file matching the pattern given in the terms
    test_var = {"get_path": "/test/playbooks/"}
    test_terms = ["*test.yml"]
    result = test_lookup.run(test_terms,variables=test_var)
    assert not result
    # Test the case when there are 1 file matching the pattern given in the terms
    test_var = {"get_path": "/test/playbooks/"}
    test_terms = ["*.yml"]
    result = test_lookup.run(test_terms,variables=test_var)
    assert result == ['test.yml']
    # Test the case when there are multiple files matching the pattern given in the terms

# Generated at 2022-06-23 11:29:10.419030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 11:29:18.059825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = Play.load(dict(
        host='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    ), variable_manager=variable_manager, loader=loader)

    tqm = None

# Generated at 2022-06-23 11:29:28.894528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get the module
    lookup = LookupModule()

    # create a test parameter
    class TestVars(object):
        def __init__(self):
            self.ansible_search_path = [u'/playbooks/files/fooapp']

    class TestVars2(object):
        def __init__(self):
            self.search_paths = [u'/playbooks/files/fooapp']

    import os
    # create some files to test against
    with open('/playbooks/files/fooapp/test_file.txt', 'a') as f:
        f.write('test')

    with open('/playbooks/files/test_file.txt', 'a') as f:
        f.write('test')

    # test with ansible_search_path

# Generated at 2022-06-23 11:29:34.564984
# Unit test for constructor of class LookupModule
def test_LookupModule():

	# Importing modules are necessary to set the globals
	import sys,os
	sys.path.append(os.path.dirname(os.path.abspath(__file__)))
	from test import test_utils
	#Creating a test class object of LookupModule class
	lookup = LookupModule()

	#####Testing for LookupBase class 
	assert isinstance(lookup, LookupBase)
	return

# Generated at 2022-06-23 11:29:36.273627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu.run(terms = ["*.py"], wantlist=True)

# Generated at 2022-06-23 11:29:42.985699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cm = LookupModule()
    # if wantlist is False, run() should return a comma-separated string
    assert cm.run(['/my/path/*.txt'], wantlist=False) == 'test.txt'
    # if wantlist is True, run() should return a list of strings
    assert cm.run(['/my/path/*.txt'], wantlist=True) == ['test.txt']
    # if no files are found, should return an empty list or empty string
    assert cm.run([''], wantlist=False) == ''
    assert cm.run([''], wantlist=True) == []
    assert cm.run(['*.txt'], wantlist=False) == ''
    # should ignore any directories

# Generated at 2022-06-23 11:29:44.805409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:29:47.807452
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Creating a LookupModule object")
    lookup_plugin = LookupModule()
    print("LookupModule object has been created: %s" %str(lookup_plugin))


# Generated at 2022-06-23 11:29:50.106397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert ['/playbooks/files/fooapp/one', '/playbooks/files/fooapp/two'] == module.run(['./fooapp/*'], {'ansible_search_path': ['/playbooks']}, wantlist=True)

# Generated at 2022-06-23 11:29:58.688296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = """
    - name: Display paths of all .txt files in dir
      debug: msg={{ lookup('fileglob', '/my/path/*.txt') }}

    - name: Copy each file over that matches the given pattern
      copy:
        src: "{{ item }}"
        dest: "/etc/fooapp/"
        owner: "root"
        mode: 0600
      with_fileglob:
        - "/playbooks/files/fooapp/*"
    """
    ret = ['/my/path/a.txt', '/my/path/b.txt']
    lm = LookupModule()
    assert lm.run(['/my/path/*.txt']) == ret
    #assert lm.run(['/my/path/*.txt'], variables={'ansible_search_path':['src/ans

# Generated at 2022-06-23 11:29:59.383366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:30:02.601767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    LookupModuleTool = LookupModule()

    assert LookupModuleTool.run("/tmp") == []
    assert LookupModuleTool.run("/tmp/") == []
    assert LookupModuleTool.run("") == []


# Generated at 2022-06-23 11:30:04.812563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L


# Generated at 2022-06-23 11:30:13.740564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with an existing file, given an absolute path
    with patch.object(os.path, 'exists', return_value=True):
        lookup_plugin = LookupModule()
        assert lookup_plugin.run([to_bytes('/path/to/a/file')],
                                 variables={'inventory_dir': 'bar', 'role_path': ['foo', 'baz']}) == [to_text('/path/to/a/file')]

    # Test with an existing file, given a relative path
    with patch.object(LookupModule, 'find_file_in_search_path', return_value='/fake/file/path'):
        with patch.object(os.path, 'exists', return_value=True):
            lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:30:15.197458
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:30:16.285415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: need to test this method
    pass

# Generated at 2022-06-23 11:30:17.690330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:30:27.889729
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:30:31.412333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    json = {"ansible_search_path": ["/home/netop/work/ansible/lookup_plugins"],
            "ansible_basedir": "/home/netop/work/ansible/lookup_plugins"}
    terms = ["*.py"]
    result = LookupModule().run(terms, variables=json)
    files = ["fileglob.py", "foo.py", "map.py", "password.py", "redshift.py"]
    assert files == result

# Generated at 2022-06-23 11:30:33.691717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_module = LookupModule()
    assert test_module

# Generated at 2022-06-23 11:30:41.546207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for the method run of class LookupModule
    """
    # First test scenario with a non existing file.
    # Expected result is an empty list
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['some_nonexisting_file'])
    assert(result == [])

    # Now create a file with known content and check for file content.
    # If it exists the test is successful
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['some_nonexisting_file'])
    assert(result == [])

# Generated at 2022-06-23 11:30:43.147042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-23 11:30:44.853380
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:30:48.832986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()
    test_result = test_module.run(["/etc/*"], {})
    assert type(test_result) is list
    assert "/etc/apt" in test_result

# Generated at 2022-06-23 11:30:54.455799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def __getitem__(self, x):
        return {'ansible_search_path': ['test_path']}[x]

    variables = type('obj', (object,), {'__getitem__': __getitem__})()

    assert LookupModule().run(['abc'], variables=variables) == []
    assert LookupModule().run(['test_pattern'], variables=variables) == []

# Generated at 2022-06-23 11:31:03.607869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    # Exceptions
    assert module.__class__.__name__ == 'LookupModule'
    assert module.__doc__ == LookupModule.__doc__

    # return attributes
    assert isinstance(module.run, object)
    assert module.run.__name__ == 'run'
    assert module.run.__doc__ == LookupBase.run.__doc__
    assert isinstance(module.find_file_in_search_path, object)
    assert module.find_file_in_search_path.__name__ == 'find_file_in_search_path'
    assert module.find_file_in_search_path.__doc__ == LookupBase.find_file_in_search_path.__doc__
    assert isinstance(module.get_basedir, object)


# Generated at 2022-06-23 11:31:07.061269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 'absent' == l.get_option('ignoremissing')
    assert 'wantlist' in l.get_options()


# Generated at 2022-06-23 11:31:12.868944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock variables containing the option ansible_search_path
    variables = {'ansible_search_path': ['.']}
    # Create a mock search path
    paths = ['.']
    # Create a test input for LookupModule class
    terms = ['file.txt']
    # Create an argument list
    arg_list = (terms,variables)
    # Run the test
    LookupModule(*arg_list).run()

# Generated at 2022-06-23 11:31:13.624819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupBase

# Generated at 2022-06-23 11:31:20.998322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_path = os.path.join(os.path.dirname(__file__), 'test_files')
    test_path = os.path.normpath(test_path)
    test_files = ['file_name', 'file_name.txt', 'file_name.ini', 'file_name.txt.bak']
    test_output = [os.path.join(test_path, f) for f in test_files]

    lookup = LookupModule()
    res = lookup.run(["file_name.*"], dict(ansible_search_path=test_path))
    assert res == test_output

# Generated at 2022-06-23 11:31:22.192754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = LookupModule()
    assert results != None

# Generated at 2022-06-23 11:31:23.170731
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:31:28.435810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # unit test doesn't handle this correctly
    #assert module.run(["/etc/hosts"]) == ["/etc/hosts"]
    assert module.run(["/etc/hosts.notfound"]) == []
    assert module.run(["hosts"]) == ["/etc/hosts"]

# Generated at 2022-06-23 11:31:35.051321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['*.yml'], {'ansible_search_path' : ['./tests/lookup_plugins/dir1/dir2', './tests/lookup_plugins']}) == ['./tests/lookup_plugins/dir1/dir2/test1.yml', './tests/lookup_plugins/dir1/dir2/test2.yml', './tests/lookup_plugins/dir1/dir2/test3.yml']


# Generated at 2022-06-23 11:31:39.078217
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text

    mocked_self = Mapping()
    mocked_self.get_basedir = lambda x : ''
    mocked_self.find_file_in_search_path = lambda x, y, z: ""
    mocked_terms = {'test.txt'}

    result = LookupModule.run(mocked_self, mocked_terms)
    assert result == [to_text('test.txt')]

# Generated at 2022-06-23 11:31:44.528651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    utils = { "is_file": lambda x: True }
    L.set_runner(utils)
    result = L.run([u"with_items.yml"])[0]
    assert result.find("with_items") > 0 or result.find("with_items.yml") > 0 

# Test whether fileglob looks up files that contain spaces

# Generated at 2022-06-23 11:31:45.691906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' in vars(LookupModule)


# Generated at 2022-06-23 11:31:47.012728
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(type(LookupModule()) == LookupModule)

# Generated at 2022-06-23 11:31:55.101551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    path = "files/"
    path_terms = ["my_file.txt", "my_file_1.txt", "my_file_2.txt", "my_file_3.txt", "my_file_4.txt", "my_file_5.txt"]
    expected_result = []

    for term in path_terms:
        expected_result.append(path + term)

    result = lookup.run(terms=[path + "*.txt"], variables=dict(ansible_basedir='/file_dir'))
    assert result == expected_result

# Generated at 2022-06-23 11:31:56.477835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert isinstance(lk,LookupModule)

# Generated at 2022-06-23 11:31:59.545276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for find user home directory
    terms = ['/test-ansible-fileglob-unit-test/*']
    result = LookupModule().run(terms)
    assert isinstance(result, list)
    assert len(result) > 0

# Generated at 2022-06-23 11:32:00.764663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(["*.py"])

# Generated at 2022-06-23 11:32:01.618152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 11:32:08.132503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import shutil
    import tempfile
    from ansible.module_utils._text import to_bytes, to_native
    lookup = LookupModule()
    assert lookup.run(["/playbooks/files/fooapp/*"]) == []
    d = tempfile.mkdtemp()
    testdir = os.path.join(d, 'testdir')
    testfile = os.path.join(testdir, 'testfile')
    os.makedirs(testdir)
    with open(testfile, 'w') as f:
        f.write('testfile')

# Generated at 2022-06-23 11:32:13.140244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Testing run() method of class LookupModule"""
    ################################################################################

    lookup = LookupModule()
    items = lookup.run(['/etc/passwd'], variables=None)
    assert items == ['/etc/passwd']
    ################################################################################

# Generated at 2022-06-23 11:32:19.360989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test file path is current directory
    terms = ['*']
    ret = lookup.run(terms)
    assert(len(ret) > 0)
    # test file path is absolute path
    terms = [os.path.join(os.path.dirname(os.path.abspath(__file__)), '*')]
    ret = lookup.run(terms)
    assert(len(ret) > 0)

# Generated at 2022-06-23 11:32:21.256372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    if sys.version_info[0] < 3:
        lookup_plugin = LookupModule()
        assert lookup_plugin is not None

# Generated at 2022-06-23 11:32:29.669142
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:32:30.561836
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup)

# Generated at 2022-06-23 11:32:32.538941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run([u'README']) == []

# Generated at 2022-06-23 11:32:33.455672
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert ('LookupModule' in globals())

# Generated at 2022-06-23 11:32:38.481869
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:32:45.135728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import hashlib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # make test directory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # non-recursive
    assert hashlib.md5(','.join(sorted(LookupModule().run(['*.txt'], variable_manager, wantlist=True))))
    assert hashlib.md5(','.join(sorted(LookupModule().run(['*.txt'], variable_manager, wantlist=False))))
    # recursive

# Generated at 2022-06-23 11:32:52.939849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    directory = os.path.join(os.path.dirname(__file__), "test_files")
    terms = ["*.txt", "*.sh", "*.missing", "*missing_directory/*.txt"]
    expected = [
        os.path.join(directory, "a.txt"),
        os.path.join(directory, "b.txt"),
        os.path.join(directory, "c.sh"),
        os.path.join(directory, "d.sh")
    ]
    found = lookup_module.run(terms, dict(ansible_search_path=[directory]))
    assert sorted(expected) == sorted(found)

# Generated at 2022-06-23 11:32:56.318787
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    all_envs = os.environ.keys()
    for key in all_envs:
        assert key in test.envs

# Generated at 2022-06-23 11:32:57.911455
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:33:08.881359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import BytesIO
    from ansible.plugins.loader import lookup_loader

    loader = lookup_loader._create_loader(None)

# Generated at 2022-06-23 11:33:17.967082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['foo'])
    assert result is None, \
        'LookupModule.run should return None when glob.glob return no results'

    def findfile_side_effect(dir_list, file_list):
        return ['base_dir']
    with patch('ansible.plugins.lookup.LookupBase') as mock_lookupbase:
        mock_lookupbase().find_file_in_search_path().side_effect = findfile_side_effect
        result = LookupModule().run(['foo'])
        assert result is not None, \
            'LookupModule.run should not return None when glob.glob return results'

    def findfile_side_effect(dir_list, file_list):
        if file_list == 'foo':
            return ['base_dir']


# Generated at 2022-06-23 11:33:21.236461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test method run, returns given arguments
    assert lookup.run(terms="test.txt",variables="test/") == "test.txt"

# Generated at 2022-06-23 11:33:32.205228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result_run_simple = ['/home/myuser/myfile1.txt', '/home/myuser/myfile2.txt']
    result_run_complex = ['/home/myuser/MyFolder1/myfile1.txt', '/home/myuser/MyFolder1/myfile2.txt']
    lookup = LookupModule()

    # Test 'simple' case with 2 hits
    result = lookup.run(['myfile*.txt'])
    assert result == result_run_simple, 'Result should match'

    # Test 'complex' case with 2 hits
    result = lookup.run(['*/*.txt'])
    assert result == result_run_complex, 'Result should match'

    # Test 'negative' case with 0 hits
    result = lookup.run(['*/*.html'])

# Generated at 2022-06-23 11:33:32.876027
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule()

# Generated at 2022-06-23 11:33:36.345146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_args = dict(
        tasks_from='/dev/null'
    )
    lookup_plugin = LookupModule()
    new_instance = lookup_plugin(module_args, [], templates='/dev/null', variables={})
    assert new_instance is not None

# Generated at 2022-06-23 11:33:37.799265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 11:33:49.972784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Basic test of method run of class LookupModule """
    # pylint: disable=protected-access
    # pylint: disable=no-self-use
    return_list = []
    return_list.append('/my/path/myfile1')
    return_list.append('/my/path/myfile2')
    term = '*.txt'
    basedir = '/my/path/'
    terms = [term]
    variables = {}
    variables['ansible_search_path'] = [basedir]
    variables['ansible_basedir'] = [basedir]
    lookup_obj = LookupModule()
    assert return_list == lookup_obj.run(terms, variables=variables)


    return_list = []

# Generated at 2022-06-23 11:33:54.823500
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print (('Inside test_LookupModule'))

    dirname = os.path.dirname(__file__)
    path = os.path.join(dirname, 'test_MyModule')

    if os.path.isdir(path):
        shutil.rmtree(path)
    os.mkdir(path)
    return path

# Generated at 2022-06-23 11:34:02.924255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule({})
    test_lookup.set_options({
      "wantlist": True,
      "terms": {
          "globbed": ["test_test.txt", "test_test.txt"]
      }
    })
    list_of_files = test_lookup.run(["test_test.txt", "test_test.txt"], {})
    assert isinstance(list_of_files, list)
    assert list_of_files == ["test_test.txt"]

# Generated at 2022-06-23 11:34:12.277584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        '_raw_params': '/playbooks/files/fooapp/*',
        'wantlist': True
    }
    obj = LookupModule()
    obj.basedir = '/playbooks/files'
    obj._reader = dict(
        _host_vars=dict(),
        _group_vars=dict(),
        _inventory_hostname_regexp=None,
        _vars_plugins=dict(
            vars=(),
            group_vars=(),
            host_vars=()
        )
    )

    obj._play = dict(
        _basedir=obj.basedir
    )

    expected_results = ['/playbooks/files/fooapp/1', '/playbooks/files/fooapp/2']
    actual_results = obj.run(**args)

# Generated at 2022-06-23 11:34:17.967301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['ANSIBLE_FILEGLOB_PATH'] = 'tests/files'
    lookup = LookupModule()
    result = lookup.run([u"*.txt"])
    assert result == [u"tests/files/vars.txt"]
    result = lookup.run([u"*.yml"])
    assert result == [u"tests/files/vars.yml"]
    result = lookup.run([u"vars.*"])
    assert result == [u"tests/files/vars.txt", u"tests/files/vars.yml"]

# Generated at 2022-06-23 11:34:29.096176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    test_terms = [
        "*.txt",
        "*.conf",
        "*/*.txt"
    ]
    test_variables = {
        "ansible_search_path": [
            "/etc/ansible",
            "/playbooks/files",
            "/playbooks",
            "/etc/ansible/tasks"
        ]
    }

# Generated at 2022-06-23 11:34:30.515535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert callable(lookup_module)

# Generated at 2022-06-23 11:34:31.502839
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:34:39.357652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.plugins.lookup.fileglob import LookupModule
    lookupModule = LookupModule()

    tempdir = tempfile.mkdtemp(prefix='ansible-test-fileglob')
    tempdir_path = os.path.join(tempdir, 'dummy_dir')
    (fd, tempfile_path) = tempfile.mkstemp(dir=tempdir_path)
    os.close(fd)

    lookupModule.set_options({'_terms': [tempfile_path]})
    assert lookupModule.run()[0] == tempfile_path

# Generated at 2022-06-23 11:34:40.129066
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:34:51.604717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Arrange
    import sys

    from ansible.plugins.lookup import LookupModule
    from ansible.parsing.dataloader import DataLoader

    terms = [
      "motd.j2"
    ]

    variables = {
      "ansible_search_path": [
        "/etc/ansible/roles/commonfiles"
      ]
    }

    l = LookupModule()
    l.set_loader(DataLoader())
    ret = []

    #Act
    ret = l.run(terms, variables, wantlist=True)

    #Assert
    found_path = "/etc/ansible/roles/commonfiles/files/motd.j2"
    element = to_text(ret[0])
    print(element)
    assert ret[0] == found_path
   

# Generated at 2022-06-23 11:34:59.012634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    lookups = lookup_loader.getAllPlugins()

    loader = DataLoader()

    variable_manager = VariableManager()

    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 11:35:00.431284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupmodule = LookupModule()
    assert isinstance(lookupmodule, LookupBase)

# Generated at 2022-06-23 11:35:08.867201
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test case 1
    # constructor LookupModule() should set _templates_basedir to None
    lookup = LookupModule()
    assert lookup._templates_basedir == None, "templates basedir set incorrectly"

    # Test case 2
    # constructor LookupModule(loader, templar, basedir) should set _templates_basedir to templates basedir
    templates_basedir = "set/templates/basedir"
    lookup = LookupModule(loader=None, templar=None, basedir=templates_basedir)
    assert lookup._templates_basedir == templates_basedir, "templates basedir set incorrectly"

# Generated at 2022-06-23 11:35:15.556108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["test_fileglob.py", "/Users/wagnercj/ansible/*.py", "*.py", "test_fileglob.txt", "/Users/wagnercj/ansible/*.txt", "*.txt"]
    variables = {'ansible_search_path': ['/Users/wagnercj/ansible/lookup_plugins']}

    # The file, /Users/wagnercj/ansible/lookup_plugins/test_fileglob.txt, was created earlier in LookupModuleTestCase.setUpClass()
    # We know that that file should be returned when we call the run method with that file name
    assert module.run(terms, variables)

# Generated at 2022-06-23 11:35:21.039783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()

    #Test with an existing dir
    terms = ["README.txt"]
    L.run(terms)

    #Test with a dir that does not exists
    terms = ["/this/does/not/exists/this/file/should/not/exists.txt"]
    L.run(terms)


# Generated at 2022-06-23 11:35:22.853435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:35:24.578938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    src = dict(a=1)
    look = LookupModule(src)
    assert look.runner == src

# Generated at 2022-06-23 11:35:34.801245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import os.path
    import glob
    import mock
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.lookup.fileglob import LookupModule
    module_name = LookupModule()
    lookup_path = os.path.join(os.path.dirname(os.path.dirname(glob.glob(os.path.join(os.getcwd(),'role_directory',''))[0])), 'role_directory')
    terms = [os.path.join(os.path.dirname(os.path.dirname(lookup_path)), 'role_directory', 'integration', 'targets', 'localhost', 'inventory', 'host_vars', 'localhost.yml')]

# Generated at 2022-06-23 11:35:36.342247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the LookupModule constructor"""
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-23 11:35:38.546754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test if lookup module method run works"""
    terms = ['/Volumes/data/tmp/nolookupbuddy/hiera/roles/**/*']
    LookupModule.run(terms)

# Generated at 2022-06-23 11:35:39.786859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-23 11:35:48.462256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''
    print("Testing method run of class LookupModule")
    # Define test input values and expected output values
    terms = ['/tmp/*.txt','/tmp/a.txt']
    variables = {'ansible_search_path':['/tmp']}
    expected_output = ['/tmp/a.txt']

    # Instantiate object of class LookupModule
    look_up = LookupModule()

    # Call method run of class LookupModule
    output = look_up.run(terms, variables)

    # Check if actual output and expected output is same
    assert output == expected_output, "Actual output is not same as expected output"

# Generated at 2022-06-23 11:35:49.448485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:35:50.840754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 11:35:52.713128
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:36:03.229120
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create the lookup class
    lookup = LookupModule()

    # Create the file structure
    os.mkdir('test_fileglob/files')
    os.mkdir('test_fileglob/vars')

    file1 = open('test_fileglob/vars/file1.txt', 'w')
    file1.write('This is file1')
    file1.close()

    file2 = open('test_fileglob/files/file2.txt', 'w')
    file2.write('This is file2')
    file2.close()

    file3 = open('test_fileglob/file3.txt', 'w')
    file3.write('This is file3')
    file3.close()

    # Instantiate the result variable
    results = []

    # Test the case where the term

# Generated at 2022-06-23 11:36:07.581466
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import context

    terms = ["/home/user/data/module_utils/test.py", "*.txt"]

    module_loader = context.CLIARGS['module_path']
    lookup_module = LookupModule(None, module_loader=module_loader)
    result = lookup_module.run(terms)

    assert result[0] == "/home/user/data/module_utils/test.py"
    assert "test_file.txt" in result
    assert "test_file_2.txt" in result
    assert "test_file_3.txt" in result
    assert "README.md" not in result
    assert result[0] == "/home/user/data/module_utils/test.py"

# Generated at 2022-06-23 11:36:16.688697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import os.path
    import tempfile
    import shutil
    plugin = LookupModule()
    results = []
    cwd = os.getcwd()
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

# Generated at 2022-06-23 11:36:18.433144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: fill with unit tests
    return

# Generated at 2022-06-23 11:36:19.395010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:36:20.872287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:36:25.033736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Call constructor with no arguments
    module = LookupModule()

    # Test that fields are accessible and have the right values
    assert hasattr(module, 'run')
    assert hasattr(module, 'get_basedir')
    assert hasattr(module, 'find_file_in_search_path')

# Generated at 2022-06-23 11:36:31.260586
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    #  Assert that we can find /etc/passwd
    assert len(lookup.run([u"/etc/passwd"])) == 1
    assert lookup.run([u"/etc/passwd"]) == [u'/etc/passwd']

    # No such file as /etc/passwd.blah
    assert lookup.run([u"/etc/passwd.blah"]) == []

# Generated at 2022-06-23 11:36:42.768902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms = ["a", "b", "c/d", "e/f/g/h"]
    ans = ["a.txt"]
    assert m.run(terms, {"a": "a.txt", "b": "b.txt", "c/d": "c/d.txt", "e/f/g/h": "e/f/g/h.txt"}) == ans

    ans = ["a.txt"]
    assert m.run(terms, {"a": "a.txt", "b": "b.txt", "c/d": "c/d.txt", "e": {"f": {"g": {"h.txt", "h.pdf"}}}}) == ans

    ans = ["a.txt"]

# Generated at 2022-06-23 11:36:43.482932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:36:51.061614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    file_name = "test.txt"
    # Create a temp file to check the modification time
    file_path = "tmp/lookup_plugins/fileglob/" + file_name
    os.makedirs("tmp/lookup_plugins/fileglob/")
    file1 = open(file_path, "w")
    file1.write("This is filetest")
    file1.close()
    # Check for case when default path is used
    terms = [file_name]
    result = module.run(terms, {})
    # Check the value returned by run
    assert result == [to_text(file_path)]
    os.remove(file_path)
    os.rmdir("tmp/lookup_plugins/fileglob/")
    # Check for case when path is

# Generated at 2022-06-23 11:36:52.092861
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 11:37:01.393666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    terms = ['*']
    variables = {'role_path': './test/test_path/', 'role_path1': './test/test_path_does_not_exist/',
                 'playbook_dir': './', 'roles_path': ['./test/test_path/', './']}
    paths = l.run(terms, variables)
    assert paths == ['./lookup_plugins/test.py', './test/test_path/test.py']

    variables = {'role_path': './test/test_path/', 'role_path1': './test/test_path_does_not_exist/',
                 'playbook_dir': './', 'roles_path': ['./test/test_path/', './']}
   

# Generated at 2022-06-23 11:37:02.486612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    print(a)

# Generated at 2022-06-23 11:37:03.255959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run([])

# Generated at 2022-06-23 11:37:04.041838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module



# Generated at 2022-06-23 11:37:07.066871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test the run method of class LookupModule"""
    lm = LookupModule()
    ret = lm.run(['/etc/passwd'], {})
    assert '/etc/passwd' in ret

# Generated at 2022-06-23 11:37:12.035755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    src_path = '/path/to/a/file.txt'
    terms = [src_path]
    basedir = '/path/to'
    variables = {'ansible_search_path': ['/path/to/files', '/path/to']}
    test_module = LookupModule()
    result = test_module.run(terms, variables)
    assert result == [src_path]

# Generated at 2022-06-23 11:37:21.241467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import mock
    import __builtin__ as builtins
    m = mock.mock_open()
    m.side_effect = [
        StringIO("value1"),
        StringIO("value2"),
        StringIO("value3")
    ]
    with mock.patch('ansible.plugins.lookup.fileglob.open', m):
        with mock.patch("__builtin__.open", m):
            lookup_instance = LookupModule()
            assert lookup_instance.run(["*.items"]) == ["*.items"]



# Generated at 2022-06-23 11:37:22.626149
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert getattr(lm, 'run')

# Generated at 2022-06-23 11:37:33.342611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test data
    import tempfile
    import os
    fd, test_file_name = tempfile.mkstemp()
    os.close(fd)
    # Create test class
    l = LookupModule()
    # Test run method
    assert [] == l.run(terms=[test_file_name], inject={'ansible_search_path': ['.']}, loader=None, templar=None, shared_loader_obj=None)
    fd, test_file_name = tempfile.mkstemp()
    os.close(fd)
    # Test run method
    assert [] == l.run(terms=[test_file_name], inject={'ansible_search_path': ['.']}, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 11:37:41.965729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    # Create test directories and files
    mod.basedir = '~test'
    mod.set_options({})
    assert '~test' == mod.basedir
    assert '' == mod.get_basedir({})
    test_dirs = [
        '~test/foo/bar/baz'
    ]
    test_files = [
        '~test/foo/bar/baz/a.txt',
        '~test/foo/bar/baz/b.xyz',
        '~test/foo/bar/baz/c.123'
    ]
    for dir in test_dirs:
        try:
            os.makedirs(dir)
        except OSError as e:
            print(e)

# Generated at 2022-06-23 11:37:43.356253
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None


# Generated at 2022-06-23 11:37:52.791516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    import os
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    workdir = tempfile.mkdtemp(dir=tmpdir)

    os.chdir(tmpdir)

    # Create files and dirs
    os.mkdir('files')

    # Create files (files/test1, files/test2)
    with open('files/test1', 'w') as f:
        f.write("test")

    with open('files/test2', 'w') as f:
        f.write("test")

    # Create file (test2)
    with open('test2', 'w') as f:
        f.write("test")

    # Create dir (nodir)
    os.mkdir('nodir')

    os.chdir(workdir)

# Generated at 2022-06-23 11:38:01.011125
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    terms = ['/path/', '/path/file.*']
    variables = {
        'ansible_search_path': [
            '/path',
            '/extra/path'
        ]
    }

    res = lookup.run(terms, variables)
    assert len(res) == 2
    assert lookup._get_real_file(res[0]) == lookup._get_real_file(os.path.join(variables['ansible_search_path'][0], 'file.txt'))
    assert lookup._get_real_file(res[1]) == lookup._get_real_file(os.path.join(variables['ansible_search_path'][0], 'file.txt'))

# Generated at 2022-06-23 11:38:02.404447
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:38:03.998885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()
    assert lookup_module_instance is not None

# Generated at 2022-06-23 11:38:14.317632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def my_load_plugins(self, class_name, terms, variables=None, **kwargs):
        lookup = LookupModule()
        return lookup.run(terms, variables, **kwargs)

    LookupBase._load_plugins = my_load_plugins

    # Test #1
    # This test is to check whether the return values are correct and if it returns a empty list when
    # there are no results
    my_val = LookupBase().run([os.path.join(os.path.dirname(__file__), "*.py")], dict(lookup_file=__file__))
    assert(isinstance(my_val, list))
    assert(all(isinstance(item, str) for item in my_val))
    assert(len(my_val) > 0)

    # Test #2
    my_val

# Generated at 2022-06-23 11:38:19.544071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    results = lookup_plugin.run(['/usr/bin/*'], dict())
    assert '/usr/bin/sudo' in results
    assert '/usr/bin/lesspipe' in results
    assert '/usr/bin/rake' not in results
    results = lookup_plugin.run(['/usr/bin/'], dict())
    assert results == []

# Generated at 2022-06-23 11:38:20.757564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run("test")
    assert result == []

# Generated at 2022-06-23 11:38:27.898693
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os, tempfile

    # Create temporary content in temporary directory
    # and perform lookup on that content
    # This will test if lookup can lookup on content
    # that is not present in the directory where the playbook
    # is present.
    temp_dir = tempfile.mkdtemp()
    temp_src = os.path.join(temp_dir, 'foo.j2')
    with open(temp_src,'w') as f:
        f.write("#jinja2: variable_end_string: [[[ ]]]\n")

    temp_dst = os.path.join(temp_dir, 'foo.conf')
    with open(temp_dst,'w') as f:
        f.write("test")

    class args:
        _terms = [temp_src,temp_dst]
        basedir = temp

# Generated at 2022-06-23 11:38:29.474549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Need to mock os/glob in order to test this
    assert False, "No test implemented"

# Generated at 2022-06-23 11:38:30.954020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:38:32.737707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(LookupModule, terms=['/my/path/*.txt'])

# Generated at 2022-06-23 11:38:42.822609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('\n\n----------\nRunning test_LookupModule_run')
    # test 1: term is a file, but no directory
    lookup = LookupModule()
    result = lookup.run(terms = ['test.txt'], variables = dict(ansible_search_path = ["/test/", "/test/testdir/"]))
    assert len(result) != 0, "test 1: no files were found in search path"
    assert result[0] == '/test/test.txt', "test 1: wrong files were found in search path"
    print('test 1 passed: correct file found, no directory specified')
    
    # test 2: term is a directory and a file, with no search path
    lookup = LookupModule()