

# Generated at 2022-06-23 11:28:43.780172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.get_basedir = lambda: "/etc/"
    lookup.find_file_in_search_path = lambda variables, dirname, filename: "/etc/ansible/%s" % (filename)
    terms = ["some_file", "passwords.yml", "some/other/file"]
    result = lookup.run(terms, dict(), wantlist=True)
    assert "/etc/ansible/some_file" in result
    assert "/etc/ansible/passwords.yml" in result
    assert "/etc/ansible/some/other/file" in result
    assert len(result) == 3

# Generated at 2022-06-23 11:28:46.391328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 11:28:48.354982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  module = LookupModule()
  test_terms = ['test']
  result = module.run(test_terms)
  assert result != None

# Generated at 2022-06-23 11:28:49.606838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:28:54.129536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['myfile.txt']
    search_path = ['/home/ansible/']
    result = LookupModule().run(terms, ansible_search_path=search_path)
    assert result[0] == '/home/ansible/myfile.txt'

# Generated at 2022-06-23 11:28:58.213719
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of lookup module
    lm = LookupModule()
    # Check that it is an instance of LookupBase
    assert isinstance(lm, LookupBase)

# Test run function, with ansible_search_path variable set

# Generated at 2022-06-23 11:29:06.389106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Create the mock object for an AnsibleModule
    #
    class MockRunner(object):
        def __init__(self):
            self.mock_basedir = '/some/path'

        def get_basedir(self):
            return self.mock_basedir

    mock_runner = MockRunner()

    #
    # Create the object to be tested
    #
    test_object = LookupModule()

    #
    # Configure the object
    #
    test_object.set_runner(mock_runner)

    #
    # Run the test
    #
    result = test_object.run([], variables={})
    assert result == []



# Generated at 2022-06-23 11:29:14.303055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    args = dict()
    terms = ['abc.txt', 'abc.doc']
    variables = dict(ansible_search_path=['./files'])
    # test with non-existent file
    result = lu.run(terms, variables)
    expected = []
    assert result == expected
    # test with existent file
    args = dict()
    terms = ['abc.txt']
    variables = dict(ansible_search_path=['./files'])
    result = lu.run(terms, variables)
    expected = ['./files/abc.txt']
    assert result == expected

# Generated at 2022-06-23 11:29:25.276722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Method lookup.run() for ansible.plugins.lookup.fileglob
    """
    import sys
    import os

    print("CWD: %s" % os.getcwd())
    print("PATH: %s" % os.environ.get('PATH'))
    print("PYTHONPATH: %s" % os.environ.get('PYTHONPATH'))
    print("ARGS: %s" % sys.argv)
    print("PYTHON VERSION: %s" % sys.version)

    dirs = [
        'dir0',
        'dir1',
        'dir2',
        'dir3',
    ]


# Generated at 2022-06-23 11:29:27.411112
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:29:30.251020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["/opt/tomcat/conf/tomcat-users.xml"]) == ['/opt/tomcat/conf/tomcat-users.xml']

# Generated at 2022-06-23 11:29:31.624819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:29:33.873536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([u"*.sh"], {}) == []

# Generated at 2022-06-23 11:29:35.155307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule._load_name == 'fileglob'

# Generated at 2022-06-23 11:29:41.759515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager.set_inventory(inventory)
    # Test result of constructor
    assert LookupModule(loader=loader, variable_manager=variable_manager, templar=None) is not None
    # Test result of run
    lookup_module = LookupModule(loader=loader, variable_manager=variable_manager, templar=None)
    assert lookup_module.run(terms="", variables=dict()) == list()

# Generated at 2022-06-23 11:29:43.255675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:29:53.742900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    """

    # Create mock object of class LookupModule
    lookup_obj = LookupModule()

    # Fake the glob module class
    class fake_glob:
        def glob(self, t):
            return [to_bytes("Elem1"), to_bytes("Elem2")]
    glob_obj = fake_glob()

    # Mock the glob module
    lookup_obj.glob = glob_obj


    # Fake the os module class
    class fake_os:
        def path(self, t):
            return self

        def exists(self, t):
            return True

        def basename(self, t):
            return to_bytes("terms")

        def dirname(self, t):
            return to_bytes("")


# Generated at 2022-06-23 11:29:58.098676
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert(isinstance(lookup_module, LookupModule))

    # test run method
    terms = ['/path/to/bar.txt']
    variables = {'ansible_search_path': ['/playbooks/files', '/playbooks/vars']}
    lookup_module.run(terms, variables)

# Generated at 2022-06-23 11:29:59.632409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'

# Generated at 2022-06-23 11:30:00.403172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:30:01.271486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:30:06.719824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestClass:
        class Options:
            _terms = 'test'
        def __init__(self):
            self.basedir = '/whatever'

    providers = [
        ('fileglob', TestClass(), {'_terms': '/base/*'}, ['/base/test1', '/base/test2']),
        ('fileglob', TestClass(), {'_terms': 'test1'}, []),
        ('fileglob', TestClass(), {'_terms': '/test1'}, []),
        ('fileglob', TestClass(), {'_terms': ['/base/*', 'test1']}, ['/base/test1', '/base/test2']),
        ('fileglob', TestClass(), {'_terms': 'test1 test2'}, []),
    ]


# Generated at 2022-06-23 11:30:09.142748
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    # assert minumum required attributes
    assert hasattr(lm, 'run')
    assert callable(lm.run)

# Generated at 2022-06-23 11:30:13.322791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms='/etc/issue') == ['/etc/issue']
    assert LookupModule().run(terms='/etc/issue', inject={'ansible_search_path': ['/etc']}) == ['/etc/issue']
    assert LookupModule().run(terms='/root/') == []
    assert LookupModule().run(terms='/etc/issuex') == []

# Generated at 2022-06-23 11:30:23.268128
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l.basedir = "."


# Generated at 2022-06-23 11:30:24.062566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:30:24.657395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:30:26.142354
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:30:35.681772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test variable substitution on the path
    """
    lookup = LookupModule()
    assert lookup._loader is not None
    # test variable substitution on the path
    terms = ['/var/lib/lookuptest_variable_substitution.txt']
    variables = dict(lookuptest_variable_substitution='/var/lib')
    assert lookup.run(terms, variables=variables) == ['/var/lib/lookuptest_variable_substitution.txt']

    # test variable substitution on the path
    terms = ['/var/lib/lookuptest_variable_substitution.txt']
    variables = dict(lookuptest_variable_substitution='/usr/lib')
    assert lookup.run(terms, variables=variables) == []

    # test variable substitution on the path

# Generated at 2022-06-23 11:30:40.908908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    sys.path.append(os.getcwd())
    from _ansible_lookup_plugins import LookupModule

    terms = ['./*.py']
    variables = {}
    lookup_module = LookupModule()
    results = lookup_module.run(terms, variables)

    assert results == ['.//ansible_lookup_plugins.py']

# Generated at 2022-06-23 11:30:41.934650
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 11:30:43.819583
# Unit test for constructor of class LookupModule
def test_LookupModule():

    args = ['/my/path/*.txt']
    assert LookupModule().run(args) == []

# Generated at 2022-06-23 11:30:55.079179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    from ansible.utils.lookup_plugins.fileglob import LookupModule
    import os
    import yaml

# Generated at 2022-06-23 11:30:57.174823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = dict()
    ret = dict()
    ret = lookup_plugin.run(terms)
    assert ret == []

# Generated at 2022-06-23 11:30:59.307622
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # default
    l = LookupModule()

    assert l._basedir is None
    assert l._templar is None

# Generated at 2022-06-23 11:31:01.326489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["test_data/testfile1.txt"]) == ["test_data/testfile1.txt"]

# Generated at 2022-06-23 11:31:02.934605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None



# Generated at 2022-06-23 11:31:05.077624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test', 'file']) == []

# Generated at 2022-06-23 11:31:16.410442
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    testcase = [
        {'terms': ['/playbooks/files/fooapp/*'], 'path': '/playbooks/files/fooapp/', 'expected_results': ['/playbooks/files/fooapp/test1', '/playbooks/files/fooapp/test2']},
        {'terms': ['test.txt'], 'path': '/playbooks/files/fooapp/', 'expected_results': ['/playbooks/files/fooapp/test.txt']},
        {'terms': ['test1.txt'], 'path': '/playbooks/files/fooapp/', 'expected_results': []}
    ]


# Generated at 2022-06-23 11:31:16.990447
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:31:22.572343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test class constructor LookupModule"""
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# when run as a script we want to test the version in lib/ansible/plugins/lookup/fileglob.py
if __name__ == '__main__':
    import sys
    sys.path.append('lib/ansible/plugins/lookup/')
    from fileglob import *
    sys.path.pop()
    test_LookupModule()

# Generated at 2022-06-23 11:31:33.349840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ['/my/path/*.txt']
    files = ['mydir/file1.txt', 'mydir/file3.txt', 'mydir/file2.txt', 'mydir/file4.txt']
    src = [dict(path='/my/path', mode=0o755, owner='', group='', file=files)]
    search_path = dict(path=['/my/path'], src=src)
    variables = dict(ansible_search_path=[], start=0, wantlist=True)
    variables.update(dict(ansible_search_path=search_path['path']))

    result = lookup_plugin.run(terms=terms, variables=variables)
    assert result == [], "Files list wrongly populated"

# Generated at 2022-06-23 11:31:35.866603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    results = lookup.run(['./test_lookup_fileglob.py'], {'lookup_file': 'test_lookup_fileglob.py'})
    assert len(results) == 1


# Generated at 2022-06-23 11:31:36.998503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.__class__.__name__ == 'LookupModule'

# Generated at 2022-06-23 11:31:37.882028
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 11:31:38.452598
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:31:39.057957
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:31:41.832879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([], None) == [], "Lookup module returned a non-empty list when empty list is passed!"

# Generated at 2022-06-23 11:31:44.355313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as loader
    pluginClass = loader.get("lookup","fileglob")
    assert("LookupModule" in str(pluginClass))

# Generated at 2022-06-23 11:31:45.291443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(1 == 1)

# Generated at 2022-06-23 11:31:46.565542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 11:31:47.497708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:31:49.884464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Unit tests for the behavior of LookupModule in the case that the file search list is empty

# Generated at 2022-06-23 11:31:52.941614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert (lm.run(['*'])) == []
    assert (lm.run(['*', '*.ini'])) == []

# Generated at 2022-06-23 11:31:54.975111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p = LookupModule()
    assert p.run(terms = "ansible")
    assert p.run(terms = "ansible.txt")
    assert p.run(terms = "ansible/ansible.txt")
    assert p.run(terms = "ansible/fileglob.ansible.txt") == []

# Generated at 2022-06-23 11:31:55.944321
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 11:31:57.309112
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run

# Generated at 2022-06-23 11:32:05.421237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['*'], {'ansible_search_path': ['/tmp']}) == [], module.run(['*'], {'ansible_search_path': ['/tmp']})

# Generated at 2022-06-23 11:32:06.361609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:32:09.902379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters for instantiating the class
    lookup = LookupModule()
    # test retrieve list of files
    ret = lookup.run(['/my/path/*.txt'])
    assert ret == []

# Generated at 2022-06-23 11:32:11.718775
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert(LookupModule)

# Generated at 2022-06-23 11:32:20.909796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    # Create a temporary directory
    tmp_dir = "/tmp/%s" % os.path.basename(__file__)
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    # Create a temporary result file
    tmp_file = os.path.join(tmp_dir, "test.txt")

    # Create the temporary file with some data
    with open(tmp_file, 'w') as f:
        f.write("Hello World!")

    # Create a lookup object
    l = LookupModule()

    # Call the lookup run method
    f = l.run(terms=[tmp_file], inject={'ansible_search_path': tmp_dir}, wantlist=True)[0]

    # Check result
    assert f == tmp_file

    #

# Generated at 2022-06-23 11:32:29.870020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First unit test for fileglob lookup on windows, based on the case described in #56764
    # Fixed in ansible v2.10
    # bugzilla: https://bugzilla.redhat.com/show_bug.cgi?id=1813700
    # pytest: https://github.com/ansible/ansible/pull/67303
    if os.name == 'nt':
        from ansible.module_utils._text import to_text
        import pytest
        lookup = LookupModule()
        term = "['C:\\Program Files\\*']"
        terms = [to_text(term)]
        with pytest.raises(AnsibleFileNotFound):
            lookup.run(terms)

# Generated at 2022-06-23 11:32:35.184245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'lookup_plugin.fileglob' in sys.modules

    # test lookup plugin
    lookup = LookupModule()
    lookup.run([], [])
    assert len(lookup.run) == 3
    assert lookup.run.__name__ == 'run'
    assert lookup.run.__doc__ == 'perform lookup plugin functionality'

    # tests parameters
    assert lookup.basedir == '.'

# Generated at 2022-06-23 11:32:43.480469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a path containing a dot.
    lookup_module = LookupModule()
    test_variable_definitions = {
        'ansible_search_path': [
            '/path/to/ansible/roles',
            '/path/to/ansible/playbooks',
        ]
    }

    files_path = '/path/to/ansible/playbooks/files'
    directory = '/path/to/ansible/playbooks/files/test'
    term = 'test/file.py'
    filename = 'file.py'
    path = os.path.join(directory, filename)
    os.path.exists = lambda path: True
    os.path.isdir = lambda path: False
    os.path.isfile = lambda path: True

    lookup_module.find_file_in_search_path

# Generated at 2022-06-23 11:32:48.795891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Python 3
        import unittest.mock as mock
    except ImportError:
        # Python 2
        import mock

    lookup = LookupModule()
    assert lookup.run(['/my/path/*.txt'], {
        'ansible_search_path': ['/my', '/your'],
        'files': '/files'
    }) == ['/files/path/a.txt', '/files/path/b.txt']
    assert lookup.run(['/my/path/*.txt'], {
        'ansible_search_path': ['/my', '/your'],
        'files': '/files'
    }) == ['/files/path/a.txt', '/files/path/b.txt']

    with mock.patch('os.path.isfile') as patched_isfile:
        patched

# Generated at 2022-06-23 11:32:52.586349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert not LookupModule({}, {}).run(terms=[''], wantlist=False)
    assert not LookupModule({}, {}).run(terms=['/'], wantlist=False)
    assert LookupModule({}, {}).run(terms=['/etc/passwd'], wantlist=False)

# Generated at 2022-06-23 11:33:00.415994
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm.run(
        terms=['*.txt'],
        variables={
            'ansible_search_path': ['/tmp/LOOKUP'],
            'playbook_dir': '/tmp',
            'play_dir': '/tmp/LOOKUP',
            'inventory_dir': '/tmp/LOOKUP',
            'inventory_file': '/tmp/LOOKUP/hosts'
        }
    ) == ['/tmp/LOOKUP/file.txt']

# Generated at 2022-06-23 11:33:07.968818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # reading a file that does not exists
    ret = lookup.run(['/tmp/abc.txt'], variables={'ansible_env': {'PATH': ['/root/']}})
    assert ret == [], 'fileglob test fails'

    # reading a file that exists
    file = open('/tmp/abc.txt', 'w+')
    file.close()
    ret = lookup.run(['/tmp/abc.txt'], variables={'ansible_env': {'PATH': ['/root/']}})
    os.remove('/tmp/abc.txt')
    assert ret == ['/tmp/abc.txt'], 'fileglob test fails'

# Generated at 2022-06-23 11:33:08.960581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-23 11:33:09.539534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 11:33:10.436154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:33:15.038466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms_list = ['/tmp/*.txt', '/tmp/', '*.yml']
    variables={'ansible_search_path': ['/tmp/']}
    ret = lu.run(terms=terms_list, variables=variables)
    assert ret == ['/tmp/file1.txt', '/tmp/file2.txt', '/tmp/file3.txt']

# Generated at 2022-06-23 11:33:16.707607
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run([], dict())


# Generated at 2022-06-23 11:33:24.128947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_instance = LookupModule()
    lookup_instance.set_options({})
    lookup_instance._templar = None

    # Test
    assert lookup_instance.run(["/etc/passwd"]) == ["/etc/passwd"]

    # Test
    assert lookup_instance.run(["/etc/*.conf"]) == ["/etc/inputrc.conf", "/etc/services.conf", "/etc/vconsole.conf"]

# Generated at 2022-06-23 11:33:26.641988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 'run' in dir(l)
    assert 'run' not in dir(LookupBase)

# Generated at 2022-06-23 11:33:36.225064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_dir = os.path.dirname(__file__)
    fixture_dir = os.path.join(ansible_dir, '../../fixtures/lookup/fileglob')

    # If there are no fixtures, tests can't run
    if not os.path.isdir(fixture_dir):
        raise Exception("Fixture directory not found: {}".format(fixture_dir))

    # Create an instance of LookupModule
    lm = LookupModule()
    lm.set_options({})

    # Create variables with ansible_search_path that point to the fixture directory
    variables = dict()

# Generated at 2022-06-23 11:33:43.345409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # To test this, override the method find_file_in_search_path
    def mock_find_file_in_search_path(variables, directory, path):
        return path

    setattr(LookupModule, 'find_file_in_search_path', mock_find_file_in_search_path)

    # First test: no file found
    result = module.run(terms=['/etc/foo.conf.j2'], variables={'ansible_search_path': ['/etc/ansible/roles/myapp']})
    assert result == []

    # Second test: file found

# Generated at 2022-06-23 11:33:44.219438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule

# Generated at 2022-06-23 11:33:46.467381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:33:54.909122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    import tempfile
    import shutil
    handle, filename = tempfile.mkstemp(suffix='.txt')
    with open(filename, 'w') as f:
        f.write("test")
    terms = [filename]
    results =  lookup.run(terms, variables={})
    assert results == terms
    os.remove(filename)
    shutil.rmtree(os.path.dirname(filename))
    terms = [os.path.basename(filename)]
    results =  lookup.run(terms, variables={})
    assert results == [filename]

# Generated at 2022-06-23 11:34:06.648495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.fileglob import LookupModule
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleImmutableDict

    base = AnsibleImmutableDict({u'__ansible_module_name': u'fileglob', u'__ansible_module_args': {u'_ansible_opts': {'muted': False}, u'_ansible_version': u'2.8.2'}})
    host = AnsibleImmutableDict({u'__ansible_module_name': u'fileglob', u'__ansible_module_args': {u'_ansible_opts': {'muted': False}, u'_ansible_version': u'2.8.2'}})
    variables = AnsibleImmutableD

# Generated at 2022-06-23 11:34:07.615963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 11:34:15.452447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    basedir = os.path.join(os.path.dirname(__file__))
    content = 'content'
    files = [
        os.path.join(basedir, 'test', 'file1.txt'),
        os.path.join(basedir, 'test', 'file2.txt'),
    ]
    test_args = [os.path.join(basedir, '*.txt')]
    test_variables = {}

    # Generate test files
    for file in files:
        os.makedirs(os.path.dirname(file), mode=0o700, exist_ok=True)
        with open(file, 'w') as f:
            f.write(content)

    # Test
    test_result = []

# Generated at 2022-06-23 11:34:26.035927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import mock
    except ImportError:
        from unittest import mock
    module = mock.MagicMock()
    module.params = {'terms': '/my/path/*.txt'}
    instance = mock.MagicMock()
    instance.run.return_value = mock.sentinel.result
    with mock.patch('ansible.plugins.lookup.fileglob.LookupModule', return_value=instance):
        import ansible.plugins.lookup.fileglob
        ansible.plugins.lookup.fileglob.run(module)
        instance.assert_called_with(terms=["/my/path/*.txt"], variables=None, inject=None)

# Generated at 2022-06-23 11:34:34.714291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object and set its attributes
    look = LookupModule()
    look.basedir = 'my/basedir'
    look.environment = dict(basedir='my/basedir')
    look.find_file_in_search_path = lambda variables, dirs, f: '/mnt/lookup/f1'
    look.get_basedir = lambda v: 'my/basedir'
    look.get_filename_variables = lambda terms: dict(basedir='my/basedir')

    look.run_search_path = lambda p, t: '/mnt/lookup/f2'
    look.run_path_backwards = lambda t: '/mnt/lookup/f3'

# Generated at 2022-06-23 11:34:44.137694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ansible_path = os.getcwd()
    ansible_search_path = [os.path.join(ansible_path, 'test')]
    variable = {'ansible_search_path': ansible_search_path}
    term = ['foo', 'bar', 'baz']
    result = lookup_module.run(terms=term, variables=variable)
    assert result == [
        os.path.join(ansible_search_path[0], 'foo'),
        os.path.join(ansible_search_path[0], 'bar'),
        os.path.join(ansible_search_path[0], 'baz')
    ]

    os.mkdir("baz")
    result = lookup_module.run(terms=term, variables=variable)
   

# Generated at 2022-06-23 11:34:45.339256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:34:46.842256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:34:50.295351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test LookupModule by initiating the class
    '''
    filename = __file__
    loc = LookupModule()
    assert loc is not None
    assert loc._templar is not None


# Generated at 2022-06-23 11:34:51.647143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:34:56.478777
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create the lookup plugin instance
    lookup_plugin = LookupModule()

    # Sample test terms
    terms = ['/my/path/file.txt', '*.txt']

    # Sample test variables(dict)
    variables = {'ansible_search_path': ['/root']}

    # Sample test for fileglob
    result = lookup_plugin.run(terms, variables)

    # Assertion
    assert result == ['', '/root/file.txt'], "lookup fileglob failed"

# Generated at 2022-06-23 11:35:07.189885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import jinja2
    import shutil

    def test_method(tmp, path):
        LookupModule().run([path], dict(ansible_search_path=[tmp]))

    test_dir = os.path.join('test', 'test_lookup_fileglob')
    test_dir1_path = os.path.join(test_dir, 'test1')
    test_dir2_path = os.path.join(test_dir, 'test2')
    test_dir3_path = os.path.join(test_dir, 'test3')
    os.makedirs(test_dir1_path)
    os.makedirs(test_dir2_path)
    os.makedirs(test_dir)


# Generated at 2022-06-23 11:35:07.792236
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:35:15.377798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule, LookupBase
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes, to_text

    lookup = LookupModule()
    lookup._connection = None
    lookup.runner = None
    lookup.basedir = '/playbooks/files'
    # test 1, term is file, no dir in term
    result = lookup.run(['file1.txt'], variables={})
    assert result == ['/playbooks/files/file1.txt']
    # test 2, term is file+path, dir in term
    result = lookup.run(['/playbooks/files/file1.txt'], variables={})
    assert result == ['/playbooks/files/file1.txt']
    # test 3, term is file+

# Generated at 2022-06-23 11:35:17.195161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'ansible' in LookupModule.run(None, terms=['ans*'])

# Generated at 2022-06-23 11:35:27.324509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # tests with invalid parameters
    invalid_params = [None, [], {}, (), 1, 1.4]
    for invalid_param in invalid_params:
        result = lookup.run(invalid_param)
        assert result == [], "test_LookupModule_run with invalid parameter should return None"

    # test with invalid objeect in list
    invalid_list = [None, [], {}, ()]
    result = lookup.run([1, "abc", 2, invalid_list])
    assert result == ["abc"], "test_LookupModule_run with invalid parameter should return a list without invalid parameter"

    # test with invalid objeect in nested list
    invalid_list = [None, [], {}, ()]

# Generated at 2022-06-23 11:35:27.876553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:35:35.742598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["test_test_test.py"], variables=None, wantlist=False) == ['/home/pavel/ansible/test/test_test_test.py']
    assert module.run(["test_test_test.py"], variables=None, wantlist=True) == ['/home/pavel/ansible/test/test_test_test.py']
    assert module.run(["test_test_test.py"], variables=None, wantlist=True, basedir="/home/pavel/ansible/test") == ['/home/pavel/ansible/test/test_test_test.py']

# Generated at 2022-06-23 11:35:47.191937
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    # pylint: disable=too-few-public-methods
    class TestFileNotFound(unittest.TestCase):

        # pylint: disable=invalid-name
        def test_LookupModule__run_should_raise_AnsibleFileNotFound_when_file_is_not_found(self):
            # arrange
            lookup = LookupModule()
            terms = ['file/path/doesnotexist']
            variables = {}
            kwargs = {}

            # act + assert
            self.assertRaises(AnsibleFileNotFound, lookup.run, terms, **kwargs)

    unittest.main(exit=False)

# Generated at 2022-06-23 11:35:48.213881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:35:53.927063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create LookupModule object
    lookup = LookupModule()

    # create fake parameters
    terms = "fake terms"
    variables = "fake variable"
    params = dict()

    # run run()
    results = lookup.run(terms, variables, **params)

    # should always return empty list
    assert type(results) is list
    assert len(results) == 0



# Generated at 2022-06-23 11:35:54.685545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 11:36:03.486984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module = LookupModule()
    lookup_module.set_options({})
    lookup_module.get_basedir = lambda variables: os.path.join(os.path.dirname(__file__), 'fixtures', 'fileglob')
    lookup_module.find_file_in_search_path = lambda variables, url, path: os.path.join(lookup_module.get_basedir(variables), path[1:])
    lookup_module.get_basedir = lambda variables: os.path.join(os.path.dirname(__file__), 'fixtures', 'fileglob')

    # Act

# Generated at 2022-06-23 11:36:05.008271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:36:09.915366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3
    from ansible.utils.listify import listify_lookup_plugin_terms
    if PY3:
        terms = ['/playbooks/files/fooapp/*']
        lm = LookupModule()
        vars = {'ansible_search_path': ['/playbooks/files']}
        lookup_result = lm._flatten(listify_lookup_plugin_terms(terms, templar=None, loader=None, fail_on_undefined=True), vars=vars)
        assert lookup_result == ['/playbooks/files/fooapp/*']
    else:
        terms = ['/playbooks/files/fooapp/*']
        lm = LookupModule()

# Generated at 2022-06-23 11:36:12.086861
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.basic import AnsibleModule
    assert LookupModule(module=AnsibleModule()).run('abc') == ['abc']

# Generated at 2022-06-23 11:36:17.640304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['/fixtures/../fixtures/file_*.txt', '/fixtures/../fixtures/dir/file_*.txt',
             '/fixtures/../fixtures/nonexistent']
    expected = ['../lookup_plugins/file_1.txt', '../lookup_plugins/file_2.txt']
    path = os.path.join(os.path.dirname(__file__), 'fixtures')
    result = module.run(terms, variables={'ansible_search_path': [path]})
    assert result == expected


# Generated at 2022-06-23 11:36:28.892785
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ret = all_failing_lookup_module_run(LookupModule)
    assert isinstance(ret, list)
    assert ret == []

    # .tablename
    terms = ["*.tablename"]
    ret = LookupModule().run(terms)
    assert isinstance(ret, list)
    assert ret == []

    # fileglob/fileglob.py
    terms = ["fileglob/fileglob.py"]
    ret = LookupModule().run(terms)
    assert isinstance(ret, list)
    assert ret == ["fileglob/fileglob.py"]

    # fileglob.py
    terms = ["fileglob.py"]
    ret = LookupModule().run(terms)
    assert isinstance(ret, list)
    assert ret == ["fileglob.py"]

# Generated at 2022-06-23 11:36:30.033551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

if __name__ == '__main__':
    print('The file was executed')

# Generated at 2022-06-23 11:36:34.190535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_path = os.path.join(os.path.dirname(__file__), "../../files/test.txt")
    expected_paths = [file_path]
    mock_paths = [file_path]
    # For each test case create a lookup module object
    lookup_module_obj = LookupModule()
    paths_list = lookup_module_obj.run(mock_paths)
    assert paths_list == expected_paths

# Generated at 2022-06-23 11:36:41.258352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # Test with existing file
    # Test with existing dir with 'files' globbing
    # Test with existing dir with 'files' path
    # Test with existing dir with 'files' globbing and 'files' path
    # Test with no existing dir
    # Test with no existing dir with 'files' globbing
    # Test with no existing dir with 'files' path
    # Test with no existing dir with 'files' globbing and 'files' path
    pass

# Generated at 2022-06-23 11:36:41.939904
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:36:42.891242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(callable(LookupModule))

# Generated at 2022-06-23 11:36:44.259155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:36:49.717392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test for method run of class LookupModule
    lookup_plugin = LookupModule()
    terms = ['*.txt', '*.a', '*.b']
    ret_vals = ['foo.txt', 'bar.txt', 'foo.a', 'bar.a', 'foo.b', 'bar.b']
    ret = lookup_plugin.run(terms, {})
    # Use assertCountEqual instead of assertEqual as order is not known
    assert len(ret) == len(ret_vals)
    assert set(ret) == set(ret_vals)

# Generated at 2022-06-23 11:36:58.245171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # in
    terms = [
      u'/my/path/*.txt',
      u"test*/test/*.txt'"
    ]
    variables = {
        u'ansible_search_path': [
            u'/playbooks/files/fooapp/'
        ]
    }
    # out
    expect = [
      u'/my/path/file.txt',
      u'/my/path/file2.txt'
    ]

    # when
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)

    # expect
    assert result == expect

# Generated at 2022-06-23 11:37:09.875036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock

    ansible_module_run_mock = mock.MagicMock()
    setattr(ansible_module_run_mock, '_ExplicitVars',
            {'_ansible_search_path': ['/ansible/search/path1'],
             '_ansible_basedir': '/ansible/basedir'
             })
    ansible_module_run_mock.get_basedir.return_value = 'fileglob_basedir'


# Generated at 2022-06-23 11:37:11.149754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:37:21.997386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    os.environ['HOME'] = '/home/myhome'
    assert lookup.run(['./file2', '/tmp/file1'], variables={
        'role_path': ['/home/myhome/roles']
    }) == ['/home/myhome/roles/test-fileglob/file2', '/tmp/file1']

    # this is looking for .gitignore file in HOME directory (need to create one for testing)
    assert lookup.run(['~/.gitignore'], variables={
        'role_path': ['/home/myhome/roles']
    }) == ['/home/myhome/.gitignore']

    # this is looking for .gitignore file in HOME directory (need to create one for testing)

# Generated at 2022-06-23 11:37:28.199987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str1 = ''
    search_paths = {'ansible_search_path': ['/home/ubuntu']}
    dwimmed_path = '/home/ubuntu/files'
    basedir = '/home/ubuntu'
    test_file_regex = '*'
    term_file = test_file_regex
    fileglob_object = LookupModule()
    assert fileglob_object.run([test_file_regex], search_paths) == [str1]

# Generated at 2022-06-23 11:37:29.399525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:37:32.039045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Unit testing LookupModule...")
    lookup = LookupModule()
    print("Test succesfull")


# Generated at 2022-06-23 11:37:34.492108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['/my/path/*.txt', '/my/path/*.jpg']
  lookup = LookupModule()
  ret = lookup.run(terms)
  for f in ret:
    assert os.path.isfile(f)
    assert os.path.basename(f) != f

# Generated at 2022-06-23 11:37:36.432208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = ['/test*.txt']
    assert len(LookupModule().run(args)) > 0

# Generated at 2022-06-23 11:37:37.517061
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj

# Generated at 2022-06-23 11:37:38.745304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global module
    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 11:37:40.540523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    assert(lookup_plugin is not None)

# Generated at 2022-06-23 11:37:41.514374
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:37:52.162438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['/tmp/ansible/'])             == []
    assert LookupModule().run(['/tmp/ansible/', '*.txt'])    == []
    assert LookupModule().run(['*.txt'])                     == []
    assert LookupModule().run(['*.txt', '*.md'])             == []
    assert LookupModule().run(['*.txt', '*.md', '*./tmp'])   == []
    assert LookupModule().run(['*.txt', '*.md', '*.ini'])    == ['../../tests/files/ansible.cfg']
    assert LookupModule().run(['*.txt', '*.md', '*.ini', '*/tmp']) == ['../../tests/files/ansible.cfg']
    assert LookupModule().run(['*/tmp'])                    

# Generated at 2022-06-23 11:37:55.176563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    result = lookup_instance.run(['test.txt'], {}, wantlist=False)
    assert len(result) == 1
    assert result[0] == '/home/yunwei/Downloads/test.txt'

# Generated at 2022-06-23 11:38:02.499158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock 'ansible_search_path' in the variables
    variables = { 'ansible_search_path': ['/my/search/path', '/my/inventories/path'] }
    lookupModule = LookupModule()
    # This should return paths of all .txt files in the search path and inventories path
    assert(lookupModule.run(['*.txt'], variables)) == ['/my/search/path/bar.txt', '/my/search/path/foo.txt', '/my/inventories/path/fruits.txt']
    # This should return a path of the file 'foo.txt' in the search path and a file 'fruits.txt' in the inventories path

# Generated at 2022-06-23 11:38:04.105098
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None, "Failed to create instance"

# Generated at 2022-06-23 11:38:07.309783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Unit test to create a file and verify the file is created

# Generated at 2022-06-23 11:38:08.418403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_basics():
        assert LookupModule

# Generated at 2022-06-23 11:38:09.373063
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule() is not None

# Generated at 2022-06-23 11:38:20.470958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Test fileglob with file name only
    ret = lookup_plugin.run([os.path.abspath('../lookup_plugins/fileglob/__init__.py')], dict(), wantlist=True)
    assert to_bytes(os.path.abspath('../lookup_plugins/fileglob/__init__.py'), errors='surrogate_or_strict') in ret
    ret = lookup_plugin.run([os.path.basename('../lookup_plugins/fileglob/__init__.py')], dict(), wantlist=True)
    assert to_bytes(os.path.abspath('../lookup_plugins/fileglob/__init__.py'), errors='surrogate_or_strict') in ret

    # Test fileglob with

# Generated at 2022-06-23 11:38:23.892886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = ansible.plugins.lookup.fileglob.LookupModule()
    assert isinstance(instance, ansible.plugins.lookup.fileglob.LookupModule)


# Generated at 2022-06-23 11:38:28.868583
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Invoke function with valid arguments to verify
    # it returns something without raising any exceptions
    terms = ['/my/path/*.txt', '/my/path/*.jpg']
    variables = {}
    lookup_instance = LookupModule()

    lookup_instance.run(terms, variables)

# Generated at 2022-06-23 11:38:29.778094
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:38:30.691473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 11:38:32.125361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:38:34.484744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:38:40.798184
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ['test_path_1', 'test_path_2']
    variables = {'ansible_search_path': ['/my/path/', '/my/path2/']}

    test_lookup = LookupModule()
    test_lookup.get_basedir = lambda x: '/my/path/'
    test_lookup.find_file_in_search_path = lambda x, y, z: z
    test_lookup.run(terms, variables)