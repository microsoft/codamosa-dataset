

# Generated at 2022-06-25 10:32:57.864944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(["/foo/bar/baz"], {"/foo/bar/baz": "/foo/bar/baz"})
    assert ret is not None

    # Test for non-existent file path
    lookup_module_1 = LookupModule()
    try:
        ret = lookup_module_1.run(["/foo/bar/baz"], {"/foo/bar/baz": "/foo/bar/baz"})
    except FileNotFoundError:
        assert True

    lookup_module_2 = LookupModule()
    ret = lookup_module_2.run(["/foo/bar/baz"], {"/foo/bar/baz": "/foo/bar/baz"})
    assert ret is not None

# Generated at 2022-06-25 10:33:01.919668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert not lookup_module_0.run()


# Check if __name__ == '__main__'
if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:13.422638
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/etc/*']
    variables = None
    lookup_module = LookupModule()


# Generated at 2022-06-25 10:33:16.570683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms  = '*.txt'
    lookup_module_0 = LookupModule()
    temp_lookup_result = lookup_module_0.run(terms)
    temp_lookup_result

# Generated at 2022-06-25 10:33:25.126283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'_ansible_verbosity': 0, '_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p', 'vfat']})

# Generated at 2022-06-25 10:33:33.097492
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #  The results of the run must be a list.
    #  In this case, the run returns the list ['/path/a.txt', '/path/b.txt'].
    #  The assertions follow.
    (test_class_0,test_module_0) = (LookupModule(),'LookupModule')
    (test_name_0,expected_result_0) = ('test_run_0',[b'/path/a.txt', b'/path/b.txt'])
    (method_name_0,args_0) = ('run',[['/path/*.txt', '/other/path/*.txt']])

    #  Execute the code to be tested.
    test_class_0_instance_0 = test_class_0()

# Generated at 2022-06-25 10:33:35.709083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing fileglob_lookup plugin")
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['*.txt'])
    assert result is not None


# Generated at 2022-06-25 10:33:39.470956
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0 = ['*.txt']

    variables_0 = {}
    ret = lookup_module_0.run(terms_0, variables_0)
    assert ret == []


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 10:33:48.193186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    lookup_module = LookupModule()

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-25 10:33:49.910764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    assert lookup_module_0._flatten(lookup_module_0.run(terms_0, variables_0)) == []


# Generated at 2022-06-25 10:34:01.887971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = ['/etc/ansible/*.cfg', '*.log']

# Generated at 2022-06-25 10:34:12.559003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["/a/b","/a/b/c.txt"])
    lookup_module.run(["/a/b","/a/b/c.txt"], {'ansible_search_path': ['/etc']})
    lookup_module.run(["/a/b","/a/b/c.txt"], {'ansible_search_path': ['/etc'], 'ansible_basedir': 'test-ansible/'})


# Unit test test cases for LookupModule
if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:18.238230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Tests if will fail due to string index out of range
    assert lookup_module_0.run(['/etc/ansible/roles/test_role/files/*.txt'])

# Generated at 2022-06-25 10:34:21.593914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Testing 'terms' type
    assert isinstance(lookup_module_0.run('/playbooks/files/fooapp/*'), list)

# Generated at 2022-06-25 10:34:28.643289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_args_0 = []
    term_file_0 = None
    found_paths_0 = []
    if term_file_0 != term_file_0:
        found_paths_0.append(lookup_module_0.find_file_in_search_path(variables_0, 'files', os.path.dirname(term_file_0)))
    else:
        found_paths_0.append(os.path.join(p_0, 'files'))
        found_paths_0.append(p_0)

# Generated at 2022-06-25 10:34:34.922483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/my/file/path']
    variables_1 = None
    returned_value_0 = lookup_module_1.run(terms_1, variables_1)
    assert returned_value_0 == ['/my/file/path']

# Generated at 2022-06-25 10:34:39.706255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleFileNotFound) as excinfo:
        lookup_module_1.run("**/*.xml")
    assert excinfo.value.message == "could not locate file in lookup: **/*.xml"

# Generated at 2022-06-25 10:34:46.455805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['amqp-run-python.sh'],None)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:53.504246
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import unittest

    class TestCase(unittest.TestCase):

        def test_0(self):

            lookup_module = LookupModule()

            # test with valid data
            terms = [ '/etc/hosts' ]
            variables = dict()
            result = lookup_module.run(terms, variables)
            self.assertEqual(result, list())


        def test_1(self):

            lookup_module = LookupModule()

            # test with valid data
            terms = [ '/etc/hosts' ]
            variables = dict(ansible_search_path=['/tmp'])
            result = lookup_module.run(terms, variables)
            self.assertEqual(result, list())


        def test_2(self):

            lookup_module = LookupModule()

            # test

# Generated at 2022-06-25 10:35:02.051877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{'key': 'value'}]
    # Case with no args and no kwargs
    try:
        lookup_module_0.run(terms_0)
    except TypeError:
        pass
    variables_0 = {'var': 'value'}
    # Case with args, no kwargs
    try:
        lookup_module_0.run(terms_0, variables_0)
    except TypeError:
        pass
    # Case with kwargs, no args
    try:
        lookup_module_0.run(terms_0, variables_0)
    except TypeError:
        pass

# Generated at 2022-06-25 10:35:06.361433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:35:09.924230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/my/path/*.txt']
    variables = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result is not None

# Generated at 2022-06-25 10:35:13.204222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yaml_result = 'lookup_plugin.run(terms, variables=variables, **kwargs)'
    assert_equal(yaml_result, 'lookup_plugin.run(terms, variables=variables, **kwargs)')

# Generated at 2022-06-25 10:35:16.095351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['/etc/hosts']) == ['/etc/hosts']

# Generated at 2022-06-25 10:35:16.884952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:35:27.111511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = '/home/ansible/playbooks/files/fooapp/foo.conf'
    terms_2 = '/home/ansible/playbooks/files/fooapp/config.conf'

# Generated at 2022-06-25 10:35:34.688255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing LookupModule.run()')
    lookup_module_0 = LookupModule()
    # Testing expected return, no error expected
    expected_return_0 = []
    terms_0 = []
    variables_0 = {}
    actual_return_0 = lookup_module_0.run(terms_0, variables_0)
    assert actual_return_0 == expected_return_0
    pass


# Generated at 2022-06-25 10:35:36.729584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert isinstance(lookup_module.run, object)

# Generated at 2022-06-25 10:35:42.099971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    with open(os.path.join(os.path.dirname(__file__), '../test_data/test_data.json')) as test_data_file:
        test_data = json.load(test_data_file)

    expected_results = [
        'tests/data/playbook/playbook.yml',
        'tests/data/playbook/playbook2.yml',
        'tests/data/playbook/playbook3.yml',
        'tests/data/playbook/playbook4.yml',
        'tests/data/playbook/playbook5.yml'
    ]


# Generated at 2022-06-25 10:35:46.638985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    os_path_join_0 = os.path.join('/my/path/*.txt')
    glob_0 = glob.glob(os_path_join_0)
    isfile_0 = os.path.isfile(glob_0)
    if isfile_0:
        term_results_0 = True
    else:
        term_results_0 = False
    if term_results_0:
        ret_0 = True
    else:
        ret_0 = False
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 is ret_0


# Generated at 2022-06-25 10:35:58.194977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_0 = os.sep
    var_0 = lookup_module_1.run(term_0)
    assert var_0 == []
    term_1 = 'etc'
    var_1 = lookup_module_1.run(term_1)
    assert var_1 == []
    term_2 = 'a'
    var_2 = lookup_module_1.run(term_2)
    assert var_2 == []

if __name__ == '__main__':
    test_run()

# Generated at 2022-06-25 10:35:58.991990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:36:01.404187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)
    print(var_0)
test_LookupModule_run()

# Generated at 2022-06-25 10:36:04.095211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)
    test_case_0()

# Generated at 2022-06-25 10:36:08.877295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing LookupModule.run")
    lookup_module = LookupModule()
    terms = lookup_module.run("/tmp/*.txt")
    assert terms is not None
    assert isinstance(terms, list)
    assert len(terms) == 0


# Generated at 2022-06-25 10:36:11.950978
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    list_0 = [lookup_module, lookup_module]
    var_0 = lookup_run(list_0)

    assert(var_0)

# Generated at 2022-06-25 10:36:16.002990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance_list = [lookup_instance, lookup_instance]
    lookup_instance_terms = lookup_instance.run(lookup_instance_list)
    lookup_instance_terms_list = list(lookup_instance_terms)
    lookup_instance_terms_list.append(lookup_instance)
    len_check_0 = len(lookup_instance_terms_list)
    assert len_check_0 > 0

# Generated at 2022-06-25 10:36:20.686217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "str"
    variables_0 = None
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert True


# Generated at 2022-06-25 10:36:31.020086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)
    for term in terms:
        assert False, "self.find_file_in_search_path(variables, 'files', os.path.dirname(term))) is False: %s" % (term)
        if term_file == term:
            assert False, "self.find_file_in_search_path(variables, 'files', os.path.dirname(term))) is False: %s" % (term)
            break
        if 'ansible_search_path' in variables:
            paths = variables['ansible_search_path']
        else:
            paths = [self.get_basedir(variables)]

# Generated at 2022-06-25 10:36:35.682549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 10:36:45.330562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = to_bytes(b'foo')
    r = to_bytes(b'foo.txt')
    r = to_bytes(b'foo.txt')
    r = to_bytes(b'/tmp/foo.txt')
    r = to_bytes(b'fileglob')
    r = to_bytes(b'fileglob', errors='surrogate_or_strict')
    r = to_bytes(b'fileglob', errors='surrogate_or_strict')
    r = to_bytes(b'/tmp/foo.txt')
    r = to_bytes(b'fileglob')
    r = to_bytes(b'fileglob', errors='surrogate_or_strict')
    r = to_bytes(b'fileglob', errors='surrogate_or_strict')

# Generated at 2022-06-25 10:36:53.149430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test presence of defaults
    lookup_module_0 = LookupModule()
    # Test failure of method run with expected exceptions
    try:
        lookup_module_0.run()
    except TypeError as e:
        if "run() takes at least 2 arguments (1 given)" in str(e):
            pass
    except AnsibleFileNotFound as e:
        if "files/fooapp/*" in str(e):
            pass
    except Exception as e:
        pass


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:37:03.220541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ["']"]
    var_0 = None
    var_1 = lookup_module_0.run(list_0, var_0)
    var_2 = lookup_module_0.run(list_0, var_0)
    var_3 = lookup_module_0.run(list_0, var_0)
    var_4 = lookup_module_0.run(list_0, var_0)
    var_5 = lookup_module_0.run(list_0, var_0)


# Generated at 2022-06-25 10:37:09.181332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = [r"/example/path/*.txt"]
    var_1 = lookup_run(list_1)
    assert var_1 == list_1


# Generated at 2022-06-25 10:37:20.124749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = "/Users/travis/build/ansible/ansible/test/lookup_plugins/fileglob.py"
    var_1 = "/tmp/ansible_fileglob_payload_D9NbIM"
    var_2 = "/tmp/ansible_fileglob_payload_xgZK80"
    lookup_module_0 = LookupModule()
    lookup_module_0.get_basedir = mock_get_basedir()
    lookup_module_0.run(var_0, var_1, var_2)
    try:
        lookup_module_0.run(var_0, var_1, var_2)
        assert False
    except AnsibleFileNotFound:
        assert True



# Generated at 2022-06-25 10:37:26.918470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args_1 = [lookup_module_1]
    var_1 = lookup_run(args_1)
    assert var_1 == "and", "return of run should be 'and'"


# Generated at 2022-06-25 10:37:30.922869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = to_bytes('', errors='strict')
    list_0 = [str_0]
    var_0 = lookup_run(list_0)

    def func_0(arg_0, arg_1=None, arg_2=None):
        return lookup_module_0.run(arg_0, arg_1, arg_2)

    func_1 = func_0(list_0)
    assert func_1 == var_0

# Generated at 2022-06-25 10:37:36.656783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = glob.glob("*.txt")
    var_1 = lookup_module_0.run(var_0)
    var_2 = lookup_module_0.find_file_in_search_path(var_0, "files", os.path.dirname("/my/path/*.txt"))
    var_3 = lookup_module_0.get_basedir(var_0)
    var_4 = glob.glob("*.txt")
    var_5 = lookup_module_0.run(var_4)
    var_6 = lookup_module_0.find_file_in_search_path(var_4, "files", os.path.dirname("/my/path/*.txt"))
    var_7 = lookup_module_0.get_based

# Generated at 2022-06-25 10:37:37.399918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(test_case_0())


# Generated at 2022-06-25 10:37:40.830609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1]
    assert type(lookup_module_1.run(list_1)) == list

# This is just a simulated 'ansible lookup' call

# Generated at 2022-06-25 10:37:52.554804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:38:01.146069
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:38:02.782736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    test_result = lookup_instance.run(["test_input"])
    assert test_result is None

# Generated at 2022-06-25 10:38:07.759278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, './test/test_demo.txt', shell.Shell())
    assert var_0 == ['Hello world!']


# Generated at 2022-06-25 10:38:10.508638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = lookup_module_0.run(['a'])
    assert list_0 == []



# Generated at 2022-06-25 10:38:19.193579
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:38:27.219102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    string_9 = 'ansible_search_path'
    list_1 = [string_9]
    lookup_module.run(list_1, variables={'ansible_search_path':['']})

    string_10 = 'files'
    list_2 = [string_10]
    lookup_module.run(list_2, variables={'files':['']})

if __name__ == '__main__':
    import sys
    import os
    import glob

    file_path = os.path.abspath(__file__)
    sys.path.append(os.path.join(os.path.dirname(file_path), os.path.pardir, 'lib'))

    from ansible.utils.display import Display

# Generated at 2022-06-25 10:38:34.371979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # no dir, just file, so use paths and 'files' paths instead
    if 'ansible_search_path' in variables:
        paths = variables['ansible_search_path']
    else:
        paths = [self.get_basedir(variables)]
    for p in paths:
        found_paths.append(os.path.join(p, 'files'))
        found_paths.append(p)

    for dwimmed_path in found_paths:
        if dwimmed_path:
            globbed = glob.glob(to_bytes(os.path.join(dwimmed_path, term_file), errors='surrogate_or_strict'))

# Generated at 2022-06-25 10:38:37.570228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = dict()
    kwargs_0 = dict()
    lookup_module_0 = LookupModule()
    get_all_0 = list(lookup_module_0)
    return_value_0 = lookup_run(terms_0, variables_0, kwargs_0)
    assert return_value_0 == get_all_0


# Generated at 2022-06-25 10:38:42.442981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo']
    var_1 = lookup_module_0.run(terms_0)



# Generated at 2022-06-25 10:38:52.225868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:38:55.379868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)
    val_0 = [lookup_module_0, lookup_module_0]
    assert val_0 == var_0

# Generated at 2022-06-25 10:39:00.143502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ''
    var_0 = lookup_module_0.run(term_0)
    assert len(var_0) == 0
    term_1 = 'fileglob.txt'
    var_1 = lookup_module_0.run(term_1)
    assert len(var_1) == 0
# // Unit test for method run of class LookupModule


# Generated at 2022-06-25 10:39:08.592066
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Save the console output after running function run
    real_stdout = sys.stdout
    sys.stdout = io.StringIO()
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    lookup_module_0.run(list_0)
    test_stdout = sys.stdout.getvalue()
    sys.stdout = real_stdout

    # Print console output on screen
    print('\n', test_stdout)

    # If you want to check the results update the assert statement accordingly
    assert False



# Generated at 2022-06-25 10:39:13.459911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate a mock AnsibleModule object
    mock_ansible_module = MagicMock(spec=AnsibleModule)
    # Create a mock class object
    mock_ansible_module_class = MagicMock(spec=AnsibleModule)
    # When the mock AnsibleModule object is called (AnsibleModule()), return a mock
    # class object
    mock_ansible_module.return_value = mock_ansible_module_class
    # Instantiate a mock LookupBase object
    mock_lookup_base = MagicMock(spec=LookupBase)
    # Create a mock class object
    mock_lookup_base_class = MagicMock(spec=LookupBase)
    # When the mock LookupBase object is called (LookupBase()), return a mock
    # class object
    mock_lookup

# Generated at 2022-06-25 10:39:20.324969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['test_file_0']
    var_0 = lookup_run(list_0)
    assert var_0 == [], "var_0 returned '%s' instead of ''" %(var_0)



# Generated at 2022-06-25 10:39:25.553516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)
    assert var_0 == '', var_0


# Generated at 2022-06-25 10:39:32.039594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        list_0 = [lookup_module_0, lookup_module_0]
        var_0 = lookup_run(list_0)
        assert var_0 == '', 'variable var_0 is not empty'
    except AnsibleFileNotFound as e:
        var_0 = e
    except AssertionError as e:
        print('AssertionError!', e)


# Generated at 2022-06-25 10:39:36.893101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        terms_0 = lookup_module_0
        list_0 = [lookup_module_0, lookup_module_0]
        var_1 = lookup_run(list_0)
        var_2 = lookup_module_0.run(terms_0)
        assert var_2 == var_1
    except:
        raise Exception('Test for method of class LookupModule failed.')


# Generated at 2022-06-25 10:39:38.295437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('/path/to/file')


# Generated at 2022-06-25 10:39:52.071117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1]
    str_1 = ['lookup_module_1', 'lookup_module_1']
    var_1 = lookup_module_1.run(list_1, 'lookup_run', str_1)

# Generated at 2022-06-25 10:39:53.596866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	lookup_instance = LookupModule()
	list_instance = [lookup_instance, lookup_instance]
	var = lookup_run(list_instance)
	assert var == []


# Generated at 2022-06-25 10:39:54.821073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = [LookupModule(), LookupModule()]
    var_1  = LookupModule.run(list_1)

# Generated at 2022-06-25 10:39:56.045764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = ['test_path']
    lookup_run(lookup_module, list)

# Generated at 2022-06-25 10:39:56.609466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:40:04.174654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # expectation 1
    expectations = []
    file_0 = open("/ansible/files/myfile.txt", "w")
    file_0.close()
    
    file_1 = open("/ansible/files/myfile_3", "w")
    file_1.close()
    
    terms_0 = [u"/ansible/files/myfile.txt", u"/ansible/files/myfile_3"]
    variables_0 = {}
    kwargs_0 = {}
    ret_0 = lookup_module.run(terms_0, variables_0, kwargs_0)
    expectations.append(ret_0)
    # assertion 1
    assert len(ret_0) == 2
    # assertion 2

# Generated at 2022-06-25 10:40:12.415002
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare the parameters as local variables.
    local_terms = None
    local_variables = None
    local_kwargs = None

    # Initialize method data
    local_kwargs = {}

    # Setup mock objects

    class MockLookupBase(object):

        @staticmethod
        def find_file_in_search_path(local_variables, files, dirname):
            return "dirname"

        @staticmethod
        def get_basedir(local_variables):
            return "basedir"

    class MockLookupBase_1(object):

        @staticmethod
        def find_file_in_search_path(local_variables, files, dirname):
            return "dirname"

        @staticmethod
        def get_basedir(local_variables):
            return "basedir"


# Generated at 2022-06-25 10:40:17.437828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.parsing.convert_bool import boolean
    lookup_module_0 = LookupModule()
    terms_0 = [lookup_module_0, lookup_module_0]
    variables_0 = MutableMapping()
    boolean_0 = boolean(0)
    kwargs_0 = {'wantlist': boolean_0}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 == []



# Generated at 2022-06-25 10:40:24.439377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with term_file is equal to term
    # assert that the return is not empty
    LookupModule.run(LookupModule, terms, variables=None, **kwargs)
    assert ret != []
    # Test with file not found
    # assert that the function return AnsibleFileNotFound
    LookupModule.run(LookupModule, terms, variables=None, **kwargs)
    assert AnsibleFileNotFound


# Generated at 2022-06-25 10:40:26.393310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    assert_equal(var_0, [], "")


# Generated at 2022-06-25 10:40:53.198836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Lookup_module_0 = LookupModule(terms_0, variables=None, wantlist=True, text=None)
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)


# Generated at 2022-06-25 10:40:53.582787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass




# Generated at 2022-06-25 10:40:55.978596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.errors import AnsibleFileNotFound
    lookup_module_0 = LookupModule()
    str_0 = 'test_gen.py'
    var_0 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:40:57.456093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run("./fileglob.py", variables=var_0)



# Generated at 2022-06-25 10:40:58.950481
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:41:03.674982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert list(LookupModule().run([""], [], wantlist=True)) == []
    assert list(LookupModule().run([""], [], wantlist=False)) == ""

# Generated at 2022-06-25 10:41:08.321026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = [lookup_module, lookup_module]
    var = lookup_run(list)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:41:15.960334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_case_0 = LookupModule()
    lookup_module_case_1 = LookupModule()
    lookup_module_case_2 = LookupModule()
    lookup_module_case_3 = LookupModule()

    var_case_0 = lookup_module_case_0.run()
    var_case_1 = lookup_module_case_1.run()
    var_case_2 = lookup_module_case_2.run()
    var_case_3 = lookup_module_case_3.run()

# Generated at 2022-06-25 10:41:20.320138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = ['term', 'term1']
    variables = { 'ansible_search_path': ['path1', 'path2']}
    lookup_insert = LookupModule()
    if not os.path.isfile('path1/term'):
        open(path1/term,'w+')
    if not os.path.isfile('path1/term1'):
        open(path1/term,'w+')
    if not os.path.isfile('path2/term'):
        open(path1/term,'w+')
    if not os.path.isfile('path2/term1'):
        open(path1/term,'w+')
    assert lookup_insert.run(term,variables) == ['term', 'term1', 'term', 'term1']

# Generated at 2022-06-25 10:41:23.113438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1]
    var_1 = lookup_run(list_1)
    assert var_1 == 'return_value'

# Generated at 2022-06-25 10:42:15.089383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({"_ansible_check_mode": False, "_ansible_no_log": False, "wantlist": True})
    list_1 = ['myvar']
    var_1 = lookup_vars(list_1)
    var_2 = var_1[0]
    var_3 = lookup_run(list_1)
    assert var_2 == var_3



# Generated at 2022-06-25 10:42:17.750800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    list_2 = [lookup_module_2, lookup_module_2]
    var_1 = lookup_run(list_2)
    if var_1:
        test_case_0()

# Generated at 2022-06-25 10:42:19.854487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0)
    assert var_0 == ['fileglob_test_0.txt']


# Generated at 2022-06-25 10:42:21.309627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [LookupModule(), LookupModule()]
    var_0 = LookupModule.run(LookupModule(), list_0, dict)
    assert var_0 == list_0


# Generated at 2022-06-25 10:42:22.405340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['/my/path/*.txt'], 'variables')

# Generated at 2022-06-25 10:42:26.936997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0()

# Generated at 2022-06-25 10:42:32.194045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution

    # Check that ansible.module_utils.facts.system.distribution.distribution is called with parameters as expected
    with patch.object(Distribution, 'distribution', return_value=None) as mock_distribution:
        distribution_spec_0 = Distribution.distribution(None, None, None, None)
        assert mock_distribution.call_args == call(None, None, None, None)

    # Check that ansible.module_utils.facts.system.distribution.distribution is called with parameters as expected

# Generated at 2022-06-25 10:42:38.047405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


if __name__ == '__main__':
    import pytest
    pytest.main(['test_fileglob.py'])

# Generated at 2022-06-25 10:42:40.048686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test: test_LookupModule_run')
    lookup_module_0 = LookupModule()
    list_0 = ['*']
    lookup_module_0.run(list_0, [])
    return None


# Generated at 2022-06-25 10:42:43.958735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = (str(), str(), str(), str(), str(), str(), str(), str(), str(), str(), str(), str(), str(), str(), str(), str())

    # Syntax error in try-except block.
    # with pytest.raises(AnsibleError) as no_file:
    #    lookup_module_0.run(terms_0)
    # assert str(no_file.value) == "One or more files specified in loop do not exist"

