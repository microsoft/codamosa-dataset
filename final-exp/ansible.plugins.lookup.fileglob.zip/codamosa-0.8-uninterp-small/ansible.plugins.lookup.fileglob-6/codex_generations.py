

# Generated at 2022-06-25 10:32:53.628754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run([])
    assert x == []


# Generated at 2022-06-25 10:32:55.602910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()

# Generated at 2022-06-25 10:32:56.136014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 10:33:03.222389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [ u'foo.txt','/etc/foo.txt' ]
    variables_1 = {}
    kwargs_1 = {}
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == [ u'foo.txt' ]

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:08.244546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['*.txt']
    variables = None
    results = lookup_module_1.run(terms, variables)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 10:33:12.682673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test parameters
    lookup_module = LookupModule()
    terms = ['/test_path/*.txt']
    variables = {'ansible_search_path': '/test_dir'}
    kwargs = {}
    # Expected result
    expected_result = []
    # Run function 'run'
    actual_result = lookup_module.run(terms, variables, **kwargs)
    assert expected_result == actual_result

# Generated at 2022-06-25 10:33:19.096504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    path_0 = '/opt/nokia/nedata/ansible/ansible_source/lib/ansible/plugins/lookup/fileglob*'
    result = lookup_module_0.run(path_0)
    assert result == ['/opt/nokia/nedata/ansible/ansible_source/lib/ansible/plugins/lookup/fileglob.py'], \
        'assertion result has unexpected value'


# Generated at 2022-06-25 10:33:24.283928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/opt/ansible/files/test.txt', '.txt']
    variables = {'ansible_search_path': ['/opt/ansible/files']}
    result = lookup_module.run(terms, variables)
    assert result == ['/opt/ansible/files/test.txt', '/opt/ansible/files/test.txt']

# Generated at 2022-06-25 10:33:27.866564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [{"_terms": ["/my/path/*.txt"]}]
    lookup_module = LookupModule()
    assert len(lookup_module.run(args)) > 0

# Generated at 2022-06-25 10:33:29.583119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[u'*'])

# Generated at 2022-06-25 10:33:33.752613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:33:37.256573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate mock class
    ansible_module_0 = AnsibleModule()
    lookup_module_0 = LookupModule()
    # Calculate and execute function
    ret = lookup_module_0.run(ansible_module_0)
    # Evaluate results
    assert(ret != None)


# Generated at 2022-06-25 10:33:38.744085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:42.713110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    check_result = True
    check_result = check_result and check_answer('test_case_0', 'ansible.builtin.fileglob.run', [], [])
    if check_result:
        case_success_count = case_success_count + 1
    else:
        case_fail_count = case_fail_count + 1


# Generated at 2022-06-25 10:33:44.777219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:33:50.401197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)


# Generated at 2022-06-25 10:33:51.413767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(var_0)


# Generated at 2022-06-25 10:33:52.793165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test if method run of class LookupModule returns expected value.
    """

    lookup_module_2 = LookupModule()

    assert test_case_0()

# Generated at 2022-06-25 10:33:55.045156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module = LookupModule()
    lookup_module.run(int_0)


# Generated at 2022-06-25 10:33:55.895809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:34:04.066702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_file = os.path.basename(term)
    found_paths = []
    if term_file != term:
        found_paths.append(self.find_file_in_search_path(variables, 'files', os.path.dirname(term)))
    else:
        # no dir, just file, so use paths and 'files' paths instead
        if 'ansible_search_path' in variables:
            paths = variables['ansible_search_path']
        else:
            paths = [self.get_basedir(variables)]
        for p in paths:
            found_paths.append(os.path.join(p, 'files'))
            found_paths.append(p)


# Generated at 2022-06-25 10:34:06.444149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    assert ret == ret, "lookup module run test failed"


# Generated at 2022-06-25 10:34:09.475194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests/test_lookup_plugins/test_fileglob.py::test_case_0
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:34:12.431433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    int_1 = None
    lookup_module_2.run(int_1)

# Generated at 2022-06-25 10:34:14.293952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()


# Generated at 2022-06-25 10:34:18.335527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    assert type(lookup_module_0.run()) == list


# Generated at 2022-06-25 10:34:20.938512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 10:34:23.071679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    int_1 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(int_0, None)
    lookup_module_0.run(int_1, None)

# Generated at 2022-06-25 10:34:29.366283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = None
    lookup_module_2 = LookupModule()
    str_1 = 'foo'
    dict_1 = {}
    str_2 = 'foo'
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    int_2 = None
    lookup_module_3 = LookupModule()
    int_3 = None
    var_1 = lookup_run(int_1)
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_

# Generated at 2022-06-25 10:34:32.734813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = None
    lookup_module_2 = LookupModule()
    lookup_module_2.run(int_1)


# Generated at 2022-06-25 10:34:41.108517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    return_value = lookup_module_0.run('term_0', 'variables_0')


# Generated at 2022-06-25 10:34:42.747132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    int_1 = None
    get_module_from_path(int_1)


# Generated at 2022-06-25 10:34:46.295051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:34:53.487339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = None
    kwargs_0 = None
    var_0 = lookup_module_0.run(terms_0, variables_0, kwargs_0)
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms_0, variables_0, kwargs_0)
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run(terms_0, variables_0, kwargs_0)
    lookup_module_3 = LookupModule()
    var_3 = lookup_module_3.run(terms_0, variables_0, kwargs_0)
    lookup_module_4 = Lookup

# Generated at 2022-06-25 10:34:57.437056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = None
    var_0 = lookup_module_0.run(terms_0,variables_0)
    return var_0


# Generated at 2022-06-25 10:35:01.905296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    setattr(lookup_module_0, 'run', lookup_module_1.run)
    var_0 = lookup_run(int_0)
    assert isinstance(var_0, list)


# Generated at 2022-06-25 10:35:03.411080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    lookup_module_1 = LookupModule()



if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:07.438781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)

# Generated at 2022-06-25 10:35:15.983057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run()


# def test_case_1():
#     int_0 = None
#     lookup_module_0 = LookupModule()
#     var_0 = lookup_run(int_0)
#     var_0 = lookup_run(int_0)
#     var_0 = lookup_run(int_0)
#     var_0 = lookup_run(int_0)
#     lookup_module_1 = LookupModule()
#
# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_2 = LookupModule()
#     lookup_module_2.run()

# Generated at 2022-06-25 10:35:19.632786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path_0 = str()
    int_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(path_0, int_0, wantlist=True)


# Generated at 2022-06-25 10:35:38.812858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    int_1 = None
    list_0 = lookup_module_0.run(int_0, int_1)
    assert isinstance(list_0, list)
    assert len(list_0) == 0


# Generated at 2022-06-25 10:35:44.592830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str = test_case_0()
    lookup_module.run(terms=str)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:49.835355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   term = '/book/ansible/files/*.yaml'
   lookup_module = LookupModule()
   var = lookup_module.run(term)
   print(var)

if __name__ == '__main__':
  test_LookupModule_run()

# Generated at 2022-06-25 10:35:54.029938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    test_case_0()



# Generated at 2022-06-25 10:36:03.915421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    dir_0 = tempfile.mkdtemp()
    words_0 = ['foo', 'bar', 'baz']
    with open(os.path.join(dir_0, 'foo'), 'w') as f:
        f.write('foo')
    with open(os.path.join(dir_0, 'bar'), 'w') as f:
        f.write('bar')
    with open(os.path.join(dir_0, 'baz'), 'w') as f:
        f.write('baz')
    os.makedirs(os.path.join(dir_0, 'subdir'))
    with open(os.path.join(dir_0, 'subdir', 'foo'), 'w') as f:
        f.write('foo')
    lookup_module_0 = Look

# Generated at 2022-06-25 10:36:14.308326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 'foo/bar'
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_1 = dict(int_1=int_0)
    dict_2 = dict()
    int_1 = 'baz'
    str_0 = 'path'
    dict_3 = dict(int_3=int_1, str_1=str_0)
    dict_4 = dict()
    int_2 = 9
    dict_5 = dict(int_4=int_2)
    dict_6 = dict(dict_4=dict_5)
    dict_7 = dict(dict_2=dict_3, dict_3=dict_4, dict_4=dict_6)

# Generated at 2022-06-25 10:36:23.057397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    # test if a files list contains file "foo"
    assert variable_0 in lookup_module_0.run(["*.txt"])
    # test if a files list contains file "foo"
    assert variable_1 in lookup_module_0.run(["/my/path/*.txt"])
    # test if a files list contains file "foo"
    assert variable_2 in lookup_module_0.run(["/playbooks/files/fooapp/*"])


# Generated at 2022-06-25 10:36:25.494755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    all_hosts = []
    lookup_module_0.run(all_hosts)

# Generated at 2022-06-25 10:36:30.022046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    return var_0


# Generated at 2022-06-25 10:36:37.072845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['ansible-playbook', 'ansible-playbook.cmd', 'ansible-playbook.py', 'ansible-pull', 'ansible-pull.cmd', 'ansible-pull.py', 'ansible-doc', 'ansible-doc.cmd', 'ansible-doc.py', 'ansible', 'ansible.cmd', 'ansible.py', 'ansible-vault', 'ansible-vault.cmd', 'ansible-vault.py'])
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:37:02.232141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(['.bashrc']) == []

# Generated at 2022-06-25 10:37:06.368661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('********* Unit test for method run of class LookupModule')
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['/playbooks/files/fooapp/*'])
    print("execute result:", var_0)
    assert '/playbooks/files/fooapp/fooapp.conf' in var_0
    assert '/playbooks/files/fooapp/barapp.conf' in var_0
    assert len(var_0) == 2


# Generated at 2022-06-25 10:37:07.022487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 10:37:08.948393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)
    assert lookup_module_0.run(int_0) == var_0


# Generated at 2022-06-25 10:37:10.976765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = None
    variables_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(term_0, variables_0)
    test_0 = var_0

    return

# Generated at 2022-06-25 10:37:13.388322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No docstring
    pass


# Generated at 2022-06-25 10:37:20.793618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:37:26.604940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('test_LookupModule_run')
    lookup_module_0 = LookupModule()  # This object should be valid immediately after creation
    # assert(True)
    return


# Generated at 2022-06-25 10:37:28.769425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    var_0 = None
    lookup_module_2 = LookupModule()
    var_1 = lookup_module_2.run(int_0, var_0)


# Generated at 2022-06-25 10:37:33.869087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = None
    var_0 = lookup_run(int_0)
    assert len(var_0) == 0, 'length of var_0 did not equal 0'


# Generated at 2022-06-25 10:38:12.814283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = glob.glob(to_bytes('/etc/ansible/files/test_file_0.txt', errors='surrogate_or_strict'))
    int_1 = None
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(int_1)
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 10:38:16.040112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_0.run(None, None)


# Generated at 2022-06-25 10:38:19.282768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

# Generated at 2022-06-25 10:38:23.746912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_args = None
    var_kwargs = None
    lookup_module_0 = LookupModule()
    var_terms = None
    var_variables_0 = None
    var_0 = lookup_module_0.run(var_terms, var_variables_0, var_args, var_kwargs)


# Generated at 2022-06-25 10:38:25.501464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_1 = LookupModule()
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(int_0)

# Generated at 2022-06-25 10:38:29.078030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    ret = lookup_module_0.run(None)

    assert ret == []

# Generated at 2022-06-25 10:38:33.068989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(Exception):
        assert False


# Generated at 2022-06-25 10:38:36.637271
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # template path
    global var_0

    # String list of paths joined by commas, or an empty list if no files match. For a 'true list' pass wantlist=True to the lookup.
    global return_0

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables=None, **kwargs)
    assert var_0 == return_0


# Generated at 2022-06-25 10:38:42.058161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = os.path.basename()
    terms = []
    terms.append(term)
    glob.glob(os.path.join(found_path, term_file))
    return ret


# Generated at 2022-06-25 10:38:49.064977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    terms_0 = list()
    with strict_warning():
        lookup_module_0.run(terms_0)
        ansible_module_0 = AnsibleModule(variable_manager=lookup_module_0)
        var_0 = ansible_module_0.params
        var_1 = lookup_module_0.get_basedir(var_0)
        var_2 = lookup_module_0.find_file_in_search_path(var_0, 'files', '/root/test')
        lookup_module_1 = LookupBase()
        var_3 = lookup_module_1.run(terms_0)
        var_4 = lookup_module_1.get_basedir(var_0)
        var_5 = lookup_module_1.find_file_in_

# Generated at 2022-06-25 10:39:59.711664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:40:03.508307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None

    # lookup_module_0 is a LookupModule object
    lookup_module_0 = LookupModule()

    # Calls function run of class LookupModule with int_0 as parameter
    lookup_run(int_0)

# Usage of method run in a class

# Generated at 2022-06-25 10:40:11.031262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test
    int_string = 'foo'
    dict_variables = {'ansible_search_path': 'foo'}
    lookup_module = LookupModule()
    path_basedir = '/tmp/test_LookupModule/ ansible '

    # Run test
    var_test = lookup_module.run(int_string, dict_variables=dict_variables, wantlist=True, basedir=path_basedir)

    # Check Results
    if var_test:
        raise ValueError


if __name__ == "__main__":
    if test_case_0():
        pass

# Generated at 2022-06-25 10:40:13.849946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_0 = LookupModule()
    int_0 = None
    int_1 = None
    var_0 = class_0.run(int_0, int_1)
    print("OK")


# Generated at 2022-06-25 10:40:18.166756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(int_0)

# Test to check if instances of the class are equal

# Generated at 2022-06-25 10:40:21.311694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    str_0 = None
    var_0 = lookup_module_0.run(int_0, str_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:40:29.137296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look_0 = LookupModule()
    look_0 = LookupModule()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()

    look_0.run(dict_0)


# Generated at 2022-06-25 10:40:31.821758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = '../lib/ansible/utils/unsafe_proxy.pyc'
    variables_0 = dict()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(term_0, variables=variables_0)
    assert_equal(str(var_0), "[]")


# Generated at 2022-06-25 10:40:33.094581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run: args list
    # LookupModule.run: args dict

    pass


# Generated at 2022-06-25 10:40:36.105983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)