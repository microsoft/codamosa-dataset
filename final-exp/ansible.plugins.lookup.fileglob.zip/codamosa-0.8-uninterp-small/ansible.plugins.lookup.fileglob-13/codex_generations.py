

# Generated at 2022-06-25 10:32:52.581407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'q5]!^nj?+A@~f\nt<U_='
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 10:32:56.945470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test fixture for the method run of class LookupModule.
    """
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0.run([])
    lookup_module_1.run([])


# Generated at 2022-06-25 10:33:05.272368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'zLf,&CqrGdNM]wY|'
    str_1 = 'E>g7R?_Z.uV0{%t;'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_2 = ";x>E_P=a"
    str_3 = "nD:a"
    assert lookup_module_1.run((str_0 + str_1, str_2 + str_3)) == [(str_0 + str_1, ';x>E_P=a', 'nD:a')]
    str_4 = "G[sF"
    str_5 = "0+x"

# Generated at 2022-06-25 10:33:10.389880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    # Test with valid inputs
    result = lookup_module_0.run('we*')
    assert result == []

    # Test with invalid inputs
    # AssertionError
    try:
        lookup_module_1.run('t*')
    except AssertionError:
        pass

# Generated at 2022-06-25 10:33:11.544859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-25 10:33:21.768963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "WL-dR$ZM-,P&o88q3o0h"
    str_1 = '~#U?=;/5$5w'
    terms_0 = [str_0, str_1, str_1]
    lookup_module_0.run(terms_0)
    str_2 = "A2t)^m'F<@K/"
    str_3 = "5w?=;/5$~#U"
    terms_1 = [str_2, str_3]
    lookup_module_0.run(terms_1)
    lookup_module_1 = LookupModule()
    str_4 = 'k-8\rNFHs'

# Generated at 2022-06-25 10:33:24.215773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert not LookupModule.run(LookupModule(), ['path/to/file'], variables={})

# Generated at 2022-06-25 10:33:27.030657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test template with a standalone Python script
    str_0 = 'kv%~n;&)|N]|8Ew'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:33:31.131912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'g@{6Ui?6UdS6U\ndS'
    lookup_module_0 = LookupModule()
    str_1 = 'w{8[r.r5@r'
    lookup_module_1 = LookupModule()
    lookup_module_1.run([str_1])



# Generated at 2022-06-25 10:33:41.048170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # term_file set to 'foo.txt'
    # term_file set to 'foo.txt'
    lookup_module_0 = LookupModule()
    terms_0 = ['foo.txt']
    variables_0 = dict()
    variables_0['home'] = LookupModule()
    variables_0['home'].find_file_in_search_path(variables_0, 'files', 'foo/path')
    variables_0['home'].find_file_in_search_path('foo/path', 'files', variables_0)
    variables_0['home'].find_file_in_search_path('foo/path', variables_0)
    variables_0['home'].run('foo.txt', {})
    variables_0['ansible_search_path'] = 'foo/path'
    variables_0

# Generated at 2022-06-25 10:33:46.690137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.run(set_0)
    lookup_module_0.run(set_0)


# Generated at 2022-06-25 10:33:48.294222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set(['*'])
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)
    assert var_0 == None


# Generated at 2022-06-25 10:33:55.781098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    term_0 = "nqrqrjmvmyy"
    lookup_module_1.run(term_0, variables=None, **kwargs)
    term_0 = "nqrqrjmvmyy"
    lookup_module_0.run(term_0, variables=None, **kwargs)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:56.582459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:33:58.241522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_1 = set()
    var_1 = lookup_run(set_1)


# Generated at 2022-06-25 10:34:04.214295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["/home/michael/im_a_file.txt"]
    var_1 = None
    var_2 = lookup_module_1.run(terms_1, variables=var_1)
    assert var_2 == ["/home/michael/im_a_file.txt"], "return value from LookupModule.run() does not match expected value"


# Static test for method run

# Generated at 2022-06-25 10:34:08.284733
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    set_0 = set( [ 'var_0' ] )
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    assert set_0 == var_0

# Generated at 2022-06-25 10:34:13.163561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    new_class_var_0 = LookupModule()
    func_ret_var_0 = new_class_var_0.run('mydir**')
    assert(func_ret_var_0 == None)


# Generated at 2022-06-25 10:34:18.643452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        set_0 = set()
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.run(set_0)
    except AnsibleError:
        var_0 = None
    assert var_0 != None


# Generated at 2022-06-25 10:34:27.531313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    assertion_0 = LookupBase()
    var_0 = assertion_0.run()
    var_1 = assertion_0.run()
    var_2 = assertion_0.run()
    var_3 = assertion_0.run()
    var_4 = assertion_0.run()
    var_5 = assertion_0.run()
    var_6 = assertion_0.run()

# Generated at 2022-06-25 10:34:34.755833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible/test/test_playbooks/files/fooapp/*']
    var_0 = lookup_run(terms_0)
    check_0 = True
    for check in var_0:
        check_0 &= check.startswith('ansible/test/test_playbooks/files/fooapp/')
    assert check_0

# Generated at 2022-06-25 10:34:36.397940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(set_0)
    for var_2 in var_1:
        print(var_2)
    print(var_1)


# Generated at 2022-06-25 10:34:43.349380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = lookup_run(['*lang'])
    var_2 = lookup_run(['demo', 'demo.txt'])
    var_3 = lookup_run(['demo.txt'])
    var_4 = lookup_run(['*txt'])
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 10:34:51.695388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, set_0)
    # assertEquals(var_0, [])
    ret = []
    print(var_0)
    print(ret)
    assert var_0 == ret
    # Case 1
    set_1 = set()
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, set_1)
    # assertEquals(var_1, [])
    ret = []
    print(var_1)
    print(ret)
    assert var_1 == ret


# Generated at 2022-06-25 10:34:55.957037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['Lookup Module unit tests']
    variables_0 = {'ansible_playbook_python': '/usr/bin/python'}
    kwargs_0 = {'wantlist': False}
    lookup_module_0 = LookupModule()
    term_0 = lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0)
    term_0_result = check_equal_type(term_0, list)
    assert term_0_result == True


# Generated at 2022-06-25 10:35:01.066052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = set()
    var_0 = variables()
    set_0 = lookup_module_0.run(terms_0, var_0)
    assert set_0 == set()
    terms_1 = set()
    var_1 = variables()
    set_1 = lookup_module_0.run(terms_1, var_1)
    assert set_1 == set()


# Generated at 2022-06-25 10:35:05.523736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = [b'*']
    variables_0 = {b'ansible_search_path': [b'', b'./0']}
    lookup_module_1.run(terms_0, variables_0)
    assert True


# Generated at 2022-06-25 10:35:12.315420
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test set up
    var_1 = '/tmp'
    lookup_module_1 = LookupModule()
    var_2 = os.path.abspath(os.path.expanduser('~/.ansible/tmp'))

    # Test method run
    try:
        lookup_module_1.run(var_1, dict(ansible_user_dir=var_2))
    except Exception as e:
        raise Exception('Unexpected exception raised: %s' % e)

# Generated at 2022-06-25 10:35:13.801889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert var_0 == {}
    assert lookup_module_0.run(terms, variables) == {}

# Generated at 2022-06-25 10:35:18.848377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = None
    var_0 = lookup_module_0.run(terms_0, variables_0)
    var_1 = unset()
    var_0 = var_1



# Generated at 2022-06-25 10:35:25.803536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    var_0 = lookup_run(set_0)
    assert var_0 == 'ansible.builtin.fileglob'


# Generated at 2022-06-25 10:35:28.691013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    if lookup_module_0.run(set_0) != None:
        raise Exception("LookupModule.run failed")
    # TODO add more tests

# Generated at 2022-06-25 10:35:31.496611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    var_0 = lookup_run(set_0)
    test_case_0()


# Loads a variable

# Generated at 2022-06-25 10:35:36.643064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    lookup_module_0.run(set_0)

# Generated at 2022-06-25 10:35:40.174607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = set_0
    variables_0 = set_0
    kwargs_0 = {'variable': False}
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    data_0 = [{'variable': None}, None]
    assert var_0 == data_0

# Generated at 2022-06-25 10:35:47.332719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = set_0
    variables_0 = None
    lookups_0 = dict()
    var_0 = lookup_module_0.run(terms_0, variables_0, **lookups_0)
    if var_0:
        print('var_0 = %s' % var_0)
    else:
        print('var_0 = None')



# Generated at 2022-06-25 10:35:49.792964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    lookup_run(set_0, lookup_module_0)


# Generated at 2022-06-25 10:35:58.838230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    var_1 = lookup_run(set_0, terms='/tmp/test.conf')
    var_2 = lookup_run(set_0, terms='test.conf')
    var_3 = lookup_run(set_0, terms='test.conf', basedir='/tmp')
    var_4 = lookup_run(set_0, terms='test.conf', ansible_search_path='/tmp')
    assert var_0 == var_1 == var_2 == var_3 == var_4

# Generated at 2022-06-25 10:36:06.107267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    var_0 = lookup_run(set_0)
    def assert_equal(a, b):
        if a != b:
            raise AssertionError("%s != %s" % (a, b))

    assert_equal(set_0, var_0)


# Generated at 2022-06-25 10:36:08.607511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = None
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 10:36:23.136846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = "_terms"
    variables_1 = None
    ret_1 = lookup_module_1.run(term_1, variables_1)
    lookup_module_2 = LookupModule()
    term_2 = "_terms"
    variables_2 = None
    ret_2 = lookup_module_2.run(term_2, variables_2)
    lookup_module_3 = LookupModule()
    term_3 = "_terms"
    variables_3 = None
    kwargs_3 = {}
    kwargs_3["wantlist"] = "True"
    ret_3 = lookup_module_3.run(term_3, variables_3, **kwargs_3)
    lookup_module_4 = LookupModule()

# Generated at 2022-06-25 10:36:25.617927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:36:30.213782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    term_0 = lookup_module_obj.run(terms=term_0)
    assert(term_0 == term_0)

# Generated at 2022-06-25 10:36:32.230774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = {'wantlist': 'True'}
    self_0 = LookupModule()
    var_String_0 = lookup_run(args_0)

# Generated at 2022-06-25 10:36:38.778513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = set()
    variables = set()
    ret_0 = lookup_module_0.run(terms, variables)
    assert ret_0 == ['C:\\Users\\Sofia\\.ansible\\tmp\\ansible-tmp-1562507935.02-21144462502321\\fileglob.txt']


# Generated at 2022-06-25 10:36:40.843794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert '_list' in test_case_0
    assert len(test_case_0['_list']) == 2
    assert 'file:/etc/passwd' in test_case_0['_list']
    assert 'file:/etc/group' in test_case_0['_list']


# Generated at 2022-06-25 10:36:45.515052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    elements_0 = set()
    var_0 = lookup_run(elements_0)
    elements_1 = {}
    var_1 = lookup_run(elements_1)
    elements_2 = {'ansible_search_path': './'}
    var_2 = lookup_run(elements_2)
    elements_3 = {'ansible_search_path': './', 'files': './'}
    var_3 = lookup_run(elements_3)
    elements_4 = {'ansible_search_path': './', 'files': './'}
    var_4 = lookup_run(elements_4)
    elements_5 = {'ansible_search_path': './', 'files': './'}
    var_5 = lookup_run(elements_5)


# Generated at 2022-06-25 10:36:47.834885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Iterating
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:36:48.996307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert isinstance(module, object)



# Generated at 2022-06-25 10:36:56.481230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = '*'
    variables_0 = dict(path='/etc/passwd')
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(term_0, variables_0)) == 1
    assert len(lookup_module_0.run(term_0, variables_0)) == 1
    assert len(lookup_module_0.run(term_0, variables_0)) == 1
    assert len(lookup_module_0.run(term_0, variables_0)) == 1
    assert len(lookup_module_0.run(term_0, variables_0)) == 1
    assert len(lookup_module_0.run(term_0, variables_0)) == 1

# Generated at 2022-06-25 10:37:09.930950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	# set up
	set_0 = set()
	lookup_module_0 = LookupModule()
	var_0 = lookup_run(set_0)

	# test
	print(var_0)


# Generated at 2022-06-25 10:37:15.063776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [0]
    variables = {
        'ansible_search_path': ['test']
    }
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(terms[0], variables)
    assert var_0 == []



# Generated at 2022-06-25 10:37:19.050876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(set_1)
    assert var_1 == lookup_module_1.run(set_1)


# Generated at 2022-06-25 10:37:23.754823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    lookup_module_1 = LookupModule()
    lookup_module_1.find_file_in_search_path(set_1, 'ansible_search_path', '1')
    var_1 = lookup_run(set_1)
    assert var_1 == 'None'


# Generated at 2022-06-25 10:37:27.163111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   var_0 = 'test'
   assert lookup_module_0.run(var_0) == 'test'

# Generated at 2022-06-25 10:37:28.968581
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert(var_0 == "C:\ProgramData\Ansible\\files\cifs-utils_6.5-1ubuntu1.1_all.deb")

# Generated at 2022-06-25 10:37:33.869964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()


# Generated at 2022-06-25 10:37:42.357719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_args_0 = [0, 1, 2]
    test_kwargs_0 = {'foo':'bar'}
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(test_args_0, test_kwargs_0)
    ret_1 = lookup_module_0.run(test_args_0, test_kwargs_0)
    assert ret_0 is not ret_1, "test 1"
    assert ret_0 == ret_1, "test 2"

# Generated at 2022-06-25 10:37:45.112627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.run(["/a","/b/c","/c/d/e"], wantlist=True)

# Generated at 2022-06-25 10:37:46.437182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod_obj_0 = LookupModule()
    var_0 = mod_obj_0.run()
    assert var_0


# Generated at 2022-06-25 10:38:02.029369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ''
    variables = ''
    kwargs = ''

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables, kwargs) == []

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms, variables, kwargs) == []

    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(terms, variables, kwargs) == []

    lookup_module_3 = LookupModule()
    assert lookup_module_3.run(terms, variables, kwargs) == []

    lookup_module_4 = LookupModule()
    assert lookup_module_4.run(terms, variables, kwargs) == []

# Generated at 2022-06-25 10:38:08.368787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    var_1 = lookup_run(var_0)
    assert var_1 == '', 'The returned value should be \'\''
    var_2 = set()
    var_3 = lookup_run(var_2)
    assert var_3 == '', 'The returned value should be \'\''
    var_4 = set()
    var_5 = lookup_run(var_4)
    assert var_5 == '', 'The returned value should be \'\''
    var_6 = set()
    var_7 = lookup_run(var_6)
    assert var_7 == '', 'The returned value should be \'\''
    var_8 = set()
    var_9 = lookup_run(var_8)
    assert var_9

# Generated at 2022-06-25 10:38:16.986028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    root_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    lookup_module_0 = LookupModule()

    # Test template: lookup_module_X.run('[value_1]', lookup_run('[value_2]', lookup_opts('[value_3]')))
    directory_1 = [os.path.join(root_dir, 'docs/examples/files')]
    set_1 = set()
    var_2 = lookup_run(set_1)
    set_2 = set()
    var_3 = lookup_opts(set_2)
    template_0 = lookup_module_0.run('[value_1]', lookup_run('[value_2]', lookup_opts('[value_3]')))
    template_

# Generated at 2022-06-25 10:38:19.865985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 10:38:26.082372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = {'ansible_search_path': None, 'is_run_on_posix': None, 'is_run_on_windows': None}
    # State assertion before the call to run
    called_0 = False
    try:
        lookup_module_0.run(terms_0,variables_0)
        called_0 = True
    except AnsibleFileNotFound as e:
        # Should not throw an error
        pass
    finally:
        assert called_0


# Generated at 2022-06-25 10:38:30.346423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module_path = os.path.join(os.path.dirname(__file__), 'test_module_0')
    lookup_module_0 = LookupModule()
    var_0 = ['test_file_0', 'test_file_1', 'test_file_2', 'test_file_3']
    var_1 = lookup_module_0.run(var_0, dict(ansible_search_path=test_module_path))
    assert var_1 == ['test_file_0', 'test_file_1', 'test_file_2', 'test_file_3']

# Generated at 2022-06-25 10:38:31.939342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)



if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-25 10:38:33.726002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_run_0 = lookup_module_0.run(terms_0,variables_0,**kwargs_0)


# Generated at 2022-06-25 10:38:34.429531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 10:38:38.482021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['']
    variables = {}
    lookup_module_run = LookupModule().run(terms, variables)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:38:57.337746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)

# Generated at 2022-06-25 10:39:00.513504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    var_0 = set_0.add(var_0)
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(var_0, var_0)

    assert var_0 == var_0

# Generated at 2022-06-25 10:39:08.885091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = [0]
    var_2[0] = 'test.txt'
    set_0 = set()
    var_0 = LookupModule()
    var_1 = 'files/test.txt'
    var_0.get_basedir = staticmethod(lambda x:x)
    var_0.find_file_in_search_path = staticmethod(lambda x,y,z:z)
    assert var_0.run(var_2,var_1) == set_0
    assert var_0.run(var_2, var_1)

if __name__ == '__main__':
    import pytest
    pytest.main(None)

# Generated at 2022-06-25 10:39:10.963610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("testing run of class LookupModule")
    instance_0 = LookupModule()
    var_0 = instance_0.run("*.txt")
    print("type: " + str(type(var_0)))
    for var_1 in var_0:
        print(var_1)



# Generated at 2022-06-25 10:39:17.643684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    set_0 = dict()
    set_0['hostvars'] = dict()
    host_0 = Host(name='hostname_0')
    set_0['hostvars']['hostname_0'] = host_0
    host_1 = Host(name='hostname_1')
    set_0['hostvars']['hostname_1'] = host_1
    host_2 = Host(name='hostname_2')
    set_0['hostvars']['hostname_2'] = host_2

# Generated at 2022-06-25 10:39:18.954844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:39:26.590166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = set_0
    variables_0 = set_0
    kwargs_0 = set_0
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert var_0 is None

# Generated at 2022-06-25 10:39:27.748081
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True



# Generated at 2022-06-25 10:39:30.622909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule('ansible_basedir')
    terms_0 = [('ansible_playbook_python')]
    var_0 = lookup_module_1.run(terms_0)
    assert var_0 == None


# unit test for method __init__ of class LookupModule

# Generated at 2022-06-25 10:39:34.169963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['']
    set_0 = set()
    lookup_module_0 = LookupModule()

    # Testing if exception is raised
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_0.run(terms_0, )


# Generated at 2022-06-25 10:40:14.862270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0)

# Generated at 2022-06-25 10:40:19.627058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:40:25.239516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    set_1 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    assert set_0 == var_0, '''AnsibleFileNotFound' raised instead of 'AssertionError' when executing the function lookup_module_run of the class LookupModule with arguments: set([]), set([]), '''
    var_1 = lookup_run(set_1)
    assert set_1 == var_1, '''AnsibleFileNotFound' raised instead of 'AssertionError' when executing the function lookup_module_run of the class LookupModule with arguments: set([]), set([]), '''


# Generated at 2022-06-25 10:40:29.850163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test values
    test_set_0 = set()
    test_var_0 = lookup_run(test_set_0)


# Generated at 2022-06-25 10:40:31.099946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)

# Generated at 2022-06-25 10:40:35.550421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    import string
    random_value = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
    dict_0 = {}
    dict_0[random_value] = random_value
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables=dict_0)

# Generated at 2022-06-25 10:40:43.326567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 10:40:49.858949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()
    lookup_module_16 = LookupModule()

# Generated at 2022-06-25 10:40:50.811465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    var_0 = lookup_run(set_0)

# Generated at 2022-06-25 10:40:54.243375
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test method run
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []

# Generated at 2022-06-25 10:42:16.421713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 10:42:22.077906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with args that match expected type
    ret_1 = LookupModule.run([' '])

    # Test with arg that doesn't match expected type
    ret_2 = LookupModule.run([' '])

# Generated at 2022-06-25 10:42:31.839836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_20 = lookup_module_0.run([set()], None)
    var_21 = set()
    var_21.update(var_20)
    assert (var_21 == set())
    var_22 = set()
    var_22.update(var_20)
    var_23 = set()
    var_23.add('/root/.ansible/tmp/ansible-tmp-1497998535.97-239599293584338/test_fileglob')
    var_22.update(var_23)
    var_20 = lookup_module_0.run([set()], var_22)
    var_24 = set()
    var_24.update(var_20)
    var_25 = set()
    var_25.add

# Generated at 2022-06-25 10:42:38.461779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests
    set_2 = set()
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(set_2)


# run test cases
if __name__ == '__main__':

    test_LookupModule_run()

# Generated at 2022-06-25 10:42:40.191910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    terms_0 = set_0
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0)



# Generated at 2022-06-25 10:42:44.473700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = {
        'variables': {
            'ansible_search_path': [
                'playbooks',
                'playbooks/roles'
            ]
        },
        'dirs': [
            'playbooks/roles',
            'playbooks'
        ]
    }

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[
        '*'
    ], variables=set_0["variables"], dirs=set_0["dirs"])
    assert "" == var_0

