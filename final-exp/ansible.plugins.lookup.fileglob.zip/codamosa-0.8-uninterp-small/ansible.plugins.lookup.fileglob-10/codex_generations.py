

# Generated at 2022-06-25 10:32:51.167930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[''])


# Generated at 2022-06-25 10:33:02.372058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ''
    variables_1 = ''
    kwargs_1 = tuple()
    kwargs_1 = dict()
    kwargs_1['wantlist'] = 1
    #kwargs_1 = {'wantlist': 1}
    ret_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)

    lookup_module_2 = LookupModule()
    terms_2 = ''
    variables_2 = ''
    kwargs_2 = tuple()
    kwargs_2 = dict()
    kwargs_2['wantlist'] = 1
    #kwargs_2 = {'wantlist': 1}

# Generated at 2022-06-25 10:33:08.166241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)

    try:
        lookup_module_0.run("")
    except NotImplementedError:
        pass

# Generated at 2022-06-25 10:33:15.163341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/test_dir/test_file_1.txt', '/test_dir/test_file_2.txt', '/test_dir/test_file_3.txt']
    variables_1 = {}
    kwargs_1 = {}
    expected_result_1 = ['/test_dir/test_file_1.txt', '/test_dir/test_file_2.txt', '/test_dir/test_file_3.txt']
    # run
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    # Assertion Error if not equal
    assert result_1 == expected_result_1



# Generated at 2022-06-25 10:33:24.781785
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # basics
    assert lookup_module_0.run(["../files/*"]) == []
    assert lookup_module_0.run(["files/*"]) == []
    assert lookup_module_0.run(["files/*"])[0].endswith("files/ansible.cfg")
    assert lookup_module_0.run(["files/ansible.cfg"])[0].endswith("files/ansible.cfg")
    assert lookup_module_0.run(["files/z*"]) == []

    # test multiple values
    results = lookup_module_0.run(["files/z*", "files/ansible.cfg"])
    assert len(results) == 1
    assert results[0].endswith("files/ansible.cfg")

    # test want

# Generated at 2022-06-25 10:33:31.921196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/tmp/foo.py']
    variables = {}
    kwargs = {'wantlist': True}
    assert_exception(AnsibleFileNotFound, lookup_module_0.run, terms, variables=variables, **kwargs)

    kwargs = {'wantlist': True}
    assert_equal(lookup_module_0.run(terms, variables=variables, **kwargs), [])
    kwargs = {'wantlist': True}
    assert_equal(lookup_module_0.run(terms, variables=variables, **kwargs), [])



# Generated at 2022-06-25 10:33:35.954346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['/etc/ansible/ansible.cfg']) == [to_text(os.path.join(os.getcwd(), 'files/ansible.cfg'), errors='surrogate_or_strict')], "Code did not return a recognized value."

# Generated at 2022-06-25 10:33:38.421146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(['/my/path/*.txt'],
                            variables=None,
                            wantlist=True)

    assert ret is not None

# Generated at 2022-06-25 10:33:41.495484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "*.yml"
    term_1 = "*.*"
    ret = lookup_module_0.run(terms=[term_0, term_1])
    assert ret == ["playbook.yml"]

# Generated at 2022-06-25 10:33:43.202817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(["test_term"]) == []


# Generated at 2022-06-25 10:33:54.140792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	
	#Initializing first argument
	terms = ["*.txt"]

	#Initializing second argument
	variables = {'ansible_search_path' : ['/my/path']}

	#Initializing specified class object
	lookup_module = LookupModule()

	#Calling the actual method from class object with above specified arguments
	result = lookup_module.run(terms, variables)
	ret = []
	#Comparing actual result with expected result
	assert result == ret, 'Test Failed : Actual result does not match expected result'
	print('Test Passed : Actual result matches expected result')

# Generated at 2022-06-25 10:33:56.452945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._load_name_to_path_cache = lambda a: None
    try:
        assert lookup_module_0.run(terms=terms_dict_0)
    except Exception as exception:
        print(exception)
        assert False



# Generated at 2022-06-25 10:34:04.623685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {'ansible_search_path': ['/home/foo/bar', '/home/foo/baz', '/home/foo/fooapp/modules']}
    kwargs = {}
    kwargs['wantlist'] = True
    ret = lookup_module_0.run(terms, variables, **kwargs)
    assert 'foo' == ret[0]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:14.339594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # case 0: no pattern
    lookup_module_0 = LookupModule()
    found_files = lookup_module_0.run(terms=['files/', 'files/test.txt'], variables={
        'ansible_search_path': ['/path/to/files/'], # for first term
        'ansible_files_dir': '/path/to/files/' # for second term
    })
    assert len(found_files) == 2
    assert found_files[0] == '/path/to/files/files/'
    assert found_files[1] == '/path/to/files/files/test.txt'
    found_files = lookup_module_0.run(terms=['files/test.txt'], variables={
        'ansible_files_dir': '/path/to/files'
    })


# Generated at 2022-06-25 10:34:21.210095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = '/etc/*.yml'
    variables = {'ansible_search_path': ['/etc/', '/etc/ansible'], 'files': '/etc/ansible'}
    lookup_module = LookupModule()
    assert lookup_module.run(term, variables) == ['/etc/hosts.yml']

# Generated at 2022-06-25 10:34:22.109505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()



# Generated at 2022-06-25 10:34:32.245152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['README.md']
    terms_1 = ['README.md']
    terms_2 = ['README.md']
    terms_3 = ['README.md']
    terms_4 = ['README.md']
    variables_0 = {}
    variables_1 = {'ansible_search_path': ['/tmp/ansible/test/ansible_search_path.txt']}
    variables_2 = {'ansible_search_path': ['/tmp/ansible/test/ansible_search_path.txt']}
    variables_3 = {'ansible_search_path': ['/tmp/ansible/test/ansible_search_path.txt']}

# Generated at 2022-06-25 10:34:35.663000
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_obj = LookupModule()
    assert lookup_module_obj.run(terms=["/home/ubuntu/sample.txt"],variables=None) == ['/home/ubuntu/sample.txt']

# Generated at 2022-06-25 10:34:39.398078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()

    # Test case 0
    module_0.run([])


# noinspection PyUnusedLocal

# Generated at 2022-06-25 10:34:45.150665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['*.py'], {'ansible_fileglob_directories': []})
    lookup_module_0.run(['*.py'], {'ansible_fileglob_directories': ['/var/tmp']})
    lookup_module_0.run(['*.py'], {'ansible_fileglob_directories': ['/var/tmp'], 'ansible_fileglob_base_dir': ['.']})

# Generated at 2022-06-25 10:34:53.932239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variable_0 = {}
    variable_0['ansible_search_path'] = ['/etc/ansible']
    variable_0['vault_password_file'] = 'ansible-vault-passwd.txt'
    variable_0['_ansible_no_log'] = False
    variable_0['ansible_inventory_cache'] = None
    variable_0['ansible_module_generated'] = False
    variable_0['ansible_verbosity'] = True
    variable_0['ansible_socket'] = None
    variable_0['ansible_forks'] = None
    variable_0['_ansible_syslog_facility'] = 'LOG_USER'
    variable_0['ansible_ssh_private_key_file'] = None

# Generated at 2022-06-25 10:35:04.637880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Looking for a file that does not exists in ansible search path
    lookup_instance = LookupModule()
    variables = dict(ansible_search_path=['/this/path/doesnot/exists/'])
    terms = ['/this/path/doesnot/exists/tests']
    lookup_instance.run(terms=terms, variables=variables)

    # The file exists in the search path
    lookup_instance = LookupModule()
    variables = dict(ansible_search_path=['/this/path/doesnot/exists/'])
    terms = ['/this/path/doesnot/exists/']
    lookup_instance.run(terms=terms, variables=variables)

    # The file exists in the search path
    lookup_instance = LookupModule()

# Generated at 2022-06-25 10:35:09.798929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'ansible.cfg']
    kwargs_0 = {u'wantlist': False}
    ret_0 = lookup_module_0.run(terms_0, **kwargs_0)

# Generated at 2022-06-25 10:35:15.706505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['/my/path/*.txt'], variables={'_original_file': '/root/ansible/hacking/testsuite/units/modules/shell/abc', '_ansible_no_log': False, '_ansible_module_name': 'shell', 'ansible_facts': {}, 'ansible_python_interpreter': '/usr/bin/python', '_ansible_debug': False, '_ansible_check_mode': False}, **{}) == []

# Generated at 2022-06-25 10:35:26.044444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'abc']
    variables_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert type(result_0) == list
    assert result_0 == []
    terms_1 = [u'*']
    variables_1 = {}
    result_1 = lookup_module_0.run(terms_1, variables_1)
    assert type(result_1) == list
    assert result_1 != []
    terms_2 = [u'abc', u'def']
    variables_2 = {}
    result_2 = lookup_module_0.run(terms_2, variables_2)
    assert type(result_2) == list
    assert result_2 == []

# Generated at 2022-06-25 10:35:35.863563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_run_terms_1 = ["testDir"]
    test_run_variables_1 = "test_run_variables_1"
    test_run_kwargs_1 = {'wantlist': True}
    expected_result_1 = []
    test_run_ret = lookup_module_1.run(test_run_terms_1, test_run_variables_1, **test_run_kwargs_1)
    assert test_run_ret == expected_result_1


# Generated at 2022-06-25 10:35:38.984629
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class lookup_module_0
    class_arguments = ['fileglob', '/my/path/*.txt']
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=variables)

# Generated at 2022-06-25 10:35:45.579683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/passwd']
    variables_0 = dict()
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert False, "doctests are not supported as of now"


# Generated at 2022-06-25 10:35:53.357770
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # should find one file, named either rabbitmq_cluster_1_1.yml
    # or rabbitmq_cluster_1_2.yml (ran it against both, so either
    # one is fine for testing purposes
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=['rabbitmq_cluster_1_*.yml'],wantlist=True)
    assert result[0] == 'plugins/lookup/targets/rabbitmq_cluster_1_1.yml' or result[0] == 'plugins/lookup/targets/rabbitmq_cluster_1_2.yml'

# Generated at 2022-06-25 10:35:59.424567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['*.txt']
    variables = {'ansible_search_path':['/usr/lib/']}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['/usr/lib/types.txt']


# Generated at 2022-06-25 10:36:09.026792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__
    from ansible.plugins.lookup import LookupBase
    glob__builtin__ = __builtin__
    glob_os = os
    glob_glob = glob
    glob_LookupBase = LookupBase
    glob_terms = ['fileglob_test_1.txt', '/tmp/fileglob_test_2.txt']
    glob_kwargs = {}
    glob_kwargs['wantlist'] = "some_wantlist"
    glob_kwargs['wantlist'] = "some_wantlist"
    glob_variables = {}
    glob_variables['ansible_search_path'] = "some_ansible_search_path"

    # Init hook

# Generated at 2022-06-25 10:36:15.308634
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    ret = lookup_module_0.run(['foo'])
    assert ret == []
    ret = lookup_module_0.run(['tests/test_lookups/fileglob_testfile1'])
    assert ret == ['tests/test_lookups/fileglob_testfile1']
    ret = lookup_module_0.run(['tests/test_lookups/fileglob*'])
    assert ret == ['tests/test_lookups/fileglob_testfile1', 'tests/test_lookups/fileglob_testfile2']

# Generated at 2022-06-25 10:36:23.662754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_2 = [
        ('/home/ubuntu/foo.yml'),
        ('/home/ubuntu/bar.yml'),
    ]
    ansible_search_path_2 = [
        ('/home/ubuntu'),
        ('/etc'),
    ]
    variables_2 = {
        'ansible_search_path': ansible_search_path_2,
    }
    kwargs_2 = {
        'wantlist': True,
    }
    ret_2 = lookup_module_2.run(terms_2, variables_2, **kwargs_2)
    assert ret_2 == []



# Generated at 2022-06-25 10:36:30.911527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    params = ['/my/path/*.txt']
    terms = params[0]
    variables = {}
    ret = lookup_module_0.run(terms, variables)
    assert ret is not None, "Failed to return data, return value was 'None'"
    assert len(ret) == 0, "Failed to return data the size of return was '%s'" % len(ret)

# Generated at 2022-06-25 10:36:37.723309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    lookup_module_1 = LookupModule()
    terms = ['makefile']
    variables = {'ansible_search_path': ['..']}
    files = lookup_module_1.run(terms, variables)
    assert files == ['makefile']
  except Exception as e:
    print(e)
    assert False

# Generated at 2022-06-25 10:36:42.908388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = {}
    lookup_module_1.run(terms_1, variables_1)

# Generated at 2022-06-25 10:36:48.874141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Structured data to use for testing
  args = []
  # Define the expected result
  expected_result = ''
  # Call the run method with the arguments
  actual_result = LookupModule.run(self, args)
  # Assert the expected result equals the actual result
  assert expected_result == actual_result

# Generated at 2022-06-25 10:36:56.859983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_1 = dict()
    list_0 = []
    str_0 = "<module 'ansible.modules.extras.system.fileglob' from '/usr/share/ansible/plugins/modules/fileglob.py'>"
    str_1 = "fileglob"
    str_2 = "loop"
    str_3 = "item"
    str_4 = "with_fileglob"
    dict_1['ansible_loop_var'] = str_3
    dict_1['ansible_loop_var_name'] = str_2
    dict_1['ansible_lookup_plugin'] = str_1
    dict_1['lookup_fileglob_0'] = str_0

# Generated at 2022-06-25 10:37:05.181631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    return_value_0 = lookup_module_0.run(terms=['*'], variables={u'ansible_search_path': [u'/home/ansible/ansible/library', u'/usr/share/ansible']})
    assert return_value_0 == []
    return_value_1 = lookup_module_0.run(terms=['*'], variables={})
    assert return_value_1 == []
    return_value_2 = lookup_module_0.run(terms=['/home/ansible/ansible/lookup_plugins/*'], variables={u'ansible_search_path': [u'/home/ansible/ansible/library', u'/usr/share/ansible']})

# Generated at 2022-06-25 10:37:06.076460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule().run('/etc/passwd', None)) == 1

# Generated at 2022-06-25 10:37:21.534329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    path_0 = 'test_dir_0/test_dir_1'
    file_0 = 'test_file_0.txt'
    path_1 = path_0 + '/' + file_0
    path_2 = 'test_dir_2'
    file_1 = 'test_file_1.txt'
    path_3 = path_2 + '/' + file_1
    terms_0 = [path_1, path_3]
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == [path_1, path_3]
    result_1 = lookup_module_0.run(terms_0, None, wantlist=True)
    assert result_1 == [path_1, path_3]


# Generated at 2022-06-25 10:37:28.397515
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    terms_str = 'abcd'
    terms_dict = {'0': 'abcd'}
    terms = [terms_dict]

    # Act
    # Return Value
    ret = lookup_module_0.run(terms, {})

    # check results
    assert ret == ['abcd']

# Generated at 2022-06-25 10:37:34.698655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(['/etc/hosts'])
    assert ret == ['/etc/hosts']


# Generated at 2022-06-25 10:37:41.350022
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    terms=[]
    terms.append('/path/to/file/one')
    terms.append('/path/to/anotherfile')
    terms.append('extfile')

    ret = lookup_module_1.run(terms)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:37:49.310680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup variables that would normally be set by Ansible for testing.
    basedir = os.path.abspath(os.path.dirname(__file__))
    os.environ['HOME'] = '/home/username'
    os.environ['ANSIBLE_ROLES_PATH'] = '%s/roles' % basedir
    os.environ['ANSIBLE_LIBRARY'] = '%s/library' % basedir
    os.environ['ANSIBLE_FILTER_PLUGINS'] = '%s/filter_plugins' % basedir
    os.environ['ANSIBLE_LOOKUP_PLUGINS'] = '%s/lookup_plugins' % basedir
    os.environ['ANSIBLE_CONFIG'] = '%s/ansible.cfg' % basedir

# Generated at 2022-06-25 10:37:54.318836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run unit test
    # Result is a list of found Python paths
    lookup_module_1 = LookupModule()
    lookup_module_1.uris.append('/usr/lib/python2.7/dist-packages')
    lookup_module_1.run(['*lib2to3*'])

# Generated at 2022-06-25 10:38:02.641437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import ansible.plugins.lookup.fileglob
    # First we must create a tmp directory and then file
    import tempfile
    tempdir = tempfile.gettempdir()
    tempdir = os.path.join(tempdir, "fileglob")
    try:
        os.makedirs(tempdir)
        file_to_create = os.path.join(tempdir, "lookup_file")
        text_to_write = "hello lookup_file"
        f = open(file_to_create, "w")
        f.write(text_to_write)
        f.close()
    except OSError:
        sys.exit("Creation of  %s directory failed" % tempdir)
    else:
        print("Successfully created the directory %s " % tempdir)



# Generated at 2022-06-25 10:38:05.283063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(["files/fooapp/*.txt"], {"ansible_search_path": ["/path1", "/path2"]}) == ["/path1/files/fooapp/foo.txt", "/path2/files/fooapp/foo.txt"]

# Generated at 2022-06-25 10:38:08.482851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([], [''])


# Generated at 2022-06-25 10:38:17.040979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # unit test for the main functionality
    # tests the basic functionality of the run() method
    # calls to methods that are overridden: find_file_in_search_path(), get_basedir(), glob.glob(), os.path.isfile()
    #
    # setup a mock object for glob.glob()
    import mock
    mock_glob = mock.Mock()
    mock_glob.side_effect = [["/etc/hosts"], ["/etc/hostname"], ["/etc/hostname", "/etc/hosts"], ["/etc/hostname", "/etc/hosts"]]
    lookup_module_0.glob = mock_glob
    
    # setup a mock object for os.path.isfile()
    import mock
    mock_isfile = mock

# Generated at 2022-06-25 10:38:53.875382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run('foo.txt')
    assert(lookup_module_run == [])

# Generated at 2022-06-25 10:38:56.350362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    terms = ["/my/path/*.txt"]
    kwargs = {}
    variables = {}
    assert lookup_module_obj.run(terms,variables,**kwargs) is None

# Generated at 2022-06-25 10:39:00.544875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_json_0 = [{'key0': 'value0'}]
    variables_0 = {'key0': 'value0', 'key1': 'value1'}
    ret_0 = lookup_module_0.run(terms_json_0, variables_0)
    assert isinstance(ret_0, list)

# Generated at 2022-06-25 10:39:08.106382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock object globally for use in test
    global lookup_module_0
    # Create test args
    terms_0 = "/etc/ansible/roles/apache/files/vhost.conf"
    variables_0 = "AnsibleUndefined"
    # Attempt call to run method
    result_0 = lookup_module_0.run(terms_0, variables_0)
    # Assert result is as expected
    assert result_0 == "/etc/ansible/roles/apache/files/vhost.conf"

# Generated at 2022-06-25 10:39:12.814570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = []
    str_0 = 'fileglob'
    str_1 = '''dWltZQ=='''
    str_2 = '''YWJj'''
    str_3 = '''ZGVm'''
    str_4 = '''Z2hp'''
    str_5 = '''aGVsbG8='''
    value_0 = lookup_module_0.run(list_0)
    value_1 = lookup_module_0.run(list_1)
    print(value_0)
    print(value_1)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:22.854233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Path to the lookup module
    module_path = os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins', 'fileglob.py')
    # Create the lookup module
    lookup_module = imp.load_source('fileglob', module_path)

    # Set the os.path.exists to return the mock_exists return value
    @mock.patch('os.path.exists')
    def run(mock_exists):

        # Set the mock_exists return value
        mock_exists.return_value = True
        # Call the run function
        lookup_module.run(terms='*', variables=None, **kwargs)



# Generated at 2022-06-25 10:39:26.378709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['../examples/*.yml']
    lookup_module.run(terms)
    assert isinstance(terms, list)
    assert isinstance(terms[0], str)

# Generated at 2022-06-25 10:39:28.795068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['*.txt']
    variables = None
    lookup_module = LookupModule()
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:39:30.420189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=['/my/path/*.txt'], variables=None, **{}) == []

# Generated at 2022-06-25 10:39:38.442592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # No files
    ret = lookup_module.run([to_text('test_files/test_file_1.txt')], {'ansible_search_path': [to_text('test_files/nonexistent')]})
    assert ret == []

    # Matching file in lookup path
    ret = lookup_module.run([to_text('test_file_1.txt')], {'ansible_search_path': [to_text('test_files')]})
    assert ret == [to_text('test_files/test_file_1.txt')]

    # Matching file in lookup path, without quoting