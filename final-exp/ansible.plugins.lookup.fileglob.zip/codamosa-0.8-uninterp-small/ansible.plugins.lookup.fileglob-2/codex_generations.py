

# Generated at 2022-06-25 10:33:02.427622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_3 = [
        'data/customers/customer_data.csv'
    ]

# Generated at 2022-06-25 10:33:07.855444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# TODO: Add test for non-existing file
# TODO: Add test for non-existing pattern
# TODO: Add test for non-existing filepath

# Generated at 2022-06-25 10:33:09.734631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1, LookupModule) is True


# Generated at 2022-06-25 10:33:20.192230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/etc/check_mk/conf.d/wato/*.mk']

# Generated at 2022-06-25 10:33:24.948870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = ""
    parameters = {'wantlist': False}
    variables = {}
    result = lookup_module_0.run(term, variables, **parameters)
    assert result == []


if __name__ == "__main__":
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 10:33:27.101357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}
    assert lookup_module_0.run(terms, variables) == []



# Generated at 2022-06-25 10:33:30.665171
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    input_0 = (['LookupModule'], {'vars': {'ansible_search_path': ['/home/ubuntu/ansible/lab-1']}}, dict())
    res = LookupModule.run(*input_0)
    print(res)

# Generated at 2022-06-25 10:33:33.273758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("----- test_LookupModule_run -----")
    lookup_module = LookupModule()
    terms = [
        '/my/path/*.txt',
        '/playbooks/files/fooapp/*'
    ]
    res = lookup_module.run(terms)
    print(res)


# Generated at 2022-06-25 10:33:41.615517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()

    # test with bad terms
    terms = ["/a/b/c/d/e/f", "/a/b/c/d/e/g"]
    variables = {
        "ansible_facts": "",
        "ansible_search_path": ["/a/b", "/a/c", "/a/b/c", "/a/d"]
    }
    result = lookup_module_3.run(terms, variables)
    assert result == []

    # test with terms with one element
    terms = ["/a/b/c/d/e/f"]

# Generated at 2022-06-25 10:33:43.954547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(["/path/sample.txt"])
    assert ret == "/path/sample.txt"



# Generated at 2022-06-25 10:33:55.890053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_args = [
        [
            {
                "ansible_search_path": [
                    "tests/integration/targets/test_fileglob"
                ],
                "ansible_facts": {
                    "module_setup": True
                }
            },
            [
                "test_fileglob/test1.txt",
                "test_fileglob/test2.txt",
                "test_fileglob/test3.txt"
            ],
            True
        ]
    ]

# Generated at 2022-06-25 10:34:01.754895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms=[os.path.abspath(os.path.join(__file__,os.pardir,'test_lookup_fileglob.py'))]
    return_value = LookupModule().run(terms,dict(ansible_search_path='/etc/ansible/lookup_plugins,./lookup_plugins,~/.ansible/plugins/lookup'))
    assert return_value == [os.path.abspath(os.path.join(__file__,os.pardir,'test_lookup_fileglob.py'))], "lookup_module.run() test_case_0"


# Generated at 2022-06-25 10:34:08.321369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(["test_data/test.conf"])
    assert len(results) == 1
    assert results[0].endswith("test_data/test.conf")


# Generated at 2022-06-25 10:34:14.125408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    output = lookup_module_1.run(['*.txt'], { 'ansible_search_path': ['/home/test_user/.ansible/tmp', '/tmp'], 'ansible_cwd': '/home/test_user/my_project'})
    assert isinstance(output, list)
    assert output == []

# Generated at 2022-06-25 10:34:22.628554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host_variables = {"ansible_search_path": ["/Users/me/playbooks", "/etc/playbooks"]}
    terms_0 = sorted(
        lookup_module_0.run(
            terms=[u'*.txt'],
            variables=host_variables,
            wantlist=False,
            basedir=u'/etc/playbooks'
        )
    )

    assert [u'foo.txt', u'foobar.txt', u'bar.txt'] == terms_0

# Generated at 2022-06-25 10:34:23.259369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:34:34.770805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # All values passed
    terms = []
    variables = {}
    kwargs = {}
    assert lookup_module_0.run(terms, variables, kwargs) == []
    # All values passed
    terms = ['/etc/init.d']
    variables = {}
    kwargs = {}
    assert lookup_module_0.run(terms, variables, kwargs) == []
    # All values passed
    terms = ['/etc/init.d', '/usr/local/bin']
    variables = {}
    kwargs = {}
    assert lookup_module_0.run(terms, variables, kwargs) == []
    # All values passed
    terms = ['/tmp']
    variables = {}
    kwargs = {}

# Generated at 2022-06-25 10:34:40.911305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["hosts"]
    variables_0 = {"ansible_search_path": ["/home/ansible/playbooks/roles"]}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == []


# Generated at 2022-06-25 10:34:51.733044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/my/path/*.txt']
    variables = {}
    assert lookup_module_0.run(terms, variables) == []

test_class_0 = LookupModule()

test_class_1 = LookupModule()

test_class_2 = LookupModule()

test_class_3 = LookupModule()

test_class_4 = LookupModule()

test_class_5 = LookupModule()

test_class_6 = LookupModule()

test_class_7 = LookupModule()

test_class_8 = LookupModule()

test_class_9 = LookupModule()

test_class_10 = LookupModule()

test_class_11 = LookupModule()

test_class_12 = Look

# Generated at 2022-06-25 10:35:01.892801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of class LookupModule
    lookup_module_0 = LookupModule()
    # testcase 1
    # input arguments
    terms = ['/root/test.txt']

# Generated at 2022-06-25 10:35:06.361505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:35:13.967980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4616.928333
    str_0 = '\n        Matches all files in a single directory, non-recursively, that match a\n        pattern.\n        '
    dict_0 = {'wantlist': True}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0, str_0, **dict_0)
    var_1 = lookup_module_0.run(float_0, str_0, **dict_0)
    assert var_0 == var_1


# Generated at 2022-06-25 10:35:25.121705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test environment
    float_0 = 1438.76701
    str_0 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    dict_0 = {}
    lookup_module_0 = LookupModule()

    # Call method
    var_0 = lookup_module_0.run(float_0, str_0, **dict_0)
    # Output test

# Generated at 2022-06-25 10:35:29.617559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1438.76701
    str_0 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0, str_0, **dict_0)
    assert var_0 == [], var_0


# Generated at 2022-06-25 10:35:36.599422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('test_LookupModule_run')
    float_0 = 1438.76701
    str_0 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    dict_0 = {}
    lookup_module_0 = LookupModule()
    try:
        var_0 = lookup_module_0.run(float_0, str_0, **dict_0)
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-25 10:35:41.294218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 1438.76701
    str_1 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    dict_1 = {}
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(float_1, str_1, **dict_1)
    assert var_1 == float_1


# Generated at 2022-06-25 10:35:48.113793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 1438.76701
    str_1 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    dict_1 = {}
    lookup_module_1 = LookupModule()
    float_2 = float_1
    str_2 = str_1
    dict_2 = dict_1
    var_0 = lookup_module_1.run(float_2, str_2, **dict_2)

# Generated at 2022-06-25 10:35:52.990074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1438.76701
    str_0 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    dict_0 = {}

    # Testing method run
    # Parameters:
    #
    # Return: None
    #
    # Return type: None
    assert lookup_module_0.run(float_0, str_0, **dict_0) is None


# Generated at 2022-06-25 10:35:53.896948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # We've got nothing to test here!
  raise NotImplementedError()

# Generated at 2022-06-25 10:35:58.023292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1438.76701
    var_0 = LookupModule.run(float_0)
    str_0 = '\n        Similar to __getitem__, however the returned data is not run through\n        the templating engine to expand variables in the hostvars.\n        '
    var_1 = LookupModule.run(str_0)
    return


# Generated at 2022-06-25 10:36:13.859804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_2 = '[a-zA-Z]+'
    str_3 = {str_2: lookup_module_1, str_2: str_2, str_2: str_2, str_2: str_2}
    str_4 = 'ansible_basedir'
    str_5 = {str_4: lookup_module_1, str_4: str_4, str_4: str_4, str_4: str_4}
    str_6 = 'warnings'
    str_7 = {str_6: lookup_module_1, str_6: str_6, str_6: str_6, str_6: str_6}
    var_1 = lookup_run(str_5, str_7)

# Generated at 2022-06-25 10:36:20.190297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  str_0 = 'ansible_search_path'
  str_1 = {str_0: lookup_module, str_0: str_0, str_0: str_0, str_0: str_0}
  assert lookup_run(str_0, str_1) == []

# Generated at 2022-06-25 10:36:30.923045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_0 = []

    output_0 = []

    output_1 = None

    output_2 = []

    output_3 = None

    # Call function run
    # Input arguments
    str_0 = 'ansible_search_path'

    str_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}

    str_2 = 'r'

    int_0 = 0

    int_1 = 0

    output_0 = lookup_run(str_0, str_1, str_2, int_0, int_1)

    # Assertions
    assert (output_0 == output_1) or (output_0 is output_1)
    # Call function run
    # Input arguments


# Generated at 2022-06-25 10:36:34.482975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 10:36:41.858196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_var_0 = LookupModule()
    str_var_0 = 'ansible_search_path'
    str_var_1 = {str_var_0: lookup_module_var_0, str_var_0: str_var_0, str_var_0: str_var_0, str_var_0: str_var_0}
    var_18 = lookup_module_var_0.run(str_var_1, str_var_1)
    print(var_18)

# Generated at 2022-06-25 10:36:48.649494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    str_2 = 'ansible_search_path'
    str_3 = '/usr/share/ansible/lookup_plugins'
    str_4 = 'ansible_search_path'
    str_5 = 'playbooks/roles/common/files/dns'
    str_6 = 'ansible_search_path'
    str_7 = 'playbooks'
    str_8 = 'ansible_search_path'
    str_9 = 'playbooks/roles/common/files'

# Generated at 2022-06-25 10:36:55.742096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str = 'ansible_search_path'
    str = {str: lookup_module, str: str, str: str, str: str}
    var = lookup_run(str, str)
    assert isinstance(var, list)

# Generated at 2022-06-25 10:37:04.973970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    src_0 = '/playbooks/files/fooapp/*'
    str_0 = 'AN'
    str_1 = 'ansible_search_path'
    str_2 = str_0 + 'SIBLE'
    str_3 = '/my/path/*.txt'
    str_4 = 'ansible_playbook_python'
    str_5 = 'ANSIBLE_'
    str_6 = 'ANSIBLE_PRIVATE_KEY_FILE'
    str_7 = 'ANSIBLE_REMOTE_TEMP'
    str_8 = 'ANSIBLE_SSH_PIPELINING'
    str_9 = 'ANSIBLE_SSH_RETRIES'
    str_10 = 'PATH'
    str_11 = 'ANSIBLE_'

# Generated at 2022-06-25 10:37:09.524460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["test_file.aaa"]) == []
    assert lookup_module.run(["*.aaa"]) == []

# Generated at 2022-06-25 10:37:14.599711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    lookup_0 = LookupModule()
    str_0 = 'list'
    str_1 = "ansible_search_path"
    str_2 = "dir"
    lookup_1 = [str_1, str_2]
    str_3 = {str_3: str_3, str_2: str_2, str_1: str_1, str_0: str_0}
    lookup_2 = lookup_0.run(lookup_1, str_3)
    assert len(lookup_2) > 0
    assert lookup_2[0] == to_text('/test/test/test')
    str_4 = 'ansible_search_path'
    str_5 = 'list'


# Generated at 2022-06-25 10:37:27.112198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  test_case_0()

# Generated at 2022-06-25 10:37:31.431110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    o_0 = LookupModule()
    o_1 = o_0.run('/etc/password')
    assert o_1 == ['/etc/passwd']
    o_2 = o_0.run('/etc/not-a-file')
    assert o_2 == []
    o_3 = o_0.run('/etc/passwd', wantlist=True)
    assert o_3 == ['/etc/passwd']
    o_4 = o_0.run('/etc/not-a-file', wantlist=True)
    assert o_4 == []

# Generated at 2022-06-25 10:37:42.100637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:37:46.948909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_2 = {}
    str_3 = ['ansible_search_path']
    # TODO: lookup_module_1.run is causing an error:
    # TypeError: run() missing 2 required positional argument: 'terms' and 'variables'
    # var_1 = lookup_module_1.run(str_2, str_3)


# Generated at 2022-06-25 10:37:53.039495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0.run(str_0, str_1)


# Generated at 2022-06-25 10:37:56.617050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module, str_0: str_0, str_0: str_0}
    lookup_module.run(str_0, str_1)

# Generated at 2022-06-25 10:38:00.598506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_1 = lookup_run(str_0, str_1)



# Generated at 2022-06-25 10:38:05.252706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '#'
    str_1 = 'test_file'
    str_2 = 'ansible_search_path'
    str_3 = {str_2: lookup_module_0, str_2: str_2, str_2: str_2, str_2: str_2, str_2: str_2, str_2: str_2}
    var_0 = lookup_run(str_0, str_3)


# Generated at 2022-06-25 10:38:13.240462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: './file_with_path', str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run('file_with_path', str_1)
    assert var_0 == ['./file_with_path']

# Generated at 2022-06-25 10:38:18.102226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str = 'ansible_search_path'
    var = {str: lookup_module, str: str, str: str, str: str}
    str_0 = 'ansible_search_path'
    var_0 = {str_0: lookup_module, str: str, str: str, str: str}
    str_1 = 'ansible_search_path'
    var_1 = {str: lookup_module, str: str, str: str, str: str}
    str_2 = 'ansible_search_path'
    var_2 = {str: lookup_module, str: str, str: str, str: str}
    str_3 = 'ansible_search_path'

# Generated at 2022-06-25 10:38:33.603295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_2 = 'ansible_search_path'
    str_3 = {str_2: str_2, str_2: str_2, str_2: str_2, str_2: str_2}
    var_1 = lookup_module_1.run(str_2, str_3)

# Generated at 2022-06-25 10:38:39.420217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert str_0 == str_0
    assert str_1 == str_1
    assert str_2 == str_2
# Test for LookupModule.run :: Path does not exist
# Test for LookupModule.run :: Run path does not exist
# Test for LookupModule.run :: Single path
# Test for LookupModule.run :: One path

# Generated at 2022-06-25 10:38:45.722426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    obj_0 = lookup_module_0.run(list(), str_1)
    print(obj_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:38:49.182114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0.run(terms='', variables=str_1)


# Generated at 2022-06-25 10:38:51.728194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    assert_equals(lookup_module_0.run(str_0, str_1), None)

# Generated at 2022-06-25 10:38:56.276333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("start test " + "test_LookupModule_run")
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0.run(str_1, str_0)


# Generated at 2022-06-25 10:39:01.573651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_2 = 'ansible_basedir'
    str_3 = '/home/vagrant/sandbox/ansible/lookups/fileglob.py'
    str_4 = 'ansible_search_path'
    str_5 = {str_4: lookup_module_2, str_2: str_3, str_4: str_4, str_4: str_4}
    len_0 = 0
    assert len_0 == 0

test_LookupModule_run()

# Generated at 2022-06-25 10:39:05.152706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'foo.txt'
    str_1 = 'files'
    str_2 = 'ansible_search_path'
    str_3 = {str_2: lookup_module_0, str_2: str_2, str_2: str_2, str_2: str_2}
    ret = lookup_module_0.run(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 10:39:13.267532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(str_1)
    assert var_0 is not None

# Generated at 2022-06-25 10:39:23.062739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	path_0 = os.path.join('files', 'fooapp', '*')
	path_1 = os.path.join('files', 'fooapp', '*.txt')
	path_2 = os.path.join('my', 'path', '*.txt')
	list_0 = [path_0, path_1, path_2]
	lookup_module_1 = LookupModule()
	lookup_module_2 = LookupModule()
	lookup_module_3 = LookupModule()
	lookup_module_4 = LookupModule()
	lookup_module_5 = LookupModule()
	lookup_module_6 = LookupModule()
	str_1 = 'ansible_search_path'

# Generated at 2022-06-25 10:39:40.260889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = "ansible_search_path"
    var_0 = lookup_module.run(["ansible_search_path"], str_0)
    # print(var_0)
    print('lookup_module ==> result = ', var_0)



# Generated at 2022-06-25 10:39:43.645650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_2 = 'ansible_search_path'
    str_3 = {str_2: lookup_module_2, str_2: str_2, str_2: str_2, str_2: str_2}
    var_1 = lookup_run(str_2, str_3)

# Generated at 2022-06-25 10:39:48.280356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_dict_0 = {}
    lookup_module_0 = LookupModule()
    dict_str_0 = lookup_module_0.run(test_dict_0)


# Generated at 2022-06-25 10:39:52.339301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str0 = ['/my/path/*.txt']
    str1 = 'ansible_search_path'
    str2 = {str1: lookup_module, str1: str1, str1: str1, str1: str1}
    var0 = lookup_module.run(str0, str2)
    assert var0 == []

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:54.116670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str = 'ansible_search_path'
    str = {str: lookup_module, str: str, str: str, str: str}
    var = lookup_run(str, str)


# Generated at 2022-06-25 10:39:57.367390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(str_0, str_1)

# Generated at 2022-06-25 10:40:01.284951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(str_0, str_1)

# Generated at 2022-06-25 10:40:09.022230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(str_0, str_1)
    str_2 = 'path'
    func_0 = lookup_module_0.run(str_2)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:40:16.769427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule().run
    terms = [lookup_run, lookup_run, lookup_run, lookup_run]
    variables = {lookup_run: lookup_run}
    ret = lookup_run(terms, variables)
    ret = lookup_run(terms, variables, wantlist=True)

    # test that glob errors when the file path contains extended chars.
    try:
        lookup_run([lookup_run], {})
    except AnsibleFileNotFound:
        pass


# Generated at 2022-06-25 10:40:21.571664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(str_0, str_1)

# Generated at 2022-06-25 10:41:00.077204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    path_0 = 'test_file_0'
    open(path_0, 'w').close()
    str_0 = 'files'
    str_1 = {'ansible_search_path': [os.getcwd()], str_0: [os.getcwd()], 'paths': [os.getcwd()]}
    str_2 = 'test_file_0'
    var_0 = lookup_module.run(str_2, str_1)
    os.remove(path_0)
    assert var_0 is not None
    assert var_0 == [path_0]

# Generated at 2022-06-25 10:41:07.557671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(str_0, str_1)

# Generated at 2022-06-25 10:41:14.520471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(str_0, str_1)
    assert var_0 == 'ansible_search_path'



# Generated at 2022-06-25 10:41:18.212475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result_0 = lookup_run_0()
    result_1 = lookup_run_1()
    result_2 = lookup_run_2()
    result_3 = lookup_run_3()
    result_4 = lookup_run_4()
    assert result_0 == result_1
    assert result_1 == result_2
    assert result_2 == result_3
    assert result_3 == result_4

# Generated at 2022-06-25 10:41:25.785109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Build mock lookup module
    lookup_module = LookupModule(loader=None, templar=None)

    # Build mock search variable
    mock_search_variable = {'ansible_search_path': lookup_module, 'ansible_search_path': 'ansible_search_path', 'ansible_search_path': 'ansible_search_path', 'ansible_search_path': 'ansible_search_path'}

    # Run method
    var_0 = lookup_module.run('ansible_search_path', mock_search_variable)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:41:28.398045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_search_path'
    str_1 = {str_0: lookup_module_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(str_0, str_1)
    assert var_0



# Generated at 2022-06-25 10:41:32.661163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test if the method run of class LookupModule returns correct results"""
    # Set up test data
    test_vars = {}

    test_vars['ansible_search_path'] = ['~/.ansible/plugins/lookup/', '~/ansible/plugins/lookup']
    test_terms = ['file_a', 'file_b']
    expected_results = ['~/.ansible/plugins/lookup/file_a', '~/.ansible/plugins/lookup/file_b', '~/ansible/plugins/lookup/file_a', '~/ansible/plugins/lookup/file_b']

    # Create the object that we are going to test
    lookup_module_test = LookupModule()

    # Run the method that we are testing

# Generated at 2022-06-25 10:41:41.529240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = ''
    term_1 = './test_fileglob.py'
    term_2 = 'ansible_test'
    term_3 = []
    term_4 = '/tmp'
    term_5 = ['../test_fileglob.py', '../test_fileglob.py']
    term_6 = './test_fileglob.py'
    term_7 = '../test_fileglob.py'
    term_8 = []
    term_9 = ['../test_fileglob.py', '../test_fileglob.py', '../test_fileglob.py']
    term_10 = './test_fileglob.py'
    term_11 = '../test_fileglob.py'
    term_12 = '..'

# Generated at 2022-06-25 10:41:44.239305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# Generated at 2022-06-25 10:41:47.256514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_2 = 'ansible_search_path'
    str_3 = {str_2: lookup_module_1, str_2: str_2, str_2: str_2, str_2: str_2}
    var_1 = lookup_module_1.run(str_3, str_3)