

# Generated at 2022-06-25 10:32:55.568008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    result_should_1 = []

    result_1 = lookup_module_1.run(terms=["*.py"])
    assert result_1 == result_should_1
    result_2 = lookup_module_1.run(terms=["*/.c*"])
    assert result_2 == result_should_1


# Generated at 2022-06-25 10:32:59.949941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    list_0 = ["test_target_var"]
    lookup_module_0.run(list_0, dict_0)
    dict_1 = dict()
    list_1 = ["test_target_var"]
    lookup_module_0.run(list_1, dict_1)


# Generated at 2022-06-25 10:33:04.447490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "/etc/*"
    variables_0 = {'ansible_facts': {'current_user': 'ansible_facts'}, 'ansible_search_path': ['/etc'], 'ansible_user_id': 'lookup_module_0'}
    kwargs_0 = {'wantlist': True}
    path_0 = lookup_module_0.run(term_0, variables_0, **kwargs_0)
    list_0 = [path_0]


# Generated at 2022-06-25 10:33:06.132524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == 'fail'

# Generated at 2022-06-25 10:33:11.844580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [None]
    variables = dict()
    variables.update({'ansible_search_path': ['/etc/hosts']})
    kwargs = dict()
    ret = lookup_module_0.run(terms, variables, **kwargs)
    assert ret == [None]


# Generated at 2022-06-25 10:33:22.359185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run([])
    str_1 = lookup_module_0.run([])
    str_2 = lookup_module_0.run([])
    str_3 = lookup_module_0.run([])
    str_4 = lookup_module_0.run([])
    str_5 = lookup_module_0.run([])
    str_6 = lookup_module_0.run([])
    str_7 = lookup_module_0.run([])
    str_8 = lookup_module_0.run([])
    str_9 = lookup_module_0.run([])
    str_10 = lookup_module_0.run([])
    str_11 = lookup_module_0.run([])
    str_12 = lookup_

# Generated at 2022-06-25 10:33:32.309951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # No error
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_0.run(terms=None, variables=None)
    # No error
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_0.run(terms='/path/to/foobar', variables=None)
    # No error
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_0.run(terms='/path/to/foobar', variables='variables')
    # No error
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_0.run(terms='/path/to/foobar', variables='variables', wantlist=True)
    # No error
   

# Generated at 2022-06-25 10:33:36.321063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["/etc/issue.net", "/etc/issue"]
    variables = {}
    kwargs = {"wantlist" : True}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result is not None, "Failed in test_LookupModule_run()"

# Generated at 2022-06-25 10:33:42.863057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    list_0 = [""]
    list_1 = [""]
    list_2 = [lookup_module_0]
    list_3 = [lookup_module_1]
    assert lookup_module_0.run(list_0, list_0) == ret
    assert lookup_module_1.run(list_1, list_1) == ret
    assert lookup_module_0.run(list_2, list_2) == ret
    assert lookup_module_1.run(list_3, list_3) == ret


# Generated at 2022-06-25 10:33:44.623475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = ['*']
    terms = [lookup_module_0, args]


# Generated at 2022-06-25 10:33:51.364807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({
                                 '_terms': [
                                            'my_file_name'
                                           ]
                                })
    lookup_module_1.run(['my_file_name'])

# Generated at 2022-06-25 10:33:52.754841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/my/path/*.txt']
    ret = lookup_module_1.run(terms_1)

# Generated at 2022-06-25 10:34:01.912830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with missing arguments
    with pytest.raises(AnsibleFileNotFound):
        lookup_module.run()

    # Test with missing terms
    with pytest.raises(AnsibleFileNotFound):
        lookup_module.run(terms=None)

    # Test with invalid search_paths
    with pytest.raises(AnsibleFileNotFound):
        lookup_module.run(terms='*.txt', variables={'ansible_search_path': 'foo'})

    # Test with invalid search_paths
    with pytest.raises(AnsibleFileNotFound):
        lookup_module.run(terms='*.txt', variables={'ansible_search_path': ['foo']})

    # Test with invalid path

# Generated at 2022-06-25 10:34:07.606233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  ret = lookup_module.run(terms=['/etc/hosts'], variables={})
  assert(ret == ['/etc/hosts'])

# Generated at 2022-06-25 10:34:18.100887
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # from ansible.plugins.lookup import LookupBase
    # from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_bytes, to_text

    # Creating the class instance
    lookup_module_0 = LookupModule()

    # Testing the method run with arguments

    # Passing invalid arguments
    lookup_module_arguments_0 = {}
    lookup_module_arguments_0['terms'] = ''

    # Testing with invalid arguments
    try:
        lookup_module_0.run(**lookup_module_arguments_0)
    except TypeError as e:
        test_error = e

    assert test_error is not None


    # Now passing valid arguments
    lookup_module_arguments_1 = {}

# Generated at 2022-06-25 10:34:27.157446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path = '/etc/ansible/roles/ansible-role-nginx/tests/inventory'
    terms = ['./hosts', './hosts']
    variables = {
        'ansible_search_path': ['/etc/ansible/roles/ansible-role-nginx/tests'],
        'ansible_basedir': '/etc/ansible/roles/ansible-role-nginx/tests'
    }
    lookup_module_1 = LookupModule()
    ret = lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 10:34:29.137219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms, variables=None, wantlist=False, executor=None)

# Generated at 2022-06-25 10:34:35.923064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run("/home/foo/bar") == ['/home/foo/bar']
    assert lookup_module_1.run("/home/foo/bar", variables={
        "ansible_search_path": "/home/foo/playbooks"
        }) == ['/home/foo/bar']


# Generated at 2022-06-25 10:34:42.784337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Check for input parameters
    result = lookup_module.run(terms=["/my/path/*.txt"])
    result2 = lookup_module.run(terms=["/my/path/*.txt"], variables=None)

    # Check for successful result
    assert type(result) is list
    assert type(result2) is list



# Generated at 2022-06-25 10:34:52.110253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({u'wantlist': True})
    lookup_module_0.set_context({u'playbook_dir': u'/root/ansible/playbooks', u'_original_file': u'/root/ansible/playbooks/test-lookup.yml', u'_run_done': True, u'_task_fields': {}, u'vars': {u'ansible_check_mode': False}, u'_hostvars_static': {}, u'_hostvars_from_fact_cache': {}, u'_python_version': 2})

# Generated at 2022-06-25 10:35:04.592201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fileglob_lookup = LookupModule()
    assert fileglob_lookup.run(['./test_fileglob.py']) == ['./test_fileglob.py']
    assert fileglob_lookup.run(['./test_fileglob.py', './test_lookup_plugin.py']) == ['./test_fileglob.py', './test_lookup_plugin.py']
    assert fileglob_lookup.run(['./test_fileglob.py', './test_fileglob.py']) == ['./test_fileglob.py', './test_fileglob.py']

# Generated at 2022-06-25 10:35:09.183559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(['*.txt'], {'ansible_search_path': ['.']})
    return ret_0

# Generated at 2022-06-25 10:35:14.069453
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up initial variables
    lookup_module = LookupModule()
    terms = ['*.txt']
    variables = {'ansible_env': {'HOME': 'test/test'}}

    # run the function
    result = lookup_module.run(terms, variables)

    # verify the results
    assert result == [('test/test/file1.txt', 'test/test/file2.txt')]

# Generated at 2022-06-25 10:35:20.833890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["/tmp/abc.txt"]
    variables = {}
    kwargs = {}
    assert(lookup_module.run(terms, variables, **kwargs) == [])


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:30.821419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests that the run method returns a list of files from the given path.
    lookup_object_0_fp = os.path.join(os.path.dirname(__file__), "test_file_0")
    lookup_object_1_fp = os.path.join(os.path.dirname(__file__), "test_file_1")
    lookup_object_0 = open(lookup_object_0_fp, "w")
    lookup_object_1 = open(lookup_object_1_fp, "w")
    lookup_object_0.close()
    lookup_object_1.close()

    opt_params = {"wantlist": True}
    terms = ["test_file*", "missing_file"]
    ret = LookupModule().run(terms=terms, variables=opt_params)


# Generated at 2022-06-25 10:35:39.226227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_runner(Runner())
    # tests the default value of the parameters
    test_args = ['test file']
    test_args_namespace = {}
    test_kwargs = {}
    test_kwargs_namespace = {}
    result = lookup_module_0.run(test_args, **test_kwargs)


# Generated at 2022-06-25 10:35:46.845273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Insert your test code here to test method run of class LookupModule

    # Test using a mock-up of the 'os' module
    #   https://docs.python.org/2/library/unittest.mock.html
    #   https://docs.python.org/2/library/unittest.html#unittest.TestCase.assertEqual

    assert True == True

# Generated at 2022-06-25 10:35:54.292234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # check run method with invalid arguments
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict

# Generated at 2022-06-25 10:36:01.338668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    FOO = 'FOO'
    lookup_module_1 = LookupModule()
    terms = [FOO]
    variables = {'ansible_search_path':['/a/path', 'b/path']}
    result = lookup_module_1.run(terms=terms, variables=variables)
    assert result == []

test_LookupModule_run()

# Generated at 2022-06-25 10:36:05.357205
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # calling run() method of LookupModule object
    assert lookup_module_0.run(terms=[]) == [], 'Test for "run" method of LookupModule'

# Generated at 2022-06-25 10:36:11.519267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run([u'/my/path/*.txt'], variables={u'ansible_search_path': [u'/my/path'], u'ansible_playbook_python': u'/usr/bin/python'}), list)
    assert isinstance(lookup_module_0.run([u'/my/path/*.txt'], variables={u'ansible_search_path': [u'/my/path'], u'ansible_playbook_python': u'/usr/bin/python'}), list)

# Generated at 2022-06-25 10:36:15.710540
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term_0 = "~/github/voice/tools/ansible/roles/user/files/[jh]in*"
    terms = [term_0]
    variables = dict()

    lookup_module_0 = LookupModule()
    files_in_lookup_module_0 = lookup_module_0.run(terms, variables)

    print("files_in_lookup_module_0=",files_in_lookup_module_0)


# Generated at 2022-06-25 10:36:19.253370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['/home/*.txt']) == []

# Generated at 2022-06-25 10:36:20.848886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('test')


# Generated at 2022-06-25 10:36:31.050378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t_str = "192.168.2.2/24"
    t_res = "192.168.2.0/24"
    t_help = 'Network Address'
    t_args = dict()
    t_args['ip'] = t_res
    t_args['mask'] = 24
    t_args['help'] = t_help
    t_args['netaddr'] = t_str
    t_args['expand'] = False
    t_args['wantlist'] = False
    terms = [
        "192.168.2.2/24",
    ]
    variables = dict()
    variables['ansible_search_path'] = [
        "./",
        "/home/vagrant/ansible/lookup_plugins/",
    ]

# Generated at 2022-06-25 10:36:38.264468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert glob.glob("/home/harshasree/DevOps/Ansible/Projects/Ansible-Projects/Files/*.txt") == lookup_module_0.run(["/home/harshasree/DevOps/Ansible/Projects/Ansible-Projects/Files/*.txt"])
#test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:36:47.907033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '''[
        "/my/path/*.txt"
    ]'''
    terms_1 = '''[
        "/my/path/*.txt"
    ]'''
    terms_2 = '''[
        "/my/path/*.txt"
    ]'''
    terms_3 = '''[
        "/my/path/*.txt"
    ]'''
    variables = "''"
    kwargs = dict()
    kwargs['wantlist'] = True
    lookup_module_0.run(terms_0, variables, **kwargs)
    # assert result["msg"] == ""
    kwargs = dict()
    kwargs['wantlist'] = True

# Generated at 2022-06-25 10:36:49.736585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  assert lookup_module_0.run(terms=['*.txt']) == []

# Generated at 2022-06-25 10:36:55.791315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yaml_data = ['/my/path/*.txt','/foo/bar/baz.txt']
    result_0 = {'_list': []}
    # result_0 = LookupModule.run(yaml_data)
    assert(result_0 == result_0)

# Generated at 2022-06-25 10:37:01.121221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No search path
    def mock_get_basedir_0(*_):
        return '.'

    # No search path
    def mock_get_basedir_1(*_):
        return '/my/path'

    # No search path
    def mock_get_basedir_2(*_):
        return '.'

    # Search path
    def mock_find_file_in_search_path_0(*_):
        return ''

    # Search path
    def mock_find_file_in_search_path_1(*_):
        return '/my/path'

    # Search path
    def mock_find_file_in_search_path_2(*_):
        return '/my/other/path'

    # Search path

# Generated at 2022-06-25 10:37:11.018137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = '-'
    var_1 = {var_0: var_0, 'wantlist': var_0}
    str_0 = '-'
    dict_0 = {str_0: str_0, var_0: lookup_module_1}
    list_0 = [str_0]
    list_1 = [str_0]
    assert '-*' == (lookup_run(str_0, dict_0))
    assert str_0 == (lookup_run(str_0, dict_0))
    assert list_0 == (lookup_run(var_0, dict_0))
    assert list_1 == (lookup_module_1.run(list_0))

# Generated at 2022-06-25 10:37:15.086076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 10:37:19.407316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)


# Generated at 2022-06-25 10:37:20.363039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ls = LookupModule()
    assert ls.run("*") != None

# Generated at 2022-06-25 10:37:27.472825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    str_1 = 'lookup_fixture.lookup_file'
    list_0 = [str_1]
    var_0 = lookup_module_0.run(list_0, {}, wantlist=True)


# Generated at 2022-06-25 10:37:35.438067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_basedir = MagicMock(return_value='/home/steve/work/ansible_py3_port')
    
    lookup_module_0.run('../../compat/jinja2.py')
    #assert(lookup_module_0.run('../../compat/jinja2.py') == ['/home/steve/work/ansible_py3_port/compat/jinja2.py'])

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:37:36.645431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('*.py')
    # assert ?


# Generated at 2022-06-25 10:37:38.596655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    var_0 = glob.glob()
    var_1 = os.path.isfile()
    
    
    
    
    
    


# Generated at 2022-06-25 10:37:44.693337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run_args = {'terms': '*'}
    run_args['variables'] = {'ansible_search_path': 'search_path'}
    LookupModule.run(**run_args)
    run_args = {'terms': '*'}
    run_args['variables'] = {'ansible_search_path': 'search_path', 'ansible_basedir': 'basedir'}
    LookupModule.run(**run_args)
    run_args = {'terms': '*'}
    run_args['variables'] = {'ansible_basedir': 'basedir'}
    LookupModule.run(**run_args)
    run_args = {'terms': '*'}

# Generated at 2022-06-25 10:37:45.625393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == False

# Generated at 2022-06-25 10:37:53.622368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with environment_vars
    lookup_module_run = LookupModule()
    lookup_module_run.run('test')



# Generated at 2022-06-25 10:37:59.187493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0) is LookupModule
    terms_0 = '-'
    variables_0 = '-'
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(terms_0, dict_0)
    lookup_module_0.run(terms_0, variables_0)



# Generated at 2022-06-25 10:38:06.085786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-25 10:38:08.533203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj_0 = LookupModule()
    obj_0.run(['-'])


# Generated at 2022-06-25 10:38:11.459383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)


# Generated at 2022-06-25 10:38:20.258735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate look module
    lookup_module = LookupModule()
    dwimmed_path = '..'
    terms = ['.git']
    found_paths = [dwimmed_path]
    # Test for the criteria when files for a given pattern is not present in the path
    if 'ansible_search_path' in {}:
        pass
    else:
        found_paths.append(lookup_module.get_basedir({}))
    for dwimmed_path in found_paths:
        if dwimmed_path:
            globbed = glob.glob(os.path.join(dwimmed_path, str(terms[0])))
            term_results = [g for g in globbed if os.path.isfile(g)]
            if term_results:
                break
   

# Generated at 2022-06-25 10:38:24.142487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '*.txt'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)



# Generated at 2022-06-25 10:38:26.855656
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Test with:
    # - lookup_module_1.run([])

    # Test with:
    # - lookup_module_1.run('-')

    # Test with:
    # - lookup_module_1.run(['-'])

# Generated at 2022-06-25 10:38:31.994557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    dict_1 = {'ansible_search_path': ['/home/ubuntu/ansible/modules', '/usr/share/ansible/plugins/modules']}
    list_0 = []
    list_1 = []
    dict_2 = dict_0
    dict_2 = dict_0
    elements = ["/home/ubuntu/ansible/modules/fileglob_lookup.py"]
    dict_1= {'_list': elements}
    list_0.append(dict_1)
    dict_3 = dict_2
    list_1.append(dict_3)
    dict_4 = dict_0
    dict_4

# Generated at 2022-06-25 10:38:34.826992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    list_0 = [str_0, str_0, str_0]
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(list_0, dict_0)

# Test case for method run of class LookupModule

# Generated at 2022-06-25 10:38:48.585255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    list_0 = []
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 10:38:59.057125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    str_1 = '-'
    list_0 = []
    list_0.append(str_1)
    str_2 = str_0
    str_3 = '-'
    str_4 = '/b/'
    str_5 = '/a/./c.txt'
    str_6 = 'cd'
    str_7 = '/a/../'
    str_8 = str_0
    str_9 = 'a'
    str_10 = '/a'
    str_11 = 'c.txt'
    str_12 = '.././b/'
    str_13 = '.././b/'
    str_14 = '/a'
    str_15 = '.'

# Generated at 2022-06-25 10:39:01.683765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = 'str_1'
    dict_0 = {str_0: str_0, str_0: lookup_module}
    var_0 = lookup_run(str_0, dict_0)

# Generated at 2022-06-25 10:39:07.143579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = '-'
    var_2 = {'ansible_search_path': ['/tmp']}
    var_3 = ['/tmp/*.txt']
    src_dir = os.path.dirname(__file__)
    template_dir = os.path.join(src_dir, 'templates')
    test_dir = os.path.join(src_dir, 'test')
    lookup_module = LookupModule()
    lookup_module._templar = Templar(loader=DataLoader(), variables=var_2)
    new_var = lookup_module.run(var_3, variables=var_2, wantlist=True)

# Generated at 2022-06-25 10:39:13.679363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    list_0 = [str_0]
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(list_0, dict_0)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:20.314223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    list_0 = [str_0]
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:39:30.849942
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Potential values for var_0
    expected_1 = list()
    expected_2 = ['my', 'my', 'my']
    expected_3 = ['my', 'my', 'your']

    # Setup object lookup_module_0
    lookup_module_0 = LookupModule()

    # Test case 1
    # Setup param_0
    str_0 = '-'
    # Setup param_1
    dict_0 = {str_0: 'my', str_0: lookup_module_0}
    # Setup param_2
    var_0 = int()

    # Invocation of method run
    result = lookup_module_0.run(str_0, dict_0, wantlist=var_0)

    # Test asserts

# Generated at 2022-06-25 10:39:38.706019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'bestrong'
    list_0 = [str_0]
    dict_0 = {str_0:list_0}
    assert lookup_module_0.run(list_0) == []

    lookup_module_0 = LookupModule()
    str_0 = 'bestrong'
    list_0 = [str_0]
    dict_0 = {str_0:list_0}
    assert lookup_module_0.run(list_0) == []

    lookup_module_0 = LookupModule()
    str_0 = 'bestrong'
    list_0 = [str_0]
    dict_0 = {str_0:list_0}
    assert lookup_module_0.run(list_0) == []



# Generated at 2022-06-25 10:39:43.298717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(terms=[str_0])
    assert isinstance(var_0, list)
    assert len(var_0) == 1
    assert isinstance(var_0[0], str)
    assert var_0[0] == str_0


# Generated at 2022-06-25 10:39:47.221405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    o = LookupModule()
    o.run([])


# Generated at 2022-06-25 10:40:15.247904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    str_1 = '-'
    dict_1 = {str_1: str_1, str_1: lookup_module_0}
    var_0 = lookup_run(str_1, dict_1)


# Generated at 2022-06-25 10:40:20.022692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    result = LookupModule.run(self, terms, variables=None, **kwargs)
    assert result in [str_0, True, None], "Method run of class LookupModule does not return str_0 or True or None"


# Generated at 2022-06-25 10:40:26.632208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text

    # Expected result (return value)
    result = [
        '/etc/ansible/roles/role1/library/test1.sh',
        '/etc/ansible/roles/role1/library/test2.sh'
    ]

    # Test with ansible_search_path
    ansibleModule = AnsibleModule({
        'ansible_search_path': [
            '/etc/ansible/roles/role1/library'
        ]
    })
    lookupModule = LookupModule()
    lookupModule.set_options(direct=dict())
    ret = lookupModule.run([
        '*.sh',
    ], variables=ansibleModule.params)

    assert result

# Generated at 2022-06-25 10:40:34.845532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    dir_0 = os.path.dirname(str_0)
    var_0 = lookup_module_0.run(dir_0, dict_0)
    str_1 = '-'
    str_2 = '-'
    var_1 = lookup_run(str_0, dict_0)
    var_2 = lookup_run(str_0, dict_0)
    assert var_0 == var_1
    del var_0, var_1, var_2
    assert True
    del lookup_module_0, str_0, dict_0, dir_0, str_1, str_2


# Generated at 2022-06-25 10:40:37.735517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 10:40:42.017127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    str_1 = '-'
    list_0 = [str_0, str_1]
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 10:40:44.906704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['-']
    var_0 = lookup_module_0.run(list_0)


# Tests for method find_file_in_search_path

# Generated at 2022-06-25 10:40:46.808962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    var_0 = [str_0]
    var_1 = lookup_run(str_0, var_0)


# Generated at 2022-06-25 10:40:48.963607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)

# Generated at 2022-06-25 10:40:50.967223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = 0
    term_0 = ['-']
    for var_0 in range(0, 10):
        lookup_module_0.run(term_0)


# Generated at 2022-06-25 10:41:44.702724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = '-'
    var_1 = {var_0: var_0, var_0: lookup_module_0}
    var_2 = [var_0]
    var_3 = lookup_module_0.run(var_2, variables=var_1)
    assert var_3 != None


# Generated at 2022-06-25 10:41:55.069509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'with_fileglob'
    str_1 = '* '
    str_2 = 'with_fileglob'
    str_3 = '*'
    str_4 = 'PYTHONIOENCODING'
    str_5 = 'utf-8'
    str_6 = 'ANSIBLE_YAML_FILTER_PLUGINS'
    dict_0 = {str_0: [str_1], str_2: str_3, str_4: str_5, str_6: str_3}
    var_0 = lookup_module_0.run(term=str_1, variables=dict_0, wantlist=True)
    print(var_0)


# Generated at 2022-06-25 10:41:57.585218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)

# Generated at 2022-06-25 10:42:00.335393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_1}
    var_0 = lookup_run(str_0, dict_0)


# Generated at 2022-06-25 10:42:10.200939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test when paths[-1] is not a directory
    str_0 = '_'
    str_1 = '-'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_1, str_1: lookup_module_0}
    term_0 = dir_0 = create_tmp_file(tmp_dir)
    if not os.path.exists(term_0):
        self.fail('Failed to open %s' % (term_0))
    os.remove(term_0)
    term_1 = 'test_LookupModule_run_test.%s' % (rand_0)
    term_2 = os.path.join(dir_0, term_1)
    terms_0 = [term_2]
    term_0 = lookup_module_0

# Generated at 2022-06-25 10:42:12.236947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)


# Generated at 2022-06-25 10:42:14.629554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    list_0 = ['-']
    var_0 = lookup_module_0.run(list_0, str_0)

# Generated at 2022-06-25 10:42:20.824664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = "os"
    var_1 = "path"
    var_2 = "join"
    var_3 = "extend"
    var_4 = "glob"
    var_5 = glob.glob
    var_6 = "isfile"
    var_7 = os.path.isfile
    var_8 = "items"
    var_9 = "variables"
    var_10 = "basename"
    var_11 = os.path.basename
    var_12 = var_11(var_0)
    var_13 = "__iter__"
    var_14 = "list"
    var_15 = []
    var_16 = "wantlist"
    var_17 = ":memory:"

# Generated at 2022-06-25 10:42:25.239946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = lookup_run(str_0, dict_0)

# Generated at 2022-06-25 10:42:29.781043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-'
    dict_0 = {str_0: str_0, str_0: lookup_module_0}
    var_0 = ['-', '-']
    assert var_0 == lookup_module_0.run(var_0, dict_0)
