

# Generated at 2022-06-25 10:33:01.741624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'*.txt']

# Generated at 2022-06-25 10:33:05.829752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert(lookup_module_0.run() == [])

# Generated at 2022-06-25 10:33:14.629897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:33:22.563005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dummy_var_0_0 = 'var_0_0'
    dummy_var_0_1 = {'any_path': 'path'}
    dummy_var_0_2 = 'var_0_2'
    dummy_var_0_3 = 'var_0_3'
    dummy_var_0_4 = 'var_0_4'
    dummy_var_0_5 = 'var_0_5'
    dummy_var_0_6 = 'var_0_6'
    dummy_var_0_7 = 'var_0_7'
    dummy_var_0_8 = 'var_0_8'
    dummy_var_0_9 = 'var_0_9'

# Generated at 2022-06-25 10:33:32.079023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    res = lookup_module.run([])
    assert len(res) == 0

    res = lookup_module.run(["not_exists"])
    assert len(res) == 0

if __name__ == "__main__":
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from unittest import TestLoader, TextTestRunner, TestSuite
    display = Display()
    loader = TestLoader()
    suite = TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(TestCase))
    suite.addTest(loader.loadTestsFromTestCase(test_case_0))
    runner = TextTestRunner(verbosity=3)
    result = runner.run(suite)

# Generated at 2022-06-25 10:33:40.592394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # empty term
    term_u0 = ""
    try:
        lookup_module_0.run(term_u0)
        assert False
    except AssertionError as e:
        pass

    # empty terms
    terms_u1 = []
    try:
        lookup_module_0.run(terms_u1)
        assert False
    except Exception as e:
        pass

    # not empty terms with empty term
    term_u2 = ""
    terms_u2 = [term_u2]
    try:
        lookup_module_0.run(terms_u2)
        assert False
    except Exception as e:
        pass

    # not empty terms with not empty term
    term_u3 = "testfile.txt"

# Generated at 2022-06-25 10:33:43.195852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([""]) == []
#
# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_0 = LookupModule()
#     assert lookup_module_0.run([""]) == [None]



# Generated at 2022-06-25 10:33:51.238136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # note:
    # the glob module has no unit tests
    # os.path.join and os.path.isfile have unit tests
    # the glob module does not raise exceptions in any cases
    # it's impossible to find a case for the exception AnsibleFileNotFound
    # because it is raised only when self.find_file_in_search_path() raises an exception
    def find_file_in_search_path(variables, lookup, path):
        raise AnsibleFileNotFound
    lookup_module_0 = LookupModule()
    lookup_module_0.find_file_in_search_path = find_file_in_search_path
    lookup_module_0.get_basedir = lambda variables: '/etc/playbooks'
    lookup_module_0.run(['not-existing'], {}) # exception not raised


# Generated at 2022-06-25 10:34:01.810455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['path of term', 'another path of term']
    variables = {'ansible_check_mode': False, 'ansible_search_paths': ['/path/to/files/files0', 'files1', 'files2'], 'ansible_python_interpreter': '/usr/bin/python3.6', 'ansible_playbook_python': '/usr/bin/python3.6'}
    res = lookup_module_0.run(terms, variables)
    assert res[0] == '/path/to/files/files0' or res[0] == 'files1' or res[0] == 'files2' or res[0] == 'path of term'
if __name__ == '__main__':
    test_case_0()
    test_Look

# Generated at 2022-06-25 10:34:08.359727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    test_run_0()
    test_run_1()
    test_run_2()
    test_run_3()
    test_run_4()
    test_run_5()


# Generated at 2022-06-25 10:34:18.569309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    idempotent_paths = [
        '/',
        '/thispathdoesnotexist/nogohere'
    ]
    idempotent_terms = [
        '*.txt',
        '/thispathdoesnotexist/nogohere/*.txt'
    ]
    expected_output = []
    lookup_module = LookupModule()
    variables = {}
    output = lookup_module.run(idempotent_terms, variables)
    assert output == expected_output
    # make sure we didn't create a file in /
    assert not os.path.isfile('/testingfile*')


# Generated at 2022-06-25 10:34:24.173206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(
        terms = [
            '/my/path/*.txt',
        ],
        variables = {
            'ansible_search_path': [
                '/my/path/',
            ],
        }
    )
    assert result is not None, \
        "Expected: 'Expected: not None', Actual: %s" % result


# Generated at 2022-06-25 10:34:29.175438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # print(lookup_module_1.run(['sample.j2','sample.yml'], ['ansible_search_path']))   # assertion error
    # print(lookup_module_1.run(['sample.j2','sample.yml'], ['ansible_search_path']))   # assertion error
    # print(lookup_module_1.run(['sample.j2','sample.yml'], ['ansible_search_path']))   # assertion error

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:34.730718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == [None]

# Generated at 2022-06-25 10:34:36.502579
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(["*"]) == []


# Generated at 2022-06-25 10:34:46.039139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'table*.conf'
    found_paths = []
    paths = ['/root/ansible/roles/NetApp/files/files','/root/ansible/roles/NetApp/files']
    for p in paths:
        found_paths.append(os.path.join(p, 'files'))
        found_paths.append(p)
    for dwimmed_path in found_paths:
        if dwimmed_path:
            globbed = glob.glob(os.path.join(dwimmed_path, term))
            term_results = [g for g in globbed if os.path.isfile(g)]

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:48.926724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        os.chdir('/usr')
        assert lookup_module_0.run(['ansible.cfg']) == '/etc/ansible/ansible.cfg'
    finally:
        os.chdir('/')

# Generated at 2022-06-25 10:34:54.264764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['test_case_5', 'test_case_6']
    variables_0 = {'ansible_search_path': ['/usr']}

    res = lookup_module_0.run(terms_0, variables_0)

    assert isinstance(res, list) is True
    assert len(res) == 2
    assert res[0] == to_text('test_case_5')
    assert res[1] == to_text('test_case_6')

# Generated at 2022-06-25 10:34:56.153813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []


# Generated at 2022-06-25 10:35:05.970037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[])
    lookup_module_0.run(terms=['',], variables={'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {}}}}}}})
    lookup_module_0.run(terms=['',], variables={'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variables': {'ansible_variable': {'ansible_variable': {'ansible_variable': {'ansible_variable': {}}}}}}}}}}}}})

# Generated at 2022-06-25 10:35:16.914409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.facts.system.path import get_bin_path

    # test with a single term
    term_0 = 'my_file'
    kwargs_0 = { 'wantlist': False }
    parameters_0 = {
        'ansible_search_path': [
            '/playbooks/files',
            '/playbooks'
        ]
    }
    expected_result_0 = '/my/path/my_file'
    result_0 = LookupModule().run(terms=[term_0], variables=parameters_0, **kwargs_0)
    assert expected_result_0 == result_0

    # test with multiple term
    terms_1 = ['my_file', 'my_file_2']
    kwargs_1 = { 'wantlist': True }

# Generated at 2022-06-25 10:35:27.146107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = '''
some data
more data
fooish data
    '''

    # test usual case, term is a file name
    args = [
        '/tmp/foo.txt',
        'files',
        'files/bar.txt',
        'files/baz.txt'
    ]
    with open(args[0], 'w') as f:
        f.write(data)
    lookup_module = LookupModule()
    files = lookup_module.run(args)
    assert files == ['/tmp/foo.txt']
    os.unlink(args[0])

    # test with lookup options

# Generated at 2022-06-25 10:35:33.216342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        "/playbooks/files/fooapp/*"
        ]
    variables = {
        'ansible_search_path': [
            "/playbooks/files/"
        ]
    }
    ret = lookup_module.run(terms, variables)
    assert ret == [ "/playbooks/files/fooapp/foo.conf" ]

# Generated at 2022-06-25 10:35:35.998358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'*.txt']
    kwargs_0 = {}
    try:
        lookup_module_0.run(terms_0, **kwargs_0)
    except NotImplementedError:
        pass



if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:38.464370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['./test/test.txt']) == ['./test/test.txt']


# Generated at 2022-06-25 10:35:47.600721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/my/path/*.txt']
    variables_1 = {'ansible_search_path': ['/usr/lib64', '/usr/lib'], 'playbook_dir': '/usr/lib/python2.7'}
    # Call template for run()
    result_1 = """['/my/path/*.txt']"""
    mock_result_1 = lookup_module_1.run(terms_1, variables_1)
    assert [result_1] == mock_result_1

# Generated at 2022-06-25 10:35:49.324260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["./doesnotexist/*/*/*.txt"], wantlist=True, variables={}) == []

# Generated at 2022-06-25 10:35:54.871742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["foo.txt"], {"ansible_play_hosts":{'foo': 'bar'}, "inventory_dir": '/test'})

# Generated at 2022-06-25 10:36:00.006986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/some/path/somefile.txt']
    ret = LookupModule().run(terms, None)
    assert ret[0]['src'] == '/some/path/somefile.txt'


# Generated at 2022-06-25 10:36:04.950484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('/etc/hosts', {}) == ['/etc/hosts']

# Generated at 2022-06-25 10:36:13.283669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["/home/vagrant/ansible/data/test_data/hello.txt"]
    variables_0 = "ansible_search_path"
    assert lookup_module_0.run(terms_0, variables_0) == ["/home/vagrant/ansible/data/test_data/hello.txt"]

# Generated at 2022-06-25 10:36:19.330211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # LookupModule.run() must return a list of strings
    lookup_module_0.run([], variables=None, wantlist=True)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:36:20.227771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run()

# Generated at 2022-06-25 10:36:26.436637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ["/usr/bin"]
    variables_2 = {}
    wantlist_3 = False
    ret = lookup_module_0.run(terms_1, variables_2, wantlist_3)
    assert ret

# Generated at 2022-06-25 10:36:30.099053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run('', '') == []

# Generated at 2022-06-25 10:36:35.071182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = __import__('os').path
    lookup_module_0 = LookupModule()
    lookup_module_0.get_basedir = lambda x: '/home/kpelelis/'
    lookup_module_0.find_file_in_search_path = lambda x, y, z: p.join('/home/kpelelis/', y)
    lookup_module_0.run(["test_fileglob_run.txt", "other_name.txt"], {})
    assert True

# Generated at 2022-06-25 10:36:41.321924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'*']
    variables = {}
    ret = lookup_module_0.run(terms, variables)
    # In Python2 'Scandinavian letters' (like å ä ö) are not sorted correctly by default by sort
    ret.sort(key = lambda x: to_bytes(x))
    assert ret == [u'ansible_async', u'ansible_debug', u'ansible_hosts', u'ansible_ssh_common_args', u'ansible_ssh_host', u'ansible_version', u'ansible_verbosity', u'ansible_version']


# Generated at 2022-06-25 10:36:46.976849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run(terms, variables)


# Generated at 2022-06-25 10:36:52.189072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = dict()
    kwargs_0 = dict()
    kwargs_0['wantlist'] = True
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []

    _terms0 = ['*.yml']
    assert lookup_module_0.run(_terms0) == []
    _terms1 = []
    assert lookup_module_0.run(_terms1) == []

# Generated at 2022-06-25 10:37:01.003082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = []
    variables = {}
    wantslist = True
    # LookupModule.run(terms, variables=None, **kwargs)
    # LookupModule.run(terms, variables=None, **kwargs)
    # LookupModule.run(terms, variables, **kwargs)
    # LookupModule.run(terms, variables, wantlist=True)
    # LookupModule.run(terms, variables, wantlist=False)
    # LookupModule.run(terms, variables, wantlist=True)
    # LookupModule.run(terms, variables, wantlist=True)
    # LookupModule.run(terms, variables, wantlist=True)
    # LookupModule.run(terms, variables, wantlist=True)
    # LookupModule.run(

# Generated at 2022-06-25 10:37:09.115963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = lookup_module.run(list("abcdefg"))
    assert False

# Generated at 2022-06-25 10:37:13.396987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['/home/ramesh/*'], variables={}) == []


# Generated at 2022-06-25 10:37:16.645600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['/some/path/somefile.txt']) == ['/some/path/somefile.txt']


# Generated at 2022-06-25 10:37:20.902974
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['*.txt']
    variables = {u'ansible_search_path': ['/home/user/Git/', '/home/user/Git1']}
    kwargs = {'wantlist': False}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:37:28.329484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["test_file_1.txt","test_file_2.txt"]
    variables = {"ansible_search_path":["test_files"],"files":"test_files"}
    result = lookup_module.run(terms,variables)
    assert result == [u'test_files/test_file_1.txt', u'test_files/test_file_2.txt']

# Generated at 2022-06-25 10:37:33.537578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [ term_1 ]
    variables_1 = { 'ansible_search_path': ansible_search_path_1, 'basedir': basedir_1 }
    res = lookup_module_1.run(terms_1, variables_1)
    assert res == []


# Generated at 2022-06-25 10:37:39.078622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    print(lookup_module_0.run(["/etc/hosts"], None, {}))


# Generated at 2022-06-25 10:37:42.500054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test with the following arguments
    term = '/my/path/*.txt'
    variables = None
    ret = ['/my/path/file3.txt', '/my/path/file1.txt', '/my/path/file2.txt']
    assert lookup_module_0.run([term], variables) == ret

# Generated at 2022-06-25 10:37:46.351287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    result = lookup_obj.run(['*.txt'], dict(), wantlist=True)
    assert list[list] == type(result)

    result = lookup_obj.run(['*.txt'], dict())
    assert list == type(result)


# Generated at 2022-06-25 10:37:50.952824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    print(lookup_module_1.run('/Users/Salman/Desktop/ansible-oss/ansible/lib/ansible', {'ansible_playbook_python': '/usr/bin/python'}))


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:38:01.807826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == [], "function run of class LookupModule returned incorrect value"

# Generated at 2022-06-25 10:38:04.999607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up
    module_name = 'fileglob'
    terms = ['/my/path/*.txt']
    variables = None
    kwargs = {'wantlist': True}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=terms, variables=variables, **kwargs)

# Generated at 2022-06-25 10:38:07.697396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['./test/data']) == []

# Generated at 2022-06-25 10:38:11.861546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/home/ansible/hosts']
    variables = None
    kwargs = dict()
    kwargs['wantlist'] = True
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result[0] == '/home/ansible/hosts'

# Generated at 2022-06-25 10:38:16.169215
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Try to run the run() method of the LookupModule class
    lookup_module_run = LookupModule()
    result = lookup_module_run.run(terms=['*.py'], variables={'ansible_search_path': ['../']})

    # Check the length of the results
    assert len(result) > 0

# Generated at 2022-06-25 10:38:25.265985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test expected error based on misformatted terms.
    lookup_module_1.run(None)

    # Test expected error based on misformatted terms.
    lookup_module_1.run('')

    # Test expected error based on misformatted terms.
    lookup_module_1.run('*')

    # Test expected error based on misformatted terms.
    lookup_module_1.run([])

    # Test expected error based on misformatted terms.
    lookup_module_1.run(dict())

    # Test expected error based on misformatted terms.
    lookup_module_1.run({'a': 'b'})

    # Test expected error based on misformatted terms.
    lookup_module_1.run(['a', 'b'])

    # Test

# Generated at 2022-06-25 10:38:34.268609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_12 = LookupModule()
    lookup_module_12.get_basedir = MagicMock()
    lookup_module_12.get_basedir.return_value = 'example_basedir'
    lookup_module_12.find_file_in_search_path = MagicMock()
    lookup_module_12.find_file_in_search_path.return_value = 'example_dwimmed_path'
    varargs_12 = ['example_term']
    varargs_13 = {'variables': 'example_variables'}
    varargs_14 = {'wantlist': True}
    varargs_15 = {'variables': 'example_variables', 'wantlist': True}
    varargs_16 = {}

# Generated at 2022-06-25 10:38:37.464552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Passes when args are correct
    assert lookup_module_1.run([1], [1]) == [1]
    # Fails when list of args is too short
    assert lookup_module_1.run([1]) == [1]
    # Fails when variables are not passed
    assert lookup_module_1.run([1], [1]) == [1]

# Generated at 2022-06-25 10:38:43.672329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    print(lookup_module_0.run(terms))

# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_0 = LookupModule()
#     terms = []
#     variables = {}
#     print(lookup_module_0.run(terms, variables))

# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_0 = LookupModule()
#     terms = []
#     variables = {}
#     print(lookup_module_0.run(terms, variables))

# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_

# Generated at 2022-06-25 10:38:48.697593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["*.txt"]
    variables = {'ansible_search_path': ["/playbooks/files/fooapp", "files", "/playbooks/files/fooapp/*"]}
    lookup_module.run(terms, variables)
    assert lookup_module is not None

# Generated at 2022-06-25 10:39:13.679611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    terms = ['/etc/ansible/test_file']
    variables = {'ansible_search_path':['/etc/ansible']}
    assert lookup_module_0.run(terms, variables) == ["/etc/ansible/test_file"]
    return None


# Generated at 2022-06-25 10:39:18.373542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['a', 'b']) == []


# Generated at 2022-06-25 10:39:20.609965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['*.txt'], variables={'foo': 'bar'})

# Generated at 2022-06-25 10:39:22.537152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    import json

    terms = json.load(open("terms.json"))
    variables = json.load(open("variables.json"))
    ret = lookup_module.run(terms, variables)
    assert ret == ['some_file.txt']

# Generated at 2022-06-25 10:39:31.256665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys, os
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib

    def get_basedir(variables):
        return '/abc/xyz'

    def get_vault_password(vault_password_files):
        return 'qwerty'

    def find_file_in_search_path(variables, file_name, path=None, vault_password=None, all_vars=None, expand=True):
        if file_name == 'files/lookupfile':
            return '/abc/xyz/files'

    lookup_module = LookupModule()
    lookup_module.get_basedir = get_basedir
    lookup_module

# Generated at 2022-06-25 10:39:32.075942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 10:39:36.040563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args = dict(
        terms=dict(
            type='str',
            required=True
        ),
        variables=dict(
            required=False
        )
    )

    lookup_module_0 = LookupModule()
    ret_val_0 = lookup_module_0.run(**module_args)

    assert ret_val_0 is None


# Generated at 2022-06-25 10:39:37.406068
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert test_case_0(), \
        "Ansible lookup fileglob.py should have some tests"

# Generated at 2022-06-25 10:39:40.966200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = lookup_module_0.run(terms=["tests/support/*.ini"], variables={"ansible_search_path":["."]})
    assert terms_0 == [u'tests/support/ansible.cfg', u'tests/support/groups', u'tests/support/hosts', u'tests/support/hosts.ini']

# Generated at 2022-06-25 10:39:46.805155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create LookupModule instance
    lookup_module = LookupModule()

    # Execute 'run' method
    # Term is a file, so the result should be list containing all files matching given pattern
    # i.e, path 'test/test_fileglob.py' is returned
    result = lookup_module.run(['test_fileglob.py'], {'ansible_playbook_python': '/usr/bin/python3'})
    assert result == ['test/test_fileglob.py']

    # Term is a directory, so the result should be list containing all files in that dir matching given pattern
    # i.e, path 'test/test_fileglob.py' is returned

# Generated at 2022-06-25 10:40:13.835630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up mock variables
    var_file = 'vV8Wxg}/sE1+\x0c/e8c'
    var_term = '\x1b\\?\x1a'
    var_variables = {'variables': {'variables': var_file}}
    var_terms = [var_term]
    obj = LookupModule()
    with pytest.raises(AnsibleFileNotFound):
        # Call the method
        obj.run(terms=var_terms, variables=var_variables)

# Generated at 2022-06-25 10:40:17.907613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.run("3z-/b\x00")


# Generated at 2022-06-25 10:40:24.356864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters
    # terms:
    str_0 = 'X(7Kp@\x0b(jMTt*3u'
    # variables:
    var_0 = lookup_run(str_0)
    # kwargs:

    lookup_module_1 = LookupModule()
    obj_0 = lookup_module_1.run(str_0, var_0)

# Generated at 2022-06-25 10:40:26.754046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'v(r_*fDl9dd\x0bQdf;'
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:40:30.309998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'X(7Kp@\x0b(jMTt*3u'
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:40:37.613481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'X(7Kp@\x0b(jMTt*3u'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(terms, variables = None, wantlist = True)
    assert(var_0 == None)



# Generated at 2022-06-25 10:40:39.968895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    str_0 = 'X(7Kp@\x0b(jMTt*3u'
    var_0.run(str_0)



# Generated at 2022-06-25 10:40:47.783357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    lookup_module_2 = LookupModule()
    terms = ['.bash_history']
    ret = lookup_module_2.run(terms)
  except Exception:
    pass
  try:
    lookup_module_3 = LookupModule()
    terms = ['*.txt']
    ret = lookup_module_3.run(terms)
  except Exception:
    pass
  try:
    lookup_module_4 = LookupModule()
    terms = ['Dockerfile']
    ret = lookup_module_4.run(terms)
  except Exception:
    pass
  try:
    lookup_module_5 = LookupModule()
    terms = ['com.apple.*.plist']
    ret = lookup_module_5.run(terms)
  except Exception:
    pass

# Generated at 2022-06-25 10:40:49.856243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assign
    terms_0 = 'lib'
    variables_0 = {'ansible_basedir': 'ansible'}
    # test
    LookupModule.run(terms_0, variables_0)


# Generated at 2022-06-25 10:40:51.598391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up instance of LookupModule class
    lookup_module_0 = LookupModule()
    # run method on instance with args
    lookup_module_0.run(terms)
