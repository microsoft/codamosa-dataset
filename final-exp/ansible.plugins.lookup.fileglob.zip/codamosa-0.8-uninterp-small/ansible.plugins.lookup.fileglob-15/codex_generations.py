

# Generated at 2022-06-25 10:32:50.317601
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    (args, kwargs) = ()
    kwargs = {'array':{'files':{'file1':{'mode':'octal'}}}}
    return LookupModule.run(args, kwargs)

# Generated at 2022-06-25 10:32:56.420291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}

    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print(ret_0)

# Generated at 2022-06-25 10:33:05.228174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = "X"
    str_1 = "X"
    str_2 = "W"
    str_3 = "Y"
    str_4 = "Z"
    str_5 = "U"
    str_6 = "V"
    str_7 = "V"
    str_8 = "U"
    str_9 = "W"
    str_10 = "Z"
    str_11 = "Y"
    lst_0 = ["Z", "Y", "W", "V", "U", "X"]

# Generated at 2022-06-25 10:33:07.445939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    case = LookupModule
    case.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 10:33:12.262937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    path_0 = os.path.join(os.path.realpath(os.path.dirname(__file__)), 'fileglob_test')
    term_0 = ['file1.txt', 'file2.txt']

    result = lookup_module_0.run(terms=[terms_0], variables=path_0)
    assert result == path_0

# Generated at 2022-06-25 10:33:21.762852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(bool_1)
    str_0 = 'fixtures/files/fileglob-test.txt'
    dict_0 = {'ansible_facts': {'search_path': ['fixtures/files', 'fixtures/files2']}, 'item': {'search_path': ['fixtures/files', 'fixtures/files2']}, 'ansible_search_path': ['fixtures/files', 'fixtures/files2']}
    result = lookup_module_0.run(str_0, dict_0)
    assert result == ['fixtures/files/fileglob-test.txt'] == result


# Generated at 2022-06-25 10:33:27.515996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = apply(LookupModule,())

    bool_0 = False
    dict_0 = {}
    list_0 = [None]
    str_0 = "/var/tmp/ansible_fileglob_payload_N1wWAj/ansible_fileglob_payload.py"

    # Parameters: 
    #  terms, variables
    # list (of path) returned

    dict_0["ansible_path_files"] = "/var/tmp/ansible_fileglob_payload_N1wWAj/files"
    dict_0["ansible_env"] = {}
    dict_0["ansible_playbook_python"] = "/usr/bin/python"
    dict_0["ansible_path_module_args"] = "fileglob"

# Generated at 2022-06-25 10:33:33.133044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("START: test_LookupModule_run")
    fileglob = LookupModule()
    terms = []
    terms.append('*.yml')
    fileglob.run(terms)
    print("END: test_LookupModule_run")

# driver program

# Generated at 2022-06-25 10:33:42.790087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    terms_0 = list()
    terms_0.append('terms_0')
    terms_0.append('terms_1')
    terms_0.append('terms_2')
    variables_0 = dict()
    dictionary_0 = dict()
    dictionary_0['files'] = 'files_0'
    dictionary_0['playbooks'] = 'playbooks_0'
    variables_0['ansible_search_path'] = dictionary_0
    variables_0['ansible_search_path:files'] = 'files_0'
    variables_0['ansible_search_path:playbooks'] = 'playbooks_0'
    del dictionary_0['files']
    del dictionary_0['playbooks']

# Generated at 2022-06-25 10:33:44.233250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:33:50.911546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _module = ModuleStub()
    _module.params = dict(a=1)
    out = _module.run()
    assert out == (1, dict(a=1), dict())



# Generated at 2022-06-25 10:34:01.668561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_1 = None
    var_2 = None

    lookup_0 = LookupModule()
    var_0 = [
        "/etc/*.conf"
    ]

    # args
    var_1 = {}
    var_2 = None

    # method to test
    ret_0 = lookup_0.run(var_0, var_1, **var_2)
    if ret_0 !=["/etc/fstab", "/etc/services", "/etc/nsswitch.conf"]:
        return 1
    return 0
# Local variables:
# mode: shell-script
# sh-basic-offset: 4
# sh-indent-comment: t
# indent-tabs-mode: nil
# End:
# ex: ts=4 sw=4 et filetype=sh

# Generated at 2022-06-25 10:34:08.322736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_1 = None
    lookup_obj = LookupModule()
    lookup_obj.run(var_0, var_1)

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 10:34:09.518899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = None
    var_2 = None
    obj_1 = LookupModule()
    obj_1.run(var_1, var_2)

# Generated at 2022-06-25 10:34:12.131974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = None
    var_0 = LookupModule(var_1)
    var_2 = None
    var_3 = None
    var_0.run(var_2, var_3)

# Generated at 2022-06-25 10:34:22.081323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_

# Generated at 2022-06-25 10:34:23.876646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = var_0
    variables = None

# Generated at 2022-06-25 10:34:26.659520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = None
    # case 0
    if str(type(var_0)) != "<type 'NoneType'>":
        ret = lookup_module.run(var_0)
        assert type(ret) == list
        assert ret == []

# Generated at 2022-06-25 10:34:37.470729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 10:34:44.885841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = os.path.join(os.path.dirname(__file__), 'test.txt')
    l = LookupModule()
    l.get_basedir = lambda x: os.path.dirname(__file__)
    l.find_file_in_search_path = lambda x, y, z: os.path.dirname(__file__)
    assert l.run([var_0]) == [var_0]
    assert l.run(['test.txt']) == [var_0]
    assert l.run(['*.txt']) == []
    assert l.run(['*.txt', '*.txt']) == []

# Generated at 2022-06-25 10:34:52.552090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test: method run of class LookupModule")
    fd = open('data.json', 'r')
    var_0 = fd.read()
    fd.close()
    inst_LookupModule = LookupModule()
    cfg = {"_raw_params": var_0}
    inst_LookupModule.set_options(cfg)
    res_0 = inst_LookupModule.run(["path_0"])
    print(res_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:55.480594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.parsing.dataloader import DataLoader

  loader = DataLoader()
  lookup_base_0 = LookupBase()
  lookup_module_0 = LookupModule()
  var_0 = test_case_0()
  terms = ['/my/path/*.txt']
  variables = {}
  kwargs = {}
  ret = lookup_module_0.run(terms, variables=variables, **kwargs)
  assert(ret == [])



# Generated at 2022-06-25 10:34:56.633018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case = '0'
    var_0 = None


# Generated at 2022-06-25 10:35:05.856874
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # this is how we usually instantiate a class in Python
    test_obj = LookupModule()

    # method run is called with these arguments
    # run(self, terms, variables=None, **kwargs):
    var_arg_0 = ['*.txt']
    var_arg_1 = 'foo1'
    var_arg_2 = 'foo2'
    var_arg_3 = 'foo3'
    var_arg_kwargs = {
        'f': 'a',
        'b': 'a',
        'c': 'a'
    }

    # call test method
    test_obj.run(var_arg_0, var_arg_1, var_arg_2, var_arg_3, **var_arg_kwargs)

# Generated at 2022-06-25 10:35:10.175809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {
        'repo_path' : 'example.com/repo', 
        'repo_name' : 'repo'
    }

    l = LookupModule()

    l.run('example.com/repo', var_0)

# Generated at 2022-06-25 10:35:17.462555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 10:35:21.635676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '3*3.14'
    obj = LookupModule()
    var_1 = obj.run([var_0])
    assert var_1 == []


# Generated at 2022-06-25 10:35:25.566734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    # Tries to run the method
    res = run(var_0, )
    # result = run(var_0, )


# Unit test 

# Generated at 2022-06-25 10:35:28.928174
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    arg_map = {
        "terms": "terms_0",
        "variables": "var_0"
    }

    test_obj = LookupModule()
    test_obj.run(**arg_map)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:35:30.055192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:35:39.627718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = None
    var_2 = None
    var_3 = None

    def new_run(terms, variables=None, **kwargs):
        terms = terms
        variables = variables
        kwargs = kwargs
        var_1 = None
        return var_1
    var_0.run = new_run
    var_1 = var_0.run(var_1, var_2, var_3)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:45.659510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_path = os.path.dirname(os.path.realpath(__file__))

    print(LookupModule().run(terms=[os.path.join(test_path, 'fileglob_test.py')]))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:35:54.029831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test that the module can run when the test vars are not set
    var_1 = None
    var_2 = None
    var_3 = None
    test_case_0()

    # test when the var_1 is set to a value
    var_1 = "test value"
    test_case_0()

    # test when the var_1 is set to a different value
    var_1 = "another test value"
    test_case_0()

    # test when the var_2 is set to a value
    var_2 = "test value"
    test_case_0()

    # test when the var_2 is set to a different value
    var_2 = "another test value"
    test_case_0()

    # test when the var_3 is set to a value

# Generated at 2022-06-25 10:36:00.606966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_0 = LookupModule()
    ret = var_0.run()
    if ret is None or ret != "":
        print("LookupModule.run does not return expected value")
    else:
        print("LookupModule.run returned expected value")


# Generated at 2022-06-25 10:36:01.874004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.run(var_0)

# Generated at 2022-06-25 10:36:12.669578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_0 = LookupModule()
    var_1 = [u'./ansible/module_utils/urls.py', u'./ansible/modules/packaging/os/yum.py', u'./ansible/modules/system/copy.py', u'./ansible/modules/system/service.py', u'./ansible/modules/system/setup.py', u'./ansible/modules/system/stat.py', u'./ansible/modules/system/user.py', u'./ansible/modules/system/yum.py', u'./ansible/parsing/dataloader.py']
    var_2 = dict()
    var_2[u'playbook_dir'] = u'./'
    var_2[u'_original_file'] = u

# Generated at 2022-06-25 10:36:18.981121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_class = LookupModule(var_0)
    var_1 = ['var_1']
    var_2 = {}
    var_return = lookupModule_class.run(var_1, var_2)
    var_expected = []
    var_expected = var_expected
    assert var_return == var_expected

# Generated at 2022-06-25 10:36:23.639106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_0 = LookupModule()
    #Unit test for line # 8 "fileglob.py", line 8
    var_1 = None
    #Unit test for line # 9 "fileglob.py", line 9
    var_2 = None
    #Unit test for line # 10 "fileglob.py", line 10
    var_3 = None
    #Unit test for line # 11 "fileglob.py", line 11
    var_0.run(var_1, var_2)

# Generated at 2022-06-25 10:36:27.426050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    args = range(0)
    if len(args) == 0:
        ansible_options = None
    elif len(args) == 1:
        ansible_options = args[0]

    ansible_options = test_case_0()
    l = LookupModule(ansible_options)
    print(l.run())

# Generated at 2022-06-25 10:36:34.179714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = [u"C:\\Users\\lucas\\Documents/test-convert"]
    var_2 = None
    var_3 = {"ansible_search_path": ["C:\\Users\\lucas\\Documents/test-convert"]}

    var_4 = None

    var_4 = var_0.run(var_1, var_2, **var_3)
    assert var_4 == u"C:\\Users\\lucas\\Documents/test-convert/test-convert.txt"

# Generated at 2022-06-25 10:36:47.852364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = "lookup"
    var_1 = "__main__"
    var_2 = "__builtin__"
    var_3 = "to_bytes"
    var_4 = "to_text"
    var_5 = "AnsibleFileNotFound"
    var_6 = "AnsibleLookupFailure"
    var_7 = "AnsibleUnicodeDecodeError"
    var_8 = "foreach"

    lu = LookupModule()
    assert len(lu._plugins) == 1, "Test #0 failed"
    assert lu.run(var_0).__class__ is list, "Test #1 failed"
    assert lu.run(var_0).__class__ is list, "Test #2 failed"

# Generated at 2022-06-25 10:36:48.711374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# vim: expandtab

# Generated at 2022-06-25 10:36:58.379737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_

# Generated at 2022-06-25 10:37:00.459138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    var_0 = None
    lu.run(var_0)


# Generated at 2022-06-25 10:37:04.528370
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declaration of variables
    lookup_module_0 = None
    terms = None
    variables = None
    kwargs = None
    ret = None

    # Assigning values to variables.
    lookup_module_0 = LookupModule()
    terms = var_0
    variables = var_0
    kwargs = var_0

    # Invoking method run of class LookupModule.
    ret = lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:37:13.527405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance_0 = LookupModule()
    var_0 = ['/home/a_dir', '/home/b_dir']
    var_1 = 'ansible_search_path'
    var_2 = 'files'
    var_3 = '/home/a_dir/file'
    var_4 = '/home/a_dir/file'
    var_5 = '/home/b_dir/file'
    var_6 = '/home/b_dir/file'
    var_7 = '/home/b_dir/file'
    var_8 = ['file']
    var_9 = '/home/a_dir'
    var_10 = '/home/b_dir'
    var_11 = '/home/b_dir'
    var_12 = '/home/b_dir/file'
    var_

# Generated at 2022-06-25 10:37:19.806474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test environment
    var_0 = None
    var_1 = None
    # Set up test environment
    term_0 = None
    variables_0 = None
    kwargs_0 = {}
    # Call method to test
    ret_0 = LookupModule(var_0, var_1).run(term_0, variables_0, **kwargs_0)
    assert ret_0
    # Return test result
    return ret_0


# Generated at 2022-06-25 10:37:30.947245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # this one works
    var = {}
    var['vars'] = {}
    var['vars']['ansible_search_path'] = ['/foo', '/bar', '/baz']
    var['vars']['playbook_dir'] = '/playbooks'
    lookup_module = LookupModule()
    ret = lookup_module.run([
        '/playbooks/files/fooapp/*',
        '*.txt',
        'my_file.txt',
        'my_file.cfg',
        'my_file_does_not_exist.txt',
    ], variables=var)

# Generated at 2022-06-25 10:37:34.200942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_instance = LookupModule()
    class_instance.run(terms, variables)


# Generated at 2022-06-25 10:37:38.691024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert 1 == 1


# Generated at 2022-06-25 10:37:49.389913
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:37:53.663054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No pattern given
    term_0 = []
    # No other input
    var_0 = None
    # No output
    var_0 = None
    # Function call
    def test_0():
        pass
    test_0()


# Generated at 2022-06-25 10:37:57.985298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_2 = '/home/user/playbook.yml'
    var_1 = None
    var_3 = None
    obj = LookupModule()
    var_4 = obj.run(var_0, var_1, var_2, var_3)
    print(var_4)

# Generated at 2022-06-25 10:37:58.855796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert var_0 == None


# Generated at 2022-06-25 10:38:00.243785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:38:01.621496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.run(var_0)

# Generated at 2022-06-25 10:38:04.349642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = None
    var_2 = ["/playbooks/files/fooapp/*"]
    var_3 = {"files":"files"}
    var_0.run(var_1, var_2, var_3)


# Generated at 2022-06-25 10:38:14.182165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_29 = None
    var_

# Generated at 2022-06-25 10:38:19.430397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ""
    var_1 = [var_0]
    var_2 = "my/path/*.txt"
    var_3 = var_1.append(var_2)
    var_4 = None
    var_5 = LookupModule(loader, var_4, var_4, var_4, var_4)
    var_6 = var_5.run(var_1)
    assert isinstance(var_6, list)


# Generated at 2022-06-25 10:38:22.708909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # Test for case 0 
    # set up variable 'var_0'
    var_0 = None
    l.run(var_0)




# Generated at 2022-06-25 10:38:31.625885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:38:33.290697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'WgT8lV/sHt'
    str_1 = 'z8e[~'
    var_0 = lookup_run(str_0)
    var_1 = lookup_run(str_1)


# Generated at 2022-06-25 10:38:37.609369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	assert lookup_run('/etc/passwd') == '/etc/passwd'


# Generated at 2022-06-25 10:38:41.960747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 10:38:48.997008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests the variable
    var_0 = 'X9Q%@HL4ih4'
    # Tests the variable
    var_1 = 'S\x7f*Z\x1c\x0f\n\x18\x17\x13\x1e\x1a\x02\x06\x06\n'
    # Tests the variable
    var_2 = 'w6Ubc8(UW'
    # Tests the variable

# Generated at 2022-06-25 10:38:53.932677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'yh[Ji*[7V7yh'
    var_1 = lookup_module_1.run(str_1)


# Generated at 2022-06-25 10:38:57.859958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:39:00.482633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    path = 'test/test_file'
    ret = lookup_module.run('test_file')
    assert ret == [path]


# Generated at 2022-06-25 10:39:07.369072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('my.ini', {'inventory_file': 'test_file'})
    ansible_list_0 = ['.test_file.test_file', '.test_file.test_file']
    assert var_0 == ansible_list_0


# Generated at 2022-06-25 10:39:12.152241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = 'H-LNN7qhXg&[VGG'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:39:23.224711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    path_0 = '/etc/ansible/ansible.cfg'
    path_1 = '/var/lib/awx/projects/test/'
    path_2 = '/etc/ansible/ansible.cfg'
    path_3 = '/var/lib/awx/projects/test/'
    dict_0 = dict()
    dict_0['ansible_search_path'] = [path_0, path_1, path_2, path_3]
    dict_1 = dict()
    dict_1['ansible_search_path'] = dict_0['ansible_search_path']

# Generated at 2022-06-25 10:39:26.151622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:39:29.004819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run()

# Generated at 2022-06-25 10:39:31.974081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj_0 = LookupModule()
    lookup_obj_0.run(['fact'], {'ansible_local': {'foo': 'bar'}})

import argparse
from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 10:39:34.462950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = lookup_run(str_0)
    return var_0


# Generated at 2022-06-25 10:39:37.631020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Jb*[7V7Jb'
    var_0 = getattr(lookup_module_0, 'run')(str_0)
    var_1 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:39:41.343213
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	lookup_module_0 = LookupModule()
	str_0 = "unit_test/test_case_0"
	var_0 = lookup_run(str_0)
	if var_0 == str_0:
		print('test_case_0')
	else:
		print('error test_case_0')


if  __name__ == '__main__':
	test_LookupModule_run()

# Generated at 2022-06-25 10:39:49.533731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    list_0 = lookup_run(str_0)
    assert len(list_0) == 0
    assert len(list_0[0]) == 0
    assert len(list_0[1]) == 0
    assert len(list_0[2]) == 0
    assert len(list_0[3]) == 0
    assert len(list_0[4]) == 0
    assert len(list_0[5]) == 0
    assert len(list_0[6]) == 0
    assert len(list_0[7]) == 0
    assert len(list_0[8]) == 0
    assert len(list_0[9]) == 0


# Generated at 2022-06-25 10:39:51.341885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var_0 = lookup_module_0.run(str_0)
    assert (test_var_0 == var_0)

# Generated at 2022-06-25 10:39:54.138174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
      lookup_module = LookupModule()
      str = 'Xa1}Q[gI6Ll'
      var = lookup_run(str)
      if var != str:
          print(var)



# Generated at 2022-06-25 10:40:00.088768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, 'run'))



# Generated at 2022-06-25 10:40:03.630694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = ''
    var_1 = lookup_run(str_0)
    assert var_1 == var_0
    
    

# Generated at 2022-06-25 10:40:10.758768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupBase()
    var_0 = lookup_module_obj_0.run('q(m9>8@')
    var_1 = lookup_module_obj_0.run('q(m9>8@')
    var_2 = lookup_module_obj_0.run('q(m9>8@')
    var_3 = lookup_module_obj_0.run('q(m9>8@')
    assert var_0 == var_1 == var_2 == var_3


# Generated at 2022-06-25 10:40:14.913340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os = Windows()
    lookup_module = LookupModule()
    assert lookup_module.run() == 'o'


# Generated at 2022-06-25 10:40:19.166754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'DU@.'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:40:21.483728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '#k>|CZ'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:40:25.517874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_2 = 'IG@Px{A9yh'
    var_2 = lookup_run(str_2)
    str_2 = var_2
    str_2 = 'B6iws>;D'
    var_2 = lookup_run(str_2)
    str_2 = var_2
    str_2 = 'C'
    var_2 = lookup_run(str_2)
    str_2 = var_2
    str_2 = 'Bh3q7V:p'
    var_2 = lookup_run(str_2)
    str_2 = var_2
    str_2 = ' '
    var_2 = lookup_run(str_2)
    str_2 = var_2

# Generated at 2022-06-25 10:40:34.797701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:40:44.998745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '8&3q!%n+o_d'
    var_0 = lookup_run(str_0)
    str_1 = 'f`|'
    var_1 = lookup_run(str_1, self=str_0)
    str_2 = 'xK)XPysFhB'
    var_2 = lookup_run(str_2, self=str_0)
    str_3 = "Z2'[4J4*K6:&X6N.E-a0*]"
    var_3 = lookup_run(str_3, self=str_0)
    str_4 = 'E0y6o$Sao'
    var_4 = lookup_run(str_4, self=str_0)
    str

# Generated at 2022-06-25 10:40:50.662118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # AssertionError: TypeError: find_file_in_search_path() missing 1 required positional argument: 'search_path' 
    
    str_0 = '2yL-bYOs/eH0w/'
    str_1 = '*z%%9l'
    lookup_run(str_0, str_1)
    # AssertionError: TypeError: run() missing 1 required positional argument: 'variables' 
    
    str_0 = 'P^o'
    str_1 = 'U1I'
    dict_0 = {str_0 : {'ansible_search_path': [str_1]}}
    lookup.run(str_0, dict_0)

# Generated at 2022-06-25 10:41:08.806947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # matches all files in a single directory, non-recursively, that match a pattern
    lookup_module_0 = LookupModule()
    str_0 = '7Vu)&A4,$4[yh'
    str_1 = '*XQ,7dD?x!ZXV7*u'
    assert len(lookup_module_0.run(str_0, str_1, wantlist=False)) == 0


# unit test for path find_file_in_search_path
# return the first file found in the search path

# Generated at 2022-06-25 10:41:18.658060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run('yh[Ji*[7V7yh', 'k(*J*h2wAp6Y')
    lookup_module_1.run('yh[Ji*[7V7yh', 'k(*J*h2wAp6Y', 'wAp6Yord')
    lookup_module_1.run('yh[Ji*[7V7yh', 'k(*J*h2wAp6Y', 'wAp6Yord', 'kw')
    lookup_module_1.run('yh[Ji*[7V7yh', 'k(*J*h2wAp6Y', 'wAp6Yord', 'kw', '1')

# Generated at 2022-06-25 10:41:22.563451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_0 = LookupModule()
    var_0 = 'YQLC3_z[K`Qyh'
    lookup_instance_0.run(var_0)


# Generated at 2022-06-25 10:41:25.030752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_var = LookupModule()
    var_var = 'hTk*R[6T,U6:9'
    var_var = lookup_run(var_var)

# ok decompiling -3 -2 -1

# Generated at 2022-06-25 10:41:26.601776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'zV7zV7zV7zV'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:41:28.364995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = lookup_run(str_0)
    if var_0 == str_0:
        print("")
    else:
        print(var_0)


# Generated at 2022-06-25 10:41:29.268229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == lookup_run()

# Unit tests of LookupModule class is implemented in plugin/lookup/fileglob.py

# Generated at 2022-06-25 10:41:31.333801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if test_case_0():
        pass
    else:
        print('Test case 1 failed')

if __name__ == '__main__':
    #Assigning values for the arguments
    arg_len = 2
    arg_0 = 'yh[Ji*[7V7yh'
    arg_1 = None
    #Calling the test functions
    test_LookupModule_run()

# Generated at 2022-06-25 10:41:33.190063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '/usr/local/bin/ansible-playbook'
    var_0 = lookup_module_0.run(str_0)
    assert type(var_0) == list, 'unit.run() not returning a list'

# Generated at 2022-06-25 10:41:38.554015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:41:52.199709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    assert_equals(lookup_run(str_0), lookup_module_0.run(str_0))



# Generated at 2022-06-25 10:41:58.245069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Zl4'
    var_0 = lookup_module_0.run(str_0)
    str_1 = '^t'
    var_1 = lookup_module_0.run(str_1)
    str_2 = 'A'
    var_2 = lookup_module_0.run(str_2)
    str_3 = 'Vu'
    var_3 = lookup_module_0.run(str_3)
    str_4 = 'JX'
    var_4 = lookup_module_0.run(str_4)
    str_5 = 'j'
    var_5 = lookup_module_0.run(str_5)
    str_6 = 'Y'

# Generated at 2022-06-25 10:42:00.316546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookups.run('yh[Ji*[7V7yh') == None
    #assert isinstance(lookups.run('yh[Ji*[7V7yh'), list)

# Generated at 2022-06-25 10:42:06.061463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'xr*[0H_,Xi1'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:42:11.357971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = lookup_run(str_0)


# def test_case_1():
#     lookup_module_1 = LookupModule()
#     str_0 = '0'
#     str_1 = '0'
#     var_0 = lookup_run(str_0, str_1)
#
# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_1 = LookupModule()
#     str_0 = '0'
#     str_1 = '0'
#     var_0 = lookup_run(str_0, str_1)

# Generated at 2022-06-25 10:42:14.266478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_1 = 'yh[Ji*[7V7yh'
    var_1 = lookup_run(str_1)
    assert var_1 == None


# Generated at 2022-06-25 10:42:19.591132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'yh[Ji*[7V7yh'
    var_0 = lookup_run(str_0)
    # Test to make sure that search paths return the right one
    var_1 = lookup_run('hello.txt')
    ret = var_1
    var_2 = lookup_run('noexist.txt')
    # Test to ensure that the right file is chosen
    var_3 = lookup_run('foo')
    assert(ret == var_3)

# test of higher level method to ensure that fileglob works when
# looking at a glob, not a full path

# Generated at 2022-06-25 10:42:27.937154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # One possible pass case
    str_1 = 'yh[Ji*[7V7yh'
    var_1 = lookup_run(str_1)
    # Another possible pass case
    str_2 = 'yh[Ji*[7V7yh'
    var_2 = lookup_run(str_2)
    # One possible pass case
    str_3 = 'yh[Ji*[7V7yh'
    var_3 = lookup_run(str_3)
    # One possible pass case
    str_4 = 'yh[Ji*[7V7yh'
    var_4 = lookup_run(str_4)
    # One possible pass case

# Generated at 2022-06-25 10:42:29.062992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    param_0 = 'yh[Ji*[7V7yh'
    lookup_module_0 = LookupModule()
    lookup_module_0.run(param_0)

# Generated at 2022-06-25 10:42:33.331094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # str_0 = 'yh[Ji*[7V7yh'
    # var_0 = lookup_run(str_0)
    # assert var_0 == None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:42:52.052495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'S6;<*}7'
    get_all_searches = lookup_module_0.run(str_0, (None,), wantlist=True)
    assert (len(get_all_searches) == 3)
    str_1 = 'E)#Km,l'
    var_0 = lookup_run(str_1)
    assert (var_0 == ['./file0015', './file0016', './file0017'])
    str_2 = '5&5#bY}r8^'
    var_1 = lookup_run(str_2, (None,), wantlist=True)