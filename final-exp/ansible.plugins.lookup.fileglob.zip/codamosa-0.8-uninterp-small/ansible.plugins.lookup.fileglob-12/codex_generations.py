

# Generated at 2022-06-25 10:32:55.522711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization of test environment
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run()


# Generated at 2022-06-25 10:33:01.911038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = lookup_module_0.run(['path_0'])
    str_1 = lookup_module_0.run(['path_1'])
    str_2 = lookup_module_0.run(['path_2'])
    assert str_0.__eq__(['path_0'])
    assert str_1.__eq__(['path_1'])
    assert str_2.__eq__(['path_2'])

# Generated at 2022-06-25 10:33:13.422115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    assert isinstance(lookup_module_0.run(["/etc/sudoers", "/etc/resolv.conf"], None), list)
    assert isinstance(lookup_module_0.run([], None), list)
    assert isinstance(lookup_module_0.run([]), list)
    assert isinstance(lookup_module_0.run(["/etc/sudoers", "/etc/resolv.conf"], None), list)
    assert isinstance(lookup_module_0.run(["/etc/sudoers", "/etc/resolv.conf"], None, []), list)
    assert isinstance(lookup_module_0.run(["/etc/sudoers", "/etc/resolv.conf"], None, kwargs={}), list)

# Generated at 2022-06-25 10:33:21.879140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test run method of LookupModule")
    variable_0 = {}
    variable_1 = ['file1.txt', 'file2.txt']
    variable_2 = 'file1.txt'
    variable_3 = 'file2.txt'
    variable_4 = 'file3.txt'
    variable_5 = 'file4.txt'
    variable_6 = 'file5.txt'
    variable_7 = 'file6.txt'
    variable_8 = 'file7.txt'

    # Cases
    # Unused -> term = ["file1.txt", "file2.txt"], wantlist = True
    # Unused -> term = ["file1.txt", "file2.txt"], wantlist = False
    # Used -> term = ["file1.txt", "file2.txt"], wantlist = True

    lookup_

# Generated at 2022-06-25 10:33:25.099924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)


# Generated at 2022-06-25 10:33:30.089561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"ansible_search_path": ["tmp"]}
    lookup_module_0 = LookupModule(dict_0)
    term = "/tmp/main.yml"
    variables = dict_0
    terms_0 = ["/tmp/main.yml"]
    kwargs = {}
    ret = lookup_module_0.run(terms, variables, **kwargs)
    assert ret == term

# Generated at 2022-06-25 10:33:35.791531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = [""]
    dict_1 = {}
    dict_1['ansible_search_path'] = [""]
    variables_0 = dict_1
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == []

# Generated at 2022-06-25 10:33:38.733403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = []
    variables_0 = {}
    list_1 = lookup_module_0.run(list_0, variables_0)

# Generated at 2022-06-25 10:33:41.807865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    terms_0 = ['./*']
    variables_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    result_0 = lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:33:43.859079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = "/etc/hosts"
    list_0 = [str_0]
    list_1 = lookup_module_0.run(list_0)
    assert len(list_1) == 1


# Generated at 2022-06-25 10:33:51.146941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    terms = ['./file_that_does_not_exist.txt']
    ret = lookup_module_0.run(terms, {})
    assert ret == []

# Generated at 2022-06-25 10:34:01.048198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    dict_0 = {'example_directory': '/etc/ansible/facts.d/', 'example_file': '/etc/ansible/facts.d/foo.fact'}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = ['/etc/ansible/facts.d/foo.fact', '/etc/ansible/facts.d/foo.fact']
    list_1 = []
    list_2 = []
    # testcase
    ret = lookup_module_0.run(list_0, variables=dict_0, wantlist=True)
    assert ret[0] == list_1
    assert ret[1] == list_2


# Generated at 2022-06-25 10:34:09.903864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = set()
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)
    dict_1 = {}
    lookup_module_1 = LookupModule(dict_1)
    terms_1 = set()
    variables_1 = {}
    lookup_module_1.run(terms_1, variables_1)
    dict_2 = {}
    lookup_module_2 = LookupModule(dict_2)
    terms_2 = {'xekyb'}
    variables_2 = {}
    lookup_module_2.run(terms_2, variables_2)
    dict_3 = {}
    lookup_module_3 = LookupModule(dict_3)
    terms

# Generated at 2022-06-25 10:34:16.830562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    kwargs_0 = {}
    x = lookup_module_0.run(terms_0, **kwargs_0)
    assert x == []
    terms_0 = ['/my/path/*.txt']
    kwargs_0 = {}
    x = lookup_module_0.run(terms_0, **kwargs_0)
    assert x == ['/my/path/*.txt']
    terms_0 = ['playbooks/files/fooapp/*']
    kwargs_0 = {}
    x = lookup_module_0.run(terms_0, **kwargs_0)
    assert x == ['playbooks/files/fooapp/*']


# Generated at 2022-06-25 10:34:22.463864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = ( 'test/test_case_0', )
    variables_0 = {}
    varargs_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0)

# Generated at 2022-06-25 10:34:26.989593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [""]
    var_1 = {}
    lookup_module_0.run(var_0, var_1)
    lookup_module_0.run(var_0, var_1)
    lookup_module_0.run(var_0, var_1)
    lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 10:34:37.685185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_file_0 = os.path.join('test', 'ansible_test_fileglob_0.txt')
    test_file_1 = os.path.join('test', 'ansible_test_fileglob_1.txt')
    test_file_2 = os.path.join('test', 'ansible_test_fileglob_2.txt')
    test_file_3 = os.path.join('test', 'ansible_test_fileglob_3.txt')
    test_file_4 = os.path.join('test', 'ansible_test_fileglob_4.txt')
    test_file_5 = os.path.join('test', 'ansible_test_fileglob_5.txt')

# Generated at 2022-06-25 10:34:40.871129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(dict_0)

    assert lookup_module_0.run() == [], "return value: " + lookup_module_0.run()

# Generated at 2022-06-25 10:34:47.560492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = ["files/logrotate"]
    variables_0 = {}
    kwargs_0 = {}
    assert ['files/logrotate'] == lookup_module_0.run(terms_0, variables=variables_0, **kwargs_0)


# Generated at 2022-06-25 10:34:51.613871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f_glob = ["*.yml", "*.txt"]
    lookup_module_0 = LookupModule({'vars': {'playbooks_dir': "playbooks/"}}, basedir='playbooks/')
    res = lookup_module_0.run(f_glob)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:59.883522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #assert lookup_module_0.run(1,2) == 3
    assert lookup_module_0.run(['./Data/plugins/lookup/README.md'],None) != []

# Generated at 2022-06-25 10:35:07.666173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    assert lookup_module_0.run(terms, variables) == []

    terms = ["/home/ec2-user/myansible_rus/ansible-examples/files/test_file.txt"]
    variables = dict(**{"_original_file": "/home/ec2-user/myansible_rus/ansible-examples/files/fileglob.yml",
                        "_original_file_name": "fileglob.yml"})
    assert lookup_module_0.run(terms, variables) == ["/home/ec2-user/myansible_rus/ansible-examples/files/test_file.txt"]

# Generated at 2022-06-25 10:35:16.914728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_basedir('/home/')
    variables = {'ansible_search_path': ['/home/abcd/a/b/c/d']}
    terms = ['lookup_module.py']
    res = lookup_module.run(terms, variables=variables)
    assert res == ['/home/abcd/a/b/c/d/lookup_module.py'], "Incorrect output running test_LookupModule_run"
    terms = ['/home/abcd/a/b/c/d/lookup_module.py']
    res = lookup_module.run(terms, variables=variables)

# Generated at 2022-06-25 10:35:21.098129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    data = ["ansible-*.log"]
    result = lookup_module_0.run(data)
    assert result == []


# Generated at 2022-06-25 10:35:25.803314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['*.yml', 'abc.txt']
    variables = {}
    ret = lookup_module_0.run(terms, variables)
    assert ret

# Generated at 2022-06-25 10:35:28.007876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # No-op use only for making sure pytest doesn't complain about missing test cases
    assert True

# Generated at 2022-06-25 10:35:38.549424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0 = ['/my/path/test_file_0.txt', '/my/path/test_file_1.txt', '/my/path/test_file_2.txt']
    term_file_0 = 'test_file_0.txt'
    term_file_1 = 'test_file_1.txt'
    term_file_2 = 'test_file_2.txt'
    found_paths_0 = []
    if term_file_0 != '/my/path/test_file_0.txt':
        found_paths_0.append('/my/path/')
    found_paths_1 = []
    if term_file_1 != '/my/path/test_file_1.txt':
        found_paths_1.append

# Generated at 2022-06-25 10:35:47.059306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['/etc/passwd'])
    assert result[0] == '/etc/passwd'
    result = lookup_module_0.run(['/etc/passwd', '/etc/ssl'])
    assert set(result) == set(['/etc/passwd', '/etc/ssl'])
    result = lookup_module_0.run([''])
    assert len(result) == 0

# Generated at 2022-06-25 10:35:52.228590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ''
    from ansible.module_utils.six import PY3
    if PY3:
        try:
            lookup_module.run(terms, None)
        except TypeError as e:
            assert 'run' in e.args[0]
    else:
        try:
            lookup_module.run(terms, None)
        except TypeError as e:
            assert 'run' in e.message

# Generated at 2022-06-25 10:35:59.220332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()

  #case0:
  terms_0 = list()
  variables_0 = dict()
  variables_0['ansible_cwd'] = '/etc/ansible'
  variables_0['ansible_env'] = {'LANGUAGE': 'en_US.UTF-8'}
  variables_0['ansible_search_path'] = ['/etc/ansible/']
  variables_0['ansible_user_id'] = 'root'
  kwargs_0 = {'variables': variables_0}
  ret_0 = lookup_module_0.run(terms_0, **kwargs_0)
  assert ret_0 == []

# Generated at 2022-06-25 10:36:14.973396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yaml_str = '''
- debug:
    msg: "{{ lookup('fileglob', '/my/path/*.txt') }}"
- copy:
    content: "{{ lookup('fileglob','/playbooks/files/fooapp/*') }}"
    dest: "/etc/fooapp/"
    mode: 0600
    owner: "root"
'''
    raw_params = {
        'terms': [
            '/my/path/*.txt',
            '/playbooks/files/fooapp/*',
        ]
    }


# Generated at 2022-06-25 10:36:17.933105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:36:22.769921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['/my/path/*.txt']
    variables = {'ansible_search_path' : ['/ansible/lookup'],
                 'ansible_basedir' : '/ansible/lookup',
                 'ansible_file_search_path' : ['/ansible/lookup/files']}
    test_run_1 = lookup_module_1.run(terms, variables)
    assert test_run_1 == []

# Generated at 2022-06-25 10:36:30.967696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['/my/path/*.txt']
    variables = {u'role_path': [u'/home/jojo/.ansible/roles/foo'], 
    u'lookup_plugins': u'/home/jojo/.ansible/roles/foo/plugins/lookup', 
    u'playbook_dir': u'/home/jojo/source/ansible-book-repo/en/playbooks', 
    u'group_names': [u'foo'], u'src_root': u'/home/jojo/source/ansible-book-repo/en'}
    testvar_0 = lookup_module_1.run(terms=terms, variables=variables)
    assert testvar_0 == []

# Generated at 2022-06-25 10:36:36.904769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters for unit test
    test_term_0 = ['test message', 'test file', 'test file 1', 'test file 2', 'test file 3']
    test_variable_0 = ['testv1', 'testv2', 'testv3']

    # Expected return value
    test_result_0 = ['test message', 'test file', 'test file 1', 'test file 2', 'test file 3']
    # Actual return value
    lookup_module_0 = LookupModule()
    actual_result_0 = lookup_module_0.run(test_term_0, test_variable_0)

    assert(test_result_0 == actual_result_0)


# Generated at 2022-06-25 10:36:41.894642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/my/path/*.txt']
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:36:46.409731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(['/home/*.md']) == ['/home/test.md']
    assert lookup_module_0.run(['/home/*.md', './*.txt']) == ['/home/test.md', './test.txt']
    assert lookup_module_0.run(['/home/test.md']) == ['/home/test.md']
    assert lookup_module_0.run(['/home/test.txt']) == []

# Generated at 2022-06-25 10:36:54.644031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["*.yml", "*.yaml", "*.txt", "*.conf", "*.cfg"]
    wantlist = False
    wantlist_value = True
    variables = None


    lookup_module = LookupModule()
    lookup_module.set_options(dict(wantlist=wantlist, variables=variables))
    result = lookup_module.run(terms, wantlist=wantlist_value)
    result_text = str(result)
    assert "test_file_1.yml" in result_text
    assert "test_file_8.txt" in result_text
    assert "test_file_9.conf" in result_text
    assert result_text.count(',') == 3
    assert len(result) == 4

# Generated at 2022-06-25 10:37:00.557886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('')
    # Create an instance of class LookupModule
    lookup_module_0 = LookupModule()

    # Create an instance of class LookupModule
    lookup_module_1 = LookupModule()

    # Create an instance of class LookupModule
    lookup_module_2 = LookupModule()

    # Define the method input arguments
    terms_0 = ['*.txt']
    terms_1 = ['*.png']
    terms_2 = ['*.jpg']

    # Invoke method run of LookupModule on the object lookup_module_0
    #return_value_0 = lookup_module_0.run(terms=terms_0)

    # Invoke method run of LookupModule on the object lookup_module_1
    #return_value_1 = lookup_module_1.run(terms=terms_1)

   

# Generated at 2022-06-25 10:37:09.023230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/my/path/*.txt']
    search_path = ['/my/path/hello.txt']
    ret = []
    for term in terms:
        term_file = os.path.basename(term)
        found_paths = []
        if term_file != term:
            found_paths.append(search_path)
        else:
            # no dir, just file, so use paths and 'files' paths instead
            for p in search_path:
                found_paths.append(os.path.join(p, 'files'))
                found_paths.append(p)


# Generated at 2022-06-25 10:37:18.447195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '<8x0E\n\r;2\r?\tT\x0c'
    var_0 = lookup_run(str_0)



# Generated at 2022-06-25 10:37:21.224152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = '/etc/hosts, /etc/foo'
    var = lookup_run(terms)
    assert isinstance(var, list)

test_LookupModule_run()

# class LookupModule:
#     def run(self, terms, variables=None, **kwargs):
#         var = lookup_run(terms)
#         return var

# Generated at 2022-06-25 10:37:27.024792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:37:31.598883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    res_0 = lookup_module_0.run(str_0)
    str_1 = '\x0c\t\n'
    res_1 = lookup_module_0.run(str_1)
    str_2 = ':z\r\r\\'
    res_2 = lookup_module_0.run(str_2)
    assert res_0 == []
    assert res_1 == []
    assert res_2 == []

# Generated at 2022-06-25 10:37:33.967202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:37:44.091857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    str_1 = '\x17\x1b|\n\x11\x1d\x13'
    str_2 = '=\x0e\xff\x0c'

# Generated at 2022-06-25 10:37:49.539302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = 'X?0y~Q<{C\x0c_\r,:Jc'
    var_2 = lookup_run(var_1)
    var_3 = 'es[Jw,\r'
    var_4 = lookup_run(var_3)
    var_5 = '5WyP^g(a\x7f_\t'
    var_6 = lookup_run(var_5)
    var_7 = '"w1\x0bS\x0b'
    var_8 = lookup_run(var_7)
    var_9 = 'gJ~,<@6p'
    var_10 = lookup_run(var_9)


# Generated at 2022-06-25 10:37:53.500588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:37:55.393106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_case_1()

# Testing with some input

# Generated at 2022-06-25 10:38:02.834360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0=LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    assert lookup_module_0.run(str_0) == ['C:\Windows\Temp\ansible-tmp-1529793482.77-279587949552421\ansible_fileglob_payload.txt']

# Generated at 2022-06-25 10:38:21.023711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "/Users/hughdbrown/ansible/ansible/lib/ansible/plugins/lookup/fileglob.py"
    var_0 = lookup_run(str_0)
    assert var_0 == []


# Generated at 2022-06-25 10:38:24.611742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)



# Generated at 2022-06-25 10:38:26.352603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:38:34.328604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'z4b4Q~^w1\x0c$\t\x0c\x0c'
    var_0 = lookup_run(str_0)
    assert var_0 == [], 'Expected ' + str([]) + ' but got ' + str(var_0)
    # Test with args
    lookup_module_0 = LookupModule()
    str_0 = 'R~TpF\x0cy'
    dict_0 = {}
    dict_0['ansible_search_path'] = ['/']
    var_0 = lookup_run(str_0, dict_0)
    assert var_0 == [], 'Expected ' + str([]) + ' but got ' + str(var_0)
    # Test with kw

# Generated at 2022-06-25 10:38:36.449068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: test not implemented.

    # check the number of arguments
    # check the value of the arguments

    # run the method
    # check we get the correct result
    # check that the correct methods are called
    # check that we called the correct methods
    # check that the correct attributes are accessed
    # check that the correct attributes are set/modified
    pass

# Generated at 2022-06-25 10:38:46.715965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)
    str_1 = 'V;\x0c'
    var_1 = lookup_run(str_1)
    str_2 = 'Z\x0c'
    var_2 = lookup_run(str_2)
    str_3 = '\x0cj'
    var_3 = lookup_run(str_3)
    str_4 = '\x0cQ\r'
    var_4 = lookup_run(str_4)
    str_5 = '\x0c|\r'
    var_5 = lookup_run(str_5)
    str_6

# Generated at 2022-06-25 10:38:47.934970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()
    lookup_mock.run('test_file.json')

# Generated at 2022-06-25 10:38:54.607721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('>>> test_LookupModule_run')
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:39:00.752652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with a pretty simple case with only one term
    # Expected result is empty list as wildcard does not match a file
    terms = ['test_file_not_exist']
    expected_result = []
    assert lookup_module.run(terms) == expected_result


# Generated at 2022-06-25 10:39:09.422302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    upstream__ansible_search_path_0 = '/usr/local/lib/python2.7/dist-packages:..'
    upstream__ansible_search_path_1 = '/etc/ansible/hosts'
    upstream__ansible_search_path_2 = '/etc/ansible'
    upstream__ansible_search_path_3 = 'upstream/ansible'
    upstream__ansible_search_path_4 = 'upstream'
    upstream__ansible_search_paths_0 = [upstream__ansible_search_path_0, upstream__ansible_search_path_1, upstream__ansible_search_path_2, upstream__ansible_search_path_3, upstream__ansible_search_path_4]


# Generated at 2022-06-25 10:39:35.191838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_1 = lookup_run(str_1)


# Generated at 2022-06-25 10:39:38.866782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0 = lookup_module_0.run('-M;(Gs3ar\r~`\n)=EC\x0c\t')
    assert len(lookup_module_0) == 0
    assert lookup_module_0[0] == 'e'
    assert lookup_module_0[1] == 'c'

# Generated at 2022-06-25 10:39:43.463780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_1 = lookup_module_1.run(str_1)
    str_2 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_2 = lookup_module_1.run(str_2)
    str_3 = 'f2b8cabd55adf7587f8760410408d5c5'
    var_3 = lookup_module_1.run(str_3)

# Generated at 2022-06-25 10:39:48.504998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)



# Generated at 2022-06-25 10:39:54.360451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(None)
    var_1 = lookup_run(None)
    var_2 = lookup_run(None)
    var_3 = lookup_run(None)
    var_4 = lookup_run(None)
    var_5 = lookup_run(None)
    var_6 = lookup_run(None)
    str_0 = 'z\x04\x11'
    str_1 = 'U6\x00\x00\x00'
    var_7 = lookup_run(str_0, str_1)
    str_2 = '\n\x14\x1b'
    str_3 = '\r'
    var_8 = lookup_run(str_2, str_3)

# Generated at 2022-06-25 10:39:56.950984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    var_0 = [dict(), dict(), dict(), dict()]
    str_0 = 'x(^\x0bY/\x0b\x0eIq\x0e$S\x0b\x0c'
    var_1 = lookup_module_run.run(var_0)
    assert var_1 == str_0


# Generated at 2022-06-25 10:39:59.108690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    path = ['fixtures/test.txt', 'fixtures/test.txt']
    terms = ['test.txt', 'bad_file.txt']
    path.extend([None, None])
    results = lookup.run(terms, variables={'r1': 'r1'}, wantlist=True)
    assert results == path

# Generated at 2022-06-25 10:40:09.021589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fileglob = LookupModule()
    # Assert: AssertionError: '../../../../../../../../../../../../../../../tmp' is not an absolute path:
    terms = ["../../../../../../../../../../../../../../../tmp"]
    variables = {
        'ansible_search_path': [
            '..',
            '/usr',
            '/etc'
        ]
    }
    # test: assert len(globbed) == 0, "globbed should be an empty list"
    # cause: AssertionError: globbed should be an empty list
    try:
        fileglob.run(terms, variables)
    except AssertionError:
        pass

test_case_0()

# Generated at 2022-06-25 10:40:15.335667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)



# Generated at 2022-06-25 10:40:24.308860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    list_0 = []
    str_1 = '}A>ug{|a_bG'
    str_2 = '<-!O&I^B_E#'
    list_1 = ['fdd', '-!m\n', '\\\t']
    list_2 = ['/vq:=T\t', 'b', 'aW%gvN'
    ]
    var_0 = lookup_run(str_0, terms=list_0)
    var_1 = lookup_run(str_1, basedir=str_2)
    var_2 = lookup_run(str_1, variables=list_1)
    var_3 = lookup_run(str_1, **dict_0)
    var_4

# Generated at 2022-06-25 10:41:04.160399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    lookup_run(str_0)

# Mock function for test_LookupModule_run

# Generated at 2022-06-25 10:41:11.827924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    var_0 = lookup_run(str_0)
    #
    #
    #
    str_1 = '`Z#>4L<j4?~]x\x0c\t'
    var_1 = lookup_run(str_1)
    #
    #
    #
    str_2 = 'yCjN?\x0c\t'
    var_2 = lookup_run(str_2)
    #
    #
    #
    str_3 = 'SKD\x0c\t'
    var_3 = lookup_run(str_3)
    #
    #
    #
    str_4

# Generated at 2022-06-25 10:41:14.492978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(['/tmp/testkdsjfslkdjf/test.txt'])
    assert ret == ['/tmp/testkdsjfslkdjf/test.txt']

# Generated at 2022-06-25 10:41:17.843745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '`&*\x0c|2_F%*'
    str_1 = '8g"7+'
    var_0 = lookup_run(str_0)
    var_1 = lookup_run(str_1)

test_case_0()

# Generated at 2022-06-25 10:41:23.472321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
    str_2 = '.'
    var_1 = lookup_module_1.run(str_1, str_2)
    assert('' == var_1)

# Generated at 2022-06-25 10:41:26.736380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = {}
  obj_0 = LookupModule()
  str_0 = '-M;(Gs3ar\r~`\n)=EC\x0c\t'
  var_1 = obj_0.run(str_0,var_0)
  print(var_1) # should print a list of files

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:41:32.075290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_1 = []
    dict_0 = {}
    str_0 = '*n\'W8<vS9_'
    var_0 = lookup_module_0.run(list_1, dict_0, wantlist=str_0)
    list_2 = [b'%sp\x15\x12']

# Generated at 2022-06-25 10:41:38.133856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    str_0 = '/*.txt'
    str_1 = "{'ansible_search_path': 'dummy'}"
    var_2 = var_0.run(str_0, str_1)
    assert var_2 == []



# Generated at 2022-06-25 10:41:38.944688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 10:41:46.529521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ['', '', '', '', '', '']
    test_array_0 = [var_0]
    lookup_module_0 = LookupModule()
    str_0 = 'N2j$nA/iG\t$)y\x0c'
    var_0 = lookup_module_0.run(test_array_0, variables=str_0)


# Generated at 2022-06-25 10:42:48.898174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = '+w4\x0cP?J\x7f9(~~`qm&0\nB\x1b}+'
    var_0 = lookup_module_1.run(str_0)
