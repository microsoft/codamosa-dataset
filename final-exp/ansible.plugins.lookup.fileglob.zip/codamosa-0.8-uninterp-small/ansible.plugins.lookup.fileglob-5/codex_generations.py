

# Generated at 2022-06-25 10:32:52.544415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([''])
    lookup_module.run('../tests/test_lookup_plugins/test_fixtures/fileglob_test_dir')
    lookup_module.run(['test_file*.txt'])
    lookup_module.run([''])

# Generated at 2022-06-25 10:32:55.357641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('term')

# Generated at 2022-06-25 10:32:59.164691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/playbooks/files/fooapp/*']
    variable = None
    want_list = False

    result = lookup_module.run(terms, variable, wantlist = want_list)
    assert result[0] == '/playbooks/files/fooapp/test'

# Generated at 2022-06-25 10:33:02.425829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['foo_0', 'foo_1']
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []

# Generated at 2022-06-25 10:33:13.457184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure we can find the file via fileglob
    lookup_module_0 = LookupModule()
    terms = ['README.md']
    assert lookup_module_0.run(terms) == [to_text(os.path.join(os.path.dirname(__file__), terms[0]))]

    # assert we can glob a directory
    lookup_module_1 = LookupModule()
    terms = ['*']
    assert lookup_module_1.run(terms) == [to_text(os.path.join(os.path.dirname(__file__), 'README.md'))]

    # We will not try to glob files in the parent directory
    terms = ['../../README.rst']
    assert lookup_module_1.run(terms) == []

    # We will not try to

# Generated at 2022-06-25 10:33:19.756674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    assert lookupModule.run(['/home/craig/Desktop/dev/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py'], {"ansible_search_path": ['/home/craig/Desktop/dev/ansible/playbooks']}) == ['/home/craig/Desktop/dev/ansible/playbooks/files/home/craig/Desktop/dev/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py']



# Generated at 2022-06-25 10:33:22.021119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = {}
    variables = {}
    result = lookup_module_1.run(terms, variables)
    assert result == []


# Generated at 2022-06-25 10:33:23.548024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=['test.yml']) == ['/home/start/ansible/test/test.yml']

# Generated at 2022-06-25 10:33:30.566763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case #1
    try:
        lookup_module_1 = LookupModule()
        terms_1 = ["None.txt"]
        variables_1 = {"search_path": "None"}
        lookup_module_1.run(terms_1, variables_1)
    except Exception as inst:
        # print type(inst)     # the exception instance
        # print inst.args      # arguments stored in .args
        # print inst           # __str__ allows args to be printed directly,
        assert True
    else:
        raise Exception("Should have raised exception")


# Generated at 2022-06-25 10:33:38.091790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict())
    term = "ansible.cfg"
    expected_out = to_text(u"/etc/ansible/ansible.cfg")
    result_out =  to_text(lookup_module.run(terms=[term], variables={'ansible_search_path': [u'/etc/ansible']}))
    assert result_out == expected_out


# Generated at 2022-06-25 10:33:45.972384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['*']
    variables = {'ansible_search_path': ['path_1', 'path_2'], 'ansible_basedir': 'basedir', 'ansible_file_priorities': ['file_1', 'file_2']}
    kwargs = {'wantlist': 'wantlist'}
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == []


# Generated at 2022-06-25 10:33:55.553117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_1 = LookupModule()
    lookup_module_obj_2 = LookupModule()
    lookup_module_obj_3 = LookupModule()
    lookup_module_obj_4 = LookupModule()
    lookup_module_obj_5 = LookupModule()
    lookup_module_obj_6 = LookupModule()
    lookup_module_obj_7 = LookupModule()
    lookup_module_obj_8 = LookupModule()
    lookup_module_obj_9 = LookupModule()
    lookup_module_obj_10 = LookupModule()
    lookup_module_obj_11 = LookupModule()
    lookup_module_obj_12 = Lookup

# Generated at 2022-06-25 10:33:59.656541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['__init__.py']) == []

# Generated at 2022-06-25 10:34:00.956675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.run(['.*'])

# Generated at 2022-06-25 10:34:05.608250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_basedir = lambda x: "/ansible/test/fileglob/basedir"
    lookup_module.find_file_in_search_path = lambda x,y,z: "/ansible/test/basedir/files/dir"
    terms = [ "*.py" ]
    ret = lookup_module.run(terms, variables=None)
    assert ret == ["/ansible/test/basedir/files/dir/test_case.py"]

# Generated at 2022-06-25 10:34:07.735518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        assert type(lookup_module_0.run(terms, variables)) in [list, tuple]
    except AssertionError as e:
        traceback.print_exc()
        print(e)

# Generated at 2022-06-25 10:34:10.688707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    ret = x.run(terms=None, variables=None)
    if ret:
        raise AssertionError("expected {} but got {}".format(None, ret))

# Generated at 2022-06-25 10:34:16.875226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['file1.txt', 'file2.txt'], variables={'ansible_search_path': '.'}) == ['file1.txt', 'file2.txt']
    assert lookup_module.run(terms=['file*.txt'], variables={'ansible_search_path': '.'}) == ['file1.txt', 'file2.txt']
    assert lookup_module.run(terms=['*.txt'], variables={'ansible_search_path': '.'}) == ['file1.txt', 'file2.txt']
    assert lookup_module.run(terms=['file1.txt'], variables={'ansible_search_path': '.'}) == ['file1.txt']

# Generated at 2022-06-25 10:34:26.125744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run("/path/to/file")
    lookup_module.run("/path/to/file 'a b c' d e f")
    lookup_module.run("/path/to/file", "")
    lookup_module.run("/path/to/file", "{}")
    lookup_module.run("/path/to/file", "a")
    lookup_module.run("/path/to/file", "a", _original_file="")
    lookup_module.run("/path/to/file", "a", _original_file="a")
    lookup_module.run("/path/to/file", "a", _original_file="/path/to/file")

# Generated at 2022-06-25 10:34:31.539135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(['/etc/ansible/hosts'])
    assert isinstance(lookup_module_run, list)
    assert lookup_module_run[0] == '/etc/ansible/hosts'



# Generated at 2022-06-25 10:34:34.870635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(['test_file.txt']) == [u'/home/dileep/ansible/test_file.txt']


# Generated at 2022-06-25 10:34:42.352465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'*.txt']
    variables_0 = [u'/my/path/test.txt']
    kwargs_0 = {}
    kwargs_0['wantlist'] = False
    run_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert run_0 == [u'/my/path/test.txt']


# Generated at 2022-06-25 10:34:46.374580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(['/fake/path/', '*.txt'], dict())
    except AnsibleFileNotFound as a:
        pass


# Generated at 2022-06-25 10:34:51.115199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        terms='test',
        variables='AnsibleUndefined',
        wantlist=False
    )
    lookup_module_0 = LookupModule()
    lookup_module_0.run(**args)


if __name__ == "__main__":
    import sys
    import pytest

    sys.exit(pytest.main(args="test_lookup_plugins/test_lookup_plugins.py"))

# Generated at 2022-06-25 10:34:54.884497
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    failed = False

    try:
        lookup_module_run = LookupModule()
    except NameError as e:
        assert False, "Unable to instantiate LookupModule()"

    ret = lookup_module_run.run("foo.txt", "variables", "wantlist=False")
    assert ret == ["foo.txt"], "LookupModule.run() method returned unexpected result"


# Generated at 2022-06-25 10:34:56.111293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = test_case_0()
    lookup_module_0.run

# Generated at 2022-06-25 10:35:01.213708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assert the invocation of lookup.run with the following arguments:
    # the list of paths to search, and variables information which includes the 'ansible_search_path' variable with the value ['playbooks/files']
    assert lookup_module.run(['*.txt'], variables={'ansible_search_path': ['playbooks/files']}) == [u'playbooks/files/test.txt']

# Generated at 2022-06-25 10:35:08.695446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:35:16.083381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    test_cases = [
        ('/folder1/*', '', [], ['/folder1/file1']),
        ('/folder1/subfolder1/*', '', [], ['/folder1/subfolder1/file1']),
        ('/folder1/*', '', [], ['/folder1/file1']),
        ('/folder1/subfolder1/*', '', [], ['/folder1/subfolder1/file1']),
    ]
    for (terms, variables, kwargs, expected_result) in test_cases:
        assert lookup_module_0.run(terms, variables, **kwargs) == expected_result


# Generated at 2022-06-25 10:35:19.057658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['lookup_module.py' , 'lookup_module.py']
    lookup_module.run(terms)

# Generated at 2022-06-25 10:35:23.098498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/ansible/hosts']
    lookup_module.run(terms)

# Generated at 2022-06-25 10:35:27.835633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_in = ['/my/path/*.txt']
    variables_in = {'ansible_search_path': ['/my/path/', '/your/path']}
    assert glob.glob(terms_in[0]) == lookup_module_0.run(terms_in, variables_in)


if __name__ == "__main__":
    """
    The Main Function
    """
    test_case_0()

# Generated at 2022-06-25 10:35:30.104729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 10:35:32.875782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '/my/path/*.txt'
    assert lookup_module_0.run(term_0) == ['/my/path/a.txt']

# Generated at 2022-06-25 10:35:42.630996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Prepare the inputs
  terms = [u'*']

# Generated at 2022-06-25 10:35:49.293488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['*.txt'], {'_original_file': 'tests/ansible/test_lookup_fileglob_unit.py'})


# Generated at 2022-06-25 10:35:55.150425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms = ['/my/path/*.txt']
    test_variables = {}
    lookup_module_0.run(test_terms, test_variables)

# Generated at 2022-06-25 10:35:58.831805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule() is not None

# Generated at 2022-06-25 10:36:04.597647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([],{}) == []

# Generated at 2022-06-25 10:36:10.884678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test run() method
    # Test successful run
    assert lookup_module_0.run(terms=['./test_data/file*']) == [u'./test_data/file1', u'./test_data/file2']
    # Test run failed exception
    assert lookup_module_0.run(terms=['../test_data/file*']) == []