

# Generated at 2022-06-25 10:32:55.725766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  assert isinstance(lookup_module_0.run(['test'], variables=None, wantlist=True), list)

# Generated at 2022-06-25 10:33:00.416255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(terms=['/my/path/*.txt'], variables={})
    assert ret == []

# Generated at 2022-06-25 10:33:02.201591
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:33:09.822512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_run_1_input_1 = {"foo"}
    test_run_1_input_2 = {"foo"}
    test_run_1_expect_output = ['']
    assert(lookup_module_1.run(test_run_1_input_1, test_run_1_input_2) == test_run_1_expect_output)

# Generated at 2022-06-25 10:33:13.889127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_basedir = lambda *args, **kwargs: ''
    lookup_module_0.find_file_in_search_path = lambda *args, **kwargs: ''
    assert lookup_module_0.run(['/my/path/*.txt', '/my/path/*.php'], {}) == []


# Generated at 2022-06-25 10:33:17.695095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['/my/path/*.txt']
    variables_1 = {'ansible_search_path': ['/my/path']}
    assert ['testfile.txt'] == lookup_module_1.run(terms_1, variables_1)

# Generated at 2022-06-25 10:33:27.908012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ '/fileglob/t?-file1.txt', '/fileglob/t?-file2.txt', '/fileglob/t?-file3.txt', '/fileglob/t?-file4.txt',
              '/test/test-file5.txt', '/test/test-file6.txt', '/test/test-file7.txt', '/test/test-file8.txt',
              'test-file9.txt', 'test-file10.txt', 'test-file11.txt', 'test-file12.txt' ]
    ansible_variables = {'ansible_search_path': ['/Test/', '/fileglob/', '/test']}


# Generated at 2022-06-25 10:33:38.576973
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Calling run() method of class LookupModule
    test_object_0 = LookupModule()
    str_0 = os.path.expanduser('~')
    list_0 = [str_0]
    test_object_0.run(list_0)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-25 10:33:47.157360
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert(
        LookupModule.run(
            ['test_dir/test_file.txt'],
            {"ansible_search_path": ['test/', 'test1/']}
        ) == ['test_dir/test_file.txt']
    )
    assert(
        LookupModule.run(
            ['test_dir/test_file.txt'],
            {"ansible_search_path": ['test_dir']}
        ) == []
    )
    assert(
        LookupModule.run(
            ['test_dir/test_file.txt'],
            {"ansible_search_path": ['test/', 'test1/']}
        ) == ['test_dir/test_file.txt']
    )

# Generated at 2022-06-25 10:33:51.458392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = dict()
    terms = list()
    terms.append("*.yml")
    kwargs['wantlist'] = True
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=terms,**kwargs)
    print(ret)
    assert ret == []



if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 10:33:58.540691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Make test data instances using the following dictionary
    test_data_0 = { 'variables': { 'ansible_search_path': [ '.' ] }, '__wantlist__': True }

    # Test execution of run method
    assert lookup_module_0.run(['*'], **test_data_0) == []

# Generated at 2022-06-25 10:34:04.239529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variable_0 = (0,)
    variable_1 = {u'ansible_search_path': u'LookupModul'}
    variable_1[u'ansible_search_path'] = u'LookupModul'
    lookup_module_0.run(terms=variable_0, variables=None, **variable_1)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:14.036929
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # make an instance of the dummy class (first param of LookupModule)
    lookup_module_0 = LookupModule()
    term_0 = "fileglob_test_file.txt"
    # This variable is a dictionary with ansible variable names as keys and their values as the value for that key.
    variables_0 = {}
    # make an instance of the dummy class (first param of LookupModule)
    lookup_module_1 = LookupModule()
    term_1 = "fileglob_test_file.txt"
    # This variable is a dictionary with ansible variable names as keys and their values as the value for that key.
    variables_1 = {}
    # make an instance of the dummy class (first param of LookupModule)
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:34:17.376897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["/tmp/*"]) == glob.glob('/tmp/*')

# Generated at 2022-06-25 10:34:22.022587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing LookupModule.run")
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([u'../test/test_fileglob/test_fileglob.py'], {}) == [u'../test/test_fileglob/test_fileglob.py']

# Generated at 2022-06-25 10:34:24.431534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["abc","xyz"]
    variables = "path"
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms, variables) == "path"


# Generated at 2022-06-25 10:34:26.213036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=['/my/path/*.txt']), "Should be True"

# Generated at 2022-06-25 10:34:28.966439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1, LookupModule)
    lookup_module_1.run(['/etc/hosts'], {})

# Generated at 2022-06-25 10:34:32.575945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['file'], variables=None)


# Generated at 2022-06-25 10:34:35.072845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert len(LookupModule().run(terms=['abc'], variables={})) == 0
