

# Generated at 2022-06-21 05:53:16.126268
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 05:53:17.537633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert(look != None)

# Generated at 2022-06-21 05:53:29.881730
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 05:53:40.693915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.group import Group
    from ansible.plugins.strategy import StrategyBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    import os
    import ansible.constants as C

# Generated at 2022-06-21 05:53:46.492360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run("/Users/test/test.txt") == ["/Users/test/test.txt"]
    assert lookup.run("test.txt") == ["test.txt"]
    assert lookup.run("/test/test.txt") == []

# Generated at 2022-06-21 05:53:52.776577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.get_basedir = lambda variables: '/my/path'
    assert lookup.run(["*.yaml", "*.yml"], ansible_search_path=["/search/1", "/search/2"]) == ["/search/2/test.yaml", "/search/2/test.yml", "/search/2/test2.yml", "/search/1/test.yaml", "/search/1/test.yml", "/search/1/test2.yml"]

# Generated at 2022-06-21 05:54:00.269097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    # The dir in which the file (name.txt) exists
    test_dir = os.getcwd()
    # The expected result with the dir and filename
    expected = [test_dir + "/name.txt"]
    # The terms in which the test is run
    terms = [test_dir + "/*.txt"]
    #The variables
    variables = {"ansible_search_path": [test_dir]}
    # The method is run with the parameters and the result is checked for equality to the expected results
    assert lookupModule.run(terms, variables) == expected

# Generated at 2022-06-21 05:54:01.071182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:54:02.551814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:54:05.106610
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing LookupModule')
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:54:10.038845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 05:54:18.510051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    terms = ["test"]
    terms2 = ["test2/*.txt"]
    variables = {"ansible_search_path": ["/test"]}
    assert lk.run(terms, variables) == []
    assert lk.run(terms2, variables) == []
    # assert lk.run(terms2, variables) == ['/test/test2/file1.txt', '/test/test2/file2.txt']

# Generated at 2022-06-21 05:54:21.384317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookup = LookupModule()
    assert myLookup != None

# Generated at 2022-06-21 05:54:23.262612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert "LookupModule" == LookupModule("")._get_plugin_name()

# Generated at 2022-06-21 05:54:25.253008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:54:34.409034
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_find_file_in_search_path = Mock(return_value="")

    lookup_plugin = LookupModule()
    lookup_plugin.find_file_in_search_path = mock_find_file_in_search_path

    terms = ["*.txt"]
    variables = dict(ansible_search_path=["/path1", "/path2"], foo="bar")
    assert lookup_plugin.run(terms, variables, wantlist=True) == "/path1/files/fooapp/.txt,/path2/files/fooapp/.txt", lookup_plugin.run(terms, variables, wantlist=True)

    terms = ["*.txt"]
    variables = dict(ansible_search_path=["/path1", "/path2"], foo="bar")
    assert lookup_plugin.run(terms, variables, wantlist=True)

# Generated at 2022-06-21 05:54:43.652427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()

    base_dir = os.path.dirname(__file__)
    terms = [os.path.join(base_dir, 'nested_dir', 'nested_dir.yml')]
    dwimmed_paths = [os.path.join(base_dir, 'files')]
    globbed = [os.path.join(base_dir, 'nested_dir', 'nested_dir.yml')]
    results = [os.path.join(base_dir, 'nested_dir', 'nested_dir.yml')]

    def find_file_in_search_path(variables, subdir, basedir):
        return os.path.join(base_dir, 'files')

    def glob_func(search_path):
        return globbed


# Generated at 2022-06-21 05:54:49.983744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # if it is not in PATH, the current directory is used
    current_dir = os.path.dirname(os.path.abspath(__file__))
    lookup_module = LookupModule()
    assert len(lookup_module.run([os.path.join(current_dir, "test_fileglob.py")])) == 1
    assert len(lookup_module.run([os.path.join(current_dir, "test_fileglob.*")])) == 3

# Generated at 2022-06-21 05:54:50.876689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:54:54.753615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = [u'/root/ansible/files/file_to_glob.xml', u'/root/ansible/files/file_to_glob.txt', u'/root/ansible/files/file_to_glob.ini']
    terms = [u'file_to_glob.*']
    module = LookupModule()
    result = module.run(terms)
    assert result == result, 'List of files not correctly retrieved'

# Generated at 2022-06-21 05:54:59.056352
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:55:01.149076
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_obj = LookupModule()


# Generated at 2022-06-21 05:55:12.100163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # mocks
    MockTerm = 'mock_term'
    MockVariables = {
        'ansible_basedir': '/mock_basedir',
        'ansible_search_path': ['/mock_path']
    }
    # tests
    assert(LookupModule().run(terms=None, variables=None) == [])

    terms = [MockTerm]
    variables = MockVariables
    lookup_instance = LookupModule()
    def mockos_path_isfile(path):
        return path == '/mock_basedir/mock_term'

# Generated at 2022-06-21 05:55:21.627384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lObj = LookupModule()
    lObj.basedir = "test_dir1"
    terms = lObj.run([os.path.join("test_dir1", "test_dir2", "test_file1")])
    assert isinstance(terms[0], str)
    assert terms[0] == os.path.join("test_dir1", "test_dir2", "test_file1")
    os.remove(os.path.join("test_dir1", "test_dir2", "test_file1"))
    terms = lObj.run([os.path.join("test_dir1", "test_dir2", "test_file2")])
    assert isinstance(terms[0], str)

# Generated at 2022-06-21 05:55:30.504901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if __name__ == '__main__':

        # Run following command "ansible localhost -m setup -a 'filter=ansible_local'" and
        # look for ansible_env.HOME key in output
        # Get value of HOME key and use it below
        class Object:
            def __init__(self, attr):
                self.__dict__ = attr
        env_vars = {'HOME': '/Users/username'}
        ansible_env = Object(env_vars)
        basedir = ansible_env.HOME

        # Run following command "ansible localhost -m setup -a 'filter=ansible_local'" and
        # look for ansible_local.files_path key in output
        # Get value of files_path key and use it below

# Generated at 2022-06-21 05:55:39.575516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock run method of AnsibleModule
    def mock_run(self, *args, **kwargs):
        args = list(args)
        args.append({'run_once': True, 'ansible_search_path': ['/path/to/files']})
        args = tuple(args)
        return self.set_options(*args, **kwargs)

    # mock lookup method of LookupBase
    def mock_lookup(name, *args, **kwargs):
        assert name == 'fileglob'
        assert args == ('/path/to/files/foo.conf',)
        assert kwargs == {'wantlist': True}
        return ['/path/to/files/foo.conf']

    from ansible.modules.source_control.git import AnsibleModule
    from ansible.plugins.lookup import Look

# Generated at 2022-06-21 05:55:43.170701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init LookupModule object
    lookup_module = LookupModule()
    # set ansible_search_path to current directory
    variables = {'ansible_search_path': '.'}
    # call run method to list all files in current directory ending with .py
    list_of_files = lookup_module.run(['*.py'], variables=variables)
    # assert that correct list of files is returned
    assert list_of_files == ['test_fileglob.py']

# Generated at 2022-06-21 05:55:46.176001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run(["fileglob"]) == []

# Generated at 2022-06-21 05:55:54.284876
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    os.chdir("tests")
    assert module.run("fileglob_test.txt") == ["fileglob_test.txt"]
    assert module.run(["fileglob_test.txt", "*.txt"]) == ["fileglob_test.txt", "fileglob_test.txt"]

# Generated at 2022-06-21 05:56:06.820411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_fixture = [
        '/path/to/file/this-is-a-lookup-test-01.txt',
        '/path/to/file/this-is-a-lookup-test-02.txt',
        '/path/to/file/this-is-a-lookup-test-03.txt'
    ]

    # Create test fixture
    for path in test_fixture:
        with open(path, 'w') as f:
            f.write(path)

    expected_result = test_fixture
    l = LookupModule()
    result = l.run(["*this-is-a-lookup-test-*.txt"], variables={})

    # Clean up
    for path in test_fixture:
        os.remove(path)

    assert expected_result == result

# Generated at 2022-06-21 05:56:19.824918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os.path
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.plugins.lookup.fileglob as lookup_fileglob

    # get lookup_fileglob.LookupModule class
    LookupModule_class = lookup_fileglob.LookupModule

    # instantiate LookupModule_class
    fileglob = LookupModule_class()

    # create test dir and test_file
    test_dir = os.path.join(os.getcwd(), 'unit_test_dir')
    os.mkdir(test_dir)

    # test pattern1 which returns 1 file
    test_file1 = os.path.join(test_dir, 'test_file1.txt')
    with open(test_file1, 'w') as file:
        file.write

# Generated at 2022-06-21 05:56:30.169103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["/my/path/*.txt", "*.txt"], variables={
        "ansible_search_path":[
          "/my/path/",
          "/other/path/",
        ],
        "ansible_current_user": "bob",
    }) == [
        "/my/path/file1.txt",
        "/my/path/file2.txt",
        "/other/path/file3.txt"
    ]
    assert LookupModule().run(["*.txt"], variables={
        "ansible_search_path":[
          "/my/path/",
          "/other/path/",
        ],
    }) == [
        "/my/path/file1.txt",
        "/my/path/file2.txt",
        "/other/path/file3.txt"
    ]


# Generated at 2022-06-21 05:56:31.636768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:56:32.898564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 05:56:33.962732
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:56:42.777506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # Instantiate the class under test
    lookup = LookupModule()
    terms = ['/my/path/*.txt']
    variables = dict(
        ansible_facts=dict(
            ansible_env=dict(
                HOME='/home/user',
                PATH='/sbin:/bin:/usr/sbin:/usr/bin'
            )
        ),
        ansible_search_path=['/some/path/', '/another/path/'],
        ansible_env=dict(
            HOME='/home/user'
        ),
    )
    # Act
    ret = lookup.run(terms, variables)
    # Assert
    assert ret == ['/my/path/*.txt']

# Generated at 2022-06-21 05:56:44.201919
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()
  assert l

# Generated at 2022-06-21 05:56:49.629114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with invalid path
    assert [] == lookup_module.run(terms='/test/the/path/is/invalid/for_sure/invalid_path', variables={})

    # test with valid path
    assert [] != lookup_module.run(terms='/test/the/path/is/valid/for_sure/valid_path', variables={})

# Generated at 2022-06-21 05:56:52.179082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module is not None)



# Generated at 2022-06-21 05:56:54.926654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/my/path/*.txt']
    result = lookup.run(terms)
    assert result == ['/my/path/*.txt']

# Generated at 2022-06-21 05:56:59.098503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if LookupModule is a class
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 05:57:00.384507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 05:57:06.875795
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lk = LookupModule()
    # Test the happy path
    lk.run(['./foo.txt'], dict(ansible_search_path=['/bar']))

    # Test a file that doesn't exist in ansible path
    assert lk.run(['./noexist.txt'], dict(ansible_search_path=['/bar'])) == []

# Generated at 2022-06-21 05:57:08.578794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:57:12.779937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms="*") is not None
    assert LookupModule().run(terms="*.py") is not None
    assert LookupModule().run(terms="./*") is not None

# Generated at 2022-06-21 05:57:14.664454
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:57:16.747625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    ret = l.run(['/my/folder/*'])
    assert isinstance(ret, list)

# Generated at 2022-06-21 05:57:18.661653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupBase)

# Generated at 2022-06-21 05:57:28.551297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create LookupModule object for test case
    lookup_module = LookupModule()

    # Create mock params for LookupModule object
    test_params = ['/path/to/file.txt']

    # Create mock Ansible variables for LookupModule object
    ansible_vars = {}

    # Create mock search path for LookupModule object
    ansible_vars['ansible_search_path'] = ['/path/to/dir1', '/path/to/dir2']

    # Test run method of LookupModule object
    test_result = lookup_module.run(test_params, ansible_vars)

    # Assert results
    assert test_result == []

# Generated at 2022-06-21 05:57:30.195506
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)


# Generated at 2022-06-21 05:57:36.257485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-21 05:57:38.462696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __main__
    lookup = LookupModule()
    __main__.__file__ = 'file'
    lookup.run(['*.py'], {})

# Generated at 2022-06-21 05:57:44.318668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_paths = ['/some/path', '/another/path']
    test_variables = {'ansible_search_path': test_paths}
    test_search = LookupModule(None, test_variables)
    assert test_search._paths == test_paths

# Generated at 2022-06-21 05:57:46.360993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule(None)
    assert module != None

# Generated at 2022-06-21 05:57:52.482921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import TestCase, mock
    from ansible import context

    def mock_get_basedir(variables):
        return variables['basedir']

    class LookupModuleTestCase(TestCase):

        def setUp(self):
            context._init_global_context(config=mock.Mock())
            self.variables = dict(
                basedir='basedir',
                ansible_search_path=['searchpath']
            )
            self.mylookup = LookupModule()
            self.mylookup.get_basedir = mock_get_basedir

        def tearDown(self):
            context._clear_global_context()


# Generated at 2022-06-21 05:57:53.307891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:58:02.617375
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:58:03.431203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 05:58:12.459885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create LookupModule object
    lookup_module = LookupModule()
    # Create search path for testing
    search_path = os.path.abspath('test/files/')
    # Add search path to LookupModule environment
    lookup_module.set_options(dict(basedir=search_path))
    terms = ["testfile*.txt"]
    # Run method run of LookupModule
    lookup_module_run_result = lookup_module.run(terms)
    assert type(lookup_module_run_result) == list
    # Check returned list of paths
    lookup_module_run_result.sort()
    assert lookup_module_run_result == [
        os.path.join(search_path, 'testfile.txt'), os.path.join(search_path, 'testfile1.txt')
    ]

# Generated at 2022-06-21 05:58:22.271506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    lookup = LookupModule()

    # This test uses the fixtures in tests/files/ to verify run
    # TODO: use the temp dir variable and move to tests/units/plugins/lookup
    #       so that this can be made a unittest
    base_dir = os.path.join(os.path.dirname(__file__), 'unit/plugins/lookup/files')

    # test pattern but no path, should return files in 'files'
    display.display('testing pattern but no path, should return files in "files"')

# Generated at 2022-06-21 05:58:35.970386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:58:38.516060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:58:43.563539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda: "/home/ansible/playbooks"
    l.find_file_in_search_path = lambda variables, file, filepath: "/home/ansible/playbooks/files"
    assert l.run(["*.txt"]) == ['/home/ansible/playbooks/files/dummy.txt']
    assert l.run(["/files/*.txt"]) == ['/home/ansible/playbooks/files/dummy.txt']
    assert l.run([".*"]) == []

# Generated at 2022-06-21 05:58:45.287549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['1.txt', '2.txt']
    ret = lookup.run(terms, variables=None)
    assert len(ret) == 2
    assert ret[0] == '1.txt'
    assert ret[1] == '2.txt'

# Generated at 2022-06-21 05:58:47.285722
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_object = LookupModule()
    assert my_object is not None

# Generated at 2022-06-21 05:58:48.749280
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 05:58:52.162541
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule class object
    lookupModule = LookupModule()
    # Call run method with proper parameters
    res = lookupModule.run(terms=['*.txt'], variables=None)
    # Print result
    print(res)

# Unit test case

# Generated at 2022-06-21 05:59:01.122659
# Unit test for constructor of class LookupModule
def test_LookupModule():
    values = [
        {
            "terms": ["*.txt"],
            "ret": ["README.txt", "LICENSE.txt"]
        },
        {
            "terms": ["*.txt", "*.rst"],
            "ret": ["README.txt", "LICENSE.txt", "README.rst"]
        }
    ]

    lookup_plugin = LookupModule()
    for value in values:
        assert lookup_plugin.run(terms=value["terms"]) == value["ret"]

# Generated at 2022-06-21 05:59:08.602944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestFailed(Exception):
        pass

    try:
        lookup_plug = LookupModule()
        lookup_plug.get_basedir({})
    except AnsibleFileNotFound as e:
        pass
    else:
        raise TestFailed("AnsibleFileNotFound Exception is not raised. Function get_basedir return incorrect value.")

# Generated at 2022-06-21 05:59:10.622563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None