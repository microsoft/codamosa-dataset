

# Generated at 2022-06-21 05:53:19.598042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._loader = DummyLoader()
    l.set_options({})
    assert l.run(['*.txt'], variables={'ansible_search_path': ['/first/path', '/second/path'], 'file_root': '/third/path', 'plugin_dir': '/plugin_dir'}) == ['/third/path/files/first.txt', '/third/path/files/second.txt', '/third/path/files/third.txt']



# Generated at 2022-06-21 05:53:20.961304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None

# Generated at 2022-06-21 05:53:31.032027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of LookupModule
    # Return:
    #   list: return list of paths
    # Create LookupModule object
    try:
        lookup_module = LookupModule()
        # Set terms
        terms = ['*.yml']
        # Set variables
        variables = {"_original_file": "/etc/ansible/roles/setup/defaults/main.yml",
                     "role_path": "/etc/ansible/roles/setup",
                     "playbook_dir": "/etc/ansible"}

        # Return path
        return lookup_module.run(terms, variables)
    except AnsibleFileNotFound as e:
        print(str(e))



# Generated at 2022-06-21 05:53:33.717459
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert dir(lookup_module) is not None


# Generated at 2022-06-21 05:53:34.563257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:53:38.263638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test with a single term
    terms = ['/tmp/*.txt']
    result = list(lookup.run(terms))

    # there shouldn't be any specific results here
    assert result == []


# Generated at 2022-06-21 05:53:41.917787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    options = dict(terms=['*.tmp'])
    lookup_obj = LookupModule()
    results = lookup_obj.run(options)
    assert results == []


# Generated at 2022-06-21 05:53:43.418461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule is not None)

# Generated at 2022-06-21 05:53:48.644396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    test for LookupModule run
    :return:
    '''

    # Test case when the file is not present
    result = LookupModule.run('', None)
    assert result == []

    # Test case when the file is present
    result = LookupModule.run('/my/path/*.txt', None)
    assert result == result

# Generated at 2022-06-21 05:54:01.017496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
    class MockDS(dict):
        def get(self, key, default=None):
            return self.get(key, default)

    class MockTemplar(object):
        def __init__(self, add_host):
            self.ds = MockDS()
            self.add_host = add_host

    module = MockModule({})
    templar = MockTemplar(False)

    lookup_module = LookupModule()
    lookup_module.set_options({})

    assert lookup_module.run(["ansible_module_utils"], variables=templar, wantlist=True) == []

# Generated at 2022-06-21 05:54:04.230393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # fileglob.run(['/my/path/*.txt'])
    pass

# Generated at 2022-06-21 05:54:06.715614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)
    assert isinstance(LookupModule(), object)

# Generated at 2022-06-21 05:54:09.042806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    data = lookup_obj.run(['./test/test_plugin/testdata/a'])
    assert data != None
    assert len(data) == 2

# Generated at 2022-06-21 05:54:09.974870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:54:11.797718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:54:21.731261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # define params
    terms = ['/my/path/*.txt']
    variables = {'ansible_search_path': '/my/path'}
    kwargs = {'wantlist': True}

    # define expected output
    expected_output = ['/my/path/file1.txt', '/my/path/file2.txt']

    # call method under test
    run_output = LookupModule().run(terms,variables,**kwargs)

    # compare output with expected output
    assert run_output == expected_output

    # define params
    terms = ['*.txt']
    variables = {'ansible_search_path': '/my/path', 'ansible_file_dir': '/my/path/files'}
    kwargs = {'wantlist': True}

    # define expected output
    expected_output

# Generated at 2022-06-21 05:54:32.605572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for function run [1]
    # mock ansible variables
    mock_variable = dict()
    mock_variable['ansible_env'] = dict()
    mock_variable['ansible_env']['HOME'] = "/home/michael"
    mock_variable['ansible_cwd'] = "/home/michael/ansible"
    mock_variable['ansible_user_dir'] = "/home/michael/.ansible"
    mock_variable['ansible_playbook_basedir'] = "/home/michael/ansible/playbooks"
    mock_variable['ansible_playbook_dir'] = "/home/michael/ansible/playbooks"
    mock_variable['ansible_facts'] = dict()
    mock_variable['ansible_facts']['module_setup_env'] = dict()
    mock

# Generated at 2022-06-21 05:54:34.513956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check if variable is empty
    test = LookupModule()
    assert test
    # Check if variable is not empty
    test1 = LookupModule()
    assert test1

# Generated at 2022-06-21 05:54:43.652207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    # If basedir is not set, then the basedir should default to /etc/ansible
    if look._basedir:
        if look._basedir != '/etc/ansible':
            raise AssertionError('failed to set default base directory')
    else:
        raise AssertionError('failed to set default base directory')

    # If basedir is set, then the basedir should be /tmp
    look.set_options(dict(basedir='/tmp'))
    if look._basedir:
        if look._basedir != '/tmp':
            raise AssertionError('failed to set base directory')
    else:
        raise AssertionError('failed to set base directory')

    # If basedir is set, then the basedir should be /tmp

# Generated at 2022-06-21 05:54:52.734085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['/my/path/*.txt'], {'_ansible_check_mode': False}) == []
    assert lookup_module.run(['/my/path'], {'_ansible_check_mode': False}) == []
    assert lookup_module.run(['/my/path/file.txt'], {'_ansible_check_mode': False}) == []
    assert lookup_module.run(['extra/plugins/lookup_plugins/fileglob.py'], {'_ansible_check_mode': False}) == []
    assert lookup_module.run(['fileglob.py'], {'_ansible_check_mode': False}) == []


# Generated at 2022-06-21 05:54:59.602139
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Need a None variable for lookup to set.  Can't be none.
    variable_none = {}
    lookup = LookupModule()
    # Do not have any terms for lookup so creating blank list
    terms = []
    # Run lookup to get list of files
    lookups = lookup.run(terms, variables = variable_none)
    assert(lookups == [])

# Generated at 2022-06-21 05:55:05.588172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate an instance of LookupModule with arguments 'initial.txt' and 'final.txt'
    lookup_instance = LookupModule('initial.txt', 'final.txt')

    # Getter to get value of instance variable
    assert len(lookup_instance.run(terms=[""])) == 0

# Generated at 2022-06-21 05:55:11.211032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LModule = LookupModule()
    terms = ['/etc/passwd', '/etc/hosts']
    variables = {}
    result = LModule.run(terms, variables, wantlist=True)
    assert len(result) == 2
    assert '/etc/hosts' in result
    assert '/etc/passwd' in result

# Generated at 2022-06-21 05:55:13.469026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Test constructor of class LookupModule """
    assert LookupModule(None, None)

# Generated at 2022-06-21 05:55:16.712245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['test.txt']
    ret = module.run(terms=terms)
    assert ret == []

# Generated at 2022-06-21 05:55:17.910947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None


# Generated at 2022-06-21 05:55:18.671249
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule()

# Generated at 2022-06-21 05:55:20.029387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:55:30.018996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # for fileglob, dirname must be present
    assert '*' not in lookup.run(['fileglob', 'foo.txt'], {})
    assert '*' not in lookup.run(['fileglob', 'foo.txt'], {'role_path': '/path/to/role'})

    # there's no file foo.txt in the example file path
    assert '*' not in lookup.run(['fileglob', 'foo.txt'], {'role_path': '/path/to/role',
                                                           'ansible_search_path': ['example_path']})
    # not even a dir named foo.txt

# Generated at 2022-06-21 05:55:41.167268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    inst_lm = LookupModule()

    # Create an array of files and dirs
    file_list = ['file1', 'file2', 'dir1']
    file_abs_paths = []

    # Create files in tmp and get their absolute paths
    for f in file_list:
        full_path = '/tmp/' + f
        if f.find('dir') >= 0:
            os.mkdir(full_path)
        else:
            open(full_path, 'a').close()
        file_abs_paths.append(os.path.abspath(full_path))
    file_abs_paths.append('/tmp')

    # Test without basedir
    os.chdir('/tmp')

# Generated at 2022-06-21 05:55:46.671458
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:55:59.275566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for the fileglob lookup class."""
    # TODO: write a unit test for this class, then remove this print
    print("Testing fileglob")

    # TODO: implement Mock class for search_path
    class search_path:
        def __init__(self, path):
            self.path = path

    # TODO: implement Mock class for variables
    class variables:
        @staticmethod
        def setdefault(key, default):
            if key == 'ansible_search_path':
                return search_path([
                        '/etc',
                        '/etc/fooapp',
                        '/usr/share',
                        '/usr/share/fooapp',
                        '/usr/local',
                        '/usr/local/fooapp',
                    ])
            return None

    # TODO: implement Mock class for LookupBase

# Generated at 2022-06-21 05:56:00.220669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:56:01.756993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-21 05:56:03.815289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 05:56:06.820686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l = l.run(['echo'])
    assert l == [], "LookupFileGlob failed"

# Generated at 2022-06-21 05:56:11.259360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    assert len(t.run(['/my/path/*.txt'])) == 0
    assert len(t.run('/no/such/file')['_list']) == 0
    #TODO implement more tests

# Generated at 2022-06-21 05:56:16.615827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({u'wantlist': u'True'})
    test_dir = os.path.dirname(__file__)
    terms = [u'/path/to/dir/*.yml', u'/path/to/dir/file']
    ret = lookup.run(terms, dict())
    assert u'/path/to/dir/file' in ret
    #assert u'file2' in ret

# Generated at 2022-06-21 05:56:25.241659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleFileNotFound):
        try:
            lookup_module = LookupModule()
            lookup_module.run(['/not-a-valid-term'], variables={'ansible_search_path': ['/']})
        except AnsibleFileNotFound as e:
            assert str(e) == "could not locate file in lookup: /not-a-valid-term"
            raise

# Generated at 2022-06-21 05:56:27.714015
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test parameters
    terms = ['foo']

    # test code - initialize test object
    lookup = LookupModule()

    # test code - run test
    value = lookup.run(terms, [])

    # test assertions
    assert value is not None

# Generated at 2022-06-21 05:56:37.672919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'module' == LookupModule().get_plugin_class()

# Generated at 2022-06-21 05:56:39.692528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Base condition
    assert(True)

# Generated at 2022-06-21 05:56:41.165503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(["*.conf"], {})

# Generated at 2022-06-21 05:56:43.833262
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This only tests that it doesn't raise an exception, for coverage.
    LookupModule(None, None)

# Generated at 2022-06-21 05:56:50.498625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing the constructor of LookupModule...')
    lookupModule = LookupModule()

    # Tests for method run
    print('Testing method run of LookupModule...')
    result = lookupModule.run(['/my/path/*.txt'], {'ansible_search_path': ['/home/ubuntu/ansible/path', '/home/ubuntu/.ansible']})
    print('Expected: []')
    print('Actual: {}'.format(result))

    assert result == []

# Generated at 2022-06-21 05:56:51.937197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   assert Callable(LookupModule().run)

# Generated at 2022-06-21 05:56:54.936578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:56:55.989475
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:56:57.540097
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 05:57:04.602719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(["paths/file1", "paths/file2"], variables={"ansible_search_path": ["/base1", "/base2"]}) == ["/base1/paths/file1", "/base2/paths/file1", "/base1/paths/file2", "/base2/paths/file2"]

# Generated at 2022-06-21 05:57:28.573530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ['/my/path/*.txt', '*.txt', 'dummy.txt']

    class Variables:
        def __init__(self):
            self.ansible_search_path = ["/tmp"]
    variables = Variables()

    results = lookup.run(terms, variables)
    assert(len(results)>0)
    assert(results[0] == "/tmp/abc.txt")

    # Test for an exception
    terms = ['/my/path/*.txt', '*.txt', 'dummy.txt', '/my/path/test*']
    results = lookup.run(terms, variables)
    assert(len(results)>0)
    assert(results[0] == "/tmp/abc.txt")

# Generated at 2022-06-21 05:57:34.523272
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        '/some/path/somefile',
        '/some/path/somefile*.txt',
        '/some/path/*.txt',
        '/some/path/*',
        'somefile*.txt'
    ]
    variables = {'ansible_search_path': ['/some/path/.']}
    lookup_module = LookupModule()
    results = lookup_module.run(terms, variables, wantlist=True)
    if len(results) != 3:
        raise Exception('Expected 3 results, got %s' % len(results))
    if results[0] != '/some/path/somefile':
        raise Exception('Expected /some/path/somefile, got %s' % results[0])

# Generated at 2022-06-21 05:57:39.434115
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import copy
    from ansible.plugins.lookup import LookupModule as lookup

    mod = lookup()
    assert isinstance(mod, lookup)
    mod1 = copy.copy(mod)
    assert isinstance(mod1, lookup)

# Generated at 2022-06-21 05:57:40.430906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:57:43.540285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert(lookup_plugin is not None)
    assert(lookup_plugin.get_basedir({}) == ".")
    assert(lookup_plugin.run(['this is not a valid term'], {}, wantlist=True) == [])



# Generated at 2022-06-21 05:57:45.457836
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-21 05:57:48.110091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.get_basedir({}) is not None
    assert lookup_module.run(['foo']) is None

# Generated at 2022-06-21 05:57:50.954142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:57:58.848342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables for the test
    test_values = [{'terms': ['test*.yml']}, {'terms': ['test1.yml']}]
    results = [{'_list': ['test1.yml', 'test2.yml']}, {'_list': ['test1.yml']}]
    lm = LookupModule()
    for test_value, result in zip(test_values, results):
        assert lm.run(**test_value) == result['_list']

# Generated at 2022-06-21 05:58:00.579307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:58:25.458060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # we need to capture the real fileglob module so we can
    # restore it across the test, since we're replacing it
    # with a fake in here
    import ansible.plugins.lookup.fileglob
    real_fileglob_module = ansible.plugins.lookup.fileglob

    import ansible.plugins.lookup
    import ansible.module_utils

    class FakeSearchPath():
        def __init__(self):
            self.aliases = {}

    class FakeVariables():
        def __init__(self):
            self.ansible_playbook_python = None
            self.ansible_play_hosts = None
            self.ansible_play_batch = None
            self.ansible_play_uuid = None

# Generated at 2022-06-21 05:58:34.949020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a class instance
    # Use glob module that does the file matching and return the matched file
    class glob:
        def glob(self, file_path):
            return ["test_file.txt"]
    lm = LookupModule()
    lm.glob = glob()
    
    # Set the data to be returned by the find_file_in_search_path_method
    class variables:
        ansible_search_path = []
        ansible_basedir = "/home/"
    lm.find_file_in_search_path_return_value = "/home/"

    # Invoke the run method of the class LookupModule with the parameters
    ret = lm.run(terms=["test_file.txt"], variables=variables())

    # Assert the results, expected result should be a list containg the file path

# Generated at 2022-06-21 05:58:40.449467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result1 = LookupModule().run('/home/*')
    assert result1 == ['/home/ansible']
    result1 = LookupModule().run(['/home/*.txt', '/*.txt'])
    assert result1 == ['/home/ansible/sample.txt', '/sample.txt']

# Generated at 2022-06-21 05:58:41.152481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:58:53.834185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lup = LookupModule()
    # test case 1
    terms = ["/ansible/library/fact_caching/*"]
    variables = {'role_path': '/etc/ansible/roles'}
    result = lup.run(terms, variables)
    assert isinstance(result, list)
    assert result[0].endswith("/ansible/library/fact_caching/jsonfile.py")
    # test case 2
    terms = ["file.txt"]
    variables = {'role_path': '/etc/ansible/roles'}
    result = lup.run(terms, variables)
    assert isinstance(result, list)
    assert len(result) == 0

# Generated at 2022-06-21 05:58:54.998345
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:59:03.153039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test terms to be feeded to run method
    terms = ['/my/path/*.txt', '/playbooks/files/fooapp/*']

    # Test variables used in run method
    variables = dict(
            ansible_search_path = ['/playbooks/files/fooapp/', '/playbooks/files/fooapp2/'],
            )

    # Test files exists in current path
    open("./ansible-1.txt", 'a').close()
    open("./ansible-2.txt", 'a').close()

    # Test files exists in ../fooapp/ path
    os.mkdir("./fooapp")
    open("./fooapp/ansible-1.txt", 'a').close()
    open("./fooapp/ansible-2.txt", 'a').close()

    #

# Generated at 2022-06-21 05:59:11.222641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = '/my/path/*.txt'
    expected = ['/my/path/file1.txt']
    lm = LookupModule()
    lm.find_file_in_search_path = lambda var, name, path: path
    lm.get_basedir = lambda var: '/my'
    glob.glob = lambda path: expected
    results = lm.run(terms)
    assert results == expected

# Generated at 2022-06-21 05:59:21.973728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['grains.yml', 'grains_sub.yml', 'nofile']
    variables = {'ansible_search_path': ['/home/ansible/tst', '/home/ansible/tst2']}
    lookup_plugin = LookupModule()

    ret = lookup_plugin.run(terms, variables, wantlist=True)
    assert(ret == ['/home/ansible/tst/files/grains.yml', '/home/ansible/tst/files/grains_sub.yml'])

# Generated at 2022-06-21 05:59:24.966491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()

# Generated at 2022-06-21 06:00:07.451628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import copy
    from ansible.parsing.dataloader import DataLoader

    module_utils_path = sys.path[0] + "/../../lib/ansible/module_utils"
    if module_utils_path not in sys.path:
        sys.path.append(module_utils_path)

    from ansible.module_utils.common._collections_compat import MutableMapping

    class Dict(MutableMapping):
        def __init__(self, **kwargs):
            self.store = dict()
            self.update(kwargs)

        def __delitem__(self, key):
            del self.store[key]

        def __getitem__(self, key):
            return self.store[key]


# Generated at 2022-06-21 06:00:10.348644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module != None)


# Generated at 2022-06-21 06:00:19.143904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    src_path = os.path.join(os.path.dirname(__file__), 'test/files/test_fileglob_src')
    basedir = os.path.join(os.path.dirname(__file__), 'test/files')
    output = StringIO()
    lookup = LookupModule()

    # Test with empty terms
    terms = []
    variables = {u'ansible_search_path': [u'/etc/ansible']}
    actual = lookup.run(terms, variables)
    expected = []
    assert actual == expected

    # Test with terms list with only one element:
    #   - Test with a path
    #   - Test with a path ending with '/

# Generated at 2022-06-21 06:00:29.299435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for LookupModule.run() method"""
    import os
    import sys

    # test with list of one file

    # create a lookup object
    lookup = LookupModule()

    # define terms
    terms = [os.path.abspath("../../../../../lib/ansible/plugins/lookup/__init__.py")]

    # define variables
    variables = {'ansible_search_path': [os.path.abspath("../../../../../lib/ansible/plugins/lookup/")]}

    # execute the lookup
    result = lookup.run(terms, variables=variables, wantlist=True)

    # assert results
    assert os.path.abspath("../../../../../lib/ansible/plugins/lookup/__init__.py") in result

    # test with

# Generated at 2022-06-21 06:00:33.417947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test constructor of class LookupModule
    '''
    lookup = LookupModule()
    assert lookup.get_basedir() == '.'

# Unit tests for method run of class LookupModule

# Generated at 2022-06-21 06:00:35.595998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_method(self, terms, variables=None, **kwargs):
        return []
    LookupModule.run = test_method
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:00:40.656933
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert(l.get_basedir({}) == '.')
    assert(l.get_basedir({'ansible_config.directory': '/foo'}) == '/foo')

# Generated at 2022-06-21 06:00:41.873997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_class = LookupModule()

# Generated at 2022-06-21 06:00:47.790031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-variable,unused-argument
    lh = LookupModule()

    # test lookup module run method
    # ansible_search_path exists in variables
    variables = {'ansible_search_path': ['/path1', '/path2']}
    fixed_vars = {'ansible_search_path': ['/path1', '/path2']}
    # term_file matches term
    term = 'test.txt'
    # file exists in search path
    file_in_search_path = os.path.join('/path1/files', to_bytes(term, errors='surrogate_or_strict'))
    os.makedirs(os.path.dirname(file_in_search_path))
    open(file_in_search_path, 'a').close

# Generated at 2022-06-21 06:00:49.232057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)
