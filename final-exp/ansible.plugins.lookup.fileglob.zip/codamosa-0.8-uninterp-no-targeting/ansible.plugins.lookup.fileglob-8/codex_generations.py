

# Generated at 2022-06-21 05:53:18.203217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.get_basedir = lambda variables: None
    lookup.find_file_in_search_path = lambda variables, dirname, filename: os.path.join('/my/path', dirname, filename)
    for terms in [
        ['*.txt'],
    ]:
        results = lookup.run(terms)
        assert(len(results) > 0)
        for result in results:
            assert result.endswith('.txt')

# Generated at 2022-06-21 05:53:22.135423
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dut = LookupModule()
    assert dut.run([
        '/etc/shadow',
        '/etc/shadow-',
    ]) == ['/etc/shadow']

# Generated at 2022-06-21 05:53:22.879975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 05:53:25.609243
# Unit test for constructor of class LookupModule
def test_LookupModule():
  test = LookupModule()
  test.run(['/my/path/*.txt'])
  test.run(['testfile.txt'])
  test.run(['test/testfile2.txt'])
  test.run(['test/testfile3*.txt'])

# Generated at 2022-06-21 05:53:27.214372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of LookupModule
    lm = LookupModule()
    assert lm.lookup_type == 'fileglob'

# unit test for run() of LookupModule

# Generated at 2022-06-21 05:53:32.409859
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_term = os.path.join("c:\\temp\\","test.txt")
    lm = LookupModule()
    test_ret = lm.run([test_term], {})
    assert test_ret == [test_term]

# Generated at 2022-06-21 05:53:41.560318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class
    lu = LookupModule()

    # Create mock of the method find_file_in_search_path
    def mock_find_file_in_search_path(self, variables, basedir, filepath):
        return([])

    lu.find_file_in_search_path = mock_find_file_in_search_path.__get__(lu, LookupModule)

    # Create mock of the method get_basedir
    def mock_get_basedir(self, variables):
        return('/playbooks')

    lu.get_basedir = mock_get_basedir.__get__(lu, LookupModule)

    # Create mocks for os.path methods

# Generated at 2022-06-21 05:53:47.125490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # call the method
    l = LookupModule()
    results = l.run(terms=['*.yml'], variables={'ansible_search_path': ['/fakedir']})

    # verify results
    assert results == [], 'Expected [] got ' + results

# Generated at 2022-06-21 05:53:59.544946
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    import shutil

    dirpath = tempfile.mkdtemp()

    # make a file located in dirpath that matches the pattern
    f = tempfile.NamedTemporaryFile(mode="r+b", delete=False, dir=dirpath)
    pattern = os.path.basename(f.name)
    f.close()

    # Now make a dir that matches the pattern
    dirname = tempfile.mkdtemp(dir=dirpath)

    m = LookupModule()

    # The following should return a list of paths to the dir and file
    # that were created
    assert m.run([dirname]) == [dirname]

    # The following should return a list of paths to the file that
    # was created
    assert m.run([pattern]) == [f.name]

    shut

# Generated at 2022-06-21 05:54:09.784008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    path = os.path.join('lookup_plugins', 'fileglob.py')
    try:
        lookup_class = loader.get_plugin_loader('lookup').get(path, class_only=True)
        try:
            return lookup_class().run(['./test/test.txt'], variables={'test_var': 'test_var'})
        except Exception as e:
            assert False, "lookup should not throw an exception: %s" % e
    except AnsibleFileNotFound:
        assert False, "Unable to find lookup plugin file %s" % path

# Generated at 2022-06-21 05:54:12.510389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:54:14.405712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing LookupModule_run")
    assert False


# Generated at 2022-06-21 05:54:16.394960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global LookupModule
    x = LookupModule()
    assert x

# Generated at 2022-06-21 05:54:20.354808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    src_args = [
        {},
        {
            '_term': 'hosts'
        },
        {
            '_terms': 'hosts'
        },
        {
            '_terms': 'hosts group_vars'
        }
    ]

    for src_arg in src_args:
        LookupModule(src_arg)

# Generated at 2022-06-21 05:54:21.152228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:54:23.054314
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:54:24.433076
# Unit test for constructor of class LookupModule
def test_LookupModule():
    looker = LookupModule()
    assert looker

# Generated at 2022-06-21 05:54:26.473956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:54:37.346067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest
    import os
    import re
    import shutil
    lookupModule = LookupModule()
    lookupModule.basedir = os.getcwd()
    # setup test dir with files
    test_dir = os.path.join(os.getcwd(), "test")
    os.makedirs(test_dir)
    f = open(os.path.join(test_dir, "test1.txt"), "w")
    f = open(os.path.join(test_dir, "test2.txt"), "w")
    f = open(os.path.join(test_dir, "test3.txt"), "w")
    f = open(os.path.join(test_dir, "test4.txt"), "w")

# Generated at 2022-06-21 05:54:49.019674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Declaring lookup module for testing
    lookup_module = LookupModule()
    # Declaring expected content
    expected_terms = ["/my/path/*.txt", "/playbooks/files/fooapp/*"]
    # Declaring expected content
    expected_result = [u"/my/path/foo.txt"]
    # Declaring expected content
    expected_result2 = [u"/my/path/foo.txt", u"/my/path/bar.txt"]

    # Unit test for function run
    assert expected_result == lookup_module.run(terms=["/my/path/*.txt"], variables=None, wantlist=False)
    assert expected_result2 == lookup_module.run(terms=["/my/path/*.txt"], variables=None, wantlist=True)