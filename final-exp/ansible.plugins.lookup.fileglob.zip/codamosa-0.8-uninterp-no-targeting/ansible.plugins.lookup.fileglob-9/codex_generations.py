

# Generated at 2022-06-21 05:53:17.246615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    import sys

    # First, set the current file as the stdin
    sys.stdin = StringIO('foo')
    print(sys.stdin.read())

    l = LookupModule()
    l.run(['/test/test1.txt', '/test/test1/test2.txt'])

# Generated at 2022-06-21 05:53:29.178208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'file' in os.path.basename("/root/file.txt")
    assert to_text("I'm a test") == "I'm a test"
    assert to_text(b"I'm a test") == "I'm a test"
    assert os.path.basename('./file.txt') == 'file.txt'
    assert os.path.basename('file.txt') == 'file.txt'
    assert os.path.basename('/root/file.txt') == 'file.txt'
    assert os.path.basename('file.txt') == 'file.txt'
    assert os.path.basename('/root/file.txt') == 'file.txt'
    assert not os.path.basename('') == 'file.txt'

# Generated at 2022-06-21 05:53:30.598554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-21 05:53:32.699342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup != None)

# Generated at 2022-06-21 05:53:41.020345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.facts import pwd
    from ansible.module_utils.facts import os

    LookupModule_obj = LookupModule()
    os.path.isfile = lambda x: True
    glob.glob = lambda x: [ 'file1', 'file2', 'file3' ]
    pwd.getpwuid = lambda x: '/home/user'
    os.path.join = lambda x, y: y

    print(LookupModule_obj.run([ '*.txt', '*.py' ], variables={ 'ansible_search_path': [ '/home/user/files/', '/' ], 'ansible_user_dir': '/home/user/files/' }))


# Generated at 2022-06-21 05:53:41.922527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:53:45.283430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Create object of LookupModule class
    lookup_mod = LookupModule()

    assert lookup_mod._basedir == os.getcwd()

# Generated at 2022-06-21 05:53:46.121276
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:53:47.583362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 05:53:52.439462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # test return type of run method
    assert(isinstance(lm.run([''], {}), list))

# Generated at 2022-06-21 05:53:55.391355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 05:53:56.717104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-21 05:54:05.982487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'wantlist': True})

# Generated at 2022-06-21 05:54:12.668233
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create object of type LookupModule
    lookup_object = LookupModule()

    # Create object of type class ansible.parsing.dataloader.DataLoader with default arguement "/home/ansible"
    data_loader_object = ansible.parsing.dataloader.DataLoader("/home/ansible")

    # Create object of type class ansible.vars.manager.VariableManager with arguements data_loader_object and None
    variable_manager_object = ansible.vars.manager.VariableManager(data_loader_object, None)

    test_term_1 = "hello"
    test_term_2 = "*.txt"
    test_terms = [test_term_1, test_term_2]

# Generated at 2022-06-21 05:54:15.409500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    terms = ['*/*.txt']
    variables = dict()
    variables['ansible_search_path'] = ['/usr/local/ansible/']
    variables['ansible_fileglob'] = False
    # TODO: Use an actual file to test.
    assert x.run(terms, variables) == []

# Generated at 2022-06-21 05:54:23.064199
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1: no file found
    file_name = "/this/file/does/not/exist.txt"
    terms = [file_name]
    variables = {}
    lm = LookupModule()
    res = lm.run(terms, variables, wantlist=True)
    assert res == []

    # Test 2: one file found
    terms = [file_name]
    variables = {}
    lm = LookupModule()
    res = lm.run(terms, variables, wantlist=True)
    assert res == []

    # Test 3: two files found
    terms = [file_name]
    variables = {}
    lm = LookupModule()
    res = lm.run(terms, variables, wantlist=True)
    assert res == []

    # Test 4: three files found

# Generated at 2022-06-21 05:54:28.335900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(["my/path/*.txt"], {"ansible_search_path": ["/home/ansible/playbooks"]})
    assert result == ['/home/ansible/playbooks/files/my/path/file1.txt', '/home/ansible/playbooks/files/my/path/file2.txt']



# Generated at 2022-06-21 05:54:30.435091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_run = LookupModule()
    assert(LookupModule_run.run('/my/path/*.txt', variables=None, **kwargs)== None)

# Generated at 2022-06-21 05:54:39.920870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    my_loader = DataLoader()
    my_inventory = InventoryManager(loader=my_loader, sources=['/dev/null'])
    my_var_manager = VariableManager(loader=my_loader, inventory=my_inventory)
    hostvars = HostVars(loader=my_loader, variable_manager=my_var_manager, host_name="localhost")
    hostvars.set_variable("ansible_search_path", ["test_path1", "test_path2"])
    my_var_manager.set_host

# Generated at 2022-06-21 05:54:50.504198
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    fileglob_lookup = LookupModule()

    # Minimal test
    assert fileglob_lookup.run(['./*'], {}) == ['./fileglob.py']

    # Test with dirs
    assert fileglob_lookup.run(['*.py'], {}) == ['fileglob.py', '__init__.py']
    assert fileglob_lookup.run(['*.py'], {'ansible_search_path':['../lookup_plugins']}) == ['fileglob.py', '__init__.py']

    # Test with dirs and extra files

# Generated at 2022-06-21 05:55:00.630033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'color': 'blue'}

    lookup_plugin = LookupModule()
    ret = lookup_plugin.run([
        "*.txt", "/my/path/*.txt",
        "not-a-file",
    ], variable_manager=variable_manager, loader=loader, wantlist=True)

    assert len(ret) == 2
    assert 'first' in ret[0]
    assert 'second' in ret[1]

# Generated at 2022-06-21 05:55:11.858481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init
    lookup = LookupModule()
    lookup.terminal = None
    lookup.runner = None

    # Test case 1
    content = ['../*.md', '../*.yaml']

# Generated at 2022-06-21 05:55:13.543595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:55:16.788738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run'), "Lookup module constructor failed to create run method"

# Generated at 2022-06-21 05:55:22.676187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_loader = None
    mock_templar = None
    mock_basedir = "/"

    lu = LookupModule(loader=mock_loader, templar=mock_templar, basedir=mock_basedir)
    terms = ['somefile.txt']
    ret = lu.run(terms=terms, **{'wantlist': True})
    assert(len(ret) > 0)  # There should be some paths in the results

    ret = lu.run(terms=terms, **{'wantlist': False})
    assert(ret == "")  # There should be no paths in the results

    terms = ['somefile.txt', 'anotherfile.txt']
    ret = lu.run(terms=terms, **{'wantlist': True})
    assert(len(ret) > 0)

# Generated at 2022-06-21 05:55:23.868650
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule)) # Check if return type is LookupModule

# Generated at 2022-06-21 05:55:33.377749
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import __main__
    __main__.file_root = os.path.realpath('test/unit/lookup_plugins/data')
    __main__.file_root = os.path.realpath('test/unit/lookup_plugins/data')
    lookup = LookupModule(loader=None, variables={'ansible_search_path': ['common']})

    results = sorted(lookup.run(['test.yml', 'test.txt', 'test_not_exist'], __main__.file_root))
    assert results == sorted(['test/unit/lookup_plugins/data/common/files/test.txt', 'test/unit/lookup_plugins/data/common/test.yml'])


# Generated at 2022-06-21 05:55:37.563831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test return value of method run
    assert lookup.run(terms=['/tests/*.ini']) == [to_text('/tests/test_fileglob.ini')]

# Generated at 2022-06-21 05:55:40.083786
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return ['/tmp/foo.txt /tmp/bar.txt', '/tmp/blah.txt']

# Generated at 2022-06-21 05:55:41.902363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    ret = lookup.run([])


# Generated at 2022-06-21 05:55:54.302182
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestPlugin(object):
        
        def __init__(self, source=None):
            self.source = source
            
        def _do_remote_expand(self, source):
            return source
        

    class MockVarManager(object):
       
        def __init__(self, variables=None):
            self.variables = variables
            
        def get_vars(self, play=None, host=None, task=None, include_hostvars=False, include_delegate_to=False):
            return self.variables
        
        
    class MockRunner(object):
        
        def __init__(self, variables=None):
            self.var_manager = MockVarManager(variables)
            
        def get_basedir(self):
            return "/some/base/path"
        


# Generated at 2022-06-21 05:55:59.781000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Generate a test module
    # TODO: Generate a test ansible engine
    module = None
    engine = None
    term = ['foo1']
    variables = {}

    lookup_mod = LookupModule()

    result = lookup_mod.run(terms=term, variables=variables)

    # TODO: Add assert
    # TODO: Verify that ansible engine is called

# Generated at 2022-06-21 05:56:01.901737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['/my/path/*.txt']) == []

# Generated at 2022-06-21 05:56:11.184271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    terms = ['file1.txt', 'file2.txt', 'file3.txt']
    lookup_terms = [['file1.txt', 'file2.txt'], ['file3.txt'], ['file2.txt']]
    variables = {'ansible_search_path': ['my/path1', 'my/path2']}
    my_lookup = LookupModule()
    my_lookup.variables = variables
    my_lookup.get_basedir = lambda v: v['ansible_search_path'][0]
    my_lookup.find_file_in_search_path = lambda v, s, p: v['ansible_search_path'][0]

    file_path_first = 'my/path1/file1.txt'

# Generated at 2022-06-21 05:56:22.155832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class FakeVars(object):
        def __init__(self, path):
            self.ansible_search_path = path

    assert ('/foo/bar/file.txt' == LookupModule.run(LookupModule(),
                                                    ['file.txt'],
                                                    FakeVars(['/foo/bar/']),
                                                    wantlist=True)[0])
    assert ('/foo/bar/file.txt' == LookupModule.run(LookupModule(),
                                                    ['/foo/bar/file.txt'],
                                                    FakeVars(['/foo/bar/']),
                                                    wantlist=True)[0])

# Generated at 2022-06-21 05:56:23.759269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print (LookupModule)

# Generated at 2022-06-21 05:56:24.649636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup is not None

# Generated at 2022-06-21 05:56:31.774597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check with a proper pattern
    lookup_module = LookupModule()
    terms = ['/tmp/test*']
    ret = lookup_module.run(terms)
    assert type(ret) == list
    assert len(ret) == 1
    assert ret[0].startswith('/tmp/test')

    # check without a pattern
    lookup_module = LookupModule()
    terms = ['/tmp/test']
    ret = lookup_module.run(terms)
    assert type(ret) == list
    assert len(ret) == 1
    assert ret[0] == '/tmp/test'

    # check for a directory
    lookup_module = LookupModule()
    terms = ['/tmp/']
    ret = lookup_module.run(terms)
    assert type(ret) == list

# Generated at 2022-06-21 05:56:34.174506
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('testing the constructor of LookupModule')
    lm = LookupModule()


# Generated at 2022-06-21 05:56:36.930334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:56:45.464507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:56:52.325323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run of class LookupModule."""
    import pytest
    import os
    lookup_module = LookupModule()
    terms = ['fake_file_non_existent', 'fake_file_existent.txt']
    # Test that method return the terms if no files are found
    assert lookup_module.run(terms) == []
    # Test that method return the terms if a file is found
    fd = open(terms[1], 'a')
    fd.close()
    assert lookup_module.run(terms) == [terms[1]]
    os.remove(terms[1])

# Generated at 2022-06-21 05:56:58.124226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for method run of class LookupModule
    lookup_test = LookupModule()
    term = ['/test_file/test_term']
    variables = ['/test_file/test_variables']
    assert lookup_test.run(term, variables) == []

# Generated at 2022-06-21 05:57:09.820081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for a missing file
    os.path.exists = lambda path: False
    lookup = LookupModule()
    lookup.get_basedir = lambda variables: 'test/test_files'
    lookup.find_file_in_search_path = lambda variables, subdir, filepath: lookup.get_basedir(variables) + '/files/' + filepath
    glob.glob = lambda path: []
    found_files = lookup.run('not.found')
    assert found_files == []

    # Tests for an existing file
    os.path.exists = lambda path: True
    lookup = LookupModule()
    lookup.get_basedir = lambda variables: 'test/test_files'

# Generated at 2022-06-21 05:57:16.437016
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    assert hasattr(lm, 'run')

    # This is the reason we need to test.  Trying to get this to work in 2.6 was a problem
    assert lm.run(["/etc/*"], {}, variables={'ansible_search_path': ['/etc/']}) == ['/etc/passwd']

# Generated at 2022-06-21 05:57:24.369522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test 1
    p = '/path/foo.txt'
    result=lookup.run([p], os.path.isdir('/path'))
    assert result == [p]
    # Test 2
    q = '/path/to/foo.txt'
    result=lookup.run([q], os.path.isdir('/path/to'))
    assert result == [q]

# Generated at 2022-06-21 05:57:26.593022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['myfile'], variables={}, wantlist=False) == ''

# Generated at 2022-06-21 05:57:32.592079
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # first, test that the prefix of fileglob based on the target is handled correctly
    # (but don't do the actual glob)
    test_lookup = LookupModule()
    test_lookup.find_file_in_search_path = lambda x, y, z: y + os.path.sep + z
    assert ['/etc/fooapp/fooapp_*.conf'] == test_lookup.run(["fooapp_*.conf"], variables={'inventory_hostname': 'target1'})
    assert ['/etc/fooapp/fooapp_*.conf'] == test_lookup.run(["fooapp_*.conf"], variables={'inventory_hostname': 'target2'})

# Generated at 2022-06-21 05:57:39.596400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    res = lookup_plugin.run(["/tmp/*.txt"], dict(ansible_search_path=["/tmp", "/home/one"]))
    assert res == []

    res = lookup_plugin.run(["*.txt"], dict(ansible_search_path=["/tmp", "/home/one"]))
    assert res == [
        '/tmp/file1.txt',
        '/tmp/file2.txt',
        '/tmp/file3.txt',
    ]

# Generated at 2022-06-21 05:57:47.692003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options()
    terms = ['/tmp/test.txt']
    variables = dict()
    variables['ansible_search_path'] = ['/home/sansible']
    variables['ansible_search_path'].append('/etc')
    variables['ansible_search_path'].append('/tmp')
    result = lookup.run(terms, variables)
    print(result)

# Generated at 2022-06-21 05:58:04.284532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run([])

# Generated at 2022-06-21 05:58:05.721240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 05:58:10.867006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "test{0}"
    lookup = LookupModule()
    terms = [term.format(i) for i in range(2)]
    variables = {"ansible_search_path":["test{0}".format(i) for i in range(3)]}
    res = lookup.run(terms, variables)
    assert len(res) == len(terms)
    for i in range(len(res)):
        assert res[i] == term.format(i) + ".txt"

# Generated at 2022-06-21 05:58:12.822587
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj1 = LookupModule()
    assert obj1 is not None

# Generated at 2022-06-21 05:58:13.659562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test")

# Generated at 2022-06-21 05:58:15.700227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-21 05:58:16.732177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-21 05:58:17.941291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 05:58:21.956102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    terms = ['/tmp/does-not-exist/*.gz']
    # Create a dummy instance of LookupModule class
    lookup = LookupModule()

    with pytest.raises(AnsibleFileNotFound):
        lookup.run(terms, dict())

# Generated at 2022-06-21 05:58:24.608495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-21 05:58:56.534017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 05:58:57.125117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:59:04.976335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Just verify if method run needs some special setup.
    # It is only focused on providing test coverage
    self = LookupModule(None)
    assert self.run(["/a/b", "/c/d"], {'paths':["paths-1","paths-2"],
                                       'ansible_search_path':["ansible_search_path-1","ansible_search_path-2"],
                                       'env':{'PWD':"env-PWD"}}) == []

# Generated at 2022-06-21 05:59:13.932085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing lookup with a mock loader as done in ansible
    # ansible/plugins/loader.py
    from ansible.plugins.loader import LookupModuleLoader

    loader = LookupModuleLoader()
    lookup = loader.get('fileglob')

    # creating a test file and directory
    temp_dir = "temp_dir"
    os.mkdir(temp_dir)
    os.chdir(temp_dir)

    temp_file = "test.txt"
    with open(temp_file, "w") as f:
        f.write("content")

    # There are two possible answers, hence checking both
    # If a file is present in the current directory its return value is
    # absolute file path
    # If a file is present in the ansible search paths its return value is
    # relative file path
    # ansible

# Generated at 2022-06-21 05:59:22.800986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict(wantlist=True))
    # file exists
    assert lookup_module.run(['myfile', '/path/to/myfile'], variables={'ansible_search_path': ['/path/to']}) == ['/path/to/myfile']
    # file does not exist
    assert lookup_module.run(['myfile', '/path/to/myfile'], variables={'ansible_search_path': ['/path/to/']}) == []


# Generated at 2022-06-21 05:59:25.100446
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True


# Generated at 2022-06-21 05:59:34.750087
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    collector = LookupModule()
    assert collector.run([u'/tmp/file*']) == []

    # test with wantlist=False
    assert collector.run([u'/tmp/file*'], wantlist=False) == ''
    assert collector.run([u'/tmp/file*'], variables={u'ansible_search_path': [u'/tmp']}, wantlist=False) == '/tmp/file*'
    assert collector.run([u'/tmp/file/'], variables={u'ansible_search_path': [u'/tmp']}, wantlist=False) == ''
    assert collector.run([u'/tmp/file/hello.txt'], variables={u'ansible_search_path': [u'/tmp']}, wantlist=False) == ''

# Generated at 2022-06-21 05:59:41.617203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    basedir = lookup.get_basedir({})
    remote_file = os.path.join(basedir, 'file')
    os.mknod(remote_file)
    result = lookup.run([remote_file], {}, wantlist=True)[0]
    os.unlink(remote_file)
    assert result == [remote_file]

# Generated at 2022-06-21 05:59:50.887699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Using the module as a lookup plugin
    lookup = LookupModule()
    result = lookup.run(['../../../etc/*'])
    assert result == [], "Testing fileglob failed, as it is testing using the actual files"
    # Using the module as an actual Ansible module
    result = LookupModule().run(['../../../etc/*'], dict(vars={'ansible_search_path': ['../../..']}), wantlist=True);
    assert result == [], "Testing fileglob failed, as it is testing using the actual files"

# Generated at 2022-06-21 05:59:58.471563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the LookupModule with a base directory (this directory is where the fixtures live)
    lookup_module = LookupModule(basedir='test/fixtures/lookup_plugins')
    # Get a file that exists
    result = lookup_module.run(['test.txt'], variables={'test': 'test'})
    assert result == [to_text('test/fixtures/lookup_plugins/test.txt', errors='surrogate_or_strict')]
    # Get a file that does not exist
    result = lookup_module.run(['not_here.txt'], variables={'test': 'test'})
    assert result == []