

# Generated at 2022-06-21 05:53:15.618546
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None


# Generated at 2022-06-21 05:53:18.811732
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run([],{})
    assert LookupModule().run(['/my/path/*.txt'],{})
    assert LookupModule().run(['/playbooks/files/fooapp/*'],{})

# Generated at 2022-06-21 05:53:30.702780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Positive test1: Verify fileglob results with terms having wildcards in filename
    terms = ["/my/path/my.txt", "/my/path/my.txt1", "my.txt*"]
    fake_variables = {'ansible_search_path:': "/home/ansible/playbooks"}
    fg = LookupModule()
    result = fg.run(terms, fake_variables)
    assert result[0] == "/home/ansible/playbooks/my.txt"
    assert result[1] == "/home/ansible/playbooks/my.txt1"
    assert result[2] == "/home/ansible/playbooks/my.txt"

    # Positive test2: Verify fileglob is case insensitive
    terms = ["my.txt", "my.txt1", "my.txt*"]


# Generated at 2022-06-21 05:53:40.966169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import shutil
    import tempfile
    import os

    test_dir = tempfile.mkdtemp(prefix='ansible-test.')
    os.chdir(test_dir)

    test_lookup = LookupModule()


# Generated at 2022-06-21 05:53:44.401085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    ret = lm.run(terms=["*.txt"])
    assert isinstance(ret, list)

# Generated at 2022-06-21 05:53:45.803397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test

# Generated at 2022-06-21 05:53:54.081979
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.vault import VaultLib
    def get_vault_secret(filename):
        """ Dummy method for testing. """
        return VaultLib(filename)

    terms = ["foo", "bar"]
    variables = {}
    lookup_module = LookupModule()
    lookup_module.get_vault_secret = get_vault_secret
    if os.path.sep == '/':
        test_results = lookup_module.run(terms, variables)
    else:
        test_results = lookup_module.run(terms, variables)

    assert test_results == ["foo", "bar"]

# Generated at 2022-06-21 05:54:03.139060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule class
    lm = LookupModule()
    # Create non-existing file /tmp/foo.txt
    non_existing_file = '/tmp/foo.txt'
    # Create existing file /tmp/bar.txt
    existing_file = '/tmp/bar.txt'
    open(existing_file, 'a').close()

    # Try to find non-existing file at non-existing path
    res = lm.run([non_existing_file])
    assert res == []

    # Try to find existing file at non-existing path
    res = lm.run([existing_file])
    assert res == []

    # Try to find non-existing file at existing path
    res = lm.run(['foo.txt'], {'ansible_search_path':['/tmp']})
    assert res

# Generated at 2022-06-21 05:54:04.534899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    s = LookupModule()

# Generated at 2022-06-21 05:54:06.434087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-21 05:54:14.197399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = DummyModule()
    lookup = LookupModule(module)
    assert lookup.run(terms=['*.txt'], variables={'ansible_search_path': ['/some/place']}) == ['/some/place/files/a.txt']



# Generated at 2022-06-21 05:54:22.651989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Replace the following values with ones that make sense for your setup
    local_base_dir = r"C:\Users\Me\Documents\Ansible\Repos\ansible\lib\ansible\plugins\lookup"
    term = r"C:\Users\Me\Documents\Ansible\Repos\ansible\lib\ansible\plugins\lookup\fileglob.py"
    term_file = r"fileglob.py"

# Generated at 2022-06-21 05:54:30.665965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    _terms = ['/some/path/*.txt']
    _variables = {}
    ret = lookup.run(_terms, _variables)
    assert len(ret) == 0

    _terms = ['/some/path/hello.txt']
    _variables = {}
    ret = lookup.run(_terms, _variables)
    assert len(ret) == 0

    _terms = ['hello']
    _variables = {'ansible_search_path':['/some/path']}
    ret = lookup.run(_terms, _variables)
    assert len(ret) == 0

# Generated at 2022-06-21 05:54:32.383529
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l.run(terms=["non-existent-file"])

# Generated at 2022-06-21 05:54:39.297464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run([], {'playbook_dir': '/playbooks'}) == []

    assert lookup_module.run(['*.txt'], {'playbook_dir': '/playbooks'}) == []

    assert lookup_module.run(['*.txt'], {'playbook_dir': '/playbooks',
                                         'ansible_search_path': ['/folder1', '/folder2']}) == []

    assert lookup_module.run(['*.txt'], {'playbook_dir': '/playbooks',
                                         'ansible_search_path': ['/folder1', '/folder2']}) == []


# Generated at 2022-06-21 05:54:45.899170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule object
    obj = LookupModule()
    assert obj is not None
    # Create terms
    terms = []
    # Create variables
    variables = []
    # Create kwargs
    kwargs = []
    result = obj.run(terms, variables, **kwargs)
    assert result == []

# Generated at 2022-06-21 05:54:48.095082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run can't be tested, because os.path.isdir is used in the method.
    # The test is generated using a parameterized fixture.
    pass

# Generated at 2022-06-21 05:54:49.588587
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:54:51.023353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    X = LookupModule()

# Generated at 2022-06-21 05:54:53.037728
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Unit test

# Generated at 2022-06-21 05:54:57.716315
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    results = lookup_plugin.run([u'/etc/passwd'])
    assert results[0] == u'/etc/passwd'

# Generated at 2022-06-21 05:55:02.132019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_glob = LookupModule()
    test_glob.run(['test_dir/*'], {'test_dir': '.'})
    assert test_glob

# Generated at 2022-06-21 05:55:07.813008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    test = LookupModule(variables=variable_manager)
    assert test._basedir == u'/etc/ansible'

# Generated at 2022-06-21 05:55:17.718292
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test LookupModule object
    ll = LookupModule()
    
    # Create a test result object
    result = ['test_file1.txt']

    # Create a test terms object
    terms = ['test_file*.txt']

    # Create a test variables object 
    variables = {'ansible_search_path':['./g', './']}

    # Compute the expected results
    expected_results = ll.run(terms, variables)

    # Ensure that the results are what we expected
    assert expected_results == result

# Generated at 2022-06-21 05:55:22.537293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test case for method LookupModule.run
        print "test_LookupModule_run"
        print "unsupported yet"
    '''
    lookup_module = LookupModule()
    lookup_module.run([])

# Generated at 2022-06-21 05:55:23.399356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:55:28.314597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    myPath = os.path.dirname(os.path.abspath(__file__))
    myLookupModule = LookupModule()
    myList = myLookupModule.run(["fileglob_testfile_exists"], {})
    assert myList[0] == os.path.join(myPath, "fileglob_testfile_exists")

# Generated at 2022-06-21 05:55:33.557493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for term in ["test/test.conf", "test/*.conf"]:
        for wantlist in [True, False]:
            lookup = LookupModule()
            results = lookup.run([term],wantlist=wantlist)
            assert results



# Generated at 2022-06-21 05:55:34.523347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:55:40.062861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: All of the code in this code block is commented out
    # because the lookup modules are not available
    # in the unit testing framework.  TODO: move them elsewhere?
  
    test_lookup = LookupModule()
    test_terms = ["abc", "def"]
    test_variables = {}
    
    test_ret = test_lookup.run(test_terms, test_variables)
    assert len(test_ret) == 0