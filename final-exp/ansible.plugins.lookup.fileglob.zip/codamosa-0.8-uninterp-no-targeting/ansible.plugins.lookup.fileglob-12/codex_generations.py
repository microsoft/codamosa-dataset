

# Generated at 2022-06-21 05:53:14.796074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:53:17.208484
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = ['test_terms', 'test_terms2']
    lookup_module = LookupModule()
    assert lookup_module.run(test_terms) == []

# Generated at 2022-06-21 05:53:18.573358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()
    assert test_object

# Generated at 2022-06-21 05:53:20.822295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)

# Generated at 2022-06-21 05:53:21.656487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:53:22.283461
# Unit test for constructor of class LookupModule
def test_LookupModule():
   assert hasattr(LookupModule, "run")

# Generated at 2022-06-21 05:53:30.456050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()

    dir = os.path.dirname(__file__)
    subdir = os.path.join(dir, 'lookup_plugins')
    subdir_module_utils = subdir.replace('lookup_plugins', 'module_utils')
    ansible_module_utils = os.path.join(dir, '..', 'module_utils')

    # Case 1: fileglob lookup
    terms = ["fileglob_test_files/fileglob_test_file.txt"]
    ret = test_lookup.run(terms)
    assert(ret == ['{0}/fileglob_test_files/fileglob_test_file.txt'.format(dir)])

    # Case 2: no match found

# Generated at 2022-06-21 05:53:31.948751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test for constructor of class LookupBase
    try:
        obj = LookupModule()
    except:
        return False
    return True

# Generated at 2022-06-21 05:53:41.358238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = "test_*/**"
    ret = module.run(terms)
    assert ret == ['test_fileglob/files/a.txt', 'test_fileglob/files/subdir/b.txt']

    terms = "test_*/**"
    ret = module.run(terms, wantlist=True)
    assert ret == [['test_fileglob/files/a.txt', 'test_fileglob/files/subdir/b.txt']]

    terms = "test_*/**"
    ret = module.run(terms, wantlist=True, prefer_dn=True)
    assert len(ret) == 1
    assert len(ret[0]) == 2
    assert ret[0][0] == 'test_fileglob/files/a.txt'

# Generated at 2022-06-21 05:53:52.705829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # empty term
    terms = []
    variables = {}
    result = lm.run(terms, variables)
    assert result is None
    # term with path
    terms = ['/tmp/*.txt']
    variables = {}
    result = lm.run(terms, variables)
    assert result is None
    # term with non-existing path
    terms = ['/tmp/random_path/*.txt']
    variables = {}
    result = lm.run(terms, variables)
    assert result is None
    # term with existing path
    terms = ['/tmp/*.txt']
    variables = {}
    result = lm.run(terms, variables)
    assert result is None
    # term with dir
    terms = ['/tmp/*']
    variables = {}
    result = lm

# Generated at 2022-06-21 05:53:55.944225
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:54:09.503718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create test object
    lookup = LookupModule(None, None)
    # create an empty variable
    variables = None
    # create an empty string
    term = ""
    # call method run of class LookupModule
    ret = lookup.run(terms=[term], variables=variables)
    # test that the return value is of type list
    assert isinstance(ret, list)
    # test that ret is not empty
    assert ret
    # test that the first element of the list is of type string
    assert isinstance(ret[0], str)
    # create test object
    lookup = LookupModule(None, None)
    # create variables
    variables = None
    # create a string object
    term = "/etc"
    # call method run of class LookupModule

# Generated at 2022-06-21 05:54:20.991350
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Normal usage
    test_module = LookupModule()
    result = test_module.run(['*.txt'])
    assert type(result) == list

    # No file found
    result = test_module.run(['*.txt'], variables={'ansible_search_path': ['/nofile']})
    assert type(result) == list

    # No file found, but file found in search_paths
    result = test_module.run(['*.txt'], variables={'ansible_search_path': ['/usr/share/cups']})
    assert type(result) == list

    # Unable to read cwd
    cwd = os.getcwd()
    os.chdir('/unreadable')

# Generated at 2022-06-21 05:54:31.845635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    abs_path = os.path.abspath(__file__)
    base_path = os.path.dirname(os.path.dirname(abs_path))
    lookup_mod = LookupModule()
    # test 'ansible_search_path' not in variables
    lookup_mod.set_options({'_ansible_basedir': base_path})
    result = lookup_mod.run(['/path/to/file', 'test1.txt'])
    assert result == [os.path.join(base_path, 'test1.txt')]
    expected_result = ['test1.txt']
    assert result == expected_result

    # test 'ansible_search_path' in variables
    lookup_mod.set_options({'_ansible_basedir': base_path})
    result = lookup_mod

# Generated at 2022-06-21 05:54:32.901809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert type(look)

# Generated at 2022-06-21 05:54:34.060650
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:54:36.513788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 05:54:49.144216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.path import unfrackpath
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader


    # Create a mock for ansible.module_utils.basic.AnsibleModule
    # class AnsibleModule:
    #     def __init__(self, argument_spec, bypass_checks=False, no_log=False,
    #                  mutually_exclusive=None, required_together=None,
    #                  required_one_of=None, add_file_common_args=False,
    #                  supports_check_mode=False):
    #         pass

    # Create a mock for ans

# Generated at 2022-06-21 05:54:49.966217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 05:54:53.259825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)
    assert hasattr(l, 'run')


# Generated at 2022-06-21 05:55:00.037504
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/etc/ansible/ansible.cfg', '*.cfg']
    variables = {'ansible_search_path': ['/etc/ansible', '/etc/other_path']}
    expected_result = ['/etc/ansible/ansible.cfg']
    result_expected = LookupModule().run(terms, variables)
    assert(expected_result==result_expected)

# Generated at 2022-06-21 05:55:01.427742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().__class__ == LookupModule

# Generated at 2022-06-21 05:55:06.203540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    res = lookup_module.run(['/my/path/*.txt'])
    assert len(res) > 0
    assert isinstance(res[0], str)
    assert isinstance(res, list)

# Generated at 2022-06-21 05:55:19.025306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    #test basedir
    basedir = lookup_module.get_basedir({'playbook_dir': 'playbookdir'})
    assert basedir == 'playbookdir'
    #test find_file_in_search_path
    search_path = lookup_module.find_file_in_search_path({'ansible_search_path': os.path.split(os.path.abspath('.'))}, 'files', 'test')
    assert search_path == 'test'
    #test run
    result = lookup_module.run([os.path.join('test', 'test.py')], {}, wantlist=True)
    assert os.path.split(os.path.abspath(result[0]))[1] == 'test.py'

# Generated at 2022-06-21 05:55:23.321857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(Runner()).run(['*.txt']) == ["file2.txt"]
    assert LookupModule(Runner()).run(['*']) == ["file1.txt"]


# Generated at 2022-06-21 05:55:26.587880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test run method LookupModule
    :return:
    '''
    lm = LookupModule()
    lm.run(terms='/tmp/*')

# Generated at 2022-06-21 05:55:30.789185
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm.get_basedir({}) == os.getcwd()
    assert lm.m

# Generated at 2022-06-21 05:55:34.590358
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Check to see if the class is correctly initialized
    # object_1 = FileGlob()
    object_1 = LookupModule()

    assert object_1

# Generated at 2022-06-21 05:55:35.678122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:55:36.493894
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 05:55:53.677799
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:55:56.965720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_module = LookupModule()
    assert test_lookup_module.run(terms=[], variables=None, **{}) == []

# Generated at 2022-06-21 05:56:09.160934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Setup test environment
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    # Add a variable
    variable_manager.extra_vars = {
        'test_variable': 'Test variable'
    }

    # Initialize LookupModule class
    lookup_module = LookupModule()

    # Run run() method
    lookup_module.run([
        'test_lookup_plugin.py',
    ], variables=variable_manager.extra_vars)

# Generated at 2022-06-21 05:56:17.820323
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test call without any parameters
    lookup_module = LookupModule()
    assert lookup_module.run(terms=None) == []

    # test call with wrong parameters
    try:
        lookup_module.run(terms=['/var/log/'])
    except AnsibleFileNotFound as e:
        assert e.errno == 2
        assert e.strerror == "No such file or directory"
        assert e.filename == '/var/log/'
    except Exception as e:
        raise
    else:
        raise Exception("AnsibleFileNotFound not raised")

    # test call with correct parameters
    with open('/tmp/fileglob.txt', 'w') as f:
        f.write('')

# Generated at 2022-06-21 05:56:20.479820
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-21 05:56:30.394582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # testing with a simple term
    assert module.run(["/etc/hostname"]) == ["/etc/hostname"]
    # testing with an '*' term
    ansible_playbook_path = os.path.abspath(__file__)
    assert module.run([os.path.split(ansible_playbook_path)[0]+"/test*.py"]) == [ansible_playbook_path]
    # testing with a term with wildcard inside directory
    assert module.run(["/etc/*.cfg"]) == []
    # testing with a term which does not exist
    assert module.run(["/etc/foo"]) == []
    # testing with a term which contains a directory
    assert module.run(["/etc"]) == []
    # testing with a list of

# Generated at 2022-06-21 05:56:39.937192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes
    from unit.mock.loader import DictDataLoader
    from unit.mock.paths import mock_unfrackpath_noop

    terms = [
        'file1',
        'file1_dir/file2',
        'file1_dir/file_dne',
        'file1_dir/file3_dne',
        'file1_dir/file3',
        'file1_dir/file3a',
        'file1_dir/file3b'
    ]

    # Create a directory with several files
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 05:56:41.573574
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule() is not None)

# Generated at 2022-06-21 05:56:47.026125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    base = LookupModule()
    assert(base.run(['*.j2']) == [])
    assert(base.run(['*.txt']) == [])
    # Test with an existing file
    assert(base.run(['*.rst']) != [])

# Generated at 2022-06-21 05:56:50.289179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  test_LookupModule = LookupModule()
  assert test_LookupModule.run("*") == []

# Generated at 2022-06-21 05:57:03.823298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the plugin
    lookup = LookupModule()

    # Testing function with the file .test_ansible_fileglob_1.txt in the directory test_input
    import os.path
    root_test_dir = os.path.normalize(os.path.join(os.path.dirname(__file__), ".."))
    test_dir = os.path.join(root_test_dir, "test_input")
    file_path = os.path.join(test_dir, ".test_ansible_fileglob_1.txt")
    # Test 1
    terms = ["*"]  # Path with the files
    variables = {"ansible_search_path": [test_dir, test_dir]}  # Variables
    # Expected result
    expected_result = [file_path]
   

# Generated at 2022-06-21 05:57:11.268208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.context import context
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.path import unfrackpath

    context.CLIARGS = dict()
    context._init_global_context(context.CLIARGS)

    lookup_instance = LookupModule()

    if PY2:
        cur_dir = to_bytes(os.getcwd(),errors='strict')
        folders = [to_bytes(os.path.join(cur_dir, "doc"),errors='strict'), to_bytes(os.path.join(cur_dir, "include"),errors='strict')]

# Generated at 2022-06-21 05:57:20.327557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    content = """
- hosts: all
  tasks:
    - fileglob:
        _terms:
          - /etc/ansible/test
    - fileglob:
        _terms:
          - /etc/ansible/test2
"""
    with open("/etc/ansible/test", "w") as f:
        f.write("test")

    with open("/etc/ansible/test2", "w") as f:
        f.write("test2")

    l = LookupModule()
    result = l.run(terms=['/etc/ansible/test','/etc/ansible/test2'])


# Generated at 2022-06-21 05:57:30.130379
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader

    # Create paths for temporary files
    test_path = []
    for i in range(10):
        tmp_file = tempfile.NamedTemporaryFile(mode='w')
        tmp_file.close()
        test_path.append(os.path.join(os.path.dirname(tmp_file.name), '*.tmp'))

    # Run LookupModule.run with ansible_search_path
    variables = {'ansible_search_path': [os.path.dirname(tmp_file.name)]}
    lookup_module = LookupModule()
    result = lookup_module.run(terms=test_path, variables=variables, wantlist=True)

    # Check results

# Generated at 2022-06-21 05:57:31.103825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-21 05:57:38.318161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    module = LookupModule()
    terms = ['../test/test_module.py']
    variables = {'ansible_search_path': '.'}
    # When
    ret = module.run(terms, variables)
    # Then
    assert ret == [os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test', 'test_module.py')]

# Generated at 2022-06-21 05:57:48.785866
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a file that exists.
    l = LookupModule()
    os.environ['ANSIBLE_SEARCH_PATH'] = "./test/units/lookup/fileglob_tests"
    result = l.run(['./test/units/lookup/fileglob_tests/file1.txt'])
    assert result == ['./test/units/lookup/fileglob_tests/file1.txt']

    # Test with a file that does not exists.
    result = l.run(['./test/units/lookup/fileglob_tests/no_file.txt'])
    assert result == []

# Generated at 2022-06-21 05:57:51.120720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()


# Generated at 2022-06-21 05:57:56.642597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    suite = unittest.TestSuite()
    test_case_1 = unittest.FunctionTestCase(test_LookupModule_run_test_case_1)
    suite.addTest(test_case_1)
    return suite


# Generated at 2022-06-21 05:57:59.058098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange
    lookup_instance = LookupModule()
    # execute
    actual = lookup_instance.run(['*.txt'])
    # assert
    expected = []
    assert actual == expected


# Generated at 2022-06-21 05:58:19.053284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ['*.txt']
    variables = [ os.path.realpath(os.path.join(os.path.dirname(__file__),'..','..','test_files')) ]
    wanted_result = [os.path.realpath(os.path.join(os.path.dirname(__file__),'..','..','test_files','fileglob_test.txt'))]
    assert lookup_module.run(terms, variables) == wanted_result

# Generated at 2022-06-21 05:58:25.264240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookup_plugin = LookupModule()

    # create test parameters for method run
    terms = ['/root/ansible-rep/test/integration/targets/fileglob/bar.txt']
    variables = {}
    variables['ansible_search_path'] = ['/root/ansible-rep/test/integration/targets/fileglob']

    # assert method run return value is ['/root/ansible-rep/test/integration/targets/fileglob/bar.txt']
    assert lookup_plugin.run(terms, variables) == ['/root/ansible-rep/test/integration/targets/fileglob/bar.txt']

# Generated at 2022-06-21 05:58:32.952243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up testing
    # required for test as we are not using an inventory file
    setattr(LookupModule, 'get_basedir', lambda x, y: '/')
    setattr(LookupModule, 'find_file_in_search_path', lambda x, y, z: z)
    expected = ['/this/is/a/file/path.txt']
    # execute test
    results = LookupModule().run(terms=['/this/is/a/file/path.txt'], variables={'ansible_search_path': []})
    # assert results
    assert results == expected

# Generated at 2022-06-21 05:58:42.560987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests for old Python 2.6
    lm = LookupModule()
    assert lm.run(terms=['/tmp/testfile10'], variables={}) == []
    assert lm.run(terms=['/tmp/testfile11'], variables={'path': '/tmp'}) == []
    assert lm.run(terms=['/tmp/testfile12'], variables={'ansible_search_path': ['/tmp']}) == []
    assert lm.run(terms=['/tmp/testfile13'], variables={'ansible_search_path': ['/']}) == []
    assert lm.run(terms=['/tmp/testfile14'], variables={'ansible_search_path': ['/tmp', '/']}) == []

# Generated at 2022-06-21 05:58:46.634412
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.lookup('_terms', 'variables', wantlist=True) == []
    assert module.lookup('_terms', 'variables') == ''

# Generated at 2022-06-21 05:58:49.415962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 05:58:51.512689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['/my/path/*.txt']
    LookupModule(None, terms, None)

# Generated at 2022-06-21 05:59:02.826141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test with exact directory
    result = module.run(['/etc/host*'],{})
    assert '/etc/hosts' in result
    result = module.run(['/etc/hosts'],{})
    assert '/etc/hosts' in result
    assert '/etc/hostname' not in result
    # test with pattern
    result = module.run(['/etc/h*'],{})
    assert '/etc/hosts' in result
    assert '/etc/hostname' in result
    result = module.run(['/etc/h*s'],{})
    assert '/etc/hosts' in result
    assert '/etc/hostname' not in result
    # test with patterns

# Generated at 2022-06-21 05:59:07.893733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.verbose = False
    mod.run([os.path.join(os.path.dirname(__file__),'test', 'test.txt')], {}, wantlist = False)

# Generated at 2022-06-21 05:59:08.439635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:59:35.501934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Tests run method of the LookupModule class """
    # test run using a single term
    lm = LookupModule()
    assert lm.run(
        ['/home/user/test.txt'],
        variables=dict(ansible_search_path=['/home/user/playbook'],
                       files_path=['/home/user/playbook/files'])
    ) == ['/home/user/playbook/test.txt']
    # test run using two terms
    lm = LookupModule()

# Generated at 2022-06-21 05:59:37.046908
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup is not None

# Generated at 2022-06-21 05:59:46.041895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dirs = ['/tmp', '/tmp/1/2']
    for d in dirs:
        if os.path.exists(d):
            os.rmdir(d)
    os.system("mkdir /tmp/1/2")
    os.system("touch /tmp/a.txt /tmp/1/b.txt /tmp/1/2/c.txt")
    lookup = LookupModule()
    list_of_files = lookup.run(['b.txt', 'a.txt'], dict(ansible_search_path=[dirs[0], dirs[1]]))
    assert isinstance(list_of_files, list)
    assert len(list_of_files) == 2
    assert list_of_files[0] == '/tmp/1/b.txt'
    assert list_of_files

# Generated at 2022-06-21 05:59:57.080210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Check the call of method run with no parameter
    # assert equality of the return value of method run and the expected value
    assert lookup_module.run(terms=None, variables=None, wantlist=False) == []

    # Check the call of method run with terms and variables parameters
    # assert equality of the return value of method run and the expected value

# Generated at 2022-06-21 06:00:06.441913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from six import StringIO
    lookup = LookupModule()
    # tests will fail if this is not in the PATH
    locale = os.environ.get('LC_ALL', None)
    if locale is not None:
        del os.environ['LC_ALL']
    # need to set this up as a dummy file, because otherwise it will try
    # and 'find' the files in the filesystem
    lookup.set_options({'_original_file': '/tmp/test', '_original_module': 'some_module'})

    existing_file = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/module_utils/basic.py'))

# Generated at 2022-06-21 06:00:08.872909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:00:10.911668
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lk = LookupModule()

    assert lk


# Generated at 2022-06-21 06:00:13.980291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test is empty until I find a way to properly test a module without invoking it.
    # See Ansible PR #32394 for more details.
    pass

# Generated at 2022-06-21 06:00:20.227008
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Test whether the module is initialised properly
  lookup1 = LookupModule()
  assert lookup1._templar is not None
  assert lookup1._loader is not None
  assert lookup1._basedir is not None
  assert lookup1._display is not None

# Generated at 2022-06-21 06:00:22.183356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

    print(test)
    assert test

# Generated at 2022-06-21 06:00:51.264341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:00:54.549828
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a lookupmodule lookup object
    lookup = LookupModule()

    # Create a test var
    result = lookup.run(["*.txt"], variables={"aaa": "aaa"})

    # print result
    print(result)

# Generated at 2022-06-21 06:00:57.630032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    x.run(["/my/path/*.txt"])

# Generated at 2022-06-21 06:01:05.036133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = LookupModule()
    assert d._loader is None
    assert d._templar is None
    assert d.basedir is None
    assert d.get_basedir() is None
    assert d.run(terms=None, variables=None, **{'wantlist': False})  is None
    assert d.run(terms=[], variables=None, **{'wantlist': False})  is None
    assert d.run(terms=['/my/path/a.txt','a.txt'], variables=None, **{'wantlist': False})  is None

# Generated at 2022-06-21 06:01:17.423210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    text = '--- test_junk_in_dirs.yml\n' + '- name: test\n' + '  hosts: all\n' + '  tasks:\n' + '  - file: ' + '    path: /tmp/foo\n' + '    state: touch\n'
    with open('/tmp/test_junk_in_dirs.yml', 'w') as f:
        f.write(text)
    x = lookup.run(
        terms=['test_*'],
        variables={'_files': ['/etc/foo']})

# Generated at 2022-06-21 06:01:20.516691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    basedir = lookup.get_basedir({})
    assert isinstance(basedir, basestring)


# Generated at 2022-06-21 06:01:32.107961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Terms with files
    assert ['/tmp/nested/test.txt'] == lookup.run(['/tmp/nested/test.txt'], dict(ansible_search_path=['/tmp']))
    assert ['/tmp/nested/test.txt'] == lookup.run(['/tmp/nested/test.txt'], dict(ansible_search_path=['/tmp/nested']))
    assert ['/tmp/nested/test.txt'] == lookup.run(['/tmp/nested/test.txt'], dict(ansible_search_path=['/tmp/nested/../nested']))

# Generated at 2022-06-21 06:01:40.627661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    terms = ["/tests/unit/plugins/lookup/files/fileglob_test1.conf", "fileglob_test2.conf"]
    kwargs = { 'wantlist': True }
    result = f.run(terms, kwargs)
    assert terms[0] in result
    assert terms[1] in result
    assert len(result) == 2

# Generated at 2022-06-21 06:01:46.417330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ["/Users/kevinroy/Downloads/test.txt"]
    variables = {"ansible_search_path": ["/Users/kevinroy"]}
    assert lm.run(terms, variables) == ["/Users/kevinroy/test.txt"]

    terms = ["/test.txt"]
    assert lm.run(terms, variables) == ["/Users/kevinroy/test.txt"]

    terms = ["test.txt"]
    assert lm.run(terms, variables) == ["/Users/kevinroy/test.txt"]

    variables = {"ansible_search_path": ["/Users/kevinroy"]}
    terms = ["/test.txt"]
    assert lm.run(terms, variables) == ["/Users/kevinroy/test.txt"]



# Generated at 2022-06-21 06:01:48.663402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj

# Generated at 2022-06-21 06:02:22.667333
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)

# Generated at 2022-06-21 06:02:24.000291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global obj
    obj = LookupModule()

# Generated at 2022-06-21 06:02:35.058652
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    terms = ["/playbooks/files/fooapp/*"]
    variables = {}
    results = module.run(terms, variables)
    assert results[0] == "/playbooks/files/fooapp/file0100"
    assert results[1] == "/playbooks/files/fooapp/file0200"
    assert results[2] == "/playbooks/files/fooapp/file0300"
    assert results[3] == "/playbooks/files/fooapp/file0400"
    assert results[4] == "/playbooks/files/fooapp/file0500"

# Generated at 2022-06-21 06:02:45.919161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    dummy_self = object()
    dummy_self.get_basedir = lambda x: "/some_basedir/"
    dummy_self.find_file_in_search_path = lambda x, y, z: "/some_search_path/"
    terms = ["*.txt"]
    expected_ret = ["/some_search_path/term.txt", "/some_search_path/term2.txt"]
    ret = []
    glob.glob = lambda x: expected_ret

    # Test
    ret = LookupModule.run(dummy_self, terms)

    # Verify
    assert ret == expected_ret

# Generated at 2022-06-21 06:02:56.427061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["hello", "world"], variables={}, wantlist=False) == ""
    assert module.run(["hello", "world"], variables={}, wantlist=True) == []

    os.system("touch path1/file1.txt path1/file2.txt path2/file3.txt")
    assert module.run(["file1.txt"], variables={"ansible_search_path" : ["path1", "path2"]}, wantlist=False) == 'path1/file1.txt'
    assert module.run(["file1.txt"], variables={"ansible_search_path" : ["path1", "path2"]}, wantlist=True) == ['path1/file1.txt']

# Generated at 2022-06-21 06:02:58.587720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['./test/test_fileglob.py']) == ['./test/test_fileglob.py']
    assert LookupModule().run(['*.py']) != []
    assert LookupModule().run(['*.pyc']) == []
    assert LookupModule().run(['*.pyc'], wantlist=True) == []

# Generated at 2022-06-21 06:03:05.855389
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Python glob return byte string
    byte_strings = [b'node_modules', b'package.json', b'server.js', b'slack-client.js']
    # Method run of class LookupModule
    lookup_module = LookupModule()
    # assert that results of method run equals byte_strings
    assert lookup_module.run(['*'], dict(ansible_search_path=['.'])) == byte_strings

# Generated at 2022-06-21 06:03:09.513932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)