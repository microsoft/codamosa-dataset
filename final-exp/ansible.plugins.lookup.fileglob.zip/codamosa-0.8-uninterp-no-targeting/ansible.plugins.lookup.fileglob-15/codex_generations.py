

# Generated at 2022-06-21 05:53:19.192210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['*.yml']) == ['roles.yml', 'test_fileglob.yml']
    assert lookup_module.run(['*does_not_exist*']) == []
    assert lookup_module.run(['*.unexisting', '*.yml']) == ['roles.yml', 'test_fileglob.yml']
    assert lookup_module.run(['test_fileglob.yml']) == ['test_fileglob.yml']
    assert lookup_module.run(['test_fileglob.yml.unexisting']) == []

# Generated at 2022-06-21 05:53:20.527078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test creation and initialization of LookupModule object
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 05:53:20.977739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:53:21.629979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 05:53:22.968912
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()



# Generated at 2022-06-21 05:53:32.417528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run(terms=['*.conf'], variables=dict(role_path=['/home/vagrant/ansible/roles/test_role1']))) == 2
    assert len(LookupModule().run(terms=['*.conf'], variables=dict(ansible_search_path=['/home/vagrant/ansible/roles/test_role1']))) == 2
    assert len(LookupModule().run(terms=['/home/vagrant/ansible/roles/test_role1/*.conf'])) == 2
    assert len(LookupModule().run(terms=['*.txt'], variables=dict(role_path=['/home/vagrant/ansible/roles/test_role1']))) == 0

# Generated at 2022-06-21 05:53:34.417929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)


# Generated at 2022-06-21 05:53:35.199113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:53:42.406049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.parsing.dataloader
    import ansible.constants as C
    loader = ansible.parsing.dataloader.DataLoader()
    lookupPluging = LookupModule()
    assert lookupPluging.get_basedir({'_original_file': 'foo.yml'}) == os.path.dirname(os.path.abspath('foo.yml'))
    # os.getcwd() changes based on where you call it from. This test assumes the test is run from the test directory
    assert lookupPluging.get_basedir({'_original_file': '/tmp/foo.yml'}) == '/tmp'
    assert lookupPluging.find_file_in_search_path({'_original_file': 'foo.yml'}, 'files', 'bar') == 'bar'

# Generated at 2022-06-21 05:53:49.365665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fake_lookup = LookupModule()
    fake_variables = {'ansible_search_path': ['./LookupModule']}
    fake_terms = ['*.py', 'boxes.yml']
    builtins = ['LookupBase', 'LookupModule']
    ret = fake_lookup.run(fake_terms, fake_variables)
    for file in ret:
        assert os.path.isfile(file)
        assert file not in builtins

# Generated at 2022-06-21 05:53:52.913853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    lookup.run(['*.py'])

# Generated at 2022-06-21 05:54:02.569785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #from ansible.plugins.lookup import LookupModule
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.vars import VariableManager
    from six import StringIO
    from ansible.utils.path import unfrackpath

    lookup = LookupModule()
    myloader = None
    myloader = DataLoader()
    var_manager = VariableManager()
    var_manager.set_inventory(Inventory(loader=myloader))

    searchpath = '/etc:/bin:/usr/bin:/usr/sbin'
    var_manager.set_vars({"ansible_search_path": searchpath})

    # find file
    # path is relative to cwd
    cwd = os.getcwd()
    os.chdir('/etc')

# Generated at 2022-06-21 05:54:04.032522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 05:54:08.535853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options()
    expected = ["/root/deployment/files/file1","/root/deployment/files/file2",
                "/root/deployment/files/file3"]
    terms = ["*.txt"]
    assert expected == l.run(terms)

# Generated at 2022-06-21 05:54:09.364101
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:54:20.930522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestVars(object):
        ansible_search_path = [
            './test/test_files',
            './test/test_files/file_with_dots.yml'
        ]
        ansible_files_dir = './test/test_files'
        ansible_inventory_dir = './test/test_files'

    my_path = './test/test_files'

    lookup_plugin = LookupModule()

# Generated at 2022-06-21 05:54:29.678779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # In this unit test we create a LookupModule object and try to run it using different arguments and different situations.
    # In order to run this unit test change the following example with the valid argument, or put the valid arguments into the
    # file and import the LookupModule_test.py in your own test file.

    # First of all we need to create a LookupModule object.
    lookup = LookupModule()
    
    # Lets say that we have a file named 'fileglob_good.txt' in the current directory.
    # The first test is to test that the LookupModule can find the file using the glob argument which is not full path.
    # The returned value should be a list of strings containing the path of all the files with the given glob argument.
    # The second test is to test that the LookupModule can find the file using the glob argument

# Generated at 2022-06-21 05:54:31.423918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run() == []

# Generated at 2022-06-21 05:54:33.129433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 05:54:35.116807
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 05:54:54.122057
# Unit test for constructor of class LookupModule
def test_LookupModule():
	LookupModule()

# Generated at 2022-06-21 05:54:56.543352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run('fake_file_name') == []

# Generated at 2022-06-21 05:54:59.470972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()



# Generated at 2022-06-21 05:55:11.451952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check that the path is correctly checked
    lookup = LookupModule()
    lookup_ret = ['/home/user/path/file.txt']
    assert lookup.run(['/home/user/path/test.txt'], dict(ansible_search_path=['/home/user/path'])) == lookup_ret
    assert lookup.run(['./test.txt'], dict(ansible_search_path=['./'])) == lookup_ret

    # If a file does not exist, an empty list should be returned
    assert not lookup.run(['/home/user/path/test.txt'], dict(ansible_search_path=['/home']))
    assert not lookup.run(['/home/user/path/test.txt'], dict(ansible_search_path=['/home/user']))

    #

# Generated at 2022-06-21 05:55:20.041892
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_params(terms, expected, exp_type='list'):
        mod = LookupModule()
        mod.set_options({})
        result = mod.run(terms)
        assert type(result) is exp_type
        assert result == expected

    test_params(['/etc/passwd'], ['/etc/passwd'])
    test_params(['/etc/passwd', 'etc*'], ['/etc/passwd', '/etc/passwd', '/etc/passwd'])
    test_params(['/etc/x*'], ['/etc/x*'])

# Generated at 2022-06-21 05:55:21.532728
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:55:22.966016
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(len(LookupModule()) == 0)

# Generated at 2022-06-21 05:55:30.896657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    # Create a mock object of class LookupBase
    LookupBase_obj = LookupBase()
    # Define different directories to be created
    found_path_dir = '/tmp/module_utils_lookup_fileglob/test_dir'
    # Define different file names
    file_test = 'test_file.txt'
    file_test_path = found_path_dir + '/' + file_test
    # Create directory for testing
    os.makedirs(found_path_dir)
    # Create file for testing
    file_handle = open(file_test_path, 'w')
    file_handle.write('foo\n')
    file_handle.close()
    # Test with different search paths
    # Test with found

# Generated at 2022-06-21 05:55:41.507783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        capture_errors = False

    import ansible.constants
    ansible.constants.DEFAULT_VAULTPASS = 'test'
    ansible.constants.DEFAULT_VAULTID = 'test'

    lookup_module = LookupModule()
    lookup_module.get_basedir = lambda: '/my/path'

    assert lookup_module.run(['file.ext'], dict(ansible_search_path=['/my/path'])) == ['/my/path/file.ext']
    assert lookup_module.run(['/my/path/file.ext'], dict(ansible_search_path=['/my/path'])) == ['/my/path/file.ext']

# Generated at 2022-06-21 05:55:52.792682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    '''
    Here is an example for testing run() method of LookupModule
    '''
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, [])
    play_context = PlayContext()
    test_lookup_plugin = lookup_loader.get('fileglob')

# Generated at 2022-06-21 05:56:05.860431
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupBase)

# Generated at 2022-06-21 05:56:06.976713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:56:11.452736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    l = LookupModule()
    # When
    ret = l.run(["/home/testuser/*"])
    # Then
    assert(ret is not None)
    assert(len(ret) > 0)

# Generated at 2022-06-21 05:56:14.489112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["/my/path/*.txt"], None) == []

# Generated at 2022-06-21 05:56:16.987869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Make sure we can create an instance of LookupModule"""
    lookup_module = LookupModule()
    assert lookup_module
    assert hasattr(lookup_module, 'run')


# Generated at 2022-06-21 05:56:25.882062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test for simple term
    terms = ["test"]
    result = lookup_module.run(terms)
    assert not result
    # test for multiple term
    terms = ["test","test"]
    result = lookup_module.run(terms)
    assert not result
    # test for term with directory
    terms = ["dir/test"]
    result = lookup_module.run(terms)
    assert not result

# Generated at 2022-06-21 05:56:29.836095
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # un-comment the following block to test.

    '''
    from ansible.plugins.lookup.fileglob import LookupModule

    ret = []

    terms = ['/tmp/*.txt']
    variables = {'ansible_search_path': '/tmp'}

    lookup = LookupModule()
    results = lookup.run(terms, variables=variables)
    print('Results is %s' % results)
    '''

    return None

# Generated at 2022-06-21 05:56:30.650562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 05:56:40.017015
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify data type of '_ansible_search_path' of varialbles
    assert isinstance(variables, dict)

    # Verify data type of 'terms'
    assert isinstance(terms, list)
    assert isinstance(terms[0], str)

    # Check if the function 'find_file_in_search_path' return value has the expected data type
    assert isinstance(find_file_in_search_path(variables, 'files', os.path.dirname(terms[0])), str)

    # Check if the function 'get_basedir' return value has the expected data type
    assert isinstance(get_basedir(variables), str)

    assert LookupModule.run(terms, variables, **kwargs)


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:56:49.998330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        "$HOME/test",
        "/var/lib/*.txt",
        "/var/lib/123*",
        "*.txt",
        "123*",
    ]
    res = LookupModule().run(terms, variables={'HOME': '/home/user/', 'ansible_search_path': ['/etc/ansible']})
    assert len(res) == 4
    assert res[0] == "/home/user/test"
    assert res[1] == "/var/lib/test.txt"
    assert res[2] == "/var/lib/123test.txt"
    assert res[3] == "/etc/ansible/test.txt"

# Generated at 2022-06-21 05:57:03.781981
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1 - checking the path of current directory
    test_1 = LookupModule()
    ansible_search_path = ['.']
    variables1 = {'ansible_search_path': ansible_search_path}
    ret1 = test_1.run(['*.txt'], variables1)
    print(variables1)
    print(ret1)
    assert ret1 == ['fileglob.py']


    # Test 2 - checking the files from remote path
    test_2 = LookupModule()
    ansible_search_path = ['/home/rajani/roles/test']
    variables1 = {'ansible_search_path': ansible_search_path}
    ret2 = test_2.run(['*.txt'], variables1)
    print(variables1)

# Generated at 2022-06-21 05:57:04.590441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-21 05:57:11.530065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test_LookupModule_run """

    ####################################################################################################################
    #
    # py.test framework does not support fixtures (yield) (http://doc.pytest.org/en/latest/fixture.html#fixtures-finalization-executing-teardown-code).
    # So we'll use pytest's monkeypatch to change the methods we want to test.
    #
    ####################################################################################################################

    # Patch the glob.glob method of the lookup class to just list all the files in the current directory.
    def fake_glob_glob(path):
        return glob.glob('*')

    # Patch the find_file_in_search_path method of the lookup class to just return the file path.

# Generated at 2022-06-21 05:57:15.125900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.path.basename("/test/test") == "test"
    assert os.path.basename("/test/test/") == "test"
    assert os.path.basename("test") == "test"
    assert os.path.basename("test/") == "test"
    assert os.path.basename("/test") == "test"
    assert os.path.basename("/") == ""

# Generated at 2022-06-21 05:57:18.018047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_module_instance = LookupModule()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-21 05:57:18.879089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:57:22.579707
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l,LookupModule)
    assert isinstance(l.get_basedir({}),str)

# Generated at 2022-06-21 05:57:26.096037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['*.j2', '*.yml']
    base = LookupModule()
    result = base.run(terms)
    result.append('test')
    assert result

# Generated at 2022-06-21 05:57:26.877229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:57:30.433107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/my/path/*.txt']
    assert lookup_module.run(terms=terms, variables={}) == []

# Generated at 2022-06-21 05:57:49.513254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:57:57.835034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['foo.sh','*/bar.sh']
    variables = dict(ansible_search_path=[str(pathlib.Path.home()),'/etc/playbook'],files=['/usr/bin/playbook'])
    assert lookup.run(terms,variables,wantlist=False) == ['/home/james/foo.sh','/etc/playbook/bar.sh']

# Generated at 2022-06-21 05:58:10.188873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    lu = LookupModule()

    #setup test 1
    d = tempfile.mkdtemp(prefix="test_LookupModule_run")

# Generated at 2022-06-21 05:58:21.577640
# Unit test for constructor of class LookupModule
def test_LookupModule():
  module = LookupModule()

  # test ansible_search_path
  variables = {'ansible_search_path':[
                                      '/ansible/playbooks/files',
                                      '/ansible/playbooks/vars'
                                      ]}

  # test dir / ansible/playbooks/files
  term = 'test'
  term_file = os.path.basename(term)
  found_paths = []
  found_paths.append(module.find_file_in_search_path(variables, 'files', os.path.dirname(term)))

# Generated at 2022-06-21 05:58:28.918466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_data = 'path/to/my/file.txt'
    lookup = LookupModule()
    assert lookup.run(terms=['*.txt'], variables = {'hostvars':{'hostname':{'ansible_search_path':[test_data]}}}) == [test_data]

# Generated at 2022-06-21 05:58:32.126807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule run() test method.
    """
    ###################################################################
    # Setup test data
    ###################################################################

    ###################################################################
    # Execute code
    ###################################################################

    ###################################################################
    # Verify results
    ###################################################################

    pass

# Generated at 2022-06-21 05:58:33.973275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """

    """
    lookup = LookupModule()
    assert lookup



# Generated at 2022-06-21 05:58:39.306287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This module is not intended to be used directly.  It evaluates paths on the local
    system, to be included in Ansible's inventory data.
    """
    assert 'LookupModule' in globals(), "This file is not a member of the LookupModule class"

# Generated at 2022-06-21 05:58:40.367950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:58:41.498252
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-21 05:59:10.061747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    f = glob
    lookup_module = LookupModule()
    assert lookup_module.run(terms="*") == []
    assert lookup_module.run(terms="") == []
    assert lookup_module.run(terms=".") == []
    assert lookup_module.run(terms=f) == []
    assert lookup_module.run(terms="", variables="") == []
    assert lookup_module.run(terms="", variables="", **{}) == []
    lookup_module.get_basedir({})
    lookup_module.find_file_in_search_path({}, "files", "files")

# Generated at 2022-06-21 05:59:15.274113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile

    from ansible.errors import AnsibleFileNotFound
    from ansible.plugins.lookup import LookupBase

    tmpdir = tempfile.mkdtemp(prefix='ansible-test-fileglob-')
    cwd = os.getcwd()


# Generated at 2022-06-21 05:59:25.161607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _glob_glob_called = 0
    _glob_glob_results = []
    _glob_glob_files = []
    _glob_glob_dirs = []

    def mocked_glob_glob(path):
        _glob_glob_called += 1
        _glob_glob_files.append(path)
        return _glob_glob_results

    def mocked_isfile(path):
        res = False
        if path in _glob_glob_results:
            res = True
        return res

    def mocked_basedir(var):
        return ['/path/to/my/role', '/path/to/my/playbook']

    def mocked_find_file_in_search_path(var, dir, name):
        _glob_glob

# Generated at 2022-06-21 05:59:32.827759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["/a/b/a.txt", "/a/c/a.txt", "*.txt"]
    variables = {'ansible_search_path': ['/a/b', '/a/c']}
    result = module.run(terms, variables)
    assert(len(result) == 2)
    assert(result[0] == "/a/b/a.txt")
    assert(result[1] == "/a/c/a.txt")

# Generated at 2022-06-21 05:59:35.522338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    print(x)

# Generated at 2022-06-21 05:59:38.111575
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert isinstance(test_lookup, LookupModule)


# Generated at 2022-06-21 05:59:46.388342
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instantiate class
    lc = LookupModule()

    # Call method run
    term_file = to_bytes("test_file.txt")
    found_paths = []
    if 'ansible_search_path' in lc._templar.available_variables:
        paths = lc._templar.available_variables['ansible_search_path']
    else:
        paths = [lc.get_basedir(lc._templar.available_variables)]
    for p in paths:
        found_paths.append(os.path.join(p, b'files'))
        found_paths.append(p)


# Generated at 2022-06-21 05:59:53.024801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test successful case
    test_terms = "/test.py"
    result = LookupModule().run(test_terms)[0]
    assert result == "lookup_plugins/fileglob.py"

    # Test failure case
    test_terms = "/text.py"
    result = LookupModule().run(test_terms)
    assert not result

# Generated at 2022-06-21 05:59:53.763226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule())


# Generated at 2022-06-21 06:00:04.406678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_glob_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data')

    module_ins = LookupModule()

    # Only testing the first term_results, since the others are all identical (in theory)
    term_results = module_ins.run([os.path.join('test_fileglob', 'basic.txt')], variables = {
            'ansible_search_path': [test_glob_path],
            'ansible_basedir': '.'
    })

    assert(term_results == [os.path.join(test_glob_path, 'test_fileglob', 'basic.txt')])

# Generated at 2022-06-21 06:01:05.457041
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l.set_options({})
    # testing with kwargs

# Generated at 2022-06-21 06:01:07.861268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(self, terms, variables)


# Generated at 2022-06-21 06:01:08.794717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:01:18.451853
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert LookupModule.run is not None, "valid function LookupModule.run"
    assert LookupModule.run_term is not None, "valid function LookupModule.run_term"
    assert LookupModule.run_terms is not None, "valid function LookupModule.run_terms"

    # Test 1: create with invalid arguments
    # except TypeError
    try:
        with pytest.raises(TypeError):
            LookupModule("invalid", "invalid")
    except:
        assert False

    # Test 2: create with valid arguments
    l = LookupModule()
    assert l is not None, "valid instance LookupModule"
    assert l.run is not None, "valid function LookupModule.run"
    assert l.run_term is not None, "valid function LookupModule.run_term"


# Generated at 2022-06-21 06:01:20.966704
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-21 06:01:22.158903
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:01:22.995185
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:01:33.935679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get("fileglob", loader=None, templar=None)
    assert lookup.run(terms=['/home/test/*'], variables={'ansible_search_path':['/home/test/']}) == []
    assert sorted(lookup.run(terms=['/home/test/myfile_1.txt'], variables={'ansible_search_path':['/home/test/']})) == sorted(['/home/test/myfile_1.txt'])

# Generated at 2022-06-21 06:01:41.406289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    globbed = glob.glob(to_bytes("/my/path/*.txt", errors='surrogate_or_strict'))
    term_results = [to_text(g, errors='surrogate_or_strict') for g in globbed if os.path.isfile(g)]
    return term_results


# Generated at 2022-06-21 06:01:43.411725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    result = plugin.run(["/my/path/*.txt"])
    assert isinstance(result, list)