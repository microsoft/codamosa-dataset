

# Generated at 2022-06-21 05:53:16.313061
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert lookup_class
    assert lookup_class.run(terms=['*.conf'], variables={})

# Generated at 2022-06-21 05:53:25.516210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Paths that do not contain any file
    # but contains files that match the pattern
    terms = ['/tmp/tests/']
    # Paths that contain files
    # that match the pattern
    expected = {'/tmp/tests/' : ['/tmp/tests/bar.txt', '/tmp/tests/foo.txt']}
    # Extacted paths that match the pattern
    result = module.run(terms)
    assert result == expected[terms[0]], 'Returned list is not as expected.'


# Generated at 2022-06-21 05:53:27.420598
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 05:53:39.756354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # paths used in testing
    TEST_PATHS = [
        "/path/to/some/file.ext",
        "/path/to/another/file.ext2",
        "/path/to/another/file.ext3",
        "/path/to/another/file.ext4",
        "/path/to/another/file.ext5",
        "/path/to/another/file.ext6",
        "/path/to/another/file.ext7",
    ]

    # setup patterns that are supported
    patterns = ["*.ext2", "file.*3", "an*file.ext4", "another/*.ext5", "another/file.ext6", "path/to/another/file.ext7", "my/path/*.txt"]

    # setup files

# Generated at 2022-06-21 05:53:45.434366
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Get the class
    ansible_module = LookupModule()

    # test for the run function
    # test for the run function

    assert(ansible_module.run(['*.txt']) == [])

    assert(not ansible_module.run(['.*']) == [])

# Generated at 2022-06-21 05:53:55.444508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    import ansible.constants as C

    class AnsibleOptions(object):

        def __init__(self):
            self.connection = 'local'
            self.module_path = '/usr/share/ansible'
            self.forks = 5
            self.become = None
            self.become_method = None

# Generated at 2022-06-21 05:53:58.417706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # negative testing
    lookup_module = LookupModule()
    assert not lookup_module.run(terms='/path/to/file')

    # positive testing
    lookup_module = LookupModule()
    assert lookup_module.run(terms='/etc/hosts')

# Generated at 2022-06-21 05:54:10.284268
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:54:19.489684
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create instance of LookupModule
    lookup_module = LookupModule()

    # Test constructor __init__()
    assert lookup_module != None

    # Test method run()
    terms = ["/path/to/files/file.txt"]
    assert lookup_module.run(terms) != None

    # Test method find_file_in_search_path()
    variables = {"ansible_search_path": ["/path/to/files"]}
    assert lookup_module.find_file_in_search_path(variables, "files", "/path/to/files") != None

# Generated at 2022-06-21 05:54:22.715322
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 05:54:27.407895
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert len(lookup_plugin.run(['*.txt'], {})) == 0

# Generated at 2022-06-21 05:54:28.555342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    #TODO: assert something


# Generated at 2022-06-21 05:54:29.982107
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print("Testing: LookupModule constructor")
    assert lookup is not None


# Generated at 2022-06-21 05:54:32.229636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(['/my/path/*.txt']) == []

# Generated at 2022-06-21 05:54:41.946425
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1: with single file exist in path
    cwd = os.getcwd()
    lookup = LookupModule()
    lookup.get_basedir = lambda variables: cwd
    lookup._loader = MockLoader({})

    # Get test file path
    sample_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), u'test_data', u'sample.txt')
    assert 1 == len(lookup.run([sample_file_path]))
    assert unicode(sample_file_path) == lookup.run([sample_file_path])[0]

    # Test case 2: with file does not exist in path
    assert 0 == len(lookup.run([u'./test_data/invalid.txt']))

    # Test case 3: with valid

# Generated at 2022-06-21 05:54:44.148418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup is not None)

# Generated at 2022-06-21 05:54:45.497209
# Unit test for constructor of class LookupModule
def test_LookupModule():
   l = LookupModule()


# Generated at 2022-06-21 05:54:48.002509
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.run(terms=["/my/path/*.txt"], variables={'ansible_search_path' : ['./ansible/plugins/lookup_plugins']})

# Generated at 2022-06-21 05:54:49.590682
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 05:55:00.601286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class EmptyModule(object):
        def __init__(self):
            self.params = {}
            self.basedir = "."
    class EmptyLoader(object):
        def __init__(self):
            self.path_vars = []
            self.basedir = "."
    class EmptyPlay(object):
        def __init__(self):
            self.hosts = []
    class EmptyInventory(object):
        def __init__(self):
            self.hosts = {}
            self.get_hosts = lambda name: []
    class EmptyVariables(object):
        def __init__(self):
            self.basedir = "."
    class EmptyRunner(object):
        def __init__(self):
            self.module = EmptyModule()
            self.loader = EmptyLoader()
            self.play

# Generated at 2022-06-21 05:55:18.367256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # method lookup.run is difficult to unit test
    # due to it's use of glob.glob.  I've chosen to
    # mock out a test for the lookup, with a target
    # path /tmp/myfile for a single file, and the
    # file does exist.
    test_glob = 'glob.glob'
    test_files = ['myfile']
    test_dwimmed_path = '/tmp'
    test_term_file = 'myfile'
    test_term_results = ['/tmp/myfile']

    lookup = LookupModule()
    lookup.get_basedir = lambda x: x
    setattr(lookup, 'find_file_in_search_path', lambda x, y, z: z)

# Generated at 2022-06-21 05:55:19.153664
# Unit test for constructor of class LookupModule
def test_LookupModule():
   assert LookupModule()

# Generated at 2022-06-21 05:55:21.175834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\nIn test_LookupModule_run")


# Generated at 2022-06-21 05:55:30.348425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing the case of fileglob lookup with wantlist=True
    lookup = LookupModule()

    # Test of fileglob lookup with wantlist=True - python2
    test_file_name = "testfile_wantlist_true.py"
    test_file = open(test_file_name)
    test_file_contents = test_file.read()
    test_file.close()
    os.remove(test_file_name)
    terms = [test_file_name]
    assert lookup.run(terms, wantlist=True) == [test_file_contents]

    # Test of fileglob lookup with wantlist=True - python3
    test_file_name = "testfile_wantlist_true.py"
    test_file = open(test_file_name, "w")
    test_

# Generated at 2022-06-21 05:55:31.672928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No tests written"

# Generated at 2022-06-21 05:55:34.389666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    l = LookupModule()

# Generated at 2022-06-21 05:55:35.906740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 05:55:37.854464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    # For now, if the constructor doesn't raise an exception, we're good.
    assert True

# Generated at 2022-06-21 05:55:42.820227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod.run(['/usr/share/fooapp/fooapp*.conf'], {})
    assert 'fooapp.conf' in lookup_mod.run(['fooapp*.conf'], {})



# Generated at 2022-06-21 05:55:53.660012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['test_terms1', 'test_terms2']
    test_variables = None
    test_wantlist = False
    test_boolean = False
    test_list = ['/playbooks/files/fooapp/*']
    test_attributes = None
    test_default = None
    test_isa = None
    test_none_found_value = None

    test_obj = LookupModule(loader=None, templar=None, **{'_loader': None, '_templar': None})

# Generated at 2022-06-21 05:56:09.026331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup = LookupModule()
    assert mylookup.run(terms=["/path/to/my/file.txt", "/path/to/another/file.txt"]) == [u'/path/to/my/file.txt', u'/path/to/another/file.txt']
    assert mylookup.run(terms=["/path/to/my/file.txt"]) == [u'/path/to/my/file.txt']

# Generated at 2022-06-21 05:56:10.347779
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 05:56:21.706209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_a = {
        'a': {
            'a1': {
                'a11': 'avalue11'
            },
            'a2': 'avalue2'
        }
    }
    dict_b = {
        'b': {
            'b1': 'bvalue1',
            'b2': {
                'b21': 'bvalue21'
            }
        }
    }
    dict_c = {
        'c': {
            'c1': 'cvalue1',
            'c2': 'cvalue2'
        }
    }
    dict_d = {
        'd': {
            'd1': 'dvalue1',
            'd2': 'dvalue2'
        }
    }

# Generated at 2022-06-21 05:56:30.820702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    os.chdir("/")
    os.chdir("home/travis/build/ansible/ansible/test/units/modules/test_lookup")

    # Test: LookupModule instance test_instance
    term = "test_instance"
    wantlist = False
    wantlist_expected = False
    kwargs = {'wantlist': 'True'}
    test_instance = LookupModule()
    # should be a list
    assert isinstance(test_instance.run(term, wantlist), list)
    # wantlist should be True
    assert wantlist_expected is test_instance.run(term, wantlist, **kwargs)[1]
    # should be a string
    assert isinstance(test_instance.run(term, wantlist, **kwargs)[0], str)

# Generated at 2022-06-21 05:56:35.643154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # fileglob()
    module = LookupModule()
    assert module.run is not None

    # run()
    assert module.run([]) is not None
    assert module.run(['a', 'b']) is not None

# Generated at 2022-06-21 05:56:44.047711
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    cwd = os.getcwd()

# Generated at 2022-06-21 05:56:47.342600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run(terms=['./test/testlookup.py'], variables={'test': 'testvalue'})

# Generated at 2022-06-21 05:56:52.178558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    loader = None
    templar = None
    lu = LookupModule(loader, templar)
    assert lu != None
    assert isinstance(lu, LookupBase)

# Generated at 2022-06-21 05:57:01.664610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run method run from class LookupModule

    # Input arguments
    terms = ["/home/*"]
    variables = None

    print("Running unit test for method run of class LookupModule")

    # Test for method run
    print("")
    print("Test case 1:")
    print("Arguments:")
    print("   terms:")
    print(terms)
    print("   variables:")
    print(variables)

    lookup_object = LookupModule()
    lookup_object_run_result = lookup_object.run(terms, variables)

    print("Returned result:")
    print(lookup_object_run_result)
    print("")

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-21 05:57:10.086361
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    terms = [ "*.yaml" ]
    variables = {}
    lookup_module = LookupModule()
    lookup_module._options = { 'wantlist': True }

    # set a test file
    test_file_path = os.path.join(os.path.dirname(__file__), "test.yaml")
    with open(test_file_path, "w") as f:
        f.write("")

    try:
        # run
        ret = lookup_module.run(terms, variables)

        # assert
        assert len(ret) == 1
        assert ret[0] == test_file_path

    finally:
        # clean up
        os.remove(test_file_path)

# Generated at 2022-06-21 05:57:35.226924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This unit test doesn't exercise the https://github.com/ansible/ansible-modules-core/blob/devel2/files/fileglob.py#L28-L44 functionality
    # Instead we just test the functionality of the method run
    # We assume we can use os.path and glob
    # We also assume we have access to the following variables ansible_debug, ansible_search_path, and isfile
    # get_basedir and find_file_in_search_path are also dependencies
    # get_basedir can be mocked out but the find_file_in_search_path cannot
    from ansible.plugins.lookup.fileglob import LookupModule
    assert LookupModule.run([]) == []
    assert LookupModule.run(['.txt']) == []

# Generated at 2022-06-21 05:57:39.564409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    terms = ['/etc/resolv.conf', '/etc/resolv.conf']
    terms_run = x.run(terms,'')
    assert terms_run == ["/etc/resolv.conf"], "Wrong result: should be ['/etc/resolv.conf'] instead of " + repr(terms_run)

# Generated at 2022-06-21 05:57:41.589457
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-21 05:57:50.968579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    play_source = {}
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    lookup = lookup_loader.get('fileglob', play=play, basedir='/dev/null')

    terms = ['*.txt']
    variables = {'ansible_search_path': ['/dev/null']}


# Generated at 2022-06-21 05:57:53.725216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 05:57:54.532570
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # verify that LookupModule class is defined
    lm = LookupModule()
    assert lm



# Generated at 2022-06-21 05:57:56.196615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/my/path/*.txt']
    os.environ['ANSIBLE_LOOKUP_PLUGINS'] = os.path.dirname(os.path.realpath(__file__))
    assert lookup.run(terms) == []

# Generated at 2022-06-21 05:58:03.572415
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:58:05.035130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None


# Generated at 2022-06-21 05:58:07.633124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    assert module

# Generated at 2022-06-21 05:58:49.914386
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms = ["/my/path/*.txt"]
    variables = {}

    result = lookup.run(terms, variables=variables)
    print(result)


# Generated at 2022-06-21 05:58:51.533341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret is not None

#Unit test when path is not found

# Generated at 2022-06-21 05:58:52.946560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 05:58:57.983968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run([u'/test_data/test*.json'], variables={
        u'ansible_search_path': [u'/test_data/']
    })

# Generated at 2022-06-21 05:59:05.287770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test if all paths are found for the given file names"""
    # Case 1 - file with extension
    input_term = "*.py"
    input_path = "/Users/sanjana/workspace/ansible-dir/lib/ansible/modules"
    actual_result = LookupModule().run([input_term], dict(ansible_search_path=[input_path]))


# Generated at 2022-06-21 05:59:08.317655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test_terms = ['/etc', '/usr/bin']

    assert test.run(test_terms)

# Generated at 2022-06-21 05:59:10.345428
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testobj = LookupModule()
    assert isinstance(testobj, LookupModule)

# Generated at 2022-06-21 05:59:12.638100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    temp_file = open("/tmp/test", "w+")
    temp_file.close()
    terms = ["/tmp/test"]
    assert lookup_module.run(terms) == ['/tmp/test']
    os.remove("/tmp/test")

# Generated at 2022-06-21 05:59:24.542776
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # empty terms

    terms = []

    variables = dict()
    variables['ansible_search_path'] = ['/playbooks/files', '/etc/fooapp']

    lookup_module = LookupModule()

    ret = lookup_module.run(terms, variables=variables)
    assert ret == [], "expected ret to be [] but got %s" % ret

    # terms with both dir and file

    terms = ['/my/path/*.txt']

    variables = dict()
    variables['ansible_search_path'] = ['/playbooks/files', '/etc/fooapp']

    lookup_module = LookupModule()

    # for unit test need to mock glob.glob
    old_glob = glob.glob
    glob.glob = lambda x: [b'/my/path/1.txt']


# Generated at 2022-06-21 05:59:26.350130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()
    assert lookup_module_instance is not None

# Generated at 2022-06-21 05:59:57.159503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:00:06.490067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # file exists in directory /
    assert sorted(lookup.run(['test_fileglob_file_exists'], dict(ansible_search_path=['/']))) == ['/test_fileglob_file_exists']
    # file does not exist in directory /
    assert lookup.run(['test_fileglob_file_does_not_exist'], dict(ansible_search_path=['/'])) == []
    # file exists in directory /tmp/
    assert sorted(lookup.run(['test_fileglob_file_exists'], dict(ansible_search_path=['/tmp/']))) == ['/tmp/test_fileglob_file_exists']
    # file does not exist in directory /tmp/

# Generated at 2022-06-21 06:00:07.444836
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:00:09.780387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:00:12.466342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.basedir == '~'


# Generated at 2022-06-21 06:00:19.821833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with empty terms
    ret = lookup_module.run(terms=[])
    assert ret == []
    # test with terms that is not a collection
    ret = lookup_module.run(terms='test_term')
    assert ret == []
    # test with empty string
    ret = lookup_module.run(terms=[''])
    assert ret == []
    # test with a term that contains only one path
    ret = lookup_module.run(terms=['/tmp/test'])
    assert ret == []
    # test with two terms, one is a empty string, another one is not
    ret = lookup_module.run(terms=['', '/tmp/test'])
    assert ret == []
    # test with two terms, both are not empty string

# Generated at 2022-06-21 06:00:20.771068
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # call constructor without arguments
    assert LookupModule() is not None

# Generated at 2022-06-21 06:00:25.470327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["/path/to/dir/file.txt"]) == ["/path/to/dir/file.txt"]
    assert LookupModule().run(["/path/to/file.txt"]) == ["/path/to/file.txt"]
    assert LookupModule().run(["file.txt"]) == ["file.txt"]

# Generated at 2022-06-21 06:00:36.465963
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple

    Mock = namedtuple('Mock', ['terms', 'variables', 'expected_result'])


# Generated at 2022-06-21 06:00:39.811010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    os.chdir('../')
    lookup_mod = LookupModule(None, None)
    assert lookup_mod

# Generated at 2022-06-21 06:01:34.773931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock class objects
    module = ansible_module_LookupModule
    terms = ["test_term"]

    # Mock methods
    module.get_basedir = MagicMock(return_value = "/valid/basedir/")
    module.find_file_in_search_path = MagicMock(return_value = "/valid/basedir/")
    module.glob.glob = MagicMock(return_value = ["globbed/file"])

    # Method run
    result = module.run(terms)
    assert result == ["globbed/file"]

# Generated at 2022-06-21 06:01:43.032351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    #Call the LookupModule constructor
    a = LookupModule()
    #Get the result of the run method for given terms
    result = a.run(['/home/ansible/ansible-modules-core/files/pip.py'], {'ansible_search_path': ['/home/ansible/ansible-modules-core/files']})
    print(result)

#This function is executed as entry point

# Generated at 2022-06-21 06:01:47.942119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #test valid case
    lookup_module = LookupModule()
    lookup_module.run(terms=['/path/to/dir/file.txt'], variables={'ansible_search_path': ['.']})

# Generated at 2022-06-21 06:01:50.967036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run(terms=['*'], variables=None) == []

# Generated at 2022-06-21 06:01:57.623940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    class FakeVariables():
        def __init__(self):
            self.search_path = []
            self.search_path.append("tests/lookup_plugins/test_fileglob_dir/")

    class FakeTerms():
        def __init__(self):
            self.params = {'wantlist': 'True'}

    class TestLookupModule(unittest.TestCase):
        lookup_module = LookupModule()
        terms = FakeTerms()
        variables = FakeVariables()

        def test_single_file(self):
            self.assertEqual(
                self.lookup_module.run(["file2"], variables=self.variables, wantlist=True),
                ["tests/lookup_plugins/test_fileglob_dir/file2"]
            )



# Generated at 2022-06-21 06:01:59.736664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:02:09.024946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock dict that represents module parameters
    terms = ['/etc/ansible/facts.d/foo.fact']
    variables = {'ansible_search_path': ['/etc/ansible'], 'ansible_facts_dir': '/etc/ansible/facts.d'}
    kwargs = {'wantlist': False}

    # mock class instance
    l = LookupModule()

    assert l.run(terms, variables, **kwargs) == ['/etc/ansible/facts.d/foo.fact']

    # mock dict that represents module parameters
    terms = ['/etc/ansible/facts.d/*.fact']
    variables = {'ansible_search_path': ['/etc/ansible'], 'ansible_facts_dir': '/etc/ansible/facts.d'}

# Generated at 2022-06-21 06:02:15.049378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up test
    lookup = LookupModule()
    lookup.basedir = os.path.join(os.path.dirname(__file__), "test_data", "basedir")
    assert os.path.isdir(lookup.basedir)

    # check that glob in path works
    terms = ['test1.txt', 'test2.txt']
    ret = lookup.run(terms)
    assert ret == [os.path.join(lookup.basedir, "test1.txt"),
                   os.path.join(lookup.basedir, "test2.txt")]

# Generated at 2022-06-21 06:02:16.142355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:02:20.068618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        module = LookupModule()
        print(module)
    except:
        print("Exception")

