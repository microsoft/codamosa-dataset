

# Generated at 2022-06-21 05:53:21.317618
# Unit test for constructor of class LookupModule
def test_LookupModule():
  print('Executing test_LookupModule')
  test_lookup = LookupModule()
  assert type(test_lookup) == LookupModule
  print('Passed test_LookupModule')

if __name__ == '__main__':
  test_LookupModule()

# Generated at 2022-06-21 05:53:22.778087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test that result of constructor is an object of the right class
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:53:25.221119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: this method does not appear in the documentation.
    #       Make sure it is documented in the future.
    assert False

# Generated at 2022-06-21 05:53:25.864516
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:53:32.220699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_data = dict()
    input_data['terms'] = ['/my/path/*.txt']
    input_data['variables'] = dict()
    input_data['variables']['ansible_search_path'] = ['.', './files']
    lookup_obj = LookupModule()
    actual_output = list()
    actual_output.append('files/sample.txt')
    expected_output = lookup_obj.run(**input_data)
    assert expected_output == actual_output, 'Test failed : LookupModule - run failed for testcase: test_LookupModule_run'


# Generated at 2022-06-21 05:53:33.533580
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()

# Generated at 2022-06-21 05:53:35.483190
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # the lookup module is not a class, so there's nothing to test for
    pass

# Generated at 2022-06-21 05:53:37.281216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.Term('one')

# Generated at 2022-06-21 05:53:50.120398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_bytes, to_text

    class MockLookupBase(LookupBase):
        def get_basedir(self, variables):
            return "/home/test/ansible"

        def find_file_in_search_path(self, variables, path, directory=None):
            return "/home/test/ansible/file"

    # mocking glob module
    glob_path = "/home/test/ansible/file/fileglob_test.txt"
    glob_path_2 = "/home/test/ansible/file/fileglob_test_2.txt"
    mocked_glob = MockLookupBase.mock()

# Generated at 2022-06-21 05:53:58.940540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import pathlib
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        shutil.copyfile('lookup_plugins/fileglob.py', pathlib.Path(temp_dir) / 'lookup_plugins/fileglob.py')
        os.makedirs(pathlib.Path(temp_dir) / 'lookup_plugins/files')
        shutil.copyfile('lookup_plugins/files/nested.txt', pathlib.Path(temp_dir) / 'lookup_plugins/files/nested.txt')
        test_file = pathlib.Path(temp_dir) / 'test.txt'
        test_file.touch()

# Generated at 2022-06-21 05:54:08.826970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['LOOKUP_FILEGLOB_TEST_ENV'] = 'lookup_fileglob_test'
    lookup = LookupModule()
    lookup.set_loader()
    lookup.set_environment(os.environ.copy())
    res = lookup.run(["*.in"], variables={'ansible_system_capabilities':{'privileged': True}})
    assert res == [u'/etc/sudoers.in']

# Generated at 2022-06-21 05:54:20.706333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = DummyTemplar()


# Generated at 2022-06-21 05:54:27.704292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVars:
        ansible_search_path = ['', '']

    terms = ['/path/dir/a', '/path/dir/b']
    MockVars.ansible_search_path = ['', '/path/dir']
    lookup_obj = LookupModule()
    results = lookup_obj.run(terms, MockVars)
    assert terms == results

# Generated at 2022-06-21 05:54:28.209780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 05:54:35.052794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    search_path = [os.path.join(os.path.dirname(__file__), '..')]
    terms = [os.path.basename(__file__)]
    vars = {'ansible_search_path': search_path}
    assert module.run(terms=terms, variables=vars) == [os.path.abspath(__file__)]

# Generated at 2022-06-21 05:54:35.901930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 05:54:44.433662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    basic_terms = {
        'exist': [
            '/etc/ansible/ansible.cfg',
            '/etc/hosts'
        ],
        'not exist': [
            '/does/not/exist',
            '/me/either/no/sir'
        ]
    }

    testresults = {}
    for term_type, terms in basic_terms.items():
        testresults[term_type] = []
        for term in terms:
            testresults[term_type].append(LookupModule().run([term], dict(ansible_search_path=[os.getcwd()])))

    assert testresults == {
        'exist': [['/etc/ansible/ansible.cfg'], ['/etc/hosts']],
        'not exist': [[], []]
    }

# Generated at 2022-06-21 05:54:46.287247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:54:47.753183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 05:54:57.119841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['/my/path/*.txt'])[0] == "a.txt"
    assert LookupModule().run(["/my/path/a.txt"])[0] == "a.txt"
    assert LookupModule().run(["a.txt"])[0] == "a.txt"
    assert LookupModule().run(["../a.txt"])[0] == "a.txt"
    assert LookupModule().run(["../a.txt"])[0] == "a.txt"

# Generated at 2022-06-21 05:55:02.489198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    arg1 = ['*.txt']
    lookup = LookupModule()
    lookup.run(arg1)
    assert True

# Generated at 2022-06-21 05:55:09.082125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['/some/path/*.txt']
  variables = {'ansible_search_path': ['/some/path', '/other/path']}
  lm = LookupModule()
  lm.get_basedir = lambda x: '/ansible'
  assert lm.run(terms, variables) == ['/some/path/file1.txt', '/some/path/file2.txt']
  variables = {'ansible_search_path': ['/some/path', '/other/path']}
  lm = LookupModule()
  lm.get_basedir = lambda x: '/ansible'
  terms = ['/other/path/*.txt']
  assert lm.run(terms, variables) == []



# Generated at 2022-06-21 05:55:10.503705
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:55:12.276688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No, don't use the glob test file
    lookup = LookupModule()
    output = lookup.run(["foobar.conf"])
    assert not output

# Generated at 2022-06-21 05:55:17.141186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.errors import AnsibleLookupError
    # test empty terms
    terms = []
    variables = None
    result = []
    with pytest.raises(AnsibleLookupError):
        ans = LookupModule().run(terms)
    # test single term
    terms = ['filename']
    variables = { 'ansible_search_path': ['.', '~/directory'] }
    result_expected = ['/my/path/file.txt']
    # test empty terms
    ans = LookupModule().run(terms, variables)
    assert ans == result_expected
    # test multiple terms
    terms = ['filename', 'another_file.py']
    variables = { 'ansible_search_path': ['.', '~/directory'] }

# Generated at 2022-06-21 05:55:18.528329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 05:55:19.818997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()

# Generated at 2022-06-21 05:55:29.940146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a new instance of LookupModule
    lookupModule = LookupModule()
    lookupModule.run(terms, variables=None, **kwargs)
# To run, just type "python3 lookup_plugin/fileglob.py"
# You need to add the following code to an ansible.cfg file in order to run the test
# [defaults]
# inventory=tests/inventory
# [inventory]
# enable_plugins = host_list, script, yaml, ini, auto, dummy
# [privilege_escalation]
# [paramiko_connection]
# [ssh_connection]
# [persistent_connection]
# [accelerate]
# [selinux]
# [colors]
# [diff]
# [pipelining]
# [ssh_args]
# ssh_args = -o ControlMaster=

# Generated at 2022-06-21 05:55:41.108697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock object for variables
    variables = {
        'ansible_search_path': ['/playbooks/files/fooapp']
    }

    # create a mock object for to_bytes
    def mock_to_bytes(a, b):
        return 'test_to_bytes'

    # create a mock object for to_text
    def mock_to_text(a, b):
        return 'test_to_text'

    # create a mock object for find_file_in_search_path
    def mock_find_file_in_search_path(a, b, c):
        return 'test_find_file_in_search_path'

    # create a mock object for get_basedir
    def mock_get_basedir(a):
        return 'test_get_basedir'

    # create a mock

# Generated at 2022-06-21 05:55:42.181676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   ret = LookupModule.run()
   assert len(ret) == 0

# Generated at 2022-06-21 05:55:53.743857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import os.path

    lookup_module = LookupModule()

    # test with non existing file
    terms = os.path.join("/", "tmp", "non-existing-file")
    ret = lookup_module.run(terms, dict())
    assert ret == [], "unexisting file should match nothing"

    # test with one existing file
    terms = os.path.join("tests", "fixtures", "test.txt")
    ret = lookup_module.run(terms, dict())

# Generated at 2022-06-21 05:55:58.399342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["/my/path/*.txt"])
    assert lookup_module.run(terms=["/directory/path/*.txt"])
    assert lookup_module.run(terms=["/directory/path/*"])
    assert not lookup_module.run(terms=["/directory/fake_path/*"])

# Generated at 2022-06-21 05:56:09.718031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_plugin = LookupModule()
        f1 = open("/tmp/foo.txt", "w")
        f1.write("foo")
        f1.close()
        f2 = open("/tmp/bar.txt", "w")
        f2.write("bar")
        f2.close()
        lookup_plugin.get_basedir = lambda x: '/tmp'
        files = lookup_plugin.run(terms=['*.txt'], variables=dict(ansible_search_path=['/tmp']), convert_data=True)
        assert files == ['/tmp/foo.txt', '/tmp/bar.txt']
    finally:
        os.unlink('/tmp/foo.txt')
        os.unlink('/tmp/bar.txt')

# Generated at 2022-06-21 05:56:12.064563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:56:22.529213
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    tm = LookupModule()

    # test with ansible_search_path
    terms = list()
    terms.append("file.yml")
    terms.append("file2.yml")
    variables = {}
    variables['ansible_search_path'] = list()
    variables['ansible_search_path'].append("/tmp/ansible")
    variables['ansible_search_path'].append("/tmp/ansible/fileglob")
    variables['ansible_search_path'].append("/tmp/ansible/fileglob/folder")
    variables['ansible_search_path'].append("tmp/ansible/fileglob/folder")

    # test with no existing files
    ret = tm.run(terms, variables)
    assert ret == []

    # test with existing directory /tmp/

# Generated at 2022-06-21 05:56:29.284503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    
    # Directory is empty
    terms = ['*']
    dwimmed_path = '/home/username/empty/'
    result = lookup_module.run(terms, {}, basedir=dwimmed_path)
    assert result == []
    
    
    # Test globbing files
    terms = ['*']
    dwimmed_path = '/home/username/'
    result = lookup_module.run(terms, {}, basedir=dwimmed_path)
    assert result == []
    
    # Test globbing files with wildcard
    terms = ['*.txt']
    dwimmed_path = '/home/username/'
    result = lookup_module.run(terms, {}, basedir=dwimmed_path)

# Generated at 2022-06-21 05:56:39.665312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    import yaml
    from ansible.plugins.loader.lookup_loader import LookupLoader
    from ansible.utils.display import Display
    display = Display()
    lookup = LookupLoader()._get_lookup_plugin_instance(display, "fileglob")

    # Act
    result = lookup.run(["/home/pcurtis/Documents/GitHub/ansible-testing/filglob/example_file.txt"])

    # Assert
    assert result == ['/home/pcurtis/Documents/GitHub/ansible-testing/filglob/example_file.txt']

# Generated at 2022-06-21 05:56:42.436700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    assert t.run(['./db-*','db_5','notfound'], dict(ansible_search_path=['/var/lib'])) == ['/var/lib/db-1']

# Generated at 2022-06-21 05:56:44.544308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:56:46.501228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

