

# Generated at 2022-06-21 05:53:24.830268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(None, ['/testfiles/a/b/c/file.txt', '/testfiles/a/b/c/file.abc']) == ['/testfiles/a/b/c/file.txt', '/testfiles/a/b/c/file.abc']
    assert LookupModule.run(None, ['/testfiles/a/b/c/*.txt']) == ['/testfiles/a/b/c/file.txt']
    assert LookupModule.run(None, ['/testfiles/a/b/c/*']) == ['/testfiles/a/b/c/file.txt', '/testfiles/a/b/c/file.abc']

# Generated at 2022-06-21 05:53:26.305186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 05:53:28.545869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ['test1', 'test2']
    result = lm.run(terms)
    assert result == []


# Generated at 2022-06-21 05:53:40.124497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.get_basedir = lambda x: '/'
    lookup.find_file_in_search_path = lambda variables, filepath, temppath: '/'
    lookup.get_basedir = lambda:'/'
    # test good
    assert lookup.run(['file1.txt'], {}, wantlist=False) == ['file1.txt']
    assert lookup.run(['file1.txt'], {}, wantlist=True) == ['file1.txt']

    # test bad
    assert lookup.run(['file2.txt'], {}, wantlist=False) == []
    assert lookup.run(['file2.txt'], {}, wantlist=True) == []

    # test with path

# Generated at 2022-06-21 05:53:52.113662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys, tempfile, shutil
    from io import open
    from ansible.module_utils import basic
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes, to_text

    fd, tfile = tempfile.mkstemp()
    with open(to_bytes(tfile, errors='surrogate_or_strict'), 'wb') as f:
        f.write(to_bytes("first\nsecond\nthird\nfourth"))

    # prepare the environment
    d = tempfile.mkdtemp()
    ds = os.path.join(d, "subdir")
    os.mkdir(ds)
    fqp = os.path.join(ds, "file1.txt")

# Generated at 2022-06-21 05:53:54.084545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:53:57.213892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule
    except NameError:
        raise AssertionError("Constructor for class LookupModule was not found")
    assert(isinstance(LookupModule, type))

# Generated at 2022-06-21 05:53:59.684529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    terms = ['/etc/*.conf']
    t.run(terms)

# Generated at 2022-06-21 05:54:08.425519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_hash = {'ansible_search_path' : ['/root/ansible', '/root/ansible/test']}
    module = LookupModule()
    module.get_basedir = lambda x: '/root/ansible'
    module.find_file_in_search_path = lambda x, y, z: '/root/ansible/test'
    result = module.run(['*.txt'], my_hash)
    assert result == ['/root/ansible/test/test.txt']

# Generated at 2022-06-21 05:54:09.831615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:54:13.714513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(['test_search_path']) == []

# Generated at 2022-06-21 05:54:22.456215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_basedir({}) == '.', 'Expected . basedir, got %s' % lookup.get_basedir({})
    assert lookup.get_basedir({'playbook_dir': '/tmp/playbook'}) == '/tmp/playbook', 'Expected /tmp/playbook basedir, got %s' % lookup.get_basedir({'playbook_dir': '/tmp/playbook'})
    assert lookup.find_file_in_search_path({}, 'files', './') == to_bytes('./files/'), 'Expected ./files/ as file path, got %s' % lookup.find_file_in_search_path({}, 'files', './')
    assert lookup.find_file_in_search_path({}, 'files', '/tmp/playbook')

# Generated at 2022-06-21 05:54:28.675561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a temp file and then use fileglob to see if it is found
    import tempfile
    import os
    f = tempfile.NamedTemporaryFile(delete=False)
    file_path = f.name
    f.close()
    assert file_path == LookupModule().run(['%s' % file_path])[0]
    os.remove(file_path)

# Generated at 2022-06-21 05:54:29.186195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:54:30.657440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-21 05:54:38.083555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test whether method run of class LookupModule returns nothing
    # when no path(s) of files to read exists for the given pattern
    assert LookupModule().run(['/tmp/test_fileglob*']) == []

    # Test whether method run of class LookupModule returns nothing
    # when path(s) of files to read exists for the given pattern
    # but the given pattern is not a file name
    assert LookupModule().run(['/tmp/test_fileglob*']) == []

    # Test whether method run of class LookupModule returns expected
    # path(s) of files to read exists for the given pattern
    assert LookupModule().run(['/etc/hosts']) == ['/etc/hosts']

# Generated at 2022-06-21 05:54:49.519873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('\n'*2)
    print('---Starting test of LookupModule---')
    lookup_module = LookupModule()
    assert os.path.dirname(lookup_module.find_file_in_search_path(None, 'files', '.')) == '/etc/ansible'
    assert lookup_module.find_file_in_search_path(None, 'files', '.') == ''
    assert lookup_module.get_basedir({}) == '/etc/ansible'
    assert lookup_module.run(['.'], {'ansible_search_path': ['.', 'base_dir']}) == ['/etc/ansible/module_utils/urls.py']

# Generated at 2022-06-21 05:54:56.622505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_basedir({}) == '.'
    assert lookup.run('foo', dict(ansible_search_path=['/tmp','/foo'])) == []
    assert lookup.run(['/foo','/tmp/bar.txt'], dict(ansible_search_path=['/tmp','/foo'])) == ['/tmp/bar.txt']

# Generated at 2022-06-21 05:55:00.803103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test class instantiation
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 05:55:07.981137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModuleTest(LookupModule):
        def __init__(self, basedir=None, **kwargs):
            self.basedir = basedir
    assert LookupModuleTest(basedir='/').run(['/etc/hosts']) == ['/etc/hosts']
    assert LookupModuleTest(basedir='/').run(['/etc/hosts/']) == []

# Generated at 2022-06-21 05:55:13.995890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_glob = LookupModule()
    assert test_glob is not None

# Generated at 2022-06-21 05:55:17.111175
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 05:55:17.925099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:55:20.380173
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run(["not_a_real_file"], variables=None)) == 0

# Generated at 2022-06-21 05:55:26.251858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test will test the class LookupModule
    """
    test_LookupModule = LookupModule()
    test_terms = ["wassup"]
    test_variables = None

    result = test_LookupModule.run(test_terms, test_variables)
    assert result == []

# Generated at 2022-06-21 05:55:28.872657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-21 05:55:32.433888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    # The following are the parameters for the test function
    module_params = dict(
        _terms = '../testfile',
        ansible_search_path = [ '.' ]
    )
    assert LookupModule().run(**module_params) == [ to_text('../testfile') ]

# Generated at 2022-06-21 05:55:33.565200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:55:37.674290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing test to check the return values of run method of class LookupModule
    test = LookupModule()
    assert test.run(["README.md"]) == ['README.md']

# Generated at 2022-06-21 05:55:38.155445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:55:53.678205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for run method of class LookupModule'''
    lookup_module = LookupModule()
    terms = ['/etc/sudoers', '*.conf'] # should return ['*.conf']
    test_dir = os.path.dirname(__file__)
    ansible_search_path = [test_dir]
    variables = dict(ansible_search_path=ansible_search_path)
    ret = lookup_module.run(terms, variables)
    assert len(ret) == 1
    assert ret[0] == '*.conf'


# Generated at 2022-06-21 05:56:05.509427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    # Create a test case for the LookupModule class.
    # In this test case, we assume that ansible.cfg file exists at path /etc/ansible/ansible.cfg.

# Generated at 2022-06-21 05:56:12.176061
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup a mock environment
    import ansible.utils.path
    import ansible.vars
    test_path = [u'/path/to/files']
    lookup_instance = LookupModule()
    variables = ansible.vars.VariableManager()
    variables.extra_vars = {
        'ansible_search_path': test_path
    }

    # Test run method
    with patch("os.path.isfile", Mock(return_value=True)):
        with patch("glob.glob", Mock(return_value=[u'file1', u'file2'])):
            ret = lookup_instance.run([u'*'], variables=variables)
            assert ret == [u'/path/to/files/file1', u'/path/to/files/file2']

# Generated at 2022-06-21 05:56:16.527857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Verify that the method ``run`` of class ``LookupModule`` returns a list."""
    lookup = LookupModule()
    assert isinstance(lookup.run(terms=["*.yml"]), list)


# Generated at 2022-06-21 05:56:19.013336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Executing tests for LookupModule class")
    res = None

# Generated at 2022-06-21 05:56:21.342609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod.run is not None

# Generated at 2022-06-21 05:56:28.510566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if not os.path.exists('unittest/test_ansible_fileglob.txt'):
        raise
    with open('unittest/test_ansible_fileglob.txt', 'r') as myfile:
        data = myfile.read()
    test_obj = LookupModule()
    test_ret = test_obj.run(['unittest/test_ansible_fileglob.txt'], {})
    if test_ret[0] != data:
        raise

# Generated at 2022-06-21 05:56:39.664742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    terms = ['/my/path/*.txt']
    look_up_mod = LookupModule()
    look_up_mod.get_basedir = lambda variables: to_bytes(os.path.abspath("tests/test_root"))
    # tests/test_root should have the following file structure
    # test_root/my/path/foo.txt
    result = look_up_mod.run(terms, variables={})
    assert result == [to_text(os.path.abspath("tests/test_root/my/path/foo.txt"))]
    # test for absolute paths
    terms = ['/etc/hosts']
    result = look_up_mod.run(terms, variables={})
    assert result == [to_text('/etc/hosts')]


# Generated at 2022-06-21 05:56:51.527436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    module = LookupModule()
    # Execute
    res = module.run(['foo.txt'],{'ansible_search_path': ['/foo/bar','/baz/qux/', 'corge/grault']})
    # Assert
    assert res == ['/foo/bar/foo.txt','/baz/qux/foo.txt', 'corge/grault/foo.txt']
    # Execute
    res = module.run(['/foo/bar/foo.txt'], {'ansible_search_path': ['/foo/bar', '/baz/qux/', 'corge/grault']})
    # Assert
    assert res == ['/foo/bar/foo.txt']
    # Execute

# Generated at 2022-06-21 05:57:01.148874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert len(lookup.run([], {})) == 0
    assert len(lookup.run(['not-file.yml'], {})) == 0
    assert len(lookup.run(['file*.yml'], {})) == 0
    assert len(lookup.run(['file*.yml', 'foo.txt'], {'files': 'files'})) == 0
    assert len(lookup.run(['file*.yml', 'foo.txt'], {'ansible_playbook_python': 'python'})) == 0
    assert len(lookup.run(['file*.yml', 'foo.txt'], {'ansible_playbook_python': 'python', 'files': 'files'})) == 0

# Generated at 2022-06-21 05:57:14.332274
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = LookupModule()
    assert d is not None

# Generated at 2022-06-21 05:57:17.100968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(["README.md"], None)
    assert result[0].endswith("README.md")
    assert len(result) == 1

# Generated at 2022-06-21 05:57:25.846888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    real_file = open(__file__, "r")
    term1 = "{0}:{1}".format(os.path.dirname(__file__), "*.py")
    term2 = "{0}:{1}".format(os.path.dirname(__file__), "*.txt")
    terms = [term1, term2]
    lookup.run(terms, None)
    lookup.run([real_file.name], None)

# Generated at 2022-06-21 05:57:30.789659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Running test_LookupModule_run")
    # the following test will fail if run from the root directory of the project or the tests directory is not present
    # to fix this the tests directory needs to be added to the path variable
    lm = LookupModule()
    try:
        result = lm.run(['test_LookupModule_run.py'], variables=dict(), wantlist=True)
        assert result == ['test/test_LookupModule_run.py']
    except AssertionError as e:
        print("Test case failed " + str(e))

# Generated at 2022-06-21 05:57:38.001187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert len(lookup_module.run(["/etc/passwd"])) > 0
    assert len(lookup_module.run(["/etc/passwd","/etc/group"])) > 0
    assert not lookup_module.run(["/etc/passwd","/etc/group","/etc/hostsx"])

# Generated at 2022-06-21 05:57:50.014438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleFileNotFound
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    hostvars = dict(ansible_search_path=['/some/path'])
    inventory = dict(loader=DataLoader(),
                     variable_manager=dict(hostvars=dict(test=Host(name='test', hostname='test'))),
                     get_host=lambda h: Host(name=h, vars=hostvars))
    basedir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking', 'test-module')

    lookup = LookupModule()
    lookup.set_loader(DataLoader())


# Generated at 2022-06-21 05:57:51.426266
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:57:54.923018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run(['*.txt'], None) == []

# Generated at 2022-06-21 05:57:55.616151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 05:58:03.409605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Construct
    lmodule = LookupModule()
    working_path = os.getcwd()

    # Create test file in working directory
    with open('test_file.txt', 'w') as file:
        file.write("This is a test file for method run of class LookupModule.")

    # Create test directory in working directory
    os.makedirs('test_dir')

    # Create test file in working directory
    with open('test_dir/test_file.txt', 'w') as file:
        file.write("This is a test file for method run of class LookupModule.")

    # test when working directory is an element of search path
    variables = {'ansible_search_path': [working_path, 'test_dir']}

    # test when search path is not defined

# Generated at 2022-06-21 05:58:36.390321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyLookupModule(LookupModule):

        def find_file_in_search_path(self, variables, dirname, path):
            search_path = None
            if path == 'base_path':
                search_path = variables['first_search_path']
            elif path == 'base_path_two':
                search_path = variables['second_search_path']
            elif path == 'base_path_three':
                search_path = variables['third_search_path']
            return search_path

        def get_basedir(self, variables):
            return variables['basedir']


# Generated at 2022-06-21 05:58:38.124782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 05:58:44.254629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    terms = ['/my/path/*.txt', '/my/path/a*.txt', '/my/path/b*.txt']
    variables = {'ansible_search_path': ['/one/path', '/two/path', '/three/path']}
    search_paths = ['/one/path/files', '/two/path/files', '/three/path/files', '/one/path', '/two/path', '/three/path']
    import mock
    a = LookupModule()
    with mock.patch.object(LookupModule, 'find_file_in_search_path') as m:
        m.return_value = '/my/path'
        result = a.run(terms, variables)

# Generated at 2022-06-21 05:58:53.788902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Method run() test cases
    """
    # unit test:
    # fileglob lookup to display all files in a given path
    # test with directory, file and list of files
    assert LookupModule().run(["/home/user/file1*"]) == [
        '/home/user/file1.txt']

    # unit test:
    # fileglob lookup to display all files matching .yml in a given path
    # test with only directory
    assert LookupModule().run(["/home/user/file2*.yml"]) == [
        '/home/user/file2.yml']

    # unit test:
    # fileglob lookup to display all files matching .yml in a given path
    # test with directory, file and list of files

# Generated at 2022-06-21 05:58:59.850045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {
        'ansible_search_path': [
            '/etc/ansible/roles',
            '/tmp/ansible/roles'
        ]
    }
    module = LookupModule()
    module.run(['/path/to/fileglob/test.fileglob'], data)

# Generated at 2022-06-21 05:59:05.213443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get values from LookupModule class
    LookupModule_obj = LookupModule()
    terms = ['*.txt']
    variables = {'ansible_search_path': 'testAnsible'}
    returned_value = LookupModule_obj.run(terms, variables)
    assert returned_value == ['testAnsible/files/filename.txt']

    # Get values from LookupModule class
    LookupModule_obj = LookupModule()
    terms = ['*.txt']
    variables = {'ansible_search_path': 'testAnsible', '_original_file': '../testLookup/testLookup.py'}
    returned_value = LookupModule_obj.run(terms, variables)
    assert returned_value == ['testAnsible/files/filename.txt']

    # Get values from Lookup

# Generated at 2022-06-21 05:59:06.011524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:59:07.405490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:59:11.848781
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert lookup_module.get_basedir('my_basedir') != 'my_basedir'
    assert lookup_module.find_file_in_search_path('search_path', 'key', 'name') != 'search_path'

# Generated at 2022-06-21 05:59:23.175907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    lookup_module = LookupModule()
    test_dir = os.getcwd()

    try:
        os.makedirs(os.path.expanduser('~/lookup_test_dir'))
        os.chdir(os.path.expanduser('~'))
        lookup_module.run(['lookup_test_dir/lookup_test_file'])
    finally:
        os.chdir(test_dir)

    assert not os.path.exists(os.path.expanduser('~/lookup_test_dir'))


# Generated at 2022-06-21 06:00:26.776622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test case is designed to test the correct behavior of run()
    # when the file pattern matches files in a directory and its subdirectories.
    lookup_module = LookupModule()
    term_file_pattern = '*.txt'
    basedir = '/Users/kranjini/ansible_lookup_plugins/tests/data/'
    terms = [term_file_pattern]
    variables = {}
    globbed_files = lookup_module.run(terms, basedir=basedir, variables=variables, wantlist=True)
    # Following is the list of files with .txt extension from the given basedir and its subdirectories.

# Generated at 2022-06-21 06:00:29.233308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# End of tests


# Generated at 2022-06-21 06:00:38.418154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    import os
    import glob
    from os.path import join, isfile, dirname, basename
    from tests.test_utils import AnsibleExitJson, AnsibleFailJson, AnsibleExitModule

    module_args = {
        "strip_newlines": "yes",
        "terms": [],
        "variables": {
            "ansible_search_path": [
                "testdir",
                "testdir1",
                "testdir2",
                "testdir3"
            ]
        }
    }


# Generated at 2022-06-21 06:00:41.386910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['../unit/module_utils/_text.py']) == ['../unit/module_utils/_text.py']

# Generated at 2022-06-21 06:00:42.589132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)


# Generated at 2022-06-21 06:00:45.571258
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test variable
    my_variable = {}
    # Test object
    test_object = LookupModule()
    # Get result of run function
    result = test_object.run(['/etc/ansible/*'],
                             variables=my_variable,
                             wantlist=True)
    # Assert
    assert type(result) == list
    assert len(result) > 0

# Generated at 2022-06-21 06:00:48.466542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # Check if class exist
    assert lookup_plugin

# Generated at 2022-06-21 06:00:53.653832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.module_utils.six import PY3
  assert(PY3)

  # Arrange
  assert(True)

  # Act
  # result = LookupModule.run()

  # Assert
  # assert(result)

# Generated at 2022-06-21 06:01:05.283075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = [
        '/my/own/file/local.txt',
        'my/own/file/local.txt',
        '../my/own/file/local.txt',
        '/my/own/glob/*.txt',
        'my/own/glob/*.txt',
        '../my/own/glob/*.txt'
    ]

    variables = {
        'ansible_search_path': ['/my/own/file']
    }

    results = module.run(terms, variables)


# Generated at 2022-06-21 06:01:10.096051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['./files/foo.txt']
    result = lookup.run(terms)
    assert result == ['./files/foo.txt']