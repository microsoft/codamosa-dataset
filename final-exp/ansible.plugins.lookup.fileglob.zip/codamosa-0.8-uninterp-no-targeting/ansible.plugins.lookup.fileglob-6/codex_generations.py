

# Generated at 2022-06-21 05:53:17.167784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:53:27.495482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    #Test with no dir given, just file
    terms = ["/tmp/testfile.txt"]
    terms_expected = [os.path.join(os.getcwd(), "/tmp/testfile.txt")]
    ret = l.run(terms)
    assert ret == terms_expected

    #Test with dir and file given
    terms = ["/tmp/testfile.txt"]
    terms_expected = [os.path.join(os.getcwd(), "/tmp/testfile.txt")]
    ret = l.run(terms)
    assert ret == terms_expected

# Generated at 2022-06-21 05:53:29.224782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == LookupModule

# Generated at 2022-06-21 05:53:31.604642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #This test does not work because we can't get the method find_file_in_search_path of super class LookupBase
    #If we can get it, we can test the method run
    assert False


# Generated at 2022-06-21 05:53:36.430611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'terms': [u'/my/path/*.txt'], 'variables': {}}
    lm = LookupModule()
    val = lm.run(**args)[0]
    assert val == u'/my/path/new.txt'

# Generated at 2022-06-21 05:53:42.766168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = []
    terms.append('/my/path/my_file')
    terms.append('my_file_2')
    terms.append('my_file_3.txt')
    terms.append('/my/path/no_file')
    terms.append('/another/path/no_file')
    terms.append('another_no_file')
    ret = l.run(terms, variables={'ansible_search_path': ['/my/path', '/another/path','.']}, **{'wantlist': True})
    assert (ret == ['/my/path/my_file', 'my_file_2', 'my_file_3.txt'])

# Generated at 2022-06-21 05:53:52.735453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    # variables is a built-in variable of Ansible
    # it is an environment variable in the playbook
    # https://github.com/ansible/ansible/blob/v2.7.0/lib/ansible/inventory/host.py#L719-L725
    myTerms = ['/path/to/term']
    myVariables = {'hostvars': {}}

    # test the result
    # expected result is the same as the example in Ansible document
    # https://docs.ansible.com/ansible/latest/plugins/lookup/fileglob.html
    assert myLookupModule.run(myTerms, myVariables) == ['/path/to/term']

# Generated at 2022-06-21 05:53:55.140974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_constructor():
        print('Testing constructor')
        lm = LookupModule()


# Generated at 2022-06-21 05:53:55.936357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) == type

# Generated at 2022-06-21 05:54:02.026872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    my_loader = DataLoader()
    my_inventory = InventoryManager(my_loader,'localhost,')
    my_variables = VariableManager(my_loader,my_inventory)

    my_lookupModule = lookup_loader.get('fileglob', my_variables, my_loader)

    # Test the case where there is a path ending with a file
    result = my_lookupModule.run('/tmp/fileglob_test.txt', my_variables)
    assert result == ['/tmp/fileglob_test.txt'], "fileglob_test.txt file was not found"

    #

# Generated at 2022-06-21 05:54:12.316165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(['globfile'], variables = {'ansible_search_path': ['/tmp'], 'ansible_basedir': '/tmp'}) == []

    # set 'files' directory in search path
    l = LookupModule()
    variables = {'ansible_search_path': ['/tmp', '/tmp/files'],
                 'ansible_basedir': '/tmp'}
    assert l.run(['globfile'], variables = variables) == []

    # set 'files' directory in search path
    l = LookupModule()
    variables = {'ansible_search_path': ['/tmp', '/tmp/files'],
                 'ansible_basedir': '/tmp'}
    assert l.run(['testfile'], variables = variables) == []

    #

# Generated at 2022-06-21 05:54:15.976255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(["somestring"])
    assert len(result) == 0

test_LookupModule_run()

# Generated at 2022-06-21 05:54:22.482078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # default test
    lookup = LookupModule()
    lookup._connection = MagicMock()
    lookup.get_basedir = MagicMock()
    lookup._loader = MagicMock()
    # mock real file
    lookup._loader.get_basedir = MagicMock(return_value='/home/data/')
    terms = ['/home/data/test/test_*.py']
    variables = {}
    results = lookup.run(terms, variables, wantlist=True)
    file_list = ['/home/data/test/test_LookupModule_run.py', '/home/data/test/test_LookupModule_run.py']
    assert results == file_list

# Generated at 2022-06-21 05:54:24.179803
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:54:26.479558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:54:36.806893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import binary_type
    class FakeVars(dict):
        def get(self, key, default):
            if key == 'ansible_search_path':
                return ['/nonexistant1/', '/nonexistant2/']
            else:
                return {}.get(key, default)
    terms = [['*testfile*'], ['testfile.*'], ['testfile.txt']]
    paths = LookupModule().run(terms, FakeVars())
    assert isinstance(paths, list)
    assert all(isinstance(path, binary_type) for path in paths)
    assert sorted(paths) == sorted(LookupModule().run(terms, FakeVars()))

# Generated at 2022-06-21 05:54:49.172964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test of method LookupModule.run"""
    # pylint: disable=no-name-in-module
    from ansible.parsing import vault
    # pylint: enable=no-name-in-module

    lookup_module = LookupModule()

    ###########################################
    # Test when fileglob is in system path
    ###########################################

    # Test with a file
    ret = lookup_module.run(['/etc/profile'], dict(ansible_search_path=['/etc', '/etc/profile'], ansible_password='password'))
    assert(ret == [u'/etc/profile'])

    # Test with a file that does not exist and path that exists

# Generated at 2022-06-21 05:55:00.451710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self):
            super(TestLookupModule, self).__init__(None, None, None)

        def find_file_in_search_path(self, variables, dirname, filename):
            return dirname
            
    import tempfile
    import shutil
    import random
    import string
    import os
    import stat
    import glob

    # create directory with random content
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 05:55:08.142704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda variables: "dummy"
    l.find_file_in_search_path = lambda variables, dirname, path: "/"

    # test() method calls run() method, passing empty list of search paths:
    # empty search paths should not affect the result of glob, as glob
    # should be executed against the current working directory
    assert l.test([],{}) == [
        'test_fileglob_test.py',
        'test_fileglob.py',
    ]

    # test() method calls run() method, passing a list of search paths:

# Generated at 2022-06-21 05:55:10.147940
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module)

# Generated at 2022-06-21 05:55:12.728624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:55:21.753458
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dummy_module = type('', (), {})()
    dummy_module.basedir = os.path.abspath(".")

    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_templar(None)

    # No matches
    terms = ["not/found/file*.txt"]

    # No terms
    assert lookup.run(terms, {}) == []

    # Single match
    test_file = "./test/testfile.txt"
    with open(test_file, "w") as f:
        f.write("Lookup Test")
    assert lookup.run(terms, {}) == [test_file]
    os.remove(test_file)

    # Multiple matches
    test_file_1 = "./test/test1.txt"

# Generated at 2022-06-21 05:55:23.180852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule = LookupModule()

# Generated at 2022-06-21 05:55:23.868923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule()

# Generated at 2022-06-21 05:55:24.824251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 05:55:34.035585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.basedir = '.'
    # Override basedir as test path
    lookup.basedir = 'tests/testdata/lookup_plugins/fileglob'
    terms = ['/test.txt']
    with open('tests/testdata/lookup_plugins/fileglob/test.txt', 'r') as f:
        result = lookup.run(terms)
        assert result == [f.name]
    # Override basedir as test path
    lookup.basedir = 'tests/testdata/lookup_plugins/fileglob_2'
    terms = ['test.txt']
    with open('tests/testdata/lookup_plugins/fileglob_2/test.txt', 'r') as f:
        result = lookup.run(terms)

# Generated at 2022-06-21 05:55:42.429528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    from ansible.module_utils._text import to_bytes

    ret = []
    look = LookupModule()
    term = '/path/to/test/*.txt'

    term_file = os.path.basename(term)
    found_paths = []
    if term_file != term:
        found_paths.append(look.find_file_in_search_path({}, 'files', os.path.dirname(term)))
    else:
        # no dir, just file, so use paths and 'files' paths instead
        paths = [look.get_basedir({})]
        for p in paths:
            found_paths.append(os.path.join(p, 'files'))
            found_paths.append(p)


# Generated at 2022-06-21 05:55:46.309904
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 05:55:47.546300
# Unit test for constructor of class LookupModule
def test_LookupModule():
	lookupModule = LookupModule()
	assert lookupModule != None

# Generated at 2022-06-21 05:55:52.052012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("In test_LookupModule")
    test_lookup = LookupModule()
    test_lookup_terms = [ "*.txt"]
    assert(test_lookup.run(test_lookup_terms))

# Generated at 2022-06-21 05:55:58.676627
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) is type

# Generated at 2022-06-21 05:56:00.765947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(type(lookup_module))

# Generated at 2022-06-21 05:56:04.185182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    print(l)

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:56:11.817231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests the case of files in the same directory as the playbook
    assert(len(LookupModule().run(['*.py'])) >= 5)

    # Tests the case of files in a relative directory to the playbook
    assert(LookupModule().run(['test/ansible_test/module_utils/urls.py']) == ['test/ansible_test/module_utils/urls.py'])

    # Tests the case of files in an absolute directory
    assert(LookupModule().run(['/test/ansible_test/module_utils/urls.py']) == ['/test/ansible_test/module_utils/urls.py'])

    # Tests the case of files in a relative directory to the playbook

# Generated at 2022-06-21 05:56:22.499871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()

    # Test with correct search path
    # Test with term list containing only one element to check for correct file name in dwimmed_path
    terms = [ '/test/path/testfile_a' ]
    variables = { 'ansible_search_path' : [ '/test/path/files' ] }
    result = test_LookupModule.run( terms, variables )
    assert( result[0] == '/test/path/files/testfile_a' )


    # Test with term list containing two elements to check for correct file names in dwimmed_path
    terms = [ '/test/path/testfile_a', '/test/other_path/testfile_b' ]

# Generated at 2022-06-21 05:56:23.759397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 05:56:25.767553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert len(l.run(['/wrong/path/*.txt'])) == 0
    assert len(l.run(['/usr/share/*.txt'])) != 0

# Generated at 2022-06-21 05:56:27.153287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["/etc/*"]) == ["/etc/passwd", "/etc/group"]

# Generated at 2022-06-21 05:56:39.180301
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ret = []
    lm = LookupModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    for term in ["*"]:
        term_file = os.path.basename(term)
        found_paths = []
        if term_file != term:
            found_paths.append(lm.find_file_in_search_path(variable_manager, 'files', os.path.dirname(term)))

# Generated at 2022-06-21 05:56:40.064047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 05:56:54.937739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.vars.unsafe_proxy import UnsafeProxy

    pytest.importorskip("glob")

    lm = LookupModule()
    basedir = lm.get_basedir()
    filename = 'test.txt'
    filepath = os.path.join(basedir, filename)
    term = filename
    terms = [term]

    with pytest.raises(AnsibleFileNotFound):
        lm.run(terms)

    with open(filepath, 'w') as myfile:
        myfile.write('foo\n')

    results = lm.run(terms)
    assert isinstance(results, list)
   

# Generated at 2022-06-21 05:56:55.699499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:57:04.046253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Run tests on LookupModule.run()
    """

    # We add a test that works with the ansible_search_path global variable
    # This variable is set to a relative path
    # When we run the test we set the current directory to a valid directory where
    # we have ansible_search_path.
    # The result of the lookup module is a list which contains the path of a file
    # that is found according to the pattern given to the run function (test_pattern)

    # We first import LookupModule class
    from ansible.plugins.lookup import LookupBase

    # We import the modules that allow to get the current directory
    import os

    # We construct the path to the current directory
    test_path = os.path.abspath(__file__)

    # We split this path in order to keep only the

# Generated at 2022-06-21 05:57:15.937231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['ANSIBLE_LIBRARY'] = os.path.join(os.path.dirname(__file__), '../../lookup_plugins')
    os.environ['ANSIBLE_FILES_FOLDER'] = os.path.join(os.path.dirname(__file__), '../../playbooks/files')
    lookup = LookupModule()
    result = lookup.run([], {}, wantlist=True)
    assert len(result) == 0
    result = lookup.run(['*.txt'], {}, wantlist=True)
    assert len(result) == 1
    assert result[0] == '../../playbooks/files/test.txt'
    result = lookup.run(['*/test.txt'], {}, wantlist=True)
    assert len(result) == 1
    assert result

# Generated at 2022-06-21 05:57:28.028370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test to check if method run of class LookupModule works for the following cases:
    None.
    Multiline text.
    Single line text.
    """

    lp = LookupModule()
    result_text = lp.run(terms = ['*.log'], variables={'ansible_search_path': ['/Users/abcd/test/', '/Users/abcd/test2/']})
    assert result_text is not None
    assert result_text == [u'/Users/abcd/test/test3.log', u'/Users/abcd/test2/test.log'] or result_text == [u'/Users/abcd/test2/test.log', u'/Users/abcd/test/test3.log']

# Generated at 2022-06-21 05:57:31.482960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda: "/path/to/basedir"
    l.find_file_in_search_path = lambda variables, dirname, filename: "/path/to/basedir/" + filename
    r = l.run(["sample.conf"])
    assert to_text(r[0]) == "/path/to/basedir/sample.conf"

# Generated at 2022-06-21 05:57:42.175486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'fileglob')
    table = (
        (['file1.yaml'], ['file1.yaml']),
        (['file2.yaml'], ['file2.yaml']),
        (['*.yaml'], ['file1.yaml', 'file2.yaml']),
        (['a*.yaml'], ['a*.yaml']),
        (['nonexist*.yaml'], ['nonexist*.yaml']),
        (['dir1/*.yaml'], ['dir1/*.yaml']),
        (['dir1/a*.yaml'], ['dir1/a*.yaml']),
    )


# Generated at 2022-06-21 05:57:49.774152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.basedir = './../'
    lookup.get_basedir = lambda x: './../'

    result = []
    result.extend(lookup.run(['./../test/test_utils.py'], dict()))
    result.extend(lookup.run(['../test/test_utils.py'], dict()))
    result.extend(lookup.run(['*.py', 'files/file_*.yml'], dict()))
    result.extend(lookup.run(['*.py'], dict()))
    result.extend(lookup.run(['./../test/test_utils.py'], dict(ansible_search_path=['./'])))

# Generated at 2022-06-21 05:57:53.090348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    print(lm.run(['./ansible.cfg']))


# Generated at 2022-06-21 05:57:57.358323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/playbooks/files/fooapp/bar*']
    variables = {}
    ret = LookupModule().run(terms, variables)
    print("Return list: " + ret + "\n")