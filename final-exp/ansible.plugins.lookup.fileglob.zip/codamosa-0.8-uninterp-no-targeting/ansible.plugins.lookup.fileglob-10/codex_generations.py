

# Generated at 2022-06-21 05:53:21.034050
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleFileNotFound
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    lookup_instance = LookupModule()
    data_loader = DataLoader()
    lookup_instance.set_loader(data_loader)
    variable_manager = VariableManager()
    lookup_instance.set_vars(variable_manager)

    assert isinstance(lookup_instance, LookupBase)
    try:
        if lookup_instance.get_basedir({}) is None:
            raise Exception("AnsibleFileNotFound")
    except AnsibleFileNotFound as e:
        pass

    # Test return file name and not directory

# Generated at 2022-06-21 05:53:22.147619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['file'], variables=dict(ansible_playbook_python=None))

# Generated at 2022-06-21 05:53:23.141213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:53:25.232289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-21 05:53:33.194410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Sample input
    term='/my/path/*.txt'
    module_args={'_ansible_check_mode': True, '_ansible_debug': False, '_ansible_diff': False, '_ansible_keep_remote_files': False, '_ansible_module_name': 'fileglob', '_ansible_no_log': False, '_ansible_selinux_special_fs': [], '_ansible_socket': None, '_ansible_verbosity': 0, '_terms': term}
    set_module_args(module_args)
    # Instantiate LookupModule
    lookup_plugin = LookupModule()

    # Call run method of LookupModule
    result = lookup_plugin.run(terms=term)

    # Assert first globbed path equals '/my/path/file

# Generated at 2022-06-21 05:53:34.679357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # for now just make sure it doesn't fail
    assert LookupModule().run(['README.rst'], dict())

# Generated at 2022-06-21 05:53:39.154265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six.moves import builtins
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert isinstance(lookup_module, object)
    assert isinstance(lookup_module, builtins.object)

# Test the run() method of class LookupModule

# Generated at 2022-06-21 05:53:42.972104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # test the 'run' method
    ret = lm.run(["/path/to/no/file"])
    assert ret == []

# Generated at 2022-06-21 05:53:43.823514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:53:51.495904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms_list = ['/my/*.txt']
    variables = {'ansible_search_path':['/my/', '/your/'],
                 'ansible_search_dirs':[('/my/', '/my/path/'), ('/your/', '/your/path/')]}
    result = lookup_obj.run(terms_list, variables)
    assert result == ['/my/path/1.txt', '/my/path/2.txt', '/your/path/1.txt', '/your/path/2.txt']

# Generated at 2022-06-21 05:53:55.140519
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:53:56.957466
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None

# Generated at 2022-06-21 05:54:09.678817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    path = os.path.expanduser('~/.ansible/plugins/lookup_plugins/fileglob.py')
    lookup_module._loader = None
    lookup_module._templar = None
    assert(len(lookup_module.run(terms=['*'], variables={'ansible_user_dir': '/home/ansible', 'inventory_dir': '/home/ansible'})) > 0)
    assert(len(lookup_module.run(terms=['*'], variables={'ansible_user_dir': '/home/ansible', 'inventory_dir': '/home/ansible', 'playbook_dir': '/home/ansible'})) > 0)

# Generated at 2022-06-21 05:54:18.892151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mp = LookupModule()
    mp.find_file_in_search_path = lambda x, y, z: ""
    mp.get_basedir = lambda x: ""

    # Test find file in search path: dir is None
    ret = mp.run([None])
    assert ret == []

    # Test find file in search path: file does not exist
    ret = mp.run(["foo"])
    assert ret == []
    
    # Test find file in search path: file empty
    ret = mp.run([None])
    assert ret == []

# Generated at 2022-06-21 05:54:31.073150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    terms = [
        '*.txt'
    ]
    variables = {
        'ansible_search_path': [
            '/path/to/files'
        ]
    }
    kwargs = {

    }
    lookupModule = LookupModule()

    # Mock
    def mock_get_basedir(variables):
        return '/path/to/files'

    def mock_find_file_in_search_path(variables, dir_name, path):
        return '/path/to/files'

    def mock_glob(pth):
        return [
            '/path/to/files/file1.txt',
            '/path/to/files/file2.txt',
            '/path/to/files/file3.txt'
        ]


# Generated at 2022-06-21 05:54:38.520388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make a temporary file
    with open(os.path.join(os.path.expanduser('~'), 'test_file'), 'w') as f:
        f.write('This is a test file')

    # To store result of run method
    result = []

    # Init LookupModule object
    lp = LookupModule()
    # Set variable ansible_search_path
    lp.set_options(direct=dict(ansible_search_path='/home'))

    # Get result
    result = lp.run('test_file', variables={})

    # Delete testing file
    os.remove(os.path.join(os.path.expanduser('~'), 'test_file'))

    # Check result
    assert len(result) == 1, "Test failed"

# Generated at 2022-06-21 05:54:46.894261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    Lookup = LookupModule()
    terms = [b"/home/testuser/dyn/?/file*.txt"]
    variables = {'ansible_search_path': [b"/home/testuser/dir1", b"/home/testuser/dir2"]}
    result = Lookup.run(terms, variables)
    assert result == [b"/home/testuser/dyn/1/file1.txt"]

# Generated at 2022-06-21 05:54:49.382448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:54:50.871867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 05:54:52.893483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert getattr(LookupModule, 'run', None) is not None


# Generated at 2022-06-21 05:54:57.356250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing Results:")
    l = LookupModule()
    l.run()



# Generated at 2022-06-21 05:55:00.377632
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 05:55:04.530696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['/foo/bar'], {'ansible_search_path': ['/foo/bar']}) == ['/foo/bar']

# Generated at 2022-06-21 05:55:10.483442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    test_lookup = LookupModule()
    test_terms = ['playbook.yml', 'playbook.retry']
    test_result = test_lookup.run(test_terms)
    assert test_result == ['/home/ubuntu/ansible/playbook.yml', '/home/ubuntu/ansible/playbook.retry']

# Generated at 2022-06-21 05:55:13.241092
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print(e)

test_LookupModule()

# Generated at 2022-06-21 05:55:21.869664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import TestCase
    from tempfile import mkdtemp
    from shutil import rmtree
    import os.path

    from ansible.plugins.lookup.fileglob import LookupModule # noqa: F401

    class TestLookupModule(TestCase):

        def setUp(self):
            self.wd = mkdtemp()
            self.path = os.path.join(self.wd, 'file.txt')
            open(self.path, 'a').close()

        def tearDown(self):
            rmtree(self.wd)

        def test_run(self):
            lookup = LookupModule()
            res = lookup.run([self.path], {}, wantlist=True)
            self.assertEqual(res, [self.path])

    return TestLookupModule


# Unit

# Generated at 2022-06-21 05:55:27.262804
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/test/test1.txt', '/test/test2/test2.txt']
    variables = { 'ansible_search_path' : ['/test'] }

    lookup_plugin = LookupModule()

    result = lookup_plugin.run(terms, variables)

    assert result == ['/test/test1.txt']

# Generated at 2022-06-21 05:55:37.871877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(
        {
            '_ansible_search_path': '/ansible/test/path/',
            'ansible_search_path': '/ansible/test/path/'
        }
    )
    result = l.run(['./test_file.txt'], {'_ansible_search_path': '/a/test/path/', 'ansible_search_path': '/a/test/path/'})
    assert result == ['test_file.txt']

# Generated at 2022-06-21 05:55:44.079242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dwimmed_path = "/my/path/files/file.txt"
    mocked_path = "/my/path/files/"
    mocked_globbed = ["/my/path/files/file.txt"]

    # mock glob function to return mocked_globbed
    original_glob = glob.glob
    def mocked_glob(path):
        if path == mocked_path:
            return mocked_globbed
        return original_glob(path)

    original_isfile = os.path.isfile
    def mocked_isfile(path):
        if path == dwimmed_path:
            return True
        return original_isfile(path)

    # mock os function to return mocked_path
    original_os_path_join = os.path.join

# Generated at 2022-06-21 05:55:48.829732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.basedir = 'foo'
    l.run(['./test/a*'], dict(ansible_search_path=['/bar/baz', 'foo'])) == ['/bar/baz/./test/a.txt', 'foo/./test/a.txt']

# Generated at 2022-06-21 05:55:53.833026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #lookup_module = LookupModule()
    #lookup_module.run()
    assert True

# Generated at 2022-06-21 05:55:55.342590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:56:02.548854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing when term and term_file are different
    # and there are no results from globbing
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    unsafeproxywrapper = UnsafeProxy({'lookup_file_result':[]})
    lookup_obj = LookupModule()
    # Create a mock for the method find_file_in_search_path of ansible.plugins.lookup
    def find_file_in_search_path(self, variables, basedir, path):
        return unsafeproxywrapper.lookup_file_result
    lookup_obj.find_file_in_search_path = find_file_in_search_path
    # Create a mock for the method get_basedir of ansible.plugins.lookup

# Generated at 2022-06-21 05:56:11.369656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_get_basedir(self, variables):
        return '/some/path'
    def mock_find_file_in_search_path(self, variables, directory_list, path):
        return '/some/path'

    lookup = LookupModule()
    lookup.get_basedir = mock_get_basedir
    lookup.find_file_in_search_path = mock_find_file_in_search_path


# Generated at 2022-06-21 05:56:13.157825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:56:22.685910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    import os
    import glob
    import tempfile
    temp_dir = tempfile.gettempdir()
    file = os.path.join(temp_dir, "foo")
    file_2 = os.path.join(temp_dir, "bar")
    open(file, 'w').close()
    open(file_2, 'w').close()
    assert lu.run([os.path.join(temp_dir, "foo"), os.path.join(temp_dir, "bar")], {}, wantlist=False) == os.path.join(temp_dir, "foo") + "," + os.path.join(temp_dir, "bar")
    assert len(lu.run([os.path.join(temp_dir, "*")], {}, wantlist=True)) == 2

# Generated at 2022-06-21 05:56:24.807657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:56:26.070626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()


# Generated at 2022-06-21 05:56:28.862999
# Unit test for constructor of class LookupModule
def test_LookupModule():
    looker = LookupModule()
    assert looker

# Generated at 2022-06-21 05:56:31.521421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #os.environ["VAR"] = "test"
    assert LookupBase.run({}) == []

# Generated at 2022-06-21 05:56:36.740150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)



# Generated at 2022-06-21 05:56:43.690990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example of creating an instance of our plugin class and calling the run method
    lookup_plugin = LookupModule()

    # Example of passing in a term and getting back a list containing
    # what the method found
    results = lookup_plugin.run(["/etc/passwd"])
    assert results == ['/etc/passwd']

# Generated at 2022-06-21 05:56:48.721957
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try :
        lookup_plugin = LookupModule()
    except Exception as e:
        # if an exception occurs, it implies that the constructor is not working
        # as intended.
        print("Exception occurred : %s", str(e))
        return False
    # if no exception occured, then the constructor is working as intended.
    return True

# Generated at 2022-06-21 05:56:50.714214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None


# Generated at 2022-06-21 05:56:51.820450
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run([], None) == []

# Generated at 2022-06-21 05:57:00.680794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class args:
        basedir = ''
        files = []
        variables = {'ansible_search_path':['/etc/ansible']}
    lookup = LookupModule()
    lookup.set_options(args)
    terms = ['/my/path/*.txt', 'passwd']
    results = lookup.run(terms)
    assert type(results) == list
    assert results[0] == '/etc/ansible/my/path/*.txt'
    assert results[1] == '/etc/ansible/my/path/*.txt'

# Generated at 2022-06-21 05:57:06.203001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup = LookupModule()
    lookup._basedir = ''
    lookup._loader = None

    # Act
    result = lookup.run(['fileglob'])

    # Assert
    assert len(result) == 0 and type(result) == list


# Generated at 2022-06-21 05:57:14.340815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1, check if files found
    lookup_module = LookupModule()
    results = lookup_module.run(['/etc/ansible/hosts'], {})
    assert results == ['/etc/ansible/hosts']

    # Test 2, check if nothing found
    results = lookup_module.run(['/etc/ansible/xyz'], {})
    assert results == []

# Generated at 2022-06-21 05:57:26.885123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    # Arrange
    import os
    import sys
    import shutil
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.lookup import LookupBase
    from ansible_collections.ansible.community.plugins.modules.network.eos import eos_eapi

# Generated at 2022-06-21 05:57:32.772091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms_text = ['foo.txt', 'bar.txt']
    terms = [to_bytes(t) for t in terms_text]
    assert lookup_module.run(terms) == []

    # test_LookupModule_run() is run from test_lookup_plugins/selection_plugin.py, which is located at
    # lib/ansible/plugins/lookup/selection_plugin.py.
    # The basedir should be .../lib/ansible/plugins/lookup
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    # test_LookupModule_run() is run from test_lookup_plugins/selection_plugin.py, which

# Generated at 2022-06-21 05:57:40.495167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    os.environ['ANSIBLE_SEARCH_PATH'] ='/path'
    terms = ['test.txt']
    variables = {'ansible_search_path': '/path/files'}
    result = lookup_module.run(terms, variables)
    assert len(result) == 1
    assert result == ['/path/files/test.txt']

# Generated at 2022-06-21 05:57:48.688444
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import unittest
    import tempfile
    import shutil
    from ansible.module_utils.six import StringIO
    from ansible.utils import module_docs

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir, ignore_errors=True)

        def test_handle_directory_not_found(self):
            # Prepare test, create lookup object
            lookup_module = LookupModule()
            search_path = [self.tempdir]

            # Execute test
            result = lookup_module.run(['/path/not/found/'], dict(ansible_search_path=search_path), wantlist=True)

            # Check

# Generated at 2022-06-21 05:57:51.046711
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global lm
    lm = LookupModule()

# Generated at 2022-06-21 05:57:55.366893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    net = LookupModule()
    net.run('/etc/hosts')
    net.run('/etc/passwd')
    net.run('passwd')
    net.run('hosts')

# Generated at 2022-06-21 05:58:03.338900
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockSearchPath(object):

        def __init__(self, path):
            self.path = path

    class MockVar(object):

        def __init__(self, path):
            self.ansible_search_path = [MockSearchPath(path)]

    import ansible.plugins.loader as loader
    lm = loader.lookup_loader.get('fileglob', class_only=True)

    mock_file1 = '/tmp/file_1'
    mock_file2 = '/tmp/file_2'

    m1 = MockVar(mock_file1)
    m2 = MockVar(mock_file2)

    ret1 = lm().run(['/tmp/file1,'], variables=m1)
    assert ret1 == ['/tmp/file1']


# Generated at 2022-06-21 05:58:12.394930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    my_lookup = LookupModule()
    # create a list of files and directories to be used as terms
    terms = ['/my/path/*1.txt', '/my/path/*2.txt', '/my/path/*3.txt']
    # create a dictionary of variables to be used
    variables = {'ansible_search_path': ['/my/path/files', '/my/path']}
    # create a dictionary of kwargs to be used
    kwargs = {}
    # call the run method of LookupModule with the parameters created
    result = my_lookup.run(terms, variables, **kwargs)
    # assert that the returned result is a list of path of files that match glob pattern in the terms

# Generated at 2022-06-21 05:58:21.736396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_search_path=[to_text(os.path.expanduser('~'), errors='surrogate_or_strict'), '/etc', '/usr/share/ansible']
    variables={'ansible_search_path' : ansible_search_path}
    lookup_terms=['test_file']
    lookup_kwargs={'wantlist':True}
    test_obj=LookupModule()
    result=test_obj.run(lookup_terms,variables=variables,**lookup_kwargs)
    assert result == ['{0}/ansible/test/unit/data/lookup_plugins/fileglob/test_file'.format(os.getcwd())]

# Generated at 2022-06-21 05:58:27.938045
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/path/foo.txt', 'bar.txt']
    variables = {'ansible_search_path': ['/path']}
    lookup = LookupModule()

    assert lookup.run(terms, variables) == ['/path/foo.txt']

# Generated at 2022-06-21 05:58:37.251168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock variables
    mocked_terms    = ['myfile*', 'mydir/file*']
    mocked_variables= {'mykey': 'myval', 'ansible_search_path': ['/foo', '/bar']}
    mocked_search_path= ['/foo','/bar']

    # mocked fileglob.glob, returning two files and a directory
    mocked_glob = ['/foo/myfile1','/bar/myfile2','mydir']

    # class under test
    l = LookupModule()

    # mock glob.glob to return mocked_glob
    def my_glob(path):
        return mocked_glob
    glob.glob = my_glob

    # mock l.find_file_in_search_path to return the same directory that
    # glob.glob returned
   

# Generated at 2022-06-21 05:58:39.234491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule."""
    assert LookupModule()

# Generated at 2022-06-21 05:58:44.989869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.get_basedir(variable=None)

# Generated at 2022-06-21 05:58:54.021791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    # establish a set of valid paths to be tested
    real_path = os.path.dirname(os.path.realpath(__file__))
    basedir = os.path.realpath(os.path.join(real_path, "../../.."))
    lookup_dir_path = os.path.join(basedir, 'lib/ansible/plugins/lookup')
    plugin_dir_path = os.path.join(basedir, 'lib/ansible/plugins')

    module = LookupModule()
    # basic plugin file test
    assert module.run(["fileglob.py"], variables=dict(ansible_search_path=[lookup_dir_path, plugin_dir_path])) == [os.path.join(lookup_dir_path, "fileglob.py")]
    #

# Generated at 2022-06-21 05:59:03.453391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run() with a file and a list of paths
    lookup_module = LookupModule()
    assert ['files/foo.txt'] == lookup_module.run(['foo.txt'], dict(files='files'))
    assert ['files/foo.txt'] == lookup_module.run(['foo.txt'], dict(files='files,files2'))
    assert ['files/foo.txt'] == lookup_module.run(['foo.txt'], dict(files='files2,files'))
    assert ['files/foo.txt'] == lookup_module.run(['foo.txt'], dict(files='files2,files,files3'))
    assert ['files/foo.txt'] == lookup_module.run(['foo.txt'], dict(files='files2,files3,files'))

    # Test run() with a

# Generated at 2022-06-21 05:59:06.926614
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Exercise __init__
    lookup = LookupModule()
    assert lookup is not None, 'Failed to instantiate lookup module LookupModule'

# Generated at 2022-06-21 05:59:12.662839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy files/ directories in temp directory
    from shutil import rmtree
    from tempfile import mkdtemp
    from os.path import join as pjoin

    temp_dir = mkdtemp()
    files_dir = pjoin(temp_dir, "files")
    os.mkdir(files_dir)
    for fname in ["foo.txt", "bar.txt"]:
        os.mknod(pjoin(temp_dir, fname))
        os.symlink(pjoin(temp_dir, fname), pjoin(files_dir, fname))

    # define terms list and run it
    terms = [ pjoin("/tmp", "*.txt"), pjoin(files_dir, "*.txt") ]
    lookup_module = LookupModule()

# Generated at 2022-06-21 05:59:15.795742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # It is used to redirect stdout to a string to facilitate testing
    class Capture(object):
        def __init__(self):
            self.result = ''
        def write(self, txt):
            self.result += txt

    capture = Capture()
    terms = ["/my/path/*.txt"]
    variables = ""
    test_lookup = LookupModule()
    test_lookup.run(terms, variables, **capture)
    assert capture.result == ""

# Generated at 2022-06-21 05:59:25.330191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    loader = DataLoader()

    def get_resource_path(*args):
        return os.path.join(fixture_path, *args)

    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 05:59:26.090478
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:59:27.407544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 05:59:28.802617
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:59:36.428590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:59:45.837758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(['/etc/*'], variables={'_': '_'}, wantlist=True)

# Generated at 2022-06-21 05:59:47.325491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lo = LookupModule()
    assert True

# Generated at 2022-06-21 05:59:58.412229
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:00:02.183027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test1 = LookupModule()
    # Assert that test1 is of type LookupModule
    assert(isinstance(test1, LookupModule))


# Generated at 2022-06-21 06:00:04.977509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    result = lookupModule.run(["/home/afg/repos/*"])[0]
    assert isinstance(result, str)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:00:15.538089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    loader = DataLoader()
    lookup_instance = lookup_loader.get('fileglob', loader=loader, vault_password=VaultLib())

    ret = lookup_instance.run(['/etc/ansible/*'], {'ansible_search_path': ['/etc/ansible']})
    assert('/etc/ansible/ansible.cfg' in ret)
    assert('/etc/ansible/hosts' in ret)

# Generated at 2022-06-21 06:00:20.980338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing LookupModule')
    lookup_module = LookupModule()
    print(lookup_module.run(['']))

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:00:23.468379
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert ("LookupModule" == a.__class__.__name__)

# Generated at 2022-06-21 06:00:31.272200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run on class LookupModule"""
#
#    import unittest
#
#    class test_LookupModule_run(unittest.TestCase):
#
#        def test_run_1(self):
#            with self.assertRaises(Exception) as context:
#                try:
#                    pass
#                except Exception:
#                    self.fail('test failed')
#
#    unittest.main()

# Generated at 2022-06-21 06:00:39.534974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run is not None

# Generated at 2022-06-21 06:00:42.829301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    assert look.run(['./myfile.txt']) == []
    assert look.run(['myfile.txt']) == []

# Generated at 2022-06-21 06:00:43.593941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:00:55.184212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import tempfile
    lookup = LookupModule()
    testdir = tempfile.mkdtemp(dir='/tmp')
    try:
        testfiles = [os.path.join(testdir, f) for f in ['a.txt', 'b.txt', 'c.txt']]
        for testfile in testfiles:
            with open(testfile, 'w') as fh:
                fh.write(testfile)
        results = lookup.run(terms=["*.txt"], variables={}, wantlist=True)
        assert(set(results) == set(testfiles))
    finally:
        for testfile in testfiles:
            os.unlink(testfile)
        os.rmdir(testdir)


# Generated at 2022-06-21 06:01:01.738582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import tempfile
    from ansible.plugins.lookup.fileglob import LookupModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import StringIO

    # create dummy files
    dummy_files = ['/tmp/fileglob.txt', '/tmp/fileglob.j2', '/tmp/fileglob.tmp']
    for fname in dummy_files:
        f = open(fname, 'w')
        f.write('Test\n')
        f.close()

    # check typical usage
    lookup = LookupModule()
    ret = lookup.run(['/tmp/fileglob.*'])
    assert len(ret) == 3

# Generated at 2022-06-21 06:01:09.735848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a stub class for
    class StubVarsModule(object):
        def get(self, key):
            return {'playbook_dir':'/home/vagrant/ansible-test-playbook'}[key]

    class StubLoaderModule(object):
        def path_dwim(self, path):
            return path

    class StubTemplarModule(object):
        def template(self, template, enable_templating=True, escape_backslashes=True, convert_data=False, fail_on_undefined=True):
            return template

    lookup = LookupModule()
    lookup.set_loader(StubLoaderModule())
    lookup.set_templar(StubTemplarModule())
    path = lookup.run(terms=['files/*.py'], variables=StubVarsModule())


# Generated at 2022-06-21 06:01:10.598224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:01:18.495854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['/my/path/*.txt']
    variables = {'ansible_search_path': ['.']}

    # Create a test class
    class TestClass(object):
        def __init__(self):
            self.tmp = None

        def get_basedir(self, variables):
            return '.'

        def find_file_in_search_path(self, variables, path, dir):
            return '.'

    # Test
    tc = TestClass()
    glob.glob = lambda x: ['file1.txt', 'file2.txt']
    os.path.isfile = lambda x: True
    assert tc.run(terms, variables=variables) == ['file1.txt', 'file2.txt']

# Generated at 2022-06-21 06:01:21.152615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()
    assert isinstance(my_lookup_module, LookupModule)

# Generated at 2022-06-21 06:01:24.398647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["*.txt"], variables={'playbook_dir': "../test/lookup/playbook.yml"}) == []
    assert not LookupModule().run(["*.txt"], variables={'playbook_dir': "/home/ansible/test/"}) == []

# Generated at 2022-06-21 06:01:45.289197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_key = 'ansible.builtin.fileglob'
    search_paths = [
        '~/playbooks/files',
        '~/playbooks/vars',
        '~/playbooks/defaults',
        '~/playbooks/meta'
    ]
    stub_file_path = '/stub/path/'
    basedir = '/mocked/basedir'
    lookup_module = LookupModule()
    lookup_module.set_options(dict())
    # prepare to test
    lookup_module.get_basedir = lambda variables: basedir
    lookup_module.find_file_in_search_path = lambda variables, ds, path: stub_file_path
    lookup_module.has_plugin = lambda module_name: False

    # test: no search path

# Generated at 2022-06-21 06:01:52.974732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return_value = ['/tmp/test1.txt', '/tmp/test2.txt']
    lookup_obj = LookupModule()
    lookup_obj.get_basedir = lambda x: '/tmp'
    assert lookup_obj.run(['test*.txt']) == return_value

# Test the jinja2 filters

# Generated at 2022-06-21 06:02:05.569852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils._text import to_bytes, to_text

    ###########################################################################
    #prepare environ
    environ = {}
    environ['ANSIBLE_CONFIG']= 'test/test_utils/test.cfg'
    environ['ANSIBLE_DATA_DIR']= 'test/test_utils/data'

    ###########################################################################
    #prepare args
    args = {}
    args['_ansible_diff']= False
    args['_ansible_debug']= False
    args['_ansible_keep_remote_files']= False

# Generated at 2022-06-21 06:02:08.556491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass (LookupModule, LookupBase)
    lookupModule = LookupModule()
    assert lookupModule is not None

# Generated at 2022-06-21 06:02:16.035523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import os
    from ansible.module_utils.six import b
    from ansible.utils.display import Display
    display = Display()

    lookup_module = LookupModule()
    def write_tempfile(filename, contents):
        with open(filename, "wb") as f:
            f.write(contents)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_dir = os.path.join(tmpdir, 'testdir')
        os.mkdir(test_dir)
        file_exists = "file.txt"
        file_does_not_exist = "file_does_not_exist.txt"
        write_tempfile(os.path.join(test_dir, file_exists), b("Test file data"))

# Generated at 2022-06-21 06:02:25.622433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _is_recursive_glob_mock(globber, term_file, found_paths):
        print("globber: ", globber)
        print("term_file: ", term_file)
        print("found_paths: ", found_paths)
        fake_glob = glob.glob(os.path.join(found_paths, term_file))
        return fake_glob

    import pytest

    lookup = LookupModule()

    # Test empty options
    result = lookup.run([], {})
    assert result == [], "Result must be empty list."

    # Test empty option
    result = lookup.run([""], {})
    assert result == [], "Result must be empty list."

    # Test option not found

# Generated at 2022-06-21 06:02:38.110058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_find_file_in_search_path(fullname, basedir, inject):
        return "/etc/ansible/files"

    def mock_get_basedir(variables):
        return "/etc/ansible"

    fullname = "test.txt"
    terms = [fullname]

    # Create a mock "lookup" class
    lookupObj = LookupModule()

    # Override methods of the mock class
    lookupObj.find_file_in_search_path = mock_find_file_in_search_path
    lookupObj.get_basedir = mock_get_basedir

    # Run method run from LookupModule
    ret = lookupObj.run(terms)

    # Test if the path was properly returned
    assert ret == ["/etc/ansible/files/test.txt"]

# Generated at 2022-06-21 06:02:47.089301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['test_terms']
    variables = {}
    lookupmodule = LookupModule()
    path = 'test_path'
    lookupmodule.find_file_in_search_path = lambda variables, d, p: path
    lookupmodule.get_basedir = lambda variables: path
    os.path.isfile = lambda path: True
    glob.glob = lambda path: [path]

    # Test
    ret = lookupmodule.run(terms, variables)

    # Assert
    assert ret[0] == path

# Generated at 2022-06-21 06:02:48.373752
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:02:57.359218
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a list of parameters to pass to the run method of class LookupModule
    terms = ['file1', 'file2']
    variables = {
        'ansible_search_path': ['/_ansible_/path', '/_ansible_/path1']
    }

    # Test 1: Test for scenario where the file is present at a location
    # Create mock file and directory
    os.makedirs('/_ansible_/path/dir')
    os.makedirs('/_ansible_/path/dir1')
    os.makedirs('/_ansible_/path1/dir')
    os.makedirs('/_ansible_/path1/dir1')
    open('/_ansible_/path/dir/file1', 'a').close()