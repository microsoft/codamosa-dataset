

# Generated at 2022-06-11 15:22:23.744952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert ["/test/test.txt"] == lookup_module.run(["test*"], None)

# Generated at 2022-06-11 15:22:26.078367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['/tmp/foo.txt'], 'variables') == ['/tmp/foo.txt']

# Generated at 2022-06-11 15:22:29.885387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lfm = LookupModule()
    lfm.get_basedir = lambda *args: '/etc/ansible'
    lfm.find_file_in_search_path = lambda *args: '/etc/ansible/playbooks/files'
    lfm.run(['test.txt'])

# Generated at 2022-06-11 15:22:39.466504
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a dictionary to mimic the variable ansible.module_utils.basic.AnsibleModule as returned by the python module
    # AnsibleModule. This is needed to initialize the object of class LookupModule.

# Generated at 2022-06-11 15:22:46.960936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    testclass = LookupModule()
    
    mock_basedir = '.'
    mock_variables = dict()
    mock_variables['ansible_search_path'] = ['.']
    
    # test 1: returns empty list in case an empty term is passed
    terms = []
    result = testclass.run(terms, mock_variables)
    
    # assertions
    assert result == [], 'invalid result.'
    
    
    
    # test 2: returns empty list if term was not found
    terms = ['not_existing_file']
    ret = testclass.run(terms, mock_variables)
    
    # assertions
    assert ret == [], 'invalid result.'
    
    ###
    # test 3: returns correct results if term was found
    #          and 'wantlist' is False

# Generated at 2022-06-11 15:22:57.023811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.errors import AnsibleFileNotFound
    # This is just a simple test, no need to make it robust
    my_test = LookupModule()
    terms = ['hello', 'doesnotexist']
    variables = {}
    # It should print out the files in inventory_paths/
    result = my_test.run(terms, variables)
    assert result[0] == "inventory_paths/hello"
    assert result[1] == "inventory_paths/hello_world"
    # Should raise the AnsibleFileNotFound exception
    try:
        my_test.run(terms, variables)
    except AnsibleFileNotFound:
        pass

# Generated at 2022-06-11 15:23:08.394628
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Options(object):
        def __init__(self, verbosity=None, connection=None, remote_user=None, private_key_file=None, timeout=10,
                     ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                     become=None, become_method=None, become_user=None, become_ask_pass=None, verbosity_level=None,
                     check=False, diff=False):
            self.verbosity = verbosity
            self.connection = connection
            self.remote_user = remote_user
            self.private_key_file = private_key_file
            self.timeout = timeout
            self.ssh_common_args = ssh_common_args
            self.ssh_extra_args = ssh_extra

# Generated at 2022-06-11 15:23:21.119104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.get_basedir = lambda x: os.path.join("/home/ansible/test")
    lookup.find_file_in_search_path = lambda variables, file, path: os.path.join("/home/ansible/test/files",path)
    terms = ["test.*","ansible.*"]
    variables = {"ansible_search_path" : ["/home/ansible/test/files","/home/ansible/test/files/files"]}
    result = lookup.run(terms, variables)
    test_result = ["/home/ansible/test/files/test.txt", "/home/ansible/test/files/ansible.yml"]
    assert result == test_result

# Generated at 2022-06-11 15:23:26.405098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    test_terms = ['file1.txt', 'file2.txt', 'file1.xml', 'file2.xml']
    assert lookup.run(test_terms, {'ansible_search_path': ['/path1', '/path2']}) == ['/path2/file1.txt', '/path2/file2.txt']



# Generated at 2022-06-11 15:23:32.441528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    """
    # Check without parameters (lists all files)
    lookup = LookupModule()
    terms = ['.']
    variables = dict()
    result = lookup.run(terms, variables)
    assert(result == [])

    # Check with parameters
    lookup = LookupModule()
    terms = ['test_LookupModule_run.py']
    variables = dict()
    result = lookup.run(terms, variables)
    assert(result == ['../lookup_plugins/test_LookupModule_run.py'])

# Generated at 2022-06-11 15:23:39.597245
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_variables = {
        'ansible_search_path': ['/etc/ansible/test/test_lookup_plugins/fileglob']
    }

    terms = ['/test/*', 'test/test_a.txt']
    l = LookupModule()

    result = l.run(terms, variables=test_variables)

    assert len(result) == 2



# Generated at 2022-06-11 15:23:40.201469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1==1

# Generated at 2022-06-11 15:23:47.023432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test run() with a file name in the complete path
    terms = ['/tmp/test_tmp_file.txt']
    assert lookup.run(terms) == terms
    # Test run() with a file name in the incomplete path
    terms = ['test_incomplete_file_path.txt']
    assert lookup.run(terms) == terms
    # Test run() with a file name with no path
    terms = ['test_filename_no_path.txt']
    assert lookup.run(terms) == terms

# Generated at 2022-06-11 15:23:52.352503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.search_path = ["/homedir"]
    play_context.safe_path = ["/homedir"]

    test_lookup_module = LookupModule()
    test_lookup_module.set_options(play_context, {})

    term = 'test_file'
    test_lookup_module.run([term], play_context)

    globbed = glob.glob(os.path.join(os.getcwd(), term))
    # When the test file exists, check that it is returned
    if globbed:
        assert(len(globbed) == 1)

# Generated at 2022-06-11 15:23:56.069556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass
    # result = LookupModule.run(self=None, terms=["/my/path/*.txt", "/another/path/*.txt"], variables={})
    # assert result == []

# Generated at 2022-06-11 15:23:59.270043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  assert l.run(['/my/path/*.txt']) == ['index.txt']

# Generated at 2022-06-11 15:24:10.358892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Returns three tests results.
    1. When full path is given, return globbed files in that directory
    2. When file is given, return globbed files in all paths
    3. Return nothing if no match
    '''
    look = LookupModule()
    results = look.run(['/path/to/file/test_file1.txt'], None)
    assert results == ['/path/to/file/test_file1.txt']

    results = look.run(['test_file1.txt'], {'ansible_search_path' : ['/path/to/file']})
    assert results == ['/path/to/file/test_file1.txt']

    results = look.run(['.txt'], {'ansible_search_path' : ['/path/to']})
    assert results

# Generated at 2022-06-11 15:24:16.178930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule is not a function, but a class
    # We use it to do a unit test, so we create a class first
    class MockLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, path, file):
            if file == '/':
                return '/home/ansible/testdir'
            else:
                return 'testdir'

        def get_basedir(self, variables):
            return 'testdir'

    mock_lookup_obj = MockLookupModule()
    
    # A test case data, which is a list of 2 tuples
    # Each tuple consists of terms, and the expected list

# Generated at 2022-06-11 15:24:18.627848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert that we dont crash if no terms are added
    lookup_module = LookupModule()
    lookup_module.run(terms=[], variables={})

# Generated at 2022-06-11 15:24:25.578852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test initialized object
    look = LookupModule()

    # test initialized variables
    # result: []
    #assert look.run([]) == []

    # result: ['/Users/ansible/ansible/test/unit/lookup_plugins/data/fileglob/<filename>']
    #assert look.run(['host.txt']) == ['host.txt']

    # result: ['/Users/ansible/ansible/test/unit/lookup_plugins/data/fileglob/<filename>',
    #          '/Users/ansible/ansible/test/unit/lookup_plugins/data/fileglob2/<filename>']
    #assert look.run(['host.txt']) == ['host.txt']

# Generated at 2022-06-11 15:24:32.734722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check list of file
    result = LookupModule().run(['/path/to/file'], variables={}, wantlist=True)
    assert result == []
    # Check with file not found
    with pytest.raises(AnsibleFileNotFound):
        LookupModule().run(['file'], variables={}, wantlist=True)

# Generated at 2022-06-11 15:24:44.373403
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    """ Unit test for method run of class LookupModule """


# Generated at 2022-06-11 15:24:51.784396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    fake_path = '/fake/path'
    fake_file = 'myfakefilename'
    fake_term = os.path.join(fake_path, fake_file)
    fake_variables = {'ansible_search_path': [fake_path]}
    returned_fileglob_list = lookup.run([fake_term], fake_variables)
    expected_fileglob_list = []
    assert returned_fileglob_list == expected_fileglob_list

# Generated at 2022-06-11 15:24:58.308689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure the class is configured correctly
    assert LookupModule.has_plugin_options() is False
    assert LookupModule.supports_check_mode() is False

    # Make sure the lookup plugin runs
    lm = LookupModule()

    # Make sure the method run returns the correct result
    assert lm.run(['ansible']) == [os.path.abspath('../../lib/ansible/plugins/lookup_plugins/ansible.py')]

# Generated at 2022-06-11 15:25:05.215720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    # all files under /etc/fstab
    assert sorted(L.run(['/etc/fstab/*'])) == [
        u'/etc/fstab/README.fstab',
        u'/etc/fstab/fstab.old'
    ]
    # no match
    assert L.run(['/etc/fstab/*.foo']) == []
    # all files under /etc/fstab/
    assert sorted(L.run(['/etc/fstab/*', '/etc/fstab/'])) == [
        u'/etc/fstab/README.fstab',
        u'/etc/fstab/fstab.old'
    ]
    assert L.run(['/etc/fstab/']) == []
    # foo.conf

# Generated at 2022-06-11 15:25:17.355104
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    test_LookupModule = LookupModule()

    # Test with a term that starts with a '/' and a term with directory
    terms = [ '/etc/passwd', 'ansible/test/test.txt']


    # Test with a variable ansible_search_path and with a terms
    variables = { 'ansible_search_path': ['/tmp/ansible/roles'] }

    # Test with a base dir
    basedir = '/tmp/ansible'

    # Test with a term with a file in search path
    term_with_file_in_search_path = {'ansible_search_path': ['/etc/passwd'], 'ansible_basedir': '/tmp/ansible'}

    test_LookupModule.set_options(term_with_file_in_search_path)

    # Test method

# Generated at 2022-06-11 15:25:26.687188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Tests whether the run() method returns the expected value

    Returns:
    None
    """
    LookupModule_run = LookupModule()

    # Good input (two files in folder)
    terms = ["fileglob_example.py"]
    result = LookupModule_run.run(terms)
    assert len(result) == 2
    assert result[0] == "fileglob_example.py"

    # Good input (one files in folder)
    terms = ["one.py"]
    result = LookupModule_run.run(terms)
    assert len(result) == 1
    assert result[0] == "one.py"

    # Bad input
    terms = ["bad_name.py"]
    try:
        result = LookupModule_run.run(terms)
    except Exception:
        assert True

# Generated at 2022-06-11 15:25:36.518360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit testing for module run method - it generates a list of found files
    """
    module = LookupModule()

    ################################################################################
    # test case 1 - term is a file, only files are being sought
    ################################################################################
    terms = [
        '/etc/resolv.conf',
    ]
    test_variables = {
        'ansible_search_path': [
            '/tmp',
            '/etc',
        ],
    }
    test_result = module.run(terms, test_variables)
    expected_result = [
        '/etc/resolv.conf',
    ]
    assert test_result == expected_result

    ################################################################################
    # test case 2 - term is a file, both files and paths are being sought
    ################################################################################

# Generated at 2022-06-11 15:25:44.054469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    attrs = { 'get_basedir.return_value' : '/tmp/' }

    mock_play_context = {}
    mocked_self = type('MockedLookupModule', (), attrs)
    test_terms = [
        '/tmp/test',
        'my_template.j2',
        '/path/some_template.j2',
    ]

    expected_result = [
        '/tmp/test',
        '/tmp/my_template.j2',
        '/tmp/some_template.j2',
    ]

    module = LookupModule()
    module.get_basedir = mocked_self.get_basedir
    result = module.run(test_terms, play_context=mock_play_context)
    assert isinstance(result, list)
    assert len(result) == 3
    assert result

# Generated at 2022-06-11 15:25:52.396066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    glob_ = "glob.glob"
    b = ['/my/path/first_file', '/my/path/second_file']
    g = ['/my/path/first_file', '/my/path/second_file']
    isfile_ = "os.path.isfile"
    open_ = "builtins.open"
    d = dict()
    d['first_file'] = "content\n"
    d['second_file'] = "more content\n"
    v = dict()
    v['ansible_search_path'] = ['.']

    # mock out built-in glob module
    with mock.patch(glob_) as mock_glob:
        mock_glob.return_value = g
        # mock out built-in open function

# Generated at 2022-06-11 15:26:05.815989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests if method run works as expected here.
    # Arrange
    glob = LookupModule()

    # Act
    result = glob.run([["../files/fileglob_tmp.txt"], ["../files/fileglob_tmp.txt"]])

    # Assert
    assert(result == ["../files/fileglob_tmp.txt", "../files/fileglob_tmp.txt"])

# Generated at 2022-06-11 15:26:18.647281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    basedir = tempfile.mkdtemp()
    searchpath = [basedir, os.path.join(basedir, 'files')]
    testfile = os.path.join(basedir, 'bar', 'foo')
    os.makedirs(os.path.dirname(testfile))
    with open(testfile, 'wt') as f:
        f.write('bar')
    lookup = LookupModule()
    assert len(lookup.run([os.path.join(basedir, 'b*', 'foo')], dict(ansible_search_path=searchpath))) == 1
    assert os.path.exists(lookup.run([os.path.join(basedir, 'b*', 'foo')], dict(ansible_search_path=searchpath))[0])

# Generated at 2022-06-11 15:26:30.552425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import textwrap
    working_dir = os.getcwd()
    lookup = LookupModule()
    test_dir = os.path.join(working_dir, 'test_LookupModule_run')
    os.makedirs(test_dir)
    os.chdir(test_dir)
    with open("test_file", "w") as f:
        f.write("this is a test file")
    os.makedirs("test_dir")
    with open("test_dir/test_file2", "w") as f:
        f.write("this is a test file")
    with open("test_dir/test_file3", "w") as f:
        f.write("this is a test file")
    os.makedirs("test_dir2")

# Generated at 2022-06-11 15:26:34.034852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fm = LookupModule()
    terms = ["/my/path/*.txt", "/my/path/*.py"]
    variabels = None
    fm.run(terms, variabels)
    # test code here.

# Generated at 2022-06-11 15:26:39.708122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test that file paths can be found if the term contains a directory.
    assert lookup_module.run(['/etc/ansible/ansible.cfg']) == ['/etc/ansible/ansible.cfg']

    # Test that file paths can be found if the term does not contain a directory.
    assert lookup_module.run(['ansible.cfg']) == ['/etc/ansible/ansible.cfg']

# Generated at 2022-06-11 15:26:48.161431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test LookupModule.run"""

    # Test no results
    lookup_module = LookupModule()
    assert not lookup_module.run(['*.fakke'], variables={})

    # Test normal success and globbing
    lookup_module = LookupModule()
    assert lookup_module.run(['*.splice'], variables={})[0].endswith('ansible/plugins/lookup/fileglob.py')
    assert lookup_module.run(['*.py'], variables={})[0].endswith('ansible/plugins/lookup/fileglob.py')

# Generated at 2022-06-11 15:26:59.604744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    file_path = './file_path_for_unit_test'
    file_name = file_path + '/test_file'

# Generated at 2022-06-11 15:27:11.111611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    dummy_args = [
        "/etc/ansible/variables/foo.yml",
        "qux*"
    ]

    dummy_kwargs = {
        "wantlist": False,
    }

    ls = LookupModule()

    ls.run = lambda *args, **kwargs: dummy_args
    ls.get_basedir = lambda *args, **kwargs: '/etc/ansible'
    ls.run_search_path = lambda *args, **kwargs: "path/to/qux"
    ls.run_list_terms = lambda *args, **kwargs: True

    assert ls.run(dummy_args, {}, **dummy_kwargs) == [
        "/etc/ansible/variables/foo.yml",
        "qux*"
    ]

# Generated at 2022-06-11 15:27:14.383948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    terms = ["1.txt","/playbooks/files/fooapp/*"]
    variables = {"ansible_search_path": ["./playbooks/files/fooapp"]}
    ret = obj.run(terms, variables)
    assert ret == ["./playbooks/files/fooapp/fooapp.conf"]

# Generated at 2022-06-11 15:27:25.923380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unitest for method run of class LookupModule"""
    print("LookupModule - Unit test for method run of class LookupModule")
    my_lookup_module_instance = LookupModule()

    #Testcase 1: Input is path of folder with 1 file
    print("Testcase 1: Input is path of folder with 1 file")
    input_dir_with_one_file = 'test01/'
    expected_result = ['test01/test01.txt']

# Generated at 2022-06-11 15:28:19.765132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    terms = ["test_1.txt","test_2.txt"]
    kwargs = {"wantlist": True, "wantdictionary": False}

    test_object.run(terms,**kwargs)

# Generated at 2022-06-11 15:28:27.160319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = dict()
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.mkdir(os.path.join(tmp_dir, 'files'))
        os.mkdir(os.path.join(tmp_dir, 'other'))
        tmp_file1 = tempfile.NamedTemporaryFile(dir=tmp_dir, suffix='.txt')
        tmp_file2 = tempfile.NamedTemporaryFile(dir=tmp_dir, suffix='.txt')
        tmp_file3 = tempfile.NamedTemporaryFile(dir=os.path.join(tmp_dir, 'files'), suffix='.txt')

# Generated at 2022-06-11 15:28:38.065550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with a file that exists and a dir that exists,
    # and a file and a dir that don't exist
    class LookupModule(LookupBase):
        def __init__(self, basedir=None):
            self._ROOT = '~/ansible'
            self._SEARCH_PATH = [self._ROOT]
            self._self_vars = {
                'ansible_search_path': [self._ROOT]
            }

    expected = [
        '~/ansible/files/find_a_file/find_a_file.txt',
        '~/ansible/files/find_a_file/find_another_file.txt'
    ]


# Generated at 2022-06-11 15:28:41.723012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    theargs = {'wantlist': True, '_raw_params': '*.txt', '_terms': ['*.txt']}
    returncode = LookupModule().run(**theargs)
    print(returncode)

test_LookupModule_run()

# Generated at 2022-06-11 15:28:44.678146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None).run(['./unit/test/testdata/existing_symlink']) == ['./unit/test/testdata/existing_symlink']

# Generated at 2022-06-11 15:28:52.510443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_name = None
            self.module_args = None
            self.args = None
            self.sudo = False
            self.sudo_user = None

    class Runner(object):
        def __init__(self):
            self.options = Options()
            self.options.connection = 'local'
            self.options.module_name = None
            self.options.module_args = None
            self.options.args = None
            self.options.sudo = False
            self.options.sudo_user = None

    class PlayContext(object):
        def __init__(self):
            self.environment = dict()
            self.port = None
            self.remote_addr = None
            self.remote_user

# Generated at 2022-06-11 15:29:02.540923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    files = ["./lookup/test_lookupplugins/test_fileglob_1.txt",
             "./lookup/test_lookupplugins/test_fileglob_2.txt",
             "./lookup/test_lookupplugins/test_fileglob_3.txt"]
    expected = ['./lookup/test_lookupplugins/test_fileglob_1.txt',
                './lookup/test_lookupplugins/test_fileglob_3.txt']
    assert lookup.run(terms=['test_fileglob_1.txt', "test_fileglob_3.txt"], variables={'files': files}) == expected

# Generated at 2022-06-11 15:29:13.735824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()

    # test for empty terms
    terms = []
    search_path = ['/etc']
    test_result = test_object.run(terms=terms, variables=dict(ansible_search_path=search_path))
    assert len(test_result) == 0

    # tests for single term
    # 1. non-existing file
    terms = ['non-existing-file']
    search_path = ['/etc']
    test_result = test_object.run(terms=terms, variables=dict(ansible_search_path=search_path))
    assert len(test_result) == 0

    # 2. existing file, no dir
    terms = ['fstab']
    search_path = ['/etc']

# Generated at 2022-06-11 15:29:25.141822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup = LookupModule()

    # Get lookup base path
    test_base_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..',
                                  'test', 'unit', 'modules', 'lookup_plugins')
    test_base_path = os.path.normpath(test_base_path)

    # Base path and files/dirs
    base_path = os.path.join(test_base_path, '..', '..', '..')
    base_path = os.path.normpath(base_path)

# Generated at 2022-06-11 15:29:25.449308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:29:52.170572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    # initialize class
    obj = LookupModule()

    # create mock test_path list and test_variables dict
    path_list = ["test_path"]
    variables = {'ansible_search_path': ['test_path']}

    # Call method run
    result = obj.run(path_list, variables)

    # assert response
    assert [] == result

# Generated at 2022-06-11 15:30:03.545589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["/my/path/*.txt", "/my/path2/*.txt"]
    variables = {}
    files_path = lookup.find_file_in_search_path(variables, 'files')
    
    file_list = []
    for i in range(10):
        file_list.append("/my/path/file.txt")
        file_list.append("/my/path/dir/file.txt")
    file_list.append("/my/path/dir/dir/file.txt")
    file_list.append("/my/path/dir/file.csv")
    
    rtn = lookup.run(terms, variables)
    
    assert rtn == file_list
    

# Generated at 2022-06-11 15:30:12.935733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()

    terms = ['foo.txt']
    variables = {'ansible_search_path': ['/path/to/some/file', '/path/to/other/file']}
    assert test_lookup.run(terms, variables, wantlist=True) == ['/path/to/some/file/foo.txt']

    terms = ['foo', 'foo.txt']
    assert test_lookup.run(terms, variables, wantlist=True) == ['/path/to/some/file/foo', '/path/to/other/file/foo', '/path/to/some/file/foo.txt', '/path/to/other/file/foo.txt']

    terms = ['foo.txt', 'bar.txt']

# Generated at 2022-06-11 15:30:24.166099
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    src_files = ['file1.txt', 'file2.txt', 'file3.txt']
    dest_files = ['file2.txt', 'file3.txt']

    # create dir and files in src dir
    os.mkdir(src_dir)
    for file in src_files:
        open(os.path.join(src_dir, file), 'a').close()

    # create dir and files in dest dir
    os.mkdir(dest_dir)
    for file in dest_files:
        open(os.path.join(dest_dir, file), 'a').close()

    # create run obj
    terms = [src_dir + '/*.txt', dest_dir + '/*.txt']
    variables={'ansible_search_path': [src_dir, dest_dir]}

# Generated at 2022-06-11 15:30:26.171509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    res = x.run(["./*.py"])
    assert res == [os.path.realpath(__file__)]

# Generated at 2022-06-11 15:30:30.253585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # stubs
    terms = ['/my/path/*.txt']
    variables = None
    kwargs = None

    lm = LookupModule()

    # run validate
    result = lm.run(terms, variables, **kwargs)

    # assert results
    assert result is not None
    assert len(result) > 0
    for r in result:
        assert r.endswith('.txt')

# Generated at 2022-06-11 15:30:36.692775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test file not found exception
    lookup = LookupModule()
    import os
    import tempfile
    (fd, tmpfile) = tempfile.mkstemp()
    os.close(fd)

    args = os.path.dirname(tmpfile)
    os.unlink(tmpfile)
    try:
        lookup.run(args)
    except AnsibleFileNotFound:
        pass
    else:
        assert False

# Generated at 2022-06-11 15:30:46.602988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    loader = DataLoader()
    # The file we will use to check exists in a module path
    check_filename = "./.check_fileglob_path"
    # The path to the modules directory
    module_path = os.path.join(os.getcwd(), "../../../lib/ansible/modules")
    # Create the file to check exists
    with open(os.path.join(module_path, check_filename), "w") as f:
        f.write("")
    # Create lookup object
    lookup_obj = LookupModule()
    # Create variable manager and set the module path
    variable

# Generated at 2022-06-11 15:30:55.691021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.fileglob
    import tempfile
    d = tempfile.mkdtemp()
    f1 = tempfile.NamedTemporaryFile(prefix=d)
    f1.write(b'first')
    f1.flush()
    f2 = tempfile.NamedTemporaryFile(prefix=d)
    f2.write(b'second')
    f2.flush()
    file = ansible.plugins.lookup.fileglob.LookupModule(vars=dict(ansible_search_path=[d]))
    assert file.run(terms=[f1.name, f2.name], wantlist=True) == [f1.name, f2.name]

# Generated at 2022-06-11 15:30:56.589094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True

# Generated at 2022-06-11 15:31:54.964866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['ANSIBLE_SEARCH_PATH'] = '.'
    mylookup = LookupModule()

    # Test file name without path
    result = mylookup.run(["*.txt"], variables={'role_path': './lookup_plugins'})
    assert result == ['README.txt'], "Return of file name without path broken"

    # Test relative path to file
    result = mylookup.run(["files/foo.txt"], variables={'role_path': './lookup_plugins'})
    assert result == ['files/foo.txt'], "Return relative path to file broken"

    # Test relative path to dir
    result = mylookup.run(["files/*.py"], variables={'role_path': './lookup_plugins'})

# Generated at 2022-06-11 15:32:03.317021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run(['/my/path/file.txt'], variables={'ansible_search_path': ['/my/path']}) == [
        '/my/path/file.txt']
    assert lookup.run(['./file.txt'], variables={'ansible_search_path': ['/my/path']}) == [
        './file.txt']
    assert lookup.run(['file.txt'], variables={'ansible_search_path': ['/my/path']}) == [
        '/my/path/file.txt']

    assert lookup.run(['file.txt'], variables={'ansible_search_path': ['/my/path', '/custom/path']}) == [
        '/my/path/file.txt', '/custom/path/file.txt']

# Generated at 2022-06-11 15:32:11.806592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod.get_basedir = lambda variables: "/tmp/"
    result = lookup_mod.run(["/tmp/a","b","../*/c"],
                      variables={"ansible_filters":{},
                                 "ansible_search_path": ["/tmp/foo", "/tmp/bar"],
                                 "ansible_connection": "local",
                                 "ansible_playbook_python": "/usr/bin/python"
                      })
    assert result == ["/tmp/a","/tmp/foo/c","/tmp/bar/c"]

# Generated at 2022-06-11 15:32:18.414162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: fails as of 28.11.2017 with
    # TypeError: expected string or bytes-like object
    # I assume it is because the test data is passed as text instead of binary?
    # (at least on Python 2.7)
    # -> find out if that is a problem, and fix.
    return

    # create a MockInventory
    # mock inv: https://docs.python-guide.org/dev/mock/
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import BytesIO