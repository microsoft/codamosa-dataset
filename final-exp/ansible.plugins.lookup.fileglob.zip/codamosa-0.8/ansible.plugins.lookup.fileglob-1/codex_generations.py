

# Generated at 2022-06-11 15:22:28.253453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mm = LookupModule()
    variables = {'test_path': 'mytest'}
    terms = ['/my/path/*.txt', '*.py', '*.cpp']
    results = mm.run(terms, variables=variables)
    #assert results == ['test/test_lookup_fileglob.py', 'src/*.cpp']

# Generated at 2022-06-11 15:22:38.418463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.plugins.lookup.fileglob import LookupModule

    paths = ['library', 'lookup_plugins', 'fileglob.py']
    # Make a dummy inventory to pass as self.inventory
    class DummyInventory(object):
        def __init__(self):
            self.basedir = os.path.join('/', *paths[:-1])
            self.hosts = {
                'host1': {
                    'vars': {},
                },
            }

    lookup = LookupModule()
    lookup.inventory = DummyInventory()

# Generated at 2022-06-11 15:22:46.331218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test without directory
    term = "test.txt"
    basedir = os.getcwd()
    paths = [basedir]
    variables = {
        'ansible_search_path': paths,
    }
    with open("./files/test.txt", "w") as f:
        f.write("test")
    assert LookupModule().run([term], variables) == [os.path.join(basedir, "files", "test.txt")]

    # test with directory
    term = "files/test.txt"
    assert LookupModule().run([term], variables) == [os.path.join(basedir, "files", "test.txt")]
    term = "./files/test.txt"

# Generated at 2022-06-11 15:22:53.650103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup = LookupModule()
    basedir = 'my/basedir'
    mylookup.set_basedir(basedir)
    terms = ['/a/b/c/d.txt']
    ret = mylookup.run(terms)
    assert ret == [basedir + '/a/b/c/d.txt']

    terms = ['d.txt']
    ret = mylookup.run(terms)
    assert ret == [basedir + '/d.txt']

# Generated at 2022-06-11 15:23:03.021759
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock variable object
    class variable_manager(object):
        def __init__(self):
            self.paths = ["/etc"]

        def get_vars(self, loader=None, play=None, task=None, include_hostvars=True):
            return {
                "ansible_search_path": self.paths
            }

    from ansible.vars import VariableManager
    var = variable_manager()
    var_mgr = VariableManager()
    var_mgr._vars = var.get_vars(include_hostvars=False)

    # create a mock loader object
    class loader_obj(object):
        def __init__(self):
            self.path = "/path/to/playbooks"

    loader = loader_obj()

    # create a mock inventory object
   

# Generated at 2022-06-11 15:23:08.197795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['/usr/share/ansible/test/data/test_lookup_fileglob/dummy.txt']
    result = module.run(terms)
    print("result: ", result)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:23:21.813851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    # mocks
    # TODO: improve this, because there are more functions in LookupModule that were not mocked
    lookup_base_initialize_mock = mock.patch.object(LookupBase, '__init__', return_value = None).start()
    lookup_base_get_basedir_mock = mock.patch.object(LookupBase, 'get_basedir', return_value='/not/a/real/path').start()
    lookup_base_find_file_in_search_path_mock = mock.patch.object(LookupBase, 'find_file_in_search_path', return_value='/not/a/real/path').start()
    # Python glob mock does not work, this one is from the third party library http://labix.org/mock
    glob

# Generated at 2022-06-11 15:23:31.326969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results1 = ['/my/path/foo.txt', '/my/path/bar.txt']
    results2 = ['/playbooks/files/fooapp/foo1', '/playbooks/files/fooapp/foo2']
    results3 = ['/my/path/baz.txt', '/my/path/bar.txt']
    paths = ['/my/path', '/playbooks/files/fooapp', '/my/path']
    terms1 = ['/my/path/*.txt']
    terms2 = ['/playbooks/files/fooapp/*']
    terms3 = ['*.txt']

    lookup_mock1 = LookupModule()
    lookup_mock1.set_options({'_ansible_search_path': paths})
    assert lookup_mock1.run(terms1) == results1

    lookup_mock

# Generated at 2022-06-11 15:23:34.985521
# Unit test for method run of class LookupModule
def test_LookupModule_run():

   # given
   test_lookup = LookupModule()
   test_terms = []

   # when
   result = test_lookup.run(test_terms)

   # then
   assert result == []



# Generated at 2022-06-11 15:23:43.313270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    module = LookupModule()
    terms = ['tests/fixtures/test_fileglob/dummy1.txt', 'tests/fixtures/test_fileglob/dummy2.txt']
    # Act
    actual_results = module.run(terms=terms)
    # Assert
    assert 'tests/fixtures/test_fileglob/dummy1.txt' in actual_results
    assert 'tests/fixtures/test_fileglob/dummy2.txt' in actual_results

# Generated at 2022-06-11 15:23:46.326699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-11 15:23:57.720322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile

    # Empty file
    tmp_file = tempfile.NamedTemporaryFile()
    test_list = [tmp_file.name]

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(test_list)

    assert result == [tmp_file.name]

    # Test with a dir
    tmp_dir = tempfile.mkdtemp()
    tmp_file_dir = tempfile.NamedTemporaryFile(dir=tmp_dir)

    test_list = [os.path.join(tmp_dir, '*')]

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(test_list)

    assert result == [os.path.join(tmp_dir, tmp_file_dir.name)]


# Generated at 2022-06-11 15:24:09.224463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["/home/steve/test.txt"],{"inventory_dir": "/home/steve/inventory"}) == ['/home/steve/test.txt']
    assert module.run(["test.txt"],{"inventory_dir": "/home/steve/inventory","ansible_search_path":["/home/steve/my/search/path"]}) == ['/home/steve/my/search/path/test.txt','/home/steve/my/search/path/files/test.txt']
    assert module.run(["/home/steve/does/not/exist.txt"],{"inventory_dir": "/home/steve/inventory"}) == []

# Generated at 2022-06-11 15:24:12.676529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lu = LookupModule()
  terms = 'build/fileglob_*.txt'
  result = lu.run(terms, variables=None)
  print(result)
  assert len(result) == 5

# Generated at 2022-06-11 15:24:21.951829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple

    # Create a mock set of variables
    VariableManager = namedtuple('VariableManager', ['hostvars'])
    SCOPE = ['hostvars']
    HOSTVARS = dict(
        ansible_search_path=['/home/someuser/whatever', '/home/someuser/another'],
    )
    variables = VariableManager(hostvars=HOSTVARS)

    # Create a mock non-existent file, then test that it doesn't exist
    test_file = '/home/someuser/whatever/hosts.txt'
    assert not os.path.isfile(test_file)

    # Create a mock set of files

# Generated at 2022-06-11 15:24:24.597795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(['*.txt'], {}, wantlist=True)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:24:28.488280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms=['*'],
                            wantlist=True) == ['../../ansible/plugins/lookup/fileglob.py',
                                               '../../ansible/plugins/lookup/fileglob.pyc']

# Generated at 2022-06-11 15:24:32.733567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = FakeLoader()
    lookup_module.set_options({'_terms': ['/path/file.txt']})
    result = lookup_module.run(['/path/file.txt'])
    assert result == ['/path/file.txt']


# Generated at 2022-06-11 15:24:44.374292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    terms = ['*.j2']
    variables = {'ansible_search_path': ['var/lib/awx/']}
    searchpaths = ['files', 'roles/example_role/files']
    l = LookupModule()
    l.run = lambda *args, **kwargs: None
    l.find_file_in_search_path = lambda *args, **kwargs: [x for x in searchpaths
                                                          if 'files' in x][0]
    l.get_basedir = lambda *args, **kwargs: 'roles/example_role'
    l.glob = builtins.glob

    # test joined by commas

# Generated at 2022-06-11 15:24:51.340003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check for the correct output for the given inputs
    lm = LookupModule()
    # Check for the output of fileglob if the file exists
    assert lm.run(["ansible/plugins/lookup/fileglob.py"]) == ['ansible/plugins/lookup/fileglob.py']
    # Check for the output of fileglob if the file does not exists
    assert lm.run(["fileglob_test1.py"]) == []

# Generated at 2022-06-11 15:24:55.314149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run == LookupModule.run
    LookupModule.run = lambda self, terms, variables=None, **kwargs: terms
    assert LookupModule().run('foo') == 'foo'

# Generated at 2022-06-11 15:24:56.819601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['foo.txt'], dict()) == []

# Generated at 2022-06-11 15:25:00.806040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path = os.path.dirname(os.path.abspath(__file__))
    lookup = LookupModule()
    ret = lookup.run([path])
    assert(ret)

    # use a non-existant path
    ret = lookup.run(['/non-existant'])
    assert(ret == [])

# Generated at 2022-06-11 15:25:05.042666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(None,['test*.txt'],variables={
        'ansible_search_path': ['/tmp'],
        'ansible_connection': 'local',
        'ansible_playbook_python': '/usr/bin/python'
    }) == ['/tmp/test.txt']

# Generated at 2022-06-11 15:25:17.246100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import shutil
    import os
    import sys
    import glob


# Generated at 2022-06-11 15:25:26.657004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create the lookup to be tested
    test_lookup = LookupModule()

    # create the test variables
    test_variables = {}
    test_variables['ansible_search_path'] = {}
    test_variables['ansible_search_path']['1'] ='/home/user1'
    test_variables['ansible_search_path']['2'] ='/home/user2'

    # create the test terms
    test_terms = {}
    test_terms[0] = '*.txt'

    # create the test results
    test_results = []
    test_results.append('/home/user1/test1.txt')
    test_results.append('/home/user2/test2.txt')

    # call the tested method

# Generated at 2022-06-11 15:25:34.863256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    dir_path = 'test/integration/lookup_plugins/test_fileglob/'
    test_path = os.path.join(dir_path, 'source/')
    assert lookup_obj.run(['*txt', '*txt'], variables={'ansible_search_path': [test_path]}, wantlist=True) == ['test_fileglob.txt']
    assert lookup_obj.run(['*txt', '*txt'], variables={'ansible_search_path': [test_path]}) == 'test_fileglob.txt'

# Generated at 2022-06-11 15:25:38.620815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    import os
    os.environ["ANSIBLE_LOOKUP_PLUGINS"] = "./"
    os.environ["ANSIBLE_CONFIG"] = "../ansible.cfg"

    lookup_module.run(["./files/sample.txt"])

# Generated at 2022-06-11 15:25:41.110317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_instance = LookupModule()
    assert module_instance.run([], dict()) == [], "Empty list is not returned"

# Generated at 2022-06-11 15:25:49.758760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['ssh_host_ecdsa_key-cert.pub']
    assert lookup.run(terms, variables={'ansible_search_path':['/etc']}) == ['/etc/ssh/ssh_host_ecdsa_key-cert.pub']
    assert lookup.run(['foobar'], variables={'ansible_search_path':['/etc']}) == []
    assert lookup.run(['/ansible_search_path/ssh_host_ecdsa_key-cert.pub'], variables={'ansible_search_path':['/etc']}) == ['/etc/ssh_host_ecdsa_key-cert.pub']

# Generated at 2022-06-11 15:25:58.905775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(["*.py"]);
    assert result == []
    lookup.basedir = "./"
    result = lookup.run(["*.py"]);
    assert len(result) >= 1
    result = lookup.run(["*.py", "*.sh"]);
    assert len(result) >= 2
    result = lookup.run(["*"]);
    assert len(result) >= 2


# Generated at 2022-06-11 15:25:59.739372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(["foo"])

# Generated at 2022-06-11 15:26:07.637066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create lookup instance
    lookupInstance = LookupModule()
    # Get valid_paths and invalid_paths (all other text paths)
    valid_paths = get_valid_paths()
    invalid_paths = get_invalid_paths()
    # Convert list to tuple
    terms = tuple(valid_paths)
    # Run lookup
    file_paths = lookupInstance.run(terms)
    # Compare returned results with valid_paths
    assert file_paths == valid_paths
    # Convert list to tuple
    terms = tuple(invalid_paths)
    # Run lookup
    file_paths = lookupInstance.run(terms)
    # Compare returned results with empty path list
    assert file_paths == []

# Get list of valid paths

# Generated at 2022-06-11 15:26:19.700724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    result = []
    test_case = ["/my/path/*.txt"]
    with open("test_LookupModule_run_1", "w+") as f:
        f.write("test")
    l = LookupModule()
    l.basedir = "test_LookupModule_run_1"
    try:
        result = l.run(test_case)
    except Exception as e:
        result.append(str(e))
    assert result == ["test_LookupModule_run_1/my/path/*.txt"], "Error in test case 1"


    # Test case 2
    result = []
    test_case = ["test_LookupModule_run_2", "test_LookupModule_run_3", "test_LookupModule_run_4"]

# Generated at 2022-06-11 15:26:22.452400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(terms=['/my/path/*.txt'])



# Generated at 2022-06-11 15:26:33.827907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get test path
    test_dir = os.path.dirname(os.path.realpath(__file__))
    expected_r = [
        u'/tmp/fileglob/test_fileglob/test1.txt',
        u'/tmp/fileglob/test_fileglob/test2.txt',
        u'/tmp/fileglob/test_fileglob/test3.txt',
        u'/tmp/fileglob/test_fileglob/test4.txt',
        u'/tmp/fileglob/test_fileglob/test5.txt'
    ]
    expected_r.sort()

    lookup_module = LookupModule()

    # test _basedir and find_file_in_search_path method
    # create one file in: ./test_fileglob/test1.txt

# Generated at 2022-06-11 15:26:41.959326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    loader = DictDataLoader({
        "path/to/file1.txt": "contents1",
        "path/to/file2.txt": "contents2",
        "path/to/file3.txt": "contents3"
    })
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        ansible_search_path=[
            "/some/path/to/files1",
            "/some/path/to/files2",
            "/some/path/to/files3"
        ]
    )

    # When
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(loader)
    lookup_plugin.set_variable_manager(variable_manager)

# Generated at 2022-06-11 15:26:50.677130
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Taken from https://github.com/ansible/ansible/blob/v2.10.1/lib/ansible/plugins/lookup/fileglob.py#L107
    lookup_module = LookupModule()
    # test for a file that is on the fixtures directory
    terms = [os.path.join('test_fileglob.py')]
    result = lookup_module.run(terms, variables={})
    assert len(result) == 1
    assert result[0] == os.path.join('test_fileglob.py')

    # test for a file that doesnt exists
    terms = [os.path.join('__unexisting_file__')]
    result = lookup_module.run(terms, variables={})
    assert len(result) == 0

# Generated at 2022-06-11 15:27:01.581819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialising the lookup plugin
    lookup_plugin = LookupModule()

    # creating a dict containing the path to the files to be used in the test
    file_list = {}
    file_list["test_file_1.txt"] = "/home/test/test_file_1.txt"
    file_list["test_file_2.txt"] = "/home/test/test_file_2.txt"
    file_list["test_file_3.txt"] = "/home/test/test_file_3.txt"
    file_list["test_file_4.txt"] = "/home/test/test_file_4.txt"
    file_list["test_file_5.txt"] = "/home/test/test_file_5.txt"

    # creating file objects for files and writing content

# Generated at 2022-06-11 15:27:07.293059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/tmp/foo/a.txt', '/tmp/foo/b.txt', '/tmp/foo/c.txt']
    variables = {"ansible_search_path": ["/tmp/foo"], "ansible_path_sep": ":"}
    results = lookup.run(terms, variables)
    assert results == terms