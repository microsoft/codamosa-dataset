

# Generated at 2022-06-11 15:22:33.684650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for LookupModule.run()
    using the files in tests directory of ansible
    """
    # Create an instance of LookupModule
    lkm = LookupModule()
    # Create a file with name 'sample.yml' in tests/files directory of ansible
    file = open("tests/files/sample.yml","a")
    # Write some lines in the file
    file.write("---\n")
    file.write("- hosts: localhost\n")
    file.write("  tasks:\n")
    file.write("  - name: run shell command\n")
    file.write("    shell: /bin/true\n")
    # Close the file
    file.close()
    # If the file is not present in the tests/files directory of ansible,
    # then ansible will

# Generated at 2022-06-11 15:22:41.490093
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.fileglob import LookupModule
    from ansible.module_utils.six import PY3


# Generated at 2022-06-11 15:22:52.862594
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a fake ansible variables for this test case
    my_vars = {
        'ansible_search_path': ['../files', 'files', '~/files'],
        'hostvars': {
            'hostname': {
                'ansible_search_path': ['host_files', 'local_files']
            },
            'localhost': {
                'ansible_search_path': ['localhost_files', 'local_files']
            }
        }
    }

    # Create a fake ansible inventory  for this test case
    my_inventory = {
        'group': {
            'hosts': [
                'hostname'
            ],
            'vars': {
                'ansible_search_path': ['group_files', 'common_files']
            }
        }
    }

    # Create

# Generated at 2022-06-11 15:23:02.692768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    import tempfile
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.lookup import LookupBase

    lookup = LookupBase()
    tmp_dir = tempfile.gettempdir()
    cwd = os.getcwd()
    file_path = os.path.join(tmp_dir, 'file.txt')
    dir_path = os.path.join(tmp_dir, 'directory')
    non_existing_path = os.path.join(tmp_dir, 'non-existing')

    # test file globbing for multiple patterns over multiple directories
    file1_path = os.path.join(dir_path, 'file1.txt')
    open(file1_path, 'a').close()

# Generated at 2022-06-11 15:23:12.378728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from collections import namedtuple
    
    # Setup mock file system
    from tempfile import TemporaryDirectory
    from shutil import copytree, copyfile
    from contextlib import contextmanager
    from distutils.dir_util import copy_tree
    import stat
    import errno

    # The directory in which the temporary directories should be created
    tempDir = "/tmp/temp_mock_file_system"

    # Class representing a temporary directory
    class TempDir:
        def __init__(self, subDir):
            self.subDir = os.path.join(tempDir, subDir)
            try:
                os.makedirs(self.subDir, 0o777)
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise



# Generated at 2022-06-11 15:23:14.402797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda x: "C:\\_root_"
    l.find_file_in_search_path = lambda x, y, z: "C:\\_root_\\" + z
    l.run(["*.txt"], {})

# Generated at 2022-06-11 15:23:22.156575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["/tmp/foobar"], dict(ansible_search_path=["/tmp"])) == ["/tmp/foobar"]
    assert LookupModule().run(["/foobar"], dict(ansible_search_path=["/tmp"])) == ["/tmp/foobar"]
    assert LookupModule().run(["*"], dict(ansible_search_path=["/tmp"])) == list(map(to_text, glob.glob("/tmp/*")))

# Generated at 2022-06-11 15:23:31.555493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = './plugins/lookup/fileglob.py'
    glance = 'ansible.plugins.lookup.fileglob.LookupModule'

    lm = LookupModule()

    # Test case 1
    # Tested using dirname "foo" and term "*.txt"
    # Expected Result: empty list
    terms = ['*.txt']
    variables = {'ansible_search_path': 'foo'}
    kwargs = {}
    assert lm.run(terms, variables, **kwargs) == []

    # Test case 2
    # Tested using dirname "foo" and term "bar/*.txt"
    # Expected Result: empty list
    terms = ['bar/*.txt']
    variables = {'ansible_search_path': 'foo'}
    kwargs = {}

# Generated at 2022-06-11 15:23:43.363853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # only file with no dir, so use ansible_playbook_python
    with open(os.path.join(os.path.dirname(__file__), 'test_fileglob.py'), 'rb') as f:
        result = lookup.run(['test_fileglob.py'], variables={'ansible_playbook_python': f.name})
        assert result[0] == f.name
    # only file with no dir, so use current dir
    with open(os.path.join(os.path.dirname(__file__), 'test_fileglob.py'), 'rb') as f:
        result = lookup.run(['test_fileglob.py'], variables={'ansible_playbook_dir': os.path.dirname(__file__)})
       

# Generated at 2022-06-11 15:23:47.408115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_module = MockModule(run_in_check_mode=False)
    terms = ['/my/path/*.txt']
    mock_module.plugins = {
        'lookup': {
            'fileglob': LookupModule(),
        }
    }

    assert mock_module.lookup('lookup.fileglob', terms) == ['foo.txt']


# Generated at 2022-06-11 15:23:56.247413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    v = {}
    v["ansible_search_path"] = []
    terms = [ "/tmp/somefile", "/some/path/somefile" ]

# Generated at 2022-06-11 15:24:08.515551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test lookup
    lookup = LookupModule()
   
    # Test basics
    search = '/'
    file = 'bar.txt'
    pathfile = search + file
    term_file = os.path.basename(pathfile)
    found_paths = []
    found_paths.append(lookup.find_file_in_search_path(None, 'files', os.path.dirname(pathfile)))
    for dwimmed_path in found_paths:
        if dwimmed_path:
            globbed = glob.glob(to_bytes(os.path.join(dwimmed_path, term_file), errors='surrogate_or_strict'))

# Generated at 2022-06-11 15:24:09.226272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:24:19.766721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test function for the LookupModule class
    """
    lookup_module = LookupModule()
    lookup_module.get_basedir = MagicMock(return_value="/")
    lookup_module.find_file_in_search_path = MagicMock(return_value="/")

    # Return value for the run method of class LookupModule
    # without argument wantlist
    ret = lookup_module.run(["/my/path/*.txt"], {"ansible_search_path":["/my/path/*.txt"]})
    # Return the string list of paths joined by commas
    assert ret == ",".join(["/my/path/*.txt"])

    # Return value for the run method of class LookupModule
    # with argument wantlist

# Generated at 2022-06-11 15:24:31.367944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create the loader for the data files
    localhost = DataLoader()

    # Create the variable manager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, [], variable_manager)
    variable_manager.set_inventory(inventory)

    # Create a dummy play
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    # Create the test PlayContext
    play_context = PlayContext()
    play_context.remote_addr = 'localhost'
    play_

# Generated at 2022-06-11 15:24:39.282928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    # Create a mock instance of LookupModule
    l = LookupModule()
    # Set the ansible_search_path to a list of directories
    l._Templar__available_variables = HostVars(unsafe=UnsafeProxy({'ansible_search_path': ['/a']}))
    # Call method run() with a list of patterns to match
    l.run(['./b/c/*.txt', './d/e/*.html'])



# Generated at 2022-06-11 15:24:48.516390
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests for kwargs parameter
    kwargs_vaules = {'wantlist': True}
    kwargs = kwargs_vaules

    # Unit tests for terms parameter
    terms_value = '/Users/umeshbatt/.ansible/tmp/ansible-tmp-1511081682.02-269764904733105/source'
    terms = terms_value

    # Unit tests for variables parameter
    variables_value = {
            'ansible_check_mode': False,
            'ansible_diff_mode': True,
            'ansible_managed': '<ansible.config.manager.ConfigManager object at 0x10188e510L>',
            'ansible_play_hosts': ['127.0.0.1'],
        }
    variables = variables_value

    #

# Generated at 2022-06-11 15:24:59.187385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    lookup = loader.lookup_loader.get('fileglob')
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    var_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Testing run method as class method
    paths = ['tests/test.txt', 'tests/test-dir', 'tests/test-dir/test2.txt']
    terms = ['"tests/*.txt"', 'tests/test-dir', 'tests/test-dir/"*"']

# Generated at 2022-06-11 15:25:07.267182
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    import unittest
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleFileNotFound

    class LookupModule_test(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookupModule_test = LookupModule_test()

    terms_test = ['/my/path/*.txt']
    variables_test = {}

    # Act
    result = lookupModule_test.run(terms_test, variables_test)

    # Assert
    assert result == terms_test

# Generated at 2022-06-11 15:25:15.611794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule()
    lookup_module = LookupModule()

    # create a fake file in /tmp
    filename = '/tmp/test.py'
    f = open(filename,'w')
    f.write('print "hello world"')
    f.close()

    # call LookupModule.run()
    ret = lookup_module.run([filename])

    # test returned value
    assert(ret == [filename])
    assert(isinstance(ret, list))

    # cleanup test file
    os.remove(filename)

# Generated at 2022-06-11 15:25:36.269273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(['./test_fileglob.py']) == ['./test_fileglob.py']
    assert lm.run(['./test_fileglob.py']) == ['./test_fileglob.py']
    assert lm.run(['./test_fileglob.py']) == ['./test_fileglob.py']
    assert lm.run(['./t*.py']) == ['./test_fileglob.py']
    assert lm.run(['./*.py']) == ['./test_fileglob.py']
    assert sorted(lm.run(['*.py'])) == ['./test_fileglob.py', './test_LookupModule_run.py']

# Generated at 2022-06-11 15:25:43.959249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import TestCase
    from unittest.mock import MagicMock
    class Test(TestCase):
        def test_with_a_single_term(self):
            expected_return = [
                "/path/to/file/foo.txt",
                "/path/to/file/bar.txt",
                "/path/to/file/test.txt"
            ]
            terms = [
                "*.txt"
            ]
            variables = {
                "ansible_search_path": [
                    "/path/to/file"
                ]
            }
            test_obj = LookupModule()
            actual_return = test_obj.run(terms, variables)
            self.assertEqual(actual_return, expected_return)

    test_obj = Test()
    test_obj.test_with_a

# Generated at 2022-06-11 15:25:46.599397
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Run method
    term = ['my_file']
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(terms=term)

    # Asserts
    assert isinstance(ret, list)
    assert len(ret) == len(term)
    assert ret == term

# Generated at 2022-06-11 15:25:57.196712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible
    import ansible.playbook.play_context
    import ansible.template
    import ansible.utils
    import ansible.vars

    context = ansible.playbook.play_context.PlayContext()
    context.SEARCH_PATH = ['.', '/tmp/ansible/']

    terms = ['/tmp/ansible/hosts']
    lookup_module = LookupModule()
    lookup_module.set_options(context, terms)

    global _tmp_test_hosts_file
    _tmp_test_hosts_file = '/tmp/ansible/hosts'
    f = open(_tmp_test_hosts_file, 'w')
    f.close()

    lookup_result = lookup_module.run(terms, context)
    assert lookup_result[0] == _tmp_test

# Generated at 2022-06-11 15:25:59.750385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['/my/path/*.txt']
    results = []
    results = lookup.run(terms)
    return results

# Generated at 2022-06-11 15:26:08.184264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import lookup_loader

    if not PY3:
        # Only supported on Python 2.7.9+
        return

    lookup = lookup_loader.get('fileglob', basedir='/this/should/fail/')
    # Python 3: bytes interface
    assert lookup.run([b'/x'], {'ansible_search_path': b'/tmp'}) == []
    assert lookup.run([b'/*'], {'ansible_search_path': b'/tmp'}) == []
    assert lookup.run([b'/x'], {'ansible_search_path': [b'/tmp']}) == []
    assert lookup.run([b'/*'], {'ansible_search_path': [b'/tmp']}) == []


# Generated at 2022-06-11 15:26:10.897564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run([])
    assert not ret
    ret = lookup_module.run(["/etc/*"])
    assert ret

# Generated at 2022-06-11 15:26:22.161776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test without search_paths
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms='/my/path/*.txt') == ['/my/path/*.txt']
    assert lookup_plugin.run(terms=['/my/path/*.txt']) == ['/my/path/*.txt']
    # test with search_paths
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms='*.txt', variables={
        'ansible_search_path': ['/my/path']
    }) == ['/my/path/test1.txt', '/my/path/test2.txt']
    lookup_plugin = LookupModule()

# Generated at 2022-06-11 15:26:30.299224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible = AnsibleRunner(
        os.path.join(os.path.dirname(__file__), 'fixtures', 'LookupModule_run')
    )
    result = ansible.get_task_result('debug', 'msg={{ lookup("fileglob","*.txt") }}')
    print(result)
    assert result['changed'] == False
    assert len(result['msg']) == len(list(filter(lambda p: p.endswith('.txt'), os.listdir(ansible.playbook_dir))))


# Generated at 2022-06-11 15:26:39.958148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.utils.listify import listify_lookup_plugin_terms

    # ansible.inventory.host.Host.get_vars
    # called from lookup modules -> returned vars
    # test fixture -> inventory/test_lookup_fileglob_inventory.yml

# Generated at 2022-06-11 15:27:07.146172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupBase(LookupBase):
        def find_file_in_search_path(self, variables, path, pathfile):
            return path
        def get_basedir(self, variables):
            return '/'

    mock = MockLookupBase()
    terms = [
        '/playbooks/files/fooapp/*'
    ]
    variables = {
        'ansible_search_path': [
            '/playbooks',
            '/roles/apache/tasks'
        ]
    }
    results = mock.run(terms, variables, wantlist=True)
    assert results == ['/playbooks/files/fooapp/']

# Generated at 2022-06-11 15:27:15.384633
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module._templar = mock.MagicMock()
    lookup_module._templar.template.return_value = "/etc/hosts"

    lookup_module.get_basedir = mock.MagicMock()
    lookup_module.get_basedir.return_value = "."

    assert lookup_module.run(["./my_file"]) == ["./my_file"]
    assert lookup_module.run(["ansible_file"]) == ["../files/ansible_file"]
    assert lookup_module.run(["/etc/hosts"]) == [
        "/etc/hosts",
        "../files//etc/hosts"
    ]

# Generated at 2022-06-11 15:27:25.774023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cm = LookupModule()
    # Run the method run of class LookupModule, with some basic terms and variables arguments
    # The result is stored in "result" variable
    result = cm.run(terms=['/foo/bar/baz.txt', '/logs/*.log'], variables={'ansible_search_path': ['/foo/bar', '/logs'], 'ansible_basedir': '/foo'})
    # Expected result:
    # ['/foo/bar/baz.txt', '/logs/some.log', '/logs/someother.log']
    assert result == ['/foo/bar/baz.txt', '/logs/some.log', '/logs/someother.log']

# Generated at 2022-06-11 15:27:33.981579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([
        '*',
        "*.txt",
        "/playbooks/files/fooapp/*",
        "*.xml",
        "*.ini",
        "*.py",
        "*.sh",
        "*.conf",
        "/playbooks/files/fooapp/*.txt",
        "/playbooks/files/fooapp/*.xml",
        "/playbooks/files/fooapp/*.ini",
        "/playbooks/files/fooapp/*.py",
        "/playbooks/files/fooapp/*.sh",
        "/playbooks/files/fooapp/*.conf",
    ])
    print(result)
    assert len(result) == 0

# Generated at 2022-06-11 15:27:44.892067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # File to be tested
    file_path = os.path.dirname(os.path.realpath(__file__)) + '/../../../plugins/lookup/fileglob.py'

    # Unit test for method run of class LookupModule
    def test_method():
        """
        Unit test for method run of class LookupModule
        """
        test_file_path_1 = os.path.dirname(os.path.realpath(__file__)) + '/'
        test_file_path_2 = os.path.dirname(os.path.realpath(__file__)) + '/test.txt'
        assert test_file_path_1 not in open(test_file_path_2).read()

    test_method()

# Generated at 2022-06-11 15:27:50.543605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_init = LookupModule()
    LookupModule_init.get_basedir = lambda x: ('')
    term = '/some/path/somefile.txt'
    ret = LookupModule_init.run(terms=[term])
    assert ret == []
    term = 'somefile.txt'
    ret = LookupModule_init.run(terms=[term])
    assert ret == []
    term = 'somefile.txt'
    ret = LookupModule_init.run(terms=[term])
    assert ret == []

# Generated at 2022-06-11 15:27:59.500204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ntpath
    import sys

    # Arrange
    # mock variables
    class MockVariables(object):
        def __init__(self, ansible_search_path):
            self._ansible_search_path = ansible_search_path

        def __getitem__(self, name):
            return self._ansible_search_path
    # mock os.path.exists

# Generated at 2022-06-11 15:28:09.184864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    import os
    import shutil

    tmpdir = None
    terms = None
    # Setup a temporary directory to run the test case
    def setUp():
        nonlocal tmpdir
        nonlocal terms
        tmpdir = os.path.join(os.path.dirname(__file__), 'tmp')
        try:
            os.mkdir(tmpdir)
        except FileExistsError:
            pass
        # Setup two files (a.conf, b.conf)
        with open(os.path.join(tmpdir, 'a.conf'), 'w') as fh:
            fh.write('a\n')

# Generated at 2022-06-11 15:28:13.428889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        "/home/user/path/*.txt"
    ]
    ret = lookup.run(terms)
    assert isinstance(ret, list)
    assert "/home/user/path/myfile1.txt" in ret


# Generated at 2022-06-11 15:28:22.892578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_basedir = lambda variables: "/home/user/playbook"
    assert lookup_module.run(
        ['/home/user/playbook/files/test.yml', 'test_dir/test.yml']) \
        == ['/home/user/playbook/files/test.yml']
    lookup_module.find_file_in_search_path = lambda variables, files, path: "/home/user/playbook/files"
    assert lookup_module.run(
        ['test_dir/test.yml']) \
        == ['/home/user/playbook/files/test_dir/test.yml']

# Generated at 2022-06-11 15:29:13.072814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    basedir = '/playbooks'
    term = 'fooapp/bar.txt'
    matched = os.path.join(basedir, term)
    not_matched = os.path.join(basedir, 'files/baz.txt')

    def look_for(path, match=True):
        if match:
            assert lookup_module.run([path], {'ansible_search_path': [basedir]}) == [matched]
        else:
            assert lookup_module.run([path], {'ansible_search_path': [basedir]}) == []

    # test matching a simple file
    look_for('fooapp/bar.txt')

    # test matching a simple file with a basedir
    look_for('/playbooks/fooapp/bar.txt')

    #

# Generated at 2022-06-11 15:29:24.490669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    variables = variable_manager.get_vars(play_context)
    lookup_module = LookupModule()
    lookup_module.set_options({'basedir': '.'})

    terms = ['my_file.conf']
    result = lookup_module.run(terms, variables)
    assert result == []

    terms = ['/my_file.conf']

# Generated at 2022-06-11 15:29:32.737448
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for method run with multi terms and without variables
    lookup_module = LookupModule()
    terms = ["/my/path/*.txt", "/my/path/*.log"]
    res = lookup_module.run(terms, variables=None)
    assert isinstance(res, list)

    # Test for method run with single term and with variables
    lookup_module = LookupModule()
    terms = ["/my/path/*.txt"]
    variables = {"ansible_search_path": ["/playbooks/files/fooapp/"]}
    res = lookup_module.run(terms, variables=variables)
    assert isinstance(res, list)

# Generated at 2022-06-11 15:29:43.804178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    lookup = LookupModule()
    lookup.set_options({})
    assert lookup.run(['/dir/file1.txt']) == []  # Fail
    assert lookup.run(['file1.txt'], variables={'ansible_search_path': ['/dir']}) == ['/dir/file1.txt']  # Success
    assert lookup.run(['*.txt'], variables={'ansible_search_path': ['/dir']}) == ['/dir/file1.txt']  # Success
    assert lookup.run(['*.txt']) == ['/file1.txt']  # Success

    lookup = LookupModule()
    loader = DataLoader()

# Generated at 2022-06-11 15:29:54.413103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    j2_env_vars = {
      'ansible_search_path': ['/path/to/ansible/module', '/path/to/ansible/module/module_utils']
    }
    # Test normal use case
    module_utils_file = module.run(['*.py'], j2_env_vars)
    assert len(module_utils_file) == 1
    assert module_utils_file[0] in [
        '/path/to/ansible/module/module_utils/module_utils.py',
        '/path/to/ansible/module/module_utils/module_utils.pyc'
    ]
    # Test filename path only
    ansible_module_file = module.run(['ansible_module.py'], j2_env_vars)

# Generated at 2022-06-11 15:30:06.536688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # just to be as close to real environment as possible
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()

    # copy fake file
    test_data_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_data_dir, '..', '..')
    fake_file = os.path.join(test_data_dir, 'fake_file')
    real_file = os.path.join(test_dir, 'fake_file')
    shutil.copyfile(fake_file, real_file)
    fake_file2 = os.path.join(test_data_dir, 'fake_file2')

# Generated at 2022-06-11 15:30:14.617686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import LookupModule
    lm = LookupModule()
    basedir = lm.get_basedir({})
    # Test the run method on files existing in the basedir
    f1 = os.path.join(basedir, 'file1.txt')
    f2 = os.path.join(basedir, 'file2.txt')
    f3 = os.path.join(basedir, 'dir1/file3.txt')
    f4 = os.path.join(basedir, 'file1.pdf')
    # Create these necessary files before testing
    f1fh = open(f1,'w')
    f1fh.write("1")
    f1fh.close()
    f2fh = open(f2,'w')
    f2fh.write("2")
    f2f

# Generated at 2022-06-11 15:30:20.230697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    filename = '../../../examples/ansible.cfg'
    module = LookupModule()
    search_path = module.find_file_in_search_path({}, 'files', '../../..')
    terms = [filename, os.path.join(search_path, filename)]
    res = module.run(terms)
    assert 'examples/ansible.cfg' in res

# Generated at 2022-06-11 15:30:29.450834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_find_file_in_search_path(variables, directory, search_path):
        if directory == 'files':
            if search_path == '/my/path/dir1':
                return '/my/path/dir1/files'
            elif search_path == '/my/path/dir2':
                return '/my/path/dir2/files'
        else:
            return '/my/path/dir3'

    def mock_get_basedir(variables):
        return '/my/path/basedir'

    def mock_glob(file):
        if file == b'/my/path/dir1/files/file1_1.txt':
            return [b'/my/path/dir1/files/file1_1.txt']

# Generated at 2022-06-11 15:30:37.474368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    # base case: test for no file found
    dummy_list = ['abcd.txt']
    dummy_result = m.run(dummy_list)
    assert not dummy_result
    # base case: test for valid file
    dummy_list = ['../tests/utils.py']
    dummy_result = m.run(dummy_list)
    assert dummy_result
    # test for no file but empty list
    dummy_list = []
    dummy_result = m.run(dummy_list)
    assert not dummy_result