

# Generated at 2022-06-23 14:17:28.626826
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def noop(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def noop2(self):
            pass

    x = Foo()
    x.noop()
    x.noop2()

# Generated at 2022-06-23 14:17:38.006607
# Unit test for function lock_decorator
def test_lock_decorator():
    in_call = [False]
    counter = [0]
    cls = type('Cls', (), {'_lock': lock_decorator(attr='_lock')(lambda self: in_call.__setitem__(0, True)), '_counter': counter})
    assert in_call[0] is False, 'Class method has been called before an object is constructed'
    assert counter[0] == 0, 'Class counter has been incremented before an object is constructed'

    obj = cls()
    assert in_call[0] is False, 'Class method has been called before an object calls the method'
    assert counter[0] == 0, 'Class counter has been incremented before an object calls the method'

    obj._lock()
    assert in_call[0] is True, 'Class method has not been called'

# Generated at 2022-06-23 14:17:48.585040
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    def test_func(arg1, arg2, *args, **kwargs):
        lock.acquire()
        locked = lock._is_owned()
        lock.release()
        return (arg1, arg2, args, kwargs, locked)

    locked = None
    test_func_wrapped = lock_decorator(lock=lock)(test_func)
    assert 'test_func_wrapped' == test_func_wrapped.__name__
    assert test_func_wrapped.__doc__ == 'Unit test for function lock_decorator'

    # Make sure the lock is locked when the func executes

# Generated at 2022-06-23 14:17:56.854015
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='_callback_lock')
        def some_method(self, value):
            self.value += value
            return self.value

        @lock_decorator(lock=threading.Lock())
        def some_other_method(self, value):
            self.value += value
            return self.value

    instance = MyClass()

    # Assert that both methods work
    assert instance.some_method(1) == 1
    assert instance.some_other_method(2) == 3

# Generated at 2022-06-23 14:18:08.083515
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    from unittest.case import skip
    from threading import Lock
    from time import sleep

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.foo = 0
            self.bar = 0
            self.baz = 0
            self.foobar = 0
            self.foobaz = 0
            self.barbaz = 0
            self.foobarbaz = 0

            self.lock = Lock()

        @lock_decorator(attr='lock')
        def test_foo(self):
            self.foo += 1
            sleep(0.1)

        @lock_decorator(lock=self.lock)
        def test_bar(self):
            self.bar += 1
            sleep(0.1)


# Generated at 2022-06-23 14:18:18.210435
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._count = 0

        @lock_decorator(attr='_lock')
        def bar(self):
            self._count += 1

        @lock_decorator(lock=threading.Lock())
        def baz(self):
            self._count += 1

    foo = Foo()

    assert not foo._lock.locked()

    foo.bar()

    assert foo._count == 1
    assert not foo._lock.locked()

    foo.baz()

    assert foo._count == 2
    assert not foo._lock.locked()

# Generated at 2022-06-23 14:18:26.278207
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Testclass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.x = 0

        @lock_decorator(attr='lock')
        def inc(self):
            self.x += 1

        @lock_decorator(lock=threading.Lock())
        def add(self, val):
            self.x += val

    obj = Testclass()
    obj.inc()
    assert obj.x == 1

    obj.add(2)
    assert obj.x == 3

# Generated at 2022-06-23 14:18:35.774986
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import unittest

    # Create test class
    class TestLockDecorator(unittest.TestCase):
        def test_lock_decorator(self):

            # create shared lock object
            lock = threading.Lock()

            # create mock shared object
            obj = type('obj', (object,), {'a': 0})
            obj.lock = lock

            # Counter object
            counter = type('counter', (object,), {'a': 0})

            def test_lock_decorator_function_1(obj):
                if obj.a == 1:
                    pass

            def test_lock_decorator_function_2(obj):
                if obj.a == 1:
                    pass


# Generated at 2022-06-23 14:18:43.213834
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class TestMethod(object):
        def __init__(self):
            self.lock_called = 0

        @lock_decorator(attr='method_lock')
        def lock_method(self):
            self.lock_called += 1

        @property
        def method_lock(self):
            return self._method_lock

        @method_lock.setter
        def method_lock(self, value):
            self._method_lock = value

    class TestStaticMethod(object):
        lock_called = 0

        @lock_decorator(attr='static_lock')
        @staticmethod
        def lock_method():
            TestStaticMethod.lock_called += 1

        @property
        def static_lock(self):
            return self._static_lock


# Generated at 2022-06-23 14:18:51.449963
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    test_lock = threading.Lock()
    test_lock_attr = 'lock'
    test_value = []

    class TestClass:
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr=test_lock_attr)
        def test_method_with_attr(self):
            test_value.append(1)

        @lock_decorator(lock=test_lock)
        def test_method_with_explicit_lock(self):
            test_value.append(2)

        @lock_decorator()
        def test_method_with_no_lock(self):
            test_value.append(3)

    t = TestClass()


# Generated at 2022-06-23 14:18:56.666458
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestClass(object):
        _lock = None
        def __init__(self):
            import threading
            self._lock = threading.Lock()

        @staticmethod
        @lock_decorator(attr='_lock')
        def test_method(num):
            return num

    tc = TestClass()
    assert tc.test_method(1) == 1

# Generated at 2022-06-23 14:19:05.119727
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class SomeClass(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def add_to(self, *args):
            for arg in args:
                time.sleep(0.01)
                self.result += arg
            return self.result

        def add_to_wrapper(self, *args):
            with self._lock:
                return self.add_to(*args)

    class SomeOtherClass(object):
        @lock_decorator(lock=threading.Lock())
        def subtract_from(self, *args):
            for arg in args:
                time.sleep(0.01)
                self.result -= arg
            return self.result


# Generated at 2022-06-23 14:19:16.462526
# Unit test for function lock_decorator
def test_lock_decorator():

    # Import here to avoid breaking requirements.txt
    import threading

    class DummyClass(object):
        '''The dummy class for testing the lock_decorator'''

        _callback_lock = threading.Lock()

        def __init__(self, *args, **kwargs):
            self.lock = threading.Lock()
            self.foo = []

        @lock_decorator(attr='_callback_lock')
        def callback_with_attr(self, val):
            self.foo.append(val)

        @lock_decorator(lock=threading.Lock())
        def callback_with_kwarg(self, val):
            self.foo.append(val)

        @lock_decorator(lock=None)
        def callback_with_none_lock(self, val):
            self.foo

# Generated at 2022-06-23 14:19:21.626515
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest

    class Foo(object):
        def __init__(self):
            self.lock = None

        @lock_decorator(attr='lock')
        def do_lock(self):
            self.lock = True

    foo = Foo()
    with pytest.raises(AttributeError):
        foo.do_lock()

# Generated at 2022-06-23 14:19:30.395028
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test lock_decorator'''
    import threading
    lock = threading.Lock()
    lock2 = threading.Lock()
    class Fake(object):
        '''Fake Object'''
        def __init__(self):
            self.lock = lock
            self.lock2 = lock2
        @lock_decorator(attr='lock')
        def method(self):
            '''Fake Object method'''
            if lock.acquire(blocking=False):
                return True
            return False
        @lock_decorator(lock=lock2)
        def method2(self):
            '''Fake Object method2'''
            if lock2.acquire(blocking=False):
                return True
            return False

# Generated at 2022-06-23 14:19:37.287854
# Unit test for function lock_decorator
def test_lock_decorator():

    '''
    Unit testing for the lock_decorator function.
    '''

    import collections
    import threading

    class DummyClass(object):
        def __init__(self):

            self.counter = 0
            self.lock = threading.Lock()
            self.counter_d = collections.defaultdict(int)
            self.lock_d = threading.Lock()
            self.counter_a = 0
            self.counter_da = collections.defaultdict(int)

        @lock_decorator(lock=None)
        def increment_counter(self):
            # Increment the counter
            self.counter += 1
            return self.counter

        @lock_decorator(lock=None)
        def reset_counter(self):
            self.counter = 0
            return self.counter


# Generated at 2022-06-23 14:19:47.606159
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestLockDecorator(object):
        @lock_decorator(attr='_lock', lock=None)
        def method_using_existing_lock(self):
            return 1234

        @lock_decorator(attr='_missing_lock_attr', lock=None)
        def method_without_existing_lock(self):
            return 4321

        @lock_decorator(attr='_lock', lock=threading.Lock())
        def method_using_explicit_lock(self):
            return 'explicit'

    obj = TestLockDecorator()
    obj._lock = threading.Lock()
    assert obj.method_using_existing_lock() == 1234
    assert obj.method_without_existing_lock() == 4321
    assert obj.method_using_explicit_lock

# Generated at 2022-06-23 14:19:58.810598
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import random
    import time

    class TestClass(object):
        def __init__(self):
            self.value = 0
            self.lock = threading.Lock()

        @lock_decorator(lock=threading.Lock())
        def __test_method_1(self):
            self.value += 1
            time.sleep(random.random() * .2)
            self.value += 1

        @lock_decorator(attr='lock')
        def __test_method_2(self):
            self.value += 1
            time.sleep(random.random() * .2)
            self.value += 1

        def test_method_1(self):
            return self.__test_method_1()

        def test_method_2(self):
            return self.__test_method

# Generated at 2022-06-23 14:20:08.034336
# Unit test for function lock_decorator
def test_lock_decorator():
    # Python2 doesn't have ``nonlocal`` so it's not possible to
    # do this without wrapping in a function
    def do_test():
        import threading

        _lock = threading.RLock()
        # The lock is always taken, so acquire() should always be called
        @lock_decorator(lock=_lock)
        def f(arg):
            f.acquire()
            return arg

        @lock_decorator(attr='_lock')
        def f(arg):
            f.acquire()
            return arg

        class C(object):
            _lock = threading.RLock()
            @lock_decorator(attr='_lock')
            def f(self, arg):
                f.acquire()
                return self, arg


# Generated at 2022-06-23 14:20:20.566248
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo:
        global lock
        lock = threading.Lock()
        def __init__(self):
            self.attrs = dict()
        def __getattr__(self, name):
            if name in self.attrs:
                return self.attrs[name]
            raise AttributeError(name)
        def __setattr__(self, name, value):
            self.attrs[name] = value
        @lock_decorator(attr='lock')
        def _locked_method(self):
            pass
        @lock_decorator(lock=threading.Lock())
        def _locked_method2(self):
            pass

    klass = Foo()
    klass._locked_method()
    klass._locked_method2()



# Generated at 2022-06-23 14:20:27.984334
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class UselessClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.num = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self.num += 1

        @lock_decorator(lock=threading.Lock())
        def other_increment(self):
            self.num += 1

    obj = UselessClass()
    assert obj.num == 0

    obj.increment()
    assert obj.num == 1

    obj.other_increment()
    assert obj.num == 2

# Generated at 2022-06-23 14:20:38.663862
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    lock_dict_obj = {'_lock': MagicMock()}
    lock_obj = MagicMock()

    # Test the attr lock
    @lock_decorator(attr='_lock')
    def some_method_1(*args, **kwargs):
        pass
    # Test the explicit lock
    @lock_decorator(lock=lock_obj)
    def some_method_2(*args, **kwargs):
        pass
    # Test the same thing with a classmethod

# Generated at 2022-06-23 14:20:48.705633
# Unit test for function lock_decorator
def test_lock_decorator():
    import inspect
    import threading

    lock = threading.Lock()

    # Realistic usage, where the lock is stored on an object
    class A:
        @lock_decorator(attr='lock')
        def func(self, arg):
            return (self, arg)

        def __init__(self):
            self.lock = threading.Lock()
            self.args = (1, 2, 3)
            self.kwargs = {'key': 'value'}

    objA = A()

    # Test that A.func is locked at runtime
    with lock:
        assert objA.func(*objA.args, **objA.kwargs) == (objA, 1)

    # Test that A.func is still wrapped at runtime
    assert inspect.ismethod(objA.func) is True

    # Test

# Generated at 2022-06-23 14:20:58.731336
# Unit test for function lock_decorator
def test_lock_decorator():
    # pylint: disable=too-few-public-methods, no-self-use, missing-docstring
    import threading
    class FakeLock(object):
        def __init__(self):
            self.acquire_count = 0
            self.release_count = 0

        def __enter__(self):
            self.acquire_count += 1

        def __exit__(self, *args):
            self.release_count += 1

    class TestObject(object):
        def __init__(self):
            self.lock = FakeLock()
            self.attr_lock = FakeLock()
            self._callback_lock = FakeLock()
            self.lock_counter = 0

        @lock_decorator(attr='_callback_lock')
        def test_method_with_attr(self):
            self.lock

# Generated at 2022-06-23 14:21:08.973081
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestCallback(object):
        def __init__(self, test_case):
            self._callback_lock = threading.Lock()
            self.test_case = test_case

        @lock_decorator(attr='_callback_lock')
        def callback(self):
            self.test_case.callback_value += 1
            time.sleep(1)

    # Mock test case...
    test_case = type('TestCase', (object, ), dict(
        callback_value=0,
    ))

    # Create callback object
    callback = TestCallback(test_case)

    # Assert that the lock is in fact acquired
    callback.callback()
    assert test_case.callback_value == 1

    # Assert that the lock is held
    callback.callback()
    assert test

# Generated at 2022-06-23 14:21:19.254667
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class A:
        def __init__(self):
            self.x = 0
            self.callback_lock = threading.Lock()

        @lock_decorator(attr='callback_lock')
        def callback_wrapper(self, y):
            self.x += y

    class B:
        def __init__(self):
            self.x = 0
            self.callback_lock = threading.Lock()

        @lock_decorator(lock=self.callback_lock)
        def callback_wrapper(self, y):
            self.x += y

    x = A()
    y = B()

    x.callback_wrapper(1)
    y.callback_wrapper(2)

    assert x.x == 1 and y.x == 2

# Generated at 2022-06-23 14:21:22.556596
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        # This is meant for threaded unit testing
        return
    lock = threading.Lock()
    lock2 = threading.Lock()
    # this class is meant to be tested in a threaded fashion
    class LockTest(object):

        def __init__(self):
            self._lock1 = Lock()
            self._lock2 = Lock()

        @lock_decorator(attr='_lock1')
        def first_lock(self, x):
            y = 0
            while y < x:
                y += 1
            return y

        @lock_decorator(lock=lock)
        def second_lock(self, x):
            y = 0
            while y < x:
                y += 1
            return y

        # this method is not locked

# Generated at 2022-06-23 14:21:28.189512
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        import sys
        sys.stderr.write('Unable to import threading, skipping test_lock_decorator\n')
        return

    class A(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self, s):
            return s

    a = A()
    assert a.method('test') == 'test'

    @lock_decorator(lock=threading.Lock())
    def method(s):
        return s

    assert method('test') == 'test'

# Generated at 2022-06-23 14:21:38.360416
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class ClassWithLock:
        def __init__(self):
            self.counter = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.counter += 1

    @lock_decorator(lock=threading.Lock())
    def increment(obj):
        obj.counter += 1

    base = 0
    for i in range(50):
        base += 1
        lock_obj = ClassWithLock()
        lock_obj.increment()

        obj = ClassWithLock()
        obj.increment()

        increment(obj)

        threads = []

        for j in range(20):
            threads.append(threading.Thread(target=lock_obj.increment))


# Generated at 2022-06-23 14:21:48.489669
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Thread
    from time import sleep
    from sys import version_info

    class TestClass:
        def __init__(self):
            self._attr_lock = threading.Lock()

        @lock_decorator(attr='_attr_lock')
        def attr_lock_method(self, value):
            sleep(5)
            return value

        @lock_decorator(lock=threading.Lock())
        def specific_lock_method(self, value):
            sleep(5)
            return value

    testobj = TestClass()

    # Test with a pre-defined lock on an attribute
    attr_thread = Thread(target=testobj.attr_lock_method, args=('attr',))
    attr_thread.start()
    sleep(0.5)

# Generated at 2022-06-23 14:21:58.911006
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    import sys

    class TestClass(object):
        c = 0
        l = Lock()

        @lock_decorator(attr='l')
        def count_up_class(self):
            self.c += 1

        @lock_decorator(attr='l')
        def count_up_static(self):
            TestClass.c += 1

        @lock_decorator(lock=l)
        def count_up_lock(self):
            self.c += 1

        @classmethod
        def check_count(cls, msg):
            if cls.c != 42:
                sys.exit(msg)

    class TestThread(Thread):
        def __init__(self, cls):
            super(TestThread, self).__init__()
            self.cls

# Generated at 2022-06-23 14:22:06.998708
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Base(object):
        def __init__(self):
            self._lock = threading.RLock()

        @property
        def lock(self):
            return self._lock

    class Test(Base):
        def __init__(self):
            super(Test, self).__init__()
            self.first = None
            self.second = None

        @lock_decorator(attr='lock')
        def _first(self, wait=None):
            if wait:
                time.sleep(wait)
            self.first = True

        @lock_decorator(attr='lock')
        def _second(self):
            self.second = True

    test = Test()
    threading.Thread(target=test._first, args=(1,)).start()

# Generated at 2022-06-23 14:22:18.018832
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Function lock_decorator'''

    def test_func(self):
        '''a function to decorate'''
        self.call_count += 1

    class TestClass(object):
        '''a class to test lock_decorator'''
        lock = threading.Lock()
        call_count = 0

        @lock_decorator(lock=lock)
        def test_method(self):
            '''a method to test lock_decorator'''
            self.call_count += 1

        @lock_decorator(attr='lock')
        def another_test_method(self):
            '''a method to test lock_decorator'''
            self.call_count += 1

    import multiprocessing
    pool = multiprocessing.Pool(5)

# Generated at 2022-06-23 14:22:29.051384
# Unit test for function lock_decorator
def test_lock_decorator():
    from mock import Mock
    from ansible.module_utils.basic import AnsibleModule

    def _load_params():
        return dict(
            lock_attr='missing_lock_attr',
            lock=None
        )

    # This is a hacky shortcut for the test suite
    # We're not actually testing the module, so we don't care about the
    # parameters.
    class MyTestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            kwargs.update(_load_params())
            super(MyTestModule, self).__init__(*args, **kwargs)

    # Let's create a mock object we can use
    # We need it to be an instance, so that we can call super()

# Generated at 2022-06-23 14:22:39.903685
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    from threading import Lock
    from threading import Thread
    from time import sleep
    from time import time

    class LockTester(object):
        def __init__(self, *args, **kwargs):
            self.lock = Lock()
            self.val = 0

        # Test using an instance attribute
        @lock_decorator(attr='lock')
        def increment_val(self):
            self.val += 1
            sleep(0.01)

        # Test using a lock object
        @lock_decorator(lock=Lock())
        def increment_val2(self):
            self.val += 1
            sleep(0.01)


# Generated at 2022-06-23 14:22:50.251430
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading

    class Test:
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def hello(self):
            print("hello")
            return True

        @lock_decorator(lock=threading.Lock())
        def world(self):
            print("world")
            return True

    t = Test()
    t.hello()
    t.world()

    with mock.patch('threading.Lock.__enter__') as m:
        t.hello()
    assert m.call_count == 1

    with mock.patch('threading.Lock.__enter__') as m:
        t.world()
    assert m.call_count == 1

# Generated at 2022-06-23 14:23:02.301970
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    from threading import Event, Lock, Thread

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.lock = Lock()
            self.event = Event()
            self.counter = 0

        def test_lock(self):
            self.assertFalse(self.lock.locked())

            @lock_decorator(lock=self.lock)
            def sub_test_lock(self):
                self.counter += 1
                self.event.set()

            sub_test_lock(self)
            self.event.wait(5)

            self.assertEqual(self.counter, 1)
            self.assertTrue(self.lock.locked())

            def sub_test_unlock(self):
                self.lock.release()

# Generated at 2022-06-23 14:23:02.872201
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-23 14:23:13.058882
# Unit test for function lock_decorator
def test_lock_decorator():
    import collections

    # test class to test ``attr`` and ``lock``
    class TestClass(object):

        def __init__(self):
            self._lock = collections.deque()

        @lock_decorator(attr='_lock')
        def attr_method(self):
            self._lock.append('attr_method')

        @lock_decorator(lock=collections.deque())
        def lock_method(self):
            self._lock.append('lock_method')

    # verify that ``_lock`` is a ``collections.deque``
    t = TestClass()
    assert isinstance(t._lock, collections.deque)
    # verify that ``attr_method`` uses ``TestClass._lock``
    t.attr_method()
    assert t._lock == ['attr_method']
    #

# Generated at 2022-06-23 14:23:23.309174
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self._counter += 1
            time.sleep(0.2)
            self._counter += 1

        def count(self):
            return self._counter


    def run_test():
        test = Test()
        assert test.count() == 0

        threads = []
        for i in range(5):
            t = threading.Thread(target=test.increment)
            t.start()
            threads.append(t)
        for t in threads:
            t.join()

        assert test.count() == 10

    run_test()

# Generated at 2022-06-23 14:23:31.502634
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass:
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, i):
            print(i)

        def some_method(self):
            self.send_callback(1)

    class TestClass2:
        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            print('some_method')

    tc = TestClass()
    tc.some_method()

# Generated at 2022-06-23 14:23:34.310529
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    from ansible.module_utils.basic import AnsibleModule

    doctest.testmod(
        AnsibleModule,
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS,
    )

# Generated at 2022-06-23 14:23:43.119266
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # This test will fail without the lock_decorator
    lock = threading.Lock()
    target = list()

    @lock_decorator(lock=lock)
    def go():
        target.append(1)
        x = target[0]
        target[0] = x + 1

    ts = []
    for _ in range(100):
        t = threading.Thread(target=go)
        ts.append(t)
    for t in ts:
        t.start()
    for t in ts:
        t.join()

    assert target == [101]

# Generated at 2022-06-23 14:23:54.636331
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import multiprocessing
    import time

    lock = threading.RLock()
    class Locked(object):
        def __init__(self):
            self._lock = lock

        @lock_decorator(attr='_lock')
        def locked_method(self):
            print('Locked method')

    @lock_decorator(lock=lock)
    def locked_function():
        print('Locked function')

    class TestProcess(multiprocessing.Process):
        def __init__(self):
            super(TestProcess, self).__init__()
            self._method = Locked()

        def run(self):
            self._method.locked_method()

    class TestThread(threading.Thread):
        def __init__(self):
            super(TestThread, self).__init

# Generated at 2022-06-23 14:24:00.251163
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        """Simple test class for lock_decorator unit test"""
        def __init__(self, msg=None):
            self.thread = threading.current_thread()
            self.msg = msg if not msg else 'Hello World!'
            self.result = ''
            self.shared_var = '1'
            self.lock = threading.Lock()

        @lock_decorator(lock=threading.Lock())
        def method1(self):
            """Explicitly passing lock"""
            time.sleep(1)
            self.result = 'method1'
            return self.result

        @lock_decorator(attr='lock')
        def method2(self):
            """Using existing lock"""
            time.sleep(1)
            self.result

# Generated at 2022-06-23 14:24:06.493870
# Unit test for function lock_decorator
def test_lock_decorator():
    import thread
    class TestLock:
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, thread, name=''):
            print(self, thread, name)
        def __init__(self, name=''):
            self._callback_lock = thread.allocate_lock()
    my_lock = TestLock('foo')
    my_lock.send_callback(thread.get_ident(), 'bar')


# Generated at 2022-06-23 14:24:17.457372
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):

        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def _locked_method(self, *args, **kwargs):
            return args, kwargs

        @lock_decorator(lock=threading.Lock())
        def _locked_method_explicit_lock(self, *args, **kwargs):
            return args, kwargs

    t = Test()

    x = t._locked_method(1, 2)
    assert x == ((1, 2), {})

    x = t._locked_method(3, 4)
    assert x == ((3, 4), {})

    x = t._locked_method_explicit_lock(5, 6)
    assert x == ((5, 6), {})


# Generated at 2022-06-23 14:24:28.712986
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys

    if sys.version_info[0] == 3:
        from unittest import mock
    else:
        import mock

    from nose.tools import assert_raises

    def test():
        pass
    lock = mock.MagicMock()

    with lock:
        test()

    lock.__enter__.assert_called_once_with()
    lock.__exit__.assert_called_once_with(None, None, None)

    @lock_decorator(lock=lock)
    def test_2():
        pass
    with lock:
        test_2()

    lock.__enter__.assert_called_with()

    # test use of attr
    class Foo(object):
        def __init__(self):
            self.bar = 'baz'


# Generated at 2022-06-23 14:24:35.409305
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class TestClass(object):
        def __init__(self):
            self._attr_lock = None

        @lock_decorator(attr='_attr_lock')
        def test_method(self):
            self._attr_lock += 1
            return self._attr_lock

    class TestClass2(object):
        @lock_decorator()
        def test_method(self):
            pass

    class TestClass3(object):
        def __init__(self):
            self._attr_lock = None

        @lock_decorator(lock=self._attr_lock)
        def test_method(self):
            self._attr_lock += 1
            return self._attr_lock


# Generated at 2022-06-23 14:24:47.021719
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    This test is designed to verify the lock_decorator decorator
    works properly.

    The basic process is to define a mock module with an object
    type and a decorated method.  We then use multiprocessing
    to run the `decorated_method` twice at the same time, and
    verify that the shared data is not modified.  We also
    decorate a method without a lock, and verify that the shared
    data is modified as expected.

    TODO:
    This code may not be 100% reliable as it seems to not always
    reproduce the desired behavior in CI.  It should be replaced
    with a 100% reliable unit test.
    '''
    import multiprocessing
    import time
    # module mock
    import mock
    import ssl

# Generated at 2022-06-23 14:24:56.315204
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    cnt = 0
    expected = 10
    lock = threading.Lock()

    @lock_decorator(attr='_lock')
    def add_one(self):
        nonlocal cnt
        cnt += 1

    class Test:
        def __init__(self, lock=None):
            self._lock = lock
            self.runner = threading.Thread(target=self.run)

        def run(self):
            for _ in range(expected):
                add_one(self)

    class TestWithoutLock:
        def __init__(self):
            self.runner = threading.Thread(target=self.run)

        def run(self):
            for _ in range(expected):
                add_one(self)


# Generated at 2022-06-23 14:25:07.058655
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # Test that the instance attribute can be used for the lock
    class Example(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def foo(self):
            self.val = 1
            time.sleep(0.2)

    # Test that an explicit lock can be passed
    class Example2(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(lock=threading.Lock())
        def foo(self):
            self.val = 1
            time.sleep(0.2)

    # Test that an instance attribute is actually used
    class Example3(object):
        def __init__(self):
            self._lock

# Generated at 2022-06-23 14:25:17.278560
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Lock decorator unit tests'''
    import sys
    import threading
    from time import sleep

    # check the module can be imported
    print("Running unit tests to verify lock decorator is working")

    # check the function has docstring for its unit tests
    assert test_lock_decorator.__doc__ is not None, "The function is missing a docstring"

    # check the module has a version number
    assert hasattr(sys.modules[__name__], '__version__'), "The module is missing a __version__"

    # check the module has an __author__
    assert hasattr(sys.modules[__name__], '__author__'), "The module is missing an __author__"

    # test the code works as expected
    print("Starting lock decorator unit tests")
    # create a custom class for testing
   

# Generated at 2022-06-23 14:25:26.112730
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    test_lock = threading.Lock()
    @lock_decorator(attr='_lock', lock=lock)
    def foo(self):
        self.foo = True
        with test_lock:
            return True
    @lock_decorator(lock=lock)
    def bar():
        return True

    class Test(object):
        def __init__(self):
            self._lock = lock

        @lock_decorator(attr='_lock')
        def baz(self):
            self.baz = True
            with test_lock:
                return True

    test = Test()

    a = threading.Thread(target=foo, args=[test])
    b = threading.Thread(target=bar)

# Generated at 2022-06-23 14:25:26.686676
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-23 14:25:37.872316
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class LockTestCase(unittest.TestCase):
        def setUp(self):
            self._lock_attr = None

        @lock_decorator()
        def missing_lock_attr(self):
            self._lock_attr = True

        def test_missing_lock_attr(self):
            self.assertRaises(RuntimeError, self.missing_lock_attr)

    suite = unittest.TestSuite()
    suite.addTest(LockTestCase('test_missing_lock_attr'))

    # Run the test suite
    rc = unittest.TextTestRunner(verbosity=2).run(suite)
    if not rc.wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-23 14:25:43.637968
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, arg):
            return arg + 'bar'

    myclass = MyClass()

    assert myclass.send_callback('foo') == 'foobar'

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:25:52.686087
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    test_lock = threading.Lock()
    lock = 'lock'

    # Inner function, with a target lock
    def inner_with_lock(l):
        with l:
            return 'success'
    # Inner function, with a target attribute
    def inner_with_attr(o):
        return getattr(o, 'lock')

    # The outer functions can be tested using the same inner functions
    def test_func(inner, outer, target):
        return inner(target) == outer(target)

    # Test with an instance attribute
    class TestLockDecoratorWithAttr(object):
        lock = lock

        @lock_decorator(attr='lock')
        def outer_with_attr(self):
            return inner_with_attr(self)


# Generated at 2022-06-23 14:26:03.195879
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._cb_list = ['l1']

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, data):
            self._cb_list.append(data)

        def run_threads(self):
            import time
            # Make sure the lock is working
            t = threading.Thread(target=self.send_callback, args=('t1',))
            t.start()
            time.sleep(0.1)
            t = threading.Thread(target=self.send_callback, args=('t2',))
            t.start()
            time.sleep(0.1)

# Generated at 2022-06-23 14:26:13.362681
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    from threading import Thread, Lock

    # Ensure the decorator passes it's arguments through properly
    class MyClass(object):
        def __init__(self):
            self.lock = Lock()
        @lock_decorator(attr='lock')
        def _mymethod(self, foo='bar'):
            return foo

    obj = MyClass()
    assert obj._mymethod() == 'bar'

    # Ensure the decorator properly wraps a method and clears the lock
    class MyClass(object):
        def __init__(self):
            self.lock = Lock()
            self.lock.acquire()
        @lock_decorator(attr='lock')
        def _mymethod(self, foo='bar'):
            return foo

    obj = MyClass()

# Generated at 2022-06-23 14:26:22.181589
# Unit test for function lock_decorator

# Generated at 2022-06-23 14:26:29.616242
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class LOL(object):

        @lock_decorator(attr='_lock')
        def method1(self, *args, **kwargs):
            return args, kwargs

        @lock_decorator(attr='_lock')
        def method2(self, *args, **kwargs):
            return args, kwargs

        @lock_decorator(lock=lock)
        def method3(self, *args, **kwargs):
            return args, kwargs

    lol = LOL()
    lol._lock = lock
    assert lol.method1('test1', 'test2', 'test3') == (('test1', 'test2', 'test3'), {})

# Generated at 2022-06-23 14:26:40.685453
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo(object):
        def __init__(self):
            self._lock = threading.RLock()
            self.counter = 0
            self.counter_lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def increment(self):
            self.counter += 1
            time.sleep(0.1)
            return self.counter

        @property
        def inc_count(self):
            with self.counter_lock:
                return self.counter

    @lock_decorator(lock=threading.Lock())
    def get_count(foo):
        return foo.inc_count

    foo = Foo()

    def increment():
        foo.increment()

    # create two threads and start them

# Generated at 2022-06-23 14:26:52.412672
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):

        def __init__(self):
            self._lock = threading.Lock()
            self._some_lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method_one(self, **kwargs):
            kwargs['foo'] = 'bar'
            return kwargs

        @lock_decorator(lock=self._some_lock)
        def method_two(self, **kwargs):
            kwargs['foo'] = 'baz'
            return kwargs

        @lock_decorator(lock=self._some_lock)
        def method_three(self, **kwargs):
            kwargs['foo'] = 'bleh'
            return kwargs


# Generated at 2022-06-23 14:27:01.944067
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # we need a class to test the first case
    class A():
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, data):
            pass

    class B():
        # and a second class to test the second case
        @lock_decorator(lock=threading.Lock())
        def send_callback(self, data):
            pass

    # and now test the two cases
    assert A().send_callback.__name__ == 'send_callback'
    assert B().send_callback.__name__ == 'send_callback'

# Generated at 2022-06-23 14:27:05.899405
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    lock = threading.Lock()
    counter = 0

    @lock_decorator(lock=lock)
    def increment():
        global counter
        counter += 1
        time.sleep(.1)
        counter += 1

    threads = [threading.Thread(target=increment) for _ in range(5)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert counter == 10

# Generated at 2022-06-23 14:27:14.600114
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile

    @lock_decorator(attr='_lock')
    def my_method(self, content=''):
        # Create a file with ``content``
        # this is a big job and so we must lock it
        with open(self.path, 'w') as f:
            f.write(content)

    class MyClass(object):
        def __init__(self):
            # Create a temp file
            self.path = tempfile.mkstemp()[1]
            # Create a lock
            self._lock = os.lockf()

    my_object = MyClass()
    my_method(my_object, content='success')
    assert my_object.path == 'success'

# Generated at 2022-06-23 14:27:22.260630
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    class Test(object):
        _lock = threading.Lock()

        @lock_decorator(lock=lock)
        def method1(self):
            pass

        @lock_decorator(attr='_lock')
        def method2(self):
            pass

    t = Test()
    assert t.method1.__doc__ == repr(t.method1) == repr(t.method1.__name__)
    assert t.method2.__doc__ == repr(t.method2) == repr(t.method2.__name__)