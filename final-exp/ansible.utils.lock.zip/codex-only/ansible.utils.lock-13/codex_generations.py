

# Generated at 2022-06-23 14:17:33.162800
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass:
        def __init__(self, attr):
            setattr(self, attr, threading.Lock())
            self.attr = attr
            self.counter = 0

        @lock_decorator(attr='attr')
        def test_method(self):
            self.counter += 1
            return self.counter

    obj = TestClass('_lock')
    print(obj.test_method())
    print(obj.test_method())
    obj = TestClass('_lock')
    print(obj.test_method())
    print(obj.test_method())

# Generated at 2022-06-23 14:17:40.859467
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    called = []
    class Class(object):
        @lock_decorator(lock=lock)
        def method(self, n):
            called.append(n)
    class Class2(object):
        def __init__(self, lock=None):
            self._lock = lock

        @lock_decorator(attr='_lock')
        def method(self, n):
            called.append(n)

    class NotLock(object):
        def __enter__(self):
            pass
        def __exit__(self, *args):
            pass

    # Validate that lock_decorator with lock passed in works
    c = Class()
    c.method(1)
    assert called == [1]

    # Validate that lock_decorator with

# Generated at 2022-06-23 14:17:47.839475
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator()
        def test(self):
            return True

        @lock_decorator(attr='_lock')
        def test2(self):
            return True

        @lock_decorator(lock=threading.Lock())
        def test3(self):
            return True

    foo = Foo()
    assert foo.test()
    assert foo.test2()
    assert foo.test3()

# Generated at 2022-06-23 14:17:57.185360
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class callback_test_class:
        lock = None
        callback_lock_attr = None

        def __init__(self):
            self.lock = lock
            self.callback_lock_attr = lock

        @lock_decorator(attr='_callback_lock')
        def send_callback1(self):
            return self._callback_lock

        @lock_decorator(lock=lock)
        def send_callback2(self):
            return lock

        @lock_decorator(attr='callback_lock_attr')
        def send_callback3(self):
            return self.callback_lock_attr

    ctc = callback_test_class()

    # This should succeed if the lock is acquired
    assert ctc.send_callback1() is lock

# Generated at 2022-06-23 14:18:07.094775
# Unit test for function lock_decorator
def test_lock_decorator():
    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator
        def test_method(self):
            with self._lock:
                return True

        @lock_decorator(lock=self._lock)
        def test_method_2(self):
            with self._lock:
                return True

        @lock_decorator(attr='_lock')
        def test_method_3(self):
            with self._lock:
                return True

    t = Test()
    assert t.test_method()
    assert t.test_method_2()
    assert t.test_method_3()

# Generated at 2022-06-23 14:18:18.119411
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    
    lock = threading.Lock()
    
    class Test(object):
        
        def __init__(self):
            self.called = 0
            self.lock = threading.Lock()
            
        @lock_decorator(lock=lock)
        def using_lock(self):
            self.called += 1
            time.sleep(1)
            
        @lock_decorator(attr='lock')
        def using_lock_attr(self):
            self.called += 1
            time.sleep(1)
            
    t = Test()
    t.using_lock()
    assert t.called == 1
    t.using_lock_attr()
    assert t.called == 2

# Generated at 2022-06-23 14:18:28.590848
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import unittest

    class TestLock(unittest.TestCase):
        def setUp(self):
            self._lock = threading.Lock()
            self._x = 0
            self._y = 0
            self._lock_attr_x = threading.Lock()
            self._lock_attr_y = threading.Lock()

        @lock_decorator(lock=self._lock)
        def test_x(self):
            time.sleep(1)
            self._x = 1

        @lock_decorator(lock=self._lock)
        def test_y(self):
            time.sleep(1)
            self._y = 1


# Generated at 2022-06-23 14:18:37.565059
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, local, Thread

    _data = local()
    _data.test_results = []

    class TestClass(object):
        _test_lock = Lock()

        @lock_decorator()
        def no_lock(self):
            # should always fail, as there is no lock
            _data.test_results.append(True)

        @lock_decorator(attr='_test_lock')
        def attr_lock(self):
            # should only fail 1/3 the time
            _data.test_results.append(True)

        @lock_decorator(lock=Lock())
        def explicit_lock(self):
            # should only fail 1/3 the time
            _data.test_results.append(True)

    # if the lock decorator works as advertised, we should expect


# Generated at 2022-06-23 14:18:45.065463
# Unit test for function lock_decorator
def test_lock_decorator():
    global bool_value
    bool_value = False
    bool_lock = threading.Lock()

    class TestClass(object):
        def __init__(self, global_lock=None):
            self._lock = global_lock or threading.Lock()

        @lock_decorator(lock=bool_lock)
        def set_bool(self):
            global bool_value
            bool_value = True

        @lock_decorator(attr='_lock')
        def set_bool_global(self):
            global bool_value
            bool_value = True

    # Test Class.set_bool
    threads = []
    for i in range(100):
        threads.append(threading.Thread(target=TestClass().set_bool))
    for t in threads:
        t.start()

# Generated at 2022-06-23 14:18:52.607772
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def method(self, x):
            return x

        @lock_decorator(lock=threading.Lock())
        def method2(self, x):
            return x

        @lock_decorator(attr='missing_lock_attr')
        def method3(self, x):
            return x

    test_inst = Test()
    assert test_inst.method(1) == 1
    assert test_inst.method2(2) == 2
    try:
        test_inst.method3(3)
    except AttributeError:
        pass
    else:
        raise Exception('test_lock_decorator failed')

# Generated at 2022-06-23 14:19:02.790749
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class AClass(object):
        def __init__(self):
            self.a = 0
            self.b = 0
            # Explicitly define lock for attribute ``a``
            self._a_lock = threading.Lock()
            # Implicitly define lock for attribute ``b``
            self._b_lock = threading.Lock()

        @lock_decorator(attr='_a_lock')
        def increment_a(self, sleep=0):
            time.sleep(sleep)
            self.a += 1

        @lock_decorator(lock=self._b_lock)
        def increment_b(self, sleep=0):
            time.sleep(sleep)
            self.b += 1

    a = AClass()


# Generated at 2022-06-23 14:19:11.662315
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    import pytest

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self._counter += 1

        @lock_decorator(lock=threading.Lock())
        def decrement(self):
            self._counter -= 1

    foo = Foo()

    foo.increment()
    assert foo._counter == 1
    foo.decrement()

    def test_threads():
        foo.increment()
        foo.decrement()

    for i in range(500):
        t = threading.Thread(target=test_threads)
        t.start()

    foo.increment()

# Generated at 2022-06-23 14:19:22.514874
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self, foo=None):
            self.foo = foo
            self._callback_lock = threading.Lock()
            self.bar = 2

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, arg):
            self.foo = arg

        @lock_decorator(lock=threading.Lock())
        def some_method(self, arg):
            return self.bar + arg

    t = Test()
    assert t.foo is None
    assert t.some_method(42) == 44
    assert t.foo is None
    t.send_callback(42)
    assert t.foo == 42

    class Test2(object):
        def __init__(self, foo=None):
            self.foo

# Generated at 2022-06-23 14:19:31.183987
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class C(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self._counter += 1

        def __repr__(self):
            return "{0}({1})".format(type(self).__name__, self._counter)

    class D(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(lock=self._lock)
        def increment(self):
            self._counter += 1

        def __repr__(self):
            return "{0}({1})".format(type(self).__name__, self._counter)

   

# Generated at 2022-06-23 14:19:43.249139
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo():
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def some_method(self):
            # calls on self._callback_lock should be OK
            # but calls on self.missing_lock_attr should fail
            try:
                self._callback_lock.acquire()
            except AttributeError:
                assert False, 'Threading lock not installed on the object'

    foo = Foo()
    assert foo.some_method() is None

    class Foo():
        def __init__(self):
            self._callback_lock = threading.Lock()


# Generated at 2022-06-23 14:19:51.919047
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()
    _flag = False
    _times = 0

    class TestLock(threading.Thread):
        def __init__(self, lock):
            threading.Thread.__init__(self)
            self.lock = lock

        @lock_decorator(lock=_lock)
        def run(self):
            global _times
            _times += 1
            with self.lock:
                global _flag
                if _flag:
                    _times = 0
                _flag = True

    test_threads = [TestLock(_lock) for x in xrange(10)]
    for test_thread in test_threads:
        test_thread.start()
    for test_thread in test_threads:
        test_thread.join()

    assert _times == 1


# Generated at 2022-06-23 14:20:03.686363
# Unit test for function lock_decorator
def test_lock_decorator():
    class Foo(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.attr = 10
            self.attr_lock = threading.Lock()

        @lock_decorator(lock=self.lock)
        def lock_method(self):
            self.attr += 1
            return self.attr

        @lock_decorator(attr='attr_lock')
        def attr_lock_method(self):
            self.attr += 1
            return self.attr

    # Instantiate a class and a lock object
    foo = Foo()
    lock = threading.Lock()

    # Set up a list of arguments
    args = [foo, lock]

    # Test that the method is properly locked

# Generated at 2022-06-23 14:20:09.307605
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, arg):
            return arg + 1

        @lock_decorator(lock=threading.Lock())
        def increment_and_return(self, arg):
            self.arg = arg + 1
            return self.arg

    t = Test()
    assert t.send_callback(1) == 2

    t.increment_and_return(1)
    assert t.arg == 2

# Generated at 2022-06-23 14:20:21.543242
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._cb_values = [0]

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, val):
            self._cb_values.append(val)

        @lock_decorator()
        def missing_lock_attr(self, val):
            self._cb_values.append(val)

        @lock_decorator(lock=threading.Lock())
        def with_lock_arg(self, val):
            self._cb_values.append(val)

    # Defaults
    test = Test()
    test.send_callback(1)
    assert test._cb_values == [0, 1]

    # Missing attr

# Generated at 2022-06-23 14:20:32.819451
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class MyClass(object):
        def __init__(self):
            self.count = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.count += 1

        @lock_decorator(lock=threading.Lock())
        def decrement(self):
            self.count -= 1

    def run(mc):
        # Increment count as fast as possible.
        # Have it cound from 0 to 100,000
        for i in range(0, 100000):
            mc.increment()

    def run2(mc):
        # Decrement count as fast as possible.
        # Have it count from 100,000 to 0
        for i in range(0, 100000):
            mc.dec

# Generated at 2022-06-23 14:20:42.025733
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class TestClass(object):
        def __init__(self):
            self.x = 0
            self.lock = lock

        @lock_decorator(attr='lock')
        def inc_x(self, num):
            self.x += num

        @lock_decorator()
        def inc_x_no_lock(self, num):
            self.x += num

        @lock_decorator(lock=lock)
        def inc_x_lock(self, num):
            self.x += num

    tc = TestClass()

    # Test if the lock works
    for _ in range(10):
        tc.inc_x(1)
    assert tc.x == 10

    # Ensure the no lock decorator works and doesn't lock

# Generated at 2022-06-23 14:20:47.734895
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class UnitTest:
        def __init__(self):
            self.lock = threading.Lock()
            self.attr_lock = threading.Lock()
            self.count = 0
            self.attr_count = 0

        @lock_decorator(attr='attr_lock')
        def test_attr(self):
            self.attr_count += 1
            return self.attr_count

        @lock_decorator(lock=self.lock)
        def test_lock(self):
            self.count += 1
            return self.count

    t = UnitTest()
    t.lock.acquire()

    def run_test_attr():
        assert t.test_attr() == 1

    def run_test_lock():
        assert t.test_lock() == 1

    threading.Thread

# Generated at 2022-06-23 14:20:55.559613
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Example(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def locked(self, *args, **kwargs):
            return args, kwargs

    e1 = Example()
    assert e1.locked('foo', bar='baz')

    class Example2(object):
        _lock = threading.Lock()

        @lock_decorator(lock=_lock)
        def locked(self, *args, **kwargs):
            return args, kwargs

    e2 = Example2()
    assert e2.locked('foo', bar='baz')

# Generated at 2022-06-23 14:21:04.899925
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()
    _list = []
    _list2 = []

    # first use a pre-defined lock
    @lock_decorator(attr='_lock')
    def _add_to_list(self, lst):
        lst.append(1)

    @lock_decorator(attr='_lock')
    def _add_two_to_list(self, lst):
        lst.append(1)
        lst.append(1)

    class MyClass(object):
        _lock = _lock

        def send_callback(self):
            _add_to_list(self, _list)

        def send_two_callbacks(self):
            _add_two_to_list(self, _list)

    # now use a lock passed to

# Generated at 2022-06-23 14:21:11.387343
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):

        def __init__(self):
            self._lock = None
            #self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test_method(self, *args, **kwargs):
            print("foo")

    t = TestClass()

    # foo should be printed twice
    t.test_method()
    t.test_method()

    # foo should be printed once
    t._lock = threading.Lock()
    t.test_method()
    t.test_method()

# Generated at 2022-06-23 14:21:22.686635
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    mylock = threading.Lock()
    lock_attr = 'mylock'

    class Foo(object):
        def __init__(self, attr):
            setattr(self, lock_attr, attr)

        @lock_decorator(attr=lock_attr)
        def attr_single_arg(self):
            return 'single_arg'

        @lock_decorator(lock=mylock)
        def lock_single_arg(self):
            return 'single_arg'

        @lock_decorator(attr=lock_attr)
        def attr_multi_arg(self, arg1, arg2, arg3):
            return arg1, arg2, arg3


# Generated at 2022-06-23 14:21:26.251668
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    num = 0

    @lock_decorator(lock=lock)
    def test(a, b, c=None):
        global num
        num += (a + b + c)

    test(1, 2, 3)
    assert num == 6
    test(1, 2)
    assert num == 9

# Generated at 2022-06-23 14:21:37.276807
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading

    class FakeClass(object):
        def __init__(self):
            self.payload = 0
            self.callback_lock = threading.Lock()

        @lock_decorator(attr='callback_lock')
        def increment_payload(self):
            self.payload += 1
            return self.payload

    class FakeClassWithoutAttr(object):
        def __init__(self):
            self.payload = 0
            self.callback_lock = threading.Lock()

        @lock_decorator(lock=self.action_lock)
        def increment_payload(self):
            self.payload += 1
            return self.payload

    thread_actions = []
    thread_payloads = []

    def thread_action(fake_obj):
        thread

# Generated at 2022-06-23 14:21:44.397508
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class A(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callbacks = []
            self._send_lock = threading.Lock()
            self._send_count = 0

        @lock_decorator(attr='_callback_lock')
        def add_callback(self, callback):
            self._callbacks.append(callback)

        @lock_decorator(lock=threading.Lock())
        def send_callback(self, arg):
            for callback in self._callbacks:
                callback(arg)

        @lock_decorator(attr='_send_lock')
        def send_data(self, data):
            self._send_count += 1
            return


# Generated at 2022-06-23 14:21:54.965759
# Unit test for function lock_decorator
def test_lock_decorator():
    import uuid
    import copy
    import threading
    import time

    class X(object):
        _lock = threading.Lock()
        _payload = []

        @lock_decorator(attr='_lock')
        def append_to_payload(self, value):
            self._payload.append(value)

        def get_payload(self):
            return copy.copy(self._payload)

    class Y(object):
        _lock = threading.Lock()

        @lock_decorator(lock=_lock)
        def set_uuid(self, payload):
            self._payload = payload

        def get_uuid(self):
            return copy.copy(self._payload)


# Generated at 2022-06-23 14:22:00.812403
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass(object):
        def __init__(self, lock_attr='_callback_lock'):
            self._callback_lock = threading.Lock()
            self._callback_lock.acquire()
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, msg):
            print(msg)
    tc = TestClass()
    tc.send_callback('Hello World!')

# Generated at 2022-06-23 14:22:11.842299
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Example(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0
        @lock_decorator(attr='_lock')
        def increment_and_decrement(self):
            self.counter += 1
            time.sleep(0.2)
            self.counter -= 1
        @lock_decorator(lock=threading.Lock())
        def increment_and_double(self):
            self.counter += 1
            time.sleep(0.1)
            self.counter *= 2

    e = Example()

    # Test that increment_and_decrement is thread-safe
    threads = []

# Generated at 2022-06-23 14:22:20.383637
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import time

    class TestLockDecorator(unittest.TestCase):
        def test_lock_decorator_with_explicit_lock(self):
            lock = threading.Lock()
            self.assertFalse(lock.acquire(blocking=False))
            @lock_decorator(lock=lock)
            def do_something():
                time.sleep(.1)
            do_something_threads = [
                threading.Thread(target=do_something)
                for x in range(3)
            ]
            for t in do_something_threads:
                t.start()
            for t in do_something_threads:
                t.join()
            self.assertFalse(lock.acquire(blocking=False))


# Generated at 2022-06-23 14:22:30.688511
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLockDecorator(object):
        def __init__(self):
            self._lock_me = threading.Lock()
    # Function _test_lock_dec_func1 is wrapped with lock_decorator
    # and uses the defined _lock_me as the lock
    # Function _test_lock_dec_func2 is wrapped with lock_decorator
    # and uses an explicit lock
    # We want both functions to raise an exception as soon as they are
    # called without lock held
    # On the other hand, if a lock is held, both functions should
    # successfully run and return a tuple
    def _test_lock_dec_func1(self):
        return (self, '1')
    def _test_lock_dec_func2(self):
        return (self, '2')

    obj1 = Test

# Generated at 2022-06-23 14:22:41.124272
# Unit test for function lock_decorator
def test_lock_decorator():

    try:
        import threading
    except ImportError:
        print('Skipping test_lock_decorator, threading not available')
        return

    import time

    class NoLock(object):
        def __enter__(self):
            pass

        def __exit__(self, *args):
            pass


    class Lock(object):
        def __init__(self, acquire=True):
            self.lock = threading.Lock()
            if acquire:
                self.lock.acquire()

        def release(self):
            self.lock.release()

        def __enter__(self):
            return self.lock.__enter__()

        def __exit__(self, *args):
            return self.lock.__exit__(*args)



# Generated at 2022-06-23 14:22:51.731422
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    shared_counter = [0]
    lock = threading.Lock()

    def foo():
        with lock:
            shared_counter[0] = shared_counter[0] + 1
            time.sleep(0.05)

    def test_threaded(fn, attempts=20, threads=2):
        threads = [threading.Thread(target=fn) for _ in range(threads)]
        [t.start() for t in threads]
        [t.join() for t in threads]

        assert shared_counter[0] == attempts

    def test():
        shared_counter[0] = 0
        test_threaded(foo)
        print("Done decorated")
        shared_counter[0] = 0
        test_threaded(foo)
        print("Done non-decorated")

# Generated at 2022-06-23 14:23:02.491105
# Unit test for function lock_decorator
def test_lock_decorator():
    from random import Random

    from threading import Event, Lock, Thread

    class TestLockDecorator(object):

        def __init__(self, seed=None):
            if seed is None:
                seed = Random().randint(1, 1000)
            self.rng = Random(seed)
            self.results = []
            self.event = Event()
            self.lock = Lock()

        @lock_decorator(attr='lock')
        def wrapped_method(self, value):
            self.results.append(value)
            self.rng.randint(1, 1000)

        def wrapper(self):
            while not self.event.is_set():
                self.wrapped_method(self.rng.randint(1, 1000))

        def test_lock(self):
            threads = []

# Generated at 2022-06-23 14:23:11.340644
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestObj(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.count = 0

        @lock_decorator('_lock')
        def incr_count(self):
            self.count += 1

        @lock_decorator(lock=threading.Lock())
        def incr_count_two(self):
            self.count += 1

    my_obj = TestObj()
    my_obj.incr_count()
    assert my_obj.count == 1

    my_obj.incr_count_two()
    assert my_obj.count == 2

# Generated at 2022-06-23 14:23:17.210429
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        _lock = threading.Lock()
        @lock_decorator('_lock')
        def test_method(self):
            return True
    assert Test().test_method() is True

    class Test(object):
        @lock_decorator(lock=threading.Lock())
        def test_method(self):
            return True
    assert Test().test_method() is True

# Generated at 2022-06-23 14:23:26.319636
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Dummy(object):
        '''Dummy class that contains threading.Lock() attr'''

        def __init__(self):
            self._lock = threading.Lock()

    class Dummy2(object):
        '''Dummy class that doesn't contain threading.Lock() attr'''
        pass

    @lock_decorator(attr='_lock')
    def dummy(self):
        self.lock_var = True

    @lock_decorator(lock=threading.Lock())
    def dummy_kwargs(lock=None):
        if lock is not None:
            self.lock_var = True

    obj1 = Dummy()
    dummy(obj1)
    assert obj1.lock_var is True
    obj2 = Dummy2()
    dummy(obj2)

# Generated at 2022-06-23 14:23:33.155882
# Unit test for function lock_decorator
def test_lock_decorator():
    class Test:
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.check = 0

        @lock_decorator(attr='_callback_lock')
        def append(self, val):
            self.check += 1

        @lock_decorator(lock=threading.Lock())
        def append(self, val):
            self.check += 1

        def get_check(self):
            return self.check



# Generated at 2022-06-23 14:23:42.827223
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    l = threading.Lock()
    class TestClass(object):
        def __init__(self):
            self.l = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='l')
        def test1(self):
            self.counter += 1

        @lock_decorator(lock=l)
        def test2(self):
            self.counter += 10

    tc = TestClass()
    tc.test1()
    assert tc.counter == 1

    tc.test2()
    assert tc.counter == 11

test_lock_decorator()

# Generated at 2022-06-23 14:23:48.467220
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class TestClass(object):
        def __init__(self):
            self._lock = lock
        @lock_decorator(attr='_lock')
        def method(self):
            return self._lock

    t = TestClass()

    def test_with_lock(l):
        with l:
            return True

    assert t.method()
    assert test_with_lock(lock)

    del TestClass.method
    setattr(TestClass, 'method', lock_decorator(lock=lock)(lambda self: self._lock))
    assert t.method()

# Generated at 2022-06-23 14:23:57.689936
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread

    class A(object):

        def __init__(self):
            self._lock = Lock()
            self.l = list()
            self.i = 0

        @lock_decorator()
        def foo(self):
            print('foo')
            self.l.append(1)

        @lock_decorator(attr='_lock')
        def bar(self):
            print('bar')
            self.l.append(2)

    def run_threads(func):
        def wrap(*args, **kwargs):
            def _run(func, *args, **kwargs):
                for _ in range(10):
                    func(*args, **kwargs)

            threads = list()

# Generated at 2022-06-23 14:24:07.911638
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading

    global lock_decorator_output
    lock_decorator_output = []

    class thingA(object):
        def __init__(self, *args, **kwargs):
            self._lock = threading.Lock()
            super(thingA, self).__init__(*args, **kwargs)

        @lock_decorator(attr='_lock')
        def do_thing(self, *args, **kwargs):
            lock_decorator_output.append(self.__class__.__name__)
            return (args, kwargs)

    class thingB(object):
        lock = threading.Lock()

        @lock_decorator(lock=lock)
        def do_thing(self, *args, **kwargs):
            lock_decorator_

# Generated at 2022-06-23 14:24:15.073132
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    lock = threading.Lock()
    value = 0

    @lock_decorator(lock=lock)
    def thread_target():
        global value
        value += 1
        time.sleep(0.5)
        value += 1

    threads = []
    for x in range(0, 5):
        threads.append(threading.Thread(target=thread_target))
        threads[-1].start()

    for thread in threads:
        thread.join()

    assert value == 10

# Generated at 2022-06-23 14:24:25.612583
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self._counter += 1

    t = Test()
    t.increment()
    assert t._counter == 1

    # Make sure that using a lock that doesn't define ``__enter__`` works
    # Not sure if this is a valid test or not, but it works
    class Test(object):
        def __init__(self):
            self._lock = threading.RLock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self._counter += 1

    t = Test()
    t.increment()

# Generated at 2022-06-23 14:24:34.283168
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Lock, Event
    from time import sleep

    class TestClass:
        def __init__(self):
            self.flag = 0
            self.event = threading.Event()
            self.lock = Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.flag += 1

        @lock_decorator(lock=Lock())
        def wait(self):
            self.event.wait()

    test = TestClass()

    def increment(obj):
        obj.increment()
        return

    def wait(obj):
        obj.wait()
        return

    def run():
        t1 = threading.Thread(target=increment, args=(test, ))

# Generated at 2022-06-23 14:24:45.837257
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    class Test(object):
        '''Object to use for testing object/instance attribute'''
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def method_one(self):
            '''Wrapped method'''
            # We expect lock to be held
            assert lock.locked() is True

        @lock_decorator(lock=lock)
        def method_two(self):
            '''Wrapped method'''
            # We expect lock to be held
            assert lock.locked() is True

    # call our method with an instance of Test
    t = Test()

    # lock should not be held
    assert lock.locked() is False
    assert t._callback_

# Generated at 2022-06-23 14:24:52.830804
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    import time

    class Example(object):
        def __init__(self, name):
            # Create the lock associated with this object
            self._lock = Lock()
            self.name = name

        # Create an instance method that uses the lock
        @lock_decorator(attr='_lock')
        def log(self, msg):
            print('[{}, {}] {}'.format(self.name, time.time(), msg))

    class Test(Thread):
        def __init__(self, example, msg, *args, **kwargs):
            self.example = example
            self.msg = msg
            super(Test, self).__init__(*args, **kwargs)

        def run(self):
            # Have the thread use the instance method that uses the lock
            self.example.log

# Generated at 2022-06-23 14:25:02.615234
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def func(*args, **kwargs):
        '''Function that should be wrapped with a lock'''
        print(args)
        print(kwargs)

    func(1, 2, 3, four=4, five=5)

    class Test(object):
        @lock_decorator(attr='_lock')
        def __init__(self, *args, **kwargs):
            self._lock = threading.Lock()
            print(args)
            print(kwargs)

    Test(1, 2, 3, four=4, five=5)

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:25:10.108338
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            # Create the lock
            self.attribute_lock = threading.Lock()

        @lock_decorator(attr='attribute_lock')
        def method_1(self):
            print('I am in method_1')
            time.sleep(1)

        @lock_decorator(lock=threading.Lock())
        def method_2(self):
            print('I am in method_2')
            time.sleep(1)

    tc = TestClass()

    # Create 2 threads
    t1 = threading.Thread(target=tc.method_1)
    t2 = threading.Thread(target=tc.method_2)

    # Start the threads
    t1.start()
    t2.start

# Generated at 2022-06-23 14:25:14.476219
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Example(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            pass

    e = Example()
    e.send_callback()

# Generated at 2022-06-23 14:25:24.779065
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for function lock_decorator'''
    from threading import Thread, Lock
    from time import sleep

    lock = Lock()
    lock_attr = Lock()

    class TestLockDecorator(object):
        '''Class to test the lock_decorator function'''

        def __init__(self):
            self.missing_lock_attr = Lock()

        @lock_decorator()
        def no_lock_or_attr(self):
            '''Test locking with no lock or attr'''
            return True

        @lock_decorator(lock=lock)
        def lock_provided(self):
            '''Test locking with explicitly provided lock object'''
            return True


# Generated at 2022-06-23 14:25:28.326895
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    args = []
    kwargs = []

    @lock_decorator(attr='_non_existing_lock_attr')
    def some_method(x, y):
        args.append(x)
        kwargs.append(y)

    import pytest
    with pytest.raises(AttributeError):
        some_method(1, y=2)

    lock = threading.Lock()
    some_method = lock_decorator(lock=lock)(some_method)

    some_method(3, y=4)

    assert args == [3]
    assert kwargs == [4]

# Generated at 2022-06-23 14:25:38.830576
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def foo(self):
            self._calls += 1

    c = Test()
    c._calls = 0

    def do_func():
        c.foo()
        c.foo()

    threads = []
    for i in range(100):
        t = threading.Thread(target=do_func)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    # We should have called ``foo`` 200 times
    # even though we were running 100 threads
    assert c._calls == 200

# Generated at 2022-06-23 14:25:48.071585
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    class Test():
        def __init__(self):
            # Used by lock_decorator
            self.callback_lock = threading.Lock()
            # Manually used
            self.event_lock = threading.Lock()
            # Used by lock_decorator with explicit lock assignment
            self.explicit_lock = threading.Lock()
            self.done = False
            self.calls = 0
            self.calls2 = 0
            self.calls3 = 0

        @lock_decorator(attr='callback_lock')
        def send_callback(self, *args, **kwargs):
            print('Sending callback')
            time.sleep(1)
            self.done = True
            return True


# Generated at 2022-06-23 14:25:56.206203
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Test with an attribute
    class Test:
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test(self, name):
            return name + '!'

    t = Test()
    assert t.test('test') == 'test!'

    # Test with a lock object
    _lock = threading.Lock()

    @lock_decorator(lock=_lock)
    def test(name):
        return name + '!'

    assert test('test') == 'test!'


# Generated at 2022-06-23 14:26:04.974963
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    self_lock = threading.Lock()
    def do_work():
        pass

    class TestClass(object):
        def __init__(self):
            self._lock_attr = self_lock

        @lock_decorator(attr='_lock_attr')
        def work_method(self):
            return do_work()

        @lock_decorator(lock=threading.Lock())
        def work_method_explicit(self):
            return do_work()

    print('Testing lock_decorator with instance attribute')
    tc = TestClass()
    print('Locking')
    with self_lock:
        print('Testing...')
        assert tc.work_method() is None
    print('Done')

    print('Testing lock_decorator with explicit lock')
    tc = TestClass

# Generated at 2022-06-23 14:26:15.016589
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass(object):
        def __init__(self):
            self._attr_lock = threading.Lock()

        @lock_decorator(attr='_attr_lock')
        def method1(self, value):
            return 'method1', value

        @lock_decorator(lock=threading.Lock())
        def method2(self, value):
            return 'method2', value
    class TestClass2(object):
        def __init__(self):
            self._attr_lock = threading.Lock()

        @lock_decorator()
        def method1(self, value):
            return 'method1', value
    tc = TestClass()
    assert tc.method1('value') == ('method1', 'value')

# Generated at 2022-06-23 14:26:22.618975
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class TestCase(object):
        def __init__(self):

            # Create a lock
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def do_stuff(self):
            # Lock was acquired if this function executes without error
            self.do_stuff_called = True

    test = TestCase()

    # Threading makes this slightly more "interesting"
    class TestThread(threading.Thread):
        def __init__(self, testcase):
            super(TestThread, self).__init__()
            self.testcase = testcase

        def run(self):
            self.testcase.do_stuff()

    thread = TestThread(test)
    thread.start()
    thread.join()

# Generated at 2022-06-23 14:26:28.419356
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self.pony = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def pony_up(self):
            self.pony += 1
            return self.pony

    f = Foo()
    assert f.pony_up() == 1
    assert f.pony_up() == 2
    assert f.pony_up() == 3

    f._lock = None
    assert f.pony_up() is None


    class Bar(object):
        def __init__(self):
            self.pony = 0
            self._lock = threading.Lock()


# Generated at 2022-06-23 14:26:39.993135
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Executes unit test for lock_decorator decorator'''
    import threading

    plugin_counter = 0

    def increment_counter():
        '''Increments the global counter'''
        global plugin_counter
        plugin_counter += 1

    class TestClass(object):
        '''Creates a test class to test the lock_decorator'''

        # Use a lock attribute
        lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment_counter_method(self):
            '''Class method that increments the global counter'''
            increment_counter()

    # Use a lock varaible
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def increment_counter_function():
        '''Function that increments the global counter'''


# Generated at 2022-06-23 14:26:51.787227
# Unit test for function lock_decorator
def test_lock_decorator():
    class Decorated:
        def __init__(self):
            self.a = 0
            self.b = 0

        @lock_decorator(attr='lock')
        def dec_one(self, a):
            self.a += a

        @lock_decorator(lock=threading.Lock())
        def dec_two(self, b):
            self.b += b

    dec = Decorated()

    def test(a, b, expected_a, expected_b):
        assert dec.a == expected_a
        assert dec.b == expected_b

    dec.dec_one(1)
    dec.dec_two(1)
    test(1, 1, 1, 1)

    dec.dec_one(1)
    test(2, 1, 2, 1)

    dec.dec_

# Generated at 2022-06-23 14:26:58.390285
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Thing:
        def __init__(self):
            self._lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def foo(self, val):
            return val * 2
    t = Thing()
    assert t.foo(2) == 4
    assert t.foo(10) == 20
    assert t.foo(0) == 0

# Generated at 2022-06-23 14:27:08.607032
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class A(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

    class B(object):
        def __init__(self):
            self._value = 0

    @lock_decorator(attr='_lock')
    def update(self):
        # You would expect this to always return 1
        # but without the lock, it would sometimes return 2
        self._value += 1
        return self._value

    @lock_decorator(lock=threading.Lock())
    def update2(self):
        # You would expect this to always return 1
        # but without the lock, it would sometimes return 2
        self._value += 1
        return self._value


# Generated at 2022-06-23 14:27:16.661529
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class StupidClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.list = []

        @lock_decorator()
        def wait(self, item):
            time.sleep(0.1)
            self.list.append(item)

        @lock_decorator(attr='_lock')
        def wait2(self, item):
            time.sleep(0.1)
            self.list.append(item)

        @lock_decorator(lock=threading.Lock())
        def wait3(self, item):
            time.sleep(0.1)
            self.list.append(item)

    inst = StupidClass()


# Generated at 2022-06-23 14:27:25.705144
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import pytest

    lock1 = threading.Lock()
    lock2 = threading.Lock()

    @lock_decorator(lock=lock1)
    def method1(value):
        time.sleep(0.5)
        return value

    @lock_decorator(lock=lock2)
    def method2(value):
        time.sleep(0.5)
        return value

    assert method1(1) == 1  # Make sure we're not doing anything weird
    assert method2(2) == 2
    assert method1.__name__ == 'method1'
    assert method2.__name__ == 'method2'

    @lock_decorator
    def attrless_method(value):
        time.sleep(0.5)
        return value
