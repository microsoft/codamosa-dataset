

# Generated at 2022-06-23 14:17:31.735845
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    l = []
    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def method(self, arg):
            l.append(arg)
    class Test2(object):
        @lock_decorator(lock=lock)
        def method(self, arg):
            l.append(arg)

    def test(func):
        t = threading.Thread(target=func, args=('one',))
        t.start()
        t.join()
        t = threading.Thread(target=func, args=('two',))
        t.start()
        t.join()

# Generated at 2022-06-23 14:17:40.048361
# Unit test for function lock_decorator
def test_lock_decorator():
    # Import here to prevent import circular errors
    from threading import Thread
    from queue import Queue
    from time import sleep

    class LockClass:
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def lock_method(self):
            self.counter += 1
            sleep(0.1)

    class LockClassDecorator:
        def __init__(self):
            self.counter = 0
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def lock_method(self):
            self.counter += 1
            sleep(0.1)

    def lock_func():
        lock_func.counter += 1
        sleep(0.1)

# Generated at 2022-06-23 14:17:50.433658
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock

    # Test with attr
    class FakeInstance(object):
        _lock = MagicMock()
        attr = '_lock'

        @lock_decorator(attr='attr')
        def method(self, *args, **kwargs):
            return

    instance = FakeInstance()
    assert instance._lock.__enter__.call_count == 0
    with patch.object(instance, 'method') as mock_method:
        instance.method('arg1', kwarg1='val1')
        mock_method.assert_called_once_with('arg1', kwarg1='val1')

    instance._lock.__enter__.assert_called_once_with()
   

# Generated at 2022-06-23 14:17:56.682304
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Test(object):
        def __init__(self, lock=None):
            self._lock = lock or threading.Lock()

        @lock_decorator(attr='_lock')
        def incr(self):
            self._count += 1

        @lock_decorator(lock=threading.Lock())
        def foo(self):
            self._count += 1

    t = Test()
    t._count = 0
    t.incr()
    t.foo()
    assert t._count == 2

# Generated at 2022-06-23 14:17:58.893035
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    lock_decorator(lock=lock)
    lock_decorator('lock')



# Generated at 2022-06-23 14:18:09.312345
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    value = 0

    class MyClass(object):
        def __init__(self):
            self.a = 7

        @lock_decorator()
        def set_value(self):
            import time
            global value
            value = self.a

        @lock_decorator(lock=lock)
        def set_value_with_lock(self):
            import time
            global value
            value = self.a

        @lock_decorator(attr='a')
        def set_value_with_attr(self):
            import time
            global value
            value = self.a
    import time

    my_obj = MyClass()

    def test_set_value():
        for i in range(5):
            my_obj.set_value()


# Generated at 2022-06-23 14:18:19.764836
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Something(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

        @lock_decorator(attr='_lock')
        def incr_value(self):
            self._value += 1
            time.sleep(0.3)
            return self._value

    obj = Something()

    def run_thread():
        obj.incr_value()

    threads = []
    for _ in range(5):
        threads.append(threading.Thread(target=run_thread))

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    assert obj._value == 5

# Generated at 2022-06-23 14:18:29.836805
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    import time

    class SomeTestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.test_attr = 0

        @lock_decorator(attr='_lock')
        def increment_test_attr(self):
            self.test_attr += 1

        @lock_decorator(lock=self._lock)
        def double_test_attr(self):
            self.test_attr *= 2

    test_obj = SomeTestClass()
    def thread_runner(func, wait_time):
        time.sleep(wait_time)
        func()

    thread0 = threading.Thread(target=thread_runner, args=(test_obj.increment_test_attr, 0.1))

# Generated at 2022-06-23 14:18:38.460550
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    lock_attr = 'some_lock'

    class Foo(object):
        def __init__(self):
            self.some_data = 0
            self.some_lock = None

        @lock_decorator(attr=lock_attr, lock=lock)
        def run(self):
            self.some_data += 1

    class Bar(object):
        def __init__(self):
            self.some_data = 0
            self.some_lock = threading.Lock()

        @lock_decorator(attr=lock_attr)
        def run(self):
            self.some_data += 1


    foo = Foo()
    bar = Bar()

    foo.run()
    assert foo.some_data == 1

    bar.run()
   

# Generated at 2022-06-23 14:18:45.971295
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    import time

    class ExampleObject(object):
        def __init__(self):
            self.my_key = 'initial'
            self.my_lock = threading.Lock()

        @lock_decorator(attr='my_lock')
        def change_key(self):
            time.sleep(1)
            self.my_key = 'changed'

    # instance of our object
    obj = ExampleObject()
    # start a thread that changes the key
    thread = threading.Thread(target=obj.change_key)
    # start the thread
    thread.start()
    # wait for the thread to start
    time.sleep(0.01)
    # check the key value
    print('Expected value:  initial')

# Generated at 2022-06-23 14:18:56.904927
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Stuff(object):
        lock = threading.Lock()
        collected = []
        collected_threadlock = []

        @lock_decorator(attr='lock')
        def lock_test(self, name):
            time.sleep(1)
            self.collected.insert(0, name)

        @lock_decorator(lock=threading.Lock())
        def threadlock_test(self, name):
            time.sleep(1)
            self.collected_threadlock.insert(0, name)

    s = Stuff()

    def lock_test_thread():
        for x in range(0, 2):
            s.lock_test('thread-%s' % x)


# Generated at 2022-06-23 14:19:03.080686
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
 
    class TestClass:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test_method(self):
            print("testing lock_decorator")
            print("end of test_method")

    t = TestClass()
    t.test_method()


if __name__ == "__main__":
    # Test the decorator
    test_lock_decorator()

# Generated at 2022-06-23 14:19:13.719353
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    class Stub(object):
        def __init__(self):
            # Create a mock for ``threading.Lock`` using a mock class
            # instead of a mock instance to ensure that ``__enter__``
            # and ``__exit__`` are called instead of ``__call__``
            self._lock = mock.Mock(spec=['__enter__', '__exit__'])

        @lock_decorator(attr='_lock')
        def stub(self):
            return 'stub'

        @lock_decorator(lock=mock.MagicMock(spec=['__enter__', '__exit__']))
        def other_stub(self):
            return 'other stub'

    stub = Stub()
    assert stub.stub() == 'stub'

# Generated at 2022-06-23 14:19:24.499512
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

        @lock_decorator(attr='_lock')
        def get_value(self):
            return self._value

        @lock_decorator(attr='_lock')
        def set_value(self, value):
            self._value = value

    def _increment(foo):
        _value = foo.get_value()
        foo.set_value(_value + 1)

    foo = Foo()
    threads = []
    for i in range(100):
        thread = threading.Thread(target=_increment, args=(foo,))
        threads.append(thread)
        thread.start()
    for t in threads:
        t.join()


# Generated at 2022-06-23 14:19:32.936431
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def some_method():
        pass

    class SomeClass(object):

        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self):
            pass

    class SomeClassWithLock(object):

        _lock = threading.Lock()

        @lock_decorator(lock=lambda: self._lock)
        def some_method(self):
            pass

    class SomeClassWithLockAttr(object):

        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self):
            pass

    # Test a standalone method

# Generated at 2022-06-23 14:19:44.610446
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import time
    import random

    class LockDecoratorTest(unittest.TestCase):
        '''Unit test for lock_decorator'''
        def setUp(self):
            self._lock = threading.Lock()
            self.count = 0

        def test_lock_decorator_uses_attribute(self):
            @lock_decorator(attr='_lock')
            def test_method(self):
                time.sleep(random.randint(0, 2))
                self.count += 1

            threads = list()
            for i in range(5):
                t = threading.Thread(target=test_method, args=(self,))
                threads.append(t)
                t.start()

            for thread in threads:
                thread.join()



# Generated at 2022-06-23 14:19:52.782631
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self.x = 0
            self.lock = threading.Lock()

        @lock_decorator()
        def test_attr(self, z=None):
            assert(self.lock.locked())
            self.x += 1
            return (self.x, z)

        @lock_decorator(lock=self.lock)
        def test_lock(self, z=None):
            assert(self.lock.locked())
            self.x += 1
            return (self.x, z)
    t = Test()
    results = []
    def tfunc():
        for i in range(10):
            results.append(t.test_attr('a'))
    threads = []

# Generated at 2022-06-23 14:20:03.724804
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class class_with_lock(object):
        _lock = threading.Lock()

        @lock_decorator()
        def method1(self, *args, **kwargs):
            print('method1 %s %s'%(args, kwargs))
            print('method1 got lock in %s'%threading.current_thread().name)
            return 'method1'

        def method2(self, *args, **kwargs):
            with self._lock:
                print('method2 %s %s'%(args, kwargs))
                print('method2 got lock in %s'%threading.current_thread().name)
            return 'method2'

    lock = threading.Lock()


# Generated at 2022-06-23 14:20:12.276568
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._lock_int = 0

        @lock_decorator(attr='_lock')
        def locked_method(self):
            self._lock_int += 1
            print('So this is locked')

    f = Foo()
    f.locked_method()
    assert f._lock_int == 1
    f.locked_method()
    assert f._lock_int == 2
    print('lock_decorator test passed')

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:20:23.201801
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from random import randint

    class Test():
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback_results = []

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, key):
            import time
            time.sleep(randint(1, 5))
            self._callback_results.append(key)

    t = Test()
    threads = []
    for i in range(50):
        threads.append(threading.Thread(target=t.send_callback, args=[i]))

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    assert len(t._callback_results) == 50
    assert len(set(t._callback_results))

# Generated at 2022-06-23 14:20:28.537760
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread

    @lock_decorator(attr='_callback_lock')
    def send_callback(self, n):
        for i in range(n):
            self.result.append(i)

    class LockTest(object):
        def __init__(self):
            self._callback_lock = Lock()
            self.result = []

    lt = LockTest()
    t1 = Thread(target=send_callback, args=(lt, 10,))
    t2 = Thread(target=send_callback, args=(lt, 10,))

    t1.start()
    t2.start()
    t1.join()
    t2.join()

    lt.result.sort()

# Generated at 2022-06-23 14:20:35.931214
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self):
            return True

    test = TestClass()

    assert test.some_method()

    class OtherClass:
        @lock_decorator(lock=threading.Lock())
        def some_other_method(self):
            return True

    other = OtherClass()

    assert other.some_other_method()

# Generated at 2022-06-23 14:20:44.191204
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Counter(object):
        def __init__(self):
            self.count = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def add(self):
            self.count += 1
            time.sleep(0.1)
            self.count += 1

        @lock_decorator(lock=threading.Lock())
        def add_again(self):
            self.count += 1
        add_again = lock_decorator(lock=threading.Lock())(add_again)

    def worker(counter):
        for _ in range(100):
            counter.add()
            counter.add_again()

    counter = Counter()

# Generated at 2022-06-23 14:20:52.250960
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # Create the object we will decorate
    class TestLock(object):
        def __init__(self):
            self.count = 0
            # Create a lock as an attribute
            self._count_lock = threading.Lock()

        # Decorate our method using the object attribute we created
        @lock_decorator(attr='_count_lock')
        def increment(self):
            self.count += 1
            time.sleep(0.1)
            self.count += 1

        # Decorate a method passing a lock explicitly
        @lock_decorator(lock=threading.Lock())
        def decrement(self):
            self.count -= 1

    # Create instance
    tl = TestLock()

    def test_increment():
        for i in range(100):
            t

# Generated at 2022-06-23 14:21:02.225804
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # These need to be non-local in order for threads to read/write
    # them via the thread's target function
    test_val = []
    thread_done = False

    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def thread_target():
        """Runs inside threads created in the main thread in
        parallel with the main thread.

        The two threads (main and the two created in the main
        thread) will interleave their calls to this function
        because of the lock in lock_decorator.
        """
        # Globals ``test_val`` and ``thread_done`` need to be
        # explicitly declared non-local
        global test_val, thread_done
        test_val.append(1)
        time.sleep(0.1)

# Generated at 2022-06-23 14:21:12.060086
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    test_lock = threading.Lock()

    class Foo:
        def __init__(self):
            self._foo_lock = threading.Lock()

        @lock_decorator(attr='_foo_lock')
        def foo(self):
            print(threading.current_thread().name)

        @lock_decorator(lock=test_lock)
        def bar(self):
            print(threading.current_thread().name)

    @lock_decorator(lock=test_lock)
    def baz():
        print(threading.current_thread().name)

    foo = Foo()
    threads = []
    for i in range(1000):
        # Use a different lock for each thread
        thread = threading.Thread(target=foo.foo)
        thread.start()


# Generated at 2022-06-23 14:21:17.228246
# Unit test for function lock_decorator
def test_lock_decorator():
    # If this fails, you should see an exception with a message
    # that the _callback_lock attribute is missing.
    class TestLock(object):

        def __init__(self):
            self._callback_lock = 'This is not a lock'

    test = TestLock()
    assert test._callback_lock == 'This is not a lock'


# Generated at 2022-06-23 14:21:26.319026
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
        Test the lock_decorator

        The test is simple, set the global variable __test_lock_decorator__
        to 0, then lock it and increment it.
        At the end, check the value and see if it is indeed incremented.
        If the check fails, raise an AssertionError

        :return: None
    '''
    __test_lock_decorator__ = 0

    @lock_decorator(lock=threading.Lock())
    def test_lock_decorator_function():
        global __test_lock_decorator__
        __test_lock_decorator__ = __test_lock_decorator__ + 1

    threads = []
    for _ in range(50):
        t = threading.Thread(target=test_lock_decorator_function)
       

# Generated at 2022-06-23 14:21:37.275848
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    from queue import Queue
    from threading import Thread
    from types import MethodType

    # Create a class that has already had the lock decorator applied
    @lock_decorator(attr='_q')
    class Threadable(object):
        def __init__(self, queue):
            self._q = queue
            self._lock = threading.Lock()

        def _current_thread_name(self):
            return threading.current_thread().name

        def _put(self, value):
            self._q.put(value)

        @lock_decorator(attr='_lock')
        def __call__(self):
            self._put(self._current_thread_name())

        def _put_lock(self, value):
            with self._lock:
                self._put

# Generated at 2022-06-23 14:21:47.164746
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._is_locked = False

        def lock(self):
            with self._lock:
                self._is_locked = True

        def unlock(self):
            with self._lock:
                self._is_locked = False

        def is_locked(self):
            return self._is_locked

        @lock_decorator(attr='_lock')
        def action(self):
            return self.is_locked()

    test_obj = TestClass()
    assert not test_obj.action()

    # Assert decorator passes kwargs
    def kwarg_test(arg1, arg2):
        return arg1, arg2

    assert (1, 2) == lock_dec

# Generated at 2022-06-23 14:21:58.089268
# Unit test for function lock_decorator
def test_lock_decorator():
    from types import FunctionType
    from threading import Thread, Lock
    from time import sleep

    # We have a few possible error cases, most of those are too difficult
    # to cover with a unit test so let's make it as easy as possible to
    # fail the test if a problem occurs
    class Error(Exception):
        pass


# Generated at 2022-06-23 14:22:06.301399
# Unit test for function lock_decorator
def test_lock_decorator():
    import copy
    import json
    import mock
    import threading
    import time

    # Create a class to wrap
    class MyClass(object):
        def __init__(self):
            self.data = dict()
            self.callback_data = copy.deepcopy(self.data)
            self.check_key_lock = threading.Lock()
            self.callback_lock = threading.Lock()

        def __getitem__(self, key):
            with self.check_key_lock:
                try:
                    return self.data[key]
                except KeyError:
                    return None

        def __contains__(self, key):
            with self.check_key_lock:
                return key in self.data


# Generated at 2022-06-23 14:22:17.490192
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys

    class Server:
        '''Tests the @lock_decorator decorator'''
        def __init__(self):
            import threading
            self._callback_lock = threading.Lock()
            self._callbacks = {}

        @lock_decorator(attr='_callback_lock')
        def register_callback(self, event, callback):
            self._callbacks[event] = callback

        @lock_decorator(attr='_callback_lock')
        def notify_callbacks(self, event):
            for cb in self._callbacks.values():
                cb(event)

        # A decorator cannot be used as an instance attribute.
        # see https://bugs.python.org/issue17094

# Generated at 2022-06-23 14:22:28.494870
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    import time
    class SomeClass(object):
        def __init__(self):
            self.my_list = list()
        @lock_decorator(attr='_callback_lock')
        def add_to_list(self, value):
            time.sleep(random.randint(1,10))
            self.my_list.append(value)
    myclass = SomeClass()
    myclass.add_to_list(1)
    myclass.add_to_list(2)
    myclass.add_to_list(3)
    myclass.add_to_list(4)
    assert myclass.my_list == [1,2,3,4]
    assert 'add_to_list' in dir(myclass)

# Generated at 2022-06-23 14:22:37.586381
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self._some_lock = threading.Lock()
            self._some_other_lock = threading.Lock()


        @lock_decorator(lock=self._some_lock)
        def test_lock(self, x):
            return x


        @lock_decorator(attr='_some_other_lock')
        def test_attr(self, x):
            return x


    instance = TestClass()
    assert instance.test_lock(1) == 1
    assert instance.test_attr(1) == 1

# Generated at 2022-06-23 14:22:41.742733
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class ExampleClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            pass
    ec = ExampleClass()
    assert hasattr(ec, 'send_callback')



# Generated at 2022-06-23 14:22:52.245623
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock

    class testobj(object):

        def __init__(self):
            self.lock = Lock()
            self.value = 0

        @lock_decorator()
        def testmethod(self):
            self.value += 1
            return self.value

        @lock_decorator(attr='lock')
        def testmethod2(self):
            self.value += 1
            return self.value

        @lock_decorator(lock=Lock())
        def testmethod3(self):
            self.value += 1
            return self.value

        @lock_decorator(lock=Lock())
        def testmethod4(self):
            self.value += 1
            return self.value

    test = testobj()
    assert test.testmethod() == 1

# Generated at 2022-06-23 14:22:52.745063
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-23 14:23:01.897768
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    test_lock = threading.Lock()
    class TestClass(object):
        __lock__ = threading.Lock()
        @lock_decorator(attr='__lock__')
        def test_method(self, arg):
            return arg

        @lock_decorator(lock=test_lock)
        def test_method2(self, arg):
            return arg

    tc = TestClass()

    assert tc.test_method("foo") == 'foo'
    assert tc.test_method2("foo") == 'foo'


#####
# END OF THIS FILE
#####
# vim:set et sw=4 ts=4 tw=80:

# Generated at 2022-06-23 14:23:08.423053
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo:
        # Default case, use an attribute
        @lock_decorator(attr='_lock')
        def append(self, item):
            # This will take a lock on ``self._lock``
            self.data.append(item)

    class Foo2:
        # Explicit case, pass a lock
        @lock_decorator(lock=threading.Lock())
        def append(self, item):
            # This will take a lock on the passed lock
            self.data.append(item)

    def simulate_worker(foo):
        # Ensure any created thread is able to run past this point
        time.sleep(0.1)
        for _ in range(10):
            foo.append('foo')
            time.sleep(0.1)

    f = Foo()
   

# Generated at 2022-06-23 14:23:18.752101
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class SomeClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback_results = []

        def new_callback(self, result):
            self._callback_results.append(result)

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, result):
            sleep(1)
            self.new_callback(result)


    obj = SomeClass()
    for i in range(5):
        obj.send_callback(i)
    assert obj._callback_results == list(range(5)), obj._callback_results

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:23:27.448168
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    class MyClass(object):
        def __init__(self, lock_attr=None, lock_val=None, raise_exc=None):
            self.my_lock = mock.MagicMock()
            self.my_lock.__enter__ = mock.MagicMock()
            self.my_lock.__exit__ = mock.MagicMock()
            if raise_exc:
                self.my_lock.__enter__.side_effect = raise_exc
            if lock_attr:
                setattr(self, lock_attr, lock_val or self.my_lock)

        @lock_decorator(attr='my_lock')
        def my_method(self):
            return 'success'

    class MySubClass(MyClass):
        def __init__(self, **kwargs):
            kw

# Generated at 2022-06-23 14:23:36.733848
# Unit test for function lock_decorator
def test_lock_decorator():
    # pylint: disable=unused-argument
    import threading
    lock = threading.Lock()
    class Foo(object):
        @lock_decorator(attr='lock')
        def a(self):
            print(1)


        @lock_decorator(lock=lock)
        def b(self, a):
            print(a)

        @lock_decorator()
        def c(self):
            print('c')
    class Bar(object):
        @lock_decorator(attr='lock')
        @classmethod
        def a(cls):
            print(1)


        @lock_decorator(lock=lock)
        @classmethod
        def b(cls, a):
            print(a)


# Generated at 2022-06-23 14:23:46.948195
# Unit test for function lock_decorator
def test_lock_decorator():
    class Plugin(object):
        def __init__(self):
            self.counter = 0

        @lock_decorator(attr='_lock')
        def add_counter(self, num):
            self.counter += 1
            return num

        @lock_decorator(lock=locker)
        def add_counter_lock(self, num):
            return self.counter + num

    locker = threading.Lock()
    plugin = Plugin()
    plugin._lock = threading.Lock()
    assert plugin.counter == 0
    assert plugin.add_counter(1) == 1
    assert plugin.counter == 1
    assert plugin.add_counter(2) == 2
    assert plugin.counter == 2
    assert plugin.add_counter_lock(3) == 3
    assert plugin.counter == 2

# Generated at 2022-06-23 14:23:57.222820
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread

    lock = Lock()
    @lock_decorator(lock=lock)
    def my_locked_method(my_value, name):
        print('[%s] %s %s' % (Thread.current_thread().name, my_value, name))

    for value in range(0, 5):
        my_locked_method(value, name='Thread-1')

    @lock_decorator(attr='_my_lock')
    def my_locked_method(self, my_value, name):
        print('[%s] %s %s' % (Thread.current_thread().name, my_value, name))

    class MyClass(object):
        def __init__(self, lock):
            self._my_lock = lock
            self.my_method = lock_dec

# Generated at 2022-06-23 14:24:07.450764
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    dummy_lock = threading.Lock()

    class Foo():
        @lock_decorator(attr='lock')
        def meth1(self):
            dummy_lock.acquire()

        @lock_decorator(lock=dummy_lock)
        def meth2(self):
            time.sleep(1)

    class Foo2():
        def meth1(self):
            dummy_lock.acquire()

        def meth2(self):
            time.sleep(1)

    foo2 = Foo2()
    foo2.meth1()
    foo2.meth2()
    dummy_lock.release()

    foo = Foo()
    foo.lock = dummy_lock

    foo.meth1()
    foo.meth2()
    dummy_lock.release()



# Generated at 2022-06-23 14:24:14.865943
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    class LockHolder(object):
        def __init__(self):
            self.lock = threading.Lock()

    rh = LockHolder()

    @lock_decorator(attr='lock')
    def some_method_attr_lock(num, multiplier=2):
        print('hello from some_method_attr_lock')
        for x in range(num):
            print('%d * %d = %d' % (x, multiplier, x * multiplier))
        time.sleep(5)
        print('goodbye from some_method_attr_lock')

    @lock_decorator(lock=threading.Lock())
    def some_method_explicit_lock(num, multiplier=3):
        print('hello from some_method_explicit_lock')

# Generated at 2022-06-23 14:24:22.495183
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class foo:
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_callback_lock')
        def f(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def g(self):
            self.counter += 1

    f = foo()
    assert f.counter == 0
    f.f()
    assert f.counter == 1
    f.g()
    assert f.counter == 2

# Generated at 2022-06-23 14:24:27.504267
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class A(object):
        def __init__(self):
            self._callback_lock = lock

        @lock_decorator()
        def some_method(self):
            return True

    a = A()
    assert a.some_method() == True

# Generated at 2022-06-23 14:24:34.075750
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import sys

    class LockDecoratorTest(object):

        def __init__(self):
            self.lock_attr = 'lock_attr'
            self.lock = threading.Lock()

        @lock_decorator(attr=lock_attr)
        def test_lock_decorator_lock_attr(self, msg):
            sys.stdout.write("%s" % msg)
            sys.stdout.flush()
            time.sleep(1)

        @lock_decorator(lock=self.lock)
        def test_lock_decorator_lock(self, msg):
            sys.stdout.write("%s" % msg)
            sys.stdout.flush()
            time.sleep(1)

    obj = LockDecoratorTest()


# Generated at 2022-06-23 14:24:45.508675
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading, time, uuid

    class DummyClass(object):
        _callback_lock_1 = threading.Lock()
        _callback_lock_2 = threading.Lock()

        @lock_decorator(attr='_callback_lock_1')
        def send_callback_attr(self, callback=None, *args, **kwargs):
            time.sleep(0.2)
            callback(*args, **kwargs)

        @lock_decorator(lock=_callback_lock_2)
        def send_callback_lock(self, callback=None, *args, **kwargs):
            time.sleep(0.2)
            callback(*args, **kwargs)


# Generated at 2022-06-23 14:24:54.105265
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyClass(object):
        _lock = threading.Lock()

        def __init__(self):
            self.data = []

        @lock_decorator(attr='_lock')
        def update(self, item):
            self.data.append(item)

        @lock_decorator(lock=threading.Lock())
        def getdata(self):
            return self.data

    inst = MyClass()
    inst.update('a')
    assert inst.getdata() == ['a']

    inst.update('b')
    assert inst.getdata() == ['a', 'b']

    # Confirm that the lock is actually blocking
    def _run(inst):
        import time
        def worker():
            time.sleep(2)
            inst.update('c')

# Generated at 2022-06-23 14:25:03.685372
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading

    if sys.version_info[0] == 2:
        from Queue import Queue
    else:
        from queue import Queue

    @lock_decorator(attr='_lock')
    def func(self, value):
        self._value = value

    class Foo:
        def __init__(self):
            self._lock = threading.Lock()
            self._value = None

        func = func

    foo = Foo()

    def run():
        i = 0
        while not q.empty():
            foo.func('value: %d' % i)
            i += 1

    q = Queue()

    for _ in range(10):
        q.put(None)

    threads = []
    for _ in range(0,10):
        t = threading.Thread

# Generated at 2022-06-23 14:25:15.435281
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    lock = threading.Lock()

    class A(object):
        def __init__(self, attr):
            self._attr = attr
            setattr(self, attr, lock)

        @lock_decorator(attr='_attr')
        def method_one(self):
            print('method_one')

        @lock_decorator(lock=lock)
        def method_two(self):
            print('method_two')

    a = A('_lock')

    def method_one():
        a.method_one()

    def method_two():
        a.method_two()

    t1 = threading.Thread(target=method_one)
    t2 = threading.Thread(target=method_two)


# Generated at 2022-06-23 14:25:25.265509
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    class TestClass(object):
        '''Test class for using ``lock_decorator``

        This class is not thread safe, but enforcing locking
        around methods can be done as such:

            @lock_decorator(attr='_lock')
            def some_method(self, ...)
        '''
        def __init__(self):
            # This lock is used when calling ``some_method``
            self._lock = threading.Lock()
            self._value = 0

        # This method is not thread safe, it
        # does not enforce a lock
        def some_method(self):
            time.sleep(.1)
            self._value += 1
            time.sleep(.1)

        def get_value(self):
            return self._value

        # This method is thread safe

# Generated at 2022-06-23 14:25:31.953301
# Unit test for function lock_decorator
def test_lock_decorator():
    @lock_decorator(lock=None)
    def test(self):
        return self
    class Test:
        _lock = False
        @lock_decorator(attr='_lock')
        def __init__(self):
            self._lock = True
    assert lock_decorator(attr='_lock')(test)(Test()) == Test()
    assert Test()._lock is True

# Generated at 2022-06-23 14:25:41.461703
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class ProtectedThing(object):
        def __init__(self):
            self.counter = 0
            self.lock = threading.Lock()

        def add_thirty(self):
            with self.lock:
                self.counter = self.counter + 30

        @lock_decorator(lock=threading.Lock())
        def add_ten(self):
            self.counter = self.counter + 10

        @lock_decorator(attr='lock')
        def add_twenty(self):
            self.counter = self.counter + 20

    pt = ProtectedThing()
    assert pt.counter == 0
    pt.add_thirty()
    assert pt.counter == 30
    pt.add_ten()
    assert pt.counter == 40
    pt.add_twenty()


# Generated at 2022-06-23 14:25:49.474578
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock_obj = threading.Lock()
    dict_obj = {'lock_key': lock_obj}

    # give the lock an initial value, we'll later test that it's
    # properly locked
    value = 0

    class MyClass(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method_with_attr(self):
            # The "with" statement should have located the lock
            # via ``self._lock``
            nonlocal value
            value += 1

        @lock_decorator(lock=lock_obj)
        def method_with_lock(self):
            # The "with" statement should have located the lock
            # via the explicit ``lock`` argument
            nonlocal value
           

# Generated at 2022-06-23 14:26:00.297368
# Unit test for function lock_decorator
def test_lock_decorator():
    import copy
    import threading
    class TestObj(object):
        _lock = threading.RLock()
        def __init__(self):
            self._num = 0
            self._cache = {}
            self._dict = {}
            self._locked = False

        def lock(self, key):
            if key not in self._cache:
                with self._lock:
                    if key not in self.cache:
                        self._cache[key] = threading.RLock()
            return self._cache[key]

        @lock_decorator(attr='_lock')
        def attrlock(self):
            self._locked = True

        @lock_decorator(lock=threading.RLock())
        def set_num(self, num):
            self._num = num


# Generated at 2022-06-23 14:26:11.004338
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Lock decorator does not support contextlib locks at the moment'''
    import unittest
    import threading
    class LockDecoratorTestCase(unittest.TestCase):
        def test_lock_decorator(self):
            class MyClass(object):
                lock_attr = threading.Lock()
                lock_obj = threading.Lock()

                def __init__(self):
                    self.lock_attr_count = 0
                    self.lock_obj_count = 0

                # The class attribute is used as a lock
                @lock_decorator(attr='lock_attr')
                def lock_attr_func(self):
                    self.lock_attr_count += 1

                # The class attribute is used as a lock

# Generated at 2022-06-23 14:26:22.048683
# Unit test for function lock_decorator
def test_lock_decorator():
    def raise_exc(exc):
        raise exc

    class Dummy(object):
        def __init__(self):
            self.attr = threading.Lock()

        def noop(self):
            pass

        def raise_exc(self):
            raise ValueError()

        @lock_decorator()
        def noop_lock(self):
            self.noop()

        @lock_decorator('attr')
        def noop_lock_attr(self):
            self.noop()

        @lock_decorator()
        def raise_exc_lock(self):
            self.raise_exc()

        @lock_decorator('attr')
        def raise_exc_lock_attr(self):
            self.raise_exc()


# Generated at 2022-06-23 14:26:26.400002
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class C(object):
        def __init__(self):
            self.some_lock = threading.Lock()
            self.counter = 0
        @lock_decorator(attr='some_lock')
        def some_method(self):
            self.counter += 1
            return self.counter

    c = C()
    assert c.some_method() == 1


# Generated at 2022-06-23 14:26:31.338949
# Unit test for function lock_decorator
def test_lock_decorator():
    import inspect
    import threading

    class LockTest(object):
        def __init__(self, val):
            self._val = val
            self._lock = threading.Lock()
            self._lock2 = threading.Lock()

        @lock_decorator(attr='_lock')
        def attr_lock(self, new_val):
            self._val = new_val
            return self._val

        @lock_decorator(lock=self._lock2)
        def explicit_lock(self, new_val):
            self._val = new_val
            return self._val

    lt = LockTest('hello')

    # Test that the lock_decorator uses the instance attribute
    # as the lock location, for attr_lock

# Generated at 2022-06-23 14:26:41.479420
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLock:
        def __init__(self):
            self.lock = lock_decorator(attr='lock')
            self.other = lock_decorator(lock=self.lock)

        @property
        def lock(self):
            return self._lock

        @lock.setter
        @lock_decorator(attr='lock')
        def lock(self, value):
            self._lock = value

        @lock_decorator(lock=self.lock)
        def something(self):
            return True

    attr = lock_decorator(attr='lock')
    # pylint: disable=no-member
    assert attr(lambda: True)() is True

    class AttrClass:
        lock = lock_decorator(attr='lock')


# Generated at 2022-06-23 14:26:53.133901
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.RLock()

    class TestClass(object):
        def __init__(self):
            self.test_attr = 0
        @lock_decorator(attr='test_attr', lock=lock)
        def test_method_one(self):
            self.test_attr += 1

        @lock_decorator(attr='test_attr')
        def test_method_two(self):
            self.test_attr += 1

        @lock_decorator(lock=lock)
        def test_method_three(self):
            self.test_attr += 1

    a = TestClass()
    a.test_method_one()
    a.test_method_two()
    a.test_method_three()

    # Properties should have been incremented
    assert a.test

# Generated at 2022-06-23 14:27:04.312782
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    threading_lock = threading.Lock()

    class SomeClass(object):
        def __init__(self):
            self._lock = threading.Lock()

    some_class = SomeClass()

    def test_with_attr():
        @lock_decorator(attr='_lock')
        def no_arg(self):
            nonlocal some_class
            some_class.foo = True

        @lock_decorator(attr='_lock')
        def with_arg(self, one):
            nonlocal some_class
            some_class.bar = one

        with threading_lock:
            no_arg(some_class)
            assert some_class.foo
            with_arg(some_class, True)
            assert some_class.bar


# Generated at 2022-06-23 14:27:14.407446
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    from itertools import islice
    from time import sleep

    class TestObject(object):
        def __init__(self, lock_attr=''):
            self.attr_value = 0
            self.lock_attr = lock_attr

        def add_at_one(self):
            with getattr(self, self.lock_attr):
                self.attr_value += 1

    def add_at_two():
        test_object.attr_value += 2

    class TestObject2(object):
        def __init__(self, lock=None):
            self.attr_value = 0
            self.lock = lock

        @lock_decorator(lock=self.lock)
        def add_at_three(self):
            self.attr_value += 3


# Generated at 2022-06-23 14:27:24.095067
# Unit test for function lock_decorator
def test_lock_decorator():
    from unit.compat.mock import MagicMock
    from ansible.module_utils._text import to_bytes

    lock = MagicMock()

    @lock_decorator(lock=lock)
    def func():
        return True

    # Call the function
    func()
    # Assert that the first thing that happened was we enter() the lock
    assert lock.__enter__.called
    # Assert that the last thing that happened was we exit() the lock
    assert lock.__exit__.called

    # Call the function a second time, but this time we'll return
    # False from lock().
    lock.reset_mock()
    lock.__enter__.side_effect = None
    lock.__enter__.return_value = False
    # Call the function
    func()
    # Assert that the first thing