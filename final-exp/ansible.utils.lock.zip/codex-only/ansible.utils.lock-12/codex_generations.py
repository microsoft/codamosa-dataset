

# Generated at 2022-06-23 14:17:34.616906
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Test(object):

        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self.counter += 1

    # Simulate two threads that are incrementing counter
    # Ensure lock decorator works as expected and counter
    # increments by only 1
    def inc_counter(t):
        t.increment()

    t = Test()
    threads = [
        threading.Thread(target=inc_counter, args=(t,)),
        threading.Thread(target=inc_counter, args=(t,))
    ]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert t.counter == 1

# Generated at 2022-06-23 14:17:45.343356
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        # Only run this test if threading is usable
        return

    class TestThreading(threading.Thread):
        def __init__(self, lock):
            super(TestThreading, self).__init__()
            self.lock = lock
            self.lockvar = True

        @lock_decorator(lock=None)
        def fake_run(self, lockvar):
            with self.lock:
                print('Acquired lock')
                assert self.lockvar
                try:
                    lockvar = False
                    assert lockvar
                finally:
                    print('Released lock')
                    assert self.lockvar
                    # This block is used to test context manager behavior
                    # of the decorated function using an explicit lock
                    with self.lock:
                        pass
                assert self

# Generated at 2022-06-23 14:17:50.449557
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self.lock_attr = threading.Lock()

        @lock_decorator(attr='lock_attr')
        def some_method(self):
            return len(self.lock_attr._RLock__block)

    f = Foo()
    assert f.some_method() == 0

# Generated at 2022-06-23 14:17:58.591101
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # this will be set to True by a thread when it has acquired the lock
    # and started to execute the function
    thread_has_lock = False

    class TestObj():
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_attr(self):
            global thread_has_lock
            assert not thread_has_lock
            thread_has_lock = True
            # pretend to do something that takes a while
            import time
            import random
            time.sleep(random.randint(1, 10))

        @lock_decorator(lock=threading.Lock())
        def lock_arg(self):
            global thread_has_lock
            assert not thread_has_lock

# Generated at 2022-06-23 14:18:09.130936
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    foo = {'counter': 0}
    foo_lock = threading.Lock()

    @lock_decorator(attr='_lock')
    def increment_foo(foo=foo, lock=foo_lock):
        foo['counter'] += 1

    @lock_decorator(lock=foo_lock)
    def increment_bar(foo=foo, lock=foo_lock):
        foo['counter'] += 1

    incremented_foo = False
    incremented_bar = False
    def thread_foo():
        for i in range(1000):
            increment_foo()
        incremented_foo = True

    def thread_bar():
        for i in range(1000):
            increment_bar()
        incremented_bar = True

    threading.Thread(target=thread_foo).start()
    threading

# Generated at 2022-06-23 14:18:20.317275
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLockDecorator(object):
        def __init__(self):
            self.counter = 0
            self.locks = {
                'attr_lock': threading.Lock(),
                'explicit_lock': threading.Lock()
            }

        @lock_decorator(attr='attr_lock')
        def with_attr_lock(self, label='auto'):
            self.counter = self.counter + 1
            print(label, self.counter)
            time.sleep(1)

        @lock_decorator(lock=self.locks['explicit_lock'])
        def with_explicit_lock(self, label='auto'):
            self.counter = self.counter + 1
            print(label, self.counter)
            time.sleep(1)

   

# Generated at 2022-06-23 14:18:30.261915
# Unit test for function lock_decorator
def test_lock_decorator():
    import copy
    import threading

    class A(object):
        pass

    import pytest
    @pytest.mark.parametrize('lock', [None, threading.Lock()])
    def test_func(lock):
        '''Test function lock_decorator'''

        # Create two instances of A
        a_to_test = A()
        a_to_test2 = A()
        # Assign a lock to the first instance
        if lock is not None:
            a_to_test.lock = lock

        # Create a list with some data to be modified
        fake_data = [1, 2, 3, 'a', 'b', 'c']
        # Create a copy of the list
        fake_data_copy = copy.copy(fake_data)

        # Create a function that modifies a list


# Generated at 2022-06-23 14:18:35.999267
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class SomeClass(object):
        def __init__(self, test_lock):
            self._test_lock = test_lock
            self._test_value = 0

        @lock_decorator(attr='_test_lock')
        def _increment_test_value(self):
            self._test_value += 1

    @lock_decorator(lock=threading.Lock())
    def _increment_test_value():
        test_value.append(1)

    lck = threading.Lock()

    for i in range(500):
        test_value = []
        o = SomeClass(lck)

        threads = []

        for j in range(10):
            threads.append(threading.Thread(target=o._increment_test_value))


# Generated at 2022-06-23 14:18:43.292040
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Obj(object):
        _my_lock = threading.Lock()
        _result = 0

        @lock_decorator(attr='_my_lock')
        def method_1(self, value):
            self._result += value

        @lock_decorator(lock=threading.Lock())
        def method_2(self, value):
            self._result += value

    obj = Obj()

    def run_method_1(my_obj, my_value):
        for x in range(0, my_value):
            my_obj.method_1(my_value)

    def run_method_2(my_obj, my_value):
        for x in range(0, my_value):
            my_obj.method_2(my_value)

    t1

# Generated at 2022-06-23 14:18:44.642108
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 'lock_decorator' == lock_decorator.__name__

# Generated at 2022-06-23 14:18:55.204942
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a test lock, and a lock attribute to use
    from threading import Lock, Semaphore
    testlock = Lock()
    testattr = 'test_lock_attr'
    testsem = Semaphore()
    semattr = 'test_sem_attr'

    class TestObj(object):
        # Initialize the lock attribute
        test_lock_attr = testlock
        test_sem_attr = testsem

        @lock_decorator(attr=testattr)
        def _test_method_lock(self):
            assert self.test_lock_attr.locked()

        @lock_decorator(lock=testlock)
        def _test_method_passed_lock(self):
            assert self.test_lock_attr.locked()


# Generated at 2022-06-23 14:18:59.759680
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyClass(object):
        '''An object to wrap methods in MyClass with a lock'''

        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator('_callback_lock')
        def callback(self):
            return True

    def callback2():
        '''This function will be wrapped with a lock'''
        return True

    callback2 = lock_decorator(lock=threading.Lock())(callback2)

    assert MyClass().callback()
    assert callback2()

# Generated at 2022-06-23 14:19:03.201768
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class A:
        def __init__(self):
            self.a = threading.Lock()

        @lock_decorator(attr='a')
        def test(self, arg):
            print(arg)

    a = A()
    a.test('test')



# Generated at 2022-06-23 14:19:13.143707
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class module_tests(unittest.TestCase):

        def setUp(self):
            self.value = 0

        @lock_decorator(attr='_lock')
        def inc(self):
            self.value = self.value + 1

        def test_with_lock(self):
            self.inc()
            self.assertEqual(self.value, 1)

        @lock_decorator(lock=threading.Lock())
        def inc_by(self, val):
            self.value = self.value + val

        def test_with_external_lock(self):
            self.inc_by(1)
            self.assertEqual(self.value, 1)

# Generated at 2022-06-23 14:19:24.089504
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # Using instance attribute for the lock
    class A(object):
        def __init__(self):
            self._input_lock = threading.Lock()

        @lock_decorator(attr='_input_lock')
        def input_1(self):
            print('input_1...')
            time.sleep(1)

        @lock_decorator(attr='_input_lock')
        def input_2(self):
            print('input_2...')
            time.sleep(1)

        @lock_decorator(attr='_input_lock')
        def input_3(self):
            print('input_3...')
            time.sleep(1)

    a = A()

    a.input_1()
    a.input_2()
    a.input

# Generated at 2022-06-23 14:19:28.310396
# Unit test for function lock_decorator
def test_lock_decorator():
    class A(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def __repr__(self):
            return 'A()'

    a = A()
    assert repr(a) == 'A()'
    assert a._lock is not None

# Generated at 2022-06-23 14:19:36.662994
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def inc(self):
            self._counter += 1

    a = MyClass()
    threads = []
    for i in range(0, 100):
        threads.append(threading.Thread(target=a.inc))
        threads[i].start()
    for i in range(0, 100):
        threads[i].join()
    assert a._counter == 100

# Generated at 2022-06-23 14:19:41.358922
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # Create a poor-man's `multiprocessing.Manager`
    class Manager:
        _shared = {}

    manager = Manager()


    # Use lock_decorator to provide a thread-safe method which can be
    # called by multiple threads, where the shared data is stored in
    # a Manager.
    @lock_decorator(attr='_callback_lock', lock=threading.Lock())
    def update(key, value, lock=None):
        manager._shared[key] = value


    update('first', '1')
    assert manager._shared == {'first': '1'}
    update('second', '2')
    assert manager._shared == {'first': '1', 'second': '2'}

# Generated at 2022-06-23 14:19:44.816042
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    class Foo:
        def __init__(self, attr='lock'):
            self.attr = attr
            lock = getattr(self.__class__, attr)
            setattr(self, attr, lock())
            self.data = 0

        def set_data(self, value):
            self.data = value

        def get_data(self):
            return self.data

    f = Foo()
    Foo.lock = threading.Lock()

    # make sure that locking works
    @lock_decorator(attr='attr')
    def set_data(self, value):
        time.sleep(0.01)
        self.set_data(value)

    start = time.time()

# Generated at 2022-06-23 14:19:52.882768
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock

    # Using a lock passed to the decorator
    lock = Lock()

    @lock_decorator(lock=lock)
    def func():
        pass

    assert hasattr(func, '__wrapped__')
    assert func.__wrapped__

    lock.acquire()
    try:
        func()
    except Exception as e:
        assert False, "Lock not acquired"
    else:
        assert True, "Lock acquired"
    finally:
        lock.release()

    # Using an instance attribute
    class Class(object):
        _lock = Lock()

        @lock_decorator(attr='_lock')
        def func(self):
            pass

    c = Class()

    c._lock.acquire()

# Generated at 2022-06-23 14:19:56.169564
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class Inst(object):
        @lock_decorator(attr='lock')
        def method(self):
            return 'foo'

        @lock_decorator(lock=lock)
        def method2(self):
            return 'bar'

    inst = Inst()
    inst.lock = threading.Lock()
    assert inst.method() == 'foo'
    assert inst.method2() == 'bar'

# Generated at 2022-06-23 14:20:06.129655
# Unit test for function lock_decorator
def test_lock_decorator():
    '''This is a basic unit test for lock_decorator

    Currently it is dependent on a specific version of
    ``threading.Lock`` for testing purposes.
    '''
    import threading
    import types

    option = {'attr': '_test_lock'}
    lock = threading.Lock()
    args = (None,)
    kwargs = {}

    @lock_decorator(**option)
    def test_function_with_lock(self, *args, **kwargs):
        assert hasattr(self, '_test_lock')
        assert getattr(self, '_test_lock') is lock
    test_function_with_lock(*args, **kwargs)

    option = {'lock': lock}

# Generated at 2022-06-23 14:20:18.519462
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    def test_thread_safe_func():
        import time
        time.sleep(1)
        return True

    class LockTestClass(object):

        def __init__(self):
            self._mylock = threading.Lock()

        @lock_decorator(attr='_mylock')
        def test_method(self):
            return test_thread_safe_func()

    class LockTestClassNoDecorator(object):

        def __init__(self):
            self._mylock = threading.Lock()

        def test_method(self):
            with self._mylock:
                return test_thread_safe_func()

    class LockTestClassStaticMethod(object):

        _mylock = threading.Lock()


# Generated at 2022-06-23 14:20:26.117360
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import inspect

    class TestClass(object):
        def __init__(self):
            self.call_count = 0
            self._test_lock = threading.Lock()

        @lock_decorator(attr='_test_lock')
        def test_method(self):
            """Fake doc string"""
            self.call_count += 1

        @lock_decorator(lock=threading.Lock())
        def test_lock_method(self):
            """Fake doc string"""
            self.call_count += 1

    t = TestClass()
    t.test_method()
    assert t.call_count == 1

    t.test_lock_method()
    assert t.call_count == 2

    assert t.test_method.__name__ == 'test_method'

# Generated at 2022-06-23 14:20:37.267117
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Test(object):
        def __init__(self):
            self.lock_attr = threading.Lock()
            self.lock = threading.Lock()
            self.value = 0
            self.lock_attr_value = 0

        @lock_decorator(attr='lock_attr')
        def lock_attr_func(self, value):
            self.lock_attr_value += value

        @lock_decorator(lock=self.lock)
        def lock_func(self, value):
            self.value += value

    test = Test()
    test.lock_func(1)
    test.lock_attr_func(1)
    assert test.value == 1
    assert test.lock_attr_value == 1


# Generated at 2022-06-23 14:20:44.854126
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    def raise_exception():
        raise Exception()

    l = threading.Lock()
    c = threading.Condition(l)

    class Test(object):

        def __init__(self):
            self.lock = threading.Lock()
            self.attr_lock = threading.Lock()

        @lock_decorator()
        def raise_exception_no_lock(self):
            return raise_exception()

        @lock_decorator(attr='not_there')
        def raise_exception_no_attr(self):
            return raise_exception()

        @lock_decorator(attr='lock')
        def raise_exception_with_attr(self):
            return raise_exception()


# Generated at 2022-06-23 14:20:53.359565
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    decorator_lock = lock_decorator(lock=lock)

    @decorator_lock
    def test_method(a, b):
        assert a
        assert b
        return True

    assert test_method(True, True)

    class MyClass():
        _callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def test_method(self, a, b):
            assert a
            assert b
            return True

    obj = MyClass()
    assert obj.test_method(True, True)

# Generated at 2022-06-23 14:21:03.465892
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading
    from time import sleep

    class TestLock(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.calls = []

        @lock_decorator
        def no_lock(self):
            self.calls.append('no_lock')

        @lock_decorator(lock=threading.Lock())
        def explicit_lock(self):
            self.calls.append('explicit_lock')

        @lock_decorator(attr='_lock')
        def attr_lock(self):
            self.calls.append('attr_lock')

    test = TestLock()

    class TestThread(threading.Thread):
        def __init__(self, test):
            threading.Thread.__init__(self)
            self.test

# Generated at 2022-06-23 14:21:12.798677
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyClass(object):
        def __init__(self, num_threads):
            self._lock = threading.Lock()
            self._lock_attr = threading.Lock()
            self.num_threads = num_threads
            self.results_lock_arg = []
            self.results_lock_attr = []

        @lock_decorator(lock=self._lock)
        def locked_method_arg(self):
            self.results_lock_arg.append(True)

        @lock_decorator(attr='_lock_attr')
        def locked_method_attr(self):
            self.results_lock_attr.append(True)

    num_threads = 10
    my_class = MyClass(num_threads)

    threads = []

# Generated at 2022-06-23 14:21:17.732316
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest

    class C(object):
        @lock_decorator(attr='missing_lock_attr')
        def C_method(self, a, b):
            return a + b

        @lock_decorator(lock=lock)
        def C_method2(self, a, b):
            return a - b

    with pytest.raises(AttributeError):
        C().C_method(1, 2)

    lock = 1

    assert C().C_method2(3, 2) == 1

# Generated at 2022-06-23 14:21:22.686859
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        @lock_decorator(attr='lock')
        def method(self):
            self.lock.acquire()  # this should be reentrant

    t = Test()
    t.lock = threading.Lock()

    t.method()  # this should now be reentrant

# Generated at 2022-06-23 14:21:32.557184
# Unit test for function lock_decorator
def test_lock_decorator():
    import ansible.module_utils.basic
    import threading
    import time

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

        @lock_decorator(attr='_lock')
        def method1(self):
            self._value += 1
            time.sleep(0.01)

        @lock_decorator(lock=threading.Lock())
        def method2(self):
            self._value += 1
            time.sleep(0.01)

    def thread_method1():
        for x in range(1000):
            t.method1()

    def thread_method2():
        for x in range(1000):
            t.method2()

    t = Test()

    threads = []

# Generated at 2022-06-23 14:21:41.681868
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import time

    class FakeLock:
        def __init__(self):
            self.reset()

        def reset(self):
            self.acquire_count = 0
            self.release_count = 0
            self.block_time = 0
            self.locked = False

        def __enter__(self):
            self.acquire_count += 1
            time.sleep(self.block_time)
            self.locked = True

        def __exit__(self, *args, **kwargs):
            self.release_count += 1
            self.locked = False

    class FakeClass:
        def __init__(self):
            self._lock = FakeLock()
            self.total = 0
            self.complete = 0
            self.timeout = 0.1


# Generated at 2022-06-23 14:21:49.906217
# Unit test for function lock_decorator
def test_lock_decorator():
    '''This is a basic unit test for the lock_decorator. The intent
    is to ensure the decorator behaves as expected.

    NOTE: This test uses the ``threading.Lock`` class, which
    is only available on Python >= 3.2
    '''
    import threading
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def foo(x):
        return x

    @lock_decorator()
    def bar(x):
        return x

    @lock_decorator(attr='_lock')
    def baz(x):
        return x

    class test(object):
        _lock = threading.Lock()

        @lock_decorator()
        def foobar(self, x):
            return x


# Generated at 2022-06-23 14:21:57.168340
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Example(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            pass
        @lock_decorator(lock=threading.Lock())
        def lock_passed_in(self):
            pass
    assert isinstance(Example.send_callback, lock_decorator)
    assert isinstance(Example.lock_passed_in, lock_decorator)

# Generated at 2022-06-23 14:22:05.462998
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeLock:
        def __enter__(self):
            return None

        def __exit__(self, *args):
            return None

    class FakeLocked:
        def __init__(self):
            self.__lock_attr = threading.Lock()

        def __lock(self):
            return self.__lock_attr

        @lock_decorator(attr='__lock')
        def __locked(self):
            return 'locked'

        @lock_decorator(lock=threading.Lock())
        def locked(self):
            return 'locked'

    locked = FakeLocked()
    assert locked.__locked() == 'locked'
    assert locked.locked() == 'locked'

    # Test that we use

# Generated at 2022-06-23 14:22:16.763372
# Unit test for function lock_decorator
def test_lock_decorator():
    class testclass(object):
        '''Basic class to test lock_decorator'''
        def __init__(self):
            self.value = ''
            self.lock = None

        @lock_decorator(attr='lock')
        def method1(self, value):
            '''method1 using attr'''
            self.value = value

        @lock_decorator()
        def method2(self, value):
            '''method2 using default value of lock'''
            self.value = value

    instance = testclass()
    instance.method1('somevalue')
    assert instance.value == 'somevalue'

    lock = lock_decorator(lock=instance.lock)
    instance.method2 = lock(instance.method2)

    instance.method2('somevalue')
    assert instance.value

# Generated at 2022-06-23 14:22:28.206391
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # Create a lock that can be used for a class field
    lock = threading.Lock()
    class TestClass(object):
        """This is a TestClass used to test lock_decorator"""
        def __init__(self):
            self._lock = lock.__class__()
        def _test(self):
            assert self._lock.acquire(False)
            self._lock.release()
            return "test"
        @lock_decorator(attr='_lock')
        def test_use_attr(self):
            self._test()
            return "test"
        @lock_decorator(lock=lock.__class__())
        def test_use_lock(self):
            self._test()
            return "test"

    test_obj = TestClass()
    # Ensure the lock

# Generated at 2022-06-23 14:22:37.976085
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class A(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.val = 0

        @lock_decorator(attr='_lock')
        def add(self, a, b):
            time.sleep(1)
            self.val = a + b

    a = A()
    t = []
    for i in range(10):
        t.append(threading.Thread(target=a.add, args=(i, 1)))
    for i in t:
        i.start()

    for i in t:
        i.join()

    assert a.val == 1

# Generated at 2022-06-23 14:22:48.785746
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    lock_attr = '_lock'

    class TestLock(object):
        def __init__(self, lock=None):
            if lock is None:
                lock = threading.Lock()
            self.lock = lock

        @lock_decorator
        def run_with_default(self):
            assert False, 'lock not respected for run_with_default'

        @lock_decorator(attr=lock_attr)
        def run_with_attr(self):
            assert hasattr(self, lock_attr), 'lock attr not set for run_with_attr'
            assert False, 'lock not respected for run_with_attr'


# Generated at 2022-06-23 14:22:55.235003
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    global my_lock

    my_lock = threading.Lock()
    my_global_value = 0

    @lock_decorator(lock=my_lock)
    def test_lock(val):
        global my_global_value
        my_global_value += val

    threads = []
    for i in range(100):
        t = threading.Thread(target=test_lock, args=(1,))
        t.daemon = True
        threads.append(t)

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    assert my_global_value == 100

# Generated at 2022-06-23 14:23:06.453671
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        return True

    class Test1(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def __len__(self):
            return 1

        @lock_decorator(lock=threading.Lock())
        def __getitem__(self, key):
            return key + 1

    class Test2(object):
        def __len__(self):
            return 2

        @lock_decorator(lock=threading.Lock())
        def __getitem__(self, key):
            return key + 2

    t1 = Test1()
    assert len(t1) == 1
    assert t1[0] == 1

    t2 = Test2()
    assert len(t2) == 2


# Generated at 2022-06-23 14:23:15.688991
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()

    t = TestClass()

    def test_method_decorator():
        '''Test that the lock decorator works with method decorator'''

        @lock_decorator(attr='_lock')
        def method(self):
            self.a += 1
            self.b += 1
            self.c += 1
            return self.a, self.b, self.c

        t.a = 1
        t.b = 1
        t.c = 1

        v1 = method(t)
        assert t.a == 2
        assert t.b == 2
        assert t.c == 2

        v2 = method(t)
        assert t.a == 3

# Generated at 2022-06-23 14:23:22.715371
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def test(self):
            return 1

        @lock_decorator(lock=threading.Lock())
        def test2(self):
            return 1

    test = Test()
    assert test.test() == 1
    assert test.test2() == 1

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:23:29.616754
# Unit test for function lock_decorator
def test_lock_decorator():
    # lock_decorator relies on a context manager pattern for the locking
    # mechanism and thus can be tested without having to mock anything
    lock = None
    try:
        from threading import Lock
        lock = Lock()
    except ImportError:
        # We may still be able to test the attr based locking
        pass

    class Foo(object):
        def __init__(self):
            self._lock = None
            if lock:
                self._lock = lock

    @lock_decorator(attr='_lock')
    def foo(self):
        return 1

    @lock_decorator(lock=lock)
    def bar(self):
        return 2

    fooinst = Foo()
    assert fooinst.foo() == 1
    assert bar(fooinst) == 2

# Generated at 2022-06-23 14:23:37.316038
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for function lock_decorator'''
    # pylint: disable=unused-import,unused-variable
    import threading
    import time

    class Fake(object):
        '''Use this fake class as a base for other fake classes'''
        def __init__(self, *args, **kwargs):
            # pylint: disable=unbalanced-tuple-unpacking
            self.args, self.kwargs = args, kwargs
            self.count = 0

        @lock_decorator(attr='_lock', lock=None)
        def method(self, *args, **kwargs):
            '''This method only calls self.increment'''
            self.increment(*args, **kwargs)

        # pylint: disable=unused-argument

# Generated at 2022-06-23 14:23:46.662314
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class LockTest(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def lock_decorator_attr_test(self, x):
            return x

        @lock_decorator(lock=threading.Lock())
        def lock_decorator_lock_test(self, x):
            return x

    lock_test = LockTest()

    for method, arg, expected in (
        (lock_test.lock_decorator_attr_test, 1, 1),
        (lock_test.lock_decorator_lock_test, 2, 2),
    ):
        assert method(arg) == expected

# Generated at 2022-06-23 14:23:57.225231
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    import time

    # Python 2 compatibility
    if sys.version_info < (3, ):
        import Queue as queue
    else:
        import queue

    class Tester(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, result, exception):
            pass

    test = [0]
    def test_func(*args, **kwargs):
        time.sleep(0.1)
        test[0] += 1

    def test_thread():
        test_func()
        time.sleep(0.1)
        test_func()


# Generated at 2022-06-23 14:24:07.450685
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    from contextlib import contextmanager

    class LockTestCase(unittest.TestCase):
        def test_lock_decorator(self):
            @lock_decorator(attr='_lock')
            @contextmanager
            def test_method(self):
                self.assertTrue(self._lock.acquire(False), 'Lock was not acquired')
                self.assertIsNone(self._lock.release(), 'Lock was not released')
                yield
                self.assertIsNone(self._lock.release(), 'Lock was not released')

            test = LockTestCase()
            test._lock = threading.Lock()

            test_method(test)
            test.assertTrue(test._lock.acquire(False), 'Lock was not acquired')

# Generated at 2022-06-23 14:24:17.877322
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    import pytest

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

        @lock_decorator(attr='_lock')
        def some_method(self):
            self._value += 1
            sleep(.01)
            return self._value

    testclass = TestClass()

    with pytest.raises(AttributeError):
        @lock_decorator()
        def some_method():
            return True

    @lock_decorator(lock=TestClass()._lock)
    def some_method():
        return True

    assert some_method()

    assert testclass.some_method() == 1
    assert TestClass().some_method() == 1


# Generated at 2022-06-23 14:24:29.153881
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import mock
    import threading
    class TestClass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self._decorated_attr = 0
            self._decorated_lock = 0
            self._decorated_instance_lock = 0
            self._callback_lock = threading.Lock()

        @lock_decorator()
        def decorated_default(self):
            self._decorated_attr += 1

        @lock_decorator(attr='lock')
        def decorated_attr(self):
            self._decorated_attr += 1

        @lock_decorator(lock=threading.Lock())
        def decorated_lock(self):
            self._decorated_lock += 1


# Generated at 2022-06-23 14:24:32.834421
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestLock(object):
        def __init__(self):
            self._attr = threading.Lock()

        @lock_decorator(attr='_attr')
        def lock_attr(self):
            return True

        @lock_decorator(lock=threading.Lock())
        def lock_explicit(self):
            return True

    test = TestLock()
    assert test.lock_attr()
    assert test.lock_explicit()

# Generated at 2022-06-23 14:24:43.612550
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class TestClass(object):
        def __init__(self, lock_attr='_testlock'):
            setattr(self, lock_attr, threading.Lock())

        @lock_decorator(attr='_testlock')
        def test_attr_lock(self):
            return

        @lock_decorator(lock=threading.Lock())
        def test_lock_object(self):
            return

    tc = TestClass()
    tc.test_attr_lock()
    tc.test_lock_object()

    # If the lock decorator is functioning, this next test
    # should hang forever
    #testlock_thread = threading.Thread(target=tc.test_lock_object)
    #testlock_thread.start()
    #testlock_thread.join(timeout=5)

# Generated at 2022-06-23 14:24:52.739058
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    _global_lock = threading.Lock()

    # Use of ``attr``
    class Test(object):
        def __init__(self):
            self._lock = _global_lock

        @lock_decorator(attr='_lock')
        def some_method(self, sleep_time):
            time.sleep(sleep_time)

    test = Test()
    start = time.time()
    threads = [threading.Thread(target=test.some_method, args=(x,)) for x in range(0,3)]
    [x.start() for x in threads]
    [x.join() for x in threads]
    print(time.time() - start)

    # Use of ``lock``
    class Test(object):
        def __init__(self):
            self

# Generated at 2022-06-23 14:25:02.291603
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            # Test that setting attr= works
            self._attr_lock = threading.Lock()
            # Test that setting lock= works
            self._lock = threading.Lock()

        @lock_decorator(attr='_attr_lock')
        def test_attr_lock(self):
            assert hasattr(self, '_attr_lock')
            assert isinstance(self._attr_lock, threading.Lock)

        @lock_decorator(lock=self._lock)
        def test_lock(self):
            assert hasattr(self, '_lock')
            assert isinstance(self._lock, threading.Lock)

# Generated at 2022-06-23 14:25:09.326972
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class Foo:
        def __init__(self, title):
            self.title = title
            self.mutex = threading.Lock()

        @lock_decorator(attr='mutex')
        def send_callback(self, value):
            time.sleep(random.random())
            print(self.title, value)

    title = 'Threading'
    threads = []
    for x in range(10):
        thread = threading.Thread(target=Foo(title).send_callback, args=('Hello',))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()
    print('Done')



# Generated at 2022-06-23 14:25:17.730796
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class ExObject(object):

        @lock_decorator(attr='_lock')
        def _callback(self):
            self.num += 1
            time.sleep(1)

        def callback(self):
            self._callback()

        def __init__(self):
            self._lock = threading.Lock()
            self.num = 0

    obj = ExObject()
    threads = []

    for x in range(0, 3):
        t = threading.Thread(target=obj.callback)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    assert obj.num == 3

# Generated at 2022-06-23 14:25:27.407299
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.value = 1

        def incr(self):
            with self.lock:
                self.value += 1

        @lock_decorator(lock=threading.Lock())
        def incr_static_lock(self):
            self.value += 1

        @lock_decorator()
        def incr_missing_lock(self):
            self.value += 1

        @lock_decorator(attr='lock')
        def incr_with_lock_attr(self):
            self.value += 1

    foo = Foo()
    foo.incr()
    assert foo.value == 2
    foo.incr_static_lock()
    assert foo.value == 3
   

# Generated at 2022-06-23 14:25:38.764242
# Unit test for function lock_decorator
def test_lock_decorator():  # pragma: no cover
    import threading
    class Example:
        _lock = threading.RLock()

        def __init__(self):
            self.lock = threading.RLock()
            self.counter = 0

        @lock_decorator()
        def increment(self):
            self.counter += 1

        @lock_decorator(lock=self.lock)
        def decrement(self):
            self.counter -= 1

        @classmethod
        @lock_decorator(attr='_lock')
        def class_increment(cls):
            cls.counter += 1

    obj = Example()

    print('Increment the counter')
    obj.increment()
    print('Decrement the counter')
    obj.decrement()
    print('Increment the counter')
    obj.incre

# Generated at 2022-06-23 14:25:45.833551
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class ExampleClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.value = 0

        @lock_decorator()
        def method_one(self):
            self.value += 1

        @lock_decorator(attr='_lock')
        def method_two(self):
            self.value += 1

    e = ExampleClass()
    assert e.value == 0
    e.method_one()
    assert e.value == 1
    e.method_two()
    assert e.value == 2

# Generated at 2022-06-23 14:25:56.260448
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    import six

    class A(object):
        def __init__(self):
            self.lock = Lock()
            self._msg = None

        def set(self, msg):
            with self.lock:
                print('Lock acquired')
                self._msg = msg
                six.print_('{}: {}'.format(self, self._msg))

        def get(self):
            with self.lock:
                six.print_('Lock acquired')
                return self._msg

        def __str__(self):
            return 'A'

    @lock_decorator(attr='lock')
    def b_set(self, msg):
        self._msg = msg
        six.print_('{}: {}'.format(self, self._msg))


# Generated at 2022-06-23 14:26:03.411857
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    from time import sleep

    class SomeClass(object):
        def __init__(self):
            self._lock = Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def a(self):
            i = 0
            while i < 11000000:
                self.counter += 1
                i += 1

        @lock_decorator(lock=Lock())
        def b(self):
            i = 0
            while i < 11000000:
                self.counter -= 1
                i += 1

    sc = SomeClass()
    threads = []
    threads.append(Thread(target=sc.a))
    threads.append(Thread(target=sc.a))
    threads.append(Thread(target=sc.b))

# Generated at 2022-06-23 14:26:08.068390
# Unit test for function lock_decorator
def test_lock_decorator():
    class Locker(object):
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            return args[0] + kwargs['b']

    l = Locker()
    assert l.send_callback(2, b=2) == 4

# Generated at 2022-06-23 14:26:14.026444
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    _lock = threading.Lock()
    class Foo(object):
        @lock_decorator(attr='_lock')
        def foo(self):
            pass

        @lock_decorator(lock=_lock)
        def bar(self):
            pass

    foo = Foo()
    # Assert that first use of decorator works
    assert not foo.foo()
    # Assert that second use of decorator also works
    assert not foo.bar()

# Generated at 2022-06-23 14:26:19.704890
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self.some_lock = threading.Lock()
            self.val = 0
            self.other_val = 0

        @lock_decorator(attr='some_lock')
        def do_this(self):
            self.val += 1

        @lock_decorator(lock=self.some_lock)
        def do_that(self):
            self.other_val += 1

    foo = Foo()
    foo.do_this()

    # Ensure the value is incremented
    assert foo.val == 1

    # Ensure the lock was actually called
    assert foo.some_lock.locked()

    foo.do_that()

    # Ensure the other value is incremented
    assert foo.other_val == 1

    # Ensure the

# Generated at 2022-06-23 14:26:28.236600
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    try:
        from unittest import mock
    except ImportError:
        import mock
    from six import PY2

    class FakeClass(object):
        def __init__(self):
            self.attr_lock = threading.Lock()

    fake_class_inst = FakeClass()

    # If ``lock`` is provided, use it
    test_lock = threading.RLock()
    _mock_enter = mock.Mock()
    _mock_exit = mock.Mock()
    test_func = mock.Mock()
    @lock_decorator(lock=test_lock)
    def lock_func_mock(*args, **kwargs):
        test_func(*args, **kwargs)
    test_func.assert_not_called()
    lock_

# Generated at 2022-06-23 14:26:39.229998
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyClass:
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, val):
            return val

        @lock_decorator('_callback_lock')
        def send_callback_2(self, val):
            return val

        @lock_decorator(lock=threading.Lock())
        def send_callback_3(self, val):
            return val

    obj = MyClass()
    assert obj.send_callback(1) == 1
    assert obj.send_callback_2(1) == 1
    assert obj.send_callback_3(1) == 1

# Generated at 2022-06-23 14:26:44.235705
# Unit test for function lock_decorator
def test_lock_decorator():
    outer = lock_decorator(attr='lock_obj')

    class TestCls:
        def __init__(self):
            self.lock_obj = 'lock'

    @outer
    def send_callback():
        pass

    assert send_callback.__name__ == 'send_callback'


# Generated at 2022-06-23 14:26:52.961748
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading
    global value

    value = 1

    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def increase_value():
        global value
        print('Lock Acquired')
        time.sleep(1)
        value = value + 1
        print('Lock Released')

    thread = threading.Thread(target=increase_value)
    thread.start()

    time.sleep(0.5)

    print('About to acquire lock')
    with lock:
        print('Lock acquired')
        print('About to release lock')

    thread.join(timeout=10)

    assert value == 2

# Generated at 2022-06-23 14:27:04.146150
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class TestClass(object):
        def __init__(self):
            self.attr = 0
            self.prop = 0

        @lock_decorator(attr='attr_lock')
        def attr_update(self):
            self.attr += 1

        attr_lock = threading.Lock()

        @property
        @lock_decorator(lock=lock)
        def prop_update(self):
            self.prop += 1

    test = TestClass()
    assert test.attr == 0
    assert test.prop == 0

    import threading
    t1 = threading.Thread(target=TestClass.attr_update, args=(test,))
    t1.start()


# Generated at 2022-06-23 14:27:14.282294
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading
    import random
    import logging

    class Dummy(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.logger = logging.getLogger('lock_decorator.test_lock_decorator')
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logger.propagate = False
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, callback):
            if not callback:
                return
            callback(self)

        @lock_decorator(lock=threading.Lock())
        def some_method(self, callback):
            if not callback:
                return
            callback(self)

# Generated at 2022-06-23 14:27:21.653862
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:
        def __init__(self, value=0):
            self.value = value
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.value += 1

        @lock_decorator(lock=threading.Lock())
        def decrement(self):
            self.value -= 1

    t = Test()

    for i in range(100):
        t.increment()
        t.decrement()

    assert t.value == 0

# Generated at 2022-06-23 14:27:26.445692
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    tlock = threading.Lock()
    class TestLockDecorator(object):
        @lock_decorator(attr='_callback_lock')
        def fake_lock(self):
            pass

        @lock_decorator(lock=tlock)
        def fake_lock_with_thread_lock(self):
            pass

    tld = TestLockDecorator()
    tld.fake_lock()
    tld.fake_lock_with_thread_lock()