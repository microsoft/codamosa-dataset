

# Generated at 2022-06-23 14:17:32.289165
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    class DummyClass(object):
        def __init__(self, lock=None):
            self.lock = lock

        @lock_decorator(attr='lock')
        def method(self, a):
            return a

    with mock.patch('threading.Lock') as mock_Lock:
        mock_Lock().__enter__.return_value = None
        mock_Lock().__exit__.return_value = None
        DummyClass().method(1)

    with mock.patch('threading.Lock') as mock_Lock:
        mock_Lock().__enter__.return_value = None
        mock_Lock().__exit__.return_value = None
        inst = DummyClass(lock=mock_Lock())
        assert inst.method(1) == 1

# Generated at 2022-06-23 14:17:40.389650
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Lock

    class Test(object):
        def __init__(self):
            self.lock = Lock()
            self.value = 0
            self.lock_value = 0
            self.attr_value = 0

        @lock_decorator(attr='lock')
        def add_value(self):
            self.value += 1

        @lock_decorator(lock=self.lock)
        def add_lock_value(self):
            self.lock_value += 1

        @lock_decorator()
        def add_attr_value(self):
            self.attr_value += 1

    t = Test()
    def multiple_thread_test():
        for i in range(1000000):
            t.add_value()
            t.add_lock_value()
            t

# Generated at 2022-06-23 14:17:50.771685
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    l = threading.Lock()
    global x
    x = 0

    @lock_decorator(lock=l)
    def f():
        global x
        x += 1

    def run():
        for i in range(1000):
            f()

    th = [threading.Thread(target=run) for i in range(2)]
    for t in th:
        t.start()

    for t in th:
        t.join()

    assert x == 2000

    class Foo(object):

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def f(self):
            global x
            x += 1

    foo = Foo()


# Generated at 2022-06-23 14:17:56.061178
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    class Foo(object):
        def __init__(self):
            self._lock = mock.Mock()

        @lock_decorator(attr='_lock')
        def bar(self, *args, **kwargs):
            pass

    f = Foo()
    f.bar()
    assert f._lock.__enter__.call_count == 1
    assert f._lock.__exit__.call_count == 1

# Generated at 2022-06-23 14:18:07.401400
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.count = 0

        @lock_decorator(attr='_lock')
        def add_count(self):
            self.count += 1
            sleep(0.1)

        @lock_decorator(lock=threading.Lock())
        def add_count_lock(self):
            self.count += 1
            sleep(0.1)

    def add_count(test_obj):
        test_obj.count += 1
        sleep(0.1)

    def test_class(test_obj, func):
        # create an extra lock that is *not* used by the
        # lock_decorator
        lock = threading.Lock()


# Generated at 2022-06-23 14:18:19.462044
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class Test(object):
        def __init__(self, interval=1, timeout=5):
            self.timeout = 5
            self.interval = interval
            self._test_lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='_test_lock')
        def add_one(self, amount):
            self.value += amount
            sleep(self.interval)

    # Instantiate our test object that will use a lock
    t = Test(interval=0.01)
    threads = []

    def _test():
        t.add_one(1)

    # Create 10 threads that will run our test method
    for x in range(10):
        thread = threading.Thread(target=_test)
        thread.start

# Generated at 2022-06-23 14:18:29.574489
# Unit test for function lock_decorator
def test_lock_decorator():

    import uuid
    import threading

    class TestLock(threading.Lock):

        def __repr__(self):
            return '%s-%s' % (self.__class__.__name__, id(self))

    # lock is a function parameter
    called_list = []
    test_lock = TestLock()

    @lock_decorator(lock=test_lock)
    def test_lock_decorator_lock_parameter(*args, **kwargs):
        called_list.append((args, kwargs))

    test_lock.acquire()
    assert test_lock.acquire(blocking=False) is False
    test_lock_decorator_lock_parameter(1, 2, foo='bar')
    assert len(called_list) == 1
    test_lock_decorator

# Generated at 2022-06-23 14:18:38.232685
# Unit test for function lock_decorator
def test_lock_decorator():
    '''A unit test for the lock_decorator function.'''
    import threading

    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.test_value = 0

        @lock_decorator(attr='lock')
        def change_value(self):
            '''A simple function that increments the test_value
            by 1, used to test the lock_decorator.
            '''
            self.test_value += 1

        @lock_decorator(lock=threading.Lock())
        def change_value_with_lock(self):
            '''A simple function that increments the test_value
            by 1, used to test the lock_decorator with a lock
            explicitly defined.
            '''
            self.test_value += 1

   

# Generated at 2022-06-23 14:18:45.754632
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from unittest import TestCase

    class Test(TestCase):
        def __init__(self, *args, **kwargs):
            self.counter = 0
            self.callback_lock = threading.Lock()
            super(Test, self).__init__(*args, **kwargs)

        @lock_decorator(attr='callback_lock')
        def incr_counter(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def incr_counter2(self):
            self.counter = -1

    t = Test()
    t.incr_counter()
    t.incr_counter()
    assert t.counter == 2
    t.incr_counter2()
    assert t.counter == -1

# Generated at 2022-06-23 14:18:53.066034
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test func
    from threading import Lock
    from random import shuffle, randint

    class A(object):
        def __init__(self):
            self.lock = Lock()
            self.x = 0

    def make_decorator(attr='lock'):
        return lock_decorator(attr=attr)

    def make_decorator_with_lock(lock):
        return lock_decorator(lock=lock)

    def test_func_with_attr_lock():
        incr_lock()
        assert a.x == 1

    def test_func_with_lock(lock):
        with lock:
            a.x += 1
        assert a.x == 1


# Generated at 2022-06-23 14:19:03.155118
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import unittest

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator('_lock')
        def method(self, sleep=0):
            time.sleep(sleep)

    test_attr = TestClass()

    class TestClassWithExplicitLock(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(lock=test_attr._lock)
        def method(self, sleep=0):
            time.sleep(sleep)

    test_explicit_lock = TestClassWithExplicitLock()

    class TestClassWithMissingLock(object):
        def __init__(self):
            pass


# Generated at 2022-06-23 14:19:13.838349
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    if sys.version_info < (3,):
        import imp
        import threading
        mock = imp.new_module('mock')
        sys.modules['mock'] = mock
        mock.Thread = threading.Thread
        mock.threading = threading
    else:
        import unittest.mock as mock
        sys.modules['mock'] = mock

    import unittest

    class TestClass(object):
        '''
        A class that uses the ``lock_decorator``
        '''
        def __init__(self):
            self.some_lock = mock.threading.Lock()
            self.some_value = 0


# Generated at 2022-06-23 14:19:18.473990
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def some_method():
        pass

    assert lock == some_method.lock
    assert some_method.__name__ == 'some_method'

# Generated at 2022-06-23 14:19:23.390834
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestClass(object):
        _lock = None

        def __init__(self):
            self.i = 0
            if self._lock is None:
                self._lock = threading.Lock()

        @lock_decorator()
        def increase(self):
            self.i += 1

    t = TestClass()
    t.increase()
    assert t.i == 1

# Generated at 2022-06-23 14:19:31.904087
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestObj(object):
        def __init__(self):
            self.mutex = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def test_call(self):
            self.mutex += 1

        @lock_decorator(lock=threading.Lock())
        def test_lock(self):
            self.mutex += 1

    class TestCase(unittest.TestCase):
        def test_attr(self):
            obj = TestObj()
            obj.test_call()
            self.assertEqual(obj.mutex, 1)

        def test_lock(self):
            obj = TestObj()
            obj.test_lock()

# Generated at 2022-06-23 14:19:43.937169
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    failed = False
    class Test(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback = 'a'
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, new_value):
            self._callback = new_value

    test = Test()
    test.send_callback('b')
    assert test._callback == 'b'

    def test_thread(test):
        test.send_callback('c')
        if test._callback != 'c':
            nonlocal failed
            failed = True
    threading.Thread(target=test_thread, args=(test,)).start()
    threading.Thread(target=test_thread, args=(test,)).start()

# Generated at 2022-06-23 14:19:52.389509
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLock(object):
        def __init__(self):
            # set up the lock
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_method(self, val):
            # set a local value
            self._val = val
            time.sleep(1)
            # return the value
            return self._val

    def test_func():
        # instantiate the class
        tl = TestLock()
        # run the wrapped method
        tl.lock_method(5)

    # create a thread
    t1 = threading.Thread(target=test_func)
    # create another thread
    t2 = threading.Thread(target=test_func)
    # start the first thread
    t1.start

# Generated at 2022-06-23 14:20:03.686226
# Unit test for function lock_decorator
def test_lock_decorator():
  import types
  import unittest

  def assert_wrapped(wrapped_func, decorated_func):
    assert wrapped_func.__name__ == decorated_func.__name__
    assert wrapped_func.__doc__ == decorated_func.__doc__
    assert wrapped_func.__module__ == decorated_func.__module__
    assert wrapped_func.__defaults__ == decorated_func.__defaults__
    assert wrapped_func.__kwdefaults__ == decorated_func.__kwdefaults__

  class TestLockDecorator(unittest.TestCase):
    test_string = 'abcdefg'

    def assert_lock_decorator(self, func):
      self.assertIsInstance(func, types.FunctionType)
      assert_wrapped(func, TestLockDecorator.func)


# Generated at 2022-06-23 14:20:15.062381
# Unit test for function lock_decorator
def test_lock_decorator():
    try: import threading
    except ImportError: return
    import time

    class LockingThing:
        '''A simple class which uses lock_decorator() to hold a list of integers
        while this object's wait_hold method is being called.
        '''
        def __init__(self, *items):
            self.items = list(items)
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def wait_hold(self, duration):
            '''Wait for a certain duration (in seconds) and return the value of
            self.items.
            '''
            time.sleep(duration)
            return self.items

    lt = LockingThing(1, 2, 3)


# Generated at 2022-06-23 14:20:24.517373
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    import random

    class TestClass(object):
        _lock = Lock()
        _value = 0

        @classmethod
        @lock_decorator(attr='_lock')
        def class_method(cls, value):
            cls._value += value

        @staticmethod
        @lock_decorator(lock=Lock())
        def static_method(value):
            TestClass._value += value

        @lock_decorator(attr='_lock')
        def instance_method(self, value):
            self._value += value

    for i in range(1000):
        value = random.randint(1, 100)
        TestClass.class_method(value=value)
        TestClass.static_method(value=value)
        TestClass().instance_method(value=value)



# Generated at 2022-06-23 14:20:33.903960
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        # Running on Python2, skipping
        return
    class A(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            pass

    class B(object):
        _lock = threading.Lock()

        @lock_decorator(lock=_lock)
        def some_method(self):
            pass

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:20:39.810037
# Unit test for function lock_decorator
def test_lock_decorator():
    class Tester(object):
        @lock_decorator(attr='_my_lock')
        def method(self, x, y):
            return x + y


    t = Tester()
    t._my_lock = type('T', (object,), {'__enter__': lambda self: None, '__exit__': lambda self, *args: None})
    assert t.method(1, 2) == 3
    assert t.method(10, 20) == 30


# Generated at 2022-06-23 14:20:46.435368
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyClass(object):

        def __init__(self, l=None):
            self.lock = l if l is not None else threading.Lock()

        def my_method(self):
            return

        @lock_decorator(attr='lock')
        def my_locked_method(self):
            return

        @lock_decorator(lock=threading.Lock())
        def my_static_locked_method(self):
            return

# Generated at 2022-06-23 14:20:56.522865
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyCls:
        def __init__(self, val=1):
            self.val = val
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def incr_val(self):
            self.val += 1

        def raise_exception(self):
            raise Exception()

        @lock_decorator(lock=threading.Lock())
        def set_val(self, val):
            self.val = val

        @lock_decorator(attr='missing_lock_attr')
        def access_missing_attr(self):
            pass

    obj = MyCls()
    for i in range(10):
        threading.Thread(target=obj.incr_val).start()
    with threading.Lock():
        obj

# Generated at 2022-06-23 14:21:05.733759
# Unit test for function lock_decorator
def test_lock_decorator():

    import unittest
    from unittest.mock import Mock
    import threading

    class MockDelayedCall(object):

        def __init__(self, f, args=None, kwargs=None, delay=None):
            pass

    class TestClass(object):
        def __init__(self, *args, **kwargs):
            pass

        @lock_decorator(attr='_lock')
        def _lock_and_no_external_lock(self):
            self.x = 'foo'

        @lock_decorator(lock=threading.Lock())
        def _lock_and_no_internal_lock(self):
            self.x = 'bar'

        @lock_decorator()
        def _no_lock(self):
            self.x = 'baz'


# Generated at 2022-06-23 14:21:14.509751
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test_lock_decorator:
        lock = threading.Lock()
        test_lock = False
        @lock_decorator(attr='lock')
        def lock_attr_with_one_arg(self):
            assert not self.test_lock, 'lock_attr_with_one_arg condition 1'
            self.test_lock = True
        @lock_decorator(lock=lock)
        def lock_with_lock(self):
            assert not self.test_lock, 'lock_with_lock condition 1'
            self.test_lock = True
        @lock_decorator()
        def no_lock(self):
            assert self.test_lock, 'no_lock condition 1'
        def clear(self):
            self.test_lock = False

    t = Test_

# Generated at 2022-06-23 14:21:18.875854
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading

    lock = threading.Lock()
    lock_attr = 'this_is_the_lock'
    obj = object()  # object to test with

    # test with a lock object
    def test_with_lock():
        assert not lock.locked()
        with lock:
            assert lock.locked()
        assert not lock.locked()

    lock_decorator(lock=lock)(test_with_lock)()

    # test with the lock as an instance attribute
    def test_with_attr(self):
        assert not getattr(self, lock_attr).locked()
        with getattr(self, lock_attr):
            assert getattr(self, lock_attr).locked()
        assert not getattr(self, lock_attr).locked()

    # test error path

# Generated at 2022-06-23 14:21:27.095856
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    from queue import Queue
    from time import sleep

    class MockObject(object):
        _instance_lock = Lock()
        _instance_queue = Queue()
        _instance_value = 0

        @lock_decorator(attr='_instance_lock')
        def add_to_queue(self, item):
            MockObject._instance_queue.put(item)

        @lock_decorator(attr='_instance_lock')
        def modify_value(self, delta):
            MockObject._instance_value += delta

        @lock_decorator(attr='_instance_lock')
        def get_value(self):
            return MockObject._instance_value

    mock_object = MockObject()
    queue = MockObject._instance_queue


# Generated at 2022-06-23 14:21:37.540307
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.counter = 0
            self.threads = []

        @lock_decorator(attr='lock')
        def increment(self):
            self.counter += 1
            time.sleep(2)

    class Runner(threading.Thread):
        def __init__(self, obj, count):
            super(Runner, self).__init__()
            self.obj = obj
            self.count = count
            self.start()
            self.obj.threads.append(self)

        def run(self):
            for i in range(self.count):
                self.obj.increment()

    # Create an instance of the test object
    t = Test()

    #

# Generated at 2022-06-23 14:21:47.240780
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestCase
    from threading import Lock

    class CustomLock(object):
        def __enter__(self):
            pass

        def __exit__(self, exc_type, exc_value, traceback):
            pass

    class Test(TestCase):
        def setUp(self):
            self._test = 'hello world'

        @lock_decorator(lock=Lock())
        def test(self, update=None):
            if update:
                self._test = update

        @lock_decorator(attr='_custom_lock')
        def test2(self, update=None):
            if update:
                self._test = update

        @lock_decorator(lock=CustomLock())
        def test3(self, update=None):
            if update:
                self._test = update



# Generated at 2022-06-23 14:21:53.965967
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def locked(self):
            return 'locked'

    assert Foo().locked() == 'locked'

    class Foo(object):
        @lock_decorator(lock=threading.Lock())
        def locked(self):
            return 'locked'

    assert Foo().locked() == 'locked'

# Generated at 2022-06-23 14:22:03.448370
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for lock_decorator'''
    from threading import Event, Thread
    from time import sleep, time

    class TestLock(object):
        def __init__(self):
            self.called = 0
            self.counter = 0
            self.lock = Event()

        @lock_decorator(attr='lock')
        def increment(self):
            self.called += 1
            sleep(0.1)
            self.counter += 1

    test_lock = TestLock()

    start = time()
    threads = [Thread(target=test_lock.increment) for _ in range(10)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    end = time()

    assert end - start > 1
    assert test_lock.counter == 10
   

# Generated at 2022-06-23 14:22:14.780038
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class Sample(object):

        def __init__(self):
            self._lock = threading.Lock()
            self.called = False

        @lock_decorator(attr='_lock')
        def sample_method(self):
            sleep(0.01)
            self.called = True

    def test_lock():
        obj = Sample()
        assert not obj.called

        # Create a bunch of threads to call the method all at (or close
        # to) the same time.
        threads = []
        for _ in range(100):
            t = threading.Thread(target=obj.sample_method)
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        # Since the method was executed inside of a lock,

# Generated at 2022-06-23 14:22:22.115832
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    from threading import Lock, Thread
    import time

    class Foo(object):
        def __init__(self):
            self._lock = Lock()

        def locked(self):
            # Call a locked method multiple times and make
            # sure we see the correct results
            return self._locked()

        @lock_decorator(attr='_lock')
        def _locked(self):
            # Put a sleep here to ensure we are able to
            # test the lock.
            time.sleep(1)
            # Return the current time, if we can call
            # this function multiple time and get the
            # same time, then we are not properly locking
            return time.time()

    class Test(unittest.TestCase):
        def test_decorator(self):
            foo = Foo()
            self

# Generated at 2022-06-23 14:22:28.663169
# Unit test for function lock_decorator
def test_lock_decorator():  # pragma: no cover
    import threading
    lock = threading.Lock()
    class Thing(object):
        @lock_decorator(attr='__lock', lock=lock)
        def method1(self, name):
            print(name)

        @lock_decorator(lock=lock)
        def method2(self, name):
            print(name)

    thing = Thing()
    thing.method1('a')
    thing.method2('b')



# Generated at 2022-06-23 14:22:39.684778
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading
    import time

    class MyThing(object):
        '''This is a class that uses MyThing to mock the lock decorator.
        It simulates the count being incremented on different threads.
        Without the lock, this would fail the test.
        '''
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.count = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            time.sleep(0.1)
            self.count += 1

    # Create the mock of the thread
    mock_thread = mock.Mock()
    # We are trying to simulate 100 threads

# Generated at 2022-06-23 14:22:50.676165
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    If the function is called without a specified lock or attribute, it should fail
    If a lock is specified, it should work
    If an unknown attribute is specified, a function call should fail
    If a known attribute is specified, a function call should work
    '''
    class X(object):
        def __init__(self):
            self.a = 1

        @lock_decorator()
        def x_inc(self):
            self.a += 1

        def x_dec(self):
            self.a -= 1

    x = X()
    try:
        x.x_inc()
    except AttributeError as e:
        pass
    else:
        raise AssertionError("Expected an exception, but none was thrown")

    import threading
    lock = threading.Lock()


# Generated at 2022-06-23 14:23:01.140370
# Unit test for function lock_decorator
def test_lock_decorator():
    class A(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test(self):
            pass

    class B(object):
        def __init__(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def test(self):
            pass

    # Make sure the lock is being used
    # This will fail if the lock is not actually used
    a = A()
    with pytest.raises(AssertionError):
        a.test()

    b = B()
    with pytest.raises(AssertionError):
        b.test()

# Generated at 2022-06-23 14:23:11.761679
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    class MyClass(object):

        def __init__(self):
            self._decorator_attrib = threading.Lock()
            self._decorator_lock = None
            self._common = 0

        @lock_decorator(attr='_decorator_attrib')
        def lock_method_attrib(self):
            self._common += 1

        @lock_decorator(lock=threading.Lock())
        def lock_method_lock(self):
            self._common += 1

    def lock_methods_thread(mc):
        for i in range(100):
            mc.lock_method_attrib()
            mc.lock_method_lock()

    mc = MyClass()
    threads = []
    for i in range(5):
        t = thread

# Generated at 2022-06-23 14:23:22.012976
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class _FakeLock(object):
        def __init__(self):
            self._lock = False
        def __enter__(self):
            assert not self._lock
            self._lock = True
        def __exit__(self, typ, val, traceback):
            assert self._lock
            self._lock = False

    class FakeClass(object):
        def __init__(self):
            self._lock = _FakeLock()

        @lock_decorator(attr='_lock')
        def attr_lock(self):
            assert self._lock._lock

        @lock_decorator(lock=_FakeLock())
        def fake_lock(self):
            pass

    FakeClass().attr_lock()
    FakeClass().fake_lock()

# Generated at 2022-06-23 14:23:29.040460
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestLock:
        def __init__(self):
            self.test_lock = threading.Lock()
            self.test_lock_attr = threading.Lock()
        @lock_decorator(lock=self.test_lock)
        def test_lock_send(self, val):
            return val
        @lock_decorator(attr='test_lock_attr')
        def test_lock_get_attr(self, val):
            return val
    test = TestLock()
    assert test.test_lock_send(42) == 42
    assert test.test_lock_get_attr(42) == 42

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:23:35.995674
# Unit test for function lock_decorator
def test_lock_decorator():
    # Lock decorator works fine with a pre-defined lock attr
    import threading
    class A(object):
        def __init__(self):
            self._lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def __str__(self):
            return 'A'
    assert str(A()) == 'A'

    # Lock decorator works fine with a passed lock
    import threading
    class B(object):
        @lock_decorator(lock=threading.Lock())
        def __str__(self):
            return 'B'
    assert str(B()) == 'B'


# Generated at 2022-06-23 14:23:46.430964
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from nose.tools import assert_equals
    try:
        from nose.tools import assert_regexp_matches  # pylint: disable=no-name-in-module
    except ImportError:
        from nose.tools import assert_regexp_matches  # pylint: disable=redefined-builtin
    # set up a global lock in case the lock_decorator doesn't work
    m_lock = threading.Lock()
    class SomeClass(object):
        # create the lock as an instance attribute
        _callback_lock = threading.Lock()

        def __init__(self):
            # make sure the instance is empty to start
            self.m_list = list()

        # decorate the method so we can access self._callback_lock

# Generated at 2022-06-23 14:23:57.062550
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit tests for lock_decorator'''
    import threading

    class LockTest(object):
        '''LockTest class'''
        def __init__(self):
            '''Init method'''
            self.attr_lock = threading.Lock()
            self.lock_lock = None

        @lock_decorator(attr='attr_lock', lock=None)
        def attr_locked_method(self):
            '''attr_locked_method'''
            return True

        @lock_decorator(attr=None, lock=threading.Lock())
        def lock_locked_method(self):
            '''lock_locked_method'''
            return True

    locktest = LockTest()
    assert locktest.attr_locked_method()

    locktest.lock_lock = threading.Lock

# Generated at 2022-06-23 14:24:07.288213
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    def non_locked():
        non_locked._called = True

    def locked():
        locked._called = True


    locked = lock_decorator(lock=threading.Lock())(locked)

    class LockManager(object):
        _lock = threading.Lock()

    class Locked(LockManager):
        @lock_decorator(attr='_lock')
        def method(self):
            Locked.method._called = True

    non_locked()
    locked()
    assert non_locked._called
    assert locked._called

    non_locked._called = False
    locked._called = False

    for _ in range(10):
        t = threading.Thread(target=non_locked)
        t.start()
    assert non_locked._called



# Generated at 2022-06-23 14:24:14.588829
# Unit test for function lock_decorator
def test_lock_decorator():
    import ansible.module_utils.s3 as s3_util
    import unittest
    class TestClass(object):
        _lock = s3_util.SemaphoreLock()

        @lock_decorator(attr='_lock')
        def a_method(self):
            return 'a_method'
    class TestLockDecorator(unittest.TestCase):
        def test_lock_decorator(self):
            tc = TestClass()
            self.assertEqual(tc.a_method(), 'a_method')

# Generated at 2022-06-23 14:24:25.284716
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    lock = threading.Lock()

    _list = []

    @lock_decorator(lock=lock)
    def func1(arg):
        time.sleep(0.01)
        _list.append(arg)

    @lock_decorator(lock=lock)
    def func2(arg):
        time.sleep(0.01)
        _list.append(arg)

    threads = []
    for i in range(10):
        t = threading.Thread(target=func1, args=(i,))
        t.start()
        threads.append(t)

    for i in range(10, 20):
        t = threading.Thread(target=func2, args=(i,))
        t.start()
        threads.append(t)


# Generated at 2022-06-23 14:24:33.205403
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class DummyClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.locked = False

        @lock_decorator(attr='_callback_lock')
        def test_locked_attr(self):
            self.locked = True

        @lock_decorator(lock=threading.Lock())
        def test_locked_kwarg(self):
            self.locked = True

    dummy = DummyClass()
    assert dummy.locked is False
    dummy.test_locked_attr()
    assert dummy.locked is True
    dummy.test_locked_kwarg()
    assert dummy.locked is True

# Generated at 2022-06-23 14:24:44.163325
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Dummy(object):
        def __init__(self):
            self.state = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment_state(self):
            self.state += 1

        @lock_decorator(lock=threading.Lock())
        def subtract_state(self):
            self.state -= 1

    D = Dummy()

    # Verify that calling outside of threads works
    D.increment_state()
    D.subtract_state()

    assert D.state == 0

    # Verify that calling within a thread fails
    # when not using lock decorator
    def set_state_thread(D):
        D.state = -1


# Generated at 2022-06-23 14:24:52.588946
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    class Test(object):
        @lock_decorator(attr='lock')
        def func(self, arg):
            return arg

        @lock_decorator(lock=mock.Mock())
        def method(self, arg2):
            return arg2 * 2

    # Mock the lock
    Test.lock = mock.Mock()

    # Verify the lock context manager was called
    assert Test.func(Test(), 'arg') == 'arg'
    Test.lock.__enter__.assert_called_once_with()

    # Verify the lock context manager was called for the method
    assert Test.method(Test(), 'arg2') == 'arg2arg2'
    Test.lock.__enter__.assert_called_with()

# Generated at 2022-06-23 14:25:00.474092
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread
    import time

    class Test(object):
        def __init__(self):
            self._test_lock = threading.Lock()
            self._num = 0

        @lock_decorator(attr='_test_lock')
        def test(self):
            self._num += 1
            time.sleep(1)
            return self._num

    threads = []
    t = Test()
    for i in range(1000):
        thread = Thread(target=t.test)
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()
    assert t._num == 1000

# Generated at 2022-06-23 14:25:08.681211
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import sys

    class C(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def f(self):
            with open('/tmp/out', 'a+') as f:
                f.write('%s:%s\n' % (threading.current_thread().name, time.time()))
                time.sleep(0.1)

    threads = []
    for _ in range(5):
        t = threading.Thread(target=C().f)
        threads.append(t)

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    print('=' * 78)
    print('Contents of file /tmp/out:')
    print('=' * 78)

# Generated at 2022-06-23 14:25:17.204625
# Unit test for function lock_decorator
def test_lock_decorator():
    class Foo(object):
        _lock = None

        def __init__(self):
            self._lock = threading.Lock()

        def __enter__(self):
            return self._lock.acquire()

        def __exit__(self, exc_type, exc_value, traceback):
            return self._lock.release()

        @lock_decorator(attr='_lock')
        def _some_method(self):
            pass

    f = Foo()

    assert f._lock._nb_owner
    assert_raises(RuntimeError, f._some_method)

    with f:
        assert_raises(RuntimeError, f._some_method)



# Generated at 2022-06-23 14:25:26.684130
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock, Event

    class TestClass(object):
        @lock_decorator(attr='_lock')
        def send_callback(self, val):
            for i in range(self._num):
                self._counter.value += val

    lock = Lock()

    counter = 0
    for i in range(3):
        event = Event()
        event.set()
        num = 3

        obj = TestClass()
        obj._lock = lock
        obj._num = num
        obj._counter = counter

        threads = [Thread(target=obj.send_callback, args=(i,)) for i in range(num)]
        with lock:
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()


# Generated at 2022-06-23 14:25:38.484513
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class MockLock(object):
        def __enter__(self):
            self._entered = True

        def __exit__(self, exc_type, exc_value, exc_tb):
            self._exit = (exc_type, exc_value, exc_tb)

    class MockObj(object):
        def __init__(self):
            self._callback_lock = MockLock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, msg):
            return msg

    class MockObj2(object):
        def __init__(self):
            self._callback_lock = MockLock()

        @lock_decorator(lock=MockLock())
        def send_callback(self, msg):
            return msg


# Generated at 2022-06-23 14:25:47.763852
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    class Test(unittest.TestCase):
        def test_attr_lock(self):
            def some_method(self):
                self.counter += 1
            class Object(object):
                counter = 0
                @lock_decorator(attr='lock')
                def incr(self):
                    self.counter += 1
            o = Object()
            o.lock = threading.Lock()
            o.incr()
            self.assertEqual(o.counter, 1)

        def test_lock_parameter(self):
            def some_method(self):
                self.counter += 1
            class Object(object):
                counter = 0
                @lock_decorator(lock=threading.Lock())
                def incr(self):
                    self.counter += 1


# Generated at 2022-06-23 14:25:57.272787
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        '''Foo Class'''
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def foo_method(self, x):
            print(x)

    foo = Foo()
    foo.foo_method('Foo')

    foo.foo_method = lock_decorator(attr='_lock')(foo.foo_method)
    foo.foo_method('Bar')

    @lock_decorator(lock=threading.Lock())
    def bar_method(x):
        print(x)

    bar_method('bar')

# Generated at 2022-06-23 14:26:05.654804
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a class that will have a callback lock
    class foo:
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.lock_contents = []

        @lock_decorator(attr='_callback_lock')
        def callback(self, num):
            # Sleep to simulate a slower operation
            time.sleep(0.01)
            # Add the number to the shared list
            self.lock_contents.append(num)

    # Create the object
    obj = foo()
    # Create a bunch of threads to bump the lock
    threads = [threading.Thread(target=obj.callback, args=(x,)) for x in range(1000)]
    # Start all the threads
    [x.start() for x in threads]
    # Wait for all the threads to finish

# Generated at 2022-06-23 14:26:15.498503
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test():
        def __init__(self):
            self._lock = threading.Lock()
            self.result = 0

        @lock_decorator(attr='_lock')
        def locked(self, num):
            self.result += num

        @lock_decorator(lock=threading.Lock())
        def some_func(self, num):
            self.result += num

    def lock_test(obj, num):
        for i in range(num):
            obj.locked(1)
            obj.some_func(1)

    t = Test()

    thread1 = threading.Thread(target=lock_test, args=(t, 5000000))
    thread2 = threading.Thread(target=lock_test, args=(t, 5000000))

# Generated at 2022-06-23 14:26:26.711484
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyObj(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.cnt = 0

        @lock_decorator(attr='_callback_lock')
        def inc_var(self):
            self.cnt += 1

        @lock_decorator(lock=self._callback_lock)
        def inc_var_lock(self):
            self.cnt += 1

    myobj = MyObj()
    myobj.inc_var()
    assert myobj.cnt == 1
    myobj.inc_var_lock()
    assert myobj.cnt == 2

# Generated at 2022-06-23 14:26:38.183193
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestLock(object):
        # Pre-defined lock
        _test_lock = threading.Lock()

        def __init__(self):
            # Lock as part of the object
            self._obj_lock = threading.Lock()

        @lock_decorator(attr='_test_lock')
        def lock_predefined_func(self):
            pass

        @lock_decorator(attr='_missing_lock_attr')
        def lock_missing_attr_func(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def lock_passed_lock_func(self):
            pass

        @lock_decorator(attr='_obj_lock')
        def lock_obj_func(self):
            pass

    test_lock = TestLock()

# Generated at 2022-06-23 14:26:44.842835
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Function lock_decorator'''
    import sys
    import threading
    if sys.version_info < (3,):
        import mock
        from mock import patch
    else:
        from unittest import mock
        from unittest.mock import patch

    lock = threading.Lock()
    lattr = '_lock_attr'
    class SomeClass(object):
        '''Some class'''

        def __init__(self):
            self._lock_attr = lock

        def lock_attr(self):
            '''Some method using the lock attribute'''
            with patch('ansible.module_utils.basic.lock_decorator._lock.__enter__') as mock_enter:
                mock_enter.return_value = None

# Generated at 2022-06-23 14:26:54.448055
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestLockDecorator(unittest.TestCase):

        def test_attr(self):
            class foo(object):
                lock = threading.Lock()
                @lock_decorator(attr='lock')
                def bar(self):
                    assert self.lock.locked()

            foo().bar()

        def test_lock(self):
            class foo(object):
                @lock_decorator(lock=threading.Lock())
                def bar(self):
                    assert self.bar.__globals__['lock'].locked()

            foo().bar()
    test_loader = unittest.TestLoader()
    test_suite = test_loader.loadTestsFromTestCase(TestLockDecorator)

# Generated at 2022-06-23 14:27:04.842730
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Foo(object):
        def __init__(self):
            self.a = 0
            self._lock = threading.Lock()
            self.threads = []

        @lock_decorator(attr='_lock')
        def method(self):
            self.a += 1
            return self.a

    foo = Foo()

    # Ensure that the lock works
    assert foo.method() == 1
    assert foo.method() == 2

    # Ensure that the lock works across threads
    def _foo_method():
        print(foo.method())

    def _foo_threads():
        for i in range(10):
            t = threading.Thread(target=_foo_method)
            foo.threads.append(t)
            t.start()

# Generated at 2022-06-23 14:27:14.703974
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        return
    import time
    import random

    class Foo:
        def __init__(self):
            self.bar = 0
            self.baz = 0
            self._lock = threading.Lock()

    def _increment_bar(obj, wait=0):
        time.sleep(wait)
        obj.bar += 1

    def _increment_baz(wait=0, **kwargs):
        time.sleep(wait)
        obj.baz += 1

    @lock_decorator(attr='_lock')
    def increment_bar(obj, wait=0):
        time.sleep(wait)
        obj.bar += 1

    @lock_decorator()
    def increment_baz(wait=0, **kwargs):
        time

# Generated at 2022-06-23 14:27:24.019929
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from threading import Lock
    except ImportError:
        try:
            # Python2
            from thread import Lock
        except ImportError:
            return

    class TestClass(object):
        def __init__(self):
            self.lock = Lock()

        @lock_decorator(lock=None, attr='lock')
        def run_method(self, nr):
            import time
            time.sleep(1)
            assert nr == 1
            assert self.lock.locked()

    a = TestClass()
    import threading
    t1 = threading.Thread(target=a.run_method, args=[1])
    t1.daemon = True
    t1.start()
    t1.join()
    assert not a.lock.locked()