

# Generated at 2022-06-23 14:17:30.928842
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class LockDecoratorTest(object):

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self):
            return time.time()

    class LockDecoratorTest2(object):

        @lock_decorator(lock=threading.Lock())
        def method(self):
            return time.time()

    for cls in [LockDecoratorTest, LockDecoratorTest2]:
        ld = cls()
        result = [ld.method() for _ in range(10)]
        assert len(result) == len(set(result))

# Generated at 2022-06-23 14:17:39.596368
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import RLock
    from threading import Lock
    from threading import Thread
    from threading import Event

    class Test:
        @lock_decorator(attr='_attr')
        def method(self):
            self._attr = True

        @lock_decorator(lock=RLock())
        def other(self):
            self._other = True

    t = Test()
    t.method()
    assert t._attr is True

    t2 = Test()
    t2.other()
    assert t2._other is True


with open('../ansible/module_utils/network/cloudengine/ce/__init__.py') as f:
    for line in f.readlines():
        if line.startswith('__metaclass__'):
            break
    else:
        raise RuntimeError

# Generated at 2022-06-23 14:17:45.014780
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    This function tests the lock decorator
    '''

    import threading

    class foo:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def bar(self):
            # this code should be locked
            return True

    class foo2:
        def bar2(self):
            # this code should not be locked
            return True

        @lock_decorator(lock=threading.Lock())
        def bar(self):
            # this code should be locked
            return True

    class foo3:
        def bar3(self):
            # this code should not be locked
            return True

        @lock_decorator(lock=threading.Lock())
        def bar(self):
            raise NotImplementedError

# Generated at 2022-06-23 14:17:50.911406
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class T(object):
        def __init__(self):
            self.lock = threading.Lock()
        @lock_decorator(attr='lock')
        def _method_one(self):
            pass
        @lock_decorator(lock=threading.Lock())
        def _method_two(self):
            pass

    t = T()
    t._method_one()
    t._method_two()

# Generated at 2022-06-23 14:18:00.664346
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestThreading(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.some_lock = threading.Lock()
            self.val = 0

        @lock_decorator(attr='_test_lock')
        def _test_func(self, sleep_time=0.2):
            self.val += 1
            time.sleep(sleep_time)

        @lock_decorator(attr='some_lock')
        def _test_func_2(self, sleep_time=0.2):
            self.val += 1
            time.sleep(sleep_time)

        def run(self):
            self._test_func()
            self._test_func(0.5)
            self._test_func

# Generated at 2022-06-23 14:18:09.131126
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test:
        _lock1 = threading.Lock()
        @lock_decorator(attr='_lock1')
        def lock1(self, name):
            return 'lock1 %s' % name

        _lock2 = threading.Lock()
        @lock_decorator(lock=_lock2)
        def lock2(self, name):
            return 'lock2 %s' % name

        def no_lock(self, name):
            return 'no_lock %s' % name

    t = Test()
    assert t.lock1('test') == 'lock1 test'
    assert t.lock2('test') == 'lock2 test'
    assert t.no_lock('test') == 'no_lock test'

# Generated at 2022-06-23 14:18:20.275955
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    obj = FuncObj()
    assert obj.value == 0

    # When not using a lock, concurrency issues will cause
    # the object's value to be greater than expected
    for _ in range(100):
        # Start a thread that increments the object value
        t = threading.Thread(target=obj.increment, args=(1,))
        # Ensure we start the thread
        t.start()
        # Wait for the thread to finish
        t.join()

    # Ensure we have more than the expected value
    assert obj.value > 100

    # Reset the value
    obj.value = 0
    # Ensure the reset was successful
    assert obj.value == 0

    # When using a lock, concurrency issues should not be present

# Generated at 2022-06-23 14:18:30.237193
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.lock = threading.Lock()
            self.lock_attr = threading.Lock()

        @lock_decorator()
        def assert_decorator_no_args(self):
            raise AssertionError

        @lock_decorator(attr='missing_lock_attr')
        def assert_decorator_attr_missing(self):
            raise AssertionError

        @lock_decorator(lock=None)
        def assert_decorator_lock_none(self):
            raise AssertionError

        @lock_decorator(attr='lock_attr')
        def assert_decorator_attr_present(self):
            raise Assertion

# Generated at 2022-06-23 14:18:38.825178
# Unit test for function lock_decorator
def test_lock_decorator():
    class Obj1:
        def __init__(self):
            self._lock = True

        @lock_decorator(attr='_lock')
        def lock_attr(self):
            return self._lock

    class Obj2:
        _lock = True

        @lock_decorator(attr='_lock')
        def lock_attr(self):
            return self._lock

    class Obj3:
        def __init__(self):
            self._lock = False

        @lock_decorator(attr='_lock')
        def lock_attr(self):
            return self._lock

    class Obj4:
        _lock = False

        @lock_decorator(attr='_lock')
        def lock_attr(self):
            return self._lock


# Generated at 2022-06-23 14:18:45.893409
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MockClass(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def method1(self):
            return 'method1'
        @lock_decorator(lock=_lock)
        def method2(self):
            return 'method2'
    mock = MockClass()
    assert mock.method1() == 'method1'
    assert mock.method2() == 'method2'

# Generated at 2022-06-23 14:18:56.761206
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    shared = 0

    class Test(object):
        def __init__(self, lock):
            self._lock = lock

        @lock_decorator()
        def test_attr(self):
            global shared

            shared += 1

        @lock_decorator('_lock')
        def test_opt_attr(self):
            global shared

            shared += 1

        @lock_decorator(lock=lock)
        def test_opt_lock(self):
            global shared

            shared += 1

    # Confirm all three methods raise when we don't pass the lock
    t = Test(lock)
    raised = False
    try:
        t.test_attr()
    except AttributeError:
        raised = True
    assert raised

    raised = False
   

# Generated at 2022-06-23 14:19:05.171840
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    import unittest

    class LockTester(object):
        def __init__(self, *args, **kwargs):
            self.counter = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test1(self, *args, **kwargs):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def test2(self, *args, **kwargs):
            self.counter += 1

    class LockTesterTestCase(unittest.TestCase):
        def setUp(self):
            self.tester = LockTester()

        def test_lock_decorator(self):
            self.tester.test1()

# Generated at 2022-06-23 14:19:13.325724
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestLock(object):

        @lock_decorator(attr='_lock')
        def locked_method(self, value):
            return value

        def __init__(self):
            self._lock = threading.Lock()

    class TestExplicitLock(object):

        _lock = threading.Lock()

        @lock_decorator(lock=_lock)
        def locked_method(self):
            pass

    assert TestLock().locked_method(True) is True
    assert TestExplicitLock().locked_method() is None

# Generated at 2022-06-23 14:19:24.228348
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class LockTest(object):
        def __init__(self):
            self._test_lock = threading.Lock()
            self._test_counter = 0

        @lock_decorator()
        def missing_lock_attr(self):
            self._test_counter += 1

        @lock_decorator(attr='_test_lock')
        def test_lock(self, increment=0):
            self._test_counter += increment

        @lock_decorator(lock=threading.Lock())
        def test_lock_object(self, increment=0):
            self._test_counter += increment

    lt = LockTest()
    lt.missing_lock_attr()
    assert lt._test_counter == 0, 'Missing lock attr'


# Generated at 2022-06-23 14:19:25.079433
# Unit test for function lock_decorator
def test_lock_decorator():
    # How-to-test-this.md
    pass

# Generated at 2022-06-23 14:19:33.422457
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    import unittest

    class TestLock(object):
        def __init__(self):
            self._lock_attr = Lock()
            self._lock_value = Lock()
            self.locked_attr = 0
            self.locked_value = 0

        @lock_decorator(attr='_lock_attr')
        def locked_attr_test(self):
            self.locked_attr += 1

        @lock_decorator(lock=Lock())
        def locked_value_test(self):
            self.locked_value += 1

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.test = TestLock()

        def tearDown(self):
            del self.test

        def test_locked_attr_test(self):
            self

# Generated at 2022-06-23 14:19:44.719518
# Unit test for function lock_decorator

# Generated at 2022-06-23 14:19:52.833917
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        # ImportError here means that the ``threading`` module doesn't exist
        # either because it is not supported, or because it is a stub.
        # This test is skipped because the module can't be imported
        return

    class TestClass(object):
        _lock = threading.Lock()

        def __init__(self):
            self._counter = 0

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass


# Generated at 2022-06-23 14:20:03.736565
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._a = 0

        @lock_decorator()
        def _inc(self):
            a = self._a
            a += 1
            import time
            time.sleep(0.5)
            self._a = a

        @lock_decorator(attr='_lock')
        def _inc2(self):
            a = self._a
            a += 1
            import time
            time.sleep(0.5)
            self._a = a

    t = Test()

    def inc():
        for x in range(3):
            t._inc()

    def inc2():
        for x in range(3):
            t._inc2()

    #

# Generated at 2022-06-23 14:20:15.160046
# Unit test for function lock_decorator
def test_lock_decorator():
    import collections
    import threading
    import time
    import random

    @lock_decorator(attr='_lock')
    def foo(self):
        time.sleep(random.random()/random.random())

    class Foo:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def foo2(self):
            time.sleep(random.random()/random.random())

    foo = Foo()

    results = collections.OrderedDict()
    def f(func):
        def wrapped(*args, **kwargs):
            with results[func.__name__]:
                return func(*args, **kwargs)
        return wrapped


# Generated at 2022-06-23 14:20:24.580902
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import sys
    import time
    import threading
    from contextlib import contextmanager

    try:
        from Queue import Queue
    except ImportError:
        from queue import Queue

    @contextmanager
    def output_redirect(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = open(os.devnull, 'w')
        sys.stdout = stdout
        try:
            yield
        finally:
            sys.stdout = old

    def in_other_thread(q, meth, *args, **kwargs):
        q.put(meth(*args, **kwargs))

    class Test(object):
        def __init__(self):
            self.lock = lock_decorator(lock=threading.Lock())
            self

# Generated at 2022-06-23 14:20:36.191079
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    def test_func():
        # This func provides the return value of the ``test_inner`` func
        # It attempts to make sure that the ``test_inner`` is only
        # called once per ``test_lock_decorator`` run
        test_func.counter += 1
        time.sleep(0.5)
        return test_func.counter

    test_func.counter = 0

    @lock_decorator(lock=threading.Lock())
    def test_inner():
        # This func uses the ``lock_decorator`` to make sure it
        # is only called once per ``test_lock_decorator`` run
        return test_func()


# Generated at 2022-06-23 14:20:42.979769
# Unit test for function lock_decorator
def test_lock_decorator():
    from mock import Mock

    class Foo(object):
        def __init__(self):
            self._some_lock = Mock()

        @lock_decorator(attr='_some_lock')
        def some_method(self):
            pass

    f = Foo()
    f.some_method()

    assert f._some_lock.acquire.called is True
    assert f._some_lock.release.called is True



# Generated at 2022-06-23 14:20:48.425030
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class SomeClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback_lock.acquire()
            self.called = False

        @lock_decorator(attr='_callback_lock')
        def callback(self):
            self.called = True

    obj = SomeClass()
    assert not obj.called
    obj.callback()
    assert obj.called

# Generated at 2022-06-23 14:20:56.231405
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest

    # Unit test code for function lock_decorator

    class MyClass:
        def __init__(self):
            self.attr = 'lock_attr'
            self.list = []

        @lock_decorator(attr='attr')
        def method(self, item):
            self.list.append(item)

    obj = MyClass()

    obj.method(1)
    assert obj.list == [1]

    obj.method(2)
    assert obj.list == [1, 2]

    obj.method(3)
    assert obj.list == [1, 2, 3]

# Generated at 2022-06-23 14:21:05.481153
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    class TestClass(object):
        _call_lock = threading.Lock()

        @lock_decorator(attr='_call_lock')
        def test_method(self, dt):
            '''
            this method is wrapped within the lock
            '''
            time.sleep(dt)
            return dt

        def test_method2(self, dt):
            '''
            this method is not wrapped inside the lock
            '''
            time.sleep(dt)
            return dt

    test_obj = TestClass()

    # This will block until test_method2 has completed
    test_thread = threading.Thread(target=test_obj.test_method, args=(0.25,))
    test_thread.start()

# Generated at 2022-06-23 14:21:14.272470
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    with pytest.raises(TypeError) as exc:
        lock_decorator()()
    assert exc.value.args[0] == 'Missing lock or attr parameter'

    class Example(object):
        def __init__(self):
            self.lock_attr = 1
            self.lock_no_attr = 2

        @lock_decorator(attr='lock_attr')
        def method_with_lock(self):
            assert self.lock_attr == 1
            self.lock_attr = 2

        @lock_decorator(lock=None)
        def method_without_lock(self):
            assert self.lock_no_attr == 2
            self.lock_no_attr = 3

    ex = Example()

# Generated at 2022-06-23 14:21:23.374746
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    def add_one(num):
        lock.acquire()
        num += 1
        lock.release()
        return num
    # AFAIK, there is no good way to unit test this,
    # so threading.Lock is used in place of our
    # decorator, and then the actual decorator is
    # used to decorate add_one, which should result
    # in identical behaviour
    assert lock_decorator(lock=lock)(add_one)(1) == add_one(1)
    assert lock_decorator(attr='_lock')(add_one)(_lock=lock, num=1) == add_one(1)

# Generated at 2022-06-23 14:21:33.876205
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class C(object):
        class_lock = threading.Lock()
        @classmethod
        @lock_decorator(lock=class_lock)
        def foo(cls):
            # Write random stuff to ``result`` in a thread safe way
            # with the lock held
            cls.result = 'foo'

        # Also works with instance methods
        instance_lock = threading.Lock()
        @lock_decorator(lock=instance_lock)
        def bar(self):
            self.result = 'bar'


        # And when using an attr
        attr_lock = threading.Lock()
        @lock_decorator(attr='attr_lock')
        def baz(self):
            self.result = 'baz'


    # Setup C instance
    c = C

# Generated at 2022-06-23 14:21:43.899232
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Mock(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.i = 0

    @lock_decorator(attr='_callback_lock')
    def send_callback(self):
        '''
        Mock callback that increments ``i`` by 1
        '''
        self.i += 1

    @lock_decorator(lock=threading.Lock())
    def send_callback_explicit_lock(self):
        '''
        Mock callback that increments ``i`` by 2
        '''
        self.i += 2

    obj = Mock()
    threads = []
    for _ in range(0, 10):
        t = threading.Thread(target=send_callback, args=(obj,))
        t.daemon

# Generated at 2022-06-23 14:21:53.229123
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread
    from time import sleep
    from math import log
    from random import random

    class Foo:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator()
        def thread_method(self, i):
            print('Starting thread {0}'.format(i))
            sleep(random() * 2)
            print('Exiting thread {0}'.format(i))

    f = Foo()
    threads = []
    for i in range(5):
        t = Thread(target=f.thread_method, args=[i])
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

# Generated at 2022-06-23 14:22:02.868835
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    import time
    import unittest

    class Modifier(object):
        '''Used for testing lock_decorator'''
        def __init__(self):
            self._lock = threading.Lock()

            # Synchronized is a list because you can't assign to
            # an integer from multiple threads
            self.synchronized = [0]

        @lock_decorator(attr='_lock')
        def synchronize(self):
            time.sleep(0.1)
            self.synchronized[0] += 1

    @lock_decorator(lock=threading.Lock())
    def lock_shared():
        time.sleep(0.1)
        Modifier.synchronized[0] += 1


# Generated at 2022-06-23 14:22:13.298653
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    result = []
    lock = threading.Lock()

    class TestObject:
        def __init__(self, lock):
            self.lock = lock

        @lock_decorator(attr='lock')
        def test_method(self, arg):
            result.append(arg)

    o = TestObject(lock)
    o.test_method('first')
    o.test_method('second')
    assert result == ['first', 'second']

    result = []
    @lock_decorator(lock=lock)
    def test_function(arg):
        result.append(arg)

    test_function('first')
    test_function('second')
    assert result == ['first', 'second']

# Generated at 2022-06-23 14:22:21.372382
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class MyClass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self._counter = 0
            self._output = []

        @lock_decorator(attr='lock')
        def inc_counter(self):
            print("Locking")
            self._counter += 1
            sleep(1)
            self._output.append(self._counter)
            print("Unlocking")

    obj = MyClass()
    t = threading.Thread(target=obj.inc_counter)
    t_2 = threading.Thread(target=obj.inc_counter)
    t.start()
    t_2.start()
    t.join()
    t_2.join()
    assert obj._output == [1, 2]

# Generated at 2022-06-23 14:22:28.075433
# Unit test for function lock_decorator
def test_lock_decorator():
    # Import here so that unit tests can be run from ansible.module_utils
    import threading
    import time

    class Test(object):
        @lock_decorator(attr='_lock')
        def locked(self):
            time.sleep(1)
            return 'done'

    test = Test()
    test._lock = threading.Lock()

    # This will go wrong if the lock is not present
    assert test.locked() == 'done'



# Generated at 2022-06-23 14:22:39.182497
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    test_list = []
    test_list_another = []
    test_list_yet_another = []

    class Test(object):
        def __init__(self):
            self._lock = lock
            self._another_lock = threading.Lock()
            self._yet_another_lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self, test_list):
            test_list.append('method')

        @lock_decorator(attr='_another_lock')
        def another_method(self, test_list):
            test_list.append('another_method')


# Generated at 2022-06-23 14:22:50.162285
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test the lock_decorator function'''
    import threading
    from collections import deque
    from functools import partial

    foo = deque(maxlen=4)

    mylock = threading.Lock()

    @lock_decorator(attr='mylock')
    def foo_append_self(*args, **kwargs):
        return foo.append(*args, **kwargs)

    @lock_decorator(lock=mylock)
    def foo_append_lock(*args, **kwargs):
        return foo.append(*args, **kwargs)

    def foo_append(*args, **kwargs):
        return foo.append(*args, **kwargs)

    foo_append_self.mylock = mylock
    foo_append_lock.mylock = mylock
    foo_append.mylock

# Generated at 2022-06-23 14:22:56.970636
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        '''Unit tests for `lock_decorator`'''
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, cb):
            '''Test the attr kwarg'''
            return cb

        @lock_decorator(lock=threading.Lock())
        def send_callback_lock(self, cb):
            '''Test the lock kwarg'''
            return cb

    test = Test()
    assert test.send_callback('foo') == 'foo'
    assert test.send_callback_lock('foo') == 'foo'

# Generated at 2022-06-23 14:23:08.208817
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from .compat import mock

    class Testclass():
        def __init__(self):
            self._lock = threading.Lock()

    t = Testclass()

    @lock_decorator(lock=t._lock)
    def testfunc(t):
        return "expected"

    assert(t._lock.acquire.call_count == 0)

    t._lock.acquire = mock.MagicMock()
    t._lock.__exit__ = mock.MagicMock()

    assert(testfunc(t) == "expected")
    assert(t._lock.acquire.call_count == 1)
    assert(t._lock.__exit__.call_count == 1)

    @lock_decorator(attr="_lock")
    def testfunc2(t):
        return "expected"

# Generated at 2022-06-23 14:23:16.728343
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class A(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.resource = 0
        @lock_decorator(attr='_lock')
        def inc(self):
            self.resource += 1
        @lock_decorator(lock=threading.Lock())
        def dec(self):
            self.resource -= 1

    a = A()
    a.inc()
    assert a.resource == 1
    a.dec()
    assert a.resource == 0


if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:23:21.000812
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Task:
        @lock_decorator(attr='lock')
        def execute(self, value):
            assert self.lock.locked()
            return value

    task = Task()
    task.lock = threading.Lock()
    assert task.execute(True)


# Generated at 2022-06-23 14:23:28.931091
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class myclass:
        def __init__(self, num):
            self.num = num
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            print("Sending callback from {}".format(self.num))
            time.sleep(1)
            print("Callback complete from {}".format(self.num))
            return self.num

    class mythread(threading.Thread):
        def __init__(self, inst):
            threading.Thread.__init__(self)
            self.inst = inst

        def run(self):
            print("Sending callback from thread {}".format(self.inst.num))
            self.inst.send_callback()

    # Making two class

# Generated at 2022-06-23 14:23:35.734197
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Thing(object):
        def __init__(self, value=None):
            self._lock = threading.Lock()
            self._value = value
        @lock_decorator(attr='_lock')
        def set_value(self, value):
            self._value = value
        @lock_decorator(attr='_lock')
        def get_value(self):
            return self._value

    thing = Thing(42)
    assert thing.get_value() == 42

    thing.set_value(84)
    assert thing.get_value() == 84

# Generated at 2022-06-23 14:23:43.633853
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    class MyClass(object):
        # Fake out the lock attribute
        _lock = None

        @lock_decorator(attr='_lock')
        def method(self):
            self._lock = lock

        @lock_decorator(lock=lock)
        def method2(self):
            pass

    my_obj = MyClass()
    my_obj.method()
    my_obj.method2()

# vim:set sts=4 shiftwidth=4 et:

# Generated at 2022-06-23 14:23:54.879953
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def first(self):
            print('lock_decorator: first: self.loc is %s' % self._lock)

        @lock_decorator(lock=threading.Lock())
        def second(self):
            print('lock_decorator: second: self.lock is %s' % self._lock)

    class Bar:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def first(self):
            print('lock_decorator: first: self.loc is %s' % self._lock)


# Generated at 2022-06-23 14:23:59.387768
# Unit test for function lock_decorator
def test_lock_decorator():

    class TestSystem:

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method_a(self):
            print('method_a')
            # Will not print
            print('method_a.lock')

        @lock_decorator(lock=threading.Lock())
        def method_b(self):
            print('method_b')
            # Will not print
            print('method_b.lock')

    s = TestSystem()
    s.method_a()
    s.method_b()

# Generated at 2022-06-23 14:24:09.006777
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class TestLocks(object):
        def __init__(self):
            self._n = 10
            self.wlock = threading.Lock()
            self._lock = threading.Lock()

        @lock_decorator(attr='wlock')
        def wait_locked_method(self, wait_time=None, count=None):
            print('\tsome wait')
        #  time.sleep(random.randint(1, 5))
            print(self._n)
        #  self._n += 1
        #  print(self._n)

        @lock_decorator(lock=self._lock)
        def locked_method(self):
            print('\tsome work')
            time.sleep(random.randint(1, 5))


# Generated at 2022-06-23 14:24:16.179059
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
        import types
        import sys
    except ImportError:
        return True

    if sys.version_info < (3, 0):
        class MockLock(object):
            def __enter__(self):
                pass

            def __exit__(self, exc_type, exc_value, traceback):
                pass

        if sys.version_info < (2, 7):
            class mock_property(object):
                '''Copied from Ansible 2.9, to allow tests to pass on
                older Python versions.
                '''
                def __init__(self, fget, fset=None, fdel=None, doc=None):
                    self.fget = fget
                    self.fset = fset
                    self.fdel = fdel

# Generated at 2022-06-23 14:24:27.350365
# Unit test for function lock_decorator

# Generated at 2022-06-23 14:24:33.020678
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo(object):
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, callback, *args, **kwargs):
            callback(*args, **kwargs)

    foo = Foo()
    callbacks = []
    def callback(msg):
        callbacks.append(msg)

    foo.send_callback(callback, 'test')
    foo.send_callback(callback, 'test')

    assert len(callbacks) == 1, "Expected one callback, got %d" % (len(callbacks))
    assert callbacks == ['test'], "Expected [test], got %s" % (callbacks)

# Generated at 2022-06-23 14:24:36.732396
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # Make sure lock_decorator functionality works as expected
    class SomeClass(object):
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, value):
            return value

        @lock_decorator(lock=threading.Lock())
        def some_method(self, value):
            return value

    # Make sure it actually works.
    sc = SomeClass()
    assert sc.send_callback(10) == 10
    assert sc.some_method(10) == 10

# Generated at 2022-06-23 14:24:45.412718
# Unit test for function lock_decorator
def test_lock_decorator():
    """
    >>> class TestClass(object):
    ...     mutex = threading.Lock()
    ...
    ...     @lock_decorator(attr='mutex')
    ...     def test_method(self, value):
    ...         return value
    ...
    ...     @lock_decorator(lock=threading.Lock())
    ...     def test_method2(self, value):
    ...         return value
    ...
    >>> test = TestClass()
    >>> test.test_method(1)
    1
    >>> test.test_method2(2)
    2

    """

# Generated at 2022-06-23 14:24:53.741792
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self.attr = 'attr'

        @lock_decorator(attr='attr')
        def test_func(self):
            return self.attr
    tc = TestClass()
    assert tc.test_func() == 'attr'

    # We use a new class here because the decorator
    # implements the lock once and we want to reset
    class TestClass2(object):
        def __init__(self):
            self.attr = 'attr'

        @lock_decorator(lock=threading.Lock())
        def test_func2(self):
            return self.attr
    tc = TestClass2()
    assert tc.test_func2() == 'attr'

# Generated at 2022-06-23 14:25:02.131900
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = None
    attr = '_lock'

    def decorator_func(func):
        @wraps(func)
        def inner(*args, **kwargs):
            if lock is None:
                _lock = getattr(args[0], attr)
            else:
                _lock = lock
            with _lock:
                return func(*args, **kwargs)
        return inner

    class SomeClass:
        _lock = None
        @decorator_func
        def some_method(self):
            return 'some_method'

    obj = SomeClass()
    assert obj.some_method() == 'some_method'

# Generated at 2022-06-23 14:25:09.717203
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading, functools
    class ATestClass(object):
        @lock_decorator(attr='_lock')
        def a_method(self, foo, bar):
            assert False
            return (foo, bar)

    t = ATestClass()
    t._lock = threading.Lock()

    # ensure the lock actually works
    with t._lock:
        assert not t._lock.locked()
    assert t._lock.locked()

    # ensure we can pass a lock to ``__init__``
    t = ATestClass(t._lock)
    assert t._lock.locked()

    # set the lock to None
    t._lock = None

    # ensure it returns none if we pass an instance attribute
    # that does not exist
    assert t.a_method('foo', bar='bar') is None

   

# Generated at 2022-06-23 14:25:20.109491
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLock(object):
        def __init__(self):
            self.data = dict(value=0)
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.data['value'] += 1
            time.sleep(1)
            self.data['value'] += 1

        @lock_decorator(lock=threading.Lock())
        def decrement(self):
            self.data['value'] -= 1
            time.sleep(1)
            self.data['value'] -= 1

    test = TestLock()
    test.increment()
    assert test.data['value'] == 2

    test.decrement()
    assert test.data['value'] == 0

# Generated at 2022-06-23 14:25:27.915881
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):

        def __init__(self):
            self._lock = threading.Lock()
            self._attr = 0

        # This method will be decorated with ``attr='_lock'``
        @lock_decorator(attr='_lock')
        def do_something_with_attr(self, delay):
            self._attr += 1
            import time
            time.sleep(delay)
            return self._attr

        # This method will be decorated with ``lock=_lock``
        @lock_decorator(lock=self._lock)
        def do_something_with_lock(self, delay):
            self._attr += 1
            import time
            time.sleep(delay)
            return self._attr

    t = Test()

    # Test the attr lock

# Generated at 2022-06-23 14:25:39.060834
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestLock(object):
        def __init__(self):
            self._attr_lock = threading.Lock()
            self._lock = threading.Lock()
            self._test = []

        # Decorator with an instance attribute
        @lock_decorator(attr='_attr_lock')
        def attr_lock(self):
            assert not self._attr_lock._RLock__owner or self._attr_lock.locked()
            self._test.append(1)

        # Decorator with an object
        @lock_decorator(lock=self._lock)
        def other_lock(self):
            assert not self._lock._RLock__owner or self._lock.locked()
            self._test.append(1)

    testlock = TestLock()
    testlock.attr_lock

# Generated at 2022-06-23 14:25:47.028718
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator()
        def unprotected(self):
            print('unprotected')

        @lock_decorator(attr='_lock')
        def locked(self):
            print('locked')

        @lock_decorator(lock=threading.Lock())
        def explicit_lock(self):
            print('explicit')

    t = Test()
    t.unprotected()
    t.locked()
    t.explicit_lock()

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:25:53.282670
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    class MyClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.called = 0
            self.exc_info = None

        @lock_decorator()
        def callback(self, exc_info):
            # This function is thread safe
            self.called += 1
            self.exc_info = exc_info

    # Setup
    obj = MyClass()

    # This is what we are testing
    obj._callback_lock = threading.Lock()

    # FAIL
    assert obj.called == 0, 'Unit test failed: non-threaded callback not called'

    # Run in 2 threads
    def fn_callback():
        try:
            raise RuntimeError('Exception')
        except RuntimeError as exc:
            exc_info

# Generated at 2022-06-23 14:26:03.603984
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    # define our locking object
    thread_lock = threading.Lock()

    # setup a shared list to track execution order
    results = []

    class MyClass(object):
        def __init__(self):
            # create instance-based lock
            self._lock = threading.Lock()

        # By default, lock_decorator behavior is to look for
        # the named attribute ``_lock``
        def first_example(self):
            with self._lock:
                results.append('first')

        # This example explicitly sets the ``attr`` to
        # be some other attribute
        @lock_decorator(attr='_lock')
        def second_example(self):
            results.append('second')

        # This example explicitly sets a lock, rather
        # than using an instance attribute
       

# Generated at 2022-06-23 14:26:14.026961
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo:
        def __init__(self):
            self._my_lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_my_lock')
        def increment(self):
            self._counter += 1

    foo = Foo()
    threads = []
    for n in range(1000):
        threads.append(threading.Thread(target=foo.increment))

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    assert foo._counter == 1000

    foo = Foo()
    threads = []
    for n in range(1000):
        threads.append(threading.Thread(target=foo.increment))

    for t in threads:
        t.start()


# Generated at 2022-06-23 14:26:19.680860
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.value = None

        @lock_decorator(attr='lock')
        def set_value_by_attr(self, value):
            self.value = value

        @lock_decorator(lock=threading.Lock())
        def set_value_by_lock(self, value):
            self.value = value

    # Create a TestClass object
    obj = TestClass()

    # Create a list of test functions to call
    func = [
        obj.set_value_by_attr,
        obj.set_value_by_lock
    ]

    # Create a list of values to set each TestClass object attribute
    values = [1, 2]

   

# Generated at 2022-06-23 14:26:28.235517
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Test class
    class C(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test(self, name):
            print('hello %s' % name)

    c = C()
    t1 = threading.Thread(target=c.test, args=('world',))
    t2 = threading.Thread(target=c.test, args=('world',))

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    # Test function
    _lock = threading.Lock()
    @lock_decorator(lock=_lock)
    def f(name):
        print('hello %s' % name)


    t

# Generated at 2022-06-23 14:26:39.952182
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    from time import sleep

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six

    # wrap the method so we can reset the counter/lock
    def wrapped_decorator(func):
        lock = threading.Lock()

        @lock_decorator(lock=lock)
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return lock, wrapper

    # Ensure we can't call multiple times concurrently
    def test_concurrent_call():
        counter = 0

        lock, method = wrapped_decorator(lambda x: x + 1)

        def count():
            nonlocal counter
            counter += 1

        method(count)
        assert counter == 1


# Generated at 2022-06-23 14:26:51.744051
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Event
    from time import sleep

    class TestCase(object):
        '''This is a basic test case for lock_decorator'''

        def __init__(self):
            self._callback_lock = Thread()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            '''This method does something'''
            return

    class Worker(Thread):
        def __init__(self, test_case, flag):
            super(Worker, self).__init__()
            self.done = Event()
            self.test_case = test_case
            self.flag = flag

        def run(self):
            '''This is the callback that the thread runs'''

# Generated at 2022-06-23 14:26:59.097994
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test_attr(self):
            return True

        @lock_decorator(lock=threading.Lock())
        def test_lock(self):
            return True

    obj = TestClass()

    assert obj.test_attr()
    assert obj.test_lock()

# Generated at 2022-06-23 14:27:09.283427
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Test the ``lock_decorator`` function
    '''
    import threading
    # We will use a simple integer for this test
    data = {'counter': 0}
    lock = threading.Lock()
    data_attr = 'data'
    # Create a class to use
    class TestClass: # pylint: disable=too-few-public-methods
        '''
        A test class for the ``lock_decorator`` function
        '''
        def __init__(self):
            setattr(self, data_attr, data)
            # We also need a lock attribute
            self._lock = lock

        @lock_decorator(attr='_lock')
        def count(self):
            '''
            Increment the counter in the dict ``data``
            '''
            getattr

# Generated at 2022-06-23 14:27:16.998014
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    from time import sleep
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.a = 0

        @lock_decorator(attr='_lock')
        def test_attr(self):
            '''This test method uses `attr`'''
            self.a += 1
            sleep(0.5)
            self.a -= 1

        @lock_decorator(lock=Lock())
        def test_lock(self):
            '''This test method uses `lock`'''
            self.a += 1
            sleep(0.5)
            self.a -= 1

    t = Test()
    t._lock = Lock()
    t.assertEqual(t.a, 0)
    t.test_attr()
   

# Generated at 2022-06-23 14:27:25.747575
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    _lock = threading.Lock()

    class TestLock(object):
        def __init__(self):
            self.value = 0

        @lock_decorator(attr='_lock')
        def lock_by_attr(self):
            self.value += 1

        @property
        def _lock(self):
            return _lock

        @lock_decorator(lock=_lock)
        def lock_by_var(self):
            self.value += 1

    test_values = [('lock_by_attr', 0), ('lock_by_var', 0)]

    def locker(f, v):
        for i in range(7):
            f()
        v[1] = test.value

    test = TestLock()