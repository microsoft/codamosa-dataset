

# Generated at 2022-06-23 14:17:35.196616
# Unit test for function lock_decorator
def test_lock_decorator():
    class LockTest(object):
        def __init__(self):
            self._lock = None
            self.lock_attr = None
            self.lockout = False

        def random_number(self, min=0, max=10):
            return random.randint(min, max)

        def set_lock(self, lock):
            self._lock = lock

        @lock_decorator(attr='lock_attr', lock=None)
        def use_attr(self):
            '''Use this method to test the use of an object attribute
            as the _lock
            '''
            # Check if the object is locked
            test_lock = getattr(self, 'lock_attr')
            if test_lock:
                self.lock_attr = True
                return True
            else:
                self.lock_attr = False


# Generated at 2022-06-23 14:17:45.488139
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    import time

    class TestObject(object):
        def __init__(self, attr='_lock'):
            self.attr = attr
            self._callback_lock = threading.Lock()
            self.callbacks = []

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, callback):
            self.callbacks.append(callback)

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            pass

    test = TestObject()
    other_lock = threading.Lock()

    @lock_decorator(attr='attr')
    def some_other_method(self, value):
        return value


# Generated at 2022-06-23 14:17:55.471772
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class Foo(object):
        def __init__(self):
            self._my_lock = threading.Lock()
            self._my_val = 0

        @lock_decorator(attr='_my_lock')
        def my_method(self):
            self._my_val += 1
            return self._my_val

    class Bar(object):
        def __init__(self):
            self._my_lock = threading.Lock()
            self._my_val = 0

        @lock_decorator(lock=self._my_lock)
        def my_method(self):
            self._my_val += 1
            return self._my_val

    class Test(unittest.TestCase):
        def test_foo(self):
            foo = Foo()


# Generated at 2022-06-23 14:18:06.974312
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Lock

    class FakeModule:
        def __init__(self, *args, **kwargs):
            self._lock = Lock()
            self._lock_custom = Lock()
            self._lock_decorated = None

        @lock_decorator(attr='_lock')
        def _my_method(self):
            self._lock_decorated = True

        @lock_decorator(lock=self._lock_custom)
        def _my_method_custom(self):
            self._lock_decorated = True

    test_module = FakeModule()
    new_thread = threading.Thread(target=test_module._my_method)
    new_thread.start()
    new_thread.join()

    assert test_module._lock_decorated is True

   

# Generated at 2022-06-23 14:18:18.403809
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.foo_lock = threading.Lock()
            self.bar_lock = threading.Lock()

        def tearDown(self):
            pass

        # Attribute Lock
        @lock_decorator(attr='foo_lock')
        def test_foo(self):
            pass

        @lock_decorator(attr='bar_lock')
        def test_bar(self):
            pass

        # Argument Lock
        @lock_decorator(lock=threading.Lock())
        def test_baz(self):
            pass

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 14:18:28.766267
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        import unittest
        import sys
        sys.stderr.write('Skipping unit tests.  The Python "threading" module is not installed.\n')
        return

    class TestLock(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method1(self, sleep_time=0.1):
            import time
            time.sleep(sleep_time)
            return 1

        @lock_decorator()
        def method2(self, sleep_time=0.1):
            import time
            time.sleep(sleep_time)
            return 2


# Generated at 2022-06-23 14:18:34.723183
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def test(*args, **kwargs):
        return True
    assert test() is True
    @lock_decorator(attr='_lock')
    def test(*args, **kwargs):
        return True
    class Test:
        _lock = lock
    assert test(Test()) is True

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-23 14:18:44.905036
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class Test1(object):
        def __init__(self):
            self.a = {}

        @lock_decorator()
        def get(self, key):
            a = self.a
            if key in a:
                return a[key]
            return None

        @lock_decorator()
        def set(self, key, value):
            self.a[key] = value

    current_value = 100
    test1 = Test1()
    for count in range(1, 11):
        threading.Thread(target=test1.set, args=('key', current_value + count)).start()

    time.sleep(3)
    assert test1.get('key') == current_value + 10


# Generated at 2022-06-23 14:18:52.522838
# Unit test for function lock_decorator
def test_lock_decorator():
    import copy
    import sys
    import threading
    import time

    if sys.version_info > (3, 0):
        builtin_str = str
        # Define a unicode string for use in this test
        unicode = str
        def b(s):
            return s.encode('utf-8')
    else:
        # Define a unicode string for use in this test
        unicode = unicode
        builtin_str = str
        def b(s):
            return s
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    my_lock = lock_decorator()

    def my_func(self):
        self.result.append(self.value)
        self.value += 1
        time

# Generated at 2022-06-23 14:19:02.751817
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class C:
        def __init__(self):
            self._callback_lock = lock

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            return args, kwargs

    class D:
        @lock_decorator(lock=lock)
        def send_callback(self, *args, **kwargs):
            return args, kwargs

    c = C()
    d = D()

    args = (1, 2, 3)
    kwargs = dict(a=1, b=2, c=3)

    assert c.send_callback(*args, **kwargs) == (args, kwargs)
    assert d.send_callback(*args, **kwargs)

# Generated at 2022-06-23 14:19:11.661437
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self.value = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def incr(self):
            self.value += 1

    # Test that lock_decorator works as expected
    foo = Foo()
    assert foo.value == 0
    foo.incr()
    assert foo.value == 1

    # Test that lock_decorator does not allow concurrent access
    t1 = threading.Thread(target=foo.incr)
    t2 = threading.Thread(target=foo.incr)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    assert foo.value == 2

# Generated at 2022-06-23 14:19:22.512728
# Unit test for function lock_decorator
def test_lock_decorator():
    def test_func(self, foo, bar=None):
        try:
            self.foo = foo
            self.bar = bar or 42
            self.result = self.bar
            self.counter += 1

        except AttributeError:
            self.result = 42
            self.counter = 1

    import threading
    class test_class:
        pass

    t = test_class()

    # Test using lock object
    test_lock = threading.Lock()
    test_wrapper = lock_decorator(lock=test_lock)(test_func)
    test_wrapper(t, 42)
    assert t.result == 42
    assert t.counter == 1

    # Test using pre-existing lock object on first argument
    t2 = test_class()
    t2._callback_lock = threading.Lock()
    test

# Generated at 2022-06-23 14:19:30.287007
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class Foo(object):
        __shared = 0
        @lock_decorator(lock=lock)
        def shared_use(self):
            self.__shared += 1

        def shared(self):
            return self.__shared

        @lock_decorator(attr="lock")
        def shared_use_attr(self):
            self.__shared += 1

    lock = threading.Lock()
    foo = Foo()
    foo.lock = lock
    threads = []
    count = 1000
    def shared_use():
        for _ in range(count):
            foo.shared_use()

    def shared_use_attr():
        for _ in range(count):
            foo.shared_use_attr()


# Generated at 2022-06-23 14:19:37.193072
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import uuid
    class Test(object):
        _lock = threading.Lock()
        _data = {}
        @lock_decorator(attr='_lock')
        def add_data(self, key, value=None):
            if value is None:
                self._data[key] = ''
            else:
                self._data[key] = value
        @lock_decorator(attr='_lock')
        def clear_data(self):
            self._data = {}
    # Using attr='_lock' 
    t = Test()
    tc = Test()
    t.add_data('test')
    assert t._data['test'] == ''
    t.add_data('test2', 'value')
    assert t._data['test2'] == 'value'
    t.clear

# Generated at 2022-06-23 14:19:47.463315
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    class TestLock(unittest.TestCase):
        class Foo:
            def __init__(self):
                self.lock = threading.RLock()
            @lock_decorator(lock=None)
            def no_lock(self):
                return "no lock"
            @lock_decorator(attr="lock")
            def lock_attr(self):
                return "lock attr"
            @lock_decorator()
            def missing_lock_attr(self):
                return "missing_lock_attr"
        def test_no_lock(self):
            foo = self.Foo()
            self.assertEqual(foo.no_lock(), "no lock")
        def test_lock_attr(self):
            foo = self.Foo()
            self

# Generated at 2022-06-23 14:19:54.107681
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()

    value = 0

    def test1():
        global value
        value += 1
        value -= 1

    def test2():
        global value
        with lock:
            value += 1
            value -= 1

    def test3():
        global value
        @lock_decorator(lock=lock)
        def test():
            global value
            value += 1
            value -= 1
        test()

    @lock_decorator(attr='_lock')
    def test4(instance):
        global value
        value += 1
        value -= 1

    class LockDecoratorTestClass:
        def __init__(self):
            self._lock = lock

    instance = LockDecoratorTestClass()

    # If the lock isn't working, we should get more than 1


# Generated at 2022-06-23 14:20:04.679612
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class LockedThing:
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback_count = 0

        @lock_decorator(attr='_callback_lock')
        def _send_callback(self):
            # Simulate some long running task
            time.sleep(0.01)
            self._callback_count += 1

    class TestLockDecorator(threading.Thread):
        def __init__(self, thing):
            super(TestLockDecorator, self).__init__()
            self.thing = thing

        def run(self):
            self.thing._send_callback()

    thing1 = LockedThing()
    thing2 = LockedThing()

    threads = []

# Generated at 2022-06-23 14:20:14.159727
# Unit test for function lock_decorator
def test_lock_decorator():
    def assert_self_lock(self):
        self.lock.acquire()
        self.lock_acquired = True

    class Test(object):
        def __init__(self):
            self.lock = object()
            self.lock_acquired = False

    t = Test()
    t.f = lock_decorator(attr='lock')(assert_self_lock)
    t.f(t)
    assert t.lock_acquired

    test_lock = object()
    t.f = lock_decorator(lock=test_lock)(assert_self_lock)
    t.f(t)
    assert t.lock_acquired

# Generated at 2022-06-23 14:20:22.478682
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def func():
        return 'foo'

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def func(self):
            return 'cls'

    t = Test()

    assert func() == 'foo'
    assert t.func() == 'cls'

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', '-vv', __file__])

# Generated at 2022-06-23 14:20:34.193367
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for function lock_decorator'''

    import threading
    import time

    lock = threading.Lock()
    attr = 'mock_attr'
    var = 0

    @lock_decorator(lock=lock)
    def increment():
        nonlocal var
        var += 1
        if var < 100:
            time.sleep(0.01)
            increment()
        return var

    threads = [threading.Thread(target=increment) for _ in range(10)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    # Ensure that the lock was held throughout the recursive
    # call to increment
    assert var == 100

    @lock_decorator(attr=attr)
    def increment(self):
        nonlocal var
        var

# Generated at 2022-06-23 14:20:42.990684
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._lock2 = threading.Lock()
            self._lock3 = threading.Lock()

        @lock_decorator(attr='_lock')
        def method1(self, a):
            return a

        @lock_decorator(lock=self._lock2)
        def method2(self, a):
            return a

        @classmethod
        @lock_decorator(lock=self._lock3)
        def method3(cls, a):
            return a


    test = Test()

    assert test.method1(None) is None
    assert test.method2(None) is None
    assert test.method3(None) is None



# Generated at 2022-06-23 14:20:49.109553
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class LockDecoratorTest(object):
        def __init__(self):
            self._private_lock = threading.Lock()

        @lock_decorator(attr='_private_lock')
        def method_1(self, *args):
            return args

        @lock_decorator(lock=threading.Lock())
        def method_2(self, *args):
            return args

    ldt = LockDecoratorTest()
    assert ldt.method_1(1, 2, 3) == (1, 2, 3)
    assert ldt.method_2(1, 2, 3) == (1, 2, 3)

# Generated at 2022-06-23 14:20:58.731352
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class A(object):
        def __init__(self, lock=None):
            if lock is None:
                self._lock = threading.Lock()
            else:
                self._lock = lock

        @lock_decorator(attr='_lock')
        def function1(self, a):
            return a

        @lock_decorator(lock=threading.Lock())
        def function2(self, a):
            return a

    a = A()
    assert a.function1(1) == 1
    assert a.function2(1) == 1
    a = A(lock=threading.Lock())
    lock = a._lock
    assert a.function1(1) == 1
    assert a.function2(1) == 1

# Generated at 2022-06-23 14:21:08.973665
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    # Define a simple threading.Lock for the unit test
    class SimpleLock:

        def __init__(self):
            self.lock_owner = None

        def __enter__(self):
            assert self.lock_owner is None
            self.lock_owner = threading.current_thread().name

        def __exit__(self, type, value, traceback):
            assert self.lock_owner == threading.current_thread().name
            self.lock_owner = None

        # Python2 doesn't have ``__bool__``
        if not hasattr(__builtins__, '__bool__'):
            __nonzero__ = __bool__ = lambda self: self.lock_owner is None

    # Define a couple of dummy classes for the unit test

# Generated at 2022-06-23 14:21:19.728755
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.count = 0
            self.inc_count()

        @lock_decorator(attr='_lock')
        def inc_count(self):
            self.count += 1
            time.sleep(1)

    f = Foo()
    assert isinstance(f._lock, threading.Lock)
    assert f.count == 1

    f = Foo()
    assert isinstance(f._lock, threading.Lock)
    assert f.count == 1

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.count = 0
            self.inc_count()


# Generated at 2022-06-23 14:21:27.445332
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading
    import random

    def check_acquire():
        # check that _lock.acquire() is valid
        l.acquire()
        time.sleep(random.random())
        l.release()

    class C(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method1(self):
            return check_acquire()

        @lock_decorator(lock=threading.Lock())
        def method2(self):
            return check_acquire()

        @lock_decorator()
        def method3(self):
            return check_acquire()

        def __init__(self):
            # save the lock from method1
            self.l = self.method1._lock

    c = C()

    #

# Generated at 2022-06-23 14:21:37.806770
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for lock_decorator'''
    import sys
    import threading

    # Python2 doesn't have ``nonlocal``
    # assign the actual lock to ``_lock``
    _lock = threading.Lock()
    count = 0

    class MyClass:
        '''Class whose method will be locked with lock_decorator'''
        def my_method(self):
            '''Method whose access will be locked with lock_decorator'''
            global count
            count += 1

    my_obj = MyClass()

    # Verify the lock_decorator is working
    # as expected in an explicit lock method
    lock_method = lock_decorator(lock=_lock)(my_obj.my_method)
    lock_method()
    lock_method()
    if count > 1:
        print

# Generated at 2022-06-23 14:21:47.433063
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading

    def some_method(self):
        pass

    with mock.patch('ansible.utils.lock_decorator.wraps') as wraps_mock:
        returned_inner = lock_decorator()(some_method)

    assert wraps_mock.call_args[0][0] == some_method

    class Fake(object):
        pass

    fake = Fake()
    fake.some_method = returned_inner

    # Simulate a threading.Lock
    class FakeLock(object):
        def __enter__(self):
            pass
        def __exit__(self, exc_type, exc_val, exc_tb):
            pass


# Generated at 2022-06-23 14:21:58.277905
# Unit test for function lock_decorator
def test_lock_decorator():

    # Test using a class attribute
    class C:
        def __init__(self):
            from threading import Lock
            self._lock = Lock()

        @lock_decorator(attr='_lock')
        def test(self, x):
            return x

    # Test using a function argument
    from threading import Lock
    _lock = Lock()

    @lock_decorator(lock=_lock)
    def test_no_self(x):
        return x

    # Test a single value
    c = C()
    for _ in [c.test(1) for _ in range(100)]:
        assert _ == 1

    # Test two different values, without the lock this would fail.
    c = C()

# Generated at 2022-06-23 14:22:06.109156
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import sys

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._var = 0

        def __check_var(self):
            if self._var != 1:
                raise Exception('Test variable was not set to correct value')
            self._var = 0

        @lock_decorator(attr='_lock')
        def test_1(self):
            self._var = 1
            self.__check_var()

        @lock_decorator(lock=threading.Lock())
        def test_2(self):
            self._var = 1
            self.__check_var()

    if sys.version_info.major > 2:
        unittest.TestCase.assertCountEqual = unittest

# Generated at 2022-06-23 14:22:17.333599
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import logging
    import time
    import sys

    logger = logging.getLogger('test')
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    l = threading.Lock()

    class Thread1(threading.Thread):
        def __init__(self, lock):
            super(Thread1, self).__init__()
            self.lock = lock

        @lock_decorator(lock=l)
        def run(self):
            logger.info("Thread1 lock obtained")
            time.sleep(1)

    class Thread2(threading.Thread):
        def __init__(self, lock):
            super(Thread2, self).__init__()
            self.lock = lock


# Generated at 2022-06-23 14:22:28.332766
# Unit test for function lock_decorator
def test_lock_decorator():
    import logging
    import threading
    import time

    class Test(object):
        def __init__(self):
            self._logger = logging.getLogger(__name__)
            self._callback_lock = threading.Lock()

        @lock_decorator(attr="_callback_lock")
        def send_callback(self, callback, result):
            """Send a callback to the system."""
            self._logger.info("Sending callback '%s'", callback)

            self._logger.info("Result is '%s'", result)

            self._logger.info("Sleeping for 1 second")
            time.sleep(1)

            self._logger.info("Done sleeping")


# Generated at 2022-06-23 14:22:39.422280
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class DecoratorTest(object):
        def __init__(self):
            self.value = 0
            self.lock = threading.Lock()
            self.another_value = 0
            self.another_lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.value += 1

        @lock_decorator(lock=self.another_lock)
        def increment_another(self):
            self.another_value += 1

    x = DecoratorTest()
    assert x.value == 0
    x.increment()
    assert x.value == 1
    x.increment()
    assert x.value == 2
    x.increment_another()
    assert x.another_value == 1
    x.increment_another

# Generated at 2022-06-23 14:22:50.422983
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Mock(object):
        def __init__(self):
            self.some_lock = lock_decorator(attr='some_lock')
            self.some_call_count = 0
            self.some_list = []

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            self.some_call_count += 1
            self.some_list.append('some_method')

        def some_other_method(self):
            self.some_call_count += 1
            self.some_list.append('some_other_method')

        def some_method_second_call(self):
            self.some_call_count += 1
            self.some_list.append('some_method_second_call')


# Generated at 2022-06-23 14:23:02.303601
# Unit test for function lock_decorator

# Generated at 2022-06-23 14:23:12.627352
# Unit test for function lock_decorator
def test_lock_decorator():
    import time

    import threading
    import unittest

    class LockDecoratorTestCase(unittest.TestCase):
        _callback_lock = threading.Lock()

        def setUp(self):
            self.data = []

        def tearDown(self):
            self.data = []

        @lock_decorator()
        def fail(self):
            pass

        @lock_decorator(attr='')
        def fail(self):
            pass

        @lock_decorator(attr='_foo')
        def fail(self):
            pass

        @lock_decorator(lock=None)
        def fail(self):
            pass

        def test_fails(self):
            self.assertRaises(AttributeError, self.fail)


# Generated at 2022-06-23 14:23:22.979702
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import random
    import time

    def check_object_lock_decorator(instance, num, lock_name, lock_object=None):
        @lock_decorator(attr=lock_name, lock=lock_object)
        def myfunc(self, num):
            time.sleep(random.uniform(0.001, 0.002))
            return num
        return myfunc(instance, num)
    def check_static_lock_decorator(num, lock_name, lock_object=None):
        @lock_decorator(attr=lock_name, lock=lock_object)
        def myfunc(num):
            time.sleep(random.uniform(0.001, 0.002))
            return num
        return myfunc(num)


# Generated at 2022-06-23 14:23:34.693601
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestObject(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._a = 'initial'

        @lock_decorator(attr='_lock')
        def method_a(self, value):
            self._a = value

        def method_a_raw(self, value):
            self._a = value

        @lock_decorator(lock=threading.Lock())
        def method_b(self, value):
            self._a = value

        def method_b_raw(self, value):
            self._a = value

    test = TestObject()
    assert test._a == 'initial'

    test.method_a('change')
    assert test._a == 'change'

    test.method_a_raw('change2')
   

# Generated at 2022-06-23 14:23:42.299301
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    def test_decorator():
        my_lock = threading.Lock()
        results_mock = []
        results_lock = []
        class LockA(object):
            def __init__(self):
                self.my_lock = my_lock

            @lock_decorator(attr='my_lock')
            def lock_method_mock(self):
                results_mock.append(1)


# Generated at 2022-06-23 14:23:50.016097
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    class Thing(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='_lock')
        def this_is_locked(self):
            assert self._lock.locked()
            self.value += 1

        @lock_decorator(lock=threading.Lock())
        def this_is_locked_too(self):
            self.value += 2

        def this_is_unlocked(self):
            assert not self._lock.locked()
            self.value += 4

    thing = Thing()
    assert thing.value == 0

    with pytest.raises(AttributeError):
        @lock_decorator()
        def function():
            pass


# Generated at 2022-06-23 14:23:58.404272
# Unit test for function lock_decorator
def test_lock_decorator():
    '''This unit test is for the lock_decorator function.  It
    tests the ``attr`` and ``lock`` options.
    '''
    import threading

    class LockDecoratorTest(object):
        def __init__(self, lock):
            self._mylock = lock
            self.lock_count = 0

        @lock_decorator(attr='_mylock')
        def mymethod(self):
            self.lock_count += 1

        @lock_decorator(lock=threading.Lock())
        def myothermethod(self):
            self.lock_count += 1

    def run_lock_decorator_test(lock):
        test = LockDecoratorTest(lock)
        assert test.lock_count == 0
        test.mymethod()
        assert test.lock_count == 1

# Generated at 2022-06-23 14:24:06.628719
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback_value = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, value):
            time.sleep(.25)
            setattr(self, '_callback_value', value)

    test = TestClass()
    test.send_callback(1)
    assert test._callback_value == 1

    test.send_callback(2)
    assert test._callback_value == 2

# Generated at 2022-06-23 14:24:13.726042
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    >>> import threading
    >>> class Simple:
    ...     _lock = threading.Lock()
    ...     def __init__(self):
    ...         self.value = 0
    ...     @lock_decorator(attr='_lock')
    ...     def increment(self):
    ...         self.value += 1
    ...         return self.value
    >>> s = Simple()
    >>> s.increment()
    1
    '''
    pass

# Generated at 2022-06-23 14:24:19.023074
# Unit test for function lock_decorator
def test_lock_decorator():
    class LockDecoratorTest(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator()
        def missing_lock_attr(self):
            assert False, 'This should never be called'

        @lock_decorator(attr='_lock')
        def call_lock(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def call_threading_lock(self):
            pass

    test = LockDecoratorTest()
    try:
        test.missing_lock_attr()
    except AttributeError:
        pass
    else:
        assert False, 'missing_lock_attr should have raised AttributeError'

    test.call_lock()
    test.call_threading_lock()

# Generated at 2022-06-23 14:24:30.255862
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class A(object):
        def __init__(self):
            self.foo = 0
            self.bar = 0
            self.baz = 0
            self.lock = threading.Lock()

        @lock_decorator(lock=None)
        def test(self):
            self.foo = 1

        @lock_decorator(attr='lock')
        def test2(self):
            self.bar = 1

        @lock_decorator(lock=threading.Lock())
        def test3(self):
            self.baz = 1

    for i in range(4):
        t = threading.Thread(target=A().test)
        t.start()
        t.join()
        assert A().foo == 1

    for i in range(4):
        t = threading

# Generated at 2022-06-23 14:24:36.387666
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass(object):
        def foo(self):
            return True

    expected_lock = threading.Lock()
    assert TestClass().foo()

    TestClass.foo = lock_decorator(attr='_missing_lock_attr')(TestClass.foo)
    try:
        TestClass().foo()
        assert False
    except AttributeError as e:
        assert str(e) == "'TestClass' object has no attribute '_missing_lock_attr'"

    TestClass.foo = lock_decorator(lock=expected_lock)(TestClass.foo)
    assert TestClass().foo()

    TestClass._my_lock = expected_lock
    TestClass.foo = lock_decorator(attr='_my_lock')(TestClass.foo)
    assert TestClass().foo()

# Generated at 2022-06-23 14:24:46.875850
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestLockDecorator(unittest.TestCase):

        def test_lock_decorator(self):
            # This tests both attr and lock scenarios
            class Foo:
                def __init__(self):
                    self._callback_lock = threading.Lock()

                @lock_decorator(attr='_callback_lock')
                def bar(self, value):
                    return value * value

                @lock_decorator(lock=threading.Lock())
                def baz(self, value):
                    return value * value

            c = Foo()

            # Only one thread at a time
            assert c.bar(2) == 4
            assert c.baz(3) == 9

# Generated at 2022-06-23 14:24:55.230476
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import unittest
    import time

    class Test(object):

        # Test has the lock on an instance attribute
        _lock = threading.Lock()

        # Test has a shared counter
        counter = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            Test.counter += 1
            time.sleep(0.1)

    @lock_decorator(lock=threading.Lock())
    def increment():
        Test.counter += 1
        time.sleep(0.1)

    class TestLockDecorator(unittest.TestCase):

        def test_attr_case(self):
            threads = []
            for _ in range(10):
                t = threading.Thread(target=Test().increment)
                t.start()
                threads.append

# Generated at 2022-06-23 14:25:02.816874
# Unit test for function lock_decorator
def test_lock_decorator():

    class Test:
        def __init__(self):
            self._lock = threading.Lock()

        def __call__(self):
            self._locked = False
            for i in range(10):
                self.lock_decorator_test()
            assert self._locked

        @lock_decorator(attr='_lock')
        def lock_decorator_test(self):
            assert self._locked is False
            self._locked = True
            time.sleep(0.1)
            assert self._locked is True
            self._locked = False

    t = Test()
    t()

# Generated at 2022-06-23 14:25:13.454534
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class TestLockDecorator(object):
        def __init__(self):
            self._lock = None
            self._value = 0

        @lock_decorator(attr='_lock')
        def set_lock(self, lock):
            self._lock = lock

        @lock_decorator(attr='_lock')
        def get_value(self):
            return self._value

        @lock_decorator(attr='_lock')
        def set_value(self, value):
            self._value = value

    tld = TestLockDecorator()
    tld.set_lock(threading.Lock())
    tld.set_value(42)

    assert tld.get_value() == 42

# Generated at 2022-06-23 14:25:24.136695
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self.lock1 = threading.Lock()
            self.lock2 = threading.Lock()
            self.data = 0

        @lock_decorator(lock=self.lock1)
        def some_instance_method(self):
            pass

        @classmethod
        @lock_decorator(lock=self.lock2)
        def some_class_method(cls):
            pass

        @property
        @lock_decorator(attr='lock1')
        def some_property(self):
            return self.data

        @some_property.setter
        @lock_decorator(attr='lock1')
        def some_property(self, value):
            self.data = value

# Generated at 2022-06-23 14:25:35.965193
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    if sys.version_info[0] < 3:
        from mock import Mock, patch
    else:
        from unittest.mock import Mock, patch

    import pytest

    @pytest.fixture
    def mock_lock():
        return Mock()

    @pytest.fixture
    def dummy_class(mock_lock):
        # Use ``__dict__`` to be able to test private attributes
        dummy = type('Dummy', (object,), {'_dummy_lock': mock_lock})
        # This is two "methods" in one, since Python2 can't
        # mark a method as ``staticmethod`` and ``classmethod``
        # at the same time (it's an ``@wraps`` issue)

# Generated at 2022-06-23 14:25:45.833703
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo(object):
        @lock_decorator(attr='_lock')
        def some_func(self):
            time.sleep(2)

    _foo = Foo()
    _foo._lock = threading.Lock()

    threading.Thread(target=lambda: _foo.some_func()).start()
    threading.Thread(target=lambda: _foo.some_func()).start()
    threading.Thread(target=lambda: _foo.some_func()).start()

    # If the lock works, you'll be waiting for ~2 seconds
    # and only the first thread will sleep for 2 seconds
    _foo.some_func()

try:
    unicode
    _unicode_class = unicode
except NameError:
    _unicode_class = str



# Generated at 2022-06-23 14:25:56.260104
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self.counter = 0
            self.lock = threading.Lock()

        @lock_decorator()
        def increment(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def increment2(self):
            self.counter += 1


    def run_threads(cls):
        threads = [threading.Thread(target=cls.increment) for i in range(10)]
        for t in threads:
            t.start()
            time.sleep(0.1)
        for t in threads:
            t.join()

    tc = TestClass()
    assert tc.counter == 0
    # The first run should not be locked, since lock is

# Generated at 2022-06-23 14:26:02.477147
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo:
        _lock = threading.Lock()
        def __init__(self):
            self.attr = 123

        @lock_decorator(attr='_lock')
        def do_something(self):
            self.attr += 1

        @lock_decorator(lock=threading.Lock())
        def do_something_else(self, *args, **kwargs):
            return (args, kwargs)

    foo = Foo()
    assert foo.attr == 123
    foo.do_something()
    assert foo.attr == 124

    assert foo.do_something_else(1, 2, three='four') == ((1, 2), {'three': 'four'})

# Generated at 2022-06-23 14:26:12.658392
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from copy import copy

    from ansible.module_utils.stratospheric import lock_decorator

    class TestLock(object):
        def __init__(self):
            self.test = []

        @lock_decorator(attr='test_lock')
        def append(self, value):
            self.test.append(value)

    original_value = []
    test = TestLock()
    test_lock = threading.Lock()
    test.test_lock = copy(test_lock)

    th1 = threading.Thread(target=test.append, args=('thread 1',))
    th2 = threading.Thread(target=test.append, args=('thread 2',))

    th1.start()
    th2.start()
    th1.join()

# Generated at 2022-06-23 14:26:21.073223
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    # For testing ``lock_decorator`` requires a class with a @lock_decorator
    # assigned to a method
    class myTestClass(object):
        @classmethod
        @lock_decorator(lock=mock.MagicMock())
        def some_method(cls, *args, **kwargs):
            return args, kwargs

    args = ('a',)
    kwargs = {
        'b': 'c'
    }

    _args, _kwargs = myTestClass.some_method(*args, **kwargs)
    assert _args == args
    assert _kwargs == kwargs



# Generated at 2022-06-23 14:26:28.774341
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()

    class LockDecoratorTest(object):
        # Usable version of the lock decorator
        @lock_decorator()
        def _activate(self):
            raise Exception('Should never be reached')

        # Generic lock decorator
        @lock_decorator(attr='_lock')
        def _locked_activate(self):
            raise Exception('Should never be reached')

        # Another generic lock decorator
        @lock_decorator(lock=_lock)
        def _other_locked_activate(self):
            raise Exception('Should never be reached')

    # Now test
    test = LockDecoratorTest()
    test._activate()
    test._locked_activate()
    test._other_locked_activate()

# Generated at 2022-06-23 14:26:40.268155
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        '''Test class for lock_decorator unit tests'''

        @lock_decorator(attr='lock_1')
        def do_something(self):
            '''Test method using instance attribute locker'''
            self.value += 1

        @lock_decorator(lock=threading.Lock())
        def do_something_else(self):
            '''Test method using explicit locker'''
            self.value += 1

    some_lock = threading.Lock()
    tc = TestClass()
    tc.lock_1 = some_lock
    tc.value = 0

    # test explicit locking
    tc.do_something_else()
    assert tc.value == 1

    # test instance attribute locking
    tc.do_something()
    assert tc.value == 2

# Generated at 2022-06-23 14:26:51.306127
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class SomeClass:

        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def some_method(self):
            print("some_method")

        @lock_decorator(lock=threading.Lock())
        def some_other_method(self):
            print("some_other_method")

    class SomeOtherClass:

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            print("some_method")

    some = SomeClass()
    some.some_method()
    some.some_other_method()

    some_other = SomeOtherClass()
    some_other.some_method()

# Generated at 2022-06-23 14:27:02.269605
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class SomeClass(object):

        def __init__(self):
            self._lock = threading.Lock()
            self.lock_counter = 0
            self.method_counter = 0
            self.method_and_lock_counter = 0

        @lock_decorator(attr='_lock')
        def do_method_with_lock(self):
            self.method_and_lock_counter += 1
            self.do_method()

        def do_method(self):
            self.method_counter += 1
            with self._lock:
                self.lock_counter += 1

    class SomeClassWithoutLock(object):

        def __init__(self):
            self.method_counter = 0

        def do_method_without_lock(self):
            self.method_counter += 1

# Generated at 2022-06-23 14:27:09.764860
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class DummyClass(object):
        def __init__(self):
            self._lock = lock
            self._val = 0

        @lock_decorator(attr='_lock')
        def meth1(self):
            self._val += 1

        @lock_decorator(lock=lock)
        def meth2(self):
            self._val += 1

    dummy = DummyClass()

    dummy.meth1()
    assert dummy._val == 1

    dummy.meth2()
    assert dummy._val == 2

# Generated at 2022-06-23 14:27:17.317916
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self, lock=None):
            if lock is None:
                self._lock = threading.Lock()
            else:
                self._lock = lock
            self.invoked = False

        @lock_decorator(attr='_lock')
        def do_something(self):
            self.invoked = True

    # Test using a lock defined in the class
    foo = Foo()
    assert foo.invoked is False
    foo.do_something()
    assert foo.invoked is True

    # Test using an overriding lock defined in the instance
    lock = threading.Lock()
    foo = Foo(lock=lock)
    assert foo.invoked is False
    foo.do_something()
    assert foo.invoked is True

# Generated at 2022-06-23 14:27:25.976463
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    # Wrapper function that simply returns the value
    # passed to it, to test that things are actually
    # called
    def wrapper(arg):
        return arg

    # Create the lock decorator
    lock_wrapper = lock_decorator(attr='lock_attr')

    # Get the lock object
    lock = threading.Lock()

    # Create the instance object to be decorated
    class O:
        lock_attr = lock
        @lock_wrapper
        def f(self):
            return wrapper('f')
    o = O()

    # Call the decorated function
    assert o.f() == 'f'

    # Call the decorated function, but with the lock held
    with lock:
        lock.acquire()
        assert o.f() == 'f'


# vim: set expandtab shiftwidth=4