

# Generated at 2022-06-21 08:45:43.361611
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random
    import itertools
    import Queue
    import unittest

    class MyClass(object):
        def __init__(self):
            self.value = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def increment(self):
            self.value += 1
            time.sleep(random.random() / 1000)

        @lock_decorator(attr='_lock')
        def increment_by(self, value):
            self.value += value
            time.sleep(random.random() / 1000)

        @lock_decorator(attr='_lock')
        def get_value(self):
            time.sleep(random.random() / 1000)
            return self.value


# Generated at 2022-06-21 08:45:53.053187
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import unittest

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.counter = 0
            self.call_count = 5

        @lock_decorator(attr='lock')
        def test_attr_lock(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def test_lock(self):
            self.counter += 1

        def test_func_lock_decorator_lock(self):
            def dothread(count):
                for num in range(count):
                    self.test_lock()

            threads = []
            for num in range(self.call_count):
                threads.append(threading.Thread(target=dothread, args=(10,)))


# Generated at 2022-06-21 08:46:03.018198
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    def sleeping_sum(a, b, sleep_time=0.01):
        time.sleep(sleep_time)
        return a + b

    lock = threading.Lock()
    locker = lock_decorator(lock=lock)
    locked_sleeping_sum = locker(sleeping_sum)

    # Fake threading
    def fake_threading(function):
        def wrapper(*args, **kwargs):
            return function(*args, **kwargs)
        return wrapper

    @fake_threading
    def fake_thread(*args, **kwargs):
        return locked_sleeping_sum(*args, **kwargs)

    assert sum([fake_thread(1, i) for i in range(10)]) == 45

# Generated at 2022-06-21 08:46:14.249701
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self, attr=None, lock=None):
            # If testing with ``attr``
            if attr is not None:
                self.test_lock = threading.Lock()
                setattr(self, attr, self.test_lock)

            # If testing with ``lock``
            if lock is not None:
                self.test_lock = lock

        @lock_decorator(attr='test_lock')
        def attr_method(self):
            return 1


        @lock_decorator(lock=threading.Lock())
        def lock_method(self):
            return 2


    foo = Foo()
    assert foo.attr_method() == 1
    assert foo.lock_method() == 2

# Generated at 2022-06-21 08:46:23.684293
# Unit test for function lock_decorator
def test_lock_decorator():
    import types
    import threading

    class Test(object):

        UNLOCKED = object()
        LOCKED = object()
        PROMISED = object()

        @lock_decorator(attr='lock')
        def locked(self, key=UNLOCKED):
            assert key is Test.LOCKED

        @lock_decorator(attr='promise')
        def promised(self, key=UNLOCKED):
            assert key is Test.PROMISED

        def __init__(self):
            self.lock = threading.Lock()
            self.promise = threading.Lock()

    p = Test()
    p.lock.acquire()
    p.promise.acquire()

    def thread_func(call):
        try:
            call()
        except AssertionError:
            pass


# Generated at 2022-06-21 08:46:33.184147
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    # The lock_decorator depends on this class
    class A(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method1(self):
            time.sleep(random.randint(0, 2))
            print("method1 finished")

    # The class A is the test of the lock_decorator
    a1 = A()
    a2 = A()

    # Let's create the threads that will work with the class A
    threads = []
    for _ in range(10):
        t = threading.Thread(target=a1.method1)
        threads.append(t)
        t.start()

    # Let's create the threads that will work with

# Generated at 2022-06-21 08:46:45.558533
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    global i

    lock = threading.Lock()

    class TestLockDecorator(object):
        # Create an instance of a threading lock
        _lock = threading.Lock()

        @lock_decorator()
        def missing_attr(self):
            global i
            i = 10

        @lock_decorator(attr='_lock')
        def ok(self):
            global i
            i = 20

        @lock_decorator(lock=lock)
        def ok2(self):
            global i
            i = 30
    # missing_attr should throw RuntimeError
    try:
        i = 0
        t = TestLockDecorator()
        t.missing_attr()
    except RuntimeError:
        assert i == 0
    # ok() should set i to 20

# Generated at 2022-06-21 08:46:55.258982
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a lock to use with this UNIT test
    _test_lock = threading.Lock()

    class Example(object):
        # Attribute we are going to use as the instance lock
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def foo(self):
            # The lock should now be set
            assert self._lock.acquire(False) is False
            self._lock.release()

        # The lock passed directly to the decorator is not touched
        @lock_decorator(lock=_test_lock)
        def bar(self):
            # The lock should now be set, but not the one that the decorator
            # was given
            assert self._lock.acquire(False) is False

            # The lock should now be set, but not the one that the decorator

# Generated at 2022-06-21 08:47:06.722647
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, RLock, Condition

    # Test class
    class Test:
        # Test initializer
        def __init__(self):
            self._my_lock = Lock()
            self._my_rlck = RLock()
            self._my_cond = Condition()
            pass

        # Test basic lock
        @lock_decorator(attr='_my_lock')
        def my_method(self):
            return self._my_lock is lock_decorator.__wrapped__.__globals__['_lock']

        # Test RLock
        @lock_decorator(lock=RLock())
        def my_method2(self):
            return lock_decorator.__wrapped__.__globals__['_lock']

        # Test Condition

# Generated at 2022-06-21 08:47:17.194641
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    from time import sleep

    class MyClass(object):
        awaiting_lock = False

        @lock_decorator(attr='lock')
        def method_1(self):
            self.awaiting_lock = True
            sleep(1)
            self.awaiting_lock = False

        @lock_decorator(attr='lock')
        def method_2(self):
            self.awaiting_lock = True
            sleep(1)
            self.awaiting_lock = False

        @lock_decorator(attr='lock')
        def method_3(self):
            self.awaiting_lock = True
            sleep(1)
            self.awaiting_lock = False

        def __init__(self):
            self.lock = Lock()

    my_obj = MyClass()

# Generated at 2022-06-21 08:47:30.211988
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestLock(threading.Lock):
        def __init__(self):
            self.acquired = False
            super(TestLock, self).__init__()

        def __enter__(self):
            self.acquire()

        def __exit__(self, exc_type, exc_value, traceback):
            self.release()

    def get_lock():
        # A function that returns the lock object
        return TestLock()

    class Test(object):
        def __init__(self):
            self.call_count = 0
            self.test_lock = TestLock()

        @lock_decorator(lock=get_lock())
        def lock_func(self):
            self.call_count += 1


# Generated at 2022-06-21 08:47:42.345397
# Unit test for function lock_decorator
def test_lock_decorator():
    from collections import deque
    from threading import Lock, Thread
    from time import sleep

    # Create a fake class to use as a testing ground
    class TestObject:

        def __init__(self, name):
            self.name = name
            self._callback_lock = Lock()
            self.callback_queue = deque()
            self.listener(1)
            self.listener(2)
        # Unit test for thread safety
        @lock_decorator(attr='_callback_lock')
        def callback(self, data):
            self.callback_queue.append(data)

        # Unit test for thread safety
        @lock_decorator(lock=Lock())
        def listener(self, data):
            out = "Listener {0} received {1}"
            print(out.format(self.name, data))

# Generated at 2022-06-21 08:47:52.111245
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    _lock = threading.Lock()
    _data = []

    @lock_decorator(lock=_lock)
    def _fn_to_test():
        _data.append(1)

    _fn_to_test()

    assert len(_data) == 1

    @lock_decorator(attr='_lock')
    def _fn_to_test(self):
        _data.append(1)

    class TestClass:
        def __init__(self):
            self._lock = _lock

    inst = TestClass()
    inst._fn_to_test()

    assert len(_data) == 2

# Generated at 2022-06-21 08:47:57.678898
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass:
        _callback_lock = threading.Lock()
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            return True
    class TestClass2:
        @lock_decorator(lock=threading.Lock())
        def some_method(self, *args, **kwargs):
            return True

    assert TestClass().send_callback('foo', 'bar')
    assert TestClass2().some_method()

# Generated at 2022-06-21 08:48:08.325978
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Example():
        def __init__(self):
            # Python2 doesn't have ``nonlocal``
            # assign the actual lock to ``lock``
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def _increment_counter(self):
            self._counter += 1

        def _increment_counter_directly(self):
            self._lock.acquire()
            self._counter += 1
            self._lock.release()

        def get_result(self, threads=1):
            for thread in range(threads):
                t = threading.Thread(target=self._increment_counter)
                t.daemon = True
                t.start()


# Generated at 2022-06-21 08:48:19.655990
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Foo(object):
        _x = 0
        _callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def update_x(self, x):
            Foo._x = x

    foo = Foo()

    def thread_update_x(x, foo_object):
        import time
        time.sleep(0.3)
        foo_object.update_x(x)

    threads = [
        threading.Thread(target=thread_update_x, args=(i, foo))
        for i in range(5)
    ]

    import pickle

    def thread_pickle_x(x):
        import time
        time.sleep(0.3)
        d = pickle.dumps(Foo._x)
        Foo._x

# Generated at 2022-06-21 08:48:29.890378
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread
    from time import sleep

    # The following test is a bit silly, as it uses threads to test
    # concurrent access to a lock, while running within a single
    # process. The goal here is to show that the lock prevents access
    # to a variable when locked, but in a simple way.
    test_data = {'value': None}

    class Test(object):
        @lock_decorator(attr='_lock')
        def add_value(self, value):
            test_data['value'] += value

        def run(self):
            Thread(target=self.add_value, args=(30,)).start()
            Thread(target=self.add_value, args=(70,)).start()

    test_data['value'] = 0
    Test().run()
    sleep(1)
    # if

# Generated at 2022-06-21 08:48:40.804383
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Foo(object):
        def __init__(self):
            self.lock = lock_decorator(attr='_foo_lock')
            self._foo_lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='_foo_lock')
        def increment(self):
            self.value += 1

        @lock_decorator(lock=threading.Lock())
        def synchronous(self):
            self.value += 1

    foo = Foo()

    foo.increment()
    assert foo.value == 1

    foo.synchronous()
    assert foo.value == 2

    foo.value = 0

    foo.lock(foo.increment)()
    assert foo.value == 1

    foo.lock(foo.synchronous)()
   

# Generated at 2022-06-21 08:48:46.823227
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        @lock_decorator(attr='_lock')
        def default(self):
            self.count += 1
        @lock_decorator(lock=threading.Lock())
        def explicit(self):
            self.count += 1

        def __init__(self):
            self._lock = threading.Lock()
            self.count = 0

    def run(test, func):
        threads = []
        for x in range(10):
            t = threading.Thread(target=func)
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        # 10 threads, each increments count by one.
        assert test.count == 10

    t = Test()
    run(t, t.default)

# Generated at 2022-06-21 08:48:56.598976
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    import time

    class Test(object):
        def __init__(self):
            self._lock = Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def doit(self):
            self.counter += 1
            time.sleep(1)

    test = Test()
    t = Thread(target=test.doit)
    t.start()
    t2 = Thread(target=test.doit)
    t2.start()
    t.join()
    t2.join()
    assert test.counter == 1

# Generated at 2022-06-21 08:49:12.702283
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._attr_lock = threading.Lock()
            self.sentinel = None

        @lock_decorator(attr='_attr_lock')
        def set_sentinel_with_attr(self, value):
            self.sentinel = value

        @lock_decorator(lock=threading.Lock())
        def set_sentinel_with_lock(self, value):
            self.sentinel = value

    t = Test()

    t.set_sentinel_with_attr('attr_lock')
    assert t.sentinel == 'attr_lock'

    t.set_sentinel_with_lock('explicit_lock')
    assert t.sentinel == 'explicit_lock'


# Generated at 2022-06-21 08:49:23.013811
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class MyTest(object):
        def __init__(self):
            self.attr = 0
            self.attr_lock = threading.Lock()

        @lock_decorator(attr='attr_lock')
        def lock_decorated(self):
            self.attr += 1
            time.sleep(1)
            self.attr += 1

    # Test using a class instance attribute as a lock
    inst = MyTest()
    thread = threading.Thread(target=inst.lock_decorated)
    thread.start()

    assert inst.attr == 0, 'Attribute should be 0'
    time.sleep(0.25)
    assert inst.attr == 0, 'Attribute should still be 0'
    time.sleep(1.0)

# Generated at 2022-06-21 08:49:33.270168
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    class Test_decorator(unittest.TestCase):
        def test_lock_decorator(self):

            lock = threading.Lock()

            lock.acquire()
            lock.release()

            class Test(object):
                def __init__(self):
                    self.foo = 0
                    self._lock = lock

                @lock_decorator(attr='_lock')
                def do_something(self):
                    self.foo = 10

                @staticmethod
                @lock_decorator(lock=lock)
                def do_static():
                    return 'I am static'

            t = Test()
            t.do_something()
            assert t.foo == 10
            assert Test.do_static() == 'I am static'

    unittest.main()

# Generated at 2022-06-21 08:49:43.802298
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._callback_lock = threading.Lock()

        @lock_decorator()
        def no_op_call(self):
            '''Foo.no_op_call'''
            pass

        @lock_decorator(attr='_lock')
        def another_no_op(self):
            '''Foo.another_no_op'''
            pass

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, arg):
            '''Foo.send_callback'''
            return arg

    f = Foo()
    f.no_op_call()

# Generated at 2022-06-21 08:49:55.101806
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    import time

    class foo(object):
        def __init__(self):
            self._lock = Lock()
            self.count = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self.count += 1
            time.sleep(0.1)

    def thread_target(obj):
        for x in range(10):
            obj.increment()

    obj = foo()

    t1 = Thread(target=thread_target, args=(obj,))
    t2 = Thread(target=thread_target, args=(obj,))

    start = time.time()
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    stop = time.time()


# Generated at 2022-06-21 08:50:06.306977
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class FakeTask(object):
        '''This won't actually exist, but it is simulating how a real task
        will work.
        '''

        task_id = 'task_id'
        # These variables will simulate what is used in the real world
        callback_lock = threading.Lock()
        callback_data_lock = threading.Lock()

        def __init__(self):
            self.callback_data = []

        def send_callback(self):
            self.callback_data.append('Hello')


# Generated at 2022-06-21 08:50:13.432631
# Unit test for function lock_decorator
def test_lock_decorator():
    '''This is a test method to test the decorator lock_decorator'''
    import threading

    class TestClass(object):
        '''This is the test class for the lock_decorator decorator.
        It shows an example of how the decorator can be used with
        an instance attribute, and also how to use the decorator
        with an explicitly passed lock object.
        '''

        def __init__(self):
            self.lock = threading.Lock()
            self.attr_lock = threading.Lock()
            self.func_lock = threading.Lock()


# Generated at 2022-06-21 08:50:21.971017
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    lock = threading.Lock()
    threads = []
    def start():
        while True:
            time.sleep(0.01)

    class Test:
        def __init__(self, lock):
            # This is required in Python 2
            self._callback_lock = lock

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            start()

        @lock_decorator(lock=lock)
        @classmethod
        def some_method(cls, *args, **kwargs):
            start()

    t = Test(lock)
    for i in range(0, 100):
        thread = threading.Thread(target=t.send_callback)
        threads.append(thread)

# Generated at 2022-06-21 08:50:33.326983
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
        assert hasattr(threading.Lock(), '__enter__') and hasattr(threading.Lock(), '__exit__')
    except ImportError:
        import unittest.case
        raise unittest.case.SkipTest("No threading.Lock object found")

    class test_lock_decorator_class(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def locked_method(self, delay):
            from time import sleep
            sleep(delay)

    test_obj = test_lock_decorator_class()
    assert not test_obj._lock.locked()
    test_obj.locked_method(0)
    assert not test_obj._lock.locked()

# Generated at 2022-06-21 08:50:44.319207
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading
    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock(self):
            print('%s: %s acquired lock' % (time.ctime(), threading.current_thread().name))
            time.sleep(1)
            print('%s: %s released lock' % (time.ctime(), threading.current_thread().name))

    t = Test()
    for _ in range(10):
        thread = threading.Thread(target=t.lock, name='UnitTask %s' % _)
        thread.daemon = True
        thread.start()

    time.sleep(5)

# Generated at 2022-06-21 08:51:01.792065
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class DummyObject(object):

        def __init__(self):
            self._callback_lock = threading.Lock()
            self.locked_data = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, value):
            self.locked_data = value

        @lock_decorator(lock=threading.Lock())
        def lock_set(self, value):
            self.locked_data = value

    obj = DummyObject()

    obj.send_callback(1)
    assert obj.locked_data == 1

    obj.lock_set(2)
    assert obj.locked_data == 2



# Generated at 2022-06-21 08:51:08.092358
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    _lock = threading.Lock()

    @lock_decorator(lock=_lock)
    def lock_using_func():
        return "success"

    @lock_decorator(attr='_lock')
    def lock_using_attr(self):
        return "success"

    class test_lock_decorator:
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_using_class_attr(self):
            return "success"

    assert lock_using_func() == "success"
    assert lock_using_attr(None) == "success"
    assert test_lock_decorator().lock_using_class_attr() == "success"

# Generated at 2022-06-21 08:51:17.542477
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Test case 1:  Equivalent

    # Using a pre-defined instance attribute
    class T1(object):
        _lock = threading.Lock()

        def __init__(self):
            self.count = 0

        @lock_decorator(attr='_lock')
        def do_it(self, count):
            self.count += count

    # Using a pre-defined lock variable
    class T2(object):
        def __init__(self):
            self.count = 0
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def do_it(self, count):
            self.count += count

    # Test case 2:  Equivalent

    # Using a pre-defined instance attribute
    class T3(object):
        _

# Generated at 2022-06-21 08:51:29.287425
# Unit test for function lock_decorator
def test_lock_decorator():
    from .unit import UnitTestCase
    from .unit import fix_loader

    # We need to import ansible.module_utils.remote_management.ansible_freeipa.module_common
    pm = fix_loader()
    if pm is not None:
        pm.load_module('ansible.module_utils.remote_management.ansible_freeipa.module_common')

    from ansible.module_utils.remote_management.ansible_freeipa.module_common import lock_decorator

    import threading

    class TestClass(object):
        _lock = threading.RLock()

        def __init__(self):
            self.val = 1

        @lock_decorator(attr='_lock')
        def with_lock_attr(self):
            self.val += 1


# Generated at 2022-06-21 08:51:41.882914
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):

        def __init__(self):
            super(Test,self).__init__()
            self._lock = threading.Lock()

        @lock_decorator()
        def no_op(self):
            pass

        @lock_decorator(attr='_lock')
        def no_op2(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def no_op3(self):
            pass


    t = Test()
    ts = list()
    lock = threading.Lock()

    test_cases = [
        ('no_op', t.no_op),
        ('no_op2', t.no_op2),
        ('no_op3', t.no_op3),
    ]

# Generated at 2022-06-21 08:51:55.167006
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import sys

    def run_thread(fn, name, lock=None):
        # set up the thread with a name and target
        thr = threading.Thread(target=fn, name=name, args=(lock,))
        # start the thread
        thr.start()
        # join the thread
        thr.join()

    def test_fn(lock):
        # print the current thread's name
        print('{0} is running'.format(threading.current_thread().name))
        # print the current thread's lock
        print('{0} has attr lock {1}'.format(threading.current_thread().name, lock))
        # how long to sleep for
        sleep_time = 0.5

        with lock:
            # sleep
            time.sleep(sleep_time)

   

# Generated at 2022-06-21 08:52:01.803796
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyLock(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def decorated(self):
            return 'decorated'

        @lock_decorator(lock=threading.Lock())
        def decorated_with_lock(self):
            return 'decorated_with_lock'

    lock = MyLock()
    assert lock.decorated() == 'decorated'
    assert lock.decorated_with_lock() == 'decorated_with_lock'


if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-21 08:52:11.990258
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading as th
    lock_attr = '__callback_lock'
    lock = th.Lock()

    # Create a class that uses a class attribute as the lock
    class Class1:
        def __init__(self):
            setattr(self, lock_attr, lock)

        @lock_decorator(attr=lock_attr)
        def do_thing1(self, num):
            return num * 2

    # Create a class that uses a class attribute as the lock
    class Class2:
        def __init__(self):
            setattr(self, lock_attr, lock)

        @lock_decorator(lock=lock)
        def do_thing2(self, num):
            return num * 2

    # Create a class that uses a instance attribute as the lock

# Generated at 2022-06-21 08:52:23.396736
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    if sys.version_info[0] != 3:
        return

    import threading


    # Explicit lock
    class WithExplicitLock(object):
        def __init__(self):
            self.value = None
            self.lock = threading.Lock()

        @lock_decorator(lock=self.lock)
        def set_value(self, value):
            self.value = value


    w = WithExplicitLock()


    # Implicit lock
    class WithImplicitLock(object):
        def __init__(self):
            self.value = None
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def set_value(self, value):
            self.value = value


    ww = WithImplicitLock()



# Generated at 2022-06-21 08:52:34.930370
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Thing(object):
        def __init__(self):
            self.counter = 0
            self.lock = threading.Lock()

        @lock_decorator(lock=None)
        def increment(self, *args, **kwargs):
            if hasattr(self, 'counter'):
                self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def decrement(self, *args, **kwargs):
            if hasattr(self, 'counter'):
                self.counter -= 1

    def threaded(func):
        '''Wraps a function and attempts to run it in a thread
        '''
        def inner(*args, **kwargs):
            threading.Thread(target=func, args=args, kwargs=kwargs).start()
        return

# Generated at 2022-06-21 08:53:01.677466
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import random
    import time
    import sys

    def sleepy_sum(max_val, delay):
        time.sleep(delay)
        return sum(range(max_val))

    def threaded_sum(args, sum_func):
        results = []
        threads = []
        for arg in args:
            t = threading.Thread(target=sum_func, args=arg)
            t.start()
            threads.append(t)
        for thread in threads:
            thread.join()
        return results

    def random_threaded_sum(args):
        results = threaded_sum(args, sleepy_sum)

    sum_start_time = time.time()

# Generated at 2022-06-21 08:53:10.336066
# Unit test for function lock_decorator
def test_lock_decorator():
    # This is intended to be run by py.test
    # So py.test must be installed

    # Add py.test to system PATH
    import sys, os
    sys.path.append(os.path.dirname(__file__))

    # import py.test
    import pytest

    # Use py.test to run test
    pytest.main([os.path.dirname(__file__), '-v'])

if __name__ == '__main__':
    test_lock_decorator()

# vim: set et ts=4 sw=4 ft=python:

# Generated at 2022-06-21 08:53:21.208963
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys

    # This function does nothing
    def some_function(arg: 'string'):
        sys.stdout.write(arg)

    # This class defines a Lock and a method that uses it
    class Lockable():

        def __init__(self, arg: 'string'):
            import threading
            self._lock = threading.Lock()
            self._arg = arg

        @lock_decorator(attr='_lock')
        def some_function(self):
            sys.stdout.write(self._arg)
            return

    # This class defines a Lock and a method that uses it
    @lock_decorator(lock=Lockable('some_function')._lock)
    def other_function(arg: 'string'):
        sys.stdout.write(arg)

    # Use the class with the ``

# Generated at 2022-06-21 08:53:29.054250
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    l = []
    @lock_decorator(lock=lock)
    def foo():
        l.append('foo')
    @lock_decorator(attr='_lock')
    def bar(self):
        l.append('bar')
    class Foo(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def baz(self):
            l.append('baz')
    threads = []
    for i in range(5):
        t = threading.Thread(target=foo)
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    assert len(l) == 5
    threads = []

# Generated at 2022-06-21 08:53:41.102957
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import mock
    import threading
    import time
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
        from unittest2.case import skip, skipIf
    else:
        import unittest
        from unittest.case import skip, skipIf
    from functools import partial
    class test_lock_decorator(unittest.TestCase):
        def test_lock_decorator_module(self):
            lock = threading.Lock()
            a = []
            def func(arg1, arg2):
                a.append((arg1, arg2))

            locked = lock_decorator(lock=lock)(func)
            locked2 = lock_decorator(attr='lock')(func)


# Generated at 2022-06-21 08:53:53.685228
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    if sys.version_info < (3, 0):
        from mock import MagicMock, patch
    else:
        from unittest.mock import MagicMock, patch
    from collections import namedtuple
    from ansible.utils.vars import merge_hash

    FakeObj = namedtuple('FakeObj', ['attr'])

    obj = MagicMock()
    obj.lock = MagicMock()

    lock1 = MagicMock()
    lock2 = MagicMock()

    fake_obj1 = FakeObj(attr='lock')
    fake_obj2 = FakeObj(attr='lock')

    @lock_decorator(attr='attr')
    def fake_attr_method(*args, **kwargs):
        assert len(args) == 1
        assert len(kwargs) == 0

# Generated at 2022-06-21 08:53:56.804852
# Unit test for function lock_decorator
def test_lock_decorator():
    class Test(object):
        @lock_decorator(attr='lock')
        def method(self, a):
            return a

    t = Test()
    assert t.method(1) == 1

# Generated at 2022-06-21 08:54:08.500802
# Unit test for function lock_decorator
def test_lock_decorator():
    # Python 2
    if hasattr(__builtins__, '__import__'):
        import imp
        from mock import patch
        from ansible_collections.sivel.python.tests.unit.compat import unittest
        from ansible_collections.sivel.python.tests.unit.compat.mock import Mock, MagicMock, patch
        from ansible_collections.sivel.python.plugins.module_utils.common._lock import lock_decorator

    # Python 3
    else:
        from importlib import util
        from unittest import mock
        from unittest import TestCase
        import inspect

        class Mock(unittest.mock.Mock):
            def assert_called_once_with(self, *args, **kwargs):
                return unittest.mock

# Generated at 2022-06-21 08:54:17.170704
# Unit test for function lock_decorator
def test_lock_decorator():
    from threadsafe_iter import threadsafe_iter

    import pytest
    import threading

    def _test_threads_iter(iterable, lock):
        for _ in threadsafe_iter(iterable, lock):
            pass

    lock = threading.Lock()

    _ = [_test_threads_iter([i for i in range(3)], i) for i in range(3)]
    for _ in range(3):
        _ = threading.Thread(target=_test_threads_iter, args=([i for i in range(3)], lock)).start()

# Generated at 2022-06-21 08:54:27.457908
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread

    class SomeClass(object):
        def __init__(self):
            self._callback_lock = Lock()
            self.executed = False

        def acquire_lock(self):
            with self._callback_lock:
                return

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            self.executed = True

        @lock_decorator(lock=Lock())
        def some_method(self):
            self.executed = True

    some_class = SomeClass()
    some_class.send_callback()
    assert some_class.executed

    def test_thread():
        some_class.acquire_lock()
        some_class.send_callback()
        some_class.release_lock()


# Generated at 2022-06-21 08:55:07.629195
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    import time
    class Test(object):
        def __init__(self):
            self.count = 0
            self.lock_count = 0
            self.lock = Lock()
        @lock_decorator(attr='lock')
        def increment_count(self):
            self.count = self.count + 1
            time.sleep(1)
        @lock_decorator(lock=Lock())
        def increment_lock_count(self):
            self.lock_count = self.lock_count + 1
            time.sleep(1)
    test = Test()
    # We need to decrement the count to catch the race condition
    # If the lock is working the count will be 1, if not then the 
    # count will be >1. This is because Thread2 is decreasing the
   

# Generated at 2022-06-21 08:55:17.292131
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Test the lock decorator works as expected
    '''
    try:
        import threading
    except ImportError:
        return

    class TestLock:
        def __init__(self):
            # Python2 doesn't have ``nonlocal``
            # simulate class variable
            self.counter = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment_attr(self):
            # set in a function scope, since Python2 doesn't have ``nonlocal``
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def increment_param(self):
            # set in a function scope, since Python2 doesn't have ``nonlocal``
            self.counter += 1

    test_lock = TestLock()
    test_lock

# Generated at 2022-06-21 08:55:27.140464
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Test(object):

        def __init__(self, value):
            self.value = value
            self._lock = threading.RLock()

        @lock_decorator(attr='_lock')
        def add_one(self, value):
            self.value += 1
            return value

        @lock_decorator(lock=threading.RLock())
        def add_two(self, value):
            self.value += 2
            return value

    test = Test(0)
    test.add_one()
    test.add_two()
    test.add_two()
    test.add_one()
    assert test.value == 4, test.value

# Generated at 2022-06-21 08:55:38.215969
# Unit test for function lock_decorator
def test_lock_decorator():
    # NOTE: message on pylint 2.3.1+:
    #       "invalid-name: Cannot use "test_lock_decorator" as a global variable name"
    #       Reason: "The Variable Name "test_lock_decorator" is not valid.\n"
    #               "Please see PEP-0008: "
    #       URL: https://docs.python.org/3/library/unittest.mock.html
    #       Solution:  (1) disable this message in pylintrc, or
    #                  (2) change name to something that begins with "_"
    #                  (3) ignore this message in pylint
    try:
        from threading import Lock
    except ImportError:
        from unittest import SkipTest
        raise SkipTest("requires threading")
