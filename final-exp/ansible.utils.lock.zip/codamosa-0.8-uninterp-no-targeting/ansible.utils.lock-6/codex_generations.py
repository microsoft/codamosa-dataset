

# Generated at 2022-06-21 08:45:43.544228
# Unit test for function lock_decorator
def test_lock_decorator():

    from threading import Lock
    from threading import Thread
    import time

    class Counter(object):
        def __init__(self):
            self.count = 0
            self._counter_lock = Lock()

        @lock_decorator(attr='_counter_lock')
        def increment(self):
            # 2 increments should be atomic
            self.count += 1
            time.sleep(1)
            self.count += 1

    counter = Counter()

    def run():
        while counter.count < 150:
            counter.increment()
            time.sleep(0.01)

    threads = []
    for _ in range(3):
        thread = Thread(target=run)
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    # If the lock decorator

# Generated at 2022-06-21 08:45:53.613307
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    class TestImplementingLock(object):
        def __init__(self, nam):
            self.attr_name = nam

        def __call__(self):
            return self

    import time
    class TestLock(object):
        def __init__(self):
            self.locked = False

        def __enter__(self):
            assert not self.locked
            self.locked = True

        def __exit__(self, *args):
            self.locked = False

    class TestObject(object):
        @lock_decorator(attr='testlock')
        def method_with_attr(self, val):
            assert self.testlock.locked
            self.val = val


# Generated at 2022-06-21 08:46:01.713342
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._attr_lock = threading.Lock()
            self._lock = threading.Lock()

        @lock_decorator(attr='_attr_lock')
        def attr_lock_decorator(self):
            pass

        @lock_decorator(lock=self._lock)
        def explicit_lock_decorator(self):
            pass

    foo = Foo()
    assert hasattr(foo, 'attr_lock_decorator')
    assert hasattr(foo, 'explicit_lock_decorator')

# Generated at 2022-06-21 08:46:13.878138
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import threading

    class TestLock(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._attr = 0
            self._lock2 = threading.Lock()
            self._attr2 = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self._attr += 1

        @lock_decorator(lock=threading.Lock())
        def increment2(self):
            self._attr2 += 1

        @lock_decorator(attr='_lock2')
        def increment3(self):
            self._attr2 += 1

    obj = TestLock()

    def worker():
        obj.increment()

    def worker2():
        obj.increment2()

    def worker3():
        obj.increment

# Generated at 2022-06-21 08:46:22.220260
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock, current_thread
    from time import sleep

    # Create a shared lock
    shared_lock = Lock()

    # Create a thread that uses @lock_decorator to take and hold
    # the lock

    class Dummy:
        def __init__(self):
            self.lock = Lock()

        @lock_decorator()
        def acquire_lock(self):
            print('starting acquire_lock(), thread {0}'.format(current_thread().getName()))
            self.lock.acquire()
            sleep(1)
            print('finishing acquire_lock(), thread {0}'.format(current_thread().getName()))


# Generated at 2022-06-21 08:46:32.244781
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class A(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

        # This method will be locked
        @lock_decorator(attr='_lock')
        def increment(self):
            self._value += 1
            print(self._value)

        # This method will not be locked
        def decrement(self):
            self._value -= 1
            print(self._value)

    # You can also explicitly pass a lock
    class B(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = 0

        # This method will be locked (explicitly passing lock)

# Generated at 2022-06-21 08:46:41.297252
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.a = 0

        @lock_decorator(lock=self.lock)
        def test_lock(self):
            self.a = self.a + 1

        @lock_decorator(attr='lock')
        def test_attr(self):
            self.a = self.a - 1

    t = Test()
    t.test_lock()
    t.test_attr()

    assert t.a == 0

# Generated at 2022-06-21 08:46:43.461080
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import sys

    try:
        import mock
    except ImportError:
        from unittest import mock

    class MyClass(object):
        @lock_decorator(attr='lock')
        def method(self):
            print('foo')

    my_obj = MyClass()
    my_obj.lock = threading.Lock()

    with mock.patch.object(sys.stdout, 'write') as out:
        my_obj.method()
        assert out.called



# Generated at 2022-06-21 08:46:53.496180
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        print('Skipping unit test for function lock_decorator; threading module not available')
        return

    # Test class to use
    class LockTester:
        def __init__(self):
            self.__lock = threading.Lock()
            self.counter = 0

        @lock_decorator()
        def update_counter(self):
            self.counter += 1

        @lock_decorator(attr='_LockTester__lock')
        def update_counter_alt(self):
            self.counter += 1

    # Start with the instance attribute
    lt = LockTester()
    for _ in range(0, 100):
        lt.update_counter()
    assert lt.counter == 100

    # Alternate instance attribute
    lt

# Generated at 2022-06-21 08:46:59.799737
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    call_me_lock = threading.Lock()

    class TestClass(object):

        def __init__(self):
            self.i = 0

        @lock_decorator(attr='_call_me_lock')
        def call_me(self, wait=None):
            from time import sleep
            if wait:
                sleep(wait)
            self.i += 1

        @lock_decorator(lock=call_me_lock)
        def call_me2(self, wait=None):
            from time import sleep
            if wait:
                sleep(wait)
            self.i += 1

    test = TestClass()
    test.i = 1

    from threading import Thread
    # Intentionally not using ThreadPool for this
    # test, since the ordering of execution is
    # important

# Generated at 2022-06-21 08:47:12.229944
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    global counter
    counter = 0
    # The lock uses a RLock so that it can be acquired more than once
    lock = threading.RLock()

    class Test(object):
        def __init__(self, lock):
            self.lock = lock

        @lock_decorator(lock=lock)
        def method(self):
            global counter
            counter += 1

    t = Test(lock)

    # Test the lock_decorator to make sure the lock is working
    for i in range(10):
        t.method()
        # Verify counter is only incremented once per method call
        assert counter == i + 1

    # Cleanup
    del global_variables['counter']

# Generated at 2022-06-21 08:47:20.968586
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a fake lock
    class FakeLock:
        def __enter__(self):
            self.enter_called = True
        def __exit__(self, exc_type, exc_value, traceback):
            self.exit_called = True
    l = FakeLock()
    # This will store attr='_lock', but instead of a real lock
    # it points to the mock object that counts the number of times
    # enter() and exit() have been called.
    @lock_decorator(attr='_lock')
    def a_func(self, a, b):
        return a + b
    # note that args[0] is a mock object
    args = (object, 2, 3)
    # set the mock lock
    setattr(args[0], '_lock', l)
    # call the function
    a

# Generated at 2022-06-21 08:47:30.904052
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import random

    class Infiltrate(object):

        lock = threading.Lock()

        def __init__(self):
            self.public_data = [0]
            self.private_data = [0]

        @lock_decorator(lock=lock)
        def public_method(self):
            self.public_data.append(random.randint(0, 100))

        @lock_decorator(attr='lock')
        def private_method(self):
            self.private_data.append(random.randint(0, 100))


    def test_public(infiltrate):
        infiltrate.public_method()

    def test_private(infiltrate):
        infiltrate.private_method()

    for _ in range(10):
        the_test = Infiltrate()

# Generated at 2022-06-21 08:47:41.912733
# Unit test for function lock_decorator
def test_lock_decorator():
    # This function will fail if the lock decorator is not working
    class Lockable(object):
        def __init__(self):
            self.lock = None

    @lock_decorator(attr='lock')
    def lockable_function(self, arg):
        return arg

    @lock_decorator()
    def dec_func():
        return True

    @lock_decorator(lock=lockable_function.__wrapped__)
    def dec_locked_func(self):
        return True

    l = Lockable()
    l.lock = lockable_function.__wrapped__
    assert lockable_function(l, True) is True

    assert dec_func() is True
    assert dec_locked_func(l) is True

# Generated at 2022-06-21 08:47:48.289016
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = threading.RLock()
    class Foo(object):
        def __init__(self):
            self._lock = lock
        @lock_decorator(attr='_lock')
        def foo(self):
            return True
        @lock_decorator(lock=lock)
        def bar(self):
            return False

    f = Foo()
    assert f.foo()
    assert not f.bar()

# Generated at 2022-06-21 08:47:57.525974
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Setup
    class A(object):
        @lock_decorator()
        def missing_lock(self):
            return self.name

    # Test
    a = A()
    assert a.missing_lock() is None

    # Setup
    class B(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def use_instance_lock(self):
            return self.name

    # Test
    b = B()
    b.name = 'B'
    assert b.use_instance_lock() == 'B'

    # Setup
    class C(object):
        @lock_decorator(lock=threading.Lock())
        def use_passed_lock(self):
            return self.name

    # Test

# Generated at 2022-06-21 08:48:08.218596
# Unit test for function lock_decorator
def test_lock_decorator():

    class Test(object):

        def __init__(self):
            self.callback = None
            self.foo = "bar"
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, data):
            self.callback = data

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            self.foo = "baz"

    data1 = {"foo": "bar"}
    data2 = {"asdf": "jkl;"}
    test = Test()

    def callback1():
        callback2()
    def callback2():
        if test.callback == data1:
            test.send_callback(data2)
        else:
            test.send_callback(data1)

   

# Generated at 2022-06-21 08:48:19.421803
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._test_lock = threading.Lock()
            self._test_compare = {}

        @lock_decorator(attr='_test_lock')
        def test_method(self, a, b):
            self._test_compare[a] = a + b

        @lock_decorator(lock=threading.Lock())
        def test_method_explicit(self, a):
            self._test_compare[a] = a

    def thread_test(a, b):
        t.test_method(a, b)

    def thread_test_explicit(a):
        t.test_method_explicit(a)

    t = Test()
    for i in range(1, 4):
        threading

# Generated at 2022-06-21 08:48:29.652529
# Unit test for function lock_decorator
def test_lock_decorator():
    failed = []

    class something(object):
        i = 0

        @lock_decorator(attr='lock')
        def incr(self):
            self.i += 1

        @lock_decorator(attr='missing_lock_attr')
        def nolock(self):
            self.i += 1

        @lock_decorator(lock=None)
        def nolock2(self):
            self.i += 1

        @lock_decorator()
        def nolock3(self):
            self.i += 1

    from threading import Lock
    from multiprocessing import Process
    from time import sleep
    from random import random

    for _ in range(10):
        sleep(random() / 10)
        s = something()
        s.lock = Lock()

# Generated at 2022-06-21 08:48:40.234580
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class SimpleClass(object):

        def __init__(self):
            self.lock = threading.Lock()
            self.counter = 0
            self.counter2 = 0

        @lock_decorator(attr='lock')
        def simple_counter(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def simple_counter2(self):
            self.counter2 += 1

    ob = SimpleClass()
    ob.simple_counter()
    assert ob.counter == 1
    ob.simple_counter()
    assert ob.counter == 2

    ob.simple_counter2()
    assert ob.counter2 == 1
    ob.simple_counter2()
    assert ob.counter2 == 2

    return 0

# Generated at 2022-06-21 08:48:56.880892
# Unit test for function lock_decorator
def test_lock_decorator():
    # NOTE: This class is not optimized for concurrency. Be careful
    #       running multi-threaded unit tests.
    class SampleClass(object):
        def __init__(self):
            self.count = 0

        @lock_decorator(attr='counter_lock')
        def increment_class_count(self):
            self.count += 1

        def increment_class_count_no_lock(self):
            self.count += 1

        @staticmethod
        @lock_decorator(lock=threading.Lock())
        def increment_static_count():
            SampleClass.count += 1

        @classmethod
        @lock_decorator(lock=threading.Lock())
        def increment_instance_count(cls):
            cls.count += 1


# Generated at 2022-06-21 08:49:06.331102
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo:
        def __init__(self):
            self.calls = 0
            self.p_lock = threading.Lock()
            self.g_lock = threading.Lock()
            self.attr_lock = threading.Lock()
            self.class_attr_lock = threading.Lock()

        @lock_decorator(lock=None)
        def protected(self):
            with self.p_lock:
                self.calls += 1

        @lock_decorator(attr='attr_lock')
        def guarded(self):
            with self.g_lock:
                self.calls += 1


# Generated at 2022-06-21 08:49:18.216875
# Unit test for function lock_decorator
def test_lock_decorator():

    # Test the lock decorator with the attr option
    class Lockable:
        def __init__(self):
            self.lock = False

    class LockedClass(Lockable):
        @lock_decorator(attr='lock')
        def some_method(self):
            pass
    
    inst = LockedClass()
    inst.some_method()
    # Using the attr option, the lock was set to False, so
    # this assert is True. This means the lock was locked.
    assert inst.lock

    # Test the lock decorator with the lock option
    class LockNotSet:
        def __init__(self):
            self.lock = False

    class LockIsSet(LockNotSet):
        @lock_decorator(lock=True)
        def some_method(self):
            pass

    inst = Lock

# Generated at 2022-06-21 08:49:25.488123
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    from shutil import rmtree
    from tempfile import mkdtemp
    from time import time

    from ansible_collections.ansible.community.plugins.module_utils.common._collections_compat import Counter

    class Foo(object):
        # Create a lock to use, but never actually assign it to ``_lock``
        _lock = Lock()

        # Wrap this method in our lock decorator
        @lock_decorator(attr='_lock')
        def method(self, fn):
            '''This is just a method that will write a file,
            but it could be any method.
            '''
            with open(fn, 'w') as f:
                f.write('1')

        # This method won't be wrapped

# Generated at 2022-06-21 08:49:34.710638
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    x = 0
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def add_1(n):
        global x
        for i in range(n):
            x += 1

    def run_add_1(n):
        try:
            add_1(n)
        except Exception as e:
            print(e)

    # Run add_1 in ten threads, all adding 10, 100, or 1000 to x
    threads = []
    for i in range(10):
        threads.append(threading.Thread(target=run_add_1, args=(i*10 + 10,)))
        threads[-1].start()
    for i in range(10):
        threads[i].join()

    # Assert that all values were added

# Generated at 2022-06-21 08:49:44.716145
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    code = 0

    class LockTestCase(object):
        def __init__(self):
            self.thread_counter = 0
            self.attr_lock = threading.Lock()
            self.explicit_lock = threading.Lock()

        def test_threads(self, count):
            threads = []
            for i in range(count):
                t = threading.Thread(
                    target=self.test_thread,
                    args=(i,)
                )
                threads.append(t)
                t.start()
            for t in threads:
                t.join()

        def thread_id(self):
            return self.thread_counter

        @lock_decorator(attr='attr_lock')
        def test_thread_attr_lock(self):
            self.thread_counter += 1



# Generated at 2022-06-21 08:49:50.840964
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method0(self):
            return 1

        @lock_decorator(lock=threading.Lock())
        def method1(self):
            return 2
    t = Test()
    assert t.method0() == 1
    assert t.method1() == 2

# Generated at 2022-06-21 08:50:00.133739
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    value = 0
    @lock_decorator(lock=lock)
    def set_value():
        # add one to value
        nonlocal value, lock
        value += 1

    @lock_decorator(attr='lock')
    def add_value():
        # add 3 to value
        nonlocal value, lock
        value += 3

    class ValueSetter:
        lock = threading.Lock()
        def __init__(self, value):
            self.value = value

        @lock_decorator(attr='lock')
        def set_value(self):
            # add two to value
            self.value += 2

    # start the thread that will call set_value
    t = threading.Thread(target=set_value)
    t.start()

# Generated at 2022-06-21 08:50:10.059923
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    l = threading.Lock()
    called = []
    class Foo(object):
        @lock_decorator()
        def method(self):
            called.append(1)

        @lock_decorator(lock=l)
        def method2(self):
            called.append(2)

        @lock_decorator(attr='_lock')
        def method3(self):
            called.append(3)

    class Bar(Foo):
        _lock = None

    foo = Foo()
    bar = Bar()

    threads = [threading.Thread(target=foo.method) for _ in range(100)]
    threads += [threading.Thread(target=foo.method2) for _ in range(100)]

# Generated at 2022-06-21 08:50:17.402197
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class SomeClass:
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(lock=lock)
        def send_callback(self, *args, **kwargs):
            pass

        @lock_decorator(attr='_callback_lock')
        def send_callback_with_attr(self, *args, **kwargs):
            pass

    SomeClass().send_callback()

# Generated at 2022-06-21 08:50:32.140223
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass:
        _callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            print('in callback')

        @lock_decorator(lock=threading.Lock())
        def some_method(self, *args, **kwargs):
            print('in some_method')

    t = TestClass()
    t.send_callback()
    t.some_method()

# Generated at 2022-06-21 08:50:38.429140
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    class MyClass(object):
        def __init__(self):
            self.lock_instance = threading.Lock()
            self.counter_instance = 0
            self.counter_class = 0

        @lock_decorator(lock=lock)
        def increment_counter(self):
            self.counter_instance += 1

        @lock_decorator(attr='lock_instance')
        def increment_counter_by_one(self):
            self.counter_instance += 1

        @lock_decorator(attr='_lock')
        @classmethod
        def increment_counter_class(cls):
            cls.counter_class += 1

    myclass = MyClass()
    myclass.increment_counter()
    assert myclass.counter_instance == 0

# Generated at 2022-06-21 08:50:49.052520
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    class LockDecoratorTestCase(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.lock = threading.Lock()
            cls.tests = []
        def setUp(self):
            self.counter = 0
        def tearDown(self):
            self.assertEqual(self.counter, 10)
            LockDecoratorTestCase.tests.append(True)
        @lock_decorator(lock=LockDecoratorTestCase.lock)
        def test_passing_lock(self):
            for i in range(10):
                self.counter += 1

# Generated at 2022-06-21 08:50:56.788599
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    
    class TestClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            self.counter += 1
            #print(self.counter)

    t = TestClass()
    def thread_func():
        import time
        #print('start thread func')
        for _ in range(10):
            t.send_callback()
            time.sleep(0.001)  # sleep 1ms
        #print('end thread func')
    
    threads = []

# Generated at 2022-06-21 08:51:03.629153
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    lock_attr = '_lock'
    dummy_attr = 'dummy'

    class TestClass(object):
        '''A class to be used while unit testing the ``lock_decorator`` function'''
        def __init__(self):
            self._lock = lock
            self.dummy = 0

        @lock_decorator(attr=lock_attr)
        def locked_method_self_lock(self):
            '''This method assumes ``self`` is the first argument'''
            lock.acquire()
            self.dummy += 1

        @lock_decorator(lock=lock)
        def locked_method_lock_arg(self):
            '''This method explicitly takes a lock object'''
            lock.acquire()
            self.dummy

# Generated at 2022-06-21 08:51:16.279195
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading
    import time

    # Test definition of attribute
    class Test(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self, name, wait_time=1):
            time.sleep(wait_time)
            return name

    inst = Test()
    print(inst.some_method('foo', wait_time=0.05))

    # Test passing of lock
    # Do no use the same lock
    import copy
    _lock = copy.copy(inst._lock)

    @lock_decorator(lock=_lock)
    def some_other_method(name, wait_time=1):
        time.sleep(wait_time)
        return name


# Generated at 2022-06-21 08:51:28.294864
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    from time import sleep
    from random import random

    class Example:
        def __init__(self):
            self.counter = 0
            self.lock = Lock()

    def run(instance):
        while True:
            sleep(random())
            instance.increment()

    @lock_decorator(attr='lock')
    def increment(self):
        self.counter += 1

    @lock_decorator()
    def decrement(self):
        self.counter -= 1

    ex = Example()
    threads = [Thread(target=run, args=(ex,)) for _ in range(5)]
    [t.start() for t in threads]
    sleep(5)
    [t.join() for t in threads]
    assert ex.counter == 0

    ex = Example()


# Generated at 2022-06-21 08:51:35.091144
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading
    import unittest
    import multiprocessing

    # Use a Lock() in the test to ensure that
    # we don't actually have to have the lock
    shared_lock = threading.Lock()

    class TestClass(object):
        def __init__(self):
            self.test_attr = None
            self.run_times = []
            # Use a temporary lock to ensure that
            # we can use the decorator with a lock object
            self.lock_obj = threading.Lock()

        @lock_decorator(attr='missing_lock_attr')
        def method_missing_attr(self):
            raise Exception('This code should never be run')


# Generated at 2022-06-21 08:51:46.153645
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class MyClass(object):
        def __init__(self):
            self._callback_lock = threading.RLock()
            self._callback_ran = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, msg):
            sleep(0.5)
            self._callback_ran += 1

    class MyOtherClass(object):
        def __init__(self):
            self._callback_ran = 0
            self._lock = threading.RLock()

        @lock_decorator(lock=self._lock)
        def send_callback(self, msg):
            sleep(0.5)
            self._callback_ran += 1

    my_class = MyClass()
    my_other_class = MyOtherClass()

   

# Generated at 2022-06-21 08:51:58.135999
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import os
    import tempfile
    from ansible.module_utils._text import to_native

    class LockDecoratorTest(object):
        '''This is a simple class for unit testing the lock decorator'''
        def __init__(self):
            self.path = os.path.join(tempfile.gettempdir(), 'lock_decorator.log')
            if os.path.exists(self.path):
                os.unlink(self.path)
            self._lock = threading.Lock()


# Generated at 2022-06-21 08:52:27.944953
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    import pytest

    # Ensure we are on Python3
    assert sys.version_info[0] >= 3, 'This code was written for Python 3 and greater'

    # Setup test class
    class TestClass:
        def __init__(self):
            self._callback_lock = threading.Lock()
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            pass

    # Tests for lock_decorator
    tc = TestClass()
    assert tc.send_callback.__name__ == 'send_callback'
    assert tc.send_callback.__doc__ == '\n    Unit test for function lock_decorator\n    '

    # Ensure decorator works as expected

# Generated at 2022-06-21 08:52:39.487751
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLock(object):
        def __init__(self):
            self.value = 'initial'
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def test_lock_attr(self, v):
            self.value = v

        @lock_decorator(lock=threading.Lock())
        def test_lock_arg(self, v):
            self.value = v

        @lock_decorator()
        def test_no_lock(self, v):
            self.value = v

        @lock_decorator(attr='missing_lock_attr')
        def test_no_lock_attr(self, v):
            self.value = v


# Generated at 2022-06-21 08:52:49.239486
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    if sys.version_info[0] >= 3:
        import unittest
    else:
        import unittest2 as unittest

    class Example(object):
        def __init__(self):
            import threading
            self.lock = threading.Lock()
            self._lock = threading.Lock()

        @lock_decorator(lock=None)
        def method(self):
            assert 'lock' in self.__dict__
            assert '_lock' in self.__dict__
            self.lock = 1
            self._lock = 2

        @lock_decorator(lock=True)
        def method2(self):
            assert 'lock' in self.__dict__
            assert '_lock' in self.__dict__
            self.lock = 1

# Generated at 2022-06-21 08:52:59.073311
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class TestLock:
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def test(self, x):
            print('inside test')
            return x


    tl = TestLock()
    assert tl.test(2) == 2

    @lock_decorator(lock=threading.Lock())
    def test(x):
        print('inside test')
        return x

    assert test('abc') == 'abc'

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-21 08:53:08.339364
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading, logging, time
    logger = logging.getLogger()

    class LockTest:

        def __init__(self):
            self.counter = 0
            self.__callback_lock = threading.Lock()
            self.__logger = logging.getLogger(str(self))

        def __str__(self):
            return "%s(%s)" % (self.__class__.__name__, id(self))

        @lock_decorator(attr='__callback_lock')
        def increment(self):
            if self.counter < 10:
                time.sleep(.1)
                self.counter += 1
            self.__logger.debug("%s: %s", self, self.counter)


# Generated at 2022-06-21 08:53:19.122616
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test lock_decorator function'''
    # This is a very limited test, but it's better than nothing
    import threading

    _lock = threading.Lock()
    _test_lock = threading.Lock()

    @lock_decorator(lock=_lock)
    def test_lock_on_lock():
        _test_lock.acquire()
        return

    @lock_decorator(attr='_lock')
    def test_lock_on_attr():
        _test_lock.acquire()
        return

    @lock_decorator()
    def test_missing_lock():
        _test_lock.acquire()
        return

    class TestObject(object):

        _lock = threading.Lock()


# Generated at 2022-06-21 08:53:27.514377
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class SomeClass(object):
        _lock = threading.Lock()
        _value = 0

        @lock_decorator(attr='_lock')
        def set_value(self, value):
            time.sleep(3)
            self._value = value

        def get_value(self):
            return self._value

    sc = SomeClass()
    sc.set_value(5)
    assert sc.get_value() == 5

    sc2 = SomeClass()
    l = threading.Lock()
    # Note: Python < 3.5 has no 'lock' method for Lock
    def _lock(lock):
        lock.acquire()

    lock_decorator(lock=l)(_lock)(l)
    assert l.locked()

# Generated at 2022-06-21 08:53:39.609718
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Create a variable
    lock_test = [0]

    # Create a lock
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def lock_test_increment():
        lock_test[0] += 1

    def lock_test_decrement():
        lock_test[0] -= 1

    # Create a decorator from the lock object
    lock_decrement = lock_decorator(lock=lock)(lock_test_decrement)

    # Create multiple threads to access the variable
    for _ in range(5):
        t = threading.Thread(target=lock_test_increment)
        t.daemon = True
        t.start()

    # Create multiple threads to access the variable

# Generated at 2022-06-21 08:53:50.426275
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import os
    import time
    import types

    class MyClass(object):
        def __init__(self):
            self.x = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def foo(self):
            self.x += 1
            time.sleep(2)
            return self.x

    class MyClassWithoutAttr(object):
        @lock_decorator(lock=threading.Lock())
        def foo(self):
            pass

    myClass = MyClass()
    myClassWithoutAttr = MyClassWithoutAttr()

    assert isinstance(myClass.foo, types.FunctionType)
    assert isinstance(myClassWithoutAttr.foo, types.FunctionType)
    assert isinstance(myClass.foo(), int)

# Generated at 2022-06-21 08:54:01.613616
# Unit test for function lock_decorator
def test_lock_decorator():
    class Obj(object):
        _lock = None

        def __init__(self, lock=None):
            if lock:
                self._lock = lock
            else:
                import threading
                self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def my_method(self, value):
            return value

        @lock_decorator(lock=None)
        def my_method2(self, value):
            return value

        @lock_decorator(lock=None)
        def my_method3(self, value):
            return value

    obj = Obj()
    assert obj.my_method(1) == 1

    import threading
    lock = threading.Lock()
    obj = Obj(lock)
    assert obj.my_method2(1) == 1

# Generated at 2022-06-21 08:54:48.734681
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def counter(self):
            self._counter += 1

    test = Test()
    test.counter()
    assert test._counter == 1

    # make sure we can't use lock_decorator wrong
    try:
        @lock_decorator()
        def test(): pass
        raise RuntimeError("lock_decorator failed")
    except TypeError:
        pass

    try:
        @lock_decorator(attr='_lock', lock=threading.Lock())
        def test(): pass
        raise RuntimeError("lock_decorator failed")
    except TypeError:
        pass


# For backwards compat

# Generated at 2022-06-21 08:54:53.036458
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class SomeClass(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self):
            pass

    obj = SomeClass()
    assert isinstance(obj._lock, threading.Lock)

# Generated at 2022-06-21 08:54:59.727211
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Obj:
        def __init__(self):
            self.num = 0
            self.lock = threading.Lock()

    @lock_decorator(lock=threading.Lock())
    def foo(num):
        return num

    @lock_decorator(attr='lock')
    def bar(obj, num):
        obj.num = num

    obj = Obj()
    obj2 = Obj()

    threads = []
    for i in range(8):
        thread = threading.Thread(target=foo, args=(i,))
        threads.append(thread)
        thread.start()
    for i in range(8):
        threads[i].join()

    for i in range(8):
        thread = threading.Thread(target=bar, args=(obj, i))
        threads

# Generated at 2022-06-21 08:55:10.117943
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    # This is the lock method, using a class attribute
    @lock_decorator(attr='_callback_lock')
    def send_callback(self, callback_func=None, callback_args=None):
        print('send_callback')

    # This is the "lock" method, using a class scoped
    # object.
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def some_method():
        print('some_method')

    # Create the class that all methods will
    # be invoked from.
    class LockClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

# Generated at 2022-06-21 08:55:18.736406
# Unit test for function lock_decorator
def test_lock_decorator():
    import subprocess
    import threading
    class dummy_cls(object):
        pass
    dummy_lock = dummy_cls()
    dummy_lock.acquire = lambda: None
    dummy_lock.release = lambda: None

    def check_release(dummy_lock, *args, **kwargs):
        _calls = getattr(dummy_lock, '_calls', 0)
        setattr(dummy_lock, '_calls', _calls + 1)

    def dummy_inner_method(*args, **kwargs):
        return args[0]

    @lock_decorator(attr='my_lock')
    def dummy_attr_method(*args, **kwargs):
        return dummy_inner_method(*args, **kwargs)


# Generated at 2022-06-21 08:55:29.471539
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Test the ``lock_decorator``.
    '''
    import threading
    class X:
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, callback, *args):
            '''
            Test method with attribute lock.
            '''
            callback('attrib', *args)
            return 0

        @lock_decorator(lock=threading.Lock())
        def some_method(self, callback, *args):
            '''
            Test method with passed lock object.
            '''
            callback('lockobj', *args)
            return 0

    # Test the attrib and passed lock object

# Generated at 2022-06-21 08:55:39.974985
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = threading.Lock()
    last_result = None

    @lock_decorator(lock=lock)
    def test_func_lock(arg):
        global last_result
        last_result = arg

    @lock_decorator(attr='lock')
    def test_attr_lock(arg):
        global last_result
        last_result = arg

    class TestObj(object):
        def __init__(self):
            self.lock = threading.Lock()

    obj = TestObj()

    lock.acquire()
    test_func_lock('test')
    assert last_result == 'test'
    lock.release()

    obj.lock.acquire()
    test_attr_lock('attr')
    assert last_result == 'attr'
    obj.lock.release()