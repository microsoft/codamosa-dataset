

# Generated at 2022-06-21 08:45:39.488226
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading
    from time import sleep

    def test_lock_decorator():

        class DummyObject(object):

            def __init__(self):
                self._lock = threading.Lock()
                self._counter = 0

            @lock_decorator(attr='_lock')
            def increment(self):
                self._counter += 1

            @lock_decorator(lock=self._lock)
            def decrement(self):
                self._counter -= 1

            def get_counter(self):
                return self._counter

        dummy = DummyObject()

        def do_work_dec():
            for i in range(100):
                dummy.decrement()

        def do_work_inc():
            for i in range(100):
                dummy.increment()

        threads = []

# Generated at 2022-06-21 08:45:49.036956
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Test function lock_decorator
    '''
    import threading

    test_lock = threading.Lock()

    # Test the attribute based lock
    class TestClass(object):
        ''' Class to test lock_decorator'''
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator()
        def test_lock(self):
            '''Test the attribute based lock. Assumes ``self`` is
            the first parameter.
            '''
            self._lock.acquire()
            self._lock.release()

    # Test the variable based lock
    class TestClass2(object):
        ''' Class to test lock_decorator'''
        def __init__(self, lock):
            self._lock2 = lock


# Generated at 2022-06-21 08:45:56.570574
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestObj(object):
        def __init__(self):
            self.lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='lock')
        def _locked_inc(self):
            self._counter += 1
            return self._counter

    to = TestObj()

    for _ in range(10):
        t = threading.Thread(target=to._locked_inc)
        t.start()
    time.sleep(3)
    assert to._counter == 1

    class TestClass(object):
        lock = threading.Lock()
        counter = 0

        @classmethod
        @lock_decorator(lock=lock)
        def _locked_inc(cls):
            cls.counter += 1

# Generated at 2022-06-21 08:46:04.605130
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    global var
    var = 0

    class dummy(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_method(self):
            global var
            var += 1

    class dummy2(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_method(self):
            global var
            var += 1

    class dummy3(object):
        @lock_decorator(lock=threading.Lock())
        def lock_method(self):
            global var
            var += 1

    d = dummy()
    d2 = dummy2()
    d3 = dummy3()


# Generated at 2022-06-21 08:46:08.119051
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass:
        def __init__(self):
            self._testing = 'Hello'
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def test_method(self):
            return self._testing

    obj = TestClass()
    assert obj.test_method() == 'Hello'

    @lock_decorator(lock=threading.Lock())
    def test_method_2():
        return 'Goodbye'

    assert test_method_2() == 'Goodbye'

# Generated at 2022-06-21 08:46:18.196494
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class Foo(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.__callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def _callback(self):
            import time
            time.sleep(3)

        @lock_decorator(attr='__callback_lock')
        def __callback(self):
            import time
            time.sleep(3)

        @lock_decorator(lock=lock)
        def callback(self):
            import time
            time.sleep(3)

    foo = Foo()
    foo._callback()
    foo.__callback()
    foo.callback()

# Generated at 2022-06-21 08:46:28.594141
# Unit test for function lock_decorator
def test_lock_decorator():
    import time

    class Example(object):
        def __init__(self):
            self._callback_lock = create_lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            time.sleep(1)
            print('send_callback')

    def create_lock():
        import threading
        return threading.Lock()

    example = Example()
    import threading
    threads = []
    for i in range(3):
        t = threading.Thread(target=example.send_callback)
        t.daemon = True
        t.start()
        threads.append(t)

    [ t.join() for t in threads ]


# Generated at 2022-06-21 08:46:34.160034
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    from threading import Thread, Lock
    lock = Lock()
    val = 0
    def test_func():
        global val
        for i in range(100):
            val = random.randint(0, 100)
        val = 100

    thread = Thread(target=test_func)
    thread.start()
    while True:
        if lock.locked():
            break
    with lock:
        assert 100 == val
    thread.join(timeout=1)
    assert not thread.is_alive

# Generated at 2022-06-21 08:46:46.024622
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Testme(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_callback_lock')
        def callback(self):
            self.counter += 1
            time.sleep(0.1)

    t = Testme()

    def run():
        # Run teh callback 100 times, so with 100 threads and no locking
        # we should see 100 * 100 (10k) callbacks
        for _ in range(100):
            t.callback()

    # Start 50 threads
    threads = [threading.Thread(target=run) for i in range(50)]

    # Start threads
    for thread in threads:
        thread.start()

    # Join threads

# Generated at 2022-06-21 08:46:55.686942
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading


    class MyClass(object):
        @lock_decorator(attr='_lock')
        def my_method(self):
            time.sleep(1)

        @lock_decorator(lock=threading.Lock())
        def my_other_method(self):
            time.sleep(1)


    @lock_decorator(attr='_lock')
    def my_function():
        time.sleep(1)

    @lock_decorator(lock=threading.Lock())
    def my_other_function():
        time.sleep(1)


    my_object = MyClass()
    assert 'my_method' in dir(my_object)
    assert 'my_other_method' in dir(my_object)

# Generated at 2022-06-21 08:47:09.218963
# Unit test for function lock_decorator
def test_lock_decorator():
    # pylint: disable=too-few-public-methods
    class Foo(object):
        def __init__(self):
            self._lock = None
            self._other = None

    f1 = Foo()
    f2 = Foo()

    @lock_decorator(attr='_lock')
    def myfunc(foo):
        assert foo._lock
        foo._other = foo
        return foo

    import threading
    f1._lock = f2._lock = threading.Lock()

    t1 = threading.Thread(target=myfunc, args=(f1,))
    t2 = threading.Thread(target=myfunc, args=(f2,))

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    assert f1 == f2

# Generated at 2022-06-21 08:47:19.094824
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class CallbackModule(object):
        callback_lock = threading.Lock()

        def __init__(self):
            self.results = None
            self.msg = None

        @lock_decorator(attr="callback_lock")
        def _load_name(self, results):
            self.results = results
            self.msg = "foo"

        @lock_decorator(attr="callback_lock")
        def _load_name_again(self, results):
            self.results = results
            self.msg = "bar"

        @lock_decorator(lock=threading.Lock())
        def _load_name_and_again(self, results):
            self.results = results

# Generated at 2022-06-21 08:47:30.061558
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Class(object):
        def __init__(self):
            self._lock = threading.Lock()

        __counter = 0
        @lock_decorator()
        def method(self):
            '''This method will be locked'''
            self.__counter += 1
            return self.__counter

        @lock_decorator(attr='_lock')
        def method2(self):
            '''This method will be locked (attr)'''
            return self.method()

    c = Class()

    e = threading.Event()
    def run(num):
        while not e.is_set():
            c.method()
            c.method2()
            e.wait(0.00001)

    threads = []

# Generated at 2022-06-21 08:47:42.308866
# Unit test for function lock_decorator
def test_lock_decorator():
    class LockObject:
        my_lock = None

        def __init__(self):
            self.my_lock = 1

        def get_lock(self):
            return self.my_lock

    # This is an example usage of a @lock_decorator using attr
    class Test1:
        def __init__(self):
            self.obj = LockObject()

        @lock_decorator(attr='obj')
        def get_obj(self):
            rv = self.obj.get_lock()
            self.obj.my_lock += 1
            return rv

    t1 = Test1()

    assert t1.get_obj() == 1
    assert t1.get_obj() == 2
    assert t1.get_obj() == 3

    # This is an example usage of @lock_decor

# Generated at 2022-06-21 08:47:54.134674
# Unit test for function lock_decorator
def test_lock_decorator():
    class DummyClass(object):

        def __init__(self):
            self._lock = 'lock is here'

        @lock_decorator(attr='_lock')
        def method_a(self, *args, **kwargs):
            return args, kwargs

        @lock_decorator(lock='lock')
        def method_b(self, *args, **kwargs):
            return args, kwargs

        @lock_decorator(lock='lock')
        def method_c(self, *args, **kwargs):
            raise RuntimeError('This should not be called')

    dc = DummyClass()
    assert dc.method_a(42, named='kall', named2='kwargs') == ((42,), {'named': 'kall', 'named2': 'kwargs'})

# Generated at 2022-06-21 08:48:00.586610
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLock(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='_lock')
        def increment(self, n):
            self.value += n

        @lock_decorator(lock=threading.Lock())
        def decrement(self, n):
            self.value -= n

    t = TestLock()

    def increment_value(n):
        for _ in range(n):
            t.increment(1)

    def decrement_value(n):
        for _ in range(n):
            t.decrement(1)


# Generated at 2022-06-21 08:48:09.943994
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    class SomeClass():
        _lock = None
        def __init__(self):
            self._lock = None

        @lock_decorator(attr='_lock')
        def this_will_succeed(self, value, result=10):
            return value + result

        @lock_decorator(lock=self._lock)
        def this_will_fail(self, value, result=10):
            return value + result

    class SomeClassTest(unittest.TestCase):
        def setUp(self):
            self.some_class = SomeClass()

        def test_this_will_succeed(self):
            self.assertEqual(self.some_class.this_will_succeed(3), 13)

if __name__ == '__main__':
    test

# Generated at 2022-06-21 08:48:20.518555
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep
    from textwrap import dedent

    class Test(object):
        def __init__(self, lock_attr_name):
            # Use the pre-defined lock attribute name
            self.lock_attr = lock_attr_name

        @lock_decorator(attr='lock_attr')
        def lock_method_with_attr(self, payload):
            return payload

        @lock_decorator(lock=threading.Lock())
        def lock_method_with_lock(self, payload):
            return payload

    # Locks are context managers, so they can be used with the ``with`` keyword
    # From the lock docs:
    # https://docs.python.org/2/library/threading.html?highlight=lock#lock-objects
    lock = threading.Lock()


# Generated at 2022-06-21 08:48:31.302411
# Unit test for function lock_decorator
def test_lock_decorator():
    # we will be testing the threading.Lock object with this decorator
    from threading import Lock

    # create a class for testing the ``attr`` param of the lock_decorator
    class TestClass(object):
        def __init__(self):
            self._callback_lock = Lock()

        @lock_decorator(attr='_callback_lock')
        def some_method(self, a, b):
            if a == b:
                return True
            return False

    # create an instance of the test class
    tc = TestClass()

    # create a second class for testing the ``lock`` param of the lock_decorator
    # a threading.Lock object is used

# Generated at 2022-06-21 08:48:41.595123
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLock(object):
        def __init__(self):
            self.count = 0
            self.timing = {}
            self.count_lock = threading.Lock()
            self.count_lock.acquire()  # Make sure the lock is acquired to begin
            self.timing_lock = threading.Lock()

        @lock_decorator(attr='count_lock')
        def increment_count(self):
            self.count += 1

        @lock_decorator(attr='timing_lock')
        def record_timing(self, key):
            assert key not in self.timing
            start = time.time()
            time.sleep(1)
            end = time.time()
            self.timing[key] = (start, end)

    test

# Generated at 2022-06-21 08:48:55.746903
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    class MockClass(object):
        lock = lock_decorator(attr='thing_locked')
        attr_lock = threading.Lock()
        @lock
        def lock_with_attr(self, value):
            self.x = value
            self.thing_locked = value
        lock_with_attr_second = lock(lock_with_attr)
        @lock(lock=attr_lock)
        def lock_with_lock(self, value):
            self.y = value
            self.attr_lock = value
        # this function only exists for unit tests
        # it's presence should not cause a collision
        attr_lock_copy = attr_lock
    obj = MockClass()

# Generated at 2022-06-21 08:49:03.058287
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._var = 0

        @lock_decorator(attr='_lock')
        def _wrapped_increment(self):
            self._var += 1

        def increment(self):
            self._wrapped_increment()
            self._wrapped_increment()
            self._wrapped_increment()

        def get_value(self):
            return self._var

    test = Test()
    test.increment()
    assert test.get_value() == 3

    test = Test()
    test_lock = threading.Lock()

    @lock_decorator(lock=test_lock)
    def wrapped_increment(test):
        test._var += 1

    wrapped

# Generated at 2022-06-21 08:49:15.413128
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading
    import time

    class Class(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._run_state = False

        @lock_decorator(attr='_lock')
        def start(self):
            # Pretend this is a method which takes some time
            # and for which we only want to allow one call at a time
            self._run_state = True
            time.sleep(1)
            self._run_state = False

    class ClassB(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._run_state = False


# Generated at 2022-06-21 08:49:25.926009
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    calls = []
    @lock_decorator(lock=lock)
    def thread_safe(number):
        if number == 1:
            calls.append(number)
            return
        calls.append(number)
        while True:
            thread_safe(number - 1)
    t1 = threading.Thread(target=thread_safe, args=(10,))
    t2 = threading.Thread(target=thread_safe, args=(20,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    assert calls == [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10]
    lock = threading.Lock()

# Generated at 2022-06-21 08:49:33.746796
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    from threading import Thread
    from time import sleep

    class TestClass(object):
        sentinel = None
        _lock = Lock()

        @lock_decorator(attr='_lock')
        def method(self, first, second=None, third=None):
            self.sentinel = first
            sleep(1)
            self.sentinel = second
            sleep(1)
            self.sentinel = third

        @classmethod
        @lock_decorator(lock=Lock())
        def klass_method(cls, one, two=None):
            cls.sentinel = one
            sleep(1)
            cls.sentinel = two


# Generated at 2022-06-21 08:49:44.178276
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import unittest
    from types import MethodType
    from types import FunctionType

    class TestClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, msg):
            return msg

    class TestClass2(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(lock=threading.Lock())
        def send_callback(self, msg):
            return msg

    class TestClass3(object):
        def __init__(self):
            self._callback_lock = threading.Lock()


# Generated at 2022-06-21 08:49:53.576556
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread

    class TestClass():
        def __init__(self, *args, **kwargs):
            self.results = []
            self.lock = Lock()

        def add_result(self, a, b):
            with self.lock:
                self.results.append(a+b)
                self.results.append(a+a)

    tc = TestClass()
    t1 = Thread(target=tc.add_result, args=(1,2))
    t2 = Thread(target=tc.add_result, args=(3,4))

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    assert tc.results == [5,2,7,6]

# Generated at 2022-06-21 08:50:01.922176
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyClass(object):
        def __init__(self):
            self.counter = 0
            self.callback_lock = threading.Lock()

        @lock_decorator(attr='callback_lock')
        def send_callback(self):
            '''send_callback is locked'''
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            '''some_method is locked'''
            self.counter += 1

        # This method is not locked
        def not_locked(self):
            '''not_locked is not locked'''
            self.counter += 1

    import multiprocessing

    def incr(c, l, method):
        for _ in range(250):
            c.send_callback()


# Generated at 2022-06-21 08:50:09.738207
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    # Test with lock passed as argument
    @lock_decorator(lock=lock)
    def some_method(arg):
        return arg

    assert some_method(2) == 2

    # Test with lock stored in class attribute
    class LockWrapperObject(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def some_method(self, arg):
            return arg

    assert LockWrapperObject().some_method(3) == 3

# Generated at 2022-06-21 08:50:20.061515
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLock(object):

        def __init__(self):
            self.call_count = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def method_one(self):
            self.call_count += 1
            time.sleep(0.2)
            return self.call_count

        @lock_decorator(lock=threading.Lock())
        def method_two(self):
            self.call_count += 1
            time.sleep(0.2)
            return self.call_count

    test = TestLock()

    thrds = []
    for i in range(20):
        thrd = threading.Thread(target=test.method_one)
        thrd.start()
        thrds.append(thrd)


# Generated at 2022-06-21 08:50:26.673715
# Unit test for function lock_decorator
def test_lock_decorator():
    class C(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self):
            return 'method'

    self.assertEqual(C().method(), 'method')

# Generated at 2022-06-21 08:50:34.515234
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    class Class(object):
        name = 'foobar'
        _lock = Lock()
        @lock_decorator(attr='_lock')
        def test(self):
            self.name = 'baz'
            print(self.name)
    class Class2(object):
        name = 'foobar'
        @lock_decorator(lock=Lock())
        def test(self):
            self.name = 'baz'
            print(self.name)
    c = Class()
    c2 = Class2()
    c.test()
    c2.test()

if __name__ == '__main__':
    test_lock_decorator()



# Generated at 2022-06-21 08:50:46.494062
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._number = 0

        def get_number(self):
            return self._number

        @lock_decorator(attr='_lock')
        def _set_number(self, number):
            sleep(.1)
            self._number = number

        def set_number(self, number):
            t = threading.Thread(target=self._set_number, args=(number,))
            t.start()
            t.join()

    # We expect to see 1000 numbers print, in order, with the
    # lock the thread will wait until it can acquire the lock
    # before attempting to set the number, so the next thread
    # will not be able to acquire the lock

# Generated at 2022-06-21 08:50:54.827858
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    import time

    def assert_exception(func, exc_type, exc_message, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except exc_type as e:
            assert e.message == exc_message
        else:
            assert False, 'no exception raised'

    class TestClass(object):

        def __init__(self):
            self.lock = Lock()
            self.value = 0

        @lock_decorator(attr='lock')
        def test_func(self):
            # This won't raise an exception
            self.value += 1
            time.sleep(1)

        @lock_decorator(lock=Lock())
        def test_func2(self):
            # This won't raise an exception
            self.value

# Generated at 2022-06-21 08:51:02.469347
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock

    class TestClass(object):
        def __init__(self, lock=True):
            if lock:
                self._lock = Lock()
            else:
                self._lock = None

        @lock_decorator(attr='_lock')
        def test_method(self, param):
            return param

    c = TestClass()
    assert c.test_method('test') == 'test'

    c = TestClass(lock=False)
    assert c.test_method('test') == 'test'

# Generated at 2022-06-21 08:51:08.654309
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass:
        @lock_decorator(attr='_lock')
        def no_lock_method(self, log_init=True):
            if log_init:
                self.log.append('no_lock_method')
            else:
                self.log.append('no_lock_method_no_log')

    class TestClassNoLockAttr:
        @lock_decorator(attr='_missing_lock_attr')
        def no_lock_attr(self, log_init=True):
            if log_init:
                self.log.append('no_lock_attr')
            else:
                self.log.append('no_lock_attr_no_log')


# Generated at 2022-06-21 08:51:12.855711
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_using_attr(self, x):
            return x * x

        @lock_decorator(lock=threading.Lock())
        def lock_using_explicit_lock(self, x):
            return x * x

    t = Test()

    assert t.lock_using_attr(2) == 4
    assert t.lock_using_explicit_lock(3) == 9

# Generated at 2022-06-21 08:51:23.711344
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from sarge import Capture
    import time

    class TestClass(object):
        def __init__(self, *args, **kwargs):
            self._my_lock = threading.Lock()

        @lock_decorator(attr='_my_lock')
        def some_method(self, *args, **kwargs):
            out = Capture()
            out.run('python -c "import time; time.sleep(1)"')
            return kwargs

        @lock_decorator(lock=threading.Lock())
        def some_other_method(self, *args, **kwargs):
            return kwargs

    start = time.time()
    some_thread = threading.Thread(target=lambda: TestClass().some_method(foo='bar'))
    some_thread.start()

# Generated at 2022-06-21 08:51:32.673414
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class MyClass(object):
        def __init__(self):
            self._mylock = None

        @lock_decorator(attr='_mylock')
        def mymethod(self, value):
            print('{}: {}'.format(threading.current_thread().name, value))

        @lock_decorator(lock=threading.Lock())
        def myothermethod(self, value):
            print('{}: {}'.format(threading.current_thread().name, value))

    import time
    import random
    import threading
    myobject = MyClass()
    # Assign a lock object to _mylock
    myobject._mylock = threading.Lock()

    def worker():
        myobject.mymethod(myobject)
        myobject.myothermethod(myobject)

   

# Generated at 2022-06-21 08:51:44.553732
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock

    class Test:
        def __init__(self):
            self.attr = 'a'
            self.lock = Lock()

        def query_attr(self):
            return self.attr

        @lock_decorator(attr='lock')
        def set_attr(self, value=None):
            self.attr = value

        @lock_decorator(lock=Lock())
        def change_attr(self, value=None):
            self.attr = value

    t = Test()
    value = 'b'
    assert t.query_attr() == 'a'
    t.set_attr(value=value)
    assert t.query_attr() == value
    t.change_attr(value=value)
    assert t.query_attr() == value

    # Test that the lock

# Generated at 2022-06-21 08:51:58.294060
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    class Foo():
        _lock = threading.Lock()
        _data = 0
        @lock_decorator(attr='_lock')
        def increment_data(self):
            time.sleep(1)
            self._data += 1
    f = Foo()
    def f1():
        f.increment_data()
    def f2():
        f.increment_data()
    t1 = threading.Thread(target=f1)
    t2 = threading.Thread(target=f2)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    assert f._data == 2

# Generated at 2022-06-21 08:52:09.799124
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    global_list = list()

    class Foo(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self, input):
            global_list.append(1)

    class Bar(object):
        @staticmethod
        @lock_decorator(lock)
        def method(input):
            global_list.append(1)

    # instantiate Foo
    foo = Foo()

    for x in range(10):
        t = threading.Thread(target=foo.method, args=(x,))
        t.start()

    # allow threads to run
    import time
    time.sleep(0.1)
    assert len(global_list) == 1
    global_list.clear()



# Generated at 2022-06-21 08:52:20.814412
# Unit test for function lock_decorator
def test_lock_decorator():

    class Foo:

        def __init__(self):
            self.log = []
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def method(self, msg):
            self.log.append(msg)

    foo = Foo()
    foo.method('test')
    assert foo.log == ['test']

    foo = Foo()
    threads = []
    for i in range(10):
        thread = threading.Thread(target=foo.method, args=('test',))
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()
    assert foo.log == ['test'] * 10

    foo = Foo()
    threads = []

# Generated at 2022-06-21 08:52:25.836804
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestLockClass:
        def __init__(self, lock=None):
            if lock is not None:
                self._callback_lock = lock

        @lock_decorator(attr='_callback_lock')
        def test_lock_decorator_method(self):
            return True

        @lock_decorator(lock=threading.Lock())
        def test_lock_decorator_method_explicit_lock(self):
            return True

    test = TestLockClass()
    test_lock = threading.Lock()
    test_explicit_lock = TestLockClass(test_lock)

    # test the TestLockClass method that uses the instance
    # attribute ``_callback_lock`` as the lock
    assert test.test_lock_decorator_method()

    # test the Test

# Generated at 2022-06-21 08:52:37.421053
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading
    import time

    class A(object):
        '''This class has one method protected by
        the lock_decorator, ``_callback_lock``, which
        is an instance attribute.
        '''

        def __init__(self):
            '''Initialize ``A``'''
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def callback(self):
            '''This method is protected by ``_callback_lock``, which
            is expected to exist as an instance attribute of ``A``
            '''
            # Sleep for a few seconds, to ensure that another thread
            # can acquire the lock, even though we already have it.
            time.sleep(3)
            return


# Generated at 2022-06-21 08:52:47.737554
# Unit test for function lock_decorator
def test_lock_decorator():

    from queue import Queue
    from threading import Lock
    from threading import Thread

    import time

    queue = Queue()
    lock = Lock()
    sentinel = object()

    @lock_decorator(attr='l')
    def _do_with_lock1(self):
        queue.put(sentinel)
        time.sleep(1)

    @lock_decorator(lock=lock)
    def _do_with_lock2():
        queue.put(sentinel)
        time.sleep(1)

    class _LockDecoratorTest(object):
        def __init__(self):
            self.l = Lock()

        @lock_decorator(attr='l')
        def _do_with_lock3(self):
            queue.put(sentinel)

# Generated at 2022-06-21 08:52:58.413201
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class C(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def another_method(self):
            pass

        @lock_decorator(attr='_lock')
        @lock_decorator(lock=threading.Lock())
        def third_method(self):
            pass

    o = C()
    o.method()
    o.another_method()
    o.third_method()
    print('Success!')

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-21 08:53:07.880969
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Locking(object):

        def __init__(self):
            self.call = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self):
            self.call += 1
            return self.call

    def increment(lock, value):
        with lock:
            value += 1
        return value

    l = Locking()
    assert l.method() == 1
    assert l.method() == 2

    default = increment(lock=l._lock, value=0)
    assert default == 1

    @lock_decorator(lock=l._lock)
    def locking_method(value):
        return increment(lock=l._lock, value=value)

    assert locking_method(value=1) == 2

    return True

# Generated at 2022-06-21 08:53:18.608693
# Unit test for function lock_decorator
def test_lock_decorator():
    # Ensure that locks are actually working
    import threading
    import time
    import random

    class FakeModule(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.call_count = 0

        @property
        def lock_decorator(self):
            return lock_decorator

        @property
        def Lock(self):
            return self._lock

        @lock_decorator(attr='lock_attr')
        def attr_lock(self):
            time.sleep(random.randint(0, 1))

        @lock_decorator(lock=Lock)
        def explicit_lock(self):
            time.sleep(random.randint(0, 1))

    m = FakeModule()
    # Should fail without locks

# Generated at 2022-06-21 08:53:25.201718
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading
    import time

    class Test:
        def __init__(self):
            self._lock = None

        def set_lock(self, lock):
            self._lock = lock

        @lock_decorator(attr='_lock')
        def locked_method(self, sleep_time):
            time.sleep(sleep_time)
            print('lock acquired, sleeping for %d seconds' % sleep_time)

    t = Test()
    t.set_lock(threading.Lock())

    for i in range(10):
        t.locked_method(1)

# Generated at 2022-06-21 08:53:45.658453
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class SomeClass(object):
        def __init__(self):
            self.callback_lock = threading.Lock()
            self.queue = []

        @lock_decorator(attr='callback_lock')
        def __callback_lock(self, value):
            self.queue.append(value)
            time.sleep(random.random())
            return True

        def send_callback(self, value):
            return self.__callback_lock(value=value)

    some_class = SomeClass()

    threads = []
    num_threads = 10
    num_messages = 100

    def run(some_class, value):
        return some_class.send_callback(value)

    for i in range(num_threads):
        t = threading.Thread

# Generated at 2022-06-21 08:53:54.434167
# Unit test for function lock_decorator
def test_lock_decorator():
    import time
    import threading

    class SomeClass(object):
        '''Test class to use with lock decorator'''
        def __init__(self, *args, **kwargs):
            self._attr = threading.Lock()

            self._global_lock = threading.Lock()

        @lock_decorator(attr='_attr')
        def some_method_with_attr(self):
            '''This method uses a Lock stored as an attribute of the class'''
            print('{:20} before'.format(self.some_method_with_attr.__name__))
            time.sleep(2)
            print('{:20} after'.format(self.some_method_with_attr.__name__))


# Generated at 2022-06-21 08:54:04.139902
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self.x = None
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def set_x(self, y, z=3):
            self.x = y + z

        @lock_decorator(lock=threading.Lock())
        def print_x(self):
            print(self.x)

    f = Foo()
    for i in range(5):
        f.set_x(i)

    for i in range(5):
        f.print_x()

# Generated at 2022-06-21 08:54:11.089799
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock_called = threading.Event()
    acquire_called = threading.Event()
    release_called = threading.Event()
    mock_lock = _MockLock(lock_called, acquire_called, release_called)

    class MyObject(object):
        def __init__(self):
            self._lock = mock_lock

        @lock_decorator(attr='_lock')
        def method(self):
            pass

    MyObject().method()

    assert lock_called.is_set()
    assert acquire_called.is_set()
    assert release_called.is_set()



# Generated at 2022-06-21 08:54:22.159147
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class SomeObj(object):
        def __init__(self):
            self.lock = lock
            self.value = 0

        @lock_decorator(attr='lock')
        def increase_value(self, value):
            self.value += value

    obj = SomeObj()
    # value should be 0
    assert obj.value == 0
    # change value to 4
    obj.increase_value(4)
    # value should be 4
    assert obj.value == 4

    obj2 = SomeObj()
    # value should be 0
    assert obj2.value == 0
    # change value to 8
    obj2.increase_value(8)
    # value should be 8
    assert obj2.value == 8

    # value should be 12 (from all

# Generated at 2022-06-21 08:54:31.448655
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import random
    import time

    class Foo(object):
        def __init__(self, sleep_time=0.01):
            self._lock = threading.Lock()
            self.val = 0
            self.sleep_time = sleep_time

        @lock_decorator(attr='_lock')
        def increment(self):
            time.sleep(random.randint(1, 100) / 1000.0)
            self.val += 1

        @lock_decorator(attr='_lock')
        def decrement(self):
            time.sleep(random.randint(1, 100) / 1000.0)
            self.val -= 1

    foo = Foo()

    threads = []

# Generated at 2022-06-21 08:54:41.661261
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    true_lock = threading.Lock()

    assert lock is not true_lock

    @lock_decorator(lock=lock)
    def do_nothing(lock):
        assert lock is not true_lock
        return True

    @lock_decorator(attr='lock')
    def also_do_nothing(self):
        assert self.lock is not true_lock
        return True

    class LockTest:

        lock = lock

        def __init__(self):
            self.do_nothing_result = False
            self.also_do_nothing_result = False

        @lock_decorator(attr='lock')
        def set_do_nothing(self):
            self.do_nothing_result = do_nothing(true_lock)


# Generated at 2022-06-21 08:54:51.848881
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    attr = '_lock'
    counter = 0
    def incr(self):
        global counter
        counter += 1

    def test_counter():
        from time import sleep
        from threading import Thread
        threads = []
        for i in range(10):
            t = Thread(target=incr, args=(self,))
            threads.append(t)
            t.start()
        for t in threads:
            t.join()
        sleep(0.1)

    class Test(object):
        def __init__(self, lock, attr):
            self.__dict__[attr] = lock

        @lock_decorator(attr=attr)
        def dec1(self):
            test_counter()
            assert counter == 1


# Generated at 2022-06-21 08:54:58.321966
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def nonlocal_lock():
        # nonlocal lock
        assert lock.acquire(blocking=False) == False
        lock.release()

    class TestClass(object):
        def __init__(self):
            self.attr_lock = threading.Lock()

        @lock_decorator(attr='attr_lock')
        def self_lock(self):
            # self.attr_lock
            assert self.attr_lock.acquire(blocking=False) == False
            self.attr_lock.release()

    test = TestClass()
    nonlocal_lock()
    test.self_lock()

# Generated at 2022-06-21 08:55:06.957250
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Test a pre-defined lock
    class TestClass:
        _lock = threading.Lock()
        _value = None

        @lock_decorator(attr='_lock')
        def set_value(self, value):
            self._value = value

        @lock_decorator(attr='_lock')
        def get_value(self):
            return self._value

    # Create the test class instance
    test = TestClass()

    # Our lock should start off clean
    assert test._lock.acquire(blocking=False)

    # We should have no value yet
    assert test.get_value() is None

    # Set the value
    test.set_value(True)

    # We should now have a value
    assert test.get_value() is True

    # Our lock should be locked because

# Generated at 2022-06-21 08:55:33.573155
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    from time import sleep
    from collections import defaultdict

    class fake_self:
        def __init__(self):
            self.test_lock = Lock()
            self.test_attr = defaultdict(int)

        @lock_decorator(attr='test_lock')
        def test_func(self, key):
            self.test_attr[key] += 1
            sleep(0.1)
            return self.test_attr[key]

    class fake_func:
        test_lock = Lock()
        test_attr = defaultdict(int)

        # This decorator allows you to pass an explicit lock object
        @lock_decorator(lock=test_lock)
        def test_func(self, key):
            self.test_attr[key] += 1