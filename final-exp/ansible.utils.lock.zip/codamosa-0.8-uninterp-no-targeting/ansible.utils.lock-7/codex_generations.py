

# Generated at 2022-06-21 08:45:43.549261
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestClass(object):
        def __init__(self):
            self.lock = lock_decorator
            self.test_lock = None

        @lock_decorator(attr='test_lock')
        def test1(self):
            return

        @lock_decorator()
        def test2(self):
            return

    test = TestClass()

    # Raise ``AttributeError`` if missing ``attr``
    try:
        test.test2()
    except AttributeError:
        pass
    else:
        raise AssertionError('Expected ``AttributeError``, got ``None``')

    # Raise ``AttributeError`` if missing ``lock``
    try:
        test.test1()
    except AttributeError:
        pass

# Generated at 2022-06-21 08:45:53.236301
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    # Default attribute
    @lock_decorator()
    def missing_attr(self):
        pass

    with mock.patch.object(missing_attr, 'missing_lock_attr') as mock_lock:
        # Mock context manager
        mock_lock.__enter__.return_value = None
        mock_lock.__exit__.return_value = None

        class TestMissingAttrLock(object):
            def __init__(self):
                self.got_lock = False

            @missing_attr
            def do_work(self):
                self.got_lock = True

        t = TestMissingAttrLock()
        t.do_work()

        try:
            assert t.got_lock
        except AssertionError:
            raise AssertionError('Failed to get lock')


# Generated at 2022-06-21 08:46:03.151531
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    def example(self):
        self.value = True
    def example_cls(cls):
        cls.cls_value = True
    # First, we'll define a standard method
    class A(object):
        @lock_decorator()
        def test_missing_lock_attr(self):
            assert getattr(self, 'value', False) is False
            assert getattr(self, 'cls_value', False) is False
            example(self)
            example_cls(self.__class__)
            assert getattr(self, 'value', False) is True
            assert getattr(self, 'cls_value', False) is True
    a = A()
    assert getattr(a, 'value', False) is False

# Generated at 2022-06-21 08:46:14.725202
# Unit test for function lock_decorator
def test_lock_decorator():
    class Test:
        def __init__(self):
            self.lock = threading.Lock()
            self.lock_attr = threading.Lock()
            self.lock_passed = threading.Lock()

        @lock_decorator()
        def test_lock_attr(self):
            return self.lock_attr

        @lock_decorator(attr='lock')
        def test_lock_attr_specified(self):
            return self.lock

        @lock_decorator(lock=self.lock_passed)
        def test_lock_passed(self):
            return self.lock_passed

    t = Test()
    assert t.test_lock_attr() is t.lock_attr
    assert t.test_lock_attr_specified() is t.lock
    assert t.test_lock_

# Generated at 2022-06-21 08:46:23.684109
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading, time

    class Test(object):

        def __init__(self, verbose=None):
            self.lock = threading.Lock()
            self.verbose = verbose
            self.val = ''

        @lock_decorator(attr='lock')
        def lock_test(self, value):
            if self.verbose:
                print('{0}'.format(value))
            # Sleep for a short period to simulate API delays
            time.sleep(.25)
            self.val = value

        @lock_decorator(lock=threading.Lock())
        def lock_test_lock(self, value):
            if self.verbose:
                print('{0}'.format(value))
            # Sleep for a short period to simulate API delays
            time.sleep(.25)
            self

# Generated at 2022-06-21 08:46:33.184024
# Unit test for function lock_decorator
def test_lock_decorator():
    import time

    class FakeLock:
        def __init__(self):
            self.counter = 0

        def __enter__(self):
            self.counter += 1

        def __exit__(self, *args):
            self.counter -= 1

        def acquired(self):
            return self.counter > 0

    lock = FakeLock()
    class Foo(object):
        def __init__(self):
            self.counter = 0

        @lock_decorator(attr='missing_lock_attr')
        def _unprotected_method(self):
            self.counter += 1
            time.sleep(0.1)
            self.counter -= 1

        @lock_decorator(attr='_lock')
        def _protected_method(self):
            self.counter += 1
            time.sleep(0.1)


# Generated at 2022-06-21 08:46:45.516666
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test the lock decorator'''

    import threading

    class MyClass:

        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def method_lock_attr(self, arg1, arg2):
            '''This method uses a decorated lock from ``attr``'''
            return '%s:%s' % (arg1, arg2)

        @lock_decorator(lock=threading.Lock())
        def method_lock_arg(self, arg1, arg2):
            '''This method uses a lock passed via ``lock``'''
            return '%s:%s' % (arg1, arg2)


    # Test the method_lock_attr method
    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1.method_

# Generated at 2022-06-21 08:46:55.219670
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Foo(object):
        def __init__(self):
            self.value = 1
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def set_value(self, value):
            self.value = value

    class Bar(object):
        def __init__(self):
            self.value = 1

        @lock_decorator(lock=threading.Lock())
        def set_value(self, value):
            self.value = value

    # Set up class instance, ``foo``
    foo = Foo()

    # Set up class instance,  ``bar``
    bar = Bar()

    # Set up threads, which use ``set_value``

# Generated at 2022-06-21 08:47:06.674039
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self.foo = 0
            self.bar = None
            self.baz = None
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method_lock_attr(self):
            self.foo += 1
            self.bar = 'test_lock_attr'

        @classmethod
        @lock_decorator(attr='_lock')
        def class_lock_attr(cls):
            cls.foo += 1
            cls.bar = 'test_lock_attr'

        @staticmethod
        @lock_decorator(attr='_lock')
        def static_lock_attr(foo):
            foo += 1
            bar = 'test_lock_attr'


# Generated at 2022-06-21 08:47:17.153867
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    _lock = threading.Lock()
    _attr_lock = threading.Lock()

    class TestClass(object):
        def _setup_lock(self):
            self._lock = _lock

        def _setup_attr_lock(self):
            self._attr_lock = _attr_lock

        @lock_decorator(attr='_attr_lock')
        def lock_attr(self):
            self.x += 1

        @lock_decorator(lock=_lock)
        def lock(self):
            self.y += 1

    from copy import copy

    # Create three copies of TestClass.  One with no lock, one with the lock
    # specified as an attribute, and one with the lock passed explicitly.
    test1 = copy(TestClass())
    test1._setup_lock()

   

# Generated at 2022-06-21 08:47:28.308526
# Unit test for function lock_decorator
def test_lock_decorator():
    class SomeClass:
        def __init__(self):
            self._callback_lock = None

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            pass

    # Make sure that ``attr`` is required
    try:
        @lock_decorator()
        def send_callback(self):
            pass
        raise AssertionError('Expected exception')
    except TypeError:
        pass

    # Make sure that the function runs, and doesn't crash
    SomeClass().send_callback()

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-21 08:47:35.082686
# Unit test for function lock_decorator
def test_lock_decorator():

    # Imports for unit test
    import os
    import tempfile
    import threading
    import time

    tmp_file = tempfile.mkstemp()[1]

    # Function to be passed below
    @lock_decorator(attr='my_lock')
    def append_to_file(self, text):
        with open(tmp_file, 'a') as f:
            f.write(text + '\n')

    # Class used to test lock_decorator
    class MyClass:
        def __init__(self):
            self.my_lock = threading.Lock()

    # Run a bunch of threads, they should block on my_lock
    # and should print the numbers in order
    class MyThread(threading.Thread):
        def __init__(self, my_class, text):
            thread

# Generated at 2022-06-21 08:47:44.007639
# Unit test for function lock_decorator
def test_lock_decorator():
    from six.moves import range
    import threading

    class SomeClass(object):
        def __init__(self):
            self.x = 0
            self.state = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def some_method_with_attr(self):
            self.state = 1
            self.x += 1
            self.state = 2
            self.x += 1
            self.state = 3
            self.x += 1
            self.state = 4

        @lock_decorator(lock=threading.Lock())
        def some_method_with_lock(self):
            self.state = 1
            self.x += 1
            self.state = 2
            self.x += 1
            self.state = 3
            self.x

# Generated at 2022-06-21 08:47:55.353303
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Thread

    class TestClass(object):

        def __init__(self):
            self.lock = threading.Lock()
            self.flag = 0

        def __wrap_me(self, _, b):
            assert b, 'b is not truthy'
            with self.lock:
                self.flag += 1

        @lock_decorator(lock=self.lock)
        def wrap_me(self, a, b):
            self.__wrap_me(a, b)

        @lock_decorator(attr='lock')
        def wrap_me_by_attr(self, a, b):
            self.__wrap_me(a, b)

    t = TestClass()


# Generated at 2022-06-21 08:48:07.498833
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class A(object):
        def __init__(self):
            self.value = 0

        @lock_decorator(attr='_lock', lock=lock)
        def set_value(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other
    a = A()
    a.set_value(1)
    assert a == 1
    a.set_value(2)
    assert a == 2

    # Using classmethod
    class B(object):
        value = 0

        @classmethod
        @lock_decorator(attr='_lock', lock=lock)
        def set_value(cls, value):
            cls.value = value


# Generated at 2022-06-21 08:48:18.654582
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestLockDecorator(unittest.TestCase):

        def setUp(self):
            self.result = []
            self.lock = threading.Lock()

        def locked_method(self):
            self.result.append(1)

        def locked_method_again(self):
            self.result.append(2)

        def test_lock_attr_lock(self):
            @lock_decorator(attr='lock')
            def wrap_locked_method(self):
                self.locked_method()

            wrap_locked_method(self)
            self.assertTrue(isinstance(wrap_locked_method, threading.Lock))
            self.assertEqual(self.result, [1])


# Generated at 2022-06-21 08:48:28.997508
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):

        def __init__(self):
            self._lock = threading.Lock()
            self._unlocked = True
            self._lock._locked = False
            self._lock_count = 0

        def __enter__(self):
            self._unlocked = self._lock._release()
            self._lock_count += 1
            return self

        def __exit__(self, exc_type, exc_value, exc_tb):
            if not self._unlocked:
                self._lock._acquire()
            self._lock_count -= 1

        def locked(self):
            return self._lock._is_owned()

        def count(self):
            return self._lock_count

    class TestClass(object):

        _lock = threading.Lock()


# Generated at 2022-06-21 08:48:40.025560
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Thread
    from time import sleep, time
    from random import randint

    # Create a class for testing

    class Countdown:
        '''A simple class for illustrating a unit test
        for `lock_decorator`
        '''

        def __init__(self, seconds=None):
            self.seconds = seconds
            self.start_time = None
            self.stop_time = None
            self.elapsed = None
            self.finished = False
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def start(self):
            self.start_time = time()

        @lock_decorator(attr='_lock')
        def stop(self):
            self.stop_time = time()
            self.elapsed = self

# Generated at 2022-06-21 08:48:50.151777
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import sys

    # This decorator relies on the first parameter of the
    # decorated function being 'self' ... in this case it
    # is an instance of DummyClass
    @lock_decorator(attr='_lock')
    def test(self):
        print("\tExecuting %s" % (self._name,))
        self._execute()

    class DummyClass(object):
        def __init__(self, name):
            self._name = name
            self._lock = threading.Lock()
            self._execute()

        @lock_decorator(attr='_lock')
        def _execute(self):
            print("\t\tThis is %s executing" % (self._name,))


# Generated at 2022-06-21 08:49:00.232738
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    import threading

    class DemoClass(object):
        def __init__(self):
            self._lock = Lock()
            self._data_lock = Lock()
            self._data = 0

        @lock_decorator(attr='_lock')
        def method_a(self):
            threading.current_thread().name = 'method_a'
            self.method_b()

        @lock_decorator(attr='_lock')
        def method_b(self):
            threading.current_thread().name = 'method_b'
            threading.current_thread().name = 'method_b'

        @lock_decorator(lock=Lock())
        def method_c(self):
            threading.current_thread().name = 'method_c'
            self.method_

# Generated at 2022-06-21 08:49:16.049687
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    import threading

    class RealEstateAgent(object):
        def __init__(self):
            self.houses_sold = 0
            self.lock = threading.Lock()

        @lock_decorator(lock=self.lock)
        def sold_house(self):
            self.houses_sold += 1
            return self.houses_sold

    class RealEstateAgency(object):
        def __init__(self):
            self.houses_sold = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def sold_house(self):
            self.houses_sold += 1
            return self.houses_sold

    class RealEstateBroker(object):
        def __init__(self):
            self.houses_sold = 0
           

# Generated at 2022-06-21 08:49:27.536255
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        lock_attr = None

        def __init__(self):
            self.lock_attr = threading.Lock()

        @lock_decorator(attr='lock_attr')
        def attr_dec(self, sleep_time=0.05):
            from time import sleep
            sleep(sleep_time)
            return True

    class Bar(object):
        lock_arg = None

        def __init__(self):
            self.lock_arg = threading.Lock()

        @lock_decorator(lock=lock_arg)
        def arg_dec(self, sleep_time=0.05):
            from time import sleep
            sleep(sleep_time)
            return True

    foo = Foo()
    bar = Bar()

    import timeit

# Generated at 2022-06-21 08:49:35.554685
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    global __test_lock_decorator_lock__
    global __test_lock_decorator_lock_arg__
    global __test_lock_decorator_attr__
    global __test_lock_decorator_attr_arg__

    e = threading.Event()
    L = threading.Lock()

    @lock_decorator(attr='__test_lock_decorator_attr__')
    def func_attr(arg, marker):
        assert arg == 'foo'
        assert marker == 'bar'
        e.set()

    @lock_decorator(lock=L)
    def func_lock(arg, marker):
        assert arg == 'foo'
        assert marker == 'bar'
        e.set()


# Generated at 2022-06-21 08:49:45.012370
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import pytest

    class Foo(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.val = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            time.sleep(0.5)
            self.val += 1

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            self.val += 1

    def test_send_callback(foo):
        foo.send_callback()

    def test_some_method(foo):
        foo.some_method()

    f = Foo()
    assert f.val == 0
    t1 = threading.Thread(target=test_send_callback, args=(f,))


# Generated at 2022-06-21 08:49:55.322702
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading
    from ansible.module_utils.helpers import lock_decorator

    @lock_decorator(attr='_lock')
    def func_with_lock_decorator(self, msg):
        return msg

    class LockerClass(object):
        def __init__(self):
            self._lock = None

        @lock_decorator(attr='_lock')
        def func_with_lock_decorator(self, msg):
            return msg

    @lock_decorator(lock=threading.Lock())
    def func_with_lock_decorator_lock(msg):
        return msg

    # test case: decorator with lock attribute missing

# Generated at 2022-06-21 08:50:05.165786
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Thing(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._shared_resource = 0

        @lock_decorator(attr='_lock')
        def locked_method(self):
            self._shared_resource += 1

    thing = Thing()

    def call_locked_method():
        for i in range(1000):
            thing.locked_method()

    threads = [threading.Thread(target=call_locked_method)
               for _ in range(10)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert thing._shared_resource == 10000

# Generated at 2022-06-21 08:50:11.691332
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class A(object):
        _lock = lock

        @lock_decorator(attr='_lock')
        def a(self, *args, **kwargs):
            return args, kwargs

    assert A().a(1, 2, 3) == ((1, 2, 3), {})

    class B(object):
        lock = lock
        @lock_decorator(lock=lock)
        def b(self, *args, **kwargs):
            return args, kwargs

    assert B().b(1, 2, 3) == ((1, 2, 3), {})

# Generated at 2022-06-21 08:50:21.383024
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class SomeClass(object):
        _lock = threading.Lock()
        _some_lock_attr = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self):
            return True

        @lock_decorator(attr='_some_lock_attr')
        def some_other_method(self):
            return True

        @lock_decorator(lock=threading.Lock())
        def some_other_method2(self):
            return True


    class SomeOtherClass(SomeClass):
        @lock_decorator(attr='_lock')
        def some_other_method_on_child(self):
            return True


    cls = SomeClass()
    assert cls.some_method()
    assert cls.some_

# Generated at 2022-06-21 08:50:30.677291
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        raise SkipTest('threading required for this test')

    class Foo(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            return True

        @lock_decorator(lock=self._lock)
        def some_method(self, *args, **kwargs):
            return True

    obj = Foo()

    obj.send_callback()
    obj.some_method()

# Generated at 2022-06-21 08:50:37.360146
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # show that it can use instance attributes
    class LockDecoratorTest(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def do_something(self):
            print('  Called do_something')

    ldt = LockDecoratorTest()
    ldt.do_something()

    # show that it can take a lock arg
    @lock_decorator(lock=threading.Lock())
    def do_something_else():
        print('  Called do_something_else')

    do_something_else()


# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from functools import wraps



# Generated at 2022-06-21 08:50:48.603934
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def _test(s):
        return '%s testing' % s
    assert _test('Lock') == 'Lock testing'
    assert not lock.locked()

# Generated at 2022-06-21 08:50:54.610367
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        lock = threading.Lock()

        @lock_decorator(attr='lock')
        def test_method(self, a, b):
            return a, b

        @lock_decorator(lock=threading.Lock())
        def test_method2(self, a, b):
            return a, b

    result = TestClass().test_method(1, 2)
    assert result == (1, 2)

    result = TestClass().test_method2(3, 4)
    assert result == (3, 4)

# Generated at 2022-06-21 08:51:04.939448
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestDecorator:
        result = []

        def run_it(self):
            threading.Thread(target=self.append_number).start()
            threading.Thread(target=self.append_number).start()
            threading.Thread(target=self.append_number).start()
            threading.Thread(target=self.append_number).start()
            threading.Thread(target=self.append_number).start()
            time.sleep(1)

        @lock_decorator()
        def append_number(self):
            for i in range(100):
                time.sleep(1.0 / 10000)
                self.result.append(i)

    t = TestDecorator()
    t.run_it()

# Generated at 2022-06-21 08:51:14.733773
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    global_lock = threading.Lock()

    class Example():
        def __init__(self, global_lock):
            self._lock = global_lock
            self.count = 0

        @lock_decorator(lock=global_lock)
        def func_a(self):
            self.count += 1

        @lock_decorator(attr='_lock')
        def func_b(self):
            self.count += 1

    e = Example(lock=global_lock)

    for _ in range(10):
        e.func_a()
        e.func_b()

    assert e.count == 20

# Generated at 2022-06-21 08:51:26.324793
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread
    import time

    class MyClass(object):
        def __init__(self, sleep_time=1):
            self._callback_lock = Lock()
            self.called = False
            self.sleep_time = sleep_time

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            time.sleep(self.sleep_time)
            self.called = True

        @lock_decorator(lock=Lock())
        def some_method(self):
            time.sleep(self.sleep_time)
            self.called = True

    my_obj = MyClass()

    send_callback_thread = Thread(target=my_obj.send_callback)
    send_callback_thread.start()
    time.sleep(0.1)
   

# Generated at 2022-06-21 08:51:34.145570
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import sys
    import tempfile
    import threading
    import unittest

    class LockTest(unittest.TestCase):
        def test_explicit_lock(self):
            lock = threading.Lock()
            @lock_decorator(lock=lock)
            def some_method():
                tmpfile = tempfile.mkstemp()
                os.close(tmpfile[0])
                self.addCleanup(os.remove, tmpfile[1])
                with open(tmpfile[1], 'w') as f:
                    f.write('test')
                    f.flush()
                with open(tmpfile[1]) as f:
                    self.assertEqual(f.read(), 'test')
            threads = []

# Generated at 2022-06-21 08:51:44.799760
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self._test_lock = threading.Lock()
            self.count = 0

        def _add(self):
            self.count += 1

        @lock_decorator(attr='_test_lock')
        def add(self):
            self._add()

    t = Test()
    t.add()
    assert t.count == 1
    t.add()
    assert t.count == 2

    t.count = 0
    @lock_decorator(lock=threading.Lock())
    def add(self):
        self._add()

    t.add()
    assert t.count == 1
    t.add()
    assert t.count == 2

# Generated at 2022-06-21 08:51:57.065680
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for lock_decorator
    '''
    import unittest
    import threading

    class TestClass(object):
        '''Class to hold unit test for lock_decorator
        '''
        @lock_decorator(lock=threading.Lock())
        def lock_func_with_lock(self):
            '''lock_decorator with pre-defined lock object
            '''
            self.message = 'success'

        @lock_decorator(attr='lock_attr')
        def lock_func(self):
            '''lock_decorator with instance attribute for lock object
            '''
            self.message = 'success'

    class TestCase(unittest.TestCase):
        '''Unit tests for lock_decorator
        '''

# Generated at 2022-06-21 08:52:08.783003
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    def test_decorator(func):
        @wraps(func)
        def inner(*args, **kwargs):
            # Python2 doesn't have ``nonlocal``
            # assign the actual lock to ``_lock``
            if lock is None:
                _lock = getattr(args[0], attr)
            else:
                _lock = lock
            with _lock:
                return func(*args, **kwargs)
        return inner
    lock_decorator.test_decorator = test_decorator

    from ansible.module_utils.six import add_metaclass
    class TestClass(object):

        # This is the 'attr' option
        _lock = threading.Lock()


# Generated at 2022-06-21 08:52:15.533863
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    test = 'hi'

    def test_function(param):
        nonlocal test
        if test == 'hi':
            test = param

    class Test(object):
        _class_lock = threading.Lock()

        @lock_decorator(attr='_class_lock')
        def test_class_attr(self, param):
            nonlocal test
            if test == 'hi':
                test = param

        @lock_decorator(lock=lock)
        def test_lock(self, param):
            nonlocal test
            if test == 'hi':
                test = param

    t = Test()

    import multiprocessing
    pool = multiprocessing.Pool()
    pool.apply(test_function, ('abc',))


# Generated at 2022-06-21 08:52:42.145711
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # Use the same lock for all tests
    lock = threading.Lock()

    class TestClass(object):
        def __init__(self):
            self.a = 1

        # Apply lock with 'attr', must be named _lock
        @lock_decorator(attr='_lock')
        def run_test_attr(self):
            self.a += 1
            time.sleep(1)
            self.a *= 2

        # Apply lock with an explicit 'lock'
        @lock_decorator(lock=lock)
        def run_test_lock(self):
            self.a += 1
            time.sleep(1)
            self.a *= 2

    # Test that the class can be instantiated
    t = TestClass()
    assert t.a == 1

   

# Generated at 2022-06-21 08:52:51.015474
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading, time

    lock = threading.Lock()
    counter = 0

    @lock_decorator(lock=lock)
    def method(counter, time_to_sleep=None):
        if time_to_sleep is not None:
            time.sleep(time_to_sleep)
        counter += 1

    class Test(object):
        def __init__(self, counter):
            self.counter = counter

        @lock_decorator(attr='lock')
        def method(self, time_to_sleep=None):
            if time_to_sleep is not None:
                time.sleep(time_to_sleep)
            self.counter += 1

    test = Test(counter=0)
    # Create the lock and assign it to an instance attribute
    test.lock = lock


# Generated at 2022-06-21 08:53:02.804233
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        """
        We're just testing the decorator, so we don't need to
        do too much work here.
        """
        def __init__(self):
            self._lock = threading.RLock()

        def __repr__(self):
            return 'TestClass()'

        @lock_decorator(attr='_lock')
        def method(self, *_):
            return threading.current_thread().name

    class TestClass2(object):
        """
        We're just testing the decorator, so we don't need to
        do too much work here.
        """
        def __init__(self):
            self._lock = threading.RLock()

        def __repr__(self):
            return 'TestClass2()'


# Generated at 2022-06-21 08:53:10.837199
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    flag = True
    _flag = True
    @lock_decorator(lock=lock)
    def set_flag_true():
        global flag
        flag = True
    @lock_decorator(attr='_lock')
    def set_other_flag_true(self):
        global _flag
        _flag = True
    set_flag_true()
    set_other_flag_true(object())
    assert flag is True
    assert _flag is True



# Generated at 2022-06-21 08:53:21.432076
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class HasLock():
        # Initialize a lock in the class and initialize it as an instance attribute too
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self):
            # Dummy method to test that lock_decorator works
            pass

    class HasLockAsArgument():

        @lock_decorator(lock=threading.Lock())
        def method(self):
            pass

    class HasNoLock():

        @lock_decorator()
        def method(self):
            pass

    # We must check that this code can run.  If there is a syntax error,
    # the unit test will take an inordinate amount of time to run.

# Generated at 2022-06-21 08:53:33.436047
# Unit test for function lock_decorator
def test_lock_decorator():
    class SampleClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0
            self.counter_buffered = 0

        @lock_decorator(attr='_lock')
        def add_counter(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def add_counter_buffered(self):
            self.counter_buffered += 1

    sample_class = SampleClass()

    # Start a thread to call add_counter_buffered
    def start_thread():
        for i in range(0, 20):
            sample_class.add_counter_buffered()

    t = threading.Thread(target=start_thread)
    t.start()

    # Call add_counter multiple times

# Generated at 2022-06-21 08:53:45.755993
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep

    class Foo(object):

        def __init__(self):
            self._method_lock = threading.Lock()
            self._class_lock = threading.Lock()
            self.run = True

        @lock_decorator(attr='_method_lock')
        def method(self, name):
            while self.run:
                print('%s running' % name)
                sleep(0.1)

        @classmethod
        @lock_decorator(attr='_class_lock')
        def classmethod(cls, name):
            while cls.run:
                print('%s running' % name)
                sleep(0.1)


# Generated at 2022-06-21 08:53:54.434758
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    def test_lock_decorator_with_lock(lock):
        class A():
            def __init__(self):
                self.test_attr = 0
            @lock_decorator(lock=lock)
            def func(self):
                self.test_attr = 1
        a = A()
        assert a.test_attr == 0
        a.func()
        assert a.test_attr == 1

    test_lock_decorator_with_lock(threading.Lock())
    test_lock_decorator_with_lock(threading.RLock())
    test_lock_decorator_with_lock(threading.Semaphore())

    def test_lock_decorator_with_attr(lock):
        class A():
            def __init__(self):
                self

# Generated at 2022-06-21 08:53:56.853322
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock_decorator(attr='_lock')
    lock_decorator(lock=threading.Lock())

# Generated at 2022-06-21 08:54:08.538203
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._num = 0

        @lock_decorator(attr='_lock')
        def protected_method(self):
            self._num += 1

    class NoAttrTest(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._num = 0

        @lock_decorator(lock=self._lock)
        def protected_method(self):
            self._num += 1

    def simple_test(t):
        t.protected_method()
        assert t._num == 1

    test = Test()
    noattr = NoAttrTest()

    simple_test(test)
    simple_test(noattr)

    import multipro

# Generated at 2022-06-21 08:54:53.414137
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import sys
    if sys.version_info < (3, 0):
        import Queue as queue
    else:
        import queue

    lock = threading.Lock()
    lock_attr = '_callback_lock'
    q = queue.Queue()

    class C(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr=lock_attr)
        def send_callback(self, x):
            q.put(x)

        @lock_decorator(lock=lock)
        def send_callback2(self, x):
            q.put(x)

    c = C()
    c.send_callback(10)
    assert q.get() == 10

    c.send_callback2(20)


# Generated at 2022-06-21 08:55:02.708210
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class myobj(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0
            self._lock_counter = 0

        @lock_decorator(attr='_lock')
        def myobj_method(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def myobj_method_lock(self):
            self._lock_counter += 1

    assert hasattr(myobj.myobj_method, '__wrapped__')
    assert hasattr(myobj.myobj_method_lock, '__wrapped__')

    myobj_inst = myobj()
    myobj_inst.myobj_method()
    assert myobj_inst.counter == 1

    myobj_inst.my

# Generated at 2022-06-21 08:55:13.955915
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Unit test for function lock_decorator
    '''
    import threading
    from threading import Lock

    class Foo(object):
        '''
        Implements a class for use in testing lock_decorator
        '''

        def __init__(self):
            self._lock = Lock()

        @lock_decorator(attr='_lock')
        def foo(self):
            '''
            Implements a method for testing lock_decorator
            '''
            return 0

    class Bar(object):
        '''
        Implements a class for use in testing lock_decorator
        '''
        @lock_decorator(lock=Lock())
        def bar(self):
            '''
            Implements a method for testing lock_decorator
            '''


# Generated at 2022-06-21 08:55:24.537732
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):
        _callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def cb_call(self, name):
            print("Start: {0}".format(name))
            time.sleep(0.1)
            print("End: {0}".format(name))

    t = Test()

    th = []
    for i in range(10):
        th.append(threading.Thread(target=t.cb_call, args=('thread-{0}'.format(i),)))

    for t in th:
        t.start()

    for t in th:
        t.join()

# Generated at 2022-06-21 08:55:32.509342
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Thing:
        def __init__(self):
            self.n = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def thing(self):
            self.n += 1
            time.sleep(1)
            print(self.n)

    t = Thing()
    def go():
        for i in range(10):
            t.thing()

    for i in range(5):
        threading.Thread(target=go).start()

    time.sleep(10)