

# Generated at 2022-06-11 18:21:06.034933
# Unit test for function lock_decorator
def test_lock_decorator():

    class Test:
        def __init__(self, value, lock=None):
            self.value = value
            self.lock = lock

        @lock_decorator(attr='lock')
        def modify(self, other):
            # Pretend there's something here that takes a while
            return self.value + other

    class TestNoAttr:
        def __init__(self, value):
            self.value = value

        @lock_decorator(lock=Test.lock)
        def modify(self, other):
            # Pretend there's something here that takes a while
            return self.value + other


    test_obj = Test(value=1)
    test_noattr_obj = TestNoAttr(value=1) # No lock passed in

# Generated at 2022-06-11 18:21:15.917429
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    sample_lock = threading.Lock()
    sample_value = 0


    class Sample(object):
        _sample_lock = sample_lock

        @lock_decorator(attr='_sample_lock')
        def method(self):
            global sample_value
            sample_value += 1

    def concurrent():
        sample = Sample()
        for i in range(10):
            sample.method()

    threads = []
    for i in range(10):
        threads.append(threading.Thread(target=concurrent))

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    assert sample_value == 100

# Generated at 2022-06-11 18:21:22.764846
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import inspect
    import random

    class A(object):
        @lock_decorator(lock=threading.Lock())
        def f(self, n):
            n = n + 1
            return n

    class B(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def f(self, n):
            n = n + 1
            return n

    a = A()
    b = B()


    def locktest(func, args, kwargs, expected_result, attrs):
        result = func(*args, **kwargs)

# Generated at 2022-06-11 18:21:33.434611
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    try:
        import thread
    except ImportError:
        import _thread as thread

    class Counter(object):
        def __init__(self):
            self._counter = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def increment(self):
            self._counter += 1

        @lock_decorator(attr='_lock')
        def decrement(self):
            self._counter -= 1

        @lock_decorator(lock=threading.Lock())
        def add_and_subtract(self, a, b):
            self._counter += a
            self._counter -= b

        def get_counter(self):
            return self._counter

    c = Counter()

# Generated at 2022-06-11 18:21:45.065205
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        return
    import time

    class TestLock(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def _inc_counter(self):
            self.counter += 1
            time.sleep(5)

        def inc_counter(self):
            self._inc_counter()

    testLock = TestLock()
    testLock.inc_counter()
    assert testLock.counter == 1

    testLock._lock.acquire()
    t = threading.Thread(target=testLock.inc_counter)
    t.start()
    time.sleep(1)
    assert testLock.counter == 1

    testLock._lock.release()


# Generated at 2022-06-11 18:21:54.108863
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import unittest

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def _send_callback(self, callback):
            callback()

        @lock_decorator(lock=threading.Lock())
        def _send_callback2(self, callback):
            callback()

        def _callback(self, *args):
            if len(args) == 0:
                args = (True, 'foo')
            return sum(args)

        def test_lock_decorator(self):
            self.assertEqual(self._send_callback(self._callback), 3)


# Generated at 2022-06-11 18:22:03.581446
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo:
        def __init__(self):
            self.x = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def increment(self, n=1):
            self.x += n

    foo = Foo()
    foo.increment(2)
    assert foo.x == 2
    foo.increment(2)
    assert foo.x == 4

    class Bar:
        def __init__(self):
            self.x = 0
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def increment(self, n=1):
            self.x += n

    bar = Bar()
    bar.increment(4)
    assert bar.x == 4
    bar

# Generated at 2022-06-11 18:22:15.858160
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test the lock decorator'''
    import threading

    lock = threading.Lock()

    def method(self, test=False):
        '''Test function'''
        # pylint: disable=protected-access
        self.test = test
        # Verify the lock is in fact locked
        assert self._lock.locked() is True

    @lock_decorator(attr='_lock')
    @lock_decorator(lock=lock)
    def method_two():
        '''Another test function'''
        # Verify the lock is in fact locked
        assert lock.locked() is True

    class NewClass:
        '''Class to test'''

        def __init__(self, lock):
            self._lock = lock

    # pylint: disable=no-member

# Generated at 2022-06-11 18:22:26.923658
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test lock_decorator'''

    import threading
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def some_method(a):
        '''Some method'''
        return a
    @lock_decorator(attr='_some_method_lock')
    def some_other_method(a):
        '''Some other method'''
        return a

    class TestClass(object):
        '''Test class'''
        _some_other_method_lock = lock

        @lock_decorator(lock=lock)
        def some_method(self, a):
            '''Some method'''
            return a

# Generated at 2022-06-11 18:22:33.049601
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self.counter = 0

        @lock_decorator(attr='lock')
        def increment(self):
            self.counter += 1

        lock = threading.Lock()

    test = Test()
    import multiprocessing
    pool = multiprocessing.Pool()
    pool.map(test.increment, range(1, 10000))
    print(test.counter)

# Generated at 2022-06-11 18:22:44.934500
# Unit test for function lock_decorator
def test_lock_decorator():
    # Use threading.Lock for this test
    import threading
    # Create a lock object
    _lock = threading.Lock()

    # Create a class to use as a test object
    class Class():
        # Create an instance of threading.Lock
        _lock = threading.Lock()
        # Using the ``attr`` argument
        @lock_decorator(attr='_lock')
        def attr_method(self, value, sleep=0.1):
            import time
            # We call sleep here to simulate a situation where
            # something would be happening that would need to be
            # protected by a lock.
            time.sleep(sleep)
            return value

        # Using the ``lock`` argument
        @lock_decorator(lock=_lock)
        def lock_method(self, value):
            return value

   

# Generated at 2022-06-11 18:22:53.102523
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading

    if sys.version_info < (3, 0):
        from Queue import Queue
    else:
        from queue import Queue

    queue = Queue()

    class Test(object):
        @lock_decorator("_lock")
        def foo(self, arg):
            queue.put(arg)

        @staticmethod
        @lock_decorator("_lock")
        def bar(arg):
            queue.put(arg)

        @classmethod
        @lock_decorator("_lock")
        def baz(cls, arg):
            queue.put(arg)

    def get_test_instance(attr):
        result = Test()
        setattr(result, attr, threading.Lock())
        return result

    def queue_length():
        return queue

# Generated at 2022-06-11 18:23:02.516192
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from time import sleep
    from types import MethodType

    class Test(object):
        def __init__(self, count=0):
            self.count = count
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.count += 1
            return self.count

        def increment_no_decorator(self):
            with self.lock:
                self.count += 1
            return self.count

        @lock_decorator(lock=threading.Lock())
        def increment_explicit_lock(self):
            self.count += 1
            return self.count

    from ansible_collections.ansible.community.plugins.module_utils.sensu_go.sensu_go import SensuGo
   

# Generated at 2022-06-11 18:23:13.948857
# Unit test for function lock_decorator
def test_lock_decorator():

    # A class foo with a lock, missing_lock_attr
    class foo:
        def __init__(self, *args, **kwargs):
            self.missing_lock_attr = args[0]
            self.bar = self.bar_orig

        @lock_decorator(attr='missing_lock_attr')
        def bar(self, *args, **kwargs):
            ret = 1
            for i in args:
                ret *= i
            for i in kwargs:
                ret *= kwargs[i]
            ret = ret * 10
            return ret

        @property
        def bar_orig(self):
            return self.bar

    assert lock_decorator(attr='missing_lock_attr')(lambda x, y: x+y)(2, 3) == 5
    assert lock_decor

# Generated at 2022-06-11 18:23:25.561314
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    import threading

    class TestClass(object):
        def __init__(self):
            self.__lock = threading.Lock()
            self.__counter = 0
            self.__results = []

        @lock_decorator(attr='__lock')
        def increment(self, value):
            self.__counter += value
            self.__results.append(self.__counter)

    class TestClass2(object):
        def __init__(self, lock):
            self.__counter = 0
            self.__results = []
            self.__lock = lock

        @lock_decorator(lock=threading.Lock())
        def increment(self, value):
            self.__counter += value
            self.__results.append(self.__counter)

    test1 = TestClass()
   

# Generated at 2022-06-11 18:23:35.062246
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class DummyLockClass(object):
        # Dummy class that simulates a lock
        def __init__(self):
            self.counter = 0

        def __enter__(self):
            # Simulate counter getting incremented
            self.counter += 1

        def __exit__(self, *args):
            pass

    class LockClass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='lock')
        def increase_counter(self):
            self.counter += 1

    lc = LockClass()
    lc.increase_counter()
    assert lc.counter == 1

    # Note that the decorator takes a `lock` object, not an `attr`,
    # as the first argument

# Generated at 2022-06-11 18:23:43.499802
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a mock class
    class LockTest(object):
        def __init__(self):
            self.lock = 1
        @lock_decorator(attr='lock')
        def some_method(self, value):
            return value == 1
        @lock_decorator(lock=2)
        def other_method(self, value):
            return value == 2
    task = LockTest()
    # Make sure the methods return correctly when the lock is
    # held, and False if it's not
    assert task.some_method(1)
    assert not task.some_method(0)
    assert task.other_method(2)
    assert not task.other_method(0)



# Generated at 2022-06-11 18:23:54.012613
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import os
    import threading

    class FakeModule(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._test = 0

        @lock_decorator(attr='_lock')
        def increase_test(self):
            self._test += 1

    class FakeModule2(object):
        def __init__(self):
            self._test = 0

        @lock_decorator(lock=threading.Lock())
        def increase_test(self):
            self._test += 1

    class FakeModule3(object):
        def __init__(self):
            self._test = 0

        @lock_decorator(lock=mock.Mock())
        def increase_test(self):
            self._test += 1

    fake_module = Fake

# Generated at 2022-06-11 18:24:03.424858
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.count = 0

        @lock_decorator()
        def inc(self):
            self.count += 1

        @lock_decorator('lock')
        def inc_attr(self):
            self.count += 1

        @lock_decorator(lock=threading.Lock())
        def inc_lock(self):
            self.count += 1

    t = Test()

    # Without coercing this value, we set ourselves up for a race
    # condition where the tests take more than one second to complete
    # and it just so happens one of the threads running the test in
    # parallel gets delayed a moment, which causes a failure.
    t.count = 0

   

# Generated at 2022-06-11 18:24:10.482759
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    a = 0
    class A(object):
        _lock = lock
        @lock_decorator(attr='_lock')
        def increment(self):
            global a
            a += 1
    for i in range(100):
        A().increment()
    assert a == 100

    g = 0
    @lock_decorator(lock=lock)
    def ginc():
        global g
        g += 1
    for i in range(100):
        ginc()
    assert g == 100

# Generated at 2022-06-11 18:24:22.875314
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestLocked(object):
        def __init__(self):
            self.locked = False
            self.lock = threading.Lock()
            self.counter = 0
            self.threadlock = threading.Lock()

        @lock_decorator(attr='lock')
        def _lock(self):
            self.locked = True
            self.counter += 1

        @lock_decorator(attr='threadlock')
        def _threadlock(self):
            # Explicitly add the ``self._lock`` decorator to a
            # method, with a pre-defined lock object.
            self._lock()


# Generated at 2022-06-11 18:24:31.992009
# Unit test for function lock_decorator
def test_lock_decorator():

    import os
    import time
    import threading

    class TestLockDecorator(object):
        def __init__(self):
            self._count = 0
            self._callback_lock = threading.Lock()

        def _readable(self):
            return self._count

        def _inc(self):
            self._count += 1

        @lock_decorator()
        def missing_lock(self):
            self._inc()

        @lock_decorator(attr='_callback_lock')
        def with_lock(self):
            self._inc()

    def test_with_lock(cls):
        for pid in range(50):
            pid = os.fork()
            if pid == 0:
                for i in range(10):
                    cls.with_lock()
                os._exit(0)


# Generated at 2022-06-11 18:24:40.575687
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import logging

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger('test_lock_decorator')
    logger.setLevel(logging.INFO)

    class Test(object):
        def __init__(self, *args, **kwargs):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(lock=threading.Lock())
        def increment(self):
            self._counter += 1
            logger.info(self._counter)
            time.sleep(1)

        @lock_decorator(attr='_lock')
        def increment2(self):
            self._counter += 1
            logger.info(self._counter)
            time.sleep(1)

    # test_lock_

# Generated at 2022-06-11 18:24:50.195298
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    __test__ = {}
    # Decorate a method without specifying a lock
    class TestDecorator(object):
        def __init__(self):
            self.lock = threading.Lock()
        def func(self):
            pass
    testdecorator = TestDecorator()
    assert not testdecorator.lock.locked()
    wrapped = lock_decorator(attr='lock')(testdecorator.func)
    with wrapped:
        assert testdecorator.lock.locked()
    assert not testdecorator.lock.locked()
    # Decorate a method with an explicitly passed lock
    testlock = threading.Lock()
    assert not testlock.locked()
    wrapped = lock_decorator(lock=testlock)(testdecorator.func)

# Generated at 2022-06-11 18:24:52.539938
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLockClass(object):
        '''This class is used to test lock_decorator'''

        def __init__(self):
            self._lock = None

        @lock_decorator(attr='_lock')
        def test(self):
            pass

    tlc = TestLockClass()
    assert tlc.test.__name__ == 'test'

# Generated at 2022-06-11 18:25:02.458251
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    value = 0

    @lock_decorator(lock=lock)
    def increment(x=1):
        global value
        value += x

    @lock_decorator(attr='_lock')
    def increment_with(x=1):
        global value
        value += x

    class TestClass(object):
        _lock = threading.Lock()
        def __init__(self):
            self.value = 0

        @lock_decorator(attr='_lock')
        def increment(self, x=1):
            self.value += x

    def val_val():
        return value, c.value

    # Test with unattached lock
    workers = []

# Generated at 2022-06-11 18:25:13.012317
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(threading.Thread):
        def __init__(self):
            self._callback_lock = threading.Lock()
            super(Foo, self).__init__()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            '''does nothing'''
            pass

        @lock_decorator(lock=threading.Lock())
        def do_nothing(self, *args, **kwargs):
            '''does nothing'''
            pass

        def run(self):
            self.send_callback()
            self.do_nothing()

    foo = Foo()
    foo.start()
    foo.join()

# Generated at 2022-06-11 18:25:20.849179
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading as t
    from time import sleep
    from os import getpid
    from subprocess import Popen
    lock = t.Lock()
    counter = 0
    def test_lock(lock):
        global counter
        with lock:
            # Ask OS to increment counter
            counter = counter + 1
            # Let OS complete the task before moving on
            sleep(1)
            # Ask OS to increment counter again
            counter = counter + 1
            # Pass the PID into the Counter
            return getpid()
    # Define test_lock with lock_decorator
    test_lock = lock_decorator(lock=lock)(test_lock)
    # Spawn a new process

# Generated at 2022-06-11 18:25:23.237011
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    my_lock = threading.Lock()
    @lock_decorator(lock=my_lock)
    def foo():
        return 42
    assert foo() == 42

# Generated at 2022-06-11 18:25:34.152169
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test to make sure lock_decorator works'''
    import threading

    class TestClass(object):
        '''Test class'''
        def __init__(self):
            self.my_lock = threading.Lock()
            self.results = []
            self.should_pass = True

        @lock_decorator(attr='my_lock')
        def send_callback(self, value):
            '''send_callback is decorated with lock_decorator'''
            if self.should_pass:
                self.results.append(value)
            else:
                raise RuntimeError('test failed')

        @lock_decorator(lock=threading.Lock())
        def some_method(self, value):
            '''some_method is decorated with lock_decorator'''

# Generated at 2022-06-11 18:25:48.462694
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import multiprocessing

    # Set up a wrapper around a ``multiprocessing.Value``
    class IntVal:
        def __init__(self, val=0):
            self.val = multiprocessing.Value('i', val)

        # Use the lock decorator to synchronize access to ``self.val``
        @lock_decorator('val')
        def set(self, val):
            self.val.value = val

        @lock_decorator('val')
        def get(self):
            return self.val.value

    class Worker(multiprocessing.Process):
        def __init__(self, val):
            self.val = val
            super(Worker, self).__init__()

        def run(self):
            # Increment the value
            self

# Generated at 2022-06-11 18:25:55.591176
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    def test_func():
        '''Test the @lock_decorator'''

        lock = threading.Lock()
        attr = 'test_lock'

        # Using ``attr`` and a class

        class TestClass:
            '''Test class for the @lock_decorator'''
            def __init__(self):
                self.counter = 0
                self.test_lock = lock

            @lock_decorator(attr=attr)
            def test_method(self):
                '''Test the @lock_decorator using ``attr``'''
                self.counter = 10
                # We expect this to timeout since the lock should be held
                with self.test_lock:
                    pass

        # Using a custom lock

# Generated at 2022-06-11 18:26:02.556656
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test_function(self, i):
            self.i = i
    t = Test()
    t.test_function(3)
    assert t.i == 3

    t = Test()
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def test_function(i):
        t.i = i
    test_function(4)
    assert t.i == 4

# Generated at 2022-06-11 18:26:09.732847
# Unit test for function lock_decorator
def test_lock_decorator():
    class Test(object):
        def __init__(self):
            self.lock = False
            self.working = False

        @lock_decorator(attr='lock')
        def wrapped_method(self):
            self.working = True

        @lock_decorator(lock=True)
        def wrapped_method_with_lock(self):
            self.working = True

    test = Test()
    test.wrapped_method()
    assert test.working is True

    test = Test()
    test.wrapped_method_with_lock()
    assert test.working is True

# Generated at 2022-06-11 18:26:18.204025
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestClass(object):
        def __init__(self):
            self.val = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment_one(self):
            self.val += 1
            return self.val

        @lock_decorator(lock=threading.Lock())
        def increment_two(self):
            self.val += 2
            return self.val

    class Test(unittest.TestCase):
        def setUp(self):
            self.t = TestClass()

        def test_increment_one(self):
            self.assertEqual(self.t.increment_one(), 1)


# Generated at 2022-06-11 18:26:25.529520
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:
        def __init__(self, a_lock=None):
            if a_lock is None:
                a_lock = threading.Lock()
            self._a_lock = a_lock

        @lock_decorator(attr='_a_lock')
        def method(self, a, b):
            return a + b

    t = Test()
    assert t.method(1, 2) == 3

    t2 = Test(a_lock=threading.Lock())
    assert t2.method(1, 2) == 3

# Generated at 2022-06-11 18:26:36.865905
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class A(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._cnt = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            self._cnt += 1
            assert self._cnt <= 1

    class B(object):
        def __init__(self):
            self._cnt = 0
            self._callback_lock = threading.Lock()

        @lock_decorator(lock=self._callback_lock)
        def send_callback(self):
            self._cnt += 1
            assert self._cnt <= 1

    a = A()
    b = B()

    a.send_callback()
    b.send_callback()

# Generated at 2022-06-11 18:26:42.879190
# Unit test for function lock_decorator
def test_lock_decorator():
    class MutableObject(object):
        def __init__(self):
            self.value = 0

    obj = MutableObject()
    assert(obj.value == 0)

    @lock_decorator(attr='missing_attr')
    def change_value(obj):
        obj.value += 1

    @lock_decorator()
    def change_value_attr_missing(obj):
        obj.value += 1

    # This should raise AttributeError since `obj` doesn't
    # have an attribute called ``missing_attr``
    try:
        change_value(obj)
        assert(0)
    except AttributeError:
        assert(True)

    # This should raise AttributeError since `obj` doesn't
    # have an attribute called ``missing_attr``

# Generated at 2022-06-11 18:26:53.793562
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator()
        def _test_lock(self):
            self.counter += 1

        @lock_decorator(attr='_lock')
        def _test_lock_attr(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def _test_lock_arg(self):
            self.counter += 1

    from contextlib import contextmanager
    @contextmanager
    def thread_test(test, func, count):
        threads = [threading.Thread(target=getattr(test, func)) for _ in range(count)]
        [thread.start() for thread in threads]

# Generated at 2022-06-11 18:26:59.488841
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class Foo(object):
        @lock_decorator(lock=lock)
        def bar(self):
            return True

        @lock_decorator(attr='_lock')
        def baz(self):
            return True

    obj = Foo()
    assert obj.bar()
    assert obj.baz()

    assert obj.bar()
    assert obj.baz()

    obj._lock = lock
    assert obj.bar()
    assert obj.baz()

# Generated at 2022-06-11 18:27:15.040944
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading, time
    from ansible.module_utils.basic import AnsibleModule

    lock = threading.Lock()

    def locked_function(module):
        '''This function will be called 8 times, with the lock being
        held for a total of 0.05s. This function should take 0.4s to
        run.

        Without the lock, it should take 0.05s to run
        '''
        with lock:
            time.sleep(0.05)
            module.exit_json(changed=True)


# Generated at 2022-06-11 18:27:23.014195
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    try:
        from unittest import mock
    except ImportError:
        import mock

    class A(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def _a(self):
            return True

    a = A()
    with mock.patch.object(a, '_lock') as m:
        a._a()
        m.assert_has_calls([mock.call().__enter__(), mock.call().__exit__(None, None, None)])

    class B(object):
        @lock_decorator(lock=threading.Lock())
        def _b(self):
            return True

    b = B()

# Generated at 2022-06-11 18:27:33.523061
# Unit test for function lock_decorator
def test_lock_decorator():
    # Python2 doesn't have module ``unittest``
    # pylint: disable=no-name-in-module
    import unittest

    class TestClass(unittest.TestCase):
        # Python2 doesn't have class decorator ``classmethod``
        # pylint: disable=no-self-argument
        @classmethod
        def setUpClass(cls):
            cls._lock = threading.Lock()

        def test_non_default_lock(self):
            '''Test using a non-default lock'''
            @lock_decorator(lock=self._lock)
            def test_method():
                return True
            self.assertTrue(test_method())

        # Python2 doesn't have class decorator ``classmethod``
        # pylint: disable=no-self-argument

# Generated at 2022-06-11 18:27:40.495551
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class LockDecoratorTest(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(lock=threading.Lock())
        def send_callback(self):
            time.sleep(1)

        @lock_decorator(attr='_callback_lock')
        def send_callback_attr(self):
            time.sleep(1)

    ldt = LockDecoratorTest()

    start = time.time()
    ldt.send_callback()
    ldt.send_callback()
    print('send_callback: %s' % (time.time() - start))
    # Should be ~2

    start = time.time()
    ldt.send_callback_attr()
    ldt.send_

# Generated at 2022-06-11 18:27:50.703372
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    a = threading.Lock()
    # This test needs to be rewritten in a better way
    # It's too brittle and not enough tests here
    class test(object):
        def __init__(self, a=a):
            self.a = a
            self.counter = 0

        @lock_decorator(attr='a')
        def method(self):
            self.counter += 1
            return self.counter

    instance = test()
    instance.method() == 1
    instance.method() == 2
    instance.method() == 3

    class test(object):
        def __init__(self, a=a):
            self.a = a
            self.counter = 0

        @lock_decorator(lock=a)
        def method(self):
            self.counter += 1
            return

# Generated at 2022-06-11 18:27:59.150569
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    def test0_dec(func):
        @wraps(func)
        def inner0(*args, **kwargs):
            # Python2 doesn't have ``nonlocal``
            # assign the actual lock to ``_lock``
            _lock = getattr(args[0], '_lock')
            with _lock:
                return func(*args, **kwargs)
        return inner0

    class TestClass0:
        def __init__(self):
            self._lock = threading.Lock()

        @test0_dec
        def test0(self):
            return 1

        @lock_decorator(attr='_lock')
        def test1(self):
            return 1

    class TestClass1:
        def __init__(self):
            self._lock1 = threading.Lock()
            self

# Generated at 2022-06-11 18:28:10.236238
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class test_class:
        def __init__(self):
            self.value = 0
            self.lock = threading.Lock()
    tc = test_class()

    @lock_decorator(attr='lock')
    def test_method1(self):
        self.value += 1

    @lock_decorator(lock=tc.lock)
    def test_method2(self):
        tc.value += 1

    def test_thread():
        test_method1(tc)
        test_method2()

    threads = []
    for _ in range(100):
        t = threading.Thread(target=test_thread)
        t.setDaemon(True)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

   

# Generated at 2022-06-11 18:28:20.187430
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self._attr = threading.Lock()

        @property
        def value(self): return self._value

        @lock_decorator(attr='_attr')
        def increment_no_lock(self): self._value += 1


# Generated at 2022-06-11 18:28:31.240727
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Lock
    # Test with explicit lock object
    self = 'self'
    self.lock = Lock()
    called = []
    def wrapper(*args, **kwargs):
        assert args[0] == self
        called.append(1)

    wrapper = lock_decorator(attr='lock')(wrapper)

    t1 = threading.Thread(target=wrapper, args=[self])
    t2 = threading.Thread(target=wrapper, args=[self])
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    assert len(called) == 1, len(called)

    # Test with missing lock attr
    self = 'self'
    called = []

# Generated at 2022-06-11 18:28:41.558845
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        def __init__(self):
            self._callback_lock = threading.RLock()
            self.foo = 0

        @lock_decorator(attr='_callback_lock')
        def callback(self):
            self.foo += 1

    T = TestClass()
    T.callback()
    assert T.foo == 1

    class TestClass2(object):
        def __init__(self):
            self.foo = 0

        @lock_decorator(lock=threading.RLock())
        def callback(self):
            self.foo += 1

    T2 = TestClass2()
    T2.callback()
    assert T2.foo == 1

# Generated at 2022-06-11 18:29:06.606526
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import logging
    import sys

    logger = logging.getLogger('test_lock_decorator')
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    class TestLogging(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def do_logging(self, i):
            logger.warning('%d: %s', i, 'testing')

    test_logging = TestLogging()
    threads = []
    for i in range(10):
        thread = threading.Thread(target=test_logging.do_logging, args=(i,))
        thread.start()
        threads.append

# Generated at 2022-06-11 18:29:16.555421
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    import os
    import sys

    if sys.version_info < (3, 0):
        try:
            import imp
            imp.reload(os)
        except ImportError:
            import imp
            imp.reload(os)

    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.RLock()

        @lock_decorator(attr='_lock')
        def test(self):
            pass

    class Test2(object):
        @lock_decorator(lock=threading.RLock())
        def test(self):
            pass

    class TestLockDecorator(unittest.TestCase):
        def test_lock_decorator_with_attr(self):
            t = Test()
            t_name

# Generated at 2022-06-11 18:29:21.472956
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class TestObject(object):
        i = 0
        _lock = lock
        @lock_decorator(attr='_lock')
        def __getitem__(self, key):
            self.i += 1
            return self.i

    test_obj = TestObject()
    assert test_obj[1] == 1

# Generated at 2022-06-11 18:29:29.171918
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test the lock decorator for various scenarios'''
    import threading
    import time
    call_value = ''

    class SampleObject(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def test_me(self, value):
            time.sleep(0.5)
            global call_value
            call_value += value

    obj = SampleObject()

    t1 = threading.Thread(target=obj.test_me, args=('one',))
    t2 = threading.Thread(target=obj.test_me, args=('two',))
    t3 = threading.Thread(target=obj.test_me, args=('three',))

# Generated at 2022-06-11 18:29:39.718610
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import threading
    import time
    import unittest

    class Test(unittest.TestCase):
        def test_attr(self):
            class _Test(object):
                '''Test using an attribute'''
                def __init__(self):
                    self.lock = threading.Lock()
                    self.data = []
                    self.threads = []

                @lock_decorator(attr='lock')
                def append(self, value):
                    self.data.append(value)
                    time.sleep(0.01)

                def run_append(self, value):
                    t = threading.Thread(target=self.append, args=(value,))
                    self.threads.append(t)
                    t.start()

            obj = _Test()

# Generated at 2022-06-11 18:29:48.672595
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class test_lock_class(object):
        def __init__(self):
            self.some_value = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment(self):
            self.some_value += 1

    class test_lock_decorator(unittest.TestCase):
        def test_lock(self):
            test_lock = test_lock_class()
            threads = [threading.Thread(target=test_lock.increment) for x in range(100)]
            [x.start() for x in threads]
            [x.join() for x in threads]
            self.assertEqual(test_lock.some_value, 100)

    unittest.main()



# Generated at 2022-06-11 18:29:56.178628
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock

    class Foo(object):

        def __init__(self):
            self.lock = Lock()
            self.count = 0

        @lock_decorator(attr='lock')
        def foo(self):
            self.count += 1

        @lock_decorator(lock=Lock())
        def bar(self):
            self.count += 1

    foo = Foo()
    foo.foo()
    assert foo.count == 1
    foo.bar()
    assert foo.count == 2


# Generated at 2022-06-11 18:30:05.119627
# Unit test for function lock_decorator
def test_lock_decorator():
    from six import add_metaclass
    import threading

    class LockTestBaseMeta(type):
        def __new__(cls, name, bases, attrs):
            def wrap(name, func):
                # add all functions that start with test_ to the list of tests
                if name.startswith('test_'):
                    cls.tests.append(func)
                return func

            # assign the lock to the class (this will be the same for
            # all instances of the class that is created)
            attrs['_lock'] = threading.Lock()

            # add a tests attribute to the class that will contain a list
            # of all of the tests that are found
            attrs['tests'] = []

            # find all functions that are decorated with lock_decorator
            # and add them to the tests list

# Generated at 2022-06-11 18:30:09.876715
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    class Foo(object):
        def __init__(self):
            self._lock = lock
        @lock_decorator()
        def foo(self):
            return self._lock
    class Bar(object):
        @lock_decorator(lock=lock)
        def bar(self):
            return lock
    a = Foo()
    b = Bar()
    assert a.foo() is lock
    assert b.bar() is lock

# Generated at 2022-06-11 18:30:19.688054
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLockDecorator(object):
        def __init__(self):
            self.data = 0
            self.lock = threading.Lock()

        @lock_decorator(lock=self.lock)
        def incr(self, n):
            self.data += n
            time.sleep(1)
            return self.data


    assert TestLockDecorator.incr.__name__ == 'incr'
    t = TestLockDecorator()
    t.incr(5)
    assert t.data == 5
    t.incr(5)
    assert t.data == 10


# Make coding more python3-ish
from __future__ import absolute_import, division, print_function
__metaclass__ = type


import abc
import os


# Generated at 2022-06-11 18:31:03.158172
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    if sys.version_info[0] < 3:
        raise SkipTest("Python 2 does not have the ``nonlocal`` keyword")
    import threading
    import time
    import unittest
    from ansible.module_utils.six import with_metaclass

    class TestObjectMetaclass(type):
        def __init__(cls, name, bases, dct):
            def get_test_method(test_func):
                @wraps(test_func)
                @lock_decorator(attr='_lock')
                def test_method(self):
                    test_func(self)
                return test_method
            # Dynamically rewrite each test method, to use a lock
            # we are otherwise not using a metaclass