

# Generated at 2022-06-11 18:21:04.518501
# Unit test for function lock_decorator
def test_lock_decorator():
    import json
    import threading
    import time
    import sys

    # Local imports
    if sys.version_info[0] < 3:
        from cStringIO import StringIO
    else:
        from io import StringIO

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._foo = ''
            self._bar = ''
            self._result = ''

        @lock_decorator(attr='_lock')
        def do_something(self):
            time.sleep(0.1)
            self._result = json.dumps([self._foo, self._bar])

        @lock_decorator(attr='_lock')
        def foo(self, val):
            time.sleep(0.1)
            self._foo = val


# Generated at 2022-06-11 18:21:12.522872
# Unit test for function lock_decorator
def test_lock_decorator():
    import multiprocessing
    from functools import partial
    from pprint import pprint

    class Foo():

        # 2.6 does not have a nonlocal keyword!
        # Just make it an instance method
        def do_something(self, param):
            self.lock.acquire()
            print('doing something', param)
            self.lock.release()
            return self.results.append(param)

        def do_something_else(self, param):
            with self.lock:
                print('doing something else', param)
            return self.results.append(param)

        def do_something_different(self, param):
            print('doing something different', param)
            return self.results.append(param)


# Generated at 2022-06-11 18:21:21.173908
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestClass(object):
        def __init__(self, *args, **kwargs):
            self._count = 0

        @lock_decorator(attr='_lock')
        def count(self):
            self._count += 1

        @lock_decorator(lock=threading.Lock())
        def count2(self):
            self._count += 1

        @lock_decorator(attr='_lock')
        def double(self):
            self._count *= 2

    class TestCase(unittest.TestCase):
        def test_lock_decorator(self):
            obj = TestClass()
            obj._lock = threading.Lock()

            obj.count()
            self.assertEqual(obj._count, 1)

            obj.count2

# Generated at 2022-06-11 18:21:32.292633
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    def make_method(func, lock=None):
        lock = lock or threading.Lock()
        @lock_decorator(lock=lock)
        def method(*args, **kwargs):
            with lock:
                return func(*args, **kwargs)
        return method

    def make_method_attr(func):
        lock = threading.Lock()
        @lock_decorator(attr='lock')
        def method(self, *args, **kwargs):
            with lock:
                return func(self, *args, **kwargs)

        method.lock = lock
        return method

    def make_class(method=None):
        class TestClass(object):
            def __init__(self):
                self.lock = threading.Lock()


# Generated at 2022-06-11 18:21:39.740811
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from random import choice

    def _random_event(num):
        '''This function is being used to generate dummy
        events for use in the unit test. It simply makes
        the list of events a list of random events.'''
        event = ['started', 'finished', 'ended']
        return choice(event)

    lock = threading.Lock()

    events = []

    class WrappedClass(object):

        @lock_decorator(lock=lock)
        def send_event(self, event):
            events.append(event)

    # Create an instance of WrappedClass
    cls = WrappedClass()

    # Create a list of random events
    events = [_random_event(x) for x in range(10)]

    # Send the events to the instance
    for event in events:
        cl

# Generated at 2022-06-11 18:21:47.062615
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import types
    import threading
    import time

    class Test(object):
        count = 0
        lock = threading.Lock()
        @lock_decorator('lock')
        def increment(self):
            self.count += 1

    test_count = 0
    for i in range(100):
        test = Test()
        def run1():
            for i in range(100):
                test.increment()
        def run2():
            for i in range(100):
                test.increment()

        t1 = threading.Thread(target=run1)
        t2 = threading.Thread(target=run2)
        t1.start()
        t2.start()
        while t1.is_alive() or t2.is_alive():
            pass
       

# Generated at 2022-06-11 18:21:54.242066
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyClass(object):
        '''A test class'''
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def foo(self):
            '''Some test function'''
            return 'bar'

    m = MyClass()
    assert m.foo() == 'bar'

    @lock_decorator(lock=threading.Lock())
    def some_method():
        '''Another test function'''
        return 'bar'

    assert some_method() == 'bar'

# Generated at 2022-06-11 18:22:03.608474
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # Python 2.6 doesn't have skipTest
    try:
        from unittest import skipTest
    except ImportError:
        skipTest = None

    class LockingObject(object):
        def __init__(self):
            self._lock = threading.Lock()

        # Test locking object with a pre-defined attribute
        @lock_decorator(attr='_lock')
        def method1(self):
            self._do_something()

        # Test locking object with explicitly defined lock
        lock = threading.Lock()
        @lock_decorator(lock=lock)
        def method2(self):
            self._do_something()

        def _do_something(self):
            pass

    obj = LockingObject()

    # Python 2.6 doesn't have skipTest

# Generated at 2022-06-11 18:22:15.858120
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo:
        def __init__(self):
            self._lock = threading.Lock()
            self.val = 0

        @lock_decorator(attr='_lock')
        def increment(self):
            self.val += 1

    foo = Foo()
    # This will fail w/o locking
    try:
        for i in range(10):
            foo.increment()
    except:
        assert False, "incrementing val w/o locking failed"

    assert foo.val == 10, "incrementing val w/o locking got unexpected result"

    # This will not fail w/ locking
    foo.val = 0
    for i in range(10):
        foo.increment()

    assert foo.val == 10, "incrementing val w/ locking got unexpected result"

# Generated at 2022-06-11 18:22:25.680181
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Example(object):
        '''An example class that demonstrates the lock_decorator'''
        def __init__(self):
            self._lock = threading.Lock()
            self.data = 5
        @lock_decorator(attr='_lock')
        def add(self, x, y):
            self.data += x + y
            return self.data
        @lock_decorator(lock=threading.Lock())
        def subtract(self, x, y):
            self.data -= x + y
            return self.data
    example = Example()
    assert example.add(1, 2) == 8
    assert example.subtract(3, 4) == 0

# Generated at 2022-06-11 18:22:35.451569
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestLockDecorator(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._count = 0

        @lock_decorator(lock=self._lock)
        def incr_count(self):
            self._count += 1

        @lock_decorator(attr='_lock')
        def decr_count(self):
            self._count -= 1
    t = TestLockDecorator()
    import nose
    nose.tools.assert_equal(t._count, 0)
    t.incr_count()
    nose.tools.assert_equal(t._count, 1)
    t.decr_count()
    nose.tools.assert_equal(t._count, 0)

# Generated at 2022-06-11 18:22:45.390522
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    value = 0
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def get_value():
        return value
    @lock_decorator(lock=lock)
    def set_value(val):
        nonlocal value
        value = val
    @lock_decorator(attr="missing_lock_attr")
    def set_value_bad(self, val):
        nonlocal value
        value = val

    # The lock should lock, preventing races
    assert value == 0
    t = threading.Thread(target=set_value, args=(1,))
    t.start()
    t.join()
    assert value == 1
    assert get_value() == 1

    # The lock should raise if attr is an exception

# Generated at 2022-06-11 18:22:52.530794
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class A(object):
        def __init__(self, name):
            self.name = name

            # Any instance of Lock will do
            self._lock = threading.Lock()
            self._value = None

        @lock_decorator(attr='_lock')
        def set(self, value):
            self._value = value

        @lock_decorator(attr='_lock')
        def get(self):
            return self._value

    a = A('foo')
    a.set(5)
    assert a.get() == 5

    a1 = A('bar')
    a1.set(10)
    assert a1.get() == 10

# Generated at 2022-06-11 18:23:02.352985
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import threading
    import time

    class Test(unittest.TestCase):
        def test_attr(self):
            self.lock = threading.Lock()

            @lock_decorator(attr='lock')
            def threaded_func(self, *args, **kwargs):
                # Using ``time.sleep()`` to simulate a task
                time.sleep(0.2)
                return 'test'

            test_args = ('a', 'b')
            test_kwargs = {'c': 'd'}
            t_threaded_func = threaded_func.__get__(self, Test)

# Generated at 2022-06-11 18:23:13.798984
# Unit test for function lock_decorator
def test_lock_decorator():

    import pytest
    from threading import Lock

    class HasLock(object):
        def __init__(self):
            self._lock = Lock()

    def test_function(self):
        return 'test'

    # Test that the decorator actually works
    # This test is purely to ensure the decorator
    # is functioning, if you change the code in
    # lock_decorator, ensure this test passes
    has_lock = HasLock()
    assert lock_decorator(attr='_lock')(test_function)(has_lock) == 'test'

    # Test that the wrapper fails when the lock
    # is not a context manager
    with pytest.raises(RuntimeError) as e:
        lock_decorator(lock=None)(test_function)()
    assert 'should be used as a context manager' in str

# Generated at 2022-06-11 18:23:25.453795
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    import time

    class Bogus:
        def __init__(self):
            self.count = 0
            self.x = 0
            self.lock = Lock()

        @lock_decorator(attr='lock')
        def increment(self, wait_time):
            time.sleep(wait_time)
            self.count += 1
            self.x += 1

        @lock_decorator(lock=Lock())
        def decrement(self, wait_time):
            time.sleep(wait_time)
            self.count -= 1
            self.x -= 1

    def test_increment(bogus):
        bogus.increment(0.1)

    def test_decrement(bogus):
        bogus.decrement(0.1)

    b = Bog

# Generated at 2022-06-11 18:23:31.005605
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self.counter = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def increment_counter(self):
            self.counter += 1

    class TestClass2(object):
        def __init__(self):
            self.counter = 0

        @lock_decorator(lock=threading.Lock())
        def increment_counter(self):
            self.counter += 1

    def test_increment_counter(func_name):
        if func_name is 'TestClass.increment_counter':
            cls = TestClass
        elif func_name is 'TestClass2.increment_counter':
            cls = TestClass2
        else:
            raise

# Generated at 2022-06-11 18:23:35.721990
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Test(object):
        def __init__(self):
            self.val = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test(self):
            self.val += 1

    test_obj = Test()
    test_obj.test()
    assert test_obj.val == 1, 'Value is not expected'

# Generated at 2022-06-11 18:23:44.668652
# Unit test for function lock_decorator
def test_lock_decorator():
    from mock import patch

    # Test the default
    with patch('threading.Lock') as lock:
        @lock_decorator()
        def foo():
            pass

        foo()
        assert lock.called, 'Threading lock not called'
        lock.assert_called_once_with()

    # Test the `_lock` argument, which sets the attribute
    with patch('threading.Lock') as lock:
        @lock_decorator(attr='_lock')
        def foo(instance):
            pass

        foo(None)
        assert lock.called, 'Threading lock not called'
        lock.assert_called_once_with()

    # Test the `lock` argument, which sets the object

# Generated at 2022-06-11 18:23:54.428619
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading

    class TestClass(object):

        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def incr(self):
            self._counter += 1

        @lock_decorator(lock=threading.Lock())
        def decr(self):
            self._counter -= 1

    if sys.hexversion > 0x03000000:
        testobj = TestClass()
    else:
        testobj = TestClass()

    threads = [
        threading.Thread(target=testobj.incr),
        threading.Thread(target=testobj.decr),
        threading.Thread(target=testobj.decr)
    ]
    for t in threads:
        t

# Generated at 2022-06-11 18:24:04.460928
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    counter = 0
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def increase_counter():
        global counter
        counter += 1
        time.sleep(1)

    def run():
        for i in range(3):
            increase_counter()

    threads = [threading.Thread(target=run) for i in range(3)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert counter == 3, 'counter should be equal to 3'

# Generated at 2022-06-11 18:24:15.328794
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    import unittest
    import time

    class TestLockDecorator(unittest.TestCase):
        def test_no_lock(self):
            # Test function without a lock
            self.assertEqual(no_lock(10, 20), 10)

        def test_function_lock_object(self):
            # Test function with a lock object
            self.assertEqual(function_lock_object(10, 20), 10)

        def test_function_lock_attr(self):
            # Test function with a class attribute as lock
            self.assertEqual(function_lock_attr(10, 20), 10)


# Generated at 2022-06-11 18:24:24.369580
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import sys

    class Example(object):
        def __init__(self, attr='missing_lock_attr', lock=None):
            if lock is None:
                self._lock = threading.Lock()
            else:
                self._lock = lock

        @lock_decorator(attr='_lock')
        def method(self):
            print('Acquiring lock with self._lock')

        @lock_decorator(lock=threading.Lock())
        def method2(self):
            print('Acquiring lock with threading.Lock()')

    @lock_decorator(lock=threading.Lock())
    def function():
        print('Acquiring lock with threading.Lock')

    ex1 = Example()
    ex2 = Example()
    ex3 = Example()

# Generated at 2022-06-11 18:24:31.153015
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MockTarget(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.value = 0

        @lock_decorator('lock')
        def update_value(self):
            self.value += 1

    target = MockTarget()

    threads = []
    for i in range(100):
        t = threading.Thread(target=target.update_value)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    assert target.value == 100

# Generated at 2022-06-11 18:24:40.467742
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Create a lock object
    _lock = threading.Lock()

    # Function without a lock
    def func(lock):
        if lock:
            raise Exception('lock should be None')

    # Function with pre-defined lock attribute
    class MyClass(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method(self, lock):
            if lock is not self._lock:
                raise Exception('lock should be self._lock')

    # Function with explicit lock object
    @lock_decorator(lock=_lock)
    def func2(lock):
        if lock is not _lock:
            raise Exception('lock should be _lock')

    # Function with pre-defined lock attribute and explicit lock object

# Generated at 2022-06-11 18:24:50.164591
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class LockingClass(object):
        def __init__(self):
            self.value = 0
            self._lock = threading.Lock()

        @lock_decorator()
        def some_method(self):
            self.value += 1
            time.sleep(1)
            # lock will cause other threads to wait for this
            # thread to exit, ensuring that the value does not
            # change mid-increment
            self.value += 1

    cls = LockingClass()
    assert cls.value == 0

    threads = []
    for i in range(5):
        thread = threading.Thread(target=cls.some_method)
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    assert cls

# Generated at 2022-06-11 18:24:57.427946
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class SomeClass:
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def __call__(self, arg):
            print(arg)

    some_class = SomeClass()

    import multiprocessing

    for x in range(10):
        multiprocessing.Process(target=some_class, args=(x, )).start()

# Generated at 2022-06-11 18:25:03.428435
# Unit test for function lock_decorator
def test_lock_decorator():
    import inspect
    class Test(object):
        def __init__(self):
            self._lock = 'something'
        @lock_decorator(attr='_lock')
        def foo(self):
            return self._lock
        @lock_decorator(lock='something')
        def bar(self):
            return self._lock
    assert Test().foo() == 'something'
    assert Test().bar() == 'something'
    assert len(inspect.getfullargspec(Test.foo)[0]) == 1
    assert len(inspect.getfullargspec(Test.bar)[0]) == 1

# Generated at 2022-06-11 18:25:10.043491
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo:
        def __init__(self):
            self.total = 0
            self.lock = threading.Lock()
        @lock_decorator(attr='lock')
        def incr(self):
            self.total += 1
    f = Foo()
    assert f.total == 0
    f.incr()
    assert f.total == 1
    f.incr()
    assert f.total == 2

# Generated at 2022-06-11 18:25:19.227945
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test:


        def __init__(self):
            self.lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='lock')
        def increment_value_with_lock(self):
            self.value += 1
            return self.value

        @lock_decorator(lock=threading.Lock())
        def increment_value(self):
            self.value += 1
            return self.value

    # Test the class with the lock
    test = Test()

    import multiprocessing.pool

    with multiprocessing.pool.ThreadPool() as pool:
        results = pool.map(test.increment_value_with_lock, range(100))

    assert len(set(results)) == 1
    assert len(set(results)) != 100

# Generated at 2022-06-11 18:25:37.586754
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    import string
    import threading

    class _MockClass:
        _some_string = None
        _callback_lock = threading.Lock()

        def set_some_string(self, new_string):
            self._some_string = new_string

        def get_some_string(self):
            return self._some_string

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            return True

        @lock_decorator()
        def set_string_with_lock(self, new_string):
            self._some_string = new_string

    class _T(threading.Thread):
        '''Simple thread class that takes a callback method
        and runs it. This allows us to do an atomic test against
        the lock decorator.'''
       

# Generated at 2022-06-11 18:25:47.197716
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    import pytest

    shared_counter = 0

    class Lockable(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def increment(self, counter_to_increment):
            return counter_to_increment + 1

        @lock_decorator(lock=threading.Lock())
        def decrement(self, counter_to_decrement):
            return counter_to_decrement + 1

        @lock_decorator(lock=threading.Lock())
        def increment_shared(self, shared_counter):
            return shared_counter + 1

        def non_locking_increment(self, counter_to_increment):
            return counter_to_increment

# Generated at 2022-06-11 18:25:55.200770
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import mock
    import six

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.test_lock = mock.MagicMock()
            self.test_lock.__enter__ = mock.MagicMock(return_value=self.test_lock)
            self.test_lock.__exit__ = mock.MagicMock(return_value=False)
            self.test_lock.return_value = self.test_lock
            self.test_lock_call_count = 0

            self.test_attr = '_test_attr'
            if six.PY2:
                self.test_self = mock.MagicMock()
            else:
                self.test_self = mock.MagicMock(spec=self.test_attr)
            self

# Generated at 2022-06-11 18:26:03.847915
# Unit test for function lock_decorator
def test_lock_decorator():
    import shutil
    import tempfile
    import threading
    import time
    import unittest

    class Example(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def f1(self):
            time.sleep(2)

        @lock_decorator()
        def f2(self):
            time.sleep(2)

        @lock_decorator(lock=threading.Lock())
        def f3(self):
            time.sleep(2)

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-11 18:26:10.196758
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    import random

    lock = Lock()
    counter = 0
    def inc():
        global counter
        with lock:
            counter += 1

    @lock_decorator(lock=lock)
    def add_wrapper():
        inc()

    @lock_decorator(attr='lock')
    def add_attr():
        inc()

    for i in range(10):
        add_wrapper()
    for i in range(10):
        add_attr()

    assert counter == 20

# Generated at 2022-06-11 18:26:18.396096
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    import time

    lock = Lock()
    calls = 0

    class A:
        @lock_decorator(lock=lock)
        def __init__(self, value):
            nonlocal calls
            calls += 1
            time.sleep(float(value))
            calls += 1

        @lock_decorator(attr='_lock')
        def method(self):
            nonlocal calls
            calls += 1
            time.sleep(1)
            calls += 1

    # Neither of these should happen in parallel
    a = A(5)
    b = A(5)
    assert calls == 4

    # No parallel method calls
    c = A(5)
    c.method()
    c.method()
    assert calls == 8

    # State should be preserved between calls

# Generated at 2022-06-11 18:26:22.340450
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    test_lock = threading.Lock()
    lock_attr = 'lock_attr'
    lock_val = 'lock_val'

    assert test_lock.locked() is False

    class LockTest(object):
        def __init__(self, lock_attr, lock_val):
            self.lock_attr = lock_attr
            self.lock_val = lock_val

        @lock_decorator(attr=lock_attr)
        def with_lock(self):
            assert test_lock.locked() is True
            assert getattr(self, self.lock_attr) is test_lock
            assert self.lock_val == 'changed'


# Generated at 2022-06-11 18:26:29.076227
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    global lock_count
    lock_count = 0

    def test_func():
        nonlocal lock_count
        lock_count += 1
        print (f"test_func(): Count = {lock_count}")

    @lock_decorator(lock=threading.Lock())
    def my_func():
        test_func()

    threads = []
    for i in range(100):
        t = threading.Thread(target=my_func)
        threads.append(t)
        t.start()

    for thread in threads:
        thread.join()

    print (f"Final Count: {lock_count}")
    assert lock_count == 1

# Generated at 2022-06-11 18:26:36.464292
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestLock(object):
        lock = threading.Lock()

        @lock_decorator(attr='lock')
        def method(self):
            pass

    class TestLockExplicit(object):
        @lock_decorator(lock=threading.Lock())
        def method(self):
            pass

    # Sanity check
    assert TestLock.method.__name__ == 'method'
    assert TestLockExplicit.method.__name__ == 'method'

# Generated at 2022-06-11 18:26:42.643371
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class MyClass(object):
        def __init__(self, lock):
            self._lock = lock

        @lock_decorator('_lock')
        def some_method(self):
            print(self._lock)
            print('method running')
            for i in range(1000000):
                pass
            print('method done')

    lock = threading.Lock()
    instance = MyClass(lock)

    t1 = threading.Thread(target=instance.some_method)
    t2 = threading.Thread(target=instance.some_method)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

# If this file is run as main program, run unit test
if __name__ == '__main__':
    test_lock

# Generated at 2022-06-11 18:27:06.910474
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class TestCls(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            return 'success'

    test = TestCls()
    assert test.send_callback() == 'success'

    class TestCls2(object):
        @lock_decorator(lock=lock)
        def send_callback(self):
            return 'success'

    test = TestCls2()
    assert test.send_callback() == 'success'



# Generated at 2022-06-11 18:27:14.986996
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        _callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def test_attr(self, wait):
            time.sleep(wait)
            return wait

        @lock_decorator(lock=threading.Lock())
        def test_lock(self, wait):
            time.sleep(wait)
            return wait

        @lock_decorator()
        def test_no_lock(self, wait):
            time.sleep(wait)
            return wait

    obj = TestClass()

    # We expect that running the test_lock method,
    # with locks, will be the same as test_no_lock
    # without locks

# Generated at 2022-06-11 18:27:22.993804
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for function lock_decorator'''
    import threading
    import time
    class Test(object):
        def __init__(self):
            self._attr_lock = threading.Lock()
            self._attr_value = 0
            self._other_attr = 10

        @lock_decorator(attr='_attr_lock')
        def _attr_increment(self):
            self._attr_value += 1
            self._other_attr += 1

        @lock_decorator(lock=threading.Lock())
        def _other_increment(self):
            self._attr_value += 1
            self._other_attr += 1

    class Worker(threading.Thread):
        def __init__(self, caller):
            super(Worker, self).__init__()
            self.call

# Generated at 2022-06-11 18:27:31.259579
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self.ran = 0
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def run(self):
            self.ran += 1
            time.sleep(1)
            self.ran += 1

    instance = TestClass()
    for x in range(0, 10):
        thread = threading.Thread(target=instance.run)
        thread.start()

    time.sleep(10)

    assert instance.ran == 20

# Generated at 2022-06-11 18:27:39.326032
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    class TestObject:
        test_attr = 0

        @lock_decorator()
        def missing_lock_attr(self):
            self.test_attr += 1

        @lock_decorator(attr='lock')
        def missing_attr_value(self):
            self.test_attr += 1

        @lock_decorator(lock=lock)
        def missing_self(self):
            self.test_attr += 1

        @lock_decorator(lock=lock, attr='lock')
        def two_args(self):
            self.test_attr += 1

    test = TestObject()

    with pytest.raises(AttributeError):
        test.missing_lock_attr()

    with pytest.raises(AttributeError):
        test

# Generated at 2022-06-11 18:27:49.984456
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.lock_attr = None
            self.lock_val = None
            self.no_lock_attr = None
            self.no_lock_val = None
        @lock_decorator(lock=threading.Lock())
        def lock_method(self, val):
            self.lock_val = val
            return True
        @lock_decorator(attr='_lock')
        def lock_attr_method(self, val):
            self.lock_attr = val
            return True
        def no_lock_method(self, val):
            self.no_lock_val = val
            return True

# Generated at 2022-06-11 18:27:58.636706
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading
    from ansible.module_utils._text import to_text

    m = mock.MagicMock()
    m.a = m.b = None

    lock = threading.Lock()
    attr = '_mylock'

    @lock_decorator(attr=attr, lock=lock)
    def test_lock(a, b, c):
        if a:
            m.a = b
            return c
        else:
            m.b = b

    def run_test_lock(a, b, c):
        return test_lock(a, b, c)

    t = threading.Thread(target=run_test_lock, args=(True, 1, 2))
    t.start()
    t.join()

    assert m.a == 1
    assert m.b

# Generated at 2022-06-11 18:28:09.966696
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import operator

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.var = 0

        @lock_decorator(attr='_lock')
        def do_foo_stuff(self, a, b):
            self.var += 1
            time.sleep(a)
            self.var += b

    def do_foo_stuff(a, b):
        self.var += 1
        time.sleep(a)
        self.var += b

    try:
        import __builtin__
        builtin = __builtin__
    except ImportError:
        import builtins
        builtin = builtins

    f = Foo()
    fen = f.do_foo_stuff

# Generated at 2022-06-11 18:28:20.117788
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import unittest

    class Foo(object):

        def __init__(self, name):
            self.name = name
            self.lock = threading.RLock()
            self.attr_lock = threading.RLock()

        @lock_decorator(attr='lock')
        def locked_method(self):
            time.sleep(1)
            return self.name

        @lock_decorator(lock=threading.RLock())
        def another_locked_method(self):
            time.sleep(1)
            return self.name

    class TestLockDecorator(unittest.TestCase):

        def runTest(self):
            foo = Foo('test')

            self.assertIsInstance(foo.locked_method, threading._RLock)

# Generated at 2022-06-11 18:28:25.254424
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class A(object):
        def __init__(self):
            self._a = 0
            self._lock = threading.Lock()

        def __repr__(self):
            return 'A(%r)' % self._a

        @lock_decorator(attr='_lock')
        def inc(self):
            self._a += 1


# Generated at 2022-06-11 18:29:07.422263
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # Test with ``attr``
    class TestAttr(object):
        def __init__(self):
            self._foo_lock = threading.Lock()

        @lock_decorator(attr='_foo_lock')
        def foo(self, i):
            self._foo_lock.acquire()
            try:
                assert self._foo_lock.locked()
                return i
            finally:
                self._foo_lock.release()

    ta = TestAttr()
    assert not ta._foo_lock.locked()
    ta.foo(0)
    assert not ta._foo_lock.locked()

    # Test with ``lock``
    class TestLock(object):
        def __init__(self):
            self.foo_lock = threading.Lock()


# Generated at 2022-06-11 18:29:17.290758
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # Initialize a global varible that is shared between threads
    val = 0

    class TestThread(threading.Thread):
        def __init__(self, l):
            self.lock = l
            threading.Thread.__init__(self)

        @lock_decorator(lock=private_lock)
        def run(self):
            global val
            for _ in range(1000):
                val += 1

    # Initialize the lock
    private_lock = threading.Lock()

    # Create 500 threads
    threads = [TestThread(private_lock) for _ in range(500)]

    # Start threads
    for t in threads:
        t.start()

    # Wait for threads to finish
    for t in threads:
        t.join()

    # Assert that the value

# Generated at 2022-06-11 18:29:27.020766
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    global_lock = threading.Lock()
    class TestClass:
        _missing_lock_attr = None
        _callback_lock = threading.Lock()
        _global_lock = global_lock
        _list = []
        _list_lock = []

        def __init__(self):
            self._list_lock.append(threading.Lock())

        @lock_decorator(attr='_missing_lock_attr')
        def decorated_missing_lock_attr(self):
            pass

        @lock_decorator(attr='_callback_lock')
        def decorated_callback_lock(self):
            pass

        @lock_decorator(lock=lock)
        def decorated_lock(self):
            pass


# Generated at 2022-06-11 18:29:37.872664
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.var = 0

        @lock_decorator(attr='_lock')
        def set_var(self, val):
            self.var = val

        def get_var(self):
            return self.var
    foo = Foo()
    foo.set_var(1)
    assert foo.get_var() == 1

    # We should always get 0 when set_var isn't locking properly
    foo.set_var(0)
    assert foo.get_var() == 0
    foo.set_var(1)
    assert foo.get_var() == 1
    foo.set_var(0)
    assert foo.get_var() == 0

# Generated at 2022-06-11 18:29:43.387815
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        return

    class TestObject(object):

        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def test_method_implicit_lock(self):
            assert self._callback_lock
            return self._callback_lock

        @lock_decorator(lock=threading.Lock())
        def test_method_explicit_lock(self):
            return threading.Lock()

    obj = TestObject()

    assert obj.test_method_implicit_lock() == obj._callback_lock
    assert obj.test_method_explicit_lock() is not obj._callback_lock

# Generated at 2022-06-11 18:29:51.485019
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    from threading import Semaphore
    from threading import Thread
    from time import sleep

    class Foo:
        _my_lock = Lock()

        @lock_decorator(attr='_my_lock')
        def locked_method(self):
            # Return self.active_threads
            return self.active_threads

        def __init__(self):
            self.active_threads = 0

    # Prepare the test class
    test_obj = Foo()
    # Ensure that we can call the method without the decorator
    assert test_obj.locked_method() == 0
    # Ensure that we can call the method with the decorator
    assert test_obj.locked_method() == 0

    # Create a mutex to ensure that the threads are properly
    # synchronized.
    mutex = Sem

# Generated at 2022-06-11 18:30:01.695175
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        # Should use class_attr as the lock
        class_attr = threading.Lock()

        @lock_decorator(attr='class_attr')
        def test_method(self):
            return self.class_attr

    test = TestClass()
    assert isinstance(test.test_method(), threading.Lock)

    # Should use instance_attr as the lock
    class_lock = threading.Lock()

    class TestClass(object):
        instance_attr = threading.Lock()

        @lock_decorator(lock=class_lock)
        def test_method(self):
            return class_lock

    test = TestClass()
    assert isinstance(test.test_method(), threading.Lock)

# Generated at 2022-06-11 18:30:08.241726
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock

    class Foo(object):
        '''Test class for lock_decorator unit test'''
        def __init__(self):
            self.val = None
            self.lock = Lock()

        @lock_decorator(attr='lock')
        def set_val(self, val):
            '''Test method for lock_decorator unit test'''
            self.val = val

    # Test the decorator with lock being an instance attribute
    foo = Foo()
    foo.set_val('test')
    assert foo.val == 'test'

    # Test the decorator with a lock passed as an argument
    lock = Lock()

    @lock_decorator(lock=lock)
    def set_val_2(val):
        '''Test function for lock_decorator unit test'''

# Generated at 2022-06-11 18:30:18.495473
# Unit test for function lock_decorator
def test_lock_decorator():

    import pytest
    import threading

    class SomeClass(object):
        def __init__(self, val):
            self.val = val
            self._callback_lock = threading.Lock()

        @lock_decorator('_callback_lock')
        def send_callback(self, val=None):
            assert self.val is not None
            assert self._callback_lock is not None
            assert type(self._callback_lock) is threading.Lock
            assert type(type(self).send_callback) is lock_decorator

        @lock_decorator(lock=threading.Lock())
        def some_method(self):
            assert type(self).some_method is lock_decorator


# Generated at 2022-06-11 18:30:27.492488
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLockDecorator(object):
        @lock_decorator(attr='_lock')
        def a_method(self):
            time.sleep(3)

        def __init__(self):
            self._lock = threading.Lock()

    def test_thread():
        t = TestLockDecorator()
        t.a_method()

    start = time.time()
    threading.Thread(target=test_thread).start()
    threading.Thread(target=test_thread).start()
    assert time.time() - start > 3
    assert time.time() - start < 4