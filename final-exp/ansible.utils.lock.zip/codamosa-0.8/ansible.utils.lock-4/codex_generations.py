

# Generated at 2022-06-11 18:21:05.506225
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        return
    import time

    class Test(object):
        '''
        Test class used to test the lock_decorator
        '''
        missing_lock_attr = threading.Lock()
        lock = threading.Lock()

        @lock_decorator(attr='missing_lock_attr')
        def method1(self, num):
            '''
            Method that increments a variable, by a number passed in
            '''
            self.count += num
            time.sleep(1)
            return self.count

        @lock_decorator(lock=threading.Lock())
        def method2(self, num):
            '''
            Method that increments a variable, by a number passed in
            '''
            self.count += num
            time.sleep

# Generated at 2022-06-11 18:21:13.121389
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest.mock
    import threading

    @lock_decorator(lock=threading.Lock())
    def fake_func():
        return 1

    with unittest.mock.patch('threading.Lock.__enter__') as mock_enter:
        mock_enter.return_value = unittest.mock.MagicMock()
        fake_func()

    with unittest.mock.patch('threading.Lock.__exit__') as mock_exit:
        fake_func()

    class Test(object):
        @lock_decorator(attr='lock')
        def fake_func(self):
            return 1

    fake = Test()
    fake.lock = threading.Lock()

# Generated at 2022-06-11 18:21:21.560990
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    sys.path.insert(0, 'lib')
    from lock_decorator import lock_decorator
    import threading
    lock = threading.Lock()
    shared = 0

    class Test:
        def __init__(self):
            self.lock = threading.Lock()
            self._shared = shared
            self._shared2 = shared

        @lock_decorator(lock=lock)
        def method_with_explicit_lock(self):
            self._shared = self._shared + 1
            print('Value in method_with_explicit_lock: {}'.format(self._shared))

        @lock_decorator(attr='lock')
        def method_with_attr_lock(self):
            self._shared2 = self._shared2 + 1

# Generated at 2022-06-11 18:21:32.370958
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading

    class Test(object):
        def __init__(self):
            self._lock = None

        def __repr__(self):
            return 'Test()'

        @lock_decorator(attr='_lock', lock=None)
        def method(self):
            pass

        # Test that lock_decorator doesn't fail when a Lock is passed
        @lock_decorator(lock=threading.Lock())
        def method2(self):
            pass

    with mock.patch('ansibullbot.wrappers.lock_decorator.Lock') as Lock:
        t = Test()
        t.method()
        Lock.assert_called_once_with()
        t.method2()
        Lock.assert_called_once_with()



# Generated at 2022-06-11 18:21:39.808551
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.lock2 = threading.Lock()
            self.val = 0
            self.val2 = 0

        # This method will not be decorated
        def method(self):
            pass

        # This method should be decorated by ``lock_decorator``
        @lock_decorator()
        def method2(self):
            pass

        # This method should be decorated by ``lock_decorator``
        @lock_decorator(lock=self.lock2)
        def method3(self):
            pass

        # This method should be decorated by ``lock_decorator``

# Generated at 2022-06-11 18:21:40.448582
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-11 18:21:48.301360
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for function lock_decorator'''

    import threading
    import time

    _test_lock = threading.Lock()

    class Test(object):
        __lock_object = _test_lock
        @lock_decorator(lock=__lock_object)
        def method_with_lock_explicit(self, x):
            return x ** x
        @lock_decorator(attr='_test_lock')
        def method_with_lock_implicit(self, x):
            return x ** x
        _test_lock = threading.Lock()

    t = Test()

    def do_lock_test(function, x, y):
        time.sleep(0.1)
        assert function(x) == y
        time.sleep(0.1)


# Generated at 2022-06-11 18:21:56.207518
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test function lock_decorator'''
    import threading

    class SomeClass(object):
        _lock = threading.Lock()
        _value = 0

        @lock_decorator(attr='_lock')
        def add_value(self, value):
            self._value += value

        @lock_decorator(lock=threading.Lock())
        def sub_value(self, value):
            self._value -= value

    class SomeOtherClass(object):
        def __init__(self, value):
            self._lock = threading.Lock()
            self._value = value

        @lock_decorator(attr='_lock')
        def add_value(self, value):
            self._value += value

    class YetAnotherClass(object):
        _lock = threading.Lock()


# Generated at 2022-06-11 18:22:03.116878
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def sleep(self):
        import time
        time.sleep(2)
    assert lock._is_owned()
    sleep()
    assert not lock._is_owned()

    @lock_decorator(attr='lock')
    def sleep_classmethod(cls):
        import time
        time.sleep(2)
    class Test(object):
        lock = threading.Lock()
    assert lock._is_owned()
    sleep_classmethod(Test)
    assert not lock._is_owned()

# Generated at 2022-06-11 18:22:15.513134
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import itertools
    _list = None

    class Test(object):
        @lock_decorator(attr='_lock')
        def method_one(self):
            global _list
            _list = [1]

        @lock_decorator(lock=threading.Lock())
        def method_two(self):
            global _list
            _list = [2]

    t = Test()
    t._lock = threading.Lock()

    threads = []

    for method in [t.method_one, t.method_two]:
        for i in itertools.repeat(None, 1000):
            threads.append(threading.Thread(target=method))

    for t in threads:
        t.start()

    for t in threads:
        t.join()


# Generated at 2022-06-11 18:22:24.227809
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self.val = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def lock_change(self):
            self.val = self.val + 1

        @lock_decorator(lock=threading.Lock())
        def lock_change_external(self):
            self.val = self.val + 1

    # Make up a bunch of threads to access a single shared object
    # and check that the result is deterministic
    test = Test()
    threads = []
    def thread_func(n):
        for i in range(5):
            test.lock_change()


# Generated at 2022-06-11 18:22:33.488547
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()
    @lock_decorator(attr='_lock')
    def check_attr_lock(arg):
        if arg != 'test':
            raise RuntimeError('arg must be test')
        print('set')
        arg = 'test'
    @lock_decorator(lock=_lock)
    def check_lock(arg):
        if arg != 'test':
            raise RuntimeError('arg must be test')
        print('set')
        arg = 'test'
    class Locker(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def check_attr_lock(self, arg):
            if arg != 'test':
                raise RuntimeError('arg must be test')
            print('set')
            arg

# Generated at 2022-06-11 18:22:37.424164
# Unit test for function lock_decorator
def test_lock_decorator():
    class FakeClass(object):
        _lock = None

        @lock_decorator(attr='_lock')
        def foo(self, value):
            self._lock = value

    fake = FakeClass()
    fake.foo('bar')

    assert fake._lock == 'bar'



# Generated at 2022-06-11 18:22:48.417549
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    class LockTest(object):
        def __init__(self):
            self._lock = 0
            self._lock_test_lock = threading.Lock()

        @lock_decorator(attr='_lock_test_lock')
        def test_no_nested_lock(self):
            self._lock += 1
            time.sleep(1)
            assert self._lock == 1

        @lock_decorator(attr='_lock_test_lock')
        def test_with_nested_lock(self):
            self._lock += 1
            with self._lock_test_lock:
                pass
            self._lock += 1
            assert self._lock == 2


# Generated at 2022-06-11 18:23:00.190088
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import time

    class TestLock(unittest.TestCase):
        def setUp(self):
            class TestLockClass(object):
                def __init__(self):
                    # Thread safe global state shared across tests
                    self._shared_state = 0
                    # Lock used by lock_decorator
                    self.silly_lock = threading.Lock()

                @lock_decorator(attr='silly_lock')
                def test_lock(self):
                    self._shared_state += 1
                    time.sleep(1)

            # Create an actual object of the test class
            self.test_obj = TestLockClass()

        def test_lock(self):
            # Validate lock
            val = self.test_obj._shared_state
            self.test_obj.test

# Generated at 2022-06-11 18:23:11.635170
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # If we have an existing attribute, use it
    class MyClass1(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def test_method1(self, value):
            return value

    class MyClass2(object):
        # If we don't have an existing attribute, pass a lock
        @lock_decorator(lock=threading.Lock())
        def test_method2(self, value):
            return value

    # Test the cases
    my_class_1 = MyClass1()
    my_class_2 = MyClass2()
    assert my_class_1.test_method1(1) == 1
    assert my_class_2.test_method2(2)

# Generated at 2022-06-11 18:23:23.278648
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class TestClass:
        '''Create a threaded class to test lock_decorator()'''

        def __init__(self):
            self.total = 0
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def add(self, number):
            print('Waiting for lock')
            self.total += number

        @lock_decorator(lock=threading.Lock())
        def subtract(self, number):
            print('Waiting for lock')
            self.total -= number

    # Create a global instance of our test class
    TC = TestClass()

    # Define a class that inherits from threading.Thread
    # that accepts an integer ``number`` and calls
    # the corresponding method on our test class


# Generated at 2022-06-11 18:23:34.286632
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class Test(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.value = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, value):
            sleep_time = random.random() * 0.1
            time.sleep(sleep_time)
            self.value = value

    test = Test()
    start = time.time()
    NUM = 100
    for i in range(NUM):
        test.send_callback(i)
    end = time.time()
    duration = end - start
    assert test.value == NUM - 1, test.value
    print("In %0.5f seconds, incremented by %d" % (duration, NUM))

# Generated at 2022-06-11 18:23:43.798753
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestWithMissingLockAttr:
        def __init__(self):
            self.lock_level = 0

        def foo(self, val):
            self.lock_level += val
            return self.lock_level

    class TestWithLock:
        def __init__(self, attr):
            self.lock_level = 0
            if attr:
                self.lock_attr = attr

        @property
        def lock_attr(self):
            return self._lock_attr

        @lock_attr.setter
        def lock_attr(self, val):
            self._lock_attr = val

        @lock_decorator(attr='lock_attr')
        def foo(self, val):
            self.lock_level += val
            return self.lock_level


# Generated at 2022-06-11 18:23:52.598204
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    _lock = threading.Lock()
    @lock_decorator(lock=_lock)
    def test(a=None, b=None):
        return a, b

    # Lock is locked by the decorator
    assert _lock.locked()

    with _lock:
        # Verify that the decorated function can be used as a context
        # manager.
        assert _lock.locked()

    # Verify that the lock was released
    assert not _lock.locked()

    # Verify that the arguments to the decorated function were passed
    # through correctly.
    assert test(a=100, b=200) == (100, 200)

# Generated at 2022-06-11 18:24:04.387158
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    lock = threading.Lock()

    class ClassA(object):

        @lock_decorator(lock=lock)
        def foo(self):
            return self

        @lock_decorator('_lock')
        def bar(self):
            return self

    a = ClassA()
    a._lock = lock

    # Method foo should have been wrapped
    assert a.foo() is a
    # Method bar should have been wrapped
    assert a.bar() is a

    # Should fail without an initialized lock
    try:
        class ClassB(object):

            @lock_decorator(attr='_lock')
            def foo(self):
                return self
        b = ClassB()
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError not raised')

# Generated at 2022-06-11 18:24:15.233932
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    try:
        # Python 2
        import __builtin__ as builtins
    except ImportError:
        # Python 3
        import builtins

    class Foo(object):
        def __init__(self):
            self.lock_attr = threading.Lock()
            self.lock_class_attr = threading.Lock()
            self.lock_object = threading.Lock()
            self.nested_lock = threading.RLock()
            self.nested_lock_count = 0
            self.lock_count = 0
            self.lock_class_count = 0
            self.lock_object_count = 0

        @lock_decorator(attr='lock_attr')
        def lock_method(self):
            self.lock_count += 1


# Generated at 2022-06-11 18:24:21.533404
# Unit test for function lock_decorator
def test_lock_decorator():
    class MyClass:
        _lock = None
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def locked_method(self, a):
            assert a == 1
            return a

        def unlocked_method(self, a):
            assert a == 1
            return a

    testobj = MyClass()

    testobj.locked_method(1)
    testobj.unlocked_method(1)

# Generated at 2022-06-11 18:24:31.086920
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo:
        def __init__(self):
            self.lock = 1
            self.bar = 2

        @lock_decorator(attr='lock')
        def method1(self):
            self.bar = 3

        @lock_decorator(attr='lock')
        def method2(self):
            return self.bar

        @lock_decorator(lock=threading.Lock())
        def method3(self):
            self.bar = 4

        @lock_decorator(lock=threading.Lock())
        def method4(self):
            return self.bar

    foo = Foo()
    foo.method1()
    assert foo.bar == 3 and foo.lock == 1
    foo.method3()
    assert foo.bar == 4 and foo.lock == 1

# Generated at 2022-06-11 18:24:40.440219
# Unit test for function lock_decorator
def test_lock_decorator():
    attr = "_test_lock_decorator_lock"

    class TestClass(object):
        def __init__(self):
            self.lock = True
            self.data = None
            self.was_locked = False

        @lock_decorator(attr=attr)
        def set(self, data):
            self.was_locked = self.lock
            self.data = data

        @lock_decorator(attr=attr)
        def get(self):
            self.was_locked = self.lock
            return self.data

    t = TestClass()
    # get the lock and make sure we can't aquire it again
    lock = getattr(t, attr)
    assert not lock.acquire(timeout=0.1)
    # sanity check that our data is correctly set in the
    # class

# Generated at 2022-06-11 18:24:50.162102
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class ExampleClass:
        # Test using a class-defined lock attribute
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def some_method(self, *args, **kwargs):
            return args, kwargs

    class ExampleClass2:
        # Test using a manually-defined lock object
        _lock = threading.Lock()

        @lock_decorator(lock=_lock)
        def some_method(self, *args, **kwargs):
            return args, kwargs

    def test_call(func, *args, **kwargs):
        results = []
        def run_threads():
            for i in range(10):
                t = threading.Thread(target=func, args=args, kwargs=kwargs)
               

# Generated at 2022-06-11 18:24:58.267592
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class A(object):
        @lock_decorator(lock=threading.Lock)
        def foo(self, _id):
            return _id
    class B(object):
        _lock_attr = threading.Lock()
        @lock_decorator(attr='_lock_attr')
        def foo(self, _id):
            return _id
    a = A()
    assert a.foo(1) == 1
    b = B()
    assert b.foo(1) == 1



# Generated at 2022-06-11 18:25:04.995964
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class m(object):
        def __init__(self):
            self.lock = threading.RLock()
        @lock_decorator(attr='lock')
        def f(self):
            lock_decorator.lock_owned.append(self.lock)
        def g(self):
            lock_decorator.lock_owned.append(self.lock)
        f = lock_decorator(attr='lock')(f)

    lock_decorator.lock_owned = []
    n = 100
    m.lock.acquire()
    threads = []
    for i in range(n):
        t = threading.Thread(target=m().f)
        threads.append(t)
        t.start()
    m.lock.release()

# Generated at 2022-06-11 18:25:16.224490
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread
    from time import sleep
    import random

    class MyClass:
        def __init__(self):
            self.data = 0
            self.total = 0
            self.mylock = 'init'

        @lock_decorator(attr='mylock')
        def my_method(self):
            sleep(random.random() / 100.0)
            self.data += 1
            sleep(random.random() / 100.0)
            self.data -= 1
            return self.data

        @lock_decorator(attr='mylock')
        def total_method(self):
            self.total += 1
            return self.total

    m = MyClass()
    m.mylock = Thread.LockType()

    threads = []

# Generated at 2022-06-11 18:25:25.475607
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    class TestDecorator(object):
        def __init__(self):
            self._lock = threading.RLock()

        @lock_decorator(attr='_lock')
        def fake_method(self):
            time.sleep(3)
            return 'Fake method ran'

    class TestDecorator2(object):
        def __init__(self):
            self._lock = threading.RLock()
            self._lock2 = threading.RLock()

        @lock_decorator(attr='_lock')
        def fake_method(self):
            time.sleep(3)
            return 'Fake method ran'


# Generated at 2022-06-11 18:25:40.493009
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class A(object):
        @lock_decorator(attr='_lock')
        def f(self, x, y=1):
            return x + y

    class B(object):
        lock = lock_decorator(lock=threading.Lock())

        @lock
        def f(self, x, y=1):
            return x + y

    a = A()
    a._lock = threading.Lock()
    b = B()

    for i in range(100):
        assert a.f(1) == 2
        assert b.f(2) == 3

if __name__ == '__main__':
    print('Running unit tests for lock_decorator')
    test_lock_decorator()
    print('Finished unit tests for lock_decorator')

# Generated at 2022-06-11 18:25:50.885296
# Unit test for function lock_decorator
def test_lock_decorator():
    # Run above tests in a separate process with
    # pytest -k test_lock_decorator
    import multiprocessing
    import sys
    import threading
    from unittest import TestCase

    class Test(TestCase):
        def test(self, lock=None):
            lock_decorator(lock=lock)

            _lock = threading.Lock()

            @lock_decorator(lock=lock)
            def with_lock():
                self.assertTrue(_lock.locked())
                with lock_decorator(lock=lock)(lambda: self.assertTrue(_lock.locked())):
                    self.assertTrue(_lock.locked())
                self.assertTrue(_lock.locked())

            self.assertFalse(_lock.locked())
            with _lock:
                self.assertTrue(_lock.locked())

# Generated at 2022-06-11 18:26:01.504752
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class FakeClass(object):
        def __init__(self, msg):
            self._msg = msg

        @lock_decorator(attr='_lock')
        def method(self):
            print(self._msg)

    # Lock is None
    f = FakeClass('test')
    try:
        f.method()
    except AttributeError:
        pass
    else:
        assert False

    # Lock is not instance of threading.Lock
    f = FakeClass('test')
    f._lock = object()
    try:
        f.method()
    except AttributeError:
        pass
    else:
        assert False

    # Test is successful
    fake_lock = threading.Lock()
    f = FakeClass('test')
    f._lock = fake_lock
    f.method

# Generated at 2022-06-11 18:26:11.182876
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from unittest import mock
    except ImportError:
        import mock
    import threading
    # verify that lock_decorator decorate method with lock
    # and this lock is called with context manager syntax
    with mock.patch.object(threading.Lock, '__enter__') as mock_lock:
        @lock_decorator(lock=threading.Lock())
        def some_method(a, b):  # pylint: disable=unused-argument
            return True
        assert some_method(1, 2)
        assert mock_lock.called
    # verify that lock_decorator decorate method with lock
    # and this lock is called with context manager syntax
    class MyClass(object):
        def __init__(self, a, b):
            self._lock = threading.Lock()


# Generated at 2022-06-11 18:26:18.655853
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    class ThreadedTest(unittest.TestCase):
        def setUp(self):
            class LockChecker(object):
                def __init__(self):
                    self.counter = 0
                    self.has_lock = False
                    self._lock = threading.Lock()

                @lock_decorator(attr='_lock')
                def increment_counter(self):
                    counter_value = self.counter
                    self.has_lock = True
                    try:
                        self.counter += 1
                    except ValueError:
                        pass
                    finally:
                        self.has_lock = False
                    return counter_value

            self.lockchecker = LockChecker()

        def test_lock_context_manager(self):
            self.assertTrue(self.lockchecker.has_lock)

# Generated at 2022-06-11 18:26:22.583857
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    _dict = {
        'foo': 1,
    }

    _lock = threading.Lock()

    def run_thread(num):
        time.sleep(1)
        print('Thread %d Starting' % num)
        with _lock:
            print('Thread %d has a lock' % num)
            time.sleep(1)
            print('Thread %d has updated the dict' % num)
            _dict['foo'] = num
        print('Thread %d has released the lock' % num)

    class MyClass:
        def __init__(self):
            self._callback_lock = threading.Lock()
            self._dict = {
                'foo': 3,
            }


# Generated at 2022-06-11 18:26:29.999757
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test the lock_decorator function
    '''
    import threading
    import time

    class TestLock(object):
        '''A simple TestLock class
        '''
        def __init__(self):
            # Create the thread lock
            self._callback_lock = threading.Lock()
            self.cb_counter = 0

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            # Increment the counter when a callback is called
            self.cb_counter += 1

    def thread_function(test_lock):
        # Call the callback 100 times
        for _ in range(100):
            test_lock.send_callback()


# Generated at 2022-06-11 18:26:36.194202
# Unit test for function lock_decorator
def test_lock_decorator():
    # Simple test for python3 compatibility
    import sys
    if sys.version_info >= (3,):
        func_name = '__wrapped__'
    else:
        func_name = 'func_name'

    @lock_decorator()
    def test_func():
        return

    assert getattr(test_func, func_name) == 'test_func'

# Generated at 2022-06-11 18:26:45.114615
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLockDecorator(object):
        def __init__(self):
            self.lock = False

        @lock_decorator(attr='lock')
        def _run_once_locked(self):
            if self.lock:
                raise Exception('Lock failed')
            self.lock = True

        @lock_decorator(lock=True)
        def _run_once_locked_nested(self):
            if self.lock:
                raise Exception('Lock failed')

        @lock_decorator(attr='missing_lock_attr')
        def _run_once_locked_missing_attr(self):
            if self.lock:
                raise Exception('Lock failed')
            self.lock = True

        def run_tests(self):
            self._run_once_locked()
            self._run_once_locked

# Generated at 2022-06-11 18:26:55.967664
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestLock(threading.Thread):
        '''Class to test lock_decorator lock'''
        def __init__(self, lock, count, name=''):
            super(TestLock, self).__init__(name=name)
            self.lock = lock
            self.count = count

        def run(self):
            for _ in range(self.count):
                with self.lock:
                    print('Start sleep for thread:', self.name)
                    time.sleep(2)
                    print('End sleep for thread:', self.name)

    my_lock = threading.Lock()
    my_thread1 = TestLock(my_lock, 5, name='my_thread1')

# Generated at 2022-06-11 18:27:21.593758
# Unit test for function lock_decorator
def test_lock_decorator():
    # pylint: disable=missing-docstring
    # pylint: disable=no-self-use
    import threading
    # pylint: disable=W0612
    @lock_decorator(attr='_lock')
    def method_one(self, number):
        return number

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def method_two(self, number):
            return number

    foo = Foo()
    assert 1 == foo.method_one(1)
    assert 2 == foo.method_two(2)

# Generated at 2022-06-11 18:27:31.939285
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    # make a lock
    lock = threading.Lock()

    # a class with a method using this lock
    class Foo(object):
        def __init__(self):
            self.x = 0

        @lock_decorator(lock=lock)
        def increment(self, x):
            self.x += x

    # create an instance of the class
    foo = Foo()
    # create multiple threads that will increment the value of x
    threads = [
        threading.Thread(target=Foo.increment, args=(foo, 1)) for _ in range(1000)
    ]
    # start all threads
    for thread in threads:
        thread.start()
    # wait for all threads to finish
    for thread in threads:
        thread.join()
    # the value of x should

# Generated at 2022-06-11 18:27:39.624556
# Unit test for function lock_decorator

# Generated at 2022-06-11 18:27:50.344973
# Unit test for function lock_decorator
def test_lock_decorator():
    # For this test, we use a mock of threading.Lock()
    import mock
    import six

    lock_mock = mock.Mock()

    # We use a class to make it easier to define a method
    # that uses ``attr``
    class A(object):
        @lock_decorator(lock=lock_mock)
        def decorated_method1(self):
            return '1'

        @lock_decorator(attr='_lock')
        def decorated_method2(self):
            return '2'

    a = A()

    # Set our class attribute for ``attr``
    a._lock = lock_mock

    # Call the decorated methods
    assert a.decorated_method1() == '1'
    assert a.decorated_method2() == '2'

    # Check that

# Generated at 2022-06-11 18:27:55.585315
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def bar(self):
            return True
    foo = Foo()
    # bar should only be able to be called while _lock is not acquired
    assert foo.bar()


if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-11 18:28:01.998357
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import unittest2 as unittest

    class Dummy(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator(attr='_lock')
        def foo(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def bar(self):
            self.counter -= 1

    class DummyTest(unittest.TestCase):
        def test_attribute(self):
            d = Dummy()
            d.foo()
            self.assertEqual(d.counter, 1)

        def test_passed(self):
            d = Dummy()
            d.bar()
            self.assertEqual(d.counter, -1)

    un

# Generated at 2022-06-11 18:28:11.652113
# Unit test for function lock_decorator
def test_lock_decorator():

    import sys
    import threading

    from ansible.module_utils._text import to_bytes

    if not sys.version_info[0] == 2:
        # Can't test
        return

    class TestClass(object):
        def __init__(self, myarg):
            self.my_object = myarg
            self.inner_method_called = False
            self.inner_method_called_with_args = (None, None)
            self.condition = threading.Condition(threading.Lock())

        @lock_decorator(attr='inner_method_called')
        def inner_method(self, arg1, arg2):
            with self.condition:
                self.inner_method_called = True
                self.inner_method_called_with_args = (arg1, arg2)
                self.condition

# Generated at 2022-06-11 18:28:21.441589
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Unit test for function lock_decorator
    '''
    import threading
    class TestLockDecorator(object):
        '''
        Test class for lock_decorator
        '''
        def __init__(self):
            '''
            Creates a new TestLockDecorator object
            '''
            self.val = 0
            # Creates the lock as a class attribute
            self._lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def add(self):
            '''
            Increases the value by 1
            '''
            self.val += 1
        @lock_decorator(lock=threading.Lock())
        def sub(self, number=1):
            '''
            Decreases the value by the number
            '''
           

# Generated at 2022-06-11 18:28:31.235656
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    lock._counter = 0

    @lock_decorator('_counter')
    def counter_incr(value):
        lock._counter += value

    @lock_decorator(lock=lock)
    def counter_decr(value):
        lock._counter -= value

    thread1 = threading.Thread(target=counter_incr, args=(1,))
    thread2 = threading.Thread(target=counter_decr, args=(1,))

    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()

    assert lock._counter == 0

# Generated at 2022-06-11 18:28:42.535593
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test the lock decorator'''
    import copy
    import threading
    # Test using class instance
    lock = threading.Lock()
    class TestClass(object):
        '''Test class for lock decorator'''
        def __init__(self):
            self.test_list = list()
            self.test_list_lock = lock
        @lock_decorator(attr='test_list_lock', lock=None)
        def add_to_test_list(self, value):
            '''Add values to test_list'''
            self.test_list.append(value)
            return self.test_list

# Generated at 2022-06-11 18:29:29.218062
# Unit test for function lock_decorator
def test_lock_decorator():
    
    import threading
    import time
    _lock = threading.Lock()

    class TestClass(object):
        __lock = threading.Lock()

        @lock_decorator(attr='__lock')
        def some_method(self):
            time.sleep(1)

        @lock_decorator(attr='_TestClass__lock')
        def some_method_1(self):
            time.sleep(1)

        @lock_decorator(lock=_lock)
        def some_method_2(self):
            time.sleep(1)

    # should all have the same time (1 + 0.1)
    tc = TestClass()
    t0 = time.time()
    for _ in range(2):
        tc.some_method()
    t1 = time.time() - t0

# Generated at 2022-06-11 18:29:39.784891
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()
    l = []
    class A(object):
        def __init__(self, lock):
            self._lock = lock
        @lock_decorator(attr='_lock')
        def sync_append(self, *args):
            l.append(*args)
        @staticmethod
        @lock_decorator(lock=_lock)
        def static_append(*args):
            l.append(*args)
    for i in range(10):
        t = threading.Thread(target=A(lock=_lock).sync_append,
                             args=(i,))
        t.start()
    for i in range(10):
        t = threading.Thread(target=A.static_append,
                             args=(i,))
        t.start()

# Generated at 2022-06-11 18:29:48.748588
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random

    class Task:
        def __init__(self):
            self.lock = threading.Lock()

        def do_work(self, delay=0.05):
            time.sleep(delay)
            print("Task Finished")

        @lock_decorator(lock=self.lock)
        def do_work_decorated(self, delay=0.05):
            time.sleep(delay)
            print("Task Finished")

    def run_task(delay=0.05):
        task = Task()
        task.do_work(delay)
        task.do_work_decorated(delay)


# Generated at 2022-06-11 18:29:52.751841
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class DummyClass(object):
        @lock_decorator(attr='_lock')
        def method1(self):
            pass

        @lock_decorator(lock=threading.Lock())
        def method2(self):
            pass

    obj = DummyClass()

# Generated at 2022-06-11 18:30:03.127816
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from threading import Thread
    from time import sleep

    class Foo(object):
        def __init__(self):
            # Instance attribute used for lock
            self._lock = threading.Lock()
            self.list = []

        @lock_decorator(attr='_lock')
        def lock_method(self, i):
            sleep(1)
            self.list.append(i)

        @lock_decorator(lock=threading.Lock())
        def lock_method2(self, i):
            sleep(1)
            self.list.append(i)

    foo = Foo()
    threads = [Thread(target=foo.lock_method, args=(i,)) for i in range(100)]

# Generated at 2022-06-11 18:30:11.204069
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import threading
    class LockedClass(object):

        def __init__(self):
            self._callback_lock = threading.Lock()

        def set_to_one(self):
            self.val = 1

        @lock_decorator(attr='_callback_lock')
        def set_to_two(self):
            self.val = 2

    obj_a0 = LockedClass()
    obj_a1 = LockedClass()

    class LockedClass():

        @lock_decorator(lock=threading.Lock())
        def set_to_three(self):
            self.val = 3

    obj_b = LockedClass()


# Generated at 2022-06-11 18:30:20.019562
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading  # noqa
    class Test(object):
        def __init__(self):
            self.counter = 0
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def incr(self):
            self.counter += 1

        @lock_decorator(lock=threading.Lock())
        def decr(self):
            self.counter -= 1

    t = Test()
    from concurrent.futures import ThreadPoolExecutor  # local-import
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_list = [executor.submit(t.incr) for i in range(100)]
        future_list = [executor.submit(t.decr) for i in range(100)]

# Generated at 2022-06-11 18:30:27.269150
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator()
        def test_lock(self, num):
            return num

    import pytest
    @pytest.mark.asyncio
    async def test():
        t = Test()
        assert await t.test_lock(1) == 1
        t._lock = threading.Lock()
        assert await t.test_lock(1) == 1

    test()

# Generated at 2022-06-11 18:30:37.544927
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Foo(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def bump_counter(self):
            self._counter += 1

    class Bar(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(lock=self._lock)
        def bump_counter(self):
            self._counter += 1

    class BrokenBar(object):
        def __init__(self):
            self._counter = 0

        @lock_decorator(lock=self._lock)
        def bump_counter(self):
            self._counter += 1

    foo_obj = Foo()
    bar

# Generated at 2022-06-11 18:30:44.196044
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()

    @lock_decorator(lock=_lock)
    def some_method(foo, bar, *args, **kwargs):
        print('foo={} bar={} args={} kwargs={}'.format(foo, bar, args, kwargs))

    @lock_decorator(attr='_callback_lock')
    def send_callback(self, *args, **kwargs):
        print('args={} kwargs={}'.format(args, kwargs))

    class TestModule(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        def send_callback(self, *args, **kwargs):
            return send_callback(self, *args, **kwargs)

    test = TestModule()