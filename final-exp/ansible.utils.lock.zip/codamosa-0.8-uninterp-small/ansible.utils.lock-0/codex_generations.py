

# Generated at 2022-06-25 13:24:09.810232
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = """This decorator is a generic implementation that allows you
    to either use a pre-defined instance attribute as the location
    of the lock, or to explicitly pass a lock object.

    This code was implemented with ``threading.Lock`` in mind, but
    may work with other locks, assuming that they function as
    context managers.

    When using ``attr``, the assumption is the first argument to
    the wrapped method, is ``self`` or ``cls``.

    Examples:

        @lock_decorator(attr='_callback_lock')
        def send_callback(...):

        @lock_decorator(lock=threading.Lock())
        def some_method(...):
    """
    assert var_1==lock_decorator.__doc__


# Generated at 2022-06-25 13:24:14.002613
# Unit test for function lock_decorator
def test_lock_decorator():
    import ansible_collections.notmintest.not_a_real_collection.plugins.action.test_actions
    a = ansible_collections.notmintest.not_a_real_collection.plugins.action.test_actions.TestActionModule()
    a.function_async(1)

# Generated at 2022-06-25 13:24:17.403629
# Unit test for function lock_decorator
def test_lock_decorator():
    from pyparsing import ParseException
    # Fail when trying to use lock_decorator without any parameters
    with pytest.raises(ParseException):
        test_case_0()



# Generated at 2022-06-25 13:24:20.438594
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test function lock_decorator
    print('')
    print('Test start:')
    test_case_0()
    # Test case for lock_decorator
    print('')
    print('Test end:')

# Generated at 2022-06-25 13:24:22.090692
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(attr='missing_lock_attr', lock=None)
    pass

# Generated at 2022-06-25 13:24:24.584326
# Unit test for function lock_decorator
def test_lock_decorator():
    assert test_lock_decorator.__name__ == 'test_lock_decorator'
    assert lock_decorator.__name__ == 'lock_decorator'

# Generated at 2022-06-25 13:24:25.173493
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:33.318360
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator().__name__ == 'outer', \
           "observed: " + lock_decorator().__name__

# Generated at 2022-06-25 13:24:33.978446
# Unit test for function lock_decorator
def test_lock_decorator():
    pass


# Generated at 2022-06-25 13:24:34.926171
# Unit test for function lock_decorator
def test_lock_decorator():
    assert type(lock_decorator()) == function


# Generated at 2022-06-25 13:24:40.823217
# Unit test for function lock_decorator
def test_lock_decorator():
    # These should pass:
    test_case_0()

    # These should fail:
    # test_case_1()
    pass


if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:24:49.712984
# Unit test for function lock_decorator
def test_lock_decorator():
  assert callable(lock_decorator)
  # Test docstring for lock_decorator

# Generated at 2022-06-25 13:24:53.475925
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

if __name__ == "__main__":
    import sys
    import doctest
    if doctest.testmod(
            optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
            ).failed == 0:
        sys.exit(0)
    sys.exit(1)

# Generated at 2022-06-25 13:25:00.188999
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator(attr=None)
    assert lock_decorator(attr=None, lock=None)
    assert lock_decorator(attr=None, lock=None, func=None)
    assert lock_decorator(attr=None, lock=None, func=None, __class__=None)
    assert lock_decorator(attr=None, lock=None, func=None, __class__=None, __delattr__=None)



# Generated at 2022-06-25 13:25:00.944625
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator) or True


# Generated at 2022-06-25 13:25:06.037680
# Unit test for function lock_decorator
def test_lock_decorator():
    for test_case_index in range(0, 1):
        test_case = test_case_0
        try:
            test_case()
        except AssertionError as e:
            print('AssertionError raised in test {}: {}'.format(test_case_index, e.message))

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:25:09.283019
# Unit test for function lock_decorator
def test_lock_decorator():
    list = (1, 2, 3, 4, 5)

    import random
    random.shuffle(list)

    assert list == [1, 2, 3, 4, 5], "Assignment 5 failed."

# Generated at 2022-06-25 13:25:18.661640
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import threading
    except ImportError:
        assert False, 'Unable to import the threading library'
    lock = threading.Lock()
    var = 'a'
    @lock_decorator(attr='test_lock_attr', lock=lock)
    def test_decorator_0():
        # This should be thread-safe
        global var
        var += 'b'
    @lock_decorator(attr='test_lock_attr', lock=lock)
    def test_decorator_1():
        # This should be thread-safe
        global var
        var += 'c'
    @lock_decorator(attr='test_lock_attr', lock=lock)
    def test_decorator_2():
        # This should be thread-safe
        global var

# Generated at 2022-06-25 13:25:20.263926
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()(lambda : None )



# Generated at 2022-06-25 13:25:21.911002
# Unit test for function lock_decorator
def test_lock_decorator():
    # Ensure the function returns a function
    assert callable(lock_decorator('missing_lock_attr', None))

# Generated at 2022-06-25 13:25:33.708746
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansibullbot.decorators.lock_decorator import lock_decorator
    func_0 = lock_decorator(attr='')
    ansible_module_0 = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', choices=['absent', 'present'], required=False),
            dependencies=dict(type='list', elements='str', required=False),
            force=dict(type='bool', required=False, default=False),
            executable=dict(type='str', required=False, default='/usr/sbin/grpck'),
            name=dict(type='str', required=True),
            description=dict(type='str', required=False)
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-25 13:25:35.829781
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator(attr='attr')
    assert isinstance(var_0, type(test_case_0))



# Generated at 2022-06-25 13:25:38.115071
# Unit test for function lock_decorator
def test_lock_decorator():
    # See: https://docs.pytest.org/en/latest/xunit_setup.html
    # test_case_0()
    pass

# Generated at 2022-06-25 13:25:47.706856
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading

    class A(object):

        def __init__(self):
            self._lock = threading.Lock()
            self._attr = None
            self.call_list = []

        def func_0(self):
            with self._lock:
                self.call_list.append('func_0')

        func_1 = lock_decorator(attr='_lock')(func_0)

        def func_2(self):
            with self._lock:
                self.call_list.append('func_2')

        @lock_decorator(lock=threading.Lock())
        def func_3(self):
            self.call_list.append('func_3')

        lock = threading.Lock()

# Generated at 2022-06-25 13:25:49.227374
# Unit test for function lock_decorator
def test_lock_decorator():
    # Add code to test lock_decorator here
    assert True == False  # Remove this line after implementating test

# Generated at 2022-06-25 13:25:49.926509
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:25:50.519683
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:51.320327
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:25:53.995352
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.sivel_ansible_2020 import lock_decorator

    assert lock_decorator.__name__ == 'lock_decorator'
    assert lock_decorator.__doc__ is not None



# Generated at 2022-06-25 13:26:04.209902
# Unit test for function lock_decorator
def test_lock_decorator():
    # lock_decorator(attr='missing_lock_attr', lock=None)
    not_invoked_lock_decorator = lock_decorator(attr=None, lock=None)

    # lock_decorator(attr='missing_lock_attr', lock=None)
    not_invoked_lock_decorator = lock_decorator(attr=None, lock=None)

    # lock_decorator(attr='missing_lock_attr', lock=None)
    not_invoked_lock_decorator = lock_decorator(attr=None, lock=None)

    # lock_decorator(attr='missing_lock_attr', lock=None)
    not_invoked_lock_decorator = lock_decorator(attr=None, lock=None)

    # lock_decorator

# Generated at 2022-06-25 13:26:13.706966
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:26:22.624939
# Unit test for function lock_decorator
def test_lock_decorator():

    class Foo(object):

        def __init__(self, lock=None):
            self.lock = lock
            self.value = 0

        @lock_decorator(attr='lock')
        def add(self, x):
            self.value += x
            return self.value

        @classmethod
        @lock_decorator(attr='lock')
        def class_add(cls, x):
            cls.class_value += x
            return cls.class_value

    assert Foo(lock=threading.Lock()).add(1) == 1
    assert Foo(lock=threading.RLock()).add(2) == 2
    class_lock = threading.Lock()
    Foo.class_value = 0
    assert Foo.class_add(lock=class_lock, x=10) == 10
   

# Generated at 2022-06-25 13:26:24.043345
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule

    with AnsibleModule() as module:
        pass

# Generated at 2022-06-25 13:26:26.665330
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(lock=None) is not None
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not None

# Generated at 2022-06-25 13:26:37.274974
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    # Test direct passing of lock object
    func_0 = lock_decorator(lock=threading.RLock())(lambda: 'a')
    assert func_0() == 'a'
    var_1 = 0
    var_2 = threading.Lock()
    @lock_decorator(lock=var_2)
    def func_1():
        func_0()
        var_1
    # Test passing attribute name to hold lock object
    class Class_0:
        _lock = threading.RLock()

        @lock_decorator()
        def func_2(self):
            func_0()
            var_1

    obj_0 = Class_0()
    obj_0.func_2()

# Generated at 2022-06-25 13:26:38.936276
# Unit test for function lock_decorator
def test_lock_decorator():
    # Unit:test_lock_decorator:test_case_0
    assert True
test_case_0()

# Generated at 2022-06-25 13:26:47.554597
# Unit test for function lock_decorator
def test_lock_decorator():
    import logging
    import tempfile
    from textwrap import dedent
    from ansible.module_utils.facts import FACT_CACHE
    from ansible.module_utils.facts.facts import get_filesystem_info


# Generated at 2022-06-25 13:26:53.804898
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading


    class TestClass(object):
        def __init__(self):
            self._lock_callback_lock = threading.Lock()


        @lock_decorator(attr='_lock_callback_lock')
        def callback(self):
            self._callback_executed = True
            # Do something potentially dangerous


    test_obj = TestClass()
    test_obj.callback()
    assert test_obj._callback_executed


    @lock_decorator(lock=threading.Lock())
    def some_other_method():
        pass

# Generated at 2022-06-25 13:27:02.511659
# Unit test for function lock_decorator
def test_lock_decorator():

    def func_0(a):
        return a

    def func_1(a, b):
        return a, b

    def func_2(a, b, c):
        return a, b, c

    class Class_0:
        @lock_decorator()
        def func_2(self, a, b, c):
            return a, b, c

    class Class_1:
        @lock_decorator(attr='lock_0')
        def func_0(self, a):
            return a

        @lock_decorator(attr='lock_1')
        def func_1(self, a, b):
            return a, b

        @lock_decorator(attr='lock_2')
        def func_2(self, a, b, c):
            return a, b, c



# Generated at 2022-06-25 13:27:12.147877
# Unit test for function lock_decorator
def test_lock_decorator():

    # test cases with var_0 = lock_decorator()
    var_0 = lock_decorator()
    assert var_0('attr') == 'missing_lock_attr'

    # test cases with var_0 = lock_decorator(attr='missing_lock_attr')
    var_0 = lock_decorator(attr='missing_lock_attr')
    assert var_0() == None

    # test cases with var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert var_0() == None

    # test cases with var_0 = lock_decorator(lock=None)
    var_0 = lock_decorator(lock=None)
    assert var_

# Generated at 2022-06-25 13:27:29.956388
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:27:32.023201
# Unit test for function lock_decorator
def test_lock_decorator():
    opts = {'test_case': 0, 'msg': 'lock_decorator', 'decorator': True}
    yield opts

# Generated at 2022-06-25 13:27:33.677859
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()


if __name__ == "__main__":
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:27:35.554300
# Unit test for function lock_decorator
def test_lock_decorator():
    # Verify that lock_decorator works as expected
    var_0 = lock_decorator()
    assert var_0 == "Hello World" or var_0 == "Goodbye World"

# Generated at 2022-06-25 13:27:43.091381
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test module lock_decorator'''
    import unittest
    import sys
    import os
    import copy

    class RunTestCase(unittest.TestCase):
        """
        Setup class RunTestCase
        """
        # pylint: disable=too-many-instance-attributes
        # pylint: disable=attribute-defined-outside-init
        def setUp(self):
            '''Setup for test_lock_decorator'''
            self.testcase_var_0 = lock_decorator
            self.testcase_var_1 = lock_decorator
            self.testcase_var_2 = lock_decorator
            self.testcase_var_3 = lock_decorator
            self.testcase_var_4 = lock_decorator
            self.testcase

# Generated at 2022-06-25 13:27:46.642509
# Unit test for function lock_decorator
def test_lock_decorator():

    from ansible.module_utils.basic import AnsibleModule

    class MyModule(AnsibleModule):
        pass

    module = MyModule()

    @lock_decorator(attr='_test_lock')
    def test_function(mod):
        pass

    module.test_function()

# Generated at 2022-06-25 13:27:50.549588
# Unit test for function lock_decorator
def test_lock_decorator():
    """Test the lock_decorator function"""
    # test_case_0
    import mock
    var_0 = mock.Mock()
    var_1 = lock_decorator()
    assert var_1(var_0)("foo") == var_0.return_value
    var_0.assert_called_with("foo")

# Generated at 2022-06-25 13:27:52.005974
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:27:59.899049
# Unit test for function lock_decorator
def test_lock_decorator():
    import json
    import mock
    class Complex:
        def __init__(self, real, imag=0.0):
            self.real = real
            self.imag = imag

        def __add__(self, other):
            return Complex(self.real + other.real,
                           self.imag + other.imag)

        def __str__(self):
            return '(%g+%gj)' % (self.real, self.imag)

    @lock_decorator()
    def foo():
        return Complex(3,4)

    import json

# Generated at 2022-06-25 13:28:02.924027
# Unit test for function lock_decorator
def test_lock_decorator():
    # Mock function
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.test.test_lock_decorator import test_case_0
    # Call function
    lock_decorator(test_case_0)



# Generated at 2022-06-25 13:28:46.177860
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    doctest.testmod()

    assert lock_decorator is not None
    assert lock_decorator is not ''

    test_lock_decorator.__doc__

    test_lock_decorator.__doc__

    test_case_0()

# Generated at 2022-06-25 13:28:46.801972
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:56.007563
# Unit test for function lock_decorator
def test_lock_decorator():
    # --
    attr_0 = 'missing_lock_attr'
    var_0 = lock_decorator(attr=attr_0)
    assert attr_0 is var_0.__annotations__['attr']
    assert var_0.__annotations__['lock'] is None
    assert var_0.__annotations__['return'] is lock_decorator.__annotations__['return']
    var_1 = var_0(test_case_0)
    # --
    var_2 = lock_decorator(lock=test_case_0)
    assert var_2.__annotations__['attr'] is lock_decorator.__annotations__['attr']
    assert var_2.__annotations__['lock'] is test_case_0

# Generated at 2022-06-25 13:29:01.675264
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._value = None
            self._sleeping = False

        @lock_decorator(attr='_lock')
        def set_value(self, value):
            time.sleep(1)
            self._sleeping = True
            assert self._value is None
            self._value = value
            assert self._sleeping is True
            self._sleeping = False

    t = Test()
    t.set_value(1)
    assert t._value == 1

# Generated at 2022-06-25 13:29:02.039720
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:29:03.810129
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        test_case_0()
    except Exception:
        # Unit test exception was raised
        import traceback
        traceback.print_exc()
        assert False

# Unit test execution
if __name__ == "__main__":
    test_lock_decorator()

# Generated at 2022-06-25 13:29:04.157152
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:29:05.904012
# Unit test for function lock_decorator
def test_lock_decorator():
    # Call lock_decorator() and make sure it returns a function
    assert callable(lock_decorator())



# Generated at 2022-06-25 13:29:13.786684
# Unit test for function lock_decorator
def test_lock_decorator():
    from tempfile import TemporaryDirectory
    from shutil import copy2
    from datetime import timedelta
    from os import path
    from threading import Thread, Lock
    from socket import socket, AF_INET, SOCK_STREAM
    from time import sleep
    from subprocess import Popen, PIPE
    from signal import signal, SIGINT
    from random import randint
    from requests import get, exceptions
    from pyngrok import ngrok

    # create a random port to listen on
    # be sure to close the socket after all
    # testing is completed
    listen_port = randint(1024, 49151)
    socket = socket(AF_INET, SOCK_STREAM)

# Generated at 2022-06-25 13:29:15.032720
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()

    assert type(var_0) == type(lock_decorator)

# Generated at 2022-06-25 13:30:51.535714
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:30:53.360277
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError) as exc:
        test_case_0()
    assert "missing 1 required positional argument" in str(exc)

# Generated at 2022-06-25 13:31:00.731480
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    obj_0 = object()
    # Pass in ``obj_0`` as a key to a dict, which will be modified
    # by the decorated functions, and use a lock to make it thread-safe
    var_0 = {obj_0: 0}
    lock_0 = threading.Lock()
    lock_1 = threading.Lock()
    lock_2 = threading.Lock()
    @lock_decorator(lock=lock_0)
    def func_0(a):
        var_0[obj_0] += a
    @lock_decorator(lock=lock_1)
    def func_1(a):
        var_0[obj_0] *= a

# Generated at 2022-06-25 13:31:05.999209
# Unit test for function lock_decorator
def test_lock_decorator():
    # Python 2 and Python 3 provides different
    # error messages for this syntax error
    # we validate that the messages match
    # regardless of which is used
    try:
        test_case_0()
    except TypeError as exc:
        assert str(exc) in ('lock_decorator() missing 1 required positional argument: \'attr\'',
                            'lock_decorator() missing 1 required positional argument: \'attr\'',
                            'missing 1 required positional argument: \'attr\'')

# Generated at 2022-06-25 13:31:09.503478
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    # Test failure
    # assert var_0 == "test", "Expected 'test', got {0}".format(var_0)

# Run test
test_lock_decorator()


# Generated at 2022-06-25 13:31:09.981101
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:31:10.444998
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True

# Generated at 2022-06-25 13:31:18.112005
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import PY3

    with pytest.raises(TypeError) as exc_info:
        test_case_0()

    exception = exc_info.value
    assert exception.args[0] == 'lock_decorator() missing 1 required positional argument: \'func\''

    # Test for absence of a lock argument
    mod_args = dict(a=1, b=2, c=3)
    module = AnsibleModule(argument_spec=mod_args)

    exit_args = dict(
        failed=True,
        changed=False,
    )

    def the_function(self, *args, **kwargs):
        return

# Generated at 2022-06-25 13:31:19.105877
# Unit test for function lock_decorator
def test_lock_decorator():
    # Testing...
    assert True, "If we got here, the test passed"

# Generated at 2022-06-25 13:31:22.060588
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    var_1()
    var_2 = lock_decorator()
    var_2()
    var_3 = lock_decorator()
    var_3()
    var_4 = lock_decorator()
    var_4()