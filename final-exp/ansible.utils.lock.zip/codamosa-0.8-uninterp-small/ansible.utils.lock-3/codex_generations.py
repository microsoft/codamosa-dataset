

# Generated at 2022-06-25 13:24:07.504304
# Unit test for function lock_decorator
def test_lock_decorator():
    import tempfile

    _lock = None
    try:
        _lock = tempfile.NamedTemporaryFile()
        _lock_name = _lock.name
        del _lock

        _lock = tempfile.NamedTemporaryFile()
        var_0 = lock_decorator(attr=_lock.name)
    finally:
        if _lock is not None:
            try:
                _lock.close()
            except Exception:
                pass

# Generated at 2022-06-25 13:24:08.051397
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:10.475558
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


if __name__ == '__main__':
    print('Executing test cases...')
    test_lock_decorator()
    test_case_0()
    print('Done!')

# Generated at 2022-06-25 13:24:12.586392
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case for lock_decorator
    # Test for lock_decorator to check for missing lock
    pass


# Generated at 2022-06-25 13:24:19.731557
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a function with arguments: lock_decorator
    from functools import wraps
    def outer(func):
        @wraps(func)
        def inner(*args, **kwargs):
            # Python2 doesn't have ``nonlocal``
            # assign the actual lock to ``_lock``
            if lock is None:
                _lock = getattr(args[0], attr)
            else:
                _lock = lock
            with _lock:
                return func(*args, **kwargs)
        return inner
    return outer


# Generated at 2022-06-25 13:24:22.048334
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 is not None
    assert type(var_0) == outer
    return



# Generated at 2022-06-25 13:24:24.189471
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    # The following lines are used by doctest:
    var_0 = test_case_0()
    return doctest.testmod()

# Generated at 2022-06-25 13:24:26.574320
# Unit test for function lock_decorator
def test_lock_decorator():
    assert test_case_0() == None, "unit test for lock_decorator"

# Generated from the above unit test
lock_decorator = lock_decorator

# Generated at 2022-06-25 13:24:34.245874
# Unit test for function lock_decorator
def test_lock_decorator():
    # Fail if not using `lock_decorator` as decorator
    try:
        lock_decorator(lock_decorator)
    except TypeError:
        pass
    else:
        assert False, 'lock_decorator used as variable'

    # Fail if using lock_decorator without arguments
    try:
        @lock_decorator
        def function_0():
            pass
    except TypeError:
        pass
    else:
        assert False, 'lock_decorator used without arguments'

    # Pass if using lock_decorator with attribute
    try:
        @lock_decorator(attr='lock_example')
        def function_1():
            pass
    except TypeError:
        assert False, 'lock_decorator used with attribute'

    # Pass if using lock_decorator

# Generated at 2022-06-25 13:24:36.874158
# Unit test for function lock_decorator
def test_lock_decorator():

    # Get the function from the module
    func = get_test_module_attr('lock_decorator')

    # Check the function
    assert func is not None

    # Check that the function returns a function
    assert callable(func)

    # Call the function
    result = func()

    # Check the result
    assert isinstance(result, Callable)

# Generated at 2022-06-25 13:24:47.123947
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import Runner, RulesCollection
    from ansiblelint.rules.LockDecoratorRule import LockDecoratorRule

    ruleset = RulesCollection()
    ruleset.register(LockDecoratorRule())

    success = 'test/lock-decorator-success.yml'
    failure = 'test/lock-decorator-failure.yml'

    good_runner = Runner(ruleset, success, [], [], [])
    res = good_runner.run()
    assert (res == 0)

    bad_runner = Runner(ruleset, failure, [], [], [])
    res = bad_runner.run()
    assert (res == 2)

# Generated at 2022-06-25 13:24:47.672071
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:55.289247
# Unit test for function lock_decorator
def test_lock_decorator():

    # Init
    import threading

    # We may need a lock to test our decorator that uses locks
    mylock = threading.Lock()

    # The following code is to ensure that the ``mylock`` lock is
    # currently not locked.  If we do not acquire and release the
    # lock around this code, then the lock may be left in an unlocked
    # state, which would cause any other code using the ``mylock`` lock
    # to fail.
    with mylock:
        test_lock = mylock.locked()

    # This block should be false
    if test_lock == True:
        raise Exception('%s already locked' % mylock)

    @lock_decorator(lock=mylock)
    def test_func(num, num2):
        return num + num2

    # This code should block until the running

# Generated at 2022-06-25 13:25:05.858505
# Unit test for function lock_decorator
def test_lock_decorator():

    # assert func.__name__ == 'inner'

    var_1 = lock_decorator()

    # assert callable(var_1)

    class Test(object):

        def __init__(self):
            self.var_0 = None

        def __call__(self, var_1):
            pass

        def __repr__(self):
            pass

        def __str__(self):
            pass

        def __get__(self, var_1, var_2):
            pass

        def __delete__(self, var_1):
            pass

    var_2 = Test()
    var_1(var_2)


    # assert var_1(var_2) is var_2

    def inner():
        pass

    def send_callback():
        pass


# Generated at 2022-06-25 13:25:06.775749
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True
    assert False
    assert False

# Generated at 2022-06-25 13:25:07.627820
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:08.520997
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:10.876231
# Unit test for function lock_decorator
def test_lock_decorator():
    obj = lock_decorator()
    assert isinstance(obj, lock_decorator)
    assert obj



# Generated at 2022-06-25 13:25:12.668278
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# vim:sw=4:ts=4:et:

# Generated at 2022-06-25 13:25:20.602570
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.sensu_go.common.decorators import SensuDecorator, lock_decorator

    class X(SensuDecorator):
        def __init__(self):
            self.attr = 'attr'
            self._lock = None

        def wrapped(self, *args, **kwargs):
            return True

    x = X()

    # Test lock_decorator with no attr or lock
    try:
        assert x.wrapped()
    except TypeError:
        pass

    # Test lock_decorator with attr only
    x.wrapped = lock_decorator(attr='attr')
    assert x.wrapped()

    # Test lock_decorator with lock only
    x.wrapped

# Generated at 2022-06-25 13:25:33.076455
# Unit test for function lock_decorator
def test_lock_decorator():
    # Fake class, just so we can pass it to the decorator
    class Foo(object):
        pass

    # Test that we can use a defined lock
    _lock = threading.Lock()
    foo = Foo()
    foo.lock = _lock
    foo.func = lock_decorator(attr='lock')(foo.func)
    with pytest.raises(AttributeError, message='expected a missing attribute'):
        foo.func()

    # If an exception occurs, ensure the lock is released
    def setup_1():
        class Foo(object):
            lock = threading.Lock()
            value = 0

            @lock_decorator(attr='lock')
            def func(self):
                self.value += 1
                return self.value

        return Foo()

    foo = setup_1()

# Generated at 2022-06-25 13:25:35.259251
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        var_0 = lock_decorator()
        assert var_0 == None
    except Exception as e:
        assert False



# Generated at 2022-06-25 13:25:37.218840
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True


# vim: set expandtab ts=4 sts=4 sw=4 ft=python:

# Generated at 2022-06-25 13:25:37.834753
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:39.179250
# Unit test for function lock_decorator
def test_lock_decorator():
    assert False, "No tests for function `lock_decorator` have been implemented"

# Generated at 2022-06-25 13:25:48.691917
# Unit test for function lock_decorator
def test_lock_decorator():

    # Create a Mock object
    _Mock = Mock()

    # Mock the function call
    mock_func = MagicMock()
    _Mock.func = mock_func
    lock_decorator(attr='attr')(_Mock.func)(_Mock)
    assert mock_func.called
    assert mock_func.called_with(_Mock)
    assert _Mock.called_with('_lock')
    mock_func.reset_mock()

    # Mock a class method call
    mock_func = MagicMock()
    _Mock.func = mock_func
    lock_decorator(lock='_lock')(_Mock.func)(_Mock)
    assert mock_func.called
    assert mock_func.called_with(_Mock)

# Generated at 2022-06-25 13:25:49.465998
# Unit test for function lock_decorator
def test_lock_decorator():
    # <Insert code here to test the function.>
    pass

# Generated at 2022-06-25 13:25:50.496421
# Unit test for function lock_decorator
def test_lock_decorator():
    assert test_case_0() == None, "lock_decorator() returned an error"

# Generated at 2022-06-25 13:25:51.735159
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test lock_decorator with arguments lock=None and attr='missing_lock_attr'
    test_case_0()

# Generated at 2022-06-25 13:26:00.839911
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    @lock_decorator(lock=threading.Lock())
    def f(x):
        return x.upper()
    f('yay')

    class T(object):
        @property
        def f(self):
            return self.v
        @f.setter
        @lock_decorator(attr='lock')
        def f(self, value):
            self.v = value
    t = T()
    t.lock = threading.Lock()
    t.f = 'yay'

    class T2(object):
        _lock = threading.Lock()
        def m(self):
            pass

        @classmethod
        def f(cls):
            pass

        @lock_decorator()
        def m2(self):
            pass


# Generated at 2022-06-25 13:26:18.035383
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile
    import sys

    # Setup test environment
    _, temp_path = tempfile.mkstemp()

    # Unit test the function
    lock_decorator(
        attr='_callback_lock_1',
        lock=None
    )
    lock_decorator(
        attr='_callback_lock_2',
        lock=None
    )
    lock_decorator(
        attr=None,
        lock=None
    )
    lock_decorator(
        attr=None,
        lock=None
    )

    # Cleanup test environment
    os.remove(temp_path)



# Generated at 2022-06-25 13:26:26.455399
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    @lock_decorator(attr='lock')
    def method(arg_0, arg_1, arg_2=None, arg_3=False):
        '''This is the docstring for method'''
        return (arg_0, arg_1, arg_2, arg_3)

    arg_0 = 'test'
    arg_1 = 123
    arg_2 = 'test_2'
    arg_3 = True

    class Test(object):
        def __init__(self):
            self.lock = mock.MagicMock()

    test = Test()

    method(test, arg_0, arg_1, arg_2=arg_2, arg_3=arg_3)
    test.lock.__enter__.assert_called_once_with()
    test.lock.__exit__

# Generated at 2022-06-25 13:26:31.046886
# Unit test for function lock_decorator
def test_lock_decorator():
    me = lock_decorator()
    assert me == 'success'


# @lock_decorator(attr='missing_lock_attr')
# def send_callback(...):
#
# @lock_decorator(lock=threading.Lock())
# def some_method(...):


# Generated at 2022-06-25 13:26:38.341490
# Unit test for function lock_decorator
def test_lock_decorator():
    @lock_decorator()
    def _foo(param_0, param_1):
        pass
    _foo('foo', 'bar')

    @lock_decorator(attr='foo_attr')
    def _foo_attr(param_0, param_1):
        pass
    _foo_attr('foo', 'bar')

    _lock_obj = True
    @lock_decorator(lock=_lock_obj)
    def _foo_obj(param_0, param_1):
        pass
    _foo_obj('foo', 'bar')

# Generated at 2022-06-25 13:26:46.074766
# Unit test for function lock_decorator
def test_lock_decorator():
    # First, we're going to define a class we can use
    # to test this decorator.
    class TestClass:
        # Use a lock (threading.Lock) as the attribute
        _attr_lock = None

        # Create the class with a new lock
        def __init__(self):
            self._attr_lock = threading.Lock()

        # this is the method we'll be decorating
        @lock_decorator(attr='_attr_lock')
        def do_something(self):
            return True

    # now create an instance we can use
    t = TestClass()

    # ensure it's working as expected
    assert t.do_something()
    # and again
    assert t.do_something()

# Generated at 2022-06-25 13:26:52.582396
# Unit test for function lock_decorator
def test_lock_decorator():
    # Set up test objects
    class TestClass(object):
        def __init__(self):
            self.func_attr = -1

        @lock_decorator(attr='func_attr')
        def test_func(self):
            self.func_attr = self.func_attr + 1

    # Test lock_decorator
    test_object = TestClass()
    if test_object.func_attr != -1:
        raise AssertionError("test_object.func_attr should be -1, got {0}".format(test_object.func_attr))
    test_object.test_func()
    if test_object.func_attr != 0:
        raise AssertionError("test_object.func_attr should be 0, got {0}".format(test_object.func_attr))
    test

# Generated at 2022-06-25 13:26:54.200712
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator), 'Function lock_decorator does not exist'



# Generated at 2022-06-25 13:27:02.861466
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from ansible.module_utils.six.moves import queue

    queue_0 = queue.Queue()

    class SomeClass(object):

        def __init__(self):
            # Use a real lock for testing
            self._lock = threading.Lock()
            self.counter = 0

        @lock_decorator(lock=self._lock)
        def some_method(self):
            self.counter += 1
            queue_0.put(self.counter)

        @lock_decorator(attr='_lock')
        def some_other_method(self):
            self.counter += 1
            queue_0.put(self.counter)

    # Create a class
    object_0 = SomeClass()
    # Use the class
    object_0.some_method()
    object_0.some

# Generated at 2022-06-25 13:27:08.347305
# Unit test for function lock_decorator
def test_lock_decorator():
    # Get the function definition and check it yields a function
    function = lock_decorator()
    assert function is not None

    # Define a variable and include it in the function definition
    var_0 = False
    def inner_0(var_0):
        assert var_0 == False
        var_0 = True
        assert var_0 == True

    # Call the function
    function(inner_0(var_0))

    # Check that the function works as expected
    assert var_0 == True

# Generated at 2022-06-25 13:27:09.713439
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:27:27.790514
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:27:32.530587
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={},
                      supports_check_mode=True)

    with patch.object(m.module, 'exit_json') as mock_exit_json:
        lock_decorator()(m.exit_json)(msg='test')
        mock_exit_json.assert_called_once_with(msg='test')

# Generated at 2022-06-25 13:27:40.437215
# Unit test for function lock_decorator
def test_lock_decorator():
    # Testing with a specific lock object

    # This lock object can be used anywhere in this test file
    lock_0 = None
    # This lock object is internal to the wrapped function
    lock_1 = None

    # Verify that the decorator is calling the lock correctly

    # The wrapped function takes two arguments, one of which
    # is used for the lock.
    #
    # We will use the lock_0 instance
    @lock_decorator(lock=lock_0)
    def test_case_1(lock_obj, value):
        # Set lock_1 to the lock object passed to function
        nonlocal lock_1
        # Check that the passed lock object is the correct
        # object (lock_0)
        assert lock_obj is lock_0
        lock_1 = lock_obj
        return value

    # Run the wrapped function

# Generated at 2022-06-25 13:27:45.418840
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import threading

    # Global vars
    var_0 = lock_decorator()
    var_1 = lock_decorator(attr='missing_lock_attr', lock=None)
    var_2 = lock_decorator(attr='missing_lock_attr')
    var_3 = lock_decorator(lock=None)
    var_4 = lock_decorator(lock=threading.RLock())

    # Test for raising exception
    # proper invocation of the decorator
    pass

# Generated at 2022-06-25 13:27:47.035870
# Unit test for function lock_decorator
def test_lock_decorator():
    assert isinstance(lock_decorator(), 'lock_decorator')


# Generated at 2022-06-25 13:27:47.514316
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:27:54.222745
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule

    args = dict(
        attr='_callback_lock',
        lock=None
    )

    module = AnsibleModule(
        argument_spec=dict(
            attr=dict(type='str', default='missing_lock_attr'),
            lock=dict(type='dict', default=None)
        )
    )

    module.exit_json(**args)


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:28:02.129175
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.UseLockDecorator import UseLockDecorator

    collection = RulesCollection()
    collection.register(UseLockDecorator())

    success = 'ansiblelint.rules.UseLockDecorator.UseLockDecorator'

    good_1 = '''
        from ansiblelint.rules.UseLockDecorator import lock_decorator
        @lock_decorator(lock=threading.Lock())
        def some_method():
    '''

    bad_1 = '''
        def some_method():
            ...
            lock.acquire()
            ...
            lock.release()
    '''

# Generated at 2022-06-25 13:28:02.923947
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:28:03.407934
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:28:45.799751
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1 == 1


# Code coverage for function lock_decorator

# Generated at 2022-06-25 13:28:55.239825
# Unit test for function lock_decorator
def test_lock_decorator():
    # 1st simple test
    var = lock_decorator(attr='_callback_lock')

    # working test
    var = lock_decorator()
    var.__name__ = 'working'
    var.__annotations__ = {'attr': '_callback_lock'}
    var.__get__(None, None)

    # 2nd working test
    var = lock_decorator()
    var.__name__ = 'working'
    var.__annotations__ = None
    var.__get__(None, None)

    # working test
    class DummyClass():
        def __init__(self):
            self.attr = '_callback_lock'
        def working(self):
            pass
    var = lock_decorator()
    var.__name__ = 'working'

# Generated at 2022-06-25 13:29:00.167541
# Unit test for function lock_decorator
def test_lock_decorator():

    # Check that non-existing lock attr causes an exception
    try:
        lock_decorator()
    except Exception as exception_instance:
        assert type(exception_instance) == AttributeError

    # Check that a valid lock object results in a valid lock
    import threading
    lock = lock_decorator(lock=threading.Lock())
    assert isinstance(lock, threading.Lock)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 13:29:03.397732
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        pass
    except (UnboundLocalError, NameError, TypeError):
        pass
    except Exception as exc:
        print(exc)
        fail('lock_decorator: did not expect to catch this exception')


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:29:08.717748
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator.__doc__ is not None
    try:
        test_case_0()
    except Exception:
        assert False, 'An exception occurred'
    assert True



# Create a module that can be run independently of any other
# code, for example via the command ``python test_lock_decorator.py``.
# Every function that starts with the name ``test_`` will be run
# as a unit test.
if __name__ == '__main__':
    locals()[sys.argv[1]]()

# Generated at 2022-06-25 13:29:12.210645
# Unit test for function lock_decorator
def test_lock_decorator():

    # Case 0: Run the function lock_decorator to see if this fails with any assertion errors
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError: ' + str(e))


if __name__ == '__main__':

    # Run unit tests
    test_lock_decorator()

# Generated at 2022-06-25 13:29:14.706922
# Unit test for function lock_decorator

# Generated at 2022-06-25 13:29:22.597505
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestClass:
        def __init__(self):
            self.lock_decorator_lock = False
            self.lock_decorator_call = False

        @lock_decorator(attr='lock_decorator_lock')
        def lock_decorator_method(self, raise_exc=False):
            assert not self.lock_decorator_lock
            self.lock_decorator_lock = True
            try:
                assert self.lock_decorator_lock
                assert not self.lock_decorator_call
                self.lock_decorator_call = True

                if raise_exc:
                    raise Exception('An exception was raised')
            finally:
                self.lock_decorator_lock = False
                assert not self.lock_decorator_lock

    t = TestClass

# Generated at 2022-06-25 13:29:23.009534
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:29:23.698587
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True



# Generated at 2022-06-25 13:31:04.344449
# Unit test for function lock_decorator
def test_lock_decorator():
    # String to use for testing, if needed
    test_string = ''
    # Assert that a lock_decorator object is created correctly
    var_0 = lock_decorator()
    assert var_0 is not None


# Generated at 2022-06-25 13:31:05.425561
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:31:13.248927
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile
    fd, path = tempfile.mkstemp()
    try:
        with os.fdopen(fd, 'w') as tmp:
            tmp.write('foo')

        sz = os.stat(path).st_size
        assert sz == 3, sz

        # Setup - create lock_decorator instance
        _lock_decorator = lock_decorator(attr='_lock')
        # Verify idempotent
        assert _lock_decorator is lock_decorator
        # Verify we can evaluate
        assert not False
        # Teardown - remove lock_decorator instance
        del _lock_decorator
    finally:
        os.remove(path)

# Generated at 2022-06-25 13:31:14.274560
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator() is not None

# Generated at 2022-06-25 13:31:21.372296
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLockDecorator(object):
        def __init__(self, lock=None):
            self.lock = lock
            self.value = 0

        @lock_decorator(attr='lock')
        def method_0(self, value):
            var_0 = self.value, value
            self.value += 1
            return var_0, self.value

        @staticmethod
        @lock_decorator(lock=threading.Lock())
        def static_method_1(value):
            var_0 = value
            value -= 1
            return var_0, value

        @classmethod
        @lock_decorator(lock=threading.Lock())
        def class_method_2(cls, value):
            var_0 = value
            value -= 1
            return var_0, value


# Generated at 2022-06-25 13:31:27.289617
# Unit test for function lock_decorator
def test_lock_decorator():
    literal_0 = None
    literal_1 = 0
    literal_2 = 1
    literal_3 = "String"
    literal_4 = {"Dict": 1}
    literal_5 = ["List", 2]
    literal_6 = ("Tuple", 3)

    @lock_decorator()
    def func_0(arg_0, **kwargs):
        return arg_0

    literal_7 = func_0(literal_0, kwarg_0=literal_1)
    literal_8 = func_0(literal_1, kwarg_0=literal_2)
    literal_9 = func_0(literal_1, kwarg_0=literal_3)
    literal_10 = func_0(literal_1, kwarg_0=literal_4)


# Generated at 2022-06-25 13:31:31.907075
# Unit test for function lock_decorator
def test_lock_decorator():
    assert func_0() == "abcd"
    assert func_1(1) == "abcd"
    assert func_2("a","b", "c", "d") == "abcd"
    assert func_3("a","b", "c", "d") == "abcd"
    assert func_4("a","b", "c", "d") == "abcd"
    assert func_5("a","b", "c", "d") == "abcd"
    assert func_6("a","b", "c", "d") == "abcd"
    assert func_7("a","b", "c", "d") == "abcd"


# Generated at 2022-06-25 13:31:37.662830
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test a lock decorator which uses the instance attribute _lock
    import threading

    class Example:
        def __init__(self):
            self._lock = threading.Lock()
            self.counter = 1

        @lock_decorator(attr='_lock')
        def increment(self):
            self.counter += 1

    e = Example()

    # threading
    t = threading.Thread(target=e.increment)
    t.start()
    t.join()

    assert e.counter == 2, 'lock decorator with instance attribute not working'

    # Test a lock decorator which uses a passed lock object
    class SecondExample:
        def __init__(self):
            self.counter = 1

        @lock_decorator(lock=threading.Lock())
        def increment(self):
            self

# Generated at 2022-06-25 13:31:38.813959
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()

    # Function ``test_case_0`` returns None
    assert var_1 == var_0

# Generated at 2022-06-25 13:31:39.744272
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# vim: set expandtab:ts=4:sw=4