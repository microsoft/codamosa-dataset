

# Generated at 2022-06-25 13:24:02.913812
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1+1 == 2



# Generated at 2022-06-25 13:24:10.973485
# Unit test for function lock_decorator
def test_lock_decorator():

    # Unit test for lock_decorator() with parameters:

    # Mock the actual class to be the one with the lock_decorator()
    # decorator applied
    class MockClass(object):
        def __init__(self):
            pass

        @lock_decorator
        def method(self):
            return self

    # Instantiate class MockClass
    mock_obj = MockClass()

    # Assert the function returns the class instance
    assert mock_obj.method() is mock_obj

    # Unit test for lock_decorator() with parameters: (attr='missing_lock_attr')

    # Mock the actual class to be the one with the lock_decorator()
    # decorator applied to the 'method' attribute
    class MockClass(object):
        def __init__(self):
            pass


# Generated at 2022-06-25 13:24:20.965504
# Unit test for function lock_decorator
def test_lock_decorator():
    # Reject call with no keyword arguments
    # Should be "missing_lock_attr"
    assert 1 == 2, 'Failed keyword argument check'
    # Reject call with too many keyword arguments
    # Should be "missing_lock_attr"
    assert 1 == 3, 'Failed keyword argument check'
    # Reject call with invalid keyword arguments
    # Should be "missing_lock_attr"
    assert 1 == 4, 'Failed keyword argument check'
    # Test with class and attribute lock
    assert 1 == 5, 'Failed class and attribute lock check'
    # Test with class and lock object
    assert 1 == 6, 'Failed class and lock object check'
    # Test with function and attribute lock
    assert 1 == 7, 'Failed function and attribute lock check'
    # Test with function and lock object

# Generated at 2022-06-25 13:24:22.212247
# Unit test for function lock_decorator
def test_lock_decorator():
    global test_case_0
    assert test_case_0() is None

# Generated at 2022-06-25 13:24:25.448715
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator(attr='missing_lock_attr', lock=None)
    var_2 = lock_decorator(attr='missing_lock_attr')
    var_3 = lock_decorator(lock=None)

# Generated at 2022-06-25 13:24:27.753168
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    var_1 = lock_decorator()
    assert var_0 == var_1

#  vim: set ft=python :

# Generated at 2022-06-25 13:24:29.234282
# Unit test for function lock_decorator
def test_lock_decorator():
    value1 = lock_decorator()
    assert value1 == "lock_decorator"

# Generated at 2022-06-25 13:24:36.168348
# Unit test for function lock_decorator
def test_lock_decorator():
    class lock_decorator_class(object):

        def __init__(self):
            self.attr_0 = lock_decorator

        def test_case_0(self):
            var_0 = lock_decorator

        def test_case_1(self):
            var_1 = lock_decorator(
                attr='_callback_lock'
            )

        def test_case_2(self):
            var_2 = lock_decorator(
                lock=threading.Lock()
            )

    try:
        from threading import Lock
    except ImportError:
        try:
            from dummy_threading import Lock
        except ImportError:
            return


# Generated at 2022-06-25 13:24:45.704675
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestClass:
        def __init__(self):
            self.lock_attr = None
            self.lock_arg = None
            self.no_arg_lock = None

    def test_decorator(arg=None):
        if arg is None or arg is 'lock_attr':
            @lock_decorator(attr='lock_attr')
            def wrapped(self):
                self.lock_attr = True
        if arg is None or arg is 'lock_arg':
            @lock_decorator(lock=test.lock_arg)
            def wrapped2(self):
                self.lock_arg = True
        if arg is None or arg is 'no_arg_lock':
            @lock_decorator()
            def wrapped3(self):
                self.no_arg_lock = True

    test = TestClass

# Generated at 2022-06-25 13:24:50.307494
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.PreferLockedModulesRule import lock_decorator

    # Use all kwargs
    var_1 = lock_decorator(lock=threading.Lock())
    assert var_1.__name__ == 'outer'

    # Use only required kwargs
    var_2 = lock_decorator()
    assert var_2.__name__ == 'outer'

# Generated at 2022-06-25 13:24:52.751073
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:02.869803
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a MagicMock to return values with
    mock = MagicMock(return_value={
        'rc': 0,
        'stdout': 'stdout',
        'stderr': 'stderr'
    })

    # Create a MagicMock to return values with
    mock_none = MagicMock(return_value=None)

    # Ensure our function is callable and does not error

# Generated at 2022-06-25 13:25:13.022162
# Unit test for function lock_decorator
def test_lock_decorator():
    import multiprocessing
    import threading
    import time

    # Ensure we are using threads
    # PyPy and PyO3 have a threading module, but it is not the same type
    # as from the stdlib
    assert threading.Thread is not multiprocessing.dummy.Process
    assert threading.Lock is not multiprocessing.dummy.Lock

    counter = 0
    counter_lock = threading.Lock()

    @lock_decorator(attr='counter_lock')
    def counter_increment():
        nonlocal counter
        counter += 1
        time.sleep(1)
        counter += 1
        time.sleep(1)
        counter += 1

    def run_increment(t):
        t.start()

    threads = []
    for i in range(0, 10):
        t

# Generated at 2022-06-25 13:25:15.521503
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Tests for lock_decorator

# Generated at 2022-06-25 13:25:21.561786
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator), 'Function "lock_decorator" is not callable'
    var_0 = lock_decorator()
    assert callable(var_0), 'Function "lock_decorator" is not callable'
    var_1 = lock_decorator('missing_lock_attr')
    assert callable(var_1), 'Function "lock_decorator" is not callable'
    var_2 = lock_decorator(lock=None)
    assert callable(var_2), 'Function "lock_decorator" is not callable'
    var_3 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert callable(var_3), 'Function "lock_decorator" is not callable'

# Generated at 2022-06-25 13:25:24.125800
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    try:
        obj = lock_decorator()
    except Exception as e:
        assert False, 'Failed to instantiate lock_decorator'



# Generated at 2022-06-25 13:25:25.270179
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()
    # Base case, call the function
    assert True

# Generated at 2022-06-25 13:25:27.617704
# Unit test for function lock_decorator
def test_lock_decorator():
    # TODO: Please, specify a list of parameter to be tested (if possible)
    #       for the function.
    assert lock_decorator is not None

# Generated at 2022-06-25 13:25:29.161199
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0() is None


# Generated at 2022-06-25 13:25:32.167808
# Unit test for function lock_decorator
def test_lock_decorator():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    cmd = "cd %s && python -m ansiblelint.tests.test_rules.test_lock_decorator" % tmpdir
    ret, out, err = command_in_module(cmd)
    assert ret == 0

# Generated at 2022-06-25 13:25:38.444050
# Unit test for function lock_decorator
def test_lock_decorator():
    print(test_case_0())

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:25:39.053637
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:25:39.619671
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:41.288814
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:25:42.166259
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:25:43.454394
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator) and callable(test_case_0)

# Generated at 2022-06-25 13:25:49.678046
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()


if __name__ == '__main__':
    import os
    import sys
    import unittest

    if not os.path.exists('./test'):
        os.mkdir('./test')
    if not os.path.exists('./test/coverage'):
        os.mkdir('./test/coverage')
    os.chdir('./test')

    sys.path.insert(0, '..')
    import test_utils

    test_utils.run_unittests(globals())

# Generated at 2022-06-25 13:25:56.369262
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import logging

    logger = logging.getLogger('test_lock_decorator')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # for reproducible results
    time.sleep(1)

    class Foo:

        def __init__(self):
            self.lock = threading.Lock()


# Generated at 2022-06-25 13:25:59.971084
# Unit test for function lock_decorator
def test_lock_decorator():

    # Arbitrary values
    var_0 = lock_decorator('fake_value', 'fake_value_0')
    assert var_0 == lock_decorator('fake_value', 'fake_value_0')

    
    
    
    
    
    


# Generated at 2022-06-25 13:26:07.778394
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    from threading import Lock, Thread

    _lock = Lock()
    _lock2 = Lock()

    # Ensure that we can use the decorator with an existing
    # lock attribute on an instance
    class Test(object):
        def __init__(self):
            self._lock = Lock()

        @lock_decorator(attr='_lock')
        def method(self):
            return random.randint(1, 10)

    test = Test()
    for _ in (1, 2, 3):
        assert test.method() == test.method()

    # Ensure that we can pass a lock to the decorator
    class Test2(object):
        @lock_decorator(lock=_lock)
        def method(self):
            return random.randint(1, 10)

    test2 = Test2()

# Generated at 2022-06-25 13:26:17.305478
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:26:25.861860
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test generic usage
    class Test(object):
        def __init__(self, func):
            self.func = func
            self.test_attr = None
            self.attr = lock_decorator(attr='test_attr')

        def __call__(self):
            return self.func()

    _test_attr = 0
    _test_attr_lock = 'a'
    test_attr = Test(lambda: _test_attr)
    # Set the instance attribute for the lock.
    setattr(test_attr, 'test_attr', _test_attr_lock)

    # Call the wrapped function
    test_attr()
    assert _test_attr == 0
    # call the decorator directly
    test_attr.attr()
    assert _test_attr == 1

    # Using the same instance attribute but with a different

# Generated at 2022-06-25 13:26:26.382290
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:26:27.464836
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:26:37.898144
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    mocked_module = patch.multiple(basic.AnsibleModule, exit_json=exit_json, fail_json=fail_json)

    # Configure the parameters that would be returned by querying the
    # remote device

# Generated at 2022-06-25 13:26:39.943747
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.LockDecorator import lock_decorator

    assert lock_decorator(attr='something')



# Generated at 2022-06-25 13:26:48.379560
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    class TestLockDecorator(unittest.TestCase):
        def test_0(self):
            # Test with no lock specified, just the lock attribute
            @lock_decorator(attr='lock')
            def func0(self):
                self.a = 1
                self.b = 2
                return self.a + self.b
            class Cls0(object):
                def __init__(self):
                    self.lock = threading.Lock()
            cls0 = Cls0()
            # The lock should be held for this entire call
            self.assertEqual(func0(cls0), 3)

        def test_1(self):
            # Test with a lock specified
            lock1 = threading.Lock()

# Generated at 2022-06-25 13:26:50.895184
# Unit test for function lock_decorator

# Generated at 2022-06-25 13:26:57.453378
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import json

    f = open(sys.argv[1])
    args_dict = json.load(f)
    f.close()

    var_0 = lock_decorator(**args_dict)

    return var_0

if __name__ == '__main__':
    import sys
    import json

    f = open(sys.argv[1])
    args_dict = json.load(f)
    f.close()

    var_0 = lock_decorator(**args_dict)

    print(var_0)

# Generated at 2022-06-25 13:26:57.890616
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:27:18.993403
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator), "Function lock_decorator not callable"
    function_0 = lock_decorator()
    assert callable(function_0), "Function lock_decorator not callable"
    with pytest.raises(AttributeError):
        function_0(lock_decorator)
# end unit test for lock_decorator



# Generated at 2022-06-25 13:27:19.796925
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:27:21.058527
# Unit test for function lock_decorator
def test_lock_decorator():
    assert var_0 is not None

# Generated at 2022-06-25 13:27:22.121590
# Unit test for function lock_decorator
def test_lock_decorator():
    arg0 = lock_decorator()

    assert arg0



# Generated at 2022-06-25 13:27:29.909831
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic

    try:
        from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    m = MagicMock()
    with patch.dict(basic.__salt__, {'test.ping': m}):
        with patch.dict(basic.__opts__, {'test': False}):
            assert basic.ping() == {'ping': 'pong'}
        with patch.dict(basic.__opts__, {'test': True}):
            assert basic.ping() == {'ping': 'pong'}

# Generated at 2022-06-25 13:27:31.427514
# Unit test for function lock_decorator
def test_lock_decorator():
    # Tests here
    assert True == True


# Generated at 2022-06-25 13:27:35.730278
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    var_0 = lock_decorator()
    assert isinstance(var_0, type(mock.MagicMock()))
    assert var_0.__name__ == 'lock_decorator'
    assert var_0.__qualname__ == 'lock_decorator'
    assert var_0.__module__ == 'tests.unit.common.lock_decorator'

# Generated at 2022-06-25 13:27:43.213816
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test implementing the most basic usage of `lock_decorator`
    # by using a pre-defined instance attribute as the lock
    class Example(object):
        _callback_lock = None

        def __init__(self, *args, **kwargs):
            self._callback_lock = 1

        @lock_decorator(attr='_callback_lock')
        def send_callback(self):
            assert not isinstance(self._callback_lock, int)
            self._callback_lock = 1

    example = Example()
    example.send_callback()
    assert example._callback_lock == 1

    # Test implementing the second use case of `lock_decorator`
    # by explicitly passing a lock object
    import threading
    class Example(object):
        _callback_lock = None


# Generated at 2022-06-25 13:27:43.811226
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator() is not None

# Generated at 2022-06-25 13:27:44.703584
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:22.670004
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:28:23.801544
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator), \
        "Failed to find function lock_decorator"


# Generated at 2022-06-25 13:28:24.389151
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:28:25.304700
# Unit test for function lock_decorator
def test_lock_decorator():
    assert var_0(var_0) == var_0

# Generated at 2022-06-25 13:28:26.357827
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:28:29.241945
# Unit test for function lock_decorator
def test_lock_decorator():
    # Set desired values
    attr = 'x'
    lock = 'y'

    # Call function
    res = lock_decorator(attr='x', lock='y')

    # Check if results are as expected
    assert res is not None, "Return value does not match expected result!"
    # Return true if assert

# Generated at 2022-06-25 13:28:31.032491
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert callable(lock_decorator(attr='_callback_lock'))


# Generated at 2022-06-25 13:28:32.436398
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()



# Generated at 2022-06-25 13:28:33.519529
# Unit test for function lock_decorator
def test_lock_decorator():
    # TODO: Implement test for function lock_decorator
    assert True

# Generated at 2022-06-25 13:28:34.005966
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:29:54.612597
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:29:55.780481
# Unit test for function lock_decorator
def test_lock_decorator():
    # Testing a function that does not exist
    try:
        test_case_0()
    except NameError:
        pass

# Generated at 2022-06-25 13:29:56.214820
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:30:01.109838
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def _count():
        yield
        for i in range(10):
            yield
    count = _count()

    @lock_decorator(lock=lock)
    def worker():
        time.sleep(0.1)
        count.send(None)
        time.sleep(0.1)
        count.send(None)
        time.sleep(0.1)
        count.send(None)

    for i in range(10):
        threading.Thread(target=worker).start()

    time.sleep(0.5)

# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-25 13:30:07.488990
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestAnsibleModule(object):
        def __init__(self):
            self.exit_json = MagicMock()
            self.fail_json = MagicMock()


    # Mock the ansible modules
    ansible = Mock()

    # Mock the module
    am = TestAnsibleModule()
    # Mock the module's params
    am.params = {}

    # Mock the command
    c = Command('foo')

    # Execute the run method
    c.run(am)

    # Assert the ansible module functions were called

# Generated at 2022-06-25 13:30:08.161979
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:30:08.585023
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:30:13.273470
# Unit test for function lock_decorator
def test_lock_decorator():
    with raises(ValueError):
        lock_decorator(foo='bar')

    @lock_decorator(attr='foo', lock='bar')
    def func(arg):
        return arg

    with raises(AttributeError):
        func('arg')

    lock = object()
    @lock_decorator(attr='foo', lock=lock)
    def func(arg):
        return arg

    with raises(AttributeError):
        func('arg')



# Generated at 2022-06-25 13:30:13.910627
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:30:18.713748
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()
    @lock_decorator(lock=_lock)
    def test_method(self):
        assert _lock.locked()

    test_method(None)
    assert not _lock.locked()

    class TestClass(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test_method(self):
            assert self._lock.locked()

    test = TestClass()
    test.test_method()
    assert not test._lock.locked()

# Generated at 2022-06-25 13:33:38.082618
# Unit test for function lock_decorator
def test_lock_decorator():
    from types import FunctionType

    assert isinstance(lock_decorator, FunctionType), 'lock_decorator is not a function'

# Generated at 2022-06-25 13:33:42.709975
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class TestLock_decorator(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_case_0(self):
            var_0 = lock_decorator()

    unittest.main()

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:33:45.607940
# Unit test for function lock_decorator
def test_lock_decorator():
    # Unit tests for the arguments
    assert callable(lock_decorator())
    assert callable(lock_decorator(attr='missing_lock_attr'))
    assert callable(lock_decorator(lock=None))

# Generated at 2022-06-25 13:33:46.941116
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator(attr='')
    var_0('')

# Generated at 2022-06-25 13:33:53.342084
# Unit test for function lock_decorator
def test_lock_decorator():

    from ansiblelint.rules import RulesCollection

    rulesdir = os.path.join('lib', 'ansiblelint', 'rules')
    collection = RulesCollection.create_from_directory(rulesdir)
    pre_run_dir = os.getcwd()

    rule = collection.rules[0]

    os.chdir('test/lib/ansiblelint/rules/test_lock_decorator')

    ast = LintASTLoad()
    match = rule.matchplay(ast, 'test_lock_decorator.yml')

    assert match[0].linenumber == 4
    assert match[0].linenumber == match[1].linenumber

    os.chdir(pre_run_dir)

# Generated at 2022-06-25 13:33:54.669838
# Unit test for function lock_decorator
def test_lock_decorator():
    s = 'This is a test for lock_decorator'
    assert s == 'This is a test for lock_decorator'

# Generated at 2022-06-25 13:33:59.724576
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert var_0(lambda *args, **kwargs: None)
    var_1 = lock_decorator(lock=None, attr='missing_lock_attr')
    assert var_1(lambda *args, **kwargs: None)
    var_2 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert var_2(lambda *args, **kwargs: None)