

# Generated at 2022-06-25 13:24:10.644353
# Unit test for function lock_decorator
def test_lock_decorator():

    # Case 0: missing arguments
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        raise AssertionError('Expected lock_decorator to fail without arguments')

    # Case 1: Parameter is not a string
    try:
        lock_decorator(attr=True)
    except TypeError:
        pass
    else:
        raise AssertionError('Expected lock_decorator to fail without a string')

    # Case 2: lock setup with a class member
    class TestClass(object):
        def method(self):
            return 'method called'

    t = TestClass()
    t.lock = 'lock'
    lock_decorator(attr='lock')(t.method)()

    # Case 3: lock setup with a class member

# Generated at 2022-06-25 13:24:20.680311
# Unit test for function lock_decorator
def test_lock_decorator():
    from pprint import pprint

    # Ensure that lock_decorator makes the necessary substitutions
    cmd = lock_decorator(attr='__lock_lock_attr')
    pprint(cmd.__dict__)

# Generated at 2022-06-25 13:24:22.008949
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator()
    assert lock_decorator

# Generated at 2022-06-25 13:24:30.850874
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading
    from functools import partial

    m = mock.Mock()

    @lock_decorator(lock=m)
    def func():
        pass

    # If a lock was passed in, the lock should be the mock
    assert m == func.__lock__

    # If a lock was passed in, the lock should be the mock
    assert func.__lock__._is_owned() is False

    func()

    # When the function is called, the lock should be obtained
    assert func.__lock__._is_owned() is True
    # When the context manager exits, the lock should be released
    assert func.__lock__._is_owned() is False


    @lock_decorator(attr='lock')
    def func_0():
        pass

    # If no lock was passed in,

# Generated at 2022-06-25 13:24:39.396843
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import doctest
    import argparse

    # debug output
    def eprint(*args, **kwargs):
        print(*args, file=sys.stderr, **kwargs)

    # parse commandline arguments
    parser = argparse.ArgumentParser(description='Unit test for function lock_decorator.')
    parser.add_argument('--debug', action='store_true', help='Enable debug output')
    args = parser.parse_args()

    # check for debug flag and set debug level
    if args.debug:
        eprint(f'Unit test for function lock_decorator: debug flag set')
        eprint(f'\tHint: Use the --debug flag when calling a python script to enable debug output')
        debug = 1
    else:
        debug = 0

    # run unit tests


# Generated at 2022-06-25 13:24:41.462426
# Unit test for function lock_decorator
def test_lock_decorator():
    print(lock_decorator())


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:24:43.309319
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    var_1 = lock_decorator()
    assert callable(var_1)

# Generated at 2022-06-25 13:24:50.821410
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass():
        def __init__(self):
            self.a = 1
            self.b = 0
            self.lock = threading.Lock()
        @lock_decorator(lock=threading.Lock())
        def func_1(self):
            self.a += 1
        @lock_decorator(attr='lock')
        def func_2(self):
            self.b += 1
    test_object = TestClass()
    for i in range(100):
        test_object.func_1()
        test_object.func_2()
    assert test_object.a == 101 and test_object.b == 100

# Generated at 2022-06-25 13:24:55.661382
# Unit test for function lock_decorator
def test_lock_decorator():
    test_decorator = lock_decorator()

    # Test with a missing attr
    try:
        test_decorator(lambda x: x)
    except AttributeError:
        pass

    test_lock = lambda x: x
    test_decorator = lock_decorator(attr='_test_lock', lock=test_lock)

    test_func = lambda x: x
    test_decorator(test_func)

    assert test_func._test_lock is not None

# Generated at 2022-06-25 13:24:59.003703
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys, json

    fname = sys._getframe().f_code.co_name
    if fname not in globals():
        print('No unit test exists for this function.')
        return

    with open('test/results/%s.json' % fname, 'r') as fh:
        expected = json.load(fh)

    got = lock_decorator()
    assert expected == got, 'Expected: %r, but got: %r' % (expected, got)

# Generated at 2022-06-25 13:25:03.789659
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:04.416787
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:05.001625
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:06.858239
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-25 13:25:17.274385
# Unit test for function lock_decorator
def test_lock_decorator():
    from unitest import mock
    from ansible.module_utils.common.text.converters import to_bytes
    mock_wrap_lock = mock.Mock()
    mock_wrap_lock(mock.Mock(return_value=mock.Mock(__call__=mock.Mock(return_value=mock.Mock(__iter__=mock.Mock()))))).__enter__().__call__().__iter__().__next__().rstrip.return_value = to_bytes('bob')
    mock_wrap_lock(mock.Mock(return_value=mock.Mock(__call__=mock.Mock(return_value=mock.Mock(__iter__=mock.Mock()))))).__enter__().__call__().__iter__().__next__().r

# Generated at 2022-06-25 13:25:19.591063
# Unit test for function lock_decorator
def test_lock_decorator():
    print("test_lock_decorator")

# vim: set ft=python ts=4 sw=4 expandtab :

# Generated at 2022-06-25 13:25:21.187243
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:25:22.083338
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:29.041724
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestLoader, TextTestRunner
    from tests.support.case import ModuleCase
    from tests.support.helpers import slowTest

    @slowTest
    class TestLockDecorator(ModuleCase):
        def test_test_case_0(self):
            test_case_0()

    tests = TestLoader().loadTestsFromModule(TestLockDecorator())
    res = TextTestRunner(verbosity=1).run(tests)
    if res.failures or res.errors:
        raise AssertionError('TestLockDecorator.test_test_case_0() failed')

# Generated at 2022-06-25 13:25:29.436896
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:34.461797
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:25:44.513906
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest.mock import patch
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils import basic

    # Patch Ansible version to 2.8.0 or higher
    #
    # NOTE:
    # This is done, as ``ansible-test require-ansible-v2.8``
    # is executed as part of the unit test suite, but we want
    # to test the ``bugfixes_until`` functionality with the
    # latest ``ansible-base``.
    #
    # In the future, we can remove this when this test runner
    # is only testing against the latest release.
    patch('ansible.module_utils.ansible_release.__version__', new=ansible_version, create=True).start()

# Generated at 2022-06-25 13:25:47.099395
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator.lock_decorator
    assert lock_decorator.lock_decorator.outer
    assert lock_decorator.lock_decorator.outer.inner

# Generated at 2022-06-25 13:25:48.945712
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case 0
    assert lock_decorator(attr='missing_lock_attr', lock=None)



# Generated at 2022-06-25 13:25:49.397909
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:57.207694
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = dict(
        attr=dict(required=True, default='my_lock'),
        lock=dict(required=False, default=None),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    result = {}

    my_lock = module.params['lock']
    @lock_decorator(lock=my_lock)
    def test1():
        import time
        time.sleep(2)

    @lock_decorator(attr='my_lock')
    def test2(self):
        import time
        time.sleep(2)


    result['test1_output'] = test1()

# Generated at 2022-06-25 13:26:03.270988
# Unit test for function lock_decorator
def test_lock_decorator():
    var_a = lock_decorator()
    var_b = lock_decorator()
    var_c = lock_decorator()
    assert var_a is var_b
    assert var_b is var_c
    assert var_a is var_c
    assert var_a is lock_decorator()


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:26:03.623897
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:05.831122
# Unit test for function lock_decorator
def test_lock_decorator():
    # Check function lock_decorator with positional arguments
    assert lock_decorator() # TODO: implement your test here

# Unit tests for class AlternateDict
# TODO: implement your tests here

# Generated at 2022-06-25 13:26:07.106947
# Unit test for function lock_decorator
def test_lock_decorator():
    # verify the return type of function call
    assert test_case_0() == None

# Generated at 2022-06-25 13:26:17.006371
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()



# Generated at 2022-06-25 13:26:19.160763
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True

    @lock_decorator
    def some_method():
        pass

    some_method()



# Generated at 2022-06-25 13:26:23.659156
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = lock_decorator()
    assert lock == lock_decorator

    lock = lock_decorator(attr='_lock')
    assert lock == lock_decorator

    lock = lock_decorator(lock='foo')
    assert lock == lock_decorator

    lock = lock_decorator(lock='foo', attr='_lock')
    assert lock == lock_decorator

# Generated at 2022-06-25 13:26:25.325406
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator == lock_decorator


# Generated at 2022-06-25 13:26:26.541980
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:26:27.093563
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:32.993048
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from ansible.module_utils.basic import env_fallback
    except ImportError:
        # Not running inside Ansible
        pass
    else:
        # Check if lock_decorator is a function
        assert callable(lock_decorator)

    # Test to see if this function properly handles the attr paramater
    assert var_0.__name__ == 'inner'

# Generated at 2022-06-25 13:26:34.323109
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:26:38.405876
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from unittest import TestCase
    except ImportError:
        from unittest2 import TestCase

    class TestLockDecorator(TestCase):
        def test_lock_from_attr(self):
            pass

        def test_lock_from_parameter(self):
            pass



# Generated at 2022-06-25 13:26:41.430151
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator(attr='missing_lock_attr', lock=None)
    var_2 = lock_decorator(lock=None)
    var_3 = lock_decorator(attr='missing_lock_attr')

# Generated at 2022-06-25 13:26:59.768555
# Unit test for function lock_decorator
def test_lock_decorator():
    # Run unit and verify expected output
    try:
        test_case_0()
        assert False, 'Should have raised a SyntaxError'
    except:
        pass
    pass

# Generated at 2022-06-25 13:27:01.046621
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError not raised"

# Generated at 2022-06-25 13:27:10.564303
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import shutil
    import tempfile
    import ansible.module_utils.facts.virtual.kvm as kvm
    import ansible.module_utils.facts.virtual.virtualbox as virtualbox
    import ansible.module_utils.facts.virtual.xen as xen
    import ansible.module_utils.facts.virtual.vmware as vmware

    tempdir = tempfile.mkdtemp()
    os.environ['LIBVIRT_DEFAULT_URI'] = 'qemu:///system'
    open(os.path.join(tempdir, 'KVM_LOCKED'), 'w').close()

# Generated at 2022-06-25 13:27:11.346687
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:27:20.980427
# Unit test for function lock_decorator
def test_lock_decorator():
    import test_utils

    var_0 = lock_decorator()

    with test_utils.capture_output() as (stdout, stderr):
        var_0
    assert stdout.getvalue() == ''

    assert stderr.getvalue() == 'missing_lock_attr is missing\n'

    var_0 = lock_decorator(attr='_callback_lock')

    with test_utils.capture_output() as (stdout, stderr):
        var_0
    assert stdout.getvalue() == ''

    assert stderr.getvalue() == '_callback_lock is missing\n'

    var_0 = lock_decorator(lock='_callback_lock')

    with test_utils.capture_output() as (stdout, stderr):
        var_0


# Generated at 2022-06-25 13:27:22.046953
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:27:29.846658
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def test_method_0(self):
            return True

    # this test passes as long as this doesn't fail
    # i.e. no side-effects
    assert TestClass().test_method_0()

    class TestClass2(object):
        # this test passes if the lock is acquired
        def __init__(self):
            self.lock = threading.Lock()
            self.acquired = False

        @lock_decorator(attr='lock')
        def test_method_0(self):
            self.acquired = True
            time.sleep(0.1)
            self.acquired = False


# Generated at 2022-06-25 13:27:36.390680
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.pycompat24 import mock
    from ansible_collections.sivel.null.plugins.module_utils.lock_decorator import lock_decorator

    # var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    var_0 = mock.Mock()
    var_0.attr = 'missing_lock_attr'
    var_0.lock = None

    # var_1 = lock_decorator(attr='missing_lock_attr', lock=None)
    var_1 = mock.Mock()
    var_1.attr = 'missing_lock_attr'
    var_1.lock = None

    # assert var_0 == var_1
    # assert var_0 is var_1
    assert var_0.attr == var

# Generated at 2022-06-25 13:27:41.486461
# Unit test for function lock_decorator
def test_lock_decorator():

    # Arrange
    import threading
    lock_object = threading.Lock()
    my_great_list = []
    def inner_func(obj):
        print(1)
    def outer_func(self, obj):
        self.inner_func(obj)

    # Act
    @lock_decorator(lock=lock_object)
    def test_func(obj, threaded=False):
        if threaded:
            my_great_list.append(obj)
            import time
            time.sleep(0.05)
            my_great_list.append(obj)

        else:
            my_great_list.append(obj)
            my_great_list.append(obj)


# Generated at 2022-06-25 13:27:42.714726
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator('attr', 'lock')



# Generated at 2022-06-25 13:28:22.794317
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 0 == 0


# Generated at 2022-06-25 13:28:23.527400
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:28:25.211740
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:28:31.108286
# Unit test for function lock_decorator
def test_lock_decorator():

    class TestClass(object):
        func_1 = lock_decorator(attr='func_2')

        def func_2(self, var_0):
            pass

        func_3 = lock_decorator(lock=None)
        func_4 = lock_decorator(attr='func_4')

        def func_5(self, var_1):
            pass
    test_class_0 = TestClass()
    test_class_0.func_1(0)
    test_class_0.func_3(1, var_0=2)
    test_class_0.func_4(var_0=0)
    test_class_0.func_5(0, var_1=1)


if __name__ == "__main__":
    test_lock_decorator()

# Generated at 2022-06-25 13:28:33.408658
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        import ansible_collections.sivel.sivel_msocket.plugins.module_utils
    except ImportError:
        import module_utils
    assert True

# Generated at 2022-06-25 13:28:33.893992
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:41.204239
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    callback_lock = threading.Lock()

    @lock_decorator(attr='callback_lock')
    def send_callback_0(msg):
        assert msg == 42
        send_callback_0._called += 1

    class Test0(object):
        def __init__(self):
            self.callback_lock = callback_lock
            self.send_callback_0 = send_callback_0

    @lock_decorator(lock=callback_lock)
    def send_callback_1(msg):
        assert msg == 42
        send_callback_1._called += 1

    class Test1(object):
        def __init__(self):
            self.send_callback_1 = send_callback_1

    test0 = Test0()
    test1 = Test1()


# Generated at 2022-06-25 13:28:50.272888
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestCase(object):

        def __init__(self, test_id):
            self.id = test_id

        @lock_decorator(attr='_lock', lock=threading.Lock())
        def test_1(self):
            var_0 = self.id

        @lock_decorator(lock=threading.Lock())
        def test_2(self, test_id):
            var_0 = test_id

        @lock_decorator(attr='_lock')
        def test_3(self):
            var_0 = self.id

    test_case_0 = TestCase(0)
    test_case_0.test_1()
    test_case_0.test_2(1)
    test_case_0.test_3()

 
# Check

# Generated at 2022-06-25 13:28:57.452201
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import os
    import pytest

    # Ensure the framework can be imported
    from ansible_collections.sivel.openshift_facts import lock_decorator

    # Set environment variables
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.path.abspath('../collections')
    sys.path.insert(0, '../')

    # Imports
    from ansible_collections.sivel.openshift_facts.lock_decorator import lock_decorator
    from ansible_collections.sivel.openshift_facts.lock_decorator import test_case_0

    # Unit tests
    assert True

# Generated at 2022-06-25 13:29:04.181514
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = threading.Lock()
    class TestClass(object):
        @lock_decorator(attr='_lock', lock=lock)
        def test_method(self, i):
            print(i)

    class TestClass2(object):
        @lock_decorator(lock=lock)
        def test_method(self, i):
            print(i)

    class TestClass3(object):
        _lock = threading.Lock()
        @lock_decorator(attr='_lock')
        def test_method(self, i):
            print(i)

    # Ensure the lock is acquired
    obj = TestClass(lock)
    obj.test_method(1)
    obj = TestClass(lock)
    obj.test_method(2)

    # Ensure the lock is acquired
    obj = Test

# Generated at 2022-06-25 13:30:43.071391
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:30:43.957112
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:30:53.247433
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.misc.tests.unit.compat.mock import MagicMock
    from ansible.module_utils.six import PY2

    # If PY2, then the `outer` variable is assigned to the
    # return value of `lock_decorator`, meaning it is actually
    # a `outer` function. If PY3, then the `outer` variable
    # is assigned to the return value of `outer`, meaning it
    # is actually the `inner` function.
    outer = lock_decorator()

    # mock the function return value
    ret = 'return value'

    # mock the function, and `func` is the function
    # returned by the mock
    func = MagicMock(return_value=ret)

    # In this instance, we are wrapping a method
    # so the first argument

# Generated at 2022-06-25 13:30:57.508704
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    from .fixtures import TestFixture

    @lock_decorator()
    def test_method():
        pass

    assert hasattr(test_method, '__module__')
    assert hasattr(test_method, '__name__')
    assert hasattr(test_method, '__doc__')
    assert hasattr(test_method, '__annotations__')



# Generated at 2022-06-25 13:30:58.233162
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()


# Generated at 2022-06-25 13:31:05.933776
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.helpers import OptionValidator

    class module_utils_parsing_convert_bool_module(object):

        def __init__(self, **kwargs):
            self.params = {
                'boolean': False,
            }
            self.params.update(kwargs)

        def exit_json(self, **kwargs):
            return False

        def fail_json(self, **kwargs):
            return True

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/usr/bin/python'

        def get_platform(self):
            return 'Linux'

# Generated at 2022-06-25 13:31:09.725201
# Unit test for function lock_decorator
def test_lock_decorator():
    # the assignment of the wrapped function to ``inner`` is for
    # documenting the actual wrapped function
    #
    # pylint: disable=unused-variable
    @lock_decorator(attr='missing_lock_attr', lock=None)
    def inner(*args, **kwargs):
        pass

# Generated at 2022-06-25 13:31:10.196028
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:31:10.655595
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:31:11.597787
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1

