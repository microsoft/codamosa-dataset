

# Generated at 2022-06-25 13:24:10.359785
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(attr='missing_lock_attr', lock=None) == lock_decorator(attr='missing_lock_attr', lock=None)
    assert lock_decorator(attr='missing_lock_attr', lock=None) != lock_decorator(attr='missing_lock_attr', lock=None)
    assert lock_decorator(attr='missing_lock_attr', lock=None) != lock_decorator(attr='missing_lock_attr', lock=None)
    assert lock_decorator(attr='missing_lock_attr', lock=None) != lock_decorator(attr='missing_lock_attr', lock=None)

    assert lock_decorator(attr='missing_lock_attr', lock=None) != lock_decorator(attr='missing_lock_attr', lock=None)

# Generated at 2022-06-25 13:24:20.395846
# Unit test for function lock_decorator
def test_lock_decorator():
    from argparse import Namespace
    import threading

    # Create a lock for use in the decorated method
    lock = threading.Lock()

    # Create an instance of a class (any class)
    # that has ``_callback_lock`` as an attribute
    class Sample(object):
        _callback_lock = lock

    # Create an instance of Sample
    s = Sample()

    # Create a method that is set as a callback
    # and is decorated with @lock_decorator
    @lock_decorator(attr='_callback_lock')
    def added_callback(data, **kwargs):
        '''Sample method that acts as a callback'''
        # Return a tuple to enable verification later
        return kwargs['host'], kwargs['port']

    f = added_callback

    # Create a second instance of Sample


# Generated at 2022-06-25 13:24:22.728429
# Unit test for function lock_decorator
def test_lock_decorator():
    import os, sys, pytest, tempfile
    # Test case 0
    output_0 = test_case_0()

# Test function lock_decorator

# Generated at 2022-06-25 13:24:24.539771
# Unit test for function lock_decorator
def test_lock_decorator():
    # Verify the first argument to ``lock_decorator`` is checked
    pass



# Generated at 2022-06-25 13:24:26.575253
# Unit test for function lock_decorator
def test_lock_decorator():
    # TODO: Add unit test
    # To automatically add a unit test add the following comment

    # FIXME: Add unit test
    pass


# Generated at 2022-06-25 13:24:27.604891
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:24:27.901182
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:31.368877
# Unit test for function lock_decorator
def test_lock_decorator():
    mock_item = MagicMock(side_effect=KeyError)
    expected_value = mock_item()
    with patch('lock_decorator.attr', mock_item):
        assert lock_decorator(attr) == expected_value
        mock_item.assert_called_once_with(attr)

# Generated at 2022-06-25 13:24:32.124749
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test the function lock_decorator
    assert True

# Generated at 2022-06-25 13:24:33.380400
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(attr='missing_lock_attr') == outer


# Generated at 2022-06-25 13:24:44.917683
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    lock = threading.Lock()
    global var_0

    @lock_decorator(lock=lock)
    def func_0():
        global var_0
        var_0 += 1

    for _ in range(10):
        with lock:
            func_0()

    assert var_0 == 10


if __name__ == '__main__':
    import sys
    import os

    if '-l' in sys.argv:
        logger = logging.getLogger()
        handler = logging.FileHandler(filename='logger.log',
                                      mode='w')
        formatter = logging.Formatter('%(asctime)s|%(levelname)s|%(name)s|%(message)s')
        handler.setFormatter(formatter)
        logger.add

# Generated at 2022-06-25 13:24:46.866619
# Unit test for function lock_decorator
def test_lock_decorator():
    # In python2 we can't annotate the return type, but we can test it
    assert lock_decorator.__annotations__['return'] == outer

# Generated at 2022-06-25 13:24:54.700940
# Unit test for function lock_decorator
def test_lock_decorator():
    # Testing the case where both ``lock`` and
    # ``attr`` are None
    # ``attr`` is None, so ``lock`` is required
    # Testing the case where lock is not None
    # ``attr`` is not None, so ``lock`` is not required
    # Testing the case where both ``lock`` and
    # ``attr`` are not None
    # ``attr`` is not None, so ``lock`` is not required
    # Testing the case where lock is None
    # ``attr`` is not None, so ``lock`` is not required
    # Testing the case where both ``lock`` and
    # ``attr`` are not None
    # ``attr`` is not None, so ``lock`` is not required
    # Testing the case where lock is None
    # ``attr`` is not None, so ``lock`` is not required
    pass

# Generated at 2022-06-25 13:24:57.917265
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator('attr','_callback_lock')
    var_2 = lock_decorator('lock','threading.Lock()')
    return var_1,var_2

# Generated at 2022-06-25 13:25:01.568494
# Unit test for function lock_decorator
def test_lock_decorator():
    # Check that lock_decorator is callable
    assert callable(lock_decorator)

    assert hasattr(lock_decorator, '__name__')

    assert lock_decorator.__name__ == 'lock_decorator'

# Generated at 2022-06-25 13:25:06.981586
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

    # check that we can call it:
    var_0 = lock_decorator()
    # check that we can call it with args and kwargs:
    var_0 = lock_decorator(attr='missing_lock_attr')
    var_0 = lock_decorator(lock=None)
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)

# Generated at 2022-06-25 13:25:08.523529
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 13:25:18.368040
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # Check missing_lock_attr is set
    try:
        var_0 = lock_decorator()
    except TypeError as e:
        assert str(e) == "'attr' or 'lock' must be set"

    # Check that attr works
    class Test(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.attr_val = 'original'

        @lock_decorator(attr='lock')
        def test_attr(self):
            self.attr_val = 'attr'

    test = Test()
    assert test.attr_val == 'original'
    test.test_attr()
    assert test.attr_val == 'attr'

    # Check that lock works

# Generated at 2022-06-25 13:25:19.508268
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:25:20.763031
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()

# Generated at 2022-06-25 13:25:30.174847
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.UseLockDecoratorRule import UseLockDecoratorRule
    #  https://github.com/ansible/ansible/blob/stable-2.8/lib/ansible/plugins/callback/yaml.py#L113

    #  https://github.com/ansible/ansible/blob/stable-2.8/lib/ansible/plugins/action/get_url.py#L32
    #  https://github.com/ansible/ansible/blob/stable-2.8/lib/ansible/plugins/cache/redis.py#L166
    #  https://github.com/ansible/ansible/blob/stable-2.8/lib/ansible/plugins/cache/memory.py#L56
    #  https://github.com/ansible/

# Generated at 2022-06-25 13:25:32.208240
# Unit test for function lock_decorator
def test_lock_decorator():
    # test0 - ???
    # assert test_case_0() == 0, "test_case_0"
    # test1 - ???
    # assert test_case_1() == 0, "test_case_1"
    pass



# Generated at 2022-06-25 13:25:32.878531
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:34.422544
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    def test_lock_decorator():
        pass

# Generated at 2022-06-25 13:25:44.471729
# Unit test for function lock_decorator
def test_lock_decorator():
    c = {
        'test_case_0': ['Var 0: outer'],
        'test_case_1': ['Var 1: inner, Var 2: outer', 'Var 0: outer'],
        'test_case_2': ['Var 1: inner, Var 2: outer', 'Var 0: outer'],
        'test_case_3': ['Var 1: inner, Var 2: outer', 'Var 0: outer'],
        'test_case_4': ['Var 1: inner, Var 2: outer', 'Var 0: outer'],
        'test_case_5': ['Var 1: outer', 'Var 0: outer'],
    }

# Generated at 2022-06-25 13:25:45.012024
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:52.971535
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    
    @mock.patch('ansible.module_utils.basic.lock_utils.wraps')
    @mock.patch('ansible.module_utils.basic.lock_utils.getattr')
    def test_case_1(getattr_mock, wraps_mock):
        var_0 = lock_decorator()

        # The following code should be executed only once.
        # Tests that the decorator is only applied once
        @var_0
        def test_case_2():
            pass

        @var_0
        def test_case_1():
            pass

        assert test_case_1.__name__ == 'test_case_1'
        assert test_case_2.__name__ == 'test_case_2'
        assert test_case_1.__doc__ == ''

# Generated at 2022-06-25 13:26:03.071869
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile
    import string
    import random
    import threading
    from ansible.module_utils._text import to_bytes, to_text

    # Semaphore for synchronization
    sync_semaphore = threading.Semaphore()

    # Lock for file
    file_lock = threading.Lock()

    # Simple lock decorator test
    @lock_decorator(lock=file_lock)
    def write_to_file(text, filename):
        with open(filename, 'a+') as f:
            f.write(to_bytes(text))

    # Use instance attribute as lock

# Generated at 2022-06-25 13:26:06.099438
# Unit test for function lock_decorator
def test_lock_decorator():
    from . import lock_decorator
    from . import test_case_0
    from . import test_case_1
    from . import test_case_2
    from . import test_case_3
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Generated at 2022-06-25 13:26:07.385147
# Unit test for function lock_decorator
def test_lock_decorator():
    # Just make sure the test case runs, the code is in the docstring
    assert test_case_0() is None

# Generated at 2022-06-25 13:26:16.616361
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 is not None

# Generated at 2022-06-25 13:26:17.520899
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:26:21.032455
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(attr='_callback_lock') == outer
    assert lock_decorator(lock=threading.Lock()) == outer
    assert lock_decorator() == outer
    assert outer(send_callback) == inner
    assert inner == inner


# Generated at 2022-06-25 13:26:23.814460
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class test_lock_decorator(unittest.TestCase):
        def test_lock_decorator_0(self):
            var_0 = lock_decorator()
    unittest.main()



# Generated at 2022-06-25 13:26:30.571780
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import mock

    class Stub(object):
        def __init__(self):
            self._lock = mock.MagicMock()

        @lock_decorator()
        def test_0(self):
            pass

        @lock_decorator(attr='_lock')
        def test_1(self):
            pass

        @lock_decorator(lock=self._lock)
        def test_2(self):
            pass

    stub = Stub()
    stub.test_0()
    stub.test_1()
    stub.test_2()


# Generated at 2022-06-25 13:26:34.277478
# Unit test for function lock_decorator
def test_lock_decorator():

    # Test for function lock_decorator
    var_0 = lock_decorator()

    # Test for function lock_decorator
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)

# Generated at 2022-06-25 13:26:43.605254
# Unit test for function lock_decorator
def test_lock_decorator():
    import lock_decorator
    import mock

    @lock_decorator.lock_decorator(attr='test')
    def func():
        pass

    class Foo(object):
        def __init__(self):
            self.test = mock.MagicMock()

    def test_0():
        try:
            fo = Foo()
            fo.test.__enter__.return_value = None

            func()

            fo.test.__enter__.assert_called_once_with()
            fo.test.__exit__.assert_called_once_with(None, None, None)
        finally:
            del fo


# Generated at 2022-06-25 13:26:44.630823
# Unit test for function lock_decorator
def test_lock_decorator():
    # Make sure parameters are correct
    assert type(lock_decorator()) is function, \
        "lock_decorator() should return a function!"



# Generated at 2022-06-25 13:26:45.401339
# Unit test for function lock_decorator
def test_lock_decorator():
    foo = test_case_0()

# Generated at 2022-06-25 13:26:45.803538
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:27:10.126412
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile

    asdf = os.path.join(tempfile.gettempdir(), 'asdf.py')

# Generated at 2022-06-25 13:27:19.565386
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    class Test(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._x = 0

    class Test2(object):
        _lock = threading.Lock()

        def __init__(self):
            self._x = 0

    def test():
        t = Test()
        t2 = Test2()
        assert t._x == t2._x == 0
        t._x = 1
        t2._x = 2
        assert t._x == 1 and t2._x == 2

    test()

    # Force use of decorator
    Test.test = lock_decorator(attr='_lock')(test)
    Test2.test = lock_decorator(attr='_lock')(test)
    Test.test()
    Test2.test

# Generated at 2022-06-25 13:27:24.144072
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.RLock()

    def func_0():
        lock.acquire()
        lock.release()
        return False

    @lock_decorator(lock=lock)
    def func_1():
        return True

    test_0 = func_0()
    test_1 = func_1()

    assert test_0 is False
    assert test_1 is True

# Generated at 2022-06-25 13:27:31.429757
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup
    import threading
    var_0 = threading.Lock()

    @lock_decorator(lock=var_0)
    def func_0():
        var_1 = 0
        var_2 = var_1 + 1
        var_3 = var_2
        return var_3

    @lock_decorator(attr='_lock')
    def func_1(var_4):
        var_1 = 0
        var_2 = var_1 + 1
        var_3 = var_2
        return var_3

    class cls_0():
        def __init__(self):
            self._lock = threading.Lock()
        def func_2(self):
            return func_1(self)

    # Exercise SUT
    var_5 = func_0()
    var_6

# Generated at 2022-06-25 13:27:33.466476
# Unit test for function lock_decorator
def test_lock_decorator():
    assert func_call(lock_decorator)[0] == [
        'attr:missing_lock_attr, lock:None'
    ]


# Generated at 2022-06-25 13:27:35.049034
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator(attr = 'missing_lock_attr', lock = None)

# Test for function lock_decorator

# Generated at 2022-06-25 13:27:35.517497
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:27:37.761536
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert var_1 is not None
    assert var_1 is not False
    assert var_1 is not True

# Generated at 2022-06-25 13:27:39.110177
# Unit test for function lock_decorator
def test_lock_decorator():
    test = lock_decorator()
    assert callable(test) is True

# Generated at 2022-06-25 13:27:39.590060
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:22.070652
# Unit test for function lock_decorator
def test_lock_decorator():
    from functools import partial
    from threading import Thread
    from unittest import TestCase

    class ThreadTest(Thread):
        def __init__(self, func):
            self.return_0 = None
            self.return_1 = None
            self.setDaemon(True)
            super(ThreadTest, self).__init__(target=func)
            self.start()


    class LockTest(TestCase):

        def setUp(self):
            self._lock = None
            self._some_value = 0

        @lock_decorator()
        def test_lock_0(self, attr='_lock'):
            return self.test_method(self._lock, attr)

        @lock_decorator(attr='_lock')
        def test_lock_1(self):
            return self

# Generated at 2022-06-25 13:28:22.410837
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:28.736545
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import sys
    import os
    import socket
    import threading
    import time
    import json
    import requests
    import pytest
    import sys
    import os
    import socket
    import threading
    import time
    import json
    import requests
    import pytest
    import sys
    import os
    import socket
    import threading
    import time
    import json
    import requests
    import pytest
    import sys
    import os
    import socket
    import threading
    import time
    import json
    import requests
    import pytest
    import sys
    import os
    import socket
    import threading
    import time
    import json
    import requests
    import pytest
    import sys
    import os
    import socket
    import threading
    import time
    import json

# Generated at 2022-06-25 13:28:29.441402
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:28:32.436554
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test exceptions
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert excinfo.value.args[0] == 'lock_decorator() missing 1 required positional argument: \'func\''

# Generated at 2022-06-25 13:28:34.408417
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test for a nested decorator, which is not supported
    test_case_0()


if __name__ == "__main__":
    test_lock_decorator()

# Generated at 2022-06-25 13:28:40.723323
# Unit test for function lock_decorator
def test_lock_decorator():
    # Assign the function to a variable
    var_0 = lock_decorator()

    # Create an instance
    obj_1 = var_0(test_case_0)

    # Call the instance
    # No exception should be thrown
    obj_1()

    # Assign the function to a variable
    var_0 = lock_decorator()

    # Create an instance
    obj_2 = var_0(test_case_0)

    # Call the instance
    # No exception should be thrown
    obj_2()

if __name__ == "__main__":
    # Unit test for function lock_decorator
    test_lock_decorator()

# Generated at 2022-06-25 13:28:43.501356
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_common import lock_decorator

    @lock_decorator()
    def test():
        assert True

    test()



# Generated at 2022-06-25 13:28:52.913773
# Unit test for function lock_decorator
def test_lock_decorator():
    from pytest import raises
    from base64 import b64decode
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    import ansible_collections.ansible.community.plugins.module_utils.basic

    with raises(TypeError) as excinfo:
        lock_decorator()
    assert 'lock_decorator() missing 1 required positional argument: \'func\'' in str(excinfo.value)

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""

        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""

        pass


# Generated at 2022-06-25 13:29:00.956272
# Unit test for function lock_decorator
def test_lock_decorator():
    from collections import namedtuple
    import time
    import threading
    from multiprocessing import Process

    class Log(object):

        @staticmethod
        def _log(result, l):
            l.append(result)

        def log(self, result):
            threading.Thread(target=self._log, args=(result, self.result)).start()

    # This is a simple namedtuple to hold the state of our
    # lock, so that we can more easily track what's happening.
    # Primarily, it's a way to ensure that we're actually
    # locking what we expect.
    LockState = namedtuple('LockState', ['locked', 'state_changed'])

    # This class is so we can just add a basic lock that keeps
    # track of its own state. Generally, you'd use a ``threading.

# Generated at 2022-06-25 13:30:37.018116
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    # check calling lock_decorator with no args raises
    with pytest.raises(TypeError):
        test_case_0()

    # check calling lock_decorator with invalid attr
    with pytest.raises(TypeError):
        lock_decorator(attr='missing_lock_attr', lock=threading.Lock())

    # check calling lock_decorator with lock and attr
    with pytest.raises(TypeError):
        lock_decorator(attr='missing_lock_attr', lock=threading.Lock())

    # check calling lock_decorator with lock and attr
    @lock_decorator(attr='_callback_lock')
    def testcase_1():
        assert testcase_1.__name__ == 'testcase_1'

# Generated at 2022-06-25 13:30:38.150156
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:30:38.837827
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator()

# Generated at 2022-06-25 13:30:41.345820
# Unit test for function lock_decorator
def test_lock_decorator():
    assert type(lock_decorator()) == type(lock_decorator)
    assert type(lock_decorator) == type(lock_decorator)
    assert lock_decorator is not lock_decorator()



# Generated at 2022-06-25 13:30:48.047986
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    @lock_decorator(attr='_lock')
    def func_0(self):
        pass

    @lock_decorator(lock=threading.Lock())
    def func_1(self):
        pass

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()

    test_case_0()

    test_class_0 = TestClass()
    func_0(test_class_0)
    func_1(test_class_0)

# Generated at 2022-06-25 13:30:53.132631
# Unit test for function lock_decorator
def test_lock_decorator():
    import ansible_collections.sivel.sivel.tests.lock_decorator as lock_decorator_module

    var_1 = 'missing_lock_attr'
    lock_decorator_0 = lock_decorator_module.lock_decorator(attr=var_1)
    assert lock_decorator_0, "Failed to create lock_decorator_0"

# Generated at 2022-06-25 13:30:53.933992
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator()



# Generated at 2022-06-25 13:30:56.392296
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    assert lock_decorator is not None


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 13:30:57.176737
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:31:03.329982
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock

    lock = Lock()

    attr = '_callback_lock'

    @lock_decorator(attr=attr)
    def send_callback(self, response):
        return 'send_callback {}'.format(response)

    @lock_decorator(lock=lock)
    def some_method(self, response):
        return 'some_method {}'.format(response)

    class MyClass(object):
        def __init__(self):
            self.attr = '_callback_lock'
            setattr(self, attr, Lock())

        send_callback = send_callback
        some_method = some_method

    obj = MyClass()
    assert obj.send_callback('send_callback') == 'send_callback send_callback'