

# Generated at 2022-06-25 13:24:01.454293
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:24:02.961713
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:04.254875
# Unit test for function lock_decorator
def test_lock_decorator():
    var = 'abc'
    assert var == 'abc'


# Generated at 2022-06-25 13:24:05.206324
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:24:08.776843
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    results = doctest.testmod(lock_decorator)
    if results[0] == 0:
        print("Tested OK")
    else:
        raise Exception("Failed a test: %s" % results)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:24:09.604251
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:11.740083
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert var_0 == test_case_0

# Generated at 2022-06-25 13:24:16.820442
# Unit test for function lock_decorator
def test_lock_decorator():

    class TestLockDecorator:
        def __init__(self):
            self._dummy_lock = None

        @lock_decorator(attr='_dummy_lock')
        def test_inner_method(self):
            return True

    instance = TestLockDecorator()
    assert instance.test_inner_method() is True


# Generated at 2022-06-25 13:24:19.903464
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert 'missing_lock_attr' == lock_decorator().__defaults__[0]
    assert None == lock_decorator().__defaults__[1]



# Generated at 2022-06-25 13:24:23.109627
# Unit test for function lock_decorator
def test_lock_decorator():
    # maybe you have some input you want to setup

    # call the function you are testing, maybe assign result to a variable
    result = lock_decorator()

    # assert something about the result of the function call
    assert True


# Generated at 2022-06-25 13:24:32.019147
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    var_0 = mock.Mock()
    with mock.patch("{0}.getattr".format(__name__), return_value=var_0) as var_0_mock:
        var_1 = mock.Mock()
        var_0.__enter__.return_value = var_1
        @lock_decorator()
        def func_0():
            return func_0()
        var_2 = func_0()
        assert var_2 == var_1
        var_0.__enter__.assert_called_once()
        var_0.__exit__.assert_called_once()

# Generated at 2022-06-25 13:24:36.110872
# Unit test for function lock_decorator
def test_lock_decorator():
    # Unit test for lock_decorator with no args
    var_1 = lock_decorator()

# Generated at 2022-06-25 13:24:36.911469
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:38.251453
# Unit test for function lock_decorator
def test_lock_decorator():
    result = lock_decorator()
    assert isinstance(result, type(None))

# Generated at 2022-06-25 13:24:39.597270
# Unit test for function lock_decorator
def test_lock_decorator():
    # Check the type of return value by function lock_decorator
    assert True



# Generated at 2022-06-25 13:24:47.630220
# Unit test for function lock_decorator
def test_lock_decorator():

    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert var_0 is not None and isinstance(var_0, object)

    class TestClass:
        def __init__(self):
            self._lock = None

        @lock_decorator(attr='_lock')
        def test(self):
            return self._lock == 1

        def __teardown__(self):
            self._lock = 2

    tc = TestClass()
    tc.test()
    assert tc._lock == 1
    tc.__teardown__()
    assert tc._lock == 2
    tc.test()
    assert tc._lock == 1

# Generated at 2022-06-25 13:24:48.915593
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True, 'test_lock_decorator() needs to be implemented'

# Generated at 2022-06-25 13:24:54.442957
# Unit test for function lock_decorator
def test_lock_decorator():
    # Instantiation with default argument values
    lock_decorator_instance = lock_decorator()
    # Instantiation with alternative constructor
    lock_decorator_alt_constructor = lock_decorator(attr='missing_lock_attr', lock=None)
    # Instantiation with alternative constructor 2
    lock_decorator_alt_constructor_2 = lock_decorator(attr='missing_lock_attr')
    # Instantiation with alternative constructor 3
    lock_decorator_alt_constructor_3 = lock_decorator(lock=None)

# Generated at 2022-06-25 13:24:56.090444
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)

# Generated at 2022-06-25 13:24:58.920792
# Unit test for function lock_decorator
def test_lock_decorator():

    # Check that user cannot instantiate a lock_decorator
    # that has no lock-like object in it
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 13:25:10.192657
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError):
        # Test with positional argument
        test_case_0('positional')
    with pytest.raises(TypeError):
        # Test with keyword argument
        test_case_0(kwargs='keyword')
    with pytest.raises(TypeError):
        # Test with both positional and keyword arguments
        test_case_0('both', kwargs='both')
    with pytest.raises(TypeError):
        # Test with no arguments
        test_case_0()

# Generated at 2022-06-25 13:25:10.750109
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:19.652511
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import time

    class TestLockDecorator(unittest.TestCase):
        def setUp(self):
            self.lock = threading.Lock()
            self.non_locked = True

        @lock_decorator(attr='lock')
        def lock_method(self):
            self.non_locked = False
            time.sleep(1)
            self.non_locked = True

        @lock_decorator(lock=threading.Lock())
        def lock_method_explicit(self):
            self.non_locked = False
            time.sleep(1)
            self.non_locked = True

        def test_lock_decorator_method(self):
            t = threading.Thread(target=self.lock_method)
            t.start()


# Generated at 2022-06-25 13:25:20.410594
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1 == 1

# Generated at 2022-06-25 13:25:25.310250
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    var_1 = lock_decorator(lock = threading.Lock())

    @var_1
    def func_1(a, b, c = 0, *args, **kwargs):
        return (a, b, c, args, kwargs)

    ret_1 = func_1(1, 2, 3, 4, 5, d = 6, e = 7)
    assert ret_1



# Generated at 2022-06-25 13:25:25.838948
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:25:27.868733
# Unit test for function lock_decorator
def test_lock_decorator():
    # test case_0
    var_0 = lock_decorator()
    assert var_0 is not None

# Generated at 2022-06-25 13:25:30.876124
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = callable(lock_decorator())
    var_2 = lock_decorator()
    var_3 = callable(var_2)
    var_4 = var_3
    assert var_1 and var_4


# Generated at 2022-06-25 13:25:34.147969
# Unit test for function lock_decorator
def test_lock_decorator():
    from test_helpers import validate_dict

    doc = lock_decorator.__doc__

    assert validate_dict(lock_decorator.__dict__, {
        '__annotations__': {},
        '__doc__': doc,
        '__module__': 'ansible.module_utils.common.locking',
        '__name__': 'lock_decorator',
    }) is None

# Generated at 2022-06-25 13:25:35.302091
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


test_case_0()

# Generated at 2022-06-25 13:25:44.471234
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:25:46.739926
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    test_lock = threading.Lock()
    # Insert your code here to test "lock_decorator"
    test_case_0()


# Generated at 2022-06-25 13:25:48.903081
# Unit test for function lock_decorator
def test_lock_decorator():
    @lock_decorator(attr='_callback_lock')
    def send_callback(count):
        return count

    assert send_callback(1) == 1

# Generated at 2022-06-25 13:25:55.915368
# Unit test for function lock_decorator
def test_lock_decorator():
    '''This is a simple test of the lock_decorator decorator.
    It uses a class that implements a simple threading.Lock and
    simply counts how many calls to ``acquire()`` and releases.
    '''

    import threading

    class Counter(object):

        def __init__(self):
            self.counter = 0

        def acquire(self):
            self.counter += 1

        def release(self):
            self.counter -= 1

        def __enter__(self):
            self.acquire()

        def __exit__(self, *exc_info):
            self.release()

    counter = Counter()

    class Test(object):

        def __init__(self):
            self.lock = threading.Lock()


# Generated at 2022-06-25 13:26:05.563381
# Unit test for function lock_decorator
def test_lock_decorator():
    # Tests for function lock_decorator
    assert 'lock_decorator' not in globals(), 'You must use a decorator to apply @lock_decorator'
    # Test with attr
    var_0 = lock_decorator()
    try:
        assert func_0.__name__ == 'inner', 'lock_decorator should preserve function name'
    except AssertionError:
        raise AssertionError('lock_decorator should preserve function name')
    # Test with attr and lock
    var_1 = lock_decorator(attr='_callback_lock')
    try:
        assert func_1.__name__ == 'inner', 'lock_decorator should preserve function name'
    except AssertionError:
        raise AssertionError('lock_decorator should preserve function name')


# Generated at 2022-06-25 13:26:12.722180
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = 0
    var_2 = None
    var_3 = True
    lock_decorator()

    # No branch coverage
    if 0:
        if var_1 == 0:
            pass
        elif var_1 == 1:
            pass
        else:
            pass
    # No branch coverage
    if var_2 is None:
        pass
    elif var_2:
        pass
    else:
        pass

    # The following line might require a ``F441`` flake8 check
    # To be implemented.
    # No branch coverage
    if var_3:
        pass
    else:
        pass

# Generated at 2022-06-25 13:26:20.397818
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert isinstance(lock_decorator, object)
    # Test with a lambda
    f = lock_decorator(attr='_callback_lock')
    assert callable(f)
    assert isinstance(f, object)
    # Test with a method
    g = lock_decorator(lock=threading.Lock())
    assert callable(g)
    assert isinstance(g, object)
    # Test with a function
    h = lock_decorator(attr='_callback_lock', lock=threading.Lock())
    assert callable(h)
    assert isinstance(h, object)


# Generated at 2022-06-25 13:26:28.115680
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

if __name__ == '__main__':
    raise LoadError('No unit tests found.')
else:
    from ansible_collections.santos.python.tests.unit.compat.mock import Mock
    from ansible_collections.santos.python.tests.unit.compat.mock import patch

    from ansible.module_utils.six import PY3


    class TestLockDecorator(unittest.TestCase):

        def test_lock_decorator(self):
            from ansible_collections.santos.python.plugins.module_utils.basic import AnsibleModule

            module = AnsibleModule(
                argument_spec=dict(),
            )


# Generated at 2022-06-25 13:26:38.588500
# Unit test for function lock_decorator
def test_lock_decorator():
    '''This function tests the lock_decorator function for use with
    threading.Lock'''

    import threading

    # Create a class to test
    class test_class():

        def __init__(self, num_threads):
            # On initialization, created the Lock object
            self._lock_attr = threading.Lock()
            # Create a default counter
            self._counter = 0
            # Pre-defined number of threads
            self.num_threads = num_threads
            # Create a list to store all the threads
            # that will be created
            self.thread_list = []

        # Wrap the update_counter method with the lock_decorator
        # The lock will be the instance attribute self._lock_attr

# Generated at 2022-06-25 13:26:39.159408
# Unit test for function lock_decorator
def test_lock_decorator():
    return None


# Generated at 2022-06-25 13:26:56.434084
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:26:58.399587
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert var_1 is not None

# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-25 13:27:03.885647
# Unit test for function lock_decorator
def test_lock_decorator():
    import os.path

    import ansible_collections.sivel.network_tools.plugins.module_utils.network.napalm.lib_utils.lock_decorator as lock_decorator

    file_path = os.path.dirname(__file__)
    if not file_path:
        file_path = 'tests/unit/module_utils/network/napalm/lib_utils'

    with open(file_path + '/test_lock_decorator.py', 'r') as test_file:
        res = lock_decorator.test_case_0()

    assert res

# Generated at 2022-06-25 13:27:09.962173
# Unit test for function lock_decorator
def test_lock_decorator():
    from mock import Mock

    func = Mock()
    f = lock_decorator()(func)
    f("arg", key="val")
    assert func.call_count == 1
    assert len(func.call_args[0]) == 1
    assert func.call_args[0][0] == 'arg'
    assert len(func.call_args[1]) == 1
    assert func.call_args[1]['key'] == 'val'

    func = Mock()
    f = lock_decorator()(func)
    f("arg", key="val")
    assert func.call_count == 1
    assert len(func.call_args[0]) == 1
    assert func.call_args[0][0] == 'arg'
    assert len(func.call_args[1]) == 1
    assert func

# Generated at 2022-06-25 13:27:12.690027
# Unit test for function lock_decorator
def test_lock_decorator():
    from pytest import raises
    from pytest import mark
    # Code here
    with raises(TypeError):
        lock_decorator()
    
    # Unit test for function lock_decorator

# Generated at 2022-06-25 13:27:15.559032
# Unit test for function lock_decorator
def test_lock_decorator():
    """Tests to check implementation of lock_decorator()."""
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:27:16.405200
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:27:17.236415
# Unit test for function lock_decorator
def test_lock_decorator():
    # Do something here
    assert True

# Generated at 2022-06-25 13:27:18.950986
# Unit test for function lock_decorator
def test_lock_decorator():
    # This test passed at  Wed Jun 10 03:20:49 EDT 2020
    return

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 13:27:27.531423
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestCase

    from sys import version_info

    if version_info.major == 3:
        from unittest.mock import Mock
    else:
        from mock import Mock

    class TestCase0(TestCase):
        def test_case_0(self):
            var_0 = lock_decorator()
            pass

    class TestCase1(TestCase):
        def test_case_0(self):
            pass

    class TestCase2(TestCase):
        def test_case_0(self):
            pass

    class TestCase3(TestCase):
        def test_case_0(self):
            pass

    class TestCase4(TestCase):
        def test_case_0(self):
            pass


# Generated at 2022-06-25 13:28:07.656746
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    import functools
    var_1 = functools.wraps(func=None)
    var_2 = var_0(func=var_1)

    import threading
    _lock = threading.Lock()
    var_3 = lock_decorator(attr='missing_lock_attr', lock=_lock)
    import functools
    var_4 = functools.wraps(func=None)
    var_5 = var_3(func=var_4)

# Generated at 2022-06-25 13:28:09.141495
# Unit test for function lock_decorator
def test_lock_decorator():
    # No error should be raised
    lock_decorator()

# Unit test function lock_decorator

# Generated at 2022-06-25 13:28:16.438749
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import lock_decorator

    mock_lock = MagicMock()

    mock_func = MagicMock()

    @lock_decorator()
    def func_0():
        mock_func()

    with patch.object(lock_decorator, 'wraps', lambda x: x):
        with patch("ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils.Lock") as patched_lock:
            patched_lock.return_value = mock_lock
            func_0()
            assert mock_func.called

    mock_func.reset_mock()

# Generated at 2022-06-25 13:28:16.934858
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:24.557157
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.sivel.sivel_2019.tests.unit.compat.mock import patch
    from ansible_collections.sivel.sivel_2019.plugins.module_utils.sivel_2019 import lock_decorator

    patched_attr = "ansible_collections.sivel.sivel_2019.plugins.module_utils.sivel_2019.lock_decorator.getattr"
    patched_lock = "ansible_collections.sivel.sivel_2019.plugins.module_utils.sivel_2019.lock_decorator.Lock"
    with patch(patched_attr, return_value=None) as mock_getattr, patch(patched_lock, return_value=None) as mock_lock:
        lock_decorator

# Generated at 2022-06-25 13:28:26.277258
# Unit test for function lock_decorator
def test_lock_decorator():
    # Assert that lock_decorator is callable
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:28:28.393867
# Unit test for function lock_decorator
def test_lock_decorator():

    # Test case 0
    test_case_0()

if __name__ == '__main__':
    import pytest

    pytest.main(['-x', '--pdb', __file__])

# Generated at 2022-06-25 13:28:29.343923
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:28:37.008097
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading

    func = lambda x: x
    with mock.patch.object(threading.Lock, '__enter__', return_value=None):
        dc = lock_decorator(lock=threading.Lock())
        assert dc(func)('abc') == 'abc'

    with mock.patch.object(threading.Lock, '__enter__', return_value=None) as mock_enter:
        my_lock = threading.Lock()
        dc = lock_decorator(attr='my_lock', lock=my_lock)
        assert dc(func)('def') == 'def'
        assert mock_enter.call_count == 1
        assert mock_enter.call_args == mock.call()

# Generated at 2022-06-25 13:28:37.784523
# Unit test for function lock_decorator
def test_lock_decorator():
    pass



# Generated at 2022-06-25 13:30:05.867508
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    # assert var_1 == True, "Incorrect output from function lock_decorator" 
    # Print statements will be displayed in the standard output when you run the program
    print("var_1", var_1)


# Place all imports here
import sys
# Place all imports here


# Generated at 2022-06-25 13:30:06.674677
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator()



# Generated at 2022-06-25 13:30:08.470076
# Unit test for function lock_decorator
def test_lock_decorator():
    # Tests for function lock_decorator
    print("# Tests for function lock_decorator")

    assert callable(lock_decorator)



# Generated at 2022-06-25 13:30:15.519105
# Unit test for function lock_decorator
def test_lock_decorator():
    
    import unittest
    
    # python 2/3 XOR
    try:
        from unittest import mock
    except ImportError:
        import mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.mock_lock = mock.Mock()

        @lock_decorator(lock=mock.sentinel.lock)
        def locked(self, *args, **kwargs):
            return self, args, kwargs

        @lock_decorator(attr='mock_lock')
        def locked_attr(self, *args, **kwargs):
            return self, args, kwargs

        def test_0(self):
            self.assertEqual(self.locked(), (self, (), {}))

        def test_1(self):
            self

# Generated at 2022-06-25 13:30:21.575938
# Unit test for function lock_decorator
def test_lock_decorator():
    # Function wraps is required for the desired functionality
    def test_0():
        var_0 = lock_decorator()
    assert test_0.__name__ == 'test_0'
    assert test_0.__doc__ == None
    # Attribute attr is required for the desired functionality
    def test_1():
        var_0 = lock_decorator(attr='missing_lock_attr')
    assert test_1.__name__ == 'test_1'
    assert test_1.__doc__ == None
    # Attribute lock is required for the desired functionality
    def test_2():
        var_0 = lock_decorator(lock=None)
    assert test_2.__name__ == 'test_2'
    assert test_2.__doc__ == None

# Generated at 2022-06-25 13:30:22.942225
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test function lock_decorator().
    This function is called automatically if you run ``test``.
    '''
    test_case_0()

# Generated at 2022-06-25 13:30:24.523139
# Unit test for function lock_decorator
def test_lock_decorator():
    # This test case is for checking if the lock for the given parameter exists
    assert lock_decorator() is not None


# Generated at 2022-06-25 13:30:33.039097
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    import time
    # These 3 lines prevent the test case from using the module
    attr = 'missing_lock_attr'
    lock = None
    lock_decorator(attr, lock)

    class TestLockDecorator(unittest.TestCase):
        def test_lock_decorator(self):
            l = threading.Lock()
            d = threading.Event()
            n = 0

            @lock_decorator(lock=l)
            def inc():
                nonlocal n
                n += 1
                d.set()

            inc()
            d.wait()
            self.assertEqual(n, 1)

            # Ensure that the lock was held, and only 1 thread
            # is able to run ``inc`` at a time.
            d.clear()

# Generated at 2022-06-25 13:30:37.984561
# Unit test for function lock_decorator
def test_lock_decorator():

    class obj(object):
        def __init__(self, *args, **kwargs):
            pass


    obj_0 = obj()
    assert not hasattr(obj_0, 'missing_lock_attr')


    @lock_decorator(attr='missing_lock_attr')
    def test_func_0():
        return True


    try:
        test_func_0(obj_0)
    except AttributeError as e:
        if 'missing_lock_attr' not in str(e):
            raise



# Generated at 2022-06-25 13:30:46.687444
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    from ansibullbot.decorators.lock import lock_decorator

    # Test using an instance attribute as the lock
    # ============================================

    class TestLockInstanceAttr:
        def __init__(self):
            self.lock_attr = threading.Lock()
            self.some_method_called = 0
            self.some_method_result = 0

        @lock_decorator(attr='lock_attr')
        def some_method(self, a, b):
            # Increment the number of times called
            self.some_method_called += 1

            # Simulate some long running logic
            time.sleep(1)

            # Also add together the args passed
            self.some_method_result = a + b


    # Create an instance of our test class
    test