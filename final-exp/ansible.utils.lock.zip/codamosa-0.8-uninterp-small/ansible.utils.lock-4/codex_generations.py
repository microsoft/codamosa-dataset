

# Generated at 2022-06-25 13:24:09.535181
# Unit test for function lock_decorator
def test_lock_decorator():
    # Tests for function lock_decorator

    import sys

    if sys.version_info < (3,):
        import __builtin__ as builtins
    else:
        import builtins

    # A function that raises an exception with a name
    # matching the error passed to make_autospec_class()
    def func_with_exception(error='This is an error'):
        raise Exception(error)

    # Check that the argument to the decorator is required
    try:
        lock_decorator()
    except TypeError as e:
        pass
    else:
        raise AssertionError('Expected function to raise a TypeError')

    # Check that the argument is checked to be a callable
    try:
        lock_decorator(attr='class')
    except TypeError as e:
        pass
   

# Generated at 2022-06-25 13:24:12.015016
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = threading.Lock()
    lock_decorator_ = lock_decorator(lock=lock)
    assert lock_decorator_ == lock_decorator()

# Generated at 2022-06-25 13:24:20.560635
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class Test(object):
        def __init__(self, lock=None):
            if lock is None:
                self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def do_stuff_lock(self):
            print("Doing stuff")

        @lock_decorator(lock=threading.Lock())
        def do_stuff_no_lock(self):
            print("Doing stuff")

    test = Test()

    test.do_stuff_lock()
    test.do_stuff_no_lock()

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:24:29.590807
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self.foo = 0
            self.bar = 0

        @lock_decorator(attr='_lock')
        def modify_foo(self):
            self.foo += 1

        @lock_decorator(lock=threading.Lock())
        def modify_bar(self):
            self.bar += 1

    test = TestClass()
    with test._lock:
        try:
            test.modify_foo()
            assert False, 'expected LockFailedError'
        except threading.ThreadError as e:
            assert str(e) == 'modify_foo() called while lock is not held'

    test.modify_foo()

# Generated at 2022-06-25 13:24:37.104422
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Test lock_decorator
    '''
    import os
    import tempfile
    import shutil
    import sys

    from ansible_collections.martz.test.plugins.module_utils.helpers import (
        AnsibleExitJson,
        AnsibleFailJson,
        ModuleTestCase,
        set_module_args,
    )

    class TestCase(ModuleTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            super(TestCase, self).tearDown()
            shutil.rmtree(self.tmpdir)

    def gen_func():
        pass

    # Test case 0
    # test_case_0

# Generated at 2022-06-25 13:24:42.770705
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.utils.lock_decorator import lock_decorator

    # Unit test for function lock_decorator

    # Test with arguments that have one of their defaults replaced
    result = lock_decorator(attr='missing_lock_attr')
    assert isinstance(result, object)

    # Test with arguments that have one of their defaults replaced
    result = lock_decorator(lock=None)
    assert isinstance(result, object)

# Generated at 2022-06-25 13:24:45.585845
# Unit test for function lock_decorator
def test_lock_decorator():
    assert getattr(lock_decorator, '__name__', None) == 'lock_decorator'
    assert not getattr(lock_decorator, '__doc__', None) is None




# Generated at 2022-06-25 13:24:52.599808
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading

    my_thread = threading.Thread()
    my_lock = threading.Lock()

    @lock_decorator(lock=my_lock)
    def my_thread_run():
        my_thread.start()

    my_thread_run()

    my_thread.start.assert_called_once()

    @mock.patch('threading.Thread.start')
    @lock_decorator(attr='_callback_lock')
    def my_thread_run(self):
        self.start()

    my_thread_run()

    my_thread.start.assert_called_once()



# Generated at 2022-06-25 13:24:53.895012
# Unit test for function lock_decorator
def test_lock_decorator():

    # Arrange

    # Act

    # Assert
    assert True == True

# Generated at 2022-06-25 13:24:54.411510
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:59.585779
# Unit test for function lock_decorator
def test_lock_decorator():
    p = dict(attr='_callback_lock', lock=None)
    assert lock_decorator(**p)
    assert lock_decorator(attr='_callback_lock')

# Generated at 2022-06-25 13:25:00.982904
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:25:11.455839
# Unit test for function lock_decorator
def test_lock_decorator():
    import inspect

    def lock_decorator_test_function():
        return 'success'

    @lock_decorator(lock=None)
    def lock_decorator_test_function_no_lock():
        return 'success'

    # Test that we can successfully decorate the function
    # and still access the docstring, name, etc.
    lock_decorator_test_function = lock_decorator(lock=None)(lock_decorator_test_function)
    assert lock_decorator_test_function.__name__ == 'lock_decorator_test_function'
    assert inspect.getdoc(lock_decorator_test_function) == 'Test for lock_decorator'

    assert lock_decorator_test_function_no_lock() == 'success'

# Generated at 2022-06-25 13:25:12.338624
# Unit test for function lock_decorator
def test_lock_decorator():
    pass


# Generated at 2022-06-25 13:25:17.344938
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible import errors
    try:
        assert type(lock_decorator()) == function
        assert None == lock_decorator()
        assert None == lock_decorator()
        assert None == lock_decorator()
        assert None == lock_decorator()
    except AssertionError as e:
        raise errors.AnsibleFilterError(e.args[0])

# Generated at 2022-06-25 13:25:27.449163
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test for function 'lock_decorator'
    # Test for function 'lock_decorator'
    # Test for function 'lock_decorator'
    from unit.compat.mock import mock, patch
    from ansible.module_utils.basic import AnsibleModule

    testobj = AnsibleModule(
        argument_spec=dict()
    )

    with patch.object(testobj, 'exit_json') as mock_exit_json:
        with patch.object(testobj, 'fail_json') as mock_fail_json:
            lock_decorator()
    assert mock_exit_json.called
    assert not mock_fail_json.called


# Generated at 2022-06-25 13:25:34.372652
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import types

    def callback_function(lock_attr_arg, lock_arg):
        assert isinstance(lock_attr_arg, threading.Lock)
        assert isinstance(lock_arg, threading.Lock)

    @lock_decorator(attr='_lock_attr')
    def lock_attr_func(self):
        self.callback_func(self._lock_attr, self._lock)
    lock_attr_func.callback_func = callback_function

    @lock_decorator(lock=threading.Lock())
    def lock_func(self):
        self.callback_func(self._lock_attr, self._lock)
    lock_func.callback_func = callback_function


# Generated at 2022-06-25 13:25:34.878613
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:36.687590
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert var_1('attr')
    assert var_1('lock')

# Generated at 2022-06-25 13:25:46.578728
# Unit test for function lock_decorator
def test_lock_decorator():

    # Test module import preferences
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock
    from ansible_collections.ansible.community.plugins.module_utils import basic

    # setup ansible module
    mock_ansible_module = Mock()
    basic._ANSIBLE_ARGS = None
    mock_ansible_module.params = {}

    # Test with lock_decorator when no lock object is provided
    with patch('ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule') as mock_module:
        mock_module.return_value = mock_ansible_module
        post_result = basic.lock_decorator()
        assert post_result

    del basic._ANSIBLE_ARGS

    # Test with lock_dec

# Generated at 2022-06-25 13:25:51.101201
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:57.189753
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    with mock.patch('junit_runner.lock_decorator.getattr', side_effect=AttributeError()):
        var_0 = lock_decorator()
        with mock.patch('junit_runner.lock_decorator.lock') as mock_lock_0:
            with mock.patch('junit_runner.lock_decorator.func') as mock_func_0:
                var_1 = var_0(mock_func_0)
                with mock.patch('junit_runner.lock_decorator.args') as mock_args_0:
                    with mock.patch('junit_runner.lock_decorator.kwargs') as mock_kwargs_0:
                        var_1(*mock_args_0, **mock_kwargs_0)
                        mock_lock_

# Generated at 2022-06-25 13:26:06.278656
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert hasattr(lock_decorator, '__call__')
    assert hasattr(lock_decorator, '__class__')
    assert hasattr(lock_decorator, '__code__')
    assert lock_decorator.__code__.co_filename == '/Users/david/repo/ansible/lib/ansible/utils/module_docs_fragments/decorators.py'
    assert lock_decorator.__code__.co_argcount == 1
    assert lock_decorator.__code__.co_varnames == ('attr',)
    assert lock_decorator.__code__.co_flags & 4
    assert lock_decorator.__code__.co_flags & 32

# Generated at 2022-06-25 13:26:06.730567
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:07.453797
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator


# Generated at 2022-06-25 13:26:12.038084
# Unit test for function lock_decorator
def test_lock_decorator():
    class A(object):
        def __init__(self):
            self._lock = None

        @lock_decorator(attr='_lock')
        def test_method(self, a):
            return a

    a = A()
    assert a.test_method(5) == 5

    assert a._lock is not None

# Generated at 2022-06-25 13:26:14.700353
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test for missing lock
    try:
        var_0 = lock_decorator()
    except TypeError:
        pass

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:26:23.545348
# Unit test for function lock_decorator
def test_lock_decorator():
    import io
    from contextlib import contextmanager
    class FileLike(io.IOBase):
        __max_open_files = 2

        @classmethod
        @lock_decorator(attr='_open_files_lock', lock=None)
        def _open_files(cls):
            try:
                return cls._open_files
            except AttributeError:
                cls._open_files = 0
                return cls._open_files

        @classmethod
        @lock_decorator(attr='_open_files_lock', lock=None)
        def _increment_open_files(cls):
            cls._open_files += 1

        def _decrement_open_files(self):
            FileLike._open_files -= 1


# Generated at 2022-06-25 13:26:24.344189
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:26:29.412691
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator(attr='_callback_1')
    var_2 = lock_decorator(lock=1)

    @lock_decorator()
    def func_1(arg1, arg2):
        return arg1 + arg2
    @lock_decorator(lock='some_lock')
    def func_2():
        return None
    @lock_decorator(attr='_callback_3')
    def func_3(arg1, **tkwargs):
        return arg1
    assert lock_decorator



# Generated at 2022-06-25 13:26:38.030767
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:26:46.786442
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()

    from ansible import module_utils
    from ansible.module_utils.common.process import get_bin_path

    class Foo(object):
        @var_0
        def bar(self):
            return 1

        @var_0
        def baz(self):
            return 2

    var_1 = Foo()

    var_2 = get_bin_path('foo')

    var_3 = var_1.bar()

    var_4 = var_1.baz()

    var_5 = module_utils.is_non_shell_executable('/bin/sh')

    var_6 = module_utils.is_non_shell_executable('/bin/bash')


# Generated at 2022-06-25 13:26:48.117991
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:26:50.266340
# Unit test for function lock_decorator
def test_lock_decorator():
    from sos.utilities.tests import run_test_module_by_name
    run_test_module_by_name(__file__, "lock_decorator")
    return None

# Generated at 2022-06-25 13:26:50.813377
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:51.361767
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:26:55.120377
# Unit test for function lock_decorator
def test_lock_decorator():
    import datetime
    # Arguments:
    #   attr (str):
    #   lock (Lock):
    # Returns:
    #   Lock:
    testlock = datetime.datetime.now().timestamp()
    lock_decorator(attr=str(testlock))
    assert True

# Generated at 2022-06-25 13:27:03.619679
# Unit test for function lock_decorator
def test_lock_decorator():
    # Shuffle operations to randomize order
    from random import shuffle
    from unittest import TestCase, main
    from threading import Lock, RLock, Lock, Condition, Semaphore, BoundedSemaphore, Event

    from collections import Counter
    from time import sleep

    import multiprocessing


    class AllLocks(object):
        _lock = Lock()
        _rlock = RLock()
        _all = Lock()
        _cond = Condition()
        _sema = Semaphore()
        _bsema = BoundedSemaphore()
        _event = Event()

        @lock_decorator(attr='_lock')
        def lock(self):
            pass

        @lock_decorator(attr='_rlock')
        def rlock(self):
            pass


# Generated at 2022-06-25 13:27:04.632318
# Unit test for function lock_decorator
def test_lock_decorator():

    # testing for return type
    assert isinstance(lock_decorator(), function)

# Generated at 2022-06-25 13:27:14.120689
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import AnsibleLintRule

    class Test(_AnsibleLintRule):
        id = 'E999'
        shortdesc = 'Test lock_decorator'
        description = 'Test lock_decorator'
        severity = 'CRITICAL'
        tags = ['formatting']
        version_added = 'historic'

        @lock_decorator()
        def matchtask(self, file, task):
            return True
    results = Test().run()

# Generated at 2022-06-25 13:27:31.390890
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == stub(globals(), 'stub')

# Generated at 2022-06-25 13:27:39.767947
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()
    try:
        lock_decorator({'attr': 'missing_lock_attr', 'lock': None})
    except TypeError as e:
        assert e.args[0] == "lock_decorator() missing 1 required positional argument: 'func'"
    try:
        lock_decorator(attr={'attr': 'missing_lock_attr', 'lock': None})
    except TypeError as e:
        assert e.args[0] == "lock_decorator() missing 1 required positional argument: 'func'"
    try:
        lock_decorator(lock={'attr': 'missing_lock_attr', 'lock': None})
    except TypeError as e:
        assert e.args[0] == "lock_decorator() missing 1 required positional argument: 'func'"

# Generated at 2022-06-25 13:27:42.317200
# Unit test for function lock_decorator
def test_lock_decorator():
    timer = timeit.default_timer

    tic = timer()
    test_case_0()
    toc = timer()

    duration = toc - tic

    assert (duration > 0), "function ran without problem"

test_lock_decorator()

# Generated at 2022-06-25 13:27:51.930015
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert type(var_1) == type(lock_decorator)
    assert var_1.__name__ == "lock_decorator"

# Generated at 2022-06-25 13:27:53.796337
# Unit test for function lock_decorator
def test_lock_decorator():
    # Make sure we run the test twice, since the test will pass the second time
    for i in range(2):
        assert test_case_0() is None

# Generated at 2022-06-25 13:28:01.644749
# Unit test for function lock_decorator
def test_lock_decorator():

    # For testing, replace ``threading.Lock`` with a mock object
    import threading
    class Lock:
        def __enter__(self):
            pass
        def __exit__(self, type, value, traceback):
            pass

    # Test the ``attr`` argument
    class TestClass:
        def __init__(self):
            self._callback_lock = Lock()

        @lock_decorator(attr='_callback_lock')
        def some_method(self):
            return 'You got it!'

    tc = TestClass()
    assert tc.some_method() == 'You got it!'

    # Test the ``lock`` argument
    @lock_decorator(lock=Lock())
    def some_method_2():
        return 'You also got it!'


# Generated at 2022-06-25 13:28:09.481868
# Unit test for function lock_decorator
def test_lock_decorator():
    # Get function lock_decorator
    func = globals()['lock_decorator']

    # Check docstring
    msg = 'lock_decorator(attr=\'missing_lock_attr\', lock=None)'
    assert func.__doc__ == msg, 'lock_decorator should have a docstring of %s, got %s' % (msg, func.__doc__)

    # Check type of function
    assert isinstance(func, type(lambda:None)), 'lock_decorator should be a function'

    # Check basic functionality of function
    assert func(attr='missing_lock_attr', lock=None)

    # Check that argument 0 is a str

# Generated at 2022-06-25 13:28:10.981402
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    var_1 = test_case_0()


# Generated at 2022-06-25 13:28:11.742383
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True


# Generated at 2022-06-25 13:28:16.932247
# Unit test for function lock_decorator
def test_lock_decorator():

    # Unit test for function lock_decorator
    import unittest
    import threading
    import types

    class TestLockDecorator(unittest.TestCase):
        def test_lock_decorator_1(self):
            self.assertEqual(isinstance(lock_decorator, types.FunctionType), True, 'Argument should be a function')
            self.assertEqual(isinstance(lock_decorator(), (types.FunctionType, types.MethodType)), True, 'Argument should be a function or a method')

    unittest.main()



# Generated at 2022-06-25 13:28:53.141054
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1 == 1

# Generated at 2022-06-25 13:28:53.869590
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:54.896591
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:28:56.606210
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.sensu_go.common.lock_decorator import lock_decorator

    assert True

# Generated at 2022-06-25 13:28:57.084542
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:28:58.152373
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:28:59.196839
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator() is not None


# Generated at 2022-06-25 13:29:02.160348
# Unit test for function lock_decorator
def test_lock_decorator():
    class Test_lock_decorator(unittest.TestCase):
        def test___init__(self):
            pass

        def test___call__(self):
            pass

    unittest.main()

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:29:04.652273
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        assert True
    except AssertionError:
        raise AssertionError

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    try:
        test_case_0()
    except AssertionError:
        raise AssertionError
    test_lock_decorator()

# Generated at 2022-06-25 13:29:05.846678
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator) is True



# Generated at 2022-06-25 13:30:39.435512
# Unit test for function lock_decorator
def test_lock_decorator():
    print(lock_decorator())
    print(lock_decorator.__annotations__)

# Generated at 2022-06-25 13:30:39.984150
# Unit test for function lock_decorator
def test_lock_decorator():
    ...

# Generated at 2022-06-25 13:30:49.447231
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import ansible.module_utils.six as six

    class TestClass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.i = 0

        @lock_decorator(attr='lock')
        def noop(self):
            time.sleep(1)

        @lock_decorator(lock=threading.Lock())
        def inc(self):
            self.i += 1

    t = TestClass()

    t.noop()

    threads = []
    for _ in six.moves.xrange(4):
        threads.append(threading.Thread(target=t.inc))
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

# Generated at 2022-06-25 13:30:57.866825
# Unit test for function lock_decorator
def test_lock_decorator():
    # fmt: off
    # :func:`lock_decorator``

    ## - ``no_var_args``
    pass
    ## - ``one_var_arg``
    pass
    ## - ``pass_kwarg``
    pass
    ## - ``pass_kwargs``
    pass
    ## - ``multiple_var_args``
    pass
    ## - ``finally_no_return``
    pass
    ## - ``finally_return``
    pass
    ## - ``pass_kwargs``
    pass
    ## - ``multiple_var_args``
    pass
    ## - ``finally_no_return``
    pass
    ## - ``finally_return``
    pass
    ## - ``pass_kwargs``
    pass
    ## - ``multiple_var_args``
    pass
    ##

# Generated at 2022-06-25 13:30:58.195318
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:30:59.182236
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:31:04.730720
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    from ansible.utils.hashing import md5s

    class TestLock(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def method_0(self):
            return 'method_0'

        @lock_decorator()
        def method_1(self):
            return 'method_1'

        @lock_decorator(lock=threading.Lock())
        def method_2(self):
            return 'method_2'

    test = TestLock()

    test_results = {}

    def thread_method(methname):
        start = time.time()
        rval = getattr(test, methname)()
        end = time.time()
        test_

# Generated at 2022-06-25 13:31:05.932663
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator


# Test using some code that is too complex to understand

# Generated at 2022-06-25 13:31:14.522577
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.runner import Runner
    from ansiblelint import RulesCollection
    from ansiblelints.rules.AvoidUsingLockDecorator import AvoidUsingLockDecorator

    input_paths = ['./test/ansible-lint-invalid-files/']

    rules_files = ['ansiblelints/rules/AvoidUsingLockDecorator.py']
    rules = RulesCollection.create_from_files(rules_files)
    runner = Runner(rules, input_paths, [], [], [])
    results = runner.run()
    assert len(results) == 1
    assert results[0].rule == 'ANSIBLE0009'
    assert results[0].linenumber == 4
    assert results[0].column == 0
    assert results[0].rule_type == 'VALUE'

# Generated at 2022-06-25 13:31:15.326756
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)