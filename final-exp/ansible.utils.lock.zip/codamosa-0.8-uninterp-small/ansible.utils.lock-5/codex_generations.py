

# Generated at 2022-06-25 13:24:02.824312
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'missing 1 required positional argument' in str(excinfo.value)

# Generated at 2022-06-25 13:24:08.319072
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not None
    assert lock_decorator(attr='missing_lock_attr', lock=None)(func) is not None
    assert lock_decorator(attr='missing_lock_attr', lock=None)(func)(self=None) is not None
    assert lock_decorator(attr='missing_lock_attr', lock=None)(func)(self=None, other=None) is not None


# Generated at 2022-06-25 13:24:09.108150
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()

# Generated at 2022-06-25 13:24:11.877830
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.sivel.tartufo.plugins.module_utils.lock import lock_decorator

    func_0 = lock_decorator(attr='missing_lock_attr', lock=None)

# Generated at 2022-06-25 13:24:19.821509
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    class TestLockDecorator(unittest.TestCase):
        def test_case_0(self):
            test_case_0()

    test_cases = [
        TestLockDecorator,
    ]

    for test_case in test_cases:
        print(f'Running {test_case.__name__}')
        suite = unittest.TestLoader().loadTestsFromTestCase(test_case)
        unittest.TextTestRunner().run(suite)


if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:24:25.494321
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.LockDecoratorRule import LockDecoratorRule

    rules_collection = RulesCollection() 
    rules_collection.register(LockDecoratorRule())
    pattern = 'test/lock_decorator-example.py'
    runner = Runner(rules_collection, {}, [pattern], [], [])
    results = runner.run()
    runner.stats['total']['errors'] == 0

# Generated at 2022-06-25 13:24:26.427983
# Unit test for function lock_decorator
def test_lock_decorator():
    pass



# Generated at 2022-06-25 13:24:34.116624
# Unit test for function lock_decorator
def test_lock_decorator():
    # TODO: Implement test_lock_decorator
    raise NotImplementedError


#
# The following is a hack to allow us to expose the test cases
# defined above as individual functions, not methods of a class.
# That is, the following allows modules like test/unit/modules/test_template.py
# to just import this file and access the functions directly.
#
# test/unit/modules/test_template.py
#     from ansible.module_utils.basic import AnsibleModule
#     from ansible.module_utils.helpers import lock_decorator
#     lock_decorator.test_case_0()
#
import os
import sys

if __name__ == '__main__':
    bn = os.path.basename(__file__)

# Generated at 2022-06-25 13:24:38.697904
# Unit test for function lock_decorator
def test_lock_decorator():
    # Note: Classes that have a __call__ method, such as type.
    # <type 'type'>
    assert isinstance(lock_decorator, type)
    assert lock_decorator()

    # Simple test with no attributes, returns function
    def test_func_0(): pass
    assert lock_decorator()(test_func_0)

    # Simple test with an attribute, and no arguments, returns function
    def test_func_1(): pass
    assert lock_decorator(attr='something')(test_func_1)

    # Simple test with an attribute, and no arguments, returns function
    def test_func_2(): pass
    assert lock_decorator(lock=True)(test_func_2)

# Generated at 2022-06-25 13:24:39.762691
# Unit test for function lock_decorator
def test_lock_decorator():
    global var_0
    assert var_0 is None

# Generated at 2022-06-25 13:24:50.705355
# Unit test for function lock_decorator

# Generated at 2022-06-25 13:24:53.772809
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()

    var_2 = lock_decorator('missing_lock_attr')

    var_3 = lock_decorator(lock=None)

    # Some code here to exercise the function.

    pass
    # Unit test for function lock_decorator


# Generated at 2022-06-25 13:24:55.721568
# Unit test for function lock_decorator
def test_lock_decorator():
    # Tests for function lock_decorator
    assert callable(lock_decorator)


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:24:56.261725
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:58.493898
# Unit test for function lock_decorator
def test_lock_decorator():

    assert callable(lock_decorator)
    # AssertionError: assert <function ...

# Generated at 2022-06-25 13:24:59.864826
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:25:10.321766
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import os
    import pytest
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import lock_decorator

    # Try passing a module to use
    try:
        import threading
    except ImportError:
        pytest.skip("threading module is not available")

    # Create a class to use in the test
    class TestClass:
        def __init__(self):
            self.lock = threading.Lock()
            self.lock_value = 0

        @lock_decorator(lock=self.lock)
        def lock_method(self):
            self.lock_value = 1

    tc = TestClass()

    # Test that the lock is working correctly
    tc.lock_method()
    assert tc.lock_value == 1


# Unit test

# Generated at 2022-06-25 13:25:18.879556
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading
    lock = threading.Lock()

# Generated at 2022-06-25 13:25:20.069423
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:21.056064
# Unit test for function lock_decorator
def test_lock_decorator():
    assert False, "Tests not implemented"

# Generated at 2022-06-25 13:25:25.837316
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:25:31.248111
# Unit test for function lock_decorator
def test_lock_decorator():
    arg_0 = None
    arg_1 = None

    # Call lock_decorator
    # AssertionError: <unprintable Lock object> != <unprintable Lock object>
    try:
        ret_0 = lock_decorator(arg_0, arg_1)
    except AssertionError as err:
        print("AssertionError: {} != {}".format(err.args[0], err.args[1]))



# Generated at 2022-06-25 13:25:36.361565
# Unit test for function lock_decorator
def test_lock_decorator():
    # Unit test for function lock_decorator
    # This test does not include any test for ``lock``, as that was
    # not included in the original PR.
    import threading
    import time

    class TestClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._counter = 0

        @lock_decorator(attr='_lock')
        def incrememnt(self):
            self._counter += 1
            time.sleep(.5)
            return self._counter

    tc = TestClass()

    def increment():
        print('Start of thread')
        print(tc.incrememnt())
        print('End of thread')

    t1 = threading.Thread(target=increment)
    t2 = threading.Thread(target=increment)
   

# Generated at 2022-06-25 13:25:39.583972
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError) as excinfo:
        assert test_case_0()
    assert str(excinfo.value) == 'lock_decorator() missing 1 required positional argument: \'func\''



# Generated at 2022-06-25 13:25:49.067584
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    import threading
    import time

    module = AnsibleModule(argument_spec={'attr': dict(type='str')})
    module.fail_json = lambda **kwargs: pytest.fail('Invalid call to fail_json')

    @lock_decorator(attr='attr')
    def _test_function(attr):
        '''This function is marked as no cover because we rely on
        the test data being ``tested``.
        '''
        assert attr == 'hello'
        time.sleep(0.1)


# Generated at 2022-06-25 13:25:56.013101
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert callable(var_1) == True

# TestMockUnitExec
mock_input = [
    'test_input_0',
    'test_input_1',
    'test_input_2',
]

mock_output = [

    # Case 0
    'test_output_0',

    # Case 1
    'test_output_1',

    # Case 2
    'test_output_2'
]

mock_error = [
    'test_error_0',
    'test_error_1',
    'test_error_2'
]

mock_program = [
    'ansible-test units --color -v',
    'test/units/test_mock_unit_exec.py'
]



# Generated at 2022-06-25 13:25:57.496924
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:25:59.185557
# Unit test for function lock_decorator
def test_lock_decorator():
    # TODO: Implement functional test for lock_decorator
    assert True


# Generated at 2022-06-25 13:26:00.281423
# Unit test for function lock_decorator
def test_lock_decorator():
    pass



# Generated at 2022-06-25 13:26:07.932376
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    # Testing if the type of var_1 is <class 'function'>
    assert isinstance(var_1, type(lock_decorator)), "Test case 0 failed."
    var_2 = var_1('missing_lock_attr')
    # Testing if the type of var_2 is <class 'function'>
    assert isinstance(var_2, type(lock_decorator)), "Test case 1 failed."
    var_3 = var_2(attr='missing_lock_attr', lock=None)
    # Testing if the type of var_3 is <class 'function'>
    assert isinstance(var_3, type(lock_decorator)), "Test case 2 failed."
    var_4 = var_3(func=None)
    # Testing if the type of var_4 is <

# Generated at 2022-06-25 13:26:16.487099
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:19.670526
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test of case 0
    x_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert type(x_0) == 'function'
    assert x_0() is None



# Generated at 2022-06-25 13:26:22.865099
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert callable(var_0)
    assert isinstance(var_0, lock_decorator)
    var_1 = lock_decorator()
    assert var_0 is not var_1


# Generated at 2022-06-25 13:26:24.828097
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator(attr='missing_lock_attr', lock=None)


# Generated at 2022-06-25 13:26:25.884366
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()

# Generated at 2022-06-25 13:26:27.091108
# Unit test for function lock_decorator
def test_lock_decorator():
    # testing for function lock_decorator
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:26:29.246782
# Unit test for function lock_decorator
def test_lock_decorator():
    assert var_0 == lock_decorator()
    assert var_0.__name__ == lock_decorator.__name__

# Generated at 2022-06-25 13:26:39.598845
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    import threading
    global_lock = threading.Lock()
    local_lock = threading.Lock()

    result = {}

    class TestObject(object):
        def __init__(self, local_lock=None):
            if local_lock is None:
                self.local_lock = threading.Lock()
            else:
                self.local_lock = local_lock

        @lock_decorator()
        def failure_no_args(self):
            module.fail_json(msg='lock_decorator() should require one of args')


# Generated at 2022-06-25 13:26:41.210248
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert var_1 is not None


# Generated at 2022-06-25 13:26:44.865415
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestCase, main

    class Test0(TestCase):
        def test_0(self):
            test_case_0()

    test_cases = [
        Test0
    ]

    main(module='test_lock_decorator', verbosity=2, exit=False)

# Generated at 2022-06-25 13:27:01.633051
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:27:10.683009
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.ANSIBLE0003 import (lock_decorator)

    # these test cases are not actually for the decorator code,
    # but for the grammar parsing of the decorator
    result = lock_decorator(lock=None)

    # this is a very simple test, but it does make sure that
    # things are happening as they should
    def dummy_func():
        pass
    decorated_func = result(dummy_func)
    if decorated_func.__name__ != 'dummy_func':
        raise AssertionError('lock_decorator did not preserve name of wrapped function')
    if decorated_func.__doc__ != dummy_func.__doc__:
        raise AssertionError('lock_decorator did not preserve docstring of wrapped function')

# Generated at 2022-06-25 13:27:20.551565
# Unit test for function lock_decorator
def test_lock_decorator():
    import logging
    import application.python.lock
    import threading

    log = logging.getLogger('test_lock_decorator')

    @lock_decorator()
    def missing_lock_attr(self):
        log.info('Missing lock attr')

    @lock_decorator(lock=threading.Lock())
    def explicit_lock_attr(self):
        log.info('Explicit lock attr')

    class LockDecoratorTest(application.python.lock.Lockable, object):
        def __init__(self):
            application.python.lock.Lockable.__init__(self)
            object.__init__(self)

        @lock_decorator()
        def missing_lock_attr(self):
            log.info('Class missing lock attr')


# Generated at 2022-06-25 13:27:21.060756
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:27:23.004972
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        var_0 = lock_decorator()
    except Exception as e:
        var_1 = e
    var_2 = var_1 is not None

# Generated at 2022-06-25 13:27:25.326754
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator.__name__ == 'lock_decorator'
    assert lock_decorator.__doc__ is not None

# Generated at 2022-06-25 13:27:32.738043
# Unit test for function lock_decorator
def test_lock_decorator():
    with patch("threading.Lock") as mock_Lock:
        mock_Lock.return_value = "threading.Lock"
        mock_self = Mock()
        mock_self.send_callback = lock_decorator(attr="_callback_lock")
        mock_self.send_callback()
        mock_Lock.assert_called_once_with()
        mock_Lock.assert_called_once_with()
        mock_self.send_callback.__wrapped__.assert_called_once_with()
        with patch("ansible.module_utils.basic.lock_decorator.lock_decorator") as mock_lock_decorator:
            mock_lock_decorator.return_value = "ansible.module_utils.basic.lock_decorator.lock_decorator"
            mock_lock_

# Generated at 2022-06-25 13:27:40.402674
# Unit test for function lock_decorator
def test_lock_decorator():
    # Init global variables
    global lock_decorator_var_0
    global lock_decorator_var_1
    global lock_decorator_var_2

    # Set one of the input parameters
    attr = lock_decorator_var_0
    lock = lock_decorator_var_1


    # These lines can be removed once the parameters are set.
    lock_decorator_var_0 = None
    lock_decorator_var_1 = None
    lock_decorator_var_2 = None

    # Call the function
    output = lock_decorator(attr, lock)
    return_value = output

    # Check the results
    assert return_value == lock_decorator_var_2


# Generated at 2022-06-25 13:27:42.228494
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    # assert lock_decorator() ==
    print(lock_decorator())


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:27:43.316697
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 is not None


# Generated at 2022-06-25 13:28:21.166233
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 13:28:28.149406
# Unit test for function lock_decorator
def test_lock_decorator():
    print('Start test_lock_decorator')
    print(lock_decorator.__doc__)

    # This unit test actually won't work in the documentation
    # but is useful to show how to use the decorator
    import threading
    class Callback(object):

        def __init__(self):
            self._callback_lock = threading.Lock()
            self._callback = []

        # Use ``attr`` to specify the instance attribute that
        # is the lock
        @lock_decorator(attr='_callback_lock')
        def send_callback(self, callback):
            self._callback.append(callback)

        # Use ``lock`` to specify the lock object directly

# Generated at 2022-06-25 13:28:36.191565
# Unit test for function lock_decorator
def test_lock_decorator():

    import mock
    import threading
    import time

    lock = threading.Lock()

    def test_generator(lock_attr):
        # Python2 doesn't have ``nonlocal``
        # assign the actual lock to ``_lock``
        if lock_attr is None:
            _lock = lock
        else:
            _lock = mock.Mock()

        @lock_decorator(attr=lock_attr, lock=_lock)
        def func(*args, **kwargs):
            with lock:
                return 'return value'
        return func

    def func0(*args, **kwargs):
        with lock:
            return 'return value'

    for lock_attr in [None, 'attr']:

        func = test_generator(lock_attr)

        func_return = func()

# Generated at 2022-06-25 13:28:36.679814
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:42.989900
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestCase
    from .compat import mock

    class MyTestCase(TestCase):
        lock_attr = '_my_lock'
        lock = mock.MagicMock()

        @lock_decorator(lock_attr)
        def foo(self):
            pass

        @lock_decorator(lock=lock)
        def bar(self):
            pass

    my_test_case = MyTestCase()
    my_test_case.foo()
    assert my_test_case.lock_attr._my_lock.__enter__.called
    assert my_test_case.lock_attr._my_lock.__exit__.called
    my_test_case.bar()
    assert my_test_case.lock.__enter__.called
    assert my_test_case.lock.__exit

# Generated at 2022-06-25 13:28:43.468518
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:28:52.226599
# Unit test for function lock_decorator
def test_lock_decorator():
    from pprint import pprint
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.sivel_2012 import lock_decorator

    # Basic examples

    assert lock_decorator.lock_decorator()

    result = lock_decorator.lock_decorator()

    assert callable(result)

    assert lock_decorator.lock_decorator(attr='attr')

    result = lock_decorator.lock_decorator(attr='attr')

    assert callable(result)

    assert lock_decorator.lock_decorator(lock='lock')

    result = lock_decorator.lock_decorator(lock='lock')

    assert callable(result)

# Generated at 2022-06-25 13:28:53.405326
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:28:54.065332
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:29:01.775020
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock, Thread

    # An object with a lock, and a list to track output
    # The lock will be accessed via a method
    class A(object):
        def __init__(self):
            self.data = []
            self.lock = Lock()
            self.x = False

        @lock_decorator(attr='lock')
        def append_1(self):
            self.data.append(1)

        @lock_decorator(attr='lock')
        def append_2(self):
            self.data.append(2)

        @lock_decorator(attr='lock')
        def append_3(self):
            self.data.append(3)

    # An object with a lock, and a list to track output
    # The lock will be accessed via a pre-defined lock object


# Generated at 2022-06-25 13:30:39.180246
# Unit test for function lock_decorator
def test_lock_decorator():

    import time
    from threading import Thread
    from queue import Queue
    from multiprocessing import Process

    @lock_decorator(attr='_lock')
    def shared_var(self, n):
        time.sleep(.5)
        self.var += n

    class Test(object):
        def __init__(self):
            self.var = 0
            self._lock = threading.Lock()

        def test_shared_var(self, n):
            shared_var(self, n)

    def check_status(var, val, errors_found):
        errors_found.put(var.var != val)
        return var.var

    def test_shared_var(self):
        shared_var(self)


# Generated at 2022-06-25 13:30:44.638916
# Unit test for function lock_decorator
def test_lock_decorator():
    # Run function lock_decorator with correct arguments
    assert callable(lock_decorator(lock=None, attr='missing_lock_attr'))

    # Run function lock_decorator with incorrect arguments
    try:
        lock_decorator(lock=lock_decorator(), attr=lock_decorator(attr='missing_lock_attr'))
    except TypeError:
        assert True

# Test if lock_decorator fails when called incorrectly

# Generated at 2022-06-25 13:30:48.198359
# Unit test for function lock_decorator
def test_lock_decorator():
    # Make sure that lock_decorator has been defined
    _lock_decorator = getattr(lock_decorator, '_lock_decorator', None)
    assert _lock_decorator is not None, "lock_decorator is not defined"


# Generated at 2022-06-25 13:30:49.408535
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 13:30:52.862339
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules import LockDecoratorRule
    from ansiblelint.runner import Runner

    runner = Runner(LockDecoratorRule())
    runner.run_tests(['lib/ansiblelint/rules/test_lock_decorator.py'])

# Generated at 2022-06-25 13:30:58.786677
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    @var_1
    def test_case_0():
        pass

    var_2 = lock_decorator(attr='_global_lock')
    @var_2
    def test_case_1():
        pass

    var_3 = lock_decorator(lock='')
    @var_3
    def test_case_2():
        pass

    var_4 = lock_decorator(attr='_global_lock', lock='_global_lock')
    @var_4
    def test_case_3():
        pass

# Generated at 2022-06-25 13:31:00.137068
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()


# Generated at 2022-06-25 13:31:00.689347
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()

# Generated at 2022-06-25 13:31:01.587984
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:31:10.087345
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator
    var_0()  # Method lock_decorator() does not exist

    @lock_decorator
    def test_0():
        print("Test 0")

    # assert "@lock_decorator" in test_0.__name__,
    # "test_0 function name is not decorated"
    # assert "@lock_decorator" in test_0.__doc__,
    # "test_0 function docstring is not decorated"

    test_0()

    @lock_decorator(attr='_lock')
    def test_1(self, a, b):
        """This is the docstring of test_1"""
        print("Test 1")
        return a + b
