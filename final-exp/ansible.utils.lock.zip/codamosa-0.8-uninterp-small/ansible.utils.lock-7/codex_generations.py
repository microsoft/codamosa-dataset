

# Generated at 2022-06-25 13:24:08.963873
# Unit test for function lock_decorator
def test_lock_decorator():

    import random
    import threading
    import time

    class SomeClass(object):
        def __init__(self):
            self._lock = threading.Lock()
            self._a = 0

        def __repr__(self):
            return '<%s>' % (self.__class__.__name__,)

        @lock_decorator(attr='_lock')
        def __foo(self):
            '''This method is not intended to be called by external code.
            '''
            self._a += 1
            time.sleep(random.randint(1, 4))
            return self._a

        def foo(self):
            return self.__foo()

    # Make sure @lock_decorator works
    some_obj = SomeClass()
    assert some_obj.foo() == 1
    assert some

# Generated at 2022-06-25 13:24:09.772934
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:13.957598
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case provisions
    global var_0

    var_0 = None

    @lock_decorator()
    def test_case_0():
        global var_0
        var_0 = True

    test_case_0()

    # Test assertion(s)
    assert var_0

# Generated at 2022-06-25 13:24:16.155041
# Unit test for function lock_decorator
def test_lock_decorator():
    from .test_lock_decorator_import import test_lock_decorator_0
    test_lock_decorator_0()

# Generated at 2022-06-25 13:24:17.448205
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:24:18.771023
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:20.030451
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert var_1 is not None

# Generated at 2022-06-25 13:24:23.575290
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError) as err:
        test_case_0()
    assert err.value.args[0] == "lock_decorator() missing 1 required keyword-only argument: 'arg'"

# vim: set expandtab shiftwidth=4 tabstop=4:

# Generated at 2022-06-25 13:24:25.931292
# Unit test for function lock_decorator
def test_lock_decorator():
    import pickle
    # pickle fails on a function wrapped with lock_decorator
    # this test exists purely as a coverage target
    pickle.dumps(test_case_0)

# Generated at 2022-06-25 13:24:26.520910
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:24:34.993850
# Unit test for function lock_decorator
def test_lock_decorator():
    # This method is mocked to only print the input and return the value, so
    # we don't have to worry about passing in all the other arguments.
    def the_func(value_0):
        '''Mocked method for testing'''
        print('Received', value_0)
        return value_0

    def mocked_method(self, value):
        '''Mocked method for testing'''
        return the_func(value)

    # Mock out a class with an instance attribute that's a lock, then wrap
    # the instance method in the lock decorator.
    class C0:
        _lock = threading.Lock()
        def the_method(self, value):
            return the_func(value)

    C0.the_method = lock_decorator(attr='_lock')(C0.the_method)



# Generated at 2022-06-25 13:24:35.510707
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True

# Generated at 2022-06-25 13:24:42.813081
# Unit test for function lock_decorator
def test_lock_decorator():
    import ansible.module_utils.basic

    attr = 'attr_0'
    decor_0 = lock_decorator(attr=attr)

    class TestClassOne(object):
        attr_0 = None

        @decor_0
        def test(self, a, b):
            return '{0}:{1}'.format(a, b)

    ansible.module_utils.basic.missing_lock_attr = 'attr_0'
    obj_0 = TestClassOne()
    ret_0 = obj_0.test('a', 'b')
    assert ret_0 == 'a:b'

# Generated at 2022-06-25 13:24:44.047453
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:24:47.215311
# Unit test for function lock_decorator
def test_lock_decorator():
    print( "Test for lock_decorator")
    # Test for lock_decorator
    assert True == True


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:24:48.400221
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 13:24:49.038773
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:56.183423
# Unit test for function lock_decorator

# Generated at 2022-06-25 13:24:57.624255
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:58.883500
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case 0
    yield (test_case_0,)

# Generated at 2022-06-25 13:25:13.022530
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    from test.support import TestData

    class TestObj(object):
        # Make sure we don't break unittest.TestCase
        _tests = []
        _cleanups = []

        def __init__(self):
            self._test_lock = mock.MagicMock()

        @lock_decorator(attr='_test_lock')
        def test_method_1(self):
            pass

        @lock_decorator(lock=mock.MagicMock())
        def test_method_2(self):
            pass

    test = TestObj()
    with mock.patch.object(test, '_test_lock') as lck:
        test.test_method_1()
        assert lck.__enter__.called
        assert lck.__exit__.called


# Generated at 2022-06-25 13:25:13.540426
# Unit test for function lock_decorator
def test_lock_decorator():
    pass



# Generated at 2022-06-25 13:25:15.393852
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:25:16.553317
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test 0
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:25:18.507993
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()


# Generated at 2022-06-25 13:25:19.550235
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:25:21.188436
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Unit tests for function test_0

# Generated at 2022-06-25 13:25:28.835772
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    l = threading.Lock()

    class Foo(object):
        def __init__(self):
            self.attr = True
            self.lock = threading.Lock()

        @lock_decorator()
        def missing_lock_attr_method(self):
            assert self.attr

        @lock_decorator(attr='attr')
        def attr_method(self):
            assert self.attr

        @lock_decorator(lock=l)
        def lock_method(self):
            assert self.attr

        @lock_decorator(lock=lock)
        def lock_kwarg_method(self):
            assert self.attr

# Generated at 2022-06-25 13:25:31.690761
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Lock
    def func0(self):
        func0.lock
    lock = Lock()
    func0.lock = lock

    lock_decorator()(func0)(None)

    lock_decorator()(func0)
    lock_decorator(attr='lock')(func0)
    lock_decorator(lock=lock)(func0)

# Generated at 2022-06-25 13:25:35.374542
# Unit test for function lock_decorator
def test_lock_decorator():
    # Ensure ``lock_decorator`` does not have an ``__wrapped__`` attribute
    # This is a workaround for a bug in the python2 version of ``functools``
    assert not hasattr(lock_decorator, '__wrapped__')
    assert lock_decorator(attr='missing_lock_attr', lock=None) is lock_decorator

# Generated at 2022-06-25 13:25:51.534637
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import argparse
    import sys
    import os
    import shutil
    import glob

    with pytest.raises(KeyError) as excinfo:
        sys.argv = ['ansible-test', 'lock_decorator', '--truncate', '-v']
        print(' *** Unit Test *** ')
        pytest.main(['-qq', 'unit_tests.py'])
    if excinfo.value.args[0] != "dict contains fields not in fieldnames: '_ansible_verbosity'":
        raise Exception(excinfo)

    with pytest.raises(SystemExit):
        sys.argv = ['ansible-test', 'lock_decorator', '--color', 'never']
        print(' *** Unit Test *** ')

# Generated at 2022-06-25 13:25:57.829466
# Unit test for function lock_decorator
def test_lock_decorator():
    # Register cases for function lock_decorator
    cases = [
        # (case_0),
        # (case_1),
        # (case_2),
        # (case_3),
        # (case_4),
        # (case_5),
        # (case_6),
        # (case_7),
        # (case_8),
        # (case_9),
    ]
    # Create an instance of ClassTestCase
    case_test_lock_decorator = ClassTestCase(test_case_0, cases)



# Generated at 2022-06-25 13:25:58.492311
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:25:59.389940
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator is not None

# Generated at 2022-06-25 13:26:07.586820
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.UseLockDecoratorRule import UseLockDecorator
    from ansiblelint.rules.UseLockDecoratorRule import get_lock_decorator
    from ansiblelint.rules.UseLockDecoratorRule import (
        get_lock_decorator_variable
    )
    import ast
    import sys

    # python2 and python3 have different AST nodes
    if sys.version_info[0] == 2:
        decorator = ast.Decorator
    else:
        decorator = ast.AnnAssign
    # setup test
    filename = 'test.py'
    raw_ast = ast.parse(test_case_0.__code__)
    decorated_func = raw_ast.body[0]

    # test None conditions
    assert get_lock_decorator

# Generated at 2022-06-25 13:26:08.305959
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:26:08.777208
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:12.378188
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator('_callback_lock')


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 13:26:17.090014
# Unit test for function lock_decorator
def test_lock_decorator():
    print("Test lock_decorator", end='')

    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError:', e)
        return
    except Exception as e:
        print('Exception:', e)
        return
    print(' - OK')

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:26:25.674795
# Unit test for function lock_decorator
def test_lock_decorator():
    # This function tests the functionality of the lock_decorator decorator
    
    # Setup
    ############################################################################
    import threading

    # Test Cases
    ############################################################################
    @lock_decorator()
    def test_case_1():
        try:
            yield
        except Exception as e:
            raise e
        finally:
            pass

    @lock_decorator()
    def test_case_2(cls, callback, action, **kwargs):
        try:
            yield
        except Exception as e:
            raise e
        finally:
            pass

    @lock_decorator(attr='_callback_lock')
    def test_case_3(cls, callback, action, **kwargs):
        try:
            yield
        except Exception as e:
            raise e
       

# Generated at 2022-06-25 13:26:44.616725
# Unit test for function lock_decorator
def test_lock_decorator():
    # Check function lock_decorator for errors
    pass


if __name__ == '__main__':
    # This is used to run the test in the container
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:26:50.853235
# Unit test for function lock_decorator
def test_lock_decorator():
    """Test the lock_decorator function
    """
    from ansible.utils.lock import lock_decorator
    from ansible.plugins.loader import get_all_plugin_loaders
    assert lock_decorator is not None

    for path in get_all_plugin_loaders():
        for name in path._get_all_plugin_loaders():
            if name == 'v2.lookup':
                for plugin in path.all(name):
                    if plugin.__doc__:
                        assert plugin.__name__ in plugin.__doc__
                    else:
                        plugin.__doc__
    pass

# Generated at 2022-06-25 13:26:51.745368
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()


# Generated at 2022-06-25 13:26:58.313328
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create a dummy class to use in the test
    class Dummy:
        pass

    # Call the function and store the result in dummy
    dummy = Dummy()
    result = lock_decorator(attr='_callback_lock')(dummy)

    # Assert result is a callable
    assert callable(result)

    # Call the function again and store the result in dummy
    dummy = Dummy()
    result = lock_decorator(attr='_callback_lock')(dummy)

    # Assert result is a callable
    assert callable(result)

# Generated at 2022-06-25 13:26:59.535306
# Unit test for function lock_decorator
def test_lock_decorator():

    assert callable(lock_decorator)
    test_case_0()

# Generated at 2022-06-25 13:27:00.426614
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator() != lock_decorator

# Generated at 2022-06-25 13:27:09.798264
# Unit test for function lock_decorator
def test_lock_decorator():
    import paramiko
    import threading

    lock = threading.Lock()
    ssh = paramiko.SSHClient()
    ssh._lock = lock
    print(lock)
    print(ssh._lock)
    print(type(lock))
    print(type(ssh._lock))

    class TestLock(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.ssh = paramiko.SSHClient()
            self.ssh._lock = self.lock
            print(self.lock)
            print(self.ssh._lock)
            print(type(self.lock))
            print(type(self.ssh._lock))

    TestLock()


# Generated at 2022-06-25 13:27:10.677315
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:27:12.383709
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True
    # Test cases to function lock_decorator
    test_case_0()



# Generated at 2022-06-25 13:27:21.937380
# Unit test for function lock_decorator
def test_lock_decorator():
    import multiprocessing
    import threading
    from time import sleep
    from time import time


    def unsynchronized_update(semaphore, list, item):
        sleep(0.1)
        list.append(item)


    # Setup the list, semaphore and worker threads
    work = []
    semaphore = lock_decorator()
    threads = [
        threading.Thread(target=unsynchronized_update, args=(semaphore, work, i))
        for i in range(10)
    ]

    # Start all threads
    [thread.start() for thread in threads]

    # Wait for all threads to complete
    [thread.join() for thread in threads]

    # Tests
    assert len(work)==10, 'Locked decorator did not work'



# Generated at 2022-06-25 13:27:56.374672
# Unit test for function lock_decorator
def test_lock_decorator():
    assert __salt__['test.echo']('Test passed!') == 'Test passed!'

# Generated at 2022-06-25 13:28:01.028252
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator


#
# The remainder of this module is used to test the lock_decorator
# decorator.
#

from collections import defaultdict
from functools import partial
import json
import logging
import os
import re
import sys
import unittest


# This is a custom class used by the test classes below, to demonstrate
# that we can use either a lock instance, or an instance attribute for
# the lock

# Generated at 2022-06-25 13:28:08.932985
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import random
    import re
    import string
    import time
    from threading import Lock, Thread

    var_0 = lock_decorator()

    # Verify that the lock attribute is set correctly
    var_1 = Lock()
    var_2 = lock_decorator(lock=var_1)
    var_3 = var_2.__name__
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    var_4 = builtins.__dict__['repr']
    var_5 = var_4(var_3)
    var_6 = var_5
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    var_7 = builtins.__dict__['repr']
    var_

# Generated at 2022-06-25 13:28:16.227611
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from jnpr.junos.utils.scp import SCP
        from jnpr.junos.exception import LockError
    except:
        pass
    else:
        import mock
        import threading
        _SCP = SCP()
        with mock.patch('paramiko.SSHClient.exec_command') as mock_exec_cmd:
            _SCP.put('foo', 'bar')
            _SCP.put('foo', 'bar')
            mock_exec_cmd.assert_called_once()

        _SCP = SCP(lock=None)
        with mock.patch('paramiko.SSHClient.exec_command') as mock_exec_cmd:
            _SCP.put('foo', 'bar')
            _SCP.put('foo', 'bar')
            mock_exec_cmd.assert_called_once()



# Generated at 2022-06-25 13:28:19.323029
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup mock
    attr = 'missing_lock_attr'
    lock = None

    # Execution
    ret = lock_decorator(attr=attr, lock=lock)

    # Verify
    assert ret is not None

    # Cleanup - none necessary



# Generated at 2022-06-25 13:28:26.413764
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test with positional arguments
    assert lock_decorator(attr='missing_lock_attr', lock=None)

    try:
        lock_decorator(1, 2, 3)
    except TypeError as exc:
        assert 'takes from 1 to 2 positional arguments but 3 were given' in str(exc)

    try:
        lock_decorator(attr=1)
    except TypeError as exc:
        assert 'argument "lock" must be of type' in str(exc)

    # Test with keyword arguments
    assert lock_decorator(attr='missing_lock_attr', lock=None)

    try:
        lock_decorator(attr=1, extra=True)
    except TypeError as exc:
        assert "got an unexpected keyword argument 'extra'" in str(exc)


# Generated at 2022-06-25 13:28:28.771172
# Unit test for function lock_decorator
def test_lock_decorator():
    '''
    Test that lock_decorator function returns correct output
    '''

    # Test case 0
    # Testing with no parameters.
    try:
        test_case_0()
    except:
        pass


# Generated at 2022-06-25 13:28:29.507384
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:28:30.503949
# Unit test for function lock_decorator
def test_lock_decorator():
    res = lock_decorator() # noqa



# Generated at 2022-06-25 13:28:37.644356
# Unit test for function lock_decorator
def test_lock_decorator():
    from test_cases.unit_tests.common import TestCase
    from ansible.module_utils.six import with_metaclass

    class Test(with_metaclass(TestCase, object)):

        def __init__(self, *args, **kwargs):
            pass

        @lock_decorator(attr='lock_decorator_0')
        def test_function(self):
            pass

    test_instance = Test()
    assert not hasattr(test_instance, 'lock_decorator_0')
    test_instance.test_function()
    assert hasattr(test_instance, 'lock_decorator_0')



# Generated at 2022-06-25 13:30:03.166469
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1, 'Not implemented'

# Generated at 2022-06-25 13:30:03.642185
# Unit test for function lock_decorator
def test_lock_decorator():
    pass



# Generated at 2022-06-25 13:30:04.893070
# Unit test for function lock_decorator
def test_lock_decorator():
    result = lock_decorator()
    assert isinstance(result, FunctionType)



# Generated at 2022-06-25 13:30:12.046433
# Unit test for function lock_decorator
def test_lock_decorator():

    class TestClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()
            self.callbacks = []

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, callback):
            self.callbacks.append(callback)

    obj = TestClass()

    for i in range(1000):
        obj.send_callback(i)

    assert len(obj.callbacks) == 1000

    @lock_decorator()
    def foo():
        raise Exception("No attr passed")

    @lock_decorator(lock=threading.Lock())
    def bar():
        raise Exception("No attr passed")

    try:
        foo()
    except:
        pass

    try:
        bar()
    except:
        pass

# Generated at 2022-06-25 13:30:13.411275
# Unit test for function lock_decorator
def test_lock_decorator():

    from insight.insightcg.plugins.callback import CallbackModule

# Generated at 2022-06-25 13:30:19.799144
# Unit test for function lock_decorator
def test_lock_decorator():
    # Testing from pickle import (ArgumentError, dump, load, loads, HIGHEST_PROTOCOL)
    import threading
    # Testing from pickle import (ArgumentError, dump, load, loads, HIGHEST_PROTOCOL)
    from pickle import (ArgumentError, dump, load, loads, HIGHEST_PROTOCOL)
    # Testing from pickle import (ArgumentError, dump, load, loads, HIGHEST_PROTOCOL)
    from threading import Thread

    class TestClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def do_work(self, a, b):
            self.a += a
           

# Generated at 2022-06-25 13:30:21.358590
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:30:26.046654
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest
    import threading

    class TestLockDecorator(unittest.TestCase):
        def test_0(self):
            # Skip this test case due to import error(s)
            pass

    # Create a test suite
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestLockDecorator))
    # Execute the test suite
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    # Collect test result
    errors = len(result.errors)
    failures = len(result.failures)
    skipped = len(result.skipped)
    tests_ran = result.testsRun

    global test_case_0

# Generated at 2022-06-25 13:30:34.178237
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        from importlib import reload
    except ImportError:
        from imp import reload

    # Save the modules that are imported
    saved_modules = list(sys.modules.keys())

    # Import the module to test
    import ansible.module_utils.common.compat

    # Reload the module to import
    reload(ansible.module_utils.common.compat)

    # Remove all the saved modules so that they are re-imported if necessary
    for saved_module in saved_modules:
        sys.modules.pop(saved_module)



# Generated at 2022-06-25 13:30:37.642284
# Unit test for function lock_decorator
def test_lock_decorator():
    # Finding the value of `attr`
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['-rx','-v','--pdb','--pdbcls=IPython.terminal.debugger:TerminalPdb','test_lock_decorator.py'])