

# Generated at 2022-06-25 13:24:05.465835
# Unit test for function lock_decorator
def test_lock_decorator():
    # Prepare the parameters
    attr = 'missing_lock_attr'

    # Execute the function
    retval = lock_decorator(attr)
  
    # Verify the results
    assert isinstance(retval, type(lock_decorator))

# Generated at 2022-06-25 13:24:11.195370
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    class Foo(basic.Basic):
        def __init__(self):
            self.var_1 = 5
            self.var_2 = 5

        @lock_decorator()
        def method_0(self):
            return self.var_1

        @lock_decorator(lock=None)
        def method_1(self):
            return self.var_2

    foo = Foo()
    assert foo.method_0() == 5
    assert foo.method_1() == 5

# Generated at 2022-06-25 13:24:12.935035
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:24:15.113239
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

    # The lock_decorator function returns a callable.
    test_case_0()

# Generated at 2022-06-25 13:24:15.914409
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1 == 0

# Generated at 2022-06-25 13:24:25.675863
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    import six
    import threading
    import time

    class ClassA(object):
        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(lock=threading.Lock())
        def method_a(self):
            assert self._lock.get_lock()
            time.sleep(0.1)
            assert self._lock.get_lock()

        @lock_decorator(attr='_lock')
        def method_b(self):
            assert self._lock.get_lock()
            time.sleep(0.1)
            assert self._lock.get_lock()


# Generated at 2022-06-25 13:24:30.200133
# Unit test for function lock_decorator
def test_lock_decorator():
    if get_mode() in ('test',):
        import pytest
        # begin testing
        # Here we test the lock_decorator
        var_1 = lock_decorator()
        var_2 = var_1('func_0')
        # end testing
    else:
        raise Exception('No test support available for this mode. See sample.py for more details.')

# Utility functions

# Generated at 2022-06-25 13:24:36.452880
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create the build directory if it doesn't already exist
    cwd = os.getcwd()
    build_path = os.path.join(cwd, 'build')
    if not os.path.exists(build_path):
        os.makedirs(build_path)
    print('----------TESTING lock_decorator-----------')
    print('STARTING TEST CASES FOR lock_decorator')
    test_case_0()
    print('FINISHED TEST CASES FOR lock_decorator')
    print('----------FINISHED TESTING lock_decorator-----------')

# Main function for testing other functions

# Generated at 2022-06-25 13:24:38.095842
# Unit test for function lock_decorator
def test_lock_decorator():
    with lock_decorator() as lock_decorator_obj:
        pass


# Generated at 2022-06-25 13:24:42.280098
# Unit test for function lock_decorator
def test_lock_decorator():
    # Make sure it detects missing ``attr`` and ``lock``
    from pytest import raises
    with raises(TypeError):
        test_case_0()
    # Make sure we can set ``attr``
    test_case_1()
    # Make sure we can set ``lock``
    test_case_2()


# Generated at 2022-06-25 13:24:46.283956
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 == 'inner'

# Generated at 2022-06-25 13:24:47.169816
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:24:48.034514
# Unit test for function lock_decorator
def test_lock_decorator():
    raise NotImplementedError()

# Generated at 2022-06-25 13:24:50.586361
# Unit test for function lock_decorator
def test_lock_decorator():
    x = lock_decorator
    assert x


# Generated from file ../../test/units/modules/test_ansible_doc.py, return code 0, stderr empty


# Generated at 2022-06-25 13:24:58.920740
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestLockDecorator():
        def __init__(self):
            self.attr = '_lock'
            self.attr1 = '_lock1'
            self.attr2 = '_lock2'
            self.attr3 = '_lock3'
            self.lock = None
            self.lock1 = None
            self.lock2 = None
            self.lock3 = None

        @lock_decorator(attr=attr)
        def function_1(self):
            return True

        @lock_decorator(attr=attr1)
        def function_2(self):
            return True

        def check_test_function_1(self):
            assert True == self.function_1()
            assert True == self.function_2()


# Generated at 2022-06-25 13:24:59.641311
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup
    var_0 = lock_decorator()



# Generated at 2022-06-25 13:25:03.120275
# Unit test for function lock_decorator
def test_lock_decorator():
    # If a parameter is given and has the correct type, that is expected.
    # If no parameter is given, and no default exists, fail.
    assert isinstance(lock_decorator(lock=threading.Lock()), function)


# Generated at 2022-06-25 13:25:05.811917
# Unit test for function lock_decorator
def test_lock_decorator():
    # Set test_var to True
    test_var = True
    assert test_var
    # Set test_var to False
    test_var = False
    assert test_var

# Generated at 2022-06-25 13:25:07.061768
# Unit test for function lock_decorator
def test_lock_decorator():
    
    # Run test case 0
    test_case_0()

# Generated at 2022-06-25 13:25:09.675038
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator()


if __name__ == '__main__':
    test_case_0()
    test_lock_decorator()

# Generated at 2022-06-25 13:25:15.882224
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = 1
    lock_decorator(lock)
    test_case_0()

# Generated at 2022-06-25 13:25:17.064376
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator()
    assert True

# Generated at 2022-06-25 13:25:22.369552
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = dict(
        action='list'
    )
    argument_spec.update(lock_decorator.__kwdefaults__)
    module = AnsibleModule(argument_spec=argument_spec)
    assert False, "Failed to initialize module"

# Generated at 2022-06-25 13:25:31.017367
# Unit test for function lock_decorator
def test_lock_decorator():
    from function_mixins import lock_decorator

    @lock_decorator
    def lock_decorator_func_0():
        return

    @lock_decorator(attr='lock_decorator_attr_0')
    def lock_decorator_func_1(self, a, b=None, c=None, d=1, e=2, f=None, g=None, h=1, i=2, j=None, k=None, l=1, m=2):
        pass

    lock_decorator_obj_0 = lock_decorator()

    lock_decorator_obj_1 = lock_decorator(attr='lock_decorator_attr_1')

    # TODO: parameterize these tests
    lock_decorator_obj_0()
    lock_

# Generated at 2022-06-25 13:25:39.361536
# Unit test for function lock_decorator
def test_lock_decorator():
    class test_class_0(object):

        # Method __init__
        def __init__(self):
            self.var_0 = True
            self.var_1 = False
            self.var_3 = True
            self.var_5 = True
            self.var_2 = False
            self.var_4 = False
            self.var_6 = False
            self.var_7 = True

        @lock_decorator(attr='var_0')
        def __test_0(self):
            pass

        @lock_decorator()
        def __test_1(self):
            pass

    self.obj_0 = test_class_0()
    assert self.obj_0.var_0 == True
    assert self.obj_0.var_1 == False

# Generated at 2022-06-25 13:25:44.175329
# Unit test for function lock_decorator
def test_lock_decorator():
    # Check if: attr='missing_lock_attr', lock=None
    # Return:
    #     decorated function (wrapper function)
    assert callable(lock_decorator())
    assert not lock_decorator()(lambda x:x)(5)
    assert callable(lock_decorator()(lambda x:x))

# Generated at 2022-06-25 13:25:45.090818
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test cases
    test_case_0()

# Generated at 2022-06-25 13:25:47.262750
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test for case when
    # ``lock`` == ``None``

    # Test for case when
    # ``lock`` != ``None``
    assert True == True


# Generated at 2022-06-25 13:25:49.107245
# Unit test for function lock_decorator
def test_lock_decorator():

    print(test_case_0())


if __name__ == "__main__":
    test_lock_decorator()

# Generated at 2022-06-25 13:25:52.347294
# Unit test for function lock_decorator
def test_lock_decorator():
    import json

    # This is a simple example, showing a single mock
    # method being decorated with a lock, and it works
    # as expected.
    with open('./test/lock_decorator/test_0.json', 'r') as f:
        test_0 = json.load(f)
    output_0 = test_case_0()
    assert output_0 == test_0

# Generated at 2022-06-25 13:26:03.730161
# Unit test for function lock_decorator
def test_lock_decorator():
    from . import lock_decorator
    var_0 = lock_decorator()
    var_0()

# vim: set ft=python sw=4 et tw=79 :

# Generated at 2022-06-25 13:26:07.210487
# Unit test for function lock_decorator
def test_lock_decorator():
    # No input
    func = lock_decorator()

    # Test required arg missing
    func()

    # Test required arg present

    # Test optional arg not used

    # Test optional arg used

    # Test required arg present and optional arg used

    # Test output

    # Test output type

    # Test output content

    # Test state changes
    pass

# Generated at 2022-06-25 13:26:08.171155
# Unit test for function lock_decorator
def test_lock_decorator():
    """Test that the function lock_decorator returns True or False"""
    assert True

# Generated at 2022-06-25 13:26:09.184132
# Unit test for function lock_decorator
def test_lock_decorator():
    _lock_decorator = lock_decorator()



# Generated at 2022-06-25 13:26:19.333651
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = threading.Lock()

    glob_var = 0

    def test_lock_decorator_var_0():
        global glob_var
        glob_var = 5
        assert glob_var == 5


    def test_lock_decorator_var_1():
        global glob_var
        assert glob_var == 5


    test_lock_decorator_var_0 = lock_decorator(lock=lock)(test_lock_decorator_var_0)
    test_lock_decorator_var_1 = lock_decorator(lock=lock)(test_lock_decorator_var_1)

    # Setup the lock
    test_lock_decorator_var_0()

    # Try to test the lock
    test_lock_decorator_var_1()


#

# Generated at 2022-06-25 13:26:19.870017
# Unit test for function lock_decorator
def test_lock_decorator():
    raise Exception("No test defined for lock_decorator")

# Generated at 2022-06-25 13:26:27.768937
# Unit test for function lock_decorator
def test_lock_decorator():
    # Unit test for function lock_decorator
    # This function uses the following variables:
    # var_0 :
    # var_1 :
    # var_10 :
    # var_11 :
    # var_2 :
    # var_3 :
    # var_4 :
    # var_5 :
    # var_6 :
    # var_7 :
    # var_8 :
    # var_9 :
    var_0 = 'https://docs.python.org/3/library/unittest.html'

    class SomeTestClass(object):

        def __init__(self):
            self.var_1 = []
            self.var_2 = []
            self.var_3 = 100
            self.var_4 = 0
            self.var_5 = 100
            self.var_

# Generated at 2022-06-25 13:26:38.208314
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile

    var_0 = lock_decorator()
    var_1 = tempfile.NamedTemporaryFile()

    with open(var_1.name, 'w') as var_2:
        var_2.write('hello world')
    
    os.unlink(var_1.name)

# This code is a simple abstraction that wraps this functionality
# and makes it easy to create new modules in the future.

import os
import sys

from ansible.module_utils.basic import AnsibleModule

VAR_0 = os.path.realpath(__file__)
VAR_1 = os.path.dirname(VAR_0)
VAR_2 = 'lib'
VAR_3 = os.path.join(VAR_1, VAR_2)

sys

# Generated at 2022-06-25 13:26:39.511836
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:26:40.076394
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:58.708674
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test if lock_decorator raises any exceptions
    assert not lock_decorator()


if __name__ == "__main__":
    test_lock_decorator()

# Generated at 2022-06-25 13:27:06.227754
# Unit test for function lock_decorator
def test_lock_decorator():

    # Set up test environment
    import threading

    class _TestLock(object):
        _lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def _do_lock(self):
            self.value = 10

        @property
        @lock_decorator(attr='_lock')
        def _test_prop(self):
            return self._value

        @_test_prop.setter
        @lock_decorator(attr='_lock')
        def _test_prop(self, value):
            self._value = value

        @property
        @lock_decorator(lock=_lock)
        def _test_prop_2(self):
            return self._value

    # Execute the test
    test_object = _TestLock()
    test_object._do_

# Generated at 2022-06-25 13:27:16.576441
# Unit test for function lock_decorator
def test_lock_decorator():
    # Make sure we can create instances
    lock_decorator()
    # Test the "attr" arg
    @lock_decorator(attr='attr1')
    def func_attr1(self):
        return True
    # Test passing in an instance
    lock1 = 'lock1'
    @lock_decorator(lock=lock1)
    def func_lock1(self):
        return True
    class Test:
        attr1 = 'attr1'
    test = Test()
    assert test.attr1 == 'attr1'
    assert func_attr1(test)
    assert func_lock1(test)
    # Make sure pre-defined attr is used
    lock2 = 'lock2'

# Generated at 2022-06-25 13:27:18.612071
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.utils import loc

    @lock_decorator()
    def test_0():
        pass

    assert loc(test_0) == (1, 0)

# Generated at 2022-06-25 13:27:20.862629
# Unit test for function lock_decorator
def test_lock_decorator():
    if True:
        # Testing for function lock_decorator
        var_0 = lock_decorator()
        assert True

# Generated at 2022-06-25 13:27:28.517377
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import tempfile

# Generated at 2022-06-25 13:27:33.242086
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class TestClass(object):
        _lock = threading.Lock()

        def __init__(self):
            self._foo = 'bar'

        @lock_decorator(attr='_lock')
        def method(self):
            assert self._foo == 'bar'

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    tc = TestClass()
    tc.method()



# Generated at 2022-06-25 13:27:35.410468
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert isinstance(lock_decorator(), lock_decorator)
    assert lock_decorator('test') is lock_decorator
    test_case_0()

# Generated at 2022-06-25 13:27:43.004508
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules import AnsibleLintRule
    class PathExistsRule(AnsibleLintRule):
        id = '123'
        shortdesc = 'short desc'
        description = 'desc'

        @lock_decorator(attr='_answer')
        def matchtask(self, file, task):
            if task.get('name') == 'should-not-match':
                raise Exception("is a dummy test")

        @lock_decorator(attr='_answer')
        def matchplay(self, file, play):
            if play.get('name') == 'should-not-match':
                raise Exception("is a dummy test")

    assert PathExistsRule(RulesCollection(), {}, {}).matchplay({}, {'name': 'should-not-match'})

# Generated at 2022-06-25 13:27:47.376751
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        test_case_0()
    except NameError:
        pass
    except Exception:
        import traceback
        traceback.print_exc()
        return 1

    # If we get here, then all the tests passed
    return 0


if __name__ == '__main__':
    import sys
    sys.exit(test_lock_decorator())

# Generated at 2022-06-25 13:28:32.246269
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test function lock_decorator
    # Assert if true (boolean)
    assert True == True
    # Assert if false (boolean)
    assert False == False
    # Assert if none (none-type)
    assert None == None
    # Assert if class Instance
    assert isinstance(test_case_0(), function)
    # Assert if equal (value compare)
    assert 1 == 1
    # Assert if not equal (value compare)
    assert 1 != 2
    # Assert if greater than (value compare)
    assert 1 > 0
    # Assert if less than (value compare)
    assert 1 < 2
    # Assert if greater than or equal (value compare)
    assert 1 >= 0
    # Assert if less than or equal (value compare)
    assert 1 <= 2

# Generated at 2022-06-25 13:28:39.891880
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    # real test
    @lock_decorator(attr='lock')
    def no_lock(self, val):
        return val

    class Foo(object):
        def __init__(self):
            self.lock = threading.Lock()

    foo = Foo()
    assert no_lock(foo, 1) == 1

    # fake test
    class FakeLock(object):
        def __enter__(self):
            pass

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    @lock_decorator(lock=FakeLock())
    def fake_no_lock(self, val):
        return val

    class FakeFoo(object):
        pass

    fake_foo = FakeFoo()

# Generated at 2022-06-25 13:28:48.879132
# Unit test for function lock_decorator
def test_lock_decorator():

    class Test(object):

        def __init__(self):
            self.count = 0
            self.lock = None

        def set_lock(self, lock):
            self.lock = lock

        @lock_decorator()
        def count_once(self):
            self.count += 1

        @lock_decorator(attr='lock')
        def count_twice(self):
            self.count += 2

    test_obj = Test()
    lock = threading.Lock()
    test_obj.set_lock(lock=lock)

    # calling count_once should sleep for 1 second
    with lock:
        t = threading.Thread(name='three', target=test_obj.count_once)
        t.start()
        time.sleep(0.5)
        assert test_obj.count == 0

# Generated at 2022-06-25 13:28:50.232612
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:28:53.368843
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test for lock_decorator(arg_0, arg_1)'''
    var_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert var_0(func)() == 'Called func'



# Generated at 2022-06-25 13:29:01.339128
# Unit test for function lock_decorator
def test_lock_decorator():
    from pytest import raises
    from inspect import signature
    from sys import version_info

    err = None
    try:
        lock_decorator(attr=0, lock=1)
    except TypeError as e:
        err = e
    assert err is not None

    err = None
    try:
        lock_decorator(lock=0)
    except TypeError as e:
        err = e
    assert err is not None

    err = None
    try:
        lock_decorator(attr=0)
    except TypeError as e:
        err = e
    assert err is not None

    @lock_decorator()
    def mock_func():
        return 0

    if version_info[0] == 2:
        assert mock_func.func_code.co_varnames[:2]

# Generated at 2022-06-25 13:29:04.793144
# Unit test for function lock_decorator
def test_lock_decorator():
    # Inner function for function lock_decorator
    def test_case_0():
        var_0 = lock_decorator()

    # Inner function for function lock_decorator
    def test_case_1():
        var_0 = lock_decorator(attr='missing_lock_attr')

    # Inner function for function lock_decorator
    def test_case_2():
        var_0 = lock_decorator(lock='lock')



# Generated at 2022-06-25 13:29:05.103096
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:29:06.185563
# Unit test for function lock_decorator
def test_lock_decorator():
    # Make sure we have at least 1 test for function lock_decorator
    assert True

# Generated at 2022-06-25 13:29:13.548648
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    @lock_decorator(attr='_test_lock')
    def some_method(self, value):
        self.foo = value

    @lock_decorator(lock=threading.Lock())
    def some_other_method(value):
        return value


    class Test(object):
        def __init__(self):
            self._test_lock = threading.Lock()

    t = Test()
    assert getattr(t, 'foo', None) is None
    some_method(t, 1)
    assert getattr(t, 'foo') == 1
    assert getattr(t, '_test_lock') == threading.Lock()

    assert some_other_method(1) == 1



# Generated at 2022-06-25 13:30:49.757522
# Unit test for function lock_decorator
def test_lock_decorator():
    # No parameters
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:30:57.583027
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.UseLockDecoratorRule import UseLockDecoratorRule

    collection = RulesCollection()
    collection.register(UseLockDecoratorRule())

    success = 'test/lock-decorator-success.yml'
    failure = 'test/lock-decorator-failure.yml'

    success_runner = collection.run(success, [])
    assert success_runner.collection.files_processed == 1
    assert len(success_runner.collection) == 0

    failure_runner = collection.run(failure, [])
    assert failure_runner.collection.files_processed == 1
    assert len(failure_runner.collection) == 1

# Generated at 2022-06-25 13:30:57.902186
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:31:03.756001
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    class Foo(object):
        def __init__(self):
            self._lock = lock

        @lock_decorator(attr='_lock')
        def foo(self):
            return 'hi! Foo'

    class Bar(Foo):
        @lock_decorator(lock=lock)
        def bar(self):
            return 'hi! Bar'

    f = Foo()
    b = Bar()

    assert f.foo() == 'hi! Foo'
    assert b.foo() == 'hi! Foo'
    assert b.bar() == 'hi! Bar'

# Generated at 2022-06-25 13:31:04.817799
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Extra Unit tests for function lock_decorator

# Generated at 2022-06-25 13:31:05.718683
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:31:06.747721
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()


# Generated at 2022-06-25 13:31:15.047127
# Unit test for function lock_decorator
def test_lock_decorator():
    # Dummy function to test the decorator and decorator args
    def func(*args, **kwargs):
        pass

    lock = object()
    attr = '_lock'

    decorated_func = lock_decorator(lock=lock)(func)
    assert decorated_func(1, 2, a=3, b=4) is None
    assert func(1, 2, a=3, b=4) is None

    decorated_func = lock_decorator(attr=attr)(func)
    assert decorated_func(1, 2, a=3, b=4) is None
    assert func(1, 2, a=3, b=4) is None

    # Ensure that we do not allow both ``attr`` and ``lock``

# Generated at 2022-06-25 13:31:16.346509
# Unit test for function lock_decorator
def test_lock_decorator():
    # No return value expected
    # Error raised, but not expected
    assert lock_decorator() == None

# Generated at 2022-06-25 13:31:22.954035
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()


if __name__ == '__main__':
    import os
    import sys
    import unittest


    class TestLockDecorator(unittest.TestCase):
        '''
        Test function lock_decorator
        '''
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_case_0(self):
            var_0 = lock_decorator()

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    suite.addTest(loader.loadTestsFromTestCase(TestLockDecorator))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)