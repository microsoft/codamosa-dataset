

# Generated at 2022-06-25 13:24:03.199026
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 13:24:07.970529
# Unit test for function lock_decorator
def test_lock_decorator():
    fake_attr = 'fake_attr'

    test_obj = type('TestObject', (), {})()
    assert not hasattr(test_obj, fake_attr)

    @lock_decorator(attr=fake_attr)
    def fake_method(self):
        return 42

    setattr(test_obj, fake_attr, 'foobar')
    assert fake_method(test_obj) == 42


# Generated at 2022-06-25 13:24:08.994360
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:24:09.810205
# Unit test for function lock_decorator
def test_lock_decorator():
    pass



# Generated at 2022-06-25 13:24:10.861414
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = test_case_0()

# Generated at 2022-06-25 13:24:11.856765
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:24:13.558711
# Unit test for function lock_decorator
def test_lock_decorator():
    assert var_0() == None # we should never get here
    try:
        pass
    except Exception:
        pass

# Generated at 2022-06-25 13:24:23.667263
# Unit test for function lock_decorator
def test_lock_decorator():
  assert lock_decorator(
    attr = 'missing_lock_attr',
    lock = None
  ) is None
  assert lock_decorator(
    attr = 'missing_lock_attr',
    lock = None
  ) is None
  assert lock_decorator(
    attr = 'missing_lock_attr',
    lock = None
  ) is None
  assert lock_decorator(
    attr = 'missing_lock_attr',
    lock = None
  ) is None
  assert lock_decorator(
    attr = 'missing_lock_attr',
    lock = None
  ) is None
  assert lock_decorator(
    attr = 'missing_lock_attr',
    lock = None
  ) is None

# Generated at 2022-06-25 13:24:32.193122
# Unit test for function lock_decorator
def test_lock_decorator():
    import pylint.lint

    class TestClass(object):
        pass

    class TestClass2(object):
        @lock_decorator(attr='missing_lock_attr')
        def test_method(self):
            pass  # noqa

    class TestClass3(object):
        @lock_decorator(lock=None)
        def test_method(self):
            pass  # noqa

        def test_method2(self, lock=None):
            pass


# Generated at 2022-06-25 13:24:41.425031
# Unit test for function lock_decorator
def test_lock_decorator():
    attr_0 = getattr(lock_decorator, "__name__")
    attr_1 = getattr(lock_decorator, "__doc__")
    var_0 = hasattr(lock_decorator, "__call__")
    attr_2 = getattr(lock_decorator, "__call__")
    var_1 = hasattr(lock_decorator, "__defaults__")
    var_2 = hasattr(lock_decorator, "__kwdefaults__")
    var_3 = hasattr(lock_decorator, "__annotations__")
    var_4 = hasattr(lock_decorator, "__globals__")
    var_5 = hasattr(lock_decorator, "__closure__")

# Generated at 2022-06-25 13:24:44.532872
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:45.167148
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    doctest.testmod()


# Utility functions


# Generated at 2022-06-25 13:24:51.356636
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock
    import threading
    assert lock_decorator('attr')(lambda x: x)('Hello') == 'Hello'
    assert lock_decorator(lock=threading.Lock())(lambda x: x)('Hello') == 'Hello'
    with mock.patch('threading.Lock') as m:
        lock_decorator(lock=m)
        m.assert_called_once_with()
    def test_0(self):
        pass
    assert lock_decorator(attr='_lock')(test_0)(mock.Mock()) is None

# Generated at 2022-06-25 13:24:52.421164
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup
    lock_decorator()
    # Teardown
    pass

# Generated at 2022-06-25 13:24:53.475843
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:24:56.596975
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Unit test for function lock_decorator
    '''
    import pytest
    @lock_decorator()
    def func_0():
        pass

    with pytest.raises(TypeError) as excinfo:
        func_0()
    assert excinfo.value.args[0] == "missing_lock_attr is required"


# Generated at 2022-06-25 13:24:58.417596
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    # assert var_0 ==

# Generated at 2022-06-25 13:25:08.565763
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    class TestClass0:
        def test_method(self):
            # Test function
            pass
    func = TestClass0().test_method
    assert func() == None
    # Test with kwargs
    var_0 = lock_decorator(attr='attr')
    class TestClass1:
        attr = None
        @var_0
        def test_method(self):
            # Test with kwargs
            pass
    test_obj = TestClass1()
    test_obj.attr = threading.Lock()
    func = test_obj.test_method
    assert func() == None
    # Test with kwargs
    var_0 = lock_decorator(lock=threading.Lock())

# Generated at 2022-06-25 13:25:18.367501
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestCase
    from sys import getsizeof
    from types import FunctionType

    class MockObject:
        def __init__(self):
            self.attr = 1

        @lock_decorator(attr='attr')
        def mock_method(self):
            return 2

    # Ensure function is callable
    assert callable(MockObject.mock_method) is True

    # Ensure the function can be invoked
    assert MockObject().mock_method() == 2

    # Ensure function is still a function
    assert isinstance(MockObject.mock_method, FunctionType) is True

    # Ensure the test object is smaller than 25 bytes
    assert getsizeof(MockObject) < 25

    # Ensure the inner function is callable

# Generated at 2022-06-25 13:25:20.111029
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 is None

# Generated at 2022-06-25 13:25:24.899144
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:25:29.882052
# Unit test for function lock_decorator
def test_lock_decorator():
    class TestClass(object):
        def __init__(self):
            self.lock = None

        def method_0(self, foo, bar):
            pass

    test_obj = TestClass()
    func = lock_decorator(lock=test_obj)(test_obj.method_0)
    assert isinstance(func, type(test_obj.method_0))



# Generated at 2022-06-25 13:25:35.340425
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.DeprecatedShellEqualsTrueRule import DeprecatedShellEqualsTrueRule
    from ansiblelint.runner import Runner

    rule = DeprecatedShellEqualsTrueRule()
    runner = Runner(rule, "/path/to/file", {}, [], [])

    result = rule.matchtask({"module_name": "command", "module_args": {"_raw_params": "true"}}, runner)
    assert result is not None

    result = rule.matchtask({"module_name": "command", "module_args": {"_raw_params": "True"}}, runner)
    assert result is not None

    result = rule.matchtask({"module_name": "command"}, runner)
    assert result is None

# Generated at 2022-06-25 13:25:40.154784
# Unit test for function lock_decorator
def test_lock_decorator():
    with patch('ansible_collections.sivel.network_tools.plugins.module_utils.network.napalm.lock_decorator.lock') as mock_lock:
        assert lock_decorator() == mock_lock.return_value
        lock_decorator()
        assert mock_lock.called



# Generated at 2022-06-25 13:25:41.256890
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True



# Generated at 2022-06-25 13:25:42.166570
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:25:43.795847
# Unit test for function lock_decorator
def test_lock_decorator():
    assert func_0 != None
    assert func_0 != 0
    assert func_0 != ""



# Generated at 2022-06-25 13:25:52.031419
# Unit test for function lock_decorator
def test_lock_decorator():
    try:
        test_case_0()
    except NameError:
        assert False, 'Failed test_case_0'


# ----
# Main
# ----

if __name__ == "__main__":
    import sys

    if len(sys.argv) == 2:
        if sys.argv[1] == 'lock_decorator':
            test_lock_decorator()

    if '__pypy__' in sys.builtin_module_names:
        import __pypy__
        __pypy__.opt.setdefault('objspace.opcodes.CALL_LIKELY_BUILTIN', False)
        __pypy__.opt.setdefault('objspace.opcodes.CALL_METHOD', True)

# Generated at 2022-06-25 13:25:53.495057
# Unit test for function lock_decorator
def test_lock_decorator():
    # Sample code here
    assert 'function lock_decorator' in lock_decorator.__doc__

# Generated at 2022-06-25 13:26:03.351855
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator.__name__ == 'lock_decorator'
    assert lock_decorator.__module__ == 'ansible_collections.ansible.community.tests.unit.compat.mock.builtins'

    import threading

    lock = threading.Lock()
    func = lambda: None
    wrapped = lock_decorator(lock=lock)(func)

    # Test that the wrapper is callable
    assert callable(wrapped)

    # Ensure the wrapped function is the original function
    assert wrapped.__self__ is func.__self__

    # Ensure the lock was used as a context manager
    assert lock.__enter__.call_count == 1
    assert lock.__exit__.call_count == 1

# Generated at 2022-06-25 13:26:14.708686
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()

    assert isinstance(var_0, type(lock_decorator)) == True
    # TODO Add more tests here
    raise Exception("Test not implemented!")

# Generated at 2022-06-25 13:26:23.544312
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    o = mock.Mock()

    @lock_decorator(attr='_lock')
    def test(i, j):
        return i + j
    o.test = test

    assert test(5, 12) == 17

    # Test the default lock attribute assumption
    assert o.test(5, 12) == 17

    # This decorator was implemented with threading locks in
    # mind, and so we assert that context manager behavior
    # works as expected.
    @lock_decorator(attr='_lock')
    def context_test(i):
        i.update({'value': i['value'] + 1})
        return i['value']

    context_test_dict = {'value': 1}
    assert context_test(context_test_dict) == 2

# Generated at 2022-06-25 13:26:26.459553
# Unit test for function lock_decorator
def test_lock_decorator():
    # pass
    assert True


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(["-xxx", "-v", "--pdb", __file__]))

# Generated at 2022-06-25 13:26:32.448743
# Unit test for function lock_decorator
def test_lock_decorator():
    from numpy import array

    # Create the needed inputs
    func_in_1 = array([11, 11, 11, 11, 11])

    # Execute the function
    # func(*func_in_1)

    # Validate the outputs
    # assert func_out_1 == array([11, 11, 11, 11, 11])
    assert True # TODO: implement your test here



# Generated at 2022-06-25 13:26:41.168601
# Unit test for function lock_decorator
def test_lock_decorator():
    lock = None
    attr = 'a'

    def f():
        pass

    def g():
        pass

    # I'm not sure how to unit test things that depend on context
    # managers, so testing for exception is probably the best
    # I can do.
    try:
        lock_decorator(attr=attr, lock=lock)(f)()
        assert False, 'Expected lock_decorator to raise exception'
    except AttributeError:
        assert True

    try:
        lock_decorator(attr=attr, lock=lock)(g)()
        assert False, 'Expected lock_decorator to raise exception'
    except AttributeError:
        assert True

    assert f() is None
    assert g() is None

# Generated at 2022-06-25 13:26:41.736764
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:49.728973
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.LockDecoratorRule import LockDecoratorRule

    ruleset = RulesCollection()
    test_case_0 = {
        'path': 'lib/ansiblelint/rules/LockDecoratorRule.py',
        'content': 'def test_case_0():\n    var_0 = lock_decorator()',
        'linenumber': 1,
        'code': 'ANSIBLE0005',
        'message': 'Method should use lock decorator'
    }


# Generated at 2022-06-25 13:26:58.655315
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.Always_run_tasks_as_root import Always_run_tasks_as_root
    from ansiblelint.rules.Always_use_command_or_shell import Always_use_command_or_shell
    from ansiblelint.rules.Command_is_always_or_never_not_both import Command_is_always_or_never_not_both
    from ansiblelint.rules.Command_uses_shell import Command_uses_shell
    from ansiblelint.rules.Command_uses_unconverted_conf_file import Command_uses_unconverted_conf_file
    from ansiblelint.rules.Command_with_become_has_no_become import Command_with_become_has_no_become

# Generated at 2022-06-25 13:27:04.729411
# Unit test for function lock_decorator
def test_lock_decorator():
    from re import match
    from sys import modules
    from ansible.module_utils.basic import AnsibleModule

    from ansible_collections.ansible.misc.plugins.module_utils.sivel_wrappers.wrappers import lock_decorator

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    module.exit_json(
        changed=False,
        meta={
            'answer': 42,
            'test': {
                'test_case_0': test_case_0(),
            }
        }
    )



# Generated at 2022-06-25 13:27:05.894915
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 13:27:27.050731
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # also validates that there are no runtime errors
    with pytest.raises(KeyError) as e:
        module = AnsibleModule(argument_spec={})
        module.exit()
    assert 'missing_lock_attr' in str(e)

# Generated at 2022-06-25 13:27:34.345500
# Unit test for function lock_decorator
def test_lock_decorator():
    from io import StringIO
    from contextlib import contextmanager
    import sys
    import shutil
    import tempfile
    import os

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


    # Create a temporary directory
    test_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = str(os.path.join(test_dir, 'test_file.txt'))



# Generated at 2022-06-25 13:27:36.266346
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()
    @lock_decorator(lock=lock)
    def func():
        return True
    assert func()


# Generated at 2022-06-25 13:27:41.264041
# Unit test for function lock_decorator
def test_lock_decorator():
    test_cases = [
        dict(
            function=var_0,
            expected_result=None,
            expected_type=None,
            test_case_number=0,
        ),
    ]

    for test_case in test_cases:
        test_case_number = test_case['test_case_number']
        assert test_case['function'], "Function for test case {test_case_number} not found".format(test_case_number=test_case_number)

        if test_case['exception']:
            with pytest.raises(test_case['exception']):
                test_case['function']()

# Generated at 2022-06-25 13:27:49.644116
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator), "Failed to create callabe object lock_decorator"
    assert callable(lock_decorator(attr="missing_lock_attr")), "Failed to create callabe object lock_decorator([attr=\"missing_lock_attr\"])"
    assert callable(lock_decorator(lock=None)), "Failed to create callabe object lock_decorator([lock=None])"
    #assert lock_decorator(attr="missing_lock_attr", lock=None) == "lock_decorator([attr=\"missing_lock_attr\"], [lock=None])", "lock_decorator([attr=\"missing_lock_attr\"], [lock=None]) returned unexpected result"
    # Test for exceptions

# Generated at 2022-06-25 13:27:51.939959
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 13:27:59.864622
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test stub used for function lock_decorator
    import pytest
    import module_0
    import module_1
    import module_2
    import module_3
    import module_4
    import module_5
    import module_6
    import module_7
    import module_8
    import module_9
    import module_10
    import module_11
    import module_12
    import module_13
    import module_14
    import module_15
    import module_16
    import module_17
    import module_18
    import module_19
    import module_20
    import module_21
    import module_22
    import module_23
    import module_24
    import module_25
    import module_26
    import module_27
    import module_28
    import module_29
   

# Generated at 2022-06-25 13:28:05.086279
# Unit test for function lock_decorator
def test_lock_decorator():
    # Save the original function so we can reset it after the test
    orig_func = lock_decorator.__wrapped__
    # Do not rely on the decorator behavior
    # explicitly call the original function
    assert lock_decorator.__wrapped__(attr='testing', lock=None)
    # Reset the original function
    lock_decorator.__wrapped__ = orig_func


if __name__ == '__main__':
    import sys
    sys.exit(test_lock_decorator())

# Generated at 2022-06-25 13:28:06.456969
# Unit test for function lock_decorator
def test_lock_decorator():
    # Check that lock_decorator returns a function
    assert callable(lock_decorator())



# Generated at 2022-06-25 13:28:13.929285
# Unit test for function lock_decorator
def test_lock_decorator():
    var_2 = lock_decorator()
    var_2( test_case_0 )
    # Test with ``attr`` specified
    class Test:
        missing_lock_attr = None
        @lock_decorator(attr='missing_lock_attr')
        def foo(self):
            assert self.missing_lock_attr
        @lock_decorator(attr='missing_lock_attr')
        def bar(self):
            pass
    t = Test()
    t.foo()
    t.bar()
    t.missing_lock_attr = ''
    t.foo()
    t.bar()
    # Test with ``lock`` specified
    class Test:
        lock = None
        @lock_decorator(lock=lock)
        def foo(self):
            assert self.lock

# Generated at 2022-06-25 13:28:52.715594
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:29:00.742331
# Unit test for function lock_decorator
def test_lock_decorator():
    func_0 = lock_decorator(attr='missing_lock_attr', lock=None)
    assert isinstance(func_0(test_case_0), type(test_case_0))
    # Test module import failures
    # Test type failures
    try:
        func_0 = lock_decorator(attr='missing_lock_attr', lock=None)
        func_0(None)
        assert False
    except AttributeError:
        pass
    except AssertionError:
        raise
    except:
        assert False
    # Test function call failures
    try:
        func_0 = lock_decorator(attr='missing_lock_attr', lock=None)
        func_0('str')
        assert False
    except AttributeError:
        pass
    except AssertionError:
        raise
   

# Generated at 2022-06-25 13:29:02.018551
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)


# Generated at 2022-06-25 13:29:02.915078
# Unit test for function lock_decorator
def test_lock_decorator():
    # We need to force a failure on this test case
    # assert lock_decorator() == None
    pass

# Generated at 2022-06-25 13:29:03.267199
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:29:10.779289
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.listify import listify_lookup_plugin_terms

    moduledata = dict(
        params=dict(
            foo=dict(type='list', default=[], elements='str', required=True),
        ),
        state=dict(default='absent', choices=['absent', 'present']),
    )

    module = AnsibleModule(argument_spec=moduledata, supports_check_mode=True)

    result = dict(
        changed=False,
    )

    foo = None

# Generated at 2022-06-25 13:29:12.048942
# Unit test for function lock_decorator
def test_lock_decorator():
    #  Check correct return for a call of the decorator
    assert lock_decorator()



# Generated at 2022-06-25 13:29:13.481763
# Unit test for function lock_decorator
def test_lock_decorator():
    func_0 = lock_decorator()
    with func_0():
        pass

# Generated at 2022-06-25 13:29:21.455449
# Unit test for function lock_decorator
def test_lock_decorator():
    from tempfile import mkdtemp
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    opts = dict(
        gather_subset='all',
        gather_timeout=50,
        gather_cache='/tmp/ansible-facts-distro-cache',
        gather_plugins=['/tmp/ansible-facts-distro-collections'],
        fact_path=['/tmp/ansible-facts-distro-collections'],
        fact_cacher_type='jsonfile',
        fact_cacher_options=dict(
            fact_cacher_timeout=50,
            fact_cacher_directory=mkdtemp(),
            fact_cacher_prefix='ansible_local'
        )
    )


# Generated at 2022-06-25 13:29:22.149195
# Unit test for function lock_decorator
def test_lock_decorator():
    # Not implemented
    pass

# Generated at 2022-06-25 13:30:59.795374
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:31:00.342606
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:31:02.742775
# Unit test for function lock_decorator
def test_lock_decorator():
    print('\n# Begin tests')
    test_case_0()
    print('# Finished tests')

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:31:11.598572
# Unit test for function lock_decorator
def test_lock_decorator():
    import salt.config
    import salt.loader
    import salt.utils.dictupdate

    # This is a hack, creating a new log, is required because we cannot
    # access __opts__ from a "minion" process, we must use an "execution" log
    opts_original = salt.config.DEFAULT_MASTER_OPTS
    opts = salt.config.DEFAULT_MINION_OPTS
    opts['__role'] = 'minion'
    opts['log_file'] = os.path.join(TMP, 'logs', 'minion.log')
    opts['__log_file'] = os.path.join(TMP, 'logs', 'minion.log')
    opts['log_level'] = 'debug'
    opts['root_dir'] = TMP
    opt

# Generated at 2022-06-25 13:31:15.977939
# Unit test for function lock_decorator
def test_lock_decorator():
    mock_lock = Mock()
    mock_lock.__enter__ = Mock()
    mock_lock.__exit__ = Mock()

    mock_function = Mock()

    test_lock_decorator_0(mock_function, mock_lock)
    test_lock_decorator_1(mock_function, mock_lock)
    test_lock_decorator_2(mock_function, mock_lock)


# Generated at 2022-06-25 13:31:16.451743
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:31:23.292950
# Unit test for function lock_decorator
def test_lock_decorator():
    import tempfile
    import threading
    import time
    import unittest

    # The idea here is to create a lock, and then create an object
    # which has that lock as a property. Then, use the object in a
    # thread, and ensure that any thread-safety issues are caught.
    # This is also locking the thread within the lock, which should
    # be safe.

    # Create a threading-safe lock
    _lock = threading.Lock()

    # Create a thread-safe object
    class Foo:
        _lock = _lock

        @lock_decorator(attr='_lock')
        def bar(self):
            time.sleep(0.1)

    # Create a file with a unique name
    fd, tmppath = tempfile.mkstemp()

# Generated at 2022-06-25 13:31:23.606862
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:31:24.241801
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# Generated at 2022-06-25 13:31:29.668227
# Unit test for function lock_decorator
def test_lock_decorator():
    @lock_decorator()
    def test_lock_decorator_0(self):
        pass

    @lock_decorator(attr=1)
    def test_lock_decorator_1(self):
        pass

    @lock_decorator(flag=1)
    def test_lock_decorator_2(self):
        pass
