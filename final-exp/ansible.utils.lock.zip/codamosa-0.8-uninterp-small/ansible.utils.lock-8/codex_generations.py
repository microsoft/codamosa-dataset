

# Generated at 2022-06-25 13:24:09.289046
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import missing_required_lib

    import json

    try:
        json.dumps({})
    except AttributeError as e:
        if '__dict__' not in e.args[0]:
            raise
        raise missing_required_lib('simplejson >= 2.5.2 is required, but does not appear to be installed')

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False,
    )

    module.exit_json(**{'ansible_lock_decorator_output': 'hello world'})

from ansible.module_utils.basic import *  # noqa: F403
from ansible.module_utils.basic import _ANSIBLE_ARGS  # no

# Generated at 2022-06-25 13:24:15.783828
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test for lock_decorator, no arguments
    assert callable(lock_decorator)
    assert lock_decorator() is lock_decorator

    def func_0(*args, **kwargs):
        pass

    assert callable(lock_decorator()(func_0))

    class Class_0():

        def func_0(*args, **kwargs):
            pass

    assert callable(lock_decorator(attr='missing_attr')(Class_0().func_0))

# Generated at 2022-06-25 13:24:20.030282
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test function lock_decorator
    '''

    ####
    # Test function signature and arguments
    @lock_decorator
    def some_method(foo):
        return foo

    return_value = some_method(foo=1)
    assert return_value == 1



# Generated at 2022-06-25 13:24:21.670475
# Unit test for function lock_decorator
def test_lock_decorator():
    f = lock_decorator('lock')
    assert f is not None


# Generated at 2022-06-25 13:24:30.551701
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.sivel.sivel_tests.tests.unit.compat.mock import patch, Mock
    from ansible_collections.sivel.sivel_tests.tests.unit.compat.mock import MagicMock, call

    with patch("ansible_collections.sivel.sivel_tests.tests.unit.compat.lock.Lock") as mock_lock:
        import ansible_collections.sivel.sivel_tests.plugins.module_utils.lock as lock

        lock._lock = MagicMock(spec_set=Mock, name='_lock')

        @lock.lock_decorator()
        def test_function():
            pass


# Generated at 2022-06-25 13:24:36.992390
# Unit test for function lock_decorator
def test_lock_decorator():
    from pytest import raises
    from ansible.module_utils.six import PY3

    @lock_decorator()
    def func_0():
        pass

    with raises(TypeError) as excinfo:
        func_0()
    if PY3:
        assert str(excinfo.value).startswith('lock_decorator() missing 1 required positional argument')
    else:
        msg = 'lock_decorator() takes at least 1 argument (0 given)'
        assert str(excinfo.value).startswith(msg)

    @lock_decorator(attr='_lock')
    def func_1():
        pass

    with raises(AttributeError) as excinfo:
        func_1()

# Generated at 2022-06-25 13:24:41.663364
# Unit test for function lock_decorator
def test_lock_decorator():
    global lock_decorator

    assert lock_decorator is not None

    with pytest.raises(TypeError):
        var_0 = lock_decorator()

    with pytest.raises(TypeError):
        var_0 = lock_decorator(attr='missing_lock_attr', lock='Incorrect lock object')



# Generated at 2022-06-25 13:24:42.197839
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:51.012946
# Unit test for function lock_decorator
def test_lock_decorator():
    from threading import Thread, Lock
    from time import sleep
    _lock = Lock()
    _dict = {'test_lock_decorator': 1}

    # Create a function/method that uses lock_decorator, that adds
    # a value to a dictionary, then sleep for 2 seconds
    @lock_decorator(lock=_lock)
    def _add_to_dict():
        _dict['test_lock_decorator'] += 1
        sleep(2)
        print('test_lock_decorator: %s' % _dict['test_lock_decorator'])

    # Then create 2 threads that run our function 5 times each.
    # Since we are using the same lock in both threads, they should
    # not step on each other.

# Generated at 2022-06-25 13:24:54.261600
# Unit test for function lock_decorator
def test_lock_decorator():
    """Test the function lock_decorator"""

    # This code may be executed more than once, so we want to
    # make sure the global values are reset.
    global var_0

    output_0 = None

    var_0 = lock_decorator()

    assert output_0 == None


# Generated at 2022-06-25 13:25:06.858769
# Unit test for function lock_decorator

# Generated at 2022-06-25 13:25:12.462838
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.DeprecatedModuleRule import DeprecatedModuleRule

    with open('test/deprecated-modules.yml') as modules:
        for line in modules:
            if line.startswith('#') or not line.strip():
                continue
            module, version = line.split()
            rule = DeprecatedModuleRule()
            assert rule.deprecations[module] == version



# Generated at 2022-06-25 13:25:13.619209
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 is not None

# Generated at 2022-06-25 13:25:17.624628
# Unit test for function lock_decorator
def test_lock_decorator():
    """
    lock_decorator
    *******************
    """
    # Check if lock_decorator could be called without parameters
    # No exception expected
    try:
        test_case_0()
    except Exception as e:
        assert False



# Generated at 2022-06-25 13:25:23.124561
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.ThreadLockNotUsedRule import ThreadLockNotUsedRule
    rules = RulesCollection()
    rules.register(ThreadLockNotUsedRule())
    wrapped_func = lock_decorator(lock=None)(test_case_0)
    success, results = rules.run(ast.parse(inspect.getsource(wrapped_func)))

    assert results == []

# Generated at 2022-06-25 13:25:31.649788
# Unit test for function lock_decorator
def test_lock_decorator():
    from six import PY2, PY3
    import sys
    import inspect
    import mock

    sys.path = ['.'] + sys.path

    mock_module = mock.MagicMock(spec=inspect)
    sys.modules['six'] = mock_module
    if PY2:
        mock.patch.object(sys.modules['six'], 'PY2', True)
    else:
        mock.patch.object(sys.modules['six'], 'PY3', True)

    import json
    import socket
    import threading

    from ansible.utils.path import makedirs_safe
    from ansible.utils.unsafe_proxy import wrap_var

    from ansible.plugins.action.synchronize import ActionModule as synchronize_ActionModule
    from ansible.plugins.action.copy import Action

# Generated at 2022-06-25 13:25:40.769128
# Unit test for function lock_decorator
def test_lock_decorator():

    import threading

    _thread_lock = threading.Lock()

    class LockExample(object):

        def __init__(self):
            self._thread_lock = _thread_lock

        @lock_decorator(attr='_thread_lock')
        def locked_method(self):
            return True

    instance = LockExample()
    assert instance.locked_method()

    # with lock:
    #     print('Before release')
    #     lock.release()
    #     print('Release')
    # print('After release')

    # lock_thread = threading.Thread(target=acquire_lock)
    # lock_thread.start()
    # time.sleep(0.01)
    # release_thread = threading.Thread(target=release_lock)
    # release_thread.start()
    # lock

# Generated at 2022-06-25 13:25:42.700658
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0 is not None



# Generated at 2022-06-25 13:25:46.420674
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test function lock_decorator
    function = lock_decorator(attr='_callback_lock')
    # Assert that the results of the function return true
    assert function is '_callback_lock'
    # Assert that the results of the function return true
    assert function is '_callback_lock'

# Generated at 2022-06-25 13:25:50.185002
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint.rules.T003 import lock_decorator

    test_0 = lock_decorator(attr='_callback_lock')
    test_1 = lock_decorator(lock=None)

    test_0(test_case_0())
    test_1(test_case_0())



# Generated at 2022-06-25 13:26:03.914025
# Unit test for function lock_decorator
def test_lock_decorator():
    # mock Py3.x import
    import sys
    if sys.version_info >= (3, 0):
        sys.modules['_thread'] = None
        sys.modules['_dummy_thread'] = None
        sys.modules['threading'] = None
    # test function
    import threading

    class Test(object):

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def test(self):
            return True

    class Test2(object):

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(lock=self._lock)
        def test(self):
            return True



# Generated at 2022-06-25 13:26:05.768005
# Unit test for function lock_decorator
def test_lock_decorator():
    import mock

    mock_args_0 = {}
    mock_kwargs_0 = {}
    var_0 = lock_decorator(**mock_kwargs_0)

# Generated at 2022-06-25 13:26:11.910790
# Unit test for function lock_decorator
def test_lock_decorator():
    last = None
    class Test(object):
        lock = None
        @lock_decorator(attr='lock')
        def test(self):
            nonlocal last
            last = self
    test = Test()
    test.lock = lock = threading.Lock()
    assert not lock.acquire(blocking=0)
    with lock:
        pass
    assert not lock.acquire(blocking=0)

    test.test()
    assert test is last

    assert lock.acquire(blocking=0)


# Generated at 2022-06-25 13:26:12.805596
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:26:13.748383
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:26:15.671663
# Unit test for function lock_decorator
def test_lock_decorator():
    # Get the function object to test
    funcobject = lock_decorator

    # Test the function object
    assert True is True



# Generated at 2022-06-25 13:26:16.228611
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:26:16.789809
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:17.689575
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()


# Generated at 2022-06-25 13:26:18.812891
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator



# Generated at 2022-06-25 13:26:28.505565
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    var_0 = lock_decorator()



# Generated at 2022-06-25 13:26:29.204179
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:38.498231
# Unit test for function lock_decorator
def test_lock_decorator():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    module_args = {}

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module.exit_json(**locals())


if __name__ == '__main__':
    import sys
    import json

    try:
        params = json.loads(sys.argv[1])
    except IndexError:
        params = {}
    try:
        test = params.pop('_test')
    except KeyError:
        test = False
    if test:
        globals().get(test)()
    else:
        main(params)

# Generated at 2022-06-25 13:26:41.864607
# Unit test for function lock_decorator
def test_lock_decorator():
    class A(object):
        def __init__(self):
            self.var_0 = None

        @lock_decorator()
        def set_var(self, value):
            self.var_0 = value

    A().set_var('test')

# Generated at 2022-06-25 13:26:49.823997
# Unit test for function lock_decorator
def test_lock_decorator():

    import types

    # Check that the function decorator properly wraps the given
    # function
    def empty_func(foo):
        pass

    @lock_decorator(attr='_lock_attr')
    def test_func(foo):
        pass

    assert isinstance(test_func, types.FunctionType)
    assert test_func.__name__ == 'test_func'
    assert test_func.__doc__ == empty_func.__doc__

    # Check that the wrapper properly locks a call
    import mock
    test_lock = mock.MagicMock()
    @lock_decorator(lock=test_lock)
    def test_func(foo):
        pass

    test_func(None)
    test_lock.__enter__.assert_called_once()

    # Check that the wrapper properly assigns the wrapped method

# Generated at 2022-06-25 13:26:50.350182
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:26:51.235356
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True

# Generated at 2022-06-25 13:26:52.472626
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 13:27:00.330602
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible import module_utils
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.lock = module_utils.threading.Lock()

        @lock_decorator(attr='lock')
        def test(self):
            pass

        @lock_decorator(lock=module_utils.threading.Lock())
        def test2(self):
            pass

    module = TestModule()
    module.test()
    module.test2()

# Generated at 2022-06-25 13:27:04.202454
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup
    my_args = {}
    my_kwargs = {}
    
    # Test
    my_return = lock_decorator(**my_args, **my_kwargs)

    # Verification
    test_case_0()
    assert my_return is None
    assert my_args == {}
    assert my_kwargs == {}


# Generated at 2022-06-25 13:27:28.619881
# Unit test for function lock_decorator
def test_lock_decorator():
    # init 0
    var_0 = lock_decorator((1, 2, 3))
    # init 1
    var_1 = lock_decorator((1, 2, 3), (1, 2, 3))
    # init 2
    var_2 = lock_decorator((1, 2, 3), (1, 2, 3))
    # init 3
    var_3 = lock_decorator((1, 2, 3), (1, 2, 3))
    # init 4
    var_4 = lock_decorator((1, 2, 3))
    # init 5
    var_5 = lock_decorator((1, 2, 3))
    # init 6
    var_6 = lock_decorator((1, 2, 3), (1, 2, 3), (1, 2, 3))
    # init

# Generated at 2022-06-25 13:27:29.459046
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

test_case_0()
test_lock_decorator()

# Generated at 2022-06-25 13:27:35.374445
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    dummy_lock = threading.Lock()
    dummy_lock2 = threading.Lock()
    dummy_obj = dummy_obj2 = None

    @lock_decorator(attr='lock')
    def dummy_method(self):
        dummy_obj = self

    @lock_decorator(lock=dummy_lock2)
    def dummy_method2():
        nonlocal dummy_obj2
        dummy_obj2 = self

    dummy_obj = Dummy()
    dummy_obj.lock = dummy_lock
    dummy_obj.method()
    assert dummy_obj == dummy_obj2



# Generated at 2022-06-25 13:27:42.948955
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test Bad Input
    try:
        var_1 = lock_decorator(attr=0)
    except TypeError as e:
        var_2 = e
        try:
            var_3 = lock_decorator(lock=0)
        except TypeError as e:
            var_4 = e
            import threading
            def send_callback(arg_1):
                var_5 = arg_1
            var_6 = lock_decorator(attr='_callback_lock')
            var_7 = var_6(send_callback)
            class TestClass(object):
                def __init__(self):
                    self._callback_lock = threading.Lock()
                    self._lock = threading.Lock()
                @var_6
                def send_callback_1(self, arg_1):
                    var_

# Generated at 2022-06-25 13:27:47.750110
# Unit test for function lock_decorator
def test_lock_decorator():

    import time

    import uvloop
    import asyncio

    from prometheus_client import Counter

    from hound.metric import Metric

    class TestMetric(Metric):
        '''Testing Metric class overriding Core methods with the lock
        wrapper to test concurrency
        '''

        def __init__(self, *args, **kwargs):
            super(TestMetric, self).__init__(*args, **kwargs)

        @lock_decorator(attr='_metric_lock')
        def add(self, labels=None, value=1):
            super(TestMetric, self).add(labels, value)

        @lock_decorator(attr='_metric_lock')
        def inc(self, labels=None):
            super(TestMetric, self).inc(labels)

       

# Generated at 2022-06-25 13:27:56.673950
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time

    class Test(object):
        lock = threading.Lock()

        @lock_decorator(attr='lock')
        def print_lock(self, name, sleep):
            time.sleep(sleep)
            print('{} was printed'.format(name))

    thread_names = ['Thread-1', 'Thread-2', 'Thread-3']
    thread_sleep = [0.5, 0.7, 0.9]
    thread_list = list()
    test = Test()

    # Iterate through list, spawn threads, start threads
    for thread_name, sleep in zip(thread_names, thread_sleep):
        # Create thread, initialize with run method, start thread
        thread = threading.Thread(target=test.print_lock, args=(thread_name, sleep))
        thread_

# Generated at 2022-06-25 13:27:57.419433
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:27:58.513876
# Unit test for function lock_decorator
def test_lock_decorator():
    pass


# Generated at 2022-06-25 13:27:59.318820
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:28:07.161480
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import threading
    import time
    # just a simple replacement for actual threading
    def thread_init(target, args=(), kwargs=None):
        if kwargs is None:
            kwargs = {}
        thread = threading.Thread(target=target, args=args, kwargs=kwargs)
        thread.start()


    # Make sure ``lock_decorator`` works
    class TestLockDecorator:

        def __init__(self):
            self._lock = threading.Lock()

        @lock_decorator(attr='_lock')
        def decorated_method(self, *args, **kwargs):
            time.sleep(.1)


# Generated at 2022-06-25 13:28:52.451138
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test exception conditions (failure cases)
    try:
        lock_decorator()
        assert False, 'Expected an exception'
    except Exception as e:
        assert type(e).__name__ == 'AssertionError'

    # Test the normal case (success case)
    # Make sure to use a unique lock attribute if you are
    # testing the normal case, and make sure to clean up
    # the lock attribute after the test is complete.
    try:
        # lock_decorator(lock=None)
        assert True
    except Exception as e:
        assert False, 'Expected no exception'

# Generated at 2022-06-25 13:28:58.517109
# Unit test for function lock_decorator
def test_lock_decorator():
    print('''
    #######################################################
    ##           TEST CASE 0 for function lock_decorator ##
    #######################################################
    ''')
    test_case_0()
    print('''
    #######################################################
    ##          TEST CASE 0 for function lock_decorator  ##
    #######################################################
    ''')
    print('''
    All test cases for function lock_decorator are passed!
    ''')

if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:29:04.812925
# Unit test for function lock_decorator
def test_lock_decorator():

    # These tests will be run when the wrapper function is called
    @lock_decorator(attr='_lock')
    class Test1:
        def __init__(self):
            self._lock = Mock()

    @lock_decorator(lock=Mock())
    class Test2:
        pass

    test1 = Test1()
    test2 = Test2()

    test1.some_method()
    test1._lock.__enter__.assert_called_once()
    test1._lock.__exit__.assert_called_once()

    test2.some_method()
    test2.some_method.__self__._lock.__enter__.assert_called_once()
    test2.some_method.__self__._lock.__exit__.assert_called_once()

# Generated at 2022-06-25 13:29:12.826657
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    import time
    import random
    import sys

    # Set up the objects we will use
    l = threading.Lock()
    shared_value = 0

    # Define the function that will be tested
    @lock_decorator(lock=l)
    def add_one():
        shared_value = shared_value + 1

    # Set up a simple thread function to run the function
    def f(l, add_one):
        for i in range(4):
            # Randomly sleep for 0-10 seconds
            time.sleep(round(random.random() * 10, 1))
            add_one()

    # Create a thread for each function and start it
    thread_list = []

# Generated at 2022-06-25 13:29:20.795762
# Unit test for function lock_decorator
def test_lock_decorator():

    # Unit test for function lock_decorator

    # Ensure that the generated decorator argument parser works as expected
    var_1 = lock_decorator()

    # Ensure that the generated decorator argument parser works as expected
    var_2 = lock_decorator()

    # Ensure that the generated decorator argument parser works as expected
    var_3 = lock_decorator()

    # Ensure that the generated decorator argument parser works as expected
    var_4 = lock_decorator()

    # Ensure that the generated decorator argument parser works as expected
    var_5 = lock_decorator()

    # Ensure that the generated decorator argument parser works as expected
    var_6 = lock_decorator()

    # Ensure that the generated decorator argument parser works as expected
    var_7 = lock_decorator()

    # Ensure that the

# Generated at 2022-06-25 13:29:23.227292
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_0 = lock_decorator(attr = 'foo')
    assert not lock_0
    lock_0 = lock_decorator(attr = 'self')
    assert not lock_0

if __name__ == "__main__":
    lock_decorator()

# Generated at 2022-06-25 13:29:30.465906
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    _lock = threading.Lock()

    my_lock = lock_decorator()

    @my_lock
    def my_func():
        print('inside')

    assert my_func() == 'inside', 'failed to decorate my_func'

    my_lock = lock_decorator(attr='_callback_lock')

    class MyClass(object):
        def __init__(self):
            self._callback_lock = _lock

        @my_lock
        def my_func(self):
            print('inside')

        @my_lock
        def my_func0(self):
            print('inside')

    my_class = MyClass()
    assert my_class.my_func() == 'inside', 'failed to decorate my_class.my_func'
    assert my_class.my

# Generated at 2022-06-25 13:29:30.885431
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:29:32.581465
# Unit test for function lock_decorator
def test_lock_decorator():
    # This function is a function
    assert callable(lock_decorator)

    # This function returns a function
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:29:33.634494
# Unit test for function lock_decorator
def test_lock_decorator():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-25 13:31:12.321915
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    from ansible_collections.community.generic.tests.unit.module_utils.test_lock_decorator import (
        MockObj0,
        MockObj1,
        MockObj2,
        MockObj3,
        MockObj4,
    )
    import pytest

    var_0 = MockObj0()
    var_1 = MockObj1()
    var_2 = MockObj2()
    var_3 = MockObj3()
    var_4 = MockObj4()

    var_5 = threading.Lock()
    var_6 = threading.Lock()
    var_7 = threading.Lock()
    var_8 = threading.Lock()
    var_9 = threading.Lock()

    var_10 = threading.Thread(target=var_0.f)
    var

# Generated at 2022-06-25 13:31:13.873387
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert callable(lock_decorator())

# Generated at 2022-06-25 13:31:16.555392
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test if the function can be called
    try:
        test_case_0()
    except NameError as error:
        assert False, error


# Run module directly for testing
if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:31:18.078395
# Unit test for function lock_decorator
def test_lock_decorator():
    pass # NOTE: We can't really test this, but running coverage will show
          # if it gets called, which is really all we care about

# Generated at 2022-06-25 13:31:23.079536
# Unit test for function lock_decorator
def test_lock_decorator():
    import os
    import pytest
    from unittest import TestCase

    # Lock to use with the decorator
    lock_obj = None


    def callback(self):
        pass

    @lock_decorator(attr='_callback_lock')
    def cb_lock(self):
        self.callback()

    class Test(TestCase):

        def setUp(self):
            self._callback_lock = lock_obj
            self.callback = callback

        def test_method(self):
            self.cb_lock()
            self.assertTrue(True)

    Test()

# Generated at 2022-06-25 13:31:26.183908
# Unit test for function lock_decorator
def test_lock_decorator():
    # Instantiate the `var_0` argument
    var_0 = lock_decorator()
    # Retrieve the value for the `var_1` argument
    var_1 = lock_decorator()
    # Make sure `val_1` is a function
    assert callable(var_1)
    # Assert that the two values are equal
    assert var_0 == var_1



# Generated at 2022-06-25 13:31:26.491745
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:31:26.955441
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator()

# Generated at 2022-06-25 13:31:27.993110
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0



# Generated at 2022-06-25 13:31:28.389055
# Unit test for function lock_decorator
def test_lock_decorator():
    pass