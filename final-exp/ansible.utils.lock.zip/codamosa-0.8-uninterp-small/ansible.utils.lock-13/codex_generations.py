

# Generated at 2022-06-25 13:24:04.941529
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def func_0(arg_0):
        return arg_0

    assert func_0(1) == 1

    var_1 = lock_decorator(lock=lock)
    assert var_1


# === Test suite ===

# Generated at 2022-06-25 13:24:07.265734
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError) as excinfo:
        lock_decorator()
    assert "missing 1 required positional arguments" in str(excinfo.value)

# Generated at 2022-06-25 13:24:07.786099
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:10.403532
# Unit test for function lock_decorator
def test_lock_decorator():

    # Test 0
    test_case_0()


if __name__ == "__main__":
    test_lock_decorator()

# Generated at 2022-06-25 13:24:10.964839
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:11.923664
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:12.588256
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:14.760703
# Unit test for function lock_decorator
def test_lock_decorator():
    # This is a unit test for function lock_decorator
    # TODO: Modify the unit test to pass
    assert True

# Generated at 2022-06-25 13:24:17.091190
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert isinstance(var_0, object)

# Generated at 2022-06-25 13:24:20.800790
# Unit test for function lock_decorator
def test_lock_decorator():
    for num, case in enumerate(test_cases(lock_decorator)):
        try:
            test_case_0(*case['input'])
        except Exception as e:
            logger.error("Test case %d failed with %s", num, e)
            logger.exception(e)
            raise

# Generated at 2022-06-25 13:24:24.188395
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)



# Generated at 2022-06-25 13:24:29.193727
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible_collections.pbasile.testcollection.plugins.module_utils.nagios import lock_decorator

    @lock_decorator()
    def test_function_0():
        pass

    @lock_decorator(attr='missing_lock_attr')
    def test_function_1():
        pass

    @lock_decorator(lock=lock_decorator())
    def test_function_2():
        pass

# Generated at 2022-06-25 13:24:30.356686
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 13:24:34.140110
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test case generator for lock_decorator
    '''
    # This is a test case template
    return [
        # _, _, _, exp_result, exp_exception =
        # Fill in the test case description
        ('description_1',
         'description_2',
         'description_3',
         'description_4',
         'description_5'),
    ]


# Generated at 2022-06-25 13:24:36.397646
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    with var_0 as var_1:
        pass
    with var_0 as var_2:
        pass
    assert type(var_0) == type(var_1) == type(var_2) == lock_decorator

# Generated at 2022-06-25 13:24:37.534813
# Unit test for function lock_decorator
def test_lock_decorator():
    test_case_0()

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 13:24:38.443216
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()



# Generated at 2022-06-25 13:24:38.940086
# Unit test for function lock_decorator
def test_lock_decorator():
    pass

# Generated at 2022-06-25 13:24:48.442619
# Unit test for function lock_decorator
def test_lock_decorator():
    from yaml import safe_dump
    from ansible.module_utils.basic import AnsibleModule

    # Module arguments:
    module_args = yaml.safe_load("""
    """)

    # Test case 1: Run module in check mode and verify results
    print(f"=========Test Case 1: Check Mode=========")
    with AnsibleModule(
        argument_spec=module_args,
        # This name takes place of module_name
        # It is used to load the module
        name='lock_decorator',
        check_invalid_arguments=False
    ) as module:
        result = module.exit_json()
        print(f"Returned: {safe_dump(result, default_flow_style=False)}\n")

    # Test case 2: Run module and verify results

# Generated at 2022-06-25 13:24:48.998228
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator()

# Generated at 2022-06-25 13:24:53.895513
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:24:55.329796
# Unit test for function lock_decorator
def test_lock_decorator():
    func = lock_decorator("_callback_lock")
    assert func("send_callback", "asdf")

# Generated at 2022-06-25 13:25:02.390391
# Unit test for function lock_decorator
def test_lock_decorator():
    # Test the following lock_decorator()
    # lock_decorator:
    #     decorator(attr='missing_lock_attr', lock=None)
    #     lock_decorator(attr='missing_lock_attr', lock=None)
    #     outer(func)
    #         wraps(func)
    #         inner(*args, **kwargs)
    test_case_0()


if __name__ == '__main__':
    test_lock_decorator()

# Generated at 2022-06-25 13:25:03.278712
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:08.323473
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    class TestFunc(unittest.TestCase):
        def test_function_definition(self):
            @lock_decorator
            def test_var(self):
                pass
            self.assertTrue(hasattr(test_var, '__code__'))

    return unittest.TestLoader().loadTestsFromTestCase(TestFunc)

# Generated at 2022-06-25 13:25:16.786002
# Unit test for function lock_decorator
def test_lock_decorator():
    x = 0
    lock = threading.Lock()

    @lock_decorator()
    def func_0():
        nonlocal x
        x += 1

    @lock_decorator(lock=lock)
    def func_1():
        nonlocal x
        x += 1

    thread_0 = threading.Thread(target=func_0)
    thread_1 = threading.Thread(target=func_1)
    thread_0.start()
    thread_1.start()
    thread_0.join()
    thread_1.join()
    assert x == 2, 'Failed lock_decorator'



# Generated at 2022-06-25 13:25:27.323814
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    assert lock_decorator.__name__ == 'lock_decorator'

# Generated at 2022-06-25 13:25:33.241868
# Unit test for function lock_decorator
def test_lock_decorator():
    class SomeClass(object):
        def __init__(self):
            self._lock_0 = ...
            self._lock_1 = ...

        @lock_decorator(attr='_lock_0')
        def method_0(self):
            assert self._lock_0
            pass

        @lock_decorator(attr='_lock_1')
        def method_1(self):
            assert self._lock_1
            pass

    @lock_decorator(lock=threading.Lock())
    def func_0():
        pass

    @lock_decorator(lock=threading.Lock())
    def func_1():
        pass

# Generated at 2022-06-25 13:25:37.973852
# Unit test for function lock_decorator
def test_lock_decorator():

    # Define variable attr
    attr = None

    # Evaluate test-case 0
    try:
        test_case_0()
    except Exception as e:
        print("Caught exception in test case 0: {0}".format(e))


# Execute test suite
test_lock_decorator()


# pylint: disable=unused-variable

# Generated at 2022-06-25 13:25:38.904136
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:25:51.174667
# Unit test for function lock_decorator
def test_lock_decorator():
    # Create an instance of the class lock_decorator for testing
    lock_decorator_instance = lock_decorator.__new__(lock_decorator)

    # Check we are not testing the abstract class
    assert lock_decorator_instance is None, 'Assertion failed, Expected None, got {0!r}'.format(lock_decorator_instance)

# Generated at 2022-06-25 13:25:59.759159
# Unit test for function lock_decorator
def test_lock_decorator():
    from unittest import TestCase
    import threading

    class TestClass(object):
        def __init__(self):
            self.lock = threading.Lock()

        @lock_decorator(attr='lock')
        def method(self):
            return 1

    class TestFailed:
        def __init__(self):
            self.lock = 1

        @lock_decorator(attr='lock')
        def method(self):
            return 1

    class Test(TestCase):
        def test_0(self):
            pass

        def test_1(self):
            assert TestClass().method() == 1

        def test_2(self):
            self.assertRaises(AttributeError, TestFailed().method)


# Generated at 2022-06-25 13:26:07.710008
# Unit test for function lock_decorator
def test_lock_decorator():
    import sys
    import os
    import tempfile
    from unittest import TestCase
    import pytest
    import random
    import threading
    try:
        import queue

        class Queue(object):
            def __init__(self, *args, **kwargs):
                self.q = queue.Queue(*args, **kwargs)

            def get(self, *args, **kwargs):
                return self.q.get(*args, **kwargs)

            def put(self, *args, **kwargs):
                return self.q.put(*args, **kwargs)
    except ImportError:
        import Queue


    class TestLock(TestCase):
        def setUp(self):
            self.q = Queue(maxsize=100)
            self.l = threading.Lock()

# Generated at 2022-06-25 13:26:15.163748
# Unit test for function lock_decorator
def test_lock_decorator():
    from pytest_ansible_modules.lock_decorator import lock_decorator

    # make sure the test case does not fail
    test_case_0()

    test_cases = [
        # Initialize the test environment for lock_decorator
        (
            {
                'lock_decorator': dict()
            },
            {
                'out': dict()
            }
        ),
    ]

    for args, kwargs in test_cases:
        lock_decorator(*args, **kwargs)

    # Test successful completion of method
    assert True



# Generated at 2022-06-25 13:26:18.119140
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading
    lock = threading.Lock()

    @lock_decorator(lock=lock)
    def test():
        return 1

    assert lock.acquire()
    assert test() == 1



# Generated at 2022-06-25 13:26:19.244280
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:26:20.483397
# Unit test for function lock_decorator
def test_lock_decorator():
    arg_0 = lock_decorator()
    assert arg_0



# Generated at 2022-06-25 13:26:21.365959
# Unit test for function lock_decorator
def test_lock_decorator():
    pass #TODO write test

# Generated at 2022-06-25 13:26:22.544243
# Unit test for function lock_decorator
def test_lock_decorator():
    assert var_0

test_lock_decorator()

# Generated at 2022-06-25 13:26:23.321858
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)

# Generated at 2022-06-25 13:26:47.743568
# Unit test for function lock_decorator
def test_lock_decorator():
    from datetime import timedelta
    import threading

    from ansible.utils.hashing import md5s
    from ansible.plugins.cache.memory_vault import CacheModule as memory_vault
    from ansible.plugins.cache.redis_vault import CacheModule as redis_vault

    _key = '{0}-{1}'.format('invenio-communities', 'ansible-vault-cache')
    _key_ttl = timedelta(minutes=1)
    _key_size = 5

    _lock = threading.Lock()

    # CacheModule.put_file()

# Generated at 2022-06-25 13:26:56.480697
# Unit test for function lock_decorator
def test_lock_decorator():
    import unittest

    import threading

    class TestLockDecorator(unittest.TestCase):

        def test_attr_lock(self):
            class SomeClass(object):

                @lock_decorator(attr='_callback_lock')
                def send_callback(self, n):
                    self._callback_value += n

            callback_lock = threading.Lock()
            some_obj = SomeClass(callback_lock)

            def callback_thread(*args, **kwargs):
                with callback_lock:
                    some_obj._callback_value = 0

            callback_thread = threading.Thread(target=callback_thread)
            callback_thread.start()
            callback_thread.join()

            self.assertEqual(some_obj._callback_value, 0)
            some_obj.send_callback(2)

# Generated at 2022-06-25 13:26:57.407193
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator


# Generated at 2022-06-25 13:27:05.331398
# Unit test for function lock_decorator
def test_lock_decorator():
    import threading

    class SomeClass(object):
        def __init__(self):
            self._callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, arg):
            return arg

        @lock_decorator(lock=threading.Lock())
        def some_method(self, arg):
            return arg

    class SomeOtherClass(object):
        @lock_decorator(attr='_callback_lock')
        def send_callback(cls, arg):
            return arg

        @lock_decorator(lock=threading.Lock())
        def some_method(cls, arg):
            return arg

    some_obj = SomeClass()
    assert some_obj.send_callback('foo') == 'foo'
    assert some

# Generated at 2022-06-25 13:27:06.810133
# Unit test for function lock_decorator
def test_lock_decorator():
    def test_case_0():
        var_0 = lock_decorator()



# Generated at 2022-06-25 13:27:17.207541
# Unit test for function lock_decorator
def test_lock_decorator():
    '''Test function lock_decorator'''
    import tempfile
    f = tempfile.NamedTemporaryFile()
    f.write('''
-------------------------------------------------------
Ran 1 test in 0.000s

OK
''')
    f.seek(0)

    import sys
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-25 13:27:19.221293
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator(lock=1)
    # Check type of ``var_0``
    assert isinstance(var_0, callable)


# Generated at 2022-06-25 13:27:27.789016
# Unit test for function lock_decorator
def test_lock_decorator():
    import pytest
    import threading
    from functools import wraps


# Generated at 2022-06-25 13:27:34.793242
# Unit test for function lock_decorator
def test_lock_decorator():
    # Setup
    from collections import namedtuple
    MockClass_0 = namedtuple('MockClass_0', ['missing_lock_attr'])
    MockClass_1 = namedtuple('MockClass_1', ['_callback_lock'])
    MockClass_2 = namedtuple('MockClass_2', ['_callback_lock', '_lock'])
    MockClass_3 = namedtuple('MockClass_3', ['_callback_lock', '_write_lock', '_read_lock'])
    MockClass_4 = namedtuple('MockClass_4', ['lock'])
    # Test
    test_case_0()
    test_case_1 = MockClass_0(missing_lock_attr='Missing lock attribute')

# Generated at 2022-06-25 13:27:37.576625
# Unit test for function lock_decorator
def test_lock_decorator():
    """ Test for lock_decorator"""
    test_case_0()


# Generated using: ``ansible-test cases --list --unit tests/units/modules/system/test_timezone.py -v``

# Generated at 2022-06-25 13:28:14.182288
# Unit test for function lock_decorator
def test_lock_decorator():
    assert 1



# Generated at 2022-06-25 13:28:15.331369
# Unit test for function lock_decorator
def test_lock_decorator():
    # User-supplied code
    ...



# Generated at 2022-06-25 13:28:16.334123
# Unit test for function lock_decorator
def test_lock_decorator():
    var_0 = lock_decorator()
    assert var_0


# Generated at 2022-06-25 13:28:22.616114
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansible.module_utils.basic import AnsibleModule

    # Define a test class
    class TestModule(object):
        def __init__(self):
            self.var_0 = var_0

    # Create a test module
    module = AnsibleModule({}, supports_check_mode=False)

    # Create instance of our test module
    test_object = TestModule()

    # Build our test function
    def test_func(self):
        return
    
    # Apply decorator to our test function
    test_func = var_0(test_func)

    # Execute the test function
    test_func()

# Generated at 2022-06-25 13:28:24.364038
# Unit test for function lock_decorator
def test_lock_decorator():
    lock_decorator_0 = lock_decorator()
    lock_decorator_1 = lock_decorator()

    # Call function lock_decorator
    assert lock_decorator_0 == lock_decorator_1

# Generated at 2022-06-25 13:28:30.714715
# Unit test for function lock_decorator
def test_lock_decorator():
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not None
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not False
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not True
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not (1)
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not 2
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not 'string'
    assert lock_decorator(attr='missing_lock_attr', lock=None) is not b'bytes'

# Generated at 2022-06-25 13:28:32.093252
# Unit test for function lock_decorator
def test_lock_decorator():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 13:28:33.485101
# Unit test for function lock_decorator
def test_lock_decorator():
    var_1 = lock_decorator(attr='_callback_lock')


# Generated at 2022-06-25 13:28:35.672653
# Unit test for function lock_decorator
def test_lock_decorator():
    from test_lock_decorator import test_case_0

    def test_case_0():
        var_0 = lock_decorator()



# Generated at 2022-06-25 13:28:37.043200
# Unit test for function lock_decorator
def test_lock_decorator():
	assert lock_decorator() == lock_decorator(lock=None)



# Generated at 2022-06-25 13:29:58.210264
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True == True



# Generated at 2022-06-25 13:30:00.698150
# Unit test for function lock_decorator
def test_lock_decorator():
    assert callable(lock_decorator)
    # No parameter specified
    var_1 = lock_decorator()
    assert callable(var_1)
    # str parameter
    var_2 = lock_decorator(attr='test')
    assert callable(var_2)


# Generated at 2022-06-25 13:30:04.445878
# Unit test for function lock_decorator
def test_lock_decorator():

    from threading import Thread, Lock

    lock = Lock()

    @lock_decorator(lock=lock)
    def decorator_lock_test(var):
        print(var)

    def my_target(var):
        decorator_lock_test(var)

    # create two threads
    t1 = Thread(target=my_target, args=(10,))
    t2 = Thread(target=my_target, args=(20,))

    # start thread 1
    t1.start()
    # start thread 2
    t2.start()

    # wait until thread 1 is completely executed
    t1.join()
    # wait until thread 2 is completely executed
    t2.join()

    print('Done!')

# Generated at 2022-06-25 13:30:11.241800
# Unit test for function lock_decorator
def test_lock_decorator():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.LockDecoratorRule import LockDecoratorRule
    from ansiblelint.runner import Runner
    import os
    import unittest

    script_dir = os.path.dirname(os.path.realpath(__file__))

    rulesdir = os.path.realpath(os.path.join(script_dir, '../../lib/ansiblelint/rules'))

    # load the rules collection
    collection = RulesCollection()
    collection.register_from_directory(rulesdir)

    # setup the runner
    runner = Runner(collection, [], [], [], [])

    # run the tests
    result = runner.run_collection('test/lock_decorator/')

    # check there are no matching errors

# Generated at 2022-06-25 13:30:12.005497
# Unit test for function lock_decorator
def test_lock_decorator():
    assert True

# Generated at 2022-06-25 13:30:18.656671
# Unit test for function lock_decorator
def test_lock_decorator():
    # Example from docs: simple use case
    # This example uses a class attribute
    # to store the lock in.
    import threading

    class callback_0:
        _callback_lock = threading.Lock()

        @lock_decorator(attr='_callback_lock')
        def send_callback(self, *args, **kwargs):
            return data_0

    # Example from docs: explicit lock object
    # This example uses an explicit lock object.
    import threading

    callback_1_lock = threading.Lock()

    class callback_1:
        @lock_decorator(lock=callback_1_lock)
        def send_callback(self, *args, **kwargs):
            return data_1

    # Example from docs: explicit lock object
    # This example uses an explicit lock object.
    import thread

# Generated at 2022-06-25 13:30:19.545422
# Unit test for function lock_decorator
def test_lock_decorator():
    # FIXME: This code needs to be tested
    assert False

# Generated at 2022-06-25 13:30:24.241670
# Unit test for function lock_decorator
def test_lock_decorator():
    from . import lock_decorator
    from mock import Mock
    from functools import wraps

    def inner(*args, **kwargs):
        print('inner')

    @wraps(inner)
    def outer(*args, **kwargs):
        print('outer')

    m = Mock()
    m.return_value = outer
    lock_decorator(attr='attr')(m())
    m.assert_called_with(var_0)
    assert m() == outer

    m2 = Mock()
    m2.return_value = inner
    lock_decorator(lock=var_0)(m2())
    m2.assert_called_with(var_0)
    assert m2() == inner

# Generated at 2022-06-25 13:30:28.302247
# Unit test for function lock_decorator
def test_lock_decorator():
    import random
    import threading
    import time

    class Counter(object):
        def __init__(self):
            # Define attribute as instance variable
            self._counter = 0
            self._lock = threading.Lock()

        @lock_decorator()
        def increment(self):
            # ``self`` is first argument, call the decorator
            # using just ``()``
            self._counter += 1
            return self._counter

        @lock_decorator(lock=self._lock)
        def decrement(self):
            # Explicitly pass a lock for the decorator
            # to use
            self._counter -= 1
            return self._counter

    class TestThread(threading.Thread):
        def __init__(self, counter):
            super(TestThread, self).__init__()
            self.counter

# Generated at 2022-06-25 13:30:30.013990
# Unit test for function lock_decorator
def test_lock_decorator():
    c0 = lock_decorator()
    assert c0(test_case_0)() == None

# Generated at 2022-06-25 13:33:53.483311
# Unit test for function lock_decorator
def test_lock_decorator():
    '''test_lock_decorator'''
    var_0 = lock_decorator()
    assert var_0 == lock_decorator
    assert isinstance(var_0, type(lock_decorator))



# Generated at 2022-06-25 13:34:00.598667
# Unit test for function lock_decorator
def test_lock_decorator():
    # Unit test for function lock_decorator

    class A(object):
        @lock_decorator(attr='_lock')
        def some_method(self):
            return self._value

        @lock_decorator(attr='_lock')
        def some_other_method(self, value):
            self._value += value
            return self._value

    a = A()
    a._lock = threading.Lock()
    a._value = 0

    def test_a():
        return a.some_other_method(1)

    threads = [threading.Thread(target=test_a) for i in range(10)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert a.some_method() == 10

    # Unit test for function lock_dec