

# Generated at 2022-06-21 01:24:33.820340
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test setup:
    fake_vars = dict()

    all_tags = ['a', 'b', 'c']
    tags = ['a', 'b']

    fake_task = Taggable()
    fake_task.tags = tags

    # Test:
    #   'only_tags' is not specified
    #   'skip_tags' is not specified
    #   'tags' are specified
    #   Expected result:
    #       should_run is True
    only_tags = None
    skip_tags = None
    result = fake_task.evaluate_tags(only_tags, skip_tags, fake_vars)
    assert(result == True)

    # Test:
    #   'only_tags' is specified
    #   'skip_tags' is not specified
    #   'tags' are specified
   

# Generated at 2022-06-21 01:24:44.759119
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a temporary object
    class A:
        def __init__(self):
            self.tags=['']

    Taggable._load_tags(A(),'one,two')
    assert (Taggable.evaluate_tags(A(),{'one'},{'two'},{'facts': {'ansible_ssh_host': '127.0.0.1'}}))
    assert (not Taggable.evaluate_tags(A(),{'one'},{'two'},{'facts': {'ansible_ssh_host': '192.168.0.1'}}))
    assert (not Taggable.evaluate_tags(A(),{'one'},{'all'},{'facts': {'ansible_ssh_host': '127.0.0.1'}}))

# Generated at 2022-06-21 01:24:53.413206
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_inst_1 = Taggable()
    taggable_inst_1._tags = ['tag_1', 'tag_2', 'tag_3']
    taggable_inst_1.only_tags = ['tag_1', 'tag_5']
    taggable_inst_1.skip_tags = ['tag_2']
    assert taggable_inst_1.evaluate_tags(taggable_inst_1.only_tags, taggable_inst_1.skip_tags, None)


# Generated at 2022-06-21 01:25:01.565680
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags_to_test = frozenset(['unit_test'])
    tags_to_skip = frozenset(['never'])
    tags_to_only = frozenset(['always'])

    test_options = dict(
        only_tags=tags_to_only,
        skip_tags=tags_to_skip,
        tags=tags_to_test,
    )

    test_item = {}
    for key, value in test_options.items():
        test_item[key] = value

    # Instance of object Taggable with _tags set to unit_test
    test_instance = Taggable()
    test_instance.tags = test_options.get('tags')

    # Evaluate tags and check result

# Generated at 2022-06-21 01:25:04.741550
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        tg = Taggable()
    except Exception as e:
        print("Error! Class Taggable initialization failed: " + str(e))
        return

# Generated at 2022-06-21 01:25:16.855589
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:25:23.481477
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    base=Base()
    assert base._load_tags('tags', []) == []
    assert base._load_tags('tags', 'tag1,tag2') == ['tag1', 'tag2']
    assert base._load_tags('tags', 'tag1,tag2,tag3') == ['tag1', 'tag2', 'tag3']
    try:
        base._load_tags('tags', 'tag1,tag2,tag3,tag4')
    except AnsibleError as e:
        assert 'tags must be specified as a list' in e.message

# Generated at 2022-06-21 01:25:34.034270
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import PlayBase
    from ansible.template import Templar
    import ansible.constants as C
    import os

    if not os.path.exists(C.DEFAULT_LOCAL_TMP):
        os.mkdir(C.DEFAULT_LOCAL_TMP)

    # create a dummy Ansible Playbook
    pb = PlayBase()

    # create a dummy Ansible Task
    task = Taggable()

    # create an Ansible Templar with a dummy variable
    templar = Templar(loader=None, variables={"ansible_variable": "hello"})

    # test case 1
    task.tags = ["non-empty"]
    only_tags = frozenset(["always", "tagged", "non-empty", "all"])
    skip_tags = frozenset

# Generated at 2022-06-21 01:25:45.423814
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.splitter import parse_kv
    ####################################################################################################################
    # Test Tags of Task
    ####################################################################################################################
    #Testcase 1: only_tags=['tag1', 'tag2'], skip_tags=['tag3', 'tag4'], tags=['tag1']
    task = Task(dict())
    only_tags = ['tag1', 'tag2']

# Generated at 2022-06-21 01:25:47.338307
# Unit test for constructor of class Taggable
def test_Taggable():
    print('Testing import of Taggable class')

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:26:08.556187
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags, only_tags, skip_tags, vars):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.vars = vars
            self.run = self.evaluate_tags(only_tags, skip_tags, vars)

    # only_tags with "all"
    o1 = MyTaggable(['test', 'always'],
                    ['all'],
                    [],
                    {'test': 'test'})
    assert o1.run

    o2 = MyTaggable(['test', 'never'],
                    ['all'],
                    [],
                    {'test': 'test'})
    assert not o2.run

    # only_tags

# Generated at 2022-06-21 01:26:11.542715
# Unit test for constructor of class Taggable
def test_Taggable():
    class Test():
        __metaclass__ = Taggable
        def __init__(self):
            pass
    t = Test()
    assert t._tags == []



# Generated at 2022-06-21 01:26:23.302007
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    m = Taggable()
    m.tags = ['tag1', 'tag2']
    print('test_Taggable_evaluate_tags: m.tags=%s' % repr(m.tags))
    assert m.evaluate_tags(only_tags = ['tag1' , 'tag2'], skip_tags = [], all_vars = {})
    assert not m.evaluate_tags(only_tags = ['tag2'], skip_tags = ['tag1'], all_vars = {})
    assert not m.evaluate_tags(only_tags = ['tag1'], skip_tags = ['tag2'], all_vars = {})
    assert m.evaluate_tags(only_tags = ['tag1'], skip_tags = [], all_vars = {})

# Generated at 2022-06-21 01:26:24.359891
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-21 01:26:36.816821
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def test_one(tests, tags, only_tags, skip_tags, expect):
        loader = FakeLoader()
        all_vars = dict()
        t = Taggable()
        t.tags = tags
        t._loader = loader
        if t.evaluate_tags(only_tags, skip_tags, all_vars) != expect:
            print("ERROR: %s" % tests)

    # Just test the if structure, not the tags evaluation.
    # list of tests with:
    # tags, only_tags, skip_tags, expected_result

# Generated at 2022-06-21 01:26:44.846455
# Unit test for constructor of class Taggable

# Generated at 2022-06-21 01:26:49.654737
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass
    obj = MyTaggable()
    assert obj._tags == [], 'Taggable did not set default value for _tags'
    obj._tags = 'a,b'
    assert obj._tags == ['a', 'b']

# Generated at 2022-06-21 01:27:00.986355
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile

    # test __constructor__ of Base play
    base = Base()
    assert base.tags == base._tags

    # test class Play
    p = Play()
    assert p.tags == p._tags

    # test class PlayContext
    pc = PlayContext()
    assert pc.tags == pc._tags

    # test class Block
    b = Block()
    assert b.tags == b._tags

    # test

# Generated at 2022-06-21 01:27:01.551301
# Unit test for constructor of class Taggable
def test_Taggable():
  Taggable()

# Generated at 2022-06-21 01:27:03.938650
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == None
    assert t.untagged == frozenset(['untagged'])

# Generated at 2022-06-21 01:27:39.484638
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Run unit test for method evaluate_tags of class Taggable
    '''

    import os
    import sys
    import unittest

    # creating the taggable test instance
    class TaggableTest(Taggable):

        def __init__(self):
            self._loader = None
            self.tags = []

    taggable_test = TaggableTest()

    # running the unit test
    class AnsibleTaggableTestCase(unittest.TestCase):

        def test_evaluate_tags(self):
            '''
            Run unit test for method evaluate_tags of class Taggable
            '''

            # test case 1: check that untagged task is ignored when
            #              only_tags is set to [tag1]
            only_tags = ['tag1']
            skip_tags = []

# Generated at 2022-06-21 01:27:42.221826
# Unit test for constructor of class Taggable
def test_Taggable():
    test_value = Taggable()
    assert test_value._tags == list
    assert test_value.untagged == frozenset(['untagged'])


# Generated at 2022-06-21 01:27:53.440078
# Unit test for constructor of class Taggable
def test_Taggable():
    # Example of using the Taggable class
    class TaggableClass(Taggable):
        def __init__(self):
            pass

    taggable = TaggableClass()
    # Test that the _tags field is initialized correctly
    assert taggable._tags == []

    # Test that tags set to a list is stored correctly
    taggable.tags = ['tag1', 'tag2']
    assert taggable._tags == ['tag1', 'tag2']

    # Test that tags set to a comma separated string is stored correctly
    taggable.tags = 'tag1, tag2'
    assert taggable._tags == ['tag1', 'tag2']

    # Test that tags set to a comma separated list is stored correctly
    taggable.tags = ['tag1', 'tag2, tag3']
    assert tagg

# Generated at 2022-06-21 01:28:02.961699
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    import ansible.playbook.condition
    import ansible.playbook.block

    # check Block
    block = Block()
    assert len(block.tags) == 0

    # check Task
    task = Task()
    assert len(task.tags) == 0

    # check Play
    play = Play()
    assert len(play.tags) == 0

    # check Handler
    handler = Handler()
    assert len(handler.tags) == 0

    # check Role
    role = Role()
    assert len(role.tags) == 0

    # check Include
    include = ans

# Generated at 2022-06-21 01:28:14.698096
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible import constants as C
    from ansible.vars.manager import VariableManager

    b = Base()
    t = Taggable()
    b._initialize_attributes()
    t._initialize_attributes()
    vm = VariableManager()
    b._variable_manager = vm

    t.tags = ['test']
    t.evaluate_tags(only_tags=['test1'], skip_tags=[], all_vars={})

    #Taggable._load_tags

# Generated at 2022-06-21 01:28:16.450841
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags is not None

# Generated at 2022-06-21 01:28:26.130594
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    def get_task_with_tags(tags):
        task_include = TaskInclude()
        task_include.action = 'some_action'
        task_include.tags = tags
        return task_include

    def get_block(block_parent, tags, tasks):
        block = Block()
        block.block  = []
        block.tags   = tags
        block._parent = block_parent
        block.block  = tasks
        return block

    def get_blocks_with_tags(tags, tasks):
        return [get_block(None, tags, tasks)]

    def run_without_tags(blocks):
        for block in blocks:
            block.filter_tagged_tasks(None, None)

# Generated at 2022-06-21 01:28:29.698264
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    tags = ['all', 'test']
    x._tags = tags
    assert tags == x.tags

# Generated at 2022-06-21 01:28:36.741997
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        pass
    dummy = DummyTaggable()

    dummy.tags = ['tag1', 'tag2', 'tag3']
    ret = dummy.evaluate_tags(
        only_tags=['tag1', 'tag2', 'tag3'],
        skip_tags=[],
        all_vars={},
    )
    assert ret is True

    dummy.tags = ['tag1', 'tag2', 'tag3', 'always']
    ret = dummy.evaluate_tags(
        only_tags=['tag1', 'tag2', 'tag3'],
        skip_tags=[],
        all_vars={},
    )
    assert ret is True

    dummy.tags = [1, 2, 3]

# Generated at 2022-06-21 01:28:46.960380
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
    def do_test(tags, only_tags, skip_tags, expected_return_value):
        taggable = MyTaggable(tags)
        return_value = taggable.evaluate_tags(only_tags, skip_tags, {})
        assert return_value == expected_return_value, \
              "Expected tags=%s, only_tags=%s, skip_tags=%s to return %s, but got %s" % \
              (tags, only_tags, skip_tags, expected_return_value, return_value)
    # test for the default (no tags, no restriction)
    do_test(None, None, None, True)
    # test for the default (no tags

# Generated at 2022-06-21 01:29:17.814342
# Unit test for constructor of class Taggable
def test_Taggable():

    taggable = Taggable()
    assert isinstance(taggable, Taggable)
    assert taggable.tags == []

#Unit test for method evaluate_tags

# Generated at 2022-06-21 01:29:26.117123
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    obj_1 = Taggable()
    obj_2 = Taggable()
    obj_3 = Taggable()
    obj_4 = Taggable()

    obj_1.tags = ['one_tag']
    obj_2.tags = ['two_tags']
    obj_3.tags = ['three_tags', 'four_tags']
    obj_4.tags = []

    assert obj_1.evaluate_tags(only_tags=['one_tag'], skip_tags=[], all_vars=dict()), "evaluate_tags"
    assert not obj_2.evaluate_tags(only_tags=['one_tag'], skip_tags=[], all_vars=dict()), "evaluate_tags"

# Generated at 2022-06-21 01:29:26.758857
# Unit test for constructor of class Taggable
def test_Taggable():

    #TODO: Complete this unit test
    pass

# Generated at 2022-06-21 01:29:37.128293
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    # Test default constructor value
    t._tags = 'tag1,tag2,tag3'
    assert t._load_tags(t.tags, t.tags) == ['tag1', 'tag2', 'tag3']

    # Test constructor with a list
    t._tags = ['tag1', 'tag2', 'tag3']
    assert t._load_tags(t.tags, t.tags) == ['tag1', 'tag2', 'tag3']

    # Test constructor with an integer
    t._tags = 1
    assert t._load_tags(t.tags, t.tags) == ['1']


# Generated at 2022-06-21 01:29:40.370814
# Unit test for constructor of class Taggable
def test_Taggable():
    """ unit tests for Taggable class """
    test = Taggable()
    assert type(test.tags) == list
    assert type(test._tags) == FieldAttribute
    assert isinstance(test._tags.isa, str)

# Generated at 2022-06-21 01:29:53.286046
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    x = Base()
    assert x._tags == [], x._tags
    # Exception should not be raised when list of strings is provided
    x._load_tags('tags', ['abc','def','xyz'])
    assert x._tags == ['abc','def','xyz'], x._tags
    # Exception should not be raised when list of ints is provided
    x._load_tags('tags', [1,2,3])
    assert x._tags == [1,2,3], x._tags
    # Exception should not be raised when list of strings and ints is provided
    x._load_tags('tags', ['abc',2,3])
    assert x._tags == ['abc',2,3], x._tags
    # Exception should be raised when list of strings and ints is provided
   

# Generated at 2022-06-21 01:29:59.421638
# Unit test for constructor of class Taggable
def test_Taggable():
    class Foo(Taggable):
        def __init__(self):
            super(Foo, self).__init__()
    foo = Foo()
    assert 'untagged' in foo.untagged
    assert foo.tags == []
    assert foo._tags == []
    assert foo.untagged == frozenset(['untagged'])

# Generated at 2022-06-21 01:30:12.005679
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host

    class Task(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None
            self.only_tags = None
            self.skip_tags = None

    task = Task()
    task.tags = ['tag1', 'tag2']
    play_context = PlayContext()
    host = Host(name='127.0.0.1')
    all_vars = host.get_vars()

    # default, tasks to run
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, all_vars) == True
    # only_tags, run
    play_context.only_tags = ['tag2']

# Generated at 2022-06-21 01:30:20.067231
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._tags, list)
    assert isinstance(taggable.tags, list)

    assert isinstance(taggable.untagged, frozenset)

    assert isinstance(taggable.evaluate_tags(None, None, None), bool)
    assert not taggable.evaluate_tags(None, None, None)
    assert taggable.evaluate_tags(["test_tag"], None, None)


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-21 01:30:21.113391
# Unit test for constructor of class Taggable
def test_Taggable():
    pass



# Generated at 2022-06-21 01:31:24.133761
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.role
    import ansible.playbook.conditional
    import ansible.playbook.block
    import ansible.playbook.task

    class TaggableObjects:
        def __init__(self, tags, only_tags, skip_tags):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags

    class TaggableRole(ansible.playbook.role.Role, Taggable):
        pass

    class TaggableConditional(ansible.playbook.conditional.Conditional, Taggable):
        pass

    class TaggableBlock(ansible.playbook.block.Block, Taggable):
        pass


# Generated at 2022-06-21 01:31:33.948722
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyTaggable(Taggable):
        pass

    d = DummyTaggable()

    # Only tags
    assert d.evaluate_tags(only_tags=['tag1','tag2'], skip_tags=[], all_vars=dict())
    d.tags = ['tag1','tag2']
    assert d.evaluate_tags(only_tags=['tag1','tag2'], skip_tags=[], all_vars=dict())
    d.tags = ['tag1','tag3']
    assert not d.evaluate_tags(only_tags=['tag1','tag2'], skip_tags=[], all_vars=dict())
    d.tags = ['tag3','tag4']

# Generated at 2022-06-21 01:31:39.649979
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()

    t.tags = "quick, brown"
    t._load_tags("tags", "quick, brown")

    t.tags = ['quick', 'brown']
    t._load_tags("tags", ['quick', 'brown'])


test_Taggable()

# Generated at 2022-06-21 01:31:45.850891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role

    import pytest

    # Create a task with tags
    t = TaskInclude()
    t._load_name_from_role = lambda x: None
    t.tags = ['always', 'bar']

    # Create a task with no tags
    t2 = TaskInclude()
    t2._load_name_from_role = lambda x: None
    t2.tags = []

    # Create a task with no tags
    t3 = TaskInclude()
    t3._load_name_from_role = lambda x: None
    t3.tags = ['never']

    # Create a role with tags
    r = Role()
    r.tags = ['always']

    # Create a role with no tags
    r

# Generated at 2022-06-21 01:31:54.931265
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test _load_tags
    taggable_obj = Taggable()
    assert(isinstance(taggable_obj._load_tags("", []), list))
    assert(isinstance(taggable_obj._load_tags("", "foo"), list))
    assert(taggable_obj._load_tags("", ["foo","bar"]) == ["foo", "bar"])
    assert(taggable_obj._load_tags("", "foo, bar") == ["foo", "bar"])
    try:
        taggable_obj._load_tags("", {})
        assert(False)
    except Exception as e:
        assert(True)
    try:
        taggable_obj._load_tags("", None)
        assert(False)
    except Exception as e:
        assert(True)

   

# Generated at 2022-06-21 01:32:00.857566
# Unit test for constructor of class Taggable

# Generated at 2022-06-21 01:32:13.148008
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    Testing Taggable constructors
    '''
    # InitObject is a class with __init__ method
    from ansible.utils.init import InitObject
    from ansible.playbook.base import Base
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.stats import AggregateStats

# Generated at 2022-06-21 01:32:23.199967
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # todo: check with a task that has no tags
    t = Taggable()
    t._tags = ['all', 'test', 'foo', 'not_all']
    # always run regardless of tags, set by option always_run
    assert t.evaluate_tags(['always', 'something'], [], {}) == True
    # always run regardless of tags, set by option always_run
    assert t.evaluate_tags(['never', 'something'], ['always'], {}) == True
    # run if item tagged with anything in only_tags, skip if tagged with anything in skip_tags
    assert t.evaluate_tags(['all'], [], {}) == True
    assert t.evaluate_tags(['all'], ['all'], {}) == False

# Generated at 2022-06-21 01:32:30.538105
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    # expected result:
    # t._tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    assert t._tags.__class__.__name__ == 'FieldAttribute'
    assert t._tags.default == list
    assert t._tags.isa == 'list'
    assert t._tags.listof == (string_types, int)

# Unit tests for the evaluate_tags method of class Taggable

# Generated at 2022-06-21 01:32:42.060558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.taggable import Taggable
    
    class MyTaggable(Base, Taggable):
        pass

    # Simple test case
    t = MyTaggable()
    t.tags = ['test_tag']
    assert t.evaluate_tags(None, None, {})

    # Untagged
    t.tags = []
    assert t.evaluate_tags(None, None, {})

    # Only 'Test_tag'
    t.tags = ['test_tag']
    assert t.evaluate_tags(['test_tag'], None, {}) == True 
    assert t.evaluate_tags(['another_tag'], None, {}) == False 

    # Only 'Test_tag', 'another_tag'