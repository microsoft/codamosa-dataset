

# Generated at 2022-06-21 01:24:34.271143
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    o = Taggable()
    o.tags = ['foo', 'bar', 'baz']

    assert(o.evaluate_tags(['foo'], None, dict()) is True)
    assert(o.evaluate_tags(['foo', 'bar'], None, dict()) is True)
    assert(o.evaluate_tags(['foo', 'bar', 'baz'], None, dict()) is True)
    assert(o.evaluate_tags(['foo', 'bar', 'baz', 'foobar'], None, dict()) is True)
    assert(o.evaluate_tags(['foobar'], None, dict()) is False)

    assert(o.evaluate_tags(None, ['foo'], dict()) is True)
    assert(o.evaluate_tags(None, ['foo', 'bar'], dict()) is True)

# Generated at 2022-06-21 01:24:42.542773
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import IncludeRole
    results = dict(
        _hosts=dict(),
        _variable_manager=dict(),
        _loader=dict()
    )
    include = IncludeRole(
        task='task',
        role='role',
        tasks=dict(),
        vars=dict(),
        handlers=dict(),
        tags=list(),
        _variable_manager=results['_variable_manager'],
        _hosts=results['_hosts'],
        _loader=results['_loader']
    )
    assert isinstance(include, Taggable)

# Generated at 2022-06-21 01:24:54.666159
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.utils.vars import combine_vars

    t = Base()
    t.tags = ['always','global']
    inventory_vars = {'global_var': 'global value'}
    group_vars = {'group_var': 'group value'}
    host_vars = {'host_var': 'host value'}
    add_host_vars = {'add_host_var': 'add_host value'}
    task_vars = {'task_var': 'task value'}
    include_vars = {'include_var': 'include value'}

    local_vars = combine_vars(inventory_vars, group_vars, host_vars)

# Generated at 2022-06-21 01:25:02.234875
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class _Taggable(Taggable):
        def __init__(self, tags):
            self._tags = tags

    # 1. tags: always
    item = _Taggable(['always'])
    assert item.evaluate_tags(['all'], [], {}), "1. tags: always"

    # 2. tags: never
    item = _Taggable(['never'])
    assert item.evaluate_tags(['all'], [], {}), "2. tags: never"

    # 3. tags: all & always
    item = _Taggable(['all', 'always'])
    assert item.evaluate_tags(['all'], [], {}), "3. tags: all & always"

    # 4. tags: all & never
    item = _Taggable(['all', 'never'])
   

# Generated at 2022-06-21 01:25:08.862028
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    taggable = Taggable()
    taggable.tags = 'all, tagged, never'
    only_tags = set(['all', 'tagged'])
    skip_tags = set(['untagged'])
    all_vars = dict()
    # Execute
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    # Test
    assert result



# Generated at 2022-06-21 01:25:10.052872
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert 'tags' in taggable._attributes
    assert taggable.tags == []

# Generated at 2022-06-21 01:25:21.383437
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    class TaggableMock(Taggable):

        def __init__(self, tags):
            self.tags = tags

    # Test cases
    # Only tags, no skip tags, no task tags
    task1 = TaggableMock([])
    only_tags = ["tag1", "tag2"]
    skip_tags = []
    assert task1.evaluate_tags(only_tags, skip_tags, None) == False

    # Only tags, no skip tags, task has tags
    task2 = TaggableMock(["tag1", "tag2"])
    assert task2.evaluate_tags(only_tags, skip_tags, None) == True

    # Only tags, skip tags, task has skip tags

# Generated at 2022-06-21 01:25:23.929579
# Unit test for constructor of class Taggable
def test_Taggable():

    test_Taggable = Taggable()
    assert test_Taggable.tags == [], 'Expected empty tags list'

# Generated at 2022-06-21 01:25:27.932488
# Unit test for constructor of class Taggable
def test_Taggable():
    class test_Taggable(Taggable):
        _name = 'test_Taggable'

    test_Taggable(tags=['tag1'])

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:25:30.691516
# Unit test for constructor of class Taggable
def test_Taggable():
    y = Taggable()
    assert y._tags == []

if __name__ == "__main__":
    y = Taggable()
    print(y._tags)

# Generated at 2022-06-21 01:25:53.076426
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    # Create a Taggable object and validate it
    _tag = Taggable()
    assert _tag.tags == []
    assert _tag.untagged == frozenset(['untagged'])

    # Create a Taggable object and validate it
    _tag = Taggable()
    assert _tag.tags == []
    assert _tag.untagged == frozenset(['untagged'])

    # Create a Play object with and without tags

# Generated at 2022-06-21 01:25:59.950086
# Unit test for constructor of class Taggable
def test_Taggable():
    class fake_class:
        tags = FieldAttribute(isa='list', default=list, listof=(string_types))

    t = Taggable()
    t.tags = ["a", "b", "c"]
    assert t.tags == ["a", "b", "c"]
    t.tags = "a, b, c"
    assert t.tags == ["a", "b", "c"]
    fake_class.tags = t.tags
    assert fake_class.tags == ["a", "b", "c"]

# Generated at 2022-06-21 01:26:05.762539
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Make sure Taggable class constructor works
    """

    obj = Taggable()
    assert obj

    obj = Taggable(tags="foo,bar")
    assert obj
    assert obj.tags == ['foo', 'bar']

    obj = Taggable(tags="foo,bar,foo,bar")
    assert obj
    assert obj.tags == ['foo', 'bar', 'foo', 'bar']

# Generated at 2022-06-21 01:26:17.795466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Playbook, PlaybookInclude

    play = Playbook.load(dict(
        name = 'dummy playbook for testing evaluate_tags',
        hosts = 'localhost',
        gather_facts = False,
        tasks = [
            dict(
                name = 'first task',
                ping = '',
            ),
            dict(
                name = 'second task',
                ping = '',
            ),
            PlaybookInclude.load(dict(
                name = 'third task',
                include = 'included_playbook.yml',
            )),
        ],
    ))

    tasks = play.get_tasks()

    only_tags = ['first', 'third']
    skip_tags = ['never']

    assert tasks[0].evaluate_tags(only_tags, skip_tags)

# Generated at 2022-06-21 01:26:27.815581
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    t1 = Task()
    t1._ds = dict(tags=['tag1'])
    assert t1.evaluate_tags(['tag1'], [], {})
    assert not t1.evaluate_tags(['tag2'], [], {})

    t1 = Task()
    t1._ds = dict(tags=['tag2'])
    assert t1.evaluate_tags(['tag1'], ['tag2'], {})
    assert not t1.evaluate_tags(['tag1'], ['tag1'], {})

    t1 = Task()
    t1._ds = dict(tags=['tag1'])
    assert t1.evaluate_tags([], ['tag2'], {})

# Generated at 2022-06-21 01:26:40.406895
# Unit test for constructor of class Taggable
def test_Taggable():
    import json
    import sys
    t = Taggable()
    # Set the loader
    t.set_loader(sys.modules[__name__])
    # Set the variable
    t.set_variable_manager(None)
    # Set the _ds to some value
    t._ds = json.loads('''
        [
            "tag1",
            "tag2"
        ]
    ''')
    # Set the attr to _tags
    # Should set the _tags list to be ['tag1', 'tag2']
    t._load_tags('_tags', t._ds)
    assert t._tags == ['tag1', 'tag2']
    # Should call evaluate_tags with only_tags = ['all'], skip_tags = ['never'], all_vars = {}
    # Should return False

# Generated at 2022-06-21 01:26:43.227173
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    test_task = TaskInclude()
    assert isinstance(test_task._tags, list)

# Generated at 2022-06-21 01:26:54.858190
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test case for evaluating tags on ansible items: tasks, blocks and plays
    """
    class FakeTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self._attributes = []
            self.tags = []

    taggable = FakeTaggable()
    taggable.tags = ["all", "here"]


# Generated at 2022-06-21 01:27:00.730504
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags(None, ['tag1', 'tag2', 'tag3']) == ['tag1', 'tag2', 'tag3']
    assert Taggable._load_tags(None, 'tag4, tag5, tag6') == ['tag4', 'tag5', 'tag6']
    assert Taggable._load_tags(None, 'tag7') == ['tag7']

# Generated at 2022-06-21 01:27:06.685331
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    >>> t = Taggable()
    >>> t.tags = [1, '2', 3]
    >>> t._load_tags('tags', 'a,  b, c')
    ['a', 'b', 'c']
    >>> t._load_tags('tags', ['a', 'b', 'c'])
    ['a', 'b', 'c']
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 01:27:25.177759
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    assert t.tags == []
    t = Taggable(tags="one,two")
    assert t._tags == ['one', 'two']
    assert t.tags == ['one', 'two']


# Generated at 2022-06-21 01:27:30.075637
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize test
    obj = {"tags": ["mytag"]}
    only_tags = []
    skip_tags = []
    all_vars = { "mytag": "mytag" }

    # Call tested method
    result = Taggable.evaluate_tags(obj, only_tags, skip_tags, all_vars)

    # Check result
    assert result == True


# Generated at 2022-06-21 01:27:41.159373
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import datetime

    ##########################################################################################################
    #
    # Taggable test class definition
    #
    ##########################################################################################################

    class TestTaggable():

        def __init__(self):
            self._tags = ['tag1', 'tag2']

        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

    ##########################################################################################################
    #
    # Test definition
    #
    ##########################################################################################################


# Generated at 2022-06-21 01:27:41.784720
# Unit test for constructor of class Taggable
def test_Taggable():
    pass

# Generated at 2022-06-21 01:27:42.428293
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-21 01:27:50.443383
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    play_ds = dict(
        name = "test play",
        hosts = "all",
        gather_facts = "no"
    )

    # init Taggable object by constructor
    play = Taggable.load(play_ds, play=Play())
    assert play._attributes['tags'] == ['untagged']

    # init Taggable object by constructor
    play = Taggable.load(play_ds, play=Play(), attribute_class=dict)
    assert play._attributes['tags'] == ['untagged']


# Generated at 2022-06-21 01:27:57.193133
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == list()
    assert obj._load_tags(attr=None, ds=['test','test2']) == ['test','test2']
    assert obj._load_tags(attr=None, ds='test,test2') == ['test', 'test2']

# Generated at 2022-06-21 01:27:58.648826
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []
    assert isinstance(obj.tags, list)
    assert obj.tags != ''

# Generated at 2022-06-21 01:28:06.543289
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a dummy class implementing evaluate_tags
    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = []

    # Prepare expected results

# Generated at 2022-06-21 01:28:16.570627
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    play_list = [
        {'hosts': 'node1', 'roles': 'base'},
        {'hosts': 'node2', 'roles': 'base'},
        {'hosts': 'node3', 'roles': 'base'},
        {'hosts': 'node4', 'roles': 'base'},
    ]
    my_play = Play()
    my_play.load(play_list, 'foo.yml', 'foo')

    group1 = Group('node1')
    group2 = Group('node2')
    group3 = Group('node3')
    group4 = Group('node4')

    host1 = Host('node1')
    host

# Generated at 2022-06-21 01:28:43.568294
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test 1: test_attrs
    result = Taggable._load_tags(None, "one,two,three")
    assert result == ['one', 'two', 'three']

    # Test 2: test_attrs
    result = Taggable._load_tags(None, ['one', 'two', 'three'])
    assert result == ['one', 'two', 'three']

    # Test 3: test_attrs
    result = Taggable._load_tags(None, "one")
    assert result == ['one']

    # Test 4: test_attrs
    result = Taggable._load_tags(None, ['one'])
    assert result

# Generated at 2022-06-21 01:28:48.061114
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    Constructor test cases
    '''
    o = Taggable()

    if o.tags != []:
        assert False, 'default constructor of Taggable failed'
    return True


# Generated at 2022-06-21 01:28:57.559413
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self):
            self._tags = list()

    tagged = MyTaggable()
    tagged._tags = ['tagged_task',]
    always = MyTaggable()
    always._tags = ['always',]
    never = MyTaggable()
    never._tags = ['never',]
    some = MyTaggable()
    some._tags = ['one', 'two', 'three', 'four']
    some._tags.append('some')
    some._tags.append(['five', 'six'])
    some._tags.append(['seven'])

    # 'always' tasks get run no matter what
    assert always.evaluate_tags(only_tags=set(['one',]), skip_tags=set(['one',]), all_vars={})

# Generated at 2022-06-21 01:29:03.956037
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    task = Task()
    handler = Handler()
    role = Role()
    block = Block()
    play = Play()
    assert(task.tags == [])
    assert(handler.tags == [])
    assert(role.tags == [])
    assert(block.tags == [])
    assert(play.tags == [])


# Generated at 2022-06-21 01:29:09.452800
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import RoleInclude
    test_object = RoleInclude()
    assert test_object.tags == []
    assert test_object.tags is test_object._tags
    assert test_object == test_object

# Generated at 2022-06-21 01:29:16.506778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """

    When loading task and play objects, they get a list of tags
    that are converted to the final version by the evaluate_tags
    method. This tests that method to ensure the correct behavior.

    """

    import pytest

    # example object that is like a play or task object
    class fake_object(Taggable):
        def __init__(self):
            self._tags = None

    obj = fake_object()
    
    # test cases for evaluate_tags

# Generated at 2022-06-21 01:29:18.050712
# Unit test for constructor of class Taggable
def test_Taggable():
    temp_Taggable = Taggable()
    # test _tags which should be an empty list
    assert len(temp_Taggable._tags) == 0


# Generated at 2022-06-21 01:29:24.351566
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_text

    class TaggableFake(Taggable):
        def __init__(self):
            self._tags = []
            self._loader = None

    # Create fake object
    taggable = TaggableFake()
    taggable.tags = ['tag1', 'tag2']

    # Define fake variables for templating
    all_vars = dict()

    # Check only tags
    only_tags = ['tag1', 'tag3']
    should_run = taggable.evaluate_tags(only_tags, None, all_vars)
    assert should_run == True

    # Check skip tags
    only_tags = []
    skip_tags = ['tag2']

# Generated at 2022-06-21 01:29:34.687568
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test Taggable.evaluate_tags method
    '''


# Generated at 2022-06-21 01:29:37.740426
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert isinstance(obj._tags, list)
    assert isinstance(obj.tags, frozenset)

# Generated at 2022-06-21 01:30:16.152048
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableClass(Taggable):
        def __init__(self):
            self._tags = []
        def get_tags(self):
            return self._tags

    test_obj = TaggableClass()
    test_obj.tags = ['all', 'never']
    only_tags = set(['all', 'never'])
    skip_tags = set(['never', 'untagged'])
    all_vars = dict()
    assert not test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    test_obj.tags = ['always', 'never']
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    test_obj.tags = ['tagged']

# Generated at 2022-06-21 01:30:25.665017
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags('test', ['1', '2']) == ['1', '2']
    assert Taggable._load_tags('test', '1, 2') == ['1', '2']
    assert Taggable._load_tags('test', '1,2') == ['1', '2']
    assert Taggable._load_tags('test', '1,  2') == ['1', '2']
    assert Taggable._load_tags('test', '1, 2, 3') == ['1', '2', '3']
    assert Taggable._load_tags('test', '1,2,3') == ['1', '2', '3']
    assert Taggable._load_tags('test', '1,  2,3') == ['1', '2', '3']


# Generated at 2022-06-21 01:30:28.516595
# Unit test for constructor of class Taggable
def test_Taggable():
    test = Taggable._load_tags('1', '[1,2]')
    assert isinstance(test, list)

    test = Taggable._load_tags('1', '1')
    assert isinstance(test, list)


# Generated at 2022-06-21 01:30:36.040508
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Test the method _evaluate_tags of the class Taggable  '''

    from ansible.playbook.play_context import PlayContext

    # Prepare the test data, i.e. the objects that the tested method will work on
    t = Taggable()
    t.tags = ['foo','bar','baz']

    # 1. Test the case when neither only_tags or skip_tags are provided (i.e. should always run)
    play_context = PlayContext()
    play_context.only_tags = set()
    play_context.skip_tags = set()
    result = t.evaluate_tags( play_context.only_tags, play_context.skip_tags, {})
    assert result

    # 2. Test the case when only_tags is provided and doesn't match the item tags
    play_context.only_

# Generated at 2022-06-21 01:30:38.026340
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-21 01:30:41.500456
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    t._tags = ['t1']
    assert t.tags == ['t1']
    t.tags = []
    assert t.tags == []
    t._load_tags = []
    assert t.tags == []

# Generated at 2022-06-21 01:30:46.857188
# Unit test for constructor of class Taggable
def test_Taggable():
    # check default value
    tag=Taggable()
    assert tag._tags == []
    tag=Taggable(tags=['tag1', 'tag2'])
    assert tag._tags == ['tag1', 'tag2']
    # check setter
    tag._tags=['tag3']
    assert tag._tags == ['tag3']
    tag._tags=('tag3', 'tag4')
    assert tag._tags == ['tag3', 'tag4']

# Generated at 2022-06-21 01:30:51.424662
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    print(taggable.tags)
    taggable.tags = ['a', 'b']
    print(taggable.tags)

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:31:00.448973
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    tasks = [
        {
            'action': {'module': 'shell', 'args': 'mkdir'},
            'tags': ['shell', 'always']
        },
        {
            'action': {'module': 'shell', 'args': 'pwd'},
            'tags': ['shell', 'pwd']
        }
    ]


# Generated at 2022-06-21 01:31:01.918500
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()
    assert t._tags == []


# Generated at 2022-06-21 01:32:05.100746
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    t = Task()
    if not isinstance(t, Taggable):
        raise Exception("Failed to create an instance of class Taggable")
    pass

# Generated at 2022-06-21 01:32:15.479401
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.module_utils.six import string_types

    class FakeLoader(object):
        def __init__(self):
            pass

        def load_from_file(self,path):
            return False

    class FakePlay(Play):
        def __init__(self):
            self._variable_manager = VariableManager()


# Generated at 2022-06-21 01:32:23.416300
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    only_tags = set()
    skip_tags = set()
    all_vars = { }
    task_incl = TaskInclude(task_include='task_include.yml')
    assert('no_tags' not in task_incl.tags)
    assert(task_incl.evaluate_tags(only_tags, skip_tags, all_vars))

    task_incl.tags = ['no_tags']
    assert(task_incl.evaluate_tags(only_tags, skip_tags, all_vars))

    only_tags = set(['no_tags'])
    assert(task_incl.evaluate_tags(only_tags, skip_tags, all_vars))

   

# Generated at 2022-06-21 01:32:33.054493
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class foo(Taggable):
        pass
    ob = foo()
    ob.tags = ['tag_a', 'tag_b']
    only_tags = []
    skip_tags = []
    all_vars = dict()
    assert ob.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['tag_a']
    assert ob.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['tag_c']
    assert not ob.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['tag_c']
    skip_tags = ['tag_a']
    assert not ob.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-21 01:32:43.119033
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

    play = Play()
    play._ds = dict(tags=['role1'])
    assert 'tags' in play.__dict__
    assert len(play.tags) == 1
    assert play.tags == ['role1']
    assert type(play.tags) == list

    block = Block(play=play)
    block._ds = dict(tags=['role2'])
    assert 'tags' in block.__dict__
    assert len(block.tags) == 1
    assert block.tags == ['role2']
    assert type(block.tags) == list


# Generated at 2022-06-21 01:32:53.884012
# Unit test for constructor of class Taggable
def test_Taggable():
    # This test only tests the tags field
    t = Taggable()
    print(t.tags)

    t = Taggable()
    t.tags = ['a','b','c']
    print(t.tags)

    t = Taggable(tags=['a'])
    print(t.tags)

    t = Taggable(tags='a,b,c')
    print(t.tags)

    t = Taggable(tags=['a', 'b', 'c'])
    print(t.tags)

    t = Taggable(tags=['a', 'b', 'c'])
    print(t.tags)

    t = Taggable(tags='a,b')
    print(t.tags)

    t = Taggable(tags='a,b,c')

# Generated at 2022-06-21 01:32:57.328178
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags is not None

test_Taggable()

# Generated at 2022-06-21 01:33:06.068272
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Unit test for method evaluate_tags of class Taggable
    """
    t = Taggable()

    assert t._load_tags(None, [1, 2, 3]) == [1, 2, 3]
    assert t._load_tags(None, "1,2,3") == ['1', '2', '3']

    try:
        t._load_tags(None, 1)
        raise AssertionError("Expected exception for invalid tags " +
                             "when evaluating evaluate_tags {}".format(t))
    except AnsibleError:
        pass

    assert t.evaluate_tags(['all'],                              ['all'],                              {}) is False
    assert t.evaluate_tags(['all'],                              [],                                   {}) is True

# Generated at 2022-06-21 01:33:14.922923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    # only_tags = ['tag1', 'tag2', 'tag3']

    # test 1:
    t.tags = ['tag1']
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

    # test 2:
    t.tags = ['tagx', 'tagy']
    assert not t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

    # test 3:
    assert not t.evaluate_tags([], [], {})

    # test 4:
    assert t.evaluate_tags(['tag0', 'tag1'], [], {})

    # test 5:
    assert t.evaluate_tags(['tag0', 'tag1'], ['tag2'], {})

    # test

# Generated at 2022-06-21 01:33:24.948620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

   import sys
   import os
   import unittest

   test_dir = os.path.abspath(os.path.dirname(__file__))
   sys.path.append(test_dir)

   from Taggable import Taggable

   class TestTaggable(unittest.TestCase):

       def setUp(self):
           self.taggable = Taggable()
           self.taggable.tags = ['alpha', 'bravo', 'charlie']

       def test_only_tags(self):
           assert self.taggable.evaluate_tags(['alpha'], None, {})
           assert self.taggable.evaluate_tags(['alpha', 'bravo', 'charlie'], None, {})