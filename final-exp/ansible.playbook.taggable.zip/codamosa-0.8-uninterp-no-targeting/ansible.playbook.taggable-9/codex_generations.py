

# Generated at 2022-06-21 01:24:36.560980
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Dummy class to be able to call the evaluate_tags method of class Taggable
    class Dummy(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Tasks to be tested
    dummy_task_1 = Dummy(tags=['tag_01'])
    dummy_task_2 = Dummy(tags=[])
    dummy_task_3 = Dummy(tags=['tag_03'])
    dummy_task_4 = Dummy(tags=['tag_04'])
    dummy_task_5 = Dummy(tags=['tag_05'])
    dummy_task_6 = Dummy(tags=['tag_06'])
    dummy_task_7 = Dummy(tags=['tag_07'])

# Generated at 2022-06-21 01:24:48.355028
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json
    import ansible.playbook.block as pb_block

    class TestTaggable(Taggable):
        def __init__(self, loader, tags=None, skip_tags=None, only_tags=None, all_vars=None):
            self._tags = tags
            self._loader = loader
            self.should_run = self.evaluate_tags(skip_tags or [], only_tags or [], all_vars or {})

    for _test in json.load(open(__file__.replace('.py', '.json'))):
        test_name = _test.pop('test_name')
        only_tags = _test.pop('only_tags')
        skip_tags = _test.pop('skip_tags')
        tags = _test.pop('tags')
        all_vars

# Generated at 2022-06-21 01:24:58.827584
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    class TestClass(Taggable):
        def __init__(self, t, o, s):
            self.tags = t
            self.only_tags = o
            self.skip_tags = s
            # dummy _loader
            self._loader = None

    # None
    assert TestClass(None, None, None).evaluate_tags(None, None, None)

    # []
    assert TestClass([], None, None).evaluate_tags(None, None, None)
    assert TestClass([], None, None).evaluate_tags([], None, None)
    assert TestClass([], None, None).evaluate_tags([], [], None)
    assert TestClass([], None, None).evaluate_tags([], None, [])
    assert TestClass([], None, None).evaluate_tags([], [], [])


# Generated at 2022-06-21 01:25:08.958055
# Unit test for constructor of class Taggable
def test_Taggable():
    assert issubclass(Taggable, object)
    assert hasattr(Taggable, '_load_tags')
    assert hasattr(Taggable, 'evaluate_tags')
    assert hasattr(Taggable, 'untagged')
    assert Taggable.untagged == frozenset(['untagged'])
    assert hasattr(Taggable, '_tags')
    assert Taggable._tags.isa == 'list'
    assert Taggable._tags.default == list
    assert Taggable._tags.listof == (string_types, int)
    assert Taggable._tags.extend == True


# Generated at 2022-06-21 01:25:13.526276
# Unit test for constructor of class Taggable
def test_Taggable():

    try:
        instance = Taggable()
        assert instance._tags == []
    except Exception as e:
        print("Failed to create Taggable instance.")
        raise

    try:
        instance.tags.append("tag1")
        instance.tags.append("tag2")
        assert len(instance.tags) == 2
        assert instance.tags[0] == "tag1"
        assert instance.tags[1] == "tag2"
    except Exception as e:
        print("Failed to create Taggable._tags.")
        raise

    try:
        result = instance.evaluate_tags(["tag1", "tag2"], [], {})
        assert result == True
    except Exception as e:
        print("Failed to test Taggable.evaluate_tags")
        raise


# Generated at 2022-06-21 01:25:23.615584
# Unit test for constructor of class Taggable
def test_Taggable():
    # with list of tags
    task = Taggable()
    assert task._load_tags(['tag1', 'tag2']) == ['tag1', 'tag2']
    # with comma separated tags
    task = Taggable()
    assert task._load_tags('tag1,tag2') == ['tag1', 'tag2']
    # with single tag
    task = Taggable()
    assert task._load_tags('tag1') == ['tag1']
    # with wrong type of value
    task = Taggable()
    try:
        task._load_tags(1)
        raise Exception
    except AnsibleError:
        pass
    # with multiple values in tag list
    task = Taggable()

# Generated at 2022-06-21 01:25:34.035473
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.playbook.base import Base

    # Add minimal test class to Taggable
    class TaggableTest(Taggable, Base):
        pass

    tt = TaggableTest()

    # No tags and nothing to skip or consider
    assert tt.evaluate_tags(set([]), set([]), {})
    assert tt.evaluate_tags(None, set([]), {})
    assert tt.evaluate_tags(set([]), None, {})
    assert tt.evaluate_tags(None, None, {})

    # No tags and skip tags 'x' and 'y'
    assert not tt.evaluate_tags(set([]), set(['x', 'y']), {})

# Generated at 2022-06-21 01:25:45.386274
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    only_tags = set(['all', 'dev', 'host1'])
    skip_tags = set(['uat'])
    all_vars = {}

    # test 1. only_tags and skip_tags are empty set, should always run
    taggable = Taggable()
    taggable.tags = set()
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # test 2. only_tags is not empty set, should run
    taggable1 = Taggable()
    taggable1.tags = set(['all'])
    assert taggable1.evaluate_tags(only_tags, skip_tags, all_vars)

    # test 3. skip_tags is not empty set, should run


# Generated at 2022-06-21 01:25:54.463865
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import Base
    from ansible.playbook.task import Task

    class FakePlay(Base):
        pass

    class FakeTask(Task, Taggable):
        def __init__(self, play):
            self._play = play
            self._loader = play._loader

    play = FakePlay()

    task = FakeTask(play)


# Generated at 2022-06-21 01:26:05.493993
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    # we need to mock a task or role in these tests
    class MyInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            self._role = Role()
            super(MyInclude, self).__init__(*args, **kwargs)

    class MyInclude2(RoleInclude):
        def __init__(self, *args, **kwargs):
            self._role = Role()
            super(MyInclude2, self).__init__(*args, **kwargs)


# Generated at 2022-06-21 01:26:13.442626
# Unit test for constructor of class Taggable
def test_Taggable():
    pass

# Generated at 2022-06-21 01:26:15.637751
# Unit test for constructor of class Taggable
def test_Taggable():

    a = Taggable()
    assert a.tags is not None

# Generated at 2022-06-21 01:26:26.183287
# Unit test for constructor of class Taggable
def test_Taggable():
    import os
    import sys

    # Load current ansible modules
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../'))

    class Task(Taggable):
        pass

    # Task is a subclass of Taggable
    task = Task()

    # Default value for instance variable _tags
    assert task._tags == []

    # Evaluate tags - Good test
    assert task.evaluate_tags([], [], {})

    # Evaluate tags - Good test
    assert task.evaluate_tags(set(['srv-db', 'srv-web']), set(['untagged', 'srv-mail']), {})

    # Evaluate tags - Fail test

# Generated at 2022-06-21 01:26:38.753416
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    from ansible.playbook.atask import Task
    from ansible.playbook.task import TaskExecutor
    te = TaskExecutor(name=None,main=None)
    t = Task(name=None,action=te)
    r = Role(name=None)
    r.add_task(t)
    t.tags = ['untagged']
    assert t.evaluate_tags(only_tags=['a'],skip_tags=None,all_vars={}) == True
    t.tags = ['untagged']
    assert t.evaluate_tags(only_tags=['tagged'],skip_tags=None,all_vars={}) == True
    t.tags = ['untagged']

# Generated at 2022-06-21 01:26:45.696460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=string_types, extend=True)

    collection = TestTaggable()

    def test(tags, only_tags, skip_tags, assert_value):
        collection.tags = tags
        assert collection.evaluate_tags(only_tags, skip_tags, {}) == assert_value


# Generated at 2022-06-21 01:26:48.085362
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert ta.tags == []
    assert ta._tags == []

# Generated at 2022-06-21 01:26:59.647082
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

   # import the class
   from ansible.playbook.base import Taggable

    # create an object
   tag = Taggable()
   tags = ["foo", "bar", "baz"]
   tag.tags = tags

   res = tag.evaluate_tags([], [], {})
   assert res

   res = tag.evaluate_tags(["foo"], [], {})
   assert res

   res = tag.evaluate_tags(["foo", "bar", "baz"], [], {})
   assert res

   res = tag.evaluate_tags(["foo", "bar"], [], {})
   assert res

   res = tag.evaluate_tags(["bar"], [], {})
   assert res

   res = tag.evaluate_tags(["bar", "foo"], [], {})
   assert res

   res = tag.evaluate_

# Generated at 2022-06-21 01:27:00.900239
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == list



# Generated at 2022-06-21 01:27:10.064729
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role.task_include import TaskInclude

    def FakeVarsModule(vars):
        class FakeModule:
            def __init__(self):
                self.vars = vars
        return FakeModule()

    # Test the default case (empty only_tags and skip_tags)
    task0 = TaskInclude()
    assert task0.evaluate_tags(only_tags=[], skip_tags=[], all_vars=FakeVarsModule({})) == True

    # Test the case when only_tags is set with a tag of current task
    only_tags = ['always', 'foo']
    task1 = TaskInclude()
    task1._role = FakeVarsModule( {} )
    task1._role.tags = ['foo']

# Generated at 2022-06-21 01:27:14.336629
# Unit test for constructor of class Taggable
def test_Taggable():
    test_class = Taggable(tags='test, tag')
    # getattr() is used as a helper function to return a value of specified attribute or property of an object
    assert getattr(test_class, 'tags') == ['test', 'tag']
    assert isinstance(test_class._tags, list)

# Generated at 2022-06-21 01:27:31.128036
# Unit test for constructor of class Taggable
def test_Taggable():
    # Create object Taggable
    taggable_obj = Taggable()

    attribute_list = taggable_obj.attribute_class_names

    # Test of constructor. Taggable object has '_tags' attribute
    assert attribute_list == ['_tags']

# Generated at 2022-06-21 01:27:31.681917
# Unit test for constructor of class Taggable
def test_Taggable():
    assert(True)

# Generated at 2022-06-21 01:27:35.814173
# Unit test for constructor of class Taggable
def test_Taggable():
    t1 = Taggable()
    assert t1._tags == []

    t2 = Taggable(tags=['tag1', 'tag2'])
    assert t2._tags == ['tag1', 'tag2']

# Generated at 2022-06-21 01:27:47.059808
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import PlaybookInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from collections import namedtuple

    class DataLoader():
        def get_basedir(self, path):
            return path

    class Host():
        def __init__(self, name):
            self.name = name
            self.vars = dict()
            self.groups = list()

    class Task():
        def __init__(self, tags=None, skip_tags=None, name=None):
            self._parent = PlaybookInclude()
            self._play_context = PlayContext()
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._token = "token"
            self

# Generated at 2022-06-21 01:27:55.716859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import PlayBase
    PlayBase._inheritance_order = lambda self: []
    pb = PlayBase()
    print("Taggable: running unit test for method evaluate_tags...")
    assert(pb.evaluate_tags(set([]), set([]), {}))
    assert(pb.evaluate_tags(set('never'), set([]), {}))
    assert(pb.evaluate_tags(set(['all']), set([]), {}))
    assert(pb.evaluate_tags(set(), set(['never']), {}))
    assert(not pb.evaluate_tags(set(), set(['always']), {}))
    assert(pb.evaluate_tags(set(), set(['always', 'never']), {}))

# Generated at 2022-06-21 01:28:05.276212
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    task = Task()
    task.tags = ['tag1', 'tag2']

    assert task.evaluate_tags(['tag1'], [], HostVars(None, VariableManager))
    assert task.evaluate_tags(['tag2'], [], HostVars(None, VariableManager))
    assert not task.evaluate_tags(['tag3'], [], HostVars(None, VariableManager))

    assert task.evaluate_tags([], ['tag1'], HostVars(None, VariableManager))

# Generated at 2022-06-21 01:28:15.920678
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest

    # Load the module to test
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars import VariableManager

    class TestTaggableRun(unittest.TestCase):

        def setUp(self):
            self.playbook = Playbook()
            self.playbook._load_playbook_data = lambda *x: (None, None)
            self.playbook.vars_prompt = []

# Generated at 2022-06-21 01:28:23.353995
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Mock class
    class MockTaggable(Taggable):
        pass

    # Create an instance of MockTaggable
    mt = MockTaggable()

    # Set default values
    mt.tags = []
    only_tags = []
    skip_tags = []
    all_vars = []

    # Testing with no tags set
    ret = mt.evaluate_tags(only_tags, skip_tags, all_vars)
    assert ret == True

    # Set only_tags to ['all']
    only_tags = ['all']

    # Testing with no tags set
    ret = mt.evaluate_tags(only_tags, skip_tags, all_vars)
    assert ret == False

    # Set tags to ['all']
    mt.tags = ['all']

    # Testing with tags set to ['all']
   

# Generated at 2022-06-21 01:28:34.974248
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.all_vars as all_vars
    import ansible.playbook.base as base
    import ansible.playbook.task as task
    import ansible.playbook.play_context as play_context
    import ansible.template as template

    class MyTaggable(Taggable, base.Base):
        def __init__(self, play, ds):
            super(MyTaggable, self).__init__(play, ds)
            self._attributes['tags'] = self.tags

    class MyTask(task.Task, MyTaggable):
        def __init__(self, play, ds):
            super(MyTask, self).__init__(play, ds)
            self._attributes['tags'] = self.tags


# Generated at 2022-06-21 01:28:45.810680
# Unit test for constructor of class Taggable
def test_Taggable():
    tbl = Taggable()
    assert tbl.tags == []
    assert tbl.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={}) == False
    assert tbl.evaluate_tags(only_tags=['test'], skip_tags=['test'], all_vars={}) == False
    assert tbl.evaluate_tags(only_tags=[], skip_tags=['test'], all_vars={}) == True
    assert tbl.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={}) == False
    assert tbl.evaluate_tags(only_tags=['test'], skip_tags=['test'], all_vars={}) == False

# Generated at 2022-06-21 01:29:24.432270
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # all
    assert Taggable().evaluate_tags(
        ["all"],
        [],
        dict()
    )
    assert not Taggable().evaluate_tags(
        [],
        ["all"],
        dict()
    )

    # all + only_tags
    assert Taggable().evaluate_tags(
        ["all", "foo"],
        [],
        dict()
    )
    assert not Taggable().evaluate_tags(
        ["all", "foo"],
        ["bar"],
        dict()
    )
    assert Taggable().evaluate_tags(
        ["foo", "all"],
        [],
        dict()
    )
    assert not Taggable().evaluate_tags(
        ["foo", "all"],
        ["bar"],
        dict()
    )

    # tagged
    assert Tagg

# Generated at 2022-06-21 01:29:34.319615
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def __init__(self):
            self.tags = None
        def __call__(self):
            print("tags: %s" % str(self.tags))

    m = MyTaggable()
    m.tags = ["foo", "bar", "foobar", "always"]
    assert m.evaluate_tags(["all"], []) is True
    assert m.evaluate_tags(["all"], ["never"]) is True
    assert m.evaluate_tags(["all"], ["always"]) is True
    assert m.evaluate_tags([], ["all"]) is False
    assert m.evaluate_tags(["foobar", "bar"], []) is True
   

# Generated at 2022-06-21 01:29:43.270672
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # pylint: disable=E1002
    from ansible.playbook.play import Play
    import ansible.playbook.task as task
    class MyTask(task.Task):
        pass
    play = Play.load({'name': 'Test', 'hosts': 'all',}, variable_manager=None, loader=None)
    t = MyTask(play=play, ds=dict(name='task1', tags=['one', 'two', 'three']))
    assert t.evaluate_tags(only_tags=['two'], skip_tags=None, all_vars=dict(vars=dict())) is True
    t = MyTask(play=play, ds=dict(name='task2', tags=['one', 'two', 'three']))

# Generated at 2022-06-21 01:29:48.589927
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = None
    only_tags = None
    skip_tags = None
    Taggable_obj = Taggable(loader=loader)
    Taggable_obj.tags = None
    # 1. Default values
    assert Taggable_obj.evaluate_tags(only_tags, skip_tags, None) == True

    # 2. Check for the tags that we need to skip
    only_tags = set(['test_only_tags'])
    skip_tags = set(['test_skip_tags'])
    assert Taggable_obj.evaluate_tags(only_tags, skip_tags, None) == False

    # 3. Check for tags that we need to run
    Taggable_obj.tags = ['test_only_tags']

# Generated at 2022-06-21 01:29:55.633078
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task, TaskInclude
    from ansible.playbook.task_include import TaskInclude

    task = Task()
    task.tags = ['test_tag']

    assert task.evaluate_tags(['test_tag'], [], {}) == True
    assert task.evaluate_tags(['test_tag'], ['skip_tag'], {}) == True
    assert task.evaluate_tags([], ['skip_tag'], {}) == True

    assert task.evaluate_tags([], ['test_tag'], {}) == False
    assert task.evaluate_tags(['skip_tag'], ['test_tag'], {}) == False

    assert task.evaluate_tags(['test_tag'], ['test_tag'], {}) == False

# Generated at 2022-06-21 01:29:57.333656
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags('_tags', 'tag1,tag2') == ['tag1', 'tag2']
    assert Taggable()._load_tags('_tags', ['tag1', 'tag2']) == ['tag1', 'tag2']

# Generated at 2022-06-21 01:30:04.983856
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4

    # Create a mock Taggable object
    class _Taggable(Taggable):
        def __init__(self, ds):
            self._loader = None
            self.tags = self._load_tags('tags', ds['tags'])
            self._ds = ds

    # Test cases:

# Generated at 2022-06-21 01:30:10.121559
# Unit test for constructor of class Taggable
def test_Taggable():
    loader = None
    class TaggableWrapper(Taggable):
        def __init__(self, t):
            self._tags = t
            self._loader = loader
    tags = {'t1', 't2'}
    tw = TaggableWrapper(tags)
    assert tw.tags == tags

# Generated at 2022-06-21 01:30:20.117954
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play = Play(
        name='myplay',
    )
    task1 = Task(
        name='mytask',
        tags=['a', 'b'],
    )
    play.add_task(task1)
    block = Block(
        name='myblock',
        tags=['a', 'b', 'c'],
    )
    play.add_block(block)
    task2 = Task(
        name='mytask2',
        tags=['b', 'c'],
    )
    block.add_task(task2)
    task3 = Task(
        name='mytask3',
        tags=['a', 'd'],
    )
   

# Generated at 2022-06-21 01:30:28.004012
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    only_tags = set(["tag1", "tag2"])
    skip_tags = set(["tag3", "tag4"])
    all_vars = {}

    # Taggable object with no tags
    obj1 = Taggable()
    obj1._tags = []
    assert obj1.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Taggable object with one tag
    obj2 = Taggable()
    obj2._tags = ["tag1"]
    assert obj2.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Taggable object with two same tags
    obj3 = Taggable()
    obj3._tags = ["tag1", "tag1"]

# Generated at 2022-06-21 01:31:28.246613
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()

    assert isinstance(a._tags, list)
    assert a._tags == []

# Generated at 2022-06-21 01:31:30.259582
# Unit test for constructor of class Taggable
def test_Taggable():
   class MyClass(Taggable):
      pass

   t = MyClass()
   assert t._tags == []

# Generated at 2022-06-21 01:31:39.011052
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass

    mock_Taggable = MockTaggable()
    print(mock_Taggable.evaluate_tags(only_tags=['a', 'never', 'always'], skip_tags=['b', 'always', 'always'], all_vars={}))

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-21 01:31:51.030503
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    pb = Play().load({
        u'hosts': u'all',
        u'tasks': [
            {u'name': u'foo', u'tags': [u'always']},
            {u'name': u'bar', u'tags': [u'never']},
            {u'name': u'baz'},
            {u'name': u'qux', u'tags': [u'foo', u'bar', u'baz']},
        ]
    }, loader=None)
    pc = PlayContext()
    pc.only_tags = set([u'always'])
    t = Task.load(pb.tasks()[0])
   

# Generated at 2022-06-21 01:32:02.877023
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    options = '--tags="tag" --skip-tags="skip"'
    (only_tags, skip_tags) = Task.split_tags(options)

    temp = Task()

    temp._variable_manager = variable_manager
    temp._loader = loader
    temp.task_include = 'include_name'

    temp.tags.append('tag')

# Generated at 2022-06-21 01:32:14.439522
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest.mock as mock

    module = mock.Mock(tags=[])
    module.tags = module._load_tags

    # setup the module's tags
    module.tags = [
        'patching',
        'ubuntu',
        'debian'
    ]

    # test all tags
    module.tags = ['patching', 'ubuntu', 'debian']
    module.evaluate_tags(['patching'], [], {}) == True
    module.evaluate_tags(['patching', 'ubuntu', 'debian'], [], {}) == True
    module.evaluate_tags(['patching', 'ubuntu', 'debian', 'all'], [], {}) == True

    # test 'all' and 'tagged' tags
    module.tags = ['patching', 'ubuntu', 'debian', 'all']
    module.evaluate_

# Generated at 2022-06-21 01:32:22.238174
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from units.mock.loader import DictDataLoader

    test_host = Host(name="test_host", port=22)

    only_tags = set(['test'])
    skip_tags = set(['test'])

    # test with only_tags and then with skip_tags
    for tags_arg in [only_tags, skip_tags]:

        # test with an empty list of tags in the task
        test_task = Taggable()
        test_task.tags = []
        assert not test_task.evaluate_tags(tags_arg, [], {})

        # test with a list of tags in the task, including 'always'
        test_task = Taggable()
        test_task.tags = ['always']

# Generated at 2022-06-21 01:32:32.522824
# Unit test for constructor of class Taggable
def test_Taggable():
  import ansible.playbook.base
  import ansible.inventory.manager
  import ansible.vars.manager
  import ansible.parsing.dataloader
  import ansible.inventory.host
  import ansible.inventory.group
  import ansible.constants as C

  fake_loader = ansible.parsing.dataloader.DataLoader()
  fake_inventory = ansible.inventory.manager.InventoryManager(loader=fake_loader, sources=C.DEFAULT_HOST_LIST)
  fake_playbook = ansible.playbook.base.BasePlaybook(loader=fake_loader, inventory=fake_inventory)
  fake_variables = ansible.vars.manager.VariableManager(loader=fake_loader, inventory=fake_inventory)

  fake_host = ansible.inventory.host

# Generated at 2022-06-21 01:32:42.905771
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test that tags specified with only_tags or skip_tags are evaluated correctly
    with method Taggable.evaluate_tags()
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.include_task import IncludeTask
    from ansible.vars.manager import VariableManager

    task = Task()
    role = Role()
    block = Block()
    include_role = IncludeRole()
    include_task = IncludeTask()
    # Create a mock object for testing
    class objectForTesting:
        _role = role
        _block = block

    ### TESTING Task
    # Expected result: True (run)
    task

# Generated at 2022-06-21 01:32:49.702398
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Test method constructor of Taggable class.
    """
    taggable = Taggable()
    assert taggable is not None
    assert taggable.tags == []
    assert Taggable.untagged is not None
    assert Taggable.untagged == frozenset(['untagged'])
