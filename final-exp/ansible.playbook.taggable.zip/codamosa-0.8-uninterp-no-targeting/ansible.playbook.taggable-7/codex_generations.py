

# Generated at 2022-06-21 01:24:39.320386
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test evaluate_tags method of Taggable.
    """

    # test data

# Generated at 2022-06-21 01:24:52.042542
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_instance = Taggable()
    test_instance.tags = []

    print("Test 1")
    result = test_instance.evaluate_tags(only_tags=[], skip_tags=[], all_vars=dict())
    assert result == True

    print("Test 2")
    result = test_instance.evaluate_tags(only_tags=['a', 'b'], skip_tags=[], all_vars=dict())
    assert result == False

    print("Test 3")
    result = test_instance.evaluate_tags(only_tags=['a', 'b'], skip_tags=['y', 'z'], all_vars=dict())
    assert result == False

    print("Test 4")

# Generated at 2022-06-21 01:25:01.000895
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Following is the list of (input,output) pairs, to be tested.'''

# Generated at 2022-06-21 01:25:02.765808
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable=Taggable()
    assert taggable.tags == []

# Generated at 2022-06-21 01:25:15.015529
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Basic unit test for method evaluate_tags of class Taggable.
    """
    class Tagged(Taggable):

        def __init__(self, tags=None):
            self.tags = tags


# Generated at 2022-06-21 01:25:16.759730
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    assert x._tags == []

# Generated at 2022-06-21 01:25:25.309502
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.block import Block

    pb = Play().load({})
    c = Conditional()
    b = Block()

    # ### case: no tags specified:
    assert c.evaluate_tags(['tag1'], [], {}) == False
    assert c.evaluate_tags(['tag1'], ['tag1'], {}) == False
    assert c.evaluate_tags([], ['tag1'], {}) == True
    assert c.evaluate_tags([], [], {}) == True

    # ### case: tags specified on the tasks
    c = Conditional(tags=['tag1', 'tag2'])
    b = Block(task_include='task.yml', tags=['tag1'])

   

# Generated at 2022-06-21 01:25:30.593284
# Unit test for constructor of class Taggable
def test_Taggable():
    # I want to make sure that only_tags and skip_tags are being properly
    # assigned to the Taggable object.
    taggable = Taggable()
    assert taggable.only_tags is not None
    assert taggable.skip_tags is not None
    assert taggable.free_form is None



# Generated at 2022-06-21 01:25:32.709300
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()
    assert Taggable().tags == []

# Generated at 2022-06-21 01:25:34.834133
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

# Generated at 2022-06-21 01:25:50.712126
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import Include
    my_taggable = Taggable()
    include = Include()
    marshall_attr = 'tags'
    include._load_tags(marshall_attr, 'tag1,tag2')
    assert include._tags == ['tag1', 'tag2']
    include._load_tags(marshall_attr, ['tag1', 'tag2'])
    assert include._tags == ['tag1', 'tag2']
    try:
        include._load_tags(marshall_attr, False)
    except AnsibleError as error:
        assert error.message == 'tags must be specified as a list'
    include._tags = ['tag1', 'tag2']
    assert set(include.tags) == set(['tag1', 'tag2'])

# Generated at 2022-06-21 01:25:55.761050
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable.evaluate_tags(None, None, None) == True

    # untagged task, only_tags=[]: should_run=True
    assert Taggable._load_tags(None, None) == []
    assert Taggable.evaluate_tags(['some_tag'], None, None) == True

    # tagged task, only_tags=[], skip_tags=[]: should_run=True
    Taggable._tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    Taggable.tags = []
    assert Taggable._load_tags(None, 'foo') == ['foo']
    assert Taggable.evaluate_tags([], None, None) == True

    # untagged task, only_tags=[tagged], skip_tags=[]: should_run=False

# Generated at 2022-06-21 01:26:00.999732
# Unit test for constructor of class Taggable
def test_Taggable():
    import sys
    class TaggableTest(Taggable):
        pass

    tag = TaggableTest()
    assert tag.tags == []

    try:
        tag._load_tags('tags', 'tag1,tag2')
    except:
        _, value, _ = sys.exc_info()
        pytest.fail("Unexpected AnsibleError({0!r}): raised".format(value))

# Generated at 2022-06-21 01:26:02.297020
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass



# Generated at 2022-06-21 01:26:07.155577
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    p = Play()
    p._ds = dict(tags = [1,2,3])
    p._play_context = PlayContext()
    assert p.tags == [1,2,3]


# Generated at 2022-06-21 01:26:18.797152
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Tags are always executed
    should_run = True
    only_tags = ['all']
    skip_tags = []
    tags = ['always']
    assert Taggable().evaluate_tags(only_tags, skip_tags, tags) == should_run

    # Tags are executed if all is in only_tags or if the tag is in only_tags
    should_run = True
    only_tags = ['all', 'tag']
    skip_tags = []
    tags = ['tag']
    assert Taggable().evaluate_tags(only_tags, skip_tags, tags) == should_run
    should_run = True
    only_tags = ['tag']
    skip_tags = []
    tags = ['tag']
    assert Taggable().evaluate_tags(only_tags, skip_tags, tags) == should_run

    #

# Generated at 2022-06-21 01:26:28.378553
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize a Taggable object
    class TestableTaggable(Taggable):
        pass
    testable_taggable = TestableTaggable()

    # Test only_tags and skip_tags with empty values
    result = testable_taggable.evaluate_tags([], [], {})
    assert result == True

    # Test only_tags with values and skip_tags with empty values
    result = testable_taggable.evaluate_tags(["tag1"], [], {})
    assert result == False

    # Test only_tags and skip_tags with one set of values
    testable_taggable.tags = ["tag1", "tag2"]
    result = testable_taggable.evaluate_tags(["tag2"], ["tag1"], {})
    assert result == True

    # Test only_tags and

# Generated at 2022-06-21 01:26:40.714441
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:26:53.483450
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude

    # Test when tags are present
    task1 = TaskInclude()
    task1._load_name('test')
    task1._load_tags('not_in, in')

    task2 = TaskInclude()
    task2._load_name('test')
    task2._load_tags('in, always')

    task3 = RoleInclude()
    task3._load_name('test')
    task3._load_tags('not_in, in')

    task4 = RoleInclude()
    task4._load_name('test')
    task4._load_tags('in, always')

    # Test with no tags specified
    task5 = TaskInclude()
    task5._load_

# Generated at 2022-06-21 01:26:58.880510
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    This is a unit test that tests the constructor of class Taggable.
    '''

    taggable_instance = Taggable()
    assert all(tag in taggable_instance._tags for tag in taggable_instance._load_tags(None, 'tag1, tag2, tag3'))


# Generated at 2022-06-21 01:27:13.597085
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    # should_run with only_tags
    data = dict(tags=['only_tag'])
    obj = TaskInclude.load(data=data)
    obj._templar = Templar(loader=None)
    only_tags = set(['only_tag'])
    skip_tags = set()
    result = obj.evaluate_tags(only_tags, skip_tags, dict())
    assert result == True

    data = dict(tags=['not_only_tag'])
    obj = TaskInclude.load(data=data)
    obj._templar = Templar(loader=None)

# Generated at 2022-06-21 01:27:15.983708
# Unit test for constructor of class Taggable
def test_Taggable():
    instance = Taggable()
    instance._tags = ['untagged']
    assert instance._tags == ['untagged']


# Generated at 2022-06-21 01:27:20.525235
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self._tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    test_obj = TestTaggable()
    assert test_obj.tags == []

# Generated at 2022-06-21 01:27:30.604266
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    assert Taggable._load_tags(None, 'foo, bar').sort() == ['bar', 'foo'].sort()
    assert Taggable._load_tags(None, ['foo', 'bar']).sort() == ['bar', 'foo'].sort()

    taggable._tags = ['foo', 'bar']
    print(taggable.tags)

    assert taggable.evaluate_tags(['foo'], None, None)
    assert not taggable.evaluate_tags(['bar'], None, None)

    assert taggable.evaluate_tags(['foo', 'bar', 'nothing'], None, None)
    assert not taggable.evaluate_tags(['baz', 'party'], None, None)


# Generated at 2022-06-21 01:27:31.385268
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()


# Generated at 2022-06-21 01:27:38.561696
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert(ta.tags == [])
    ta = Taggable(tags='t1, t2, t3')
    assert(ta.tags == ['t1', 't2', 't3'])
    ta = Taggable(tags=['t1', 't2', 't3'])
    assert(ta.tags == ['t1', 't2', 't3'])


# Generated at 2022-06-21 01:27:48.988393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyClass(Taggable):
        pass
    dummy_class = DummyClass()

    tags = ['never', 'tag']
    dummy_class.tags = tags

    test_cases = [
        # only_tags
        # skip_tags
        # expected result
        (['tag'], [], True),
        (['tag'], ['never'], False),
        (['something_else'], [], False),
        (['something_else'], ['never'], False),
        ([], [], True),
        ([], ['never'], False),
    ]

    for only_tags, skip_tags, result in test_cases:
        assert dummy_class.evaluate_tags(only_tags, skip_tags, None) == result

# Generated at 2022-06-21 01:27:51.761516
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.base import Base

    class MyTaggable(Base, Taggable):
        pass

    t = MyTaggable()

    assert t.tags == []
    assert list(t.untagged) == ['untagged']

# Generated at 2022-06-21 01:27:59.270321
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # create a blank block
    blk = Block()
    my_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=my_vars)

    # Instantiate Taggable class
    test_tags = Taggable()
    test_tags.tags = ['WebServer']
    assert test_tags.tags == ['WebServer'], 'Tags set incorrectly'

# Generated at 2022-06-21 01:28:13.077759
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    task_include = TaskInclude()
    task_include._load_name('tasks')

    # Test when task does not have tags at all, neither does the play
    # Default behavior is to run task
    # only_tags is not set, so this should always run
    assert task_include.evaluate_tags(only_tags=None, skip_tags=None, all_vars=dict())

    # Test when task does not have tags, but play has skip_tags
    # No tags in a task will cause the task to be skipped
    assert not task_include.evaluate_tags(only_tags=None, skip_tags=['all'], all_vars=dict())

    # Test when task does not have tags, but play has only_tags
    # No tags in a task

# Generated at 2022-06-21 01:28:31.665618
# Unit test for constructor of class Taggable
def test_Taggable():
    d = {}
    o = Taggable()
    o.tags = ['untagged', 'always']
    o.evaluate_tags(None, ['always'], d)

# Generated at 2022-06-21 01:28:43.939520
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    assert t._tags.default == list
    assert t._tags.isa == 'list'

    #
    # _load_tags
    #
    x = t._load_tags('foo', [1,2,3])
    assert x == [1,2,3]

    x = t._load_tags('foo', "1, 2, 3")
    assert x == ['1', '2', '3']

    try:
        x = t._load_tags('foo', 12)
    except AnsibleError:
        pass

    #
    # evaluate_tags
    #
    assert t.evaluate_tags([], [], {}) == True

    # only_tags
    assert t.evaluate_tags(['all'], [], {}) == True

# Generated at 2022-06-21 01:28:54.996023
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
       This method tests the Taggable.evaluate_tags method.
    """
    obj = Taggable()
    allvars = {}
    # No tags defined, check always
    obj.tags = None
    should_run = obj.evaluate_tags(['always'], None, allvars)
    assert should_run

    # Tags defined, check always
    obj.tags = ['foo', 'bar', 'baz']
    should_run = obj.evaluate_tags(['always'], None, allvars)
    assert should_run

    # No tags defined, check all
    obj.tags = None
    should_run = obj.evaluate_tags(['all'], None, allvars)
    assert should_run

    # Tags defined, check all
    obj.tags = ['foo', 'bar', 'baz']

# Generated at 2022-06-21 01:29:04.574947
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test for an empty set of tags. Do the tags indicate we should run?
    t = Taggable()
    t.tags = []
    only_tags = []
    skip_tags = []
    all_vars = {}
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result
    # test for an explicit set of tags. Do the tags indicate we should run?
    t = Taggable()
    t.tags = ['a', 'b', 'c', 'd']
    only_tags = ['a', 'b', 'c', 'd']
    skip_tags = []
    all_vars = {}
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result
    # test for an explicit set of tags. Do

# Generated at 2022-06-21 01:29:15.027358
# Unit test for constructor of class Taggable
def test_Taggable():
    print("Testing constructor of Taggable")
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude(task=dict())
    print('task_include.tags: ' + str(task_include.tags))
    task_include.tags = ['a', 'b']
    print('task_include.tags: ' + str(task_include.tags))
    tags = task_include._load_tags('_tags', {'a': 'a', 'b': 'b'})
    print(tags)
    tags = task_include._load_tags('_tags', 12)
    print(tags)

# Generated at 2022-06-21 01:29:25.274648
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    block = Block()

    tags = set()
    tags.add('tag1')
    tags.add('tag2')

    only_tags = set()
    only_tags.add('tag1')
    only_tags.add('tag2')
    only_tags.add('tag3')

    skip_tags = set()
    skip_tags.add('tag1')

    res = block.evaluate_tags(only_tags, skip_tags, None)
    assert res == True, 'Block with no vars and only_tags and skip_tags specified not executed'

    block.tags = ['tag1']
    res = block.evaluate_tags(only_tags, skip_tags, None)

# Generated at 2022-06-21 01:29:35.093572
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ansible.template import Templar
    from ansible.module_utils import basic
    from ansible.playbook import PlayBook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    basic._ANSIBLE_ARGS = None

    module_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'lib', 'ansible', 'modules')

    _playbook_dir = os.path.join(os.path.dirname(__file__), 'playbooks')

    inventory = os.path.join(module_dir, 'inventory')

    fd, test

# Generated at 2022-06-21 01:29:43.339873
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test specific variables
    my_all_vars = {"vault_password":"mypassword", "my_tag":"tagged"}
    # Test derived variables

    # Test specific settings
    my_only_tags = ["tagged"]
    my_skip_tags = []
    my_tags = ["my_tag"]
    my_should_run = True

    # Test specific checks
    my_taggable = Taggable()
    my_taggable.tags = my_tags
    my_should_run_test = my_taggable.evaluate_tags(my_only_tags, 
                                                   my_skip_tags,
                                                   my_all_vars)
    assert my_should_run_test == my_should_run

    return True


# Generated at 2022-06-21 01:29:48.625697
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    class PlayImplementation(Play, Taggable):
        pass
    fake_loader = DataLoader()
    fake_play = PlayImplementation(loader=fake_loader, variable_manager={}, host_list='localhost')
    # if no tags are specified
    only_tags=['tag1', 'tag2']
    skip_tags=[]
    all_vars=dict()
    assert fake_play.evaluate_tags(only_tags, skip_tags, all_vars)
    # if the task is tagged
    fake_play._tags=['tag1']
    assert fake_play.evaluate_tags(only_tags, skip_tags, all_vars)
    # if the task is not tagged

# Generated at 2022-06-21 01:29:55.648452
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task

    test_tags = ['foo', 'bar']

    # Case 1: Only tags given

    test_only_tags = ['all']

    test_task1 = Task()
    test_task1._task_fields['tags'] = test_tags

    assert test_task1.evaluate_tags(test_only_tags, [], {})

    test_task2 = Task()
    test_task2._task_fields['tags'] = ['something_else']

    assert not test_task2.evaluate_tags(test_only_tags, [], {})

    test_only_tags = ['tagged']

    test_task3 = Task()
    test_task3._task_fields['tags'] = test_tags


# Generated at 2022-06-21 01:30:35.379024
# Unit test for constructor of class Taggable
def test_Taggable():
    import os
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_object
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    # create a task object
    t = TaskInclude()
    t._load_name("test_task")
    t._load_tags("new_tag")

    # create a handler object
    h = Handler()
    h._load_name("test_handler")

    # create a play object
    yaml_data = dict(
        name="foobar play",
        hosts=[ 'test.org' ],
        tasks=[
            t
        ],
        handlers=[
            h
        ]
    )


# Generated at 2022-06-21 01:30:45.327300
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys
    import os
    sys.path.append('../..')
    from ansible.executor.task_result import TaskResult
    #import ansible.executor.task_result

    #def __init__(self, host, task, return_data, task_fields=None,):

# Generated at 2022-06-21 01:30:57.223885
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    # task's only_tags parameter has value "untagged, always, never" and
    # task's skip_tags parameter has value "tagged, maybesomtimes"
    # play's only_tags parameter has value "skipped, task1" and
    # play's skip_tags parameter has value "skipped2, task2"
    tags_list = []

# Generated at 2022-06-21 01:31:04.807934
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.assemble import Assemble
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-21 01:31:11.228557
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test case for function evaluate_tags.
    '''
    obj_instance = Taggable()
    obj_instance.tags = ['test_tag']

    # Test case to evaluate tags
    only_tags = ['test_tag']
    skip_tags = []
    all_vars = []
    should_run = obj_instance.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # Test case to evaluate tags failed
    only_tags = ['test_tag']
    skip_tags = ['failed_tag']
    all_vars = []
    should_run = obj_instance.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # Test case to test evaluate tags with empty tags
    only_

# Generated at 2022-06-21 01:31:22.802102
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import Include
    from ansible.playbook.task import Task

    t = Taggable()
    assert isinstance(t._tags, FieldAttribute)
    assert t._tags.isa == 'list'
    assert t._tags.default == list
    assert t._tags.extend is True
    assert isinstance(t._tags.listof, tuple)
    assert t._tags.listof[0] == string_types
    assert t._tags.listof[1] == int

    r = Include()
    r.tags = u'a, b, c'
    assert r._load_tags(u'tags', u'a, b, c') == [u'a', u'b', u'c']

    t = Task()

# Generated at 2022-06-21 01:31:31.875377
# Unit test for constructor of class Taggable
def test_Taggable():
    # test for constructor of Taggable class
    print("Constructor for class Taggable")
    test_attr = None
    test_ds = "tag1, tag2"
    test_class_object = Taggable()
    test_class_object._tags = test_class_object._load_tags(test_attr, test_ds)
    if test_class_object._tags == ['tag1', 'tag2']:
        print("Success")
    else:
        print("Failed")

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:31:43.556936
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class book(Taggable):
        pass

    playbook = book()
    all_vars = VariableManager()
    playbook._loader = DataLoader()
    playbook.tags = ['tag1']
    assert playbook.evaluate_tags(None, ['tag1'], all_vars) == False
    assert playbook.evaluate_tags(['tag1'], None, all_vars) == True
    assert playbook.evaluate_tags(['tag2'], None, all_vars) == False
    assert playbook.evaluate_tags(None, ['tag2'], all_vars) == True
    assert playbook.evaluate_tags(['tag1','tag2'], None, all_vars) == True

# Generated at 2022-06-21 01:31:51.700313
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert(True == Taggable().evaluate_tags(set(), set(), dict()))
    assert(True == Taggable().evaluate_tags(set(['all']), set(['never']), dict()))
    assert(False == Taggable().evaluate_tags(set(['all']), set(['always']), dict()))
    assert(False == Taggable().evaluate_tags(set(['all', 'always']), set(['always']), dict()))
    assert(True == Taggable().evaluate_tags(set(['all', 'always']), set(['never']), dict()))

# Generated at 2022-06-21 01:32:03.172653
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self, **kwargs):
            self._tags = kwargs.get('tags')
            self.tags = []

            if self._tags:
                if isinstance(self._tags, string_types):
                    self.tags = self._tags.split(',')
                elif isinstance(self._tags, list):
                    self.tags = self._tags
                for i in range(len(self.tags)):
                    self.tags[i] = self.tags[i].strip()

    # If no tags are specified in play, skip_tags or only_tags
    # None of the plays and tasks should be skipped
    assert TestClass(tags=['tag1', 'tag2']).evaluate_tags(None, None, None) == True

    # If no tags are specified in

# Generated at 2022-06-21 01:33:11.479521
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    >>> test_Taggable()
    True
    '''
    taggable = Taggable()
    taggable._tags = ['test']
    return True if taggable.tags  else False

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 01:33:14.154793
# Unit test for constructor of class Taggable
def test_Taggable():
   test_taggable = Taggable()
   assert (test_taggable._tags == [])

# Generated at 2022-06-21 01:33:17.774133
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    # test default value of _tags is empty list, empty list is false
    assert not taggable._tags

# Generated at 2022-06-21 01:33:20.426047
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    assert t.tags == []
    assert t.tags == t._tags

# Generated at 2022-06-21 01:33:31.773905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Tagged(Taggable):
        pass

    #Test 1
    tagged = Tagged()
    tagged.tags = []
    assert tagged.evaluate_tags([], [], {}) == True

    #Test 2
    tagged = Tagged()
    tagged.tags = []
    assert tagged.evaluate_tags([], ['all'], {}) == True

    #Test 3
    tagged = Tagged()
    tagged.tags = ['always']
    assert tagged.evaluate_tags([], ['all'], {}) == True

    #Test 4
    tagged = Tagged()
    tagged.tags = ['all']
    assert tagged.evaluate_tags([], ['all'], {}) == True

    #Test 5
    tagged = Tagged()
    tagged.tags = []

# Generated at 2022-06-21 01:33:41.702703
# Unit test for constructor of class Taggable
def test_Taggable():
  # Constructor of Taggable
  a = Taggable()
  # Unittest of _tags field
  assert a._tags == list()
  # Unittest of function untagged
  assert a.untagged == frozenset(['untagged'])
  # Unittest of function _load_tags
  assert (a._load_tags('attr', ['a', 'b', 'c']) == ['a', 'b', 'c'])
  # Unittest of function evaluate_tags
  assert (a.evaluate_tags(['tagged'], [], {'a': 'b'}) == True)

# Generated at 2022-06-21 01:33:53.429783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.template
    import six
    if six.PY2:
        import __builtin__ as builtins
    else:
        import builtins

    play_context = ansible.playbook.PlayContext()

    # Evaluate tags on a task
    task = ansible.playbook.task.Task()
    task.tags = ["test1", "test2"]
    # Evaluate tags with only-tags
    play_context.only_tags = None
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, {}) == True
    play_context.only_tags = []
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, {}) == True

# Generated at 2022-06-21 01:33:58.272654
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test Taggable Task
    task = Task()
    task.tags = ['t1', 't2', 't3']
    tag = task.tags
    assert (tag == ['t1', 't2', 't3'])

    # Test Taggable Block
    block = Block()
    block.tags = ['t1', 't2', 't3']
    tag = block.tags
    assert (tag == ['t1', 't2', 't3'])

    # Test Taggable Role
    role = Role()

# Generated at 2022-06-21 01:34:02.796990
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    Verify that a new Taggable object is instantiated correctly
    '''

    taggable = Taggable()

    assert isinstance(taggable, Taggable)
    assert taggable._tags == []


# Generated at 2022-06-21 01:34:11.673135
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    import pytest

    class Test(Base, Taggable):
        def __init__(self, options, roles=None, loader=None):
            super(Test, self).__init__()
            self._loader = loader

    # Evalutae tags with all params as None
    objTest = Test(None, None, None)
    objTest.tags = ''
    assert objTest.evaluate_tags(None, None, None) is True

    # Evalutae tags with only_tags as None and skip_tags as 'all'
    objTest = Test(None, None, None)
    objTest.tags = ['always']
    assert objTest.evaluate_tags(None, ['all'], None) is True

    #