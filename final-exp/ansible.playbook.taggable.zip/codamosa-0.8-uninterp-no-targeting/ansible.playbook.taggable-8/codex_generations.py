

# Generated at 2022-06-21 01:24:34.069660
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude

    # Check if evaluate_tags returns true if no tags are used
    play = Play().load({'name': 'test'})
    assert play.evaluate_tags(None, None, {}) == True
    task = Task().load(dict(name='test'))
    assert task.evaluate_tags(None, None, {}) == True
    role = Role().load({'name': 'test'})
    assert role.evaluate_tags(None, None, {}) == True

# Generated at 2022-06-21 01:24:44.991702
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory


# Generated at 2022-06-21 01:24:47.162951
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert t._tags == []

# Generated at 2022-06-21 01:24:48.355019
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()


# Generated at 2022-06-21 01:24:58.827779
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude

    task = TaskInclude('foo')

    # Test for one element in only_tags, it should be present in tags,
    # to be executed.
    only_tags = ['bar']
    skip_tags = []
    task.tags = ['bar']
    assert task.evaluate_tags(only_tags, skip_tags, {}) == True

    # Test for one element in only_tags, it should be not present in tags,
    # to be NOT executed
    only_tags = ['bar']
    skip_tags = []
    task.tags = ['foo']
    assert task.evaluate_tags(only_tags, skip_tags, {}) == False

    # Test for one element in only_tags, should be executed, as both are present
    only_tags = ['foo']

# Generated at 2022-06-21 01:25:11.511682
# Unit test for constructor of class Taggable
def test_Taggable():
    tag1 = 'tag1'
    tag2 = 'tag2'
    tag3 = 'tag3'
    tags = [tag1, tag2]

    tg = Taggable()
    assert tg._tags is None
    assert tg.tags is None
    assert isinstance(tg.tags, list)
    assert tg.untagged == frozenset(['untagged'])
    assert tg.evaluate_tags(None, None, None) == True

    # initialize with a list
    tg._tags = tags
    assert tg._tags is not None
    assert tg.tags is not None
    assert tg.tags == tags
    assert tg.evaluate_tags(None, None, None) == True

    # initialize with a string
    tg = Taggable()

# Generated at 2022-06-21 01:25:23.481813
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def Taggable_child():
        class __Taggable_child(Taggable):
            pass
        return __Taggable_child

    #
    # Check with tags and tags attribute
    #
    child = Taggable_child()
    child.tags = ['production']
    assert child.evaluate_tags(['production'], [], {})
    assert not child.evaluate_tags(['development'], [], {})
    assert child.evaluate_tags(['development', 'production'], [], {})
    assert child.evaluate_tags(['production', 'development'], [], {})
    assert not child.evaluate_tags([], ['production'], {})
    assert not child.evaluate_tags([], ['development', 'production'], {})

# Generated at 2022-06-21 01:25:34.034138
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    #test basic functionality
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(None, None, {})

    #test not run if no tags
    t.tags = None
    assert not t.evaluate_tags(None, None, {})

    #test only_tags
    t.tags = ['tag1', 'tag2']
    assert not t.evaluate_tags(['only1'], None, {})
    assert t.evaluate_tags(['only1', 'tag1'], None, {})
    assert t.evaluate_tags(['only1', 'tag2'], None, {})
    assert t.evaluate_tags(['tag1'], None, {})
    assert t.evaluate_tags(['tag2'], None, {})

    #test skip

# Generated at 2022-06-21 01:25:38.908657
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    assert test_obj.tags == list()
    assert test_obj.untagged == frozenset(['untagged'])


## Unit test for method _load_tags of class Taggable
# Test case 1:
# Test parameter ds is a list.

# Generated at 2022-06-21 01:25:48.143167
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass
#     task = Task()
#     task.tags = ['always', 'second']
#
#     # skip_tags = ['never']
#     # only_tags = ['always', 'first']
#     # should_run = task.evaluate_tags(only_tags, skip_tags)
#     # print(should_run)
#
#     # skip_tags = []
#     # only_tags = ['always']
#     # should_run = task.evaluate_tags(only_tags, skip_tags)
#     # print(should_run)
#
#     # skip_tags = ['never']
#     # only_tags = []
#     # should_run = task.evaluate_tags(only_tags, skip_tags)
#     # print(should_run)
#
#     # skip_tags =

# Generated at 2022-06-21 01:25:59.004763
# Unit test for constructor of class Taggable
def test_Taggable():
    class Testable(Taggable):
        pass
    t = Testable()
    assert not t.tags
    t = Testable()
    t.tags = ['a','b']
    assert t.tags == ['a','b']



# Generated at 2022-06-21 01:26:07.907989
# Unit test for constructor of class Taggable
def test_Taggable():
    """This is a unit test for the Taggable class in the ansible.playbook.taggable module.
    """
    taggable = Taggable()

    # Assert default values.
    assert 'untagged' in taggable.untagged
    assert taggable.tags == []

    # Assert _load_tags method.
    assert taggable._load_tags(None, []) == []
    assert taggable._load_tags(None, "tag1,tag2") == ['tag1', 'tag2']

    # Assert evaluate_tags method.
    assert taggable.evaluate_tags([], [], {}) == True
    taggable.tags = ['tag1']
    assert taggable.evaluate_tags([], [], {}) == True

# Generated at 2022-06-21 01:26:19.957608
# Unit test for constructor of class Taggable
def test_Taggable():

    assert isinstance(Taggable().tags, list)
    assert Taggable().tags == []

    assert isinstance(Taggable(tags=[]).tags, list)
    assert Taggable(tags=[]).tags == []

    assert isinstance(Taggable(tags='').tags, list)
    assert Taggable(tags='').tags == []

    assert isinstance(Taggable(tags=['foo']).tags, list)
    assert Taggable(tags=['foo']).tags == ['foo']

    assert isinstance(Taggable(tags='foo').tags, list)
    assert Taggable(tags='foo').tags == ['foo']

    assert isinstance(Taggable(tags='foo, bar').tags, list)

# Generated at 2022-06-21 01:26:28.864308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.inventory.host import Host

    def test_case(only_tags, skip_tags, expected_result, tags=None):

        the_host = Host('test_host')

        the_host.tags = tags

        actual_result = the_host.evaluate_tags(only_tags, skip_tags, all_vars={})

        if actual_result != expected_result:
            print("""
test_case({})
with tags {}
failed.
expected: {}
got: {}
""".format(
                (only_tags, skip_tags),
                tags,
                expected_result,
                actual_result))


# Generated at 2022-06-21 01:26:41.137984
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    t = Base()
    o = Taggable()
    o.tags = ['tag_1']
    assert o.evaluate_tags(only_tags=['tag_1'], skip_tags=[], all_vars={})
    assert o.evaluate_tags(only_tags=['tag_1'], skip_tags=['tag_2'], all_vars={})
    assert o.evaluate_tags(only_tags=[], skip_tags=['tag_1'], all_vars={})
    assert not o.evaluate_tags(only_tags=[], skip_tags=['tag_2'], all_vars={})
    assert not o.evaluate_tags(only_tags=['tag_2'], skip_tags=[], all_vars={})

# Generated at 2022-06-21 01:26:53.483627
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test_Taggable_evaluate_tags
        test evaluate_tags function of Taggable class
    '''

    test_object = Taggable()

    # case 1
    # action to execute (only_tags = [] and skip_tags = [])
    test_object.tags = ['tag1', 'tag2']
    only_tags = []
    skip_tags = []
    all_vars = {}
    should_run = test_object.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # case 2
    # action to execute (only_tags = [] and skip_tags = [])
    test_object.tags = ['never', 'tag1', 'tag2']
    only_tags = []
    skip_tags = []

# Generated at 2022-06-21 01:27:04.169961
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestModule(Taggable):
        pass

    class TestModule2(Taggable):
        _tags     = FieldAttribute(isa='list', default=list, listof=(string_types), extend=True)
        test_tags = FieldAttribute(isa='list', default=list, listof=(string_types), extend=True)
        def __init__(self):
            self._tags = []

    t = TestModule()
    t2 = TestModule2()

    t.tags = ['always']

    # The role should run because it has the 'always' tag, which
    # is considered as a tag that should be run
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={}) == True

# Generated at 2022-06-21 01:27:11.977932
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test if method evaluate_tags works with only_tags
    hostvars = {"hostvar": "foo"}
    task = {"tags": ["always"]}
    t = Taggable()
    only_tags = ["all"]
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, hostvars) is True

    only_tags = ["tagged"]
    assert t.evaluate_tags(only_tags, skip_tags, hostvars) is True

    only_tags = ["tagged"]
    task = {"tags": ["foo"]}
    assert t.evaluate_tags(only_tags, skip_tags, hostvars) is True

    only_tags = ["tagged"]

# Generated at 2022-06-21 01:27:15.190315
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)

    assert t.tags == []
    assert t.untagged == frozenset(['untagged'])



# Generated at 2022-06-21 01:27:26.423556
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Creating object of class Play
    pb = Play()

    # Creating object of class Task
    t = Task()

    # Creating object of class Block
    b = Block()

    # Setting the tags property for task 't'
    t.tags = ["test"]

    # Adding task 't' to play 'pb'
    pb.add_task(t)

    # Checking if the tags property is set correctly
    assert t.tags == ['test'], "Tag set incorrectly"

    # Adding task 't' to block 'b'
    b.add_task(t)

    # Setting the tags property of block 'b'
    b.tags = ["test"]

    # Adding the block '

# Generated at 2022-06-21 01:27:50.483903
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test when no tags are specified
    tb = Taggable()
    assert tb.evaluate_tags({}, {})

    # Test when no tag options are specified
    tb = Taggable()
    tb.tags = ['valid_tag']
    assert tb.evaluate_tags({}, {})

    # Test when skip_tags is specified
    tb = Taggable()
    tb.tags = ['valid_tag']
    assert tb.evaluate_tags({}, {'skip_tags': ['valid_tag']}) == False

    # Test when only_tags is specified
    tb = Taggable()
    tb.tags = ['valid_tag']
    assert tb.evaluate_tags({'only_tags': ['invalid_tag']}, {}) == False

    # Test when both are specified
    tb

# Generated at 2022-06-21 01:28:03.165894
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest2 as unittest
    from ansible.module_utils.six import PY3

    class MyTaggable(Taggable):
        __slots__ = ('_data', '_ds', '_task_vars', '_play', '_loader', '_variable_manager', '_block', '_host', 'tags')
        def __init__(self):
            self._task_vars = dict()
        def set_loader(self, loader):
            self._loader = loader
        def set_variable_manager(self, variable_manager):
            self._variable_manager = variable_manager

    class TestTaggable(unittest.TestCase):
        def setUp(self):
            self.taggable = MyTaggable()

# Generated at 2022-06-21 01:28:07.404550
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        pass

    test = TestClass()
    assert test.untagged == frozenset(['untagged'])
    assert test.tags == list()

# Generated at 2022-06-21 01:28:17.007135
# Unit test for constructor of class Taggable
def test_Taggable():
    from .block import Block
    from .task import Task
    from .play import Play
    from .playbook import Playbook

    # set up test objects with tags, and run them through the constructor
    # of Taggable.
    test_playbook = Playbook()
    test_play = Play()
    test_block = Block()
    test_task1 = Task()
    test_task2 = Task()
    test_task3 = Task()
    test_task1.tags = ['tag1', 'tag3', 'tag5']
    test_task2.tags = ['tag1', 'tag2', 'tag4']
    test_task3.tags = ['tag1']
    test_block.block = [test_task1, test_task2, test_task3]
    test_play.block = test_block
    test

# Generated at 2022-06-21 01:28:26.577834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggableClass(Taggable):
        pass

    myTaggableClass = MyTaggableClass()
    myTaggableClass.tags = ['untagged']

    assert myTaggableClass.evaluate_tags(set(), set(), {}) is True
    assert myTaggableClass.evaluate_tags(set(), set(['untagged']), {}) is False
    assert myTaggableClass.evaluate_tags(set(['untagged']), set(), {}) is True
    assert myTaggableClass.evaluate_tags(set(['untagged']), set(['untagged']), {}) is False

    myTaggableClass.tags = ['always']

    assert myTaggableClass.evaluate_tags(set(), set(), {}) is True

# Generated at 2022-06-21 01:28:31.719249
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task._play_context = PlayContext()
    task.tags = ['foo', 'bar']
    assert task.tags == ['foo', 'bar']

    task.tags = ['foo', 1]
    assert task.tags == ['foo', 1]

    task.tags = 'foo,bar'
    assert task.tags == ['foo', 'bar']

    task.tags = 'foo, 1'
    assert task.tags == ['foo', 1]

# Generated at 2022-06-21 01:28:38.710176
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    result = Taggable()
    assert result.evaluate_tags([], None, None) is True
    assert result.evaluate_tags(None, None, None) is True
    assert result.evaluate_tags([], [], None) is True
    assert result.evaluate_tags(None, [], None) is True

# Generated at 2022-06-21 01:28:47.907035
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.module_utils.six import PY3
    from ansible.playbook.attribute import FieldAttribute

    assert Taggable.__name__ == 'Taggable'
    assert Taggable._tags.__name__ == '_tags'
    assert Taggable._tags.isa == 'list'
    assert Taggable._tags.default == list
    assert Taggable._tags.listof == (string_types, int)
    assert Taggable._tags.extend == True
    assert Taggable.untagged == frozenset(['untagged'])
    # This test will fail if the _tags is changed to an attribute which is not a FieldAttribute
    # since isinstance(t.__class__, FieldAttribute) will return False
    t = Taggable()

# Generated at 2022-06-21 01:28:57.483818
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.template import Templar

    class MyTaggableClass(Base, Taggable):
        pass

    b = MyTaggableClass()

    # make sure we can set tags
    b.tags = ['foo']
    assert(b.tags == ['foo'])

    # make sure tags was converted to a list
    b.tags = 'bar'
    assert(b.tags == ['bar'])

    # make sure tags was converted to a list
    b.tags = ['a','b','c']
    assert(b.tags == ['a','b','c'])

    # make sure tags was converted to a list
    b.tags = 'a,b,c'

# Generated at 2022-06-21 01:29:04.901447
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy instance of Taggable
    class Dummy_Taggable(Taggable):
        def __init__(self, loader, variable_manager, tags=None):
            self._loader = loader
            self._variable_manager = variable_manager
            self.tags = tags

    dataloader = DataLoader()
    variable_manager = VariableManager()

    # Create dummy instance of Taggable
    t = Dummy_Taggable(dataloader, variable_manager)

    # Test to make sure that when no tags are specified the current tagged item should be executed
    t.tags = None
    only_tags = None
   

# Generated at 2022-06-21 01:29:42.338836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    import os
    import sys

    class Options():
        def __init__(self):
            self.only_tags = None
            self.skip_tags = None

    class PlayContext():
        def __init__(self, options):
            self.options = options

    # ansible/lib/ansible/executor/task_result.py

# Generated at 2022-06-21 01:29:53.883604
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Instantiate a dummy class deriving from Taggable
    class Dummy(Taggable):
        pass

    d = Dummy() # Instantiate object

    # Expected True
    d.tags = set(['yes', 'no', 'maybe'])
    assert d.evaluate_tags(['yes', 'maybe'], [], None) == True
    assert d.evaluate_tags(set(['yes']), set(['no']), None) == True

    # Expected False
    d.tags = set(['yes', 'no', 'maybe'])
    assert d.evaluate_tags(['no'], [], None) == False
    assert d.evaluate_tags(set(['no']), set(['maybe', 'yes']), None) == False

# Generated at 2022-06-21 01:29:56.588624
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []


# Generated at 2022-06-21 01:30:01.852951
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObject

    try:
        Play.include
    except AttributeError:
        Play.include = PlayObject

    p = Play()
    assert p.tags == None

    p = Play(tags="foo, foo2")
    assert p.tags == ["foo", "foo2"]

if __name__ == '__main__':
    test_Taggable()
    sys.exit(0)

# Generated at 2022-06-21 01:30:13.628835
# Unit test for constructor of class Taggable
def test_Taggable():
    params = {'tags': ['a', 'b', 'c']}
    test_obj = Taggable()
    test_obj._load_tags('tags', ['a', 'b', 'c'])
    test_obj._load_tags('tags', 'a,b,c')
    try:
        test_obj._load_tags('tags', 2)
    except AnsibleError:
        pass
    # check if evaluate_tags() works properly
    test_obj.tags = ['always']
    assert test_obj.evaluate_tags(['all', 'a', 'b', 'c'], None, 'all')
    assert test_obj.evaluate_tags(['a', 'b', 'c'], None, 'all')
    test_obj.tags = ['all']

# Generated at 2022-06-21 01:30:16.903434
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags(None, ['a', 'b']) == ['a', 'b']
    assert t._load_tags(None, 'a,b') == ['a', 'b']

    try:
        t._load_tags(None, 1234)
        assert False
    except Exception:
        pass

# Generated at 2022-06-21 01:30:25.162639
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ['tag1', 'tag2']
    t.tags = ['tag3', 'tag4']

    # check that t._tags is a list
    assert isinstance(t._tags, list)
    # ensure that a listof objects is created when a list is passed in
    assert isinstance(t.tags, listof)
    # ensure that members of t.tags are string objects
    assert isinstance(t.tags[0], string_types)
    assert isinstance(t.tags[1], string_types)

    # check that t._tags is a list of tags
    print(t._tags)
    print(t.tags)

# Generated at 2022-06-21 01:30:30.305566
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    tb = "---\n- name: test block\n  hosts: all\n  tasks:\n    - name: test task\n      debug:\n        msg: test task\n"
    result = Task.load(tb)
    assert result._ds['name'] == 'test task'
    assert result._ds['debug']['msg'] == 'test task'

# Generated at 2022-06-21 01:30:33.103081
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.untagged == frozenset(['untagged'])
    assert t._tags == []

# Generated at 2022-06-21 01:30:43.171558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    use_vars = {'hostvars': {}}

    # Create a role definition
    role_definition = RoleDefinition()
    role_definition.tags = ['role_tag1']

    # Create a Taggable that has a list of tags
    test1_taggable = Taggable()
    test1_taggable._loader = None
    test1_taggable.tags = ['tag1']

    # Check if the taggable should be included
    # when only_tags is empty and skip_tags is empty
    (should_run, included_tags) = test1_taggable

# Generated at 2022-06-21 01:31:41.688560
# Unit test for constructor of class Taggable
def test_Taggable():
  test_obj = Taggable()
  print(test_obj._tags)

# Generated at 2022-06-21 01:31:52.970411
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class A(Taggable):
        pass

    a = A()
    a.tags = ['tag1', 'tag2']

    # this will test every possible combination of only_tags and skip_tags
    assert a.evaluate_tags(['tag1'], ['tag2'], {})
    assert not a.evaluate_tags(['tag2'], ['tag1'], {})
    assert a.evaluate_tags(['tag1'], ['tag1'], {})
    assert not a.evaluate_tags(['tag2'], ['tag2'], {})
    assert a.evaluate_tags([], ['tag2'], {})
    assert not a.evaluate_tags(['tag2'], [], {})
    assert a.evaluate_tags(['tag1'], [], {})

# Generated at 2022-06-21 01:32:03.475286
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    import pytest
    from units.mock.loader import DictDataLoader

    task = Task()
    task.tags = ['a', 'b']
    assert list == type(task._tags)
    assert ['a', 'b'] == task._tags

    task = Task()
    task.tags = 'a, b'
    assert list == type(task._tags)
    assert ['a', 'b'] == task._tags

    task = Task()
    with pytest.raises(AnsibleError) as err:
        task.tags = 1
    assert 'tags must be specified as a list' in str(err.value)

    task = Task()

# Generated at 2022-06-21 01:32:14.752326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_only_tags = ['only_tag']
    test_skip_tags = ['skip_tag']
    test_tags = ['never']
    test_all_var = dict()
    test_case = Taggable()
    test_case.tags = test_tags
    test_case.evaluate_tags(test_only_tags, test_skip_tags, test_all_var)
    assert test_case.evaluate_tags(test_only_tags, test_skip_tags, test_all_var) == True

    test_tags = ['never', 'always']
    test_case = Taggable()
    test_case.tags = test_tags
    assert test_case.evaluate_tags(test_only_tags, test_skip_tags, test_all_var) == True

    test_tags = ['never']
   

# Generated at 2022-06-21 01:32:17.677300
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        taggable = Taggable()
    except Exception as e:
        fail_msg = "Failed to create Taggable object: {}".format(e)
    finally:
        assert "taggable" in locals(), fail_msg

# Generated at 2022-06-21 01:32:24.256801
# Unit test for constructor of class Taggable
def test_Taggable():
    class Foo(Taggable):
        def __init__(self, test_tags=None):
            self.tags = test_tags
    print("Testing Taggable")
    td = Foo(test_tags = ['tag1', 'tag2'])
    print(td.tags)
    td = Foo(test_tags = ['tag1', 'tag2', 'tag3,tag4,tag5'])
    print(td.tags)
    try:
        td = Foo(test_tags = 3)
    except AnsibleError as e:
        print("Caught exception:" + str(e))
        print("Correctly raised AnsibleError exception aimed at %s" % td)


if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-21 01:32:32.523492
# Unit test for constructor of class Taggable
def test_Taggable():
    tag = Taggable()
    assert type(tag._load_tags(None,'test')) == list
    assert type(tag._load_tags(None, ['test1', 'test2'])) == list
    assert tag._tags[0] == 'test1' and tag._tags[1] == 'test2'
    tag2 = Taggable()
    tag2.evaluate_tags(None, None, {'test' : 2})
    assert tag2.tags == ['test'] and tag2.untagged == frozenset(['untagged'])


if __name__ == '__main__':
    test_Taggable()
    print('Unit tests completed successfully.')

# Generated at 2022-06-21 01:32:34.925209
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    l = [1, 2, 3]
    print(l[0:])

# Generated at 2022-06-21 01:32:41.766638
# Unit test for constructor of class Taggable
def test_Taggable():
    ''' the constructor of Taggable will be called when we use this class in other
        modules. So, it is very important.
    '''
    k = Taggable()
    # check the default parameter
    assert(isinstance(k._tags, list))
    assert(len(k._tags) == 0)
    assert(isinstance(k.tags, list))
    assert(len(k.tags) == 0)
    # k is a Taggable object
    assert(isinstance(k, Taggable))


# Generated at 2022-06-21 01:32:50.772848
# Unit test for constructor of class Taggable
def test_Taggable():
    print('Testing constructor of class Taggable')
    assert Taggable().tags == []  # default
    assert Taggable().tags == []  # default
    assert Taggable(tags=[]).tags == []  # list
    assert Taggable(tags=['tagged']).tags == ['tagged']  # list
    assert Taggable(tags='tagged').tags == ['tagged']  # string
    assert Taggable(tags='tagged, another').tags == ['tagged', 'another']  # string