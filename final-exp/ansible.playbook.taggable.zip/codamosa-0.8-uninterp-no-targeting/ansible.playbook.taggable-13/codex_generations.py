

# Generated at 2022-06-21 01:24:39.320358
# Unit test for constructor of class Taggable
def test_Taggable():
    def _my_loader(path): return dict(path=path)
    t = Taggable()
    t._loader = _my_loader
    t.tags = "tag1, tag2 ,tag3,tag4,tag5 ,tag6"
    if t.tags is not None:
        assert False, "tags is not initialized correctly"
    t.tags = ["tag1", "tag2"]
    assert len(t.tags) == 2, "tags is not initialized correctly"
    t.tags = dict(tags="tag1,tag2")
    assert len(t.tags) == 2, "tags is not initialized correctly"

    tags = t._load_tags("tags", "tag1,tag2")
    assert tags == ["tag1", "tag2"], "tags is not initialized correctly"

# Generated at 2022-06-21 01:24:52.042432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    #
    # Invoke method evaluate_tags with valid only tag
    #
    t = Taggable()
    tags = ['tag1']
    only_tags = ['tag1']
    skip_tags = []
    all_vars = dict()
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert (should_run == True)

    #
    # Invoke method evaluate_tags with valid skip tag
    #
    t = Taggable()
    tags = ['tag1']
    only_tags = []
    skip_tags = ['tag1']
    all_vars = dict()
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert (should_run == False)

    #
    # Invoke

# Generated at 2022-06-21 01:25:01.000587
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import Include
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.vars import include_vars
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser

    module = ModuleArgsParser.parse_kv('dummy_module name=/foo')

    task = Include()
    task.vars = dict()
    task.args = {'module': module, 'tasks': ['tasks/main.yml']}
    task.tags = ['all', 'tagged', 'untagged']
    task.role_name = 'dummy_role'
    task.role_path = '/dummy_path'
    task.task_include = dict()
   

# Generated at 2022-06-21 01:25:13.237986
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestModule1(Taggable):
        pass
    test_module1 = TestModule1('/etc/ansible/test_module1.py', 'name', 'root', '')
    assert(test_module1.tags == [])
    # Make sure that we can serialize
    assert(test_module1.dump_attrs() == {'tags': []})

    class TestModule2(Taggable):
        tags = ['tag1', 'tag2']
    test_module2 = TestModule2('/etc/ansible/test_module2.py', 'name', 'root', '')
    assert(test_module2.tags == ['tag1', 'tag2'])
    # Make sure that we can serialize

# Generated at 2022-06-21 01:25:23.464166
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        pass

    t = DummyTaggable()
    t.tags = ['a', 'b', 'c']
    assert(t.evaluate_tags(set(['b']), set([]), {}))
    assert(t.evaluate_tags(set(['b']), set(['a']), {}))
    assert(not t.evaluate_tags(set([]), set(['b']), {}))
    assert(not t.evaluate_tags(set(['a']), set(['b']), {}))
    assert(not t.evaluate_tags(set(['c']), set([]), {}))
    assert(t.evaluate_tags(set(['a']), set([]), {}))

# Generated at 2022-06-21 01:25:34.034062
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Taggable get_tags method
    class Taggable_object(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # !!! should_run == False
    # skip_tags (set) is a subset of tags(set)
    result = Taggable_object(["tag1", "tag2"]).evaluate_tags(None, set(["tag2"]), None)
    expected_result = False

# Generated at 2022-06-21 01:25:45.386277
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    only_tags = set()
    skip_tags = set()
    all_vars = dict()
    # Test 1: Empty tags (default: run task)
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test 2: Tags set to true (run task)
    obj.tags = ['testtag']
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test 3: Tags set to true (run task)
    obj.tags = ['testtag']
    only_tags = set(['testtag'])
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test 4: Tags set to false (don't run task)

# Generated at 2022-06-21 01:25:54.462155
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Task
    from ansible.playbook.task import Task as TaskDeprecated
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    r = Role()
    b = Block()

    assert r.tags == []
    assert b.tags == []

    r = Role(tags=['foo','bar'])
    b = Block(tags=['foo','bar'])

    assert r.tags == ['foo','bar']
    assert b.tags == ['foo','bar']


# Generated at 2022-06-21 01:26:03.218695
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    >>> from ansible.playbook.block import Block
    >>> block = Block()
    >>> block.tags = ['a','b']
    >>> block.tags
    ['a', 'b']
    >>> block.tags = [1,'b']
    >>> block.tags
    [1, 'b']
    >>> block.tags = 'a,b'
    >>> block.tags
    ['a', 'b']
    >>> block.tags = 1
    Traceback (most recent call last):
    ...
    AnsibleError: tags must be specified as a list
    '''
    pass



# Generated at 2022-06-21 01:26:15.741071
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:26:27.530267
# Unit test for constructor of class Taggable
def test_Taggable():
    def check_Taggable(item, *args):
        cls, name, value = args
        assert hasattr(item, name)
        assert getattr(item, name) == value
    item = Taggable()
    for i in ['tags', 'untagged']:
        check_Taggable(item, Taggable, i, Taggable._fields[i].default)


# Generated at 2022-06-21 01:26:40.251839
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    For the "Taggable" class, the "evaluate_tags" method is used to
    return a value indicating whether a task should execute based
    on the tags which are associated with the task.
    '''

    class TestTaggable(Taggable):
        '''
        TestTaggable is a subclass of class Taggable which defines
        the needed "__init__" method.
        '''

        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    # Test with no tags
    tt = TestTaggable([])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with "never" tag
    tt = TestTaggable(['never'])
    assert not tt.evaluate

# Generated at 2022-06-21 01:26:47.693569
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    a = Task()
    a._load_tags('load_tags', 'a,b,c')
    assert a._load_tags('load_tags', 'a,b,c') == ['a','b','c']
    assert a._load_tags('load_tags', 'a') == ['a']
    import pytest
    with pytest.raises(AnsibleError):
        a._load_tags('load_tags', ('a'))

# Generated at 2022-06-21 01:26:59.290431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    import ansible.utils.template as template
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    # Initialize class
    t = Taggable()

    # Set a fake loader and inventory to enable the tests
    t._loader = template.AnsibleLoader()
    t._inventory = Inventory(loader=t._loader)
    t.variable_manager = VariableManager(loader=t._loader, inventory=t._inventory)

    # Case 1: skip everything
    # set input
    all_vars = dict()
    skip_tags = ['all']
    only_tags = set()
    # set output
    output = False
    # run test
    assert t.evaluate_tags(only_tags,skip_tags,all_vars) == output

    # Case

# Generated at 2022-06-21 01:27:01.479860
# Unit test for constructor of class Taggable
def test_Taggable():
    test_instance = Taggable()
    
    assert test_instance.tags == []
    assert isinstance(test_instance.tags, list)
    # will always return True, not really asserting anything
    assert test_instance.evaluate_tags([], [], {})

# Generated at 2022-06-21 01:27:03.517107
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable != None, "Failed to create Taggable"

# Generated at 2022-06-21 01:27:09.649077
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._ds = {}
            self._ds['tags'] = []

    t = TestTaggable()
    t.tags = ['tagged']
    a_vars = {'test': 'value'}
    assert t.evaluate_tags(only_tags=None, skip_tags=['all'], all_vars=a_vars)
    t.tags = ['untagged']
    assert not t.evaluate_tags(only_tags=None, skip_tags=['all'], all_vars=a_vars)
    t.tags = []
    assert not t.evaluate_tags(only_tags=None, skip_tags=['all'], all_vars=a_vars)
    t.tags = ['all']


# Generated at 2022-06-21 01:27:13.811326
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []
    assert obj._load_tags(None, 'tag1,tag2') == ['tag1', 'tag2']
    assert obj._load_tags(None, ['tag1', 'tag2']) == ['tag1', 'tag2']

# Generated at 2022-06-21 01:27:25.047112
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = Taggable()
    # Set up tags for testing
    task.tags = ['always', 'test']
    assert task.evaluate_tags(['test', 'always'], ['never'], {})
    # Test _load_tags
    task._load_tags('tags', ['test', 'always'])
    assert task.tags == ['test', 'always']
    task._load_tags('tags', 'test, always')
    assert task.tags == ['test', 'always']
    # Test evaluate_tags with only_tags skip_tags as empty
    assert task.evaluate_tags([], [], {})
    # Test evaluate_tags with skip_tags as empty and only_tags as not empty
    assert task.evaluate_tags(['foo', 'bar'], [], {})
    # Test evaluate_tags with only_tags as empty and

# Generated at 2022-06-21 01:27:25.663417
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-21 01:27:50.030050
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.variables import VariableManager

    class MyClass(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    # Most of this is testing the evaluate_tags method of the Taggable class,
    # but it is not possible to test that directly, so it is tested here
    # against its children.

    # Test Case 1: no tags on task
    myobj = MyClass()
    myobj.tags = []
    assert myobj.evaluate_tags(['foo'], [], {}) == False
    assert myobj.evaluate_tags([], ['foo'], {}) == True

    #

# Generated at 2022-06-21 01:27:56.824462
# Unit test for constructor of class Taggable
def test_Taggable():
    class Foo(Taggable):
        pass

    foo = Foo()
    assert foo.tags == []

    class Foo(Taggable):
        _tags = FieldAttribute(isa='list', default="a,b")

    foo = Foo()
    assert foo.tags == ['a', 'b']

# Generated at 2022-06-21 01:28:09.737419
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    verbose = False
    assert Taggable(tags=[]).evaluate_tags(only_tags=[], skip_tags=[])
    assert Taggable(tags=['all']).evaluate_tags(only_tags=[], skip_tags=[])
    assert Taggable(tags=['all']).evaluate_tags(only_tags=['all'], skip_tags=[])
    assert not Taggable(tags=['all']).evaluate_tags(only_tags=['all'], skip_tags=['all'])
    assert not Taggable(tags=['all']).evaluate_tags(only_tags=[], skip_tags=['all'])
    assert Taggable(tags=[]).evaluate_tags(only_tags=[], skip_tags=['all'])

# Generated at 2022-06-21 01:28:17.948060
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTask(Taggable):
        def __init__(self, tags):
            self._tags = tags
    assert not TestTask(tags=None).evaluate_tags(only_tags=['foo','bar'], skip_tags=None, all_vars={})
    assert TestTask(tags=['foo','bar']).evaluate_tags(only_tags=['foo','bar'], skip_tags=None, all_vars={})
    assert TestTask(tags=['foo','bar']).evaluate_tags(only_tags=None, skip_tags=['foo','bar'], all_vars={})
    assert not TestTask(tags=['foo']).evaluate_tags(only_tags=['foo','bar'], skip_tags=None, all_vars={})
    assert not TestTask(tags=['foo','bar']).evaluate

# Generated at 2022-06-21 01:28:21.154814
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == list


# Generated at 2022-06-21 01:28:32.876221
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    taggable._tags = frozenset(["tag1", "tag2"])
    taggable.tags
    taggable = Taggable()
    taggable._tags = frozenset(["tag3", "tag4"])
    taggable.tags
    taggable = Taggable()
    taggable._tags = "tag3,tag4"
    taggable.tags
    taggable = Taggable()
    taggable._tags = ["tag3", "tag4"]
    taggable.tags
    taggable = Taggable()
    taggable.tags
    # No unit test for the method evaluate_tags()

# Generated at 2022-06-21 01:28:36.726292
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert isinstance(a, Taggable)
    #assert a.tags == []



# Generated at 2022-06-21 01:28:46.656078
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    test_obj = TestClass()
    test_obj.tags = ['always']
    assert test_obj.evaluate_tags(only_tags=['tagged'], skip_tags=['never'], all_vars=dict())
    assert test_obj.evaluate_tags(only_tags=['tagged','never','always'], skip_tags=['never'], all_vars=dict())
    assert test_obj.evaluate_tags(only_tags=['tagged','always'], skip_tags=['never'], all_vars=dict())

# Generated at 2022-06-21 01:28:54.994869
# Unit test for constructor of class Taggable
def test_Taggable():

    taggable1 = Taggable()
    taggable1.tags = ["tag1", "tag2"]
    taggable1.evaluate_tags(["tag1"], None, None)

    taggable2 = Taggable()
    taggable2.tags = []
    taggable2.evaluate_tags(None, None, None)

    taggable3 = Taggable()
    taggable3.tags = ["always"]
    taggable3.evaluate_tags(["always"], None, None)
    taggable3.evaluate_tags(None, None, None)

# Generated at 2022-06-21 01:29:03.168106
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    >>> ta = Taggable()
    >>> ta._load_tags('', [])
    []
    >>> ta._load_tags('', 'tag_A,tag_B')
    ['tag_A', 'tag_B']
    >>> ta._load_tags('', 'tag_A,,tag_B')
    ['tag_A', '', 'tag_B']
    >>> ta._load_tags('', '{{ test_var }}')
    ['{{ test_var }}']
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 01:29:18.378078
# Unit test for constructor of class Taggable
def test_Taggable():
    a = list()
    assert Taggable(a, a)

# Generated at 2022-06-21 01:29:22.199322
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    my_task = Task()
    my_task.tags = ["tag_name_1", "tag_name_2"]
    only_tags = ["tag_name_1"]
    skip_tags = []
    all_vars = {}
    assert(my_task._evaluate_tags(only_tags, skip_tags, all_vars))



# Generated at 2022-06-21 01:29:33.790819
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTestCase(Taggable):
        def __init__(self, tags=None, loader=None, variable_manager=None):
            self.tags = tags
            self._loader = loader
            self._variable_manager = variable_manager
            self._attribute_errors = []

    taggable = TaggableTestCase(tags=None, loader=None, variable_manager=None)
    assert taggable.evaluate_tags(only_tags=['mytag'], skip_tags=[], all_vars=dict()) == False
    assert taggable.tags == Taggable.untagged
    taggable = TaggableTestCase(tags=['mytag'], loader=None, variable_manager=None)

# Generated at 2022-06-21 01:29:35.718118
# Unit test for constructor of class Taggable
def test_Taggable():
    # Taggable class is tested in task.py and role.py
    pass

# Generated at 2022-06-21 01:29:43.668317
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.plays.play import Play
    from ansible.playbook.handler import Handler

    # Instantiate a class Taggable
    test_playbook = Taggable()
    # Check type
    assert(isinstance(test_playbook, Taggable))
    # Check type
    assert(isinstance(test_playbook, Base))
    # Check type
    assert(isinstance(test_playbook, Block))

    # Instantiate a class Taggable
    test_task = Task()
    # Check type
    assert(isinstance(test_task, Taggable))
    # Check type

# Generated at 2022-06-21 01:29:47.891523
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableDummy(Taggable):
        pass
    t = TaggableDummy() # tags must be initialized to default value (list)
    assert type(t.tags) is list

# Generated at 2022-06-21 01:29:51.255799
# Unit test for constructor of class Taggable
def test_Taggable():

    # Simple case when the member is set to default value
    t = Taggable(tags = list())

    # Create a case when the member is not set to default value
    t = Taggable(tags = ['one', 'two'])



# Generated at 2022-06-21 01:29:53.915941
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert isinstance(t, Taggable)

# Generated at 2022-06-21 01:29:58.364422
# Unit test for constructor of class Taggable
def test_Taggable():
  test_taggable = Taggable()
  assert isinstance(test_taggable.tags, list)
  assert test_taggable.tags == []
  assert test_taggable.untagged == frozenset(['untagged'])
  assert test_taggable.evaluate_tags([], [], {})


# Generated at 2022-06-21 01:30:03.897393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class fake_task(Taggable):
        def __init__(self,tags):
            self.tags = tags
            self._loader = None

    def assert_evaluate_tags(only_tags, skip_tags, tags, should_run):
        task = fake_task(tags)
        assert task.evaluate_tags(only_tags, skip_tags, None) == should_run

    # We shouldn't run tagged and always tasks in skip_tags=['all']
    assert_evaluate_tags(None, ['all'], ['tagged'], False)
    assert_evaluate_tags(None, ['all'], ['always'], False)

    # We should run always tasks in skip_tags=['all']
    assert_evaluate_tags(None, ['all'], ['always','tagged'], True)

# Generated at 2022-06-21 01:30:20.746887
# Unit test for constructor of class Taggable
def test_Taggable():
   t = Taggable()
   assert t is not None

# Generated at 2022-06-21 01:30:28.291912
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_task = Task()
    my_variable_manager = VariableManager()
    my_loader = DataLoader()

    my_variable_manager.set_inventory(my_loader.load_from_file('../../../tests/inventory'))

    # Evaluate tag using a task and inventory
    my_task._variable_manager = my_variable_manager
    my_task.tags = ['always', 'test', 'tagged']
    assert my_task.evaluate_tags(['always', 'tagged'], None, my_variable_manager.get_vars(play=None, include_hostvars=False))

    # Evaluate tag using a task and inventory
    my

# Generated at 2022-06-21 01:30:35.925314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    print("#########################################################################")
    print("UNIT TESTING: Taggable evaluate_tags()")

    tasks = []

    # Task with no tags
    task = dict(
        task1=dict(
            action=dict(
                module='setup'
            )
        )
    )
    tasks.append(task)

    # Task with simple string tag (1)
    task = dict(
        task1=dict(
            action=dict(
                module='setup'
            ),
            tags='tag1'
        )
    )
    tasks.append(task)

    # Task with simple string tag (2)
    task = dict(
        task1=dict(
            action=dict(
                module='setup'
            ),
            tags='tag2'
        )
    )
    tasks.append(task)

# Generated at 2022-06-21 01:30:45.458188
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class T(Taggable):
        def __init__(self):
            self.tags = ['foo', 'bar']

    t = T()
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['bar'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['baz'], skip_tags=[], all_vars={}) == False

    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-21 01:30:57.305453
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Task
    t = Task()
    t.tags = ['a', 'b', 'c']
    vars = dict()

    # test case 1
    assert t.evaluate_tags(only_tags=['a', 'b'], skip_tags=['never'], all_vars=vars), \
        "task must be part of tags 'a' or 'b' but not part of tags 'never'"

    # test case 2
    t.tags = ['never', 'c']
    assert not t.evaluate_tags(only_tags=['a', 'b'], skip_tags=['never'], all_vars=vars), \
        "task must not be part of tags 'never'"

    # test case 3
    t.tags = ['all', 'c']
    assert t.evaluate_tags

# Generated at 2022-06-21 01:30:58.777062
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == [], taggable.tags

# Generated at 2022-06-21 01:31:01.804512
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t is not None
    assert t._tags is not None
    assert len(t._tags) == 0

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:31:09.276842
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def get_mock_item():
        mock_item = Taggable()
        mock_item._loader = 'faked_loader'
        return mock_item

    mock_item = get_mock_item()
    mock_item._tags = 'a,b,c'
    assert mock_item.evaluate_tags(['a'], [], {}) == True
    assert mock_item.evaluate_tags(['b'], [], {}) == True
    assert mock_item.evaluate_tags(['c'], [], {}) == True
    assert mock_item.evaluate_tags(['a','b'], [], {}) == True
    assert mock_item.evaluate_tags(['x'], [], {}) == False
    assert mock_item.evaluate_tags(['a','b','c'], [], {}) == True

# Generated at 2022-06-21 01:31:12.709745
# Unit test for constructor of class Taggable
def test_Taggable():
    class Play(Taggable):
        pass
    p = Play()
    assert p._tags == []

# Generated at 2022-06-21 01:31:25.409935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.model import Model

    taggable = Taggable()

    taggable.tags = [ "foo" ]
    taggable.evaluate_tags(only_tags=["foo"], skip_tags=[], all_vars={})

    taggable.tags = [ "bar", "baz" ]
    taggable.evaluate_tags(only_tags=["foo"], skip_tags=[], all_vars={})

    taggable.tags = [ "bar", "baz" ]
    taggable.evaluate_tags(only_tags=[], skip_tags=["foo"], all_vars={})

    taggable.tags = [ "bar", "baz" ]
    taggable.evaluate_tags(only_tags=["foo"], skip_tags=["foo"], all_vars={})

    tag

# Generated at 2022-06-21 01:32:04.551977
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Define object
    taggable = Taggable()

    # We test all skip_tags variations
    # - At this time, there is no 'skip_tags' in the execution options
    taggable.tags = ['foo', 'bar', 'baz']
    assert taggable.evaluate_tags(None, [], dict())

    # - At this time, there is 'skip_tags' in the execution options.
    #   We test all the variations of the skip_tags
    taggable.tags = ['foo', 'bar', 'baz']
    assert taggable.evaluate_tags(None, ['skip_tags'], dict())

    # - At this time, there is 'skip_tags' in the execution options.
    #   We test all the variations of the skip_tags

# Generated at 2022-06-21 01:32:15.251993
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test evaluate_tags function of class Taggable with all the combination of
    # only_tags, skip_tags and tags.

    # Create an instance of class Taggable
    class TaggableTest(Taggable):
        def __init__(self, tags, only_tags, skip_tags):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags


# Generated at 2022-06-21 01:32:23.879381
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None

    t = TestTaggable()

    # test when tags is empty and only_tags is not empty
    t.tags = []
    only_tags = [ 'tag1', 'tag2' ]
    skip_tags = []
    should_run = t.evaluate_tags(only_tags, skip_tags, {})
    assert(should_run == False)

    # test when tags is empty and only_tags is empty
    t.tags = []
    only_tags = []
    skip_tags = []
    should_run = t.evaluate_tags(only_tags, skip_tags, {})
    assert(should_run == True)

    # test when tags is empty and only_tags

# Generated at 2022-06-21 01:32:26.966680
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable(dict(tags=('test', 'test2')))
    assert t.tags == ['test', 'test2']

# Generated at 2022-06-21 01:32:35.018959
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import Include
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    task = Task.load(dict(
        name = "example",
        action = dict(module="ping"),
        tags = ['example-tag']
    ), loader=None, variable_manager=None)

    assert task.tags == ['example-tag']


# Generated at 2022-06-21 01:32:43.641927
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class fake_object(Taggable):
        def __init__(self, tags):
            self.tags = tags


# Generated at 2022-06-21 01:32:47.004313
# Unit test for constructor of class Taggable
def test_Taggable():

    test_taggable = Taggable()
    assert test_taggable._load_tags('', '') == ['']
    assert test_taggable._load_tags('', []) == []
    assert test_taggable._load_tags('', 'foo,bar,baz') == ['foo', 'bar', 'baz']
    assert test_taggable._load_tags('', ['foo,bar,baz']) == ['foo,bar,baz']

# Generated at 2022-06-21 01:32:54.994194
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Taggable_test(Taggable):
        def __init__(self):
            self._tags = []
    taggable_test_obj = Taggable_test()

    # Base case: no tags at all
    assert taggable_test_obj.evaluate_tags(only_tags = [], skip_tags = [], all_vars = {})
    assert taggable_test_obj.evaluate_tags(only_tags = ['a'], skip_tags = [], all_vars = {})
    assert taggable_test_obj.evaluate_tags(only_tags = [], skip_tags = ['a'], all_vars = {})
    assert taggable_test_obj.evaluate_tags(only_tags = ['a'], skip_tags = ['b'], all_vars = {})



# Generated at 2022-06-21 01:33:05.310643
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    
    # You need to make sure that this module is
    # present in your $PYTHONPATH. A quick way to do this is:
    # $ export PYTHONPATH=$PYTHONPATH:./lib
    import ansible.playbook

    only_tags=['servers']
    skip_tags=[]
    all_vars=dict()

    # Create a task
    task = ansible.playbook.Task()
    task.tags=['tag1', 'tag2']

    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == False

    task.tags=['servers']
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # Create

# Generated at 2022-06-21 01:33:14.643574
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    t = Taggable()

    t.tags = ['example1']
    assert t.tags == ['example1']

    t.tags = ['example2', 'example3']
    assert t.tags == ['example2', 'example3']

    t.tags = 'example4,example5'
    assert t.tags == ['example4', 'example5']

    t.tags = ['example6,example7']
    assert t.tags == ['example6,example7']

    t.tags = 'example8'
    assert t.tags == ['example8']
