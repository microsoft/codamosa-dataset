

# Generated at 2022-06-21 01:24:33.672895
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable(tags=['test'])
    assert obj.tags == ['test']


    obj = Taggable()
    assert obj.tags == []




# Generated at 2022-06-21 01:24:44.759117
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableStub(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test if should_run is set to False if only_tags is set True
    test_object = TaggableStub([])
    assert test_object.evaluate_tags(only_tags=[], skip_tags=[]) is True

    # Test if should_run is set to False if only_tags is set True
    test_object = TaggableStub([])
    assert test_object.evaluate_tags(only_tags=[], skip_tags=['all']) is True

    # Test if should_run is set to False if only_tags is set True
    test_object = TaggableStub(['all'])

# Generated at 2022-06-21 01:24:48.354951
# Unit test for constructor of class Taggable
def test_Taggable():
    result=Taggable()
    assert isinstance(result,Taggable)

# Run the unit tests
if __name__ == "__main__":
    test_Taggable()
    print("All tests passed")

# Generated at 2022-06-21 01:24:58.827625
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags=None, only_tags=None, skip_tags=None,
                     all_vars=None):
            self._tags = tags
            self._only_tags = only_tags
            self._skip_tags = skip_tags
            self._all_vars = all_vars
    class TestLoader: pass

    # 'always' present in tags, but not in skip_tags
    t = TestTaggable(tags=['always', 'foo'], only_tags=None,
                     skip_tags=None, all_vars=None)
    t._loader = TestLoader()

# Generated at 2022-06-21 01:25:03.015435
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    a = Task()
    assert isinstance(a, Taggable)
    assert isinstance(a, Taggable)
    assert isinstance(a._tags, list)

# Generated at 2022-06-21 01:25:15.300191
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test_Taggable_evaluate_tags

        The following is a unit test for the Taggable
        evaluate_tags class method. The purpose of this
        is to ensure that the logic works for all possible
        cases.
    '''

    # Basic tests for simple tag sets
    tag = Taggable()
    assert tag.evaluate_tags('tagged', 'untagged', None)
    assert not tag.evaluate_tags(['tagged'], ['untagged'], None)

    # Simple only_tags/skip_tags tests
    assert tag.evaluate_tags(['tagged'], ['untagged'], None)
    assert not tag.evaluate_tags(['untagged'], ['tagged'], None)
    assert tag.evaluate_tags(['tagged'], [], None)

# Generated at 2022-06-21 01:25:24.870657
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['bar', 'baz']
    only_tags = ['foo', 'bar', 'baz']
    skip_tags = ['foo', 'tagged']
    all_vars = dict()
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    if result:
        print("Test 1 PASS")
    else:
        print("Test 1 FAIL")

    t.tags = ['bar']
    only_tags = ['foo', 'bar', 'baz']
    skip_tags = ['foo', 'tagged']
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    if result:
        print("Test 2 PASS")
    else:
        print("Test 2 FAIL")

    t.tags

# Generated at 2022-06-21 01:25:34.816674
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = Taggable()

    # Test "should_run" variable for no tags specified for a task
    tags = []
    only_tags = []
    skip_tags = []

    # Test for "only_tags" specified on command line
    only_tags = ['linux']
    should_run = task.evaluate_tags(only_tags, skip_tags, None)
    assert (not should_run)

    only_tags = ['untagged']
    should_run = task.evaluate_tags(only_tags, skip_tags, None)
    assert (should_run)

    only_tags = ['all']
    should_run = task.evaluate_tags(only_tags, skip_tags, None)
    assert (should_run)

    only_tags = ['tagged']

# Generated at 2022-06-21 01:25:37.962328
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == list, '_tags should be set to type list if not set'

# Generated at 2022-06-21 01:25:40.872818
# Unit test for constructor of class Taggable
def test_Taggable():
    # Taggable is an abstract class and cannot be instantiated,
    # so nothing needs to be done here
    pass


# Generated at 2022-06-21 01:25:58.264991
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task 
    import sys
    import StringIO

    # Case 1: tags = ['foo', 'bar'] only_tags = [], skip_tags = []
    # Result: should_run = True
    # print "Test Case #1"
    task = Task()
    task.tags = ['foo', 'bar']
    only_tags = []
    skip_tags = []
    all_vars = {}
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    if should_run != True:
        sys.exit("Test Case #1 does not pass!")

    # Case 2: tags = ['foo', 'bar'] only_tags = ['foo'], skip_tags = []
    # Result: should_run = True
    # print "Test Case

# Generated at 2022-06-21 01:26:07.454599
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.insert(0, '..')

    from ansible.playbook import Playbook
    from ansible.module_utils.common.collections import ImmutableDict

    num_ok = 0
    num_error = 0

    def ok(where, tags, only_tags, skip_tags, all_vars, should_run):
        global num_ok, num_error

# Generated at 2022-06-21 01:26:19.502908
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    from ansible.playbook.task import Task

    # Create a Taggable object and test if the untagged attribute is initialized correctly
    # as a frozenset containing the string 'untagged'
    t = Taggable()
    assert t.untagged == frozenset(['untagged'])

    # Create a Taggable object and test if the tags attribute is initialized correctly
    # as a list containing the string 'untagged'
    t = Taggable()
    assert t.tags == ['untagged']

    # Create a Taggable object and test if the tags attribute is updated correctly
    # when created with a list containing string 'newtag'
    t = Taggable(tags=['newtag'])
    assert t.tags == ['newtag']

    # Create a Taggable object and test

# Generated at 2022-06-21 01:26:28.583351
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:26:37.905042
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play

    # construct object
    play_ds = dict(
        name = "Ansible play",
        hosts = "all",
        gather_facts = "no",
        tasks = [],
        )

    play = Play().load(play_ds, loader=None)

    # Inject object for testing
    play.__class__ = type('Play', (Taggable,), dict())

    # check loaded object
    assert play.name == 'Ansible play'
    assert play.tasks == []
    assert play.tags == []

# Generated at 2022-06-21 01:26:40.304349
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    task = Task()
    assert len(task._tags) == 0
    assert task.tags == []

# Generated at 2022-06-21 01:26:42.570573
# Unit test for constructor of class Taggable
def test_Taggable():
    inp = Taggable()
    assert len(inp.tags) == 0
    assert 'untagged' in inp.untagged


# Generated at 2022-06-21 01:26:45.357338
# Unit test for constructor of class Taggable
def test_Taggable():
    assert isinstance(Taggable()._tags, list)
    assert isinstance(Taggable(tags=['tag1,tag2'])._tags, list)

# Generated at 2022-06-21 01:26:57.488989
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        inst = Taggable()
        assert False, "No exception for not implemented _load_tags"
    except NotImplementedError as e:
        assert True, "Exception for not implemented _load_tags"

    class Taggable2(Taggable):
        def _load_tags(self, attr, ds):
            return ds

    # new class should instantiate
    inst = Taggable2()
    # inheritance:  default list
    assert inst.tags == [], "tags defaults to list"

    class Taggable3(Taggable2):
        def __init__(self):
            self.tags = 'foo'

    # inheritance:  custom list
    inst = Taggable3()
    assert inst.tags == ['foo'], "tags custom list"


# Generated at 2022-06-21 01:27:00.040122
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert len(a.tags) == 0
    assert 'untagged' in a.untagged

# test_Taggable()

# Generated at 2022-06-21 01:27:24.834811
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import ansible.constants as C

    loader = DataLoader()
    inventory = Host(name='test_host')
    groups = ['test_group']
    templar = Templar(loader, {})

# Generated at 2022-06-21 01:27:31.455876
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    import ansible.inventory.host as host
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager


    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.plugins.callback import CallbackBase
    import json



# Generated at 2022-06-21 01:27:43.474667
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.insert(0, '../')
    from ansible.playbook.task import Task as Taggable
    import unittest

    class TestTaggableEvaluateTags(unittest.TestCase):

        def test_list_tags(self):
            ''' Test that evaluate_tags returns True for the case that a list of
            tags is provided and those tags are present in current item.
            '''
            # Create object to use for test
            t = Taggable()
            t.tags = ['ping', 'pong']
            # Test against a list of tags
            self.assertEqual(t.evaluate_tags(['pong'], ['always'], None), True)


# Generated at 2022-06-21 01:27:48.466104
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.template import Templar

    class TestTagged(Taggable):
        pass

    tagged = TestTagged()
    tagged.tags = ['my_tag1']
    tagged_var = TestTagged()
    tagged_var.tags = ['{{ my_tag2 }}']

    all_vars = dict(my_tag2='my_tag2')
    templar = Templar(loader=None, variables=all_vars)

    # Test for variable tags
    assert tagged_var.evaluate_tags(only_tags=None, skip_tags=None, all_vars=all_vars)
    assert tagged_var.evaluate_tags(only_tags=['my_tag2'], skip_tags=None, all_vars=all_vars)

# Generated at 2022-06-21 01:27:56.331715
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.base import Base
    import copy

    class MyTaggable(Taggable):
        pass

    # Test tags set by constructor
    tags = 'a,b,c'
    my_taggable = MyTaggable(tags=tags)
    assert my_taggable._tags == tags

    # Test tags set by constructor and setattr
    tags2 = 'a,b,d'
    my_taggable.tags = tags2
    assert my_taggable.tags == tags2

    # Test tags set by constructor and append
    tags3 = 'a,b,e'
    my_taggable.tags.append(tags3)

# Generated at 2022-06-21 01:28:04.233726
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert _test_load_tags(t, "value") == ['value']
    assert _test_load_tags(t, "value1,value2") == ['value1', 'value2']
    assert _test_load_tags(t, [1, 2]) == [1, 2]
    assert _test_load_tags(t, {1:'1', 2:'2'}) == [1, 2]
    try:
        _test_load_tags(t, {'name':'value'})
        raise AssertionError('error')
    except AnsibleError:
        pass



# Generated at 2022-06-21 01:28:11.324272
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.base import Base
    import pytest

    for base_class in (Base, Taggable):
        with pytest.raises(AnsibleError) as excinfo:
            base_class()._load_tags('tags', {'a': 'b'})
        assert 'must be specified as a list' in str(excinfo.value)

    # without tags
    c_tags = Conditional()


# Generated at 2022-06-21 01:28:20.182557
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert ta._tags == []

    ta._load_tags(None, ['a','b','c'])
    assert ta._tags == ['a','b','c']

    ta._load_tags(None, 'd,e,f')
    assert ta._tags == ['d','e','f']

    ta._load_tags(None, 3)
    assert ta._tags == [3]

    try:
        ta._load_tags(None, {'g':'h'})
        assert False
    except AnsibleError as e:
        assert "must be specified as" in str(e)

# Generated at 2022-06-21 01:28:23.004262
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert t.evaluate_tags([], [], {}) == True

# Generated at 2022-06-21 01:28:34.804607
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # import needed modules
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    task = TaskInclude()
    block = Block()

    # test default value of tags
    task.tags = None
    assert task.evaluate_tags(None, None, None) == True

    # test if evaluate_tags without skip_tags returns True only when task's tags contains only_tags
    only_tags = ['foo', 'bar']
    task.tags = ['bar']
    assert task.evaluate_tags(only_tags, None, None) == True
    task.tags = ['baz']
    assert task.evaluate_tags(only_tags, None, None) == False

    # test if evaluate_tags without only_tags returns False when task's tags contains skip_tags

# Generated at 2022-06-21 01:29:06.543607
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()

    assert isinstance(test_obj._load_tags("tags", ["tag1", "tag2"]), list)
    assert isinstance(test_obj._load_tags("tags", "tag1, tag2"), list)

# Generated at 2022-06-21 01:29:13.994996
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys

    class TestTaggable(Taggable):
        pass

    # Test with no tags in the task
    test_task = TestTaggable()

    # Test with only_tags
    assert test_task.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={}) == True
    assert test_task.evaluate_tags(only_tags=['tagged'], skip_tags=None, all_vars={}) == True
    assert test_task.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == False
    assert test_task.evaluate_tags(only_tags=['untagged'], skip_tags=None, all_vars={}) == False

    # Test with skip_tags

# Generated at 2022-06-21 01:29:16.228387
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    assert taggable.tags == []

# Generated at 2022-06-21 01:29:25.733471
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class Dummy:
        ''' Dummy class to allow creating of Task and Block objects. '''
        _loader = None
        def __init__(self):
            self.tags = None
            self.only_tags = None
            self.skip_tags = None
            self.dep_chain = []

    dummy = Dummy()

    # Test case 1: checks if the method always returns True when no tags has been set
    # This test case will fail if the default value of the tag attribute has changed
    # Method evaluate_tags is not the right place to check the default value of a property
    # since

# Generated at 2022-06-21 01:29:32.164550
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.base import PLAYBOOK_COMPAT_MAP
    yaml_data = {'name': 'a', 'hosts': 'all', 'gather_facts': 'no', 'tags': 'b'}
    task = Task.load(yaml_data, loader=None, variable_manager=None, play=None)
    assert type(task.tags) == list
    assert len(task.tags) == 1

# Generated at 2022-06-21 01:29:42.607872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Trying to test the method evaluate_tags of Taggable class
    # The method evaluate_tags internally uses the method isdisjoint, which is specific to sets
    # Hence, creating a mock Class Taggable with isdisjoint method
    class Taggable(object):
        def __init__(self):
            return None

        def isdisjoint(self, param):
            return False

    # Mocking the instance of the class and calling the function evaluate_tags
    taggable_instance = Taggable()
    only_tags = True
    skip_tags = False

    # Calling the function evaluate_tags and asserting the result
    assert taggable_instance.evaluate_tags(only_tags, skip_tags, None) == True
    assert taggable_instance.evaluate_tags(skip_tags, only_tags, None) == False

# Generated at 2022-06-21 01:29:55.013968
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:30:03.664214
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags=None, only_tags=None, skip_tags=None):
            super(MyTaggable, self).__init__()
            self._tags = tags
            self.only_tags = only_tags or []
            self.skip_tags = skip_tags or []

    # Empty tags, only_tags and skip_tags
    assert MyTaggable().evaluate_tags([], [], {}) is True
    assert MyTaggable(tags=[]).evaluate_tags([], [], {}) is True
    assert MyTaggable(tags=frozenset()).evaluate_tags([], [], {}) is True
    assert MyTaggable(tags=['foo']).evaluate_tags([], [], {}) is True

# Generated at 2022-06-21 01:30:15.190895
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == [], 'default tags value is expected to be []'

    class myClass(object):
        tags = ['tag1']
    t2 = Taggable()
    t2.tags = myClass()
    assert t2.tags == [u'tag1'], 'expected tags value is [u\'tag1\']'
    names = t2._metadata.keys()
    names.remove('tags')
    assert 'tags' in t2._metadata, 'tags should be in the _metadata'
    assert len(names) > 0, '_metadata should have more than one key'
    for k in names:
        assert 'tags' in t2._metadata[k], 'tags should be in the _metadata'

    class myClass2(object):
        tags = 'tag2'
    t

# Generated at 2022-06-21 01:30:24.803843
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    task = Task()
    assert task.tags == []

    task = Task(tags=['always'])
    assert task.tags == ['always']

    task = Task(tags='always,another')
    assert task.tags == ['always', 'another']

    # FIXME: raise AnsibleError or return an empty list?
    #task = Task(tags=[])
    #assert task.tags == []

    # FIXME: raise AnsibleError or return an empty list?
    #task = Task(tags='')
    #assert task.tags == []

    # FIXME: raise AnsibleError or return an empty list?
    #task = Task(tags={})
    #assert task.tags == []

    # FIXME: raise AnsibleError or return an empty list?
    #task =

# Generated at 2022-06-21 01:31:30.181139
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

    p = Play()
    assert p._tags == []

    r = RoleInclude()
    assert r._tags == []

    t = Task()
    assert t._tags == []

    b = Block()
    assert b._tags == []



# Generated at 2022-06-21 01:31:33.436741
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags('tags',['test1','test2']) == ['test1', 'test2']

# Generated at 2022-06-21 01:31:44.096774
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    
    task = Task()
    task._play = 'play'
    task._ds = dict(name='test')
    task._play_context = PlayContext()

    task.only_tags = ['foo']
    task.skip_tags = ['bar']
    task.tags = ['foo', 'bar', 'baz']

    assert task.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={}) == True
    assert task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=['bar'], all_vars={}) == True

# Generated at 2022-06-21 01:31:51.976020
# Unit test for constructor of class Taggable
def test_Taggable():
    # use import statement to test constructor of class Taggable
    from ansible.playbook.block import Block

    # Initialize attribute of class Block
    b = Block(
        parent=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )
    # call constructor of class Taggable
    my_Taggable = Taggable(b)
    assert my_Taggable

# Unit  test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:32:03.283131
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # prepare inventories
    host_list = [
        u'127.0.0.1'
    ]
    inventory = InventoryManager(loader=None, sources=host_list)

    # prepare variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # prepare task
    task = Task()
    task.variable_manager = variable_manager

    # run the test
    should_run = task.evaluate_tags(['tagged'], [], {})
    assert should_run

    task._tags = ['tag_1', 'tag_2']
    should_run = task.evaluate_tags(['tagged'], [], {})

# Generated at 2022-06-21 01:32:05.480968
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()
    #Shouldn't ever make it here

# Generated at 2022-06-21 01:32:15.712063
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    # default value of _tags is []
    assert taggable.tags == []
    
    # test with list input
    taggable._load_tags('tags', ['a', 'b'])
    assert taggable.tags == ['a', 'b']

    # test with string input
    taggable._load_tags('tags', 'a, b')
    assert taggable.tags == ['a', 'b']

    # test with a string that does not contain ','
    taggable._load_tags('tags', 'tag')
    assert taggable.tags == ['tag']

    # test exception if input is not a list or a string.
    try:
        taggable._load_tags('tags', None)
    except AnsibleError:
        assert True

# Generated at 2022-06-21 01:32:18.669331
# Unit test for constructor of class Taggable
def test_Taggable():
    # test constructor of class Taggable with valid inputs
    Taggable()

    # test constructor of class Taggable with invalid input type
    try:
        Taggable({})
    except Exception as e:
        assert isinstance(e, AnsibleError)

# Generated at 2022-06-21 01:32:31.017094
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    # creating an object of Taggable
    class testTaggable(Taggable):
        pass

    # creating an object of Task
    class testTask(Task):
        pass

    # creating an object of AnsibleLoader
    class testAnsibleLoader(AnsibleLoader):
        pass

    # creating an object of Templar
    class testTemplar(Templar):
        pass

    # checking the default return of the field 'tags'
    assert testTaggable().tags == list()

    # checking the return of the function '_load_tags' for a 'list'

# Generated at 2022-06-21 01:32:42.314960
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        pass

    my_taggable = MyTaggable()
    my_taggable.tags = ['tag_tag_tag', 'adam', 'bar']
    only_tags = ['tag_tag_tag', 'bob', 'adam', 'baz']
    skip_tags = ['foo', 'bar', 'baz']

    print("in %s" % (inspect.stack()[0][3]))
    print("my_taggable.tags = %s" % (my_taggable.tags))
    print("only_tags = %s" % only_tags)
    print("skip_tags = %s" % skip_tags)