

# Generated at 2022-06-21 01:24:38.450748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Test case for the Taggable class method evaluate_tags '''
    # Create a Taggable object
    class Taggable2(Taggable):
        pass
    test_obj = Taggable2()

    # Only tags
    test_obj.tags = ['role_1','role_2','role_3']
    only_tags = ['role_2']
    skip_tags = []
    all_vars = {}

    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Skip tags
    test_obj.tags = ['role_1','role_2','role_3']
    only_tags = []
    skip_tags = ['role_2']
    all_vars = {}


# Generated at 2022-06-21 01:24:42.484167
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    obj = Taggable()
    assert isinstance(obj, Taggable)
    assert len(obj._tags) == 0


# Generated at 2022-06-21 01:24:54.621554
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Use the Block class to test the evaluate_tags method
    class Block(Taggable):
        def __init__(self):
            # Define the mandatory attributes of the Block class
            self._loader = None
            self._parent = None
            self._play = None
            self._role = None
            self._task_include = None
            self._notify = None
            self._loop = None
            self._when = None
            self._block = None
            self._rescue = None
            self._always = None

    # Define a variable that will be used in tests
    variable = dict(name="should_run_test",
                    value="value")

    # Create a Block instance
    block_obj = Block()
    # Initialize block tags
    block_obj.tags = ["linux"]
    # Check that the block should run

# Generated at 2022-06-21 01:24:56.655879
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert t._tags == []
    assert t.tags == []

# Generated at 2022-06-21 01:25:08.665659
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    hostname = 'testhost'
    only_tags = ['all', 'test1']
    skip_tags = []
    all_vars = dict()

    task = Task()
    task.args = dict()
    task._name = hostname
    task.tags = ['test1']
    task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert task.tags.__contains__('test1')
    assert task.tags.__contains__('tagged') == False

    task = Task()
    task.args = dict()
    task._name = hostname
    task.tags = ['test2']

# Generated at 2022-06-21 01:25:20.352286
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import sys
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task

    # Create a Host object to be passed to Taggable object for generating all_vars
    h = Host(name='test_host')

    # Create a Task object
    t = Task()
    t.vars = {'tags': 'tag1,tag2'}
    t._variable_manager = 'dummy'
    t._loader = 'dummy'
    t._hosts = 'dummy'
    t.name = 'dummy'

    # Test case with only_tag option
    print("Testing evaluate_tags method with only_tags option on Taggable object")

# Generated at 2022-06-21 01:25:24.697210
# Unit test for constructor of class Taggable
def test_Taggable():
    # Set attributes
    #_tags = ['tag1']
    #_load_tags = ['tag2']

    # Create new instance of Taggable
    #taggable = Taggable(tags=_tags, load_tags=_load_tags)
    taggable = Taggable()

    # Check attributes
    assert taggable.tags == []
    #assert taggable.load_tags == ['tag2']

# Generated at 2022-06-21 01:25:34.683726
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("=============================================================================")
    print("")
    print("Unit test for method evaluate_tags of class Taggable")
    print("")
    print("=============================================================================")
    print("")
    print("")
    t = Taggable()
    t._tags = ['tagged', 'tagged1', 'tagged2']
    print("t._tags = %s" %t._tags)
    print("t.tags = %s" %t.tags)
    print("t.tags = %s" %t.tags)
    print("t.untagged = %s" %t.untagged)

# Generated at 2022-06-21 01:25:36.415128
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._tags._get_defaults() == set()

# Generated at 2022-06-21 01:25:45.095420
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class MockTaggable(Taggable):
        def __init__(self):
            pass

    class TestTaggableEvaluateTags(unittest.TestCase):
        ''' test Taggable.evaluate_tags()'''

        def setUp(self):
            self.taggable = MockTaggable()

        # @todo: write some tests for Taggable.evaluate_tags()

    # Run unit tests
    unittest.main()


if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-21 01:25:54.947582
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.utils.path import makedirs_safe

    mytask = Task()
    mytask.tags = ['test']

    assert mytask.tags == ['test'], mytask.tags

# Generated at 2022-06-21 01:25:56.780470
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []


# Generated at 2022-06-21 01:26:04.101772
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    TaggableMixin = Taggable()
    TaggableMixin.__bases__ = (AnsibleBaseYAMLObject,)
    TaggableMixin.__init__()
    test = TaggableMixin._tags
    # Unit test for constructor of class Taggable
    print('test:',    test)


if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:26:12.106570
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert a.tags == list()
    a = Taggable('role1,role2,role3')
    assert a.tags == ['role1', 'role2', 'role3']
    a = Taggable(['role1', 'role2', 'role3'])
    assert a.tags == ['role1', 'role2', 'role3']
    # test extend
    a.tags.append('role4')
    assert a.tags == ['role1', 'role2', 'role3', 'role4']

# Generated at 2022-06-21 01:26:23.812842
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def __init__(self):
            pass
    t = DummyTaggable()

    class DummyVars:
        pass

    dv = DummyVars()
    dv.tags = []
    dv.all_vars = dict()

    # Only tagged task
    t.tags = ['always']
    assert t.evaluate_tags(['tagged'], [], dv.all_vars) is True
    assert t.evaluate_tags(['tagged'], [], dv.all_vars) is True
    # Only tagged task, failure if 'never'
    t.tags = ['never']
    assert t.evaluate_tags

# Generated at 2022-06-21 01:26:24.931882
# Unit test for constructor of class Taggable
def test_Taggable():
    # Taggable()
    assert 'test_Taggable'

# Generated at 2022-06-21 01:26:30.807947
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # imports
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook import Play


    # class test
    class TaggableTest(Base, Taggable):
        pass


    # test 1
    # tests the default should_run behavior
    t = TaggableTest()
    t.tags = []
    t.only_tags = None
    t.skip_tags = None
    all_vars = dict()
    result = t.evaluate_tags(t.only_tags, t.skip_tags, all_vars)
    assert result == True

    # test 2
    # tags only tags for defined task, should run
    t = TaggableTest()
    t.tags = ['tag1', 'tag2']
    t.only_tags

# Generated at 2022-06-21 01:26:42.009121
# Unit test for constructor of class Taggable
def test_Taggable():
    ansible = Ansible()
    playbook = Playbook()
    play = Play()
    block = Block()

    assert isinstance(getattr(Taggable,'_tags'),FieldAttribute)
    assert isinstance(Taggable()._tags,list)
    assert len(Taggable()._tags) == 0
    assert Taggable()._load_tags('_tags',[1,2,3]) == [1,2,3]
    assert Taggable()._load_tags('_tags','1,2,3') == ['1','2','3']
    try:
        Taggable()._load_tags('_tags',1)
    except AnsibleError as e:
        assert 'tags must be specified as a list' in str(e)

    assert Taggable().evaluate_tags(None,None,None)

# Generated at 2022-06-21 01:26:54.149208
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # We just need one instance of Taggable which we can pass to the method
    t = Taggable()

    all_vars = dict()
    all_vars['example'] = ['alternative', 'untagged']

    # provided only_tags: ['alternative']
    only_tags = ['alternative']
    skip_tags = []
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # provided only_tags: ['alternative'], skip_tags: ['untagged']
    only_tags = ['alternative']
    skip_tags = ['untagged']
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # provided only_tags: ['altern

# Generated at 2022-06-21 01:27:04.741424
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test Taggable._evaluate_tags() '''
    # pylint: disable=protected-access
    obj = Taggable()
    obj._loader = None
    # pylint: enable=protected-access

    # Test the default behavior of evaluate_tags()
    assert obj._evaluate_tags(obj, None, None) is True

    # Test with only_tags
    obj.tags = ["tag1", "tag2"]
    only_tags = ["tag1"]
    assert obj._evaluate_tags(obj, only_tags, None) is True

    # Test with only_tags that has only 'all'
    only_tags = ["all"]
    assert obj._evaluate_tags(obj, only_tags, None) is True

    # Test with only_tags that has only 'all' and 'never'

# Generated at 2022-06-21 01:27:13.663108
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-21 01:27:20.719322
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert(t.tags == [])

    t = Taggable(from_what="from_what")
    assert(t.tags == [])

    t = Taggable(from_what="from_what", tags="tags")
    assert(t.tags == ['tags'])

    t = Taggable(from_what="from_what", tags=["tag1", "tag2"])
    assert(t.tags == ['tag1', 'tag2'])

# Generated at 2022-06-21 01:27:29.807689
# Unit test for constructor of class Taggable
def test_Taggable():
    test_tags = Taggable()

    if test_tags._load_tags(attr=None, ds='test_tag') != ['test_tag']:
        raise Exception("_load_tags method failed")
    if test_tags._load_tags(attr=None, ds=['test_tag1', 'test_tag2']) != ['test_tag1', 'test_tag2']:
        raise Exception("_load_tags method failed")
    if test_tags._load_tags(attr=None, ds='test_tag1,test_tag2') != ['test_tag1', 'test_tag2']:
        raise Exception("_load_tags method failed")

test_Taggable()

# Generated at 2022-06-21 01:27:37.178241
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

    t = Taggable(tags=['foo', 'bar'])
    assert t._tags == ['foo', 'bar']

    t = Taggable(tags=['foo', 'bar'])
    assert t._tags == ['foo', 'bar']

    t.tags = [1, 2, 3]
    assert t._tags == [1, 2, 3]

    t.tags += [4, 5, 6]
    assert t._tags == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 01:27:38.048619
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-21 01:27:49.469576
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    # Constructor for class Taggable
    #def __init__(self, loader, play=None, parent_block=None):
    # _tags is a property of an object of class Taggable
    # _load_tags is a private method of class Taggable

    # _evaluate_tags is a private method of class Taggable
    # evaluate_tags defined in class Taggable
    # evaluate_tags is a method of an object of class Taggable

    p = Play()
    t = Task()

# Generated at 2022-06-21 01:27:57.071979
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role import Role

    # Check if role with tagged task should be run
    role = Role()
    role._tags = set(['tag3'])
    assert role.evaluate_tags(set(['tag3']), set(), dict())

    # Check if role without tags should be run
    role = Role()
    assert role.evaluate_tags(set(['tag3']), set(), dict())

    # Check if role without tagged task should not be run
    role = Role()
    assert not role.evaluate_tags(set(['tag3']), set(), dict())

    # Check if role should not run with skip_tags set to all
    role = Role()
    role._tags = set(['tag3'])
    assert not role.evaluate_tags(set(), set(['all']), dict())

    # Check if

# Generated at 2022-06-21 01:28:05.885563
# Unit test for constructor of class Taggable
def test_Taggable():
    import imp
    import copy
    import sys
    import os
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_text

    # Load the class Taggable
    m_path = copy.deepcopy(sys.path)
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir, os.pardir, 'lib'))
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Initialize the test object
    task = Task()
    task._role = None
    task._block = Block()
    task._play = None

# Generated at 2022-06-21 01:28:07.827769
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Test Taggable()
    """

    class TaggableImpl(Taggable):
        pass

    t = TaggableImpl()
    assert t.tags is None

# Generated at 2022-06-21 01:28:09.611780
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()
    assert isinstance(tags, Taggable)

# Generated at 2022-06-21 01:28:25.656237
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert(obj._tags == [])


# Generated at 2022-06-21 01:28:35.581759
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    hosts = ['localhost']
    roles = ['test_role']
    vars = {
        'foo': 'bar',
        'roles': roles,
        'ansible_check_mode': False
    }


# Generated at 2022-06-21 01:28:37.452290
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    class MyClass(Base, Taggable):
        def __init__(self):
            Base.__init__(self)
            Taggable.__init__(self)

    myclass = MyClass()
    myclass.evaluate_tags([], [], [])

# Generated at 2022-06-21 01:28:42.377909
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task 
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    task = Task()
    assert task.tags == []

    block = Block()
    assert block.tags == [] 

    play = Play()
    assert play.tags == []



# Generated at 2022-06-21 01:28:54.995308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for tasks of normal play
    play = Play().load({}, loader=None)
    play.tags = {'all'}

    task = Task()
    task.action = 'setup'
    task.tags = ['play2', 'play3']
    play.add_task(task)

    # Test for block tasks of normal play
    block = Block()
    block.tags = ['play3']

    task = Task()
    task.action = 'setup'
    task.tags = ['play1', 'play2']
    block.add_task(task)



# Generated at 2022-06-21 01:28:56.944252
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._tags.default == list

# Generated at 2022-06-21 01:29:05.194287
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    pb = Playbook.load("../../test/playbooks/loops/for.yaml", loader=None)
    assert len(pb._entries) == 1
    play = pb.get_entries()[0]
    assert isinstance(play, Play)
    assert len(play._entries) == 1
    block = play.get_entries()[0]
    assert isinstance(block, Block)
    assert len(block._entries) == 5
    for task in block._entries:
        assert isinstance(task, Task)
        # all tasks

# Generated at 2022-06-21 01:29:15.281975
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    test taggable class
    """
    base = Taggable()

    assert(base.tags == [])

    base = Taggable(tags=3)

    assert(base.tags == [3])

    base = Taggable(tags='1, 2, 3')

    assert(base.tags == ['1', '2', '3'])

    base = Taggable(tags=['1', '2', '3'])

    assert(base.tags == ['1', '2', '3'])

    base = Taggable(tags=['1', '2', '3'])
    base._load_tags('tags', '4, 5, 6')

    assert(base.tags == ['1', '2', '3', '4', '5', '6'])

# Generated at 2022-06-21 01:29:19.851438
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    t = Task()
    if len(t.tags) != 0:
        raise  RuntimeError("Failed to create Taggable object (tags attribute)")

# Generated at 2022-06-21 01:29:25.825797
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test evaluate_tags method of class Taggable '''
    import unittest

    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    class TaggableTest(unittest.TestCase):
        def test_evaluate_tags(self):
            taggable = MockTaggable([])
            self.assertEqual(True, taggable.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars=None))
            taggable = MockTaggable([])
            self.assertEqual(False, taggable.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars=None))
            taggable = MockTaggable(['tag1'])
            self.assertE

# Generated at 2022-06-21 01:30:02.162791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    A test using mock objects to check that the method evaluate_tags
    of class Taggable works as expected.
    """
    from ansible.playbook.task import Task

    class MockTask(Task, Taggable):
        pass

    task = MockTask()

    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    task.tags = ['always']
    assert task.evaluate_tags(None, None, all_vars)

    task.tags = ['untagged']
    assert task.evaluate_tags(None, None, all_vars)

    task.tags = ['never']
    assert task.evaluate_tags(None, None, all_vars)

    # "should_run" is expected to be True

# Generated at 2022-06-21 01:30:13.807397
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    tags = ['untagged']
    t.tags = tags
    assert True == t.evaluate_tags(['all'], [], {})

    tags = ['untagged']
    t.tags = tags
    assert False == t.evaluate_tags(['tagged'], [], {})

    tags = ['tag1', 'tag2', 'never']
    t.tags = tags
    assert False == t.evaluate_tags([], ['tag1', 'tag2', 'never', 'all'], {})

    tags = ['tag1', 'tag2', 'never']
    t.tags = tags
    assert False == t.evaluate_tags(['tag2', 'tag3'], ['tag1', 'tag2', 'never', 'all'], {})


# Generated at 2022-06-21 01:30:20.945594
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    t = TaskInclude()

    t.tags = ['test']
    assert t.evaluate_tags(['test'], [], {})
    assert t.evaluate_tags(['test'], [], {'test': 'test'})
    assert not t.evaluate_tags([], ['test'], {})
    assert not t.evaluate_tags([], ['test'], {'test': 'test'})

    t.tags = ['always']
    assert t.evaluate_tags([], ['always'], {})
    assert t.evaluate_tags([], ['always'], {'test': 'test'})

    t.tags = ['never']
    assert t.evaluate_tags(['never'], [], {})

# Generated at 2022-06-21 01:30:26.251283
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags(None, 'one, two, three') == ['one', 'two', 'three']
    assert t._load_tags(None, ['one', 'two', 'three']) == ['one', 'two', 'three']

# Generated at 2022-06-21 01:30:34.313674
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    t = Taggable()
    assert t._attributes['tags'] == []
    assert not t.tags
    assert isinstance(t.tags, list)
    assert t.tags == []

    t = Taggable()
    t.load({'tags': ['foo', 'bar']})
    assert t.tags == ['foo', 'bar']

    t = Taggable()
    t.load({'tags': ['foo', 'bar']})
    assert t.tags == ['foo', 'bar']

    t = Taggable()
    t.load({'tags': 'foo,bar'})
    assert t.tags == ['foo', 'bar']

    t = Taggable()

# Generated at 2022-06-21 01:30:37.751193
# Unit test for constructor of class Taggable
def test_Taggable():
  t = Taggable()
  print(t._tags)

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:30:46.016600
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_object = Taggable()
    test_object.tags = ['test1', 'test2']
    results = test_object.evaluate_tags(only_tags=[], skip_tags=[])
    assert results == True

    test_object.tags = ['test1', 'test2']
    results = test_object.evaluate_tags(only_tags=[], skip_tags=['test1'])
    assert results == False

    test_object.tags = ['test1', 'test2']
    results = test_object.evaluate_tags(only_tags=['test1'], skip_tags=[])
    assert results == True

    test_object.tags = ['test1', 'test2', 'always']
    results = test_object.evaluate_tags(only_tags=['test1'], skip_tags=[])

# Generated at 2022-06-21 01:30:57.385533
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    # Defining mock object with tags field
    object_with_tags = Task()
    object_with_tags.tags = ['tag1', 'tag2', 'tag3']

    # Case 1:
    #   Tags specified:
    #       skip_tags = None
    #       only_tags = ['tag0', 'tag1', 'tag2', 'all']
    #   Expectation:
    #       should_run = True
    skip_tags = None
    only_tags = ['tag0', 'tag1', 'tag2', 'all']
    should_run = object_with_tags.evaluate_tags(only_tags, skip_tags, {})
    assert should_run is True

    # Case 2:
    #   Tags specified:
    #       skip_tags = None


# Generated at 2022-06-21 01:31:03.485339
# Unit test for constructor of class Taggable
def test_Taggable():
    play = Taggable()
    assert play._tags == []
    assert type(play.tags) is list
    play.tags = ['a', 'b']
    assert play.tags == ['a', 'b']
    play.tags += ['c', 'd']
    assert play.tags == ['a', 'b', 'c', 'd']
    play.tags += 'e'
    assert play.tags == ['a', 'b', 'c', 'd', 'e']
    play.tags += ['e', 'f', 'e']
    assert play.tags == ['a', 'b', 'c', 'd', 'e', 'f', 'e']

# Generated at 2022-06-21 01:31:10.540801
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    to run individually:
    python -m test.unit.playbook.test_Taggable_evaluate_tags
    '''
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    import os

    all_vars = dict(os.environ, **{'user': os.environ['USER']})

    obj = Task(name='foo')
    assert obj.evaluate_tags(['ok'], ['notok'], all_vars)

    obj.tags = ['ok']
    assert obj.evaluate_tags(['ok'], ['notok'], all_vars)

    obj.tags = ['notok']
    assert not obj.evaluate_tags(['ok'], ['notok'], all_vars)

    obj.tags = ['ok']

# Generated at 2022-06-21 01:32:08.910580
# Unit test for constructor of class Taggable
def test_Taggable():
    n = Taggable()
    assert n._load_tags(None, "a,b,c,d") == ['a','b','c','d']

# Generated at 2022-06-21 01:32:17.640146
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    class MyTaggable(Taggable):
        pass

    #check task only_tags with tag not in tags
    t = Task()
    m = MyTaggable()
    setattr(m, 'tags', ['tag1'])
    t.only_tags = ['tag2']
    should_run = m.evaluate_tags(t.only_tags, t.skip_tags, {})
    assert not should_run, 'Task should not run because of only_tags'

    #check task only_tags with tag in tags
    t = Task()
    m = MyTaggable()
    setattr(m, 'tags', ['tag1'])
    t.only_tags

# Generated at 2022-06-21 01:32:19.664335
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-21 01:32:29.638354
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    print("Tags: %s" % ta.tags)
    print("Tags type: %s" % type(ta.tags))
    ta.tags = ['dev', 'test']
    print("Tags: %s" % ta.tags)
    print("Tags type: %s" % type(ta.tags))
    ta.tags = ['qa', 'prod']
    print("Tags: %s" % ta.tags)
    print("Tags type: %s" % type(ta.tags))

'''
test_Taggable()
'''

# Generated at 2022-06-21 01:32:36.984950
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags("tag1,tag2,tag3", "tag1,tag2,tag3") == ['tag1', 'tag2', 'tag3']
    assert t._load_tags("tag1,tag2,tag3", ["tag1", "tag2", "tag3"]) == ['tag1', 'tag2', 'tag3']
    try:
        t._load_tags("tag1,tag2,tag3", 123)
        raise AssertionError("123 is not a list or string")
    except AnsibleError:
        pass
    try:
        t._load_tags("tag1,tag2,tag3", "123")
        raise AssertionError("tags are not a comma separated list")
    except AnsibleError:
        pass

# Generated at 2022-06-21 01:32:43.741439
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

  # test case with all tags
  t1 = Taggable()
  t1.tags = ['tag1','tag2','tag3']
  assert t1.evaluate_tags(only_tags=['tag2','tag3'], skip_tags=[], all_vars={}) == True

  # test case with no tags
  t2 = Taggable()
  t2.tags = []
  assert t2.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

  # test case with only_tags "all"
  t3 = Taggable()
  t3.tags = ['tag1','tag2']
  assert t3.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True

  # test case with skip_tags "all"

# Generated at 2022-06-21 01:32:44.140102
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-21 01:32:54.109460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.plugins.loader as loader_pkg
    import ansible.playbook.play_context
    import ansible.playbook.play

    loader_pkg._find_plugin_file = lambda p, f: None  # Dummy function
    loader_pkg._get_all_plugin_loaders = lambda: []
    mock_loader = loader_pkg.PluginLoader('')
    mock_loader.paths = []
    mock_loader.package = None
    loader_pkg._all_plugin_loaders.append(mock_loader)

    play_context = ansible.playbook.play_context.PlayContext()
    play_context.only_tags = ['my_tag']
    play_context.skip_tags = ['never']

    play = ansible.playbook.play.Play()
    play._play_context = play

# Generated at 2022-06-21 01:33:05.189868
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        pass
    check = DummyTaggable()
    assert check.evaluate_tags(["test1"], [], {}) is True
    assert check.evaluate_tags(["test1"], ["test1"], {}) is False
    assert check.evaluate_tags(["test1", "test2"], ["test2"], {}) is True
    assert check.evaluate_tags(["test1", "test2"], ["test3"], {}) is True
    assert check.evaluate_tags(["test1", "test2"], ["test1", "test2"], {}) is False
    assert check.evaluate_tags(["all", "test2"], ["test2"], {}) is True
    assert check.evaluate_tags(["all", "test2"], ["test3"], {}) is True
    assert check.evaluate_

# Generated at 2022-06-21 01:33:14.587212
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Note that these tests are not really exhaustive but just a start
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Test 1, with only_tags set
    # Based on https://github.com/ansible/ansible/issues/10673
    # and http://stackoverflow.com/questions/40509569/ansible-2-2-0-only-tags-does-not-work-as-expected-for-roles-and-includes
    task1 = Task()
    task1.tags.extend(['foo', 'bar'])
    pc = PlayContext(only_tags=['foo', 'nonesuch'])
    assert task1.evaluate_tags(pc.only_tags, pc.skip_tags, dict())

    # Test 2, with