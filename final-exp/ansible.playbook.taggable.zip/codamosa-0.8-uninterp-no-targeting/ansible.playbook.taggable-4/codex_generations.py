

# Generated at 2022-06-21 01:24:38.018009
# Unit test for constructor of class Taggable
def test_Taggable():
    import os
    import sys
    sys.path.insert(0, os.path.abspath('.'))
    from ansible import constants
    from ansible.playbook.base import Base

    raise NotImplementedError()

    base = Base()
    base.only_tags = {'tag1', 'tag2'}

    tags = ['tag1', 'tag2']
    assert base._should_run_task(tags) == True

    tags = ['tag1', 'tag2', 'tagged']
    assert base._should_run_task(tags) == False

    base.only_tags.add('tagged')
    assert base._should_run_task(tags) == True



# Generated at 2022-06-21 01:24:39.340956
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    assert test_obj._tags == list

# Generated at 2022-06-21 01:24:41.747183
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable() is not None

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-21 01:24:54.799362
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()
    
    only_tags = ['tag1', 'tag2', 'tag3', 'all', 'tagged']
    skip_tags = ['tag4', 'tag5', 'tag6', 'all', 'tagged']
    all_vars = {}
    tags = ''
    # Case 1 : tags is a list
    tags = ['tag1', 'tag2', 'tag3']
    assert(task.evaluate_tags(only_tags, skip_tags, all_vars) == False)
    # Case 2 : tags is a list
    tags = ['tag4', 'tag5', 'tag6']
    assert(task.evaluate_tags(only_tags, skip_tags, all_vars) == False)
    # Case 3 : tags is a list
    tags

# Generated at 2022-06-21 01:25:02.333256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar


# Generated at 2022-06-21 01:25:14.671875
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    import ansible.errors as ans_errors
    from ansible.vars import VariableManager, HostVars
    from ansible.module_utils.six import string_types

    class Bunch(dict):
        def __getattr__(self, key):
            return self[key]
        def __setattr__(self, key, value):
            self[key] = value

    h = Bunch()
    h.tags = ['a', 'b', 'c']
    hvars = Bunch()
    hvars.hostvars = dict()

    h.variable_manager = VariableManager()
    h.variable_manager.set_host_variable(h, hvars)


# Generated at 2022-06-21 01:25:19.530823
# Unit test for constructor of class Taggable
def test_Taggable():
    testTaggable = Taggable()
    assert testTaggable.tags == []
    assert testTaggable._load_tags('foo', []) == []
    assert testTaggable._load_tags('foo', "a,b") == ['a', 'b']

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:25:26.838537
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:25:35.749363
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy:
        tags = ['foo', 'bar', 'baz']
        untagged = ['untagged']

        def __init__(self, loader):
            self._loader = loader

    obj = Dummy(None)
    # Test what happens when
    # 1. only_tags is none
    # 2. there are no only_tags
    # 3. there are some only_tags and they are in the obj.tags
    # 4. there are some only_tags and none of them is in the obj.tags
    # 5. there are tags, skip_tags and all of the skip_tags are there

    # Test 1.
    assert obj.evaluate_tags(None, None, None)

    # Test 2.
    assert obj.evaluate_tags(set(), set(), None)

    # Test 3.
    assert obj.evaluate_

# Generated at 2022-06-21 01:25:42.679577
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert ta._load_tags('_tags', []) == []
    assert ta._load_tags('_tags', 'mytag') == ['mytag']
    assert ta._load_tags('_tags', 'mytag, mytag2') == ['mytag', 'mytag2']
    assert ta._load_tags('_tags', ['mytag','mytag2']) == ['mytag','mytag2']

# Generated at 2022-06-21 01:25:59.394476
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable:
        def __init__(self,tags):
            self.tags = tags
    taggable = TestTaggable(tags=['test1','test2'])
    assert(taggable.evaluate_tags(only_tags=['test1','test2','test3'],skip_tags=[],all_vars=None) == True)
    assert(taggable.evaluate_tags(only_tags=['test3','test4'],skip_tags=[],all_vars=None) == False)
    assert(taggable.evaluate_tags(only_tags=[],skip_tags=['test1','test2','test3'],all_vars=None) == True)

# Generated at 2022-06-21 01:26:08.133480
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    block_tags = ['tag_name']
    task_tags = ['tag_name1']
    untagged_tags = frozenset(['untagged'])
    untagged_task_tags = []
    tagged_task_tags = ['tag_name1','tag_name2','tag_name3']
    mixed_tags = ['tag_name1','tag_name2','tag_name3','never']
    tagged_task_matched_tags = ['all','tag_name1']

    play_context = PlayContext()
    # Case 1: block_tags = ['tag_name'], task_tags = ['tag_name1'], only_tags = [], skip_tags = [] -- should return True

# Generated at 2022-06-21 01:26:20.103506
# Unit test for constructor of class Taggable
def test_Taggable():
    import unittest

    class TestTaggable(unittest.TestCase):
        
        def setUp(self):
            self.attr_name='tags'
            self.attr_default=[]
            self.attr_listof=string_types
        
        def tearDown(self):
            pass
        
        def test_load_tags_list(self):
            expected = ['test1', 'test2']
            actual = Taggable._load_tags(self, self.attr_name, expected)
            self.assertEqual(expected, actual)
        
        def test_load_tags_string(self):
            expected = ['test1', 'test2']
            actual = Taggable._load_tags(self, self.attr_name, "test1, test2")

# Generated at 2022-06-21 01:26:28.940029
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import collections

    # Task:
    task = Task()
    task.tags = ['tag1', 'tag2', 'tag3']
    assert type(task.tags) == list
    assert len(task.tags) == 3
    # Role:
    role = Role()
    role.tags = ['tag1', 'tag2', 'tag3']
    assert type(role.tags) == list
    assert len(role.tags) == 3
    # Play:
    play = Play()
    play.tags = ['tag1', 'tag2', 'tag3']
    assert type(play.tags) == list

# Generated at 2022-06-21 01:26:41.136778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.module_utils.six import PY3
    task = TaskInclude()
    print(task.evaluate_tags(only_tags = ['tag1','tag2','tag3'], skip_tags = ['tag4','tag5','tag6'], all_vars = dict(foo='bar')))
    if not PY3:
        task = TaskInclude()
        task.tags = u'foo'
        print(task.evaluate_tags(only_tags = ['foo'], skip_tags = ['foo'], all_vars = dict(foo='bar')))
        task.only_tags = 'baz'
        task.skip_tags = 'baz'

# Generated at 2022-06-21 01:26:52.896475
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    mock_self = AnsibleBaseYAMLObject()
    mock_self._loader = None
    mock_self.tags = None
    mock_self.untagged = ('untagged',)

    # test normal condition
    mock_self.tags = ['foo', 'bar']
    only_tags = set('foo,bar,all'.split(','))
    skip_tags = set('skip,foo,bar'.split(','))

    # test condition when tags is None
    only_tags = set('all'.split(','))

# Generated at 2022-06-21 01:27:03.658946
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    import ansible.module_utils.six as six

    # Initialize an instance of Taggable
    test_taggable = Base()

    # Initialize only_tags attribute
    test_taggable.only_tags = ["all"]

    # Initialize skip_tags attribute
    test_taggable.skip_tags = ["never"]

    # Initialize a default tags attribute
    test_taggable.tags = [""]

    # Import necessary modules to test Taggable class
    # AnsibleError, FieldAttribute, isinstance, Template

    # Testcase 1: tags is a list but evaluate_tags() method
    # should return False because the tags attribute is not
    # set and there are no tags passed in.

# Generated at 2022-06-21 01:27:05.362139
# Unit test for constructor of class Taggable
def test_Taggable():
    print(Taggable()._tags)

# Constructor test
test_Taggable()

# Generated at 2022-06-21 01:27:12.624432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Testing method evaluate_tags of class Taggable")

    class FakeTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    # Test with no only_tags
    t = FakeTaggable()
    # Test with no skip_tags
    t.tags = ['tagged']
    assert t.evaluate_tags([], [], {}) == True
    t.tags = ['never']
    assert t.evaluate_tags([], [], {}) == False
    t.tags = ['always']
    assert t.evaluate_tags([], [], {}) == True
    t.tags = ['never', 'always']
    assert t.evaluate_tags([], [], {}) == True
    t.tags = ['never', 'never']
    assert t.evaluate_

# Generated at 2022-06-21 01:27:15.179023
# Unit test for constructor of class Taggable
def test_Taggable():
    class test(Taggable):
        pass
    t = test()
    assert (t._tags == list)


# Generated at 2022-06-21 01:27:29.319829
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj is not None

# Generated at 2022-06-21 01:27:32.897983
# Unit test for constructor of class Taggable
def test_Taggable():
    inj = dict(
        _loader = None,
    )
    t = Taggable(**inj)
    assert isinstance(t, Taggable)
    assert isinstance(t._loader, type(None))

test_Taggable()

if __name__ == '__main__':
    # Unit test for Taggable class
    test_Taggable()

    print('Done')

# Generated at 2022-06-21 01:27:44.995781
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    mt = MyTaggable()
    mt.tags = ['untagged']

    only_tags = ['all']
    skip_tags = []
    
    # Simple test
    assert(True == mt.evaluate_tags(only_tags, skip_tags, {}))
    assert(False == mt.evaluate_tags(skip_tags, only_tags, {}))

    # Untagged, only_tags
    only_tags = ['all']
    skip_tags = []
    assert(True == mt.evaluate_tags(only_tags, skip_tags, {}))
    
    # Tagged
    mt.tags = ['one']
    assert(True == mt.evaluate_tags(only_tags, skip_tags, {}))

# Generated at 2022-06-21 01:27:54.376132
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # These are set for the task, and have specific results:
    #  - when tags are None, the result must be True
    #  - when only_tags contains 'never', the result must be False
    #  - when skip_tags contains 'never', the result must be True
    #  - when the tags are ['foo'], the result depends on the content of
    #    only_tags and skip_tags
    # Set below is a list of only_tags and skip_tags values, with expected
    # results. Note that a run with

# Generated at 2022-06-21 01:28:04.880706
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    import ansible.executor.task_queue_manager
    import ansible.plugins.loader
    import ansible.callbacks
    import ansible.utils.display

    ansible.plugins.loader._find_plugins()
    ansible.executor.task_queue_manager._create_global_task_queue_manager()
    ansible.utils.display.Display().verbosity = 2

    # Base class
    obj = Base()
    assert isinstance(obj, Base)
    assert obj.tags == []

# Generated at 2022-06-21 01:28:12.558191
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockClass:

        tags = []

        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

    class MockLoader:

        def __init__(self):
            pass

        def get_basedir(self):
            return ''

    # Only-tags
    mock_class = MockClass()
    mock_class.tags = ['test_tag']
    assert mock_class.evaluate_tags(['test_tag'], [], dict())

    mock_class.tags = ['test_tag']
    assert not mock_class.evaluate_tags(['not_test_tag'], [], dict())

    mock_class.tags = ['test_tag']
    assert mock_class.evaluate_tags

# Generated at 2022-06-21 01:28:14.766897
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ['tag1', 'tag2']
    t2 = eval(repr(t))
    assert t2._tags == ['tag1', 'tag2']

# Generated at 2022-06-21 01:28:22.900350
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Task(Taggable):
        # a task can have a module, a handler, etc.
        # but we just need to init the tags
        def __init__(self, tags=None):
            self.tags = tags

    test_task = Task(tags=['test_tag'])

    # nothing in skip_tags, 'always' in tags, only_tags does not matter
    assert test_task.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    assert test_task.evaluate_tags(only_tags=['not_always'], skip_tags=None, all_vars={})
    assert test_task.evaluate_tags(only_tags=['test_tag', 'not_always'], skip_tags=None, all_vars={})

    # 'always' in skip

# Generated at 2022-06-21 01:28:34.769522
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create objects
    item = Taggable()
    item.tags = ['all']
    all_vars = {}

    # Test evaluate_tags for default values of parameters
    should_run = item.evaluate_tags(None, None, all_vars)
    assert should_run == True, "should_run (expected: True) was: " + str(should_run)

    # Test evaluate_tags with only_tags and skip_tags being None
    should_run = item.evaluate_tags(None, None, all_vars)
    assert should_run == True, "should_run (expected: True) was: " + str(should_run)

    # Test evaluate_tags with only_tags not None and skip_tags being None
    only_tags = ['all']

# Generated at 2022-06-21 01:28:40.446889
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags('field', ['foo','bar','baz']) == ['foo','bar','baz']
    assert t._load_tags('field', 'foo,bar,baz') == ['foo', 'bar', 'baz']

# Generated at 2022-06-21 01:29:15.655058
# Unit test for constructor of class Taggable
def test_Taggable():
    loader_mock = Mock()
    variable_manager_mock = Mock()
    templar_object = Templar(loader=loader_mock, variable_manager=variable_manager_mock)
    variable_manager_mock.extra_vars = None
    variable_manager_mock.options = Mock()
    variable_manager_mock.set_available_variables = variable_manager_mock
    variable_manager_mock.get_vars = variable_manager_mock
    variable_manager_mock.get_hostvars = variable_manager_mock
    variable_manager_mock.get_group_vars = variable_manager_mock
    variable_manager_mock.allvars = None
    task_mock = Mock()

# Generated at 2022-06-21 01:29:25.508663
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    def make_tags(tag_list):
        tags = set()
        for tag in tag_list:
            if isinstance(tag, list):
                tags.update(tag)
            else:
                tags.add(tag)
        return list(tags)

    assert MockTaggable(make_tags(['tag1', 'tag2'])).evaluate_tags(['tag1'], [], {})

    assert not MockTaggable(make_tags(['tag1', 'tag2'])).evaluate_tags(['tag3'], [], {})


# Generated at 2022-06-21 01:29:28.008136
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable() # default value of _tags is list
    assert a._tags == []


# Generated at 2022-06-21 01:29:36.300305
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    tag_list = ['foo','bar']

    o = MockTaggable()
    o.tags = tag_list
    assert o.evaluate_tags(['foo','bar'],['never', 'notag'],{})
    assert o.evaluate_tags(['foo','bar'],['foo'],{})
    assert not o.evaluate_tags(['foo','bar'],['bar'],{})
    assert o.evaluate_tags(['all'],['never', 'notag'],{})
    assert not o.evaluate_tags(['all'],['foo'],{})

# Generated at 2022-06-21 01:29:44.476328
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        pass
    taggable = DummyTaggable()
    taggable.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag1', 'tag4']
    skip_tags = ['tag4', 'tag5']
    all_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable.tags = ['always']
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable.tags = ['never']
    only_tags = ['never']
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable.tags = ['never']
   

# Generated at 2022-06-21 01:29:55.015532
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    # setup test vars
    test_vars = dict()
    test_vars['test_var'] = "foo"

    # Setup a task to test with
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    test_task = Task()
    test_task.context = 'test_task'
    test_task.vars = test_vars
    test_task.args = dict()
    test_task.action = 'test_task_action'
    test_task.name = 'test_task_name'
    test_task.ignore_errors = False
    test_task.register = 'test_task_register'
    test_task

# Generated at 2022-06-21 01:30:03.722907
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import Include
    from ansible.playbook.task.task import Task

    task = Task()
    task._load_tags('tags', ['f1'])
    assert task.tags == ['f1']
    task._load_tags('tags', "f1")
    assert task.tags == ['f1']

    assert task._load_tags('tags', 'f1, f2') == ['f1', 'f2']
    assert task._load_tags('tags', ['f1', 'f2', 'f3']) == ['f1', 'f2', 'f3']

    include = Include()
    include._load_tags('tags', ['f1'])
    assert include.tags == ['f1']
    include._load_tags('tags', "f1")

# Generated at 2022-06-21 01:30:09.687466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.playbook.task as task
    import ansible.playbook.role as role
    import ansible.playbook.block as block
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    play_context.only_tags = frozenset(["all"])
    play_context.skip_tags = frozenset(["skip_me"])
    
    # play contains only tags but no specific tags.
    play = task.Task(play_context=play_context)
    assert(play.evaluate_tags(only_tags=play_context.only_tags, skip_tags=play_context.skip_tags, all_vars={}))
    
    # play contains only tags but also a specific tag
    play.tags = ["test"]

# Generated at 2022-06-21 01:30:17.071294
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook as playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role


# Generated at 2022-06-21 01:30:26.311271
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=True, always_run=False, vars_prompt=None, bypass_tags=None)
    task = Task(block=block, data={})
    task.tags = ['4','5','7','8']
    task.always_run = True
    assert task.evaluate_tags('always', 'never', {}) == True
    assert task.evaluate_tags(['0','1','2','3'], ['0','1','2','3'], {}) == False
    assert task.evaluate_tags(['4','5','6'], [], {}) == True
    assert task.evaluate_

# Generated at 2022-06-21 01:31:22.500497
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []


# Generated at 2022-06-21 01:31:33.523370
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task

    t = Task()
    t.tags = ['foo']

    assert(t.evaluate_tags(set(), set(), {}) == True)
    assert(t.evaluate_tags(set(['foo']), set(), {}) == True)
    assert(t.evaluate_tags(set(['foo', 'bar']), set(), {}) == True)
    assert(t.evaluate_tags(set(['bar']), set(), {}) == False)
    assert(t.evaluate_tags(set(['bar', 'baz']), set(), {}) == False)
    assert(t.evaluate_tags(set(['bar', 'baz', 'foo']), set(), {}) == True)

# Generated at 2022-06-21 01:31:34.403794
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True

# Generated at 2022-06-21 01:31:44.448565
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    pb = Playbook.load(playbook, variable_manager=variable_manager, loader=loader)
    play = pb.get_plays()[0]
    play._variable_manager = variable_manager
    play_context = PlayContext(play=play)
    # play_context._become is a Become object
    play_context._become = Become()

# Generated at 2022-06-21 01:31:53.836336
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ele = Taggable()

    # Testing for default value of only_tags
    only_tags = None
    skip_tags = None
    all_vars = {}
    ele.tags = []
    assert ele.evaluate_tags (only_tags, skip_tags, all_vars)

    # Testing for tags when only_tags is empty
    only_tags = []
    skip_tags = []
    ele.tags = []
    assert not ele.evaluate_tags (only_tags, skip_tags, all_vars)

    # Testing for tags when only_tags is a list
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    ele.tags = []
    assert not ele.evaluate_tags (only_tags, skip_tags, all_vars)

    # Testing for tags when only_tags

# Generated at 2022-06-21 01:32:03.617297
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import io
    from ansible.playbook.play_context import PlayContext

    vars = dict()
    play_context = PlayContext(play=None, options=None, variable_manager=None, loader=None)

    # test case with only_tags = None and skip_tags = None
    test_obj1 = Taggable()
    test_obj1.tags = ['test1','test2','test3']
    result1 = test_obj1.evaluate_tags(only_tags=None, skip_tags=None, all_vars=vars)
    assert result1 == True

    # test case with only_tags = ['always'] and skip_tags = None
    test_obj2 = Taggable()
    test_obj2.tags = ['test1','test2','test3']
    result2 = test

# Generated at 2022-06-21 01:32:14.829375
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMixIn(Taggable):
        pass

    class Task(TaggableMixIn):
        _tags = FieldAttribute(isa='list', default=list, listof=string_types, extend=True)

        def __init__(self, tags):
            self.tags = tags

    # Please note that all tests are written for Python version 2.7
    test_Taggable_evaluate_tags.assertEqual = __builtins__['assertEqual']

    # Assert that a task without tags runs
    task = Task(tags=[])
    test_Taggable_evaluate_tags.assertEqual(True, task.evaluate_tags([], [], {}))

    # Assert that a task with tags runs
    task = Task(tags=['important'])
    test_Taggable_evaluate_tags.assertEqual

# Generated at 2022-06-21 01:32:23.416391
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        _tags = None

    only_tags = ['test', 'ansible', 'python']
    skip_tags = ['java', 'golang']

    all_vars = dict()
    all_vars['my_tags'] = ['test', 'ansible', 'python']

    taggable = MockTaggable()

    taggable.tags = ['test', 'ansible', 'python', 'java']
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False

    taggable.tags = ['ansible', 'python', 'java', 'golang']
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False


# Generated at 2022-06-21 01:32:32.593588
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def get_loader(self, play=None):
            return None

    # Test 1 - Test default 'should_run' behavior
    tt = TestTaggable()
    tt.tags = []
    tt.only_tags = set()
    tt.skip_tags = set()
    assert tt.evaluate_tags(tt.only_tags, tt.skip_tags, dict())

    # Test 2 - Test evaluate_tags method with 'only_tags' with 'all'
    tt = TestTaggable()
    tt.tags = []
    tt.only_tags = set()
    tt.only_tags.add('all')
    tt.skip_tags = set()

# Generated at 2022-06-21 01:32:42.958636
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys
    from collections import namedtuple

    # named tuple for the tags:
    tags_tuple = namedtuple('tags',['tags','only_tags','skip_tags','expected_result'])

    # List of tags (untagged tasks) to test: