

# Generated at 2022-06-21 01:24:38.767441
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook import Task
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    results_callback = TaskQueueManager._results_callback
    display = Display()

# Generated at 2022-06-21 01:24:41.059315
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == [], 'Tags should empty list as default'

# Generated at 2022-06-21 01:24:53.789755
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['a', 'b', 'c']
    only_tags = ['a', 'c', 'd']
    all_vars = dict()

    should_run = True  # default, tasks to run

    if only_tags:
        if 'always' in tags:
            should_run = True
        elif ('all' in only_tags and 'never' not in tags):
            should_run = True
        elif not tags.isdisjoint(only_tags):
            should_run = True
        elif 'tagged' in only_tags and tags != untagged and 'never' not in tags:
            should_run = True
        else:
            should_run = False


# Generated at 2022-06-21 01:25:01.753904
# Unit test for constructor of class Taggable
def test_Taggable():
    import ansible.playbook.block
    import ansible.playbook.task_include
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-21 01:25:12.103862
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()
    task.tags = ['foo', 'bar', 'bat']

    assert task.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) is False
    assert task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={}) is True
    assert task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=['foo'], all_vars={}) is False
    assert task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=['bar'], all_vars={}) is True

# Generated at 2022-06-21 01:25:21.857805
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    task = Task()
    if task.tags is not None:
        raise Exception ("task Tags should be None at construction time")
    if task._load_tags('', 'test') != ['test']:
        raise Exception ("_load_tags should return ['test']")
    if task._load_tags('', ['test1','test2']) != ['test1','test2']:
        raise Exception ("_load_tags should return ['test1','test2']")
    try:
        task._load_tags('', 1)
    except AnsibleError:
        pass
    else:
        raise Exception ("should raise an exception because 1 is not a list nor a string")

# Generated at 2022-06-21 01:25:32.870893
# Unit test for constructor of class Taggable
def test_Taggable():
    """
      This test case is to test the constructor of the class Taggable.
    """
    try:
        import ansible.playbook.task
        from ansible.playbook.task import Task
        from ansible.template import Templar
    except ImportError as e:
        print("failed=True msg='{0}'".format(e))

    task = Task()

    task._tags = [ 'tag1', 'tag2' ]

    # test tag initialization with a list
    data = [ 'tag2', 'tag3' ]
    task._load_tags(None, data)
    assert task._tags == data
    assert task.tags == data

    # test tag initialization with a string
    data = 'tag3, tag4'
    task._load_tags(None, data)

# Generated at 2022-06-21 01:25:43.994193
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        def __init__(self, a, b, c, d, e, f):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f
    mt = MyTaggable(a="a", b="b", c="c", d="d", e="e", f="f")
    assert mt.a == "a"
    assert mt.b == "b"
    assert mt.c == "c"
    assert mt.d == "d"
    assert mt.e == "e"
    assert mt.f == "f"

# Generated at 2022-06-21 01:25:53.075902
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory
    from ansible.playbook.task import Task

    class TestTaggable(Taggable):
        def __init__(self, tags=None):
            self._tags = tags

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    task = Task()
    task.hosts = inventory.get_hosts()
    task.variable_manager = variable_manager

    test_taggable = TestTaggable(['always'])

# Generated at 2022-06-21 01:26:04.205917
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.boolean import boolean

    class Dummy(Base):
        pass

    variable_manager = VariableManager()
    templar = Templar(loader=None, variable_manager=variable_manager)

    variable_manager.extra_vars = {'foo': 'bar'}

    # Test with no extra options
    variable_manager.options = {}
    d = Dummy(dict(tags=['tag1']), variable_manager=variable_manager, loader=None)
    assert boolean(d.evaluate_tags(only_tags=[], skip_tags=[], all_vars=variable_manager._hostvars['inventory_hostname']), strict=False)

    # Test with only_tags

# Generated at 2022-06-21 01:26:24.784237
# Unit test for constructor of class Taggable
def test_Taggable():

    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    my_playbook = Playbook()
    my_playbook.vars_manager = VariableManager()
    my_playbook.loader = DataLoader()
    my_playbook.inventory = InventoryManager(loader=my_playbook.loader, sources=my_playbook.inventory_sources)
    my_playbook.exduct_facts = {}
    my_playbook.options = Play()

    my_playbook.options.only_tags = []
    my_playbook.options.skip_tags = []

    taggable = Taggable()


# Generated at 2022-06-21 01:26:37.511334
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self._tags = tags

    assert FakeTaggable([]).evaluate_tags(set(), set(), {})
    assert not FakeTaggable([]).evaluate_tags(set(['all']), set(), {})
    assert FakeTaggable(['all']).evaluate_tags(set(['all']), set(), {})
    assert FakeTaggable(['all']).evaluate_tags(set(['tagged']), set(), {})
    assert FakeTaggable(['tagged']).evaluate_tags(set(['tagged']), set(), {})
    assert not FakeTaggable([]).evaluate_tags(set(['tagged']), set(), {})

# Generated at 2022-06-21 01:26:42.839080
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    all_tags = ['a1', 'a2', 'a3', 'a4', 'a5']

    t.tags = all_tags
    print(t.tags)
    # Following test method should return true with all the tags lists
    print(t.evaluate_tags(['a1', 'a3'], ['a2', 'a4', 'a5'], {'a':'1', 'b':'2', 'c':'3'}))

    # This will return true as a5 has never, even through a5 is in skip_tags
    print(t.evaluate_tags(['a1', 'a3'], ['a2', 'a4', 'a5', 'never'], {'a':'1', 'b':'2', 'c':'3'}))

    # This

# Generated at 2022-06-21 01:26:54.450585
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    my_taggable_untagged = MyTaggable()
    my_taggable_tagged = MyTaggable()
    my_taggable_tagged._tags = [ 'tag1' ]

    # Tasks with no tag defined should run always
    assert my_taggable_untagged.evaluate_tags(['always'], [], {}) == True

    # Tasks with no tag defined should not run never
    assert my_taggable_untagged.evaluate_tags(['never'], [], {}) == False

    # Tasks with tag1 defined should run when tag1 is provided
    assert my_taggable_tagged.evaluate_tags(['tag1'], [], {}) == True

    # Tasks with tag1 defined should not run never


# Generated at 2022-06-21 01:27:05.041146
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.included_file import IncludedFile

    t = Taggable()
    assert t._tags == []

    t = Taggable()
    t.tags = ['end_tag']
    assert t._tags == ['end_tag']

    t = Taggable()
    t.tags = []
    assert t._tags == []

    t = Taggable()
    t.tags = ['end_tag']
    t.tags.append('new_tag')

# Generated at 2022-06-21 01:27:06.099367
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Returns: a new instance of Taggable, for unit testing only.
    """
    return Taggable()

# Generated at 2022-06-21 01:27:08.008337
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    assert x.tags == []
    assert set(x.untagged) == set(['untagged'])

# Generated at 2022-06-21 01:27:17.990975
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    # skip_tags and all_vars are unused, they are only there to match the signature of the method

    t = Taggable()

    # tasks with 'always' in tags should always run
    t.tags = ['always']
    assert (t.evaluate_tags([], [], {}) == True)
    assert (t.evaluate_tags(['always'], [], {}) == True)
    assert (t.evaluate_tags(['never'], [], {}) == True)

    # tasks without tags should always run
    t.tags = []
    assert (t.evaluate_tags([], [], {}) == True)
    assert (t.evaluate_tags(['always'], [], {}) == True)

# Generated at 2022-06-21 01:27:19.429962
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == list()


# Generated at 2022-06-21 01:27:20.820503
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-21 01:27:46.714889
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert set(t._load_tags(None, ['a', 'b'])) == set(['a', 'b'])
    assert set(t._load_tags(None, 'a, b')) == set(['a', 'b'])
    assert set(t._load_tags(None, 'a,b')) == set(['a', 'b'])
    assert t._load_tags(None, 'a') == ['a']
    assert t._load_tags(None, '"a"') == ['a']
    try:
        t._load_tags(None, {})
        raise Exception("Unreachable code")
    except:
        pass
    try:
        t._load_tags(None, None)
        raise Exception("Unreachable code")
    except:
        pass

# Generated at 2022-06-21 01:27:54.762787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable.evaluate_tags(Taggable, ['tag1', 'tag2'], ['tag3'], {})
    assert Taggable.evaluate_tags(Taggable, ['tag1', 'tag2'], ['tag1'], {})
    assert Taggable.evaluate_tags(Taggable, ['tag1', 'tag2'], ['tag2'], {})
    assert not Taggable.evaluate_tags(Taggable, ['tag1', 'tag2'], ['tag1', 'tag2'], {})
    assert Taggable.evaluate_tags(Taggable, ['tag1', 'tag2'], ['tag3', 'tag4'], {})


# Generated at 2022-06-21 01:28:05.681476
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task
    test_task = ansible.playbook.task.Task()
    test_task.tags = []
    print(test_task.evaluate_tags(only_tags=['my_tag_1'], skip_tags=[], all_vars={}))
    print(test_task.evaluate_tags(only_tags=['my_tag_1'], skip_tags=['my_tag_2'], all_vars={}))
    print(test_task.evaluate_tags(only_tags=['my_tag_1', 'my_tag_2'], skip_tags=['my_tag_3'], all_vars={}))

# Generated at 2022-06-21 01:28:07.330406
# Unit test for constructor of class Taggable
def test_Taggable():

    t_object = Taggable()
    t_object.tags = ['foo', 'bar']
    assert t_object.tags == ['foo', 'bar']

# Generated at 2022-06-21 01:28:16.977477
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    task = Taggable()

    # Act and Assert
    assert task.evaluate_tags(None, None, {}) == True

    # Act and Assert
    assert task.evaluate_tags(['a', 'b'], ['c', 'd'], {}) == True

    # Act
    #task.tags = set(['a', 'b'])
    task.tags = ['a', 'b']

    # Assert
    assert task.evaluate_tags(['a', 'b'], ['c', 'd'], {}) == True

    # Act
    #task.tags = set(['c', 'd'])
    task.tags = ['c', 'd']

    # Assert
    assert task.evaluate_tags(['a', 'b'], ['c', 'd'], {}) == False



# Generated at 2022-06-21 01:28:24.581567
# Unit test for constructor of class Taggable
def test_Taggable():
    # Constructor
    class MyTaggable(Taggable):
        pass

    m = MyTaggable()

    # Test default 'tags' attribute
    assert not m.tags

    # Test 'tags' attribute loading
    tags = MyTaggable._load_tags('tags', 'a, b')
    assert tags == ['a', 'b']

    # Test 'tags' attribute loading of non-lists
    tags = MyTaggable._load_tags('tags', 'a')
    assert tags == ['a']


# Generated at 2022-06-21 01:28:35.368744
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    m = MyTaggable()

    # Define some test data.
    # Each list contains a tag set, a set with the only_tags to be applied,
    # and a set with the skip_tags to be applied, and the resulting value
    # of should_run.

# Generated at 2022-06-21 01:28:38.136175
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        def __init__(self):
            super(TestTaggable,self).__init__(tags = ['tag1','tag2'])
    t = TestTaggable()
    assert t.tags == ['tag1','tag2']


# Generated at 2022-06-21 01:28:47.637546
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class t(Taggable):
        def __init__(self):
            self._tags = ['never', 'always']

    x = t()
    assert x.evaluate_tags(only_tags=set(['always', 'bar']), skip_tags=set(['never'])) is True
    assert x.evaluate_tags(only_tags=set(['always']), skip_tags=set(['never'])) is True
    assert x.evaluate_tags(only_tags=set(['always']), skip_tags=set(['never', 'always'])) is False

    y = t()
    y.tags = ['something']
    assert y.evaluate_tags(skip_tags=set(['tagged'])) is True
    assert y.evaluate_tags(skip_tags=set(['something', 'always'])) is False


# Generated at 2022-06-21 01:28:59.054541
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager.set_inventory(inventory)

    hosts = inventory.get_groups_dict()

    # test Tags
    block_data = {}
    block_data['tags'] = ['webservers', 'work']

# Generated at 2022-06-21 01:29:40.777357
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' evaluate_tags method of class Taggable '''
    # pylint: disable=protected-access,too-many-locals
    item_ = dict(
        tags=['tag1', 'tag2', 'tag3'],
        untagged=['untagged', 'tag1'],
    )
    def assert_run_no():
        ''' assert that should_run is False '''
        assert not item_.evaluate_tags(only_tags, skip_tags, all_vars)
    def assert_run_yes():
        ''' assert that should_run is True '''
        assert item_.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-21 01:29:53.462379
# Unit test for constructor of class Taggable
def test_Taggable():
    t1 = Taggable()
    # If this is Tagbabble, the next line should print out '[]'
    # print t1._tags
    # Otherwise, the next line should print out '['tag1', 'tag2']'
    t1._tags = ['tag1', 'tag2']
    print(t1._load_tags('x', ['tag1', 'tag2']))
    # The next line should print out ''
    print(t1._load_tags('x', ''))
    # The next line should print out '['tag1,tag2']'
    print(t1._load_tags('x', 'tag1,tag2'))

    # The next line should print out 'True'
    print(t1.evaluate_tags(['tag1', 'tag2'], ['tag3'], {}))
   

# Generated at 2022-06-21 01:30:02.574942
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import os
    os.environ["ANSIBLE_CONFIG"] = "tests/ansible.cfg"
    os.environ["ANSIBLE_FORCE_COLOR"] = "true"

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-21 01:30:14.405604
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableDummy(Taggable):
        def __init__(self):
            self._loader = None
            self._tags = []

    # create the instance of TaggableDummy class
    t = TaggableDummy()

    # tests goes from here
    # without tags
    assert t.evaluate_tags(only_tags=['all', 'tagged'], skip_tags=None, all_vars=None) == True

    # only_tags set to "all"
    t._tags = ['all']
    assert t.evaluate_tags(only_tags=['all', 'tagged'], skip_tags=None, all_vars=None) == True

    # only_tags set to "tagged"
    t._tags = ['tagged']

# Generated at 2022-06-21 01:30:24.177110
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    #print(os.path.abspath(os.path.dirname(__file__)))
    from ansible.playbook import Task
    from ansible.executor.task_result import TaskResult

    task = Task()
    task._role = None
    task._parent = None
    task._loader = None
    task._block = None
    task._play = None
    task._attributes = {'tags':['test_tag', 'another_tag']}

    results = TaskResult(host=None, task=task)
    underlying_results = results._result

    # single tag to run test with
    underlying_results['only_tags'] = ['test_tag']
    underlying_results['skip_tags'] = []
    underlying_results['all_vars'] = {}

    result_should_run = task

# Generated at 2022-06-21 01:30:32.679352
# Unit test for constructor of class Taggable
def test_Taggable():
    # test loading tags in tasks/handlers
    testing = Taggable()
    tags = testing._load_tags('tags', 'tag1tag2tag3')
    assert tags == ['tag1tag2tag3']
    tags = testing._load_tags('tags', ['tag1', 'tag2', 'tag3'])
    assert tags == ['tag1', 'tag2', 'tag3']
    tags = testing._load_tags('tags', 12345)
    assert tags == [12345]
    # test evaluation of tags
    # pylint: disable=unused-variable
    all_vars = dict(tags=['a','b','c'])
    # pylint: disable=attribute-defined-outside-init
    testing._loader = "dummy"
    testing.tags = ['a','b','c']
    only_

# Generated at 2022-06-21 01:30:34.478596
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()


    assert taggable._tags == list
    assert taggable.tags == list




# Generated at 2022-06-21 01:30:40.260632
# Unit test for constructor of class Taggable
def test_Taggable():
    import os
    from ansible.parsing.dataloader import DataLoader

    cur_dir = os.path.dirname(os.path.realpath(__file__))
    loader = DataLoader()
    loader.set_basedir(cur_dir)

    taggable = Taggable(None, loader)
    taggable.vars = {}

# Generated at 2022-06-21 01:30:47.502796
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class T(Taggable):
        pass

    only_tags = ['all']
    skip_tags = []
    all_vars = dict()

    # test without tags
    t = T()
    assert(t.evaluate_tags(only_tags, skip_tags, all_vars))

    # test with 'always' tags
    t = T()
    t._tags = ['always', 'test']
    assert(t.evaluate_tags(only_tags, skip_tags, all_vars))

    # test with 'never' tags
    t = T()
    t._tags = ['never', 'test']
    assert(not t.evaluate_tags(only_tags, skip_tags, all_vars))

    # test with 'never' tags and skip_tags
    t = T()

# Generated at 2022-06-21 01:30:49.398797
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    t = Task()
    assert t.tags == []

# Generated at 2022-06-21 01:31:49.962784
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(['all'],['never'],{})

# Generated at 2022-06-21 01:32:02.325399
# Unit test for constructor of class Taggable
def test_Taggable():
    test_tags = ["tag_1", "tag_2", "tag_3"]
    taggable = Taggable()
    taggable.tags = test_tags
    assert taggable._tags == test_tags
    assert taggable.tags == test_tags
    assert set(taggable.tags) == {'tag_1', 'tag_2', 'tag_3'}

    taggable = Taggable()
    taggable.tags = "tag_1, tag_2"
    assert taggable._tags == test_tags
    assert taggable.tags == test_tags
    assert set(taggable.tags) == {'tag_1', 'tag_2', 'tag_3'}

    taggable = Taggable()

# Generated at 2022-06-21 01:32:14.321518
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    pc = PlayContext()
    fake_loader = None

    # Test case 1: no tags at all
    host = Host(name="host1", port=22)
    group = Group(name="group1")
    group.hosts.append(host)
    inventory = Inventory(host_list=[host], group_list=[group], loader=fake_loader)

# Generated at 2022-06-21 01:32:21.346006
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("### Testing function evaluate_tags of class Taggable ###")

    task = Taggable()
    task.tags = ['foo', 'bar']
    # Test case 1: Only_tags = ['foo'], skip_tags = [], all_vars = []
    only_tags = ['foo']
    skip_tags = []
    all_vars = []
    expected_result = True
    actual_result = task.evaluate_tags(only_tags, skip_tags, all_vars)
    if actual_result == expected_result:
        print("test_Taggable.evaluate_tags(): PASSED")
    else:
        print("test_Taggable.evaluate_tags(): FAILED")


# Generated at 2022-06-21 01:32:30.114598
# Unit test for constructor of class Taggable
def test_Taggable():
    objects = ['', 'a', 'b', 'c', '1']
    a = Taggable()
    a.tags = objects[0]
    assert(a.tags == [''])
    a.tags = objects[1]
    assert(a.tags == ['a'])
    a.tags = objects[2]
    assert(a.tags == ['b'])
    a.tags = objects[3]
    assert(a.tags == ['c'])
    a.tags = objects[4]
    assert(a.tags == ['1'])


# Generated at 2022-06-21 01:32:30.888550
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-21 01:32:34.071848
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert isinstance(obj._tags, list)
    assert isinstance(obj.tags, list)

# Generated at 2022-06-21 01:32:43.406850
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        def __init__(self):
            self._tags = ['a']
            self._loader = None
            self.tags = ['a']

    # Case in which no tags are specified
    taggable = DummyTaggable()
    assert taggable.evaluate_tags(None, None, {})

    # Case in which only one tag is specified as 'only_tags' in the task
    taggable = DummyTaggable()
    assert taggable.evaluate_tags(['a'], None, {})
    taggable = DummyTaggable()
    assert taggable.evaluate_tags(['a'], [], {})

    # Case in which only one tag is specified as 'only_tags' in the task,
    # and the task has multiple tags
   

# Generated at 2022-06-21 01:32:49.560111
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    test_item = TaskInclude()
    test_item.tags = [u'always'] # u'' is unicode
    test_only_tags = [u'all']
    test_skip_tags = [u'never']
    test_all_vars = {}

    result = test_item.evaluate_tags(only_tags = test_only_tags,
           skip_tags = test_skip_tags, all_vars = test_all_vars)
    assert True == result

    test_item.tags = [u'never']
    result = test_item.evaluate_tags(only_tags = test_only_tags,
           skip_tags = test_skip_tags, all_vars = test_all_vars)
    assert False == result

   

# Generated at 2022-06-21 01:32:51.167970
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []