

# Generated at 2022-06-21 01:24:36.347722
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        _valid_attrs = frozenset(['tags', 'another'])
        def __init__(self, loader, another=None):
            self._loader = loader
            self.another = another
        def get_dep_attrs(self, attrname=None):
            return ['tags']

    # Test that tags are initialized to an empty list
    test_obj = TestTaggable(None)
    assert test_obj.tags == []

    # Test that tags are correctly converted from string to list
    test_obj = TestTaggable(None, tags='abc, def ,, hello   ')
    assert test_obj.tags == ['abc', 'def', 'hello']

    # Test that tags are correctly converted from string to list

# Generated at 2022-06-21 01:24:41.869829
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    t = Taggable()
    assert isinstance(t, Taggable)
    assert t._load_tags('tags', [1]) == [1]
    assert t._load_tags('tags', 1) == [1]
    assert t._load_tags('tags', '1') == ['1']
    assert t._load_tags('tags', ['1', 2]) == [1, 2]
    assert isinstance(t._load_tags('tags', '1,2'), list)
    assert isinstance(t._load_tags('tags', ['1', 2]), list)
    try:
        t._load_tags('tags', {})
    except AnsibleError:
        pass
    else:
        assert False, "failed to raise error"
    # test evaluate_

# Generated at 2022-06-21 01:24:46.471615
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    This unit test shows how to create an object of Taggable class.
    '''

    from ansible.playbook.play import Play

    p = Play()
    # Check that an object of class Taggable is created successfully
    assert isinstance(p, Taggable)

# Generated at 2022-06-21 01:24:54.750160
# Unit test for constructor of class Taggable
def test_Taggable():

    assert(Taggable._preprocess_attr.get('tags')(None, []) == [])
    assert(Taggable._preprocess_attr.get('tags')(None, 'a') == ['a'])
    assert(Taggable._preprocess_attr.get('tags')(None, 'a, b, c') == ['a', 'b', 'c'])
    try:
        Taggable._preprocess_attr.get('tags')(None, {})
    except AnsibleError:
        pass
    else:
        assert(False)

# Generated at 2022-06-21 01:24:59.884328
# Unit test for constructor of class Taggable
def test_Taggable():
    t1 = Taggable()
    t2 = Taggable(tags=['t2'])
    assert t1._load_tags(None, 'a, b') == ['a', 'b']
    assert t2.tags == ['t2']
    assert t1.untagged == frozenset(['untagged'])
    assert t1.untagged == frozenset(['untagged'])
    assert t2.evaluate_tags([], [], {}) == True

# Generated at 2022-06-21 01:25:11.903628
# Unit test for constructor of class Taggable
def test_Taggable():
    ansible = __import__('ansible')
    module_utils = __import__('ansible.module_utils')
    six = __import__('ansible.module_utils.six')
    taggable = __import__('ansible.playbook.taggable')

    module_name = '<module_name>'
    module_args = '<module_args>'
    fm = module_utils.basic.AnsibleModule(module_name, module_args)
    gv = ansible.playbook.group.GroupVars(vars=dict(foo='foo', bar='bar', baz='baz'))
    mv = ansible.playbook.hosts.HostVars(vars=dict(foo='foo', bar='bar', baz='baz'))
    lm = module_utils._

# Generated at 2022-06-21 01:25:23.481522
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task1 = Taggable()
    task2 = Taggable()
    task3 = Taggable()
    host1 = Taggable()
    host2 = Taggable()
    host3 = Taggable()
    play1 = Taggable()
    play2 = Taggable()
    play3 = Taggable()
    play4 = Taggable()
    play5 = Taggable()
    play6 = Taggable()
    play7 = Taggable()

    #task1.tags = []
    #task2.tags = ['always']
    #task3.tags = ['foo']

    #host1.tags = []
    #host2.tags = ['never']
    #host3.tags = ['foo']

    play1.tags = []
    play2.tags = ['foo']
    play

# Generated at 2022-06-21 01:25:29.827483
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # load_tags_data and tags must be declared before the test
    load_tags_data = ds = [{ "tags" : "tag1, tag2" }]
    for i in load_tags_data:
        tags = i["tags"].split(',')
        print(tags)
    # tags = [ "tag1", "tag2" ]

test_Taggable_evaluate_tags()

# Generated at 2022-06-21 01:25:37.025006
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task as task
    t = task.Task()

    # W/o tags, tags will be 'untagged'
    only_tags = ['tag1']
    skip_tags = ['tag2']
    assert t.evaluate_tags(only_tags, skip_tags, dict())

    # W/o tags, tags will be 'untagged', except skip_tags has 'all'
    only_tags = ['tag1']
    skip_tags = ['tag2', 'all']
    assert not t.evaluate_tags(only_tags, skip_tags, dict())

    t = task.Task()
    t.tags = ['tagX']
    assert t.evaluate_tags(only_tags, skip_tags, dict())

    t = task.Task()
    t.tags = ['tagX', 'always']
   

# Generated at 2022-06-21 01:25:47.252764
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task

    inc = IncludeRole()
    inc.tags = ['tag1']
    tags = ['tag3', 'tag4']

    # test for method Taggable.evaluate_tags when inclusion is skipped
    assert (not inc.evaluate_tags(only_tags=['tag2'], skip_tags=['tag1'], all_vars={}))

    # test for method Taggable.evaluate_tags when inclusion is not skipped
    assert inc.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={})

    # test for method Taggable.evaluate_tags when inclusion is not skipped

# Generated at 2022-06-21 01:26:05.944246
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    class TestTaggableMethods(unittest.TestCase):
        def setUp(self):
            self.task = Task()
            self.role = Role()
            self.play = Play()

        def tearDown(self):
            pass

        def test_evaluate_tags(self):
            # test a role
            self.role.tags = ['role-tag']
            self.assertTrue(self.role.evaluate_tags(['all', 'role-tag'], [], {}))
            self.assertFalse(self.role.evaluate_tags(['all', 'no-role-tag'], [], {}))

            # test a play
            self.play

# Generated at 2022-06-21 01:26:17.850866
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible import utils
    from ansible.playbook.task import Task
    from ansible.playbook.include.role import IncludeRole
    try:
        __import__('mylib')
    except ImportError:
        class AnsibleModule(object):
            def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                        check_invalid_arguments=True, mutually_exclusive=None, supports_check_mode=False,
                        required_together=None, required_one_of=None, add_file_common_args=False,
                        supports_diff=False):
                print('Task:', self._task.name)
                print('Module:', self._name)
                print('Args:', self.params)
                self.exit_json = utils.default_from_current_

# Generated at 2022-06-21 01:26:23.150740
# Unit test for constructor of class Taggable
def test_Taggable():

    taggable = Taggable()
    taggable.tags = ["first", "second", "third"]
    if taggable.tags != ["first", "second", "third"]:
        raise Exception("tags are not loaded well")
    if "second" not in taggable.tags:
        raise Exception("tags are not loaded well")

# Generated at 2022-06-21 01:26:25.138419
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    assert t.untagged == frozenset(['untagged'])

# Generated at 2022-06-21 01:26:28.882190
# Unit test for constructor of class Taggable
def test_Taggable():
    # constructor test
    t = Taggable()
    assert t.untagged == frozenset(['untagged'])
    assert t._tags == list()
    assert t.tags == list()

# Generated at 2022-06-21 01:26:32.401433
# Unit test for constructor of class Taggable
def test_Taggable():
    sample_Taggable = Taggable()
    sample_Taggable._tags = ["foo", "bar"]

    print(sample_Taggable._tags)


# Generated at 2022-06-21 01:26:42.890883
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTask:
        def __init__(self, tags):
            self._tags = tags

    t1 = DummyTask(['t1', 't2'])
    t2 = DummyTask(['t1', 't2', 'always'])

    # With t1 and t2, we only execute t2
    assert not t1.evaluate_tags(['always'], set(), {})
    assert t2.evaluate_tags(['always'], set(), {})

    # With t1 and t2, we only execute t2
    assert not t1.evaluate_tags(set(), ['never'], {})
    assert t2.evaluate_tags(set(), ['never'], {})

    # With t1 and t2, we execute both of them
    assert t1.evaluate_tags(set(), set(), {})


# Generated at 2022-06-21 01:26:51.746124
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        def __init__(self):
            self.tags = None
            self._tags = None
            self._loader = "default"
    
    #test for empty list
    testClass = TestClass()
    assert testClass.evaluate_tags([], [], {}) == True

    #test for empty list
    testClass = TestClass()
    assert testClass.evaluate_tags([1, 2, 4], [3], {}) == False

    #test for empty list
    testClass = TestClass()
    assert testClass.evaluate_tags([1, 2, 4], [], {}) == False

# Generated at 2022-06-21 01:27:02.703533
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTaggable(Taggable):

        def __init__(self, tags):
            self.tags = tags
            self._loader = None
            self.only_tags = set()
            self.skip_tags = set()

    # Only tags
    t = FakeTaggable([])
    t.only_tags = set([ 'green', 'blue' ])
    assert t.evaluate_tags(t.only_tags, t.skip_tags, {}) is False, 'No tags and no \'always\' tag'

    t = FakeTaggable(['green'])
    t.only_tags = set([ 'green', 'blue' ])
    assert t.evaluate_tags(t.only_tags, t.skip_tags, {}) is True, 'No skip tags, green tag'


# Generated at 2022-06-21 01:27:06.686334
# Unit test for constructor of class Taggable
def test_Taggable():
	
	t = Taggable()
	t._load_tags(6, [2, 3])
	print(t.evaluate_tags(5, 6, {'test': 1}))
	return t


if __name__ == '__main__':
	t = test_Taggable()

# Generated at 2022-06-21 01:27:28.271827
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    test the constructor of class Taggable
    """
    yaml_obj = {'a': 'b'}
    taggable = Taggable()
    taggable.__init__(play=None, tqm=None, role=None, task=None, block=None, loader=yaml_obj)

    #Assert that the loader is of type dict
    assert isinstance(yaml_obj, dict)

    #Assert that the loader is the same object that is passed to the constructor
    assert yaml_obj is taggable._loader


# Generated at 2022-06-21 01:27:34.489295
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.template import Templar

    class FakeVarsModule(object):
        def __init__(self):
            self._templar = Templar(loader=None, variables={})
            self.vars = {'var1': ['tag1', 'tag2'], 'var2': "tag3,tag4", 'var3': 'tag1'}
            self.evaluate_tags = self._templar.template


# Generated at 2022-06-21 01:27:45.628614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task


    # Used as a placeholder when testing
    class TestClass(Base, Taggable):
        pass

    # Fake loader for the above class
    class TestLoader(object):
        class AllVars(dict):
            def get(self, key, default=None, boolean=False, expand_lists=False):
                return self[key]

        def __init__(self, data=None):
            self.vars = self.AllVars()
            if data is not None:
                self.vars.update(data)

    # Used as a placeholder when testing

# Generated at 2022-06-21 01:27:54.787194
# Unit test for constructor of class Taggable
def test_Taggable():
    class Target(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    target = Target([])
    assert target.tags == []

    target = Target("foo,bar")
    assert target.tags == ['foo', 'bar']

    target = Target("foo,bar, baz")
    assert target.tags == ['foo', 'bar', 'baz']

    target = Target(['a', 'b', 'c'])
    assert target.tags == ['a', 'b', 'c']

    # tags must be specified as a list
    try:
        target = Target(100)
        assert False
    except:
        assert True

    target = Target()
    assert target.tags == []

    target = Target([])
    assert target.tags == []


# Generated at 2022-06-21 01:28:05.754456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    obj = Taggable()
    obj_task = Task()
    only_tags = set(['patching','image','prechecks','postchecks','reboot'])
    skip_tags = set(['postchecks','reboot'])

    # Check for 'all' only_tags
    assert(obj.evaluate_tags(set(['all']), set([]), {}) == True)

    # Check for 'all' only_tags with never tag
    obj_task.tags = ['never']
    assert(obj_task.evaluate_tags(set(['all']), set([]), {}) == False)

    # Check for 'all' only_tags with never tag and all tag
    assert(obj.evaluate_tags(set(['all']), set([]), {}) == True)

   

# Generated at 2022-06-21 01:28:06.957840
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t._tags, list)

# Generated at 2022-06-21 01:28:10.683210
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags != None
    assert taggable.tags == []
    assert taggable.untagged == frozenset(['untagged'])

# Generated at 2022-06-21 01:28:21.436301
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import PlayBook


# Generated at 2022-06-21 01:28:28.458871
# Unit test for constructor of class Taggable
def test_Taggable():
  t = Taggable()
  t._tags = ["tag1","tag2","tag3"]
  assert len(t._tags) == 3
  assert t._tags[0] == "tag1"
  assert t._tags[1] == "tag2"
  assert t._tags[2] == "tag3"

# Generated at 2022-06-21 01:28:36.410379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host = Host('localhost')
    group = Group('all')
    play = Play()
    role = Role()
    task = Task()

    # Default behaviour: return true
    assert host.evaluate_tags([], [], {})
    assert group.evaluate_tags([], [], {})
    assert play.evaluate_tags([], [], {})
    assert role.evaluate_tags([], [], {})
    assert task.evaluate_tags([], [], {})

    # Add list of tags and test if all tags are evaluated correctly
    host.tags = ['tag1', 'tag2', 'tag3']
    group.tags = ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-21 01:29:02.315793
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    attrs = ['task1', 'task2', 'task3', 'task4']
    steps = ['task1', 'task2', 'task3']
    # only_tags = ['task1', 'task2']
    # only_tags = []
    # skip_tags = ['task1']
    # skip_tags = []
    # print(evaluate_tags(attrs, steps, only_tags, skip_tags))

    # only_tags = ['task1', 'task2']
    # only_tags = []
    # skip_tags = ['task2']
    # skip_tags = []
    # print(evaluate_tags(attrs, steps, only_tags, skip_tags))

    # only_tags = ['task1', 'task2']
    # only_tags = []
    # skip_tags = ['task1', '

# Generated at 2022-06-21 01:29:03.656336
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()


# Generated at 2022-06-21 01:29:14.766369
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyClass(Taggable):
        def __init__(self, tags=None, run_once=False):
            self._tags = tags
            self._run_once = run_once
        def get_tags(self):
            return self._tags
        def set_tags(self, tags):
            self._tags = tags
        def get_run_once(self):
            return self._run_once
        tags = property(get_tags, set_tags)
        run_once = property(get_run_once)

    # always run
    my_class = MyClass(tags=['always'])
    assert(True == my_class.evaluate_tags(only_tags=[], skip_tags=[]))

    # never run
    my_class = MyClass(tags=['never'])

# Generated at 2022-06-21 01:29:19.316431
# Unit test for constructor of class Taggable
def test_Taggable():
    loader = DummyModuleLoader()
    taggable = Taggable(loader=loader)
    taggable.tags = ['a', 'b', 'c']
    assert taggable
    assert taggable.tags == ['a', 'b', 'c']
    taggable.tags = 'a,b,c'
    assert taggable.tags == ['a', 'b', 'c']
    taggable.tags = []
    assert taggable.tags == []
    taggable.tags = 'foo'
    assert taggable.tags == ['foo']


# Generated at 2022-06-21 01:29:22.947800
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    t = Taggable()
    assert t._load_tags(attr="test", ds="test") == ["test"]
    t.tags = "test"
    assert t.evaluate_tags("", "", {}) == True


# Generated at 2022-06-21 01:29:26.003064
# Unit test for constructor of class Taggable
def test_Taggable():
    class C(Taggable):
        pass
    o = C()
    assert o._tags == []

# Generated at 2022-06-21 01:29:35.414709
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['foo', 'bar']
    assert t.evaluate_tags([], [], {}) is True
    assert t.evaluate_tags(['foo'], [], {}) is True
    assert t.evaluate_tags([], ['foo'], {}) is False

    t.tags = ['foo', 'bar', 'always']
    assert t.evaluate_tags([], [], {}) is True
    assert t.evaluate_tags(['foo'], [], {}) is True
    assert t.evaluate_tags([], ['foo'], {}) is False
    assert t.evaluate_tags(['all'], [], {}) is True
    assert t.evaluate_tags(['all'], ['never'], {}) is True
    assert t.evaluate_tags(['all'], ['always'], {})

# Generated at 2022-06-21 01:29:41.177528
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test _load_tags
    taggable = Taggable()
    tags = ['a', 'b', 'c']
    taggable._load_tags('_tags', tags)
    assert taggable._tags == tags

    tags = 'a, b, c'
    taggable._load_tags('_tags', tags)
    assert taggable._tags == ['a', 'b', 'c']

# Generated at 2022-06-21 01:29:53.634887
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Unit test for the method evaluate_tags of class Taggable
       The test_Taggable_load_tags() test should be run prior to this one
    '''

    taggable = Taggable()

    # test default is True
    assert taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # test only_tags
    assert taggable.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={}) == True
    assert taggable.evaluate_tags(only_tags=['all', 'tag_A'], skip_tags=None, all_vars={}) == True

# Generated at 2022-06-21 01:30:02.147922
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(object):
        _tags = ['tag1', 'tag2']

    taggable_obj = MyTaggable()
    only_tags = ['tag1']
    assert taggable_obj._load_tags == taggable_obj.tags
    assert taggable_obj.evaluate_tags(only_tags, None, None) == True
    only_tags = ['tag1', 'tag2', 'tag3']
    assert taggable_obj.evaluate_tags(only_tags, None, None) == True
    skip_tags = ['tag1']
    assert taggable_obj.evaluate_tags(None, skip_tags, None) == False
    skip_tags = ['tag1','tag2','tag3']
    assert taggable_obj.evaluate_tags(None, skip_tags, None)

# Generated at 2022-06-21 01:30:33.209440
# Unit test for constructor of class Taggable
def test_Taggable():
    c = Taggable()
    c.tags = []
    assert c.tags == []
    assert c.untagged == frozenset(['untagged'])

# Generated at 2022-06-21 01:30:43.288597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTestObject(Taggable):
        pass

    test_object = TaggableTestObject()
    test_object.tags = ['test', 'test2']

    test_object.evaluate_tags(['test'], [], [])
    assert test_object.tags == ['test', 'test2']

    test_object.evaluate_tags(['test', 'test3'], [], [])
    assert test_object.tags == ['test', 'test2']

    test_object.evaluate_tags(['test2'], [], [])
    assert test_object.tags == ['test', 'test2']

    test_object.evaluate_tags(['test'], ['test2'], [])
    assert test_object.tags == ['test', 'test2']


# Generated at 2022-06-21 01:30:54.751040
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Host():

        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

        def __init__(self):
            self.tags = ['michael']

        def evaluate_tags(self, only_tags=None, skip_tags=None, all_vars=None):
            return True

    h = Host()
    assert h.evaluate_tags(only_tags=['michael'])
    assert h.evaluate_tags(only_tags=['all'])
    assert h.evaluate_tags(only_tags=['tagged'])
    assert h.evaluate_tags(only_tags=['all', 'tagged'])
    assert h.evaluate_tags(only_tags=['all', 'tagged', 'michael'])


# Generated at 2022-06-21 01:31:03.031887
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableSubclass(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2']

    obj = TaggableSubclass()

    all_vars = dict()

    # Test nothing to be skipped, nothing to be run only
    assert obj.evaluate_tags(set(), set(), all_vars) == True
    assert obj.evaluate_tags(set(), set(['tag1']), all_vars) == True
    assert obj.evaluate_tags(set(), set(['tag1', 'tag2']), all_vars) == True
    assert obj.evaluate_tags(set(), set(['tag1', 'tag2', 'skip_tag']), all_vars) == True

    # Test something to be skipped

# Generated at 2022-06-21 01:31:10.240206
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'unit', 'test_data')
    src_dir = os.path.join(test_dir, '..', '..', '..', 'lib')

    sys.path.insert(0, src_dir)

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_path = os.path.join(test_data_dir, 'test_inventory.yml')
    inv_source = loader.load_from_file(inv_path)

# Generated at 2022-06-21 01:31:22.378141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass

    tags = {'shell': 'dummy_shell', 'become': None, 'become_user': 'root'}

    # test case: no tag option
    only_tags = []
    skip_tags = []
    should_run = True
    obj = MockTaggable()
    obj._tags = tags
    result = obj.evaluate_tags(only_tags, skip_tags, {})
    assert result == should_run, "unexpected result for only_tags {} and skip_tags {}".format(only_tags, skip_tags)

    # test case: only --tags all and --skip-tags never
    only_tags = ['all']
    skip_tags = ['never']
    should_run = True
    obj = MockTaggable()
    obj._tags

# Generated at 2022-06-21 01:31:25.410909
# Unit test for constructor of class Taggable
def test_Taggable():
    print('Testing Taggable constructor')
    assert Taggable()

# Generated at 2022-06-21 01:31:28.410207
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._tags, list)
    assert isinstance(taggable.tags, list)

    data = {'tags': ["tag1", "tag2"]}
    data = Taggable._load_tags(None, data)
    assert isinstance(data, list)

    data = {'tags': "tag1, tag2"}
    data = Taggable._load_tags(None, data)
    assert isinstance(data, list)


test_Taggable()

# Generated at 2022-06-21 01:31:30.922452
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t.tags = ["foo", "bar", "baz"]
    assert(t.tags == ["foo", "bar", "baz"])

# Generated at 2022-06-21 01:31:34.909761
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ['test', 'test2']
    assert t.tags == ['test', 'test2']

# Generated at 2022-06-21 01:32:42.043040
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    t = Task()
    t.tags = ['t1','t2']

    assert t.evaluate_tags(None, None, None)
    assert t.evaluate_tags([], [], None)
    assert t.evaluate_tags(['t1'], [], None)
    assert t.evaluate_tags(['t2'], [], None)
    assert t.evaluate_tags(['t1','t2'], [], None)
    assert t.evaluate_tags(['t1', 't2', 'always'], [], None)
    assert t.evaluate_tags(None, ['t1'], None)
    assert t.evaluate_tags([], ['t2'], None)
    assert t.evaluate_tags(['t1'], ['t2'], None)
   

# Generated at 2022-06-21 01:32:46.402315
# Unit test for constructor of class Taggable
def test_Taggable():

    # Create object of class Taggable
    obj = Taggable()

    # Instance of class Taggable
    assert isinstance(obj, Taggable)

# Generated at 2022-06-21 01:32:54.836816
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    ##########################
    # Test all: tagged: True #
    ##########################

    test_block = Block()
    test_block.tags = ['tag']

    test_block._update_block_args(dict())

    only_tags = ['tag']
    skip_tags = []
    assert test_block.evaluate_tags(only_tags, skip_tags, dict()) == True

    ##########################
    # Test all: tagged: True #
    ##########################

    test_block = Block()
    tags = ['tag']
    test_block.tags = tags

    test_block._update_block_args(dict())

    only_tags = ['tag']
    skip_tags = []

# Generated at 2022-06-21 01:32:57.060298
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    assert test_obj._tags == []

# Generated at 2022-06-21 01:33:05.974248
# Unit test for constructor of class Taggable
def test_Taggable():

    class A(Taggable):
        def __init__(self, tags, ds):
            self._tags  = self._load_tags(self._tags, tags)
            self.ds = ds

    a1 = A('foo, bar', 'first')
    assert a1.tags == ['foo', 'bar'], a1.tags
    assert a1.ds == 'first', a1.ds
    assert a1._tags is a1.tags

    a2 = A(['foo', 'bar'], 'second')
    assert a2.tags == ['foo', 'bar'], a2.tags
    assert a2.ds == 'second', a2.ds
    assert a2._tags is a2.tags

    a3 = A('', 'third')
    assert a3.tags == []
    assert a3.ds

# Generated at 2022-06-21 01:33:14.875937
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.playbook.taggable
    import ansible.playbook.block
    import ansible.playbook.task

    #
    # Test for ansible.playbook.Block
    #
    pb = ansible.playbook.PlayBook()
    block = ansible.playbook.block.Block()

    # test 1: no tags
    # block.tags=None
    # block._vars=dict(tags=['all'])
    # block.evaluate_tags(['all'], []) should be true
    block.tags = None
    block._vars = dict(tags=['all'])
    assert block.evaluate_tags(['all'], []) == True

    # test 2: all
    # block.tags=["all"]
    # block._vars=

# Generated at 2022-06-21 01:33:24.584551
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import pytest

    @pytest.fixture
    def variable_manager():
        variable_manager = VariableManager()
        variable_manager.set_inventory(inventory)
        return variable_manager


# Generated at 2022-06-21 01:33:26.246589
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()



# Generated at 2022-06-21 01:33:28.878667
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    task = Task()
    assert task.tags == []

# Generated at 2022-06-21 01:33:30.471449
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
