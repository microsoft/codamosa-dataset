

# Generated at 2022-06-21 01:24:33.027944
# Unit test for constructor of class Taggable
def test_Taggable():
   assert Taggable._load_tags(None, None) == list()
   assert Taggable._load_tags(None, list()) == list()
   assert Taggable._load_tags(None, "foo,bar") == ["foo", "bar"]
   assert Taggable._load_tags(None, "foo bar") == ["foo bar"]
   assert Taggable._load_tags(None, 7) == [7]
   assert Taggable._load_tags(None, "") == ['']
   assert Taggable._load_tags(None, "  ") == ['  ']

# Generated at 2022-06-21 01:24:34.585221
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert(a.tags == list())
    return a

# test_Taggable()

# Generated at 2022-06-21 01:24:45.457766
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager

    # Case 1 - always run
    tags = ['always']
    only_tags = ['tagged']
    skip_tags = []
    task = TaskInclude('dummy')
    task.tags = tags
    assert task.evaluate_tags(only_tags, skip_tags, VariableManager()) == True

    # Case 2 - only_tags contains all, should run
    tags = ['tag1']
    only_tags = ['tagged', 'all']
    skip_tags = []
    task = TaskInclude('dummy')
    task.tags = tags
    assert task.evaluate_tags(only_tags, skip_tags, VariableManager()) == True

    # Case 3 - only_tags contains all, should not run

# Generated at 2022-06-21 01:24:56.951008
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        pass

    test = TestTaggable()

    assert 'tags' in test._attributes
    assert test._attributes['tags']._type == list
    assert test._attributes['tags'].default == list

    assert test._attributes['tags'].isa._type == 'list'
    assert test._attributes['tags'].isa.listof[0]._type == string_types
    assert test._attributes['tags'].isa.listof[1]._type == int
    assert test._attributes['tags'].isa.listof._type == tuple

    assert test._attributes['tags'].extend == True

    assert test._load_tags('tags', ['test']) == ['test']
    assert test._load_tags('tags', 'test') == ['test']


# Generated at 2022-06-21 01:25:03.315422
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    t1 = Task()

    assert t1.tags == []

    t1 = Task(tags=['tag1'])
    assert t1.tags == ['tag1']

    t2 = Task(tags='tag1,tag2')
    assert t2.tags == ['tag1', 'tag2']

# Generated at 2022-06-21 01:25:15.588223
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestableTaggable(Taggable):
        def __init__(self):
            self._loader = None
    tt = TestableTaggable()

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    vm = VariableManager()
    inventory = InventoryManager()
    vm.set_inventory(inventory=inventory)

    # both empty
    only_tags = []
    skip_tags = []
    # no tags so should run
    tt.tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars=vm.get_vars(play=None))

    # only_tags [ 'foo' ]
    only_tags = [ 'foo' ]
    skip_tags

# Generated at 2022-06-21 01:25:24.789878
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()
    assert t.tags == []
    assert t.untagged == frozenset(['untagged'])
    t.tags = ['a', 'b']
    assert t.tags == ['a', 'b']
    t.tags = 'a, b'
    assert t.tags == ['a', 'b']
    t.tags = ('a', 'b')
    assert t.tags == ['a', 'b']
    assert t.evaluate_tags([], ['a'], {}) == False
    assert t.evaluate_tags(['a'], ['b'], {}) == True
    assert t.evaluate_tags(['a'], [], {}) == True
    assert t.evaluate_tags([], [], {}) == True

# Generated at 2022-06-21 01:25:34.750546
# Unit test for constructor of class Taggable
def test_Taggable():
    class FakeClass():
        tags = None
        _tags = None
        def __init__(self,tags=None):
            self.tags = tags
            self._tags = tags

    # testing constructor of Taggable class
    t = Taggable()

    # testing constructor of Taggable class
    t = Taggable()
    f = FakeClass(tags=['tag1','tag2'])
    t.get_tags(f,d={})
    assert t.tags == ['tag1','tag2']


    # testing constructor of Taggable class
    t = Taggable()
    f = FakeClass(tags=['tag1,tag2'])
    t.get_tags(f,d={})
    assert t.tags == ['tag1,tag2']

# Generated at 2022-06-21 01:25:45.917006
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # taggable_obj = Taggable()
    taggable_obj = Taggable()
    taggable_obj._loader = loader
    taggable_obj._templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None))

    print(taggable_obj._load_tags(attr='tags', ds='hosts'))

# Generated at 2022-06-21 01:25:52.993700
# Unit test for constructor of class Taggable
def test_Taggable():
    test_taggable = Taggable()
    assert '_tags' in test_taggable.__dict__
    assert '_tags' in test_taggable._attributes
    assert 'untagged' in test_taggable.__dict__
    assert 'untagged' in test_taggable._attributes
    assert 'evaluate_tags' in test_taggable.__dict__
    assert 'evaluate_tags' in test_taggable._attributes
    assert '_load_tags' in test_taggable.__dict__
    assert '_load_tags' in test_taggable._attributes

# Generated at 2022-06-21 01:26:17.756660
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import os
    import sys

    # Setup the class we want to test
    class TestClass(Taggable, object):
        pass

    # Setup the module. Ansible modules are required to be in the ansible.modules.something namespace.
    # Add the path to that namespace to sys.modules so we can import it.
    class TestModule(unittest.TestCase):
        def setUp(self):
            self.cwd = os.getcwd()
            os.chdir(os.path.dirname(__file__))
            sys.path.append(os.path.dirname(__file__))
            sys.modules['ansible'] = sys.modules['ansible_unit_tests']
            sys.modules['ansible.modules'] = sys.modules['ansible_unit_tests'].modules


# Generated at 2022-06-21 01:26:26.264490
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['busybox']
    skip_tags = ['timmy', 'tommy', 'frank']
    all_vars = {'ansible_tags': 'busybox,frank'}
    assert Taggable().evaluate_tags(only_tags, skip_tags, all_vars)
    all_vars = {'ansible_tags': 'busybox'}
    assert Taggable().evaluate_tags(only_tags, skip_tags, all_vars)
    all_vars = {}
    assert not Taggable().evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-21 01:26:27.608413
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-21 01:26:34.076435
# Unit test for constructor of class Taggable
def test_Taggable():
    module = Taggable()
    assert module._load_tags("tag", ["tag1", "tag2"]) == ["tag1", "tag2"]
    assert module._load_tags("tag", "tag1,tag2") == ["tag1", "tag2"]
    assert module._load_tags("tag", "tag1") == ["tag1"]

# Generated at 2022-06-21 01:26:40.096125
# Unit test for constructor of class Taggable
def test_Taggable():
    import ansible.playbook.task
    # create an instance of Taggable
    task = Taggable()
    # assert that task is an instance of Taggable
    assert isinstance(task, Taggable)
    # assert that task is an instance of ansible.playbook.task.Task
    assert isinstance(task, ansible.playbook.task.Task)
    return


# Generated at 2022-06-21 01:26:51.293772
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        pass

    class Task2(Taggable):
        pass

    task = Task()
    task2 = Task2()

    # Test no tags
    result = task.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={})
    assert result == True

    # Test always
    task.tags = ['always']
    result = task.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={})
    assert result == True

    # Test never
    task.tags = ['never']
    result = task.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={})
    assert result == False

    # Test skip_tags
    task2.tags = ['never']
    result = task2.evaluate

# Generated at 2022-06-21 01:27:00.082927
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class myTaggable(Taggable):
        pass
    mt = myTaggable()
    assert mt.evaluate_tags([], [], {})
    assert not mt.evaluate_tags(['all'], [], {})
    assert mt.evaluate_tags(['all'], [], { 'tags': ['foo']})
    assert not mt.evaluate_tags(['all'], ['foo'], { 'tags': ['foo']})
    assert mt.evaluate_tags([], ['all'], {})
    assert not mt.evaluate_tags([], ['all'], {'tags':['foo']})

# Generated at 2022-06-21 01:27:00.986035
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #TODO: implement
    pass

# Generated at 2022-06-21 01:27:10.148175
# Unit test for constructor of class Taggable
def test_Taggable():

    class Taggable_Child(Taggable):
        pass

    tc = Taggable_Child()

    # Check that the _tags field is list and initialized to []
    # (even if no _tags were specified in constructor parameters)
    assert isinstance(tc._tags, list)
    assert [] == tc._tags

    # Check that tags field is accessible through the class
    tc.tags = ['tag1', 'tag2']
    assert ['tag1', 'tag2'] == tc.tags

    # Check that Taggable class has an untagged property that is a frozen set
    # containing only 'untagged'
    assert frozenset(['untagged']) == tc.untagged

    # Check that tags can be extended with a list
    tc.tags.extend('tag3')

# Generated at 2022-06-21 01:27:14.325029
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags is not None

    field = t._fields['tags']
    assert field.isa == 'list'
    assert field.default == list
    assert field.listof == (string_types, int)
    assert field.extend


# Generated at 2022-06-21 01:27:34.283838
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing import DataLoader
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.module_utils.six import string_types
    test_taggable = Taggable()
    test_taggable._loader = DataLoader()
    test_taggable.tags = ['ping','pong','bong']
    test_inventory = Inventory(loader=test_taggable._loader, variable_manager=VariableManager(), host_list=[])
    test_play_context = PlayContext(play=None, options=None, variable_manager=VariableManager(), loader=test_taggable._loader)

    # Test tag operations

# Generated at 2022-06-21 01:27:45.428076
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Foo(Taggable):
        def __init__(self, tags=[]):
            self.tags = tags

    f = Foo()

    assert f.evaluate_tags(["all"], [], {}) is True
    assert f.evaluate_tags([], ["all"], {}) is True
    assert f.evaluate_tags(["all","bar"], [], {}) is True
    assert f.evaluate_tags([], ["all","bar"], {}) is True

    assert f.evaluate_tags(["bar"], [], {}) is False
    assert f.evaluate_tags([], ["bar"], {}) is True

    assert f.evaluate_tags(["foo"], [], {}) is False
    assert f.evaluate_tags([], ["foo"], {}) is True

    assert f.evaluate_tags(["always"], [], {}) is True


# Generated at 2022-06-21 01:27:54.651040
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        def __init__(self, tags=None):
            self._tags = tags

    task = Task()
    assert(task._load_tags('_tags', 'tag1') == ['tag1'])
    assert(task._load_tags('_tags', ['tag1']) == ['tag1'])
    try:
        task._load_tags('_tags', 1)
    except Exception as e:
        assert(e.__str__() == "tags must be specified as a list")

    task = Task(['tag1'])
    assert(task.evaluate_tags(['tag1'], [], {}) == True)
    assert(task.evaluate_tags(['tag2'], [], {}) == False)

# Generated at 2022-06-21 01:27:59.475284
# Unit test for constructor of class Taggable
def test_Taggable():
    print("Testing constructor of class Taggable")

    t = Taggable()
    if (t):
        print("Test passed")

    test = Taggable()
    test._tags = ['tag1', 'tag2', 'tag3']
    test.tags = ['tag1', 'tag2', 'tag3']

    if (test._tags == ['tag1', 'tag2', 'tag3'] and
        test.tags == ['tag1', 'tag2', 'tag3']):
        print("Test passed")

# Generated at 2022-06-21 01:28:06.861429
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.utils.vars import load_extra_vars

    def fail(msg):
        raise AssertionError(msg)

    def success(msg):
        pass

    def create_task(tags):
        task = Task()
        task._role_name = 'test_role'
        task._role = None
        task._ds = dict(tags=tags)
        return task

    # Test 1: no tags in the play and no specified on the task
    role_vars = dict()

# Generated at 2022-06-21 01:28:16.695391
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    import six

    test_task = Task()
    test_task.vars = dict()
    test_task.tags=['tag1']
    test_block = Block()
    test_block.vars = dict()
    test_block.tags = ['tag1']
    test_task_include = TaskInclude()
    test_task_include.vars = dict()
    test_task_include.tags=['tag1']
    test_loader = dict()

    test_task.evaluate_tags(['tag1'], [], test_task.vars)

# Generated at 2022-06-21 01:28:26.329664
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test(Taggable):
        def __init__(self, tags):
            self._tags = tags
    import ansible.plugins
    all_vars = ansible.plugins.vars.VarsModule()
    tests = [
        Test([['tag1']]),
        Test([['tag2']]),
        Test([['tag3']]),
        Test([['tag1','tag3']]),
        Test([['tag1','tag2','tag3']]),
        Test([])
    ]
    for test in tests:
        only_tags = []
        skip_tags = []
        result = test.evaluate_tags(only_tags, skip_tags, all_vars)
        assert result

        only_tags = ['tag1','tag2','tag3']
        skip_tags = []

# Generated at 2022-06-21 01:28:32.778491
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Fake 'self' object for method call
    class _fake_self:
        pass
    fake_self_obj = _fake_self()

    # Fake 'tasks' object for object self.tasks access
    class _fake_tasks:
        def __init__(self, parent):
            self._parent = parent
        @property
        def play(self):
            return self._parent.play
    fake_tasks_obj = _fake_tasks(fake_self_obj)
    fake_self_obj.tasks = fake_tasks_obj

    # Fake 'play' object for object self.tasks.play access
    class _fake_play:
        def __init__(self, parent):
            self._parent = parent
        @property
        def only_tags(self):
            return self._parent.__fake

# Generated at 2022-06-21 01:28:44.796481
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.plugins
    from ansible.inventory.host import Host

    host = Host(name="dummy")
    import os
    print("CWD: " + os.getcwd())
    print("Setting ANSIBLE_ROLES_PATH to: " + os.path.abspath("test/roles"))
    os.environ['ANSIBLE_ROLES_PATH'] = os.path.abspath("test/roles")
    

# Generated at 2022-06-21 01:28:46.954125
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

# Generated at 2022-06-21 01:29:25.210367
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task_include import TaskInclude

    play_ds = dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = "yes",
        roles = [
            dict(
                name = "apache"
            ),
            dict(
               name = "nginx",
               tags = ['foo', 'bar'],
            )
        ],
        pre_tasks = [
            dict(
                name = "pre-task",
                tags = ["always"]
            ),
            dict(
                name = "pre-task2",
                tags = ["never"]
            )
        ]
    )



# Generated at 2022-06-21 01:29:30.714393
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable().tags == []
    assert Taggable(tags='a,b,c').tags == ['a', 'b', 'c']
    assert Taggable(tags=['d', 'e', 'f']).tags == ['d', 'e', 'f']


if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:29:42.182600
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import types
    import sys
    import unittest


    class TestTaggable(Taggable):

        def __init__(self, only_tags=None, skip_tags=None, task_tags=None, task_always_run=False,
                     task_skip_tags=None, loader=None, variable_manager=None, shared_loader_obj=None,
                     templar=None):
            Taggable.__init__(self)
            self.tags = []
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.task_tags = task_tags
            self.task_always_run = task_always_run
            self.task_skip_tags = task_skip_tags
            self._loader = loader
            self._shared_loader_obj = shared_loader

# Generated at 2022-06-21 01:29:55.014459
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.parsing.dataloader import DataLoader

    ds = DataLoader()
    obj = Taggable()

    list_of_tags = ["A", "B"]
    obj._load_tags(obj.tags, list_of_tags)

    assert obj.tags == list_of_tags

    list_of_tags = "A, B"
    obj._load_tags(obj.tags, list_of_tags)

    assert obj.tags == ["A", "B"]

    list_of_tags = "A, B, C, D"
    obj._load_tags(obj.tags, list_of_tags)

    assert obj.tags == ["A", "B", "C", "D"]

    list_of_tags = "tagged, A, B"

# Generated at 2022-06-21 01:29:57.054744
# Unit test for constructor of class Taggable
def test_Taggable():
    my_host = Taggable()
    assert my_host.tags is None


# Generated at 2022-06-21 01:30:02.546579
# Unit test for constructor of class Taggable
def test_Taggable():
    class Tested(Taggable):
        pass
    tested = Tested(_tags="one, two, three")
    assert tested._tags == ['one', 'two', 'three']
    tested = Tested(_tags=["one", "two", "three"])
    assert tested._tags == ["one", "two", "three"]
    tested = Tested(_tags="one")
    assert tested._tags == ["one"]
    tested = Tested(_tags=["one"])
    assert tested._tags == ["one"]

# Generated at 2022-06-21 01:30:14.407004
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    tags_list = ['t1', 't2', 't3']
    tags_list_2 = ['t4', 't5']

    t.tags = tags_list
    assert t.tags == tags_list

    t.tags = tags_list_2
    assert t.tags == tags_list_2

    tags_str = 't6,t7,t8,t9'
    t.tags = tags_str
    assert t.tags == tags_str.split(',')

    tags_str = 't10, t11, t12, t13'
    t.tags = tags_str
    assert t.tags == tags_str.split(',')


# Generated at 2022-06-21 01:30:15.702695
# Unit test for constructor of class Taggable
def test_Taggable():
    result = Taggable()
    assert result._tags == []

# Generated at 2022-06-21 01:30:25.234922
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable():
        def __init__(self):
            self.tags = None 
    taggable = MockTaggable()
    all_vars = {}
    taggable.tags = None
    assert taggable.evaluate_tags(['tagged'], [], all_vars) == False
    taggable.tags = []
    assert taggable.evaluate_tags(['tagged'], [], all_vars) == False
    taggable.tags = ['tagged']
    assert taggable.evaluate_tags(['tagged'], [], all_vars) == True
    assert taggable.evaluate_tags(['tagged', 'test'], [], all_vars) == True

# Generated at 2022-06-21 01:30:26.664217
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert t._tags == []

# Generated at 2022-06-21 01:31:30.026756
# Unit test for constructor of class Taggable
def test_Taggable():
    data1 = {}
    data1['untagged'] = 'some string'
    data1['_tags'] = 'tag1,tag2,tag3'
    a1 = Taggable(**data1)
    assert a1.untagged == 'some string'
    assert a1._tags == ['tag1', 'tag2', 'tag3']
    a2 = Taggable()
    assert a2._tags == []

# Generated at 2022-06-21 01:31:33.813229
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Taggable()
    assert isinstance(t, Taggable)


# Generated at 2022-06-21 01:31:35.746870
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert type(taggable._tags) == list

# Generated at 2022-06-21 01:31:44.879602
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    test_obj = TestTaggable()

    test_only_tags = [ 'tag1', 'tag2' ]
    test_skip_tags = [ 'tag2', 'tag3', 'tag4' ]

    test_obj.tags = [ 'tag1', 'tag2' ]
    assert test_obj.evaluate_tags(test_only_tags, test_skip_tags, None)

    test_obj.tags = [ 'tag1', 'tag3' ]
    assert test_obj.evaluate_tags(test_only_tags, test_skip_tags, None)

    test_obj.tags = [ 'tag1', 'tag2', 'tag3' ]
    assert test_obj.evaluate_tags(test_only_tags, test_skip_tags, None)



# Generated at 2022-06-21 01:31:53.975453
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars=[])
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars=[])
    tt = TestTaggable()
    tt.tags = ['tag1']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars=[])
    assert not tt.evaluate_tags(only_tags=[], skip_tags=['tag1'], all_vars=[])
    tt = TestTaggable()

# Generated at 2022-06-21 01:32:02.705874
# Unit test for constructor of class Taggable
def test_Taggable():
    tags1 = Taggable()
    # tags1.tags = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u']
    tags1.tags = '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21'
    assert len(tags1.tags) == 21
    assert isinstance(tags1.tags, list)
    assert len(tags1._load_tags('tags', ['1','2','3','4','5'])) == 5
    assert isinstance(tags1._load_tags('tags', '12,34,56'), list)

# Generated at 2022-06-21 01:32:14.362614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    mock_loader = None

    ti = TaskInclude(loader=mock_loader, play=None)
    vm = VariableManager()

    context = PlayContext(vm=vm)
    context.only_tags=['tagged','notthis','nothisneither','nevertag']
    context.skip_tags=['never']

    ti._tags = ["ansible_tags"]
    ti.tags = ["tagged"]

    task = TaskInclude()
    task.evaluate_tags(context.only_tags,context.skip_tags,vm.get_vars(loader=None))

# Generated at 2022-06-21 01:32:20.044742
# Unit test for constructor of class Taggable
def test_Taggable():
    _tags = Taggable._tags
    assert(_tags._origin == 'Taggable')
    assert(_tags._name == '_tags')
    assert(_tags._class_name == 'Taggable')
    assert(_tags._module_name == 'Taggable')
    assert(_tags._origin_class == Taggable)

# Generated at 2022-06-21 01:32:31.704223
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.playbook import PlayBook

    # plays
    pb = PlayBook()
    play_context = PlayContext()
    play_context.tags = 'tagged'

    play = Play().load(dict(
        name = "A test play",
        hosts = 'localhost',
        gather_facts = 'no',
        vars = dict(a='123', b='234'),
        tasks = list()
    ), pb, play_context)

    task = Task()
    task.tags = 'tagged'
    task.action = 'shell echo "this is a test"'
    task._parent = play


# Generated at 2022-06-21 01:32:42.624033
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']

    testObject = TestTaggable()

    # Test case when current item is tagged with only_tags but not skip_tags
    testObject.tags = ['tag1']
    assert testObject.evaluate_tags(only_tags, skip_tags, {})

    # Test case when current item is tagged with both only_tags and skip_tags
    testObject.tags = ['tag1', 'tag3']
    assert not testObject.evaluate_tags(only_tags, skip_tags, {})

    # Test case when current item is not tagged with either only_tags or skip_tags
   