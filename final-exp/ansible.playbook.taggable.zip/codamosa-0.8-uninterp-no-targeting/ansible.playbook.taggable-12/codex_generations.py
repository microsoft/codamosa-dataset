

# Generated at 2022-06-21 01:24:36.127752
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    assert x._tags == []
    assert x.tags == []

    x = Taggable(tags=['a','b','c'])
    assert x._tags == ['a','b','c']
    assert x.tags == ['a','b','c']

    x = Taggable(tags='a, b, c')
    assert x._tags == ['a','b','c']
    assert x.tags == ['a','b','c']
    assert x._load_tags(None, 'a,b,c') == ['a','b','c']
    assert x._load_tags(None, ['a','b','c']) == ['a','b','c']

    # test the extend option
    x._tags = ['a']
    x._load_tags('_tags', 'b,c')


# Generated at 2022-06-21 01:24:47.623631
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()
    assert t.tags == []
    t.tags = None
    assert t.tags == []
    t.tags = ['lint:only=e,w3']
    assert t.tags == ['lint:only=e,w3']
    t.tags = 'lint:only=e,w3'
    assert t.tags == ['lint:only=e,w3']
    t.tags = ['lint:only=e,w3', 'lint:only=i']
    assert t.tags == ['lint:only=e,w3', 'lint:only=i']
    t.tags = ['lint:only=e,w3', 'lint:only=i', 'lint:only=i']

# Generated at 2022-06-21 01:24:49.584285
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-21 01:24:59.776942
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:25:06.812330
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    obj.tags = ['test']
    obj.tags.extend(['test2'])
    assert obj.evaluate_tags(['test'], [], None) == True
    assert obj.evaluate_tags(['fake'], [], None) == False
    assert obj.evaluate_tags([], ['fake'], None) == True
    assert obj.evaluate_tags([], ['test2'], None) == False

# Generated at 2022-06-21 01:25:18.718470
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, play_context, variable_manager=None, loader=None)

    taggable = Taggable()
    print ("taggable type: %s" % type(taggable))

# Generated at 2022-06-21 01:25:20.080261
# Unit test for constructor of class Taggable
def test_Taggable():

    test_instance = Taggable()
    assert test_instance.tags == []

# Generated at 2022-06-21 01:25:21.386183
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    assert test_obj._tags == []

# Generated at 2022-06-21 01:25:32.446611
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        def __init__(self, tag):
            self.tags = tag
            self.name = tag
            self.untagged = frozenset(['untagged'])

    print('test_Taggable_evaluate_tags')

    test_obj_1 = TestTaggable('only_once')
    test_obj_2 = TestTaggable('only_once,second')
    test_obj_3 = TestTaggable(['only_once', 'second'])
    test_obj_4 = TestTaggable('untagged')
    test_obj_5 = TestTaggable('all')
    test_obj_6 = TestTaggable('never')
    test_obj_7 = TestTaggable('never,second')

    test_obj_8 = TestTaggable

# Generated at 2022-06-21 01:25:34.933431
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable.tags, list)

# Generated at 2022-06-21 01:25:50.380668
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # A TaskInclude is a Taggable object
    ti = TaskInclude('some_path')
    r = Role('some_role', 'some_path')
    b = Block('some_block')

    # Check if the TaskInclude is executed without tags
    assert ti.evaluate_tags('', [], {})

    # Check if the TaskInclude is executed with empty tags
    assert ti.evaluate_tags('', [], {})

    # Check if the TaskInclude is skipped with skip-tags
    ti.tags = 'ssl'
    assert not ti.evaluate_tags('', ['ssl', 'deploy'], {})

# Generated at 2022-06-21 01:25:59.264665
# Unit test for constructor of class Taggable
def test_Taggable():
    import json
    import sys
    import unittest2 as unittest

    class TestTaggable(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_init_taggable(self):
            t = Taggable()
            self.assertEquals(len(t.tags), 0)
            t = Taggable(tags=['test1', 'test2'])
            self.assertEquals(len(t.tags), 2)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestTaggable)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 01:26:00.505863
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []


# Generated at 2022-06-21 01:26:05.645599
# Unit test for constructor of class Taggable
def test_Taggable():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    with pytest.raises(AnsibleError) as exc:
        obj = Taggable()
        obj._load_tags('tags', {'test':1})
    assert 'tags must be specified as a list' in exc.value.message

# Generated at 2022-06-21 01:26:11.638991
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_tag = ["tag", "tag2"]
    test_only_tags = ["tag"]
    test_skip_tags = ["tag2"]
    test_all_vars = dict()

    t = Taggable()
    t.tags = test_tag

    assert t.evaluate_tags(test_only_tags, test_skip_tags, test_all_vars) == False

# Generated at 2022-06-21 01:26:23.401007
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags is None, 'tags is initialized None.'

    # Test of _load_tags
    # tags = None
    t = Taggable()
    assert t._load_tags(ds = None) is None, 'ds = None'

    # tags = [t1, t2, ...]
    t = Taggable()
    assert t._load_tags(ds = ['t1', 't2']) == ['t1', 't2'], 'ds = [\'t1\', \'t2\'] (type of list)'
    t = Taggable()
    assert t._load_tags(ds = ('t1', 't2')) == ['t1', 't2'], 'ds = (\'t1\', \'t2\') (type of tuple)'

    # tags =

# Generated at 2022-06-21 01:26:26.927126
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableSubClass(Taggable):
        pass
    sub_class_instance = TaggableSubClass()
    assert type(sub_class_instance._tags) == list
    assert sub_class_instance._tags == []


# Generated at 2022-06-21 01:26:30.123749
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableImpl(Taggable):
        _tags = None

    instance = TaggableImpl()
    assert instance._tags == []

# Generated at 2022-06-21 01:26:41.624041
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    my_worker = Taggable()

    # ###################
    # Evaluate with only_tags
    # ###################
    # Only tag "always" is given
    only_tags = {'always'}
    skip_tags = None
    all_vars = None

    # Tags of task is given as 'always'
    my_worker.tags = ['always']
    assert my_worker.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Tags of task is given as empty
    my_worker.tags = []
    assert my_worker.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Tags of task is given as 'never'
    my_worker.tags = ['never']

# Generated at 2022-06-21 01:26:53.628308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    fake_only_tags = ['tagged', 'tag1']
    fake_skip_tags = ['tag1', 'tag3']

    fake_tags = ['tag2']
    fake_tags2 = ['tag1']
    fake_tags3 = ['always']
    fake_tags4 = ['never']
    fake_tags5 = ['tag1', 'never']
    fake_tags6 = ['tag3', 'never']
    fake_tags7 = ['tag1', 'tag2']

    fake_all_vars = dict()

    from ansible.playbook.task import Task
    test_task = Task()

    test_task.tags = fake_tags
    assert not test_task.evaluate_tags(fake_only_tags, fake_skip_tags, fake_all_vars)
    test_task.tags = fake_tags

# Generated at 2022-06-21 01:27:10.274581
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    # Test setup
    task = Taggable()
    task.tags = []

    # Test data
    all_vars = {}
    only_tags = ['test']
    skip_tags = []
    should_run = True
    all_tag_list = [
        ('all', 'all', should_run),
        ('all', 'never', not should_run),
        ('all', 'always', should_run),
        ('all', 'tagged', should_run),
    ]
    tagged_tag_list = [
        ('tagged', 'all', should_run),
        ('tagged', 'never', not should_run),
        ('tagged', 'always', should_run),
        ('tagged', 'tagged', should_run),
    ]

# Generated at 2022-06-21 01:27:15.733420
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable(dict())
    assert(t.tags == [])

    t = Taggable(dict({'tags': 1}))
    assert(t.tags == 1)

    t = Taggable(dict({'tags': 1}))
    assert(t.tags == 1)

    t = Taggable(dict({'tags': [1]}))
    assert(t.tags == [1])

# Generated at 2022-06-21 01:27:21.837425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_eval_tags = Taggable()
    test_eval_tags.tags = ['test', 'test1']
    test_eval_tags.only_tags = ['test', 'test1']
    test_eval_tags.skip_tags = []

    assert test_eval_tags.evaluate_tags(test_eval_tags.only_tags, test_eval_tags.skip_tags, None) == True, 'Should return True'


# Generated at 2022-06-21 01:27:22.811912
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-21 01:27:26.207242
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Unit test for constructor of class Taggable
    """
    taggable = Taggable()
    assert isinstance(taggable.tags, (list, tuple))

# Generated at 2022-06-21 01:27:33.497464
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task_include import TaskInclude

    ti=TaskInclude()
    ti.tags=["deploy"]
    assert ti.evaluate_tags(None, None, None)

    ti.tags=["deploy", "never"]
    assert not ti.evaluate_tags(None, None, None)

    ti.tags=["devops", "never"]
    assert ti.evaluate_tags(None, None, None)
    ti.tags=["deploy","devops", "never"]
    assert not ti.evaluate_tags(None, None, None)

    ti.tags=["deploy","devops", "never"]
    assert ti.evaluate_tags(['all'], None, None)

    ti.tags=["deploy", "never"]

# Generated at 2022-06-21 01:27:45.038069
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO: Make this into real unit tests.
    # Code here is just a scratchpad while writing the docs.
    # (https://docs.ansible.com/ansible/latest/user_guide/playbooks_filters_tags.html)

    class Mock():
        pass

    class MockItem(Taggable):
        pass

    item = MockItem()

    def assert_evaluate_tags(tags, expected, only_tags, skip_tags):
        item.tags = tags
        # create an all_vars dict that contains all of the values from the
        # only_tags and skip_tags list
        all_vars = dict((k, 1) for k in only_tags)
        all_vars.update((k, 1) for k in skip_tags)

# Generated at 2022-06-21 01:27:54.410892
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    taggable = Taggable()
    assert isinstance(taggable, Base)

    taggable = Taggable()

    # test tags property
    assert taggable.tags == list()

    # test evaluate_tags() method
    taggable = Taggable()
    taggable.tags = ['tag1', 'tag2']
    assert taggable.evaluate_tags(['tag1'], [], {}) == True
    assert taggable.evaluate_tags(['tag2'], [], {}) == True
    assert taggable.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert tag

# Generated at 2022-06-21 01:28:04.951638
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Check for the logic of evaluation of tags
    # First we create an object of class Taggable,
    # and we assign parameters for the tags, tags_skip and tags_only
    # We then call evaluate_tags method with the above parameters
    # depending on the evaluation, it returns a boolean value
    # which we assert in each of the test

    obj = Taggable()
    obj.tags = ['tagged', 'untagged']
    obj.tags_skip = None
    obj.tags_only = ['tagged']
    assert obj.evaluate_tags(obj.tags_only, obj.tags_skip, None) == True

    obj.tags_skip = ['tagged']
    obj.tags_only = None
    assert obj.evaluate_tags(obj.tags_only, obj.tags_skip, None) == False

    obj.tags

# Generated at 2022-06-21 01:28:12.693360
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Foo(Taggable):
        _ansible_module_name = 'types'
        _ansible_for_host = 'dummy'
        _task_name = 'dummy'
        _role = 'dummy'

    # Just for testing, create a dummy Foo task
    t = Foo()

    # Test with no only_tags, skip_tags and empty tags
    assert t.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) == True

    # Test with no only_tags, skip_tags and only 'untagged'
    t.tags = set(['untagged'])
    assert t.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) == True

    # Test with only_tags=all and empty tags
    assert t.evaluate_

# Generated at 2022-06-21 01:28:33.035298
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.tasks.include import Include
    from ansible.playbook.tasks.task import Task
    from ansible.playbook.conditional import Conditional

    # Playbook:
    # playbook.yml
    # ---
    # - hosts: localhost
    #   tasks:
    #     - include: task.yml
    #     - name: always run
    #       tags: ["always"]

    # Task:
    # tasks.yml
    # ---
    # - tags: a
    # - name: never run
    #   tags: ["never"]

    # 1. Check only_tags without skip_tags
    # 1.1 Check only_tags with tag 'all'


# Generated at 2022-06-21 01:28:44.911011
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block

    # We need to set some attributes because we can't instantiate Taggable
    # on its own, which would have been more pythonic.
    # Instead, we need to inherit from Base, which is a subclass of Taggable
    class TaggableTest(Base):
        def __init__(self):
            self._loader = None
            self.tags = []
            # Call the parent's __init__ method
            # The super method is not available in Python 2.6
            # thus we need to use Base.__init__ instead of super(Block, self).__init__
            Base.__init__(self)

    tt = TaggableTest()

    # Set the tags attribute

# Generated at 2022-06-21 01:28:46.498291
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert t.tags == []

# Generated at 2022-06-21 01:28:49.315364
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable_Test = Taggable()
    assert Taggable_Test
    assert Taggable_Test.untagged == frozenset(['untagged'])
    assert Taggable_Test._tags == []

# Generated at 2022-06-21 01:28:52.324453
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """ evaluate_tags() should return True when no tag option is specified """
    assert Taggable().evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True


# Generated at 2022-06-21 01:29:03.437407
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class cls(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # should run if no tags at all
    assert cls(tags=None).evaluate_tags(only_tags=None, skip_tags=None, all_vars={})

    # should run if no tags are specified
    assert cls(tags=None).evaluate_tags(only_tags=None, skip_tags=None, all_vars={})

    # should run if only_tags and skip_tags are both empty lists
    assert cls(tags=None).evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # should not run if there are only_tags and no tags are specified

# Generated at 2022-06-21 01:29:14.646244
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional

    from collections import namedtuple

    TestEntry = namedtuple('TestEntry', ['cls', 'kwargs', 'expected_tags'])

    class TestLoader:
        def __init__(self):
            pass

        def load_from_file(self, fname):
            return dict(key="value", tags=["test1", "test2"], _raw_params="{% if key %}bar{% endif %}",)


# Generated at 2022-06-21 01:29:25.138860
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class MockTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    # set up
    mt = MockTaggable()

    all_vars = dict()

    only_tags = []
    skip_tags = []

    # test default
    # when neither only_tags nor skip_tags are given,
    # evaluate_tags should return True
    assert mt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test a simple case
    mt.tags = ['foo']
    only_tags = ['foo']
    skip_tags = []
    assert mt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test a simple case

# Generated at 2022-06-21 01:29:35.032458
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    task = Task()
    handler = Handler()

    # Check if tags are set to default value
    assert task._tags == [] and handler._tags == []
    task.tags = None
    handler.tags = None
    assert task._tags == [] and handler._tags == []

    # Check whether _load_tags method works correctly
    assert task._load_tags('tags', 'a,b,c') == ['a', 'b', 'c']
    assert task._load_tags('tags', ['a', 'b', 'c']) == ['a', 'b', 'c']
    assert handler._load_tags('tags', ['a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-21 01:29:43.491442
# Unit test for constructor of class Taggable
def test_Taggable():
    test_object = Taggable()
    assert type(test_object.tags) == list, 'Expected list, got {}'.format(test_object.tags)
    assert type(test_object.tags) is not list, 'Expected not a list, got {}'.format(test_object.tags)
    assert hasattr(test_object, 'untagged')
    assert type(test_object._tags) is FieldAttribute, 'Expected FieldAttribute, got {}'.format(type(test_object._tags))
    assert type(test_object._load_tags(None, None)) == list, 'Expected list, got {}'.format(type(test_object._load_tags(None, None)))

# Generated at 2022-06-21 01:30:03.534515
# Unit test for constructor of class Taggable
def test_Taggable():

    # The constructor of class Taggable
    # is required to extend the default constructor
    # of its parent class(es).
    class A(Taggable):
        def __init__(self):
            Taggable.__init__(self)

    test_taggable = A()
    assert test_taggable
    assert isinstance(test_taggable, Taggable)
    assert not hasattr(test_taggable, "_tags")
    assert not hasattr(test_taggable, "untagged")



# Generated at 2022-06-21 01:30:15.148120
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Example 1:
    # check when only_tags is empty
    # check only if skip_tags is "never"
    only_tags = []
    skip_tags = ['never']

    tags = ['test']
    assert(Taggable.evaluate_tags(Taggable(tags),only_tags,skip_tags, {}))

    tags = ['never']
    assert(Taggable.evaluate_tags(Taggable(tags),only_tags,skip_tags, {}))

    tags = ['never', 'never']
    assert(Taggable.evaluate_tags(Taggable(tags),only_tags,skip_tags, {}))

    tags = ['test', 'never']
    assert(Taggable.evaluate_tags(Taggable(tags),only_tags,skip_tags, {}))


# Generated at 2022-06-21 01:30:17.307767
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == list
    assert t.evaluate_tags('', '', '')
    assert t.evaluate_tags(['tag'], '', '')

# Generated at 2022-06-21 01:30:21.264606
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)

    # Test Set Tags
    t.tags = ['A', 'B', 'C']
    assert t.tags == ['A', 'B', 'C']


# Generated at 2022-06-21 01:30:29.708896
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        def __init__(self, tags_):
            self._tags = tags_

    def _test_eval(tags_, only_tags, skip_tags, expected_result):
        my_taggable = MyTaggable(tags_)
        actual_result = my_taggable.evaluate_tags(only_tags, skip_tags, {})
        assert actual_result == expected_result

    _test_eval(tags_=[],
               only_tags=[],
               skip_tags=[],
               expected_result=True)

    _test_eval(tags_=['check_id'],
               only_tags=[],
               skip_tags=[],
               expected_result=True)


# Generated at 2022-06-21 01:30:37.121583
# Unit test for constructor of class Taggable
def test_Taggable():
    '''unit test for Taggable'''
    tb = Taggable()
    assert tb.tags == []
    tb2 = Taggable(tags=['1', 'two', u'\xe4', u'\u2603'])
    assert tb2.tags == ['1', 'two', u'\xe4', u'\u2603']
    tb3 = Taggable(tags="1,two,3")
    assert tb3.tags == ['1', 'two', '3']
    # make sure tags is always a list
    tb4 = Taggable(tags="1")
    assert tb4.tags == ['1']
    tb5 = Taggable(tags=1)
    assert tb5.tags == [1]

# Generated at 2022-06-21 01:30:45.676639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    ############################################
    #
    #  Test for only_tags
    #
    ############################################
    inventory = Inventory()
    variable_manager = VariableManager(inventory=inventory)

    # task: only_tags = always, tagged
    task1 = Task()
    task1.tags = ['always']
    only_tags = ['always', 'tagged']
    skip_tags = []
    assert task1.evaluate_tags(only_tags, skip_tags, variable_manager.get_vars())

    # task: only_tags = always, untagged
    task1 = Task()
    task1.tags = ['always']

# Generated at 2022-06-21 01:30:57.346425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml import from_yaml
    from ansible.playbook.task_include import TaskInclude

    # Untagged, no tags specified, will evaluate to true
    test_include_file = TaskInclude()
    test_include_file._load_name_from_data('tasks/main.yml')
    assert test_include_file.evaluate_tags(['all'], [], {}) == True

    # Untagged, 'all' tags specified, will evaluate to true
    test_include_file = TaskInclude()
    test_include_file._load_name_from_data('tasks/main.yml')
    assert test_include_file.evaluate_tags(['all'], [], {}) == True

    # Untagged, specific tag specified, will evaluate to false
    test_include

# Generated at 2022-06-21 01:31:04.871073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyClass:
        def __init__(self):
            pass

    # Create an instance of a class that inherits from Taggable
    tag_instance = DummyClass()
    tag_instance.tags = ['test_tag']

    # Only tag specified and task tagged, should run
    assert tag_instance.evaluate_tags(['test_tag'], [], {})

    # Only tag specified and task untagged, should not run
    tag_instance.tags = []
    assert not tag_instance.evaluate_tags(['test_tag'], [], {})

    # Only tag specified and task always, should run
    tag_instance.tags = ['always']
    assert tag_instance.evaluate_tags(['test_tag'], [], {})

    # Only tag specified and task never, should not run
    tag_instance.tags

# Generated at 2022-06-21 01:31:06.327700
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._load_tags([], None)

# Generated at 2022-06-21 01:31:41.705321
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    assert x.tags == []
    assert x.evaluate_tags(["tag1", "tag2"], [], {}) == True

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-21 01:31:43.191762
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-21 01:31:53.456282
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    Testing class Taggable
    '''

    # Test for member function _load_tags
    def test_load_tags(attr, ds):
        '''
        Testing member function _load_tags
        '''

        obj = Taggable()
        try:
            obj._load_tags(attr, ds)
        except Exception as e:
            print(e)

    obj = Taggable()

    # Test for member function _load_tags
    attr = 'tags'
    ds = ['tag1', 'tag2']
    test_load_tags(attr, ds)

    ds = 'tag1, tag2'
    test_load_tags(attr, ds)

    # Test for member function evaluate_tags
    # Testing for only_tags

# Generated at 2022-06-21 01:32:02.119995
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # TODO: add more tests and fix the existing ones

    # class Taggable has to be set up for testing
    def __init__(self, tags, only_tags = None, skip_tags = None, all_vars = None):
        self.tags = tags
        self.evaluate_tags(only_tags, skip_tags, all_vars)
        self.should_run

    tags = []
    only_tags = None
    skip_tags = None
    all_vars = None

    # list of tags
    Taggable(tags, only_tags, skip_tags, all_vars)
    assert should_run == True

    tags = ['foo', 'bar']
    only_tags = ['foo', 'bar']
    skip_tags = None

# Generated at 2022-06-21 01:32:14.195968
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import types
    if sys.version_info[0] < 3:
        str_type = basestring
        int_type = (int, long)
    else:
        str_type = str
        int_type = int
    from ansible.compat.tests import mock
    from io import StringIO
    from ansible.module_utils.six import PY2

    # Mock class for Taggable, needed for testing
    class Taggable(Taggable):
        def __init__(self):
            self.tags = []
            self.untagged = frozenset(['untagged'])
            self._tags = FieldAttribute(isa='list', default=list, listof=(str_type, int_type), extend=True)

    # Tests, creation of class objects
    taggable = Taggable

# Generated at 2022-06-21 01:32:16.620796
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    print(taggable.__dict__)


# Generated at 2022-06-21 01:32:23.994169
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    T = TestTaggable()

    T.tags = ['first', 'second']
    T.evaluate_tags('whatever', 'whatever', 'whatever')

    # test case:  object.tags=['tm1', 'tm2', 'tm3', 'tm4'],
    #             only_tags=['tm1','tm2','foobar'], skip_tags=['tm3', 'tm5']
    # should_run should be True
    only_tags = ['tm1','tm2','foobar']
    skip_tags = ['tm3', 'tm5']
    T.tags = ['tm1', 'tm2', 'tm3', 'tm4']
    assert(T.evaluate_tags(only_tags, skip_tags, 'whatever'))

    # test case:

# Generated at 2022-06-21 01:32:24.828505
# Unit test for constructor of class Taggable
def test_Taggable():
    pass

# Generated at 2022-06-21 01:32:31.917913
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    assert TestTaggable(tags=['foo']).tags == ['foo']
    assert TestTaggable(tags='bar').tags == ['bar']
    assert TestTaggable(tags=['a', 'b', 'c']).tags == ['a', 'b', 'c']
    try:
        TestTaggable(tags={'foo': 'bar'})
    except AnsibleError as e:
        assert "tags must be specified as a list" in str(e)

# Generated at 2022-06-21 01:32:39.775727
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    Validate the constructor of class Taggable for the following:
    1. Valid tags -  A list of tags containing a string and an integer value.
    2. Invalid tags - A list of tags containing a float.
    3. Null tags - No tags value specified.
    '''

    tags = ['tag1', 'tag2', 106]
    tags_should_pass = True
    try:
        t = Taggable()
        t._load_tags(None, tags)
    except AnsibleError:
        tags_should_pass = False
    finally:
        assert tags_should_pass, 'Valid tags are not being accepted'

    tags = ['tag1', 'tag2', 3.14]
    tags_should_pass = False

# Generated at 2022-06-21 01:34:00.951761
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json


# Generated at 2022-06-21 01:34:11.181456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create an instance of Taggable
    test_obj = Taggable()

    # Create an empty dict to hold vars
    all_vars = {}

    # Create a tag list and set the tags list of test_obj
    test_obj.tags = ['a', 'b', 'c']

    # Create a tag list that needs to be skipped
    skip_tags = ['a','b']

    # Create an empty list that needs to be run
    only_tags = []

    # Check if evaluate_tags should_run for the above settings
    should_run = test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Check if the result is False since all tags in test_obj.tags are skipped
    assert should_run == False

    # Set skip_tags to an empty list
    skip_tags

# Generated at 2022-06-21 01:34:22.101431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
        Test case for method evaluate_tags of class Taggable
    """
    class Taggable_Evaluate_Tags(Taggable):
        def __init__(self, tags):
            self._tags = tags
    # Check if the method evaluate_tags returns True
    # If the tags specified are present in the list
    # of only_tags
    only_tags = ['tag_1', 'tag_2', 'tag_3']
    assert (Taggable_Evaluate_Tags(['tag_1', 'tag_2'])).evaluate_tags(only_tags, [], {})
    assert (Taggable_Evaluate_Tags(['tag_1', 'tag_2', 'tag_3'])).evaluate_tags(only_tags, [], {})