

# Generated at 2022-06-21 01:24:38.686532
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # class MockTaggable(Taggable):
    #     pass

    # class MockTaggable(Taggable):
    #     _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    #     def __init__(self,tags):
    #         self.tags = tags
    #         super(MockTaggable,self).__init__()

    class MockTaggable(Taggable):
        def __init__(self,tags):
            self.tags = tags
            # super(MockTaggable,self).__init__()
    
    #MockTaggable._tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    # Create an instance of the class and evaluate the tags


# Generated at 2022-06-21 01:24:50.882287
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    playbook_included_tags = set()
    only_tags = None
    skip_tags = None
    all_vars = dict()
    # Test task with include only_tags
    t1 = Task(); t1.tags = ["always"]
    assert t1.evaluate_tags(playbook_included_tags, only_tags, skip_tags, all_vars)
    only_tags = set(["tag1"])
    assert not t1.evaluate_tags(playbook_included_tags, only_tags, skip_tags, all_vars)
    # Test task with include skip_tags
    t2 = Task(); t2.tags = ["never"]

# Generated at 2022-06-21 01:25:00.609318
# Unit test for constructor of class Taggable
def test_Taggable():
    from six import assertRegex
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    test_Taggable = Taggable()

    #test pretagging
    test_Taggable._tags=['test_tag']

    #test _load_tags
    dict_1 = dict(test_tag = 'test_tag')
    dict_2 = dict(test_tag = ['test_tag', 'test_tag2'])
    dict_3 = dict(test_tag = 'test_tag,test_tag2')
    dict_4 = dict(test_tag = ['test_tag', 'test_tag2'])
    dict_5 = dict(bad_key = 'test_tag')

    test_T

# Generated at 2022-06-21 01:25:12.572611
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    
    # Test evaluate_tags for class Task
    task = Task()
    assert task.evaluate_tags(only_tags=['tag'], skip_tags=[], all_vars={}) == False
    task.tags.append('tag')
    assert task.evaluate_tags(only_tags=['tag'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-21 01:25:18.930117
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable().tags == []
    assert Taggable().tags == []
    assert Taggable(tags=['a']).tags == ['a']
    assert Taggable(tags='a').tags == ['a']
    assert Taggable(tags='a,b').tags == ['a', 'b']
    assert Taggable(tags='a ,b').tags == ['a', 'b']

# Generated at 2022-06-21 01:25:26.542064
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags([], 'tags') == ['tags']
    assert Taggable()._load_tags([], ['tags']) == ['tags']
    assert Taggable()._load_tags([], ('tags', 'tags2')) == ['tags', 'tags2']
    assert Taggable()._load_tags([], 1) == [1]
    assert Taggable()._load_tags([], ['tags', 1]) == ['tags', 1]
    assert Taggable()._load_tags([], ('tags', 1)) == ['tags', 1]
    assert Taggable()._load_tags([], ['tags, tags2']) == ['tags, tags2']
    assert Taggable()._load_tags([], 'tags,tags2') == ['tags,tags2']
    assert Taggable()._load_

# Generated at 2022-06-21 01:25:35.587851
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.plugins import module_loader

    pb = Play().load({'name': 'template', 'hosts': 'localhost'})

    t = Task().load({'name': 'debug', 'debug': 'msg={{foo}}', 'vars': {'foo': 'bar'}, 'tags': ['a', 'b', 'c']})
    t._play = pb
    t._role = None
    t._block = Block.load(dict(t.get_vars()), pb=pb)


# Generated at 2022-06-21 01:25:36.604740
# Unit test for constructor of class Taggable
def test_Taggable():
    # Check import
    assert Taggable

# Generated at 2022-06-21 01:25:46.978356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy:
        _loader = None
        def __init__(self, tags=None, always_run=False):
            self.tags = tags or []
            self.always_run = always_run

    class TestCase:
        def __init__(self, all_vars, item, only, tags, should_run):
            self.all_vars = all_vars
            self.item = item
            self.only = only
            self.tags = tags
            self.should_run = should_run


# Generated at 2022-06-21 01:25:50.560323
# Unit test for constructor of class Taggable
def test_Taggable():
    # create an instance of Taggable
    taggable = Taggable()
    # assert the default values
    assert taggable._tags is not None
    assert isinstance(taggable._tags, list)
    assert len(taggable._tags) == 0


# Generated at 2022-06-21 01:25:59.091600
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert a._tags == []
    assert a.tags == []


# Generated at 2022-06-21 01:26:07.958686
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from collections import namedtuple

    class FakeDS(namedtuple('FakeDS', ['name', 'tags'])):
        def isdisjoint(self, other):
            # Set difference, same logic as set.isdisjoint()
            return not self.tags.intersection(other)

    class FakeClass(Taggable):
        pass


# Generated at 2022-06-21 01:26:20.007914
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Import here because Taggable is in the module Ansible
    from ansible.playbook.task import Task, TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Mocking of classes for testing purpose
    class MockPlaybook:
        variable_manager = VariableManager()

    playbook = MockPlaybook()

    class MockPlay:
        variable_manager = VariableManager()

    class MockRole:
        variable_manager = VariableManager()

    class MockIncludedFile:
        variable_manager = VariableManager()


# Generated at 2022-06-21 01:26:22.082845
# Unit test for constructor of class Taggable
def test_Taggable():
    tg = Taggable()
    assert tg._tags == []
    assert tg.tags == []



# Generated at 2022-06-21 01:26:29.703787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import os
    import sys
    import unittest2 as unittest

    from ansible.errors import AnsibleError
    from ansible.parsing import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-21 01:26:41.358642
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os, sys, inspect
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook import Play


    from ansible.playbook.task_include import TaskInclude

    class TestCallbackModule(CallbackBase):
        """
        Test callback module
        """

        def __init__(self):
            return super(TestCallbackModule, self).__init__()

        def v2_playbook_on_task_start(self, task, is_conditional):
            print

# Generated at 2022-06-21 01:26:44.213184
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert not t.tags == t.untagged

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-21 01:26:47.592350
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    tags = taggable._load_tags("tags", "one, two")
    assert tags == ["one", "two"]

# Generated at 2022-06-21 01:26:59.257970
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize instance of class Taggable
    ta = Taggable()
    # Initialize a set of tags and assign it to attribute tags of class Taggable
    ta.tags = set(['tag1', 'tag2', 'tag3', 'tag4', 'tag5'])
    # Initialize a set of skip_tags and a set of only_tags
    skip_tags = set(['tag4', 'tag5'])
    only_tags = set(['tag2', 'tag3'])
    # Invoke the method under test with the initialized instance of class Taggable, the set of skip_tags and only_tags
    # and the default all_vars set {}
    # This should return True as the code under test will not enter the conditional statement
    # if only_tags and not tags.isdisjoint(only_tags):


# Generated at 2022-06-21 01:27:01.546338
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert isinstance(obj.tags, list)
    assert obj.tags == []
    assert obj.untagged == frozenset(['untagged'])

# Generated at 2022-06-21 01:27:23.263300
# Unit test for constructor of class Taggable
def test_Taggable():
    test = Taggable()
    test.tags = []
    if test.tags != []:
        raise AssertionError()
    if test._load_tags(2, 3) != 3:
        raise AssertionError()
    if test._load_tags(2, "abc") != ["abc"]:
        raise AssertionError()
    if test._load_tags(2, ["abc","def"]) != ["abc","def"]:
        raise AssertionError()
    if test._load_tags(2, [3,4]) != [3,4]:
       raise AssertionError()

# Generated at 2022-06-21 01:27:32.149312
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    class Playbook(Taggable):
        pass

    playbook = Playbook()
    playbook.tags = ['foo', 'bar']
    playbook.evaluate_tags('', '', {})
    assert set(playbook.tags) == set(['foo', 'bar'])

    playbook.tags = ['foo', ['bar', 'baz']]
    playbook.evaluate_tags('', '', {})
    assert set(playbook.tags) == set(['foo', 'bar', 'baz'])

    playbook.tags = ['foo', 'bar']
    playbook.evaluate_tags('', '', {'bar': 'baz'})
    assert set(playbook.tags) == set(['foo', 'bar'])

    playbook.tags = ['foo', ['bar', '{{ bar }}']]
    playbook.evaluate_

# Generated at 2022-06-21 01:27:44.279710
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    class test_Taggable_evaluate_tags(unittest.TestCase):

        class fake_Taggable(Taggable):
            def __init__(self, file, task_vars):
                self._loader = fake_loader()
                self.tags = file
                self.task_vars = task_vars

        def test_1(self):
            f = self.fake_Taggable({ 'value' : 't1, t2' },
            { 'tags' : [ 't1' , 't2', 't3' ], 'skip_tags': [ 't3', 't4' ] })
            self.assertTrue(f.evaluate_tags( ['t3','t6'], [], {} ))

        def test_2(self):
            f = self.fake_Tagg

# Generated at 2022-06-21 01:27:50.443949
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    t.tags = ['foo']
    assert t._tags == ['foo']
    t.tags = 'bar'
    assert t._tags == ['bar']
    t.tags = ['foo' , 'bar']
    assert t._tags == ['foo' , 'bar']
    t.tags = 'foo,bar'
    assert t._tags == ['foo', 'bar']


# Generated at 2022-06-21 01:27:54.975780
# Unit test for constructor of class Taggable
def test_Taggable():
    from collections import Iterable
    assert isinstance(Taggable.untagged, frozenset)
    assert isinstance(Taggable.untagged, Iterable)

# Generated at 2022-06-21 01:27:58.132918
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []

taggable = Taggable()


# Generated at 2022-06-21 01:28:06.341449
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from ansible.playbook import Playbook, Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:28:16.434851
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def test_tags_result(tags, only_tags, skip_tags, all_vars, expected_result):
        class TaggableMock(Taggable):
            def __init__(self): self.tags = tags
        import six
        all_vars = all_vars or {}
        only_tags = only_tags or []
        skip_tags = skip_tags or []
        if not isinstance(tags, six.string_types): tags = tags
        print("\n- tags: %s, only_tags: %s, skip_tags: %s, all_vars: %s" % (tags, only_tags, skip_tags, all_vars))
        res = TaggableMock().evaluate_tags(only_tags, skip_tags, all_vars)
        if res == expected_result: print

# Generated at 2022-06-21 01:28:23.501154
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader

    t = Taggable()
    loader = DataLoader()

    new_tags = ['tag1', 'tag2', 'tag3']
    assert t.tags is None
    t._load_tags('tags', new_tags)
    assert t.tags == new_tags
    t._load_tags('tags', 'tag1,tag2,tag3')
    assert t.tags == new_tags

    # validate that the tags are correctly evaluated
    all_vars = dict(foo=['bar'])
    t._tags = ['foo']
    assert t.evaluate_tags(['all', 'tagged'], [], all_vars)
    assert t.evaluate_tags(['tagged'], [], all_vars)
    assert not t.evaluate_tags

# Generated at 2022-06-21 01:28:35.071419
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Unit tests for class Taggable.evaluate_tags
    # First, we define a Taggable class that has tags and a
    # evaluate_tags method that calls super()
    class A(Taggable):
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return super(A, self).evaluate_tags(only_tags, skip_tags, all_vars)

    # the following tests should be true

# Generated at 2022-06-21 01:29:13.510470
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible import playbooks
    from ansible.utils.vars import combine_vars

    # test a playbook, which contains:
    # - a play with tags (['a','b']), with a task containing tags
    # - a play with no tags
    pb = playbooks.Playbook.load('../../tests/playbook/playbook_tags.yml', loader=playbooks.playbook, variable_manager=playbooks.variable_manager)

    all_vars = combine_vars(pb.get_vars(), pb.get_vars_files())

    pb.post_validate(play_context=playbooks.play_context)
    pb.static_inventory.post_validate(loader=playbooks.loader, variable_manager=playbooks.variable_manager)

    assert pb.get_plays

# Generated at 2022-06-21 01:29:16.300309
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-21 01:29:25.770888
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import mock

    # setup data
    obj = Taggable()
    obj.tags = ['tag1', 'tag2']

    # we want to test the 'always' condition
    only_tags = ['always', 'other']
    skip_tags = []
    all_vars = {}

    # the mocked method returns True for 'always'
    with mock.patch.object(obj, 'has_run_once', return_value=True):
        assert(True == obj.evaluate_tags(only_tags, skip_tags, all_vars))

    # the mocked method returns False for 'always'
    with mock.patch.object(obj, 'has_run_once', return_value=False):
        assert(True == obj.evaluate_tags(only_tags, skip_tags, all_vars))

    # we want to test the

# Generated at 2022-06-21 01:29:37.406884
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test_Taggable_evaluate_tags
    Unit test for method evaluate_tags of class Taggable
    '''
    from ansible.playbook.task import Task
    task_ds = {}
    task = Task.load(task_ds, None, None, None)
    only_tags = set()
    skip_tags = set()

    # with no tags
    assert task.evaluate_tags(only_tags, skip_tags, {})

    # with tags
    task.tags = ['role1', 'role2', 'role3']
    assert task.evaluate_tags(only_tags, skip_tags, {})

    # with only_tags
    only_tags = set(['role1', 'role2'])
    assert task.evaluate_tags(only_tags, skip_tags, {})

# Generated at 2022-06-21 01:29:45.185046
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleUnicode

    mock_vars = [
        ('the_tag_var', 'tag_value'),
        ('the_tag_list_var', ['tag_value', 'another_tag_value']),
        ('the_skip_tag_list_var', ['tag_value', 'another_tag_value']),
        ('the_untagged_var', 'untagged'),
    ]
    MockTask = namedtuple('MockTask', ['tags', '_loader'])
    MockLoader = namedtuple('MockLoader', ['path_dwim'])

    loader = MockLoader(path_dwim=lambda x: 'loader/' + AnsibleUnicode(x))


# Generated at 2022-06-21 01:29:58.359838
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    play = Taggable()

    play.tags = []

    only_tags = set(['all'])
    skip_tags = set()
    all_vars = dict()
    result = play.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result, "Test with all only_tags should run"

    only_tags = set(['all'])
    skip_tags = set(['all'])
    all_vars = dict()
    result = play.evaluate_tags(only_tags, skip_tags, all_vars)
    assert not result, "Test with all only_tags and skip_tags should not run"

    only_tags = set(['all'])
    skip_tags = set(['always'])
    all_vars = dict()
    result = play.evaluate_

# Generated at 2022-06-21 01:29:59.207094
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-21 01:30:11.885526
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    block = Block()
    task1 = Task()
    task1._parent = block
    task2 = Task()
    task2._parent = block
    play = Play()
    play._included_path = 'test'
    play._included_file = 'test'
    block._parent = play

    # this checks if the current item should be executed depending on tag options
    # def evaluate_tags(self, only_tags, skip_tags, all_vars):

    # tags are specified as a list, one or more tags, which can be processed by Jinja2

    # Task
    # Task _tags
    #  should_run = True, tasks to run
    # Play
   

# Generated at 2022-06-21 01:30:22.292879
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os
    import copy
    import ansible.playbook
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class MyTask(Task, Taggable):
        pass

    class MyBlock(Block, Taggable):
        pass

    loader = DataLoader()
    variable_manager = VariableManager()

    # Create playbook

# Generated at 2022-06-21 01:30:29.508127
# Unit test for constructor of class Taggable
def test_Taggable():
    def _tags(tags):
        assert tags == ["foo", "bar"] or tags == ["foo"] or tags == []

    taggable = Taggable()
    taggable._load_tags("foo,bar")
    _tags(taggable.tags)
    taggable._load_tags("foo")
    _tags(taggable.tags)
    taggable._load_tags([])
    _tags(taggable.tags)
    taggable._load_tags([])
    _tags(taggable.tags)
    taggable._load_tags(["foo"])
    _tags(taggable.tags)

# Generated at 2022-06-21 01:31:33.458905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    class TestTaggable(Taggable):
        def __init__(self, *args, **kwargs):
            super(TestTaggable, self).__init__(*args, **kwargs)
            self._tags = None

        @staticmethod
        def load(data, loader=None):
            tt = TestTaggable()
            tt._tags = data.get('tags')
            tt._loader = loader
            return tt

    tt = TestTaggable()

    # Test empty tags
    tt._tags = []
    assert tt.evaluate_tags([], [], {})

# Generated at 2022-06-21 01:31:37.957884
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    print(Task)
    assert issubclass(Task, Taggable)
    print(getattr(Task, '_tags'))
    assert getattr(Task, '_tags') == FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    tt = Task()
    print(isinstance(tt, list))
    assert isinstance(tt, list) == True

# Generated at 2022-06-21 01:31:42.956680
# Unit test for constructor of class Taggable
def test_Taggable():
    class TempTaggable:
        def __init__(self, tags):
            self._tags = tags

        def __getattr__(self, attr):
            return self._tags

    taggable = TempTaggable(['michael', 'herculis'])
    assert taggable.tags == ['michael', 'herculis']

# Generated at 2022-06-21 01:31:53.212165
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    ti = TaskInclude()

    ti._variable_manager = VariableManager()
    ti._variable_manager.set_nonpersistent_facts(dict(ansible_tags=['foo','bar']))

    assert ti.evaluate_tags(['always'], [], dict()) == True
    assert ti.evaluate_tags(['foo'], [], dict()) == True
    assert ti.evaluate_tags(['bar'], [], dict()) == True
    assert ti.evaluate_tags(['never'], [], dict()) == False
    assert ti.evaluate_tags(['all'], [], dict()) == True
    assert ti.evaluate_tags([], [], dict()) == True

# Generated at 2022-06-21 01:32:03.498695
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    assert isinstance(Taggable()._tags, list)
    assert isinstance(Taggable()._load_tags('_tags', [123, '456']), list)
    assert isinstance(Taggable()._load_tags('_tags', 123), list)

    try:
        Taggable()._load_tags('_tags', 123.456)
        assert False, "should have raised an exception"
    except AnsibleError:
        pass

    try:
        Block()
        assert False, "should have raised an exception"
    except AnsibleError:
        pass


# Generated at 2022-06-21 01:32:14.752956
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.mod_args import ModuleArgsParser

    module_args_parser = ModuleArgsParser()
    module_args = module_args_parser.parse_args('', "", "", "", "", "", "", {})[0]
    module_args.tags = []
    module_args.skip_tags = []
    module_args.only_tags = []
    assert module_args.evaluate_tags(module_args.only_tags, module_args.skip_tags, {})
    module_args.tags = 'first_tag'
    module_args.skip_tags = ['second_tag']
    assert module_args.evaluate_tags(module_args.only_tags, module_args.skip_tags, {})
    module_args.tags = ['first_tag', 'second_tag']
    module

# Generated at 2022-06-21 01:32:22.487208
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    class MockTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=[], listof=(string_types, int))

        def __init__( self, include_tags = None, exclude_tags = None ):
            self._tags = include_tags
            self._load_tags( '_tags', include_tags )
            self.should_run = self.evaluate_tags( include_tags, exclude_tags, dict() )

    class MockTaggedTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=['always', 'foo'], listof=(string_types, int))

        def __init__( self, include_tags = None, exclude_tags = None ):
            self._load_tags( '_tags', include_tags )
            self.should_run

# Generated at 2022-06-21 01:32:25.099390
# Unit test for constructor of class Taggable
def test_Taggable():
    #Arrange
    from ansible.playbook.base import Base
    from ansible.playbook.plays import Play

    #Act
    play = Play()

    #Assert
    assert isinstance(play, Base)
    assert isinstance(play, Taggable)


# Generated at 2022-06-21 01:32:33.804756
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    # creation of object: Task
    task_obj = Task()
    # creation

# Generated at 2022-06-21 01:32:42.509816
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags('a', ['test1','test2']) == ['test1','test2']
    assert Taggable()._load_tags('a', 'test1,test2') == ['test1', 'test2']
    assert Taggable()._load_tags('a', 'test1') == ['test1']
    try:
        Taggable()._load_tags('a', '1')
    except:
        assert 1
    try:
        Taggable()._load_tags('a', 1)
    except:
        assert 1
    try:
        Taggable()._load_tags('a', {})
    except:
        assert 1