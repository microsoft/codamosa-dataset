

# Generated at 2022-06-21 01:24:30.197812
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        pass
    tt = TestTaggable()
    assert tt.tags == []

# Generated at 2022-06-21 01:24:38.300122
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.plugin.loader import load_plugin
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    # Test Task
    t = Task()
    t._loader = loader
    t._variable_manager = variable_manager
    t._shared_loader_obj = loader
    t._task_vars = dict()
    t._role_vars = dict()
    t._play = Play()

# Generated at 2022-06-21 01:24:50.414764
# Unit test for constructor of class Taggable
def test_Taggable():
    def load_tags(attr, ds):
        return ds
    class TestTaggable(Taggable):
        pass
    test = TestTaggable()
    assert hasattr(test, '_tags')
    test._load_tags = load_tags
    # test the case of ds is a list
    test.tags = ['a','b','c']
    ret = test._load_tags(None, ['b','c','d'])
    assert isinstance(ret, list)
    assert ret == ['b','c','d']
    # test the case of ds is a string
    ret = test._load_tags(None, "a,b,d")
    assert isinstance(ret, list)
    assert ret == ['a','b','d']
    # test the case of ds is an int

# Generated at 2022-06-21 01:25:00.299825
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['tag1','tag2','tag3']
    # Run the test
    assert t.evaluate_tags(['tag1'],[],{}) == True, "tag1 should run"
    assert t.evaluate_tags(['tag2'],[],{}) == True, "tag2 should run"
    assert t.evaluate_tags(['tag3'],[],{}) == True, "tag3 should run"
    assert t.evaluate_tags(['tag4'],[],{}) == False, "tag4 should not run"

    assert t.evaluate_tags(['tag1','tag2'],[],{}) == True, "both tag1 and tag2 should run"

# Generated at 2022-06-21 01:25:10.024156
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Run `python -m ansible.utils.test_debug Taggable_evaluate_tags`

    From t/test-taggable.yml:
        - name: "Ensure that 'evaluate_tags' returns True when given no tags"
          import_playbook: t/test-taggable.yml
          tags: ['untagged', 'skip']
          register: res

    '''
    tags = Taggable()
    tags.tags = []
    only_tags = []
    skip_tags = []
    assert tags.evaluate_tags(only_tags, skip_tags, all_vars={})



# Generated at 2022-06-21 01:25:21.339131
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """ Test evaluate_tags behavior
    """
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test Block
    b = Block()
    b.tags = ['a', 'b']
    assert b.evaluate_tags(['a'], [], {})
    assert b.evaluate_tags(['a'], ['b'], {})
    assert not b.evaluate_tags(['c'], [], {})
    assert not b.evaluate_tags(['c'], ['b'], {})
    assert b.evaluate_tags([], ['b'], {})
    assert b.evaluate_tags([], [], {})
    assert not b.evaluate_tags([], ['x'], {})

    # Test Task
    t = Task()

# Generated at 2022-06-21 01:25:22.884971
# Unit test for constructor of class Taggable
def test_Taggable():
    #Taggable()
    return True

test_Taggable()


# Generated at 2022-06-21 01:25:33.620073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test for only_tags
    only_tags = ['all', 'tagged', 'untagged']
    skip_tags = []
    test_tags = ['all']
    tag_object = Taggable()
    tag_object._tags = test_tags
    assert tag_object.evaluate_tags(only_tags, skip_tags, {})

    test_tags = []
    tag_object._tags = test_tags
    assert tag_object.evaluate_tags(only_tags, skip_tags, {})
    
    test_tags = ['tagged']
    tag_object._tags = test_tags
    assert tag_object.evaluate_tags(only_tags, skip_tags, {})
    
    test_tags = ['untagged']
    tag_object._tags = test_tags

# Generated at 2022-06-21 01:25:43.774732
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._tags, list)
    assert taggable._tags == []
    assert taggable._load_tags("", {}) == []
    assert taggable._load_tags("", []) == []
    assert taggable._load_tags("", "Hello,world") == ["Hello", "world"]
    try:
        taggable._load_tags("", 37)
        assert False
    except:
        pass
    assert taggable.evaluate_tags("", "", "")
    taggable._tags = "Hello,world"
    assert taggable.evaluate_tags("", "", "")

# Generated at 2022-06-21 01:25:52.870103
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    t = Task()
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={'tags': ['always']}) == True
    assert t.evaluate_tags(only_tags=['test'], skip_tags=['test'], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['test'], skip_tags=['test'], all_vars={'tags': ['test']}) == False
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['test'], all_vars={}) == True

# Generated at 2022-06-21 01:26:02.231628
# Unit test for constructor of class Taggable
def test_Taggable():
    class Test(Taggable):
        pass
    assert Test(tags=['a'])
    assert Test(tags=['a', 'a'])

# Generated at 2022-06-21 01:26:14.452922
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """Test Taggable class's method evaluate_tags"""
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    # tags in item are subset of tags in either only_tags and skip_tags

    # test with only_tags
    task = Task()
    block = Block()
    task.tags = ['t1', 't2', 't3']
    block.tags = ['t2']
    play_context = PlayContext()

    # test with only_tags = ['t1', 't2']
    play_context.only_tags = ['t1', 't2']
    play_context.skip_tags = []

# Generated at 2022-06-21 01:26:25.450861
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    assert FakeTaggable(tags=['foobar']).evaluate_tags(skip_tags=[], only_tags=[], all_vars={})
    assert not FakeTaggable(tags=['foobar']).evaluate_tags(skip_tags=['foobar'], only_tags=[], all_vars={})
    assert not FakeTaggable(tags=['foobar']).evaluate_tags(skip_tags=[], only_tags=['bar'], all_vars={})
    assert FakeTaggable(tags=['foobar']).evaluate_tags(skip_tags=[], only_tags=['foobar'], all_vars={})
    assert not FakeTaggable(tags=['foobar']).evaluate

# Generated at 2022-06-21 01:26:38.182720
# Unit test for constructor of class Taggable
def test_Taggable():
    t1 = Taggable()
    t2 = Taggable()
    t3 = Taggable()
    t1.tags = ["apple", "banana"]
    t2.tags = ["pear"]
    t3.tags = []

    t1._tags = "apple, banana"
    t2._tags = "pear"
    t3._tags = ""

    # test_t1
    assert t1.tags == ["apple", "banana"]
    assert t1._tags == "apple, banana"
    assert t1.evaluate_tags(None, None, None) == True

    # test_t2
    assert t2.tags == ["pear"]
    assert t2._tags == "pear"
    assert t2.evaluate_tags(None, None, None) == True

    # test_t3

# Generated at 2022-06-21 01:26:42.156511
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Validates the Taggable Class.
    This testcase tests the constructor of the Taggable class.
    It checks if Taggable class is correctly initialized.
    """
    test = Taggable()
    assert test._tags == []
    assert test.tags == []



# Generated at 2022-06-21 01:26:49.105089
# Unit test for constructor of class Taggable
def test_Taggable():
    assert '_load_tags' in dir(Taggable)
    assert 'untagged' in dir(Taggable)
    assert '_tags' in dir(Taggable)
    assert str(type(Taggable.untagged)) == "<class 'frozenset'>"
    assert str(type(Taggable._tags)) == "<class 'ansible.playbook.attribute.FieldAttribute'>"

# Unit tests for constructor of class FieldAttribute

# Generated at 2022-06-21 01:27:00.505229
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert t.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    t.tags = ['tag1', 'tag2']
    assert t.tags == ['tag1', 'tag2']
    assert t.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    assert t.evaluate_tags(only_tags=[], skip_tags=None, all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=None, all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == True


# Generated at 2022-06-21 01:27:02.216950
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert type(t.tags) == list
    assert len(t.tags) == 0

# Generated at 2022-06-21 01:27:10.960861
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy1(Taggable):
        pass

    class Dummy2(Taggable):
        tags = ['cat', 'dog']

    class Dummy3(Taggable):
        tags = ['cat', 'monkey']

    class Dummy4(Taggable):
        tags = ['tagged', 'dog']

    assert Dummy1().evaluate_tags(['dog'], [], {}) == True
    assert Dummy1().evaluate_tags(['cat'], [], {}) == False
    assert Dummy2().evaluate_tags(['cat'], [], {}) == True
    assert Dummy2().evaluate_tags([], ['dog'], {}) == False
    assert Dummy2().evaluate_tags([], ['cat'], {}) == True

# Generated at 2022-06-21 01:27:21.488973
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os

    # - set up fake vars
    class fake_vars:
        pass

    fake_loader = None
    test_vars = fake_vars()
    test_vars.local = os.path.dirname(os.path.abspath(__file__))
    test_vars.group_names = ['fake_group']

    # - test when no tags are specified
    test_play = Taggable()
    test_play._loader = fake_loader

    test_play.tags = None
    assert test_play.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], test_vars) == True

    # - test when tags are specified
    test_play.tags = ['tag1', 'tag2', 'tag3', 'tag4']

    assert test

# Generated at 2022-06-21 01:27:46.023851
# Unit test for constructor of class Taggable
def test_Taggable():
    '''test constructor of class Taggable'''

    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # test for class Role
    r = Role()
    assert r.tags is None
    r = Role(tags=['tag'])
    assert r.tags == ['tag']
    r.tags = ['tag1', 'tag2']
    assert r.tags == ['tag1', 'tag2']
    r = Role(tags=['tag1', 'tag2'])
    assert r.tags == ['tag1', 'tag2']
    r = Role(tags='tag1, tag2')
    assert r.tags == ['tag1', 'tag2']
    r.tags = 'tag1, tag2'
    assert r.tags == ['tag1', 'tag2']
   

# Generated at 2022-06-21 01:27:55.061551
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    variables = dict()
    variables['tag_bad_tag_at_start'] = 'bad,good'
    variables['tag_trailing_comma'] = 'bad,'
    variables['tag_bad_tag_with_comma'] = 'bad,good,bad'
    variables['tag_all'] = 'all'
    variables['tag_always'] = 'always'
    variables['tag_never'] = 'never'
    variables['tag_untagged'] = 'untagged'
    variables['tag_tagged'] = 'tagged'
    variables['tag_no_space_tag'] = 'nospace'
    variables['tag_space_tag'] = 'space'
    variables['tag_digit_tag'] = '1'
   

# Generated at 2022-06-21 01:28:06.355011
# Unit test for constructor of class Taggable
def test_Taggable():
    task1 = Taggable()
    task2 = Taggable()

    # Test 1: Set tags to list
    task1.tags = ['tag1','tag2','tag3']
    print("Task 1 tags: {}".format(task1.tags))
    if task1.tags == ['tag1','tag2','tag3']:
        print("Test 1 passed!")
    else:
        print("Test 1 failed!")

    # Test 2: Set tags to list
    task2.tags = ['tag1','tag2','tag3']
    print("Task 2 tags: {}".format(task2.tags))
    if task2.tags == ['tag1','tag2','tag3']:
        print("Test 2 passed!")
    else:
        print("Test 2 failed!")

    # Test 3: Get tags from task 1


# Generated at 2022-06-21 01:28:16.473350
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()
    task._role = None
    task._block = None
    assert task.evaluate_tags(only_tags=['foo'], skip_tags=['bar', 'foobar'], all_vars={}) == False
    assert task.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == False
    assert task.evaluate_tags(only_tags=[], skip_tags=['bar', 'foobar'], all_vars={}) == True
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    # Test that tags can be specified as a string (comma-separated list of words)
    task.tags = ['foo']

# Generated at 2022-06-21 01:28:25.649986
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    task = Task()

    # Test constructor
    assert isinstance(task.tags, list)
    assert len(task.tags) == 0

    # Test _load_tags
    task.tags = "tag1"
    assert task.tags == ["tag1"]
    task.tags = "tag1, tag2"
    assert task.tags == ["tag1", "tag2"]
    task.tags = [ "tag1", "tag2" ]
    assert task.tags == ["tag1", "tag2"]

    # Test evaluate_tags
    # assert task.evaluate_tags(None, None, None)

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-21 01:28:26.915840
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-21 01:28:33.184993
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('This is a unit test of the Taggable class')
    import pdb
    pdb.set_trace()

# Generated at 2022-06-21 01:28:44.994029
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Tests for Taggable class
    """
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os
    import sys

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    # Test basic Taggable constructor
    my_taggable = Taggable()
    assert my_taggable.tags == []
    assert my_taggable.evaluate_tags([], [], {}) == True

    # Test simple assignation
    my_taggable = Taggable()
    my_taggable.tags = [u"test"]
    assert my_t

# Generated at 2022-06-21 01:28:51.428748
# Unit test for constructor of class Taggable
def test_Taggable():
    # instantiate a Taggable object
    myTaggable = Taggable()
    # set the default value
    myTaggable._tags = list('tag1')
    # check the value after loading
    assert myTaggable.tags == ['tag1']
    # check the function evaluate_tags
    assert myTaggable.evaluate_tags(['tag1','tag2'], ['tag3','tag4'], {}) == True
    myTaggable.tags = []
    assert myTaggable.evaluate_tags(['tag1','tag2'], ['tag3','tag4'], {}) == False

# Generated at 2022-06-21 01:29:03.041050
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Test to see if the Taggable class is working
    """
    # Create a MockAttribute instance to be used for the test
    class MockAttribute(object):
        def __init__(self, value):
            self.value = value
        def __eq__(self, other):
            return self.value == other
    # Create a MockHost instance to be used for the test
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    mock_hosts = [
        Host(name='localhost', port=22),
        Host(name='localhost', port=22),
        Host(name='localhost', port=22),
    ]
    group = Group(name='localhost')
    group.add_host(mock_hosts[0])
   

# Generated at 2022-06-21 01:29:18.080907
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == list

# Generated at 2022-06-21 01:29:20.296732
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    >>> tr = Taggable()
    >>> tr.tags = ['bob']
    >>> tr.tags
    ['bob']
    '''

# Generated at 2022-06-21 01:29:27.731903
# Unit test for constructor of class Taggable
def test_Taggable():
    #assert Taggable() is None
    #assert Taggable() == {}
    #assert Taggable() == {}
    #assert Taggable() == ''
    #assert Taggable() == ''
    #assert Taggable() == ''
    #assert Taggable() == ''
    #assert Taggable() == ''
    assert Taggable() == ''


# Generated at 2022-06-21 01:29:40.776938
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:29:53.463532
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os

    # FIXME: for some reason the handler is not being loaded here ...
    # fix later
    from ansible import constants as C
    from ansible.plugins import lookup_loader, filter_loader, module_loader, test_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    lookup_loader.add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'lookup_plugins'))
    filter_loader.add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'filter_plugins'))
    module_loader.add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'action_plugins'))

# Generated at 2022-06-21 01:30:01.922047
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    # Test with only_tags and skip_tags both empty
    testobj = TestClass()
    testobj.tags = []
    assert testobj.evaluate_tags([], [], {}) is True

    # Test with an empty tag
    testobj.tags = ['']
    assert testobj.evaluate_tags([], [], {}) is True

    # Test with an only_tag of 'tagged'
    testobj.tags = ['some_tag']
    assert testobj.evaluate_tags(['tagged'], [], {}) is True

    # Test with an only_tag of 'some_tag'
    testobj.tags = ['some_tag']
    assert testobj.evaluate_tags(['some_tag'], [], {}) is True

    # Test with an only_tag

# Generated at 2022-06-21 01:30:13.669043
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    class TestTaggable(Taggable):
        pass

    class TestTask(TestTaggable):
        pass

    all_vars = {'foo': 'bar'}
    vars = {'foo': 'bar'}

    task = TestTask()
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars=all_vars)

    task = TestTask(tags=['foo', 'bar'])
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars=all_vars)
    assert task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars=all_vars)

# Generated at 2022-06-21 01:30:20.846843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import copy
    import pytest
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:30:28.339062
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os
    import pytest
    from collections import namedtuple
    from units.mock.loader import DictDataLoader

    os.environ['ANSIBLE_CONFIG'] = ''
    os.environ['ANSIBLE_LIBRARY'] = '/fake/library'
    os.environ['ANSIBLE_ROLES_PATH'] = '/fake/roles/path'
    os.environ['ANSIBLE_CONFIG'] = ''

    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

# Generated at 2022-06-21 01:30:35.955576
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyObj(Taggable):
        pass
    o = MyObj()
    o.tags = ['untagged']
    assert o.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert not o.evaluate_tags(only_tags=['all'], skip_tags=['never', 'untagged'], all_vars={})
    assert o.evaluate_tags(only_tags=['always'], skip_tags=['never'], all_vars={})
    assert not o.evaluate_tags(only_tags=['always'], skip_tags=['always'], all_vars={})
    assert not o.evaluate_tags(only_tags=['never'], skip_tags=['always'], all_vars={})
    assert o.evaluate_tags

# Generated at 2022-06-21 01:30:53.936669
# Unit test for constructor of class Taggable
def test_Taggable():
    attr = 'tags'
    t = Taggable()
    # in constructor 'tags' is a default value
    assert t._load_tags(attr, None) == [], 'error in constructor of Taggable class'

# Generated at 2022-06-21 01:30:55.235270
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-21 01:30:59.391339
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    try:
        t = TaskInclude()
        assert t._tags == []
    except:
        raise Exception("Taggable class constructor has errors")

    return True

# Generated at 2022-06-21 01:31:08.128675
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = None # Does not use this, can be None

    t = Taggable()
    t._loader = loader

    # Test: all_vars is None
    only_tags = set(['test'])
    skip_tags = set(['test'])
    assert t.evaluate_tags(only_tags, skip_tags, None) == True

    # Test: only_tags
    t.tags = ['test']
    assert t.evaluate_tags(only_tags, skip_tags, None) == True

    only_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, None) == True

    # Test: skip_tags
    only_tags = []
    skip_tags = ['test']
    assert t.evaluate_tags(only_tags, skip_tags, None) == False

    # Test

# Generated at 2022-06-21 01:31:13.178635
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task

    from ansible.plugins.loader import get_all_plugin_loaders
    for loader_cls in get_all_plugin_loaders():
        if loader_cls.__name__ == 'DictDataLoader':
            my_loader = loader_cls()

    my_task = Task()
    # Should run if no tags are specified
    assert(my_task.evaluate_tags(only_tags=None, skip_tags=None, all_vars=dict()) is True)
    # Should run if no tags are specified
    assert(my_task.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars=dict()) is True)

    # Should not run if only_tags is ONY

# Generated at 2022-06-21 01:31:16.304432
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert(taggable._tags is not None)

# Test if evaluating tags works as expected

# Generated at 2022-06-21 01:31:17.166543
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-21 01:31:25.409909
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()  # example of taggable object

    # evaluates when tag is not present in only_tags
    assert taggable_obj.evaluate_tags(tags = ['tag1', 'tag2'], only_tags = ['tag3', 'tag4'], skip_tags = None, all_vars = None) == True

    # evaluates when tag is not present in only_tags or skip_tags
    assert taggable_obj.evaluate_tags(tags = ['tag1', 'tag2'], only_tags = ['tag3', 'tag4'], skip_tags = ['tag5', 'tag6'], all_vars = None) == True

    # evaluates when tag is present in only_tags

# Generated at 2022-06-21 01:31:28.034220
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    print(t.tags)
    print(t.untagged)

# Generated at 2022-06-21 01:31:35.289190
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        pass

    taggable = MockTaggable()

    taggable.tags = ['always']
    assert taggable.evaluate_tags(['always'], [], {}) is True
    assert taggable.evaluate_tags(['always'], ['always'], {}) is True
    assert taggable.evaluate_tags([], [], {}) is True
    assert taggable.evaluate_tags([], ['always'], {}) is False
    assert taggable.evaluate_tags([], ['never'], {}) is True
    assert taggable.evaluate_tags(['always', 'always'], ['always'], {}) is True
    assert taggable.evaluate_tags(['never'], ['never'], {}) is False

    taggable.tags = ['never']


# Generated at 2022-06-21 01:32:13.372426
# Unit test for constructor of class Taggable
def test_Taggable():

    # construct a Taggable
    my_taggable = Taggable()

    # test the evaluate_tags() method
    my_tags = set(['tag1', 'tag2'])
    my_only_tags = set(['tag2'])
    my_skip_tags = set(['tag1'])
    my_all_vars = {"ansible_tags": "tag1"}
    should_run = my_taggable.evaluate_tags(my_tags, my_only_tags, my_skip_tags, my_all_vars)
    assert should_run == True, "evaluate_tags() should return True"

# Generated at 2022-06-21 01:32:15.261717
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []

# Generated at 2022-06-21 01:32:23.416439
# Unit test for constructor of class Taggable
def test_Taggable():
    # Constructor of class Taggable
    print("Toggable Constructor")
    tog = Taggable()
    print("constructor Success")
    # Constructor of class "Taggable" with two arguments.
    print("Toggable Constructor without arguments")
    try:
        tog1 = Taggable("2","3")
        print("Fail:Expected error: TypeError")
    except TypeError :
        print("Success:Expected error: TypeError")
    return tog
    
if __name__ == '__main__':
    tog = test_Taggable()
    print("\n")
    print("Tag:", type(tog.tags))
    print("Untagged:", type(tog.untagged))
    print("Tags:", tog.tags)

# Generated at 2022-06-21 01:32:33.053992
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' assert if only_tags and skip_tags are set the play will
    be run only if the tags given in only_tags and not in skip_tags
    are included in the tags of the play object '''

    class test_play(Taggable):
        pass

    play_obj = test_play()
    tags = ['tag1', 'tag2', 'tag3']
    play_obj.tags = tags
    only_tags = set(['tag1', 'tag2'])
    skip_tags = set(['tag3'])
    assert play_obj.evaluate_tags(only_tags, skip_tags, {}) == True

    # Test for only-tags
    play_obj.tags = tags
    only_tags = set(['tag1'])
    skip_tags = set()
    assert play_obj.evaluate_tags

# Generated at 2022-06-21 01:32:43.118601
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible import errors
    from ansible.playbook.role.include import RoleInclude

    class FakeTaggable(Taggable):
        def __init__(self, loader):
            self._loader = loader

        def __getattr__(self, name):
            if name == 'tags':
                return self._tags
            else:
                return None

        def filters(self):
            return {}

    class FakeLoader():
        def get_basedir(self):
            return '/tmp'

        def path_dwim(self, path):
            return "/tmp/%s" % path

    # _loader is mandatory for call Templar().template(...) in method evaluate_tags()
    # tags is mandatory for call Templar().template(...) in method evaluate_tags()
    # all_vars is mandatory for call Templar().template(...) in

# Generated at 2022-06-21 01:32:53.875595
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ti = TaskInclude()
    ti._loader = Templar._loader
    # We need a variable manager to process variable in tags
    variable_manager = VariableManager()

    # Evaluate tags for only_tags
    ti.tags = ['tag1', 'tag2']
    assert True == ti.evaluate_tags(['tag1'], [], variable_manager.get_vars())
    assert False == ti.evaluate_tags(['tag3'], [], variable_manager.get_vars())
    assert True == ti.evaluate_tags(['tag1', 'tag2'], [], variable_manager.get_vars())


# Generated at 2022-06-21 01:33:05.115274
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    class NotTaggable:
        pass

    only_tags = set()
    skip_tags = set()
    all_vars = {}
    tags = None
    expected_should_run = True

    not_taggable = NotTaggable()
    taggable = Taggable()

    not_taggable._loader = None
    taggable._loader = None

    # Act
    not_taggable.tags = tags
    taggable.tags = tags
    should_run_not_taggable = not_taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    should_run_taggable = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # Assert
    assert should_run_not

# Generated at 2022-06-21 01:33:14.587227
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestClass(Taggable):
        name = 'test_object'

    # Tasks with empty tags always run
    obj = TestClass(tags=list())
    assert obj.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars=dict()) is True
    assert obj.evaluate_tags(only_tags={ 'foo' }, skip_tags=set(), all_vars=dict()) is True
    assert obj.evaluate_tags(only_tags=set(), skip_tags={ 'foo' }, all_vars=dict()) is True
    assert obj.evaluate_tags(only_tags={ 'foo' }, skip_tags={ 'bar' }, all_vars=dict()) is True

    # Tasks with 'always' tag run on all conditions
    obj = TestClass(tags=[ 'always' ])

# Generated at 2022-06-21 01:33:24.480492
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # constructor of class Playbook
    p = Playbook()
    # constructor of class Task
    t = Task()
    # constructor of class Role
    r = Role()
    # constructor of class Block
    b = Block()
    # constructor of class Handler
    h = Handler()

    # test of function _load_tags
    print(p._load_tags('tags', [1, 2, 3]))
    print(p._load_tags('tags', '1,2,3'))
    #print(p._load_tags(['tags'], 4))
    #print(p._

# Generated at 2022-06-21 01:33:33.243214
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    print(t.tags)
    print(t._load_tags('tags', 'pre_deploy_test'))

    task_tags = ['test', 'ansible', 'docker']
    task1 = AnsibleTask(
        action='test_tag', only_tags=['test', 'ansible'],
        skip_tags=['docker'],
    )
    task2 = AnsibleTask(
        action='test_tag', only_tags=['test', 'ansible'],
        skip_tags=['docker'],
    )
    task2.tags = task_tags

    all_vars = {}
    print(task1.evaluate_tags(['test'], ['test'], all_vars))