

# Generated at 2022-06-21 01:24:36.091262
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()
    tags._tags = ['foo', 'bar']
    tags = tags._load_tags('foo', tags._tags)
    assert tags == ['foo', 'bar']
    tags = Taggable()
    tags._tags = 'foo,bar'
    tags = tags._load_tags('foo', tags._tags)
    assert tags == ['foo', 'bar']
    try:
        tags = Taggable()
        tags._tags = 5
        tags = tags._load_tags('foo', tags._tags)
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-21 01:24:47.573501
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    name = 'test'
    loader = None
    variable_manager = None
    loader = None
    tasks = [
        Task.load(dict(action=dict(module='debug', args=dict(msg='{{ server_port }}')), tags=['test']),
                  variable_manager=variable_manager, loader=loader)
    ]

    # no tag options
    only_tags = set()
    skip_tags = set()
    assert tasks[0].evaluate_tags(only_tags, skip_tags, variable_manager) is True

    # 'all' only tag options
    only_tags = set(['all'])
    skip_tags = set()
    assert tasks[0].evaluate

# Generated at 2022-06-21 01:24:51.848276
# Unit test for constructor of class Taggable
def test_Taggable():

    # Create a fake class to test constructor of Taggable class.
    class FakeTaggable(Taggable):
        def __init__(self, *args, **kwargs):
            pass

        def __new__(cls, *args, **kwargs):
            return None

    # Test with only_tags = untagged, skip_tags = tagged
    only_tags = frozenset(['untagged'])
    skip_tags = frozenset(['tagged'])
    fake_taggable = FakeTaggable()

    # Assert that a task is skipped, when there is only 'untagged' tag
    fake_taggable._tags = ['untagged']
    assert fake_taggable.evaluate_tags(only_tags, skip_tags, {}) == False

    # Assert that a task is not skipped, when

# Generated at 2022-06-21 01:25:00.877284
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create an object of class Taggable
    from ansible.playbook.task_include import TaskInclude

    obj = TaskInclude()
    obj._tags = ['tag1','tag2','tag3','tag4','tag5','tag6','never','always','tagged','untagged','tagged']

    # Test case 1 - only tags are passed , tags are not skipped,tags are present in only_tags
    only_tags = ['tag1','tag2','tag3','tag4','tag5','tag6','never','always','tagged','untagged','tagged']
    skip_tags = []
    all_vars = {}
    result = obj.evaluate_tags(only_tags,skip_tags,all_vars)
    expect = True
    assert result == expect

    #Test case 2 - only tags are passed , tags are not skipped

# Generated at 2022-06-21 01:25:01.931791
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-21 01:25:06.812749
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task import Task
    t = Task()
    for attr in t.__dict__:
        if isinstance(t.__dict__[attr], FieldAttribute):
            print(attr)
    print(vars(t))

# Generated at 2022-06-21 01:25:18.718120
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:25:26.414757
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # Default (run without any tag option specified)
    assert t.evaluate_tags(None, None, None) == True, \
        "by default, tags are not specified and tasks should run"

    # NOT tagged
    t._tags = []
    assert t.evaluate_tags(['tagged'], None, None) == False, \
        "NOT tagged task does not run when tagged option is specified"

    # tagged with 'never'
    t._tags = ['never']
    assert t.evaluate_tags(['tagged'], None, None) == False, \
        "task tagged with 'never' does not run when tagged option is specified"

    # tagged with 'always'
    t._tags = ['always']

# Generated at 2022-06-21 01:25:27.932305
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert ta.tags == list()

# Generated at 2022-06-21 01:25:34.055214
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    test_cases = dict(
        Role=Role,
        Task=Task,
        Play=Play,
        Block=Block,
    )
    for key, val in test_cases.items():
        assert key in val.__str__(), '%s inherited Taggable class' % (key, )

# Generated at 2022-06-21 01:25:50.039574
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass


# Generated at 2022-06-21 01:25:59.906481
# Unit test for constructor of class Taggable
def test_Taggable():

    class MyTaggable(Taggable):
        def __init__(self, loader, tags=None):
            self._loader = loader
            # TODO: this is an ugly hack to get the FieldAttribute to work
            self.tags = None
            if tags:
                self.tags = list(tags)

    # Simple comma separated string
    t = MyTaggable(tags='a,b')
    assert isinstance(t.tags, list)
    assert t.tags == ['a', 'b']

    # Correctly specified list
    t = MyTaggable(tags=['a', 'b'])
    assert isinstance(t.tags, list)
    assert t.tags == ['a', 'b']

    # Strings not separated by commas
    t = MyTaggable(tags='ab')

# Generated at 2022-06-21 01:26:01.922393
# Unit test for constructor of class Taggable
def test_Taggable():
    # Taggable constructor test
    assert hasattr(Taggable, 'tags')

# Generated at 2022-06-21 01:26:05.907560
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    # if tags wasn't set, which it isn't, should be returning empty list
    assert t.tags == []
    # no tags should be present.
    assert t.untagged == frozenset(['untagged'])


# Generated at 2022-06-21 01:26:17.848078
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import pytest

    # Verify that 'tags' is marked as default to an empty list as documented.
    play_ctx = PlayContext()
    task = Task()
    task.action = 'stats'
    task.tags = ['abc', 'def']
    task._role_context = play_ctx.prepare_task_for_task_include(task)
    assert task.tags == ['abc', 'def']

    # Verify that evaluation works against 'only_tags' using an empty set
    assert task.evaluate_tags(set(), set(), dict()) == True
    play_ctx.only

# Generated at 2022-06-21 01:26:27.837180
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # The test requires 'PYTHONPATH' pointing to a working copy of Ansible.
    # It is needed to create an instance of Taggable

    import ansible.playbook.base as base
    from ansible.template import Templar
    my_taggable = base.Taggable()
    my_taggable._loader = None
    my_taggable.tags = list()

    # There should be an instance variable '_tags' with type list with
    # default value []
    assert type(my_taggable._tags) is list
    assert my_taggable._tags == list()

    # There should be an instance variable 'tags' with type list with
    # default value []
    assert type(my_taggable.tags) is list
    assert my_taggable.tags == list()

    # Default test

# Generated at 2022-06-21 01:26:40.406659
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    only_tags = [AnsibleUnicode('always'), AnsibleUnicode('test_tag')]
    skip_tags = [AnsibleUnicode('never'), AnsibleUnicode('test_tag')]

    # test class represents a class that extends Taggable
    test_class = type('test_class', (Taggable,), {})

    # test_instance is a instance of test_class
    test_instance = test_class()
    assert test_instance.evaluate_tags(only_tags, None, None) == True
    assert test_instance.evaluate_tags(None, skip_tags, None) == False
    assert test_instance.evaluate_tags(only_tags, skip_tags, None) == True

# Generated at 2022-06-21 01:26:51.897304
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    from ansible.playbook.task_include import TaskInclude

    t = TaskInclude()
    t._loader = None

    all_vars = dict(myvar='myvalue')

    # Test all modes, with and without tags
    for only_tags in (None, [], ['all'], ['mytag'], ['untagged'], ['always']):
        for skip_tags in (None, [], ['all'], ['mytag'], ['never']):

            # Test 1: empty tags should be run, when no only and no skip tags are set
            t.tags = []
            assert t.evaluate_tags(only_tags, skip_tags, all_vars)

            # Test 2: tags with only_tags=all and without skip_tags
            t.tags = ['mytag']

# Generated at 2022-06-21 01:27:02.849776
# Unit test for constructor of class Taggable
def test_Taggable():
    # Check for correct loading of a structured tag list
    t = Taggable()
    tags = [ 'tag1', 'tag2', 'tag3' ]
    t._load_tags('tags', tags)
    assert t.tags == tags

    # Check for correct loading of a string tag list
    t = Taggable()
    tags = 'tag1,tag2,tag3'
    t._load_tags('tags', tags)
    assert t.tags == ['tag1','tag2','tag3']

    # Check for correct loading of a structured tag list
    t = Taggable()
    tags = 'tag1,tag2,tag3'
    t._load_tags('tags', tags)
    assert t.tags == ['tag1','tag2','tag3']

    # Check that we reject non-string tag lists

# Generated at 2022-06-21 01:27:04.214184
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert a._tags == [], a._tags

# Generated at 2022-06-21 01:27:19.069723
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()
    assert(tags._tags == [])

# Generated at 2022-06-21 01:27:29.439794
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class MyTaggable(Taggable):
        def __init__(self):
            self._tags = None

    taggable = MyTaggable()

    # Should be executed if no tags are specified
    taggable._tags = None
    assert taggable.evaluate_tags(None, None, {}) == True

    # Should not be executed if no tags are specified
    # but the user only wants to run tags 'bar'
    taggable._tags = None
    only_tags = ['bar']
    assert taggable.evaluate_tags(only_tags, None, {}) == False

    # Should not be executed if no tags are specified
    # but the user wants to skip tasks with tags 'bar'
    taggable._tags

# Generated at 2022-06-21 01:27:34.943914
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):

        is_task = True

        def __init__(self, tags):
            self.tags = tags

    def make_MockTaggable(tags):
        return MockTaggable(tags)

    # Test when only_tags is set to "tag1, tag2":
    # tags: "tag1" --> should run
    # tags: "tag1, tag2" --> should run
    # tags: "tag2" --> should run
    # tags: "tag1, tag2, tag3" --> should run
    # tags: "tag3" --> should NOT run
    # tags: "tag1, tag3" --> should NOT run
    # tags: "tag2, tag3" --> should NOT run
    # tags: "" --> should NOT run
    task = make_MockTagg

# Generated at 2022-06-21 01:27:46.122575
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Object initialization
    loader_mock = 'a loader mock'
    only_tags = ['tag1']
    skip_tags = ['tag2']
    all_vars = 'all_vars'
    my_class = Taggable(loader_mock)
    # Test: set my_class.tags to None
    my_class.tags = None
    if my_class.evaluate_tags( only_tags, skip_tags, all_vars ):
        # Test: set my_class.tags to None failed
        print('Taggable.evaluate_tags() test failed: set my_class.tags to None failed')
        return 1
    # Test: set my_class.tags to None passed

    # Test: set my_class.tags to None
    my_class.tags = ['tag1']

# Generated at 2022-06-21 01:27:55.164288
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Get the class object for the module
    class_object = Taggable()

    # Test for when no tags are defined
    result = class_object.evaluate_tags(None, None, None)
    assert result == True

    # Test for when only tags are defined
    result = class_object.evaluate_tags(["tag1", "tag2"], None, None)
    assert result == False

    class_object.tags = ["tag1"]

    # Test for when only tags and no skip tags are defined
    result = class_object.evaluate_tags(["tag1", "tag2"], None, None)
    assert result == True

    # Test for when only tags and skip tags are defined
    result = class_object.evaluate_tags(["tag1", "tag2"], ["tag1", "tag2"], None)
    assert result == False



# Generated at 2022-06-21 01:28:06.552532
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyClass(Taggable):
        pass

    item = DummyClass()

    # should run the item if neither only_tags or skip_tags are specified
    assert item.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # The default is True, so if only_tags is specified and the item doesn't have any tags, it should run
    assert item.evaluate_tags(only_tags=['deploy'], skip_tags=None, all_vars={}) == True
    # same as the above, but with a different only_tag
    assert item.evaluate_tags(only_tags=['run'], skip_tags=None, all_vars={}) == True

    # assign a tag to the item
    item.tags = ['deploy']
    # the item should run

# Generated at 2022-06-21 01:28:16.571929
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # create a block with no tags, but with only_tags = all
    only_tags = ['all']
    block = Block.load(dict(name='block', tasks=[
        dict(action=dict(module='foo', args=dict(name='bar')))
    ], only_tags=only_tags))

    # task should be runned
    assert block.evaluate_tags(only_tags, [], {}) is True

    # create a block with tag=foo, but with only_tags = [bar]
    only_tags = ['bar']

# Generated at 2022-06-21 01:28:24.900288
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []
    assert taggable.tags == []
    assert taggable.untagged == ('untagged',)

    taggable = Taggable(['tag1', 'tag2', 'tag3'])
    assert taggable._tags == ['tag1', 'tag2', 'tag3']
    assert taggable.tags == ['tag1', 'tag2', 'tag3']
    assert taggable.untagged == ('untagged',)


# Generated at 2022-06-21 01:28:35.395981
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-21 01:28:41.124777
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test for andy implementation
    taggable = Taggable()
    taggable._tags = ['all', 'never']

    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars), "evaluate_tags did not work."

    only_tags = ['all']
    skip_tags = ['never']
    all_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars), "evaluate_tags did not work."

    only_tags = ['all']
    skip_tags = ['all']
    all_vars = {}

# Generated at 2022-06-21 01:29:10.582961
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == [], "tags must be an empty list"

# Generated at 2022-06-21 01:29:22.249429
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable1 = Taggable()
    taggable2 = Taggable()

    assert taggable1.tags is not None
    assert taggable1.tags == taggable2.tags == []

# Run tests with 'python -m ansible.playbook.taggable test_Taggable'
if __name__ == '__main__':
    import sys
    import pytest
    import ansible.playbook.taggable

    if sys.version_info[0] == 3:
        from importlib import reload

    reload(ansible.playbook.taggable)
    errno = pytest.main(['-s', __file__])
    sys.exit(errno)

# Generated at 2022-06-21 01:29:33.825089
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.shell import ActionModule as ShellActionModule

    context = PlayContext()
    context._variable_manager = dict()
    context.tags = ['all']

    action_module = ShellActionModule(
        task=dict(action=dict(module='shell', args='uname')),
        task_vars=dict(),
        play_context=context,
        loader=action_loader,
        templar=None
    )
    assert action_module.evaluate_tags(context.only_tags, context.skip_tags, context._variable_manager)


# Generated at 2022-06-21 01:29:41.760530
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert Taggable().evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) is False
    assert Taggable(tags='tag3').evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) is False
    assert Taggable(tags=['tag3']).evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) is False
    assert Taggable(tags='tag1, tag4').evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) is True

# Generated at 2022-06-21 01:29:55.015426
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test(Taggable):
        pass

    # Inputs
    t = Test()
    t.tags = ['tag1','tag2','never']
    only_tags = ['tag3','tag4']
    skip_tags = ['do_not_run','tag2','never']
    all_vars = []

    # Expected result
    result = t.evaluate_tags(only_tags,skip_tags,all_vars)
    expected_result = False
    assert result == expected_result

    # Test skip_tags = ['always']
    t = Test()
    skip_tags = ['always']
    expected_result = True

    # Test (t.tags = None) and (skip_tags = ['tag2', 'never'])
    t = Test()
    t.tags = None

# Generated at 2022-06-21 01:30:03.693910
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    # Case 1: Empty only_tags, skip_tags, and empty tags
    current = Task()
    current.load_data({'name': 'test task'})
    only_tags = []
    skip_tags = []
    print("case 1:")
    print("tags:")
    print(current.tags)
    print("only_tags:")
    print(only_tags)
    print("skip_tags:")
    print(skip_tags)
    print("Test 1:")
    result = current.evaluate_tags(only_tags, skip_tags, {})
    print("Result:")
    print(result)
    print("\nTest 2:")
    only_tags = ["all"]
    print("only_tags:")
    print(only_tags)

# Generated at 2022-06-21 01:30:07.308616
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    fake_item = Taggable()
    fake_item.tags = ['tag1','tag2','tag3','tag4','tag5']
    fake_all_vars = dict(foo='bar')
    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = ['tag4', 'tag5']
    assert fake_item.evaluate_tags(only_tags, skip_tags, fake_all_vars)

# Generated at 2022-06-21 01:30:09.096234
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-21 01:30:11.245359
# Unit test for constructor of class Taggable
def test_Taggable():
    task = Taggable()
    assert task.tags == []
    task = Taggable(tags=['tag1'])
    assert task.tags == ['tag1']

# Generated at 2022-06-21 01:30:17.810674
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj1 = Taggable()
    obj2 = Taggable()
    obj3 = Taggable()
    obj4 = Taggable()

    obj1.tags = set(['tag1'])
    obj2.tags = set(['tag1','tag2','tag3','tag4'])
    obj3.tags = set(['tag2', 'tag3'])
    obj4.tags = set([])

    # run with only_tags and skip_tags
    assert obj1.evaluate_tags(set(['tag1','tag5']), set(['tag4']), None) == True
    assert obj1.evaluate_tags(set(['tag2','tag3']), set(['tag4']), None) == False

# Generated at 2022-06-21 01:31:25.410955
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    import ansible.inventory
    import ansible.utils
    import sys

    p = PlayContext()

    # Hack around lack of host in context
    p.hostvars = dict()

    i = ansible.inventory.Inventory('hosts')
    i.set_variable('testhost', 'ansible_ssh_host', 'testhost')
    i.set_variable('testhost', 'ansible_ssh_port', 22)

    h = i.get_host('testhost')
    assert h.name == 'testhost'

    # check to make sure the port is now 22
    assert h.port == 22

    # test host as it comes from inventory

# Generated at 2022-06-21 01:31:34.387452
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Unit test for method Taggable.evaluate_tags
    """
    from ansible.playbook.task_include import TaskInclude

    # Here we create an empty object of class TaskInclude
    task_i = TaskInclude()

    # For convenience, we set the attributes 'tags' and 'untagged'
    task_i.tags = ['tagged']
    task_i.untagged = ['untagged']

    # We define some variables that will be used
    only_tags = ['tagged']
    skip_tags = ['tagged']

# Generated at 2022-06-21 01:31:44.422179
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class MyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    class TestTaggable(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_only_tags(self):
            self.assertTrue(MyTaggable(tags=['bar']).evaluate_tags(
                only_tags=set(['bar']),
                skip_tags=None,
                all_vars={},
            ))

# Generated at 2022-06-21 01:31:54.930758
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    only_tags = ['bar', 'foo']
    skip_tags = []
    all_vars = dict()

    ## Test different Tags value types

    # List
    tags1 = ['tag1', 'tag2', 'tag3']
    class TagTestClass(Taggable):
        tags = tags1

    tagtest1 = TagTestClass()
    assert tagtest1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # String
    tags2 = 'tag1, tag2, tag3'
    class TagTestClass(Taggable):
        tags = tags2



# Generated at 2022-06-21 01:32:03.938233
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = None
    all_vars = dict()
    only_tags = set()
    skip_tags = set()
    class tags_load:
        tags = ["tag1", "tag2"]
    tags_load = tags_load()
    tags_load.tags = ["tag1", "tag2"]
    # First pass
    assert tags_load.evaluate_tags(only_tags, skip_tags, all_vars)
    # Second pass
    only_tags = set(["tag1"])
    assert tags_load.evaluate_tags(only_tags, skip_tags, all_vars)
    # Third pass
    only_tags = set(["tag3"])
    assert not tags_load.evaluate_tags(only_tags, skip_tags, all_vars)
    # Fourth pass

# Generated at 2022-06-21 01:32:06.079089
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []


# Generated at 2022-06-21 01:32:15.979843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    # very simple play for testing

# Generated at 2022-06-21 01:32:23.688278
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        def __init__(self, only_tags=None, skip_tags=None, all_vars=dict(), tags=None):
            self._loader = None
            self.tags = tags
            self.evaluate_tags(only_tags, skip_tags, all_vars)

    # simple test with list of tags
    assert (True, ) == (Task(tags=['my-tag'], only_tags=['my-tag'], skip_tags=[]).tags,)
    assert (False, ) == (Task(tags=['my-tag'], only_tags=[], skip_tags=['my-tag']).tags,)

# Generated at 2022-06-21 01:32:33.308036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    only_tags = [ 'two' ]
    skip_tags = [ 'two' ]
    all_vars = dict()

    # Test when ignore_tags is present
    temp = TaskInclude(temp_ds)
    assert temp._evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Test when ignore_tags is not present
    temp = TaskInclude(default_ds)
    assert temp._evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test when ignore_tags is present
    temp = TaskInclude(temp_ds)
    assert temp._evaluate_tags(only_tags, [], all_vars) == False

    # Test when ignore_tags is not present
    temp = Task

# Generated at 2022-06-21 01:32:36.350965
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    assert test_obj._tags == []

