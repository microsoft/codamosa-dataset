

# Generated at 2022-06-23 07:05:55.180558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags_default = []
    only_tags_all = ['all']
    only_tags_specific = ['specific', 'tags']
    only_tags_mixed = ['all', 'specific', 'tags']
    only_tags_none = []
    only_tags_always = ['always']
    only_tags_always_as_list = ['always', 'other-tags']
    only_tags_always_in_list = ['always', 'other-tags']

    skip_tags_default = []
    skip_tags_all = ['all']
    skip_tags_specific = ['specific', 'tags']
    skip_tags_mixed = ['all', 'specific', 'tags']
    skip_tags_none = []
    skip_tags_never_as_list = ['never', 'other-tags']
    skip_tags_never

# Generated at 2022-06-23 07:06:05.731460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        _allow_duplicates = FieldAttribute(isa='bool', default=False)

    foo = TestTaggable(all_vars={})
    foo._load_tags(tags="tag1")
    assert foo.evaluate_tags(["tag1"], [], {}) == True
    foo._load_tags(tags="tag2")
    assert foo.evaluate_tags(["tag1"], [], {}) == False
    assert foo.evaluate_tags(["tag1"], ["tag2"], {}) == False
    assert foo.evaluate_tags([], ["tag2"], {}) == False

    class Bar(Taggable):
        _allow_duplicates = FieldAttribute(isa='bool', default=False)

    bar = Bar(all_vars={})

# Generated at 2022-06-23 07:06:15.751550
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []

    taggable = Taggable(tags=['a', 'b', 'c'])
    assert taggable.tags == ['a', 'b', 'c']

    taggable = Taggable(tags=['d', 'e', 'f'])
    assert taggable.tags == ['d', 'e', 'f']

    taggable.tags = taggable.tags + ['g', 'h', 'i']
    assert taggable.tags == ['d', 'e', 'f', 'g', 'h', 'i']

    taggable.tags = taggable.tags + ['j', 'k', 'l']

# Generated at 2022-06-23 07:06:27.629499
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C
    item = Block()
    item._role = IncludeRole()
    item._parent = Block()
    item._parent._role = IncludeRole()
    item._parent._parent = Block()
    item._parent._parent._role = IncludeRole()

    # test the 'tags' parameter with a string
    item.tags = 'one'
    assert item.evaluate_tags('one', [], dict())

    # test the 'tags' parameter with a list
    item.tags = ['one','two']
    assert item.evaluate_tags(['one','two'], [], dict())

    # test the 'tags' parameter with a template

# Generated at 2022-06-23 07:06:31.186676
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._tags.flatten('foo', 42) == [ '42' ]
    assert Taggable._tags.flatten('foo', ['42']) == [ '42' ]

# Generated at 2022-06-23 07:06:39.348392
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class Taggable_eval_tags(Taggable):
        pass


# Generated at 2022-06-23 07:06:41.201829
# Unit test for constructor of class Taggable
def test_Taggable():
    testInstance = Taggable()
    assert testInstance.tags == []

# Generated at 2022-06-23 07:06:50.180762
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create an instance of Taggable
    t = Taggable()

    # Create a tags list to test
    tags = ["tag1", "tag2", "tag3", "tag4"]

    # Test when only_tags is None and skip_tags is None
    only_tags = None
    skip_tags = None
    expected_result = True
    result = t.evaluate_tags(only_tags, skip_tags, {})
    assert result == expected_result

    # Test when only_tags is None, skip_tags is an empty list
    # and tags are an empty list
    only_tags = None
    skip_tags = []
    tags = []
    expected_result = True
    result = t.evaluate_tags(only_tags, skip_tags, {})
    assert result == expected_result

    # Test when only_

# Generated at 2022-06-23 07:06:52.421766
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags is not None

# Generated at 2022-06-23 07:06:57.672855
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableTest(Taggable):
        read_only = FieldAttribute(isa='bool', default=False, read_only=True)
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    test_class = TaggableTest()
    assert not test_class.read_only
    assert not test_class.tags

# Generated at 2022-06-23 07:06:58.283055
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:07:10.109636
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Taggable.__init__
    # Taggable._load_tags
    # Taggable.evaluate_tags

    # PlayContext: used by Taggable
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()

    # Loader: used by PlayContext
    from ansible.playbook.play_context import Loader
    loader = Loader()

    from ansible.playbook.block import Block
    b = Block()
    b._loader = loader
    b._play_context = pc

    # Loader: used by Block
    from ansible.playbook.play_context import Loader
    loader = Loader()

    # Task: extends Taggable
    from ansible.playbook.task import Task
    t = Task()
    t._loader = loader

# Generated at 2022-06-23 07:07:20.650303
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude

    # Create a hosts object and a play object
    hosts = ['1.1.1.1','2.2.2.2','3.3.3.3']
    play = Play()
    play._ds = dict(
        name='test_play',
        hosts=hosts,
        user='admin',
        gather_facts='no'
    )
    play._basedir = './'

    # Create a task object and include it in the play
    task = TaskInclude()
    task._ds = dict(
        name='test_task',
        tags='test_tag, another_tag'
    )

# Generated at 2022-06-23 07:07:32.208455
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        pass

    import collections

    # Test data
    only_tags_all = ['all']
    only_tags_tagged = ['tagged']
    only_tags_empty = []
    only_tags_multiple = ['tag1', 'tag2']
    only_tags_only_always = ['always']
    only_tags_always_only_never = ['always', 'never']
    only_tags_never_only_always = ['never', 'always']

    skip_tags_all = ['all']
    skip_tags_empty = []
    skip_tags_multiple = ['tag1', 'tag2']
    skip_tags_never = ['never']
    skip_tags_always = ['always']
    skip_tags_always_and_never = ['always', 'never']
   

# Generated at 2022-06-23 07:07:34.967346
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        pass

    assert TestTaggable()._tags == []


# Generated at 2022-06-23 07:07:35.805838
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-23 07:07:51.208358
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:07:53.185345
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert type(taggable) == Taggable


# Generated at 2022-06-23 07:08:09.033117
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Import required modules
    import os
    import sys
    import unittest
    from ansible.playbook.role_include import IncludeRole

    # Setup the directories
    MODULES_PATH = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/modules')
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../../lib/ansible'))
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../../lib/ansible/utils'))
    sys.path.insert(0, MODULES_PATH)



# Generated at 2022-06-23 07:08:14.130470
# Unit test for constructor of class Taggable
def test_Taggable():
    class AnsibleModule:
        def __init__(self, name):
            self.name = name

    assert Taggable().tags == []
    assert Taggable(tags=[]).tags == []
    assert Taggable(tags=['a', 'b']).tags == ['a', 'b']
    assert Taggable(tags='a,b').tags == ['a', 'b']


# Generated at 2022-06-23 07:08:18.923182
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert set(t.tags) == set([])
    assert t._tags == []
    assert t.untagged == frozenset(['untagged'])
    assert t.evaluate_tags(['tag1'], [], dict())



# Generated at 2022-06-23 07:08:29.635535
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.tagged_tasks import TaggedTasks
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.utils.unsafe_proxy import wrap_var

    class TestName(Taggable):
        _name = FieldAttribute(isa='string', default=None)

    obj = TestName()

    assert obj.name == None

    obj = TestName(name='test')

    assert obj.name == 'test'

    # Taggable added for now to get the tests passing until it's decided
    # if Block, Task and Role should/not be taggable
    obj = Block()
    assert obj.tags == []

    obj = Task()
    assert obj.tags == []

    obj = T

# Generated at 2022-06-23 07:08:31.529829
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:08:41.278774
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_inst = Taggable()
    test_inst.tags = []
    assert test_inst.evaluate_tags(['always'], [], {}) == True
    assert test_inst.evaluate_tags(['universal'], [], {}) == False
    assert test_inst.evaluate_tags(['tagged'], [], {}) == False
    assert test_inst.evaluate_tags(['all'], [], {}) == True
    
    assert test_inst.evaluate_tags(['universal', 'always'], [], {}) == True
    assert test_inst.evaluate_tags(['tagged', 'always'], [], {}) == False
    assert test_inst.evaluate_tags(['all', 'always'], [], {}) == True

# Generated at 2022-06-23 07:08:48.356631
# Unit test for constructor of class Taggable
def test_Taggable():
    class Tagger(Taggable):
        pass
    t = Tagger()
    assert t.tags == []
    t.tags = 'foo'
    assert t.tags == ['foo']
    t.tags = 'foo, bar'
    assert t.tags == ['foo', 'bar']
    t.tags = ['foo', 'bar']
    assert t.tags == ['foo', 'bar']

# Generated at 2022-06-23 07:08:59.247144
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()

# Generated at 2022-06-23 07:09:05.276064
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    t = Task()

    # check that _tags are initialized as a list
    assert(isinstance(t._tags, list))

    # check that _tags get initialized
    # with a list of integer
    t._load_tags('tags', (1, 2, 3))
    assert(t.tags == [1, 2, 3])

    # check that _tags get initialized
    # with a list of strings
    t._load_tags('tags', ("1", "2", "3"))
    assert(t.tags == ["1", "2", "3"])

    # check that _tags get initialized
    # with a comma-separated string
    t._load_tags('tags', "1, 2, 3")
    assert(t.tags == ["1", "2", "3"])

# Generated at 2022-06-23 07:09:16.463375
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):

        def __init__(self, tags):
            self._tags = tags


# Generated at 2022-06-23 07:09:26.509249
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    mytaggable = Taggable()

    mytaggable.tags = ['wow']
    assert mytaggable.evaluate_tags(['wow'], [], all_vars = {}) == True
    assert mytaggable.evaluate_tags(['wow'], [], all_vars = {}) == True

    mytaggable.tags = ['wow']
    assert mytaggable.evaluate_tags(['wow2'], [], all_vars={}) == False
    assert mytaggable.evaluate_tags(['wow2'], [], all_vars={}) == False

    mytaggable.tags = ['wow']
    assert mytaggable.evaluate_tags(['wow2'], ['wow'], all_vars={}) == False

# Generated at 2022-06-23 07:09:30.217591
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []
    assert obj.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:09:34.003075
# Unit test for constructor of class Taggable
def test_Taggable():
    # Create a variable for the class Taggable
    t = Taggable()
    #Test the tags
    t._tags = ['tag1','tag2','tag3']
    # Check the tags
    assert t.tags == ['tag1','tag2','tag3']

# Generated at 2022-06-23 07:09:35.117717
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    if t.tags != []:
        raise ValueError('tag list not initialized correctly')

# Generated at 2022-06-23 07:09:43.225279
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            super(TestTaggable, self).__init__()
            self.tags = []

    # Inputs
    only_tags = set([])
    skip_tags = set([])
    # Only the default values
    myTaggable = TestTaggable()
    # Default tags=[]
    assert myTaggable.evaluate_tags(only_tags, skip_tags, {}) == True

    # Only the default values
    myTaggable.tags = ['untagged']
    assert myTaggable.evaluate_tags(only_tags, skip_tags, {}) == True

    # Inputs
    only_tags = set([])
    skip_tags = set([])
    # Only the default values
    myTaggable = TestTagg

# Generated at 2022-06-23 07:09:56.075387
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        def __init__(self):
            self._tags = []
            self._loader = None
    dummy = DummyTaggable()

    only_tags = set(['tag1'])
    skip_tags = set(['tag2'])
    all_vars = {}

    # Case 1
    dummy.tags = ['tag1']
    result = dummy.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    # Case 2
    dummy.tags = ['tag2']
    result = dummy.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False

    # Case 3
    dummy.tags = ['tag3']

# Generated at 2022-06-23 07:09:59.267908
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t.tags = ["http", "ssl"]
    assert t.tags == ["http", "ssl"]



# Generated at 2022-06-23 07:10:03.119958
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable({})

    assert(test_taggable.tags == [])

# Generated at 2022-06-23 07:10:12.073008
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

# Generated at 2022-06-23 07:10:24.046748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['tagA', 'tagB']
    assert t.evaluate_tags(['tagA', 'tagB'], [], {}) == True
    assert t.evaluate_tags(['tagA'], [], {}) == True
    assert t.evaluate_tags([], [], {}) == True
    assert t.evaluate_tags(['tagA', 'tagB', 'tagD'], [], {}) == True
    assert t.evaluate_tags(['tagD'], [], {}) == False
    assert t.evaluate_tags(['tagD'], ['tagA', 'tagB'], {}) == True
    assert t.evaluate_tags(['tagD'], ['tagA'], {}) == True

# Generated at 2022-06-23 07:10:25.631413
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    # Check default value of tags
    assert a.tags == []
    assert a._load_tags(None, 'foo,bar') == ['foo', 'bar']
    assert a._load_tags

# Generated at 2022-06-23 07:10:36.881180
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyClass(Taggable):

        def __init__(self, tags=None):
            self._tags = tags

    # no tags set, should run
    d1 = DummyClass()
    assert d1.evaluate_tags(None, None, {}) is True

    # no tags set, should run
    d2 = DummyClass([])
    assert d2.evaluate_tags(None, None, {}) is True

    # tagged with 'always', should run
    d3 = DummyClass(["always"])
    assert d3.evaluate_tags(None, None, {}) is True

    # tagged with 'never', should not run
    d4 = DummyClass(["never"])
    assert d4.evaluate_tags(None, None, {}) is False

    # tagged with 'always' and 'never', should

# Generated at 2022-06-23 07:10:47.160400
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest

    class TestTaggable(Taggable):
        pass

    class PlaybookBase(unittest.TestCase):

        def setUp(self):
            os.environ['ANSIBLE_ROLES_PATH'] = '../../../../roles'

            # make the class we are testing
            self.name = TestTaggable()

        def tearDown(self):
            pass

    class TestEvaluateTags(PlaybookBase):
        def test_evaluate_tags(self):

            all_vars = dict()
            all_vars['tagged'] = True

            # Test that 'not tagged' does not run when using 'spin_tags'
            self.name.tags = list()
            skip_tags = set(["tagged"])

# Generated at 2022-06-23 07:10:51.539369
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ["S1", "S2", "S3"]

    all_vars = dict()

    only_tags = ["S1", "S3"]
    skip_tags = ["S1"]
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run, 'should_run'

    only_tags = ["S1", "S3"]
    skip_tags = ["S1", "S3"]
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert not should_run, 'should_run'

    only_tags = ["S1", "S3"]
    skip_tags = ["S2", "S3"]
    should_run = t.evaluate_

# Generated at 2022-06-23 07:11:01.114812
# Unit test for constructor of class Taggable
def test_Taggable():
   ob1 = Taggable("","")
   assert isinstance(ob1._tags,list)
   assert ob1._tags == []
   ob1.tags = ['tag1','tag2']
   ob1._tags = ['tag3','tag4']
   assert ob1.tags == ['tag3','tag4']
   ob1.tags = []
   ob1._tags = []
   assert ob1.tags == []
   ob1.tags = ['tag1','tag2']
   ob1._tags = ['tag3','tag4']
   assert ob1.tags == ['tag3','tag4']


# Generated at 2022-06-23 07:11:13.147787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable:
        def __init__(self, tags):
            self.tags = tags

        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return super(MockTaggable, self).evaluate_tags(only_tags, skip_tags, all_vars)

    # Test tags
    task_tags_yes = ['foo']
    task_tags_no = ['bar']
    task_tags_always = ['always']
    task_tags_never = ['never']
    task_tags_none = []
    task_tags_many = ['foo', 'bar', 'baz']
    task_tags_many_include_never = ['never', 'foo']
    task_tags_many_include_always = ['always', 'foo']

    # Test defaults
    only_tags

# Generated at 2022-06-23 07:11:22.036263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.append('/usr/local/share/ansible/')
    from ansible.playbook.task import Task

    test_task = Task()

    test_task.tags = ['test1', 'test2']
    assert test_task.evaluate_tags(only_tags=['test3'], skip_tags=['test1'], all_vars={}) is False
    assert test_task.evaluate_tags(only_tags=['test1'], skip_tags=['test1'], all_vars={}) is True

    test_task.tags = []
    assert test_task.evaluate_tags(only_tags=['test3'], skip_tags=['test1'], all_vars={}) is True

# Generated at 2022-06-23 07:11:34.239469
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys
    test_f = Taggable()
    test_f.tags = ['test_tag1', 'test_tag2']

    def test_1_evaluate_tags_only_tags(self, tags=test_f.tags, only_tags=["test_tag1"]):
        self.assertTrue(test_f.evaluate_tags(only_tags, None, {}))

    def test_2_evaluate_tags_skip_tags(self, tags=test_f.tags, skip_tags=["test_tag2"]):
        self.assertFalse(test_f.evaluate_tags(None, skip_tags, {}))


# Generated at 2022-06-23 07:11:43.720801
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # create one instance of TaggableMock, Block, Task and Role
    taggable_mock = TaggableMock()
    block = Block()
    task = Task()
    role = Role()
    play = Play()
    playbook = Playbook()

    # set tags of one TaggableMock to be empty list, will return Untagged

# Generated at 2022-06-23 07:11:50.990978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play, Playbook
    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    # Create a Playbook

# Generated at 2022-06-23 07:12:01.350819
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_playbook = Taggable()

    # Test case when only_tags but all tags
    only_tags = ["all"]
    skip_tags = []
    test_playbook.tags = ["always"]
    assert test_playbook.evaluate_tags(only_tags, skip_tags, {})

    # Test case when only_tags but no tags
    only_tags = ["all"]
    skip_tags = []
    test_playbook.tags = []
    assert not test_playbook.evaluate_tags(only_tags, skip_tags, {})

    # Test case when only_tags but never tag
    only_tags = ["all"]
    skip_tags = []
    test_playbook.tags = ["never"]
    assert not test_playbook.evaluate_tags(only_tags, skip_tags, {})

    #

# Generated at 2022-06-23 07:12:12.576560
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):

        def __init__(self):
            Taggable.__init__(self)
            self.tags = []

    tt = TestTaggable()
    tt.tags = ['a', 'b']
    assert tt.evaluate_tags(['d'], ['c'], []) == True
    assert tt.evaluate_tags(['a'], ['c'], []) == True
    assert tt.evaluate_tags(['B'], [], []) == True
    assert tt.evaluate_tags(['d'], ['b'], []) == False
    tt.tags = []
    assert tt.evaluate_tags(['d'], ['c'], []) == True

# Generated at 2022-06-23 07:12:15.361354
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()
    tags.tags = "tag_1,tag_2"
    assert tags.tags == ["tag_1", "tag_2"]

# Generated at 2022-06-23 07:12:25.385826
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Taggable.evaluate_tags() used with different collection of tags'''

    task1 = Taggable()
    task2 = Taggable()
    task3 = Taggable()
    task4 = Taggable()

    task1._tags = ['jack', 'jill', 'foo']
    task2._tags = ['jack', 'joe', 'foo']
    task3._tags = ['jack', 'jill']
    task4._tags = ['bar', 'baz']

    assert task1.evaluate_tags(['foo'], ['jill'], {}) == True
    assert task2.evaluate_tags(['foo'], ['jill'], {}) == True
    assert task3.evaluate_tags(['foo'], ['jill'], {}) == False

# Generated at 2022-06-23 07:12:37.701620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.included_file
    import ansible.playbook.helpers


# Generated at 2022-06-23 07:12:47.142569
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()
    assert t._tags == []
    assert t.tags == []

    # test loading from a string
    t = Taggable()
    t._load_tags("foo, bar, baz", 'test string')
    assert len(t.tags) == 3
    assert "foo" in t.tags
    assert "bar" in t.tags
    assert "baz" in t.tags

    # test loading from a list
    t = Taggable()
    t._load_tags("foo, bar, baz", ['test', 'list'])
    assert len(t.tags) == 2
    assert "test" in t.tags
    assert "list" in t.tags

    # test loading from a non templated string
    t = Taggable()

# Generated at 2022-06-23 07:12:56.851859
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    yml_data = """
    - hosts:
        - localhost
      tasks:
        - debug:
            msg: 'taggable constructor test'
    """
    pb = Playbook.load(yml_data, variable_manager=VariableManager(), loader=None, inventory=InventoryManager(loader=None, sources=''))
    host_list = pb.get_hosts('localhost')
    play = pb.get_plays()[0]
    task = play.get_tasks()[0]
    assert task.tags == list()

# Generated at 2022-06-23 07:13:08.269480
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def _test_Taggable_evaluate_tags(tags, only_tags, skip_tags, expected_should_run):
        ''' Unit test for method evaluate_tags of class Taggable '''
        item = Taggable()
        item._tags = tags
        should_run = item.evaluate_tags(only_tags, skip_tags, dict())
        assert(should_run == expected_should_run)

    # Test tags set to None/False
    tags = None
    only_tags = ['A']
    skip_tags = ['B']
    expected_should_run = False
    _test_Taggable_evaluate_tags(tags, only_tags, skip_tags, expected_should_run)
    tags = False
    expected_should_run = False

# Generated at 2022-06-23 07:13:20.868241
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable().tags == []
    assert Taggable(tags=['foo','bar']).tags == ['foo', 'bar']
    assert Taggable(tags='foo, bar').tags == ['foo', 'bar']
    assert Taggable(tags='foo').tags == ['foo']

    try:
        Taggable(tags=set())
        assert False
    except AnsibleError:
        pass
    try:
        Taggable(tags={'foo':'bar'})
        assert False
    except AnsibleError:
        pass
    try:
        Taggable(tags=123)
        assert False
    except AnsibleError:
        pass
    try:
        Taggable(tags=True)
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:13:31.121912
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableObject(Taggable):
        pass
    test_object = TaggableObject()
    test_object.tags = ['tag1', 'tag2']

    test_object._ds = None

    # Test no tags
    assert test_object.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) == True

    # Test "all" in only_tags with no "never"
    test_object.tags = ['tag1', 'tag2']
    assert test_object.evaluate_tags(only_tags=set(['all']), skip_tags=set(), all_vars={}) == True
    test_object.tags = ['tag1', 'tag2', 'never']

# Generated at 2022-06-23 07:13:42.897006
# Unit test for constructor of class Taggable
def test_Taggable():
    input = [
        ['a', 'b'],
        'a,b',
        ['a', ['b', 'c']],
        'a,b,c',
        ['a', 'never'],
        'never',
        ['a', ['b', 'c'], 'never'],
        'a,b,c,never'
    ]
    output = [
        ['a', 'b'],
        ['a', 'b'],
        ['a', 'b', 'c'],
        ['a', 'b', 'c'],
        ['a', 'never'],
        ['never'],
        ['a', 'b', 'c', 'never'],
        ['a', 'b', 'c', 'never']
    ]


# Generated at 2022-06-23 07:13:46.399877
# Unit test for constructor of class Taggable
def test_Taggable():
   """Test the Constructor"""
   t = Taggable()
   assert t.tags == []
   assert t.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:13:57.484173
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # test case when `tags` is a string
    t1 = Taggable()
    t1.tags = 'test_Taggable_1'
    assert t1.tags == ['test_Taggable_1']

    # test case when `tags` is a list
    t2 = Taggable()
    t2.tags = ['test_Taggable_2']
    assert t2.tags == ['test_Taggable_2']

    # test case when `tags` is a list of list
    t3 = Taggable()
    t3.tags = [["test_Taggable_3_1", "test_Taggable_3_2"]]

# Generated at 2022-06-23 07:14:01.136607
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == list()

# Unit test function to test if tags should be executed

# Generated at 2022-06-23 07:14:12.938426
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    T = Taggable()
    # False "eval_tags" results
    T.tags = []
    assert not T.evaluate_tags({'foo'}, {}, {})
    assert not T.evaluate_tags({'foo', 'bar'}, {}, {})
    T.tags = ['foo']
    assert not T.evaluate_tags({'bar'}, {}, {})
    T.tags = ['foo', 'bar']
    assert not T.evaluate_tags({'foo', 'baz', 'bam'}, {}, {})
    assert not T.evaluate_tags({'foo', 'baz'}, {'bam'}, {})
    assert not T.evaluate_tags({'baz', 'bam'}, {'foo'}, {})
    assert not T.evaluate_tags({}, {'foo'}, {})


# Generated at 2022-06-23 07:14:15.262747
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()
    tags.tags = ['tag1', 'tag2']
    tags.tags.append('tag3')
    assert tags.tags == ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-23 07:14:17.174287
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags is not None, 'tags must be not None'

# Generated at 2022-06-23 07:14:19.012675
# Unit test for constructor of class Taggable
def test_Taggable():
    my_taggable = Taggable()
    assert (not hasattr(my_taggable, 'tags'))

# Generated at 2022-06-23 07:14:24.672785
# Unit test for constructor of class Taggable
def test_Taggable():

    # Defines a class C that inherits class Taggable
    class C(Taggable):
        pass

    # Instantiate class C
    c = C()

    # Checks that the object 'c' is an instance of class C
    assert isinstance(c, C)

    # Checks that the object 'c' is an instance of class Taggable
    assert isinstance(c, Taggable)


# Generated at 2022-06-23 07:14:30.730081
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyClass(Taggable):
        def __init__(self):
            super(MyClass, self).__init__()
            self._loader = None

    mc = MyClass()
    assert not mc.tags
    assert not mc.only_tags
    assert not mc.skip_tags
    assert not mc.untagged

# Generated at 2022-06-23 07:14:37.775625
# Unit test for constructor of class Taggable
def test_Taggable():

    class Foo(Taggable):
        pass

    foo = Foo()
    assert isinstance(foo._tags, list)
    assert foo._load_tags("", "tag1,tag2") == ['tag1', 'tag2']
    assert foo._load_tags("", 42) == [42]
    assert foo.untagged == frozenset(['untagged'])
    foo._tags = ['tag1', 'tag2']
    assert foo.tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:14:48.742266
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTask:
        def __init__(self, tags):
            self.tags = tags

    class FakePass:
        def __init__(self, result=True):
            self.result = result
            self._task_result = result

    class FakeFail:
        def __init__(self, result=False):
            self.result = result
            self._task_result = result

    # A positive example to assert we can run an item with the right flags
    fake_task = FakeTask(['tag1'])
    assert fake_task.evaluate_tags(['tag2'], ['tag3'], {}) == True

    fake_task = FakeTask([])
    assert fake_task.evaluate_tags([], ['tag3'], {}) == True

    fake_task = FakeTask([])
    assert fake_task.evaluate_

# Generated at 2022-06-23 07:14:50.471063
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-23 07:14:59.894300
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy(Taggable):
        pass

    d = Dummy()
    # Default run, no tags
    assert d.evaluate_tags(only_tags=None, skip_tags=[], all_vars={})
    # Run only tasks with tags:
    assert d.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    # Ignore task without tags
    assert not d.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    # Ignore task without tags, but with always tag
    d.tags = ['always']
    assert not d.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    # Run task with always tag

# Generated at 2022-06-23 07:15:11.603080
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handlers import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude

    play1 = Play()
    block1 = Block()
    block2 = Block()
    block3 = Block()

    play2 = Play()
    block4 = Block()
    block5 = Block()

    role1 = Role()
    role_block1 = Block()
    role_block2 = Block()

# Generated at 2022-06-23 07:15:14.536206
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert not t.untagged  # untagged is a frozenset

# Generated at 2022-06-23 07:15:15.872263
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj is not None


# Generated at 2022-06-23 07:15:20.351805
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        t = Taggable()
        print("test_Taggable: t = %s" % t)
        print("test_Taggable: t._tags = %s" % t._tags)
    except Exception as e:
        print("test_Taggable: exception = %s" % e)


# Generated at 2022-06-23 07:15:33.368843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base

    class TestTaggable(Taggable, Base):
        def __init__(self, all_vars, only_tags=None, skip_tags=None):
            super(TestTaggable, self).__init__()
            self.all_vars = all_vars
            self.only_tags = only_tags
            self.skip_tags = skip_tags

        def run(self, *args, **kwargs):
            if self.evaluate_tags(self.only_tags, self.skip_tags, self.all_vars):
                return (True, args, kwargs)
            return False

    # 1. Test for all tags
    # With only_tags
    # run --tags should run for all tags and for no tags
    # run --tags all should run

# Generated at 2022-06-23 07:15:43.465352
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self):
            self._loader  = None
            self.tags     = ['tag1', 'tag2', 'tag3']
            self.name     = 'MockTaggable'

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_mock_taggable = MockTaggable()
    my_var_manager   = VariableManager()
    my_loader        = DataLoader()

    my_vars = {
        'first_variable': 'foo',
        'second_variable': 42,
    }

    my_var_manager.set_nonpersistent_facts(my_vars)

    # Case 1: no tags given
    only_tags  = None
    skip_

# Generated at 2022-06-23 07:15:50.868063
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dt_block = Taggable()
    dt_block._tags = ['never', 'always']

    task = Taggable(tags = ['never', 'always'])

    assert not dt_block.evaluate_tags(['never'], None, None)
    assert dt_block.evaluate_tags(['always'], None, None)
    assert dt_block.evaluate_tags(['never', 'always'], None, None)
    assert dt_block.evaluate_tags(['always', 'never'], None, None)
    assert not dt_block.evaluate_tags(['never', 'never'], None, None)

    assert not task.evaluate_tags(['never'], None, None)
    assert task.evaluate_tags(['always'], None, None)