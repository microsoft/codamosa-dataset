

# Generated at 2022-06-23 07:05:50.751331
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.static_inventory import StaticInventory


    obj = Taggable()
    assert obj.tags == list()

    obj = Tagg

# Generated at 2022-06-23 07:05:52.041710
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags is not None

# Generated at 2022-06-23 07:06:03.363252
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyClass(Taggable):
        pass

    task = DummyClass()

    # 'always' tag
    task.tags = ['always']
    assert task.evaluate_tags([], [], {}) == True

    # 'always' tag will run even if skip_tags contains 'always'
    task.tags = ['always']
    assert task.evaluate_tags([], ['always'], {}) == True

    # tagged task will run if only_tags contains 'all'
    task.tags = ['foo']
    assert task.evaluate_tags(['all'], [], {}) == True

    # untagged task will run if only_tags contains 'all'
    task.tags = []
    assert task.evaluate_tags(['all'], [], {}) == True

    # untagged task will run if skip_tags contains 'all'

# Generated at 2022-06-23 07:06:06.515872
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert(taggable.evaluate_tags(['a'], ['a'], {}) == False)

# Generated at 2022-06-23 07:06:17.030384
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ['test']
    assert t.evaluate_tags(None, None, {})
    assert t.evaluate_tags(None, ['test'], {})
    assert not t.evaluate_tags(['test'], None, {})
    assert not t.evaluate_tags(['test'], ['test'], {})
    assert not t.evaluate_tags(['other', 'test'], None, {})
    assert not t.evaluate_tags(['other'], ['test'], {})
    assert not t.evaluate_tags(['other'], ['other'], {})
    assert t.evaluate_tags(['other'], ['other', 'test'], {})
    assert t.evaluate_tags(['other', 'test'], ['other'], {})
    assert not t.evaluate_

# Generated at 2022-06-23 07:06:23.764777
# Unit test for constructor of class Taggable
def test_Taggable():
    testTaggable = Taggable()
    assert isinstance(testTaggable._tags, list)
    assert testTaggable._load_tags(testTaggable._tags, 'test_tag') == ['test_tag']
    assert testTaggable._load_tags(testTaggable._tags, ['test_tag1', 'test_tag2']) == ['test_tag1', 'test_tag2']

# Generated at 2022-06-23 07:06:25.842992
# Unit test for constructor of class Taggable
def test_Taggable():
    test_Taggable = Taggable()
    assert test_Taggable._tags == []


# Generated at 2022-06-23 07:06:35.729178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Mock(Taggable):
        pass

    mock = Mock()
    mock.tags = ['tag1', 'tag2', 'tag3']

    assert mock.evaluate_tags(['tag1'], [], {}) == True
    assert mock.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert mock.evaluate_tags(['all'], [], {}) == True
    assert mock.evaluate_tags(['tag6'], [], {}) == False

    mock.tags = ['always', 'tag1', 'tag2']
    assert mock.evaluate_tags(['tag4'], [], {}) == True
    assert mock.evaluate_tags(['tag4'], ['tag1'], {}) == True

    mock.tags = []

# Generated at 2022-06-23 07:06:47.439192
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTask(Taggable):
        def __init__(self):
            self._tags = ['foo', 'bar']

    # task tags contains 'foo' and 'bar'
    t = FakeTask()
    # test with only_tags set
    assert not t.evaluate_tags(['foo'], [], {})
    assert not t.evaluate_tags(['bar'], [], {})
    assert not t.evaluate_tags(['baz'], [], {})
    # and with only_tags not set
    assert t.evaluate_tags([], ['foo'], {})
    assert t.evaluate_tags([], ['bar'], {})
    assert t.evaluate_tags([], ['baz'], {})


# Generated at 2022-06-23 07:06:58.839920
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    class Play(Taggable):
        def get_vars(self):
            return {}

    play = Play()
    assert isinstance(play, Base)
    assert isinstance(play, Taggable)

    play.vars = {}
    assert play.evaluate_tags(None, None, play.get_vars())
    assert play.evaluate_tags([], [], play.get_vars())

    play.vars = {}
    assert play.evaluate_tags(['foo', 'bar'], [], play.get_vars())
    assert not play.evaluate_tags(['foo', 'bar'], ['foo'], play.get_vars())

# Generated at 2022-06-23 07:07:00.731227
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert t._tags == []
    assert t.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:07:10.565891
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block

    b1 = Block()
    assert isinstance(b1, Block)

    b1.tags = ['mytag', 'mytag2']
    assert b1.tags == ['mytag', 'mytag2']

    only_tags = ['mytag3', 'mytag4']
    skip_tags = ['mytag', 'mytag2']
    all_vars = dict()
    assert not b1.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['mytag', 'mytag2']
    skip_tags = ['mytag3', 'mytag4']
    all_vars = dict()
    assert b1.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['tagged']

# Generated at 2022-06-23 07:07:19.243562
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Test evaluate_tags method for role include
    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))

    ri = IncludeRole()
    ri._load_name = lambda x, y: 'test'
    ri._role_name = 'test'
    ri._parent = Play()
    ri._parent._play = Play().load({'name': 'play'}, loader=loader, variable_manager=VariableManager())
    ri._parent._play._variable_manager = VariableManager()

    templar

# Generated at 2022-06-23 07:07:28.987513
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags(None, ['foo', 'bar']) == ['foo', 'bar']
    assert Taggable._load_tags(None, ['foo,bar']) == ['foo', 'bar']
    assert Taggable._load_tags(None, 'foo') == ['foo']
    assert Taggable._load_tags(None, 'foo,bar') == ['foo', 'bar']
    import pytest
    with pytest.raises(AnsibleError):
        Taggable._load_tags(None, {'foo': 'bar'})

# Generated at 2022-06-23 07:07:32.098540
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        Taggable()
    except:
        exception_raised = True

    assert exception_raised is False, 'Taggable object could not be created'

# Generated at 2022-06-23 07:07:45.345265
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.become import Become
    from ansible.playbook.connection import Connection


    results = []


# Generated at 2022-06-23 07:07:55.190675
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    # test case 1: return False
    only_tags = ['wugang']
    skip_tags = ['tagged', 'job1']
    all_vars = {
        'tags': ['wugang', 'tagged', 'job1'],
        'tags1': ['job1'],
        'tags2': ['wugang'],
    }
    res = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert not res
    # test case 2: return True
    only_tags = ['job1', 'wugang']
    skip_tags = ['tagged', 'job2']

# Generated at 2022-06-23 07:08:03.622776
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    if __file__ != 'playbook/__init__.py' and __file__ != 'playbook/play_context.py':
        raise ValueError("The file %s not located in playbook directory" % (__file__))

    try:
        from ansible.inventory.host import Host
        from ansible.vars import VariableManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.executor.task_queue_manager import TaskQueueManager
    except ImportError:
        raise ImportError("module for the test could not be imported")

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()


# Generated at 2022-06-23 07:08:06.696672
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags is not None

test_Taggable()

# Generated at 2022-06-23 07:08:08.435375
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

# Generated at 2022-06-23 07:08:17.638552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    all_vars = dict()
    only_tags = list()
    skip_tags = list()

    # Check the evaluation of tags without tags and without options
    should_run = MyTaggable().evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    assert should_run is True

    # Check the evaluation of tags with tags and without options
    only_tags = list()
    skip_tags = list()
    taggable = MyTaggable()
    taggable.tags = ["tag1"]
    should_run = taggable.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    assert should_run

# Generated at 2022-06-23 07:08:27.739538
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    t = TestClass()
    # no tags, should run
    assert t.evaluate_tags(['never'], [], {}) == True
    assert t.evaluate_tags([], ['never'], {}) == True
    assert t.evaluate_tags([], [], {}) == True

    # tags is empty list - should not run
    t.tags = []
    assert t.evaluate_tags(['never'], [], {}) == False
    assert t.evaluate_tags([], ['never'], {}) == True
    assert t.evaluate_tags([], [], {}) == True

    # tags is ['never'] - should not run
    t.tags = ['never']
    assert t.evaluate_tags(['never'], [], {}) == False
    assert t.evaluate_tags

# Generated at 2022-06-23 07:08:38.409902
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.vars import VariableManager
    v = VariableManager()
    v.extra_vars = dict(
        tags=['tag1'],
        skip_tags=['tag5'],
        other_tags=['tag3', 'tag4'],
        )
    t = Taggable()
    t.tags = ['tag1', 'tag2', 'tag3', 'tag4']
    assert t.evaluate_tags(vars=v.extra_vars) == True
    t.tags = ['tag5']
    assert t.evaluate_tags(vars=v.extra_vars) == False
    t.tags = ['tag2', 'tag3', 'other']
    assert t.evaluate_tags(vars=v.extra_vars) == True

# Generated at 2022-06-23 07:08:39.474798
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t.tags,list)

# Generated at 2022-06-23 07:08:41.368628
# Unit test for constructor of class Taggable
def test_Taggable():
    loader = object()
    block = Taggable(loader=loader)
    assert block._loader == loader
    assert block.tags == []

# Generated at 2022-06-23 07:08:53.462722
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def assertTags(should_run, only_tags, skip_tags, tags):
        t = Taggable()
        t.tags = tags
        assert t.evaluate_tags(only_tags, skip_tags, {}) == should_run

    # base test
    assertTags(True, [], [], [])

    # if there are no tags, we only run tasks that are tagged with always
    assertTags(True, [], [], ['always'])
    assertTags(False, [], [], [])

    # normal should_run and skip_tags
    assertTags(True, [], [], ['tag1'])
    assertTags(True, [], ['tag1'], ['tag1', 'tag2'])
    assertTags(False, [], ['tag2'], ['tag1', 'tag2'])

    # should_

# Generated at 2022-06-23 07:09:02.403535
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # test with all O/S

# Generated at 2022-06-23 07:09:04.694438
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:09:16.033442
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class RuntimeVarTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    class Loader(object):
        def __init__(self, variables=None):
            if variables is None:
                variables = dict()
            self.variables = variables

        def set_variable(self, k, v):
            self.variables[k] = v

    class TestString(unittest.TestCase):
        def setUp(self):
            self.loader = Loader()

        def test_Taggable_evaluate_tags_with_empty_tags(self):
            tags = []
            rv = RuntimeVarTest(tags)
            rv._loader = self.loader
            only_tags = []
            skip_tags = []

            all_vars = dict

# Generated at 2022-06-23 07:09:20.493374
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    task = Task()

    # check if tags is list
    assert isinstance(task.tags, list)

    # check if tags is extendable
    task.tags.append('test')
    assert task.tags == ['test']

# Generated at 2022-06-23 07:09:21.779406
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:09:29.402405
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags_obj = Taggable()
    tags_obj.tags = [ "always", "test" ]
    everything_is_true = True
    everything_is_false = False

    # perform tests
    assert tags_obj.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None) == everything_is_true
    assert tags_obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars=None) == everything_is_true
    assert tags_obj.evaluate_tags(only_tags=["test", "foo"], skip_tags=[], all_vars=None) == everything_is_true
    assert tags_obj.evaluate_tags(only_tags=["test"], skip_tags=["fail"], all_vars=None) == everything_is_true
    assert tags

# Generated at 2022-06-23 07:09:41.103521
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    class DummyTask(Taggable, TaskInclude):
        pass

    dummy_task = DummyTask()

    # Create vars
    test_vars = VariableManager()
    test_vars.add_host_variable('all', 'localhost', {'tags': ['mytag', 'mytag2']})
    test_vars.add_host_variable('localhost', {'tags': ['mytag', 'mytag2']})
    test_vars.add_host_variable('otherhost', {'tags': ['othertag']})
    test_vars.add_host_variable('nottagged', {'tags': []})

    # Define

# Generated at 2022-06-23 07:09:51.344094
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class task(Taggable):
        pass

    t = task()

    # Test whether to run or not with only_tags
    # Tags of task is empty
    only_tags = ['always', 'test']
    skip_tags = []
    assert True == t.evaluate_tags(only_tags, skip_tags, {})
    # Tags of task contains 'always'
    t.tags = ['always']
    assert True == t.evaluate_tags(only_tags, skip_tags, {})
    # Tags of task contains 'test'
    t.tags = ['test']
    assert True == t.evaluate_tags(only_tags, skip_tags, {})
    # Tags of task contains 'always' and 'test'
    t.tags = ['always', 'test']

# Generated at 2022-06-23 07:09:59.156583
# Unit test for constructor of class Taggable
def test_Taggable():

    # omitting the tags field
    tags = Taggable()
    assert tags.tags == []

    # "tags" field should be a list element type
    try:
        tags = Taggable(tags=123)
    except Exception as error:
        assert error.message == 'tags must be specified as a list'

    # "tags" field should be a list element type "string"
    try:
        tags = Taggable(tags=123)
    except Exception as error:
        assert error.message == 'tags must be specified as a list'

# Generated at 2022-06-23 07:10:08.923574
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    t = Task()
    assert t.tags == []
    t.tags = "a,b,c"
    assert t.tags == ['a', 'b', 'c']
    t.tags = ['a', 'b', 'c']
    assert t.tags == ['a', 'b', 'c']

    # TODO: remove this test when we remove the default
    t = Task(tags="a,b,c")
    assert t.tags == ['a', 'b', 'c']
    t = Task(tags=['a', 'b', 'c'])
    assert t.tags == ['a', 'b', 'c']

# Generated at 2022-06-23 07:10:12.092421
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    test_Taggable_obj = Taggable()
    assert test_Taggable_obj._tags == list
    assert test_Taggable_obj.untagged == frozenset(['untagged'])
    # test_Taggable_obj._load_tags()
    # test_Taggable_obj.evaluate_tags()


# Generated at 2022-06-23 07:10:24.045202
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest2 as unittest
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.curdir))
    from ansible.playbook.attribute import FieldAttribute
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.loader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class Test(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    def setUp(self):
        self.test = Test()
        self.test.tags = []
        self.all_v

# Generated at 2022-06-23 07:10:25.940685
# Unit test for constructor of class Taggable
def test_Taggable():
    class Foo(Taggable):
        pass
    foo = Foo()
    print(foo.tags)
    print(foo.evaluate_tags(['all'], [], {}))

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:10:34.756991
# Unit test for constructor of class Taggable

# Generated at 2022-06-23 07:10:46.301256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    import ansible.constants as C

    # define some tasks with different tags

    task_with_tag_never = Task()
    task_with_tag_never.tags = ['never']

    task_with_tag_always = Task()
    task_with_tag_always.tags = ['always']

    task_with_tag_foo = Task()
    task_with_tag_foo.tags = ['foo']

    task_with_tag_untagged = Task()
    task_with_tag_untagged.tags = ['untagged']

    task_with_tags_never_and_foo = Task()
    task_with_tags_never_and_foo.tags = ['never', 'foo']

    task_with_

# Generated at 2022-06-23 07:10:57.454165
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task
    
    mytask = Task()
    mytask.tags = ['test1', 'test2', 'test3']
    mytask.set_loader(None)
    mytask.play = None

    # should run because of the presence of the always tag
    assert mytask.evaluate_tags(only_tags=['always'], skip_tags=[])

    assert mytask.evaluate_tags(only_tags=[], skip_tags=['always']) is False

    # here we're using a string...
    assert mytask.evaluate_tags(only_tags=['test1', 'test2'], skip_tags=[]) is False


# Generated at 2022-06-23 07:10:59.732304
# Unit test for constructor of class Taggable
def test_Taggable():
    task = Taggable()
    t = Taggable()
    assert task is t


# Generated at 2022-06-23 07:11:00.912316
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t.tags,list)

# Generated at 2022-06-23 07:11:09.750102
# Unit test for constructor of class Taggable
def test_Taggable():
    attr = '_tags'
    obj = Taggable()
    ds1 = ["A", "B", "C"]
    ds2 = "A,B,C"
    ds3 = 1
    assert obj._load_tags(attr, ds1) == ['A', 'B', 'C']
    assert obj._load_tags(attr, ds2) == ['A', 'B', 'C']
    try:
        obj._load_tags(attr, ds3)
    except Exception as err:
        assert isinstance(err, AnsibleError)

# Generated at 2022-06-23 07:11:11.107932
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()



# Generated at 2022-06-23 07:11:12.052949
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-23 07:11:22.996146
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableMixin(Taggable):
        def __init__(self):
            self.tags = None

    simple_obj = TaggableMixin()

    # empty tags
    assert simple_obj.evaluate_tags(None, None, None)
    # empty tags
    assert simple_obj.evaluate_tags(set(), set(), None)
    # empty tags
    assert simple_obj.evaluate_tags(set(), None, None)
    # empty tags
    assert simple_obj.evaluate_tags(None, set(), None)

    # no tag specified
    simple_obj.tags = None
    assert simple_obj.evaluate_tags(set(['test']), None, None)

    # no tag specified
    simple_obj.tags = None

# Generated at 2022-06-23 07:11:25.041479
# Unit test for constructor of class Taggable
def test_Taggable():
  from ansible.playbook.task import Task
  t = Task()
  assert t.tags == None

# Generated at 2022-06-23 07:11:37.091522
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTask(Taggable):
        def __init__(self, tags):
            self.tags = tags
    # tests when only_tags is empty
    t = FakeTask([])
    assert t.evaluate_tags([], [], {})
    t = FakeTask([])
    assert t.evaluate_tags([], ['never'], {})
    t = FakeTask(['never'])
    assert not t.evaluate_tags([], ['never'], {})
    t = FakeTask(['always'])
    assert t.evaluate_tags([], ['never'], {})
    # tests when only_tags is all
    t = FakeTask(['always'])
    assert t.evaluate_tags(['all'], [], {})
    t = FakeTask(['never'])

# Generated at 2022-06-23 07:11:45.095688
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # this test is just to exercise the method
    from ansible.playbook.task import Task

    t = Task()
    t.tags = ['foobar', 'baz', 'bar']
    t.evaluate_tags(['baz', 'qux'], ['baz'], {})
    t.evaluate_tags(['bux', 'qux'], ['baz'], {})
    t.evaluate_tags(['bax', 'baz'], ['baz'], {})
    t.evaluate_tags(['baz', 'bax'], ['baz'], {})

# Generated at 2022-06-23 07:11:51.621441
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        from ansible.utils.unicode import to_unicode
    except ImportError:
        from ansible.utils.unicode import to_unicode
    t = Taggable()

    def test_load_tags(a, d):
        return t._load_tags(a, d)

    # test load tags with string
    try:
        test_load_tags('', 'linux,nxos')
        assert False
    except AnsibleError:
        assert True

    # test load tags with list
    try:
        assert test_load_tags('', ['linux', 'nxos']) == ['linux', 'nxos']
        assert True
    except AnsibleError:
        assert False

    # test load tags with int

# Generated at 2022-06-23 07:12:01.363545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    playbook = ansible.playbook.PlayBook()
    only_tags = ['a', 'b']
    skip_tags = ['c', 'd']

    # simple lists
    ta = playbook.create_task_object('debug')
    ta.tags = ['a']
    assert ta.evaluate_tags(only_tags, skip_tags, dict())
    ta.tags = ['e']
    assert not ta.evaluate_tags(only_tags, skip_tags, dict())
    ta.tags = ['c']
    assert not ta.evaluate_tags(only_tags, skip_tags, dict())

    # strings
    ta.tags = 'a'
    assert ta.evaluate_tags(only_tags, skip_tags, dict())
    ta.tags = 'e'
    assert not ta.evaluate_tags

# Generated at 2022-06-23 07:12:12.614694
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  from collections import namedtuple

  TestArgs = namedtuple('TestArgs', 'only_tags, skip_tags, all_vars, tags, expected')

# Generated at 2022-06-23 07:12:23.376262
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestClass(Taggable):
        __slots__ = ['tags']

    # If tags is empty/None, return True
    instance = TestClass()
    instance.tags = None
    assert instance.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) is True

    # If only_tags is empty/None, return True
    instance = TestClass()
    instance.tags = ['always']
    assert instance.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) is True

    # If skip_tags is empty/None, return True
    instance = TestClass()
    instance.tags = ['never']
    assert instance.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) is True

    # If 'always'

# Generated at 2022-06-23 07:12:36.045080
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task1 = Taggable()
    task1.tags = []
    assert task1.evaluate_tags(None, ["tag1"], {}) == True
    assert task1.evaluate_tags(["tag1"], None, {}) == False
    assert task1.evaluate_tags(["tag1"], ["tag1"], {}) == False
    assert task1.evaluate_tags(["tag1", "tag2"], ["tag1"], {}) == False
    assert task1.evaluate_tags(["tag1", "tag2"], ["tag1", "tag2"], {}) == False
    assert task1.evaluate_tags(["tag1", "tag2"], ["tag1", "never"], {}) == False
    assert task1.evaluate_tags(["tag1", "tag2"], ["tag1", "tag3"], {}) == False

# Generated at 2022-06-23 07:12:37.389720
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()


# Generated at 2022-06-23 07:12:39.002556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-23 07:12:47.824248
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    tags = [ 'foo' ]

    only_tags = [ 'jacques', 'foo' ]
    only_tags2 = [ 'all', 'foo' ]

    skip_tags = [ 'never', 'bar' ]
    skip_tags2 = [ 'all' ]

    test = TestTaggable()

    # Test deactivated
    assert test.evaluate_tags(False, False, {}) == True

    # Test evaluation with only_tags
    assert test.evaluate_tags(only_tags, False, {}) == True
    assert test.evaluate_tags(only_tags2, False, {}) == True

    # Test evaluation with only_tags and skip_tags
    assert test.evaluate_tags(only_tags, skip_tags, {}) == True
    assert test.evaluate

# Generated at 2022-06-23 07:12:50.514891
# Unit test for constructor of class Taggable
def test_Taggable():

    t = Taggable()
    assert t._tags == []
    assert t.tags == []

# Generated at 2022-06-23 07:12:58.693280
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    c = Task()
    c.tags = ['test1', 'test2']

    # No tags specified in options
    assert c.evaluate_tags(only_tags=[], skip_tags=[]) is True

    # Everything should be skipped
    assert c.evaluate_tags(only_tags=[], skip_tags=['test1', 'test2']) is False

    # Task contains some --skip-tags options, but also one that matches
    assert c.evaluate_tags(only_tags=['test1', 'test2'], skip_tags=['test2']) is True

    # Task contains tags, but only tags are specified
    assert c.evaluate_tags(only_tags=['test1', 'test2'], skip_tags=[]) is True

    # Task contains no tags, but only tags are

# Generated at 2022-06-23 07:13:09.041794
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['only']
    skip_tags = ['skip']
    all_vars = {}

    # Test 1: Reject 'only' and 'skip' tag without tags in object
    my_obj = Taggable()
    my_obj.tags = []
    assert not my_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test 2: Accept 'only' and 'skip' tag with 'always' tag in object
    my_obj.tags = ['always']
    assert my_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test 3: Accept 'only' and 'skip' tag with 'tagged' tag in object
    my_obj.tags = ['tagged']

# Generated at 2022-06-23 07:13:21.399069
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    task1 = Task()
    task1.name = 'task1'
    task1.tags = ['task1tag1', 'task1tag2']
    task2 = Task()
    task2.name = 'task2'
    task2.tags = ['task2tag1', 'task2tag2']
    task3 = Task()
    task3.name = 'task3'
    task3.tags = ['task3tag1', 'task3tag2']
    task4 = Task()
    task4.name = 'task4'
    task4.tags = ['task4tag1', 'task4tag2']
    task5 = Task()

# Generated at 2022-06-23 07:13:31.629637
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockItem(Taggable):

        def __init__(self, tags, all_vars):
            self._tags = tags
            self._loader = None
            self._all_vars = all_vars


# Generated at 2022-06-23 07:13:42.994314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test related to GitHub issue #17517
    # https://github.com/ansible/ansible/issues/17517
    a = Taggable()
    a.tags = ['foo']
    assert a.evaluate_tags(['foo'], [], {})

    a = Taggable()
    a.tags = ['foo']
    assert a.evaluate_tags(['!foo'], [], {})

    a = Taggable()
    a.tags = ['foo']
    assert a.evaluate_tags(['!foo'], ['foo'], {})

    a = Taggable()
    a.tags = ['foo']
    assert a.evaluate_tags(['foo', '!foo'], ['foo'], {})

    a = Taggable()
    a.tags = ['foo']
    assert a.evaluate_

# Generated at 2022-06-23 07:13:55.426207
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    # expect t.tags to be empty list
    assert t.tags == []
    # expect _load_tags to raise error if non-list passed
    try:
        t._load_tags(t.tags, 'a')
        # raise error if previous succeeds
        assert False == True 
    except AnsibleError:
        # otherwise, test passed
        assert True == True

    try:
        t._load_tags(t.tags, 1)
        assert False == True
    except AnsibleError:
        assert True == True

    try:
        t._load_tags(t.tags, True)
        assert False == True
    except AnsibleError:
        assert True == True


# Generated at 2022-06-23 07:13:57.207252
# Unit test for constructor of class Taggable
def test_Taggable():
    test_Taggable = Taggable()


# Generated at 2022-06-23 07:14:10.239256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test:
        ''' Group of class attributes required to instantiate class Taggable
        '''
        def __init__(self):
            self.tags = []
            self._loader = None

    # Set up class objects required for instantiating class Taggable
    test = Test()

    # Instantiate class Taggable
    testTaggable = Taggable()

    # Set up test variables
    testTaggable.tags = ['always']
    test.tags = []

    # Test evaluate_tags function
    assert testTaggable.evaluate_tags([], [], test) == True
    assert testTaggable.evaluate_tags(['all'], [], test) == True
    assert testTaggable.evaluate_tags(['all','foo'], [], test) == True

# Generated at 2022-06-23 07:14:20.276227
# Unit test for constructor of class Taggable
def test_Taggable():
    class EmptyObject:
        pass

    def test_EmptyObject(self):
        test_object = EmptyObject()
        assert not hasattr(test_object, '_tags')
        assert not hasattr(test_object, 'evaluate_tags')

    test_object = EmptyObject()
    test_object.__class__ = type('TaggableObject', (Taggable, EmptyObject), {})
    assert hasattr(test_object, '_tags')
    assert hasattr(test_object, 'evaluate_tags')
    assert not hasattr(test_object, 'test_object')
    assert test_object.tags == []
    assert test_object.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:14:32.679467
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self, tags):
            self._tags = tags

    inst = TestClass([])
    assert inst.evaluate_tags([], [], {}) == True

    inst = TestClass(['test_tag_1'])
    assert inst.evaluate_tags([], ['test_tag_1'], {}) == False
    assert inst.evaluate_tags(['test_tag_1'], [], {}) == True

    inst = TestClass(['test_tag_1', 'test_tag_2', 'test_tag_3'])
    assert inst.evaluate_tags(['test_tag_1', 'test_tag_2', 'test_tag_4'], [], {}) == True

# Generated at 2022-06-23 07:14:43.247994
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    tags = ['tag1', 'tag2', 'tag3']
    remove_tags = ['tag4', 'tag5']
    myplay = Play()
    myplay.tags = tags
    myplay.remove_tags = remove_tags
    # case 1: no specific tag applied and no tag based on which to skip
    (only_tags, skip_tags) = (None, None) 
    assert myplay.evaluate_tags(only_tags, skip_tags, None) == True
    # case 2: only_tags is set and myplay contains that tag
    only_tags = ['tag3']
    assert myplay.evaluate_tags(only_tags, skip_tags, None) == True
    # case 3: only_tags is set, but not present

# Generated at 2022-06-23 07:14:52.646684
# Unit test for constructor of class Taggable
def test_Taggable():
    ''' test_Taggable
    This is a unit test for constructor of class Taggable
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Create a taggable object
    test_block = Block()
    test_play = PlayContext()

    # block & play both got tags attributes
    print("(1) test_block.tags = %s" % test_block.tags)
    print("(2) test_play.tags = %s" % test_play.tags)
    print("(2) type(test_block.tags) = %s" % type(test_block.tags))

# Generated at 2022-06-23 07:15:00.797876
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class myTaggable(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    # Should run by default
    myTaggable1 = myTaggable()
    myTaggable2 = myTaggable()
    myTaggable2.tags = "always"
    assert myTaggable1.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={})
    assert myTaggable1.evaluate_tags(only_tags=set(['all']), skip_tags=set(), all_vars={})
    assert myTaggable1.evaluate_tags(only_tags=set(), skip_tags=set(['all']), all_vars={})

# Generated at 2022-06-23 07:15:12.641755
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook import TaskInclude

    test_play = Play()

    test_play.tags = ['tag1', 'tag2']
    assert test_play.tags == ['tag1', 'tag2']
    assert test_play.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) is True
    assert test_play.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={}) is False

    test_play.tags = ['tag3', 'tag4']
    assert test_play.tags == ['tag3', 'tag4']

# Generated at 2022-06-23 07:15:22.170460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags=None, only_tags=None, skip_tags=None, all_vars={}):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.all_vars = all_vars

    debug_msg = "Tags: \"%s\", " % (",".join(TestTaggable(tags=tags).tags))

    # Check that the tags are evaluated as expected
    tags = ['always', 'foo']
    assert TestTaggable(tags=tags).evaluate_tags(only_tags=[], skip_tags=[]), \
        debug_msg + "Expected 'True' with only_tags and skip_tags empty list"


# Generated at 2022-06-23 07:15:23.514433
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-23 07:15:28.817234
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    t._load_tags('hello')
    assert t._tags == ['hello']
    t._load_tags(['hello', 'world'])
    assert t._tags == ['hello', 'world']

# Generated at 2022-06-23 07:15:39.733979
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.defaults import DefaultAttribute

    class B(Base, Taggable, DefaultAttribute):
        pass
    b = B.load(dict(dict(tags=['tag1'])))
    assert b.tags == ['tag1']
    b = B.load(dict(dict(tags='tag1, tag2')))
    assert b.tags == ['tag1', 'tag2']
    b = B.load(dict(dict(tags=['tag1', 'tag2'])))
    assert b.tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:15:40.914573
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()

# Generated at 2022-06-23 07:15:47.953983
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleUnicode
    t = Taggable()
    t._tags = ['a', 'b']
    assert t._load_tags(None, ['a', 'b']) == ['a', 'b']
    assert t._load_tags(None, 'a, b') == ['a', 'b']
    assert t._load_tags(None, AnsibleUnicode('a, b')) == ['a', 'b']
    assert t._load_tags(None, UnsafeProxy(dict(foo='bar'))) == ['bar']