

# Generated at 2022-06-23 07:05:57.874728
# Unit test for constructor of class Taggable
def test_Taggable():
    import os
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    basedir = os.path.dirname(__file__)
    f = open(os.path.join(basedir, '../../fixtures/yaml/block_tags.yml'))
    y = f.read()
    yaml = DataLoader()
    yaml.set_basedir(basedir)

    results = yaml.load(StringIO(y))

    t = Taggable()
    t._load_tags('tags', results[0][1])

# Generated at 2022-06-23 07:05:58.939764
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:06:10.623326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar


    class TestBlock(Block):

        def __init__(self, tasks, tags):
            self.parent = None
            self.block = []
            self.tasks = tasks
            self.tags = tags
            self._loader = None
            super(TestBlock, self).__init__(self.parent, self.block, self.tasks)

        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
                if isinstance(value, list):
                    return [x.strip() for x in value]

# Generated at 2022-06-23 07:06:17.792633
# Unit test for constructor of class Taggable
def test_Taggable():
    import tempfile
    import os
    import shutil
    from ansible.utils.collection_loader import _get_collection_base_path

    # Path to test collection
    collection_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, 'packaging', 'collections', 'ansible_collections', 'test_ns', 'test_coll'))
    # Temporary directory used to create a collection
    temp_collection_dir = tempfile.mkdtemp()
    # Copy the test collection to the temporary directory
    shutil.copytree(collection_dir, os.path.join(temp_collection_dir, 'test_ns-test_coll-0.1.0'))
    # Get the path to the test collection

# Generated at 2022-06-23 07:06:22.988456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
	tags = ['a','b']
	only_tags = ['all','c','d']
	skip_tags = ['e','b']
	all_vars = {}
	o = Taggable()
	r = o.evaluate_tags(only_tags, skip_tags, all_vars )
	assert r == False

# Generated at 2022-06-23 07:06:31.617172
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # create a test class as parent for Taggable class
    class DummyTaggable(Taggable):
        def __init__(self, tags=None, skip_tags=None, only_tags=None, all_vars=None):
            self._tags = tags
            self.skip_tags = skip_tags
            self.only_tags = only_tags
            self.all_vars = all_vars
            self._loader, self._templar = self._load_tags()

    # test case 1
    print('\n***** test case 1 *****')
    test_tags = ['all']
    test_skip_tags = None
    test_only_tags = ['never']
    test_all_vars = []

# Generated at 2022-06-23 07:06:39.595313
# Unit test for constructor of class Taggable
def test_Taggable():
    import unittest

    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.module_utils.six import PY3

    class TaggableTest(unittest.TestCase):

        def setUp(self):
            display = Display()
            display.verbosity = 0
            variable_manager = VariableManager()
            # Constructor test for class Taggable
            # When: Having assigned less than two values to the tags attribute
            # Then: Taggable should assert that the tags attribute needs to be a list of two or more items

# Generated at 2022-06-23 07:06:44.360546
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
        
    taggable = Taggable()
    all_vars = {'foo': 'bar'}

    # Test no tags
    taggable._tags = []
    result = taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars=all_vars)
    assert result == True
    result = taggable.evaluate_tags(only_tags=[], skip_tags=['foo'], all_vars=all_vars)
    assert result == True

    # Test only_tags with 'always' tag
    taggable._tags = []
    result = taggable.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars=all_vars)
    assert result == True

# Generated at 2022-06-23 07:06:48.373612
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        _load_name = False

    t = MyTaggable()
    assert t._tags == []
    t._load_tags(None, 'tag1, tag2')
    assert t._tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:06:52.206199
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        from ansible.playbook.base import Base
    except:
        return None

    t = Taggable()
    
    assert t is not None

# Generated at 2022-06-23 07:07:01.362691
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    t = Taggable()
    b = Block()
    b._loader = 'fake_loader'
    p = Play()
    p._loader = 'fake_loader'

    # Test that a task evaluates to runnable
    t.tags = ['test']
    assert t.evaluate_tags([], [], {})
    assert not t.evaluate_tags(['notest'], [], {})

    # Test that an untagged task evaluates to non-runnable
    t.tags = []
    assert not t.evaluate_tags(['notest'], [], {})

    # Test that an untagged task evaluates to runnable


# Generated at 2022-06-23 07:07:05.940442
# Unit test for constructor of class Taggable
def test_Taggable():

    class foo(Taggable):
        pass

    assert isinstance(foo._tags, FieldAttribute)
    assert foo._tags.default == list
    assert foo._tags.isa == 'list'
    assert foo._tags.extend
    assert foo._tags.listof == (string_types, int)


# Generated at 2022-06-23 07:07:14.170384
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.attribute import FieldAttribute

    assert hasattr(Taggable, '_tags')
    assert isinstance(Taggable._tags, FieldAttribute)
    assert Taggable._tags.isa == 'list'
    assert Taggable._tags.default == list
    assert Taggable._tags.listof[0] == str
    assert Taggable._tags.listof[1] == int
    assert Taggable._tags.extend
    assert Taggable.untagged == frozenset(['untagged'])



# Generated at 2022-06-23 07:07:23.073498
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    assert t.evaluate_tags(t.tags, None, t._metadata)
    t.tags.append('test_tag')
    assert t.evaluate_tags(t.tags, None, t._metadata)
    assert not t.evaluate_tags(['test_tag1', 'test_tag2'], None, t._metadata)

    # test 'all' mode
    assert t.evaluate_tags(['all'], None, t._metadata)
    assert not t.evaluate_tags(['all'], ['test_tag'], t._metadata)

    # test 'tagged' mode
    assert not t.evaluate_tags(['tagged'], None, t._metadata)
    t.tags.append('tagged')

# Generated at 2022-06-23 07:07:25.832876
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

test_Taggable()

# Generated at 2022-06-23 07:07:27.481095
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert(isinstance(t, Taggable))

# Generated at 2022-06-23 07:07:32.842444
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable=Taggable()
    assert taggable._load_tags('_tags', ['abc', 'def']) == ['abc', 'def']
    assert taggable._load_tags('_tags', 'abc,def') == ['abc', 'def']
    assert taggable._load_tags('_tags', 'abc') == ['abc']
    assert taggable._load_tags('_tags', 3) == [3]

# Generated at 2022-06-23 07:07:33.740648
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

Taggable()

# Generated at 2022-06-23 07:07:43.066887
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    t = Taggable()
    block = Block([])
    # test _load_tags()
    assert t._load_tags('tags', 'a, b, c') == ['a', 'b', 'c']
    assert t._load_tags('tags', ['a', 'b', 'c']) == ['a', 'b', 'c']
    assert t._load_tags('tags', 1) == [1]

# Generated at 2022-06-23 07:07:45.125847
# Unit test for constructor of class Taggable
def test_Taggable():
        # create instance
        test = Taggable()
        assert isinstance (test.tags, list)

# Generated at 2022-06-23 07:07:47.063415
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible import consta

# Generated at 2022-06-23 07:07:50.970423
# Unit test for constructor of class Taggable
def test_Taggable():
    # Constructor Tests
    # Taggable as Role
    role = Taggable()
    assert role.tags is not None

    # Taggable as Play
    play = Taggable()
    assert play.tags is not None

    # Taggable as Task
    task = Taggable()
    assert task.tags is not None

# Generated at 2022-06-23 07:07:58.556836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(only_tags=None, skip_tags=None, all_vars={'a': 1}) == True
    assert Taggable().evaluate_tags(only_tags=['a'], skip_tags=None, all_vars={'a': 1}) == False
    assert Taggable().evaluate_tags(only_tags=None, skip_tags=['a'], all_vars={'a': 1}) == True
    assert Taggable().evaluate_tags(only_tags=['a'], skip_tags=['b'], all_vars={'a': 1}) == False
    assert Taggable().evaluate_tags(only_tags=['b'], skip_tags=['b'], all_vars={'a': 1}) == True

# Generated at 2022-06-23 07:08:04.815282
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = ['tag2']
    all_vars = {}
    block = Block()
    block.tags = tags
    block_run = block.evaluate_tags(only_tags, skip_tags, all_vars)
    assert block_run, 'Taggable method evaluate_tags missing case'

# Generated at 2022-06-23 07:08:06.519726
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass


# Generated at 2022-06-23 07:08:16.387773
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role_include import IncludeRole
    class TaggedTask(IncludeRole):
        def __init__(self, play=None, **kwargs):
            super(IncludeRole, self).__init__(play=play, **kwargs)
            self._task_queue = []

    class TaggedTask2(IncludeRole):
        def __init__(self, play=None, **kwargs):
            super(IncludeRole, self).__init__(play=play, **kwargs)
            self._task_queue = []
    task1 = TaggedTask(tags=['tag3', 'tag2', 'tag1'])
    task2 = TaggedTask(tags=['tag1', 'tag2', 'tag3'])

# Generated at 2022-06-23 07:08:26.446536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    temp_Taggable = Taggable()
    print("Test case: Tags (only_tags) and (skip_tags) are empty, tags are non-empty")
    temp_Taggable.tags = ['tag1', 'tag2', 'tag2']
    only_tags = {}
    skip_tags = {}
    all_vars = {}
    evaluate_tags_result = temp_Taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    expected_result = True
    print("\tExpected result: " +str(expected_result))
    print("\tActual result: " +str(evaluate_tags_result))
    if (str(expected_result) == str(evaluate_tags_result)):
        print("\tTest #1 passed")

# Generated at 2022-06-23 07:08:36.698712
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Taggable: _evaluate_tags()
    '''

    t = Taggable()

    t.tags = 'always'
    assert t.evaluate_tags(only_tags=['always'], skip_tags=['never'], all_vars={})

    t.tags = 'always'
    assert t.evaluate_tags(only_tags=['always'], skip_tags=['always'], all_vars={}) == False

    t.tags = 'always'
    assert t.evaluate_tags(only_tags=['never'], skip_tags=['never'], all_vars={}) == False

    t.tags = 'always'
    assert t.evaluate_tags(only_tags=['never', 'never'], skip_tags=['never'], all_vars={}) == False


# Generated at 2022-06-23 07:08:48.176065
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    task = dict(
        tags=[
            'test',
            'foo'
        ]
    )
    loader = None
    task_obj = Taggable()
    task_obj.tags = task['tags']

    all_vars = dict()
    print(task_obj.tags)

    # check if default value = True, that is, task should run.
    result = task_obj.evaluate_tags(set(), set(), all_vars)
    assert result == True
    print(task_obj.tags)

    # check if 'test' tag is set, that is, task should run.
    only_tags = set(['test'])
    result = task_obj.evaluate_tags(only_tags, set(), all_vars)
    assert result == True
    print(task_obj.tags)

    # check

# Generated at 2022-06-23 07:09:00.100396
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host

    class TaggableTest(Taggable):
        def __init__(self, host, tags):
            self._loader = None
            self.tags = tags
            self._ds = None
            self._ds = self._load_tags(self._ds, tags)

    all_tags = [ 'all_tag1', 'all_tag2', 'all_tag3', 'all_tag4' ]
    only_tags = [ 'only_tag1', 'only_tag2', 'only_tag3', 'only_tag4' ]
    skip_tags = [ 'skip_tag1', 'skip_tag2', 'skip_tag3', 'skip_tag4' ]

    host = Host(name="test_Taggable_evaluate_tags")
    test_Taggable = Taggable

# Generated at 2022-06-23 07:09:07.725007
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.task import Task

    # all the tags are in this list
    t = Taggable()

    for i in t.tags:
        print(i)

    # add some tags
    t.tags = [1, 2, 3, 4]
    print("after adding tags")
    for i in t.tags:
        print(i)


if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:09:08.573390
# Unit test for constructor of class Taggable
def test_Taggable():
    pass

# Generated at 2022-06-23 07:09:20.005544
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()
    task.tags = ['untagged']
    task.action = "sleep"
    assert task.evaluate_tags(only_tags=[], skip_tags=["sleep"]) == False
    assert task.evaluate_tags(only_tags=[], skip_tags=["sleep", "untagged"]) == False
    assert task.evaluate_tags(only_tags=["sleep"], skip_tags=[]) == True
    assert task.evaluate_tags(only_tags=["untagged"], skip_tags=[]) == False
    assert task.evaluate_tags(only_tags=["tagged"], skip_tags=[]) == False
    assert task.evaluate_tags(only_tags=["tagged"], skip_tags=["untagged"]) == False

# Generated at 2022-06-23 07:09:24.787186
# Unit test for constructor of class Taggable
def test_Taggable():

    # Constructor test: list
    assert isinstance(Taggable._load_tags(None, ['tag1', 'tag2']), list)

    # Constructor test: string
    assert Taggable._load_tags(None, 'tag1, tag2') == ['tag1', 'tag2']

    # Constructor test: other
    try:
        Taggable._load_tags(None, 123)
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:09:33.899078
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    import pytest

    class MyTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    class FakeInclude:
        def __init__(self, tags):
            self.tags = tags

    m = MyTaggable()
    m.tags = ['foo']
    m.all_vars = dict()

    # Default (run everything)
    assert m.evaluate_tags(PlayContext().only_tags, PlayContext().skip_tags, m.all_vars)

    # only_tags is a list with value(s) and not empty
    default_tags = PlayContext().only_tags
    m.all_vars = dict()
    assert m.evaluate_

# Generated at 2022-06-23 07:09:42.753018
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class OtherClass:
        def __init__(self, tags=None, _loader=None):
            self.tags = tags
            self._loader = _loader
    import pytest
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.vars import VariableManager
    # First test
    oc = OtherClass(tags=['foo', 'bar'])
    oc.tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    oc.tags = oc._load_tags(oc.tags, ['foo', 'bar'])
    assert oc.tags == ['foo', 'bar']

# Generated at 2022-06-23 07:09:46.246290
# Unit test for constructor of class Taggable
def test_Taggable():
    class Temp(Taggable):
        pass
    t = Temp()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:09:58.202154
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_taggable = Taggable()
    test_taggable.tags = ["red", "green"]

    # Taggable has only "red" and "green" tag, only_tags has "yellow" and "all",
    # should not be executed
    only_tags = ["yellow", "all"]
    skip_tags = []
    assert False == test_taggable.evaluate_tags(only_tags, skip_tags, {})

    # only_tags has "red" and "yellow", should be executed
    # because of "red" tag
    only_tags = ["red", "yellow"]
    skip_tags = []
    assert True == test_taggable.evaluate_tags(only_tags, skip_tags, {})

    # only_tags has "yellow", and skip_tags has "yellow", "green"
   

# Generated at 2022-06-23 07:10:01.048680
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == [], "Error, default set for tags is not empty."

# Generated at 2022-06-23 07:10:08.602139
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    playbook = ansible.playbook.PlayBook()


# Generated at 2022-06-23 07:10:14.748337
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        def __init__(self):
            self.tags = None
    t = MockTaggable()

    only_tags = frozenset()
    skip_tags = frozenset()

    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(only_tags, skip_tags, dict())

    only_tags = frozenset(['tag2'])
    assert t.evaluate_tags(only_tags, skip_tags, dict())

    only_tags = frozenset(['tag3'])
    assert not t.evaluate_tags(only_tags, skip_tags, dict())

    skip_tags = frozenset(['tag2'])
    assert not t.evaluate_tags(only_tags, skip_tags, dict())


# Generated at 2022-06-23 07:10:23.344859
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    task = Task()
    task._tags = ['tag1', 'tag2']
    task._ds = {'tags': 'tag1, tag2'}

    # Test load_tags method
    assert task._load_tags(task._tags, task._ds['tags']) == ['tag1', 'tag2']

    # Test evaluate_tags method
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) is True

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-23 07:10:35.676961
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def test_equal(expected,result):
        if expected != result:
            raise Exception("expected "+str(expected)+" but got "+str(result))
        else:
            return True

    test_Taggable_1 = Taggable()

    # No tags
    test_result = test_Taggable_1.evaluate_tags(
        only_tags = [],
        skip_tags = ['tagged'],
        all_vars = {},
    )
    test_equal(False,test_result)

    test_result = test_Taggable_1.evaluate_tags(
        only_tags = ['tagged'],
        skip_tags = ['tagged'],
        all_vars = {},
    )
    test_equal(False,test_result)

    # A tag
    test_Tagg

# Generated at 2022-06-23 07:10:46.620786
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest
    from ansible.playbook.task_include import TaskInclude

    playbook_vars = {
        'ansible_ssh_host': '127.0.0.1',
        'ansible_ssh_port': 22
    }

    task_include1 = TaskInclude()
    task_include1._parent = object()
    task_include1.tags = ['upgrade', 'always']
    task_include1.static = False
    task_include1._variable_manager = None
    task_include1._loader = False

    assert task_include1.evaluate_tags(['upgrade'], [], playbook_vars)
    assert task_include1.evaluate_tags(['always'], [], playbook_vars)

# Generated at 2022-06-23 07:10:51.956009
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block

    tag_list = ['test_tag', 'another_test_tag']
    block = Block(None)
    block._load_tags = Taggable._load_tags
    block.tags = tag_list
    assert block.tags == tag_list, 'tags not as expected'

# Generated at 2022-06-23 07:11:03.575728
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def create_task(tags=None, is_block=False):
        if not isinstance(tags, list):
            tags = []

        class MyTask:
            pass

        task = MyTask()
        task.tags = tags
        task.is_block = is_block
        task.evaluate_tags = lambda only_tags, skip_tags, all_vars: Taggable.evaluate_tags(task, only_tags, skip_tags, all_vars)  # pylint: disable=E1101
        return task

    task = create_task(tags=['a', 'b'])
    assert task.evaluate_tags(only_tags=[], skip_tags=[])

    task = create_task()
    assert not task.evaluate_tags(only_tags=['a'], skip_tags=[])

    task = create_

# Generated at 2022-06-23 07:11:14.219030
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Unit test for method Taggable.evaluate_tags() '''

    class TestTaggable(Taggable):
        pass

    # Test: no tags, check only_tags with tag all
    t = TestTaggable()
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[],
                all_vars={})

    # Test: no tags, check only_tags with tag all and skip_tags with tag never
    t = TestTaggable()
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['never'],
                all_vars={})

    # Test: no tags, check only_tags with tag all and skip_tags with tag always
    t = TestTaggable()

# Generated at 2022-06-23 07:11:24.373901
# Unit test for constructor of class Taggable

# Generated at 2022-06-23 07:11:35.269344
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.play_context import PlayContext

    # Useful constants for testing
    always = frozenset(['always'])
    never = frozenset(['never'])
    empty = frozenset()
    _all = 'all'
    _all = Sentinel('ALL', 'all')
    tagged = Sentinel('TAGGED', 'tagged')

    # Classes used for testing
    class MockModule:

        def __init__(self, tags=None, run_tags=None, skip_tags=None, play_context=None):
            self.tags = tags
            self.run_tags = run_tags
            self.skip_tags = skip_tags
            self.play_context = play_context
            self._loader = None


# Generated at 2022-06-23 07:11:48.187041
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_obj = Taggable()
    test_obj._loader = None
    test_obj.tags = ['tag1', 'tag2', 'tag3', 'never']

    test_obj.evaluate_tags(['tag1', 'tag2'], [], {}) # 'always' is not in self.tags, should_run = True
    test_obj.evaluate_tags(['tag2'], ['tag3'], {}) # 'always' is not in self.tags, should_run = True
    test_obj.evaluate_tags(['tag1'], ['tag1'], {}) # 'always' is not in self.tags, should_run = False
    test_obj.evaluate_tags(['tag1'], ['tag2'], {}) # 'always' is not in self.tags, should_run = False
    test_obj

# Generated at 2022-06-23 07:11:59.101075
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Taggable: Test evaluation of tags '''

    class TestObject(Taggable):
        pass

    test_object = TestObject()
    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = ['tag4', 'tag5', 'tag6']
    all_vars = {}

    # test_object.tags = 'tag1, tag2, tag3'
    test_object.tags = 'tag1, tag3'
    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test_object.tags = 'tag1, tag2, tag3'
    test_object.tags = 'tag1, tag2, tag3'

# Generated at 2022-06-23 07:12:01.498365
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        ansible.playbook.task.Task()
    except:
        fail("Failed to initialize class Taggable")

# Generated at 2022-06-23 07:12:06.126419
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """method evaluate_tags of class Taggable"""

    # given
    t = Taggable()

    # when
    t.tags = []
    only_tags = set('tag1')
    skip_tags = set('tag2')
    all_vars = { 'tags' : [] }
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)

    # then
    assert result is False


    # when
    t.tags = set(['tag3', 'tag1'])
    only_tags = set('tag1')
    skip_tags = set('tag2')
    all_vars = { 'tags' : [] }
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)

    # then
    assert result is True


    #

# Generated at 2022-06-23 07:12:16.363055
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    import unittest
    import ansible.playbook.play_context as C
    class MockData:
        pass
    loader = MockData()
    loader.load_from_file.return_value = {}
    play_context = PlayContext(loader=loader)
    test_Taggable = Taggable()
    test_Taggable.tags = ['test_tag']
    assert test_Taggable.evaluate_tags('all', 'tagged', {}) == True
    assert test_Taggable.evaluate_tags('test_tag', 'tagged', {}) == True
    assert test_Taggable.evaluate_tags('all', 'tagged', {}) == False
    assert test_Taggable.evaluate_tags('test_tag', 'tagged', {})

# Generated at 2022-06-23 07:12:25.980262
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_tags_list_1 = ['foo', 'bar']
    test_tags_list_2 = []
    test_tags_string = "foo, bar"
    test_tags_dict = {"foo": "bar"}
    test_var_list = ['foo', 'bar']
    test_var_dict = {"foo": "bar"}
    test_var_dict2 = {"impossible": "foo"}
    test_var_str = '{"foo": "bar"}'
    test_only_tags_list_1 = ['foo', 'bar']
    test_only_tags_list_2 = []
    test_only_tags_string = "foo, bar"
    test_only_tags_dict_1 = {"foo": "bar"}
    test_only_tags_dict_2 = {"bar": "foo"}
    test_

# Generated at 2022-06-23 07:12:38.116368
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    t = Taggable()
    assert t._load_tags(None, 'tag1,tag2') == ['tag1', 'tag2']

    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) is True
    assert t.evaluate_tags([], ['tag1'], {}) is False
    assert t.evaluate_tags(['tag2'], [], {}) is True
    assert t.evaluate_tags([], ['tag2'], {}) is False

    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) is True

# Generated at 2022-06-23 07:12:47.413966
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # declare a block with tags 'tag1' and 'tag2'
    class Block(Taggable):
        _tags = ['tag1', 'tag2']

    # declare a task with tags 'tag3' and 'tag4'
    class Task(Taggable):
        _tags = ['tag3', 'tag4']

    # test with empty list of skip_tags and only_tags
    block_tags = ['tag1', 'tag2']
    task_tags = ['tag3', 'tag4']

    # test that block task is evaluated if there are no tags
    block = Block()
    task = Task()
    assert block.evaluate_tags([], [], {}) == True
    assert task.evaluate_tags([], [], {}) == True

    # test that block task is evaluated

# Generated at 2022-06-23 07:12:57.708222
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
        constructor test for `Taggable` class
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    import unittest

   

# Generated at 2022-06-23 07:13:07.468273
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyClass(Taggable):

        def __init__(self, tags=[]):
            self._tags = tags

    tc = DummyClass(['foo', 'bar'])
    assert tc.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert not tc.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert tc.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})
    assert tc.evaluate_tags(only_tags=['bar', 'foo'], skip_tags=[], all_vars={})
    assert tc.evaluate_tags(only_tags=['foo', 'bar', 'all'], skip_tags=[], all_vars={})
    assert tc

# Generated at 2022-06-23 07:13:09.167996
# Unit test for constructor of class Taggable
def test_Taggable():
    '''test constructor of Taggable class'''
    t = Taggable()
    assert t is not None

# Generated at 2022-06-23 07:13:21.400287
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_class = Taggable()
    test_class._tags = ['tagged']
    
    # all_vars should be the same for all tests
    all_vars = {
        'ansible_play_hosts': 'localhost',
    }

    # for a test case
    # - 'test_id' is the identifier for the test, just for readability
    # - 'only_tags' and 'skip_tags' are the values to be passed to evaluate_tags
    # - 'expected_return' is the expected return value of evaluate_tags
    # - 'details' is used to explain the test case, just for readability

# Generated at 2022-06-23 07:13:22.284512
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:13:30.866851
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Set up class instances
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    inventory = Base()
    play_context = PlayContext()
    play_context.TEMP_DIR = '/tmp'

    # Test Taggable constructor
    t = Taggable(play_context=play_context, variable_manager=variable_manager, loader=loader)
    assert t is not None

# Generated at 2022-06-23 07:13:33.603346
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert isinstance(obj._tags, list)
    assert obj._tags == []

# Generated at 2022-06-23 07:13:44.214717
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    modi = TaskInclude()

    # Test 1
    modi.tags = ['test_tag']
    assert modi.evaluate_tags({u'all'}, {u'all'}, dict())

    # Test 2
    modi.tags = ['always']
    assert modi.evaluate_tags({u'tagged'}, {u'tagged'}, dict())

    # Test 3
    modi.tags = []
    assert modi.evaluate_tags({u'tagged'}, {u'tagged'}, dict())

    # Test 4
    modi.tags = ['never']
    assert not modi.evaluate_tags({u'tagged'}, {u'tagged'}, dict())

# Test for method load_tags of class Taggable

# Generated at 2022-06-23 07:13:50.988716
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags('tags', ['mytag1','mytag2']) == ['mytag1','mytag2']
    assert Taggable()._load_tags('tags', "mytag1, mytag2") == ['mytag1','mytag2']
    assert Taggable()._load_tags('tags', "mytag1") == ['mytag1']

# Generated at 2022-06-23 07:13:57.186923
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert a.evaluate_tags(only_tags=['a'], skip_tags=[], all_vars={}) == False
    assert a.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == False
    assert a.evaluate_tags(only_tags=['a', 'b', 'c'], skip_tags=['a', 'b', 'c'], all_vars={}) == True

# Generated at 2022-06-23 07:14:01.077436
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    print(t.tags)

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:14:12.905576
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test the tags being set to a list, with the list of strings
    tags = Taggable(loader=None, tags = ['tag1', 'tag2'])
    assert tags.tags == ['tag1', 'tag2']

    # Test the tags being set to a list, with the list of integers
    tags = Taggable(loader=None, tags = [1,2])
    assert tags.tags == [1,2]

    # Test the tags being set to a string, with a list of strings
    tags = Taggable(loader=None, tags = 'tag1, tag2')
    assert tags.tags == ['tag1', 'tag2']

    # Test the tags being set to a string, with a list of integers
    tags = Taggable(loader=None, tags = '1,2')

# Generated at 2022-06-23 07:14:15.520499
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    tags = Taggable(loader=loader)
    tags.tags = 'hello, world'
    assert tags.tags == ['hello', 'world']

# Generated at 2022-06-23 07:14:24.850404
# Unit test for constructor of class Taggable
def test_Taggable():

    try:
        # test with a host that does not have vmware installed
        class notag(Taggable):
            tags = ['tag1','tag2','tag3']
        foo = notag()
        assert foo.tags == ['tag1','tag2','tag3']

        class notag(Taggable):
            tags = ['tag1','tag2','tag3']

            def __init__(self, tags=None):
                super(notag, self).__init__(tags=tags)
        foo = notag(tags=['tag1'])
        assert foo.tags == ['tag1']
        assert foo.__doc__ is None

    except:
        print("Failed to instantiate a Taggable class")
        exit(1)

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:14:31.298561
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.helpers import load_list_of_tasks

    task = Task()
    tasks = load_list_of_tasks(task, {})

    if not isinstance(tasks[0], Taggable):
        raise Exception('Taggable not used in construction of Task')

# Generated at 2022-06-23 07:14:42.247294
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable(tags=['foo']).tags == ['foo']
    assert Taggable(tags='foo').tags == ['foo']
    assert Taggable(tags=None).tags == []
    assert Taggable(tags={}).tags is None
    assert Taggable(tags=['foo']).evaluate_tags(['foo'], [], None)
    assert not Taggable(tags=['foo']).evaluate_tags(['bar'], [], None)
    assert Taggable(tags=['foo']).evaluate_tags(['bar'], ['foo'], None)
    assert not Taggable(tags=['foo']).evaluate_tags(None, ['foo'], None)
    assert Taggable(tags=['foo']).evaluate_tags(None, ['bar'], None)

# Generated at 2022-06-23 07:14:51.929056
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # initialize the test object
    obj = Taggable()
    obj.tags = ['tag1', 'tag2']

    # test the Task class, which inherits from Taggable
    task = Task()
    task.tags = obj.tags

    # test for 'only_tags' to be set
    only_tags = ['tag1', 'tag2']
    assert task.evaluate_tags(only_tags, [], dict()) == True, \
        "The task should run"

    only_tags = ['tag1', 'tag3']
    assert task.evaluate_tags(only_tags, [], dict()) == True, \
        "The task should run"



# Generated at 2022-06-23 07:14:57.866924
# Unit test for constructor of class Taggable
def test_Taggable():

    class TestTaggable(Taggable):

        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    assert TestTaggable(tags='hello,world').tags == ['hello', 'world']
    assert TestTaggable(tags=['hello', 'world']).tags == ['hello', 'world']

    def __init__(self, loader=None):
        super(TestTaggable, self).__init__(loader)

# Generated at 2022-06-23 07:15:10.286456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Unit test for method evaluate_tags of class Taggable
    '''

    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    obj = TaskInclude()
    obj.tags = ['tag1', 'tag2']
    only_tags = set(['tag1', 'tag2','tag3'])
    skip_tags = set(['tag4'])

    all_vars = dict()
    all_vars['tag1'] = AnsibleUnsafeText('tag1')
    all_vars['tag2'] = AnsibleUnsafeText('tag2')
    all_vars['tag3'] = AnsibleUnsafeText('tag3')
    all_vars['tag4'] = AnsibleUnsafeText('tag4')

# Generated at 2022-06-23 07:15:20.841696
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    td = dict(
        _loader = None,
    )

    # all run
    only_tags = []
    skip_tags = []

    # only [foo] run
    only_tags = ['foo']
    skip_tags = []

    # only [foo] and [bar,baz] run
    only_tags = ['foo']
    skip_tags = []

    # only [foo] and [bar,baz] run
    only_tags = ['foo','bar','baz']
    skip_tags = []

    # skip [foo] and [bar,baz]
    only_tags = []
    skip_tags = ['foo', 'bar', 'baz']

    # only [foo] run, [bar,baz] skipped
    only_tags = ['foo']

# Generated at 2022-06-23 07:15:23.233572
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:15:35.388548
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    import json

    class test_class(Base, Taggable):
        _test_only_tags = FieldAttribute(isa='list', default=list, listof=string_types)
        _test_skip_tags = FieldAttribute(isa='list', default=list, listof=string_types)

    test_class._load_name = lambda x, y: 0

    test_tags = ['test']

    opt1 = {'tags': test_tags, 'tasks': [{'name': 'task1'}, { 'name': 'task2', 'tags': ['on']}]}
    opt2 = {'tags': test_tags, 'tasks': [{'name': 'task1'}, { 'name': 'task2', 'tags': ['off']}]}


# Generated at 2022-06-23 07:15:44.622608
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    from ansible.playbook.task_include import TaskInclude
    class MockActionPlugin(object):
        def __init__(self, loader, play_context, new_stdin, module_path, task_uuid, ansible_vars):
            self._loader = loader
            self._play_context = play_context
            self._new_stdin = new_stdin
            self._module_path = module_path
            self._task_uuid = task_uuid
            self._ansible_vars = ansible_vars
            self._available_variables = dict()
            self.deprecate_options = dict()
        def get_vars(self):
            return self._ansible_vars
        def set_loader(self, loader):
            self._loader = loader

# Generated at 2022-06-23 07:15:51.541352
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    t.tags = ['osfamily:redhat', 'repo-redhat6']
    t.evaluate_tags(['tagged', 'osfamily:redhat'], ['tagged'], {})
    assert t.evaluate_tags(['tagged', 'osfamily:redhat'], ['tagged'], {}) == True
    assert t.evaluate_tags(['tagged'], ['osfamily:redhat'], {}) == False
    assert t.evaluate_tags(['repo-redhat6'], ['osfamily:redhat'], {}) == True
    assert t.evaluate_tags(['repo-redhat7'], ['osfamily:redhat'], {}) == False

    t.tags = ['all', 'repo-redhat6']
