

# Generated at 2022-06-23 07:05:48.530573
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    t.__dict__.update(dict(
        tags = ["one", "two", "three"],
    ))

    assert(t.tags == ["one", "two", "three"])


# Generated at 2022-06-23 07:05:59.401188
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_context = PlayContext()
    play_context.only_tags = []
    play_context.skip_tags = []

    task_include = TaskInclude()
    task_include.tags = ['always', 'test_tag']
    task_include.evaluate_tags(play_context.only_tags, play_context.skip_tags)

    # Check that evaluate_tags returns true when only_tags is empty and skip_tags is empty
    assert(task_include.should_run is True)

    play_context.only_tags = ['test_tag']
    play_context.skip_tags = []

# Generated at 2022-06-23 07:06:10.964840
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class Test1(Taggable):
        name = 'TEST'
        tags = ['TEST']

    class Test2(Taggable):
        name = 'TEST'
        tags = []

    class Test(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_1_only_tags(self):
            t = Test1()
            self.assertTrue(t.evaluate_tags(only_tags=['TEST'], skip_tags=None, all_vars={}))
            self.assertFalse(t.evaluate_tags(only_tags=['TEST2'], skip_tags=None, all_vars={}))

        def test_2_skip_tags(self):
            t = Test1()

# Generated at 2022-06-23 07:06:17.859631
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.config.manager import ConfigManager
    from ansible.context import CLIContext
    from ansible.parsing.dataloader import DataLoader
    import os
    import yaml
    
    class StubTaggable(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    
    class StubBase(Base, StubTaggable):
        pass
    
    def test_taggable(taggable, only_tags, skip_tags, expected_result):
        base = StubBase()
        base.tags = taggable['tags']
        base._loader = DataLoader()
        templar = Templar(loader=base._loader, variables=None)
        data = {}

# Generated at 2022-06-23 07:06:18.493344
# Unit test for constructor of class Taggable
def test_Taggable():
    pass

# Generated at 2022-06-23 07:06:24.177838
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable('all', variable_manager.get_vars(loader=None, play=None, host=None))

    task = Task()
    task._variable_manager = variable_manager
    task.tags = 'foo'

    # No tags specified to only/skip, so should be True
    assert task.evaluate_tags(only_tags=None, skip_tags=None, all_vars=variable_manager.get_vars())

    # only_tags specified with a tag not in task.tags, so should be False

# Generated at 2022-06-23 07:06:32.094273
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    obj = Taggable()
    obj.tags = [ "tag1", "tag2" ]

    # obj should run
    only_tags = ['tag1']
    skip_tags = []
    assert (obj.evaluate_tags(only_tags, skip_tags, dict()))

    # obj should run
    only_tags = []
    skip_tags = []
    assert (obj.evaluate_tags(only_tags, skip_tags, dict()))

    # obj should not run
    only_tags = []
    skip_tags = ['tag1']
    assert (not obj.evaluate_tags(only_tags, skip_tags, dict()))

    # obj should not run
   

# Generated at 2022-06-23 07:06:45.434764
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test for empty tag list for Taggable
    tg = Taggable()
    assert tg._tags == []

    # Test for None tag list for Taggable
    tg = Taggable(tags=None)
    assert tg._tags == []

    # Test for a valid tag list
    tg = Taggable(tags=['tag1', 'tag2'])
    assert tg._tags == ['tag1', 'tag2']

    # Test for invalid tag list
    try:
        tg = Taggable(tags=['tag1', 1])
        assert False
    except AnsibleError as e:
        assert ('tags must be specified as a list' in e.message)

    # Test for tags not defined
    tg = Taggable(tags=None, task_name="test1")
    assert t

# Generated at 2022-06-23 07:06:56.980938
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:07:01.753039
# Unit test for constructor of class Taggable
def test_Taggable():
    import collections
    t = Taggable()
    assert t._tags == []
    assert isinstance(t._tags, collections.Sequence)
    assert hasattr(t, '_load_tags')
    assert hasattr(t, 'evaluate_tags')

# Generated at 2022-06-23 07:07:09.882598
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['foo']
    only_tags = ['bar', 'baz']
    skip_tags = []
    all_vars = {}
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = ['bar']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    skip_tags = ['bar']
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = ['untagged']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-23 07:07:20.500484
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # create a fake class that supports tags
    class TestableTaggableClass(Taggable):
        tags = None

    target = TestableTaggableClass()

    target.tags = ['tag1']

    assert target.evaluate_tags(None, None, None)  # no tags => True

    assert target.evaluate_tags(['tag1'], None, None)  # tag1 only => True
    assert target.evaluate_tags(['tag1', 'tag2'], None, None)  # tag1 only => True
    assert target.evaluate_tags(['tagged'], None, None)  # tagged => True
    assert target.evaluate_tags(['tag2'], None, None)  # no tag2 => False
    assert target.evaluate_tags([], None, None)  # empty list => False

    assert target.evaluate_

# Generated at 2022-06-23 07:07:26.480247
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags(None, None) == []
    assert Taggable()._load_tags(None, "one, two, three") == ["one", "two", "three"]
    assert Taggable()._load_tags(None, ["one", "two", "three"]) == ["one", "two", "three"]

# Generated at 2022-06-23 07:07:28.190181
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # FIXME: write unit tests for method evaluate_tasks of class Taggable
    pass

# Generated at 2022-06-23 07:07:37.141705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from collections import namedtuple
    import pytest

    class FakeSettings:
        pass
    fake_settings = FakeSettings()
    fake_settings.roles_path = ["./tests/test_utils/roles/role_assumptions/roles"]
    fake_loader = namedtuple('fake_loader', ['path_dwim', 'get_basedir', 'set_basedir', '_variable_manager'])
    fake_inventory = namedtuple('fake_inventory', ['get_variables'])
    task_include = TaskInclude()
    task_include._loader = fake_loader(path_dwim=False,
                                       get_basedir=False,
                                       set_basedir=False,
                                       _variable_manager=False)

# Generated at 2022-06-23 07:07:39.498811
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = ['test_tagging']
    tag = Taggable(tags)
    assert tag.tags == tags

# Generated at 2022-06-23 07:07:42.497784
# Unit test for constructor of class Taggable
def test_Taggable():
    tc = Taggable()
    assert tc._tags == []
    assert tc.tags != []
    assert isinstance(tc.tags, list)

# Generated at 2022-06-23 07:07:45.823936
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.evaluate_tags(only_tags={}, skip_tags={}, all_vars={}) is True


if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:07:48.555331
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable is not None

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:07:56.882047
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    the_object = Taggable()

    # _tags
    assert isinstance(the_object, Base)
    assert isinstance(the_object._load_tags('', []), list)
    assert isinstance(the_object._load_tags('', 'a,b'), list)
    assert isinstance(the_object._load_tags('', 'a,b'), list)
    try:
        the_object._load_tags('', {'foo':'bar'})
        assert False, "_load_tags should have raised exception"
    except:
        pass
    try:
        the_object._load_tags('', 1)
        assert False, "_load_tags should have raised exception"
    except:
        pass

# Generated at 2022-06-23 07:08:09.811550
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    tests the method evaluate_tags of class Taggable with different values of
    only_tags, skip_tags and tags
    '''

    # create an instance of class Taggable
    taggable_object = Taggable()

    # set the value for only_tags and skip_tags.
    only_tags = 'all'
    skip_tags = 'never'

    # test with tags = 'always' and tags = 'never'
    taggable_object.tags = ['always']
    should_run = taggable_object.evaluate_tags(only_tags, skip_tags, {})
    assert(should_run == True)
    taggable_object.tags = ['never']
    should_run = taggable_object.evaluate_tags(only_tags, skip_tags, {})

# Generated at 2022-06-23 07:08:18.529011
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    original_tags = ['debug']
    t = Taggable()
    t.tags = original_tags
    assert t._tags == ['debug']
    assert t.tags == original_tags

    # test with no tags and no options: should run
    assert t.evaluate_tags([], [], dict())
    # test with no tags and only_tag=foo: should not run
    assert not t.evaluate_tags(['foo'], [], dict())
    # test with no tags and skip_tag=bar: should not run
    assert not t.evaluate_tags([], ['bar'], dict())
    # test with no tags and only_tag=all: should run
    assert t.evaluate_tags(['all'], [], dict())
    # test with tags=debug and only_tag=all: should run
    assert t.evaluate_tags

# Generated at 2022-06-23 07:08:29.798141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    for obj in [Host(), Task(), Role()]: # Taggable is a mix-in class
        obj.tags = ['A']
        assert obj.evaluate_tags(None, None, None)
        assert obj.evaluate_tags(None, [], None)
        assert obj.evaluate_tags([], None, None)
        assert obj.evaluate_tags([], [], None)

        assert not obj.evaluate_tags(['B'], None, None)
        assert not obj.evaluate_tags(['B'], [], None)
        assert obj.evaluate_tags(['B', 'A'], None, None)

# Generated at 2022-06-23 07:08:37.131909
# Unit test for constructor of class Taggable
def test_Taggable():
    from collections import Counter
    
    class TaggableTest(Taggable):
        pass

    tt = TaggableTest()

    tt. _tags = [1,2,3]
    assert Counter(tt._tags) == Counter([1,2,3])
    
    tt._tags = "1, 2, 3"
    assert Counter(tt._tags) == Counter([1,2,3])

    # test proper error
    try:
        tt._tags = 1
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-23 07:08:44.271955
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_object = Taggable()
    test_object.tags = ['always']
    assert test_object.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert test_object.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert test_object.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert test_object.evaluate_tags(only_tags=[], skip_tags=['never'], all_vars={})
    assert not test_object.evaluate_tags(only_tags=['never'], skip_tags=[], all_vars={})

# Generated at 2022-06-23 07:08:48.955813
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable(
        _ds={
            'tags': {
                'hash': '1234'
            }
        }
    )
    assert taggable._tags == ['1234']
    #assert taggable._ds == {'tags': {'hash': '1234'}}

# Generated at 2022-06-23 07:09:00.600888
# Unit test for constructor of class Taggable
def test_Taggable():
    # test default value
    t = Taggable()
    assert t.tags == []

    # test with a list of strings
    t = Taggable(tags=['a', 'b'])
    assert t.tags == ['a', 'b']

    # test with a string
    t = Taggable(tags='a, b')
    assert t.tags == ['a', 'b']

    # test with an integer
    t = Taggable(tags=1)
    assert t.tags == [1]

    # test with an invalid parameter
    try:
        t = Taggable(tags=dict())
    except:
        assert True
    else:
        assert False

    # test with a list of integers
    t = Taggable(tags=[1, 2])
    assert t.tags == [1, 2]


# Generated at 2022-06-23 07:09:13.289491
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            pass

    tagged_item = TestTaggable()
    tagged_item.tags = ['tagged', 'another']
    untagged_item = TestTaggable()
    untagged_item.tags = []
    always_item = TestTaggable()
    always_item.tags = ['always']

    assert tagged_item.evaluate_tags(['tagged', 'something'], ['untagged'], [])
    assert not tagged_item.evaluate_tags(['untagged'], ['tagged', 'something'], [])

    assert untagged_item.evaluate_tags([], ['untagged'], [])
    assert not untagged_item.evaluate_tags(['untagged'], [], [])


# Generated at 2022-06-23 07:09:23.791822
# Unit test for constructor of class Taggable
def test_Taggable():
    import unittest

    class TestTaggable(unittest.TestCase):
        '''This is a testing class for class Taggable'''
        def test__load_tags(self):
            from ansible.playbook.base import Base
            from ansible.template import Templar
            from ansible.module_utils. facts.system.distribution import DistributionFactCollector
            from ansible.module_utils.facts.system.distribution import LinuxDistribution
            from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
            from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDefaultImpl

            base = Base()
            templar = Templar(loader=None, variables={})
            fact_collection_distribution = DistributionFactCollector(loader=None)
            ld = LinuxDist

# Generated at 2022-06-23 07:09:36.558708
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self):
            self.tags = []
    import pytest
    taggable = FakeTaggable()
    taggable.tags = ['a', 'b']

    only_tags = {'all'}
    skip_tags = set()
    all_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = set()
    skip_tags = {'all'}
    all_vars = {}
    assert not taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    taggable.tags = []
    only_tags = {'untagged'}
    skip_tags = set()
    all_vars = {}
   

# Generated at 2022-06-23 07:09:38.018798
# Unit test for constructor of class Taggable
def test_Taggable():
    actual = Taggable()
    assert 'tags' in actual._attributes

# Generated at 2022-06-23 07:09:44.849841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible import constants as C

    class _DS():
        pass

    ds = _DS()
    loader = None
    variable_manager = None

    ################################################################################
    # Test block 1:
    #   only_tags is not empty
    #   skip_tags is empty
    #   tags is empty
    #   expect should_run is False
    ################################################################################
    only_tags = ['tag1','tag2','tag3']
    skip_tags = []
    tags = []
    all_vars = {'a':'b'}
    obj = Taggable()
    obj._loader = loader
    obj._variable_manager = variable_manager
    obj.tags = tags
    should_run = obj.evaluate_tags(only_tags, skip_tags, all_vars)
   

# Generated at 2022-06-23 07:09:46.583401
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

# Test for constructor of the class Taggable

# Generated at 2022-06-23 07:09:58.386256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t_all = frozenset(['all'])
    t_test = frozenset(['test'])
    t_test_tagged = frozenset(['test', 'tagged'])
    t_always = frozenset(['always'])
    t_always_tagged = frozenset(['always', 'tagged'])
    t_always_test = frozenset(['always', 'test'])
    t_all_always_test = frozenset(['all', 'always', 'test'])
    t_never_all_always_test = frozenset(['never', 'all', 'always', 'test'])
    t_never_all_always_test_tagged = frozenset(['never', 'all', 'always', 'test', 'tagged'])


# Generated at 2022-06-23 07:10:09.872465
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    module_path = os.path.join(os.path.dirname(__file__), '../..')
    sys.path.append(module_path)

    from ansible.plugins import module_loader

    loader = DataLoader()
    variable_manager = VariableManager()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=["testhost"])
    variable_manager.set_inventory(inventory)

    # test_Taggable_evaluate_tags is a hack, so that we have structurally the same object
    # as in playbooks.py
    # The following variables are set to make sure that the evaluate_tags

# Generated at 2022-06-23 07:10:21.897347
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = dict()
    all_vars['foo'] = [1, 2, 3]
    all_vars['bar'] = [4, 5, 6]
    all_vars['baz'] = [7, 8, 9]
    all_vars['qux'] = [10, 11]

    # The following tests are taken from test_tag_matchers
    # (TestPlaybookExecution.test_tag_matchers)
    #
    # Test that a task gets run when given a list of tags with 'all'
    # and the task has a matching tag
    only_tags = set(['tag1', 'tag2', 'tag3', 'all'])
    skip_tags = set()
    t = Taggable()
    t.tags = ['tag1']

# Generated at 2022-06-23 07:10:30.183788
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    tags=ta._load_tags('tags', ['tag1', 'tag2']);
    assert tags == ['tag1', 'tag2'], 'list constructor failed'
    tags=ta._load_tags('tags', 'tag1, tag2');
    assert tags == ['tag1', 'tag2'], 'string constructor failed'
    import pytest
    pytest.raises(AnsibleError, "ta._load_tags('tags', {})");

# Generated at 2022-06-23 07:10:32.865320
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert ta.tags is not None, "Taggable.__init__(): tags is not None"

# Generated at 2022-06-23 07:10:35.178088
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert t.untagged == frozenset(['untagged'])


# Generated at 2022-06-23 07:10:46.342217
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = dict()
    class MockObj():
        tags = list()
        _loader = None
        def __init__(self, tags):
            self.tags = tags
    class MockOnlyTags():
        def __contains__(self, tag):
            return tag in ('all', 'tagged')

    class MockSkipTags():
        def __contains__(self, tag):
            return tag in ('all', 'tagged')
    impl = Taggable()
    mock_obj = MockObj(list())

    # Tag list is empty so should_run should be False
    assert impl.evaluate_tags(MockOnlyTags(), MockSkipTags(), all_vars) == False
    # Add tag which is not in MockOnlyTags.should_run should be False
    mock_obj.tags.append('some_tag')
   

# Generated at 2022-06-23 07:10:57.493098
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3']

    play = Play().load({}, play_context=play_context, variable_manager=None, loader=None)
    play._loader = 'fake_loader'

    # Case 1: Test the case with only_tags and skip_tags options
    task1 = Task().load({}, play=play, variable_manager=None, loader=None)
    task1.tags = ['tag1', 'tag3']
    assert task1.should_run()


# Generated at 2022-06-23 07:10:59.767578
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []


# Generated at 2022-06-23 07:11:12.219926
# Unit test for constructor of class Taggable
def test_Taggable():
    class Container(object):
        def __init__(self):
            self._attributes = {}
        def __setattr__(self, name, value):
            if name.startswith('_'):
                self.__dict__[name] = value
            else:
                self._attributes[name] = value
        def __getattr__(self, name):
            if name.startswith('_'):
                raise AttributeError()
            else:
                return self._attributes[name]

    class TestObject(Taggable):
        tags = None
    a_obj = TestObject()
    assert True == isinstance(a_obj, Taggable)
    value = ['a', 'b', 'c']
    a_obj.tags = value
    assert value == a_obj.tags


# Generated at 2022-06-23 07:11:23.076348
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.helpers import load_list_of_blocks

    class Foo(Taggable):
        name = ""
        tags = FieldAttribute(isa='list', default=[])
    foo = Foo({"name": "test"})
    foo._loader = None

    blocks = load_list_of_blocks([""], {})
    assert foo.evaluate_tags(blocks.only_tags, blocks.skip_tags, {})

    foo.tags = ["test-tag", "untagged"]
    assert foo.evaluate_tags(blocks.only_tags, blocks.skip_tags, {})

    blocks = load_list_of_blocks(["test-tag"], {})
    assert foo.evaluate_tags(blocks.only_tags, blocks.skip_tags, {})


# Generated at 2022-06-23 07:11:34.394365
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a named tuple, as we are unable to create mock module
    testmodule = namedtuple('TestModule', '_original_basename')
    testmodule.tags = ['tag1', 'tag2', 'always']

    # Create a data loader and variable manager
    loader = DataLoader()
    v = VariableManager()

    # Test the condition when only_tags is not empty
    testmodule.evaluate_tags(['tag3', 'tag4'], [], v)
    assert testmodule.tags == ['tag1', 'tag2', 'always']  # Tuple is not modified

    # Test the condition when only_tags is not empty and 'always' tag is present in tuple.


# Generated at 2022-06-23 07:11:44.225813
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    # In order to check that 'extend' functionality works for Taggable._tags
    # we need to first use Taggable._load_tags to load in some list of tags.
    # For this purpose we'll use a RoleInclude instance, which (like all
    # instances of Taggable) has a ._tags attribute.
    role_include = RoleInclude.load(
        None,
        dict(
            name='roleA',
            tasks=[
                dict(
                    include='some_task',
                )
            ],
            tag='first, second'
        ),
        role_name='roleA',
    )

    playbook = PlaybookBase()


# Generated at 2022-06-23 07:11:45.093178
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()


# Generated at 2022-06-23 07:11:50.047835
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    class TestTaggable(unittest.TestCase):
        class TestObj(Taggable):
            pass
        def testTaggable_evaluate_tags(self):
            # Tests the evaluate_tags() method in the Taggable class
            obj = self.TestObj()
            obj.tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag_all','tag_always']
            # case 1: always, all
            only_tags = ['always','all']
            skip_tags = []
            all_vars = {}
            result = obj.evaluate_tags(only_tags, skip_tags, all_vars)
            self

# Generated at 2022-06-23 07:11:54.925830
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    mt = MyTaggable()
    mt.tags = ['tag1', 'tag2']
    mt.evaluate_tags(['tag1'], [], {}) == True
    mt.evaluate_tags([], [], {}) == True
    mt.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-23 07:12:00.000639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={'foo': 'bar'}) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['foo'], all_vars={'foo': 'bar'}) == True
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=['foo'], all_vars={'foo': 'bar'}) == False

# Generated at 2022-06-23 07:12:11.866860
# Unit test for constructor of class Taggable
def test_Taggable():
    test_Taggable = Taggable()

    # Test normal case of a list passed in for tags
    test_Taggable.tags = ['test_tag_1']
    assert test_Taggable.tags == ['test_tag_1']

    # Test case of a string passed in for tags
    test_Taggable.tags = "test_tag_1, test_tag_2"
    assert test_Taggable.tags == ['test_tag_1', 'test_tag_2']

    # Test case of an invalid type passed in for tags
    # Should raise an AnsibleError
    def test_func():
        test_Taggable.tags = {'test_tag_1': 'value'}

    try:
        test_func()
    except AnsibleError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 07:12:23.207139
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()

    assert(obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True)
    assert(obj.evaluate_tags(only_tags=['x'], skip_tags=[], all_vars={}) == False)
    assert(obj.evaluate_tags(only_tags=['x', 'y'], skip_tags=[], all_vars={}) == False)
    assert(obj.evaluate_tags(only_tags=['x', 'y'], skip_tags=['a', 'b'], all_vars={}) == False)
    assert(obj.evaluate_tags(only_tags=['x', 'y'], skip_tags=['a', 'y'], all_vars={}) == False)

# Generated at 2022-06-23 07:12:26.002014
# Unit test for constructor of class Taggable
def test_Taggable():
    class Test(Taggable):
        def __init__(self):
            pass
    obj = Test()
    assert obj._tags == []
    assert obj.tags == []

# Generated at 2022-06-23 07:12:38.116255
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.play import Play
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    Base.__bases__ = (Taggable,)

    def _create_play(play_id, play_tags=None):
        play = Play.load(x, play_id=play_id)
        play.tags = play_tags
        return play

    x = '''
    name: "test play"
    hosts:
      - all
    gather_facts: false
    tasks:
      - name: "task1"
        ping:
      - name: "task2"
        ping:
      - name: "task3"
        ping:
    '''

    # test empty skip_tags
    # test tagged

# Generated at 2022-06-23 07:12:40.294017
# Unit test for constructor of class Taggable
def test_Taggable():
    test_Taggable = Taggable()
    assert test_Taggable._tags is not None

# Generated at 2022-06-23 07:12:48.459880
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' unit test for method evaluate_tags of class Taggable '''
    # pylint: disable=too-many-locals
    from ansible.playbook import Play
    from ansible.playbook.task import Task

    play = Play()
    play.hosts = ['host1']
    play.name = 'test_Taggable_evaluate_tags'
    play.tags = ['tag1', 'tag2']

    task_01 = Task()
    task_01.name = 'task_01'
    task_01.tags = ['always', 'tagged']
    task_01.action = 'debug'
    task_01.args = {'msg': 'task_01'}

    task_02 = Task()
    task_02.name = 'task_02'

# Generated at 2022-06-23 07:12:57.955782
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    # case 1
    obj.tags = ['a', 'b']
    only_tags = ['a', 'b', 'c']
    skip_tags = ['d', 'e']
    assert obj.evaluate_tags(only_tags, skip_tags, None)
    # case 2
    obj.tags = ['all']
    only_tags = ['a', 'b', 'c']
    skip_tags = ['d', 'e']
    assert obj.evaluate_tags(only_tags, skip_tags, None)
    # case 3
    obj.tags = []
    only_tags = ['a', 'b', 'c']
    skip_tags = ['d', 'e']
    assert not obj.evaluate_tags(only_tags, skip_tags, None)
    # case 4
    obj.tags

# Generated at 2022-06-23 07:13:08.803529
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    """
    Test case for the method evaluate_tags
    This method returns a boolean depending on the tags specified for the object
    Test Cases:
        case 1: Test execute when only_tags are specified
        case 2: Test execute when skip_tags are specified
        case 3: Test execute when both skip_tags and only_tags are specified
        case 4: Test execute when both skip_tags and only_tags are specified with untagged tasks
        case 5: Test execute when only_tags are specified with the following tags ['tagged', 'all', 'tag1' ]
    """
    # use an existing task as the task to

# Generated at 2022-06-23 07:13:13.015802
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == list

# Check if evaluate_tags works correctly with no tags

# Generated at 2022-06-23 07:13:15.634167
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t.tags = [1, 2, 3]
    assert t.evaluate_tags(['all'], [], {})

# Generated at 2022-06-23 07:13:23.618138
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test for method 'evaluate_tags' of class Taggable
    """

    class FakeTask(Taggable):
        def __init__(self):
            self.tags = []

    task = FakeTask()

    assert task.evaluate_tags(['fake_tag'], None, {'foo': 'bar'}) == False
    assert task.evaluate_tags([], None, {'foo': 'bar'}) == True

    task.tags = ['fake_tag']
    assert task.evaluate_tags([], None, {'foo': 'bar'}) == True

    task.tags = ['fake_tag']
    assert task.evaluate_tags(['fake_tag'], None, {'foo': 'bar'}) == True

    task.tags = ['fake_tag', 'always']

# Generated at 2022-06-23 07:13:33.028358
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

        def __init__(self, tags):
            self.tags = tags

    # This test if the tags are correctly evaluated when
    # an only_tags is provided
    def test_only_tags():
        task = Task(tags=['a','b','c'])
        assert task.evaluate_tags(only_tags=['c'], skip_tags=None, all_vars=None) == True
        assert task.evaluate_tags(only_tags=['d'], skip_tags=None, all_vars=None) == False

    # This test if the tags are correctly evaluated when
    # an skip_tags is provided

# Generated at 2022-06-23 07:13:43.809437
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude

    only_tags = {'runme', 'runmetoo'}
    skip_tags = {'dontrunme', 'dontrunmetoo'}
    all_vars = {}
    task_include = TaskInclude()
    task_include.tags = ['runme']

    assert(task_include.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    task_include.tags = ['dontrunme']
    assert(task_include.evaluate_tags(only_tags, skip_tags, all_vars) == False)

    task_include.tags = ['runme', 'dontrunme']
    assert(task_include.evaluate_tags(only_tags, skip_tags, all_vars) == True)

# Generated at 2022-06-23 07:13:56.251876
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

    # Base
    base = Base()
    assert base.tags == []

    # Task
    task = Task()
    assert task.tags == []

    # Handler
    handler = Handler()
    assert handler.tags == []

    # Role
    role = Role()
    assert role.tags == []

    # Test that tags can be specified as a list
    base = Base(tags=['one','two','three'])
    assert base.tags == ['one','two','three']
    task = Task(tags=['one','two','three'])
    assert task.tags == ['one','two','three']

# Generated at 2022-06-23 07:14:09.585732
# Unit test for constructor of class Taggable
def test_Taggable():

    class A(Taggable):
        pass

    a = A()
    assert a.tags == []


    class B(Taggable):
        _tags = ['foo', 'bar']

    b = B()
    assert b.tags == ['foo', 'bar']
    assert b._evaluate_tags(['foo'], [])
    assert not b._evaluate_tags(['bar'], [])
    assert not b._evaluate_tags(['baz'], [])
    assert not b._evaluate_tags([], ['foo', 'bar'])

    assert b._evaluate_tags([], ['foo'])
    assert b._evaluate_tags([], ['bar'])
    assert b._evaluate_tags([], ['baz'])

    assert b._evaluate_tags(['foo'], ['foo', 'bar'])
    assert b._

# Generated at 2022-06-23 07:14:11.471445
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []
    assert obj.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:14:21.625763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test with empty only_tags and empty skip_tags
    only_tags = []
    skip_tags = []
    all_vars = {}
    _tags = ['apple', 'banana', 'cherry']
    _tags_str = 'apple , banana, cherry'
    # Test a. with only_tags and skip_tags as list
    only_tags = []
    skip_tags = []
    obj = Taggable()
    obj.tags = _tags
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True
    obj.tags = _tags_str
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True
    only_tags = ['always']

# Generated at 2022-06-23 07:14:33.915361
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test class
    class testClass(Taggable):
        pass

    # test case 1
    tc1 = testClass()
    tc1.tags = ['all', 'never', 'tagged']
    only_tags1 = ['all', 'never']
    skip_tags1 = ['always']
    all_vars1 = dict()
    res1 = tc1.evaluate_tags(only_tags1, skip_tags1, all_vars1)
    assert res1 == True
    print('test case 1 passed!')

    # test case 2
    tc2 = testClass()
    tc2.tags = ['all', 'never', 'tagged']
    only_tags2 = ['all', 'tagged']
    skip_tags2 = []
    all_vars2 = dict()
    res2 = tc2.evaluate_

# Generated at 2022-06-23 07:14:44.720237
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert Taggable().evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert not Taggable().evaluate_tags(only_tags=['a'], skip_tags=[], all_vars={})
    assert Taggable().evaluate_tags(only_tags=['a', 'b'], skip_tags=['b'], all_vars={})
    assert Taggable().evaluate_tags(only_tags=['skipme'], skip_tags=['skipme'], all_vars={})
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=['skipmetoo'], all_vars={})

# Generated at 2022-06-23 07:14:56.486412
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_tags = Taggable()
    test_tags.tags = ['never', 'test']
    result = test_tags.evaluate_tags(['always','test'], ['never'], {})
    assert result == True
    test_tags2 = Taggable()
    test_tags2.tags = ['never', 'test2']
    result2 = test_tags2.evaluate_tags(['always','test'], [], {})
    assert result2 == False
    test_tags3 = Taggable()
    test_tags3.tags = ['never', 'test2']
    result3 = test_tags3.evaluate_tags(['test'], ['never'], {})
    assert result3 == False
    test_tags4 = Taggable()
    test_tags4.tags = ['never', 'test2']
    result

# Generated at 2022-06-23 07:15:09.363304
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    task = TaskInclude()
    vim = VariableManager()

    task.tags = ['my_tag']
    task.when = []

    # Should be True
    assert task.evaluate_tags(None, None, vim)

    # With only_tags
    only_tags = AnsibleUnicode("my_tag")
    assert task.evaluate_tags(only_tags, None, vim)
    only_tags = AnsibleUnicode("tagged, my_tag")
    assert task.evaluate_tags(only_tags, None, vim)

# Generated at 2022-06-23 07:15:20.317146
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = object.__new__(Taggable)
    task.tags = ['foo','bar','baz']
    only_tags = None
    skip_tags = None
    all_vars = {}
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) is True

    task = object.__new__(Taggable)
    task.tags = []
    only_tags = ['foo']
    skip_tags = None
    all_vars = {}
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) is False

    task = object.__new__(Taggable)
    task.tags = ['foo']
    only_tags = ['bar']
    skip_tags = None
    all_vars = {}

# Generated at 2022-06-23 07:15:26.264185
# Unit test for constructor of class Taggable
def test_Taggable():
    print("Test Taggable constructor")
    obj = Taggable()
    assert obj.__class__.__name__ == 'Taggable'
    assert obj._tags == []

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:15:38.058224
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    # Initialize variables and objects
    only_tags = {'all'}
    skip_tags = None
    class_name = 'MyTaggable'
    all_vars = ['env']
    my_taggable = MyTaggable()
    my_taggable.tags = ['all']

    # Test with only_tags, skip_tags and my_taggable.tags set
    data = my_taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert data is True, '%s unit test 1 failed' % class_name

    # Test with only_tags and skip_tags set
    skip_tags = ['all']

# Generated at 2022-06-23 07:15:47.139344
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Playbook:
        def __init__(self):
            self.tags = set()

    class Task:
        def __init__(self):
            self._loader = None
            self._role = None
            self._block = None
            self._play = Playbook()

    t = Task()
    t.tags = 'always,role::database'

    # CASE 1: no tags specified
    only_tags = set()
    skip_tags = set()
    assert t.evaluate_tags(only_tags, skip_tags, {})

    # CASE 2: no tags specified, but skip role::database
    only_tags = set()
    skip_tags = set(['role::database'])
    assert not t.evaluate_tags(only_tags, skip_tags, {})

    # CASE 3: only run role::database
   