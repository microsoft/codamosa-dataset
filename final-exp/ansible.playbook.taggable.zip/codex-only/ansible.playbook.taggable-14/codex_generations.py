

# Generated at 2022-06-23 07:05:51.579369
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    # test _load_tags
    assert t._load_tags(None, ['1', '2']) == ['1', '2']
    assert t._load_tags(None, '1,2') == ['1', '2']
    assert t._load_tags(None, ['1,2']) == ['1,2']
    assert t._load_tags(None, '1,2,3') == ['1', '2', '3']

# Generated at 2022-06-23 07:06:02.751162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    ti = TaskInclude()
    ti._loader = None
    only_tags = ['tag1', 'tag3']
    skip_tags = ['tag2', 'tag4']
    all_vars = {}


# Generated at 2022-06-23 07:06:14.760304
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:06:19.737816
# Unit test for constructor of class Taggable
def test_Taggable():
   tags = dict()
   tags['all'] = True
   tags['never'] = False
   tags['untagged'] = False 

   assert Taggable._load_tags(tags) == ['all', 'never', 'untagged']

# Generated at 2022-06-23 07:06:29.781097
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Taggable._evaluate_tags() unit test '''

    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Create a playbook context
    play_context = PlayContext()
    play_context.only_tags = ['bar']

    # Create a fake block
    block = Block()

    # Test for the default condition (no tags)
    task = Task()
    task._block = block
    task._play_context = play_context
    assert task._evaluate_tags(None, None, None) == True

    # Test for the 'all' only_tag
    task.tags = ['foo', 'bar', 'baz']

# Generated at 2022-06-23 07:06:38.646001
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory import Host
    from ansible.executor import task_queue_manager
    from ansible.playbook import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Initialize objects
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 07:06:41.715332
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable(dict(tags=list(['a', 'b', 'c'])))
    assert x.tags == ['a', 'b', 'c']

# Generated at 2022-06-23 07:06:48.749616
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    t = Task()
    t._load_tags("tags", "only: foo,bar")
    t._load_tags("tags", "never,foo")
    t._load_tags("tags", [u"only: foo,bar"])
    t._load_tags("tags", [u"never,foo"])
    try:
        t._load_tags("tags", { "only": "foo,bar" })
        raise Exception("Should have thrown exception")
    except:
        pass

# Generated at 2022-06-23 07:06:59.872679
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play, Playbook
    from ansible.vars.manager import VariableManager

    # Build a base list of tags.
    tags = ['tag1', 'tag2', 'tag3']

    # Build a base list of tags to skip.
    skip_tags = ['skip1', 'skip2']

    # Build a base list of tags to include.
    only_tags = ['only1', 'only2']

    # Build a play with the tags listed in the tags list. This should return True.
    play = Play().load({}, dict(name='test1', hosts='all', roles=[], tasks=[], tags=tags, vars={}), loader=None)
    result1 = play._evaluate_tags(only_tags, skip_tags, VariableManager())
    assert(result1 is True)

    # Build a play

# Generated at 2022-06-23 07:07:08.113023
# Unit test for constructor of class Taggable
def test_Taggable():
  assert Taggable._tags.default == list
  assert Taggable._tags.default is not Taggable._tags.default
  assert Taggable._tags.default is not Taggable._tags.default
  assert Taggable.untagged == frozenset(['untagged'])
  assert Taggable.untagged is not Taggable.untagged
  assert Taggable.untagged is not Taggable.untagged
  assert Taggable._tags.name == 'tags'
  assert Taggable._tags.isa == 'list'

# Generated at 2022-06-23 07:07:14.471454
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    t.tags = ['tag_1', 'tag_2']

    only_tags = ['tag_1', 'tag_3']
    skip_tags = ['tag_2', 'tag_3']

    assert t.evaluate_tags(only_tags,skip_tags,{})


# Generated at 2022-06-23 07:07:15.118566
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  pass

# Generated at 2022-06-23 07:07:21.498033
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a dummy class Taggable_Test that inherites from class Taggable
    class Taggable_Test(Taggable):
        pass

    # Create a Taggable_Test object
    x = Taggable_Test()

    # Test Taggable_Test object's evaluate_tags method
    x.tags = []
    only_tags = ['all']
    skip_tags = []
    assert x.evaluate_tags(only_tags, skip_tags, {}) == True

    x.tags = []
    only_tags = []
    skip_tags = ['all']
    assert x.evaluate_tags(only_tags, skip_tags, {}) == False

    x.tags = []
    only_tags = []
    skip_tags = ['untagged']

# Generated at 2022-06-23 07:07:32.730611
# Unit test for constructor of class Taggable
def test_Taggable():
    import ansible.playbook.play_context
    import ansible.playbook.role
    context = ansible.playbook.play_context.PlayContext()
    role = ansible.playbook.role.Role()
    role._role_name = 'TEST'
    role._role_path = '/TEST'
    role._loader = None
    role._tasks = []
    role._parent = None
    # Check if untagged is empty
    assert role.untagged == frozenset([])
    # Check if _tags is an empty list
    assert role._tags == []
    # Check if _load_tags raises error
    try:
        role._load_tags('TEST1', 'TEST2')
    except AnsibleError as e:
        assert "tags must be specified as a list" in str(e)
   

# Generated at 2022-06-23 07:07:44.469745
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags(Taggable(), None, ['a','b']) == ['a', 'b']
    assert Taggable._load_tags(Taggable(), None, 'a') == ['a']
    assert Taggable._load_tags(Taggable(), None, 'a,b,c') == ['a', 'b', 'c']
    assert Taggable._load_tags(Taggable(), None, 42) == [42]
    try:
        Taggable._load_tags(Taggable(), None, {'a': 'b'})
        assert False, "should have raised exception"
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:07:48.970078
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert isinstance(obj, Taggable)
    assert issubclass(type(obj), Taggable)
    assert obj.tags == []
    assert obj.untagged == frozenset(['untagged'])




# Generated at 2022-06-23 07:07:57.138704
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_obj = Taggable()
    test_obj.tags = ['tag']
    assert test_obj.evaluate_tags(['tag'], [], {})
    assert not test_obj.evaluate_tags(['other'], [], {})
    assert test_obj.evaluate_tags(['all'], [], {})
    assert test_obj.evaluate_tags(['tagged'], [], {})
    assert test_obj.evaluate_tags(['tag', 'other'], [], {})
    assert test_obj.evaluate_tags(['tag', 'other'], ['tag'], {})
    assert not test_obj.evaluate_tags(['tag', 'other'], ['other'], {})
    assert test_obj.evaluate_tags(['always'], ['always'], {})
    assert test_obj.evaluate_

# Generated at 2022-06-23 07:08:04.755906
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # 0. Prepare data
    class FakeLoader():
        def get_basedir(self, path):
            return None
    loader = FakeLoader()

    class FakeClass(Taggable):
        _loader = loader
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    obj = FakeClass()

    # 1. test for 'only_tags' is not empty
    only_tags = ['t1', 't2']
    skip_tags = []
    all_vars = dict()

    # 1.1. test for tags is a str, containing several tags
    obj.tags = 't1,t2'
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)  # it should run because of t1 & t2

# Generated at 2022-06-23 07:08:15.680741
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.attribute import Attribute
    class DummyTaggable(Taggable, Attribute):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    # User specified only_tags and skip_tags both are empty
    obj1 = DummyTaggable()
    obj1.tags = ['test_tag']
    assert obj1.evaluate_tags([], [], {}) == True

    # User specified only_tags is not empty and skip_tags is empty
    # Step 1: User specified only_tags contains a valid tag
    obj2 = DummyTaggable()
    obj2.tags = ['test_tag1']
    assert obj2.evaluate_tags(['test_tag'], [], {}) == True
    # Step 2: User specified only

# Generated at 2022-06-23 07:08:26.057914
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['foo', 'bar', 'baz']
    t.vars = {'var_in_vars': 'var_in_vars'}
    all_vars = {
        'var_in_all_vars': 'var_in_all_vars',
        'var_in_vars': 'var_in_vars',
        'var_is_tags': t.tags
    }
    t.set_loader(None)
    t.set_variable_manager(None)

    # default value of only_tags and skip_tags is [], so the task should execute
    only_tags = []
    skip_tags = []
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run

# Generated at 2022-06-23 07:08:36.376436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def assert_evaluate_tags(only_tags, skip_tags, tags, expected):
        class FakeTaggable(Taggable):
            tags = tags
            def __init__(self):
                self._loader = None

        taggable = FakeTaggable()
        result = taggable.evaluate_tags(only_tags, skip_tags, {})
        assert result == expected, \
            'for only_tags={!r}, skip_tags={!r}, tags={!r}: expected {!r}, got {!r}'.format(
                only_tags, skip_tags, tags, expected, result)

    # No tags, no options => should run
    assert_evaluate_tags(
        only_tags=None, skip_tags=None,
        tags=None, expected=True)

# Generated at 2022-06-23 07:08:38.030680
# Unit test for constructor of class Taggable
def test_Taggable():
    tag1 = Taggable()

    assert tag1.tags == []
    assert tag1._tags == []



# Generated at 2022-06-23 07:08:44.710167
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    def get_play():
        host_list = ['localhost', ]
        play_source = dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='Hello World'))),
                dict(action=dict(module='debug', args=dict(msg='Goodbye World'))),
            ],
        )

        play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

        # create a mock to

# Generated at 2022-06-23 07:08:49.202881
# Unit test for constructor of class Taggable
def test_Taggable():
    assert(Taggable()._load_tags('_tags', 'foo, bar, baz') == ['foo', 'bar', 'baz'])
    assert(Taggable()._load_tags('_tags', ['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz'])

# Generated at 2022-06-23 07:09:00.812293
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import copy

    # Create a Taggable object with tags = ['foo']
    t = Taggable()

    t.tags = copy.deepcopy(['foo'])
    assert t.evaluate_tags(None, None, None) == True
    assert t.evaluate_tags(['foo'], None, None) == True
    assert t.evaluate_tags(['bar'], None, None) == False
    assert t.evaluate_tags(['bar', 'foo'], None, None) == True
    assert t.evaluate_tags(['bar', 'foo', 'all'], None, None) == True
    assert t.evaluate_tags([], None, None) == False
    assert t.evaluate_tags(['all'], None, None) == True
    assert t.evaluate_tags(['tagged'], None, None) == True


# Generated at 2022-06-23 07:09:04.794290
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableTest(Taggable):
        pass
    test = TaggableTest()
    assert test.tags == []

# Generated at 2022-06-23 07:09:14.247396
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test instantiation of a Taggable object
    assert Taggable()
    # Test that tags is a FieldAttribute which is a list
    assert isinstance(Taggable()._tags, list)
    # Test that the tags FieldAttribute has the correct type
    assert isinstance(list.__getattribute__(Taggable()._tags, '_type_name'), str)
    # Test that the FieldAttribute has the correct isa
    assert list.__getattribute__(Taggable()._tags, '_isa') == 'list'
    # Test that untagged is a frozenset
    assert isinstance(Taggable.untagged, frozenset)

# Generated at 2022-06-23 07:09:17.436598
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == [], '_tags should be initialized to an empty list'


# Generated at 2022-06-23 07:09:26.309267
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.append('/Users/bkrk/Ansible/ansible/lib')
    from ansible.playbook.base import Base
    b = Base()
    a = Taggable()
    should_run = a.evaluate_tags(only_tags=['my'], skip_tags=['term'], all_vars={})
    assert should_run == False
    b.tags = ['my','all','term','tagged','never','always']
    should_run = a.evaluate_tags(only_tags=['my'], skip_tags=['term'], all_vars={})
    assert should_run == True
    

if __name__ == '__main__':
    test_Taggable_evaluate_tags()
    print('ok')

# Generated at 2022-06-23 07:09:31.698014
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    h = Host(name="testhost")
    g = Group(name="thisgroup")

    b = Base()
    b.only_tags = [ 'tag1', 'tag2', ]
    b.skip_tags = [ 'tag3', 'tag4', ]

    t = Taggable()
    t.tags = ['tag1',]
    assert t.evaluate_tags(b.only_tags, b.skip_tags, {})

    t.tags = ['tagx',]
    assert not t.evaluate_tags(b.only_tags, b.skip_tags, {})

    t.tags = ['tag1', 'tag4',]

# Generated at 2022-06-23 07:09:43.418242
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    class MyTaskInclude(TaskInclude):
        def __init__(self):
            self._parent = None
            self.all_parents = dict()
            self.role = None
            self._play = None
            self._loader = None

    t = MyTaskInclude()
    t._loader = None
    t.name = "test_Taggable_evaluate_tags"

    tags_correct = frozenset(['correct'])
    t.tags = tags_correct

    # test only_tags = ["correct"]
    only_tags = frozenset(["correct"])
    skipped_tags = frozenset()
    assert t.evaluate_tags(only_tags, skipped_tags, dict())
   

# Generated at 2022-06-23 07:09:56.076630
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ansible_options = []
    ansible_options.append("--skip-tags=tagA,tagB")
    ansible_options.append("--tags=tagA,tagB,tagC")
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.set_inventory(Inventory())
    variable_manager.set_loader(Loader())

# Generated at 2022-06-23 07:10:08.512841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print(
        "Testing Taggable.evaluate_tags"
    )
    class TestTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags


# Generated at 2022-06-23 07:10:13.845053
# Unit test for constructor of class Taggable
def test_Taggable():
    class Foo(Taggable):
        pass

    foo = Foo()
    # The default value of field tags should be an empty list
    assert foo.tags == []

# Generated at 2022-06-23 07:10:16.970064
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable_obj = Taggable()
    expected_output = []
    assert taggable_obj._tags == expected_output


# Generated at 2022-06-23 07:10:26.199842
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude

    # test the case where the Taggable class can be used as an attribute of another class
    taggable_playbook = Play

# Generated at 2022-06-23 07:10:37.201014
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableMock(Taggable):
        pass

    task = TaggableMock()

    def check_evaluate_tags(t, only_tags, skip_tags, expected, case_desc):
        # When
        result = t.evaluate_tags(only_tags, skip_tags, all_vars={})
        # Then
        assert result == expected, "%s: '%s' - '%s': %s != %s" % (case_desc, only_tags, skip_tags, result, expected)

    #
    # only_tags
    #
    # Check that only_tags works
    #
    # Case: Tagged, Only
    task.tags = ['a','b','c','always']
    check_evaluate_tags(task, ['a','d'], [], True, "Tagged, Only")

# Generated at 2022-06-23 07:10:39.825097
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == list()


# Generated at 2022-06-23 07:10:49.037280
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTask(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None


# Generated at 2022-06-23 07:10:59.688127
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        """Extend Taggable class with a run method"""
        def run(self):
            pass

    # nv tasks - No Valid Tags
    tnv = Task()
    tnv.tags = ['none']
    rtnv = tnv.evaluate_tags(['always'], [], dict())
    assert rtnv == False

    # vn tasks - Valid No Tags
    tvn = Task()
    tvn.tags = ['always']
    rtvn = tvn.evaluate_tags(['foo'], [], dict())
    assert rtvn == True
    # test for tags-only run
    rtvn = tvn.evaluate_tags(['tagged'], [], dict())
    assert rtvn == True

    # v tasks - Valid Tags
    tv = Task()
   

# Generated at 2022-06-23 07:11:06.732992
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = Taggable()
    task.tags = ["all"]
    assert task.evaluate_tags(
        only_tags = set(),
        skip_tags = set(),
        all_vars  = {},
    ) == True
    assert task.evaluate_tags(
        only_tags = set(["all"]),
        skip_tags = set(),
        all_vars  = {},
    ) == True
    assert task.evaluate_tags(
        only_tags = set(["toto"]),
        skip_tags = set(),
        all_vars  = {},
    ) == False
    assert task.evaluate_tags(
        only_tags = set(["always"]),
        skip_tags = set(),
        all_vars  = {},
    ) == False

# Generated at 2022-06-23 07:11:18.648739
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import include_role
    from ansible.playbook.handler import Handler
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.become import Become

    import yaml
    yaml.add_representer(Taggable, yaml.representer.SafeRepresenter.represent_dict)


# Generated at 2022-06-23 07:11:20.255323
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable is not None
    assert taggable.tags == []

# Generated at 2022-06-23 07:11:28.618589
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    class TestObj:
        tags = set()

    obj = TestObj()
    obj.tags = []
    obj.tags = ['not_always']
    assert t.evaluate_tags(only_tags=['always'], skip_tags=None, all_vars=dict()) == False
    obj = TestObj()
    obj.tags = []
    obj.tags = ['not_always', 'always']
    assert t.evaluate_tags(only_tags=['always'], skip_tags=None, all_vars=dict()) == True
    obj = TestObj()
    obj.tags = []
    obj.tags = ['always']
    assert t.evaluate_tags(skip_tags=['always'], only_tags=None, all_vars=dict()) == False
    obj = TestObj()


# Generated at 2022-06-23 07:11:40.109588
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    yaml_data = """
    - hosts: localhost
      tasks:
        - name: Test
          template: src=template.j2 dest=/tmp/template.txt force=yes
          tags:
            - always
            - test1
            - test2
    """


# Generated at 2022-06-23 07:11:41.940939
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags is not None
    assert t.tags == []


# Generated at 2022-06-23 07:11:53.638069
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    from ansible.utils.vars import combine_vars
    import ansible.utils.unsafe_proxy

    obj = AnsibleBaseYAMLObject()
    obj.__class__ = Taggable
    obj.tags = ['foo']

    data = AnsibleMapping()
    data.__class__ = ansible.utils.unsafe_proxy.AnsibleUnsafeText
    data._data = 'foo'

    assert obj._load_tags('tags', data) == ['foo']
    assert obj._load_tags('tags', 'foo') == ['foo']

    obj.tags = []
    only_tags = ['foo']
    skip_tags = []

# Generated at 2022-06-23 07:12:02.676263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['test1', 'test2', 'test3']
    taggable.tags = ['test1', 'test2', 'test3']
    assert taggable.evaluate_tags(['all'], [], {}) == True
    assert taggable.evaluate_tags([], [], {}) == True
    assert taggable.evaluate_tags(['test1'], [], {}) == True
    assert taggable.evaluate_tags(['test2'], [], {}) == True
    assert taggable.evaluate_tags(['test3'], [], {}) == True
    assert taggable.evaluate_tags(['test4'], [], {}) == False
    assert taggable.evaluate_tags(['tagged'], [], {}) == True


# Generated at 2022-06-23 07:12:03.463623
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-23 07:12:13.838774
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    only_tags = ['foo']
    skip_tags = ['no_foo']
    all_vars = dict()

    # test 'always' execution
    t = Task()
    t.tags = ['always']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) is True
    t.tags = ['not_always']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) is False

    # test 'always' execution skipping
    t.tags = ['always']
    assert t.evaluate_tags(only_tags, ['always'], all_vars) is False

    # test 'no_foo' execution skipping
    t.tags = ['no_foo']

# Generated at 2022-06-23 07:12:24.286711
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    from ansible.parsing import vault

    class TestClass(Taggable):
        def __init__(self):
            self.all_vars = dict(test_var='test')
            self._loader = None
            self.tags = list()

    test_class = TestClass()

    # no tags
    assert test_class.evaluate_tags(['all'], [], test_class.all_vars)

    # run always
    test_class.tags = ['always']
    assert test_class.evaluate_tags(['all'], [], test_class.all_vars)


# Generated at 2022-06-23 07:12:37.348836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockedTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    m = MockedTaggable()
    m.tags = []
    only_tags = ['tag1']
    skip_tags = []
    all_vars = dict()

    # Default, tasks to run
    assert (True == m.evaluate_tags(only_tags, skip_tags, all_vars))

    m.tags = ['tag1']
    # Tags are valid for the condition
    assert (True == m.evaluate_tags(only_tags, skip_tags, all_vars))

    m.tags = ['tag2']
    # Tags are not valid for the condition

# Generated at 2022-06-23 07:12:39.579058
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == [], 'Given: obj._tags == [], expected: []'

# Generated at 2022-06-23 07:12:48.024518
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils import py3compat
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler

    # In the first test, tags are not specified.
    data_structure = dict(
        name = 'Ansible test',
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            'example_role1'
        ]
    )
    play = Play().load(data_structure, variable_manager=None, loader=None)
    assert play.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

# Generated at 2022-06-23 07:12:57.821095
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    class TestTask(Task, Taggable):
        pass

    play_context = PlayContext()

    def setup_tags(task, only_tags, skip_tags, use_task_tags=False):
        if use_task_tags:
            task.tags = ['tag1', 'tag2', 'tag3', 'tag4']
        else:
            task.tags = []
        play_context.only_tags.extend(only_tags)
        play_context.skip_tags.extend(skip_tags)
        play_context.tags = ['tag1', 'tag2', 'tag3']
    
    def check_tags(task, should_run):
        assert task.evaluate_tags

# Generated at 2022-06-23 07:13:08.804273
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Starting:")
    print("Method evaluate_tags")

    class TestClass(Taggable):
        pass

    test_class = TestClass()
    test_class.tags = ['test', 'list']

    result = test_class.evaluate_tags(only_tags=[], skip_tags=['list'],
                                      all_vars={})
    assert result == False

    result = test_class.evaluate_tags(only_tags=[], skip_tags=['test'],
                                      all_vars={})
    assert result == False

    result = test_class.evaluate_tags(only_tags=[], skip_tags=['test', 'list', 'never'],
                                      all_vars={})
    assert result == True


# Generated at 2022-06-23 07:13:21.398673
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    import ansible.constants as C

    class MyTaskInclude(TaskInclude, Taggable):
        pass

    class MyBlock(MyTaskInclude, Block):
        pass

    class MyPlay(MyBlock, Play):
        pass

    class MyPlaybook(Base, Playbook):
        pass

    all_vars = dict()
    templar = Templar(loader=None, variables=all_vars)
    b_block_tags = ["myblocktag", "myblocktag2"]
    p_

# Generated at 2022-06-23 07:13:31.628254
# Unit test for constructor of class Taggable
def test_Taggable():

    class DummyClass:
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

        def __init__(self, tags=None):
            object.__setattr__(self, '_tags', self._load_tags('_tags', tags))
            object.__setattr__(self, '_ds', tags)

        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
                if isinstance(value, list):
                    return [x.strip() for x in value]
                else:
                    return [ds]

# Generated at 2022-06-23 07:13:42.997700
# Unit test for constructor of class Taggable
def test_Taggable():
    #Check simple tags
    a = Taggable()
    a._load_tags('tags', 'foo,bar')
    assert isinstance(a.tags, list)
    assert 'foo' in a.tags and 'bar' in a.tags

    #Check list of tags
    a = Taggable()
    a._load_tags('tags', ['foo', 'bar'])
    assert isinstance(a.tags, list)
    assert 'foo' in a.tags and 'bar' in a.tags

    #Check errors
    try:
        a = Taggable()
        a._load_tags('tags', 1)
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:13:55.427193
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class CommonPlay:
        tags = ['all']
        only_tags = ['all','test']
        skip_tags = ['all','foo']

    class TestTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
            self.only_tags = CommonPlay.only_tags
            self.skip_tags = CommonPlay.skip_tags
        def __call__(self):
            return self.evaluate_tags(CommonPlay.only_tags, CommonPlay.skip_tags, None)
        def __repr__(self):
            return str(self.tags)


# Generated at 2022-06-23 07:14:08.879107
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class SubTaggable(Taggable):
        def __init__(self):
            super(SubTaggable, self).__init__()
            self.tags = ['tag1', 'tag2', 'tag3']

    task = SubTaggable()

    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) is True
    assert task.evaluate_tags(['tag1', 'tag2'], ['tag3'], {}) is True
    assert task.evaluate_tags(['tag1', 'tag2'], ['tag2'], {}) is False
    assert task.evaluate_tags([], ['tag2'], {}) is True
    assert task.evaluate_tags([], ['tag1', 'tag3'], {}) is True

# Generated at 2022-06-23 07:14:19.483758
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    import os
    import unittest
    import sys, imp
    sys.meta_path = [imp.find_module('ansible')[1]]
    sys.path.insert(0, os.path.join( imp.find_module('ansible')[1], '..','..'))
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils import basic
    import ansible.module_utils.basic as basic
    import ansible.module_utils.six as six

    class TestPlaybook(unittest.TestCase):

        def test_Taggable_constructor(self):

            taggable = Taggable()


# Generated at 2022-06-23 07:14:31.450213
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    inventory = ansible.inventory.Inventory(
        ansible.inventory.InventoryScript(_AN_INVENTORY_SCRIPT)
    )
    host = inventory.get_host('localhost')
    host.vars = {}
    host.vars['var1'] = 100
    host.vars['var2'] = 'hello world'
    
    if len(sys.argv) > 1:
        ansible.constants.DEFAULT_ROLES_PATH = sys.argv[1]
    else:
        ansible.constants.DEFAULT_ROLES_PATH = './'
    

# Generated at 2022-06-23 07:14:42.346723
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    only_tags = None
    skip_tags = None
    all_vars = None


    #
    # 1. When "tags" is empty. Should return True.
    #
    t = Task()
    t.tags = []
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    #
    # 2. When "tags" is ["test"], "only_tags" is ["test"] and "skip_tags" is None. Should return True.
    #
    t.tags = ["test"]
    only_tags = ["test"]
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-23 07:14:51.381267
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude

    t = TaskInclude()
    assert t.tags == t.get_tags() == []
    assert t._load_tags(None, []) == []
    assert t._load_tags(None, '') == []
    assert t._load_tags(None, 'tag1,tag2,tag3') == ['tag1', 'tag2', 'tag3']
    assert t._load_tags(None, [1, 2, 't1,t2', 4]) == [1, 2, 't1,t2', 4]
    assert t._load_tags(None, 't1,t2,t3') == ['t1', 't2', 't3']

# Generated at 2022-06-23 07:15:00.475694
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self):
            self._tags = []

    taggable = MockTaggable()
    # No tags set and no tag options specified
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    # No tags set, --skip-tags 'never' specified
    assert taggable.evaluate_tags(only_tags=[], skip_tags=['never'], all_vars={})
    # No tags set, --skip-tags 'all' specified
    assert not taggable.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={})
    # No tags set, --skip-tags 'tagged' specified

# Generated at 2022-06-23 07:15:12.114447
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock(Taggable):
        def __init__(self):
            self._loader = 'LOADER'
            self.tags = []


# Generated at 2022-06-23 07:15:22.003853
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ds = Taggable()
    only_tags = ['tag2']
    skip_tags = ['tag1']
    all_vars = {}
    result = ds.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True
    assert ds.tags == []
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3']
    result = ds.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True
    assert ds.tags == []
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag1', 'tag2']
    result = ds.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False

# Generated at 2022-06-23 07:15:24.626872
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test with empty object
    a = Taggable()
    assert a.tags == []

    # Test with a string
    b = Taggable(tags="test")
    assert b.tags == ['test']

    # Test with a list
    c = Taggable(tags=['test1', 'test2'])
    assert c.tags == ['test1', 'test2']

# Generated at 2022-06-23 07:15:36.912312
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock:
        def __init__(self):
            self.tags = None
            self.untagged = Taggable.untagged
            self._loader = None
    taggable_mock = TaggableMock()
    # empty tags are set as untagged in evaluate_tags
    taggable_mock.tags = []
    assert taggable_mock.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    taggable_mock.tags = None
    assert taggable_mock.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    # 'always' tag always forces execution
    taggable_mock.tags = ['always']

# Generated at 2022-06-23 07:15:41.354935
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t2 = Taggable()
    t2.tags='Tag'
    t3 = Taggable()
    t3.tags='Tag1,Tag2'
    assert t._tags==[]
    print(t._tags)
    print(t2._tags)
    assert t2._tags==['Tag']
    assert t3._tags==['Tag1','Tag2']

# Generated at 2022-06-23 07:15:42.209483
# Unit test for constructor of class Taggable
def test_Taggable():
  assert Taggable().tags == []

# Generated at 2022-06-23 07:15:50.113611
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import json
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook import Play

    class MyBlock(Block, Taggable):
        pass

    class MyTask(Task, Taggable):
        pass

    def test_evaluate_tags(taggable, only_tags, skip_tags, all_vars, expected=True):

        if not isinstance(taggable, Taggable):
            raise Exception("Invalid taggable", taggable)

        if not isinstance(only_tags, list):
            raise Exception("Invalid only_tags", only_tags)

        if not isinstance(skip_tags, list):
            raise Exception("Invalid skip_tags", skip_tags)
