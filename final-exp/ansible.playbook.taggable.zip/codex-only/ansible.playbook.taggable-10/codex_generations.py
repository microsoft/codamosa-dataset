

# Generated at 2022-06-23 07:05:49.962780
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyClass(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
        def _load_tags(self, attr, ds):
            return ds

    assert DummyClass(tags=['tag1']).evaluate_tags(only_tags=None, skip_tags=None, all_vars=None) == True
    assert DummyClass(tags=['tag1']).evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars=None) == True
    assert DummyClass(tags=['tag1']).evaluate_tags(only_tags=['tag2'], skip_tags=None, all_vars=None) == False

# Generated at 2022-06-23 07:05:59.918766
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    t = Task()
    assert t._tags == [], '_tags should be initialized to empty list'
    assert t.evaluate_tags(['all', 'osx'], [], {}), 'all tag should return True'
    assert not t.evaluate_tags(['osx'], [], {}), 'empty tags should return False'
    assert t.evaluate_tags([], ['osx'], {}), 'empty tags with osx skip should return True'
    assert not t.evaluate_tags(['osx'], ['osx'], {}), 'tags and skip tags should return False'
    assert not t.evaluate_tags([], ['all'], {}), 'empty tags with all skip tags should return False'

# Generated at 2022-06-23 07:06:00.770618
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-23 07:06:07.871510
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_dict = dict(
        __ansible_tags__ = ['tagged', 'tagged2'],
        )
    test_class = Taggable()
    test_class._load_tags('_tags', test_dict['__ansible_tags__'])
    test_class.tags = ['tagged']
    test_class.evaluate_tags(['tagged', 'tagged2'], test_dict['__ansible_tags__'], {'__ansible_tags__': test_dict['__ansible_tags__']})
    assert test_class.tags == ['tagged']

# Generated at 2022-06-23 07:06:18.044493
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task.load(None, dict(), '/nonexistent', loader=None)
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3']
    all_vars = dict()
    # Testing with only_tags
    task.tags = ['tag1']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == True
    task.tags = ['tag3']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == False
    # Testing with skip_tags
    task.tags = ['tag1']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == True
    task.tags = ['tag3']
    assert task.evaluate

# Generated at 2022-06-23 07:06:28.930869
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeClassWithTags(Taggable):
        def __init__(self):
            self.tags = []

    def run_test_case(test_name, obj, only_tags, skip_tags, all_vars, expected_result):
        result = obj.evaluate_tags(only_tags, skip_tags, all_vars)
        if result != expected_result:
            raise AnsibleError("ERROR: test_Taggable_evaluate_tags: test '%s': unexpected evaluation result: got %s but expected %s" % (test_name, result, expected_result))

    fake_obj = FakeClassWithTags()

    # Test case: no tag options
    run_test_case("no tag options", fake_obj, [], [], {}, True)

    # Test case: no tags

# Generated at 2022-06-23 07:06:38.444320
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Import necessary methods, classes and constants from module_utils
    from ansible.module_utils.six import string_types

    # Class Taggable, method evaluate_tags of class Taggable to be tested
    from ansible.playbook.taggable import Taggable

    # Create mock objects and initialize them with arbitrary
    # test data
    mock_Taggable_Taggable_instance_obj = Taggable()
    mock_Taggable_Taggable_instance_tags = ["tag1", "tag2"]
    mock_Taggable_Taggable_instance_obj.tags = mock_Taggable_Taggable_instance_tags
    mock_Taggable_Taggable_instance_untagged = frozenset(["untagged"])
    mock_Taggable_Taggable_instance_obj.untagged

# Generated at 2022-06-23 07:06:48.750930
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test_Taggable_evaluate_tags()
        This is a basic test to ensure the evaluate_tags method
        works as expected.
    '''
    def run_tag_test(tag, only_tags, skip_tags, expected):
        t = Taggable()
        t.tags = [tag]
        all_vars = {}
        assert t.evaluate_tags(only_tags, skip_tags, all_vars) == expected
    # test basic tag handling
    run_tag_test('tag1', [], [], True)
    run_tag_test('tag1', [], ['tag1'], False)
    run_tag_test('tag1', ['tag1'], [], True)
    run_tag_test('tag1', ['tag1'], ['tag1'], True)
    # test the

# Generated at 2022-06-23 07:06:59.272289
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils.path import unfrackpath

    test_data_path = unfrackpath('../../../test/integration/filter_plugins/test_data', __file__)
    test_data_path_template = unfrackpath(test_data_path + '/../../../../templates', __file__)

    play_context = PlayContext()
    task = Task()

    # Test that file_name is None
    assert task.file_name is None

    # Test that module_args is None
    assert task.module_args is None

    # Test that loop is an empty list
    assert task.loop == []

# Generated at 2022-06-23 07:07:10.364005
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role.include import RoleInclude
    # Empty lists for run_tags and skip_tags, so default should be True
    # if no tags are set on the item
    item = RoleInclude()
    assert item.evaluate_tags(only_tags=[], skip_tags=[], all_vars=dict())

    # The 'never' tag should be checked, so this should be False
    item.tags = ['never']
    assert not item.evaluate_tags(only_tags=[], skip_tags=[], all_vars=dict())

    # Default is True, but the 'tagged' tag in skip_tags overrides this
    # so it should be False.
    item.tags = ['notarealtag']

# Generated at 2022-06-23 07:07:20.836165
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create test object
    class Test_Taggable(Taggable):
        def __init__(self):
            self.tags = list()

    test_obj = Test_Taggable()

    # Create test variables
    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    # Test default behavior (task will be run)
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test only tags: tags:always
    test_obj.tags = ['always']
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test only tags: tag1
    only_tags = {'tag1'}
    test_obj.tags = ['tag1']

# Generated at 2022-06-23 07:07:25.305038
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._tags.default == list
    assert Taggable._tags.type == 'list'
    assert Taggable._tags.isa == 'list'
    assert Taggable._tags.listof == (string_types, int)

# Generated at 2022-06-23 07:07:34.110731
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import Include
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, None, None) #FIXME
    include = Include()
    include.tags = ['tag1', 'tag2']
    assert (include._tags == ['tag1', 'tag2'])
    include2 = Include()
    include2.tags = 'tag1, tag2 , tag3'
    assert (include2._tags == ['tag1', 'tag2', 'tag3'])
    try:
        include3 = Include()
        include3.tags = 'tag1, tag2 , tag3'
        include3.tags = [42, 42]
        assert (False)
    except Exception:
        assert (True)

# Generated at 2022-06-23 07:07:46.701802
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    class TestTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    playbook = TestTaggable()

    # Act
    result1 = playbook.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    playbook._tags = ['test']
    result2 = playbook.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})

    # Assert
    assert result1 == False
    assert result2 == True
#
#    if __name__ == '__main__':
#    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:07:55.609891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):

        def __init__(self, tags, loader, all_vars):
            self._loader = loader
            self.tags = tags

    all_vars = { }
    loader = None

    # Test tag_only and tag_skip parameters
    only_tags = []
    skip_tags = []
    test_tags = ['tag1']
    should_run = TestTaggable(test_tags, loader, all_vars).evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run is True

    only_tags = ['tag1']
    skip_tags = []
    test_tags = ['tag1']

# Generated at 2022-06-23 07:08:03.670379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class _ModuleUtilsTestCase(unittest.TestCase, Taggable):
        def test_tag_evaluation_true_always(self):
            # Test true eval with always
            self.tags = ['always']
            self.assertTrue(self.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}))
            self.assertTrue(self.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[], all_vars={}))
            self.assertTrue(self.evaluate_tags(only_tags=['always', 'all'], skip_tags=[], all_vars={}))


# Generated at 2022-06-23 07:08:10.526924
# Unit test for constructor of class Taggable
def test_Taggable():
    # Taggable was creating class objects that allowed concurrent executions to
    # step on each others data, see issue #6514
    taggable = Taggable()

    c1 = taggable.__dict__
    c2 = Taggable().__dict__

    for key in c1:
        assert(c1[key] is c2[key]), "Class Taggable does not correctly create new instances"

# Generated at 2022-06-23 07:08:23.663381
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy:
        pass
    dummy = Dummy()
    dummy.tags = ['always']
    assert(dummy.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}))
    assert(dummy.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={'tags': ['foo','bar']}))
    assert(not dummy.evaluate_tags(only_tags=[], skip_tags=['tagged'], all_vars={}))
    assert(dummy.evaluate_tags(only_tags=[], skip_tags=['always'], all_vars={}))
    assert(dummy.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={'tags': []}))

# Generated at 2022-06-23 07:08:35.179196
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    play = Play().load({'name': 'test play', 'hosts': 'all'})

    def test_module(play, only_tags, skip_tags, tags, expected):
        play.tags = tags
        should_run = play.evaluate_tags(only_tags, skip_tags, dict())
        assert expected == should_run

    yield test_module, play, [], [], [], True  # default
    yield test_module, play, [], [], None, True  # default
    yield test_module, play, [], ['skipme'], ['skipme'], False  # skip_tags
    yield test_module, play

# Generated at 2022-06-23 07:08:38.137334
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == list


if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:08:44.748928
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole

    block = Block()
    task_ = Task()
    role = Role()
    play = Play()
    include_role = IncludeRole()

    assert type(block._load_tags(None, [1, 2, 3])) == list
    assert block._load_tags(None, [1, 2, 3]) == [1, 2, 3]
    assert task_._load_tags(None, "1, 2, 3") == ['1', '2', '3']

# Generated at 2022-06-23 07:08:56.040258
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    try:
        t._load_tags("", 1)
    except AnsibleError:
        assert True

    assert t._load_tags("", "") == []
    assert t._load_tags("", []) == []
    assert t._load_tags("", ["a,b", "c"]) == ["a,b", "c"]
    assert t._load_tags("", "a,b,c") == ["a", "b", "c"]
    assert t._load_tags("", "1,2,3") == ["1", "2", "3"]

    t.tags = "a,b,c"

    assert t.tags == ["a", "b", "c"]
    t.tags = ["a", "b", "c"]

# Generated at 2022-06-23 07:09:03.691970
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']

    tags = ['tag1', 'tag2', 'tag3']
    ti = TaskInclude(name='', play=Play().load({'name': 'foo', 'connection': 'local', 'hosts': 'localhost'}, loader=None), role='', task='', block=None)

    ti._tags = tags
    assert ti.evaluate_tags(only_tags, skip_tags, PlayContext())

    ti._tags = ['tag1', 'tag2', 'tag3', 'never']

# Generated at 2022-06-23 07:09:05.916564
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

test_Taggable()

# Generated at 2022-06-23 07:09:08.408100
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    print(taggable)

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:09:19.883914
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    only_tags_play = [ 'tag_play' ]
    skip_tags_play = [ 'tag_play' ]
    only_tags_task = [ 'tag_task' ]
    skip_tags_task = [ 'tag_task' ]
    play_context = PlayContext(only_tags = only_tags_play, skip_tags = skip_tags_play, run_once = list())
    task = Task()
    task_vars = dict()
    task._loader = "dummy"

    task.tags = [ ]
    should_run = task.evaluate_tags(only_tags_task, skip_tags_task, task_vars)
    assert should_run == False


# Generated at 2022-06-23 07:09:28.139638
# Unit test for constructor of class Taggable
def test_Taggable():
    globals()['__ansible_module__'] = type('MockModule', (object,), dict())
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    def compare(a, b):
        return set(a) == set(b)

    ti = TaskInclude('test', dict())

    ti._load_tags = Taggable._load_tags.fget
    ti.tags = dict(name='tags', no_log=True, default=['test'], type='list')

    assert compare(ti.tags, ['test'])

    ti.tags = 'foo,bar, baz'
    assert compare(ti.tags, ['foo', 'bar', 'baz'])

    ti.tags = dict(some='value')

# Generated at 2022-06-23 07:09:40.360326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyModule:
        tags = []
        def __init__(self, tags, _loader):
            self._loader = _loader
            self.tags = tags

    class DummyLoader:
        def list_templates(self):
            pass

    class DummyVariables:
        def set_available_variables(self, variables):
            pass
        def get_vars(self, load_vars=True):
            pass
        def add_host_vars(self, host, hostvars):
            pass
        def add_group_vars(self, group, groupvars):
            pass
        def add_task_and_variable_files(self, play, include_tasks=True):
            pass
        def all(self):
            pass


# Generated at 2022-06-23 07:09:43.882946
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t._load_tags('tags', ['1', '2']), list)
    assert isinstance(t._load_tags('tags', '1,2'), list)

# Generated at 2022-06-23 07:09:56.321725
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.block
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role

    def get_id(block):
        if isinstance(block, dict):
            return block.get('_unique_id')
        if isinstance(block, ansible.playbook.block.Block):
            return block._unique_id

    only_tags = {'tag1', 'tag2'}
    skip_tags = {'tag3', 'tag4'}

# Generated at 2022-06-23 07:10:05.948995
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        from ansible.playbook import Play
        import ansible.playbook.play as play
        from ansible.playbook.block import Block

    except ImportError:
        print("SKIPPED")
        return

    p = Play().load({'roles': ['foo'], 'tasks': []})
    assert not p._attributes['tags']

    b = Block().load({'block': ["foo"], "tags": ["a", "b"]}, p=p, role=play.Role())
    assert b._attributes['tags'] == ['a', 'b']

    b = Block().load({'block': ["foo"], "tags": 'a'}, p=p, role=play.Role())
    assert b._attributes['tags'] == ['a']


# Generated at 2022-06-23 07:10:18.410214
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):

        def __init__(self, tags):
            self.tags = tags

    all_vars = dict()

    class Loader:
        pass

    my_loader = Loader()

    #
    # Check for case where task gets run
    #
    only_tags = list()
    skip_tags = list()
    item = MyTaggable(tags=['test', 'test2'])
    item._loader = my_loader
    assert item.evaluate_tags(only_tags, skip_tags, all_vars) is True

    #
    # Check for case where task doesn't get run
    #
    only_tags = list()
    skip_tags = ['test2']
    item = MyTaggable(tags=['test', 'test2'])
    item._

# Generated at 2022-06-23 07:10:26.888480
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test constructor
    no_data = Taggable()
    data = Taggable(tags=['test1', 'test2'])

    # Test class variables
    assert hasattr(Taggable, '_tags')
    assert hasattr(Taggable, 'untagged')
    assert no_data._tags == []
    assert data._tags == ['test1', 'test2']

    # Test functions
    assert hasattr(Taggable, '_load_tags')
    assert hasattr(Taggable, 'evaluate_tags')
    assert no_data._load_tags('tags', ['test']) == ['test']

    # Test our puppet run options
    assert no_data.evaluate_tags(['test1'], ['test2'], None)

# Generated at 2022-06-23 07:10:37.578345
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import PlayBase
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vmanager = VariableManager(loader=loader, inventory=None)
    pb = PlayBase()

    assert Task().evaluate_tags(['always'], [], vmanager) == True
    assert Task().evaluate_tags(['always'], ['never'], vmanager) == True
    assert Task().evaluate_tags(['all'], [], vmanager) == True
    assert Task().evaluate_tags(['all'], ['tagged'], vmanager) == True
    assert Task().evaluate_tags(['tagged'], [], vmanager) == True
    assert Task().evaluate_tags

# Generated at 2022-06-23 07:10:47.772009
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    assert t.evaluate_tags(['all'], [], {})
    assert not t.evaluate_tags(['never'], [], {})
    assert t.evaluate_tags(['t1', 't2'], ['t2'], {})
    assert not t.evaluate_tags(['t1', 't2'], ['t1', 't2'], {})
    assert t.evaluate_tags(['all', 't1'], ['t2'], {})
    assert not t.evaluate_tags(['all', 't1'], ['t1'], {})
    assert t.evaluate_tags(['all', 't1'], ['all', 't1'], {})

# Generated at 2022-06-23 07:10:49.469968
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()
    tags._load_tags('tags', list)

# Generated at 2022-06-23 07:10:57.611073
# Unit test for constructor of class Taggable
def test_Taggable():
    data_structure_1 = {'tags': ['test']}
    c = Taggable(data_structure_1)
    assert c.tags == ['test'], c.tags

    data_structure_2 = {'tags': 'test'}
    c = Taggable(data_structure_2)
    assert c.tags == ['test'], c.tags

    data_structure_3 = {'tags': [1, 2, 3, 4]}
    c = Taggable(data_structure_3)
    assert c.tags == [1, 2, 3, 4], c.tags


# Generated at 2022-06-23 07:11:00.565151
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = list()
    assert tags == Taggable().tags
    assert tags == Taggable(tags=tags).tags
    assert tags == Taggable(tags="").tags

# Generated at 2022-06-23 07:11:03.794081
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []


# Generated at 2022-06-23 07:11:06.331156
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

if __name__ == '__main__':
    print("Testing Taggable class")
    test_Taggable()

# Generated at 2022-06-23 07:11:10.724961
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    if taggable.tags is None:
        raise Exception('Taggable tags is None')
    if len(taggable.tags) != 0:
        raise Exception('Taggable tags is not empty')
    return

# Generated at 2022-06-23 07:11:21.521318
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Unit test for method evaluate_tags of class Taggable'''
    import ansible.playbook.task
    t = ansible.playbook.task.Task()
    t.tags = ['all', 'never']
    assert not t.evaluate_tags({'all', 'some'}, {}, {})
    assert not t.evaluate_tags({'all'}, {}, {})
    assert not t.evaluate_tags({}, {'all'}, {})
    assert not t.evaluate_tags({'all'}, {'never'}, {})
    assert not t.evaluate_tags({'all'}, {}, {})
    assert t.evaluate_tags({'some'}, {'all'}, {})
    assert t.evaluate_tags({'some'}, {'all', 'never'}, {})
    assert not t.evaluate

# Generated at 2022-06-23 07:11:25.322732
# Unit test for constructor of class Taggable
def test_Taggable():

    class TestTaggable(Taggable):
        def __init__(self, tags):
            self._tags = tags

    test_taggable_object = TestTaggable([1, 2, 3])
    assert test_taggable_object.tags == [1, 2, 3]

# Generated at 2022-06-23 07:11:37.244432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # Test with no tags
    assert t.evaluate_tags({'all'}, set(), dict())
    assert not t.evaluate_tags({'nonexistTag'}, set(), dict())
    assert not t.evaluate_tags({'tagged'}, set(), dict())
    assert not t.evaluate_tags({'nonexistTag', 'tagged'}, set(), dict())

    t.tags = ['testTag']
    assert t.evaluate_tags({'all'}, set(), dict())
    assert t.evaluate_tags({'testTag'}, set(), dict())
    assert t.evaluate_tags({'tagged'}, set(), dict())
    assert t.evaluate_tags({'nonexistTag', 'tagged'}, set(), dict())

    # Test with skip tags

# Generated at 2022-06-23 07:11:49.120496
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    # test default
    assert t.tags == [], 'the default for tags is wrong'

    # test attribute loading
    t._load_tags('tags', ['foo', 'bar'])
    assert t.tags == ['foo', 'bar'], 'attribute loading of list failed'

    t._load_tags('tags', 'foo, bar')
    assert t.tags == ['foo', 'bar'], 'attribute loading of string failed'

    try:
        t._load_tags('tags', 5)
        assert False, 'attribute loading of scalar did not fail'
    except AnsibleError:
        assert True

    try:
        t._load_tags('tags', {'foo': 'bar'})
        assert False, 'attribute loading of dict did not fail'
    except AnsibleError:
        assert True



# Generated at 2022-06-23 07:11:59.999997
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a new Taggable object
    t = Taggable()
    t.tags = ['tag1','tag2','tag3','tag4','tag5']

    # No tags specified
    only_tags = []
    skip_tags = []
    expected_value = True
    actual_value = t.evaluate_tags(only_tags, skip_tags)
    assert actual_value == expected_value

    # Only tag 'tagged' specified
    only_tags = ['tagged']
    skip_tags = []
    expected_value = True
    actual_value = t.evaluate_tags(only_tags, skip_tags)
    assert actual_value == expected_value

    # Only tag 'tag1' specified
    only_tags = ['tag1']
    skip_tags = []
    expected_value = True
    actual_value

# Generated at 2022-06-23 07:12:11.867077
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    my_task = Task()
    
    my_task.tags = ['tag1','tag2','tag3']
    
    ##
    ## only_tags = ['tag1']
    ##
    only_tags = ['tag1']
    skip_tags = []
    assert my_task.evaluate_tags(only_tags, skip_tags, {})
    
    only_tags = ['tag2']
    skip_tags = []
    assert my_task.evaluate_tags(only_tags, skip_tags, {})
    
    only_tags = ['tag3']
    skip_tags = []
    assert my_task.evaluate_tags(only_tags, skip_tags, {})
    
    only_tags = ['tag1', 'tag2']
    skip_tags = []

# Generated at 2022-06-23 07:12:23.206064
# Unit test for constructor of class Taggable
def test_Taggable():
    """ Test Taggable class constructor """
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    pc = PlayContext(tags=['tag1', 'tag2'], only_tags=['tag1'], skip_tags=['tag1'])
    play = Play.load(dict(name='test_play', hosts=['localhost'], gather_facts='no', tasks=[]),
                     loader=None, variable_manager=None, loader_cache={})
    play.context = pc
    # Test Taggable class concstructor without tags
    t = Task()
    t._parent = Block(play=play)
    t._attribute_overrides = dict()

    assert t

# Generated at 2022-06-23 07:12:35.734178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # Check behavior of evaluate_tags for a Task with tags
    #   1) not specified in only_tags option, but specified in skip_tags.
    #   2) not specified in skip_tags option, but specified in only_tags.
    #   3) specified in both only_tags and skip_tags.
    #   4) not specified in both only_tags and skip_tags.
    task = Task()
    task.tags.append('tag1')
    assert task.evaluate_tags(set(['tag2']), None, {'tags': 'tag1'})
    assert not task.evaluate_tags(None, set(['tag1']), {'tags': 'tag1'})


# Generated at 2022-06-23 07:12:45.869781
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test object initialisation
    ta = Taggable()
    ta.tags = []

    data = {'tags': ['a', 'b', 'c', 'd']}
    data_list = [data]
    # tests
    ta.evaluate_tags(['a'], [], data_list)
    ta.evaluate_tags([], ['a'], data_list)
    ta.evaluate_tags(['a', 'b'], ['a'], data_list)
    ta.evaluate_tags(['a', 'b'], ['c', 'd'], data_list)
    ta.evaluate_tags(['a', 'b'], ['f'], data_list)

    assert ta._load_tags('tags', ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 07:12:51.527308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    # Test always
    t2 = Task()
    t2.tags = ['always']
    assert t2.evaluate_tags([], [], {}) == True
    assert t2.evaluate_tags(['always'], [], {}) == True
    assert t2.evaluate_tags([], ['always'], {}) == False
    assert t2.evaluate_tags(['always'], ['always'], {}) == False
    # Test never
    t3 = Task()
    t3.tags = ['never']
    assert t3.evaluate_tags([], [], {}) == False
    assert t3.evaluate_tags(['never'], [], {}) == False
    assert t3.evaluate_tags([], ['never'], {}) == True
    assert t

# Generated at 2022-06-23 07:12:53.009967
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Test Taggable class constructor
    """
    Taggable()

# Generated at 2022-06-23 07:12:59.724184
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    class DummyTaggable(Taggable):
        def __init__(self, loader, play_context, variable_manager, host):
            self._loader = loader
            self._play_context = play_context
            self._variable_manager = variable_manager
            self._host = host

    # Now run a number of tests
    loader, inventory, variable_manager = Playbook.loader()
    play_context = PlayContext()
    host = inventory.get_host('localhost')

    # 1. Tags are given but no only_tags and skip_tags are given
    test_task = DummyTaggable(loader, play_context, variable_manager, host)
    test_task.tags = ['test_tag']

# Generated at 2022-06-23 07:13:01.500463
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:13:10.774544
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.group import Group

    tag_obj = Taggable()
    tag_obj._loader = False
    tag_obj._play = False
    tag_obj._play_context = False

    tag_obj.tags = ['test1','test2','test3']

    all_vars = dict()

    # if tags and only_tags are defined then tags should run
    only_tags = ['test1', 'test2', 'test4']
    skip_tags = []
    test_result = tag_obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert test_result == True

    # if tags and only_tags are defined and tag should not run based on skip_tags
    only_tags = []
    skip_tags = ['test2']

# Generated at 2022-06-23 07:13:21.582362
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import types
    from ansible.module_utils.six import PY3

    tags = ["t1", "t2", "t3"]
    only_tags = ["t1", "t2"]
    skip_tags = ["t3"]

    # Create an object of class Taggable
    t = Taggable()

    # Set the tags on the object
    t.tags = tags

    # Check if the object got a list of tags
    assert( t.tags == tags), "The object did not get the tags properly"

    # Check if the object got the right type for tags
    assert( type(t.tags) == list ), "The object did not get the right type of tags"

    # Evaluate the tags, make sure that the method returns True

# Generated at 2022-06-23 07:13:28.921719
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    fake_variable_manager = object()
    fake_loader = object()
    class Fake_Obj(Taggable):
        def __init__(self, tags=None, all_vars=None):
            self._variable_manager = fake_variable_manager
            self._loader = fake_loader
            Taggable.__init__(self, tags=tags, all_vars=all_vars)

    # Test if tags is empty
    fake_obj = Fake_Obj(tags=None)
    assert fake_obj.evaluate_tags([], [], 'fake_all_vars')

    # Test if neither only_tags nor skip_tags is specified
    fake_obj = Fake_Obj(tags=['fake_tag'])
    assert fake_obj.evaluate_tags([], [], 'fake_all_vars')

    # Test

# Generated at 2022-06-23 07:13:30.870298
# Unit test for constructor of class Taggable
def test_Taggable():
    test_Taggable = Taggable()
    assert isinstance(test_Taggable, Taggable)


# Generated at 2022-06-23 07:13:33.138389
# Unit test for constructor of class Taggable
def test_Taggable():

    x = Taggable()
    assert x.tags == []

# Generated at 2022-06-23 07:13:42.048061
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    class MyTaggable(Taggable, Base):
        pass

    mt = MyTaggable()

    assert type(mt.tags) == list
    assert mt.tags == []
    assert type(mt.untagged) == frozenset
    assert type(mt.untagged) != set
    assert len(mt.untagged) == 1
    assert type(mt.untagged.pop()) == str
    assert mt.untagged.pop() == 'untagged'
    assert mt._tags == list


if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:13:49.880347
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    # default
    assert taggable.tags == []

    # test that passing list of tags works
    taggable = Taggable(tags=['test1', 'test2'])
    assert taggable.tags == ['test1', 'test2']

    # test that passing a comma delimted string convert to list
    taggable = Taggable(tags="test1, test2")
    assert taggable.tags == ['test1', 'test2']

# Generated at 2022-06-23 07:13:59.088758
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class TestTaggable_evaluate_tags(unittest.TestCase):

        def test_empty_tags(self):
            # Initialize Taggable class
            x = Taggable()
            # Test if evaluate_tags returns True for empty tags
            self.assertEquals(x.evaluate_tags(None, None, None), True)

        def test_match_only_tags(self):
            # Initialize Taggable class
            x = Taggable()
            # Initialize tags variable
            x.tags = ['tag1', 'tag2']
            # Test if evaluate_tags returns True if tag1 or tag2 is in only_tags
            self.assertEquals(x.evaluate_tags(['tag1', 'tag2'], None, None), True)
            # Test if evaluate_tags returns True if

# Generated at 2022-06-23 07:14:10.856927
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class test_taggable(Taggable, AnsibleBaseYAMLObject):
        def __init__(self):
            pass

    taggable = test_taggable()
    taggable._tags = [1, '2']
    result = taggable._load_tags(None, ['2', 3])
    assert len(result) == 3
    assert result[0] == '2'
    assert result[1] == '3'
    assert result[2] == 1

    taggable = test_taggable()
    taggable._tags = [1, '2']
    result = taggable._load_tags(None, '2, 3')
    assert len(result) == 3

# Generated at 2022-06-23 07:14:20.944003
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class obj:
        _loader = None

    o = obj()
    o.tags = ['tag1']
    only_tags = set(['tag1', 'tag2'])

    assert o.evaluate_tags(only_tags=only_tags, skip_tags=set(), all_vars={})
    assert not o.evaluate_tags(only_tags=only_tags, skip_tags=set(['tag1']), all_vars={})

    o.tags = ['always']
    assert o.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={})
    assert o.evaluate_tags(only_tags=set(['all']), skip_tags=set(), all_vars={})

# Generated at 2022-06-23 07:14:31.500595
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Temp(Taggable):
        pass
    temp = Temp()
    temp._loader = None
    temp.tags = ['tag1', 'tag2']
    all_vars = {}
    only_tags = ['tag3', 'tag4']
    skip_tags = ['tag5']
    
    # Should succeed
    temp.evaluate_tags(only_tags, skip_tags, all_vars)
    temp_tags = {'tag1', 'tag2'}
    assert temp.tags == temp_tags
    
    # Should fail
    temp.tags = 'tag1, tag2'
    temp.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-23 07:14:42.396231
# Unit test for constructor of class Taggable
def test_Taggable():
    print ("\n***** BEGIN test_Taggable() *****")

    t1 = Taggable()
    assert t1.tags == []
    assert t1.evaluate_tags(None, None, {}) == True
    assert t1.evaluate_tags(set(['fizz']), None, {}) == False
    assert t1.evaluate_tags(None, set(['fizz']), {}) == True
    assert t1.evaluate_tags(set(['fizz']), set(['buzz']), {}) == False
    assert t1.evaluate_tags(set(['fizz']), set(['all']), {}) == False
    assert t1.evaluate_tags(set(['all']), set(['fizz']), {}) == True

# Generated at 2022-06-23 07:14:44.889783
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == list()
    assert t.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

# Generated at 2022-06-23 07:14:56.577602
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    import os
    import pytest
    import tempfile

    temp_dir = tempfile.gettempdir()
    fake_inventory_file = os.path.join(temp_dir, 'fake_inventory')

    # Create fake inventory file
    with open(fake_inventory_file, 'w', encoding='utf-8') as f:
        f.write("""
localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python2.7
""")


# Generated at 2022-06-23 07:15:00.661615
# Unit test for constructor of class Taggable
def test_Taggable():
    tg = Taggable()
    assert(tg.tags == [])
    tg.tags.append('test')
    assert(tg.tags == ['test'])

# Generated at 2022-06-23 07:15:12.266280
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TagItem(Taggable):
        pass

    # the only_tags argument is the only one which is optional
    # this way we can test the other one in isolation

# Generated at 2022-06-23 07:15:22.090148
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test evaluate_tags with skip_tags = False
    only_tags = set(['test_tag'])
    skip_tags = False
    fake_all_vars_1 = dict()
    fake_all_vars_2 = dict()
    fake_all_vars_3 = dict()
    fake_tags_1 = list(['test_tag'])
    fake_tags_2 = list(['test_tag1', 'test_tag2', 'test_tag3'])
    fake_tags_3 = list(['test_tag1', 'test_tag3'])
    fake_taggable_1 = Taggable()
    fake_taggable_2 = Taggable()
    fake_taggable_3 = Taggable()
    fake_taggable_1._loader = None
    fake_

# Generated at 2022-06-23 07:15:29.546110
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    class TestEvaluateTags(unittest.TestCase):
        def setUp(self):
            self.simple = dict(
                tags=['test_tag'],
            )
            self.dictionary = dict(
                tags={"foo": ["foo1", "foo2"]},
            )
            self.nested = dict(
                tags=[{"foo": ["foo1", "foo2"]}],
            )
            self.string = dict(
                tags="foo1, foo2",
            )
            self.escape = dict(
                tags=["foo,bar"],
            )
            self.template = dict(
                tags=["foo_{{name}}"],
                vars=dict(
                    name="foo",
                ),
            )

# Generated at 2022-06-23 07:15:35.115226
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    for t in taggable.tags:
        if t == 'taggable_test' or t == 'test_taggable':
            print("test_Taggable(): Failed, taggable.tags is not empty")
            return False
    return True


# Generated at 2022-06-23 07:15:43.864640
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host = Host(name="foo")
    group = Group(name="bar")
    group.add_host(host)
    task = Task()
    task.name = 'baz'
    task._hosts = [host]
    task._parents_groups = [group]
    task.name = 'baz'
    task.tags = []
    assert task.evaluate_tags(['all'],[],{}) == True
    task.tags = ['foo', 'bar']
    assert task.evaluate_tags(['all'],[],{}) == True

# Generated at 2022-06-23 07:15:49.717624
# Unit test for constructor of class Taggable
def test_Taggable():
    #Specify tag to constructor
    tags = ['tag1', 'tag2', 'tag3']
    t = Taggable(tags)
    assert t.tags == ['tag1', 'tag2', 'tag3']
    #Constructor with no tags specified
    t = Taggable()
    assert t.tags is None
    #Specify invalid tag
    try:
        Taggable(1)
        assert False
    except AnsibleError:
        pass
    #Specify invalid tag
    try:
        Taggable(['tag', 1])
        assert False
    except AnsibleError:
        pass

