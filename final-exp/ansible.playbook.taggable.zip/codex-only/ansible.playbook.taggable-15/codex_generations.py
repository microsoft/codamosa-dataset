

# Generated at 2022-06-23 07:05:53.594131
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.playbook
    import ansible.utils
    from ansible.vars.manager import VariableManager
    from ansible.utils import template

    class DummyPlaybook(object):
        variable_manager = VariableManager()

    class DummyTask(Taggable):
        def __init__(self, data, vars={}):
            self._task = data
            self._variable_manager = VariableManager()
            self._variable_manager.set_nonpersistent_facts(vars)
            self.tags = data.get("tags")

    class DummyBlock(Taggable):
        def __init__(self, data, vars={}):
            self._block = data
            self._variable_manager = VariableManager()
            self._variable_manager.set_nonpersistent_facts(vars)

# Generated at 2022-06-23 07:06:00.855099
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # tags is empty by default
    assert taggable.tags == []

    # tags is empty by default, should run
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # now set a tag
    taggable.tags = [ 'test_tag' ]
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert taggable.evaluate_tags(only_tags=[ tags ], skip_tags=[], all_vars={}) == True

    # skip if the tag matches
    assert taggable.evaluate_tags(only_tags=[], skip_tags=['test_tag'], all_vars={}) == False
    assert taggable.evaluate_

# Generated at 2022-06-23 07:06:09.630251
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize a Taggable object
    obj = Taggable()

    # Test case -1: only_tags is not None and skip_tags is None
    assert obj.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={}) is True
    assert obj.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={'ansible_check_mode': True}) is True
    assert obj.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={'ansible_check_mode': False}) is True
    assert obj.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={'ansible_check_mode': 'false'}) is True

# Generated at 2022-06-23 07:06:17.256154
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    obj = Taggable()
    assert obj.tags == []
    obj = Taggable()
    assert obj.tags == []
    obj = Taggable()
    assert obj.tags == []
    obj = Taggable(tags="['a']")
    assert obj.tags == ['a']
    obj = Taggable(tags="['a', 'b', 'c']")
    assert obj.tags == ['a', 'b', 'c']
    obj = Taggable(tags="['a, b']")
    assert obj.tags == ['a, b']
    obj = Taggable(tags="['a', 'b, c']")
   

# Generated at 2022-06-23 07:06:17.889771
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-23 07:06:19.992167
# Unit test for constructor of class Taggable
def test_Taggable():
    class A(Taggable):
        def __init__(self,*args, **kwargs):
            super(A, self).__init__(*args, **kwargs)
    A()

# Generated at 2022-06-23 07:06:29.958334
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class test_class(Taggable):
        pass
    test_instance = test_class()
    tag_options_dict = {
            'only_tags': ['test1'],
            'skip_tags': ['test2']
            }
    all_vars = {
            'test1_var': ['test1','test5'],
            'test2_var': ['test2','test3','test4'],
            'test3_var': ['test2','test3','test4'],
            'test4_var': ['test1','test5']
            }

    # Test successfull run of the command
    test_instance.tags = ['test1']
    assert test_instance.evaluate_tags(**tag_options_dict) == True

    # Test failure of the command

# Generated at 2022-06-23 07:06:38.731741
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    from ansible.playbook.base import Base
    from units.mock.loader import DictDataLoader

    # Prepare the test data
    myvars = dict(tags=['tag1', 'tag2'])
    all_vars = dict(hostvars={'127.0.0.1': myvars})
    b_only_tags = []
    b_skip_tags = []
    c_only_tags = [ 'tag1' ]
    c_skip_tags = [ 'tag3', 'tag4' ]
    d_only_tags = [ 'tag3', 'tag4' ]
    d_skip_tags = []
    e_only_tags = [ 'tag1', 'tag2', 'tag3' ]
    e_skip_tags = [ 'tag4' ]
    f_only

# Generated at 2022-06-23 07:06:47.749004
# Unit test for constructor of class Taggable
def test_Taggable():
    # Check for tags with array input
    class TestClass(object):
        tags = ['t1','t2','t3']
    task = Taggable(base_class = TestClass)
    assert(len(task.tags) == 3)
    assert('t3' in task.tags)

    # Check for tags with comma separated string input
    class TestClass(object):
        tags = 't1,t2,t3'
    task = Taggable(base_class = TestClass)
    assert(len(task.tags) == 3)
    assert('t3' in task.tags)
    print("Taggable test passed")
test_Taggable()

# Generated at 2022-06-23 07:06:49.543458
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []
    assert taggable.tags == []

# Generated at 2022-06-23 07:07:00.380810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # pylint: disable=no-self-use,too-many-locals,too-many-branches,too-many-statements,unused-argument
    ''' test evaluate_tags method of Taggable '''

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # TODO: Why do we need to pass a variable to this?
    # pylint: disable=no-value-for-parameter
    all_vars = {}

    # Test evaluate_tags with empty only_tags and skip_tags
    # pylint: disable=unused-variable
    untagged_task = Task()
    tagged_task = Task(tags=['tag1'])
   

# Generated at 2022-06-23 07:07:04.077366
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO: implement unit test
    raise NotImplementedError

if __name__ == '__main__':
    # TODO: implement unit test
    raise NotImplementedError

# Generated at 2022-06-23 07:07:16.179449
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    assert t.tags == []

    class Fake:
        def __init__(self):
            self.tags = ['tag1']
            self.tasks = []

        def task(self, *args, **kwargs):
            self.tasks.append(kwargs.get('tags'))

    fake = Fake()
    fake.task(tags='tag2')

    # test specific tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True
    assert fake.tasks == []
    fake.task(tags='tag2, tag1')
    assert fake.tasks == [ ['tag2', 'tag1'] ]

    # test tagged
    only_tags = ['tagged']

# Generated at 2022-06-23 07:07:21.831486
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task1 = dict(tags=['tag1','tag2'])
    task2 = dict(tags=['tag3','tag4'])

    testcase = dict()

    testcase['1: only_tags=tag1; skip_tags=; what=run'] = dict(task=task1, only_tags=['tag1'], skip_tags=[], what=True)
    testcase['2: only_tags=tag1; skip_tags=; what=run'] = dict(task=task2, only_tags=['tag1'], skip_tags=[], what=False)
    testcase['3: only_tags=tag1,tag2; skip_tags=; what=run'] = dict(task=task1, only_tags=['tag1','tag2'], skip_tags=[], what=True)

# Generated at 2022-06-23 07:07:32.947289
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os._getframe().f_code.co_name))
    from test_data import *

    tag_list = ['test']

    # Run should return True if no tags or tags and tags are empty
    assert(Taggable().evaluate_tags([], [], {}))

    # Run should return True if only_tags is empty and tags is not
    assert(Taggable(tags=tag_list).evaluate_tags([], [], {}))

    # Run should return True if only_tags is not empty and tags is not empty and the two are not disjoint
    assert(Taggable(tags=tag_list).evaluate_tags(tag_list, [], {}))

    # Run

# Generated at 2022-06-23 07:07:46.441785
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    c = Taggable()
    c.tags = ['a', 'b', 'c']
    only_tags = []
    skip_tags = []
    all_vars = None
    
    tag_res = c.evaluate_tags(only_tags, skip_tags, all_vars)
    # Default: tasks to run
    assert(tag_res == True)
    
    # Always run
    only_tags = ['always']
    tag_res = c.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(tag_res == True)
    
    # Run if item is tagged
    only_tags = ['tagged']
    tag_res = c.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(tag_res == True)
    
   

# Generated at 2022-06-23 07:07:47.140716
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:07:59.949100
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils import context_objects as co

    class MockCommandLine:
        pass

    co.GlobalCLIArgs = MockCommandLine()
    co.GlobalCLIArgs.tags = 'foo'
    co.GlobalCLIArgs.skip_tags = 'bar'
    task = Task()
    task.tags = ['foo', 'bar', 'baz']
    assert task.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={})
    assert not task.evaluate_tags(only_tags=['foo'], skip_tags=['baz'], all_vars={})

# Generated at 2022-06-23 07:08:11.685434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash
    from ansible.inventory import Inventory
    import pytest

    loader = DataLoader()
    data = dict(
        hosts='localhost',
        gather_facts='no',
        connection='local',
    )
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])

# Generated at 2022-06-23 07:08:15.337378
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ["a", "b", "c"]


# Generated at 2022-06-23 07:08:18.382035
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable(dict(tags=['first_tag', 'second_tag']))
    assert taggable.tags == ['first_tag', 'second_tag']

# Generated at 2022-06-23 07:08:29.141630
# Unit test for constructor of class Taggable
def test_Taggable():

    def load_tags(self, attr, ds):
        if isinstance(ds, list):
            return ds
        elif isinstance(ds, string_types):
            value = ds.split(',')
            if isinstance(value, list):
                return [x.strip() for x in value]
            else:
                return [ds]
        else:
            raise AnsibleError('tags must be specified as a list', obj=ds)

    taggable = Taggable()
    taggable.__class__._load_tags = load_tags


    # test taggable._load_tags with ","
    tags = taggable._load_tags(taggable.tags, "name,location")
    assert tags == ["name", "location"]


# Generated at 2022-06-23 07:08:39.521715
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    test_task = Task()
    # This task is never run because there are no tags and the tag 'never' is in the skip tags.
    assert( test_task.evaluate_tags(only_tags=[], skip_tags=['never']) == False )
    # This task is never run because the tag 'never' is in the skip tags.
    test_task.tags = ['never']
    assert( test_task.evaluate_tags(only_tags=[], skip_tags=['never']) == False )
    # This task is always run because there are no tags and the tag 'always' is in the only tags.
    test_task.tags = ['never']
    assert( test_task.evaluate_tags(only_tags=['always'], skip_tags=[]) == True )
    # This

# Generated at 2022-06-23 07:08:50.812604
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # import the class
    from ansible.playbook.task import Task
    # create a task and set the tags attribute to a list
    task = Task()
    task.tags = ['always', 'foo']

    # create another task and set the tags attribute to a string
    task2 = Task()
    task2.tags = 'always, foo'

    # tests
    assert task.evaluate_tags([], [], {})
    assert task.evaluate_tags(['foo'], [], {})
    assert task.evaluate_tags([], ['foo'], {})
    assert task.evaluate_tags(['foo'], ['foo'], {})
    assert task.evaluate_tags(['all'], [], {})
    assert not task.evaluate_tags([], ['all'], {})

# Generated at 2022-06-23 07:08:53.220298
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:08:55.350342
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()

    assert isinstance(obj.tags, list)


# Generated at 2022-06-23 07:09:04.334499
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class PlayBook(Taggable):
        def __init__(self):
            self._tags = ["environment:production"]
            self.tags = self._tags

    play = PlayBook()

    if not play.evaluate_tags(["production"], [], None):
        return False

    if play.evaluate_tags(["staging"], [], None):
        return False

    if play.evaluate_tags(["production","staging"], [], None):
        return False

    if play.evaluate_tags([], ["production"], None):
        return False

    if not play.evaluate_tags([], ["staging"], None):
        return False

    if not play.evaluate_tags([], ["production","staging"], None):
        return False

    if not play.evaluate_tags([], ["tagged"], None):
        return False


# Generated at 2022-06-23 07:09:15.725650
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
   task = Taggable()

   only_tags = ['step1', 'step2', 'step3', 'step4']
   skip_tags = ['step3', 'step4']
   all_vars = {}

   task.tags = ['step1']
   assert True == task.evaluate_tags(only_tags, skip_tags, all_vars)

   task.tags = ['step2']
   assert True == task.evaluate_tags(only_tags, skip_tags, all_vars)

   task.tags = ['step3']
   assert False == task.evaluate_tags(only_tags, skip_tags, all_vars)

   task.tags = ['step4']
   assert False == task.evaluate_tags(only_tags, skip_tags, all_vars)

   task.tags = ['step5']
  

# Generated at 2022-06-23 07:09:17.240620
# Unit test for constructor of class Taggable
def test_Taggable():
    # Class Taggable has no constructor, so no test.
    pass

# Generated at 2022-06-23 07:09:19.526215
# Unit test for constructor of class Taggable
def test_Taggable():
    tag_object = Taggable()
    assert tag_object._tags == []
    assert tag_object.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:09:27.855637
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # A bare-bones Taggable class to unit test the evaluate_tags method
    class TaggableTest(object):
        def __init__(self):
            self._loader = None
            self.tags = None

    t = TaggableTest()

    only_tags = frozenset(['one', 'two'])
    skip_tags = frozenset(['three', 'four'])

    # Test no tags set
    t.tags = None
    assert t.evaluate_tags(only_tags, skip_tags, {})

    # Test no tags set with task including always (not skipped because of always)
    t.tags = None
    assert t.evaluate_tags(skip_tags, only_tags, {})

    # Test no tags set with task including always and always in skip_tags (skipped because of always)

# Generated at 2022-06-23 07:09:40.092624
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    play_context._become = False
    play_context._become_method = 'sudo'
    play_context._become_user = None
    play_context._diff = False
    play_context._tags = []
    play_context._force_handlers = False
    play_context._only_tags = []
    play_context._skip_tags = []
    play_context._verbosity = 0

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 07:09:50.270400
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    debug = {
        'msg': 'Debug task',
        'debug': {
            'msg': 'output'
        }
    }

    host = {
        'hostname': 'test',
        'vars': {
            'test_var': 'var'
        }
    }

    only_tags = ['test', 'all']
    skip_tags = ['test']

    # default behaviour - always tag is present
    result = Taggable().evaluate_tags(only_tags, skip_tags, host)
    assert result == True

    # tag is present
    debug['tags'] = ['test']
    result = Taggable().evaluate_tags(only_tags, skip_tags, host)
    assert result == True

    # tag is not present
    debug['tags'] = ['another']
    result = Taggable().evaluate

# Generated at 2022-06-23 07:09:52.838018
# Unit test for constructor of class Taggable
def test_Taggable():
    test_tag = Taggable()
    assert test_tag._load_tags('tags', ['tags']) == ['tags']
    assert test_tag._load_tags('tags', 'tags') == ['tags']

# Generated at 2022-06-23 07:09:55.632816
# Unit test for constructor of class Taggable
def test_Taggable():

    class MyTaggable(Taggable):
        pass

    tag = MyTaggable()
    assert tag.tags == []

# Generated at 2022-06-23 07:10:05.448173
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys

    # change path so we find modules and plugins
    if __file__ != '__main__':  # only necessary when test is run stand-alone
        testpath = os.path.dirname(os.path.realpath(__file__))  # run from same path as file
        sys.path.insert(0, os.path.join(testpath, '..'))  # load module from parent directory
        sys.path.insert(0, os.path.join(testpath, '..', '..'))  # load ansible module for testing
        sys.path.insert(0, os.path.join(testpath, '..', '..', '..'))  # load ansible module for testing

    # pylint: disable=import-error
    from ansible.errors import AnsibleError

# Generated at 2022-06-23 07:10:13.649289
# Unit test for constructor of class Taggable
def test_Taggable():
    test_object = Taggable()

    # This will test if the _tags property of class Taggable has been initialized by
    # the constructor
    assert hasattr(test_object, '_tags')

    # This will test if the tags property of class Taggable has been initialized by
    # the constructor
    assert hasattr(test_object, 'tags')

# Generated at 2022-06-23 07:10:24.735747
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable._loader = None
    taggable.tags = ['test_tag']
    assert taggable.evaluate_tags(['test_tag'], '', dict()) == True, \
        "Only check for tag 'test_tag' should match"
    assert taggable.evaluate_tags(['test_tag2'], '', dict()) == False, \
        "Only check for tag 'test_tag2' should fail"
    assert taggable.evaluate_tags(['test_tag', 'test_tag2'], '', dict()) == True, \
        "Only check for tag 'test_tag' and 'test_tag2' should match"

# Generated at 2022-06-23 07:10:32.144542
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    assert x.tags == []
    # Test the _load_tags function
    assert x._load_tags('tags', ['Hello','World']) == ['Hello','World']
    assert x._load_tags('tags', 'Hello, World') == ['Hello', 'World']
    assert x._load_tags('tags', 'Hello') == ['Hello']

# to keep compatibility
TaggableMixin = Taggable

# Generated at 2022-06-23 07:10:37.815800
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    mytask = Task()
    assert mytask.tags == None
    mytask.tags = 'first, second'
    assert mytask.tags == ['first', 'second']
    mytask.tags = 'first'
    assert mytask.tags == ['first']

# Generated at 2022-06-23 07:10:47.927288
# Unit test for constructor of class Taggable
def test_Taggable():
	
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.include import Include
    from ansible.playbook.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.template import Templar

    loader = None
    variable_manager = None

    p = Play()

# Generated at 2022-06-23 07:10:53.799012
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    x = Taggable.load(dict(
        _name = "foo",
        _parent = None,
        tags = [ 'a', 'b', 'c' ]
    ))
    assert isinstance(x, Base)
    assert isinstance(x, Taggable)
    assert isinstance(x.tags, list)
    assert len(x.tags) == 3
    assert 'a' in x.tags
    assert 'b' in x.tags
    assert 'c' in x.tags
    x = Taggable.load(dict(
        _name = "foo",
        _parent = None,
        tags = 'a,b,c'
    ))
    assert isinstance(x, Base)
    assert isinstance(x, Taggable)
    assert isinstance

# Generated at 2022-06-23 07:10:55.983031
# Unit test for constructor of class Taggable
def test_Taggable():
    # Constructor of class Taggable
    assert Taggable._tags._get_default() ==  []


# Generated at 2022-06-23 07:11:04.713154
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.become import Become
    from ansible.playbook.task import Task
    from ansible.playbook.become import Become

    class TaskSubclass(Taggable, Task):
        _task_type = "TaskSubclass"

    mytask = TaskSubclass()

    class BecomeSubclass(Taggable, Become):
        pass

    become = BecomeSubclass()

    # no tags set
    assert mytask.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert mytask.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert mytask.evaluate_tags(only_tags=['tagged'], skip_tags=['never'], all_vars={})

# Generated at 2022-06-23 07:11:15.098398
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    
    # Create a new Taggable instance
    test_taggable = Taggable()
    
    # Assume the parent of class Taggable is a Task instance
    assert isinstance(test_taggable, Task)
    
    # Assume the default value of _tags field, which is an attribute of class Taggable, is an empty list
    assert test_taggable._tags == []

    # Assume the actual value of _tags field, which is an attribute of class Taggable, can be modified
    # as a list
    test_taggable._tags = ["test"]
    assert isinstance(test_taggable._tags, list)
    
    # Assume the default value of only_tags and skip_tags fields which are parameters for evaluate_tags method
    #

# Generated at 2022-06-23 07:11:16.910044
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert t._tags == [] -- t.tags

# Generated at 2022-06-23 07:11:28.535767
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    class FakeTaggable(Taggable):
        def __init__(self):
            self.tags = []

    task = FakeTaggable()
    play_context = PlayContext()
    play_context.only_tags = set(['all'])
    task.evaluate_tags(play_context.only_tags, set([]), dict())
    assert task.tags == ['all'], task.tags

    task.tags = []
    play_context.only_tags = set(['all'])
    play_context.skip_tags = set(['all'])
    task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict())
    assert task.tags == [], task.tags

    task.tags = []
    play

# Generated at 2022-06-23 07:11:30.097126
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []


# Generated at 2022-06-23 07:11:31.861137
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    print(t._tags)

# Generated at 2022-06-23 07:11:36.006424
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    class MyClass(Base, Taggable):
        pass

    x = MyClass()
    assert hasattr(x._ds, 'tags')

    y = MyClass()
    assert hasattr(y._ds, 'tags')

# Generated at 2022-06-23 07:11:48.610778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeDS(object):
        def __init__(self, value):
            self.value = value

    class FakeVar(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    class FakeVars(dict):
        def __getitem__(self, key):
            if key == 'tag_name':
                return FakeVar('tag_name', 'tag_value')
            elif key == 'templated_tag_name':
                return FakeVar('templated_tag_name', 'tag_value')
            else:
                return None

    class FakePlay(object):
        def __init__(self):
            self.tags = ['foo', 'bar', 'baz']


# Generated at 2022-06-23 07:11:50.095024
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []


# Generated at 2022-06-23 07:12:00.954331
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    tasks = [
        Task(name='Task1', tags=['tag1', 'tag2']),
        Task(name='Task2', tags=['tag1', 'tag2', 'tag3']),
    ]

    blocks = [
        Block(name='Block1', tags=['tag1', 'tag2'], tasks=tasks),
        Block(name='Block2', tags=['tag1', 'tag2', 'tag3'], tasks=tasks),
    ]

    roles = [
        Role(name='Role1', blocks=blocks, tasks=tasks),
        Role(name='Role2', blocks=blocks, tasks=tasks),
    ]


# Generated at 2022-06-23 07:12:06.241585
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TempTaggable(Taggable):
        pass
    class TempTask(TempTaggable):
        def __init__(self, tags):
            self.tags = tags
    obj = TempTask(['tag1', 'tag2'])
    assert obj.evaluate_tags(None, None, {})
    assert not obj.evaluate_tags(['tag3'], None, {})
    assert not obj.evaluate_tags(['tag1', 'tag3'], None, {})
    assert not obj.evaluate_tags(['tag3', 'tag2', 'tag1'], None, {})
    assert obj.evaluate_tags(['tag1'], None, {})
    assert not obj.evaluate_tags(['tag3'], ['tag1', 'tag2'], {})

# Generated at 2022-06-23 07:12:16.085820
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    r = Role()
    r.tags = ['test1','test2']
    assert r.tags == ['test1','test2']
    r.tags = 'test1,test2,test3'
    assert r.tags == ['test1','test2','test3']
    try:
        r.tags = 123
        assert False
    except:
        pass
    assert len(r._tags.attributes) == 2
    assert r._tags.attributes[0] == ['test1','test2']
    assert r._tags.attributes[1] == ['test1','test2','test3']
    r.tags = ['test1','test2']
    assert r.tags == ['test1','test2']
    assert r.evalua

# Generated at 2022-06-23 07:12:26.698437
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:12:38.395553
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.constants as C

    # C.TAG_SKIP_TAGS may not be initialized yet (e.g. when using
    # `ansible-playbook --help`)
    if C.TAG_SKIP_TAGS is None:
        C.TAG_SKIP_TAGS = set()

    class FakeTask(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    tasks = [
        FakeTask(tags=['always']),
        FakeTask(tags=['t1', 't2']),
        FakeTask(tags=['t2', 't3']),
        FakeTask(tags=['never']),
        FakeTask(tags=['t3', 't4', 't5']),
    ]


# Generated at 2022-06-23 07:12:47.443253
# Unit test for constructor of class Taggable
def test_Taggable():

    class TaggableTest(Taggable):
        pass

    test = TaggableTest()

    # test if attribute tags exists and has value []
    assert hasattr(test, 'tags')
    assert getattr(test, 'tags') == []

    t1 = TaggableTest(tags='one')
    t2 = TaggableTest(tags=['two'])
    t3 = TaggableTest(tags=['three', 'four'])
    t4 = TaggableTest(tags=23)
    t5 = TaggableTest(tags=['only', 'tags'])

    # test if type of attribute tags is list
    assert isinstance(getattr(t1, 'tags'), list)
    assert isinstance(getattr(t2, 'tags'), list)

# Generated at 2022-06-23 07:12:52.789586
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTask(Taggable):
        def __init__(self, tags):
            self._tags = tags

    assert MockTask([]).evaluate_tags(only_tags = set(), skip_tags = set(), all_vars = dict()) == True

    assert MockTask(['test']).evaluate_tags(only_tags = set(['test']), skip_tags = set(), all_vars = dict()) == True
    assert MockTask(['test']).evaluate_tags(only_tags = set(['test', 'test2']), skip_tags = set(), all_vars = dict()) == True
    assert MockTask(['test', 'test2']).evaluate_tags(only_tags = set(['test', 'test2']), skip_tags = set(), all_vars = dict()) == True

# Generated at 2022-06-23 07:12:59.667615
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyClass(Taggable):
        pass

    my_tags = MyClass()

    # test1 with tags = ['update', 'upgrade'] and only_tags = ['update']
    my_tags.tags = ['update', 'upgrade']
    only_tags = ['update']
    assert my_tags.evaluate_tags(only_tags, None, None) # should return true
    # test2 with tags = ['update', 'upgrade'] and only_tags = ['update', 'never']
    my_tags.tags = ['update', 'upgrade']
    only_tags = ['update', 'never']
    assert not my_tags.evaluate_tags(only_tags, None, None) # should return false
    # test3 with tags = ['update', 'upgrade'] and only_tags = ['update', 'upgrade', 'never']


# Generated at 2022-06-23 07:13:09.728292
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    variables = dict()
    only_tags = ['tag_a', 'tag_b']
    skip_tags = ['tag_c', 'tag_d']

    # Object of subclass Taggable
    tags_obj_1 = ModuleArgs()
    tags_obj_1.tags = ['tag_a', 'tag_b']
    assert tags_obj_1.evaluate_tags(only_tags, skip_tags, variables) == True
    tags_obj_2 = ModuleArgs()
    tags_obj_2.tags = ['tag_a', 'tag_b', 'tag_c']
    assert tags_obj_2.evaluate_tags(only_tags, skip_tags, variables) == True
    tags_obj_3 = ModuleArgs()
    tags_obj_3.tags = ['tag_a', 'tag_b', 'tag_d']

# Generated at 2022-06-23 07:13:21.440893
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        __slots__ = ('tags',)

        def __init__(self):
            self.tags = []

    test = TestClass()

    # test has a list, so we should get back a list
    result = test._load_tags(attr='tags', ds=[1])
    assert(result == [1])

    # test has a string, so we should get back a list, with 1 element
    result = test._load_tags(attr='tags', ds="1")
    assert(result == ['1'])

    # test is None, so we should get back a list
    result = test._load_tags(attr='tags', ds=None)
    assert(result == [])

    # test has a dict, so we should get a JSON string
    result = test._load_tags

# Generated at 2022-06-23 07:13:26.925435
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    a = Taggable()
    assert a.tags == []

    # Test format of tag names
    task = Task()
    task.tags = 'tag1, tag2'
    assert task.tags == ['tag1', 'tag2']

    task = Task()
    task.tags = [1,2]
    assert task.tags == [1,2]

    task = Task()
    task.tags = ['tag3', ['tag4', 'tag5']]
    assert task.tags == ['tag3', 'tag4', 'tag5']

# Generated at 2022-06-23 07:13:37.405744
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None
    t = Test(["foo", "bar"])
    assert t.evaluate_tags(None, None, {}) == True
    assert t.evaluate_tags(set(["all"]), None, {}) == True
    assert t.evaluate_tags(set(["all", "bar"]), None, {}) == True
    assert t.evaluate_tags(set(["foo"]), None, {}) == True
    assert t.evaluate_tags(set(["baz"]), None, {}) == False
    assert t.evaluate_tags(None, set(["all"]), {}) == False
    assert t.evaluate_tags(None, set(["all", "foo"]), {}) == False

# Generated at 2022-06-23 07:13:46.830927
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        _loader = None
        tags=None

        def __init__(self, tags=None):
            self.tags = tags
            super(MockTaggable, self).__init__(self._loader, self.tags)

    m = MockTaggable(['always'])
    assert m.evaluate_tags(['all'], [], {}) == True

    m = MockTaggable(['never'])
    assert m.evaluate_tags(['all'], [], {}) == False

    m = MockTaggable(['never'])
    assert m.evaluate_tags(['all'], ['never'], {}) == True

    m = MockTaggable(['always'])
    assert m.evaluate_tags(['all'], ['never'], {}), True

   

# Generated at 2022-06-23 07:13:57.845007
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class test_class(object):
        def __init__(self):
            self._tags = list()
            self.tags = self._tags
            self._loader = None
    test = test_class()

    test.tags = list()
    assert test.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is True
    assert test.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) is False
    assert test.evaluate_tags(only_tags=[], skip_tags=['foo'], all_vars={}) is True
    assert test.evaluate_tags(only_tags=[], skip_tags=['tagged'], all_vars={}) is True

    test.tags = ["foo", "bar", "baz"]
    assert test.evaluate_tags

# Generated at 2022-06-23 07:14:10.466325
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:14:20.546928
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        _loader = None
        def __init__(self, tags):
            self.tags = tags
    t = FakeTaggable(['tag1', 'tag2'])
    assert t.evaluate_tags(['tag1'], [], {})
    assert not t.evaluate_tags(['tag3'], [], {})
    assert t.evaluate_tags(['all'], [], {})
    assert t.evaluate_tags([], ['tag1'], {})
    assert not t.evaluate_tags([], ['all'], {})
    assert not t.evaluate_tags([], ['tagged'], {})
    assert t.evaluate_tags([], ['tag1', 'tag3'], {})
    assert t.evaluate_tags(['tagged'], [], {})


# Generated at 2022-06-23 07:14:32.979988
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
        # When only_tags is all
        t = Taggable()
        t.tags = ['ubuntu', 'redhat']
        only_tags = ['all']
        skip_tags = []
        all_vars = {}
        assert True == t.evaluate_tags(only_tags, skip_tags, all_vars)

        # When only_tags is all and has never tag
        t = Taggable()
        t.tags = ['ubuntu', 'redhat', 'never']
        only_tags = ['all']
        skip_tags = []
        all_vars = {}
        assert False == t.evaluate_tags(only_tags, skip_tags, all_vars)

        # When only_tags is all and has always tag
        t = Taggable()
        t.tags = ['ubuntu', 'redhat', 'always']

# Generated at 2022-06-23 07:14:43.581758
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test Taggable.evaluate_tags() '''

    # create a task object, and call evaluate_tags on it.
    test_task = Taggable()
    only_tags = []
    skip_tags = []
    all_vars = dict()
    assert test_task.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['all']
    assert test_task.evaluate_tags(only_tags, skip_tags, all_vars)

    test_task.tags = ['tagged']
    assert test_task.evaluate_tags(only_tags, skip_tags, all_vars)

    skip_tags = ['all']
    assert not test_task.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-23 07:14:44.597566
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO: implement
    pass

# Generated at 2022-06-23 07:14:53.436569
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyTaggable(Taggable):
        tags = []

    d = DummyTaggable()
    assert d.evaluate_tags(only_tags=['a'], skip_tags=[], all_vars={}) is False
    assert d.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) is True
    assert d.evaluate_tags(only_tags=[], skip_tags=['a'], all_vars={}) is True
    assert d.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) is False

    d.tags = ['a']
    assert d.evaluate_tags(only_tags=['a'], skip_tags=[], all_vars={}) is True

# Generated at 2022-06-23 07:15:01.258694
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    task = Task()
    task._loader = None
    task.tags = ['bar']
    task.name = 'foo'
    role = Role()
    role.tags = ['bar']
    role.name = 'foo'
    role._tasks = [task]

    only_tags = {'bar'}
    skip_tags = set()

    # check that the task has a matching tag (bar)
    assert(task.evaluate_tags(only_tags, skip_tags, {}) == True)

    # check that the role has a matching tag (bar)
    assert(role.evaluate_tags(only_tags, skip_tags, {}) == True)

    task.tags = ['nottag']

# Generated at 2022-06-23 07:15:13.338506
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableTester(Taggable):
        pass

    tg = TaggableTester(tags=['FOO', 'BAR'])

    only_tags = ['FOO']
    skip_tags = ['BAZ']
    all_vars = {}

    result = tg.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    only_tags = ['BAZ']
    skip_tags = ['BAZ']
    all_vars = {}

    result = tg.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False

    tg = TaggableTester(tags=['FOO'])

    only_tags = ['FOO', 'BAR']
    skip_tags = []

# Generated at 2022-06-23 07:15:14.926490
# Unit test for constructor of class Taggable
def test_Taggable():
    r = Taggable()
    assert(r.tags == [])

# Generated at 2022-06-23 07:15:23.169962
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True, 'should match tags even if more tags are defined'

    t.tags = ['tag1']
    assert t.evaluate_tags(['tag2'], [], {}) == False, 'should not match if item has no tags defined'
    assert t.evaluate_tags(['notag'], [], {}) == False, 'should not match if item has no tags defined'

    t.tags = []
    assert t.evaluate_tags(['tag1'], [], {}) == False, 'should not match if item has not tags defined'

    t.tags = ['untagged']

# Generated at 2022-06-23 07:15:29.791804
# Unit test for constructor of class Taggable
def test_Taggable():
    Task = Taggable()
    Task.tags = ['always']
    assert(Task.tags == ['always'])
    Task.tags = 'always'
    assert(Task.tags == ['always'])
    Task.tags = ['tag1', 'tag2', 'tag3']
    assert(Task.tags == ['tag1', 'tag2', 'tag3'])

# Generated at 2022-06-23 07:15:32.627257
# Unit test for constructor of class Taggable
def test_Taggable():
    tg = Taggable()
    assert isinstance(tg, Taggable)


# Generated at 2022-06-23 07:15:41.935043
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.errors import AnsibleError

    # base class test
    b = Base()
    try:
        b.tags
        raise Exception("base class should not have a tags attribute")
    except AttributeError:
        pass

    try:
        b.tags = 'foo'
        raise Exception("base class should not have a tags attribute")
    except AttributeError:
        pass

    # task class test
    t = Task()
    assert t.tags == []

    t.tags = "foo,bar"

# Generated at 2022-06-23 07:15:48.285174
# Unit test for constructor of class Taggable
def test_Taggable():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestClass(Taggable):
        pass

    class TestFuncs(unittest.TestCase):
        def test_tags(self):
            # Constructor
            t = TestClass()
            self.assertEqual(t.tags, [])
            self.assertEqual(t.untagged, ('untagged',))

#    unittest.main()
if __name__ == '__main__':
    test_Taggable()