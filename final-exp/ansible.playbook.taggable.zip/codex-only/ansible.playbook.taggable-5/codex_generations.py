

# Generated at 2022-06-23 07:05:49.883821
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ## Prepare the test data
    # Create a mock class inherited from Taggable so that we can call the method evaluate_tags to test.
    class Mock_Taggable:
        def __init__(self):
            self.tags = None

    # Create a Mock_Taggable object
    mock_obj = Mock_Taggable()

    # Create a dict which contains all variables needed by the method evaluate_tags.
    all_vars = {}

    ## Start the test
    # Case 1
    # Prepare the test data
    # Create a dict which contains all tags of the mock_obj. The dict will be changed to a list in the method
    # evaluate_tags. The list will be checked to evaluate if the current item should be executed.
    # The tags list here is for testing, it is not the default tags list.

# Generated at 2022-06-23 07:05:54.281600
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t.tags = ['tag1', 'tag2']
    t.tags = ['tag1', 'tag2', 'tag3']
    t.tags = 'tag1,tag2'
    t.tags = 'tag1, tag2, tag3'


# Generated at 2022-06-23 07:06:01.444673
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            super(TestTaggable, self).__init__()

    class TaggableTestCase(unittest.TestCase):
        def test_should_run_with_no_only_tags_and_no_skip_tags(self):
            # given
            taggable = TestTaggable(tags=['tagged'])
            only_tags = None
            skip_tags = None

            # when
            should_run = taggable.evaluate_tags(only_tags, skip_tags, {})

            # then
            self.assertTrue(should_run)


# Generated at 2022-06-23 07:06:05.129119
# Unit test for constructor of class Taggable
def test_Taggable():
   t = Taggable()
   assert t.tags is not None
   assert t._tags is not None

# Generated at 2022-06-23 07:06:11.497684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # class Taggable:

    #     untagged = frozenset(['untagged'])
    #     _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    class Taggable_class(Taggable):
        def __init__(self, tags):
            self._tags = tags

    import ansible.playbook.attribute
    t = Taggable_class([])
    print(t.evaluate_tags(None, None, None))
    print(t.evaluate_tags([], None, None))
    print(t.evaluate_tags(None, [], None))
    print(t.evaluate_tags([], [], None))
    print(t.evaluate_tags(['all'], None, None))

# Generated at 2022-06-23 07:06:13.821327
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert t.tags == []

# Generated at 2022-06-23 07:06:26.583696
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock:
        # We make all required methods and properties to be
        # available for Taggable.evaluate_tags
        def __init__(self):
            self._tags = list
            self.tags = None

    only_tags = list(['a', 'b', 'c'])
    skip_tags = list(['d', 'e', 'f'])
    all_vars = dict()

    taggable_mock = TaggableMock()

    # 1.1. As tags == None, all_vars == None, then False
    should_run = Taggable.evaluate_tags(
        taggable_mock,
        only_tags,
        skip_tags,
        all_vars
    )
    assert should_run is False

    # 1.2. As tags == None

# Generated at 2022-06-23 07:06:36.156897
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable:
        untagged = frozenset(['untagged'])
        
    # Test when no tags are defined, only_tags and skip_tags are None
    t = MockTaggable()
    t.tags = None
    result = t.evaluate_tags(None, None, {})
    assert result

    # Test when no tags are defined, only_tags contains tag 'always'
    t = MockTaggable()
    t.tags = None
    result = t.evaluate_tags(["always"], None, {})
    assert result

    # Test when no tags are defined, only_tags contains tag 'all'
    t = MockTaggable()
    t.tags = None
    result = t.evaluate_tags(["all"], None, {})
    assert not result

    # Test when no tags are defined,

# Generated at 2022-06-23 07:06:47.652047
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyTaggable(Taggable):
        pass

    dt = DummyTaggable()

    # Check that only_tags with 'always' in self.tags
    # returns True
    dt.tags = ['always']
    assert dt.evaluate_tags(['foo', 'bar'], None, None)

    # Check that only_tags with 'all' in it returns True
    # when there's no 'never' in tags
    dt.tags = ['foo']
    assert dt.evaluate_tags(['all', 'bar'], None, None)

    # Check that only_tags with 'all' in it returns False
    # when there's 'never' in tags
    dt.tags = ['never', 'foo']
    assert not dt.evaluate_tags(['all', 'bar'], None, None)

# Generated at 2022-06-23 07:06:52.633654
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass

    thing = MyTaggable()
    thing._load_tags(None, "foo, bar, baz")
    assert set(thing._tags) == set(['foo','bar','baz'])

test_Taggable()

# Generated at 2022-06-23 07:07:01.602769
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task

    Base._load_name = Taggable._load_name
    Base._load_tags = Taggable._load_tags

    t = Task()
    assert t.tags == []
    t._load_tags(None, dict(tags=['tag1', 'tag2']))
    assert t.tags == ['tag1', 'tag2']
    t._load_tags(None, dict(tags='tag1,tag2'))
    assert t.tags == ['tag1', 'tag2']

    t = Task()
    assert t.tags == []
    t._load_tags(None, dict(tags=['tag1', ['tag2', 'tag3']]))

# Generated at 2022-06-23 07:07:05.582599
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    # Test initialization of empty list
    assert taggable._tags == []
    # Test initialization of list of string types
    taggable._load_tags("tags", ["foo", "bar"])
    assert taggable._tags == ["foo", "bar"]
    # Test initialization of string type
    taggable._load_tags("tags", "foo,bar")
    assert taggable._tags == ["foo", "bar"]
    # Test initialization of non-list, non-string
    try:
        taggable._load_tags("tags", 1)
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:07:07.507490
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert t.tags == []


# Generated at 2022-06-23 07:07:18.942716
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test only_tags
    item = {'tags': ['foo', 'bar']}
    test_only_tags = ['foo', 'bar', 'baz']
    actual_result = Taggable().evaluate_tags(test_only_tags, None, item)
    assert actual_result == True
    test_only_tags = ['foo', 'baz']
    actual_result = Taggable().evaluate_tags(test_only_tags, None, item)
    assert actual_result == True
    test_only_tags = ['foo', 'bar']
    actual_result = Taggable().evaluate_tags(test_only_tags, None, item)
    assert actual_result == True
    test_only_tags = ['baz', 'bar']

# Generated at 2022-06-23 07:07:31.411474
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        pass

    #### TEST evaluate_tags ####
    myTaggable = MyTaggable()
    myTaggable.tags = None

    # CASE #1
    #   initialize
    #   myTaggable.tags = None
    #   only_tags = None
    #   skip_tags = None
    #   all_vars = None
    #   expected result: True
    only_tags = None
    skip_tags = None
    all_vars = None
    should_run = myTaggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

    # CASE #2
    #   initialize
    #   myTaggable.tags = None
    #   only_tags = []
    #  

# Generated at 2022-06-23 07:07:38.479425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):

        def __init__(self, tags):
            self.tags = tags

    # Create a mock for all_vars
    all_vars = dict()

    # Create a mock for only_tags
    only_tags = list()
    only_tags.append("mytag")
    only_tagset = set(only_tags)

    # Create a mock for skip_tags
    skip_tags = list()
    skip_tags.append("skipme")

    # Create a mock tags
    tags = list()
    tags.append("mytag")

    # Check that evaluate tags returns true when only_tags is provided
    taggable = MockTaggable(tags)
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    #

# Generated at 2022-06-23 07:07:44.258081
# Unit test for constructor of class Taggable
def test_Taggable():

    # class Taggable is a subclass of object, so an object of class Taggable is
    # an instance of both class Taggable and of class object.
    assert isinstance(Taggable(), Taggable)
    assert isinstance(Taggable(), object)
    assert not isinstance(Taggable(), str)



# Generated at 2022-06-23 07:07:48.555267
# Unit test for constructor of class Taggable
def test_Taggable():
    import collections
    person = collections.namedtuple("Person", "name age")
    person = person("test", 25)
    print("Name is: ", person.name)
    print("Age is: ", person.age)

test_Taggable();

# Generated at 2022-06-23 07:07:49.443935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #TODO
    pass

# Generated at 2022-06-23 07:07:50.286499
# Unit test for constructor of class Taggable
def test_Taggable():
    myTaggable = Taggable()

# Generated at 2022-06-23 07:07:56.995329
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._load_tags('foo', 'bar') == ['bar']
    assert Taggable()._load_tags('foo', ['bar', 'baz']) == ['bar', 'baz']
    try:
        Taggable()._load_tags('foo', 5)
        assert False, "should have raised exception"
    except AnsibleError as e:
        assert 'tags must be specified as a list' in str(e)


# Generated at 2022-06-23 07:08:09.881626
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test taggable with default value
    t = Taggable()
    assert t._load_tags(1, 'test1,test2') == ['test1', 'test2']
    assert t._load_tags(1, ['test1', 'test2']) == ['test1', 'test2']
    assert t._load_tags(1, ['test1', 'test2', 'test3']) == ['test1', 'test2', 'test3']
    # Test Taggable with non-default value
    t = Taggable()
    assert t._load_tags(1, 'test1,test2,test3') == ['test1', 'test2', 'test3']
    assert t._load_tags(1, 123) == [123]

# Generated at 2022-06-23 07:08:18.554513
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test setup
    class MockTaggable(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2']
    test_obj = MockTaggable()
    all_vars = dict()

    # tests
    # Tagger should run only_tags specified tags
    assert not test_obj.evaluate_tags(['tag3'], [], all_vars)
    assert test_obj.evaluate_tags(['tag1'], [], all_vars)
    assert test_obj.evaluate_tags(['tag2'], [], all_vars)
    assert test_obj.evaluate_tags(['tag1', 'tag2'], [], all_vars)

    # Tagger should not run skip_tags specified tags

# Generated at 2022-06-23 07:08:29.846332
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    
    class TestTaggable(Taggable):
        pass

    # Make 'tags' attribute accessible
    setattr(TestTaggable, 'tags', TestTaggable._tags)

    class TestTask(Task, TestTaggable):
        pass

    class TestTask2(Task, TestTaggable):
        def __init__(self, data, loader):
            super(TestTask2, self).__init__(data, loader)

        def args(self):
            return None
    
    # Make 'tags' attribute accessible
    setattr(TestTask2, 'tags', TestTask2._tags)
    
    # Test with empty 'only_tags' and empty 'skip_tags'

# Generated at 2022-06-23 07:08:39.271326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    module = None
    loader = None

    # Test case for no tags
    only_tags = ['tag1']
    skip_tags = ['tag2']
    all_vars = {'tags': None}
    ta = Taggable()
    ta.tags = None
    ta.all_vars = all_vars
    assert ta.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test case for only-tags should run
    only_tags = ['tag1']
    skip_tags = ['tag2']
    all_vars = {'tags': 'tag1'}
    ta = Taggable()
    ta.tags = None
    ta.all_vars = all_vars
    assert ta.evaluate_tags(only_tags, skip_tags, all_vars)

   

# Generated at 2022-06-23 07:08:50.560112
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(None, None, None) == True
    assert Taggable()._load_tags(None, "a,b,c") == ["a", "b", "c"]
    assert Taggable()._load_tags(None, 1) == [1]
    assert Taggable()._load_tags(None, ["a", "b", "c"]) == ["a", "b", "c"]
    assert Taggable()._load_tags(None, dict()) == dict()
    try:
        Taggable()._load_tags(None, {})
        raise AnsibleError()
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:09:01.734688
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyParent(object):
        def __init__(self):
            self.vars = {'test_var_1': 't1', 'test_var_2': 't2'}
    loader = DummyParent()
    class DummyClass(Taggable):
        _parent = loader

    # Test evaluate_tags with only tags
    # t1 and t2 are tags, 'never' and 'tagged' are skip tags
    # 'always' is always tag
    test_obj = DummyClass()
    test_obj.tags = ['t1', 't2']
    assert test_obj.evaluate_tags(['t1'], ['never', 'tagged'], {}) is False
    test_obj.tags = ['t1', 't2']

# Generated at 2022-06-23 07:09:14.253349
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = ['a', 'b', 'c']

    mtg = MyTaggable()

    # should run because no tags are specified
    assert mtg.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is True

    # should run because the tags in self.tags do not overlap
    # with the ones specified
    assert mtg.evaluate_tags(only_tags=['d'], skip_tags=[], all_vars={}) is True
    assert mtg.evaluate_tags(only_tags=['d'], skip_tags=[], all_vars={}) is True

    # should not run because overlapping with skip_tags

# Generated at 2022-06-23 07:09:25.710067
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Define base class for test
    class TestParent:
        def __init__(self):
            self._loader = None

    # Define class for test
    class TestObject(Taggable, TestParent):
        def __init__(self):
            Taggable.__init__(self)
            TestParent.__init__(self)

    # Create object of class TestObject
    to = TestObject()

    # Test if evaluate_tags returns False for empty tags
    to.tags = []
    assert to.evaluate_tags(['a'], [], {}) == False
    assert to.evaluate_tags([], ['a'], {}) == True

    # Test if evaluate_tags returns expected results
    to.tags = ['a']
    assert to.evaluate_tags(['a'], ['a'], {}) == True
   

# Generated at 2022-06-23 07:09:27.794799
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

# Generated at 2022-06-23 07:09:32.240869
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []
    obj = Taggable(dict(tags=['foo']))
    assert obj._tags == ['foo']

# testing of Taggable class method gettags

# Generated at 2022-06-23 07:09:43.917718
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' unit test for Taggable.evaluate_tags method '''
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import task_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block

    class MockJob:
        def __init__(self):
            self.callback = callback_loader.get('minimal')()

    class MockTask:
        def __init__(self):
            self.action = 'setup'
            self.task = task_loader.get('setup')()
            self.name = 'setup'


# Generated at 2022-06-23 07:09:56.369780
# Unit test for constructor of class Taggable
def test_Taggable():
    tg = Taggable()
    tags = tg.tags
    if tags is None or len(tags) != 0:
        raise Exception('Default tags is not correct')

    # Set tags with a list
    tg.tags = ['a', 'b']
    tags = tg.tags
    if tags is None or len(tags) != 2 or tags[0] != 'a' or tags[1] != 'b':
        raise Exception('Set list to tags is not correct')

    # Set tags with a string
    tg.tags = 'a,b'
    tags = tg.tags
    if tags is None or len(tags) != 2 or tags[0] != 'a' or tags[1] != 'b':
        raise Exception('Set string to tags is not correct')


# Generated at 2022-06-23 07:10:05.982805
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test play 1
    p1 = Play()
    p1.vars = dict(foo=1)

    # Test task 1 of play 1
    t1 = Task()
    t1.tags = ['one', 'two']
    p1.tasks.append(t1)

    # Test task 2 of play 1
    t2 = Task()
    t2.tags = ['one', 'three', 'always']
    p1.tasks.append(t2)

    # Test task 3 of play 1
    t3 = Task()
    t3.tags = ['never']
    p1.tasks.append(t3)

    # Test play 2
    p2 = Play()
    p2.vars = dict(foo=1)

    # Test task 1 of play 2
    t4 = Task()
    t4

# Generated at 2022-06-23 07:10:13.059906
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    Make sure that the Taggable object is created properly
    '''
    taggable = Taggable()

    assert '_tags' in taggable.__dict__
    assert taggable._tags == []

# Generated at 2022-06-23 07:10:24.351176
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        pass
    def check(tags, only_tags, skip_tags, expected):
        task = Task()
        task.tags = tags
        assert task.evaluate_tags(only_tags, skip_tags, {}) == expected

    # Default
    yield check, ['foo', 'bar'], None, None, True

    # Basic operations
    yield check, ['foo', 'bar'], ['foo'], None, True
    yield check, ['foo', 'bar'], ['foo', 'bar'], None, True
    yield check, ['foo', 'bar'], ['bar'], None, True
    yield check, ['foo'], ['bar'], None, False
    yield check, ['foo', 'bar'], ['baz'], None, False

# Generated at 2022-06-23 07:10:26.795818
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    taggable._tags = [1,2,3]

# Generated at 2022-06-23 07:10:27.721844
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:10:28.632289
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()

# Generated at 2022-06-23 07:10:29.285619
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:10:38.600298
# Unit test for constructor of class Taggable
def test_Taggable():
    import sys
    import os
    import ansible
    script_dir = os.path.dirname(__file__)
    ansible_dir = os.path.dirname(os.path.dirname(script_dir))
    module_utils_dir = os.path.join(ansible_dir, 'module_utils')
    sys.path.insert(0, module_utils_dir)
    from ansible.module_utils.testing import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    required_by = {'ansible_version': '2.1.0.0'}

    class Fake(Taggable):
        def __init__(self):
            pass


# Generated at 2022-06-23 07:10:48.312681
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    This is a unit test for method evaluate_tags of class Taggable
    """
    only_tags=['all']
    skip_tags=['all', 'never']
    class Temp():
        def __init__():
            self.tags=None
            self._loader=None
        def evaluate_tags(self,only_tags,skip_tags,all_vars):
            if self.tags:
                if 'always' in tags:
                    should_run = True
                elif ('all' in only_tags and 'never' not in tags):
                    should_run = True
                elif not tags.isdisjoint(only_tags):
                    should_run = True
                elif 'tagged' in only_tags and tags != self.untagged and 'never' not in tags:
                    should_run = True
               

# Generated at 2022-06-23 07:10:58.961654
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base

    class TestClass(Base, Taggable):
        pass

    test_instance = TestClass()

    # Test for 'always' tag
    test_instance.tags = ['always', 'foo']
    assert test_instance.evaluate_tags(only_tags=['bar', 'baz'], skip_tags=[])

    # Test for 'never' tag
    test_instance.tags = ['foo', 'never']
    assert not test_instance.evaluate_tags(only_tags=[], skip_tags=['bar', 'baz'])

    # Test for 'always' and 'never' tags
    test_instance.tags = ['always', 'never']

# Generated at 2022-06-23 07:11:01.077488
# Unit test for constructor of class Taggable
def test_Taggable():
    print("Constructor of class Tagable")
    tag = Taggable()
    assert tag.tags == [], "Problem in constructor of class Taggable"



# Generated at 2022-06-23 07:11:08.763314
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass
    t = MyTaggable()
    assert t._tags == list()

    t = MyTaggable(tags=1)
    assert t._tags == [1]

    t = MyTaggable(tags='2')
    assert t._tags == ['2']

    t = MyTaggable(tags='3,4')
    assert t._tags == ['3', '4']


# Generated at 2022-06-23 07:11:19.858876
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    # Data to use
    sample_data = ['tagA', 'tagB', 'tagC']
    tbl = Taggable()
    tbl.tags = sample_data
    assert tbl.tags == sample_data
    # Data to use
    sample_data = 'tagD,tagE,tagF'
    tbl = Taggable()
    tbl.tags = sample_data
    # Prepare object to test evaluate_tags
    play_context = PlayContext()
    variable_manager = VariableManager()

# Generated at 2022-06-23 07:11:28.346044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    all_vars = {'tags': ['test']}
    runner_tags = ['test']
    options = {}
    results = [True, True, True]

    options['only_tags'] = ['test']
    temp_results = [Taggable().evaluate_tags(options['only_tags'], options['skip_tags'], all_vars)]
    for result in temp_results:
        results.append(result)

    options['only_tags'] = ['tagged']
    temp_results = [Taggable().evaluate_tags(options['only_tags'], options['skip_tags'], all_vars)]
    for result in temp_results:
        results.append(result)

    options['only_tags'] = ['tagged']
    all_vars = {'tags': []}
   

# Generated at 2022-06-23 07:11:38.734786
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class fake_self(object):
        def __init__(self):
            self.tags = []

    fake_self_obj = fake_self()
    # test when value of only_tags is empty
    only_tags = []
    skip_tags = []
    all_vars = {}
    result = Taggable.evaluate_tags(fake_self_obj, only_tags, skip_tags, all_vars)
    assert result

    # test when value of skip_tags is empty
    only_tags = []
    skip_tags = []
    all_vars = {}
    result = Taggable.evaluate_tags(fake_self_obj, only_tags, skip_tags, all_vars)
    assert result

    # test when value of all_vars is empty and excepted return value is false
    only_tags

# Generated at 2022-06-23 07:11:40.987388
# Unit test for constructor of class Taggable
def test_Taggable():

    class Foo(Taggable):
        pass

    x = Foo()
    print(x.tags, x.evaluate_tags())

# Generated at 2022-06-23 07:11:43.736029
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    t2 = Taggable(tags="tag")
    assert t2._tags == ['tag']

# Generated at 2022-06-23 07:11:45.251990
# Unit test for constructor of class Taggable
def test_Taggable():
    task = Taggable()
    assert task._tags == list()
    assert task.tags == list()
    assert task.tags is not task._tags


# Generated at 2022-06-23 07:11:56.463744
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self):
            self._loader = None

    # Taggable object with no tags
    taggable = MockTaggable()
    taggable.tags = []
    assert taggable.evaluate_tags([], [], {}) == True

    # Taggable with only_tags
    taggable.tags = []
    assert taggable.evaluate_tags(['foo'], [], {}) == False
    taggable.tags = ['foo']
    assert taggable.evaluate_tags(['foo'], [], {}) == True
    taggable.tags = ['foo', 'bar']
    assert taggable.evaluate_tags(['foo'], [], {}) == True
    taggable.tags = ['bar', 'baz']
   

# Generated at 2022-06-23 07:12:04.017773
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        from ansible.playbook.task import Task
        from ansible.playbook.play_context import PlayContext
    except:
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.task import Task
        from ansible.playbook.play_context import PlayContext

    class myTask(Task, Taggable):
        def __init__(self):
            self._task_type = 'myTask'
            super(myTask, self).__init__()

    task = myTask()

    assert isinstance(task, myTask)
    assert isinstance(task._tags, list)
    assert task._tags == []

    task = Taggable()
    t = task._load_tags('tags', "foo, bar")
    assert t == ['foo','bar']

    t

# Generated at 2022-06-23 07:12:11.823080
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t._tags = ['test_tag']

    only_tags = set(['test_tag', 'test_tag2'])
    skip_tags = set(['test_tag3', 'test_tag4'])
    all_vars = {}

    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    skip_tags = set(['test_tag', 'test_tag4'])
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-23 07:12:17.447858
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    t._tags = [1, 2, 3]
    assert t._tags == [1, 2, 3]
    assert t.tags == [1, 2, 3]
    assert t.tags is t._tags

# Unit test init_tags method of class Taggable

# Generated at 2022-06-23 07:12:26.450803
# Unit test for constructor of class Taggable
def test_Taggable():

    # Create a Taggable using a dict for the arg
    t1 = Taggable({'tags': ['a', 'b', 'c']})

    # test the list of tags is the same as the string from list
    t1str1 = str(t1._tags)
    t1str2 = t1.tags.__str__()
    assert(t1str1 == t1str2)
    
    # Test that the string is the same as the string version of the list
    t1str = str([t1.tags])
    assert(t1str1 == t1str)

    # Test that the constructor with a dict argument works
    assert(t1.tags == ['a', 'b', 'c'])

    # Create a Taggable object with a string argument

# Generated at 2022-06-23 07:12:28.690183
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable().tags == []

# Generated at 2022-06-23 07:12:39.146246
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        tags = []

    obj = MockTaggable()

    tags = [
        'yellow',
        'green',
        'blue',
        'red'
    ]

    result = obj.evaluate_tags(only_tags=[], skip_tags=tags, all_vars={})
    assert result is True

    result = obj.evaluate_tags(only_tags=tags, skip_tags=[], all_vars={})
    assert result is True

    obj.tags = tags

    result = obj.evaluate_tags(only_tags=['yellow'], skip_tags=[], all_vars={})
    assert result is True

    result = obj.evaluate_tags(only_tags=['yellow'], skip_tags=['yellow'], all_vars={})
    assert result is False

# Generated at 2022-06-23 07:12:42.737169
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._load_tags('_tags', ['tag1', 'tag2']), list)
    assert isinstance(taggable._load_tags('_tags', 'tag1,tag2'), list)

# Generated at 2022-06-23 07:12:49.820141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(['a', 'b'], [], {}) is False
    assert Taggable().evaluate_tags(['a', 'b'], [], {'tags':'a'}) is True
    assert Taggable().evaluate_tags([], [], {'tags':'a'}) is True
    assert Taggable().evaluate_tags([], [], {}) is True
    assert Taggable().evaluate_tags([], ['a', 'b'], {'tags':'a'}) is False
    assert Taggable().evaluate_tags([], ['a', 'b'], {}) is True
    assert Taggable().evaluate_tags([], ['a', 'b'], {'tags':['a', 'b']}) is False

# Generated at 2022-06-23 07:12:52.920459
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass

    myTaggable = MyTaggable()

    assert isinstance(myTaggable.tags, list)

# Generated at 2022-06-23 07:12:59.515124
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    import os
    import sys
    lib = os.path.join(os.path.dirname(__file__), '..', '..')
    sys.path.insert(0, lib)

    # test that evaluate_tags method returns the right value
    # in all possible cases defined in documentation
    assert TestTaggable([]).evaluate_tags(['tag1'], [], {}) is False
    assert TestTaggable([]).evaluate_tags(['tag1', 'tag2'], [], {}) is False
    assert TestTaggable([]).evaluate_tags([], ['tag1'], {}) is True

# Generated at 2022-06-23 07:13:02.540636
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = ['tag1', 'tag2']
    task = Task(tags=tags)
    print("The tags are: " + str(task.tags))


# Generated at 2022-06-23 07:13:11.426311
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class test:
        def __init__(self, only_tags, skip_tags, tags):
            self.tags = tags
        def __eq__(self, rhs):
            return self.tags == rhs.tags
        def __repr__(self):
            return 'test(%r)' % (self.tags)

    def assert_evaluate_tags(only_tags, skip_tags, tags, result):
        assert result == Taggable.evaluate_tags(test(only_tags, skip_tags, tags), only_tags, skip_tags, {'inventory_hostname': 'localhost'})

    # only_tags/skip_tags/tags -> result[True]/False
    assert_evaluate_tags([], [], [], True) # Default: run
    assert_evaluate_tags([], [], [], True) # Default:

# Generated at 2022-06-23 07:13:21.823028
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible import constants
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude


# Generated at 2022-06-23 07:13:31.787328
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_context = PlayContext()
    task = Task()
    task._role = RoleInclude()
    task._role._parent = Block()

    taggable = Taggable()
    taggable.tags = ['tag1', 'tag2']
    assert taggable._load_tags(taggable.tags, ['tag1', 'tag2']) == ['tag1', 'tag2']
    assert taggable._load_tags(taggable.tags, 'tag1,tag2') == ['tag1', 'tag2']


# Generated at 2022-06-23 07:13:43.089151
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    global DEBUG
    DEBUG = True

    def show_test(only_tags, skip_tags, tags, result):
        print(
            "TEST-only_tags=%s, skip_tags=%s, tags=%s ==> should_run=%s"
            % (repr(only_tags), repr(skip_tags), repr(tags), repr(result)))

    class MockTaggable():
        def __init__(self):
            self._loader = None
            self.tags = None
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

    taggable = MockTaggable()
    all_vars = {}

    # test scenarios based on Ansible documentation
   

# Generated at 2022-06-23 07:13:44.848399
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t != None


# Generated at 2022-06-23 07:13:48.744393
# Unit test for constructor of class Taggable
def test_Taggable():
    class FakeClass(Taggable):
        pass
    obj = FakeClass()
    assert(obj.tags == [])

# verify that an empty task list can return an empty list for tags, for display purposes

# Generated at 2022-06-23 07:13:58.786540
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # no tags, no only_tags, no skip_tags
    test_item = Taggable()
    all_vars = dict()
    assert test_item.evaluate_tags(None, None, all_vars)

    # tags, no only_tags, no skip_tags
    test_item.tags = [ "tag1" ]
    assert test_item.evaluate_tags(None, None, all_vars)

    # tags, only_tags, no skip_tags
    test_item.tags = [ "tag1" ]
    assert test_item.evaluate_tags(['tag1'], None, all_vars)
    assert not test_item.evaluate_tags(['tag2'], None, all_vars)

    # no tags, only_tags, no skip_tags
    test_item.tags = []


# Generated at 2022-06-23 07:14:10.729681
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.module_utils.six import iteritems

    class TaskSubclass(Task):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def __init__(self, loader=None, variable_manager=None, name=None, play=None, parent=None, role=None, task_vars=dict()):
            super(TaskSubclass, self).__init__(loader=loader, variable_manager=variable_manager, name=name, play=play, parent=parent, role=role, task_vars=dict())


# Generated at 2022-06-23 07:14:13.420465
# Unit test for constructor of class Taggable
def test_Taggable():
    class test(Taggable):
        pass
    x = test()
    x._tags = {"blah"}
    assert isinstance(x._tags, set)
    assert x.tags is None

# Generated at 2022-06-23 07:14:14.832796
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    print(test_obj)


test_Taggable()

# Generated at 2022-06-23 07:14:24.412012
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    task = Task()
    task._loader = None
    task.tags = ["LAB"]
    task.only_tags = ["LAB"]

    if task.evaluate_tags(task.only_tags, [], {}) == True:
        print("test_Taggable_evaluate_tags: test 1 success")
    else:
        print("test_Taggable_evaluate_tags: test 1 failed")

    task.tags = ["LAB"]
    task.only_tags = ["LAB", "TEST"]

    if task.evaluate_tags(task.only_tags, [], {}) == True:
        print("test_Taggable_evaluate_tags: test 2 success")
    else:
        print("test_Taggable_evaluate_tags: test 2 failed")


# Generated at 2022-06-23 07:14:36.125617
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    o = Taggable()
    o.tags = ['test_tags']
    only_tags = ['test_tags']
    skip_tags = [ ]
    all_vars = {}
    if o.evaluate_tags(only_tags, skip_tags, all_vars):
        assert True
    else:
        assert False

    o.tags = ['never']
    only_tags = ['test_tags']
    skip_tags = [ ]
    all_vars = {}
    if o.evaluate_tags(only_tags, skip_tags, all_vars):
        assert False
    else:
        assert True

    o.tags = ['never']
    only_tags = [ ]
    skip_tags = ['test_tags']
    all_vars = {}

# Generated at 2022-06-23 07:14:47.688447
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.vars
    import ansible.inventory

    yaml_data = """
        - hosts: localhost
          tasks:
            - name: test if we can skip the task
              ping:
              tags: tag_to_skip
    """

    inventory = ansible.inventory.Inventory(host_list=[])
    variable_manager = ansible.vars.VariableManager(loader=None, inventory=inventory)
    loader = ansible.playbook.playbook.Playbook.loader
    pb = ansible.playbook.PlayBook(loader=loader,
                                   variable_manager=variable_manager,
                                   playbooks=[yaml_data,])

    for play in pb.get_plays():
        play.post_validate(templar=None)


# Generated at 2022-06-23 07:14:58.306418
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    fake_vars = {}
    fake_only_tags = []
    fake_skip_tags = []

    # Default case with no tags
    fake_taggable = Taggable()
    assert fake_taggable.evaluate_tags(fake_only_tags, fake_skip_tags, fake_vars)

    # Case with an "always" tag
    fake_taggable = Taggable()
    fake_taggable.tags = ['always']
    assert fake_taggable.evaluate_tags(fake_only_tags, fake_skip_tags, fake_vars)

    fake_only_tags = ['all']
    fake_taggable = Taggable()
    fake_taggable.tags = []

# Generated at 2022-06-23 07:15:10.696476
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test with an empty list
    obj1 = Taggable()
    assert obj1._tags == list()

    # Test with a list of strings
    obj2 = Taggable()
    obj2._tags = ['tag1', 'tag2']
    assert obj2._tags == ['tag1', 'tag2']

    # Test with a string of comma-separated strings
    obj3 = Taggable()
    obj3._tags = 'tag1, tag2'
    assert obj3._tags == ['tag1', 'tag2']

    # Test that error is raised with an empty string
    obj4 = Taggable()
    try:
        obj4._tags = ''
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError was not raised"

    # Test that error is raised with a non

# Generated at 2022-06-23 07:15:15.631926
# Unit test for constructor of class Taggable
def test_Taggable():
    class ATaggable(Taggable):
        pass

    assert '==' == {'tags': []}.__eq__({'tags': []})
    assert ATaggable({'tags': []}) != '=='
    assert ATaggable({'tags': []}) != '==='


# Generated at 2022-06-23 07:15:19.815876
# Unit test for constructor of class Taggable
def test_Taggable():
    # create empty object
    obj = Taggable()
    # check if empty
    assert obj._tags == []
    # call constructor with parameter
    obj2 = Taggable(tags=['foo', 'bar'])
    # check if not emtpy
    assert obj2._tags == ['foo', 'bar']

# Generated at 2022-06-23 07:15:33.281449
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.base import Base
    from ansible.playbook.become import Become
    from ansible.playbook.role.meta import RoleMeta
    import pytest

    class TestModule(Taggable):
        pass

    # Create a new instance of Test

# Generated at 2022-06-23 07:15:37.124657
# Unit test for constructor of class Taggable
def test_Taggable():
    import pytest
    from ansible.playbook.attribute import FieldAttribute

    test_class = Taggable()
    assert test_class._tags == FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)


# Generated at 2022-06-23 07:15:45.261415
# Unit test for constructor of class Taggable
def test_Taggable():
   tag = Taggable()
   assert tag._tags == list  # default value for instance var _tags
   assert tag.untagged == frozenset([])  # default value for static var untagged
   assert tag._load_tags(attr = '_tags', ds = '[a,b,c]') == ['a','b','c']  # test loading a list
   assert tag._load_tags(attr = '_tags', ds = 'a') == ['a']  # test loading a string
   assert tag._load_tags(attr = '_tags', ds = 1) == [1]  # test loading an integer
   try:
       assert tag._load_tags(attr='_tags', ds={})
   except AnsibleError:
       assert True
