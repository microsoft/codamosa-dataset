

# Generated at 2022-06-23 07:05:46.584152
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable, Taggable)


# Generated at 2022-06-23 07:05:54.805870
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    klass = Taggable()
    klass.tags = ['untagged']
    assert not klass.evaluate_tags(['all'], [], {})
    assert not klass.evaluate_tags(['untagged'], [], {})
    assert not klass.evaluate_tags(['tagged'], [], {})
    assert klass.evaluate_tags(['tagged', 'all'], [], {})
    assert not klass.evaluate_tags([], ['all'], {})
    assert not klass.evaluate_tags([], ['untagged'], {})
    assert not klass.evaluate_tags([], ['tagged'], {})
    assert klass.evaluate_tags([], ['tagged', 'all'], {})
    assert klass.evaluate_tags(['untagged'], ['tagged'], {})

# Generated at 2022-06-23 07:05:58.511500
# Unit test for constructor of class Taggable
def test_Taggable():
    class FakeLoader():
        pass
    loader = FakeLoader()
    tags = ['test_tag']
    test_Taggable = Taggable(loader=loader, tags=tags)
    assert test_Taggable.tags[0] == 'test_tag'


# Generated at 2022-06-23 07:06:10.439376
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # for test purpose, we define a class TaggableTest inheriting from Taggable
    class TaggableTest(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    # define helper function __evaluate_tags_helper to test evaluate_tags method
    def __evaluate_tags_helper(tags, only_tags, skip_tags, should_run):
        t = TaggableTest(tags)
        assert t.evaluate_tags(only_tags, skip_tags, {}) == should_run

    # check with tags only
    tags = ['tag1', 'tag2']
    only_tags = set(['tag3'])
    skip_tags = set([])
    __evaluate_tags_helper(tags, only_tags, skip_tags, False)

# Generated at 2022-06-23 07:06:17.699468
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.module_utils._text import to_text
    from ansible.utils.vars import combine_vars

    class TestTaggableEvaluateTags(unittest.TestCase):

        def setUp(self):
            fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
            self.loader = DataLoader()

# Generated at 2022-06-23 07:06:19.737948
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-23 07:06:21.517969
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags(None, None) is None

# Generated at 2022-06-23 07:06:23.178641
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable()._tags == []

# Generated at 2022-06-23 07:06:33.744884
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.playbook.handler


# Generated at 2022-06-23 07:06:46.536822
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        pass

    task = Task()

    # set tags
    task.tags = ['test', 'untagged']
    # set only_tags
    only_tags = ['test', 'never']
    # set skip_tags
    skip_tags = ['never']
    # set all_vars
    all_vars = dict(
        # _ansible_tags=['test', 'never'],
        # _ansible_skip_tags=['never']
    )

    # Tags in list
    # assert(task.evaluate_tags(only_tags, skip_tags, all_vars) is True)

    # Tags in string with ','
    task.tags = "test,untagged"

# Generated at 2022-06-23 07:06:58.092938
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import collections

    t = Taggable()
    t._loader = None

    class FakeVars:
        def get_vars(self):
            return {
                "foo": "bar"
            }

    # Test when no tags are set and no --only-tags or --skip-tags are specified
    t.tags = []
    o = collections.namedtuple('T', ["only_tags", "skip_tags"])
    opts = o(only_tags=None, skip_tags=None)
    assert t.evaluate_tags(opts.only_tags, opts.skip_tags, all_vars=FakeVars())

    # Test when tags are set and no --only-tags, then task should run
    t.tags = ["something"]

# Generated at 2022-06-23 07:07:09.878314
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.playbook_include import Include
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_play = Play.load(dict(name="test",
                               hosts=['localhost'],
                               gather_facts='no',
                               gather_subset=[],
                               tags=['tag1', 'tag2']),
                               variable_manager=VariableManager(), loader=None, inventory=InventoryManager())

    test_play.post_validate(PlayContext())
    assert isinstance(test_play.tags, list)
    assert 'tag1' in test_play.tags
    assert 'tag2' in test_play.tags
   

# Generated at 2022-06-23 07:07:20.496365
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Unit tests for the method Taggable.evaluate_tags'''
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    # this one must be called first to get the assert statements to work
    assert test_Taggable_evaluate_tags.__doc__ is not None

    # the mock_role method will be used as the first argument to the TaskInclude constructor
    def mock_role(name, role_path, loader, variable_manager):
        return name

    # instantiate a variable manager
    variable_manager = None

    # test case 1: 'only_tags' has 'never' which means the task should not run
    t1 = TaskInclude(mock_role, 'role1', 'role1', variable_manager)
    t1.tags = ['never']


# Generated at 2022-06-23 07:07:28.836724
# Unit test for constructor of class Taggable
def test_Taggable():
    #   print("test_Taggable")
    t = Taggable()
    t._loader = None
    t._tags = ['test_tag_a']
    t._ds = ['test_tag_b']
    t._ds = t._load_tags(0, t._ds)
    #   print("    " + "print_tags = %s" % (t._tags))
    #   print("    " + "print_ds = %s" % (t._ds))
    return


# Generated at 2022-06-23 07:07:37.397332
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy():
        pass
    t = Dummy()
    # Default case, nothing to run
    t.tags = [1]
    assert Taggable.evaluate_tags(t, [2], []) == False, 'Default case should be False'
    assert Taggable.evaluate_tags(t, [], ['all']) == False, 'Default case should be False'
    assert Taggable.evaluate_tags(t, [1], []) == True, 'Default case should be True'
    assert Taggable.evaluate_tags(t, [1], ['all']) == False, 'Default case should be False'
    assert Taggable.evaluate_tags(t, [1], ['tagged']) == True, 'Default case should be True'

# Generated at 2022-06-23 07:07:52.633255
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    class MyTask(Task):
        _task_type = "MyTask"
        def __init__(self, block=None, role=None, play=None):
            super(MyTask, self).__init__(block=block, role=role, play=play)

    class MyHandler(Handler):
        pass

    #
    # Test should_run
    #

    task = MyTask()
    block = Block()
    block.parent_role = Role()
    block.parent_play = Play()

    # When 'only_tags' is empty, we run
    assert task

# Generated at 2022-06-23 07:07:57.985729
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags("", ["tag1", "tag2"]) == ["tag1", "tag2"]

# Generated at 2022-06-23 07:08:07.098662
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    play = Play()
    task = Task()
    handler = Handler()

    play.tags = ['a', 'b']
    assert play.tags == ['a', 'b']

    task.tags = ['b', 'c']
    assert task.tags == ['b', 'c']

    handler.tags = ['c', 'd']
    assert handler.tags == ['c', 'd']

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:08:11.241903
# Unit test for constructor of class Taggable
def test_Taggable():

    # Instantiate Taggable() with no arguments
    ta = Taggable()

    # Verify _tags attribute is as expected
    assert isinstance(ta._tags, list)
    assert 0 == len(ta._tags)

# Generated at 2022-06-23 07:08:19.464679
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_tags = 'test1'
    task_to_test = TaskInclude()
    task_to_test.tags = [test_tags]

    assert task_to_test.evaluate_tags(['test1'], [], []) == True
    assert task_to_test.evaluate_tags([], ['test1'], []) == False

    # test1 should not be skipped
    assert task_to_test.evaluate_tags([], ['test2', 'test3'], []) == True

    # test2 and test3 should be skipped
    assert task_to_test.evaluate_tags(['test2', 'test3'], [], []) == False

   

# Generated at 2022-06-23 07:08:31.682276
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:08:41.381429
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Dummy Taggable class to test the method
    class DummyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
        def _load_tags(self, attr, ds):
            return ds

    test_object = DummyTaggable(tags=['untagged'])
    assert not test_object.evaluate_tags(only_tags=['some_test_tag'], skip_tags=[], all_vars={})
    assert not test_object.evaluate_tags(only_tags=[], skip_tags=['some_test_tag'], all_vars={})

    test_object = DummyTaggable(tags=['all', 'untagged'])

# Generated at 2022-06-23 07:08:53.460466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    assert Taggable.evaluate_tags.__doc__

    only_tags = ['all', 'test-tagged']
    skip_tags = ['test-skip-tag']

    task = Task()
    task.tags = ['test-tagged']
    assert task.evaluate_tags(only_tags, skip_tags, {})
    task.tags = ['test-skip-tag']
    assert not task.evaluate_tags(only_tags, skip_tags, {})
    task.tags = ['test-tagged', 'test-skip-tag']
    assert not task.evaluate_tags(only_tags, skip_tags, {})
    task.tags = ['test-tagged', 'test-skip-tag', 'foo']

# Generated at 2022-06-23 07:08:55.608969
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == [], "Taggable has wrong default value"

# Generated at 2022-06-23 07:09:04.514067
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == list
    assert t.tags == []
    assert t.untagged == frozenset()
    assert t.evaluate_tags(["all"],["none"], {})
    assert t.evaluate_tags(["none"],["all"], {})
    assert not t.evaluate_tags(["none"],["none"], {})
    assert not t.evaluate_tags(["all"],["all"], {})
    t.tags = ["all"]
    assert t.evaluate_tags(["all"],["none"], {})
    assert not t.evaluate_tags(["none"],["all"], {})
    assert not t.evaluate_tags(["none"],["none"], {})
    assert not t.evaluate_tags(["all"],["all"], {})
    t.tags = ["none"]

# Generated at 2022-06-23 07:09:15.901356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.block

    role_mock = ansible.playbook.role.Role()
    task_mock = ansible.playbook.task.Task()
    block_mock = ansible.playbook.block.Block()

    # test with no tags
    task_mock.tags = None
    assert task_mock.evaluate_tags(only_tags=set(['tag1']), skip_tags=set(['tag2']), all_vars={}) == False
    assert task_mock.evaluate_tags(only_tags=None, skip_tags=set(['tag2']), all_vars={}) == True

# Generated at 2022-06-23 07:09:18.115337
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test Taggable constructor
    t = Taggable()

    # Test that tags field is initialized with an empty list
    assert t._tags == []

# Generated at 2022-06-23 07:09:26.846020
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    always_tags = ['always']
    never_tags = ['never']
    tagged_tags = ['tagged']

    t = Taggable()

    # test defaults
    assert t.evaluate_tags(only_tags=None, skip_tags=None) == True
    assert t.evaluate_tags(only_tags=always_tags, skip_tags=None) == True
    assert t.evaluate_tags(only_tags=never_tags, skip_tags=None) == False

    # test only_tags:
    #     - skip a task without tags
    t.tags = None
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=None) == False
    #     - don't skip a task with tags
    t.tags = ['tagged']

# Generated at 2022-06-23 07:09:39.490461
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class obj(Taggable):
        tags = ['tag1', 'tag2']
    only_tags = ['tag1', 'tag3']
    skip_tags = ['tag2', 'tag3']
    all_vars = {}
    assert obj().evaluate_tags(only_tags, skip_tags, all_vars) == True
    class obj(Taggable):
        tags = ['tag1', 'tag2']
    only_tags = ['tag3']
    skip_tags = ['tag2', 'tag3']
    all_vars = {}
    assert obj().evaluate_tags(only_tags, skip_tags, all_vars) == False
    class obj(Taggable):
        tags = ['tag1', 'tag2']
    only_tags = ['tag3']
    skip_tags = ['tag1']


# Generated at 2022-06-23 07:09:45.502381
# Unit test for constructor of class Taggable
def test_Taggable():
    class FakeLoader:
        pass

    test_tags = 'a, b, c'
    test_only_tags = ['a', 'c']
    test_skip_tags = ['b']

    obj = Taggable()
    obj._loader = FakeLoader()
    obj.tags = test_tags

    assert obj.evaluate_tags(test_only_tags, test_skip_tags, {}) == True

# Generated at 2022-06-23 07:09:55.785164
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable(tags=['test', 'other']) == {'tags': ['test', 'other']}
    assert Taggable(tags='test, other') == {'tags': ['test', 'other']}
    assert Taggable(tags=['test', 'other']) == {'tags': ['test', 'other']}
    assert Taggable(tags='test,other') == {'tags': ['test', 'other']}
    assert Taggable(tags='test,\nother') == {'tags': ['test', 'other']}
    assert Taggable(tags='test\n,\nother') == {'tags': ['test', 'other']}

# Generated at 2022-06-23 07:10:08.466558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    t = TestClass()
    t.tags = ['tag1', 'tag2']

    # Test with a combination of skip_tags and only_tags
    only_tags = ['tag1']
    skip_tags = ['skip_tag1']
    assert t.evaluate_tags(only_tags, skip_tags, dict())
    only_tags = ['tag1']
    skip_tags = ['tag1']
    assert not t.evaluate_tags(only_tags, skip_tags, dict())
    only_tags = ['skip_tag1']
    skip_tags = ['tag1']
    assert not t.evaluate_tags(only_tags, skip_tags, dict())
    only_tags = ['skip_tag1']
    skip_tags = ['skip_tag1']

# Generated at 2022-06-23 07:10:19.998871
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.utils.listify import listify_lookup_plugin_terms

    import ansible.constants as C
    C.DEFAULT_HOST_LIST = 'simple_hosts'

    play1 = Play()
    play1.vars = {'rancher_role': 'server'}

    rancher_role = "rancher_role"

    # untagged block
    t1 = Task()
    t2 = Task()

# Generated at 2022-06-23 07:10:21.850102
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    # Test the default constructor
    assert taggable._tags == []

# Generated at 2022-06-23 07:10:34.655687
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    class MyClass(Base):
        def __init__(self, tags=['tag1','tag2','tag3','tag4']):
            Base.__init__(self, dict(tags=tags))

    my_class = MyClass()

    only_tags=['tag1']
    skip_tags=[]
    assert my_class.evaluate_tags(only_tags, skip_tags, dict())

    only_tags=['tag3']
    skip_tags=[]
    assert not my_class.evaluate_tags(only_tags, skip_tags, dict())

    only_tags=[]
    skip_tags=['tag1']
    assert not my_class.evaluate_tags(only_tags, skip_tags, dict())

    only_tags=['tag1']
    skip_

# Generated at 2022-06-23 07:10:46.302104
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # tasks without tags
    t1 = Task().load({'name': 't1'})
    assert t1.evaluate_tags([], [], {})
    assert t1.evaluate_tags(['all'], [], {})
    assert not t1.evaluate_tags(['tagged'], [], {})
    assert not t1.evaluate_tags(['tagged', 'all'], [], {})

    # tasks with tags
    t2 = Task().load({'name': 't2', 'tags': ['foo']})
    assert t2.evaluate_tags([], [], {})
    assert t2.evaluate_tags(['all'], [], {})

# Generated at 2022-06-23 07:10:49.875135
# Unit test for constructor of class Taggable
def test_Taggable():

        obj = Taggable()
        assert type(obj.tags) is list
        assert type(obj.untagged) is frozenset
        assert obj.tags == []


# Generated at 2022-06-23 07:11:00.448583
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars
    import os

    # Load up a task
    my_task = Task.load(dict(
        name="Example task",
        action=dict(
            module="shell",
            args="uptime",
        )
    ), play=None, variable_manager=None, loader=None)

    # Set some tag options
    skip_tags=["never", "tagged", "untagged"]

# Generated at 2022-06-23 07:11:12.602453
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ['untagged']
    t.evaluate_tags(['untagged'],['never'], [])
    t._tags = ['always']
    t.evaluate_tags(['always'],['never'], [])
    t.evaluate_tags([],['never'], [])
    t._tags = ['never']
    t.evaluate_tags(['never'],['never'], [])
    t.evaluate_tags([],['never'], [])
    t._tags = ['no-op']
    t.evaluate_tags(['no-op'],['never'], [])
    t.evaluate_tags([],['never'], [])
    t._tags = ['tagged']
    t.evaluate_tags(['tagged'],['never'], [])

# Generated at 2022-06-23 07:11:23.116850
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # object to test
    # cannot instantiate Taggable() directly because it is an abstract class
    # but we can use another class that extends Taggable, for instance ActionBase
    from ansible.plugins.action.normal import ActionModule
    test_obj = ActionModule(loader=None, templar=None, shared_loader_obj=None)

    # tag to test
    t_tag = ['tag_1', 'tag_2']
    # skip_tags
    t_skip_tags = ['all', 'tag_3']
    # only_tags
    t_only_tags = ['tag_1']

    # set object tags
    test_obj.tags = t_tag

    # test objects defaults
    # should be set to True but initialized to None
    assert test_obj.run_once is None

# Generated at 2022-06-23 07:11:34.433837
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib
    from ansible.utils.path import makedirs_safe

    vault_secret = 'password'
    vault_password_file = '/tmp/vault-pass.txt'
    test_file = '/tmp/Taggable.yml'
    test_content = {
        'vault_password_file': VaultLib(vault_secret).encrypt('foo'),
        'tasks': {
            'foobar': {
                'tags': 'foo, bar',
            },
            'foobaz': {
                'tags': ['foo', 'baz'],
            },
        }
    }

    templar = Templar(loader=None, variables=None)
   

# Generated at 2022-06-23 07:11:44.275452
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host = Host(name='host1')
    hosts = [host]
    var_mgr = VariableManager()
    inventory = {'hosts': hosts, '_meta': {'hostvars': {}}}
    var_mgr = VariableManager(loader=loader, inventory=inventory)


    # test_Taggable_evaluate_tags_defaults: default values of only_tags and skip_tags
    #   Taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    #   -> returns True
    default_skip_tags = None
    default_only_tags = None

# Generated at 2022-06-23 07:11:45.127458
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()

# Generated at 2022-06-23 07:11:47.400487
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:11:51.673434
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        pass

    test_object = TestClass()
    assert test_object.tags == ['untagged']

    test_object.tags = ['test']
    assert test_object.tags == ['test']

# Generated at 2022-06-23 07:12:01.364166
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        def __init__(self):
            self._tags = ['tagged', 'tags', 'notag']
            self._loader = None

    def _test(only_tags, skip_tags, expected, **kwargs):
        taggable = MockTaggable()
        all_vars = kwargs.get('all_vars', {})
        got = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
        assert expected == got, "'%s' != '%s'" % (expected, got)

    # Unit test for method evaluate_tags
    #   only_tags
    #       always
    #           'always' in tags
    #           tags != self.untagged
    #       all and never not in tags
    #       not tags

# Generated at 2022-06-23 07:12:05.275108
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Test that the Taggable class defaults to the always tag when
    it is not explicitly marked.
    """
    class MyTaggable(Taggable):
        pass

    m = MyTaggable()
    assert 'always' in m.tags

# Generated at 2022-06-23 07:12:15.242888
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
    def _test_expected_result(tags, only_tags=None, skip_tags=None, expected=True):
        assert DummyTaggable(tags=tags).evaluate_tags(only_tags, skip_tags, {}) == expected
    # Tasks with no tags always run
    _test_expected_result(None)
    _test_expected_result([])

    # Tasks that aren't skipped always run
    _test_expected_result(None, skip_tags=['never'])
    _test_expected_result([], skip_tags=['never'])
    _test_expected_result(['test'], skip_tags=['never'])

    # If only given empty list, no

# Generated at 2022-06-23 07:12:25.816402
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(only_tags=["all"], skip_tags=["always"], all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=["all"], skip_tags=[], all_vars={}) == True
    assert Taggable().evaluate_tags(only_tags=["all"], skip_tags=["all"], all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=["always"], all_vars={}) == True
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=["always", "all"], all_vars={}) == True
    assert Taggable().evaluate_tags(only_tags=["all"], skip_tags=["all"], all_vars={}) == False
    assert Tagg

# Generated at 2022-06-23 07:12:29.568640
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable(loader=None, constructor_data={ 'tags': ['foo','bar'] })
    assert t.tags == ['foo','bar']

# Generated at 2022-06-23 07:12:38.068972
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import PlayBase
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # We don't need templar for unit test
    class FakeTemplar():
        def template(self, tags):
            return tags

    # We don't need loader for unit test
    class FakeLoader():
        pass

    # mock of class Taggable
    class MockTaggable(Taggable):
        def __init__(self):
            self.task = 'task'
            self.parents = []
            self._loader = FakeLoader()


    # only_tags and skip_tags are both {}
    test_play = PlayBase()

# Generated at 2022-06-23 07:12:47.413788
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    # none
    assert t._load_tags('tags', None) == []
    # empty list
    assert t._load_tags('tags', []) == []
    # list of list
    assert t._load_tags('tags', [['one','two'],['three','four','five']]) == ['one','two','three','four','five']
    # list of one element
    assert t._load_tags('tags', ['one']) == ['one']
    # list of one element with nested list
    assert t._load_tags('tags', ['one', ['three','four','five']]) == ['one', 'three','four','five']
    # single element list
    assert t._load_tags('tags', ['one','two']) == ['one','two']
    # string
    assert t._

# Generated at 2022-06-23 07:12:52.750321
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # All items should be skipped
    taggable.tags = ['never']
    assert taggable.evaluate_tags(only_tags={'tagged'}, skip_tags={'all'}, all_vars={}) == False

    # All items should be skipped
    taggable.tags = ['never']
    assert taggable.evaluate_tags(only_tags={'tagged'}, skip_tags={'tagged'}, all_vars={}) == False

    # All items should be skipped
    taggable.tags = ['never']
    assert taggable.evaluate_tags(only_tags={'tagged'}, skip_tags={'always'}, all_vars={}) == False

    # This item should be skipped
    taggable.tags = ['never', 'mytag']


# Generated at 2022-06-23 07:12:56.113534
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable().tags == []
    assert Taggable().tags == Taggable(_tags=[]).tags
    assert Taggable(_tags=['a', 'b']).tags == ['a', 'b']
    assert Taggable(_tags=['a', 'b', 'c']).tags == ['a', 'b', 'c']

# Generated at 2022-06-23 07:13:07.946279
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class mock_obj(Taggable):
        pass

    test_obj = mock_obj()
    test_obj.tags = None
    # Test 1
    result = test_obj.evaluate_tags(only_tags = set(['tag1', 'tag2']), skip_tags = set(['tag3']), all_vars = dict())
    assert result == True

    # Test 2
    result = test_obj.evaluate_tags(only_tags = set(['tag1', 'tag2', 'tag3']), skip_tags = set(['tag3']), all_vars = dict())
    assert result == False

    # Test 3
    test_obj.tags = set(['tag2', 'tag3'])

# Generated at 2022-06-23 07:13:20.585158
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class SampleTaggable(Taggable):
        _loader = object()

    class EmptySampleTaggable(Taggable):
        _loader = object()
        tags = []

    import pytest
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    # test for no tags
    s = SampleTaggable()
    result = s.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True
    
    # test for tags of 'all'
    only_tags.add('all')
    s = SampleTaggable()
    result = s.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-23 07:13:22.119340
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-23 07:13:32.055870
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.module_utils._text import to_text

    # test all combinations of 'only_tags' and 'skip_tags' with
    # 'tags' a list of list of strings

# Generated at 2022-06-23 07:13:32.879791
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableTest(Taggable):
        pass
    testcase = TaggableTest()

    assert testcase._tags == []

# Generated at 2022-06-23 07:13:40.984836
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    task = Task.load(dict(name='example task', action=dict()), dataloader=dataloader)
    # task has no tags attribute yet
    assert not hasattr(task, 'tags')
    # create Taggable object with class Task
    taggable = Taggable(task, loader=dataloader)
    # now task has also tags attribute
    assert hasattr(task, 'tags')

# Generated at 2022-06-23 07:13:49.169073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    taggable = TestTaggable()
    all_vars = dict()

    taggable.tags = ['bar', 'baz']
    assert(taggable.evaluate_tags(set(['bar']), set(), all_vars) == True)
    assert(taggable.evaluate_tags(set(['bar']), set(['baz']), all_vars) == False)

    taggable.tags = ['bar', 'baz']
    assert(taggable.evaluate_tags(set(['all']), set(), all_vars) == True)
    assert(taggable.evaluate_tags(set(['all']), set(['bar']), all_vars) == False)


# Generated at 2022-06-23 07:13:51.784789
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

    obj = Taggable(tags='one,two')
    assert obj._tags == ['one','two']


# Generated at 2022-06-23 07:13:58.103832
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass():
        def __init__(self, tags=None):
            self.tags = tags
            self.tags = Taggable().validate_tags(self.tags)
        def get_tags(self):
            return self.tags
    myTaggedTask = TestClass()
    myTaggedTask_with_tags = TestClass(['A', 'B'])
    assert myTaggedTask.get_tags() == False
    assert myTaggedTask_with_tags.get_tags() == ['A', 'B']

# Generated at 2022-06-23 07:14:04.558295
# Unit test for constructor of class Taggable
def test_Taggable():
    data = dict()
    data['tags'] = ['demo','tag']
    only_tags = ['demo']
    skip_tags = []
    all_vars = dict()
    data2 = Taggable()
    x = data2.evaluate_tags(only_tags, skip_tags, all_vars)
    assert (x == True)

# Generated at 2022-06-23 07:14:11.738670
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    t = Taggable()
    assert(t._tags == [])

    task = Task.load(dict(name="test", action=dict(module="ping"), tags=['foo', 'bar']))
    assert(task._tags == ['foo', 'bar'])

    task = Task.load(dict(name="test", action=dict(module="ping"), tags=[['foo', 'bar']]))
    assert(task._tags == ['foo', 'bar'])

# Generated at 2022-06-23 07:14:22.022325
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.template
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    class TestObject(Taggable):
        def __init__(self, *args, **kwargs):
            super(TestObject, self).__init__(*args, **kwargs)
            self._tags = []

    loader = DataLoader()
    all_vars = VariableManager()
    inventory = InventoryManager(loader=loader, variables=all_vars)
    testObj = TestObject(play=None, loader=loader, inventory=inventory, variable_manager=all_vars)

    testObj.tags = ['always']

# Generated at 2022-06-23 07:14:34.142044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # note: 'include_role' class inherits from Taggable
    #       therefore, 'include_role' instance has Taggable attributes and methods
    include_role = IncludeRole()

    #
    # TESTS
    #

    # SPECIFIC TAGS
    # 1) 'only_tags' is specified, 'skip_tags' is NOT specified
    #    1.1) 'tags' is specified, 'skip_tags' is NOT specified
    #    1.2) 'tags' is NOT specified, 'skip_tags' is NOT specified
    # 2) 'skip_tags' is specified, 'only_tags' is NOT specified
    #    2.1) 'tags' is specified, 'only_tags' is NOT specified
    #    2.2) 'tags' is NOT specified, 'only_tags' is NOT specified
    # 3

# Generated at 2022-06-23 07:14:37.863555
# Unit test for constructor of class Taggable
def test_Taggable():
	assert Taggable._load_tags('_tags', ['tag']) == ['tag']
	assert Taggable._load_tags('_tags', 'tag') == ['tag']

test_Taggable()

# Generated at 2022-06-23 07:14:48.741548
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

    # following tasks uses tags attribute
    t1 = Task()
    t1.tags = ['t1_1', 't1_2']

    t2 = Task()
    t2.tags = ['t2_1', 't2_2']

    t3 = Task()
    t3.tags = ['always']

    t4 = Task()
    t4.tags = ['never']

    t5 = Task()
    t5.tags = ['t5_1', 'never']

    b = Block()


# Generated at 2022-06-23 07:14:50.822671
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert t is not None

# Generated at 2022-06-23 07:14:56.786256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake class for the test
    class TaggableClass:
        name = ""
        tags = []
        def get_name(self):
            return self.name
        def set_name(self, name):
            self.name = name
        def get_tags(self):
            return self.tags
        def set_tags(self, tags):
            self.tags = tags
        name = property(get_name, set_name)
        tags = property(get_tags, set_tags)

# Generated at 2022-06-23 07:14:59.854938
# Unit test for constructor of class Taggable
def test_Taggable():
    class Test(Taggable):
        pass

    t = Test()
    assert t._tags == []


# Generated at 2022-06-23 07:15:11.615166
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeObject(Taggable):
        def __init__(self, tags):
            self.tags = tags
    obj = FakeObject(tags=['tag1', 'tag2'])
    assert obj.evaluate_tags(['tag1'], ['tag2'], None) == True
    assert obj.evaluate_tags(['tag2'], ['tag1'], None) == True
    assert obj.evaluate_tags(['tag1', 'tag2'], ['tag2', 'tag1'], None) == True
    assert obj.evaluate_tags(['tag1', 'tag2'], ['tag2', 'tag1'], None) == True

    assert obj.evaluate_tags(['tag3'], ['tag1'], None) == False
    assert obj.evaluate_tags(['tag1'], ['tag3'], None) == True

# Generated at 2022-06-23 07:15:21.733023
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Task as Handler

    p = Play().load(dict(
        name = 'foo',
        hosts = 'all',
        gather_facts = 'no',
        tags = ['always', 'untagged'],
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out', tags=['untagged']),
            dict(action=dict(module='shell', args='whoami'), register='shell_out', tags=['untagged']),
            dict(action=dict(module='shell', args='id'), register='shell_out', tags=['untagged']),
        ]
    ))

    # Constructor:

# Generated at 2022-06-23 07:15:33.794187
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=None, host_list=[])
    block = Block()
    host = Host(name='test_host')
    group = Group(name='test_group')
    inventory.add_host(host)
    inventory.add_group(group)
    block.set_loader(loader=loader)
    block.set_inventory(inventory)
    taggable_obj = Taggable()
    taggable_obj.set_loader(loader=loader)
    taggable_obj.set_

# Generated at 2022-06-23 07:15:43.743684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggableClass(Taggable):
        def __init__(self, loader, tags):
            self._loader = loader
            self.tags = tags

    all_vars = dict(
        foo = "1"
    )

    class MockLoader:
        pass

    loader = MockLoader()
    taggable = MockTaggableClass(loader, ["foo"])
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars=all_vars)
    assert taggable.evaluate_tags(only_tags=["foo"], skip_tags=[], all_vars=all_vars)
    assert not taggable.evaluate_tags(only_tags=[], skip_tags=["foo"], all_vars=all_vars)
    assert not taggable.evaluate

# Generated at 2022-06-23 07:15:46.182153
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    print(taggable.tags)

if __name__ == '__main__':
    test_Taggable()