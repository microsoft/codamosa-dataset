

# Generated at 2022-06-23 07:05:46.220639
# Unit test for constructor of class Taggable
def test_Taggable():
    module = Taggable()
    assert module._tags == []

# Generated at 2022-06-23 07:05:54.435718
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from collections import namedtuple
    TestResult = namedtuple('TestResult', ['input', 'expected'])

    taggable = Taggable()
    taggable._loader = object()


# Generated at 2022-06-23 07:06:01.525937
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    task = Task()

    # tags is a list of strings
    task.tags = ['all', 'never', 'tagged']
    assert task.evaluate_tags(['all', 'tagged'], [], {})
    assert not task.evaluate_tags([], ['all', 'tagged'], {})

    task.tags = ['all', 'never', 'tagged']
    assert task.evaluate_tags(['all', 'tagged'], ['never'], {})
    assert not task.evaluate_tags([], ['never'], {})

    # tags is a string
    task.tags = 'all,never,tagged'
    assert task.evaluate_tags(['all', 'tagged'], [], {})

# Generated at 2022-06-23 07:06:14.407208
# Unit test for constructor of class Taggable
def test_Taggable():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # create mock class
    MockTaggable = namedtuple('MockTaggable', 'tags')
    mock_taggable = MockTaggable(tags=['foo', 'bar'])

    assert mock_taggable.tags == ['foo', 'bar']
    mock_taggable._loader = loader
    mock_taggable.evaluate_tags(['foo', 'bar'], [], {})

    assert mock_taggable.tags == ['foo', 'bar']

    # test_tags_template is None
    mock_taggable.tags = None
    mock_taggable.evaluate

# Generated at 2022-06-23 07:06:16.972957
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    assert type(t.tags) == list
    assert t.tags == []

# Generated at 2022-06-23 07:06:28.271705
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableClass(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)


    taggable = TaggableClass()

    # ansible_taggable._load_tags() is tested for correct loading of tags in the test of attribute.py
    taggable._load_tags('tags', ["untagged", "test_tag"])
    taggable._load_tags('tags', "untagged, test_tag")
    taggable._load_tags('tags', "untagged")

    should_run = taggable.evaluate_tags(["all"], [], {})
    assert(should_run)

    should_run = taggable.evaluate_tags([], [], {})
    assert(should_run)

    should_run

# Generated at 2022-06-23 07:06:38.305594
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:06:48.676770
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    # setup
    t = TaskInclude()
    a = AnsibleError('an error')
    t._loader = True
    t._variable_manager = True

    # no tags given, should run
    t.tags = None
    assert t.evaluate_tags(None, None, {}) == True

    # no tags given, should not run
    t.tags = None
    assert t.evaluate_tags(['all'], None, {}) == False

    # one tag given, should run
    t.tags = ['foo']
    assert t.evaluate_tags(None, None, {}) == True

    # one tag given, should not run
    t.tags = ['foo']

# Generated at 2022-06-23 07:06:59.836842
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # tags set to empty string is same as tags not set at all, which is same as tags set to untagged
    def assert_untagged(only_tags, skip_tags, tags, untagged, should_run):
        class MyTaggable(Taggable): pass

        # mocking _loader with a class of dummy return ''
        def dummy(): return ''
        MyTaggable._loader = dummy

        t = MyTaggable()
        t.tags = tags
        r = t.evaluate_tags(only_tags, skip_tags, {})
        assert r == should_run, "expected %s is same as tags set to '%s'" % (should_run, untagged)
        pass

    assert_untagged([], [], None, 'untagged', True)

# Generated at 2022-06-23 07:07:02.118780
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()


# Generated at 2022-06-23 07:07:08.278903
# Unit test for constructor of class Taggable
def test_Taggable():
    load_tags = ['test_load_tags']
    _tags = ['test_tags']
    templar = Templar(loader=None, variables=None)

    t = Taggable()
    assert t.tags == []
    assert t._load_tags('tags', load_tags) == ['test_load_tags']
    assert t.evaluate_tags('tag_only', 'tag_skip', 'all_vars') == True
    assert t.tags == []

# Generated at 2022-06-23 07:07:10.212875
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:07:20.725737
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    from ansible.template import Templar
    from ansible.vars import VariableManager

    ########################
    #### initialize everything
    playbook = ansible.playbook.PlayBook(
        playbook='/tmp/ansible_test',
        host_list='/tmp/ansible_test',
        module_path=None,
        loader=None,
        variable_manager=VariableManager(),
        stdout_callback='default',
    )
    variable_manager = playbook.variable_manager
    variable_manager.extra_vars = {'hostvars': {'localhost': {}}}
    templar = Templar(loader=playbook._loader, variables=variable_manager.get_vars(play=None, host=None, task=None))

    ########################
    # test some tag specifications


# Generated at 2022-06-23 07:07:22.861405
# Unit test for constructor of class Taggable
def test_Taggable():
    t=Taggable()
    t._tags=["a","b","c"]
    print(t.tags)

# Generated at 2022-06-23 07:07:26.015591
# Unit test for constructor of class Taggable
def test_Taggable():
    test_obj = Taggable()
    assert test_obj.tags == []
    assert test_obj._tags == list

# Generated at 2022-06-23 07:07:34.481145
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTask(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None # For unit test

    task = FakeTask(['foo', 'bar'])
    assert task.evaluate_tags(['foo'], [], {})
    assert not task.evaluate_tags(['foo', 'bar'], [], {})
    assert not task.evaluate_tags(['foo', 'bar'], ['foo', 'bar'], {})
    assert not task.evaluate_tags(['foo', 'bar'], ['all'], {})
    assert not task.evaluate_tags(['foo', 'bar'], ['tagged'], {})

    task = FakeTask(['foo', 'untagged'])
    assert task.evaluate_tags([], ['untagged'], {})
    assert task

# Generated at 2022-06-23 07:07:47.556426
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.async_task import AsyncTask
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    from ansible.utils.vars import combine_vars

# Generated at 2022-06-23 07:07:56.115888
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager

    # Note: this is a very basic test to check if tags are properly
    #       evaluated. More tests are needed to cover all possible cases.
    #       If tags are not properly evaluated, the TaskQueueManager will
    #       crash because it relies on the results of this function.

    host = InventoryManager(loader=None, sources=None).get_host('localhost')
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=None, sources=None))


# Generated at 2022-06-23 07:08:03.742311
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    # Taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    # 1.
    #   1.1 True when no tags are specified
    taggable = Taggable()
    taggable.tags = None
    assert taggable.evaluate_tags(None, None, None) is True

    #   1.2 True when 'all' is in only_tags
    assert taggable.evaluate_tags(['all'], None, None) is True

    #   1.3 True when 'tagged' is in only_tags
    assert taggable.evaluate_tags(['tagged'], None, None) is True

    #   1.4 False when 'tagged' is in skip_tags

# Generated at 2022-06-23 07:08:06.281349
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj is not None
    assert obj.tags == []

# Generated at 2022-06-23 07:08:16.232558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def mock_current_task(self, attr, ds):
        return 'current'

    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    taggable = MockTaggable(None)

    # check always tag
    only_tags = ['always']
    skip_tags = []
    taggable.tags = ['always']
    assert taggable.evaluate_tags(only_tags, skip_tags, None)

    # check all tag
    taggable.tags = ['foo', 'bar', 'baz']
    assert taggable.evaluate_tags(only_tags, skip_tags, None)

    # check never tag
    taggable.tags = ['never']

# Generated at 2022-06-23 07:08:17.414537
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()


# Generated at 2022-06-23 07:08:27.232946
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    t = Taggable()
    b = Base()
    assert t._tags == list
    assert t.tags == []
    assert t.untagged == frozenset(['untagged'])
    assert t.evaluate_tags(None, None, None) == True
    t.tags = ['lala', 'hoho']
    assert t.tags == ['lala', 'hoho']
    assert t.evaluate_tags(['hoho'], None, None) == True
    assert t.evaluate_tags(['lala'], ['hoho'], None) == True
    assert t.evaluate_tags(['lolo', 'hoho'], ['haha'], None) == True
    assert t.evaluate_tags(['mumu'], None, None) == False
    assert t

# Generated at 2022-06-23 07:08:37.326385
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    class Taggable_ut(Taggable):
        pass

    # Define class variables that are required or need to be initialised in the unit test
    class Taggable_ut_vars(object):
        def __init__(self):
            self._loader = None
            self.tags = []

    taggable = Taggable_ut()
    taggable.__dict__ = Taggable_ut_vars().__dict__

    # Test 1: Test the default case
    all_vars = {}
    only_tags = None
    skip_tags = None

    # Define the expected result
    expected_result = True

    res = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # Check if the unit test result and the expected result are the same

# Generated at 2022-06-23 07:08:48.356327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    block = Block()
    task  = Task()
    task._parent = block
    block._attributes['tags'] = ['a', 'b']

    task._attributes['tags'] = ['c', 'd']

    task._attributes['always_run'] = True
    assert task.evaluate_tags(only_tags=[], skip_tags=[])
    task._attributes['always_run'] = False

    assert task.evaluate_tags(only_tags=[], skip_tags=[])
    assert task.evaluate_tags(only_tags=['c'], skip_tags=[])
    assert task.evaluate_tags(only_tags=['c', 'd'], skip_tags=[])

# Generated at 2022-06-23 07:08:54.017867
# Unit test for constructor of class Taggable
def test_Taggable():
    import unittest
    class TaggableTest(unittest.TestCase):
        def test_Taggable(self):
            taggable = Taggable()
            self.assertIsInstance(taggable, Taggable)
            #self.assertEqual(taggable.tags, [])

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:08:57.439701
# Unit test for constructor of class Taggable
def test_Taggable():

  class test_class_1(Taggable):
    pass

  test_obj = test_class_1()
  assert test_obj._tags == [], "_tags variable of class Taggable not initializated correctly"

# Generated at 2022-06-23 07:08:58.753203
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    # Initial Value
    assert obj._tags == []

# Generated at 2022-06-23 07:09:00.846933
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    obj.tags = ['tag1', 'tag2']
    should_run = obj.evaluate_tags([], ['tag1', 'tag3'], {})
    assert should_run == True

# Generated at 2022-06-23 07:09:13.735878
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
    # this is to ensure the self._loader is available
    obj = TestTaggable(tags=['foo', 'bar'])

# Generated at 2022-06-23 07:09:19.572356
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags(None, 'a,b,c')    == ['a', 'b', 'c']
    assert t._load_tags(None, ['a', 'b']) == ['a', 'b']
    try:
        assert t._load_tags(None, 1)
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:09:27.891844
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        pass
    tc1 = TestClass()
    assert tc1._tags == []
    tc2 = TestClass(tags=['foo', 'bar'])
    assert tc2._tags == ['foo', 'bar']
    tc3 = TestClass(tags='foo,bar')
    assert tc3._tags == ['foo', 'bar']
    kb = dict(
        _ds={
            'tags': [1,2,3],
            },
        )
    tc4 = TestClass(**kb)
    assert tc4._tags == [1,2,3]
    tc5 = TestClass(tags=['foo', 1, 2, 3, 4])
    assert tc5._tags == ['foo', 1, 2, 3, 4]

# Generated at 2022-06-23 07:09:40.091905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test for a true result
    class test_class(Taggable):
        tags = ['a','b','c']
        pass
    test_instance=test_class()
    result=test_instance.evaluate_tags(only_tags=['a','b'],skip_tags=['d','e'],all_vars=[])
    assert result==True
    # test for a true result with list as input for only_tags and skip_tags
    result=test_instance.evaluate_tags(only_tags=['a','b','f','g'],skip_tags=['d','e','h','i'],all_vars=[])
    assert result==True
    # test for a false result

# Generated at 2022-06-23 07:09:50.269266
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requiremenst import RoleRequirement

    t = Play()
    for i in ('all', 'tagged', 'never', 'always'):
        assert t.evaluate_tags(i, None, None)
        assert t.evaluate_tags(None, i, None)
    assert not t.evaluate_tags(None, None, None)

    t = Task()
    t.tags=[1,2]
    assert t.evaluate_tags(['all', 'tagged'], None, None)
    assert not t.evaluate_tags(['never'], None, None)

# Generated at 2022-06-23 07:09:59.512948
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible import context
    import json

    # class to load plugins
    class TestModule:
        def __init__(self, filename):
            self.filename = filename
            self.__name__ = os.path.splitext(os.path.basename(self.filename))

# Generated at 2022-06-23 07:10:02.513566
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Basic constructor test.
    """
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-23 07:10:11.758005
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tb = Taggable()
    tb.tags = ['tag1', 'tag2']
    assert tb.evaluate_tags(['tag1'], [], {})
    assert tb.evaluate_tags([], [], {})

    tb.tags = ['always', 'tag1', 'tag2']
    assert tb.evaluate_tags([], [], {})

    tb.tags = ['always', 'tag1', 'tag2']
    assert tb.evaluate_tags(['always'], [], {})

    tb.tags = ['tag1', 'tag2']
    assert tb.evaluate_tags(['tag1'], [], {})
    assert tb.evaluate_tags(['tag1', 'tag2'], [], {})

    tb.tags = ['tag1', 'tag2']


# Generated at 2022-06-23 07:10:13.291790
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-23 07:10:24.493115
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible import utils

    test_only_tags = frozenset(['always', 'test_tag', 'tagged'])
    test_skip_tags = frozenset(['test_skip_tag'])
    test_tags_value = ['test_tag']
    test_tags = frozenset(test_tags_value)
    test_tags_value_2 = ['test_tag_2']
    test_tags_2 = frozenset(test_tags_value_2)
    test_tags_value_3 = ['always']
    test_tags_3 = frozenset(test_tags_value_3)


# Generated at 2022-06-23 07:10:36.414906
# Unit test for constructor of class Taggable
def test_Taggable():
    import tempfile
    import os
    inv_file = tempfile.mktemp(prefix='ansible_test_inventory')
    with open(inv_file, 'w') as f:
        f.write("[test_group]\n")
        f.write("localhost ansible_connection=local\n")

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    t = Taggable()
    t.tags = ['my_tag']
    assert t.tags == ['my_tag']
    t.tags = 1
    assert t.tags == ['1']
    t.tags = None
    assert t.tags == []

    pc = PlayContext()

# Generated at 2022-06-23 07:10:47.122917
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableSub(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    assert TaggableSub().evaluate_tags(only_tags=['always'], skip_tags=['never'], all_vars={}) is False
    assert TaggableSub().evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={}) is True
    assert TaggableSub().evaluate_tags(only_tags=['all'], skip_tags={}, all_vars={}) is True
    assert TaggableSub().evaluate_tags(only_tags=['tagged'], skip_tags=['never'], all_vars={}) is False


# Generated at 2022-06-23 07:10:53.383978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Thing(Taggable):
        pass

    t = Thing()
    t.tags = ['a','b','c','always','never','not_run','run','tagged','3']
    # test with only_tags, skip_tags empty
    ret1=t.evaluate_tags([], [], {})
    assert ret1 == True
    # Test with only_tags empty, skip_tags non empty
    ret2 = t.evaluate_tags([], ['always'], {})
    assert ret2 == False
    # Test with only_tags, skip_tags both non empty
    ret3 = t.evaluate_tags(['a'], ['b'], {})
    assert ret3 == True
    # Test with only_tags
    ret4 = t.evaluate_tags(['a'], [], {})
    assert ret4 == True


# Generated at 2022-06-23 07:11:03.850156
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    hosts = [Host(name='host0'),Host(name='host1'),Host(name='host2')]
    hosts[0].vars = {'group_names': ['group0']}
    hosts[1].vars = {'group_names': ['group0', 'group1']}
    hosts[2].vars = {'group_names': ['group1']}
    groups = [Group(name='group0'),Group(name='group1')]
    groups[0].vars

# Generated at 2022-06-23 07:11:14.372366
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestObj(Taggable):
        def __init__(self, tags, name):
            self.tags = tags
            self.name = name
        def __str__(self):
            return "<obj %s>"%(self.name)

    # Create objects to test
    obj1 = TestObj([], 'obj1')
    obj2 = TestObj(['tag1'], 'obj2')
    obj3 = TestObj(['tag1', 'tag2'], 'obj3')
    obj4 = TestObj(['tag2', 'tag3'], 'obj4')
    obj5 = TestObj(['never'], 'obj5')
    obj6 = TestObj(['always'], 'obj6')

    # List of tests 

# Generated at 2022-06-23 07:11:15.917466
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:11:25.501737
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    obj.tags = ['tag1', 'tag2']
    assert obj.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True
    assert obj.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True
    assert obj.evaluate_tags(only_tags=[], skip_tags=['tag1'], all_vars={}) == True
    assert obj.evaluate_tags(only_tags=[], skip_tags=['tag2'], all_vars={}) == True
    assert obj.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True

# Generated at 2022-06-23 07:11:36.270841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task_include as task_include
    task_include.TaskInclude._load_tags = Taggable._load_tags
    task_include.TaskInclude.evaluate_tags = Taggable.evaluate_tags

    task = task_include.TaskInclude()
    task._parent = task_include.TaskInclude()

    task.tags = ["foo", "bar", "always"]
    task.only_tags = ["all"]
    assert task._parent.evaluate_tags(task.only_tags, None, {}) == True

    task.tags = ["foo", "bar", "always"]
    task.only_tags = ["always"]
    assert task._parent.evaluate_tags(task.only_tags, None, {}) == True

    task.tags = ["foo", "bar", "always"]
    task

# Generated at 2022-06-23 07:11:48.799549
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Define a Dummy class to test Taggable
    class Dummy(Taggable):
        pass

    dummy = Dummy()

    # Check if tag 'always' will result in task execution
    dummy.tags = ['always']
    assert dummy.evaluate_tags(False, False, {})

    # Check if a task without tags will be skipped
    dummy.tags = []
    assert dummy.evaluate_tags(False, False, {})

    # Check if option 'targed' will result in task execution
    dummy.tags = ['foobar']
    assert dummy.evaluate_tags(['tagged'], False, {})

    # Check if option 'tagged' will skip a task
    dummy.tags = []
    assert not dummy.evaluate_tags(['tagged'], False, {})

    # Check if option 'all' will

# Generated at 2022-06-23 07:11:50.657432
# Unit test for constructor of class Taggable
def test_Taggable():
    host = Taggable()
    host._tags = ['hello']
    assert(host.tags == ['hello'])

# Generated at 2022-06-23 07:12:00.444736
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    class TestClass(Base, Taggable):
        _testfield = "testvalue"

    test = TestClass()
    assert test._tags == list
    assert test._load_tags("[ 'one', 'two' ]", None) == [ 'one', 'two' ]
    assert test._load_tags("[ 'one' ]", None) == [ 'one' ]
    assert test._load_tags("one", None) == [ 'one' ]
    assert test._load_tags("one,two", None) == [ 'one', 'two' ]
    try:
        test._load_tags(1, None)
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-23 07:12:01.805397
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-23 07:12:05.915102
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    #Create a new task
    t = Task()
    assert t._load_tags == Taggable._load_tags
    assert t.evaluate_tags == Taggable.evaluate_tags

# Generated at 2022-06-23 07:12:14.935041
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableClass(Taggable):
        def __init__(self):
            self.tags = [[1,2,3], ['a', 'b', 'c']]

    tc = TaggableClass()
    assert isinstance(tc.tags, list)
    assert isinstance(tc.tags[0], list)
    assert isinstance(tc.tags[1], list)
    assert tc._load_tags('tags', [1,2,3]) == [1,2,3]
    assert tc._load_tags('tags', '1,2,3') == ['1', '2', '3']
    assert tc._load_tags('tags', ['1,2,3']) == ['1,2,3']

# Generated at 2022-06-23 07:12:25.117726
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    Taggable.tags = ['always']
    assert Taggable.evaluate_tags(['always'], ['never'], {'bla': 'bla'}), 'Failed 1'

    Taggable.tags = ['never']
    assert not Taggable.evaluate_tags(['bla'], ['never'], {'bla': 'bla'}), 'Failed 2'

    Taggable.tags = ['bla']
    assert Taggable.evaluate_tags(['bla'], ['never'], {'bla': 'bla'}), 'Failed 3'

    Taggable.tags = ['blo']
    assert not Taggable.evaluate_tags([], ['bla'], {'bla': 'bla'}), 'Failed 4'

    Taggable.tags = ['bla']

# Generated at 2022-06-23 07:12:37.296699
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._load_tags('tags', '[foo, bar, baz]')
    assert t.tags == ['foo', 'bar', 'baz']
    t.tags = 'foo, bar, baz'
    assert t._tags == ['foo', 'bar', 'baz']
    t._load_tags('tags', 'foo, bar, baz')
    assert t._tags == ['foo', 'bar', 'baz']
    t._load_tags('tags', 'foo, bar')
    assert t._tags == ['foo', 'bar']
    assert t.tags == ['foo', 'bar']
    t._load_tags('tags', 'foo')
    assert t._tags == ['foo']
    assert t.tags == ['foo']

# Generated at 2022-06-23 07:12:46.820358
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.attribute import Attribute

    class MyTaggable(Taggable):
        tags_attr = Attribute(isa='list', default=[], listof=(string_types, int))
        def __init__(self):
            self._tags_attr = []
        def _get_tags(self):
            return self._tags_attr
        def _set_tags(self, value):
            self._tags_attr = value
        tags = property(_get_tags, _set_tags)

    obj = MyTaggable()
    obj.tags = ['untagged']

    assert obj.evaluate_tags(['untagged', 'test1'], ['test2'], {}) is True
    assert obj.evaluate_tags([], [], {}) is True

# Generated at 2022-06-23 07:12:57.649948
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    _loader = DictDataLoader({})
    _all_vars = dict()
    _taggable = Taggable(loader=_loader)
    _taggable.tags = ['tag:1', 'tag:2', 'tag:3']
    # action:      only_tags/skip_tags ===> should_run
    # default
    # default      None                None      True
    # default      []                  None      True
    # default      None                []        True
    # default      []                  []        True
    # ('all' not in only_tags or 'never' not in skip_tags)
    # default      [all]               []         True
    # default      [all]               ['never'] True
    # default      [all]               ['never', 'all'] False
    # default      [all]               ['always', 'all']

# Generated at 2022-06-23 07:13:06.223476
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    assert(taggable._load_tags('_tags', 'hi') == ['hi'])
    assert(taggable._load_tags('_tags', ['hi']) == ['hi'])
    assert(taggable._load_tags('_tags', 'hi,ho') == ['hi', 'ho'])
    assert(taggable._load_tags('_tags', ['hi', 'ho']) == ['hi', 'ho'])
    assert(taggable._load_tags('_tags', []) == [])


# Generated at 2022-06-23 07:13:13.036392
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.playbook
    from ansible.playbook.task_include import TaskInclude
    task = TaskInclude()
    task.tags = []
    
    assert True == task.evaluate_tags(['all','always'], [], {}), \
        'ERROR: task Test1 should be executed'

    task.tags = ['never']
    assert False == task.evaluate_tags(['all','always'], [], {}), \
        'ERROR: task Test2 should not be executed'

    task.tags = ['never']
    assert True == task.evaluate_tags(['all','always'], ['never'], {}), \
        'ERROR: task Test3 should be executed'

    task.tags = ['always']

# Generated at 2022-06-23 07:13:22.569953
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():


    class TagTest:

        def __init__(self, att_tags):
            self.att_tags = att_tags

    my_tags = [ 'always', 'test-tag', 'test-tag-2' ]
    my_skip_tags = [ 'never' ]
    my_only_tags = [ 'test-tag', 'test-tag-2' ]
    my_all_vars = { 'test_var': 'test_var' }

    x = TagTest(att_tags=my_tags)
    x.tags = my_tags
    x.evaluate_tags(my_only_tags,my_skip_tags,my_all_vars)
    assert x.tags == my_tags

    tags = []
    skip_tags = []
    only_tags = []

# Generated at 2022-06-23 07:13:26.484070
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import RoleInclude
    t = Taggable()
    x = RoleInclude()
    assert x.tags == []
    assert t.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:13:34.576408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))))
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import DEFAULT_VAULTS_PATHS
    from ansible.utils.unsafe_proxy import UnsafeProxy, wrap_var

    # Create a fake module object that will be passed in to the constructor
    class FakeModule():
        pass
    fake_module = FakeModule()

# Generated at 2022-06-23 07:13:37.029543
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable, Taggable) == True

#test_Taggable()

# Generated at 2022-06-23 07:13:46.641246
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # default, only_tags=None and skip_tags=None: should run
    assert Taggable().evaluate_tags(None, None, None) == True
    # only_tags=[] and skip_tags=None: should run
    assert Taggable().evaluate_tags([], None, None) == True
    # only_tags=['tag1', 'tag2'] and skip_tags=None: should run
    assert Taggable().evaluate_tags(['tag1', 'tag2'], None, None) == True
    # only_tags=['tag1', 'tag2'] and skip_tags=[]: should run
    assert Taggable().evaluate_tags(['tag1', 'tag2'], [], None) == True
    # only_tags=None and skip_tags=[]: should run

# Generated at 2022-06-23 07:13:57.704881
# Unit test for constructor of class Taggable
def test_Taggable():
    class NewClass(Taggable):
        pass
    new_instance = NewClass()
    assert(new_instance.evaluate_tags([], [], {}) == True)
    assert(new_instance.evaluate_tags(['all'], [], {}) == True)
    assert(new_instance.evaluate_tags(['all'], [], {'tags': ['tag1']}) == True)
    assert(new_instance.evaluate_tags(['tag1'], [], {'tags': []}) == False)
    assert(new_instance.evaluate_tags(['tag1'], [], {'tags': ['tag1']}) == True)
    assert(new_instance.evaluate_tags(['tag1'], [], {'tags': ['tag1','tag2']}) == True)

# Generated at 2022-06-23 07:14:10.377378
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Test evaluation of Ansible task tags '''

    play = dict(
        name='test play',
        hosts='all',
        gather_facts='no',
        tags=['test-tag']
    )

    # Test 1: should_run with empty `only_tags` / `skip_tags`
    #         Should return True
    task = dict(
        name='test task',
        action='shell',
        args='whoami',
        register='whoami'
    )
    t = Taggable()
    t.tags = [ 'test-tag' ]
    result = t.evaluate_tags(None, None, play)
    assert result, 'return value should be `True`'

    # Test 2: should_run with `only_tags` = [ 'test-tag' ] / `skip_tags` = None


# Generated at 2022-06-23 07:14:13.126583
# Unit test for constructor of class Taggable
def test_Taggable():
    test_Taggable = Taggable()
    # Check the tags field
    assert isinstance(test_Taggable._tags, list)
    assert test_Taggable._tags == []
    # Check the constructor
    assert test_Taggable is not None
    
if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:14:23.185169
# Unit test for constructor of class Taggable
def test_Taggable():
    import copy
    import json
    import os
    import sys
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class ResultCallback:
        """A fake callback plugin used to test"""
        def v2_runner_on_ok(self, result, **kwargs):
            """Print a json representation of the result"""
            host = result._host

# Generated at 2022-06-23 07:14:24.050805
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-23 07:14:29.681250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass

    taggable = MockTaggable()
    taggable.tags = ['foo']

    assert not taggable.evaluate_tags(only_tags=set(['bar']), skip_tags=set(), all_vars={})
    assert taggable.evaluate_tags(only_tags=set(['foo', 'bar']), skip_tags=set(), all_vars={})
    assert taggable.evaluate_tags(only_tags=set(['all']), skip_tags=set(), all_vars={})
    assert taggable.evaluate_tags(only_tags=set(['tagged']), skip_tags=set(), all_vars={})


# Generated at 2022-06-23 07:14:40.876601
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task_include import TaskInclude

    Taggable.tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    tags = TaskInclude('test')
    tags.tags = ['t1', 't2', 't3']
    assert tags.evaluate_tags(only_tags=['t1'], skip_tags=None, all_vars={}) == True
    assert tags.evaluate_tags(only_tags=['t4'], skip_tags=None, all_vars={}) == False
    assert tags.evaluate_tags(only_tags=['t1', 't2'], skip_tags=None, all_vars={}) == True
    assert tags.evaluate

# Generated at 2022-06-23 07:14:51.099187
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.template import Templar


# Generated at 2022-06-23 07:15:00.015343
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_instance = Taggable()
    assert test_instance.evaluate_tags(['one'], ['two'], {}) == False
    assert test_instance.evaluate_tags(['one'], ['one'], {}) == False
    assert test_instance.evaluate_tags(['one'], ['three'], {}) == True
    assert test_instance.evaluate_tags(['two', 'one'], ['three'], {}) == True
    assert test_instance.evaluate_tags(['two', 'one'], ['three', 'one'], {}) == False
    assert test_instance.evaluate_tags(['two', 'one'], ['one'], {}) == False
    assert test_instance.evaluate_tags(['all'], ['three', 'one'], {}) == True

# Generated at 2022-06-23 07:15:02.272672
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)


# Generated at 2022-06-23 07:15:04.431382
# Unit test for constructor of class Taggable
def test_Taggable():
    class Myclass(Taggable):
        pass
    obj = Myclass()
    assert obj.tags == []

# Generated at 2022-06-23 07:15:07.887203
# Unit test for constructor of class Taggable
def test_Taggable():
    '''
    >>> t = Taggable()
    >>> t.tags = '''
    ['untagged']
    '''
    '''

# Generated at 2022-06-23 07:15:16.946768
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTaggable(Taggable):

        def __init__(self):
            self.vars = dict()
            self.tags = ['tag1', 'tag2']

    # Test for no tag
    taggable = FakeTaggable()
    assert taggable.evaluate_tags(None, None, taggable.vars) is True

    # Test for not running with --tags
    taggable = FakeTaggable()
    assert taggable.evaluate_tags(None, None, taggable.vars) is True
    assert taggable.evaluate_tags('', '', taggable.vars) is True

    # Test for evaluating --tags=tag1
    taggable = FakeTaggable()

# Generated at 2022-06-23 07:15:24.905556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest

    class TaggableTest(unittest.TestCase):

        def setUp(self):
            self.taggable_object = Taggable()

        def test_should_run_true_with_tags_for_only_tags(self):
            # Tags are present, but only_tags parameter is not specified
            # The method to check is self.evaluate_tags(only_tags = [], skip_tags = [])
            self.taggable_object.tags = ['tag1']
            self.assertTrue(self.taggable_object.evaluate_tags([], []))

        def test_should_run_false_with_only_tags(self):
            # Tags are present and only_tags parameter also present
            self.taggable_object.tags = ['tag1']

# Generated at 2022-06-23 07:15:35.236410
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import PlayBook
    from ansible.playbook.play_context import PlayContext

    play = PlayBook.load(dict(
        name = 'test',
        hosts = 'all',
        vars = {'abc': '123'},
        pre_tasks = '',
        roles = '',
        tasks = '',
        post_tasks = '',
    ), loader=None, variable_manager=None)

    play_context = PlayContext(play=play)

    print(play.get_vars())
    print(play_context.get_vars())


if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:15:43.948666
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest
    from ansible import context

    # Testing without tags to be skipped
    context.CLIARGS = {'skip_tags': []}
    # Testing tags with tags to be skipped
    context.CLIARGS = {'skip_tags': ['never', 'test']}

    # Testing tags with tags to be ran
    context.CLIARGS = {'tags': ['always', 'test']}

    # Testing tags with tags to be ran and tags to be skipped
    context.CLIARGS = {'tags': ['always', 'test'], \
                       'skip_tags': ['never', 'test']}

    # Testing tags with only_tags and skip_tags
    context.CLIARGS = {'only_tags': ['always', 'test'], \
                       'skip_tags': ['never', 'test']}