

# Generated at 2022-06-23 07:05:59.027433
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()

    # no tags, no only_tags, no skip_tags
    assert obj.evaluate_tags(None, None, None)
    assert obj.evaluate_tags([], [], None)

    # only_tags, no skip_tags, no tags
    assert not obj.evaluate_tags(['only_tag'], [], None)

    # only_tags, no skip_tags, tags
    obj.tags = ['only_tag']
    assert obj.evaluate_tags(['only_tag'], [], None)
    assert not obj.evaluate_tags(['only_tag1'], [], None)

    # no tags, skip_tags, no only_tags
    assert obj.evaluate_tags([], ['skip_tag'], None)

    # skip_tags, no only_tags, tags
    assert not obj

# Generated at 2022-06-23 07:06:01.296640
# Unit test for constructor of class Taggable
def test_Taggable():
        class Foo(Taggable):
            pass
        foo = Foo()
        assert(foo.tags==[])
        assert(hash(foo.untagged)==hash(frozenset([u'untagged'])))

# Generated at 2022-06-23 07:06:07.439209
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        x = Taggable()
        assert False
    except TypeError:
        pass

    assert isinstance(x._load_tags('tags', ['foo']), list)
    assert isinstance(x._load_tags('tags', 'foo'), list)
    try:
        assert isinstance(x._load_tags('tags', {'foo', 'bar'}), list)
        assert False
    except AnsibleError:
        pass

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:06:17.826893
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    
    all_vars = dict(foo='bar')
    loader = None
    
    # Set up a block
    block = Block()
    block._load_name('foo')
    block._load_tags(['bar'], 'foo')
    
    # Set up a task
    task = Task()
    task.when = dict()
    task._role = Role()
    task._role.vars = dict()
    task._load_name('foo')
    task._load_tags(['bar'], 'foo')
    task._parent = block

# Generated at 2022-06-23 07:06:25.081896
# Unit test for constructor of class Taggable
def test_Taggable():
    class Tagged(Taggable):
        def __init__(self):
            self.tags = ['tag1', 'tag2']
    tagged = Tagged()
    assert tagged.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) == True
    assert tagged.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=['tag2'], all_vars={}) == False

# Generated at 2022-06-23 07:06:30.529060
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._tags, FieldAttribute)
    assert taggable._tags.isa == 'list'
    assert taggable._tags.default == list
    assert taggable._tags.listof == (string_types, int)
    assert taggable._tags.extend == True
    assert taggable.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:06:31.928271
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == [], t._tags

# Generated at 2022-06-23 07:06:45.390086
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert not t.tags, 'Taggable class is not initialized'

    t = Taggable(tags=None)
    assert not t.tags, 'Taggable class is not initialized with None'

    t = Taggable(tags=[])
    assert not t.tags, 'Taggable class is not initialized with empty list'

    t = Taggable(tags=[1])
    assert t.tags == [1], 'Taggable class is not initialized with list of int'

    t = Taggable(tags='A')
    assert t.tags == ['A'], 'Taggable class is not initialized with single string'

    t = Taggable(tags='A, B')
    assert t.tags == ['A', 'B'], 'Taggable class is not initialized with string of multiple tags'



# Generated at 2022-06-23 07:06:47.551786
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert(a._tags == [])

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:06:58.917960
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    task = Task()
    task.tags = None
    task.only_tags = None
    task.any_tags = None

    # Test cases for evaluate_tags()

    # Test case 1: When all of only_tags, skip_tags and tags are set to None
    #              and the method evaluate_tags() is called, it should return True
    assert task.evaluate_tags(None, None, None) is True

    # Test case 2: When 'only_tags' is set to ['all'], 'skip_tags' and 'tags' are None
    #              and the method evaluate_tags() is called, it should return True
    task.only_tags = ['all']
    assert task.evaluate_tags(['all'], None, None) is True

    # Test case 3: If 'only

# Generated at 2022-06-23 07:07:10.175530
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils import variable_manager
    import sys

    class MyTaskInclude(TaskInclude, Taggable):
        def __init__(self, role=None, tasks=None, tags=None, name=None, play=None):
            TaskInclude.__init__(self, role=role, tasks=tasks, name=name, play=play)
            Taggable.__init__(self, tags=tags)

        def load_role_tasks(self):
            pass

    tags = ['sample', 'test']


# Generated at 2022-06-23 07:07:20.726045
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('Testing Taggable.evaluate_tags')
    # add some test data
    from ansible.playbook.task import Task

    t1 = Task()
    t1.name = 'task1'
    t1.tags = ['always']

    t2 = Task()
    t2.name = 'task2'
    t2.tags = ['bar']

    t3 = Task()
    t3.name = 'task3'
    t3.tags = ['foo']

    # construct expected results
    results = {}
    results[(t1, (), ())] = True
    results[(t1, (), ('ping',))] = True
    results[(t1, (), ('never',))] = False
    results[(t1, (), ('always',))] = True

# Generated at 2022-06-23 07:07:24.900742
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['tag1', 'tag2']

    only_tags = ['tag2', 'tag3']
    skip_tags = ['tag1', 'tag2']

    ans1 = Taggable().evaluate_tags(only_tags, skip_tags, None)
    ans2 = Taggable(tags=tags).evaluate_tags(only_tags, skip_tags, None)
    assert ans1 == True
    assert ans2 == False
    return True

# Generated at 2022-06-23 07:07:26.594197
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-23 07:07:34.678923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t._loader = None
    t.tags = ['all', 'never']

    assert t.evaluate_tags(['all'], [], {}) == True, "playbook should run, tags: ['all', 'never'], only_tags: ['all']"

    assert t.evaluate_tags(['all'], ['never'], {}) == False, "playbook should not run, tags: ['all', 'never'], only_tags: ['all'], skip_tags: ['never']"

    assert t.evaluate_tags(['all'], ['never'], {}) == False, "playbook should not run, tags: ['all', 'never'], only_tags: ['all'], skip_tags: ['never']"


# Generated at 2022-06-23 07:07:47.556254
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    all_vars = dict(
        tag1=[1, 2, 3],
        tag2=dict(
            tag21=[2, 1],
            tag22=set([2, 2])
        ),
        tag3=[2, 3, 1]
    )

    class Sprinkle(Taggable):
        def __init__(self, tag_list):
            self.tags = tag_list

    assert Sprinkle(['tag1', 'tag2', 'tag2.tag21']).evaluate_tags(['tag1', 'tag2', 'tag2.tag21'], None, all_vars) is True

# Generated at 2022-06-23 07:08:01.944446
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Mockup attributes of class Taggable

    t = Taggable()
    t._loader = "some object"
    t.tags = ["tag1", "tag2", "tag3"]
    t.name = "some name"

    # Case 1: only_tags == None && skip_tags == None
    all_vars = {}
    only_tags = []
    skip_tags = []
    assert t.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars) == True

    # Case 2: only_tags == "tag1" && skip_tags == None
    only_tags = ["tag1"]
    assert t.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars) == True

# Generated at 2022-06-23 07:08:12.726260
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(object):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int, list), extend=True)
        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
                if isinstance(value, list):
                    return [x.strip() for x in value]
                else:
                    return [ds]
            else:
                raise AnsibleError('tags must be specified as a list', obj=ds)
    tt = TestTaggable()
    assert tt.tags == []

test_Taggable()

# Generated at 2022-06-23 07:08:16.360379
# Unit test for constructor of class Taggable
def test_Taggable():

    test = Taggable()
    test.tags = ['tag1', 'tag2']

    assert test.tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:08:17.464903
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable is not None

# Generated at 2022-06-23 07:08:27.293865
# Unit test for constructor of class Taggable
def test_Taggable():

    # Test case with empty tag option
    t = Taggable()
    assert t.evaluate_tags(None, None, {}) == True
    assert t.evaluate_tags([], [], {}) == True

    # Test case with tag set to empty string
    t = Taggable()
    t._tags = ''
    assert t.evaluate_tags(None, None, {}) == True
    assert t.evaluate_tags([], [], {}) == True

    # Test case with tag set to empty list
    t = Taggable()
    t._tags = []
    assert t.evaluate_tags(None, None, {}) == True
    assert t.evaluate_tags([], [], {}) == True

    # Test case with tag set to untagged
    t = Taggable()
    t._tags = 'untagged'

# Generated at 2022-06-23 07:08:34.802933
# Unit test for constructor of class Taggable
def test_Taggable():
    tagString = 'test1,test2,test3'
    class TestTaggable(Taggable):
        _tags = tagString

    
    obj = TestTaggable()
    
    # Test that _load_tags(...) method is called when setting the _tags attribute
    assert(isinstance(obj._tags, list))
    assert(obj._tags == tagString.split(','))

# Should return True for:
#  - test3 is in tags and no skip_tags are specified
# False for:
#  - test1 is in skip_tags

# Generated at 2022-06-23 07:08:43.064901
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    # Create fake objects for play
    fake_play = dict(
        name = "fake play",
        hosts = "fake hosts",
        gather_facts = "fake gather_facts",
        serial = "fake serial",
        tasks = "fake tasks"
    )

    # Create fake task

# Generated at 2022-06-23 07:08:54.630786
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy(Taggable):
        tags = dict()
        _loader = dict()

    # default
    d = Dummy()
    assert d.evaluate_tags(only_tags=None, skip_tags=None, all_vars=dict()) is True

    # test only_tags
    d.tags = ['tag1', 'tag2']
    assert d.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars=dict()) is True
    assert d.evaluate_tags(only_tags=['tag2'], skip_tags=None, all_vars=dict()) is True
    assert d.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=None, all_vars=dict()) is True

# Generated at 2022-06-23 07:09:02.864909
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    from ansible.playbook.task import Task

    p = Play()
    t = Task()

    p.tasks = [t]
    p._loader = None

    assert p.tags == ['all']

    p.tags = ['foo']
    assert 'foo' in p.tags and len(p.tags) == 1

    t.tags = ['bar', 'baz']
    assert 'bar' in t.tags and 'baz' in t.tags and len(t.tags) == 2

    assert t.evaluate_tags([], [], []) is True
    assert t.evaluate_tags(['bar'], [], []) is True
    assert t.evaluate_tags([], ['baz'], []) is True
    assert t.evaluate_tags([], ['foo'], [])

# Generated at 2022-06-23 07:09:09.885146
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert type(taggable._tags) is list
    assert taggable.tags == []
    assert taggable.untagged == frozenset(['untagged'])
    assert taggable.evaluate_tags(None, None, None) == True
    assert taggable.evaluate_tags([], [], []) == True
    assert taggable.evaluate_tags("only_tags", "skip_tags", "all_vars") == True

# Generated at 2022-06-23 07:09:21.069975
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import yaml

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()

    path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'basic.yaml')

# Generated at 2022-06-23 07:09:25.131847
# Unit test for constructor of class Taggable
def test_Taggable():
    class AnsibleTaggable(Taggable):
        pass

    item = AnsibleTaggable()
    assert isinstance(item.tags, list)
    assert not item.tags

    item = AnsibleTaggable(tags=['example'])
    assert isinstance(item.tags, list)
    assert len(item.tags) == 1
    assert item.tags == ['example']

# Generated at 2022-06-23 07:09:34.845269
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import shutil
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    fake_play = dict(
        vars=dict()
    )

    # Create a dummy action plugin to load
    shutil.copyfile("lib/ansible/plugins/action/ping.py", "ping.py")
    action_loader._remove_plugin_dirs()
    action_loader.add_directory(".")

    # Create a fake Task object
    t = Task.load(dict(action="ping"), play=fake_play, variable_manager=None, loader=None)

    # Test 1: preserve default
    t._only_tags = frozenset(['tag1','tag2'])
    t._skip_tags = frozenset(['tag3','tag4'])

# Generated at 2022-06-23 07:09:36.441687
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:09:40.292494
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Taggable()
    assert t
    t.tags += ['test_tag']
    assert t.tags == ['test_tag']
    tt = Task()
    assert tt
    tt.tags += ['test_tag']
    assert tt.tags == ['test_tag']

# Generated at 2022-06-23 07:09:43.417418
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    assert taggable._tags == list()
    assert taggable.untagged == frozenset(['untagged'])


# Generated at 2022-06-23 07:09:56.075357
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    group = Group()
    group.tags = ['tag1', 'tag2', 'tag3']

    host = Host()
    host.tags = ['tag1', 'tag2', 'tag3']

    task = Task()
    task.tags = ['tag1', 'tag2', 'tag3']

    task_include = TaskInclude()
    task_include.tags = ['tag1', 'tag2', 'tag3']

    assert group.tags == ['tag1', 'tag2', 'tag3']
    assert host.tags == ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-23 07:09:58.880494
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert _load_tags(taggable) == []

# Generated at 2022-06-23 07:10:10.232598
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.include import Include
    from ansible.playbook.assignment import Assignment
    from ansible.playbook.conditional import Conditional
    import pytest
    # Test for class Task
    test_task_1 = Task()
    test_task_2 = Task()
    assert test_task_1.tags == test_task_2.tags
    #Test for class Role
    test_role_1 = Role()
    test_role_2 = Role()
    assert test_role_1.tags == test_role_2.tags
    #Test for class

# Generated at 2022-06-23 07:10:20.055257
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    import ansible.playbook.playbook_include as playbook_include
    from ansible.playbook.play import Play
    import ansible.playbook.play_context as play_context
    import ansible.playbook.role.definition as role_definition
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    Taggable.tags = ['t1', 't2']
    assert Taggable().evaluate_tags(set(), set(), dict()) is True

    # Test if only_tags option is working correctly
    Taggable.tags = ['t1', 't2']
    assert Taggable

# Generated at 2022-06-23 07:10:28.017282
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableTest(Taggable):
        pass

    test_object = TaggableTest()
    test_object.tags = 'a, b, c'
    assert test_object.evaluate_tags(None, None, {}) == True
    assert test_object.evaluate_tags(['a'], None, {}) == True
    assert test_object.evaluate_tags(['a', 'b'], None, {}) == True
    assert test_object.evaluate_tags(['a', 'b', 'c'], None, {}) == True
    assert test_object.evaluate_tags(['a', 'b', 'c', 'd'], None, {}) == True
    assert test_object.evaluate_tags(['d'], None, {}) == False

# Generated at 2022-06-23 07:10:37.980774
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block


# Generated at 2022-06-23 07:10:41.092450
# Unit test for constructor of class Taggable
def test_Taggable():
    assert issubclass(Taggable, object) == True
    assert isinstance(Taggable, type) == True
    assert Taggable is Taggable


# Generated at 2022-06-23 07:10:52.608386
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.include import Include
    from ansible.module_utils.six import string_types

    assert issubclass(Task, Taggable)
    assert issubclass(Block, Taggable)
    assert issubclass(Role, Taggable)
    assert issubclass(Play, Taggable)
    assert issubclass(Include, Taggable)

    task = Task()
    tag = task._load_tags(None, 'tag1, tag2, tag3')
    if isinstance(tag, list) and len(tag) == 3:
        pass
    else:
        assert False

   

# Generated at 2022-06-23 07:10:56.693422
# Unit test for constructor of class Taggable
def test_Taggable():
    class TaggableTest(Taggable):
        pass
    taggable_test = TaggableTest()
    print("In test_Taggable(), taggable_test.tags: ", taggable_test.tags)

# Generated at 2022-06-23 07:11:06.429923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import collections

    class TaggableTest(collections.namedtuple('TaggableTest', ['tags', 'opt_only_tags', 'opt_skip_tags', 'expect_result']), Taggable):
        pass


# Generated at 2022-06-23 07:11:16.549967
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test data
    test_tag = 'test_tag'
    test_tag_alt = 'test_tag_alt'
    test_untagged = frozenset(['untagged'])
    test_only_tags = [test_tag]
    test_skip_tags = [test_tag_alt]
    test_all_vars = {'test_var_1': 'test_val_1'}

    # Test function, expecting true
    class TestTaggableTrue(Taggable):
        tags = [test_tag]
    should_run_true = TestTaggableTrue().evaluate_tags(test_only_tags, test_skip_tags, test_all_vars)
    assert should_run_true is True

    # Test function, expecting false

# Generated at 2022-06-23 07:11:28.214787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestType(Taggable):    
        def __init__(self, tags=None):
            self.tags = tags
            
    assert TestType().evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    assert TestType(tags=['tag1','tag2','tag3']).evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    assert TestType(tags=['tag1','tag2','tag3']).evaluate_tags(only_tags=None, skip_tags=['tag2'], all_vars={})
    assert not TestType().evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={})
    assert TestType(tags=['tag1','tag2','tag3']).evaluate_tags

# Generated at 2022-06-23 07:11:35.514144
# Unit test for constructor of class Taggable
def test_Taggable():
    test_vars = {"test_var": "testing"}
    test_play = {
        "hosts": "localhost",
        "vars": test_vars,
        "tasks": [
            {"debug": "msg={{test_var}}"}
            ]
        }
    t = Taggable()
#   t._load_tags(test_play, 'ci, release, testing')
    t.evaluate_tags([], [], test_vars)


# Generated at 2022-06-23 07:11:48.187182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test basic usage of Taggable.evaluate_tags.  This method
    returns True if the task/play should run, and False if it
    should be skipped.
    '''

    # Create a mock loader object
    class MockLoader:
        pass
    loader = MockLoader()

    # Create a mock templar object
    class MockTemplar:
        def __init__(self, loader, vars):
            pass

        def template(self, str):
            return str

    # Create a Taggable object
    class MockTaggable(Taggable):
        pass
    obj = MockTaggable()
    obj._loader = loader

    # Create a mock play object
    class MockPlay:
        def __init__(self, play, loader, vars):
            self.tasks = []

# Generated at 2022-06-23 07:11:59.100691
# Unit test for constructor of class Taggable
def test_Taggable():
    import json
    import os
    import sys
    #import play, task, block
    #from ansible.playbook.play_iterator import PlayIterator

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.plugin_docs import read_docstring
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import callback_loader, fragment_

# Generated at 2022-06-23 07:12:01.894102
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = ['tag1','tag2','tag3']
    tg = Taggable(tags=tags)

    for tag in tags:
        assert tag in tg._tags

# Generated at 2022-06-23 07:12:04.185369
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    assert ta.tags == []

test_Taggable()

# Generated at 2022-06-23 07:12:06.217251
# Unit test for constructor of class Taggable
def test_Taggable():
    test_taggable = Taggable()
    assert test_taggable._tags == []

# Generated at 2022-06-23 07:12:15.742229
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.utils.vars import combine_vars


    class A(Taggable):
        def __init__(self):
            self.vars = combine_vars(dict())

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.tags = ['foo', 'bar', 'baz']

    class C(B):
        pass

    b = B()
    c = C()
    assert b.evaluate_tags(['foo'], [], {})
    assert b.evaluate_tags(['bar'], [], {})
    assert b.evaluate_tags(['baz'], [], {})
    assert not b.evaluate_tags(['notfoo'], [], {})

# Generated at 2022-06-23 07:12:26.221590
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    mock_data = {
        'tags': [
            'all',
        ],
    }

    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude.load(mock_data, loader=None, variable_manager=None)

    # test 1, check if only_tags work
    only_tag = 'all'
    skip_tag = None

    result = task_include.evaluate_tags(only_tags=[only_tag], skip_tags=[skip_tag], all_vars={})
    assert result == True

    # test 2, check if skip_tags work
    skip_tag = 'all'
    result = task_include.evaluate_tags(only_tags=[only_tag], skip_tags=[skip_tag], all_vars={})


# Generated at 2022-06-23 07:12:37.614844
# Unit test for constructor of class Taggable
def test_Taggable():
    assert( isinstance(Taggable()._tags, list) )
    assert( Taggable(tags=['a', 'b', 'c'])._tags == ['a', 'b', 'c'] )
    assert( Taggable(tags='a,b,c')._tags == ['a', 'b', 'c'] )
    try:
        Taggable(tags=123)
        assert( False )
    except AnsibleError as e:
        assert( 'tags must be specified as a list' in str(e) )
    try:
        Taggable(tags={'a':1, 'b':2})
        assert( False )
    except AnsibleError as e:
        assert( 'tags must be specified as a list' in str(e) )

# Generated at 2022-06-23 07:12:47.075514
# Unit test for constructor of class Taggable
def test_Taggable():

    # Check if _load_tags method works correctly
    class loaded_tags_testing_class(Taggable):
        _metaclass__ = type  # Python2 needs this in order to override above parent class
        pass

    # Check if _load_tags method works correctly for list
    option1 = loaded_tags_testing_class()
    assert option1._load_tags("tags",['tag1','tag2']) == ['tag1','tag2']

    # Check if _load_tags method works correctly for string
    option2 = loaded_tags_testing_class()
    assert option2._load_tags("tags",'tag1, tag2') == ['tag1', 'tag2']

    # Check if _load_tags method works correctly for single tag
    option3 = loaded_tags_testing_class()

# Generated at 2022-06-23 07:12:57.679263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    _temp_tags = set()
    obj = Taggable()
    obj.tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag7','tag8','tag9','tag10']
    only_tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag7','tag8','tag9','tag10']
    skip_tags = ['skip1','skip2','skip3','skip4','skip5','skip6','skip7','skip8','skip9','skip10']
    all_vars = ['var1','var2','var3','var4','var5','var6','var7','var8','var9','var10']
    templar = Templar(loader=obj._loader, variables=all_vars)

# Generated at 2022-06-23 07:12:58.811858
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []

# Generated at 2022-06-23 07:13:09.121999
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableKls(Taggable):
        _tags = None
        def __init__(self, tags):
            self.tags = tags

    all_vars = dict()

    for tag in ['a', 'b', 'c']:
        assert TaggableKls([tag]).evaluate_tags(
                only_tags=[],
                skip_tags=[],
                all_vars=all_vars
        )

    assert not TaggableKls(['a', 'c']).evaluate_tags(
            only_tags=['a', 'b'],
            skip_tags=[],
            all_vars=all_vars
    )


# Generated at 2022-06-23 07:13:21.398873
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tag_util = Taggable()

    fake_vars = dict(environment="staging")
    fake_task = dict(
        tags=["tagged", "environment_%s" % fake_vars['environment']],
        name="Test"
    )

    assert tag_util.evaluate_tags(['all'],[],fake_vars) == True
    assert tag_util.evaluate_tags(['tagged'],[],fake_vars) == True
    assert tag_util.evaluate_tags(['environment_%s' % fake_vars['environment']],[],fake_vars) == True
    assert tag_util.evaluate_tags([],['all'],fake_vars) == False
    assert tag_util.evaluate_tags(['environment_none'],['all'],fake_vars) == True


# Generated at 2022-06-23 07:13:31.291484
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy_class(Taggable):
        _tags = []
    dummy = Dummy_class()
    dummy.tags = []
    result = dummy.evaluate_tags(['tagged'], [], {})
    assert result == False

    class Dummy_class(Taggable):
        _tags = []
    dummy = Dummy_class()
    dummy.tags = ['always']
    result = dummy.evaluate_tags(['tagged'], [], {})
    assert result == True

    class Dummy_class(Taggable):
        _tags = []
    dummy = Dummy_class()
    dummy.tags = ['never_tagged']
    result = dummy.evaluate_tags(['tagged'], [], {})
    assert result == False

# Generated at 2022-06-23 07:13:42.896620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # cant use unittest testcase because would be too heavy to setup an inventory and 2 playbooks with 2 tasks
    from ansible.playbook import Play, Playbook
    from ansible.playbook.play import Play as PlayClass

    # for test we make a task with an AttributeError
    class MyTask(Taggable):
        def __init__(self, play):
            #super(Taggable, self).__init__()
            self.name = 'test1'
            self.tags = ['always']
            self.action = 'debug'
            self.args = 'msg=foo'
            self.loop = None
            self.when = None
            self.post_validate = None
            self._attributes = []
            self._loader = None
            self._role = None
            self._block = None
            self._

# Generated at 2022-06-23 07:13:55.290260
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Initialize class variables
    only_tags = frozenset(['only'])
    skip_tags = frozenset(['skip'])
    all_vars = dict()
    tags = ['always']
    obj = dict()
    obj.update(all_vars)
    obj.update(tags=tags)

    # Evaluate evaluate_tags results
    def test_evaluate_tags(obj, only_tags, skip_tags, all_vars, result):
        assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == result

    # Test evaluate_tags to return value True for both tags & skip_tags None
    test_evaluate_tags(obj, None, None, all_vars, True)

    # Test evaluate_tags to return value True for tags not empty

# Generated at 2022-06-23 07:14:08.721812
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task1 = Taggable()
    task2 = Taggable()
    task3 = Taggable()
    task4 = Taggable()

    task1.tags = ['tag1']
    task2.tags = ['tag2']
    task3.tags = ['tag3']
    task4.tags = ['tag4']

    only_tags = ['tag1']
    skip_tags = ['tag2']
    skip_tagged = ['tagged']
    all_tags = ['all']
    none_tags = []

    assert task1.evaluate_tags(only_tags, none_tags, {})
    assert not task1.evaluate_tags(only_tags, skip_tags, {})
    assert task2.evaluate_tags(all_tags, none_tags, {})

# Generated at 2022-06-23 07:14:12.316055
# Unit test for constructor of class Taggable
def test_Taggable():
    import doctest
    from ansible.playbook.role.include import RoleInclude

    fail_any, tests_run = doctest.testmod(RoleInclude)
    assert tests_run > 0
    assert fail_any == 0

# Generated at 2022-06-23 07:14:22.596838
# Unit test for constructor of class Taggable
def test_Taggable():
    # _load_tags
    try:
        obj = Taggable()
        tags = obj._load_tags(attr="attr", ds=["tag1","tag2"]) 
        assert tags == ["tag1","tag2"]
    except Exception as e:
        print(e)
        assert False

    try:
        obj = Taggable()
        tags = obj._load_tags(attr="attr", ds="tag1,tag2") 
        assert tags == ["tag1", "tag2"]
    except Exception as e:
        print(e)
        assert False

    # evaluate_tags
    try:
        obj = Taggable()
        obj.tags = ["tag1","tag2"]
        assert obj.evaluate_tags("only_tags","skip_tags") == True
    except Exception as e:
        print

# Generated at 2022-06-23 07:14:23.584461
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO
    assert True

# Generated at 2022-06-23 07:14:35.393210
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['test']
    only_tags = [ 'test' ]
    skip_tags = []
    assert Taggable.evaluate_tags(tags,only_tags,skip_tags) == True

    tags = ['test']
    only_tags = [ 'test' ]
    skip_tags = []
    assert Taggable.evaluate_tags(tags,only_tags,skip_tags) == True

    tags = ['always']
    only_tags = [ 'always' ]
    skip_tags = []
    assert Taggable.evaluate_tags(tags,only_tags,skip_tags) == True
    
    tags = ['test']
    only_tags = [ 'test2' ]
    skip_tags = []
    assert Taggable.evaluate_tags(tags,only_tags,skip_tags) == False


# Generated at 2022-06-23 07:14:39.604479
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t._tags, FieldAttribute)
    assert t._tags.default == list
    assert t._tags.isa == 'list'
    assert 'extend' in t._tags.flags

# Test inheritance of class Taggable

# Generated at 2022-06-23 07:14:45.220538
# Unit test for constructor of class Taggable
def test_Taggable():
    class testClass(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    inst = testClass()
    inst.tags = ['tag1', 'tag2', 'tag3']
    test = ['tag1', 'tag2', 'tag3']
    assert inst.tags == test, inst.tags

# Generated at 2022-06-23 07:14:53.881613
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class A(Taggable):
        def __init__(self):
            self.tags = None

    # set up _loader, create instance
    import ansible.parsing.dataloader
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff', 'virtualenv_plugins_path'])

# Generated at 2022-06-23 07:15:05.111228
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    t = Task()
    t.tags = 'a, b, c'
    assert t.tags == ['a', 'b', 'c']

    t = Task()
    t.tags = 'a,b,c'
    assert t.tags == ['a', 'b', 'c']

    t = Task()
    t.tags = ['a', ['b', 'c']]
    assert t.tags == ['a', 'b', 'c']

    t = Task()
    t.tags = ['a', 'b', 'c']
    assert t.tags == ['a', 'b', 'c']

# test _load_tags method

# Generated at 2022-06-23 07:15:07.314394
# Unit test for constructor of class Taggable
def test_Taggable():
    t1=Taggable()
    print("t1.tags is: " +t1.tags.__str__())

# Generated at 2022-06-23 07:15:18.503363
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list="")
    variable_manager.set_inventory(inventory)
    variable_manager._extra_vars = {'my_var': 'foo'}

# Generated at 2022-06-23 07:15:25.709415
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
    def test_subcase(tags, only_tags, skip_tags, result):
        only_tags = set(only_tags)
        skip_tags = set(skip_tags)
        taggable = DummyTaggable(tags)
        return taggable.evaluate_tags(only_tags, skip_tags, {'foo': 'bar'}) == result

    assert test_subcase(tags=['always'], only_tags=['all'], skip_tags=['all'], result=True)
    assert test_subcase(tags=['never'], only_tags=['all'], skip_tags=['all'], result=False)

# Generated at 2022-06-23 07:15:32.347490
# Unit test for constructor of class Taggable
def test_Taggable():
    testLoad = Taggable()
    result = testLoad._load_tags("test", ["test1", "test2"])
    assert len(result) == 2

    result = testLoad._load_tags("test", ["test1", "test2", "test3"])
    assert len(result) == 3

    result = testLoad._load_tags("test", "test1,test2")
    assert len(result) == 2

    result = testLoad._load_tags("test", "test1,test2,test3")
    assert len(result) == 3

# Generated at 2022-06-23 07:15:41.801631
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
	from ansible.parsing.yaml.objects import AnsibleUnicode
	from ansible.template import Templar
	from jinja2 import Environment
	from jinja2 import DictLoader

	class DummyClass(Taggable):
		_loader = DictLoader({'host1':'host1','true':'true','false':'false','ack':'ack'})

		def __init__(self):
			self.all_vars = {'ec2_metadata_document':'{"instanceId":"i-fefd5c2e"}','inventory_hostname':'ip-10-119-228-155.ec2.internal'}
			self.tags = []
			self.only_tags = []
			self.skip_tags = []

	# Case when both only

# Generated at 2022-06-23 07:15:42.973349
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:15:50.637498
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import copy
    class MyTaggable(Taggable):
        def __init__(self):
            super(MyTaggable, self).__init__()
            self._loader = None
            self.tags = list()
            self.vars = dict()
    t = MyTaggable()
    t.tags = copy.deepcopy(t.tags)
    t.vars = copy.deepcopy(t.vars)
    t.only_tags = t.skip_tags = []
    assert t.evaluate_tags(None, None, None)
    t.only_tags = ['all']
    assert t.evaluate_tags(t.only_tags, None, None)
    assert not t.evaluate_tags(t.only_tags, [], None)