

# Generated at 2022-06-23 07:05:51.165731
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t.tags = 'tag'
    assert t.tags == ['tag']

    t.tags = ['tag']
    assert t.tags == ['tag']

    t.tags = ['tag1', 'tag2']

    t.tags = None
    assert t.tags == []

# test the loader
if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:05:56.481385
# Unit test for constructor of class Taggable
def test_Taggable():
    host = Taggable(tags=['a'])
    assert host.tags == ['a']
    host = Taggable(tags='b')
    assert host.tags == ['b']
    host = Taggable(tags='c,d')
    assert host.tags == ['c', 'd']
    host = Taggable(tags='e, f')
    assert host.tags == ['e, f']

# Generated at 2022-06-23 07:06:06.917385
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            Taggable.__init__(self)
            self.tags = []

    test_class = TestTaggable()

    # Return True for all cases
    assert True == test_class.evaluate_tags(None, None, {})
    assert True == test_class.evaluate_tags(None, [], {})
    assert True == test_class.evaluate_tags(['test'], ['test'], {})
    assert True == test_class.evaluate_tags(['test'], None, {})
    assert True == test_class.evaluate_tags(['test'], ['test'], {})

    # Return False for all cases
    assert False == test_class.evaluate_tags(['test'], ['untagged'], {})
    assert False

# Generated at 2022-06-23 07:06:17.341784
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:06:27.339314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        from ansible.playbook.play_context import PlayContext
    except:
        from ansible.playbook.play import PlayContext

    class FakeTaggable(Taggable):
        pass

    my_fake_taggable = FakeTaggable()
    my_fake_taggable.tags = [ 'bob', 'joe', 'beth']
    play_context = PlayContext()
    play_context.only_tags = set(['fred'])
    print(my_fake_taggable.evaluate_tags(play_context.only_tags, play_context.skip_tags, {}))


if __name__ == "__main__":
    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:06:31.805569
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ["test"]
    only_tags = ["test"]
    skip_tags = ["test"]
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True
    pass

# Generated at 2022-06-23 07:06:39.672378
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task

    data = { 'tags': ['foo', 'bar'] }
    t = Task.load(data)

    # evaluate_tags with only_tags=['foo'] and skip_tags=[], should return True
    assert t.evaluate_tags(['foo'], [], {})

    # evaluate_tags with only_tags=[''] and skip_tags=[], should return False
    assert not t.evaluate_tags([''], [], {})

    # evaluate_tags with only_tags=[''] and skip_tags=['foo'], should return False
    assert not t.evaluate_tags([''], ['foo'], {})

    # evaluate_tags with only_tags=['bar'] and skip_tags=['foo'], should return True

# Generated at 2022-06-23 07:06:49.375796
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()

    # check default attributes
    assert taggable.tags == list()
    assert taggable.untagged == frozenset(['untagged'])

    # check _tags taggable instance
    taggable._tags = [1,2,3]
    assert taggable._tags == [1,2,3]

    # check _load_tags
    assert taggable._load_tags('_tags', [1,2,3]) == [1,2,3]
    assert taggable._load_tags('_tags', 'a,b,c') == ['a','b','c']
    assert taggable._load_tags('_tags', 'a b c') == ['a b c']
    assert taggable._load_tags('_tags', 2) == [2]

# Generated at 2022-06-23 07:06:52.367454
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass

    my_taggable = MyTaggable()

# Generated at 2022-06-23 07:06:53.845539
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj._tags == []

# Generated at 2022-06-23 07:06:57.434535
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass

    ds = 'test_tag_1,test_tag_2'

    mt = MyTaggable()
    mt._load_tags('tags', ds)
    print(mt._tags)

# Generated at 2022-06-23 07:07:03.943247
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    # Test for case: only_tags: all, TestClass.tags: untagged
    TestClass.tags = TestClass.untagged
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert TestClass().evaluate_tags(only_tags, skip_tags, all_vars) is True

    # Test for case: only_tags: all, TestClass.tags: []
    TestClass.tags = []
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert TestClass().evaluate_tags(only_tags, skip_tags, all_vars) is True

    # Test for case: only_tags: all, TestClass.tags: ['aaa']

# Generated at 2022-06-23 07:07:06.055079
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:07:17.245536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest2 as unittest

    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = ['tag_1', 'tag_2', 'tag_3']

    test_taggable = TestTaggable()

    assert test_taggable.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars=dict())
    assert test_taggable.evaluate_tags(only_tags=['tag_1', 'tag_2', 'tag_3'], skip_tags=None, all_vars=dict())
    assert test_taggable.evaluate_tags(only_tags=['tag_1'], skip_tags=None, all_vars=dict())

# Generated at 2022-06-23 07:07:25.164667
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    taggable = Taggable()
    # print(type(taggable.tags))
    # print(type(Task().tags))
    assert taggable.tags == Task().tags
    assert type(taggable.tags) == type(Task().tags)

    assert taggable._load_tags("tags", ["httpd","mysql"]) == ["httpd","mysql"]
    assert taggable._load_tags("tags", "httpd,mysql") == ["httpd","mysql"]
    #assert taggable._load_tags("tags", {"httpd": "/srv/httpd"}) == ["httpd","mysql"]

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:07:31.979349
# Unit test for constructor of class Taggable
def test_Taggable():
    fake_loader = 1

    taggable = Taggable(loader=fake_loader)
    assert taggable.tags == []

    taggable = Taggable(tags='tag1,tag2', loader=fake_loader)
    assert taggable.tags == ['tag1', 'tag2']

    taggable = Taggable(tags=['tag1', 'tag2'], loader=fake_loader)
    assert taggable.tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:07:38.811904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from collections import namedtuple
    class MockTaggable(Taggable):
        def __init__(self):
            self.tags = None
    class MockLoader():
        def __init__(self):
            pass
    obj = MockTaggable()
    obj._loader = MockLoader()

    obj.tags = []
    only_tags = set()
    skip_tags = set()
    obj.evaluate_tags(only_tags, skip_tags, {})
    assert obj.tags == obj.untagged

    obj.tags = ['tag01', 'tag02', 'tag03']
    only_tags = set()
    skip_tags = set()
    obj.evaluate_tags(only_tags, skip_tags, {})
    assert obj.tags == ['tag01', 'tag02', 'tag03']

    obj.tags

# Generated at 2022-06-23 07:07:53.448638
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task

    # Create a task
    task = Task()

    # Create a handler
    handler = HandlerTaskInclude()

    # Create a block
    block = Block()
    block._load_name("Test Block")
    block._parent = task

    # Create a play
    play = Play()

    # Create a play context
    play_context = PlayContext()

    # Create a role
    role = IncludeRole()



# Generated at 2022-06-23 07:07:58.687605
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []

# Generated at 2022-06-23 07:08:04.517704
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class One:
        pass
    one = One()
    one.tags = ['tag1', 'tag2']

    assert Taggable.evaluate_tags(one, only_tags=['tag1', 'tag3'], skip_tags=[], all_vars={}) is True
    assert Taggable.evaluate_tags(one, only_tags=['tag3'], skip_tags=[], all_vars={}) is False

# Generated at 2022-06-23 07:08:10.489773
# Unit test for constructor of class Taggable
def test_Taggable():
    #Constructor called without parameter
    taggable1 = Taggable()
    assert taggable1._tags == []

    #Constructor called with tag_list parameter
    tag_list = ['tag1', 'tag2']
    taggable2 = Taggable(tags=tag_list)
    assert taggable2.tags == tag_list


# Generated at 2022-06-23 07:08:17.062599
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable, msg = Taggable(), "constructor should return Taggable, not {}"
    print(msg.format(type(taggable)))
    assert isinstance(taggable, Taggable), msg


# Generated at 2022-06-23 07:08:29.175086
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock(Taggable):
        def __init__(self):
            self.tags = []
    tag_object = TaggableMock()
    class DummyLoader:
        pass
    tag_object._loader = DummyLoader()

    # Test that non list, string and dict args are not accepted
    try:
        tag_object.tags = 123
        tag_object.evaluate_tags([], [], DummyLoader())
        return False
    except AnsibleError:
        pass
    # Test that lists and strings as args are accepted
    tag_object.tags = ['test']
    tag_object.evaluate_tags(['test'], ['test'], DummyLoader())
    tag_object.tags = 'test'
    tag_object.evaluate_tags(['test'], ['test'], DummyLoader())

# Generated at 2022-06-23 07:08:38.805113
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class TestCase(unittest.TestCase):
        def test_success(self):
            test_list = ["tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "tag7"]

            t = Taggable()

            all_vars = {"only_tags": "tag1", "skip_tags": "tag5,tag6,tag7"}

            self.assertTrue(t.evaluate_tags(all_vars["only_tags"], all_vars["skip_tags"], all_vars))

            all_vars = {"only_tags": "tag1,tag2,tag3", "skip_tags": "tag2,tag3,tag4"}


# Generated at 2022-06-23 07:08:43.037420
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['tag1', 'tag2']
    only_tags = ['tag1', 'tag3']
    skip_tags = ['tag3']
    all_vars = []
    assert Taggable().evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-23 07:08:54.096461
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []
    taggable.tags = [u'debug', u'mytag']
    assert taggable._tags == [u'debug', u'mytag']
    taggable.tags = [u'debug', u'shell:echo hello']
    assert taggable._tags == [u'debug', u'shell:echo hello']
    taggable.tags = u'debug,shell:echo hello'
    assert taggable._tags == [u'debug', u'shell:echo hello']
    taggable.tags = u'shell:echo hello, debug'
    assert taggable._tags == [u'shell:echo hello', u'debug']



# Generated at 2022-06-23 07:08:56.225359
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert isinstance(obj, Taggable), "test_Taggable"

# Generated at 2022-06-23 07:09:00.505745
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass

    class MockTaggableWithTags(Taggable):
        tags = ['tag1', 'tag2']

    class MockTaggableWithAlwaysTag(Taggable):
        tags = ['always']

    class MockTaggableWithNeverTag(Taggable):
        tags = ['never']

    mock_taggable = MockTaggable()
    mock_taggable_with_tags = MockTaggableWithTags()
    mock_taggable_with_always_tag = MockTaggableWithAlwaysTag()
    mock_taggable_with_never_tag = MockTaggableWithNeverTag()

    # test with only_tags
    assert mock_taggable.evaluate_tags(['tag1'], [], {}) is False
    assert mock_tagg

# Generated at 2022-06-23 07:09:02.054267
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == [], "Initialize tags failed"


# Generated at 2022-06-23 07:09:14.247511
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # -------------------------------
    # test class import, instantiation and attribute access
    assert Taggable

    a = Taggable()
    assert a

    assert a._tags

    # -------------------------------
    # test evaluate_tag when not specifying any tag options
    assert a.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})

    # -------------------------------
    # test evaluate_tag when specifying only_tags
    # test with no tag specified for corresponding item, should be skipped
    assert not a.evaluate_tags(only_tags=['python'], skip_tags=None, all_vars={})
    assert not a.evaluate_tags(only_tags=['python', 'perl'], skip_tags=None, all_vars={})

    # test with tag specified for corresponding item, should run
    a._tags

# Generated at 2022-06-23 07:09:25.711538
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.role
    import ansible.playbook.task_include

    my_tags = ['a', 'b']
    item = ansible.playbook.task_include.TaskInclude()
    item._parent = ansible.playbook.role.Role()
    item._role_name = 'my_role'
    item.tags = my_tags

    item.evaluate_tags(only_tags=[], skip_tags=[])
    assert my_tags == item.tags

    item.evaluate_tags(only_tags=[], skip_tags=['a'])
    assert ['b'] == item.tags

    item.evaluate_tags(only_tags=[], skip_tags=['b'])
    assert ['a'] == item.tags


# Generated at 2022-06-23 07:09:37.218822
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    class TestTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None

    test_class = TestTaggable()

    # Test with no tags
    test_class.tags = None
    assert test_class.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={}) == True

    # Setup
    test_class.tags = ['foo']
    assert test_class.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={}) == True

    assert test_class.evaluate_tags(only_tags=['bar'], skip_tags=['bar'], all_vars={}) == False


# Generated at 2022-06-23 07:09:44.525538
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
	attrs = {
		'_tags' : [
			'unit', 'testing'
		]
	}
	TaggableInstance = type('TaggableInstance', (Taggable,object,), attrs)

	play_vars = {
		'unit_test_only_tags' : ['unit', 'testing'],
		'unit_test_skip_tags' : []
	}

	assert True == TaggableInstance.evaluate_tags(TaggableInstance, only_tags = play_vars['unit_test_only_tags'], skip_tags = play_vars['unit_test_skip_tags'], all_vars = play_vars)

# Generated at 2022-06-23 07:09:46.669316
# Unit test for constructor of class Taggable
def test_Taggable():
	Taggable._load_tags(Taggable, 'tag_one,tag_two')

# Generated at 2022-06-23 07:09:58.436766
# Unit test for constructor of class Taggable
def test_Taggable():
    import pytest
    from ansible.playbook.role import Role
    data = {}
    a = Role.load(data, 'test')
    assert isinstance(a, Role), "Testcase 1 failed"
    data = 1
    try:
        a = Role.load(data, 'test')
    except AnsibleError as e:
        assert e.message == 'tags must be specified as a list', "Testcase 2 failed"
    else:
        pytest.fail("Expected AnsibleError not raised")
    data = '1,2,3'
    a = Role.load(data, 'test')
    assert a.tags == [1, 2, 3], "Testcase 3 failed"
    data = [1, 2, 3]
    a = Role.load(data, 'test')

# Generated at 2022-06-23 07:10:09.913655
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task_tags = ''
    only_tags = ''
    skip_tags = ''

    # Test 1: Check Taggable evaluate_tags with task_tags as string and only_tags, skip_tags as ''
    task_tags = 'test1'
    only_tags = ''
    skip_tags = ''
    assert Taggable().evaluate_tags(only_tags, skip_tags, task_tags)

    # Test 2: Check Taggable evaluate_tags with task_tags as string, only_tags and skip_tags as list
    task_tags = 'test2'
    only_tags = ['test2']
    skip_tags = ['test2']
    assert Taggable().evaluate_tags(only_tags, skip_tags, task_tags)

    # Test 3: Check Taggable evaluate_tags with task_tags as string and only

# Generated at 2022-06-23 07:10:21.942736
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Test case for ansible.utils.Taggable.evaluate_tags '''
    import pytest

    # Test evaluate_tags without 'only_tags' and 'skip_tags'
    # when tags is empty
    test_tags = []
    test_only_tags = None
    test_skip_tags = None

    # test obj1, it is expected to run
    obj1 = Taggable()
    obj1.tags = test_tags
    assert obj1.evaluate_tags(test_only_tags, test_skip_tags, {})

    # Test evaluate_tags with 'only_tags' when tags is empty
    test_only_tags = ['foo', 'bar']

    # test obj1 and obj2, they are expected to run
    obj1 = Taggable()
    obj1.tags = test_tags

# Generated at 2022-06-23 07:10:34.806829
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_only_tags = set()
    test_skip_tags = set()

    test = TestTaggable()
    test.tags = ['test']
    test_result = test.evaluate_tags(test_only_tags, test_skip_tags, {})
    assert test_result == True

    test_only_tags = set(['test'])
    test_skip_tags = set()
    test_result = test.evaluate_tags(test_only_tags, test_skip_tags, {})
    assert test_result == True

    test_only_tags = set()
    test_skip_tags = set(['test'])
    test_result = test.evaluate_tags(test_only_tags, test_skip_tags, {})
    assert test_

# Generated at 2022-06-23 07:10:46.301812
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import json

    from ansible import constants as C

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template import Templar

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    C.DEFAULT_PRIVATE_ROLE_VARS = True
    C.DEFAULT_HOST_LIST         = os.path.join(C.DEFAULT_BASEDIR, "hosts")
    C.DEFAULT_ROLES_PATH        = os.path.join(C.DEFAULT_BASEDIR, 'roles')
    C.DEFAULT_ROLES_PATH

# Generated at 2022-06-23 07:10:57.454577
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    loader = None
    variable_manager = None

    block = dict(
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='hello'))),
        ]
    )

    only_tags = (('all',), ('tagged',), ('always',), ('never',))
    skip_tags = (('all',), ('tagged',), ('always',), ('never',))
    expected_result = (True, False, False, False), (True, True, False, True), (True, True, True, True), (False, False, False, False)

# Generated at 2022-06-23 07:11:01.925062
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == list
    # Additional conversion tests that is not tested by the FieldAttribute
    # constructor test_list
    assert t._load_tags('tags', 'a') == ['a']
    assert t._load_tags('tags', 'a,b,c') == ['a','b','c']

# Generated at 2022-06-23 07:11:13.275910
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.sentinel import Sentinel

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict())
    parent_block = Sentinel()

    # Test the case where no tags are specified
    ti = TaskInclude(play=None, parent_block=parent_block, task_include=None, role=None, task_deps=None, loop=None,
                     loop_args=None, role_params=None)

    # no tags and no skip or only options
    play_context.only_tags.append('all')
    play_context.skip_tags.append('all')

# Generated at 2022-06-23 07:11:23.625379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Taggable_test(Taggable):
        hostvars = {
            'x1': {
                'my_tags': ['tag1', 'tag2', 'tag4'],
            }
        }


    t = Taggable_test()

    all_vars = { 'hostvars': t.hostvars }

    # test only_tags, skip_tags
    only_tags = ['tag2', 'tag3']
    skip_tags = ['tag3']
    should_run = t.evaluate_tags(only_tags, skip_tags, all_vars)
    if not should_run:
        raise AssertionError("Incorrect result of evaluation_tags")

    # test only_tags, skip_tags with tag3 on playbook
    t.tags = ['tag3']

# Generated at 2022-06-23 07:11:36.272245
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_class = Taggable
    test_object = Taggable()


# Generated at 2022-06-23 07:11:39.399603
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        pass

    x = TestTaggable()
    assert x.tags == []



# Generated at 2022-06-23 07:11:40.380968
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:11:43.012365
# Unit test for constructor of class Taggable
def test_Taggable():
    # setup
    test_obj = Taggable()

    # assertion
    assert isinstance(test_obj.tags, list)

    # teardown
    del test_obj

# Generated at 2022-06-23 07:11:54.547727
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os

    os.environ['ANSIBLE_CONFIG'] = ''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    task_include = TaskInclude(loader=None,
                               play=None,
                               variable_manager=variable_manager,
                               templar=None)


# Generated at 2022-06-23 07:11:59.416775
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    taggable.tags = ['test']
    assert taggable.tags == ['test']
    taggable.tags = ['test2', 'test3']
    assert taggable.tags == ['test2', 'test3']
    taggable.tags.extend(['test4', 'test4'])
    assert taggable.tags == ['test2', 'test3', 'test4', 'test4']

# Generated at 2022-06-23 07:12:04.341435
# Unit test for constructor of class Taggable
def test_Taggable():
    class FooTaggable(Taggable):

        untagged = frozenset(['untagged'])
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    foo = FooTaggable()
    assert foo.tags == []

# Generated at 2022-06-23 07:12:14.447725
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def __evaluate_tags(tags, only_tags, skip_tags): # noqa: E302
        class FakeTaggable(Taggable):
            def __init__(self):
                self.tags = tags

        return FakeTaggable().evaluate_tags(only_tags, skip_tags, {})

    # whatever tags, no tag options
    assert __evaluate_tags(None, [], [])
    assert __evaluate_tags([], [], [])
    assert __evaluate_tags(['one', 'two'], [], [])
    assert __evaluate_tags(['one', 'two'], [], ['all'])

    # whatever tags, --tags=all
    assert __evaluate_tags(None, ['all'], [])
    assert __evaluate_tags(None, [], ['all'])

# Generated at 2022-06-23 07:12:24.763192
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    class TestTags(Taggable): pass
    def tt(tags, only_tags=[], skip_tags=[], vars=None):
        obj = TestTags()
        obj.tags = tags
        return obj.evaluate_tags(only_tags, skip_tags, vars)
    # Basic tag handling
    assert tt(['always'], skip_tags=['always']) == True
    assert tt(['always'], skip_tags=['all']) == False
    assert tt(['always'], only_tags=['all']) == True
    assert tt(['always']) == True
    assert tt(['never'], skip_tags=['all']) == False
    assert tt(['never'], skip_tags=['never']) == False

# Generated at 2022-06-23 07:12:37.525661
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task

    t0 = Task()

    # Test for case when only_tags is ['all'] and skip_tags is empty
    # This task should run
    t0.tags = ['all']
    only_tags = ['all']
    skip_tags = []

    assert t0.evaluate_tags(only_tags, skip_tags, {}) == True

    # Test for case when only_tags is empty and skip_tags is ['all']
    # This task should not run
    t0.tags = ['all']
    only_tags = []
    skip_tags = ['all', 'never']

    assert t0.evaluate_tags(only_tags, skip_tags, {}) == True
    # Test for case when only_tags is empty and skip_tags is ['all']
    # This task should not

# Generated at 2022-06-23 07:12:39.758536
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test the constructor
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-23 07:12:45.949923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['tag1','tag2']

    only_tags = ['tag1','tag2','tag3']
    skip_tags = ['tag4','tag5','tag6']
    all_vars = {}

    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    taggable.tags = ['tag4','tag5','tag6']
    assert not taggable.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-23 07:12:57.445564
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_obj = Taggable()

    # Test 1: Should return true, 'test_tag' is in only_tags
    # and 'test_tag' is present in items tags
    test_obj.tags = [ "test_tag" ]
    only_tags = [ "test_tag" ]
    skip_tags = []
    assert test_obj.evaluate_tags(only_tags, skip_tags, None) == True

    # Test 2: Should return true, 'test_tag' is present in items tags
    # and 'tagged' is present in only_tags
    test_obj.tags = [ "test_tag" ]
    only_tags = [ "tagged" ]
    skip_tags = []
    assert test_obj.evaluate_tags(only_tags, skip_tags, None) == True

    # Test 3: Should

# Generated at 2022-06-23 07:13:07.740192
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    import os

    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=['localhost'])
    variable_manager = VariableManager()
    loader = None
    play = Play.load(dict(name = 'test', hosts='localhost', gather_facts='no', tasks=[dict(action=dict(module='copy', args='src=copytest.j2 dest=/tmp/testfile mode=644'))]), variable_manager=variable_manager, loader=loader)
    t = Taggable()
    assert(isinstance(t, Taggable))
    return Play()

# Generated at 2022-06-23 07:13:15.487810
# Unit test for constructor of class Taggable
def test_Taggable():
    """Check behaviour of Taggable class.

    Taggable class is an abstract class that provides common
    behavior for modules,tasks,plays and blocks.

    This unit test check the behavior of Taggable class constructor.
    """
    taggable_obj = Taggable()
    assert taggable_obj.tags == [], 'default tag should be empty list'

# Generated at 2022-06-23 07:13:17.177436
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-23 07:13:20.015312
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == list
    assert taggable.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:13:23.625109
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role.include import RoleInclude

    t = RoleInclude()
    assert t.tags == []
    t.tags = 'foo, bar, baz'
    assert t.tags == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 07:13:33.028283
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.utils.yaml.objects import AnsibleUnicode
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C

    t = TaskInclude()

    t.tags = ['test_tag']
    assert t.evaluate_tags(only_tags=['test_tag'], skip_tags=[],
                           all_vars={})
    assert t.evaluate_tags(only_tags=['always'], skip_tags=[],
                           all_vars={})
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['never'],
                           all_vars={})

# Generated at 2022-06-23 07:13:35.010314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    Taggable_class = Taggable()
    {} # empty test for now




# Generated at 2022-06-23 07:13:39.719750
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._load_tags('tags', ['tag1', 'tag2'])
    assert t._tags == ['tag1', 'tag2']

    t._load_tags('tags', 'tag1,tag2')
    assert t._tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:13:48.387333
# Unit test for constructor of class Taggable
def test_Taggable():
    print('Testing Taggable')

    t = Taggable()
    assert t.tags == []

    t = Taggable(tags="a,  b")
    assert t.tags == ['a', 'b']

    t = Taggable(tags=['a','b','c','d'])
    assert t.tags == ['a','b','c','d']

    # Test tag parsing
    t = Taggable(tags="a,b")
    assert t.tags == ['a','b']

    # Test tag parsing
    t = Taggable(tags="a, a, b, b")
    assert t.tags == ['a','b']

    # Test appending tags
    t = Taggable(tags="a,b")
    t.tags.append('c')

# Generated at 2022-06-23 07:13:58.608733
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    class MyTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = self._load_tags('tags', tags)

    # No tags at all
    t = MyTaggable()
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # No tags specified, only_tags with all
    t = MyTaggable()
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # No tags specified, only_tags with tagged
    t = MyTaggable()
    only_

# Generated at 2022-06-23 07:14:05.188837
# Unit test for constructor of class Taggable
def test_Taggable():
    print('TEST: Taggable')
    t = Taggable()
    assert t._tags  == []

    t = Taggable(tags="tag1, tag2")
    assert t._tags == ['tag1', 'tag2']

    t = Taggable(tags=["tag1", "tag2"])
    assert t._tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:14:08.026382
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert a._load_tags("a,b,c,d", "a,b,c,d") == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 07:14:12.822227
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = Taggable()

    tags.tags = "tag1,tag2"
    assert tags.tags == ['tag1','tag2']
    tags.tags = "tag1"
    assert tags.tags == ['tag1']
    tags.tags = ["tag1","tag2"]
    assert tags.tags == ['tag1','tag2']

# Generated at 2022-06-23 07:14:23.109990
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.template import Templar

    def _load_tags(self, attr, ds):
        if isinstance(ds, list):
            return ds
        elif isinstance(ds, string_types):
            value = ds.split(',')
            if isinstance(value, list):
                return [x.strip() for x in value]
            else:
                return [ds]
        else:
            raise AnsibleError('tags must be specified as a list', obj=ds)

    # Monkey patch Taggable class with play.load_tags method
    Taggable._load_tags = _load_tags

    # create a task
    task = dict(name='Test task',
                tags=['always'])

    # create a play

# Generated at 2022-06-23 07:14:28.205439
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t.tags = [ "test" ]
    assert (t.evaluate_tags(['test'], None, {}) == True)
    assert (t.evaluate_tags(['not_in_tags'], None, {}) == False)

# Generated at 2022-06-23 07:14:30.215348
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert isinstance(a._tags, list)

# Generated at 2022-06-23 07:14:40.997073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # First test a task without tags
    task = Taggable()
    only_tags = ['tag1','tag2','tag3']
    skip_tags = ['tag4','tag5','tag6']
    all_vars = dict()
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    print('should_run = ', should_run)
    # Check that the task should run since it has no tags
    assert should_run
    # Next test a task with tags that should be skipped
    task = Taggable()
    task.tags = ['tag4','tag5','tag6']
    only_tags = ['tag1','tag2','tag3']
    skip_tags = ['tag4','tag5','tag6']
    all_vars = dict()

# Generated at 2022-06-23 07:14:52.852182
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:14:55.686834
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._tags, list)
    assert taggable._tags == list()


# Generated at 2022-06-23 07:15:04.589700
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C

    ti = TaskInclude()

    # test _load_tags
    ti.tags = 'tag1, tag2'
    assert type(ti.tags) == list
    assert len(ti.tags) == 2

    ti = TaskInclude()
    ti.tags = ['tag1', 'tag2']
    assert type(ti.tags) == list
    assert len(ti.tags) == 2

# Generated at 2022-06-23 07:15:10.129679
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class A(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    a = A()
    a.tags = None
    assert a.evaluate_tags(['a'], [], dict()) == False

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:15:20.751141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role_include import RoleInclude

    class FakeResult(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    tasks = [
        FakeResult([]),
        FakeResult(['foo']),
        FakeResult(['bar']),
        FakeResult(['foo', 'bar']),
        FakeResult(['always']),
        FakeResult(['never']),
        FakeResult(['foo', 'never']),
        FakeResult(['never', 'foo']),
        FakeResult(['never', 'bar']),
        FakeResult(['bar', 'never']),
    ]

    # Check that no tags to apply/skip don't affect results
    for task in tasks:
        assert task.evaluate_tags([], [], {})

   

# Generated at 2022-06-23 07:15:33.409684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    fake_loader = None
    fake_play_context = PlayContext()
    fake_task_include = TaskInclude.load(dict(name='fake_task_include', tags=['fake_task_tags']), fake_loader, fake_play_context)
    fake_play_context.only_tags = ['all', 'fake_play_context_only_tags']
    fake_play_context.skip_tags = []

    # case 1
    fake_task_include.tags = ['always']
    assert fake_task_include.evaluate_tags(fake_play_context.only_tags, fake_play_context.skip_tags, dict()) == True

    # case

# Generated at 2022-06-23 07:15:41.973131
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a dummy dataloader and variable manager
    dl = DataLoader()
    vm = VariableManager()

    # Create a Taggable object, we don't care what it is
    taggable = Taggable(loader=dl, variable_manager=vm)

    # Check that the values are what we expect them to be
    assert taggable._tags == []
    assert taggable.tags == []
    assert taggable.untagged == frozenset(['untagged'])

    return taggable



# Generated at 2022-06-23 07:15:43.691843
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    role = Role()
    assert isinstance(role, Taggable)

# Generated at 2022-06-23 07:15:51.014919
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleDefinition
    from ansible.playbook.block import Block

    only_tags = ['a', 'b']
    skip_tags = ['c', 'd']
    t = Task()
    t._task_fields = {}
    t._task_fields['tags'] = ['a']
    assert t.evaluate_tags(only_tags, skip_tags, {})

    t = Task()
    t._task_fields = {}
    t._task_fields['tags'] = ['e']
    assert not t.evaluate_tags(only_tags, skip_tags, {})

    t = Task()
    t._task_fields = {}