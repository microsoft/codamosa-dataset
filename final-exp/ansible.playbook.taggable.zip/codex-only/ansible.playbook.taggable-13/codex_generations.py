

# Generated at 2022-06-23 07:05:49.241394
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Taggable()
    tags = ["foo", "bar"]
    t._tags = tags
    assert t.tags == tags
    t = Task()
    assert t.tags is None

# Generated at 2022-06-23 07:05:50.785599
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == [], "initial value of tags is not []"

# Generated at 2022-06-23 07:06:01.407548
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    def args_to_task(tags, only_tags, skip_tags=None):
        ''' Create a Task with the given args and return it '''
        task = Task()
        task.tags = tags
        task.only_tags = only_tags
        task.skip_tags = skip_tags
        return task

    t = args_to_task(['A', 'B'], ['A', 'C', 'D'])  # expect true
    assert t.run

    t = args_to_task([], ['A', 'C', 'D'])  # expect false; empty tags
    assert not t.run

    t = args_to_task(['A', 'B'], [])  # expect true, empty only_tags
    assert t.run

    t = args_

# Generated at 2022-06-23 07:06:09.758585
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    task = Task()
    task_include = TaskInclude()
    handler = Handler()

    # test the constructor
    assert task._load_tags(None, []) == []
    assert task._load_tags(None, ['foo', 'bar']) == ['foo', 'bar']
    assert task._load_tags(None, 'foo, bar') == ['foo', 'bar']
    assert task._load_tags(None, 'foo') == ['foo']
    assert task._load_tags(None, 1) == [1]
    assert task._load_tags(None, 1.2) == [1.2]

# Generated at 2022-06-23 07:06:18.797327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Test the evaluate_tags method of the Taggable class '''

    data = dict(
        only_tags=None,
        skip_tags=None,
        all_vars=dict(),
        tags=None,
    )

    obj = Taggable()
    for key in data:
        setattr(obj, key, data[key])

    result = obj.evaluate_tags(data['only_tags'], data['skip_tags'], data['all_vars'])
    assert result == True

    # simple tests
    data = dict(
        only_tags=['foo'],
        skip_tags=None,
        all_vars=dict(),
        tags=None,
    )

    obj = Taggable()
    for key in data:
        setattr(obj, key, data[key])



# Generated at 2022-06-23 07:06:20.542537
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert False, "No tests written for method evaluate_tags of class Taggable"

# Generated at 2022-06-23 07:06:21.511987
# Unit test for constructor of class Taggable
def test_Taggable():
    pass

# Generated at 2022-06-23 07:06:30.723634
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test without tags
    test_item = Taggable()
    test_item.tags = []
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert test_item.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # test with tags
    test_item = Taggable()
    test_item.tags = ['tag1', 'tag2']
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert test_item.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # test with tags and only_tags
    test_item = Taggable()
    test_item.tags = ['tag1', 'tag2']

# Generated at 2022-06-23 07:06:39.060721
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test that the constructor ignores comments
    taglist = Taggable()
    taglist._load_tags(None, ['foo', 'bar #blah'])
    assert taglist.tags == ['foo', 'bar']

    # Test that the constructor handles comma-separated strings
    taglist = Taggable()
    taglist._load_tags(None, 'foo, bar')
    assert taglist.tags == ['foo', 'bar']

    # Test that the constructor handles other iterables
    taglist = Taggable()
    taglist._load_tags(None, {'foo', 'bar'})
    assert taglist.tags == ['foo', 'bar']

    # Test that the constructor raises on other types

# Generated at 2022-06-23 07:06:41.715056
# Unit test for constructor of class Taggable
def test_Taggable():
    assert(issubclass(Taggable, object))
    assert(Taggable.__doc__ is not None)



# Generated at 2022-06-23 07:06:44.727148
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        pass

    tc = TestClass()

    # Test that the class was constructed properly
    assert isinstance(tc, Taggable) is True
    assert tc.tags == []

# Generated at 2022-06-23 07:06:56.424870
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tagg = Taggable()

    def _test(tags, only_tags, skip_tags, exp):
        tagg._tags = tags
        act = tagg.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars={})
        assert act == exp, '%s: %s != %s' % (tags, act, exp)


# Generated at 2022-06-23 07:07:03.493463
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.template import Templar
    import os
    import sys

    # Ansible loads its plugins using find_plugins which needs a valid play context
    # to prevent a circular import we import ansible.playbook.play here and
    # initialize the context after
    from ansible.playbook.play import Play
    play_context = Play().set_loader()

    class MyTaggable(Taggable):
        def __init__(self):
            self._loader = play_context._loader

    # Mock __init__ of Templat class
    Templar.__init__ = lambda self, loader=None, variables=None, **kwargs: None

    # Mock template method of Templat class
    Templar.template = lambda self, value=None, **kwargs: value

    # Mock _load_tags method of Taggable class
    Taggable._

# Generated at 2022-06-23 07:07:05.787820
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test if the class Definition can be used
    TestTaggable = Taggable()
    assert TestTaggable


# Generated at 2022-06-23 07:07:17.108416
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    test_tags = ['test_tag_1', 'test_tag_2']
    only_tags = ['test_tag_1', 'test_tag_3']
    skip_tags = ['test_tag_3']
    all_vars = dict()

    test_task = Task()
    test_task._load_tags = Taggable._load_tags
    test_task.tags = test_tags

    assert test_task.evaluate_tags(only_tags, None, None) == True
    assert test_task.evaluate_tags(only_tags, skip_tags, all_vars) == True
    assert test_task.evaluate_tags(only_tags, None, all_vars) == True

    only_tags = ['test_tag_3']
    assert test_task

# Generated at 2022-06-23 07:07:25.117194
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()

    # test only-tags
    tt.tags = "test1, test2, test3"
    results = tt.evaluate_tags("test", "", {})
    assert not results
    results = tt.evaluate_tags("test3", "", {})
    assert results
    results = tt.evaluate_tags("test", "", {})
    assert results
    results = tt.evaluate_tags("test1,test2", "", {})
    assert results
    results = tt.evaluate_tags("test1,test2,test3,test4,test5", "", {})
    assert results

# Generated at 2022-06-23 07:07:35.082216
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableClass(Taggable):
        pass

    tag_obj = TaggableClass()
    tag_obj._loader = {}
    assert tag_obj.evaluate_tags(None, None, {}) == True, "Failed to run when both skip_tags and only_tags are None"

    assert tag_obj.evaluate_tags(['a', 'b', 'c'], None, {}) == False, "Failed to skip when only_tags is provided and task tags not found in it"
    tag_obj.tags = ['a']
    assert tag_obj.evaluate_tags(['a', 'b', 'c'], None, {}) == True, "Failed to run when only_tags is provided and task tags found in it"

    tag_obj.tags = ['a', 'b']
    assert tag_obj.evaluate_tags

# Generated at 2022-06-23 07:07:37.252799
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert type(t.tags) is list

# Generated at 2022-06-23 07:07:52.499345
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  
  from ansible.playbook.task import Task
  from ansible.parsing.dataloader import DataLoader

  only_tags = [ 'test' ]
  skip_tags = []
  loader = DataLoader()
  shared_loader = loader._loader
  variable_manager = VariableManager()

  task = Task(loader=loader)

  task._parent = object
  task._role  = object

  task.tags = ['test', 'test2', 'test3']

  assert task.evaluate_tags( only_tags = only_tags, skip_tags = skip_tags, all_vars = variable_manager._fact_cache ) == True

  task.tags = []


# Generated at 2022-06-23 07:07:59.134459
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # an example string
    line = 'test1, test2'
    # create an instance of class Taggable as obj
    obj = Taggable()
    # 0 means no tags should be skipped
    skip_tags = 0
    # create a dict all_vars
    all_vars = {}
    # add a value to the dict all_vars
    all_vars['test1'] = 'skip'
    all_vars['test2'] = 'toremove'
    # set the value of object attribute _tags to a line string
    obj._tags = line
    # set the value of object attribute _loader to None
    obj._loader = None
    # use the method evaluate_tags to check if the current item should be run

# Generated at 2022-06-23 07:08:00.772596
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == ''

# Generated at 2022-06-23 07:08:12.950165
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Unit test for method Taggable.evaluate_tags
    """
    class MyDumbClass(Taggable):
        pass
    mydumbobject = MyDumbClass()
    # evaluatoin of None is not allowed
    try:
        mydumbobject.evaluate_tags(None, None, None)
    except AnsibleError:
        assert True
    else:
        assert False
    # Case 1: run with only_tags
    assert mydumbobject.evaluate_tags(['a'], None, None) == True
    # Case 2: don't run with only_tags
    assert mydumbobject.evaluate_tags(['b', 'c'], None, None) == False
    # Case 3: run with skip_tags
    assert mydumbobject.evaluate_tags(None, ['d'], None)

# Generated at 2022-06-23 07:08:15.527742
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert set(t.tags) == set([])

# Generated at 2022-06-23 07:08:25.978399
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__) + "/../")
    import ansible.playbook
    import ansible.utils

    # here we have one play with 'tagged' and 'never' tags, and one play with no tags
    # test to see if we match under the following conditions:
    #   1) only_tags=tagged
    #   2) only_tags=never
    #   3) only_tags=always
    #   4) skip_tags=never
    #   5) skip_tags=always
    #   6) skip_tags=tagged
    #   7) skip_tags=all
    #   8) no tag options
    #   9) only_tags=strange-tag
    #  10) skip_tags=strange-

# Generated at 2022-06-23 07:08:36.298845
# Unit test for constructor of class Taggable
def test_Taggable():
    # test _load_tags method
    # create a new Taggable object
    tag = Taggable()

    # test case for both tags and tags_all
    # tags is a string and tags_all is a list
    attr = "tags"
    ds = "tag1,tag2"
    new_tags = tag._load_tags(attr, ds)
    assert new_tags == ['tag1', 'tag2']

    # test case for both tags and tags_all
    # tags is a list and tags_all us a string
    attr = "tags"
    ds = ["tag1", "tag2"]
    new_tags = tag._load_tags(attr, ds)
    assert new_tags == ['tag1', 'tag2']

    # test case for both tags and tags_all
    # tags

# Generated at 2022-06-23 07:08:48.131497
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    class DummyTaggable(Taggable):
        def __init__(self, play_context, tags=None, only_tags=None, skip_tags=None):
            super(DummyTaggable, self).__init__()
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.play_context = play_context
            self.name = 'dummy_taggable'
            self._loader = None

    pc = PlayContext()
    pc.only_tags = ['only_tag1', 'only_tag2']
    pc.skip_tags = ['skip_tag1', 'skip_tag2']
    dt = DummyTaggable(pc)

# Generated at 2022-06-23 07:09:00.098934
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.role.include import Include

    # Create test instance
    include = Include()

    # Create tags variables
    tags = ["test"]
    only_tags = ["test"]
    skip_tags = []
    all_vars = []

    # Test for tags evaluation
    assert True == include.evaluate_tags(only_tags, skip_tags, all_vars)

    # Create tags variables
    tags = ["test"]
    only_tags = ["test"]
    skip_tags = ["test"]
    all_vars = []

    # Test for tags evaluation
    assert False == include.evaluate_tags(only_tags, skip_tags, all_vars)

    # Create tags variables
    tags = ["test"]
    only_tags = ["foo"]
    skip_tags = []
   

# Generated at 2022-06-23 07:09:03.270048
# Unit test for constructor of class Taggable
def test_Taggable():
    #Test for default constructor
    myTaggable=Taggable()
    assert myTaggable._tags == []
    assert myTaggable._load_tags("tags","[u'ping', u'pong']") == [u'ping',u'pong']

# Generated at 2022-06-23 07:09:04.793619
# Unit test for constructor of class Taggable
def test_Taggable():
    # Make sure the class is available
    assert Taggable



# Generated at 2022-06-23 07:09:09.620280
# Unit test for constructor of class Taggable
def test_Taggable():

    # create a fake class for testing
    class MyTaggable(Taggable):
        def __init__(self):
            super(MyTaggable, self).__init__()
            self.tags = ['tag1', 'tag2']

    tag = MyTaggable()
    print(tag.tags)

# Generated at 2022-06-23 07:09:20.862962
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.defaults import DefaultVars
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    import copy

    class fake_loader:
        def get_basedir(self):
            return "."

    class fake_playbook:
        def get_loader(self):
            return fake_loader()

    def _get_play_context(play, task, variable_manager, loader=None, templar=None):
        all_vars = variable_manager.get_vars(play=play, task=task)

# Generated at 2022-06-23 07:09:28.838329
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ["a", "b"]
    assert taggable.evaluate_tags(['a', 'c'], None, {})
    assert taggable.evaluate_tags(None, ['a'], {})
    assert taggable.evaluate_tags(['a', 'c'], ['a'], {})
    assert not taggable.evaluate_tags(['c'], None, {})
    assert not taggable.evaluate_tags(None, ['a', 'c'], {})
    assert not taggable.evaluate_tags(['c'], ['a', 'c'], {})
    assert not taggable.evaluate_tags(['always'], None, {})
    assert taggable.evaluate_tags(['always'], ['never'], {})
   

# Generated at 2022-06-23 07:09:40.629305
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []
    assert t.tags == []
    t = Taggable(tags=['foo', 'bar'])
    assert t._tags == ['foo', 'bar']
    assert t.tags == ['foo', 'bar']
    # check for bad types for tags attribute
    try:
        t = Taggable(tags=42)
    except Exception as e:
        assert type(e) == AnsibleError
    try:
        t = Taggable(tags='foo, bar')
    except Exception as e:
        assert type(e) == AnsibleError
    try:
        t = Taggable(tags=['foo', 42])
    except Exception as e:
        assert type(e) == AnsibleError


# Generated at 2022-06-23 07:09:51.041595
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    ti = TaskInclude()
    ti.tags = ['foo', 'bar']

    # tagged task, only_tags=['foo'], skip_tags=['none']
    assert True == ti.evaluate_tags(['foo'], ['none'], None)

    # tagged task, only_tags=['none'], skip_tags=['foo']
    assert False == ti.evaluate_tags(['none'], ['foo'], None)

    # tagged task, only_tags=['all'], skip_tags=[]
    assert True == ti.evaluate_tags(['all'], [], None)

    # untagged task, only_tags=['all'], skip_tags=['never']

# Generated at 2022-06-23 07:09:53.289824
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable_obj = Taggable()
    assert taggable_obj == taggable_obj, "Taggable object creation failed"

# Generated at 2022-06-23 07:10:04.066014
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test(Taggable):
        pass

    options = {}
    host = Test()

    # test default
    host.tags = set(['tag'])
    assert host.evaluate_tags(options.get('tags', None), options.get('skip_tags', None), {}) == True

    # test only_tags
    options['tags'] = set(['tag'])
    assert host.evaluate_tags(options.get('tags', None), options.get('skip_tags', None), {}) == True

    options['tags'] = set(['untagged'])
    assert host.evaluate_tags(options.get('tags', None), options.get('skip_tags', None), {}) == False

    # test skip_tags
    host.tags = set(['untagged'])

# Generated at 2022-06-23 07:10:12.614904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task_1 = Taggable()
    task_1.tags = ['task1', 'task2']
    task_2 = Taggable()
    task_2.tags = ['tagged']
    task_3 = Taggable()
    task_3.tags = ['tagged', 'task3']
    task_4 = Taggable()
    task_4.tags = ['tagged', 'never']
    task_5 = Taggable()
    task_5.tags = ['task5', 'task6']
    tasks = [task_1, task_2, task_3, task_4, task_5]

    # Run tagged tasks with skip tagged option
    for task in tasks:
        if task.tags != ['never']:
            assert(task.evaluate_tags(None, ['tagged'], {}) == False)

# Generated at 2022-06-23 07:10:21.414796
# Unit test for constructor of class Taggable
def test_Taggable():
  assert Taggable()._load_tags(attr=None,ds=['tag1','tag2']) == ['tag1','tag2']
  assert Taggable()._load_tags(attr=None,ds='tag1,tag2') == ['tag1','tag2']
  assert Taggable()._load_tags(attr=None,ds=123) == [123]
  assert Taggable()._load_tags(attr=None,ds={'key':'value'}) == ['{u\'key\': u\'value\'}']


# Generated at 2022-06-23 07:10:33.953232
# Unit test for constructor of class Taggable
def test_Taggable():
    print ("Taggable class:")
    print(Taggable.__dict__)
    my_taggable = Taggable()
    print ("my_taggable:")
    print(my_taggable.__dict__)
    my_taggable.tags = ['sometag']
    print ("my_taggable.tags:")
    print(my_taggable.tags)
    only_tags = ['foo_tag']
    skip_tags = ['bar_tag']
    all_vars = {'my_var': 1}
    print ("my_taggable.evaluate_tags")
    print(my_taggable.evaluate_tags(only_tags, skip_tags, all_vars))

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:10:40.110522
# Unit test for constructor of class Taggable
def test_Taggable():
    mytags = frozenset(['tag1', 'tag2'])
    mytask = Taggable()
    mytask.tags = mytags
    assert mytask.tags == frozenset(['tag1', 'tag2']), "Taggable tags are wrong."

# Generated at 2022-06-23 07:10:41.141300
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()


# Generated at 2022-06-23 07:10:52.608349
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test values
    task_name = "task 1"
    task_tags = [ 'tag1', 'tag2' ]
    task_should_run = True

    # Initialize Taggable class instance
    taggable = Taggable()

    # Assign private attribute values
    taggable._loader = None
    taggable._attributes = None
    taggable._ds = None
    taggable._ds_merged = None
    taggable.name = task_name

    # Assign class attribute values
    taggable.tags = task_tags

    # Test that the method _load_tags correctly handles a list of tags
    assert(taggable._load_tags(None, task_tags) == task_tags)

    # Test that the method _load_tags correctly handles a comma-separated
    # string

# Generated at 2022-06-23 07:10:54.475885
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:11:03.495319
# Unit test for constructor of class Taggable
def test_Taggable():
    import attributes.taggable

    fake_list_tags = ['a', 'b']

    taggable_test = attributes.taggable.Taggable()
    taggable_test.tags = fake_list_tags
    assert(len(taggable_test.tags) == 2)

    fake_str_tags = 'c,d'

    taggable_test = attributes.taggable.Taggable()
    taggable_test.tags = fake_str_tags
    assert(len(taggable_test.tags) == 2)

    try:
        taggable_test = attributes.taggable.Taggable()
        taggable_test.tags = 0
    except:
        assert(True)

# Generated at 2022-06-23 07:11:05.089748
# Unit test for constructor of class Taggable
def test_Taggable():
    testclass = Taggable()
    assert testclass is not None

# Generated at 2022-06-23 07:11:08.797114
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyModule(object):
        _tags = ['test1', 'test2']
    instance = Taggable()
    instance._loader = None
    instance.tags = DummyModule._tags
    success = instance.evaluate_tags(['test1'], [], {})
    assert success

# Generated at 2022-06-23 07:11:19.902227
# Unit test for constructor of class Taggable
def test_Taggable():
    """Test constructor for class Taggable."""
    from ansible.playbook.task import Task
    from ansible.playbook.base import Base

    t = Taggable()
    assert t is not None, 't is None'

    # Test tags are not set
    assert t._tags == [], 'expected _tags to be an empty list'

    # Test attribute tags is not set
    assert t.tags is None, 'expected t.tags to be None'

    # Test some special default values
    assert t.untagged == frozenset(['untagged']), 'expected t.untagged to be a frozenset(["untagged"])'

    # Test base class of Taggable
    t = Taggable()
    assert isinstance(t, Base), 'expected t to be an instance of Base'

# Generated at 2022-06-23 07:11:25.746404
# Unit test for constructor of class Taggable
def test_Taggable():
    ta = Taggable()
    ta._tags = ['test1', 'test2']
    assert ta.tags == ['test1', 'test2']
    ta._tags = 'test1, test2'
    assert ta.tags == ['test1', 'test2']
    assert ta.evaluate_tags(['test1'], ['test2'], {})
    assert not ta.evaluate_tags(['test2'], [], {})
    assert ta.evaluate_tags([], [], {})

# Generated at 2022-06-23 07:11:30.050587
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestTaggable(Taggable):
        pass

    test_tag = TestTaggable()
    assert isinstance(test_tag._taggable_attributes, frozenset)
    assert test_tag.tags == []


# Generated at 2022-06-23 07:11:40.673063
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Task without tags, its tag list is ['']
    task1 = Task()
    task1.tags = ['']

    # Task with tags='tag_x, tag_y'
    task2 = Task()
    task2.tags = ['tag_x', 'tag_y']

    # Task with tags='tag_x, tag_z, tag_k'
    task3 = Task()
    task3.tags = ['tag_x', 'tag_z', 'tag_k']

    # Task with tags='tag_y, tag_z, tag_k'
    task4 = Task()
    task4.tags = ['tag_y', 'tag_z', 'tag_k']

    # Task with tags='tag_z, tag_k'
    task5 = Task()

# Generated at 2022-06-23 07:11:41.675352
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()



# Generated at 2022-06-23 07:11:45.040430
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags is None
    assert t.evaluate_tags(only_tags=['toto'], skip_tags=['tata'], all_vars={}) is True

# Generated at 2022-06-23 07:11:47.726565
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = ['tag1', 'tag2']
    assert t.tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:11:49.223797
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Task()
    assert isinstance(t, Taggable)

# Generated at 2022-06-23 07:12:00.273847
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    roles = [ Role('foo'), Role('bar') ]
    play = Play(name='foo', roles=roles)
    tasks = [ Task(), Task() ]
    block = Block(tasks=tasks)

    # get tags
    print(play.tags)
    print(block.tags)
    print(block.tasks[0].tags)
    print(block.tasks[1].tags)
    play.tags.append('foo')
    block.tasks[0].tags.append('bar')
    block.tags.append('baz')
    print(play.tags)
    print(block.tags)
   

# Generated at 2022-06-23 07:12:11.991637
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass


# Generated at 2022-06-23 07:12:23.149144
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeLoader:
        pass

    class FakeVars(object):
        pass

    class FakeTaggable(Taggable):
        def __init__(self):
            self._loader = FakeLoader()
            self.tags = None

    def set_vars(variables):
        vars = FakeVars()
        vars.variable_manager = None
        vars.host_vars = variables
        vars.all = variables
        vars.get = lambda k, default=None: variables.get(k, default)

        for (k, v) in variables.items():
            vars.__dict__[k] = v

        return vars


# Generated at 2022-06-23 07:12:35.576393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    t = Templar(variables={})
    options = dict(
        tags = {
            'tags': [
                'always',
            ],
            'only_tags': [
                'always',
                'all',
                'test',
            ],
            'skip_tags': [
                'never',
                'all',
            ],
            'only_tags_list': [
                'always',
                'all',
                'test',
            ],
            'skip_tags_list': [
                'never',
                'all',
            ],
        },
    )

    x = Taggable()
    x._loader = None
    x._templar = t
    x.tags = t.template(options['tags'])
   

# Generated at 2022-06-23 07:12:36.735695
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable().tags is not None

# Generated at 2022-06-23 07:12:46.508326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class taggable_test_class(Taggable):
        def __init__(self):
            self.tags = None

    tt = taggable_test_class()
    # Test when only_tags is empty
    only_tags = []
    skip_tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True
    # Test with both empty
    only_tags = []
    skip_tags = []
    tt.tags = 'all'
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True
    # Test when only_tags contains "all"
    only_tags = ['all']
    skip_tags = []
    tt.tags = 'all'

# Generated at 2022-06-23 07:12:51.624758
# Unit test for constructor of class Taggable
def test_Taggable():
    test = Taggable()
    test._load_tags('_tags', ['test'])
    assert test.tags == ['test']
    test.tags = ['test']
    assert test.tags == ['test']

# Generated at 2022-06-23 07:12:53.097563
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []

# Generated at 2022-06-23 07:12:59.805275
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.callbacks
    import ansible.utils
    import ansible.constants

    ansible.callbacks.display = ansible.utils.display.Display()
    ansible.constants.HOST_KEY_CHECKING = False
    ansible.constants.DEFAULT_HOST_LIST = '/dev/null'
    ansible.constants.DEFAULT_MODULE_PATH = '/dev/null'
    ansible.constants.DEFAULT_PRIVATE_KEY_FILE = None
    ansible.constants.DEFAULT_SSH_ARGS = ''
    ansible.constants.DEFAULT_SUDO_USER = None
    ansible.constants.DE

# Generated at 2022-06-23 07:13:06.420537
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    tags = Taggable()
    tags._load_tags(tags.tags, 'tag1,tag2')
    #assert tags.tags == ['tag1', 'tag2']
    b = Base()
    vars = dict(foo='foo', bar='bar')
    assert tags.evaluate_tags('tag1', 'tag2', vars)

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:13:13.165548
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    class Object(object):
        def __init__(self):
            self.tags = []
            self._loader = None
    o = Object()
    o.tags = ['A', 'B']
    assert t.evaluate_tags(['A'], [], dict()) == True
    assert t.evaluate_tags(['C'], [], dict()) == False
    assert t.evaluate_tags(['always'], [], dict()) == True
    assert t.evaluate_tags(['all'], [], dict()) == True
    assert t.evaluate_tags(['tagged'], [], dict()) == True
    assert t.evaluate_tags(['tagged'], [], dict()) == True
    assert t.evaluate_tags(['B'], [], dict()) == True

# Generated at 2022-06-23 07:13:22.643872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    
    taggable = MockTaggable()
    taggable.load({'tags': ['test_tag1', 'test_tag2']})
    all_vars = dict()
    
    # test with only_tags: all and skip_tags: none
    only_tags = ['all', 'test_tag2']
    skip_tags = set()
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True
    
    # test with only_tags: none and skip_tags: all
    only_tags = set()
    skip_tags = ['all', 'test_tag2']

# Generated at 2022-06-23 07:13:32.471134
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    class TestTaggable(Taggable):
        pass
    test_obj = TestTaggable()

    # Test when "only_tags" is empty
    assert test_obj.evaluate_tags(only_tags = [], skip_tags = [], all_vars={}) == True

    # Test when "only_tags" as [always]
    assert test_obj.evaluate_tags(only_tags = ['always'], skip_tags = [], all_vars={}) == True

    # Test when "only_tags" as [always], "skip_tags" as [always]
    assert test_obj.evaluate_tags(only_tags = ['always'], skip_tags = ['always'], all_vars={}) == False

    # Test when "only_tags" as [nonexistent]


# Generated at 2022-06-23 07:13:43.398066
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # pylint: disable=unused-variable
    ''' tests the evaluate_tags() method of Taggable '''

    test_tags = ['a', 'b']
    only_tags = ['a', 'b', 'c']
    skip_tags = ['c', 'd']

    class Task(Taggable):
        pass

    class TaskWithTags(Taggable):
        tags = test_tags

    class TaskWithAlways(Taggable):
        tags = ['always']

    class TaskWithNever(Taggable):
        tags = ['never']

    class TaskWithTagged(Taggable):

        def __init__(self, loader=None):
            self._loader = loader
            self.tags = ['foo']
            super(TaskWithTagged, self).__init__()

    task = Task()
    task

# Generated at 2022-06-23 07:13:46.882390
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = Taggable()
    tags.tags = ['OSA-172']
    tags.evaluate_tags(['OSA-172'],['OSA-173'],{})

# Generated at 2022-06-23 07:13:57.877789
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import yaml
    from ansible import constants
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    moment = datetime.utcnow()
    host = Host(name="foo")
    inventory = Mock()
    templar = Templar(loader=None, variables={})
    task = Task()
    block = Block()

# Generated at 2022-06-23 07:13:59.810580
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-23 07:14:11.345688
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Block(Taggable):
        pass
    block = Block()
    assert not block.evaluate_tags(None, None, {})
    assert block.evaluate_tags(['foo', 'bar'], None, {'tags': ['foo', 'bar']})
    assert block.evaluate_tags(['foo', 'bar'], None, {'tags': ['all', 'foo']})
    assert block.evaluate_tags(['foo', 'bar'], None, {'tags': ['all', 'always']})
    assert not block.evaluate_tags(['foo', 'bar'], None, {'tags': ['all', 'never']})
    assert not block.evaluate_tags(['foo', 'bar'], None, {'tags': ['foo', 'never']})

# Generated at 2022-06-23 07:14:13.373291
# Unit test for constructor of class Taggable
def test_Taggable():
    test_class = Taggable()
    assert test_class._tags == list()
    assert test_class.tags == list()

# Generated at 2022-06-23 07:14:15.321696
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    s = Taggable()
    assert set(t._tags) == s._tags

# Generated at 2022-06-23 07:14:24.718545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """ Method evaluate_tags returns the right result in any case """

    # Initialize variables
    all_vars = {}
    only_tags = ''
    skip_tags = ''
    tags = ''

    # Initialize an instance of Taggable
    taggable = Taggable()
    taggable.tags = tags

    # Assert that the method evaluate_tags return the right value
    # in any case (only_tags are empty and skip_tags are empty)
    assert (taggable.evaluate_tags(only_tags, skip_tags, all_vars))

    # Set the variable only_tags
    only_tags = 'test_only_tags'

    # Assert that the method evaluate_tags return the right value
    # in any case (only_tags are not empty and skip_tags are empty)

# Generated at 2022-06-23 07:14:36.363250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Subclass of Taggable, with fields suitable for templating
    class SubTaggable(Taggable):
        _name = FieldAttribute(isa='string')
        _tags = FieldAttribute(isa='list')

    # Some arbitrary tags that we'll use in the test
    tags1 = ['always', 'first']
    tags2 = ['second']
    tags3 = ['never']

    # Note that this is a 'list' of SubTaggable, even though we only have one
    task1 = [SubTaggable(name=u'task1', tags=tags1)]

    play_context = {}

    # Run test with invalid inputs

# Generated at 2022-06-23 07:14:47.287231
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.constants import DEFAULT_VAULTPASS  # Fake load the ansible.constants module
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager

    # Create vars for tests
    only_tags = set([])
    skip_tags = set([])
    all_vars = dict()
    fake_variable_manager = VariableManager(loader=None, variables=all_vars)
    fake_loader = None

    # Create Taggable object
    fake_taggable = Taggable()
    fake_taggable.tags = list()
    fake_taggable._loader = fake_loader
    fake_taggable._variable_manager = fake_variable_manager

    # Run evaluate_tags

# Generated at 2022-06-23 07:14:55.081436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    accepts a list of tags, and returns True or False
    based on whether the current task should be executed
    or not.  Takes into account the C{only_tags} and
    C{skip_tags} inventory variables.
    """
    class FakeTaggable(Taggable):
        def __init__(self):
            self.tags = ['common']
            self.vars = {'only_tags': ['common'], 'skip_tags': ['stop_here']}

    i = FakeTaggable()
    assert i.evaluate_tags(i.vars['only_tags'], i.vars['skip_tags'], i.vars) is True

    class FakeTaggable(Taggable):
        def __init__(self):
            self.tags = ['client', 'common']
            self.vars

# Generated at 2022-06-23 07:15:08.140828
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    # Setup test task with tags
    task = Task()
    task.tags = ["docker", "nginx"]

    # Should run when only_tags = [["nginx", "docker"]]
    assert task._evaluate_tags(only_tags=["nginx", "docker"], skip_tags=[], all_vars={})
    # Should not run when only_tags = [["one", "two"]]
    assert not task._evaluate_tags(only_tags=["one", "two"], skip_tags=[], all_vars={})

    # Should not run when skip_tags = [["nginx", "docker"]]
    assert not task._evaluate_tags(only_tags=[], skip_tags=["nginx", "docker"], all_vars={})
    # Should run when skip_tags

# Generated at 2022-06-23 07:15:10.948666
# Unit test for constructor of class Taggable
def test_Taggable():

    test = Taggable()
    test._tags = ['tag1', 'tag2']


    assert test.evaluate_tags(['tag1'], None, None)



# Generated at 2022-06-23 07:15:16.244565
# Unit test for constructor of class Taggable
def test_Taggable():
    # Create an instance Taggable
    taggable = Taggable()

    # Check if the default value of _tags is list
    assert taggable._tags == [], "Default value of _tag is not list"

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-23 07:15:23.877799
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.playbook import Playbook

    task = Task()
    block = Block()
    play = Play()
    role = Role()
    task_include = TaskInclude()
    handler = Handler()
    playbook = Playbook()

    # Only tags : None
    assert task.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    assert block.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})

# Generated at 2022-06-23 07:15:33.104539
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    t = Task()

    with pytest.raises(AnsibleError):
        t.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    assert t.evaluate_tags(only_tags=['one','two'], skip_tags=[], all_vars=None)
    assert not t.evaluate_tags(only_tags=['one','two'], skip_tags=[], all_vars=None)

# Test for method _load_tags of class Taggable

# Generated at 2022-06-23 07:15:33.792914
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-23 07:15:43.743733
# Unit test for constructor of class Taggable
def test_Taggable():
    from . import DataLoader
    from . import Task

    loader = DataLoader()
    t = Task.load(dict(name='test', tags=[]), loader=loader, from_yaml=False)
    assert t._tags == []
    assert t.tags == []

    t = Task.load(dict(name='test', tags=['tag1']), loader=loader, from_yaml=False)
    assert t._tags == ['tag1']
    assert t.tags == ['tag1']

    t = Task.load(dict(name='test', tags='tag1'), loader=loader, from_yaml=False)
    assert t._tags == ['tag1']
    assert t.tags == ['tag1']


# Generated at 2022-06-23 07:15:51.050494
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test if tags is evaluated correctly when only_tags is present
    test_taggable_1 = TestTaggable(['tag1', 'tag2', 'tag3'])
    assert (test_taggable_1.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True)
    assert (test_taggable_1.evaluate_tags(only_tags=['tag4'], skip_tags=[], all_vars={}) == False)
    assert (test_taggable_1.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == True)

    # Test if only_tags is evaluated