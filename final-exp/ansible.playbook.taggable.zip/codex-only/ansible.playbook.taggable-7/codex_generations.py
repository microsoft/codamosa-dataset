

# Generated at 2022-06-23 07:05:53.593881
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import ansible.playbook.base
    import ansible.template
    import ansible.utils.template
    import ansible.utils.unsafe_proxy

    class FakeLoader:
        def get_basedir(self, name=None):
            pass
        def path_dwim(self, name):
            return name

    fake_basedir = 'fake_basedir'
    fake_filename = 'fake_filename'

# Generated at 2022-06-23 07:06:04.324066
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    a = ["test tag 1","test tag 2"]
    b = "test tag 1,test tag 2"
    c = 10
    d = ["test tag 1",10,"test tag 2"]
    e = "test tag 1,10,test tag 2"

# Generated at 2022-06-23 07:06:15.283761
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class testClass(Taggable):
        def __init__(self):
            self.tags = ['testTag']

    t = testClass()

    # Test -v skip_tags=testTag,all
    only_tags = None
    skip_tags = ['testTag','all']
    should_run = t.evaluate_tags(only_tags, skip_tags, dict())
    assert should_run == False

    # Test -v only_tags=testTag
    only_tags = ['testTag']
    skip_tags = None
    should_run = t.evaluate_tags(only_tags, skip_tags, dict())
    assert should_run == True

    # Test -v only_tags=failTag,testTag
    only_tags = ['failTag','testTag']
    skip_tags = None
    should_run = t

# Generated at 2022-06-23 07:06:27.338967
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.template
    import copy
    import sys
    class MockModuleUtils(object): pass
    class MockTemplate(ansible.template.AnsibleEnvironment):
        def __init__(self):
            ansible.template.AnsibleEnvironment.__init__(self, MockModuleUtils())
            self.variables = {}
    class MockVars(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def get_vars(self, *args, **kwargs):
            return self.args, self.kwargs
    class MockAction(ansible.playbook.ActionBase):
        def __init__(self):
            self._loader = MockLoader()
            self._templar

# Generated at 2022-06-23 07:06:37.266171
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeVars:
        pass

    class FakeRole:
        def __init__(self):
            self._loader = None
            self.tags = []

    fake_role = FakeRole()
    fake_role.all_vars = FakeVars()

    a = fake_role.evaluate_tags([], [], fake_role.all_vars)
    assert a == True
    b = fake_role.evaluate_tags([], ['all'], fake_role.all_vars)
    assert b == False
    c = fake_role.evaluate_tags([], ['all'], fake_role.all_vars)
    assert c == False
    d = fake_role.evaluate_tags(['all'], [], fake_role.all_vars)
    assert d == True
    e = fake_role.evaluate_

# Generated at 2022-06-23 07:06:48.147799
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    module = object()
    class FakeTask(Taggable):
        loader = module

    task = FakeTask()
    all_vars = {}

    # Test 1
    # No tags provided, no tag options, should always run
    only_tags = []
    skip_tags = []
    task.tags = []
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test 2
    # No tags provided, only_tags provided, should not run
    only_tags = ['tag4', 'tag5']
    task.tags = []
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Test 3
    # Tags provided, no tag options, should always run
    only_tags = []
    skip_tags = []
    task

# Generated at 2022-06-23 07:06:51.513881
# Unit test for constructor of class Taggable
def test_Taggable():
    class tmp(Taggable):
        pass
    t = tmp()
    assert isinstance(t.tags, list)
    assert t.tags == []

# Generated at 2022-06-23 07:06:53.006878
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == []

# Generated at 2022-06-23 07:07:01.814597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Test method evaluate_tags of class Taggable'''
    t1 = Taggable()
    only_tags = frozenset([])
    skip_tags = frozenset(['never'])
    assert t1.evaluate_tags(only_tags, skip_tags, {}) == True

    t1 = Taggable()
    only_tags = frozenset(['tag1'])
    skip_tags = frozenset(['tag2'])
    assert t1.evaluate_tags(only_tags, skip_tags, {'tag1': 'tagged', 'tag2': 'never'}) == True

    t1 = Taggable()
    only_tags = frozenset(['tag1'])
    skip_tags = frozenset(['tag2'])

# Generated at 2022-06-23 07:07:04.683623
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_object = Taggable()
    test_object.tags = ['test_tag']
    assert test_object.evaluate_tags([],['test_tag'], {}) == False

# Generated at 2022-06-23 07:07:16.624655
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager

    data = '''
- hosts: localhost
  tasks:
    - ping:
  tags:
    - all
    - always
    - never
    - tagged
    - remote
  when: always
'''

    task = Task.load(data[1], variable_manager=VariableManager(), loader=AnsibleLoader(data))
    assert task.evaluate_tags({}, {}, {})
    assert not task.evaluate_tags({'remote'}, {}, {})
    assert task.evaluate_tags({'always'}, {}, {})
    assert not task.evaluate_tags({'always'}, {'always'}, {})
    assert task.evaluate_tags

# Generated at 2022-06-23 07:07:18.909551
# Unit test for constructor of class Taggable
def test_Taggable():
    test_taggable = Taggable()
    assert isinstance(test_taggable.tags, list)


# Generated at 2022-06-23 07:07:22.417835
# Unit test for constructor of class Taggable
def test_Taggable():
    loader_mock = {}
    t = Taggable(loader=loader_mock)
    assert t.tags == []
    assert t._loader == loader_mock


# Generated at 2022-06-23 07:07:27.547979
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []
    assert taggable.untagged == frozenset(['untagged'])
    assert isinstance(taggable.tags, list)
    assert isinstance(taggable.untagged, frozenset)

# Generated at 2022-06-23 07:07:34.916712
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    taggable = FakeTaggable([])
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert taggable.evaluate_tags(only_tags=["never"], skip_tags=[]) == False
    assert taggable.evaluate_tags(only_tags=[], skip_tags=["always"]) == False
    assert taggable.evaluate_tags(only_tags=["never"], skip_tags=["never"]) == False

    taggable.tags = ["never"]
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[]) == False

# Generated at 2022-06-23 07:07:47.652233
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # No tags, no only_tags, no skip_tags
    assert Taggable().evaluate_tags(only_tags = None, skip_tags = None, all_vars = {})

    # No tags, only_tags contains 'tag1', no skip_tags
    assert not Taggable().evaluate_tags(only_tags = ['tag1'], skip_tags = None, all_vars = {})

    # No tags, no only_tags, skip_tags contains 'tag1'
    assert Taggable().evaluate_tags(only_tags = None, skip_tags = ['tag1'], all_vars = {})

    # Tags contains 'tag1', no only_tags, skip_tags contains 'tag1'

# Generated at 2022-06-23 07:07:52.644981
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import Include

    b = Block()
    b.tags = ['tag1','tag2']
    assert b.tags == ['tag1','tag2'], b.tags

    i = Include()
    i.tags = ['tag3','tag4']
    assert i.tags == ['tag3','tag4'], i.tags

# Generated at 2022-06-23 07:07:54.449436
# Unit test for constructor of class Taggable
def test_Taggable():
   t = Taggable()
   assert(t.tags == [])
   assert(t.untagged == frozenset(['untagged']))

# Generated at 2022-06-23 07:08:09.744220
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = None
    skip_tags = None
    all_vars = None
    taggable = Taggable()
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = None
    skip_tags = ['skip_tag']
    all_vars = None
    taggable = Taggable()
    taggable.tags = ['task_tag']
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['only_tag']
    skip_tags = None
    all_vars = None
    taggable = Taggable()
    taggable.tags = ['only_tag']

# Generated at 2022-06-23 07:08:11.109758
# Unit test for constructor of class Taggable
def test_Taggable():
  t = Taggable()
  assert t._tags == []


# Generated at 2022-06-23 07:08:20.771557
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role

    for clsdef in [Base, Role]:
        obj = clsdef()
        assert obj.tags == []

        obj = clsdef(tags=['test'])
        assert obj.tags == ['test']

        obj = clsdef(tags='test,one,two')
        assert obj.tags == ['test', 'one', 'two']

        obj = clsdef(tags='test')
        assert obj.tags == ['test']


# Generated at 2022-06-23 07:08:32.744357
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult

    play_context = PlayContext()
    play_context.only_tags = ['test_tag']
    play_context.skip_tags = ['untagged']
    play_context._tqm = None
    play_context._task = None

    my_loader = None

    def my_load_list_of_tasks(self,):
        return ['test_task']

    def my_get_vars(self,):
        return dict()

    my_include_role = Taggable()
    my_include_role._load_list_of_tasks = my_load_list_of_tasks
    my_include_role._get_vars = my_get_vars
    my_

# Generated at 2022-06-23 07:08:41.910678
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # Case 1: evaluate_tags for Task
    only_tags = ['always', 'test_only',]
    skip_tags = ['never', 'test_skip',]

    t = Task()
    t._ds = {}
    t._ds['tags'] = ['always', 'test_only']

    # should run
    assert t.evaluate_tags(only_tags, [], t._ds) == True
    assert t.evaluate_tags(only_tags, skip_tags, t._ds) == True

    t._ds['tags'] = ['never', 'test_skip']
    # should not run
    assert t.evaluate_tags(only_tags, skip_tags, t._ds) == False

# Generated at 2022-06-23 07:08:53.930297
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    from ansible.parsing.utils.yaml import from_yaml

    DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data')
    PLAYBOOK_PATH = os.path.join(DATA_PATH, 'playbook')

    vars = {
        'var1': 'var1',
        'var2': 'var2',
        'var3': 'var3',
        'var4': 'var4',
        'var5': 'var5',
    }

    # miniyaml test
    test1 = {'name': 'test1', 'tags': 'tag1, tag2'}
    test2 = {'name': 'test2', 'tags': 'tag4'}

# Generated at 2022-06-23 07:09:03.533719
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    loader, inventory, variable_manager = C.get_constants()

    playbook = Playbook.load(loader=loader, variable_manager=variable_manager,
                             host_list=['localhost'], play=dict(name='pl1', hosts=['all']))
    host = inventory._get_host('localhost')
    play = playbook.get_plays()[0]

    task = Task()
    task._role = [Role()]

# Generated at 2022-06-23 07:09:09.302685
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = ['test1']

    t = TestTaggable()
    res = t.evaluate_tags(['test1'], [], {})
    assert res == True

if __name__ == '__main__':
    # Run unit tests
    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:09:17.483867
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags(None, ['foo']) == ['foo']
    assert Taggable._load_tags(None, 'foo') == ['foo']
    assert Taggable._load_tags(None, ['foo', 'bar']) == ['foo', 'bar']
    assert Taggable._load_tags(None, 'foo, bar') == ['foo', 'bar']
    try:
        Taggable._load_tags(None, 123)
    except AnsibleError:
        pass
    else:
        raise AssertionError('should have raised AnsibleError')

# Generated at 2022-06-23 07:09:26.657439
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    # Initialize variables
    all_vars = dict()
    only_tags = set()
    skip_tags = set()

    # Create object of class Taggable
    obj = Taggable()

    # Role object will be used for the test
    obj = Role()

    # test case 1 - No "tags:" attribute in role
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # test case 2 - "tags:" attribute in role with single tag entry
    obj.tags = 'role1'
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # test case 3 - "tags:" attribute in role with multiple tag entries

# Generated at 2022-06-23 07:09:39.279526
# Unit test for constructor of class Taggable
def test_Taggable():
    # Create an instance of Taggable
    test_taggable = Taggable()
    # Check if the tags field is initialized
    assert test_taggable._tags == list
    # Check if untagged attribute is initialized with untagged value
    assert test_taggable.untagged == frozenset(['untagged'])
    # Check if tags field is initialized correctly from tags provided in list format
    assert test_taggable._load_tags('tags', ['test1', 'test2']) == ['test1', 'test2']
    # Check if tags field is initialized correctly from tags provided in string format
    assert test_taggable._load_tags('tags', 'test1, test2') == ['test1', 'test2']
    # Check if AnsibleError is raised if tags are provided in an invalid format 

# Generated at 2022-06-23 07:09:49.247243
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.plugins import module_loader as plugin_loader
    from ansible.playbook.task import Task
    test_task    = Task.load(dict(action=dict(module='ping'), tags=['a', 'b', 'c']),
                             play=None, variable_manager=None, loader=plugin_loader)
    test_task_1  = Task.load(dict(action=dict(module='ping')),
                             play=None, variable_manager=None, loader=plugin_loader)
    test_task_2  = Task.load(dict(action=dict(module='ping'), tags='a, b, c'),
                             play=None, variable_manager=None, loader=plugin_loader)
    assert (test_task.tags == ['a', 'b', 'c'])

# Generated at 2022-06-23 07:09:54.300295
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._load_tags('dummy', ['tag', 'tag2']) == ['tag', 'tag2']
    assert t._load_tags('dummy', 'tag') == ['tag']
    try:
        t._load_tags('dummy', 1234)
        1/0
    except:
        pass


if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:09:55.494532
# Unit test for constructor of class Taggable
def test_Taggable():
    input = {'tags': ['install']}
    assert Taggable._load_tags(None, input) == input

# Generated at 2022-06-23 07:10:02.955970
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    b_task = Taggable()
    b_task.tags = ['test', 'moduletest']
    assert b_task.evaluate_tags(['test'], [], {}) == True
    assert b_task.evaluate_tags(['test'], ['test'], {}) == False
    assert b_task.evaluate_tags([], ['test', 'moduletest'], {}) == False
    assert b_task.evaluate_tags(['test', 'moduletest'], ['test', 'moduletest'], {}) == False


# Generated at 2022-06-23 07:10:07.472088
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._tags = []
    assert (t.tags == [])

    t._tags = 'foo,bar'
    assert (t.tags == ['foo','bar'])

    t._tags = ['foo','bar']
    assert (t.tags == ['foo','bar'])

    t._tags = 'foo'
    assert (t.tags == ['foo'])

    t._tags = ['foo']
    assert (t.tags == ['foo'])

# Generated at 2022-06-23 07:10:08.523906
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert(t._tags == [])


# Generated at 2022-06-23 07:10:14.357086
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.play import Play

    p = Play()
    p._full_vars = p._finder._load_vars_files(p._loader, 'all')
    p._full_vars.update(p._loader.get_basedir())
    p._full_vars.update(p._loader.get_vars(p._basedir))
    p._tqm = None

    try:
        t = Taggable()
    except Exception as e:
        print(str(e))

    t.name = "test"
    t.tags = ["one", "two", "list", "three", "list"]
    print(t.evaluate_tags(['all', 'list'], [], p._full_vars))

# Generated at 2022-06-23 07:10:20.350892
# Unit test for constructor of class Taggable
def test_Taggable():
    assert Taggable._load_tags(None, "a]") == ['a]']
    assert Taggable._load_tags(None, [1, 2, 3]) == [1, 2, 3]
    assert Taggable._load_tags(None, "a,b,c") == ['a', 'b', 'c']

# Generated at 2022-06-23 07:10:21.414519
# Unit test for constructor of class Taggable
def test_Taggable():
    assert 'untagged' in Taggable.untagged

# Generated at 2022-06-23 07:10:33.953949
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.mod_args import ModuleArgsParser

    task = dict(
        action=dict(
            module='shell',
            args=dict(
                _raw_params='echo "Hello World"'
            )
        )
    )

    module_args_parser = ModuleArgsParser(task['action'])

    class MockAnsibleModule:
        def __init__(self, module_name='mock_shell'):
            self.module_name = module_name
            self.params = module_args_parser.get()

    class MockTaggable(Taggable):
        def __init__(self, action, args, ignore_errors=False):
            self.action = action
            self.args = args
            self.ignore_errors = ignore_errors
            self.tags = action.get('tags')

# Generated at 2022-06-23 07:10:46.042513
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ['tag1', 'tag2']
    print('evaluation1: ' + str(t.evaluate_tags(['tag1', 'tag2'], [], None)))
    print('evaluation2: ' + str(t.evaluate_tags(['tag1', 'tag2'], ['tag2'], None)))
    print('evaluation3: ' + str(t.evaluate_tags(['tag1', 'tag2'], ['tag3'], None)))
    print('evaluation4: ' + str(t.evaluate_tags(['tag1'], ['tag2'], None)))
    print('evaluation5: ' + str(t.evaluate_tags([], ['tag2'], None)))
    print('evaluation6: ' + str(t.evaluate_tags([], [], None)))

# Generated at 2022-06-23 07:10:57.201739
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    b = Base()
    b.vars = {'foo': 'bar'}
    b.tags = ['a', 'b']
    b.dep_chain = []
    i = VariableManager()
    i.add_or_update_vars({'foo': 'far'})
    i.set_fact('foo', 'faz')
    i.add_or_update_vars({'bar': 'baz'})
    print(combine_vars(i.get_vars()))
    print(b.evaluate_tags(['a', 'b'], ['bar'], combine_vars(i.get_vars())))

# Generated at 2022-06-23 07:10:58.909152
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()

# Generated at 2022-06-23 07:11:08.457854
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import copy
    import os
    import sys
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 07:11:11.979035
# Unit test for constructor of class Taggable
def test_Taggable():
    try:
        obj = Taggable()
    except Exception as e:
        assert False, "Failed to construct Taggable instance: " + str(e)


# Generated at 2022-06-23 07:11:22.718177
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = ['tag1', 'tag2', 'tag3']
    taggable = Taggable()
    taggable.tags = tags
    assert taggable.evaluate_tags(only_tags, skip_tags, None) == True

    tags = ['tag1']
    only_tags = ['tag1']
    skip_tags = ['tag2', 'tag3']
    taggable = Taggable()
    taggable.tags = tags
    assert taggable.evaluate_tags(only_tags, skip_tags, None) == True

    tags = ['tag1']
    only_tags = ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-23 07:11:24.583152
# Unit test for constructor of class Taggable
def test_Taggable():
    test_instance = Taggable()
    assert test_instance._tags == []
    return True


# Generated at 2022-06-23 07:11:36.813691
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    if taggable.tags == []:
        print("Taggable Constructor Test 1: Pass")
    else:
        print("Taggable Constructor Test 1: Fail")

    from collections import namedtuple
    FakeObj = namedtuple('FakeObj', ['tags'])
    taggable = Taggable(FakeObj(tags='fake'))
    if taggable.tags == ['fake']:
        print("Taggable Constructor Test 2: Pass")
    else:
        print("Taggable Constructor Test 2: Fail")

    taggable = Taggable(FakeObj(tags=['fake1', 'fake2']))
    if taggable.tags == ['fake1', 'fake2']:
        print("Taggable Constructor Test 3: Pass")

# Generated at 2022-06-23 07:11:48.855791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object:
    import ansible.playbook.task_include as task_include
    include_task = task_include.TaskInclude()

    # Set tags
    include_task.tags = ['tag1']
    # Check evaluate_tags with only_tags
    only_tags = ['tag1']
    assert include_task.evaluate_tags(only_tags, None, {}) is True
    only_tags = ['tag2']
    assert include_task.evaluate_tags(only_tags, None, {}) is False
    only_tags = ['tag1', 'tag2']
    assert include_task.evaluate_tags(only_tags, None, {}) is True
    # Check evaluate_tags with skip_tags
    skip_tags = ['tag1']

# Generated at 2022-06-23 07:11:58.267370
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    This is a unit test to verify tags using a class Taggable.
    :return:
    '''
    class TaggableTest(Taggable):
        pass
    taggabletest = TaggableTest()
    taggabletest.tags = ['foo', 'bar', 'not']

    only_tags = ['foo', 'bar']
    skip_tags = []
    all_vars = {}
    taggabletest.evaluate_tags(only_tags, skip_tags, all_vars)

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:12:09.488432
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    t = Task()
    assert hasattr(t, 'tags') and t.tags == None
    t.tags = ['tag1']
    assert hasattr(t, 'tags') and t.tags == ['tag1']
    t.tags.append('tag2')
    assert hasattr(t, 'tags') and t.tags == ['tag1', 'tag2']

    t2 = Task(tags=['tag3'])
    assert hasattr(t2, 'tags') and t2.tags == ['tag3']

    ir = IncludeRole(tags=['tag4', 'tag5'])
    assert hasattr(ir, 'tags') and ir.tags == ['tag4', 'tag5']

# Generated at 2022-06-23 07:12:20.962529
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
        Tests the basic functionality of the Taggable class.
    """

    class TaggableClass(Taggable):
        tags = []

    # tags not set, all always
    taggable = TaggableClass(tags=None)
    assert (taggable.evaluate_tags(only_tags=[], skip_tags=['always']))
    assert (taggable.evaluate_tags(only_tags=[], skip_tags=[]))
    assert (taggable.evaluate_tags(only_tags=[], skip_tags=['foo', 'bar']))

    # tags not set, all tagged
    taggable.tags = None
    assert (taggable.evaluate_tags(only_tags=['tagged'], skip_tags=[]))

# Generated at 2022-06-23 07:12:24.367991
# Unit test for constructor of class Taggable
def test_Taggable():
    import ansible.playbook.task as task
    host = "localhost"
    t = task.Task(dict(action=dict(module="setup", args="")))
    print(t.tags)


if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:12:37.349653
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable.tags = ["always"]

    all_vars = dict()

    only_tags = ["tagged"]
    # must return True since 'always' is in tags and
    # there is no 'never' in tags
    assert taggable.evaluate_tags(only_tags, list(), all_vars)

    only_tags = ["tagged", "never"]
    # must return False since 'never' is in tags
    assert not taggable.evaluate_tags(only_tags, list(), all_vars)

    skip_tags = ["never"]
    # must return True since there is no 'never' in tags
    assert taggable.evaluate_tags(list(), skip_tags, all_vars)

    skip_tags = ["always"]
    # must return False since there is

# Generated at 2022-06-23 07:12:38.953235
# Unit test for constructor of class Taggable
def test_Taggable():
    p = Taggable()
    assert p.tags == []

# Generated at 2022-06-23 07:12:43.390623
# Unit test for constructor of class Taggable
def test_Taggable():
        _loader = None
        _task = Taggable()
        assert _task.tags == []

# Generated at 2022-06-23 07:12:49.195707
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test Taggable.evaluate_tags
    '''
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['foo', 'bar']

    # should_run is True if the task passed
    should_run = test_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert should_run == True

    # should_run is False if the task passed
    should_run = test_taggable.evaluate_tags(only_tags=None, skip_tags=[], all_vars={})
    assert should_run == False

    # should_run is False if the task passed

# Generated at 2022-06-23 07:12:58.167687
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Test method evaluate_tags of class Taggable'''

    test_object = Taggable()
    test_object.tags = ['foo', 'bar']

    only_tags = []
    skip_tags = []
    all_vars = {}

    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['foo']
    skip_tags = []
    all_vars = {}

    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = []
    skip_tags = ['foo']
    all_vars = {}

    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['foo']
    skip

# Generated at 2022-06-23 07:13:07.800510
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Unit test for method `evaluate_tags` of class `Taggable`
    '''
    # validate inclusion with 'all' tag
    taggable = Taggable()
    taggable._tags = ['all']
    assert taggable._load_tags('_tags', taggable._tags) == taggable._tags
    assert taggable.evaluate_tags(['all'], None, None) == True

    # validate inclusion with no 'all' tag
    taggable = Taggable()
    assert taggable.evaluate_tags(['all'], None, None) == False

    # validate exclusion with 'never' tag
    taggable = Taggable()
    taggable._tags = ['never']
    assert taggable._load_tags('_tags', taggable._tags) == tagg

# Generated at 2022-06-23 07:13:10.811840
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert isinstance(taggable._load_tags(taggable.tags, ['test1', 'test2']), list)
    assert isinstance(taggable._load_tags(taggable.tags, 'test1,test2'), list)


# Generated at 2022-06-23 07:13:21.580913
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role

    t = Taggable()
    assert t.tags == []
    assert t._load_tags(None, 'foo') == ['foo']
    assert t._load_tags(None, ['foo']) == ['foo']
    assert t._load_tags(None, [1, 2, 3]) == [1, 2, 3]

    t = Role()
    assert t.tags == []
    assert t._load_tags(None, 'foo') == ['foo']
    assert t._load_tags(None, ['foo']) == ['foo']
    assert t._load_tags(None, [1, 2, 3]) == [1, 2, 3]

    t = Base()
    assert t.tags == []
    assert t._load

# Generated at 2022-06-23 07:13:28.637763
# Unit test for constructor of class Taggable
def test_Taggable():
    class TempTaggable(Taggable):

        def __init__(self):
            self.tags = ['tag1', 2]

    tt = TempTaggable()

    assert tt._load_tags(None, ['tag1', 2]) == ['tag1', 2]
    assert tt._load_tags(None, 'tag1, 2') == ['tag1', '2']
    assert tt._load_tags(None, 'tag1') == ['tag1']
    assert tt._load_tags(None, '2') == ['2']

    try:
        tt._load_tags(None, 123)
        raise AssertionError("123 is not a valid type for tags")
    except AnsibleError:
        pass

# unit test for function evaluate_tags

# Generated at 2022-06-23 07:13:34.120456
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

    t = Taggable()
    assert isinstance(t, Taggable)
    assert isinstance(t, (Base, BaseTask, BaseRole, BaseBlock, BaseHandler, BasePlay))
    assert t.tags == []


# Generated at 2022-06-23 07:13:44.304678
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = [ '1' ]
    taggable._loader = []
    taggable._all_vars = {}
    assert taggable.evaluate_tags(['1'], [], taggable._all_vars)
    assert not taggable.evaluate_tags([], [], taggable._all_vars)
    assert taggable.evaluate_tags(['always'], [], taggable._all_vars)
    assert not taggable.evaluate_tags(['never'], [], taggable._all_vars)

    taggable.tags = [ ['2'] ]
    assert taggable.evaluate_tags(['2'], [], taggable._all_vars)


# Generated at 2022-06-23 07:13:56.288657
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import pytest

    tags1 = ['tag1', 'tag2']
    tags2 = ['tag1', 'tag3']
    tags3 = ['tag1']
    context = PlayContext()
    templar = Templar()

    # Taggable is an abstract class, so we need to test its concrete subclasses

# Generated at 2022-06-23 07:14:00.781919
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    t.tags.append('test_tag')
    assert t.tags == ['test_tag']

# Generated at 2022-06-23 07:14:06.748897
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    import ansible.errors
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    class TestTask(Task):
        def __init__(self, name, tags=None):
            self.name = name
            self.tags = tags

    class TestTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

        def evaluate_tags(self, only_tags, skip_tags, all_vars=None):
            return super(TestTaggable, self).evaluate_tags(only_tags, skip_tags, all_vars)



# Generated at 2022-06-23 07:14:14.268400
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create object
    test = Taggable()
    test.tags = ['tag1', 'tag2']

    # Test
    only_tags = ['tag2']
    results = [{'should_run': True, 'skip_tags': None}, {'should_run': False, 'skip_tags': ['tag1']}]
    for expected in results:
        skip_tags = expected['skip_tags']
        should_run = expected['should_run']
        assert test.evaluate_tags(only_tags, skip_tags) == should_run

# Generated at 2022-06-23 07:14:24.125709
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # Create playbook to test
    task1 = Task()
    task1.name = 'Task 1'
    task1.tags = ['tag1', 'tag2']
    task1.only_tags = ['tag2', 'tag3']
    task1.skip_tags = ['tag4']

    task2 = Task()
    task2.name = 'Task 2'
    task2.tags = ['tag5', 'tag6']
    task2.only_tags = ['tag6', 'tag7']
    task2.skip_tags = ['tag8']

    task3 = Task()
    task3.name = 'Task 3'

# Generated at 2022-06-23 07:14:34.456656
# Unit test for constructor of class Taggable
def test_Taggable():
    class myTaggable(Taggable):
        pass

    m = myTaggable()
    m._tags = [1, 2, 3]

    # testing list of integers
    assert m._tags == [1, 2, 3]

    # testing string of integers
    m = myTaggable()
    m._tags = "1,2,3"
    assert m._tags == [1, 2, 3]

    # testing string of strings
    m = myTaggable()
    m._tags = "one,two,three"
    assert m._tags == ['one', 'two', 'three']

    # testing list of strings
    m = myTaggable()
    m._tags = ["one", "two", "three"]
    assert m._tags == ['one', 'two', 'three']

    # testing list of lists

# Generated at 2022-06-23 07:14:39.738701
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    playbook = TaskInclude('my_include')
    playbook.tags = [u"debug","deploy"]
    tags = playbook.tags
    assert tags[0] == u"debug"


if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:14:43.247786
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = ['tag1', 'tag2']
    obj = Taggable(tags=tags)
    assert isinstance(obj, Taggable), "Test Taggable constructor"

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:14:54.990393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # only_tags=['tag1']
    # skip_tags=['tag2', 'tag3']
    assert t.evaluate_tags(['tag1'], ['tag2', 'tag3'], [])

    assert not t.evaluate_tags(['tag2'], ['tag2', 'tag3'], [])

    assert t.evaluate_tags(['tag1', 'tag2'], ['tag2', 'tag3'], [])

    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag2', 'tag3'], [])

    assert not t.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag2', 'tag3', 'tag4'], [])


# Generated at 2022-06-23 07:14:56.642643
# Unit test for constructor of class Taggable
def test_Taggable():
    obj = Taggable()
    assert obj.tags == []


# Generated at 2022-06-23 07:15:09.505836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    This test provides the functionality of the method evaluate_tags of the class Taggable.
    '''
    # TEST 1
    only_tags = []
    skip_tags = []
    all_vars = {}
    taggable = Taggable()
    taggable._tags = []
    eval_tags = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert eval_tags == True, "TEST 1 FAILURE!"
    # TEST 2
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    taggable._tags = ['tag1']
    eval_tags = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-23 07:15:16.797943
# Unit test for constructor of class Taggable
def test_Taggable():
    a = Taggable()
    assert a._tags == []
    a = Taggable(tags='tag1,tag2,tag3')
    assert a._tags == ['tag1', 'tag2', 'tag3']
    a = Taggable(tags=[['tag1','tag2'],['tag3']])
    assert a._tags == ['tag1', 'tag2', 'tag3']
    a = Taggable(tags='tag1,tag2 tag3')
    assert a._tags == ['tag1', 'tag2 tag3']

# Generated at 2022-06-23 07:15:18.360840
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags is not None

# Generated at 2022-06-23 07:15:25.590967
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._load_tags('foo', 'bar') == ['bar']
    assert taggable._load_tags('foo', ['bar']) == ['bar']
    assert taggable._load_tags('foo', ['bar', 'baz']) == ['bar', 'baz']

    if hasattr(taggable, '_load_tags'):
        delattr(taggable, '_load_tags')
    taggable._ds = {'tags': 'bar'}
    taggable._initialize_attributes()
    assert taggable.tags == ['bar']
    taggable._ds = {'tags': ['bar']}
    taggable._initialize_attributes()
    assert taggable.tags == ['bar']

# Generated at 2022-06-23 07:15:37.637091
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTask(object):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    # Test if tasks without any tags should run
    task = MockTask(tags=None)
    assert task.evaluate_tags(None, None, None) == True

    # Test if a task should run with only tag
    task1 = MockTask(tags=['test_tag1'])
    assert task1.evaluate_tags(['test_tag1'], None, None) == True

    # Test if a task should run with only tag and skip tag
    task2 = MockTask(tags=['test_tag2', 'test_tag3'])
    assert task2.evaluate_tags(['test_tag3'], ['test_tag2'], None) == True

    # Test if a task should run with

# Generated at 2022-06-23 07:15:38.505886
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:15:46.824036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    def test_tag(tag, tag_options, expected, only_tags=None, skip_tags=None):
        tags = [tag]
        t = Taggable()
        t._tags = tags
        only_tags = only_tags or []
        skip_tags = skip_tags or []
        assert t.evaluate_tags(only_tags, skip_tags, {}) == expected
