

# Generated at 2022-06-23 07:05:53.594282
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Load a playbook and check that the method evaluate_tags 
    of class Taggable works as expected.
    '''
    # Load a playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-23 07:05:57.022435
# Unit test for constructor of class Taggable
def test_Taggable():
    class FakeClass:
        def __init__(self, host=None, tags=None):
            self.host = host
            self.tags = Taggable()
            self.tags._tags = tags

    acl = FakeClass(tags=['always', 'test'])
    assert acl.tags == ['always', 'test']

# Generated at 2022-06-23 07:06:07.108589
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os

    # set up and load data structures
    current_dir = os.path.dirname(os.path.realpath(__file__))
    class FakePlaybook:
        def __init__(self):
            self.basedir = current_dir
    loader = DataLoader()
    vars_manager = VariableManager()
    fake_playbook = FakePlaybook()
    tags = ["tag1", "tag2"]
    task_name = "sample task name"

    # initialize task include
    task = TaskInclude(loader, play=fake_playbook)

    # Set tags for task include
    task.tags = tags

   

# Generated at 2022-06-23 07:06:17.538477
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyBlock(object):
        tags = ['test']

    class MyTask(Taggable):
        pass

    mb = MyBlock()
    mt = MyTask()

    mb.vars = dict()

    mt.tags = ['test']
    assert mt.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars=mb.vars)
    assert not mt.evaluate_tags(only_tags=[], skip_tags=['test'], all_vars=mb.vars)
    assert mt.tags == ['test']

    mt.tags = ['always']
    assert mt.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars=mb.vars)

# Generated at 2022-06-23 07:06:28.569060
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        pass

    t = MyTaggable()

    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={'inventory_hostname': "localhost"})

    t.tags = {'all'}

    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={'inventory_hostname': "localhost"})

    assert t.evaluate_tags(only_tags=['x'], skip_tags=[], all_vars={'inventory_hostname': "localhost"}) == False

    t.tags = {'x'}

    assert t.evaluate_tags(only_tags=['x'], skip_tags=[], all_vars={'inventory_hostname': "localhost"})

    assert t

# Generated at 2022-06-23 07:06:38.409365
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    item = MyTaggable()

    # basic: no vars to expand
    item.tags = ["tag1", "tag2"]
    only_tags = []
    skip_tags = []
    all_vars = {}
    result = item.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result == True)
    only_tags = ["tag1"]
    skip_tags = []
    all_vars = {}
    result = item.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result == True)
    only_tags = []
    skip_tags = ["tag1"]
    all_vars = {}

# Generated at 2022-06-23 07:06:41.892765
# Unit test for constructor of class Taggable
def test_Taggable():

    class Unk(Taggable):
        name = 'unknown'

    try:
        obj = Unk()
    except NameError:
        obj = None

    assert(obj is not None)

# Generated at 2022-06-23 07:06:43.390778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO: create unit tests for Taggable.evaluate_tags
    pass

# Generated at 2022-06-23 07:06:49.101175
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['aaa', 'bbb']
    only_tags = ['bbb']
    skip_tags = ['aaa']
    all_vars = dict()
    class obj:
        tags = tags
        def __init__(self):
            self._loader = None
    o = obj()
    o.evaluate_tags(only_tags, skip_tags, all_vars)
    assert o.tags == only_tags

# Generated at 2022-06-23 07:06:52.527412
# Unit test for constructor of class Taggable
def test_Taggable():
    dagger = Taggable('load_tags', ['tag1', 'tag2'])
    assert dagger.tags == ['tag1', 'tag2']

# Generated at 2022-06-23 07:07:01.547366
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    class MyTaggable(Taggable):
        def __init__(self, tags):
            super(MyTaggable, self).__init__()
            self._tags = tags

    class FakeLoader:
        pass

    fake_loader = FakeLoader()

    class FakeInventory:
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, host, new_vars=None):
            vars = dict()
            vars.update(self.vars)
            if new_vars:
                vars.update(new_vars)
            return vars

    i = Inventory(loader=fake_loader, variable_manager=VariableManager())
    i.get_host

# Generated at 2022-06-23 07:07:10.737748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import include_role
    from ansible.playbook.include import Include
    from ansible.playbook.include import IncludeRole

    test_classes = [Task, Play, Include, Handler, Block, IncludeRole]

    for test_class in test_classes:

        # Initialize one object of test_class
        test_object = test_class()

        # set required attributes
        test_object._attributes = {}
        test_object._loader = {}

        # Case 1
        test_object.tags = ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-23 07:07:12.396770
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    t._load_tags('_tags', '1,2,3')
    assert t._tags == ['1', '2', '3']


# Generated at 2022-06-23 07:07:16.990730
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    task = TaskInclude()
    print(task.get_name())

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:07:19.586648
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable=Taggable()
    taggable._tags=['Windows']
    taggable_tags=taggable.tags
    assert 'Windows' in taggable_tags

# Generated at 2022-06-23 07:07:23.284647
# Unit test for constructor of class Taggable
def test_Taggable():
    class SubTaggable(Taggable):
        pass
    sub_Taggable = SubTaggable()
    assert sub_Taggable._tags == []

# Generated at 2022-06-23 07:07:33.629069
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:07:47.264642
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert not Taggable().evaluate_tags(['tag1'], [], {})
    assert not Taggable().evaluate_tags(['tag1', 'tag2'], [], {})
    assert not Taggable().evaluate_tags(['tag1'], [], {'tag1':'tag2'})
    assert not Taggable().evaluate_tags(['tag1'], [], {'tag2':[]})
    assert not Taggable().evaluate_tags(['tag1'], [], {'tag2':None})
    assert not Taggable().evaluate_tags(['tag1'], [], {'tag2':'tag2'})
    assert not Taggable().evaluate_tags(['tag1'], [], {'tag2':99})

    obj = Taggable()
    obj.tags = ['tag1']

# Generated at 2022-06-23 07:07:53.145930
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

    data = [1, 2]
    attr = t._load_tags('tags', data)
    assert attr == data


# Generated at 2022-06-23 07:07:59.434425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()

    # check untagged items
    obj.tags = []
    should_run = obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert should_run == True

    should_run = obj.evaluate_tags(only_tags=[], skip_tags=['untagged'], all_vars={})
    assert should_run == False

    should_run = obj.evaluate_tags(only_tags=['untagged'], skip_tags=[], all_vars={})
    assert should_run == True

    should_run = obj.evaluate_tags(only_tags=['untagged'], skip_tags=['untagged'], all_vars={})
    assert should_run == False

    # check skipped items
    obj.tags = ['never']
    should

# Generated at 2022-06-23 07:08:00.656920
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()

# Generated at 2022-06-23 07:08:05.234667
# Unit test for constructor of class Taggable
def test_Taggable():
    class TestClass(Taggable):
        def __init__(self, tags):
            self._tags = tags

    assert TestClass([1, 2, 'foo'])._tags == [1, 2, 'foo']
    assert TestClass('1,2,foo')._tags == [1, 2, 'foo']


# Generated at 2022-06-23 07:08:15.919610
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableImpl(Taggable):
        def __init__(self, data):
            super(TaggableImpl, self).__init__()
            self.tags = data

    # Check default behaviour
    block = TaggableImpl([])
    assert block.evaluate_tags(None, None, None)

    # Check --tags=a
    block = TaggableImpl([b"a"])
    assert block.evaluate_tags([b"a"], None, None)

    # Check --tags=a,b --skip-tags=a,c
    block = TaggableImpl([b"a", b"b"])
    assert block.evaluate_tags([b"a", b"b"], [b"a", b"c"], None)

    # Check --tags=a --skip-tags=a
    block = Taggable

# Generated at 2022-06-23 07:08:26.176816
# Unit test for constructor of class Taggable
def test_Taggable():
    def _constructor(tags):
        class Fake_object:
            def __init__(self):
                self.tags = tags
        return Fake_object()
    # Check if tags list is set and converted to lower case
    obj1 = _constructor(tags=["Hello","world"])
    assert obj1._tags == ["hello","world"]
    # Check if tags string is converted to list
    obj2 = _constructor(tags="Hello,World")
    assert obj2._tags == ["hello","world"]
    # Check if tags string is set as list 
    obj3 = _constructor(tags="Hello")
    assert obj3._tags == ["hello"]
    # Check if tags string is converted to list
    obj4 = _constructor(tags="Hello, World")
    assert obj4._tags == ["hello", "world"]
   

# Generated at 2022-06-23 07:08:34.553462
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task
    t = Taggable()
    assert t._tags == [], 'Default _tags should be empty, but it wasnt'
    t._tags = 'a, b, c'
    assert t._tags == ['a', 'b', 'c'], '_tags should be set to list, but it wasnt.'
    t._tags = 'a, b, c'
    assert t._tags == ['a', 'b', 'c'], '_tags should be set to list, but it wasnt.'
    t = Task()
    assert t._tags == [], '_tags should be set to list, but it wasnt.'

# Generated at 2022-06-23 07:08:42.926213
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest

    class TestTaggable(Taggable):

        def __init__(self):
            self._data = {}

    class TestTaggableEvaluateTags(unittest.TestCase):

        class Capturing(list):

            def __enter__(self):
                self._stdout = sys.stdout
                sys.stdout = self._stringio = StringIO()
                return self

            def __exit__(self, *args):
                self.extend(self._stringio.getvalue().splitlines())
                sys.stdout = self._stdout

        def setUp(self):
            self.taggable = TestTaggable()
            self.all_vars = {'role_name': 'ceph-common'}


# Generated at 2022-06-23 07:08:47.521469
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    >>> a = Taggable()
    >>> a.tags = ['always']
    >>> print a.tags
    ['always']
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 07:09:00.014342
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    untagged = frozenset(['untagged'])

    # test with only_tags option
    # test with only_tags option with 'tagged'
    myTaggable = Taggable()
    myTaggable.tags = ['tagged']
    assert myTaggable.evaluate_tags(['tagged'], [], None) == True

    # test with only_tags option with 'all'
    myTaggable = Taggable()
    myTaggable.tags = ['tagged']
    assert myTaggable.evaluate_tags(['all'], [], None) == True

    # test with only_tags option with multiple tags
    myTaggable = Taggable()
    myTaggable.tags = ['tagged']

# Generated at 2022-06-23 07:09:07.577016
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test that if the task has no tags, and no only_tags/skip_tags are given, the task is executed
    class Task(Taggable):
        tags = []

    assert (Task().evaluate_tags(None, None, {}))

    # Test that if the task has tags, and only_tags are given, and 'tagged' is in only_tags, the task is executed
    class Task(Taggable):
        tags = ['test_tag']

    assert (Task().evaluate_tags(['tagged'], None, {}))

    # Test that if the task has no tags, and only_tags are given, and 'tagged' is in only_tags, the task is executed
    class Task(Taggable):
        tags = []

    assert (Task().evaluate_tags(['tagged'], None, {}))

    # Test that

# Generated at 2022-06-23 07:09:10.526056
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert isinstance(t, Taggable)
    t._tags.append('test')
    assert t.tags[0] == 'test'

# Generated at 2022-06-23 07:09:21.812148
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task

    task1 = Task()

    task1.tags = ['foo', 'bar']
    assert task1.evaluate_tags(['foo'], [], {}) is True

    task1.tags = ['foo', 'bar']
    assert task1.evaluate_tags(['foo', 'bar'], [], {}) is True

    task1.tags = ['foo', 'bar']
    assert task1.evaluate_tags(['foo', '!bar'], [], {}) is True

    task1.tags = ['foo', 'bar']
    assert task1.evaluate_tags(['!foo', 'bar'], [], {}) is True

    task1.tags = ['foo', 'bar']
    assert task1.evaluate_tags(['!foo', '!bar'], [], {}) is True

# Generated at 2022-06-23 07:09:28.462557
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Thing(Taggable):
        def __init__(self, name):
            self.name = name

    # Function to be tested
    def evaluate_tags(item, only_tags, skip_tags, all_vars):
        return item.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test setup

# Generated at 2022-06-23 07:09:32.548476
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t.tags == []
    assert 'untagged' in t.untagged

# Make sure the _load_tags method of class Taggable works properly

# Generated at 2022-06-23 07:09:42.587017
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.unicode import to_unicode
    # to_unicode is required for py3.x
    t = Task()
    t.tags = ['foo','bar','baz','never','always','tagged']
    pc = PlayContext()
    pc.only_tags = ['foo','bar','all','tagged','always']
    pc.skip_tags = ['always','never','baz']
    assert t.evaluate_tags(pc.only_tags, pc.skip_tags, {}) is True
    pc.only_tags = ['foo','bar','all','tagged','always']
   

# Generated at 2022-06-23 07:09:55.937145
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:10:05.667535
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggedItem(Taggable):
        def __init__(self, tags=None):
            self.tags = tags


# Generated at 2022-06-23 07:10:13.294723
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class myTaggable(Taggable):
        pass

    mT = myTaggable()
    assert mT.evaluate_tags(None, None, None) == True
    mT.tags = ['a']
    assert mT.evaluate_tags(None, None, None) == True
    assert mT.evaluate_tags(['a'], None, None) == True
    assert mT.evaluate_tags(['a', 'b'], None, None) == True
    assert mT.evaluate_tags(['a', 'c'], None, None) == True
    assert mT.evaluate_tags(['b'], None, None) == False
    assert mT.evaluate_tags(['d'], None, None) == False

# Generated at 2022-06-23 07:10:24.494545
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    class MyTaggable(Taggable, Base):
        pass

    mt = MyTaggable()
    mt2 = MyTaggable()

    assert set([]) == mt._tags
    assert set([]) == mt2._tags

    class MyTaggable2(Taggable, Base):
        _tags = [ "foo" ]

    mt3 = MyTaggable2()
    assert set( ["foo"] ) == mt3._tags
    assert set( ["foo"] ) == mt3._tags

    class MyTaggable3(Taggable, Base):
        _tags = [ "foo", "bar" ]

    mt4 = MyTaggable3()
    assert set( ["foo", "bar"] ) == mt4._tags

# Generated at 2022-06-23 07:10:34.249174
# Unit test for constructor of class Taggable
def test_Taggable():
    def my_loader(path):
        return '''
---
- hosts: localhost
  tasks:
  - command: echo {{ foo }}
    tags: [one, two, three]

  - command: echo hi
    tags: [four, five]
  '''

    tags = Taggable._load_tags("tags", "one, two, three")
    assert tags == ['one', 'two', 'three']

    x = Taggable()
    x._loader = my_loader
    assert x._loader("x")

# The test for evaluate_tags also tests for _load_tags.

# Generated at 2022-06-23 07:10:46.089626
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.vars import combine_vars
    for obj in [dict(tags=['a', 'b']), dict(tags=['c', 'd'])]:
        t = Taggable()
        t.vars = dict( a=1, b=2, c=3, d=4 )
        t.tags = obj['tags']
        # No only_tags and skip_tags
        assert t.evaluate_tags(
            only_tags=None,
            skip_tags=None,
            all_vars=t.vars.copy()
        )
        # only_tags and skip_tags, with no match

# Generated at 2022-06-23 07:10:48.815242
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []


# Generated at 2022-06-23 07:10:59.440459
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.variables import VariableManager
    from ansible.inventory.manager import InventoryManager

    pl = Playbook()
    ti = TaskInclude()
    ti2 = TaskInclude()
    blk = Block()
    pl.tasks = [ti, ti2, blk]
    host_list = InventoryManager(loader=None, sources=['localhost'])
    variable_manager = VariableManager(loader=None, inventory=host_list)

# Generated at 2022-06-23 07:11:06.569942
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import collections
    class MockLoader:
        __init__ = lambda x: None
    t = Taggable()
    t._loader = MockLoader()
    t.tags = list()
    t.tags = None
    t.tags = collections.deque([])
    t.tags = collections.deque([1])
    t.tags = set()
    t.tags = set([])
    t.tags = set([1])
    t.tags = frozenset()
    t.tags = frozenset(['untagged'])
    all_vars = dict()
    assert(t.evaluate_tags(only_tags=None,skip_tags=None,all_vars=all_vars))

# Generated at 2022-06-23 07:11:18.518805
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Taggable(Taggable):
        def __init__(self):
            self.tags = None
        #def evaluate_tags(self, only_tags, skip_tags, all_vars):
        #    return super(Taggable,self).evaluate_tags(only_tags, skip_tags, all_vars)

    task = Taggable()
    print("task.tags:", task.tags)
    assert task.evaluate_tags(['a', 'b', 'c'], None, None) == True
    print("task.tags:", task.tags)
    assert task.evaluate_tags(['a', 'b', 'c'], [], None) == True
    print("task.tags:", task.tags)
    assert task.evaluate_tags(['a'], None, None) == False

# Generated at 2022-06-23 07:11:20.480190
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    task = Task()

    task._load_tags('tags', 'a,b')


# Generated at 2022-06-23 07:11:32.308834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os

    # prepare the basic requisites
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources='localhost, ')
    variable_manager.set_inventory(inventory)

    # load the playbook file
    playbook_path = os.path.join(os.path.dirname(__file__), 'playbook_tests/tagged_playbook.yml')

# Generated at 2022-06-23 07:11:40.822517
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.plugins import action_loader

    # Minimal test class
    class ClassForTest(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
        def __repr__(self):
            return(type(self).__name__ + ": " + repr(self.tags))

    # Minimal test function
    def test_func(self):
        pass

    # Find the test function inside loader
    loader = action_loader.ActionModuleLoader(None)
    for action in loader.all():
        if "test_func" in dir(action):
            test_func = action.test_func

    # Create a minimal test instance
    class_instance = ClassForTest()
    class_instance.tags = ["first_tag"]

    # Default should run
    ShouldRun = class_

# Generated at 2022-06-23 07:11:47.084556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        tags = ['tag1', 'tag2']
    myTaggable = MyTaggable()
    assert myTaggable.evaluate_tags(['tag1'], [], dict())
    assert not myTaggable.evaluate_tags(['tag3'], [], dict())
    assert myTaggable.evaluate_tags([], [], dict())
    assert not myTaggable.evaluate_tags(['tag3'], [], dict())
    assert myTaggable.evaluate_tags(['tag1', 'tag2', 'tag3'], [], dict())
    assert myTaggable.evaluate_tags([], ['tag1'], dict())
    assert not myTaggable.evaluate_tags([], ['tag3', 'tag4'], dict())

# Generated at 2022-06-23 07:11:56.000758
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass

    # Construct a MyTaggable object
    myobj = MyTaggable()
    assert hasattr(myobj, 'tags')
    assert hasattr(MyTaggable, 'tags')
    assert not hasattr(myobj, 'not_my_attr')

    # Since myobj.tags is an @property, it executes the _load_tags method
    # So _load_tags returns empty list if _tags is empty
    # But _tags is initialized to None as a result of FieldAttribute(default=list)
    # So myobj._tags MUST NOT be None
    assert myobj._tags is not None
    assert myobj.tags == []

# Generated at 2022-06-23 07:12:02.959107
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, i_tags):
            self.tags = i_tags


# Generated at 2022-06-23 07:12:12.877854
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    class MyClass(Base, Taggable):
        pass

    me = MyClass()
    assert me._tags == list()
    assert me.tags == list()
    assert me.evaluate_tags(['a', 'b', 'c'], ['d'], {}) is True
    assert me.evaluate_tags(['always'], ['d'], {}) is True
    assert me._load_tags('tags', ['a', 'b', 'c']) == ['a', 'b', 'c']
    assert me._load_tags('tags', 'a,b,c') == ['a', 'b', 'c']
    assert me._load_tags('tags', 'a') == ['a']

# Generated at 2022-06-23 07:12:13.985560
# Unit test for constructor of class Taggable
def test_Taggable():
    global taggable
    taggable = Taggable()
    assert taggable

# Generated at 2022-06-23 07:12:24.409135
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    class DummyModule(object):
        def __init__(self):
            self.DS = ''

    class DummyClass(Taggable):
        def __init__(self):
            self._ds = {}
            self._ds['tags'] = list(self._tags)
            self._ds['tags'].append('always')
            self._ds['tags'].append('never')

    # Test Play
    dummy_task = Task()
    dummy_task.DS = DummyModule()
    dummy_task._ds = {'tags': ['all']}

# Generated at 2022-06-23 07:12:37.348268
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # We create a class derived from Taggable class and we add
    # a dummy should_run method whose return value is always
    # based on evaluation of evaluate_tags method.
    class Dummy(Taggable):
        tags = []
        def should_run(self, only_tags, skip_tags, all_vars=dict()):
            return self.evaluate_tags(only_tags, skip_tags, all_vars)

    # We create an instance of the dummy class and set its
    # tags attribute to a list of tags
    dummy = Dummy()
    dummy.tags = ['A', 'B']

    # We test that the method should_run returns True if
    # only_tags is empty and skip_tags is empty
    result = dummy.should_run(only_tags=[], skip_tags=[])
    assert result



# Generated at 2022-06-23 07:12:46.858538
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # For debugging:
    # def my_represent_scalar(self, tag, value, style=None):
    #     return self.represent_scalar(u'tag:yaml.org,2002:str', u'foo')

    # AnsibleDumper.add_representer(type(u''), my_represent_scalar)

    # test string input
    ###################
    # test_taggable = Taggable()
    # test_taggable._load_tags("foo,bar,baz")
    # print("tags={}".format(test_taggable.tags))
    #

# Generated at 2022-06-23 07:12:55.329747
# Unit test for constructor of class Taggable
def test_Taggable():
    # We do not want the constructor to fail when
    # called without any arguments, this is the
    # reason why we call it with some dummy arguments.
    t = Taggable(name=None, loader=None, variable_manager=None)
    assert t.tags == [], t.tags
    assert isinstance(t._tags, list)
    assert t._tags == [], t._tags
    assert t.untagged == frozenset(['untagged'])

# Test for the method _load_tags of class Taggable

# Generated at 2022-06-23 07:13:07.310237
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    class Taggable_evaluate_tags:
        def __init__(self):
            self._tags = []
            self.tags = ''

    taggable = Taggable_evaluate_tags()

    taggable.tags = ['tag1', 'tag2']
    assert True == taggable.evaluate_tags(['tag1'], [], {})
    assert True == taggable.evaluate_tags(['tag2'], [], {})
    assert False == taggable.evaluate_tags(['tag3'], [], {})

    taggable.tags = ['tag1', 'tag2']
    assert True == taggable.evaluate_tags([], ['tag1'], {})
    assert True == taggable.evaluate_tags([], ['tag2'], {})
    assert False == tagg

# Generated at 2022-06-23 07:13:13.740747
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        __metaclass__ = type

        def __init__(self):
            self._tags = []

    test_obj = TestTaggable()

    class _VarsModule:
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, play=None, host=None, task=None):
            return self.vars

    test_only_tags = []
    test_skip_tags = []

    # Test that the task with tags marked as 'always' is always run
    test_obj._tags = ['always']
    assert test_obj.evaluate_tags(test_only_tags, test_skip_tags, _VarsModule(dict()))

    # Test that the task with tags marked as 'never' is never run

# Generated at 2022-06-23 07:13:18.262656
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_object = Taggable()
    test_object.tags = ['test1']
    # test all cases for one tag and a given list of only_tags
    assert(test_object.evaluate_tags(['test1'], [], {}) == True)
    assert(test_object.evaluate_tags(['test2'], [], {}) == False)

    # should be executed, if tagged
    assert(test_object.evaluate_tags(['tagged'], [], {}) == True)

    # should be executed, if all
    assert(test_object.evaluate_tags(['all'], [], {}) == True)

    # should be executed, if only_tags empty
    assert(test_object.evaluate_tags([], [], {}) == True)

    # should be skipped, if skipped

# Generated at 2022-06-23 07:13:29.476733
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        def __init__(self, tags=None, only_tags=None, skip_tags=None, all_vars=None):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.all_vars = all_vars
            self._loader = None

    # test with only_tags
    dummy_taggable = DummyTaggable(tags=['a', 'always'], only_tags=['all'], skip_tags=None, all_vars=None)

# Generated at 2022-06-23 07:13:41.387810
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import Include

    raw_data = b'''
    - hosts:
        - '*'
      tasks:
        - tags:
            - "tag1"
          debug:
            msg: "hello world"
        - tags:
              - "tag2"
            - "tag3"
          debug:
            msg: "hello world"
    '''
    data = AnsibleLoader(raw_data, 'test').get_single_data()
    assert data is not None

# Generated at 2022-06-23 07:13:42.645784
# Unit test for constructor of class Taggable
def test_Taggable():
    test = Taggable()
    assert test._tags == []
    assert test.tags is test._tags
    assert test.tags == []

# Generated at 2022-06-23 07:13:49.636111
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    --- tests for evaluate_tags method of class Taggable
    '''
    t = Taggable()
    t._loader = None
    only_tags = None
    skip_tags = None
    all_vars = None
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)==True
    return
test_Taggable_evaluate_tags()


# Generated at 2022-06-23 07:13:58.973278
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Tests if the method evaluate_tags of class Taggable is working as expected
    by testing all possible scenarios.
    '''
    from ansible.playbook.task_include import TaskInclude
    t = TaskInclude()
    t._variable_manager = None
    t._loader = None
    t._block = None
    errors = 0

    # Test 1
    # Expectation: Task will be executed
    # Input: Tagged task, Only_tags = "Test_Tag"
    t.tags = ["Test_Tag"]
    if not t.evaluate_tags(["Test_Tag"],[],{}):
        print(
            "Test 1 Failed: Tagged Task should be executed with Only_Tags = Test_Tag, " \
            "but evaluate_tags method returned False")
        errors = errors + 1

    # Test

# Generated at 2022-06-23 07:14:07.047625
# Unit test for constructor of class Taggable
def test_Taggable():
    import copy
    t = Taggable()
    t._tags = ['tag1', 'tag2']
    assert t._tags == [ 'tag1', 'tag2' ]

    t2 = Taggable()
    t2._tags = t._tags
    assert t2._tags == [ 'tag1', 'tag2' ]

    # make sure deepcopy can be done
    t2._tags = copy.deepcopy(t._tags)
    assert t2._tags == [ 'tag1', 'tag2' ]

# Generated at 2022-06-23 07:14:13.509359
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

    # Create play and check that evaluate_tags returns true
    play = Play()
    assert play.evaluate_tags(['always'], [], {})

    # Create task, play and check that evaluate_tags returns true
    task = Task()
    play = Play()
    play.tasks = [task]
    assert play.evaluate_tags(['always'], [], {})

    # Add try/except to avoid "skip test" issues

# Generated at 2022-06-23 07:14:16.760166
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggable(Taggable):
        pass
    mt = MyTaggable()
    assert mt.tags == []
    assert mt.untagged == frozenset(['untagged'])

# Generated at 2022-06-23 07:14:18.220858
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable._tags == []

# Generated at 2022-06-23 07:14:26.422259
# Unit test for constructor of class Taggable
def test_Taggable():

    test_taggable_1 = Taggable()

    if test_taggable_1.tags != [] or test_taggable_1.untagged != frozenset(['untagged']) or not isinstance(test_taggable_1, Taggable):
        raise Exception('test_taggable_1 failed')

    test_taggable_2 = Taggable(tags=['tag1','tag2','tag3'], untagged=frozenset(['untagged']))

    if test_taggable_2.tags != ['tag1','tag2','tag3'] or test_taggable_2.untagged != frozenset(['untagged']) or not isinstance(test_taggable_2, Taggable):
        raise Exception('test_taggable_2 failed')

# Unit test

# Generated at 2022-06-23 07:14:37.198878
# Unit test for constructor of class Taggable
def test_Taggable():
    """
    Unit test for constructor of class Taggable
    """
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    import os

    # Check if tags is a dict and return an error
    tags = dict()
    try:
        taggable = Taggable(tags=tags)
    except ValueError as e:
        assert str(e) == "tags should be list, got dict"

    # Check if tags is a list and None element is present in it and return an error
    tags = [None]
    try:
        taggable = Taggable(tags=tags)
    except ValueError as e:
        assert str(e) == "tags has a None value in the list"


    # Check if tags is a list

# Generated at 2022-06-23 07:14:43.661902
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude
    ti = TaskInclude()
    ti._load_tags('tags', 'tag1,tag2')
    ti._tags = ['tag1', 1, 'tag2', 2]
    assert len(ti._tags) == 4
    assert ti._tags[0] == 'tag1'
    assert ti._tags[1] == 1
    assert ti._tags[2] == 'tag2'
    assert ti._tags[3] == 2

# Generated at 2022-06-23 07:14:50.345279
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task import Task

    t = Task()
    assert hasattr(t, 'tags')
    assert isinstance(t.tags, list)
    assert not t.tags

    t = Task(tags=['a', 'b'])
    assert hasattr(t, 'tags')
    assert isinstance(t.tags, list)
    assert sorted(t.tags) == sorted(['a', 'b'])


# Generated at 2022-06-23 07:14:54.530123
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base

    # assert class constructor works as expected
    taggable = Taggable()
    assert type(taggable) == Taggable
    assert isinstance(taggable, Base)

# Generated at 2022-06-23 07:14:56.255067
# Unit test for constructor of class Taggable
def test_Taggable():
    x = Taggable()
    assert x.tags == [], x.tags

# Generated at 2022-06-23 07:15:09.041128
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    obj._tags = []

    # Test for empty skip_tags, also when no tag is defined for task under test
    only_tags = []
    skip_tags = []
    all_vars = dict()
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = []
    skip_tags = []
    all_vars = dict()
    obj._tags = ["foo"]
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test for empty only_tags, also when no tag is defined for task under test
    only_tags = []
    skip_tags = ["bar"]
    all_vars = dict()

# Generated at 2022-06-23 07:15:10.592614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True == Taggable.evaluate_tags(Taggable(), None, None, None)

# Generated at 2022-06-23 07:15:20.085644
# Unit test for constructor of class Taggable
def test_Taggable():
    class Foo(Taggable):
        pass
    foo = Foo()
    foo.tags = ['a', 'b']
    assert foo.evaluate_tags(only_tags=['a']) == True
    assert foo.evaluate_tags(only_tags=['b']) == True
    assert foo.evaluate_tags(only_tags=['a', 'b']) == True
    assert foo.evaluate_tags(only_tags=['a'], skip_tags=['a']) == False
    assert foo.evaluate_tags(only_tags=['b'], skip_tags=['b']) == False
    assert foo.evaluate_tags(only_tags=['a', 'b'], skip_tags=['a', 'b']) == False
    assert foo.evaluate_tags(only_tags=['c']) == False
    assert foo

# Generated at 2022-06-23 07:15:33.326986
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    
    from ansible.inventory.host import Host

    # Test 1: Assert True when not specifying 'only_tags' and 'skip_tags'
    #         and when 'tags' attribute of the task has a value
    host = Host()
    host.vars = {'ansible_ssh_host': '192.168.1.1'}
    host.name = 'server1'
    host.port = 22
    host._variable_manager = 'None'

    task1 = Taggable()
    task1._loader = None
    task1.set_loader(None)
    task1.tags = ['debian']
    
    assert task1.evaluate_tags(None, None, host.vars) == True

    # Test 2: Assert False when not specifying 'only_tags' and 'skip_tags'
    #        

# Generated at 2022-06-23 07:15:42.258972
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:15:42.763817
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:15:50.496079
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableObject(Taggable):
        def __init__(self,tags):
            self.tags = tags
        def _get_dep_attrs(self, play):
            deps = Taggable._get_dep_attrs(self, play)
            deps.add('tags')
            return deps

    play = dict()
    play['tags'] = set()
    play['skip_tags'] = set()

    to = TaggableObject([])
    assert to.evaluate_tags(set(),set(),dict())
    to = TaggableObject(['tag_1'])
    assert not to.evaluate_tags(set(),['tag_1'],dict())
    assert not to.evaluate_tags(['tag_2'],['tag_1'],dict())