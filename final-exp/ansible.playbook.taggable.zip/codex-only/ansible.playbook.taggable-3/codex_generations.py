

# Generated at 2022-06-23 07:05:48.482837
# Unit test for constructor of class Taggable
def test_Taggable():
    #Taggable.__init__(Taggable)
    #test = Taggable()
    Taggable()

# Generated at 2022-06-23 07:05:59.405620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ('tag1', 'tag2')
    skip_tags = ('tag3', 'tag4')
    all_vars = {}

    # Test case 1
    tags = ['tag1', 'tag3']
    result = True
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags, all_vars) == result

    # Test case 2
    tags = ['tag5', 'tag6']
    result = False
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags, all_vars) == result

    # Test case 3
    tags = ['tag1', 'tag4']
    result = True
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags, all_vars) == result

    # Test case 4

# Generated at 2022-06-23 07:06:08.994597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = [ 'foo', 'bar' ]
    print(t.evaluate_tags(set(['foo']), set([]), {}))
    print(t.evaluate_tags(set(['baz']), set([]), {}))
    print(t.evaluate_tags(set([]), set(['foo']), {}))
    print(t.evaluate_tags(set([]), set(['baz']), {}))
    print(t.evaluate_tags(set(['foo']), set(['foo']), {}))
    print(t.evaluate_tags(set(['foo']), set(['bar']), {}))
    print(t.evaluate_tags(set(['foo']), set(['foo', 'bar']), {}))


# Generated at 2022-06-23 07:06:16.399849
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    class MyTaggable(Base, Taggable):
        def __init__(self):
            Base.__init__(self)
            Taggable.__init__(self)
            self._load_name = 'Taggable'

        def vars_from_file(self, filename):
            pass  # pragma: no cover

    t = MyTaggable()
    assert t.tags == []

    # Override the 'tags' attribute
    t = MyTaggable()
    tags_attr = ['foo', 'bar']
    t.tags = tags_attr
    assert t.tags == tags_attr


# Generated at 2022-06-23 07:06:27.933170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case: Evaluate a task that does not have any tags
    #  only_tags: untagged,skip_tags: never, expected: True
    a = Taggable()
    a.tags = ''
    a_result = a.evaluate_tags(['untagged'], ['never'], {})
    assert(a_result == True)

    # Test case: Evaluate a task that does not have any tags
    #  only_tags: untagged,skip_tags: always, expected: False
    b = Taggable()
    b.tags = ''
    b_result = b.evaluate_tags(['untagged'], ['always'], {})
    assert(b_result == False)

    # Test case: Evaluate a task that has a tag that matches the only_tag value
    #  only_tags: tag_a

# Generated at 2022-06-23 07:06:30.425448
# Unit test for constructor of class Taggable
def test_Taggable():
    print(Taggable._load_tags(1, 2))

# Generated at 2022-06-23 07:06:38.202949
# Unit test for constructor of class Taggable
def test_Taggable():
    class MyTaggedClass(Taggable):
        pass

    assert MyTaggedClass()._load_tags('_tags', ['a', 'b', 'c']) == ['a', 'b', 'c']  # pylint: disable=protected-access
    assert MyTaggedClass()._load_tags('_tags', 'a,b,c') == ['a', 'b', 'c']  # pylint: disable=protected-access

# Generated at 2022-06-23 07:06:43.542686
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:06:49.194652
# Unit test for constructor of class Taggable
def test_Taggable():
    import pprint
    taggable = Taggable()
    print(taggable)
    print(taggable._load_tags(None, " I am a tag "))
    print(taggable._load_tags(None, [" I am a tag "]))
    print(taggable._load_tags(None, ['xyz', 'abc', '  lvh']))
        
test_Taggable()

# Generated at 2022-06-23 07:07:00.184614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """Return True if the method evaluate_tags() of class Taggable 
    calculates the correct value for should_run for a given set of tags 
    and only_tags(list of str)."""

# Generated at 2022-06-23 07:07:06.093171
# Unit test for constructor of class Taggable
def test_Taggable():
    t=Taggable()
    assert t._load_tags(None, ['a','b']) == ['a','b']
    assert t._load_tags(None, None) == []
    assert t._load_tags(None, 'a') == ['a']
    assert t._load_tags(None, ' a, b ') == ['a','b']

# Generated at 2022-06-23 07:07:07.765777
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook.task import Task

    t1 = Task()
    t2 = Taggable()

# Generated at 2022-06-23 07:07:19.214303
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Unit test for method evaluate_tags of class Taggable'''
    class TestTaggable(Taggable):
        _name = 'testtaggable'

    from ansible.playbook.play import Play

    # Test case with only_tags
    testtaggable = TestTaggable()
    testtaggable.tags = ['always']
    assert testtaggable.evaluate_tags(['always'], [], {})
    assert testtaggable.evaluate_tags(['all'], [], {})
    assert testtaggable.evaluate_tags(['tagged'], [], {})

    testtaggable.tags = ['all']
    assert testtaggable.evaluate_tags(['all'], [], {})
    assert testtaggable.evaluate_tags(['tagged'], [], {})

# Generated at 2022-06-23 07:07:31.617072
# Unit test for constructor of class Taggable
def test_Taggable():

    # Test initial tag list
    t = Taggable()
    assert t._tags == []

    # Test load of single tag string
    t = Taggable()
    assert t._load_tags(None, 'a') == ['a']

    # Test load of tag list
    t = Taggable()
    assert t._load_tags(None, ['a', 'b']) == ['a', 'b']

    # Test load of tag string with fewer than 2 items
    t = Taggable()
    try:
        t._load_tags(None, 'a,b,c')
    except AnsibleError as e:
        pass
    else:
        assert False #should have raised an exception


# Generated at 2022-06-23 07:07:39.934559
# Unit test for constructor of class Taggable
def test_Taggable():

    tags = Taggable()
    tags._tags = ['1','2','3']
    assert tags._load_tags(attr='_tags', ds=['1','2','3']) == ['1','2','3']
    assert tags._load_tags(attr='_tags', ds='1,2,3') == ['1','2','3']
    assert tags._load_tags(attr='_tags', ds=['1,2,3']) == ['1,2,3']

# Generated at 2022-06-23 07:07:40.866183
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:07:54.598236
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    taggable.tags = [1, 2, 3, 4]
    assert taggable.tags == [1, 2, 3, 4]
    assert taggable._load_tags('tags', [1, 2, 3, 4]) == [1, 2, 3, 4]
    assert taggable._load_tags('tags', '1, 2, 3, 4') == ['1', '2', '3', '4']

    try:
        taggable._load_tags('tags', 1)
    except AnsibleError as e:
        if 'tags must be specified as a list' in str(e):
            assert 1
        else:
            assert 0

    assert taggable.evaluate_tags(['all'], [], [])

# Generated at 2022-06-23 07:08:00.252904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unicode import to_bytes
    import unittest

    class TestTaggable(Taggable, Task):
        pass

    t = TestTaggable()

    t.tags = ['all']
    if not t.evaluate_tags(['all'], None, dict()):
        raise unittest.TestCase.failureException('Unexpected result.')
    if not t.evaluate_tags(['all'], ['all'], dict()):
        raise unittest.TestCase.failureException('Unexpected result.')
    if not t.evaluate_tags(['all'], ['all', 'web'], dict()):
        raise unittest.TestCase.failure

# Generated at 2022-06-23 07:08:12.623034
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.playbook.role.task_include import TaskInclude

    test_Taggable = Taggable()

    # test that the class constructor sets _tags to an empty list
    assert test_Taggable._tags == []
    assert test_Taggable.tags == []

    # test that the class constructor sets untagged to a frozen set of 'untagged'
    assert test_Taggable.untagged == frozenset(['untagged'])

    # test that setting the tags attribute to a string sets the value in _tags
    test_Taggable.tags = "this, is, a, test"
    assert test_Taggable._tags == ['this', 'is', 'a', 'test']

# Generated at 2022-06-23 07:08:24.307377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Case 1: no tags, no skip tags
    t = Taggable()
    t.tags = []
    only_tags = None
    skip_tags = None
    all_vars = dict()

    assert(t.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    # Case 2a: no tags, 1 skip tag
    t.tags = []
    only_tags = None
    skip_tags = ['always']
    all_vars = dict()

    assert(t.evaluate_tags(only_tags, skip_tags, all_vars) == False)

    # Case 2b: no tags, 1 skip tag
    t.tags = []
    only_tags = None
    skip_tags = ['never']
    all_vars = dict()


# Generated at 2022-06-23 07:08:26.358915
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #TODO: write a test unit for class Taggable
    assert False, "test unit for Taggable not implemented"

# Generated at 2022-06-23 07:08:36.659287
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.playbook import Play
    from ansible.playbook.base import Base

    t = Taggable()
    if t.tags != t._tags:
        raise AssertionError("Taggable._tags != Taggable.tags")
    if not isinstance(t._tags, FieldAttribute):
        raise AssertionError("Taggable._tags is not an instance of FieldAttribute")
    if not isinstance(t._tags._attribute, FieldAttribute):
        raise AssertionError("Taggable._tags._attribute is not an instance of FieldAttribute")
    if t._tags.isa != 'list':
        raise Assert

# Generated at 2022-06-23 07:08:38.177068
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t != None

# Generated at 2022-06-23 07:08:44.361627
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTaggable(Taggable):

        def __init__(self):
            self._loader = None
            self.tags = None

        def get_name(self):
            return self._name

    fake_taggable = FakeTaggable()
    fake_taggable.get_name = lambda: "fake_taggable"

    # Test the default behavior, no tags.
    # No tags set in only_tags and skip_tags, should run.
    should_run = fake_taggable.evaluate_tags(set(), set(), {})
    if not should_run:
        raise AssertionError("Unit test failed: default behavior, no tags. Should run.")

    # Test null tags.
    # No tags set in only_tags and skip_tags, should run.
    fake_taggable.tags = None

# Generated at 2022-06-23 07:08:55.794443
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar

    class MyTask(Taggable, Task):
        def __init__(self, my_tags=[]):
            super(MyTask, self).__init__(None, None, None, None)
            self._tags = my_tags
            self._role_name = None
            self._task_name = None
            self._handler_name = None

    play_context = PlayContext()

    my_task1 = MyTask(my_tags=['tag_a', 'tag_b'])
    assert my_task1.evaluate_tags(['tag_a'], None, dict(play_context=play_context)) == True

# Generated at 2022-06-23 07:09:04.653486
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.task import Task
    import yaml
    p = Play.load(dict(name="some play", hosts=['localhost'],
           tasks=[dict(action=dict(module='shell', args='/usr/bin/uptime'), tags=['one'])]))
    p._load_included_file = False
    p = PlayObj.load(p.get_data())
    t = Task.load(dict(action=dict(module='shell', args='/usr/bin/uptime'), tags=['one', 'two'], when='1==1'))
    assert t.tags == ['one', 'two']
    assert t._load_tags(None, None) == []
    assert t._load

# Generated at 2022-06-23 07:09:16.033947
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    block = Block()

    # set tags for tasks
    task_no_tag = Task()
    task_no_tag.name = 'Test task 1'
    task_always = Task()
    task_always.name = 'Test task 2'
    task_always.tags.append('always')
    task_never1 = Task()
    task_never1.name = 'Test task 3'
    task_never1.tags.append('never')
    task_never2 = Task()
    task_never2.name = 'Test task 4'
    task_never2.tags.append('never')
    task_tag_example = Task()
    task_tag_example.name = 'Test task 5'

# Generated at 2022-06-23 07:09:26.289782
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    o = Taggable()
    o._tags = ['tag1', 'tag2', 'tag3']
    assert o.evaluate_tags([], ['skip_tag1', 'skip_tag2'], {}) == True
    assert o.evaluate_tags(['only_tag1', 'only_tag2'], ['skip_tag1', 'skip_tag2'], {}) == False
    assert o.evaluate_tags(['only_tag1', 'only_tag2'], [], {}) == False
    assert o.evaluate_tags(['tag1', 'tag2'], ['tag3'], {}) == True
    assert o.evaluate_tags([], ['tag3'], {}) == True
    assert o.evaluate_tags(['tag1'], ['tag2', 'tag3'], {}) == True
    assert o.evaluate_

# Generated at 2022-06-23 07:09:38.167814
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test parameters
    test_tags = ['test1', 'test2', 'test3']
    only_tags = ['test1', 'test2', 'test4']
    skip_tags = ['test4', 'test5']
    all_vars = {'var1': 'hello', 'var2': 'world'}
    expected_should_run = True

    # Object mock up
    class TaggableMock(Taggable):
        def __init__(self):
            self._tags = [test_tags]
            self.tags = []
            self._loader = None
        def __repr__(self):
            return "Mock Taggable object"

    # Test
    taggable_mock = TaggableMock()

# Generated at 2022-06-23 07:09:41.155113
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    result = Taggable().evaluate_tags("only_tags", "skip_tags", "all_vars")
    assert result == True

# Generated at 2022-06-23 07:09:43.823139
# Unit test for constructor of class Taggable
def test_Taggable():
    tags = ['a','b','c']
    t = Taggable(tags=tags)
    assert tags != t.tags

# Generated at 2022-06-23 07:09:46.107548
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert(True == Taggable().evaluate_tags(None, None, None))

# Generated at 2022-06-23 07:09:57.865920
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:09:59.699973
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert t._tags == list()

# Generated at 2022-06-23 07:10:10.816650
# Unit test for constructor of class Taggable
def test_Taggable():
    assert 'untagged' in Taggable.untagged
    assert Taggable.untagged == frozenset(['untagged'])
    assert 'untagged' in Taggable.untagged
    assert Taggable.untagged == frozenset(['untagged'])

    # class attr extend
    obj = Taggable()
    assert '_tags' in obj._attributes
    assert obj._attributes['_tags'] == {'extend': True}

    # Check for error when unexpected type for _tags
    try:
        obj._load_tags(None, None)
        assert True
    except AnsibleError:
        assert False
    except:
        assert False

    # isa
    try:
        obj._load_tags(None, 1)
        assert True
    except:
        assert False

    # List

# Generated at 2022-06-23 07:10:19.008919
# Unit test for constructor of class Taggable
def test_Taggable():
    task = Taggable()
    assert task._load_tags(None, []) == []
    assert task._load_tags(None, 'tag1') == ['tag1']
    assert task._load_tags(None, 'tag1,tag2') == ['tag1', 'tag2']
    assert task._load_tags(None, 'tag1, tag2, tag3') == ['tag1', 'tag2', 'tag3']
    assert task._load_tags(None, [1,2,3]) == [1,2,3]
    assert task._load_tags(None, [1,2,'tag1,tag2']) == [1,2,'tag1,tag2']

# Generated at 2022-06-23 07:10:22.519272
# Unit test for constructor of class Taggable
def test_Taggable():
    print("testing Taggable")
    #test _load_tags
    
    class Test(Taggable):
        def __init__(self):
            self._tags = list()
            self._loader = None
    
    t = Test()
    tag = t._load_tags("1,2,3,4", None)
    assert tag == ['1', '2', '3', '4'], tag

test_Taggable()

# Generated at 2022-06-23 07:10:31.986294
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role import Role
    loader = 'test/loader'
    variable_manager = 'test/variable_manager'
    all_vars = {'test':'success', 'ansible_play_hosts':['host0', 'host1']}
    role = Role(loader=loader, variable_manager=variable_manager)
    role.tags = ['test', 'ok', 'always', 'tagged']
    role.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars=all_vars)

# Generated at 2022-06-23 07:10:39.769591
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        _valid_tags = ['always', 'never']

    test_class = TestClass()

    try:
        test_class.evaluate_tags([], ['always'], {})
        assert False, 'should fail because tag "always" is not allowed'
    except AssertionError as e:
        raise e
    except:
        pass

    test_class._valid_tags = ['always']
    assert test_class.evaluate_tags([], ['always'], {}) is False
    assert test_class.evaluate_tags(['always'], [], {}) is True
    assert test_class.evaluate_tags([], [], {}) is True
    assert test_class.evaluate_tags(['always', 'never'], ['always'], {}) is True

# Generated at 2022-06-23 07:10:49.003259
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Unit test for method Taggable.evaluate_tags '''
    import unittest

    class MockTaggable(Taggable):
        pass

    class TestTaggable(unittest.TestCase):

        def test_Taggable_evaluate_tags_basic(self):
            mt = MockTaggable()

            setattr(mt, '_tags', [ 't1' ])
            self.assertTrue(mt.evaluate_tags([ 't1' ], [], {}))
            self.assertTrue(mt.evaluate_tags([], [ 't1' ], {}))

        def test_Taggable_evaluate_tags_always(self):
            mt = MockTaggable()

            setattr(mt, '_tags', [ 'always' ])
            self.assertTrue(mt.evaluate_tags([], [], {}))

# Generated at 2022-06-23 07:10:54.419755
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    class FakeTask(Taggable):
        def __init__(self, tags):
            self._tags = tags
            self._loader = None

    # Mock the function which is called during the test on the Taggable object
    fake_loader = {'template': lambda text, vars: text}
    t = Templar(loader=fake_loader, variables={})
    def mock_template(self, val):
        return t.template(val)
    Taggable._get_field = mock_template
    # End of mocked templar.template

    task = FakeTask('')
    try:
        task.evaluate_tags()
    except TypeError:
        assert True

# Generated at 2022-06-23 07:11:03.944587
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.parsing.yaml.objects
    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None
    # We test the Taggable class in a very isolated way
    # We directly set its _tags attribute, because we do not have any other possibility here
    myTaggable = MyTaggable()
    myTaggable._tags = ['t1', 't2']
    # Case: only_tags: 'all'. Should run
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert myTaggable.evaluate_tags(only_tags, skip_tags, all_vars), "Taggable.evaluate_tags() test1 failed"
    # Case: only_tags: 'all

# Generated at 2022-06-23 07:11:14.409163
# Unit test for constructor of class Taggable
def test_Taggable():
    tag = Taggable()
    assert tag.tags == list()
    tag = Taggable(tags=['tag1'])
    assert tag.tags == ['tag1']
    tag = Taggable(tags=['tag1', 'tag2'])
    assert tag.tags == ['tag1', 'tag2']
    tag = Taggable(tags='tag1')
    assert tag.tags == ['tag1']
    tag = Taggable(tags='tag1, tag2')
    assert tag.tags == ['tag1', 'tag2']
    tag = Taggable(tags=['tag1', 'tag2'], _ansible_no_log=False)
    assert tag.tags == ['tag1', 'tag2']
    tag = Taggable(tags='tag1', _ansible_no_log=False)


# Generated at 2022-06-23 07:11:24.990810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()

    #default state: no tags and no options
    assert t.evaluate_tags([], [], {}) == True
    #add tags
    t.tags = set(['always'])

    #tags and options match
    assert t.evaluate_tags(['always'], [], {}) == True
    #tags and options don't match
    assert t.evaluate_tags(['foo'], [], {}) == False

    #skip_tags empty
    assert t.evaluate_tags([], ['always'], {}) == False
    assert t.evaluate_tags([], [], {}) == True
    assert t.evaluate_tags(['always'], [], {}) == True

    #test all
    t.tags = set([])

# Generated at 2022-06-23 07:11:27.943445
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []


# Generated at 2022-06-23 07:11:38.410298
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.dataloader import DataLoader
    the_loader = DataLoader()
    from ansible.vars import VariableManager
    the_vars = VariableManager()
    from ansible.inventory.manager import InventoryManager
    the_inven = InventoryManager(loader=the_loader, sources=None, variable_manager=the_vars)

    tag_instance = Taggable()
    tag_instance._loader = the_loader
    tag_instance._variable_manager = the_vars
    tag_instance._inventory = the_inven

    # _tags not specified, tags is untagged 
    tag_instance.tags = None
    assert tag_instance.evaluate_tags([], [], {}) == True

    class Dummy_class():
        pass

    # Only_tags without 'all'
    tag_

# Generated at 2022-06-23 07:11:42.710254
# Unit test for constructor of class Taggable
def test_Taggable():
  taggable = Taggable()
  # Test attributes exist
  assert (taggable.tags)
  assert (taggable.evaluate_tags)
  assert (taggable.untagged)
  assert (taggable._load_tags)
  assert (taggable._tags)
test_Taggable()

# Generated at 2022-06-23 07:11:50.782761
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.playbook import Playbook, PlaybookInclude
    from ansible.playbook.task import Task, TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    playbook = Playbook()
    play = PlaybookInclude()
    task = Task()
    block = TaskInclude()
    handler = Handler()
    role = Role()
    role.name = 'apt'
    play_context = PlayContext()
    playbook.set_loader('/usr/share/ansible')

    # task.load_tags
    task.tags = 'tag1,tag2,tag3'
    task._load_tags('tags', task.tags)

# Generated at 2022-06-23 07:12:01.266499
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    class Play:
        def __init__(self):
            self._ds = [{
                'tasks': [
                    {'name': 'task1', 'tags': ['always']},
                    {'name': 'task2', 'tags': ['test']},
                    {'name': 'task3', 'tags': ['never']},
                    {'name': 'task4'}
                ]
            }]
            self._loader = None
            self._variable_manager = VariableManager()

        def get_vars(self, play=None):
            return self._variable_manager.get_vars(play=play)

        def serialize(self):
            return self._ds


# Generated at 2022-06-23 07:12:09.628508
# Unit test for constructor of class Taggable
def test_Taggable():
    # Create taggable instance
    t = Taggable()
    # get all the public methods of Taggable
    public_methods = [func for func in dir(t) if callable(getattr(t, func)) and not func.startswith("__")]
    assert len(public_methods) == 0
    # check private field in Taggable
    assert "_tags" in dir(t)
    assert "_tags" not in t.__dict__.keys()
    # check instance method in Taggable
    assert "_load_tags" in dir(t)

# Generated at 2022-06-23 07:12:21.185108
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test for simple tags, i.e. only_tags and skip_tags are simple lists of strings
    # Test for variable tags, i.e. one of the elements in the only_tags list is a variable name,
    # and that variable's value is a list of strings
    # Test for complex tags, i.e. one of the elements in the only_tags list is a variable name,
    # and that variable's value is a string which contains multiple tags separated by commas.
    class Fake(Taggable):
        pass
    fake = Fake()

    # Simple tags
    fake.tags = ['A', 'B', 'C']
    assert fake.evaluate_tags(['A', 'B', 'C'], [], {}) is True
    assert fake.evaluate_tags(['A'], [], {}) is True
    assert fake.evaluate_

# Generated at 2022-06-23 07:12:22.888947
# Unit test for constructor of class Taggable
def test_Taggable():

    from ansible.utils.display import Display
    display = Display()
    display.deprecated("testing deprecated stuff")

# Generated at 2022-06-23 07:12:30.252721
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.playbook.task_include as task_include
    t = task_include.TaskInclude()

    # Check if no tags options (only_tags, skip_tags) were defined,
    # task should be executed
    assert(t.evaluate_tags(None, None, None) == True)

    # Check if tags are not defined in task, and tags option only_tags
    # is defined, task should not be executed
    assert(t.evaluate_tags(set(['tag1']), None, None) == False)

    # Check if tags are defined in task, and tags option only_tags is
    # defined, task should be executed
    t.tags = ['tag1']
    assert(t.evaluate_tags(set(['tag1']), None, None) == True)

    # Check if tags are defined in task and tags

# Generated at 2022-06-23 07:12:43.084041
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_task = Task()

    all_vars = dict(always='always', others='others', tagged='tagged')
    test_taggable.tags = ['always', 'others']
    assert test_task.evaluate_tags(only_tags=['always'], skip_tags=list(), all_vars=all_vars)
    assert test_task.evaluate_tags(only_tags=['tagged'], skip_tags=list(), all_vars=all_vars)
    assert not test_task.evaluate_tags(only_tags=['never'], skip_tags=list(), all_vars=all_vars)
    assert not test

# Generated at 2022-06-23 07:12:47.532558
# Unit test for constructor of class Taggable
def test_Taggable():
    def test_tags():
        return ['test', 'pip']
    test = Taggable()
    test.tags = test_tags()
    if __name__ == '__main__':
        print(test.tags)
    else:
        assert test.tags == ['test', 'pip']

if __name__ == '__main__':
    test_Taggable()

# Generated at 2022-06-23 07:12:55.618781
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Object(Taggable): pass
    obj = Object()

    obj.tags = ['always']
    assert obj.evaluate_tags({}, {}, {})

    obj.tags = ['never']
    assert not obj.evaluate_tags({}, {}, {})

    obj.tags = ['tagged']
    assert not obj.evaluate_tags({}, {}, {})

    obj.tags = []
    assert obj.evaluate_tags({}, {}, {})

    obj.tags = ['untagged']
    assert obj.evaluate_tags({}, {}, {})

    obj.tags = ['foo']
    assert obj.evaluate_tags({}, {}, {})

    obj.tags = ['foo', 'bar']

    assert obj.evaluate_tags({}, {'bar'}, {})

# Generated at 2022-06-23 07:13:02.741709
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.task_include import TaskInclude

    loader = 'loader'
    t = TaskInclude(loader=loader)
    assert t.tags is not None
    assert t.tags == []
    assert t._tags is not None
    assert t._tags == []
    assert t.untagged is not None
    assert t.untagged == frozenset(['untagged'])


# Generated at 2022-06-23 07:13:11.425810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Run unit test for Taggable.evaluate_tags()
    '''

    from collections import namedtuple
    from ansible.playbook import block
    from ansible.playbook.base import Base
    from ansible.template import Templar

    class FakePlayContext(object):
        tags = set()

    class FakeTask(Taggable):

        tags = None

        def __init__(self, tags, block=None):
            self.tags = tags
            self.block = block

        def load(self, loader):
            self._loader = loader


# Generated at 2022-06-23 07:13:16.212694
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    taggable._tags = [1, 2, 3, 4, 5]
    assert taggable._load_tags("_tags", [1, 2, 3, 4]) == [1, 2, 3, 4]


# Generated at 2022-06-23 07:13:23.755925
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']

    taggable_obj = Taggable()

    taggable_obj.tags = ['tag3', 'tag1']
    assert False == taggable_obj.evaluate_tags(play_context.only_tags, play_context.skip_tags, {})

    taggable_obj.tags = ['tag4']
    assert False == taggable_obj.evaluate_tags(play_context.only_tags, play_context.skip_tags, {})

    taggable_obj.tags = ['tag2', 'tag5']

# Generated at 2022-06-23 07:13:25.266156
# Unit test for constructor of class Taggable
def test_Taggable():
    # taggable = Taggable()
    pass



# Generated at 2022-06-23 07:13:34.062642
# Unit test for constructor of class Taggable
def test_Taggable():
    import unittest2 as unittest

    class TestTaggable(unittest.TestCase):
        def setUp(self):
            self.taggable = Taggable()

        def tearDown(self):
            del self.taggable

        def test_tags_none(self):
            self.assertEqual(self.taggable.tags, list())

        def test_load_tags(self):
            tags = ['tag1', 'tag2', 'tag3']
            tags_str = ', '.join(tags)
            self.assertEqual(self.taggable._load_tags('tags', tags), tags)
            self.assertEqual(self.taggable._load_tags('tags', tags_str), tags)


# Generated at 2022-06-23 07:13:40.473483
# Unit test for constructor of class Taggable
def test_Taggable():
    # Case 1
    obj = Taggable()
    assert obj._tags == []

    # Case 2
    obj = Taggable(tags=['a', 'b'])
    assert obj._tags == ['a', 'b']

    # Case 3
    try:
        obj = Taggable(tags=42)
    except AnsibleError:
        assert True
    else:
        assert False, 'AnsibleError should have been raised'

# Generated at 2022-06-23 07:13:48.889890
# Unit test for constructor of class Taggable
def test_Taggable():
    class FakeParent:
        def __init__(self):
            self._loader = "fake_loader"

    t = Taggable()
    assert t.tags == list

    t = Taggable(tags=['test_tag'])
    assert t.tags == ['test_tag']

    t = Taggable(tags="test_tag")
    assert t.tags == ['test_tag']

    t = Taggable(tags=['test_tag', 'test_tag2'])
    assert t.tags == ['test_tag', 'test_tag2']

    t = Taggable(tags="test_tag,test_tag2")
    assert t.tags == ['test_tag', 'test_tag2']

    t = Taggable(tags="test_tag, test_tag2")

# Generated at 2022-06-23 07:13:51.483161
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()  # no exception expected

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-23 07:13:52.351507
# Unit test for constructor of class Taggable
def test_Taggable():
    Taggable()

# Generated at 2022-06-23 07:13:57.355012
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    # test normal constructor
    assert t._tags == []
    # test constructor with tags
    t = Taggable(tags=['tag1', 'tag2'])
    assert t._tags == ['tag1', 'tag2']
    # test constructor with non-list tags
    t = Taggable(tags='tag3')
    assert t._tags == ['tag3']

# Generated at 2022-06-23 07:14:10.238699
# Unit test for constructor of class Taggable
def test_Taggable():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.base import Base

    Loader = namedtuple('Loader', ['get_basedir'])

    tags = AnsibleUnicode('tag1, tag2')
    tags2 = AnsibleUnicode('tag1')
    tags3 = AnsibleUnicode('tag1,tag2')

    loader = Loader(lambda: '')

    class ClassTest(Base, Taggable):
        def __init__(self, tags, loader):
            super(ClassTest, self).__init__()
            self._tags = tags
            self._loader = loader

    instance = ClassTest(tags, loader)

# Generated at 2022-06-23 07:14:11.649808
# Unit test for constructor of class Taggable
def test_Taggable():
    from ansible.playbook.role import Role
    r = Role()
    assert (r.tags == [])

# Generated at 2022-06-23 07:14:15.525331
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable = Taggable()
    assert taggable.tags == []
    assert taggable._load_tags(None, 'tag1') == ['tag1']
    assert taggable._load_tags(None, ['tag1']) == ['tag1']

# Generated at 2022-06-23 07:14:18.323742
# Unit test for constructor of class Taggable
def test_Taggable():
    t = Taggable()
    assert not t._tags
    assert t.untagged == frozenset(['untagged'])
    assert not t._loader


# Generated at 2022-06-23 07:14:21.252130
# Unit test for constructor of class Taggable
def test_Taggable():
    class var(object):
        pass
    m = var()
    m.tags = []
    t = Taggable()
    t.tags = m.tags
    assert t.tags is not None

# Generated at 2022-06-23 07:14:33.744028
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-23 07:14:44.303957
# Unit test for constructor of class Taggable
def test_Taggable():
    # Test taggable
    taggable = Taggable()
    taggable.tags = ['untagged']
    only_tags = ['untagged']
    skip_tags = ['untagged']
    test_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, test_vars) is True

    taggable.tags = ['test_tag']
    only_tags = ['untagged']
    skip_tags = ['untagged']
    test_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, test_vars) is False

    taggable.tags = ['untagged', 'test_tag']
    only_tags = ['test_tag', 'untagged']
    skip_tags = ['untagged']
    test_vars = {}

# Generated at 2022-06-23 07:14:55.732104
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Just a very simple test due to lack of time.
    # This test could be extended with many more cases.
    test_class = Taggable()
    tags = ['one', 'two']
    test_class.tags = tags

    only_tags = ['one']
    skip_tags = ['two']
    assert(test_class.evaluate_tags(only_tags, skip_tags, {}) == True)
    assert(test_class.evaluate_tags(skip_tags, None, {}) == False)
    assert(test_class.evaluate_tags(None, skip_tags, {}) == True)
    assert(test_class.evaluate_tags(None, None, {}) == True)

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:15:08.609667
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    class TestObject(Taggable):
        pass

    obj = TestObject()
    test_vars = dict(always = 'yes')

    # Test _load_tags
    data_string = 'one, two, three'
    output = obj._load_tags('tags', data_string)
    assert(output == ['one', 'two', 'three'])

    data_list = ['one', 'two', 'three']
    output = obj._load_tags('tags', data_list)
    assert(output == ['one', 'two', 'three'])

    try:
        output = obj._load_tags('tags', 1)
    except AnsibleError:
        pass

    # Test evaluate_tags - always
    obj.tags = ['always']
    only_tags = set()
    skip

# Generated at 2022-06-23 07:15:17.788882
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    cls_inst = Taggable()
    block_tags = ['test_run']
    cls_inst.tags = block_tags
    result = cls_inst.evaluate_tags(only_tags=['test_run'], skip_tags=None, all_vars={})
    assert result
    block_tags = ['test_run1','test_run2']
    cls_inst.tags = block_tags
    result = cls_inst.evaluate_tags(only_tags=['test_run1','test_run2','test_run3'], skip_tags=None, all_vars={})
    assert result

# Generated at 2022-06-23 07:15:20.800801
# Unit test for constructor of class Taggable
def test_Taggable():
    taggable_object = Taggable()
    assert set(taggable_object.tags) == set()

#The following test case is to test the evaluate_tags method in class Taggable
#The tags variable is set to a string and tags variable type is string

# Generated at 2022-06-23 07:15:23.677901
# Unit test for constructor of class Taggable
def test_Taggable():
   a = Taggable()
   assert isinstance(a, Taggable)


# Generated at 2022-06-23 07:15:30.265755
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """Taggable: testing method evaluate_tags"""
    # Testing the method evaluate_tags of class Taggable
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    # import sys
    # sys.exit(test_Taggable_evaluate_tags())
    test_Taggable_evaluate_tags()

# Generated at 2022-06-23 07:15:40.960394
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
        '''Tests Taggable.evaluate_tags method'''

        # GIVEN: we have a class Taggable
        taggable = Taggable()

        # GIVEN: a default always tag and a default never tag for our tests
        always_tag = ['always']
        never_tag = ['never']

        # WHEN: we call evaluate_tag with an empty only_tags and empty skip_tags
        #       then the current task should be executed
        should_run = taggable.evaluate_tags([], [], {})
        assert should_run == True, "should_run should be set to True"

        # WHEN: we call evaluate_tag with an empty only_tags and a skip_tags
        #       then the current task should be skipped
        should_run = taggable.evaluate_tags([], never_tag, {})

# Generated at 2022-06-23 07:15:49.004663
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tag=None):
            self.tags = tag

    loader = None
    vars = dict()
    only_tags = None
    skip_tags = None

    # Test case when only_tags is none and skip_tags is none
    # and tag is none
    taggable = FakeTaggable(tag=None)
    assert taggable.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=vars) == True

    # Test case when only_tags is none and skip_tags is none
    # and tag is empty
    taggable = FakeTaggable(tag=[])