

# Generated at 2022-06-11 11:00:25.605299
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class A(Taggable):
        pass

    # Run with no tags specified
    a = A()
    assert a.evaluate_tags(['always'], [], {}) is True
    assert a.evaluate_tags(['never'], [], {}) is False
    assert a.evaluate_tags([], ['always'], {}) is False
    assert a.evaluate_tags([], ['never'], {}) is True
    assert a.evaluate_tags(['all'], [], {}) is True
    assert a.evaluate_tags([], ['all'], {}) is False
    assert a.evaluate_tags(['tagged'], [], {}) is False
    assert a.evaluate_tags([], ['tagged'], {}) is True

    # Run with tags populated
    a = A()
    a.tags = ['runme']


# Generated at 2022-06-11 11:00:34.227348
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    global results
    results = {}

    class ClassToTest(Taggable):
        pass

    # Testing with only_tags and skip_tags
    test_object = ClassToTest()
    test_object._loader = None
    test_object.tags = 'mytag'
    only_tags = ['mytag']
    skip_tags = ['all', 'never']
    all_vars = {}
    result = test_object.evaluate_tags(only_tags, skip_tags, all_vars)
    results['test_01'] = result == False
    results['test_01_result'] = result

    # Testing with only_tags
    test_object = ClassToTest()
    test_object._loader = None
    test_object.tags = 'mytag'
    only_tags = ['mytag']

# Generated at 2022-06-11 11:00:43.942431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self, ds, loader):
            self._ds = ds
            self._loader = loader
            self._variable_manager = None
            self._load_tags("tags", ds)

        def get_variable_manager(self):
            return self._variable_manager

        def set_variable_manager(self, vm):
            self._variable_manager = vm

        @property
        def tags(self):
            return self._tags
    # use Ansible to load the yaml
    from ansible import constants as C

    ds = {
        'roles': [{'name': 'test_role', 'foo': 'bar', 'tags': ['test_role']}],
        'hosts': ['test'],
    }

    # Ansible parses d

# Generated at 2022-06-11 11:00:50.585540
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # MakeDummyClass
    class DummyClass(Taggable):
        pass

    # Check if method 'evaluate_tags' is implemented in class 'Taggable'
    assert hasattr(DummyClass, 'evaluate_tags')

    # Check if method 'evaluate_tags' returns boolean
    dummy_object = DummyClass()
    assert isinstance(dummy_object.evaluate_tags('only_tags', 'skip_tags', 'all_vars'), bool)

test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:01:01.988026
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    task1 = Base()
    task1.args = {'tags':['foo','bar','baz']}

    task2 = Base()
    task2.args = {'tags':['foo','baz','qux']}

    task3 = Base()
    task3.args = {'tags':['qux','quux','quuz']}

    task4 = Base()
    task4.args = {'tags':['never']}

    task5 = Base()
    task5.args = {'tags':['always']}

    only_tags = ['all']
    skip_tags = []
    all_vars = {}

    assert task1.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:01:12.187211
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # These tags are used to test the tags option
    tags1 = ['a', 'b', 'c']
    tags2 = ['d', 'e', 'f']

    # These tags are used to test the only_tags and skip_tags options
    only_tags_one = ['a', 'b', 'c']
    only_tags_two = ['all', 'a']
    only_tags_three = ['tagged', 'a']
    skip_tags_one = ['a', 'b', 'c']
    skip_tags_two = ['all', 'a']
    skip_tags_three = ['tagged', 'a']

    # These tasks are used to test Taggable.evaluate_tags()
    task_one = Task()

# Generated at 2022-06-11 11:01:22.975503
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  tagger_object = Taggable() # Create a Taggable class object
  assert(tagger_object.evaluate_tags([], [], []) == True) # Test default case when only_tags and skip_tags are empty
  assert(tagger_object.evaluate_tags(["all"], [], []) == True) # Test case when only_tags is not empty
  assert(tagger_object.evaluate_tags([], ["all"], []) == False) # Test case when skip_tags is not empty
  assert(tagger_object.evaluate_tags(["all"], ["never"], []) == True) # Test case when always is present in tags
  assert(tagger_object.evaluate_tags(["never"], [], []) == False) # Test case when never is present in tags

# Generated at 2022-06-11 11:01:32.012403
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task

    task = Task()
    task.tags = ['test', 'other']
    assert task.evaluate_tags([], [], {}) == True
    assert task.evaluate_tags(['all'], [], {}) == True
    assert task.evaluate_tags(['test'], [], {}) == True
    assert task.evaluate_tags(['other'], [], {}) == True
    assert task.evaluate_tags(['test', 'other'], [], {}) == True
    assert task.evaluate_tags(['test', 'other', 'another'], [], {}) == True
    assert task.evaluate_tags(['another'], [], {}) == False
    assert task.evaluate_tags([], ['all'], {}) == False
    assert task.evaluate_tags

# Generated at 2022-06-11 11:01:44.727713
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from os.path import join, dirname, realpath
    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    test_file = 'test_playbook_evaluate_tags.yml'
    test_path = join(dirname(realpath(__file__)), 'unit', 'playbook', 'test_data', test_file)

    Playbook = namedtuple('Play', ['vars', 'roles', 'tasks'])
    Playbook.vars = {}
    Playbook.roles = []
    Playbook.tasks = []
    play = Play.load(test_path, variable_manager=None, loader=None)


# Generated at 2022-06-11 11:01:47.932428
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  only_tags = ['debug']
  tags = ['debug', 'test']
  skip_tags = []

  t = Taggable()
  t.tags = tags

  print(t.evaluate_tags(only_tags, skip_tags, {}))

# Generated at 2022-06-11 11:02:10.568364
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Set up an object with tag attribute as a mix of str, int and list
    myobj = Taggable()
    myobj.tags = ['red', 'green', 1, ['foo', 'bar', 2]]
    myobj.tags = myobj._load_tags(myobj.tags, myobj.tags)

    # Test with only_tags
    assert myobj.evaluate_tags(only_tags=['red'], skip_tags=[], all_vars={})
    assert not myobj.evaluate_tags(only_tags=['blue'], skip_tags=[], all_vars={})
    assert myobj.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:02:21.552913
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # Test 1: only_tags = ['tag1', 'tag2']
    # Test skip_tags = None
    # Test tags = ['tag1']
    ret = t.evaluate_tags(['tag1', 'tag2'], None, dict())
    assert ret

    # Test 2: only_tags = ['tag1', 'tag2']
    # Test skip_tags = None
    # Test tags = ['tag11']
    ret = t.evaluate_tags(['tag1', 'tag2'], None, dict())
    assert not ret

    # Test 3: only_tags = None
    # Test skip_tags = ['tag1', 'tag2']
    # Test tags = ['tag1']
    ret = t.evaluate_tags(None, ['tag1', 'tag2'], dict())

# Generated at 2022-06-11 11:02:33.058327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # A simple Play to use in our test
    pb = Play().load({
        "name"       : "foobar",
        "hosts"      : "all",
        "gather_facts" : "no"
    }, loader=None, variable_manager=None)

    # Set a playbook tag
    pb._tags = ['playtag']

    # Create a Block
    blk = Block(play=pb)

    # Create a Task with no tags
    task0 = Task(block=blk)

    # Create a Task with a static tag
    task1 = Task(block=blk)
    task1._tags = ['tag1']

    # Create a Task with a static list

# Generated at 2022-06-11 11:02:42.210552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class task(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
            self._loader = None
            self.vars = dict()

    # test with 'always' tag
    values = {'always': True, 'never': False, 'all': False, 'tagged': False}
    task1 = task(tags=['always'])
    result = task1.evaluate_tags(['always', 'all'], [], values)
    assert result, "False returned for always tag evaluation"

    result = task1.evaluate_tags(['all', 'never'], [], values)
    assert not result, "True returned for always tag evaluation"

    # test with 'never'

# Generated at 2022-06-11 11:02:53.196438
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTask(Taggable):
        pass

    task = MockTask()
    task._loader = None

    # Check that running a tagged task with only_tags=["tag1"] works
    task.tags = ["tag1"]
    assert task.evaluate_tags(["tag1"], [], {})

    task.tags = []

    # Check that running a task with no tags and only_tags=["tag1"] fails
    assert not task.evaluate_tags(["tag1"], [], {})

    # Check that running a task with no tags and only_tags=["all"] works
    assert task.evaluate_tags(["all"], [], {})

    # Check that running a task with no tags and only_tags=["tagged"] fails
    assert not task.evaluate_tags(["tagged"], [], {})

    # Check that running

# Generated at 2022-06-11 11:03:04.974581
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  # Create an object representing a task
  task = Taggable()
  # Set the tags
  task.tags = [ 'tag1', 'tag2' ]
  # Test
  assert task.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})
  assert task.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
  assert not task.evaluate_tags(only_tags=['tag3', 'tag4'], skip_tags=[], all_vars={})
  assert task.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=['tag1'], all_vars={})
  # Create an object representing an untagged task
  task = Taggable()

# Generated at 2022-06-11 11:03:13.766977
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self._tags = tags


# Generated at 2022-06-11 11:03:24.174771
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['foo']
    item = {'tags' : tags}
    result = Taggable().evaluate_tags(['all', 'foo'], item, [])
    assert result == True
    result = Taggable().evaluate_tags(['all', 'bar'], item, [])
    assert result == False
    result = Taggable().evaluate_tags(['all', 'never'], item, [])
    assert result == False
    result = Taggable().evaluate_tags(['all', 'always'], item, [])
    assert result == True
    result = Taggable().evaluate_tags(['all'], item, [])
    assert result == True
    result = Taggable().evaluate_tags(['all', 'never', 'foo'], item, [])
    assert result == True

# Generated at 2022-06-11 11:03:34.729578
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    def test_items(tags, only_tags, skip_tags, should_run):
        assert taggable.evaluate_tags(only_tags, skip_tags, dict(tags=tags)) == should_run

    test_items([], [], [], True)
    test_items([], [], ['foo'], True)
    test_items(['foo'], [], ['foo'], False)
    test_items(['foo'], [], ['bar'], True)
    test_items(['foo'], [], [''], True)
    test_items(['foo'], [], [], True)
    test_items('foo', [], [], True)
    test_items('foo', [], ['foo'], False)

# Generated at 2022-06-11 11:03:41.683230
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    def _test_condition(evaluate_tags, expected_ret, msg):
        if not expected_ret:
            expected_ret = False
        else:
            expected_ret = True
        assert(evaluate_tags == expected_ret), msg

    # Test only_tags and skip tags is empty
    test_taggable = TestTaggable()
    _test_condition(test_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars=[]), True, "Incorrect return for only_tags and skip_tags empty")

    # Test only_tags with 'all' and skip_tags is empty
    test_taggable = TestTaggable()

# Generated at 2022-06-11 11:04:06.845482
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # create an instance of Playbook
    pb = Playbook()

    # create an instance of Block
    b = Block.load(pb.loader, pb._variable_manager, {'name': 'test-block'}, None)

    # create an instance of Task
    t = Task.load(pb.loader, pb._variable_manager, {'name': 'test-task'}, b)

    # evaluate_tags
    assert t.evaluate_tags([], [], {})
    assert not t.evaluate_tags([], ['all'], {})

    # check 'all'
    assert t.evaluate_tags(['all', 'tagged'], [], {})
    assert not t

# Generated at 2022-06-11 11:04:17.743776
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t._tags = None
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    t = Taggable()
    t._tags = ['a', 'b']
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == False

# Generated at 2022-06-11 11:04:27.579058
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestTaggable(Taggable):
      _loader = AnsibleLoader

      def __init__(self, taglist, skip, only):
          self.tags = taglist
          self.only_tags = only
          self.skip_tags = skip

    # Positive tests
    # When tags has always, test_obj.evaluate_tags() should return true
    test_obj = TestTaggable(['always'], ['never'], ['always'])
    assert test_obj.evaluate_tags(test_obj.only_tags, test_obj.skip_tags, {})

    # When only_tags has all and untagged, test_obj.evaluate_tags() should return true


# Generated at 2022-06-11 11:04:39.175215
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Method evaluate_tags of class Taggable
    '''

    # Set up object
    obj = Taggable()
    obj.tags = ['tag1', 'tag2', 'ansible_tag']

    ds = [{u'hosts': [u'vagrant-ubuntu-trusty-64'], u'vars': {u'ansible_connection': u'local', u'ansible_python_interpreter': u'/usr/bin/python'}}, {u'include': u'_vagrant_provision_test.yml'}]
    obj._loader = None
    obj._variable_manager = None
    obj.all_vars = dict()

    # Test with only ansible_tag
    only_tags = ['ansible_tag']
    skip_tags = []

# Generated at 2022-06-11 11:04:50.069097
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Foo(Taggable):
        def __init__(self):
            self._tags = ["all"]

    f = Foo()
    # First test, with only_tags specified, only_tags matching
    assert f.evaluate_tags(["all"], [], {})

    # Second test, with only_tags specified, only_tags matching with templating
    assert f.evaluate_tags(["{{ 'all' }}"], [], {})

    # Third test, with only_tags specified, only_tags not matching
    assert not f.evaluate_tags(["never"], [], {})

    # Fourth test, with skip_tags specified, skip_tags matching
    assert not f.evaluate_tags([], ["all"], {})

    # Fifth test, with skip_tags specified, skip_tags matching with templating
    assert not f.evaluate_tags

# Generated at 2022-06-11 11:05:00.711978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class tTaggable(Taggable):
        pass

    tt = tTaggable()
    tt.tags = [ 'test1', 'test2' ]
    ret = tt.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars="test")
    assert ret

    ret = tt.evaluate_tags(only_tags=set(['test1']), skip_tags=set(), all_vars="test")
    assert ret

    ret = tt.evaluate_tags(only_tags=set(['test3']), skip_tags=set(), all_vars="test")
    assert not ret

    ret = tt.evaluate_tags(only_tags=set(['test2']), skip_tags=set(['test2']), all_vars="test")
    assert not ret

# Generated at 2022-06-11 11:05:11.166873
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = Taggable()
    task.role = 'test'
    task.tags = ['always', 'test']

    # 1.1. positive test: no skip and no only
    assert(task.evaluate_tags(None, None, None) is True)

    # 1.2. positive test: only all and no skip
    assert(task.evaluate_tags(['all'], None, None) is True)

    # 1.3. positive test: only tagged and no skip
    assert(task.evaluate_tags(['tagged'], None, None) is True)

    # 1.4. positive test: only specific tag and no skip
    assert(task.evaluate_tags(['test'], None, None) is True)

    # 1.5. negative test: only specific tag and no skip

# Generated at 2022-06-11 11:05:20.947943
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Test the evaluate_tags method of Taggable'''
    from ansible.playbook.role.include import RoleInclude
    from ansible.taggable import Taggable
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    # Test data
    playbook_vars = dict(a='a', b='b')
    host_vars = dict(c='c', d='d')
    group_vars = dict(e='e', f='f')
    all_vars = combine_vars(host_vars, group_vars, playbook_vars)

    # Setup the VariableManager
    vm = VariableManager()
    vm.add_host_vars(host_vars)

# Generated at 2022-06-11 11:05:32.691289
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # 1. Test if task does not run when skip_tags is used
    # Test case 1.1: 'tagged' in skip_tags
    class TestTaggable1(Taggable):
        def __init__(self):
            self.tags = ['always']
    testTaggable1 = TestTaggable1()
    assert testTaggable1.evaluate_tags(only_tags=[], skip_tags=['tagged'], all_vars={}) == False

    # Test case 1.2: 'never' in skip_tags
    class TestTaggable2(Taggable):
        def __init__(self):
            self.tags = ['never']
    testTaggable2 = TestTaggable2()

# Generated at 2022-06-11 11:05:40.424296
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.module_utils.facts import FacterModule
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    from ansible.module_utils.facts.system import DefaultSystemFacts
    from ansible.module_utils.facts.utils import get_all_facts
    fact_list = [FacterModule(), DistributionFactModule(), DefaultSystemFacts(get_all_facts())]
    all_vars = get_all_facts(fact_list)

    run_tags = {'always', 'never'}
    run_tags.update(all_vars.get('ansible_distribution', '').lower())
    run_tags.update(all_vars.get('ansible_virtualization_role', '').lower())

    #print run_tags


# Generated at 2022-06-11 11:06:11.751844
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Evaluate_tags tests
    '''

    # make sure evaluate_tags is True when using an empty list of skip_tags

    # make sure evaluate_tags is True when using an empty list of only_tags

    # make sure evaluate_tags is True when using both empty lists
    pass

# Generated at 2022-06-11 11:06:22.860195
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

    t = Taggable()
    t._loader = loader
    t._display = display
    t._variable_manager = variable_manager

    inventory = {'host_vars': {}, 'group_vars': {'all': {}}}
    variable_manager.update_inventory(inventory)
    variable_manager.extra_vars = {}

    # test_Taggable_evaluate_tags: 'always' and 'never' tags
    only_tags = None
    skip_tags = None
    t.tags = ['always', 'never']
    assert t.evaluate_tags

# Generated at 2022-06-11 11:06:32.746565
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        from ansible.playbook.play_context import PlayContext
        from ansible.playbook.task import Task
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.handler import Handler
        from ansible.playbook.block import Block
    except:
        from ansible.playbook.base import PlayContext
        from ansible.playbook.task import Task
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.handler import Handler
        from ansible.playbook.block import Block

    class Dummy(Taggable):
        module_utils_path = ''
        _role_params = {}

        def __init__(self):
            self.tags = None
            self.vars = {}


# Generated at 2022-06-11 11:06:43.195899
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test cases for class Taggable, method evaluate_tags

    Consider the following test cases:

    1. The task contains 'only_tags' and is tagged
    2. The task contains 'only_tags' and is not tagged
    3. The task does not contain 'only_tags' and is tagged
    4. The task does not contain 'only_tags' and is not tagged
    5. The task contains 'skip_tags' and should not be skipped
    6. The task contains 'skip_tags' and should be skipped

    :return: None
    """

    testcase_dict = dict()

    # Test case 1
    task_tags = ['test']
    only_tags = ['test']
    skip_tags = list()
    all_vars = dict()


# Generated at 2022-06-11 11:06:54.224215
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test = Taggable()
    test.tags = "always,george"
    only_tags = ['always', 'george']
    skip_tags = []
    all_vars = "george"
    result = test.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True, "Should be True"
    only_tags = ['always', 'george']
    skip_tags = ['george']
    result = test.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False, "Should be False"
    only_tags = ['always', 'george']
    skip_tags = ['george']
    test.tags = ['george']
    result = test.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:07:03.951293
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vars import MockVars

    mytags = ['one', 'two']

    # only run tasks with tags: ['two']
    only_tags = ['two']
    skip_tags = []
    vars = MockVars({})
    t = Taggable()
    t.tags = mytags
    t._loader = DictDataLoader({})
    unfrackpath_patcher = mock_unfrackpath_noop()
    unfrackpath_patcher.start()
    assert t.evaluate_tags(only_tags, skip_tags, vars)
    unfrackpath_patcher.stop()

    # only run tasks with tags: ['two']
    only

# Generated at 2022-06-11 11:07:13.866430
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Fake(Taggable):

        def __init__(self, only_tags, skip_tags):
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.tags = []

        def _load_tags(self, attr, ds):
            return []

    #  Test basic: no filters and empty tags
    fake = Fake(None, None)
    assert fake.evaluate_tags(None, None, {}) is True

    # Test only_tags = []
    fake = Fake([], None)
    assert fake.evaluate_tags([], None, {}) is True

    # Test only_tags = [tag] and empty tags
    fake = Fake(['tag'], None)
    assert fake.evaluate_tags(['tag'], None, {}) is False

    # Test only_tags

# Generated at 2022-06-11 11:07:24.291483
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook import Play, Playbook
    from ansible.inventory import Inventory

    pb = Playbook.load('./test/units/data/tags', variable_manager=None, loader=False)

    assert len(pb.get_plays()) == 1

    test_play = pb.get_plays()[0]

    # "task 1" should run because 'tagged' and 'tag1' are in only_tags
    assert test_play.get_tasks()[0].evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars=[]) == True

    # "task 1" should NOT run because 'tagged' is in skip_tags

# Generated at 2022-06-11 11:07:29.038838
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    task = dict(tags=['tag1'])
    evaluated = Taggable.evaluate_tags(Taggable(), task, 'tag1', 'never')
    assert not evaluated

    task = dict(tags=['tag1', 'never'])
    evaluated = Taggable.evaluate_tags(Taggable(), task, 'tag1', 'never')
    assert not evaluated

    task = dict(tags=['tag1'])
    evaluated = Taggable.evaluate_tags(Taggable(), task, 'tag1', None)
    assert evaluated

    task = dict(tags=[])
    evaluated = Taggable.evaluate_tags(Taggable(), task, ['tag1'], None)
    assert not evaluated

    task = dict(tags=[])

# Generated at 2022-06-11 11:07:36.705443
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    only_tags = set()
    skip_tags = set()
    all_vars  = dict()

    t = Taggable()
    t.tags = list()
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = set(["foo"])
    skip_tags = set()
    all_vars  = dict()

    t = Taggable()
    t.tags = list()
    with pytest.raises(AnsibleError):
        t.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:08:44.772003
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.helpers import load_list_of_blocks

    ri = RoleInclude()
    setattr(ri, '_host_list', [])

    ri.tags = ['a', 'b', 'c']
    ri.always_run = False
    ri.run_once = False
    ri.delegate_to = None
    ri.deprecated = False
    ri.action = 'include'
    ri.loop = '{{ my_loop }}'
    ri.static = 'yes'
    ri.ignore_errors = False
    ri.register = ''
    #ri.attributes = {}
    ri.include_role = {'name': 'my_role'}


# Generated at 2022-06-11 11:08:54.736905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Fake1(Taggable):
        pass
    x = Fake1()
    # 1. test with only_tags
    # 1.1 test with 'all' and 'always' tag
    x.tags = ['all', 'always']
    only_tags = ['all', 'foo']
    skip_tags = None
    all_vars = None
    assert x.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # 1.2 test with 'all' and 'never' tag
    x.tags = ['all', 'never']
    only_tags = ['all', 'foo']
    assert x.evaluate_tags(only_tags, skip_tags, all_vars) == False
    # 1.3 test with 'all' tag
    x.tags = ['all']

# Generated at 2022-06-11 11:09:06.308998
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTaggable(Taggable):
        pass

    ft = FakeTaggable()

    # test no tags
    ft.tags = None
    assert ft.evaluate_tags(None, None, None) == True

    # test empty tags
    ft.tags = list()
    assert ft.evaluate_tags(None, None, None) == True

    # test all tag
    ft.tags = ['all']
    assert ft.evaluate_tags(['all'], None, None) == True
    assert ft.evaluate_tags(['all'], [], None) == True
    assert ft.evaluate_tags(None, ['all'], None) == False
    assert ft.evaluate_tags(['all', 'test'], ['all'], None) == False

    # test always tag
    ft.tags = ['always']
    assert ft

# Generated at 2022-06-11 11:09:15.945334
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.helpers import load_list_of_tasks

    class MyTaggable(Taggable, Base):
        pass

    task = MyTaggable()

    task.tags = []
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert not task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})

    task.tags = ['always']
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert task.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:09:23.685909
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:09:34.208859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Definition of test variables
    all_vars = dict(
        a="a",
        b="b",
        c="c",
        d=dict(
            e="e",
            f="f",
            g="g",
            h=dict(
                i="i",
                j="j"
            )
        )
    )

    task = Taggable()
    task._loader = None
    task._ds = None

    # Test only_tags
    task.tags = ["{{a | default('never') }}", "{{b | default('always') }}"]
    only_tags = ["b"]
    skip_tags = []
    assert task.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:09:44.545576
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.vars.manager import VariableManager
    import ansible.parsing.dataloader
    from ansible.playbook.play_context import PlayContext

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()

    # test 1 -- when there is no tags
    pb = Taggable()

    # no tags options
    context.only_tags = []
    context.skip_tags = []
    assert pb.evaluate_tags(context.only_tags, context.skip_tags, variable_manager._fact_cache) is True

    # only_tags
    context.only_tags = ['tag1', 'tag2', 'tag3']
    context.skip_tags = []

# Generated at 2022-06-11 11:09:55.872531
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    # Test with no tags defined
    TestTaggable_obj = TestTaggable()
    assert TestTaggable_obj.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) is True

    # Test with tags defined
    TestTaggable_obj = TestTaggable(tags=['tag1', 'tag2'])
    assert TestTaggable_obj.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) is True
    assert TestTaggable_obj.evaluate_tags(only_tags=set(['tag1']), skip_tags=set(), all_vars={}) is True
    assert TestTaggable

# Generated at 2022-06-11 11:10:06.412262
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # assert with all positive conditions
    t = Taggable()
    t.tags = "a, b, all, always, tagged"
    assert(t.evaluate_tags(set(['a', 'b', 'c', 'all', 'always', 'tagged']), set(), {}) == True)

    # assert with all negative conditions
    t = Taggable()
    t.tags = "a, b, all, tagged"
    assert(t.evaluate_tags(set(['c', 'd', 'e', 'f']), set(), {}) == False)

    # assert with skip all and positive or negative condition
    t = Taggable()
    t.tags = "a, all, tagged"