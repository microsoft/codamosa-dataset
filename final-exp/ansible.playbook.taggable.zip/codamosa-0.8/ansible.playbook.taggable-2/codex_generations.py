

# Generated at 2022-06-11 11:00:26.450962
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import pytest

    #TODO: Replace Taggable by mock
    #from mock import Mock
    #Taggable = Mock()

    # Fixing the problem with the dynamic module loading:
    def load_module(module_name):
        module_path = os.path.join(module_path,module_name)
        if module_path not in sys.path:
            sys.path.insert(0, module_path)

    #'test_module_path' should be a path to the modules directory of ansible
    test_module_path = os.path.expanduser("~/ansible/lib/ansible/modules")
    load_module(test_module_path)

    # Importing the module module
    from ansible.modules.extras.cloud.rackspace import cs_domain

# Generated at 2022-06-11 11:00:34.982481
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags=None):
            if tags:
                self.tags = tags

    # test execution of always tag
    taggable = MyTaggable(tags=['always'])
    assert taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})

    # test skipped execution of always tag
    taggable = MyTaggable(tags=['always'])
    assert not taggable.evaluate_tags(only_tags=None, skip_tags=['always'], all_vars={})

    # test execution of never tag
    taggable = MyTaggable(tags=['never'])

# Generated at 2022-06-11 11:00:44.885152
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Tag Strategy
    never : exclude task from execution
    always: include task for execution
    tagged: include task if tagged
    '''

    class FakeTaggable(Taggable):
        ''' Fake Taggable class that only has the method evaluate_tags '''

        def __init__(self, tags):
            self._tags = tags

    # no tags provide should be True
    assert FakeTaggable(None).evaluate_tags(None, None, None)

    # no tags should be run if only_tags is provided
    assert not FakeTaggable(None).evaluate_tags(['all'], None, None)

    # no tags should be run if skip_tags is provided
    assert not FakeTaggable(None).evaluate_tags(None, ['all'], None)

    # tags = ['never', 'skip'] and

# Generated at 2022-06-11 11:00:52.066405
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, name):
            self.name = name

    assert FakeTaggable('foo').evaluate_tags([], ['never'], {}) == False
    assert FakeTaggable('foo').evaluate_tags([], [], {}) == True

    # Default behavior when no tags are defined
    assert FakeTaggable('foo').evaluate_tags([], ['all'], {}) == False
    assert FakeTaggable('foo').evaluate_tags(['all'], ['never'], {}) == True

# Generated at 2022-06-11 11:00:52.829566
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True


# Generated at 2022-06-11 11:01:03.947326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Test(Taggable):
        pass

    only_tags = frozenset()
    skip_tags = frozenset()

    test = Test()
    assert test.evaluate_tags(only_tags, skip_tags, None)

    test.tags = ['foo', 'bar']
    assert not test.evaluate_tags(only_tags, skip_tags, None)

    only_tags = frozenset(['tagged'])
    assert not test.evaluate_tags(only_tags, skip_tags, None)

    only_tags = frozenset(['foo'])
    assert test.evaluate_tags(only_tags, skip_tags, None)

    test.tags = []
    assert test.evaluate_tags(only_tags, skip_tags, None)

    test.tags = ['foo', 'bar']
    skip_tags

# Generated at 2022-06-11 11:01:15.975747
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyTaggable(Taggable):
        def __init__(self, _loader, tags):
            self._loader = _loader
            if tags is not None:
                self.tags = tags

    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    all_vars = {}

    # should_run = True  # default, tasks to run

    assert DummyTaggable(None, None).evaluate_tags(only_tags, skip_tags, all_vars) == True
    assert DummyTaggable(None, '').evaluate_tags(only_tags, skip_tags, all_vars) == True
    assert DummyTaggable(None, []).evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-11 11:01:26.722689
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    test_task = Task()
    test_task._loader = None
    test_task._attributes = dict()

    # Case 1-1. both only_tags and skip_tags are empty
    result = test_task.evaluate_tags([], [], {})
    assert result == True

    # Case 1-2. only_tags is empty but skip_tags is not empty
    result = test_task.evaluate_tags([], ['debug'], {})
    assert result == False

    # Case 1-3. only_tags is not empty but skip_tags is empty, tags of task is empty
    result = test_task.evaluate_tags(['A', 'B', 'C'], [], {})
    assert result == True

    # Case 1-4. only_tags is not empty, tags

# Generated at 2022-06-11 11:01:33.722010
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    Taggable_object = Taggable()
    Taggable_object._loader = True
    assert Taggable_object.evaluate_tags(['all'], [], {}) == True
    assert Taggable_object.evaluate_tags(['all'], ['never'], {}) == False
    assert Taggable_object.evaluate_tags(['all'], ['no_exist_tag'], {}) == True
    assert Taggable_object.evaluate_tags(['no_exist_tag'], ['all'], {}) == False
    assert Taggable_object.evaluate_tags(['tagged'], ['all'], {}) == False
    assert Taggable_object.evaluate_tags([], ['all'], {}) == False
    assert Taggable_object.evaluate_tags([], ['tagged'], {}) == False

# Generated at 2022-06-11 11:01:46.396794
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Task()
    p = PlayContext()
    t._play_context = p

    # check default behavior
    assert t.evaluate_tags() == True

    # check if only_tags * empty * skip_tags * empty * while * tags * empty
    # should_run = True

    # check if only_tags * not empty * skip_tags * empty * while * tags * empty
    p.only_tags = ['only1']
    assert t.evaluate_tags() == False

    # check if only_tags * empty * skip_tags * not empty * while * tags * empty
    p.only_tags = []
    p.skip_tags = ['skip1']
    assert t.evaluate_tags() == True

    #

# Generated at 2022-06-11 11:02:01.115293
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize the class
    import ansible.playbook.role
    import ansible.playbook.task
    from ansible.template import Templar
    import ansible.vars.manager
    import ansible.vars.unsafe_proxy

    class Tagged:
        def __init__(self, tags):
            self.tags = tags
        def get_tags(self):
            return self.tags

    class MockTask(ansible.playbook.task.Task):
        _valid_attrs = frozenset(['name', '_role', 'tags'])
        def __init__(self, name, tags):
            super(MockTask, self).__init__(name, MockRole(), dict())
            self._role = MockRole()
            self.tags = tags


# Generated at 2022-06-11 11:02:10.517586
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeObj(Taggable):
        def __init__(self):
            self.tags = None

    o = FakeObj()
    assert o.evaluate_tags(only_tags=None, skip_tags=None, all_vars=dict()) is True
    assert o.evaluate_tags(only_tags=['A'], skip_tags=None, all_vars=dict()) is False
    assert o.evaluate_tags(only_tags=['A'], skip_tags=['B'], all_vars=dict()) is False
    assert o.evaluate_tags(only_tags=None, skip_tags=['A'], all_vars=dict()) is True
    assert o.evaluate_tags(only_tags=None, skip_tags=['A'], all_vars=dict()) is True


# Generated at 2022-06-11 11:02:21.441136
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggedItem(Taggable):
        def __init__(self):
            self.tags = list()
        def set_tags(self,tags):
            self.tags = tags

    tagged_item = TaggedItem()

    # default, tasks to run
    only_tags = None
    skip_tags = None
    tagged_item.set_tags([])
    assert tagged_item.evaluate_tags(only_tags, skip_tags, {})

    # only_tags: run only tags with tags listed here
    tagged_item.set_tags( [ 'odd', 'even'])
    assert tagged_item.evaluate_tags( ['odd'], None, {})

    # skip_tags: run tasks with tags not listed here
    tagged_item.set_tags( [ 'odd', 'even'])
    assert not tagged_item

# Generated at 2022-06-11 11:02:25.495614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        """
        A test class
        """
        def __init__(self):
            pass

    cls = TestClass()

    cls.tags = ['always']
    cls.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert cls.tags == [u'always']

    cls.tags = [u'all']
    cls.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert cls.tags == [u'all']

    cls.tags = [u'never']
    cls.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert cls.tags == [u'never']

   

# Generated at 2022-06-11 11:02:36.913088
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            pass
    tt = TestTaggable()

    tt.tags = None
    assert tt.evaluate_tags(None, None, None) == True

    tt.tags = []
    assert tt.evaluate_tags(None, None, None) == True

    tt.tags = ['a', 'b', 'c']
    assert tt.evaluate_tags(None, ['a'], None) == False
    assert tt.evaluate_tags(None, ['a', 'b'], None) == False
    assert tt.evaluate_tags(None, ['a', 'b', 'c'], None) == False
    assert tt.evaluate_tags(None, ['d'], None) == True


# Generated at 2022-06-11 11:02:45.705138
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    # Make sure we can create a task
    task = Task()

    # Check that a normal task without tags doesn't run
    only_tags = set()
    skip_tags = set()
    all_vars = dict()
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert not should_run

    # Check that a normal task with tags run
    task.tags = 'tag1'
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run

    # Check that a normal task with tags run
    task.tags = ['tag1', 'tag2']
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:02:57.106549
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Import needed stuff
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # Prepare test
    my_play = Play()

    my_task_with_tags = Task()
    my_task_with_tags.tags = ['foo']
    my_task_with_tags.action = 'test'

    my_task_with_untagged = Task()
    my_task_with_untagged.tags = []
    my_task_with_untagged.action = 'test'

    my_task_with_always = Task()
    my_task_with_always.tags = ['always']
    my_task_with_always.action = 'test'

    my_task_with_never = Task()
    my_task_with_never.tags = ['never']
    my

# Generated at 2022-06-11 11:03:07.881317
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    # Unit test setup
    # Tags will have to be empty, to not depend on any extra tasks
    class test_tag():
        tags = Taggable._tags
        def __init__(self, tags=None):
            self.tags = tags
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

    # Valid tests

# Generated at 2022-06-11 11:03:18.476088
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
        
    # Declare and setup the test_Taggable 
    test_Taggable = Taggable()
    # tags member is assigned an instance of FieldAttribute with isa='list',default=list,listof=(string_types,int),extend=True.
    test_Taggable.tags = test_Taggable._tags
    # Declare and setup the test_vars
    test_vars=dict()
    test_vars['name']='test'
    test_vars['tags'] = list(['foo','bar','bat','baz','never','always','tagged','untagged','all'])
    test_Taggable.all_vars = test_vars
    # should run the task if no tags are specified
    only_tags=None
    skip_tags=None
    should_run = test_

# Generated at 2022-06-11 11:03:29.101444
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # for testing purposes we need to be able to instantiate a class
    class TaggableClass(object):
        __metaclass__ = Taggable

    # define only_tags and skip_tags lists
    only_tags    = [ 'test1' ]
    skip_tags    = [ 'test2', 'always' ]

    # define the object to be tagged and the object template variables
    myobj        = TaggableClass()
    all_vars     = {}

    # tag object with a list
    myobj.tags   = [ 'test1', 'test2', 'test3' ]
    assert myobj.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # tag object with a string
    myobj.tags   = 'test1'

# Generated at 2022-06-11 11:03:52.535702
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestTaggable(Taggable):
        pass

    t1 = TestTaggable()
    t2 = TestTaggable()
    t3 = TestTaggable()

    # Testing evaluate_tags
    # Base tests
    # Check that it works with no tags on the task and no tags set
    assert t1.evaluate_tags(None, None, {})
    # Check that it works with no tags on the task and all tag set
    assert t1.evaluate_tags(['all'], None, {})
    # Check that it works with no tags on the task and skip tags set
    assert t1.evaluate_tags(None, ['all'], {})
    # Check that it works with no tags on the task and only tags

# Generated at 2022-06-11 11:04:03.421702
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.release import __version__
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.module_utils.six import string_types
    import os
    import pytest
    import yaml

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    basedir = os.path.dirname(__file__)

    if not os.path.isdir(os.path.join(basedir, 'vars')):
       pytest.skip('vars folder not found')

    loader = yaml.SafeLoader(open(os.path.join(basedir, 'vars/tagged_tasks.yml')))
    data = loader

# Generated at 2022-06-11 11:04:14.721141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test creation of Tagable object
    class TestTaggable(Taggable):
        pass
    t = TestTaggable()

    # Test with only_tags
    t.tags = ['notag']
    assert t.evaluate_tags(['notag'], [], {})
    t.tags = 'notag'
    assert t.evaluate_tags(['notag'], [], {})
    t.tags = ['notag1', 'notag2']
    assert t.evaluate_tags(['notag1', 'notag2'], [], {})
    t.tags = 'notag1,notag2'
    assert t.evaluate_tags(['notag1', 'notag2'], [], {})

    t.tags = ['notag']

# Generated at 2022-06-11 11:04:25.368674
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTester(Taggable):

        def __init__(self, tags):
            self.tags = tags

    class LoaderDummy:
        pass

    assert TaggableTester(tags=['tag1']).evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == True
    assert TaggableTester(tags=['tag1']).evaluate_tags(only_tags=['tag2'], skip_tags=None, all_vars={}) == False
    assert TaggableTester(tags=['tag1']).evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=None, all_vars={}) == True

# Generated at 2022-06-11 11:04:31.139493
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    a = Taggable()
    a.tags = ['t1', 't2']
    assert a.evaluate_tags(only_tags=['t1'], skip_tags=[], all_vars={}) is True
    assert a.evaluate_tags(only_tags=['t3'], skip_tags=[], all_vars={}) is False
    assert a.evaluate_tags(only_tags=[], skip_tags=['t1'], all_vars={}) is False
    assert a.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) is True
    assert a.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) is True

# Generated at 2022-06-11 11:04:42.874723
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class BaseExample(Taggable):
        def __init__(self, tags=None, always=False, never=False, _loader=None):
            super(BaseExample, self).__init__()
            self.tags = tags
            self.always = always
            self.never = never
            self._loader = _loader
            if self.always:
                if 'always' not in self.tags:
                    self.tags.append('always')
            if self.never:
                if 'never' not in self.tags:
                    self.tags.append('never')

            self.tags = list(sorted(set(self.tags)))

    # Items with tag 'always' must be executed
    be = BaseExample(tags=['always'], _loader=False)

# Generated at 2022-06-11 11:04:52.426774
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # class for mocking super(Taggable,self).__getattribute__(attr)
    class _TaggedCheck:
        tags = ['']
        def __getattribute__(self, attr):
            if attr == 'tags':
                return ['test_tag']
            else:
                raise AttributeError

    # class for mocking super(Taggable,self).__getattribute__(attr)
    class _UntaggedCheck:
        tags = ['']
        def __getattribute__(self, attr):
            if attr == 'tags':
                return []
            else:
                raise AttributeError

    # class for mocking super(Taggable,self).__getattribute__(attr)
    class _NeverTaggedCheck:
        tags = ['']

# Generated at 2022-06-11 11:05:03.250107
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host

    only_tags = ['all', 'test_only_tags']
    skip_tags = ['all', 'test_skip_tags']
    all_vars = {}

    host = Host('test')
    assert host.evaluate_tags(only_tags, skip_tags, all_vars) == True
    host.tags = ['test_only_tags']
    assert host.evaluate_tags(only_tags, skip_tags, all_vars) == True

    host.tags = ['test_skip_tags']
    assert host.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # When both only_tags and skip_tags are defined, skip_tags will be ignored
    host.tags = ['test_skip_tags']

# Generated at 2022-06-11 11:05:13.341316
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    result = Taggable(tags=['tag'], _loader=None, _variable_manager=None).evaluate_tags(
        only_tags=['tag'], skip_tags=[], all_vars=None)
    assert result is True

    result = Taggable(tags=['tag'], _loader=None, _variable_manager=None).evaluate_tags(
        only_tags=['tag'], skip_tags=['tag'], all_vars=None)
    assert result is False

    result = Taggable(tags=['tag1', 'tag2'], _loader=None, _variable_manager=None).evaluate_tags(
        only_tags=['tag1'], skip_tags=[], all_vars=None)
    assert result is True


# Generated at 2022-06-11 11:05:23.199418
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    This function tests different use cases of method
    evaluate_tags of class Taggable.
    '''

    t = Taggable()
    # only_tags and skip_tags conditions for different use cases.

    # Skip the task, because tag 'skip_this' is in 'skip_tags'.
    t.tags = ['skip_this', 'other_tag']
    only_tags = ['untagged', 'all']
    skip_tags = ['skip_this', 'all']
    assert t.evaluate_tags(only_tags, skip_tags, None) == False

    # Run the task, because tag 'skip_this' is not in 'only_tags'
    t.tags = ['skip_this', 'other_tag']
    only_tags = ['untagged', 'all']
    skip_tags = ['all']
   

# Generated at 2022-06-11 11:05:59.574333
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook import Playbook

    #  1) Setup, reference data
    play = Playbook()
    play.TAGS_ROOT = [ "all" ]
    play.TAGS_ALL = [ "all" ]
    play.TAGS_UNTAGGED = [ "untagged" ]
    play.TAGS_TASKS_ALWAYS = [ "always" ]
    play.TAGS_TASKS_NEVER = [ "never" ]

    #  2) Test data
    tag_data = dict(
        all_vars = dict(),
        only_tags = play.TAGS_ROOT,
        skip_tags = None,
        tags = play.TAGS_TASKS_NEVER,
        result = True,
    )

    #  3) Run the test
    t = Tagg

# Generated at 2022-06-11 11:06:09.449985
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    taggable_obj = MyTaggable()

    # default, tasks to run
    assert taggable_obj.evaluate_tags(only_tags=set([]), skip_tags=set([]), all_vars={}) == True

    # run because of always
    assert taggable_obj.evaluate_tags(
        only_tags=set(['foo']), skip_tags=set([]), all_vars={}
        ) == False
    assert taggable_obj.evaluate_tags(
        only_tags=set(['foo']), skip_tags=set([]), all_vars={}
        ) == False
    taggable_obj.tags = ['always']

# Generated at 2022-06-11 11:06:20.826004
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TempTaggable(Taggable):
        pass
    t = TempTaggable()
    t.tags = ['tag_1', 'tag_2', 'tag_3']  # this is a list of tags
    assert t.evaluate_tags(only_tags=['tag_1', 'tag_2'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=[], skip_tags=['tag_3'], all_vars={})
    assert t.evaluate_tags(only_tags=['tag_1'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag_2'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:06:31.377035
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import sys
    import os
    import unittest
    import mock

    sys.modules['yaml'] = mock.Mock()    # just to import module boto
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'plugins', 'action'))
    import ec2_asg

    # Mocking object for object of class Taggable
    t = ec2_asg.ASGActionModule()
    obj = Taggable()

    # 1st test case : Expected Result : should_run = True
    # Only_tags=['test', 'test1'], Skip_tags=['test3'], tags=['test', 'test2', 'test3']
    # Result: should_run = True

# Generated at 2022-06-11 11:06:41.283512
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self):
            self._tags = []
            self.tags = ['tag_one', 'tag_two']

    # test1
    # setup only_tags
    only_tags = frozenset(['tag_one', 'tag_two', 'tag_three'])
    skip_tags = None
    test_class = TestClass()
    assert test_class.evaluate_tags(only_tags, skip_tags, {}) == True, '1st test failed'

    # test2
    # setup only_tags and skip_tags
    only_tags = frozenset(['tag_one', 'tag_two', 'tag_three'])
    skip_tags = frozenset(['tag_two', 'tag_three', 'tag_four'])

# Generated at 2022-06-11 11:06:52.231170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Using class Task as an example of class Taggable
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.template import Templar

    task_ds = dict(
        tags  = ['task_tag1', 'task_tag2']
    )
    # The following variables are obtained from the following ansibleyaml file
    # ---
    # skip_tags:
    #   - skip_tag1
    #   - skip_tag2
    # only_tags:
    #   - only_tag1
    #   - only_tag2

# Generated at 2022-06-11 11:06:57.417638
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ['tag1', 'tag2', 'tag3']

    only_tags = ['tag3', 'tag4']
    skip_tags = ['tag2', 'tag4']

    t.evaluate_tags(only_tags, skip_tags, None) == True
    assert t.evaluate_tags(only_tags, skip_tags, None) == True

# Generated at 2022-06-11 11:07:03.612544
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # This represents a task that is implicitly tagged with 'always'
    class ImplicitTask(Taggable):
        def __init__(self):
            self._tags = []

    # This represents a task that is explicitly tagged
    class ExplicitTask(Taggable):
        def __init__(self, names):
            self._tags = names

    # These tests will run if the task meets the specified on_any/on_all conditions
    # The implicit task should always be run regardless of tag conditions
    # An explicitly tagged task should run only if it has tags mentioned in on_any
    #   and not tags mentioned in on_all

# Generated at 2022-06-11 11:07:13.675095
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play 
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import pytest

    name = 'debug_vars'
    play = Play.load(dict(name=name, hosts=['all'], gather_facts='no'),
                     variable_manager=VariableManager(), loader=None)

    tags_default = TaskInclude.load(dict(
        name=name,
        task=dict(debug=dict(var='tags_default'))
    ), play=play, variable_manager=play.get_variable_manager(), loader=None)


# Generated at 2022-06-11 11:07:24.167065
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from copy import deepcopy
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars

    # Test 1 - default behavior
    ti = TaskInclude()
    ti.tags = ['t1']
    only_tags = ['t1']
    skip_tags = []
    all_vars = {}
    assert ti.evaluate_tags(only_tags, skip_tags, all_vars) == True
    only_tags = []
    skip_tags = ['t1']
    assert ti.evaluate_tags(only_tags, skip_tags, all_vars) == False
    only_tags = []
    skip_tags = []
    assert ti.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-11 11:08:34.330324
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test data
    all_vars = dict(
        name1='tag1',
        my_tag_list=['tag2','tag3','tag4','tag5','tag6']
    )
    only_tags = ['tag1', 'tag2', 'tag4']
    skip_tags = ['tag5', 'tag6']

    # create instance of Taggable
    t = Taggable()
    # set tags to test
    # (1) list with one string
    t.tags = ['tag1']
    # (2) list with two strings
    # t.tags = ['tag2', 'tag3']
    # (3) list with one variable
    # t.tags = ['tag4', '{{name1}}']
    # (4) list with one variable, containing a list of strings
    # t.tags =

# Generated at 2022-06-11 11:08:45.004970
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test case for evaluating tags in a task '''

    class FakePlay(object):
        def __init__(self):
            self.tags = ['role_b']

    class FakeTask(Taggable):
        def __init__(self, name, tags):
            self.name = name
            self.tags = tags
            self.play = FakePlay()

    def _create_test(description, only_tags, skip_tags, task_tags, expected_result):
        task = FakeTask('fake task', task_tags)
        actual_result = task.evaluate_tags(only_tags, skip_tags, dict())
        assert actual_result == expected_result, \
           'Task %s is expected to be %s' % (task.name, expected_result)

    # test logic for parameter 'only_tags'
    _

# Generated at 2022-06-11 11:08:54.915516
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from collections import namedtuple
    PlayContext = namedtuple('PlayContext', ['only_tags'])

    only_tags = ['tagA', 'tagB']
    # only_tags = set(only_tags)
    skip_tags = ['tagD', 'tagE']
    # skip_tags = set(skip_tags)
    task_disjoint = TaskInclude()
    task_disjoint.tags = ['tagC']
    task_disjoint1 = TaskInclude()
    task_disjoint1.tags = ['tagB']
    task_intersect = TaskInclude()
    task_intersect.tags = ['tagA', 'tagB', 'tagC', 'tagD']
    task_intersect1 = TaskInclude()
   

# Generated at 2022-06-11 11:09:06.524675
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Use an simple object to verify unit test
    class _Taggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # "always" is there, it should run
    obj = _Taggable(['always', ])
    assert obj.evaluate_tags(tags['only_tags'], tags['skip_tags'], None)

    # "all" is there, it should run
    obj = _Taggable(['never', ])
    assert obj.evaluate_tags(tags['only_tags'], tags['skip_tags'], None)

    # "all" is there and "never" is there, it should run
    obj = _Taggable(['all', 'never'])
    assert obj.evaluate_tags(tags['only_tags'], tags['skip_tags'], None)

# Generated at 2022-06-11 11:09:16.149910
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class foo(Taggable):
        pass

    obj = foo()
    obj.tags = ['tag1', 'tag2']

    # only_tags, skip_tags, tags, expected result

# Generated at 2022-06-11 11:09:23.821347
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    class fake_class(Taggable):
        pass

    fake_ds = fake_class()

    fake_ds2 = fake_class()
    fake_ds3 = fake_class()
    fake_ds4 = fake_class()

    fake_ds2.tags = ['always']
    fake_ds4.tags = ['never']

    fake_ds5 = fake_class()
    fake_ds6 = fake_class()
    fake_ds

# Generated at 2022-06-11 11:09:34.377054
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # class definition
    class TaggableTest(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None

    # test data
    tag_only_all_no_skip = dict(only_tags=['all'],
                                skip_tags=[],
                                assigned_tags=[],
                                expected_result=True)

    tag_only_all_skip_never = dict(only_tags=['all'],
                                   skip_tags=['never'],
                                   assigned_tags=['never'],
                                   expected_result=False)

    tag_only_all_skip_always = dict(only_tags=['all'],
                                    skip_tags=['always'],
                                    assigned_tags=['always'],
                                    expected_result=False)

   

# Generated at 2022-06-11 11:09:44.741350
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['tag1', 'tag2']

    # Default values of arguments
    assert taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    # Run only tagged items
    assert taggable.evaluate_tags(only_tags=['tagged'], skip_tags=None, all_vars=None)

    # Run if any of the only tags is present
    assert taggable.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars=None)
    assert taggable.evaluate_tags(only_tags=['tag2'], skip_tags=None, all_vars=None)

    # Run if any of the only tags is present and skip if the item has the

# Generated at 2022-06-11 11:09:48.842183
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):

        ansible_loader = None
        _role = None
        _block = None
        _parent = None
        task_include = None
        loop = None
        when = None
        register = None
        ignore_errors = None
        local_action = None
        remote_user = None
        sudo = None
        sudo_user = None
        delegate_to = None
        delegate_facts = None
        _loader = None
        _variable_manager = None
        _task_vars = None
        _templar = None
        _shared_loader_obj = None
        _role_name = None
        _play_name = None
        _task_fields = None

    t = TestTaggable()

    t._tags = []

# Generated at 2022-06-11 11:09:59.993001
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.block import Block

    # test only_tags, skip_tags and tags as lists
    block = Block()
    block.only_tags = ['foo']
    block.skip_tags = ['bar']
    block.tags = ['foo', 'bar']
    assert block.evaluate_tags(block.only_tags, block.skip_tags, dict()) == False

    # test only_tags, skip_tags and tags as strings
    block = Block()
    block.only_tags = 'foo'
    block.skip_tags = 'bar'
    block.tags = 'foo,bar'
    assert block.evaluate_tags(block.only_tags, block.skip_tags, dict()) == False

    # test only_tags and tags as lists, skip_tags None
    block = Block()
    block.only_tags