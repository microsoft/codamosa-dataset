

# Generated at 2022-06-11 11:00:20.282169
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    assert isinstance(Taggable(), Taggable)
    assert isinstance(Taggable(), Block)

    assert Taggable().evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert Taggable(tags=['first', 'second']).evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert Taggable(tags=['first', 'second']).evaluate_tags(only_tags=['first'], skip_tags=[], all_vars={}) == True
    assert Taggable(tags=['first', 'second']).evaluate_tags(only_tags=['third', 'second'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-11 11:00:29.348211
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class FakeVariable(object):
        def __init__(self, key, value):
            self.key = key
            self.value = value

        def __getitem__(self, key):
            return self.value

    class FakeTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = []

    class FakeVars(object):
        def __init__(self):
            self.variables = []

        def add(self, key, value):
            self.variables.append(FakeVariable(key, value))

        def get(self, key, default=None):
            for var in self.variables:
                if key == var.key:
                    return var.value
            return default


# Generated at 2022-06-11 11:00:38.188450
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case 1
    # Expected: Task/Playbooks should run as task/playbook is tagged and not mentioned in skip_tags and is tagged
    #           and mentioned in only_tags
    assert Taggable().evaluate_tags(['compute', 'network'], [], []) == True

    # Test case 2
    # Expected: Task/Playbooks should not run as task/playbook is not tagged
    #           and is mentioned in only_tags
    assert Taggable().evaluate_tags(['storage'], [], []) == False

    # Test case 3
    # Expected: Task/Playbooks should not run as it is tagged and is mentioned in skip_tags.
    assert Taggable().evaluate_tags([], ['network'], []) == False

    # Test case 4
    # Expected: Task/Playbooks should run as task

# Generated at 2022-06-11 11:00:48.469797
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    instance = TestClass()

    instance.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag2']
    skip_tags = []
    all_vars = {}

    assert instance.evaluate_tags(only_tags, skip_tags, all_vars) == True

    instance.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag4']
    skip_tags = []
    all_vars = {}

    assert instance.evaluate_tags(only_tags, skip_tags, all_vars) == False

    instance.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag2', 'tag5']
    skip_tags = []

# Generated at 2022-06-11 11:00:59.545443
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Verify that evaluate_tags returns the correct value
        when only_tags and skip_tags are set
    '''
    t = Taggable()
    t._loader = None
    t._shared_loader_obj = None
    t._role_name = None
    t.tags = None
    t.untagged = Taggable.untagged

    assert t.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=[]) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['foo']) == True

    assert t.evaluate_tags(only_tags=['foo'], skip_tags=['foo']) == False

# Generated at 2022-06-11 11:01:08.408120
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Taggable()
    i = Inventory()
    play_context = PlayContext(
        only_tags = frozenset(['tag1', 'tag2', 'tagged', 'all']),
        skip_tags = frozenset(['tag3', 'tagged']),
        all_vars = dict(),
        inventory = i,
        variables = dict(),
    )
    t.play_context = play_context
    task = Task()
    task.play_context = play_context

    # The attributes `tags` and `when` should be evaluated in case they are templated
    # We check this here by setting their values to something that shouldn't get evaluated
    # and

# Generated at 2022-06-11 11:01:19.317873
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        # pre-fill tags attribute with dummy data
        tags = ['one', 'two']
    # check default behaviour
    only_tags = []
    skip_tags = []
    all_vars = {}
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars)
    # check only_tags
    only_tags = ['one']
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['two']
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['one', 'three']
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:01:29.513813
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # pylint: disable=R0903
    class MockTaggable(Taggable):
        def __init__(self):
            pass

    def equal_to(left, right):
        assert left == right

    m_taggable = MockTaggable()
    m_taggable.tags = ['foo', 'bar']
    equal_to(m_taggable.evaluate_tags(['foo', 'bar', 'baz'], [], {}), True)
    equal_to(m_taggable.evaluate_tags(['baz'], [], {}), False)
    equal_to(m_taggable.evaluate_tags([], [], {}), False)

    m_taggable.tags = []

# Generated at 2022-06-11 11:01:41.246651
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    # Inject the inventory in the module since we are not in a playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context._prompt = None
    play_context.remote_addr = None
    play_context.connection = 'local'

    # Test the simple case: no tags
    only_tags = None
    skip_tags = None
    task = TaskInclude

# Generated at 2022-06-11 11:01:51.537362
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest
    import sys
    import os
    import tempfile
    import shutil

    # Load a fake copy of ansible.parsing.yaml.objects.AnsibleBaseYAMLObject
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
    class AnsibleBaseYAMLObject:
        def __init__(self):
            self._attributes = dict()
        def __setattr__(self, name, value):
            if name in self._attributes:
                attr = self._attributes[name]
                attr.load(self, value)
            else:
                self.__dict__[name] = value
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

# Generated at 2022-06-11 11:02:07.494100
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableClass(Taggable):
        pass

    test_class = TaggableClass()

    # Testing tagged task with only-tags
    test_class._tags    = ['DB', 'APP']
    only_tags           = ['DB']
    skip_tags           = []
    all_vars            = {}
    assert (test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    # Testing tagged task with skip-tags
    test_class._tags    = ['DB', 'APP']
    only_tags           = []
    skip_tags           = ['DB']
    all_vars            = {}
    assert (test_class.evaluate_tags(only_tags, skip_tags, all_vars) == False)

    # Testing tagged task with both skip-tags and only-

# Generated at 2022-06-11 11:02:18.087439
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:02:28.343592
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    my_task = Task()
    my_task.tags = ['a','b','c','d']
    my_task.INTERNAL_CONSTANTS = {'_ANSIBLE_IGNORE_ERRORS': ()}
    # default
    assert my_task.evaluate_tags([],[],{})
    # with only-tags
    assert my_task.evaluate_tags(['a'], [], {})
    # with skip-tags
    assert not my_task.evaluate_tags([], ['b'], {})
    # with only-tags and skip-tags
    assert my_task.evaluate_tags(['a'], ['b'], {})

# Generated at 2022-06-11 11:02:38.899457
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test only_tags, skip_tags and tags
    only_tags = set(['x', 'y', 'all', 'tagged'])
    skip_tags = set(['x', 'y', 'z', 'all'])
    tags = set(['x', 'z'])

    # assert that evaluate_tags returns False when
    # only_tags is defined and both tags and skip_tags are empty
    assert Taggable().evaluate_tags(only_tags=only_tags, skip_tags=[], all_vars={}) == False

    # assert that evaluate_tags returns False when
    # only_tags is defined and tags are not included in only_tags
    assert Taggable().evaluate_tags(only_tags=only_tags, skip_tags=[], all_vars={}, tags=tags) == False

    # assert that evaluate_

# Generated at 2022-06-11 11:02:47.876404
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # The below test calls the evaluate_tags method on an object of type Taggable
    # This object has a list of tags that have been associated with it. The evaluate_tags method
    # takes 2 arguments viz. the only_tags and the skip_tags incase the user has provided any.
    # The evaluate_tags would return true only if the tags associated with it intersect with
    # the tags provided to the method.

    taggable = Taggable()

    taggable.tags = ['one','two','three']

    assert taggable.evaluate_tags(set(['all']), set(), []) == True


if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:02:59.934339
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # test single tags

    fake_play = Play()
    fake_play._loader = None
    fake_task = Task()
    fake_task._loader = None

    # test only tags

    play_vars = dict()
    fake_play.vars = play_vars

    fake_task.tags = ['foo', 'bar']
    should_run = fake_task.evaluate_tags(['foo', 'bar'], [], fake_play.vars)
    assert should_run

    should_run = fake_task.evaluate_tags(['baz'], [], fake_play.vars)
    assert not should_run

    fake_task.tags = []

# Generated at 2022-06-11 11:03:09.383987
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2', 'tag3']


    test_class = TestClass()
    # assertEqual: expected == result
    #assertEqual(test_class.evaluate_tags(only_tags = set(['tag1', 'tag4'])), True)
    #assertEqual(test_class.evaluate_tags(only_tags = set(['tag4'])), False)
    #assertEqual(test_class.evaluate_tags(skip_tags = set(['tag1', 'tag4'])), True)
    #assertEqual(test_class.evaluate_tags(skip_tags = set(['tag1'])), False)
    #assertEqual(test_class.evaluate_tags(skip_tags =

# Generated at 2022-06-11 11:03:20.029600
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags, loader, only_tags=None, skip_tags=None, all_vars=None):
            self._tags = tags
            self._loader = loader
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.all_vars = all_vars

    class MyLoader:
        def get_basedir(self):
            return "/home/user"

    loader = MyLoader()

    tags = ["a", "b", "c"]
    only_tags = ["a", "c"]
    skip_tags = ["b", "d"]
    all_vars = {}

    item = MyTaggable(tags, loader, only_tags, skip_tags, all_vars)


# Generated at 2022-06-11 11:03:30.996652
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class X(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1:
    # skip_tags = ['deprecated']
    # only_tags = [ ]
    # tags = ['deprecated']
    # expect True
    x = X(['deprecated'])
    assert not x.evaluate_tags([], ['deprecated'], {})

    # Test 2:
    # same as test 1, but tags['deprecated'] is not in skip_tags
    # expect True
    x = X(['deprecated'])
    assert x.evaluate_tags([], ['old'], {})

    # Test 3:
    # skip_tags = ['deprecated']
    # only_tags = ['a', 'deprecated']
    # tags = ['deprecated']
    # expect True


# Generated at 2022-06-11 11:03:39.433016
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableClass(Taggable):
        name = 'taggable_class'
        tags = ['tag1']

    taggable_class = TaggableClass()
    tags = taggable_class.tags
    only_tags = ['tag1']
    skip_tags = []
    expected_result = True
    result = taggable_class.evaluate_tags(only_tags, skip_tags, {})
    assert result == expected_result

    only_tags = ['tag3']
    expected_result = False
    result = taggable_class.evaluate_tags(only_tags, skip_tags, {})
    assert result == expected_result

    only_tags = []
    skip_tags = ['tag1']
    expected_result = False

# Generated at 2022-06-11 11:04:04.028411
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.utils

    tags = ['test']
    only_tags = ['all', 'always']
    skip_tags = []

    t = ansible.playbook.Taggable()
    for method in t.__class__.__dict__.keys():
        if method.startswith('_') or method in ['display','dump','evaluate_tags','tags','untagged','set_loader','load_tags','get_loader','get_tags']:
            del t.__dict__[method]
    t.__name__ = 'test'
    t.tags = tags
    t.all_vars = ansible.utils.merge_hash(t._play.vars, t._play.get_vars())

# Generated at 2022-06-11 11:04:04.720512
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-11 11:04:15.963773
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:04:26.384989
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test 1
    t = Taggable()
    t.tags = ['A', 'B']
    assert t.evaluate_tags(only_tags=['A', 'C'], skip_tags=[], all_vars=[]) == True

    # Test 2
    t = Taggable()
    t.tags = ['A', 'B']
    assert t.evaluate_tags(only_tags=['C', 'D'], skip_tags=[], all_vars=[]) == False

    # Test 3
    t = Taggable()
    t.tags = ['A', 'B']
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars=[]) == True

    # Test 4
    t = Taggable()
    t.tags = set(['untagged'])
   

# Generated at 2022-06-11 11:04:28.028203
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    assert t.evaluate_tags(['all'], ['all'], {}) is True

# Generated at 2022-06-11 11:04:39.658700
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a class that inherits from Taggable
    class MyClass(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
    # Setup for the test of the method
    only_tags = frozenset()
    skip_tags = frozenset()
    all_vars = dict()
    # tests for evaluate_tags
    obj = MyClass(tags=None)
    true_or_false = obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(true_or_false == True)
    obj = MyClass(tags=['a', 'b', 'c'])
    true_or_false = obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(true_or_false == True)
   

# Generated at 2022-06-11 11:04:50.385249
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class TestPlay(object):
        play_context = None
        loader = None
        variable_manager = None
        def __init__(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.inventory = InventoryManager(loader=self.loader, sources=['localhost,'])
            self.variable_manager.set_inventory(self.inventory)

# Generated at 2022-06-11 11:05:01.027357
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 1, only_tags has 'all', should_run is True
    only_tags = ['all']
    skip_tags = ['my_tag']
    obj = Taggable()
    all_vars = dict()
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Case 2, only_tags has 'all' and 'never', should_run is False
    only_tags = ['all', 'never']
    skip_tags = ['my_tag']
    obj = Taggable()
    all_vars = dict()
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Case 3, only_tags has 'tagged', should_run is True
    only_tags = ['tagged']

# Generated at 2022-06-11 11:05:11.452934
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = Taggable()
    task.tags = ['foo', 'bar', 'baz']

    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    result = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result == True)

    only_tags = set(['foo'])
    skip_tags = set()
    all_vars = dict()

    result = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result == True)

    only_tags = set(['baz'])
    skip_tags = set()
    all_vars = dict()

    result = task.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:05:21.220607
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest
    import ansible.playbook.task as task

    # == Test function with only_tags ==
    # TEST 1: should_run = True with only_tag = 'tag1' and task.tags = ['tag1']
    t1 = task.Task()
    t1.tags = ['tag1']
    assert t1.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})

    # TEST 2: should_run = True with only_tag = 'tag2' and task.tags = ['tag1', 'tag2']
    t2 = task.Task()
    t2.tags = ['tag1', 'tag2']
    assert t2.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})

    # TEST 3:

# Generated at 2022-06-11 11:05:57.276575
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        print("Evaluating tags")
        only_tags=['docker']
        skip_tags = []

        vars = {}
        vars['ansible_tags'] = ['nginx','container']
        all_vars = dict(vars)
        all_vars['playbook_dir'] = '/root/ansible/playbooks'

        class MyClass(Taggable):
            pass

        myclass = MyClass()

        myclass.tags = ['docker', 'container']
        myclass.evaluate_tags(only_tags, skip_tags, all_vars)
        print("test_Taggable_evaluate_tags passed")
    except:
        print("test_Taggable_evaluate_tags failed")

#test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:06:07.279088
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # skip_tags=['never', 'tagged'], only_tags=['tagged']
    # tags=None
    # tags should be ignored
    should_run = Taggable().evaluate_tags(['tagged'], ['never', 'tagged'], None)
    assert should_run

    # skip_tags=['never'], only_tags=['tagged']
    # tags=['untagged']
    # tags should be ignored
    should_run = Taggable().evaluate_tags(['tagged'], ['never'], None)
    assert not should_run

    # skip_tags=['never'], only_tags=['tagged']
    # tags=['ok', 'ok2']
    should_run = Taggable().evaluate_tags(['tagged'], ['never'], None)
    assert not should_

# Generated at 2022-06-11 11:06:18.383263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test the Taggable class evaluate tags method '''

    tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = ['tag3']
    only_tags_all = ['all']
    skip_tags_all = ['all']
    only_tags_always = ['always']
    skip_tags_always = ['always']
    only_tags_tagged = ['tagged']
    skip_tags_tagged = ['tagged']
    only_tags_never = ['never']
    skip_tags_never = ['never']
    only_tags_all_and_always = ['all', 'always']
    skip_tags_all_and_always = ['all', 'always']
    only_tags_tagged_and_tag1 = ['tagged', 'tag1']
    skip

# Generated at 2022-06-11 11:06:29.480909
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    # Create a task with a template for tags
    class Task(Taggable):
        def __init__(self):
            self.tags = "{{ hostvars['localhost']['tag_var'] }}"

    task = Task()

    # Set a tag variable
    tag_var = "correct_tag"
    all_vars = dict(hostvars=dict(localhost=dict(tag_var=tag_var)))

    # Set a required tag
    only_tags = ['correct_tag']

    # Check if tag was evaluated correctly
    assert task.evaluate_tags(only_tags=only_tags, skip_tags=None, all_vars=all_vars)

    # Change tag variable to wrong value
    tag_var = "incorrect_tag"
   

# Generated at 2022-06-11 11:06:32.970598
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableSub(Taggable):
        pass
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    tags = ['tag1', 'tag2', 'tag3']

    all_vars = dict()

    taggable = TaggableSub()
    taggable._loader = None
    taggable.tags = list(tags)
    assert taggable.evaluate_tags(only_tags = only_tags, skip_tags = skip_tags, all_vars = all_vars) == False

# Generated at 2022-06-11 11:06:43.429570
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    
    import random
    
    my_only_tags = ['tag1', 'tag2', 'tag3']
    my_skip_tags = ['tag4', 'tag5', 'tag6']
    my_all_vars = None

    t = Taggable()
    t._tags  = [ 'tag1', 'tag2']

    assert t.evaluate_tags(my_only_tags, my_skip_tags, my_all_vars) == True
    
    # Remove any tags from self._tags
    nb_of_tags_to_remove = random.randint(1, len(t._tags))
    for i in range(0, nb_of_tags_to_remove):
        index = random.randint(0, len(t._tags)-1)
        del(t._tags[index])


# Generated at 2022-06-11 11:06:54.474125
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    templar = Templar(loader=None, variables={})
    hostvars = templar.template({'hostvars': {'localhost': {}, 'otherhost': {}}})

    # initialize needed objects
    tqm = None
    loader = DataLoader()
    options = None
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-11 11:07:04.100973
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # [1] If a task is configured with tags and one of these tags is part of the
    #     only_tags option, then it should be scheduled for execution
    testcase = [
        # Task Block with tags (list of tags)
        {
            '_task_fields': {'tags': ['tag1']},
            'tags': ['tag1']
        }
    ]

    # Setup only_tags option with a tag part of the task tags
    only_tags = ['tag1']

    # Setup skip_tags option with an empty list
    skip_tags = []

    # Expected result: The task should be scheduled for execution
    expected_result = True

    # Setup all_vars
    all_vars = {}

    # Get the class Taggable
    TaggableClass = type(Taggable)

    # Initialize

# Generated at 2022-06-11 11:07:14.053279
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # Test if skips the task if there are tags missing and no 'all' in only_tags
    # Test if skips the task if 'all' in only_tags and 'never' in tags
    # Test if skips the task if 'tagged' in only_tags and 'never' in tags
    # Test if skips the task if 'never' is in skip_tags
    # Test if skips the task if 'always' is in skip_tags
    # Test if skips the task if 'all' in skip_tags
    # Test if skips the task if 'tagged' in skip_tags and 'never' is not in tags
    # Test if skips the task if 'never' is in tags

# Generated at 2022-06-11 11:07:24.495070
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass
    item = TestTaggable()
    item.tags = ['tag1', 'tag2']
    all_vars = dict()
    assert item.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=['tag3'], all_vars=all_vars)
    assert item.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars=all_vars) == False
    assert item.evaluate_tags(only_tags=['tag2'], skip_tags=['tag1'], all_vars=all_vars)
    assert item.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars=all_vars)

# Generated at 2022-06-11 11:08:34.242116
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    x = Taggable()
    x.tags = ["tag1", "tag2"]
    y = Taggable()
    y.tags = ["tag2", "tag3"]
    z = Taggable()
    z.tags = ["tag3", "always"]
    w = Taggable()
    w.tags = ["never"]
    assert x.evaluate_tags(['tag1', 'tag3'], [], {})
    assert x.evaluate_tags(['tag2'], ['tag1'], {})
    assert not x.evaluate_tags(['tag1', 'tag3'], ['tag2'], {})
    assert not x.evaluate_tags(['tag2'], ['tag1', 'tag3'], {})

# Generated at 2022-06-11 11:08:44.909026
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class _Taggable(Taggable):
        def __init__(self):
            self._loader = None
            self.only_tags = None
            self.skip_tags = None
            self.tags = None
            self.all_vars = None

    from copy import copy

    def dont_run_test(tags, only_tags, skip_tags, all_vars={"hostvars":{}}):
        taggable = _Taggable()
        taggable.tags = copy(tags)
        taggable.only_tags = copy(only_tags)
        taggable.skip_tags = copy(skip_tags)
        taggable.all_vars = copy(all_vars)

# Generated at 2022-06-11 11:08:54.808346
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    class FakeTask(Taggable):
        def __init__(self, loader, variable_manager, name, tags, only_tags, skip_tags):
            self._loader = loader
            self._variable_manager = variable_manager
            self.name = name
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags

    # Setup fake inventory, variable manager, and task
    fake_all_vars = dict(os='Ubuntu', cluster='my_cluster')
    fake_host_vars = dict(cluster='my_other_cluster')

# Generated at 2022-06-11 11:09:06.429453
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize class Taggable
    tclass = Taggable()
    # Setup test data
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']

    # Test case where tag_list and skip_tag are None
    # Expected: return True
    tag_list = None
    skip_tag = None
    expected_result = True
    actual_result = tclass.evaluate_tags(only_tags, skip_tags, tag_list, skip_tag)
    assert expected_result == actual_result

    # Test case where tag_list is set to tag1 and skip_tag is set to tag4
    # Expected: return True
    tag_list = ['tag1']
    skip_tag = ['tag4']
    expected_result = True
    actual_result = t

# Generated at 2022-06-11 11:09:16.101834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    assert t.evaluate_tags(only_tags=['tag1','tag2'], skip_tags=['skip_tag','skip_tag1','skip_tag2'], all_vars=None)

    t.tags = ['always', 'tag1', 'tag2']
    assert t.evaluate_tags(only_tags=['tag1','tag2'], skip_tags=['skip_tag','skip_tag1','skip_tag2'], all_vars=None)

    t.tags = ['always', 'tag3', 'tag4']
    assert not t.evaluate_tags(only_tags=['tag1','tag2'], skip_tags=['skip_tag','skip_tag1','skip_tag2'], all_vars=None)


# Generated at 2022-06-11 11:09:23.795248
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import tempfile
    import shutil
    import os
    import sys

    from ansible import context
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.six.moves import configparser
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.cli.adhoc import AdHocCLI as cli


# Generated at 2022-06-11 11:09:34.314054
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    t.tags = ['test']
    assert t.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={}) is True
    assert t.evaluate_tags(only_tags=['test'], skip_tags=['test'], all_vars={}) is False
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is True
    assert t.evaluate_tags(only_tags=[], skip_tags=['test'], all_vars={}) is True
    assert t.evaluate_tags(only_tags=['other'], skip_tags=[], all_vars={}) is False

# Generated at 2022-06-11 11:09:44.650598
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_dependency import RoleDependency

    all_vars = dict()

    # Test no tags
    p = Play()
    t = Task()
    p.load(dict(
        name="test",
        hosts=["all"],
        gather_facts="no",
        roles=[],
        tasks=[t]
    ))

    assert p.evaluate_

# Generated at 2022-06-11 11:09:45.251912
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-11 11:09:56.688716
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        _tags = []

    # Test 1 - should_run = True
    t = TestTaggable()
    t._tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = ['tag3']
    assert t.evaluate_tags(only_tags, skip_tags, None)

    # Test 2 - should_run = True
    t = TestTaggable()
    t._tags = ['tag1', 'tag2']
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3']
    assert t.evaluate_tags(only_tags, skip_tags, None)

    # Test 3 - should_run = True
    t = TestTaggable()