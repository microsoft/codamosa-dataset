

# Generated at 2022-06-11 11:00:25.157777
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = set()

    # Test 1
    # Setup
    skip_tags = set()
    all_vars = {}
    t = Taggable()
    t.tags = ['all']
    expected_result = True
    # Test

    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    # Verify
    assert result == expected_result

    # Test 2
    # Setup
    skip_tags = set()
    all_vars = {}
    t.tags = set()
    expected_result = False
    # Test

    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    # Verify
    assert result == expected_result

    # Test 3
    # Setup
    skip_tags = set()
    all_vars = {}

# Generated at 2022-06-11 11:00:33.762408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task

    assert Task().evaluate_tags(None, None, None) is True, 'When neither only_tags nor skip_tags, tasks should run'

    assert Task().evaluate_tags(['a'], None, None) is False, 'If a tag other than "always" is specified, tasks should not run'

    assert Task(tags=['always']).evaluate_tags(['a'], None, None) is True, 'When "always" is specified, tasks should run'

    assert Task(tags=['always']).evaluate_tags(['always', 'b'], None, None) is True, 'When "always" is specified, tasks should run'


# Generated at 2022-06-11 11:00:43.393919
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    only_tags = ['all', 'test']
    skip_tags = ['never']
    assert TestClass().evaluate_tags(only_tags, skip_tags,{}) == True
    only_tags = ['other_test']
    skip_tags = ['never']
    assert TestClass().evaluate_tags(only_tags, skip_tags,{}) == False
    only_tags = ['all', 'test']
    skip_tags = ['always']
    assert TestClass().evaluate_tags(only_tags, skip_tags,{}) == False
    only_tags = ['all', 'test']
    skip_tags = ['never']
    class TestClass(Taggable):
        _tags = ['never']
    assert TestClass().evaluate_tags(only_tags, skip_tags,{})

# Generated at 2022-06-11 11:00:53.952596
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    # Simple test with no tags and no filters given
    t1 = Task()
    only_tags = None
    skip_tags = None
    all_vars = {}
    assert t1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Simple test with no tags and only tags filter given
    t2 = Task()
    only_tags = ['role-1']
    skip_tags = None
    all_vars = {}
    assert t2.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Simple test with no tags and

# Generated at 2022-06-11 11:01:04.865274
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    untagged = frozenset(['untagged'])
    class Taggable_temp:
        untagged = untagged
        def __init__(self, tags):
            self.tags = tags
    test_taggable = Taggable_temp([])
    assert(test_taggable.evaluate_tags(['test'], [], {}) == False)
    assert(test_taggable.evaluate_tags(['test'], ['test'], {}) == False)
    assert(test_taggable.evaluate_tags(['test'], ['test'], {}) == False)
    assert(test_taggable.evaluate_tags(['test'], ['test'], {}) == False)
    assert(test_taggable.evaluate_tags(['test'], ['another'], {}) == False)

# Generated at 2022-06-11 11:01:16.131492
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Declare and initialize a dummy class
    class TaggableClass(Taggable):
        pass

    t = TaggableClass()

    # call method evaluate_tags with tags, tags_list and tags_single
    # tags_single and tags_list are both lists.
    # The lists contain string which are tags
    # tags_list contains tags as string separated by commas
    # tags_single contains tags as string separated by commas (ie same as tag_list)
    # tags is a list of tags
    # The method evaluate_tags should return a bool
    should_run = t.evaluate_tags(t.tags,t.tags,t.all_vars)
    assert isinstance(should_run,bool)

    # call method evaluate_tags with tags, tags_list and tags_single
    # tags_single and tags_list

# Generated at 2022-06-11 11:01:26.858254
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def _fix_tags(tags):
        '''Add a str() to every item in the list of tags to make it a string'''
        return [str(tag) for tag in tags]
    
    # Define class for testing
    class TaggableTester(Taggable):
        def __init__(self, only_tags, skip_tags, loader, variables, tags):
            self._loader    = loader
            self.all_vars   = variables
            self.only_tags  = only_tags
            self.skip_tags  = skip_tags
            self.tags       = tags
            self.should_run = None
        
        def test_evaluate(self):
            '''Execute the method evaluate_tags'''

# Generated at 2022-06-11 11:01:35.563066
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # return_value is a list of tuples: [ (test_description, test_data), ... ]
    return_value = []

    # define data used to test the method evaluate_tags of class Taggable
    taggable_object = Taggable()

    # test with simple tags on a taggable object
    taggable_object.tags = ['foo', 'bar']
    only_tags = ['foo']

# Generated at 2022-06-11 11:01:47.977400
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins import module_loader

    setattr(Display, 'verbosity', 4)
    loader = 'ansible.parsing.dataloader.DataLoader'
    variable_manager = VariableManager()

# Generated at 2022-06-11 11:01:56.822217
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import Base
    from ansible.playbook.helpers import load_list_of_blocks

    class Block(Base, Taggable):
        _block: list

    all_vars = dict()

    # Case 1: should_run is True when there is a tag 'always' in the tags, no matter what the value of only_tags is
    # only_tags is None
    blocks = load_list_of_blocks([
        {'name': 'Block_1', 'tags': ['always']},
    ])
    should_run = blocks[0].evaluate_tags(only_tags=None, skip_tags=None, all_vars=all_vars)
    assert should_run is True

    # Case 2: should_run is False when there is a tag 'always' in the tags, no matter

# Generated at 2022-06-11 11:02:14.430573
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    my_dir = os.path.dirname(__file__)
    test_data_dir = os.path.join(my_dir, '../../test/integration/')
    print(test_data_dir)
    sys.path.append(test_data_dir)
    from _ansible_test_data import _ANSIBLE_TEST_DATA
    data = _ANSIBLE_TEST_DATA['taggable'].copy()

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    test_cases = data['taggable_cases']

    for case in test_cases:
        print(case)

# Generated at 2022-06-11 11:02:25.713694
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import ansible.playbook as apb
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    class TaggableTest(Taggable, Block):
        pass

    class TestTask(Task):
        def __init__(self, name, tasklist, block):
            super(TestTask, self).__init__(name, tasklist, block)
            self._role = None
            self._parent = None
            self._role_params = None

    class TestBlock(Block):
        pass

    class TestPlay(apb.Play.Play):
        pass

    test_tags = {True: [], False: ['1']}
    test_tags_dict = {True: [], False: ['1']}

# Generated at 2022-06-11 11:02:37.097783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    import pytest

    class FakeIncludeRole(IncludeRole):
        _allow_duplicates = False

        def load(self, ds, *args):
            self._attributes.update(ds)

    class FakeTask(Task, Taggable):
        pass

    class FakeHandler(Handler, Taggable):
        pass

    test_play_context = PlayContext()
    test_play_context.only_tags = ['all']
    test_play_context.tags = ['all']
    test_play_context.skip_tags = ['never', 'always']

    # test for IncludeRole


# Generated at 2022-06-11 11:02:45.998118
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import copy
    class FakePlay:
        only_tags = []
        skip_tags = []

    class FakeModule:
        def __init__(self, play, tags):
            self.play = play
            self.tags = tags

        def get_name(self):
            return str(self.tags)

    class FakeHost:
        def __init__(self):
            pass

    class FakeTask:
        def __init__(self, play, tags):
            self.play = play
            self.tags = tags
            self._hosts = [FakeHost]

        def get_name(self):
            return str(self.tags)

        def get_vars(self):
            return self.vars

    class FakeBlock:
        def __init__(self, play, tags):
            self.play = play
           

# Generated at 2022-06-11 11:02:57.461505
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Initialize variables for test
    class block:
        name = 'test'

    tags = ['tag1', 'tag2']

    # Initialize Taggable object for test
    testobj = Taggable()
    setattr(testobj, 'tags', tags)

    # Only run tasks tagged with 'tag1' or 'all'
    only_tags = ['tag1', 'all']
    # Skip tasks tagged with 'tag2' or 'never'
    skip_tags = ['tag2', 'never']
    assert testobj.evaluate_tags(only_tags, skip_tags, {}) == True

    # Only run tasks tagged with 'tag2'
    only_tags = ['tag2']
    # Skip tasks tagged with 'tag1' or 'never' or 'all'

# Generated at 2022-06-11 11:03:08.104087
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable():
        __metaclass__ = Taggable
        tags = ["tag1"]

    t = TestTaggable()

    assert t.evaluate_tags(only_tags = None, skip_tags = None, all_vars = None) == True
    assert t.evaluate_tags(only_tags = ["tag2"], skip_tags = None, all_vars = None) == False
    assert t.evaluate_tags(only_tags = ["tag1"], skip_tags = None, all_vars = None) == True
    assert t.evaluate_tags(only_tags = ["tag1", "tag2"], skip_tags = None, all_vars = None) == True

# Generated at 2022-06-11 11:03:18.662639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()

    only_tags = ['test1','test2','test3']
    skip_tags = ['skip1','skip2','skip3']

    # Check when tags is defined as a list
    t.tags = ['test1']
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True
    assert t.evaluate_tags(only_tags, ['skip1','test1'], {}) == False

    # Check when tags is defined as a comma separated string
    t.tags = 'test1,test2,test3'
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True
    assert t.evaluate_tags(only_tags, ['skip1','test1'], {}) == False
    assert t.evaluate_tags

# Generated at 2022-06-11 11:03:29.296515
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """Taggable: test_Taggable_evaluate_tags"""

    class Mock_Play_Context():
        only_tags = None
        skip_tags = None
        extra_vars = None

    class Mock_Taggable(Taggable):
        _play_context = None
        _loader = None

        def __init__(self):
            self._play_context = Mock_Play_Context()

    t = Mock_Taggable()

    #################################################################################
    # Test with only_tags
    #################################################################################

    # Test with only_tags=None
    t.tags = []
    t._play_context.only_tags = None

# Generated at 2022-06-11 11:03:38.407194
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_class = Taggable()
    task_with_tag1 = {'tags': ['tag1']}
    task_with_tag1_and_tagged = {'tags': ['tag1','tagged']}
    task_with_tag2 = {'tags': ['tag2']}
    task_with_tag2_and_tagged = {'tags': ['tag2','tagged']}
    task_with_tag3 = {'tags': ['tag3']}
    task_with_always = {'tags': ['always']}
    task_with_never = {'tags': ['never']}
    task_with_never_and_tagged = {'tags': ['never','tagged']}
    task_untagged = {'tags':[]}

# Generated at 2022-06-11 11:03:47.753210
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  import nose

  # Test case: only_tags: 'always'
  t = Taggable()
  t.tags = ['always']
  t.all_vars =  {}
  nose.tools.assert_equal(True, t.evaluate_tags('always', '', t.all_vars))

  # Test case: only_tags: 'all', tags: ['never']
  t = Taggable()
  t.tags = ['never']
  t.all_vars =  {}
  nose.tools.assert_equal(False, t.evaluate_tags('all', '', t.all_vars))

  # Test case: only_tags: 'all', tags: ['always']
  t = Taggable()
  t.tags = ['always']
  t.all_vars =  {}
  nose.tools

# Generated at 2022-06-11 11:04:13.733878
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class test_class(Taggable):
        pass

    test_obj = test_class()
    test_obj.tags = [u'option_tag_executes']

    if not test_obj.evaluate_tags([], [u'option_tag_executes'], dict()):
        raise ValueError("Taggable.evaluate_tags failed to skip specified tag")
    elif test_obj.evaluate_tags([u'option_tag_executes'], [u'option_tag_executes'], dict()):
        raise ValueError("Taggable.evaluate_tags failed to skip specified tag")
    elif not test_obj.evaluate_tags([u'option_tag_executes'], [], dict()):
        raise ValueError("Taggable.evaluate_tags failed to execute specified tag")

# Generated at 2022-06-11 11:04:21.917405
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.utils
    loader = 'n/a'
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    all_vars = {'hostvars': {'hostname': {'tags': ['tag1', 'tag2', 'tag3']}}}
    t = Taggable()
    t._loader = loader
    t.tags = ['tag1', 'tag2', 'tag3']
    tags = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert tags == True, tags


# Generated at 2022-06-11 11:04:29.881180
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import ansible.playbook
    from ansible.vars import VariableManager
    from ansible.parsing.yaml import from_yaml

    from ansible.module_utils.six import PY3

    if not PY3:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
        unsafe = lambda x: x
    else:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
        unsafe = lambda x: x.encode('utf-8')

    class TestPlay(ansible.playbook.Play):
        pass

    class TestTask(Taggable):
        pass

    t = TestTask()
    p = TestPlay()
    t._play = p
    t._loader = None
    vm = VariableManager()

    # _tag value set as a string
   

# Generated at 2022-06-11 11:04:41.570564
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    global t

    t = Taggable()
    t.tags = ['tag1', 'tag2', 'always']
    assert t.evaluate_tags(only_tags=['tag1', 'tag-does-not-exist'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag3', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:04:51.638498
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True == Taggable.evaluate_tags(None, set(), set(), set())
    assert True == Taggable.evaluate_tags(None, set(), {'tag1'}, set())
    assert True == Taggable.evaluate_tags(None, {'tag1'}, set(), set())
    assert True == Taggable.evaluate_tags(None, {'tag1'}, {'tag1'}, set())
    assert True == Taggable.evaluate_tags(None, set(), {'tag1', 'tag2'}, set())
    assert True == Taggable.evaluate_tags(None, {'tag2'}, {'tag1'}, set())
    assert False == Taggable.evaluate_tags(None, {'!tag1'}, {'tag1'}, set())
    assert True == Taggable.evaluate_tags

# Generated at 2022-06-11 11:05:02.291835
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    host = Host(name='localhost')
    inventory = InventoryManager(loader=None, sources='')
    inventory.add_host(host, 'all')

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    play = Playbook()
    play.set_variable_manager

# Generated at 2022-06-11 11:05:12.517373
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    
    # Test conditions for Task
    def _test_evaluate_tags(should_run, tags, only_tags, skip_tags):
        # Test condition for 'tags' of Task
        task = Task()
        task.tags = tags
        # Test condition for 'only_tags' of Play
        if only_tags is not None:
            task.block.only_tags = set(only_tags)
        else:
            task.block.only_tags = only_tags
        # Test condition for 'skip_tags' of Play
        if skip_tags is not None:
            task.block.skip_tags = set(skip_tags)
        else:
            task.block.skip_tags = skip_tags
        # Test condition for '

# Generated at 2022-06-11 11:05:22.398100
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    only_tags = TestTaggable()
    skip_tags = TestTaggable()

    # Scenario 1 : Test for only_tags and skip_tags both empty
    only_tags.tags = []
    skip_tags.tags = []
    only_tags.tags_ptrn = [""]
    skip_tags.tags_ptrn = [""]
    result = only_tags.evaluate_tags(only_tags.tags_ptrn, skip_tags.tags_ptrn, None)
    assert result == True

    # Scenario 2 : Test for only_tags and skip_tags both is not empty
    only_tags.tags = ["test_tag"]
    skip_tags.tags = ["test_tag"]
    only_tags.tags_ptrn = ["test_tag"]


# Generated at 2022-06-11 11:05:34.251267
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()
    task.tags = ['dev']
    assert task.evaluate_tags(['dev'], [], {})
    assert task.evaluate_tags([], [], {})
    assert task.evaluate_tags(['all'], [], {})
    assert task.evaluate_tags([], ['all'], {})
    assert task.evaluate_tags(['all'], ['prod'], {})
    assert task.evaluate_tags([], ['dev'], {})
    assert task.evaluate_tags(['tagged'], ['dev'], {})
    assert task.evaluate_tags([], ['tagged'], {})
    assert task.evaluate_tags(['prod'], ['dev'], {})

# Generated at 2022-06-11 11:05:41.073887
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Taggable: evaluate tags
    '''
    my_class = Taggable()
    only_tags = {'all', 'notwe', 'we', 'are'}
    skip_tags = {'we', 'are', 'doing', 'it'}

    my_class.tags = ['are']
    my_return = my_class.evaluate_tags(only_tags, skip_tags, None)
    my_expected = False
    assert my_return == my_expected

#    my_class.tags = ['are']
#    my_return = my_class.evaluate_tags(only_tags, skip_tags, None)
#    my_expected = False
#    assert my_return == my_expected

    my_class.tags = ['we', 'are']

# Generated at 2022-06-11 11:06:05.640431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Since the method is messy to test, we use the help of a mock class.
    '''

    class Mock:

        @property
        def tags(self):
            return self._tags

        @tags.setter
        def tags(self, value):
            self._tags = value

        def __init__(self, tags=None):
            self._tags = tags

    class Option:

        def __init__(self, tags=None, untagged=None):
            self._tags = tags
            self.untagged = untagged

        @property
        def tags(self):
            return self._tags

        @tags.setter
        def tags(self, value):
            self._tags = value


# Generated at 2022-06-11 11:06:16.774405
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['common', 'my_tag']
    skip_tags = []
    all_vars = dict()

    # Task without tags
    test_task_1 = Taggable()
    assert test_task_1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Task with empty tags - untagged
    test_task_2 = Taggable()
    test_task_2.tags = []
    assert test_task_2.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Task with tags which is not in only_tags
    test_task_3 = Taggable()
    test_task_3.tags = ['tag1']

# Generated at 2022-06-11 11:06:28.149868
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_obj = Taggable()
    test_obj.tags = ['A', 'B']

    assert test_obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True, 'Tasks should run'

    # tasks should NOT run when skipping 'all' or 'A' or B
    for skip_tag in ['all', 'A', 'B']:
        assert test_obj.evaluate_tags(only_tags=[], skip_tags=[skip_tag], all_vars={}) == False, 'Tasks should not run when skipping %s' % skip_tag

    # tasks should run when only running 'all' or 'A' or B

# Generated at 2022-06-11 11:06:35.646922
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Dist(Taggable):
        pass

    dist = Dist()

    # Test without tags and without only_tags and without skip_tags
    all_vars = dict()
    only_tags = []
    skip_tags = []
    dist.tags = []
    assert dist.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with tags and without only_tags and without skip_tags
    all_vars = dict()
    only_tags = []
    skip_tags = []
    dist.tags = ['tag1', 'tag2']
    assert dist.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with tags and with only_tags and without skip_tags
    all_vars = dict()
    only_tags = ['tag1']
    skip_

# Generated at 2022-06-11 11:06:46.608654
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    my_taggable = MyTaggable()

    # Evaluate tags on a task with no tags.
    my_taggable.tags = None
    assert my_taggable.evaluate_tags(list(),list(),dict()) == True  # Task runs by default

    # My task has tags, let's see what happens
    my_taggable.tags = ["my_tag"]
    # If I specify no only_tags and no skip_tags, the task should run
    assert my_taggable.evaluate_tags(list(),list(),dict()) == True
    # If I use skip_tags, the task should not run
    assert my_taggable.evaluate_tags(list(),["my_tag"],dict()) == False
    # If I use only_tags, the task should

# Generated at 2022-06-11 11:06:57.418749
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags([], [], {'my_only_tags':['one', 'two'], 'my_skip_tags':['three', 'four']})
    assert not Taggable(tags=['five', 'six']).evaluate_tags(['one', 'two', 'three', 'four'], [], {'my_only_tags':['one', 'two'], 'my_skip_tags':['three', 'four']})
    assert not Taggable(tags=['five', 'six']).evaluate_tags(['one', 'two', 'three', 'four'], [], {'my_only_tags':['four', 'one', 'two'], 'my_skip_tags':['three', 'four']})

# Generated at 2022-06-11 11:07:03.612742
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableClass:
        def __init__(self):
            class Obj:
                def __init__(self):
                    self.tags = ['always']
            self.tags = Obj()

    tc = TaggableClass()
    assert True == Taggable.evaluate_tags(tc, ['tagged'], [])
    assert False == Taggable.evaluate_tags(tc, [], ['tagged'])

    tc.tags.tags = ['never']
    assert False == Taggable.evaluate_tags(tc, ['tagged'], [])
    assert True == Taggable.evaluate_tags(tc, [], ['tagged'])

    tc.tags.tags = ['never', 'always']
    assert True == Taggable.evaluate_tags(tc, ['tagged'], [])
    assert False == Taggable

# Generated at 2022-06-11 11:07:13.614161
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def assert_evaluate_tags(self, tag_line, only_tags=None, skip_tags=None):
        only_tags = only_tags or []
        skip_tags = skip_tags or []
        self.tags = tag_line
        v = self.evaluate_tags(only_tags, skip_tags, {})
        return v

    # Mock class to test Taggable's test method
    class MockTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    hostvars = {'inventory_hostname': 'localhost'}

    mt = MockTaggable()

    # tags or not are ok when no --tags or --skip-tags
    assert assert_evaluate_tags(mt, [], [])

# Generated at 2022-06-11 11:07:24.074445
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    from ansible.playbook.role import Role
    from ansible.playbook.dropin import RoleDropIn
    from ansible.playbook.include import Include

    def _t(tags):
        return set(tags) if tags else Taggable.untagged

    def _ts(tags):
        return set(tags) if tags else Taggable.untagged

    # These two should be identical in terms of how tags are handled
    play = Play()
    block = Block()

    play.tags = []
    block.tags = []
    expected = True
    assert play.evaluate_tags([], [], {}) == expected

# Generated at 2022-06-11 11:07:28.997652
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableMock(Taggable):
        def __init__(self, tags, _loader):
            self.tags = tags
            self._loader = _loader

    # Positive cases
    assert(TaggableMock(['tag1'], None).evaluate_tags(['tag1'], [], {}) == True)
    assert(TaggableMock(['tag1'], None).evaluate_tags(['tag2', 'tag1'], [], {}) == True)
    assert(TaggableMock(['tag1', 'tag2'], None).evaluate_tags(['tag1'], [], {}) == True)

    # Negative cases
    assert(TaggableMock(['tag1'], None).evaluate_tags([], [], {}) == False)

# Generated at 2022-06-11 11:08:13.049169
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()

    # test for always
    task.tags = ['always']
    only_tags = ['all', 'tagged']
    skip_tags = ['never']
    assert task.evaluate_tags(only_tags, skip_tags, {}) == True
    only_tags = ['all', 'tagged', 'never']
    assert task.evaluate_tags(only_tags, skip_tags, {}) == False

    # test for untagged
    task.tags = []
    only_tags = ['all', 'tagged']
    assert task.evaluate_tags(only_tags, skip_tags, {}) == True
    only_tags = ['all', 'tagged', 'untagged']
    assert task.evaluate_tags(only_tags, skip_tags, {}) == True


# Generated at 2022-06-11 11:08:22.214329
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block

    task = Base()
    block = Block()
    play = Base()
    play.vars = dict()

    task.tags = ['tag1', 'tag2']

    ####################
    # Check that if 'only_tags' is not an empty list and 'tags' is not empty and
    #   does not contain any of the items in 'only_tags' then the function returns False
    ####################

    # 'only_tags' is a list of strings and 'tags' is a list of strings
    #   one of which is not in 'only_tags'
    task.tags = ['tag1', 'tag2']
    block.only_tags = ['tag3', 'tag4']
    assert task.evaluate_

# Generated at 2022-06-11 11:08:33.302518
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        def __init__(self, tags):
            self.tags = tags

    task = Task([u'foo', u'bar', u'baz'])
    only_tags = [u'foo', u'bar']
    skip_tags = [u'biz', u'buz']
    assert task.evaluate_tags(only_tags, skip_tags, dict()) == True

    only_tags = [u'foo', u'bar']
    skip_tags = [u'baz']
    assert task.evaluate_tags(only_tags, skip_tags, dict()) == False

    only_tags = [u'foo', u'bar']
    skip_tags = [u'biz', u'baz']
    assert task.evaluate_tags(only_tags, skip_tags, dict()) == False

# Generated at 2022-06-11 11:08:44.074052
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test with only
    # Test with only and skip
    # Test with only and skip and tags
    # Test with only and tags
    class FakeTaggable(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2', 'tag3']

    taggable = FakeTaggable()
    assert taggable.evaluate_tags(only_tags = ['tag1'], skip_tags = ['tag3']) == True
    assert taggable.evaluate_tags(only_tags = ['tag1', 'tag2'], skip_tags = ['tag3']) == True
    assert taggable.evaluate_tags(only_tags = ['tag2'], skip_tags = ['tag1', 'tag2']) == False

# Generated at 2022-06-11 11:08:49.751308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags_in_task1 = ["tag1"]
    only_tags = ["tag2"]
    skip_tags = []
    all_vars = None
    taggable = Taggable()
    taggable._tags = tags_in_task1
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False

# Generated at 2022-06-11 11:08:58.041377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task

    class FakeClass:
        tags = ['tag1', 'tag2']

        pass

    fakeobj = FakeClass()
    fakeobj.only_tags = ['tag2', 'tag3']
    fakeobj.skip_tags = ['tag3']

    fakeobj._loader = DataLoader()
    fakeobj._variable_manager = VariableManager()
    fakeobj._inventory = InventoryManager(loader=fakeobj._loader, sources=None, variable_manager=fakeobj._variable_manager)

    # First test
    fakeobj.tags = ['all']
    only_tags = ['tag1']

# Generated at 2022-06-11 11:09:08.960818
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestClass(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # fully tagged test class
    tc = TestClass(['tag1', 'tag2'])

    # the class is never tagged
    assert tc.evaluate_tags(['tagged'], [], {}) is False

    # the class is always tagged
    assert tc.evaluate_tags(['tagged'], ['never'], {}) is True

    # test for empty only_tags
    assert tc.evaluate_tags([], ['never'], {}) is True

    # test for empty skip_tags
    assert tc.evaluate_tags([], [], {}) is True

    # test for empty only_tags and skip_tags
    assert tc.evaluate_tags([], [], {}) is True

    # test for 'tagged' in

# Generated at 2022-06-11 11:09:18.239778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class X(Taggable):
        pass

    x = X()
    x.tags = ['a', 'b']

    assert x.evaluate_tags(None, None, {})
    assert x.evaluate_tags(['a'], None, {})
    assert x.evaluate_tags(None, ['c'], {})
    assert not x.evaluate_tags(['c'], None, {})
    assert not x.evaluate_tags(None, ['a'], {})
    assert not x.evaluate_tags(['c'], ['a'], {})
    assert x.evaluate_tags(['a'], ['c'], {})

    x.tags = ['always']
    assert x.evaluate_tags(['always'], ['never'], {})

# Generated at 2022-06-11 11:09:26.574668
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestModule:
        class TestPlay:
            class TestTask:
                _loader = None
                tags = []
                only_tags = []
                skip_tags = []
                all_vars = {}

        _loader = None
        tags = []
        only_tags = []
        skip_tags = []
        all_vars = {}

    class TestBlock:
        _loader = None
        tags = []
        only_tags = []
        skip_tags = []
        all_vars = {}

    class TestPlay:
        class TestTask:
            _loader = None
            tags = []
            only_tags = []
            skip_tags = []
            all_vars = {}

        _loader = None
        tags = []
        only_tags = []
        skip_tags = []

# Generated at 2022-06-11 11:09:36.613368
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Mock(object):

        def __init__(self):
            self.tags = None
            self._loader = None

    # tests using class attribute "tags"

    t = Mock()
    assert t.evaluate_tags(None, None, {})

    t.tags = ['a', 'b']
    assert t.evaluate_tags(['a'], [], {})
    assert t.evaluate_tags(['a','b'], [], {})
    assert t.evaluate_tags(['a','b','c'], [], {})
    assert not t.evaluate_tags(['c'], [], {})
    assert not t.evaluate_tags([], ['b'], {})
    assert not t.evaluate_tags(['a'], ['b'], {})

    # tests using class attribute "tags" and parameter "only_