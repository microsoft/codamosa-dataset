

# Generated at 2022-06-11 11:00:21.023821
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Important: These tests are NOT exhaustive. Do NOT assume that if these
    # tests pass, then evaluate_tags() works as expected under all conditions.

    # Many objects use Taggable, and some of those objects have their own
    # behavior which may change the behavior of evaluate_tags(). As such, we
    # need a Taggable object with no special behavior.
    class _Taggable(Taggable):
        # Provides set_loader() behavior
        def __init__(self, loader=None):
            self._loader = loader

    # Evaluate_tags() requires self.tags.
    def _test(tags):
        return _Taggable().evaluate_tags(tags, None, None)

    # No special behavior for tags=[] or tags=None
    for tags in [None, []]:
        assert _test(tags)

    #

# Generated at 2022-06-11 11:00:30.129874
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    arg_only_tags = [u'test']
    arg_skip_tags = []
    arg_vars = {'abc': 123}
    test_obj = Taggable()
    assert (test_obj.evaluate_tags(arg_only_tags, arg_skip_tags, arg_vars) == None)
    test_obj.tags = u'test'
    assert (test_obj.evaluate_tags(arg_only_tags, arg_skip_tags, arg_vars) == True)
    test_obj.tags = [u'test', u'always']
    assert (test_obj.evaluate_tags(arg_only_tags, arg_skip_tags, arg_vars) == True)
    test_obj.tags = [u'test', u'never']

# Generated at 2022-06-11 11:00:38.965201
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableTester(Taggable):
        pass

    # Create a TaggableTester object with no tags
    tt = TaggableTester()
    # Try running without any tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True

    # Try running with a tag that isn't present
    assert tt.evaluate_tags(only_tags=['test'], skip_tags=[]) == False

    # Create a TaggableTester object with the tag 'test'
    tt.tags = ['test']

    # Try running with the tag 'test' present
    assert tt.evaluate_tags(only_tags=['test'], skip_tags=[]) == True

    # Try running with the tag 'test' in tag list

# Generated at 2022-06-11 11:00:49.300560
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):

        def __init__(self, tags_list):
            self._tags = tags_list
            self._loader = None
            self._role = None

        def __repr__(self):
            return 'MockTaggable(tags=%s)' % self._tags

    assert MockTaggable(['always']).evaluate_tags({'always'}, None, None)
    assert MockTaggable(['always']).evaluate_tags({'tagged'}, None, None)
    assert MockTaggable(['always','foo']).evaluate_tags({'tagged'}, None, None)
    assert MockTaggable(['never']).evaluate_tags({'never'}, None, None)

# Generated at 2022-06-11 11:01:00.775261
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    item = Taggable()
    item.tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag7','tag8','tag9','tag10']

    # Check if tagged items should run, requires matching tags. Items should run
    assert True == item.evaluate_tags([],['tag2', 'tag4'],{})

    # Check if tagged items should run, requires matching tags. Items should run
    assert True == item.evaluate_tags(['tag1'],['tag4'],{})
    assert True == item.evaluate_tags(['tag3'],['tag4'],{})
    assert True == item.evaluate_tags(['tag5'],['tag4'],{})
    assert True == item.evaluate_tags(['tag7'],['tag4'],{})
    assert True == item

# Generated at 2022-06-11 11:01:08.942537
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task1(Taggable):
        pass

    t1 = Task1()
    # test case 0
    t1.tags = [ 'test1', 'test2', 'test3' ]
    only_tags = [ 'test1', 'test2' ]
    skip_tags = [ 'test3' ]
    all_vars = {}
    assert t1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test case 1
    only_tags = [ 'all' ]
    assert t1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test case 2
    t1.tags = [ 'never' ]
    only_tags = [ 'all' ]

# Generated at 2022-06-11 11:01:19.922751
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest

    class TestTaggable(Taggable):
        # A simple class that we can use to test the Taggable class
        pass

    class TestTaggable_evaluate_tags(unittest.TestCase):

        # Test if evaluate_tags() returns True when only_tags and skip_tags are empty lists
        def test_only_tags_and_skip_tags_are_empty_lists(self):
            taggable = TestTaggable()
            taggable.tags = ['test1', 'test2']
            only_tags = []
            skip_tags = []
            result = taggable.evaluate_tags(only_tags, skip_tags, None)
            self.assertTrue(result)

        # Test if evaluate_tags() returns True when only_tags is empty and

# Generated at 2022-06-11 11:01:29.987552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test to make sure that the evaluate_tags method works
    """
    taggable = Taggable()

    taggable.tags = ['foo', 'bar']
    assert taggable.evaluate_tags(['foo'], [], {}) is False
    assert taggable.evaluate_tags(['foo', 'bar'], [], {}) is True
    assert taggable.evaluate_tags(['foo', 'bar'], ['foo'], {}) is False

    taggable.tags = ['foo', 'bar']
    assert taggable.evaluate_tags([], ['foo'], {}) is False
    assert taggable.evaluate_tags([], ['bar'], {}) is True
    assert taggable.evaluate_tags([], ['foo', 'bar'], {}) is False

    taggable.tags = []

# Generated at 2022-06-11 11:01:41.817513
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import PlaybookInclude
    from ansible.playbook.play_context import PlayContext

    only_tags = ['test_tag']
    skip_tags = []
    all_vars = {}
    tags = ['test_tag']
    play_context = PlayContext()
    pb_include = PlaybookInclude(play_context)

    # Test with "only_tags" contains "test_tag"
    expected = True
    actual = pb_include.evaluate_tags(only_tags, skip_tags, all_vars)
    assert actual == expected

    # Test with "skip_tags" contains "test_tag"
    expected = False
    skip_tags = ['test_tag']
    actual = pb_include.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-11 11:01:52.037660
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test for no tags
    t = Taggable()
    assert t.evaluate_tags(['foo'], [], {}) == True
    assert t.evaluate_tags([], ['foo'], {}) == True
    assert t.evaluate_tags(['foo'], ['foo'], {}) == True
    # test for tags on the object
    t.tags = ['foo']
    assert t.evaluate_tags(['foo'], [], {}) == True
    assert t.evaluate_tags([], ['foo'], {}) == False
    assert t.evaluate_tags(['foo'], ['foo'], {}) == False
    t.tags = ['bar']
    assert t.evaluate_tags(['foo'], ['bar'], {}) == False

# Generated at 2022-06-11 11:02:16.609450
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    import os
    import sys
    import pytest
    import time

    ansible_path = os.path.dirname(os.path.realpath(__file__)) + '/../../'

    src_path = ansible_path + 'lib/ansible/modules/'
    path_list = [ansible_path + 'lib/ansible', ansible_path + 'test/test_utils', src_path]
    for x in path_list:
        sys.path.insert(1, x)
        sys.path.insert(1, os.path.expanduser(x))
        sys.path.append(os.path.expanduser(x))

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import Local

# Generated at 2022-06-11 11:02:17.683314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # so far, not implemented yet.
    pass

# Generated at 2022-06-11 11:02:29.223981
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    from ansible.playbook.role.include import Include

    t = Task()
    i = Include()

    t.tags = ["one","two","three"]
    i.tags = ["four","five","six"]
    all_vars = dict()

    assert t.evaluate_tags("","",all_vars) == True
    assert t.evaluate_tags("","all",all_vars) == False
    assert t.evaluate_tags("always","",all_vars) == True
    assert t.evaluate_tags("always","all",all_vars) == True
    assert t.evaluate_tags("always","all,always",all_vars) == False
    assert t.evaluate_tags("one","",all_vars) == True

# Generated at 2022-06-11 11:02:39.607250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test for method evaluate_tags
    # Testing method evaluate_tags of class Taggable

    class FakeObject(Taggable):
        def __init__(self, tags):
            self.tags = tags

    assert FakeObject(['foo']).evaluate_tags([], [], {'inventory_hostname': 'localhost'})
    assert FakeObject(['foo', 'bar']).evaluate_tags(['bar'], [], {'inventory_hostname': 'localhost'})
    assert not FakeObject(['foo']).evaluate_tags(['bar'], [], {'inventory_hostname': 'localhost'})
    assert FakeObject(['foo', 'bar']).evaluate_tags(['bar', 'foo'], [], {'inventory_hostname': 'localhost'})

# Generated at 2022-06-11 11:02:50.261558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ### setup
    class TestTaggable(Taggable):
        pass
    t = TestTaggable()
    t.tags = []
    all_vars = dict()
    ### all tests
    t.tags = []
    only_tags = []
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['tag']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == False
    t.tags = ['tag']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = []
    only_tags = []
    skip_tags = ['tag']

# Generated at 2022-06-11 11:03:01.890430
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    For evaluating tag options the ``only_tags`` and ``skip_tags`` are passed to the ``Taggable.evaluate_tags()``
    method, example:

        - name: test only tags functionality
          debug: msg="hello world"
          tags:
            - always

        - name: test skip tags functionality
          debug: msg="hello world"
          tags:
            - always

    """
    class MockTask(Taggable):
        pass

    class MockPlayBook(Taggable):
        pass

    class MockRole(Taggable):
        pass

    mock_task = MockTask()
    mock_playbook = MockPlayBook()
    mock_role = MockRole()

    # Unit tests for mock_task

    # Test 1 - only_tags with all and tagged

# Generated at 2022-06-11 11:03:06.288899
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    ti = TaskInclude()
    ti.tags = ['always']
    ti.action = 'fail'

    vm = VariableManager()

    # Only Allow Always tasks
    assert ti.evaluate_tags(only_tags=ti.tags, skip_tags=[], all_vars=vm.get_vars())
    # Run all tasks
    assert ti.evaluate_tags(only_tags=[], skip_tags=[], all_vars=vm.get_vars())
    # Skip Always tasks
    assert not ti.evaluate_tags(only_tags=[], skip_tags=['always'])

    # Only Allow Always tasks and Skip Always tasks: must not run

# Generated at 2022-06-11 11:03:16.189530
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Given an item that has tags, returns True
        that item should run if the only_tags and skip_tags options
        are not specified or if both are specified with an empty value
    '''
    # given
    block = PlaybookBlock(None, None).load({'hosts': 'localhost'})
    item = Taggable().load({'block': block})

    all_vars = {}
    only_tags = None
    skip_tags = None

    # when
    should_run = item.evaluate_tags(only_tags, skip_tags, all_vars)
    # then
    assert should_run == True, \
            "item should run if the only_tags and skip_tags options are not specified"
    # when
    only_tags = []
    skip_tags = []
    # then
    should_run

# Generated at 2022-06-11 11:03:26.445263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Unit test for method evaluate_tags of class Taggable'''

    import ansible.playbook
    import ansible.inventory.host
    import ansible.vars.manager

    h = ansible.inventory.host.Host('testhost')
    v = ansible.vars.manager.VariableManager(loader=None, inventory=None, host_vars=h.vars, play_vars={})

    # always tag
    t = ansible.playbook.Taggable()
    t.tags = ['always']
    assert t.evaluate_tags(['tagged'], [], v)
    assert t.evaluate_tags(['tagged', 'foo'], [], v)
    assert t.evaluate_tags(['tagged', 'never'], [], v)

# Generated at 2022-06-11 11:03:36.570302
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):

        def __init__(self, tags=None):
            self.tags = tags

    test_taggable = TestTaggable(tags=["test_tag"])

    assert(test_taggable.evaluate_tags(only_tags=set(['test_tag']), skip_tags=set([]), all_vars={}) == True)

    assert(test_taggable.evaluate_tags(only_tags=set(['test_tag1']), skip_tags=set([]), all_vars={}) == False)

    assert(test_taggable.evaluate_tags(only_tags=set(['tagged']), skip_tags=set([]), all_vars={}) == False)


# Generated at 2022-06-11 11:04:01.936494
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Tests with only_tags
    only_tags = ['tag1']
    skip_tags = []
    tags = ['tag1']
    vars = {}
    tTagg = TestTaggable()
    tTagg.tags = tags
    assert(tTagg.evaluate_tags(only_tags, skip_tags, vars))

    only_tags = ['tag1']
    skip_tags = []
    tags = ['tag2']
    tTagg.tags = tags
    assert(not tTagg.evaluate_tags(only_tags, skip_tags, vars))

    only_tags = ['tag1']
    skip_tags = []
    tags = ['always']
    tTagg.tags = tags

# Generated at 2022-06-11 11:04:13.264321
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test class for method evaluate_tags of class Taggable
    class Test(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

        def __init__(self, tags):
            self.tags = tags

    test1 = Test(['tag1','tag2','tag3'])
    assert(test1.evaluate_tags(['tag1'], ['tag2'], {}) == True)
    assert(test1.evaluate_tags(['tag2'], ['tag1'], {}) == True)
    assert(test1.evaluate_tags(['tag1'], ['tag1'], {}) == False)
    assert(test1.evaluate_tags(['tag2'], ['tag2'], {}) == False)

# Generated at 2022-06-11 11:04:24.025366
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags, only_tags, skip_tags, all_vars):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.all_vars = all_vars

    t_base = MyTaggable(tags=None,
                        only_tags=None,
                        skip_tags=None,
                        all_vars=dict())

    # assert on the default value for should_run and on the value for the untagged tasks
    assert t_base.evaluate_tags(None, None, None) is True
    assert t_base.evaluate_tags([], '', '') is True
    assert t_base.evaluate_tags([], [], []) is True
    assert t_base

# Generated at 2022-06-11 11:04:27.488574
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ...tests.lib.loader import DsLoader
    from ...tests.lib.testcase import TestCaseBase
    from ...tests.fakes.playbook_taggable import FakeTaggable

    # initialize
    loader = DsLoader()
    tc = TestCaseBase(loader)
    taggable = FakeTaggable()

    # test for run_tags optional param
    all_vars = dict(ansible_tagged_run_tagged=True, ansible_tagged_run_task_with_tag=True, ansible_tagged_run_task_without_tag=True)
    only_tags = None
    skip_tags = None
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-11 11:04:39.071276
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:04:49.986937
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self):
            self.tags = None
            self._loader = None
    fake_taggable = FakeTaggable()

    # test case 1: no tags or only_tags or skip_tags
    fake_taggable.tags = []
    ret = fake_taggable.evaluate_tags(None, None, [])
    assert ret == True

    # test case 2: only have tags, no only_tags or skip_tags
    fake_taggable.tags = ['a','b','c']
    ret = fake_taggable.evaluate_tags(None, None, [])
    assert ret == True

    # test case 3: only have tags, have only_tags, no skip_tags

# Generated at 2022-06-11 11:04:59.393160
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableClass(Taggable):
        def __init__(self):
            self.tags = []

    t = TaggableClass()
    t.tags = ['always', 'never', 'test']
    assert t.evaluate_tags({'always', 'test'}, set(), {})
    assert t.evaluate_tags({'never'}, set(), {}) is False
    assert t.evaluate_tags(set(), {'never'}, {})
    assert t.evaluate_tags(set(), {'always'}, {}) is False
    assert t.evaluate_tags(set(), {'tagged'}, {})
    assert t.evaluate_tags(set(), {'tagged'}, {}) is False

# Generated at 2022-06-11 11:05:09.976939
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    only_tags = ['all', 'untagged', 'tagged', 'always']
    skip_tags = ['all', 'untagged', 'tagged', 'never', 'always']

    # class Taggable is being used as base class for PlaybookInclude
    class PlaybookInclude(Taggable):
        name = "playbook-include"
        tags = ['always']

    # Test for 'always' tag
    obj1 = PlaybookInclude()
    assert obj1.evaluate_tags(only_tags, skip_tags, None) == True
    assert obj1.evaluate_tags(['all'], None, None) == True
    assert obj1.evaluate_tags(None, skip_tags, None) == True
    assert obj1.evaluate_tags(['untagged'], skip_tags, None) == True

# Generated at 2022-06-11 11:05:19.603136
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = []
    skip_tags = []
    all_vars = {}

    taggable = Taggable()
    taggable._loader = None

    # Check the default return value
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(should_run == True)

    # Check only_tags (tags=None)
    only_tags = [ "all" ]
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(should_run == True)

    # Check skip_tags
    skip_tags = [ "all" ]
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:05:30.847408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest

    test_dir = os.path.dirname(os.path.realpath(__file__))
    ansible_dir = os.path.dirname(test_dir)
    sys.path.insert(0, ansible_dir)
    #from ansible.playbook.base import Base
    #from ansible.playbook.attribute import FieldAttribute
    #from ansible.playbook.helpers import load_list_of_blocks

    root_dir = os.getcwd()

    class Taggable(object):
        untagged = frozenset(['untagged'])
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def __init__(self):
            self.tags = None

       

# Generated at 2022-06-11 11:06:09.650782
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    # Create an empty inventory
    inventory = Inventory(loader=None, variable_manager=None, host_list=[])

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Create a play context
    play_context = PlayContext()
    play_context.prompt = dict()

    def _add_vars(var_list):
        for v in var_list:
            variable_manager.set_nonpersistent_facts(v)

    # Create a new instance of Taggable
    taggable = Taggable()

# Generated at 2022-06-11 11:06:20.974197
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    hosts = None
    all_vars = dict()

    # test passing only_tags option to evaluate_tags
    # passing 'all' will ensure passing without any tags
    only_tags = ['all']
    my_taggable = MyTaggable(tags=['red'])
    assert my_taggable.evaluate_tags(only_tags, None, all_vars) == True
    my_taggable_untagged = MyTaggable(tags=['untagged'])
    assert my_taggable_untagged.evaluate_tags(only_tags, None, all_vars) == True


# Generated at 2022-06-11 11:06:31.498196
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    # Test inclusion
    only_tags = ['foo','bar']
    skip_tags = []
    task = Task()
    task.tags = ['foo','bar']
    assert task.evaluate_tags(only_tags, skip_tags, {}) is True
    task.tags = ['bar']
    assert task.evaluate_tags(only_tags, skip_tags, {}) is True
    task.tags = ['foo']
    assert task.evaluate_tags(only_tags, skip_tags, {}) is True
    task.tags = ['foo','bar','baz']
    assert task.evaluate_tags(only_tags, skip_tags, {}) is True

# Generated at 2022-06-11 11:06:41.687789
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # import class Taggable
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # initialize the class Task
    task = Task()
    task.tags = ['test_tag']
    task._loader = 'fake_loader'

    # initialize the class Handler
    handler = Handler()
    handler.tags = ['test_tag']
    handler._loader = 'fake_loader'

    # initialize the class Block
    block = Block()
    block.tags = ['test_tag']
    block._loader = 'fake_loader'

    # test for method evaluate_tags of class Task
    assert (True == task.evaluate_tags({}, {}, {}))
    assert (True == task.evaluate_tags({'test_tag'}, {}, {}))

# Generated at 2022-06-11 11:06:52.628058
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    class Options:
        tags = None
        skip_tags = None
        verbosity = 0
        extra_vars = []

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-11 11:07:02.573155
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyClass(Taggable):
        def __init__(self):
            self.tags = None

    my_obj = DummyClass()

    assert my_obj.evaluate_tags([], [], {}) is True

    my_obj.tags = []
    assert my_obj.evaluate_tags([], [], {}) is True
    assert my_obj.evaluate_tags(['foo'], [], {}) is False
    assert my_obj.evaluate_tags([], ['foo'], {}) is True

    my_obj.tags = ['foo']
    assert my_obj.evaluate_tags([], [], {}) is True
    assert my_obj.evaluate_tags(['foo'], [], {}) is True
    assert my_obj.evaluate_tags(['bar'], [], {}) is False
    assert my_obj

# Generated at 2022-06-11 11:07:08.492244
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test class Taggable evaluate_tags method '''
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    all_vars = dict()

    # Example 1:
    # --solt-tags "always"
    # This should return TRUE
    ############################################################################

    only_tags = set(['always'])
    skip_tags = set()
    tags = set()

    should_run = Taggable().evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run, 'failed to run when required tags are only "always" tags'

    tags = tags.union(['never'])
    should_run = Taggable().evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_

# Generated at 2022-06-11 11:07:19.351771
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock:
        _tags = []
        tags = []
        untagged = frozenset(['untagged'])

    taggable = TaggableMock()
    taggable.tags = ['tag1', 'tag2']

    assert taggable.evaluate_tags(set(['tag1']), [], {})

    assert taggable.evaluate_tags(set(['tag2']), [], {})

    assert taggable.evaluate_tags(set(['tag1', 'tag2']), [], {})

    assert taggable.evaluate_tags(set(['tag1', 'tag2', 'tag3']), [], {})

    assert taggable.evaluate_tags(set(['tag3']), [], {}) is False


# Generated at 2022-06-11 11:07:29.759510
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Import Taggable class, create instance and check
        if it returns expected results.
    '''
    from ansible.playbook.base import Base
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role.include import Include
    from ansible.template import Templar

    # AssertionError if Taggable is not loaded from ansible.playbook.taggable
    assert Taggable
    x = Taggable()

    # The following values must be defined for the xmpl_tt() function
    x.tags = 'tagged'
    all_vars = {'omit': 'a'}

    # AssertionError if method evaluate_tags doesn't exist in Taggable
    assert x.evaluate_tags

    # AssertionError if evaluate_tags() doesn't

# Generated at 2022-06-11 11:07:39.699510
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest

    fake_loader = 'fake_loader'

    class TaggableFake(Taggable):
        _loader = fake_loader

        def __init__(self, tags):
            self.tags = tags

    class TestEvaluateTags(unittest.TestCase):

        def test_with_only_tag(self):

            tags = ['tag1']
            only_tags = ['tag1']
            skip_tags = []

            task = TaggableFake(tags)

            self.assertTrue(task.evaluate_tags(only_tags, skip_tags, {}))

        def test_with_skip_tag(self):

            tags = ['tag1']
            only_tags = None
            skip_tags = ['tag1']

            task = TaggableFake(tags)


# Generated at 2022-06-11 11:08:52.250971
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    t = Taggable()
    t.tags = None

    only_tags = ['only_this_tag']
    skip_tags = []
    all_vars = {}

    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == False
    
    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = []
    
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True
    t.tags = ['tag1', 'tag2', 'tag3']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-11 11:09:02.770970
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from copy import deepcopy
    from ansible.utils.vars import merge_hash

    class MockTaggable(Taggable):
        # This class is just a mock, so keep it simple
        def __init__(self, parent, from_files):
            self._loader = None
            self._parent = parent
            self._from_files = from_files

    def test_case(taggable, opt_tags, only_tags, skip_tags, my_vars, expect_run):
        taggable.tags = opt_tags
        should_run = taggable.evaluate_tags(only_tags, skip_tags, my_vars)
        assert should_run == expect_run


# Generated at 2022-06-11 11:09:13.000685
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest2 as unittest
    tags = ['tag1']

    # First one evaluate_tags without any tags
    class MyTest1(Taggable):
        def __init__(self):
            self.tags = tags

    test1 = MyTest1()
    assert (test1.evaluate_tags(None, None, None) == True)

    # Second test with only run with certain tags
    class MyTest2(Taggable):
        def __init__(self):
            self.tags = tags

    test2 = MyTest2()
    assert (test2.evaluate_tags(['tag1'], None, None) == True)
    assert (test2.evaluate_tags(['tag2'], None, None) == False)

    # Third test with only run with certain tags

# Generated at 2022-06-11 11:09:21.734041
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # NOTE: test data is deliberately inconsistent in list and set formats
    only_tags = ["all"]
    skip_tags = set(["never"])
    all_tags = "all, never" # all_tags is a string

    # NOTE: test data is deliberately inconsistent in list and set formats
    tags_should_run = ["all"]
    tags_should_not_run = set(["never"])

    # Test 1: should_run should be True
    assert taggable.evaluate_tags(only_tags, skip_tags, all_tags) is True

    # Test 2: should_run should be True
    assert taggable.evaluate_tags(only_tags, skip_tags, tags_should_run) is True

    # Test 3: should_run should be False
    assert taggable

# Generated at 2022-06-11 11:09:31.759784
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "lib"))

    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.utils.vars import combine_vars

    # initialize the required class
    playbook = Task()
    role = Role()
    block = Block()
    templar = Templar(loader=None)

    # initialize the vars required for method evaluate_tags
    only_tags = frozenset(['all'])
    skip_tags = frozenset(['first'])
    all

# Generated at 2022-06-11 11:09:42.307756
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #Create objects that can be used as references in the tests
    class module_utils_TestObject(object):
        class Test_class():
            test_var = "variable" #Variable in the loader

            def __init__(self):
                self.tags = list()
                self._loader = module_utils_TestObject()

            def evaluate_tags(self, only_tags, skip_tags, all_vars):
                return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

        def get_basedir(self):
            return "base_dir"

        def path_dwim(self, path):
            return path

        def path_dwim_relative(self, path1, path2, prefix, basedir, intent):
            return path1


# Generated at 2022-06-11 11:09:53.510620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, only_tags, skip_tags, all_vars, tags):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.all_vars = all_vars

    all_vars = dict()
    for only_tags in [None, []]:
        for skip_tags in [None, []]:
            for tags in [['TAG1', 'TAG2'], ['TAG1'], []]:
                args = dict(
                    only_tags=only_tags,
                    skip_tags=skip_tags,
                    all_vars=all_vars,
                    tags=tags,
                )
                test = MyTaggable(**args)
                actual = test.evaluate_

# Generated at 2022-06-11 11:10:04.240407
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook import Play, Playbook
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    class ModuleImport(AnsibleBaseYAMLObject):

        def __init__(self, data=None):
            pass

        class ModuleArgs(object):
            _argspec = {'name': dict()}

        def _load_args(self, attr):
            pass

        def __getstate__(self):
            raise Exception('should not be called')

        def __setstate__(self, d):
            raise Exception('should not be called')

        def serialize(self):
            return dict()
