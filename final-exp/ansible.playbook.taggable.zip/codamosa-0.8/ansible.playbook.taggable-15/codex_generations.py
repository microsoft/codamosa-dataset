

# Generated at 2022-06-11 11:00:27.355632
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    only_tags = ["test1", "test2"]
    skip_tags = ["test2", "test3"]

    templar = Templar(loader=None, variables=None)

    # Case 1: tags => ["test1", "test2"]
    tags = ["test1", "test2"]
    _temp_tags = set()
    for tag in tags:
        _temp_tags.add(tag)
    tags = _temp_tags
    print("tags:", tags)
    print("should run:", Taggable(loader=None).evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=None))
    print("------------------------------")

    # Case 2: tags => "test1, test2"
    tags = "test1, test2"
    # Converts a string to

# Generated at 2022-06-11 11:00:35.902819
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    global_vars = dict()
    # Build a simple tagged playbook
    task1 = dict(
        tags=['tag1', 'tag2']
    )
    task2 = dict(
        tags=['tag1', 'tag3']
    )
    task3 = dict(
        tags='tag2'
    )
    task4 = dict(
        tags=['tag4']
    )
    taggable1 = Taggable()
    taggable2 = Taggable()
    taggable3 = Taggable()
    taggable4 = Taggable()
    taggable1._tag_and_action(task1, loader=None, variable_manager=None, all_vars=global_vars)

# Generated at 2022-06-11 11:00:45.875453
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj_class = Taggable()
    obj_class._loader = None
    all_vars = dict()
    only_tags = ['tag1']
    skip_tags = ['tag2']
    obj_class.tags = ['tag1']
    assert obj_class.evaluate_tags(only_tags, skip_tags, all_vars) == True
    obj_class.tags = ['tag2']
    assert obj_class.evaluate_tags(only_tags, skip_tags, all_vars) == False
    obj_class.tags = ['tag3']
    assert obj_class.evaluate_tags(only_tags, skip_tags, all_vars) == False
    obj_class.tags = []
    assert obj_class.evaluate_tags(only_tags, skip_tags, all_vars) == False
    obj

# Generated at 2022-06-11 11:00:56.686982
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from collections import Mapping
    from ansible.inventory import Inventory

    hostvars = dict(foo=dict(id=42), bar=dict(id=23))
    loader = MockDataLoader({
        'all': dict(hosts=['foo', 'bar'], vars=dict(gid=1)),
        'group1': dict(hosts=['foo', 'bar']),
        'group2': dict(hosts=['foo', 'bar'])
    })
    inventory = Inventory(loader, hostvars=hostvars)

    class MockTask(Taggable):
        pass

    # empty tags
    task = MockTask(tags=[])
    # no filters set

# Generated at 2022-06-11 11:01:02.450367
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.display import Display
    from ansible.utils import plugins
    from ansible.playbook.task import Task

    display = Display()
    t = Task(
        name='foo',
        loader=plugins.module_loader,
        display=display
    )
    t.tags = ['bar']
    t.evaluate_tags('bar', '', dict())

# Generated at 2022-06-11 11:01:13.595688
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    import ansible.playbook.block as block
    mytask = TaskInclude('my include task')
    myblock = block.Block()
    myblock._parent = mytask
    myblock._play = mytask._play
    myblock.all_vars = {
        'env': 'prod',
        'site': 'hq',
        'app' : 'app1',
        'applications': {
            'app1': {'hosts': ['host1', 'host2']}
        }
    }
    yaml = '''
        - name: test1
          hosts: localhost
          tags: ['always']
          tasks: []
        - name: test2
          hosts: localhost
          tasks: []
    '''
    tasks

# Generated at 2022-06-11 11:01:24.430193
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.module_utils.six import StringIO
    from ansible.utils.vars import combine_vars

    class TestTaggable(Taggable):
        _valid_attrs = frozenset(['tags'])

        @staticmethod
        def load(data, loader):
            obj = TestTaggable()
            obj._attributes.update(data)
            obj._loader = loader
            return obj


# Generated at 2022-06-11 11:01:32.701122
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create an instance of Taggable
    tagable = Taggable()
    tagable.tags = []

    # mock up _loader
    class MyLoader(object):
        pass
    tagable._loader = MyLoader()
    
    # mock up all_vars    
    class MyAllVars(object):
        pass
    all_vars = MyAllVars()
    all_vars.tags = None
    
    # Test 1
    # only_tags = None(default) , skip_tags = None(default)
    should = tagable.evaluate_tags(only_tags=None, skip_tags=None, all_vars=all_vars)
    assert should == True

    # Test 2
    # only_tags = ['all'], skip_tags = None(default)
    should = tagable.evaluate

# Generated at 2022-06-11 11:01:45.425819
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible import constants as C

    playbook_vars = dict()
    all_vars = dict(playbook_vars)
    only_tags = list(['core'])
    skip_tags = list(['debug'])

    tagged_case_1 = dict(tags=["core"], name="Tagged case 1")
    tagged_case_2 = dict(tags=["core"], name="Tagged case 2")
    tagged_case_3 = dict(tags=["core"], name="Tagged case 3")
    tagged_case_4 = dict(tags=["core"], name="Tagged case 4")

    untagged_case_1 = dict(tags=["untagged"], name="Untagged case 1")
    untagged_case_2 = dict(tags=["untagged"], name="Untagged case 2")
    untagged_case_

# Generated at 2022-06-11 11:01:54.778170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test default value of tags
    a = Taggable()
    a.tags = []
    assert a.tags == []
    # Test variuous settings
    a.tags = ['aaa']
    assert a.evaluate_tags(only_tags = ['bbb'], skip_tags = [], all_vars = {}) == False
    assert a.evaluate_tags(only_tags = ['bbb'], skip_tags = ['aaa'], all_vars = {}) == False
    assert a.evaluate_tags(only_tags = ['aaa'], skip_tags = [], all_vars = {}) == True
    assert a.evaluate_tags(only_tags = [], skip_tags = [], all_vars = {}) == True

# Generated at 2022-06-11 11:02:19.365540
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Testing the method evaluate_tags of the Taggable class
    '''
    class FakeClass(Taggable):
        '''
        Fake class for the test
        '''
        pass

    test_obj = FakeClass()

    # The base class does not have any tags set.
    assert test_obj.tags == []

    # set the tags
    test_obj.tags = ['never']

    # Check that the tags are set
    assert test_obj.tags == ['never']

    # set the skip_tags and make sure that the task is skipped
    assert test_obj.evaluate_tags(None, ['never'], None) == False

    # Clear the tags
    test_obj.tags = None
    # set the only_tags and make sure that the task is skipped

# Generated at 2022-06-11 11:02:30.837150
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    obj.tags = ['tag1', 'tag2', 'tag3']
    result = obj.evaluate_tags(['tag1', 'tag2'], [], [])
    assert result == True
    result = obj.evaluate_tags(['tag1', 'tag2'], ['tag2'], [])
    assert result == True
    result = obj.evaluate_tags(['tag1', 'tag2'], ['tag4'], [])
    assert result == True
    result = obj.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], [])
    assert result == True
    result = obj.evaluate_tags(['tag1', 'tag2'], ['tag2', 'tag4'], [])
    assert result == True
    result = obj.evaluate_tags

# Generated at 2022-06-11 11:02:40.750913
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    class myTask(Task):
        _allow_async = FieldAttribute(isa='bool', default=False)

    class myRole(Role):
        _allow_async = FieldAttribute(isa='bool', default=False)
    # Use the class myRole instead of the class Role in order to skip the
    # runtime check for the action plugin.

    only_tags = frozenset(['tag1', 'tag2', 'tagged'])
    skip_tags = frozenset(['tag3', 'tag4', 'tagged'])

# Generated at 2022-06-11 11:02:51.528488
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        tags = ['nt']

    # tags = tags.split(',')
    # assert tags == ['nt']

    # tags = _load_tags(tags)
    # assert tags == ['nt']

    # all_vars = dict(tags=['t1', 't2'])
    # tags = evaluate_tags(tags, only_tags=['t1', 't2', 't3'], skip_tags='t4', all_vars=all_vars)
    # assert tags == ['t1', 't2']

    # tags = tags.split(',')
    # assert tags == ['nt']

    # tags = _load_tags(tags)
    # assert tags == ['nt']

    # all_vars = dict(tags=['t1', 't2'])

# Generated at 2022-06-11 11:03:03.335978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

   from ansible.playbook.base import Base

   class ClassTest(Base, Taggable):
       _allow_duplicates = False

   instance = ClassTest()

   # Unit test 1:
   # Tags: 1, 2
   # Only_tags: 1
   # Skip_tags: none
   # Expected: True
   instance.tags = [ 1, 2 ]
   only_tags = [ 1 ]
   skip_tags = []
   all_vars = dict()
   (test1_result) = instance.evaluate_tags(only_tags, skip_tags, all_vars)
   assert test1_result == True

   # Unit test 2:
   # Tags: 1, 2
   # Only_tags: 1, 3
   # Skip_tags: none
   # Expected: False

# Generated at 2022-06-11 11:03:07.603383
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # case 1: only_tags=['all'], skip_tags=[], tags=['always']
    only_tags = ['all']
    skip_tags = []
    t.tags = ['always']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars=None) == True

    # case 2: only_tags=['all'], skip_tags=[], tags=[]
    only_tags = ['all']
    skip_tags = []
    t.tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars=None) == True

    # case 3: only_tags=['all'], skip_tags=[], tags=['never']
    only_tags = ['all']
    skip_tags = []

# Generated at 2022-06-11 11:03:18.098629
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    from ansible.template import Templar

    class Block(Taggable):
        pass

    class Play(Taggable):
        pass

    class Action(Taggable):
        pass

    class Base(Taggable):
        pass

    class Role(Taggable):
        pass

    class RoleTask(Role, Task):
        pass

    assert(Taggable._load_tags(None, 'all, test_tag') == ['all', 'test_tag'])
    assert(Taggable._load_tags(None, 'all, test_tag, other_tag') == ['all', 'test_tag', 'other_tag'])
    assert(Taggable._load_tags(None, 'test_tag') == ['test_tag'])

# Generated at 2022-06-11 11:03:28.435892
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible import constants as C
    import ansible.playbook.base as base
    import ansible.playbook.helpers as helpers

    fake_loader = None

    # Construct base object in order to call method _get_parent_attribute

# Generated at 2022-06-11 11:03:38.011536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test only_tags
    o_t_a = Taggable()
    o_t_b = Taggable()
    o_t_c = Taggable()
    o_t_a.tags = ['foo', 'bar']
    o_t_b.tags = ['foo', 'bar', 'baz']
    o_t_c.tags = []
    assert o_t_a.evaluate_tags(['foo'], [], {}) == True
    assert o_t_a.evaluate_tags('foo', [], {}) == True
    assert o_t_a.evaluate_tags('foo,bar', [], {}) == True
    assert o_t_a.evaluate_tags('bar, baz', [], {}) == False

# Generated at 2022-06-11 11:03:47.494948
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class obj:
        pass

    # default should be True
    x = obj()
    assert(Taggable.evaluate_tags(x, None, None, None) == True)

    # This should be true because the task has no tags
    x.tags=[]
    assert(Taggable.evaluate_tags(x, ['always'], [], None) == True)

    # This should be false because 'never' is a skip tag
    x.tags=['never']
    assert(Taggable.evaluate_tags(x, ['always'], [], None) == False)

    # This should be true because 'always' is a run tag
    x.tags=['always']
    assert(Taggable.evaluate_tags(x, ['always'], [], None) == True)

    # This should be false, because 'always' is

# Generated at 2022-06-11 11:04:13.419026
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #for inheritance
    class TaggableClass:
        def __init__(self):
            self.tags = ['always', 'untagged']

        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

    only_tags = set()
    skip_tags = set()

    # all in skip_tags
    only_tags.add('tagged')
    t = TaggableClass()
    assert t.evaluate_tags(only_tags, skip_tags, None) == True

    skip_tags.add('all')
    assert t.evaluate_tags(only_tags, skip_tags, None) == False
  
    # all in only_tags and all in skip_tags
    only_tags

# Generated at 2022-06-11 11:04:24.177796
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        _loader = None
        def __init__(self):
            self.tags = None

    # Tests with various tag combinations

# Generated at 2022-06-11 11:04:33.740972
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:04:44.485182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    a = Taggable()
    a.tags = ['tag1', 'tag2']
    assert a.evaluate_tags(['tag1'], [], {})
    assert not a.evaluate_tags([], ['tag1', 'tag2'], {})
    assert a.evaluate_tags(['tag1'], ['tag2'], {})
    assert not a.evaluate_tags(['tag3'], [], {})
    assert not a.evaluate_tags(['tag3'], ['tag3'], {})
    assert not a.evaluate_tags(['tag3'], ['tag1', 'tag4'], {})
    assert a.evaluate_tags(['tag1', 'tag4'], ['tag2'], {})


# Generated at 2022-06-11 11:04:53.233569
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' This is testing method evaluate_tags of class Taggable. '''
    import pytest

    # Test case 1
    only_tags = ['test1', 'test2', 'test3']
    skip_tags = ['test4', 'test5', 'test6']
    class TestTags:
        tags = ['test1', 'test2']

    test_tags = TestTags()

    result = test_tags.evaluate_tags(only_tags, skip_tags, None)

    assert result == True

    # Test case 2
    only_tags = ['test2', 'test3', 'test4']
    skip_tags = ['test5', 'test6', 'test7']
    class TestTags:
        tags = ['test1', 'test2']

    test_tags = TestTags()

    result = test_tags.evaluate_

# Generated at 2022-06-11 11:05:04.143371
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    # Raw input data
    only_tags_1 = ['errands', '3', '4']
    only_tags_2 = ['add', '3']
    skip_tags_1 = []
    skip_tags_2 = ['all']
    all_vars_1  = {}
    all_vars_2  = {"string_type": "To be or not to be"}


    # Create a Block to test evaluate_tags method
    block = Block()

    # Test 1: check whether all items will be executed when tags list is empty, only tags list is also empty, skip tags list is empty - New Block
    block.tags = []
    should_run = block.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert should_

# Generated at 2022-06-11 11:05:14.195089
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MyTask(Task):
        pass

    class MyPlay(Play):
        task_class = Task

    play = MyPlay()
    play.hosts = ['localhost']
    play._variable_manager = VariableManager()
    hosts = Inventory(loader=DataLoader(), groups=dict(all=[Host(name="localhost", groups=[])]))
    play = play.set_loader(DataLoader())
    play = play.set_hosts(hosts)

    only_

# Generated at 2022-06-11 11:05:24.337571
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    # Patch for AnsibleModule.exit_json()
    def exit_json(*args, **kwargs):
        return

    # Patch AnsibleModule.run_command()
    def run_command(*args, **kwargs):
        return 0, '', ''

    # Patch AnsibleModule.run_command()
    def fail_json(*args, **kwargs):
        raise SystemExit(1)

    class AnsibleModule():
        def __init__(self, *args, **kwargs):
            self.exit_json = exit_json
            self.run_command = run_command
            self.fail_json = fail_json

    # Mock the inventory, needed for the hosts cache

# Generated at 2022-06-11 11:05:28.460611
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable.evaluate_tags(None, [], []) == False
    assert Taggable.evaluate_tags(None, [], ['untagged']) == True
    assert Taggable.evaluate_tags(None, ['untagged'], ['untagged']) == False

# Generated at 2022-06-11 11:05:38.768286
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = {"sitemap": "http://www.example.com/"}

    # Test with no tags specified
    play = TestTaggable()

    # Test with only_tags specified
    only_tags = set(["all"])
    assert(play.evaluate_tags(only_tags, None, all_vars) == True)

    # Test with skip_tags specified
    skip_tags = set(["tagged"])
    assert(play.evaluate_tags(None, skip_tags, all_vars) == True)

    # Test with only_tags and skip_tags both specified
    only_tags = set(["all"])
    skip_tags = set(["tagged"])
    assert(play.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    # Test with

# Generated at 2022-06-11 11:06:04.527078
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:06:15.351705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    attr = {}
    class MockTaggable(Taggable):
        _tags = attr

    tags = ['tag1', 'tag2']

    attr['value'] = tags
    t = MockTaggable()
    assert t.evaluate_tags(None, None, {}) == True
    assert t.evaluate_tags([], [], {}) == True
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert t.evaluate_tags([], ['tag1'], {}) == True
    assert t.evaluate_tags([], ['tag1', 'tag2'], {}) == True
    assert t.evaluate_tags(['tag1'], ['tag2'], {}) == True

# Generated at 2022-06-11 11:06:26.788109
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class _Taggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
            self._loader = None

    # Test with only-tags argument
    taggable = _Taggable(tags=['tag1', 'tag2'])
    assert taggable.evaluate_tags(['tag1'], [], {})

    taggable = _Taggable(tags=['tag1', 'tag2'])
    assert not taggable.evaluate_tags(['tag3'], [], {})

    taggable = _Taggable(tags=[])
    assert taggable.evaluate_tags(['tagged'], [], {})

    taggable = _Taggable(tags=['tag1'])

# Generated at 2022-06-11 11:06:34.983633
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert True == Taggable().evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    assert True == Taggable().evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})

    assert False == Taggable().evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})

    assert True == Taggable().evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

    assert False == Taggable().evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})


# Generated at 2022-06-11 11:06:45.757526
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    class aTask(Taggable):
        pass
    fake_Task = aTask()

    # Create a fake set of variables
    all_vars = dict(foo=[1,2,3])

    # Method evaluate_tags requires arguments only_tags, skip_tags and all_vars
    # which are lists of tags and a dictionary, respectively.
    # This test case assumes that all_vars is not used in the evaluation.
    # The test case only_tag includes two diffent elements: 'tag1', 'tag2'.
    # The test case skip_tag includes two diffent elements: 'skip_tag1', 'skip_tag2'.
    # The test only_tag always includes element 'always'

    # Case 1: no tags
    fake_Task.tags = None
    only_tags = None


# Generated at 2022-06-11 11:06:56.822324
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy:
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types,), extend=True)
    d = Dummy()
    d.tags = ['a', 'b']
    try:
        d.evaluate_tags(only_tags=['a'], skip_tags =[], all_vars={})
    except Exception as e:
        assert False, e
    try:
        d.evaluate_tags(only_tags=('a', 'a2'), skip_tags =[], all_vars={})
    except Exception as e:
        assert False, e
    try:
        d.evaluate_tags(only_tags=('a', 'a2'), skip_tags =['b'], all_vars={})
    except Exception as e:
        assert False, e

# Generated at 2022-06-11 11:07:03.010497
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = None
    all_vars = dict()

    # initialize the class
    obj = Taggable()
    obj._loader = loader
    obj.tags = ["t1", "t2"]

    # only_tags is specified and task tags is subset of only_tags
    only_tags = set(["t1"])
    skip_tags = set()
    result = obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    # only_tags is specified and task tags is not subset of only_tags
    only_tags = set(["t3"])
    skip_tags = set()
    result = obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False
    
    # skip_tags is specified and task tags is subset of

# Generated at 2022-06-11 11:07:08.812410
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # The test_Taggable_evaluate_tag method tests the method
    # evaluate_tags of the Taggable class.
    #
    # It first creates an instance of class Taggable, to which it
    # assigns a few tags of different types. Then it uses an if
    # statement to check if the method evaluate_tags works
    # correctly. If all the conditions it checks are satisfied, the test
    # method returns True. If not at least one condition fails, it
    # returns False and raises an AssertionError.

    class MyTaggable(Taggable):
        pass

    myTaggable = MyTaggable()
    myTaggable.tags = [1, 2]


# Generated at 2022-06-11 11:07:19.642061
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    import ansible.constants as C
    import ansible.plugins.loader as p
    from ansible.vars.manager import VariableManager
    from six import print_

    class MyPlay(Play):
        def __init__(self, t_tags, only_tags, skip_tags):
            super(MyPlay, self).__init__()
            self._ds = dict(tags=t_tags)
            self.module_vars = dict()
            self.only_tags = frozenset(only_tags)
            self.skip_tags = frozenset(skip_tags)
            self.tags = []

    class MyTaggable(Taggable):
        def __init__(self, tags, only_tags, skip_tags):
            self._ds = dict(tags=tags)

# Generated at 2022-06-11 11:07:29.996567
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import PlayBook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import os

    my_loader = DataLoader()
    my_inventory = Inventory(loader=my_loader, variable_manager=VariableManager(),
                             host_list=['localhost'])

# Generated at 2022-06-11 11:08:18.150282
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    All tests pass when test_Taggable_evaluate_tags() return True
    """
    class FakeTaggable(Taggable):
        def __init__(self, task):
            self.tags = task['tags']

    # test always
    task = { 'tags': ['always'] }
    taggable = FakeTaggable(task)
    assert taggable.evaluate_tags('all', 'never', None)

    task = { 'tags': ['always'] }
    taggable = FakeTaggable(task)
    assert taggable.evaluate_tags(['all'], ['never'], None)

    # test never
    task = { 'tags': ['never'] }
    taggable = FakeTaggable(task)
    assert not taggable.evaluate_tags('all', 'never', None)

# Generated at 2022-06-11 11:08:28.511841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ['tag1', 'tag2']

    # empty only_tags and skip_tags
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # only_tags and skip_tags using only all
    only_tags = ['all']
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    skip_tags = ['all']
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)
    skip_tags = ['always']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    skip_tags = ['never']

# Generated at 2022-06-11 11:08:39.572440
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        tags = [
            'all',
            'never',
            'tagged',
            'not_untagged',
            'foo',
            'bar'
        ]
        def __init__(self):
            pass

    taggable = MockTaggable()

    # Test run all
    assert taggable.evaluate_tags(
        None,
        None,
        {}
    ) == True

    # Test skip all
    assert taggable.evaluate_tags(
        None,
        {
            'all'
        },
        {}
    ) == False

    # Test run only tagged, skip untagged

# Generated at 2022-06-11 11:08:51.068772
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:08:57.832325
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    t = Task.load(dict(name='foo', tags=['tag1', 'tag2', 'tag3']))

    # without any tags specified, task should run
    should_run = t.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    if not should_run:
        raise AssertionError('evaluate_tags returned wrong result, should run')

    # only tag1 specified
    should_run = t.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={})
    if not should_run:
        raise AssertionError('evaluate_tags returned wrong result, should run')

    # skip tag1, should run

# Generated at 2022-06-11 11:09:08.772603
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.playbook.task

    Taggable._tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    Taggable.untagged = frozenset(['untagged'])

    class fake_task(ansible.playbook.task.Task, Taggable):
        pass

    obj = fake_task(play=None)

    assert obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert obj.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={'tags': [ 'tag1' ]})

# Generated at 2022-06-11 11:09:18.070655
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = dict(only_tags=['test'], skip_tags=[], all_vars={})
    assert Taggable().evaluate_tags(**tags) == False

    tags = dict(only_tags=['test'], skip_tags=[], all_vars={}, tags=['test'])
    assert Taggable().evaluate_tags(**tags) == True

    tags = dict(only_tags=['test'], skip_tags=[], all_vars={}, tags=['another_tag'])
    assert Taggable().evaluate_tags(**tags) == False

    tags = dict(only_tags=['test'], skip_tags=['another_tag'], all_vars={}, tags=['another_tag'])
    assert Taggable().evaluate_tags(**tags) == False


# Generated at 2022-06-11 11:09:26.117325
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    test_Taggable_evaluate_tags checks whether the evaluation of tags against only_tags and skip_tags works as it is supposed to
    '''


# Generated at 2022-06-11 11:09:36.250251
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test default behavior, without any tag option
    ansible_options = dict()
    TaggableObj = Taggable()
    TaggableObj.tags = []
    assert TaggableObj.evaluate_tags('', '', ansible_options) # Should be True as default

    # Test one option without any tag
    ansible_options = dict()
    ansible_options['skip_tags'] = 'tag1'
    TaggableObj = Taggable()
    TaggableObj.tags = []
    assert TaggableObj.evaluate_tags('', ansible_options['skip_tags'], ansible_options) # Should be True

    # Test one tagged item with one tagged option
    ansible_options = dict()
    ansible_options['only_tags'] = 'tag1'
    TaggableObj = Taggable

# Generated at 2022-06-11 11:09:46.958714
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(
        tags=['tag0', 'tag1'],
        only_tags=['tag0'],
        skip_tags=['tag1'],
        all_vars=variable_manager._extra_vars
    )
    variable_manager._options_vars = dict(
        tags=['tag2', 'tag3'],
        only_tags=['tag2'],
        skip_tags=['tag3'],
        all_vars=variable_manager._options_vars
    )
