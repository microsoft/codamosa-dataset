

# Generated at 2022-06-11 11:00:26.874782
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.task import Task

    # create a sample task to test evaluate_tags
    sample_task = Task()
    sample_task._attributes = {'tags': Attribute(sample_task, 'tags'),
                               'name': Attribute(sample_task, 'name')}
    sample_task.name = "sample task"
    sample_task._add_attribute_to_class('tags')

    # test cases
    # test case format is:
    # test_Taggable_evaluate_tags:
    # (only_tags, skip_tags, tags, expected results)

# Generated at 2022-06-11 11:00:32.355246
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # SUT
    taggable = Taggable()

    # inputs
    taggable.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag2', 'tag4']
    skip_tags = ['tag3', 'tag5']
    all_vars = {}

    # action
    only_tags_match = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # verification
    assert only_tags_match == True

# Generated at 2022-06-11 11:00:41.386873
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test case for evaluating tags
    """
    test_obj = Taggable()

    only_tags = ['test', 'other']
    skip_tags = ['neverskiptest', 'other', 'secondother']
    all_vars = dict()

    # Test case when tags are present
    test_obj.tags = ['test']
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test case when no tags are present
    test_obj.tags = []
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test case for always tags
    test_obj.tags = ['always']
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test case when

# Generated at 2022-06-11 11:00:52.065569
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    class TaggableClass(Taggable):
        def __init__(self, tags, _loader):
            self.tags = tags
            self._loader = _loader

    only_tags = {'all'}
    skip_tags = set()
    all_vars = dict()
    _loader = object()


# Generated at 2022-06-11 11:01:03.350278
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    obj._loader = None
    # Test with only_tags
    obj.tags = ['foo', 'bar']
    obj.evaluate_tags(['foo', 'bar'], [], {})
    obj.evaluate_tags(['foo', 'bar'], [], {'_run_tags': 'foo, bar'})
    obj.evaluate_tags(['foo', 'bar'], [], {'_run_tags': 'foo, baz'})
    obj.evaluate_tags(['foo', 'bar'], [], {'_run_tags': 'baz, qux'})
    obj.evaluate_tags(['foo', 'bar'], [], {'_run_tags': 'foo, bar, '})

# Generated at 2022-06-11 11:01:15.046843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    t = Task(play=None, ds=None, loader=None)
    assert t.evaluate_tags("all,webservers", "database", None) == True
    assert t.evaluate_tags("all,webservers", "none", None) == True
    assert t.evaluate_tags("all,webservers", "", None) == True
    assert t.evaluate_tags("all,webservers", None, None) == True
    assert t.evaluate_tags("all", "webservers", None) == False
    assert t.evaluate_tags("webservers", "all", None) == True
    assert t.evaluate_tags("webservers", "all,database", None) == True

# Generated at 2022-06-11 11:01:25.864042
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a fake instance of Taggable to unit test
    class FakeTaggable(Taggable):
        def __init__(self):
            self._tags = []
            self._loader = None
            self.tags = []
            self.untagged = frozenset(['untagged'])

    # Test case: creation of an empty FakeTaggable
    fake_taggable = FakeTaggable()
    assert(fake_taggable._tags == [])
    assert(fake_taggable._loader == None)
    assert(fake_taggable.tags == [])
    assert(fake_taggable.untagged == frozenset(['untagged']))

    # Test case: test when no tags are provided
    assert(fake_taggable.evaluate_tags([], [], {}) == True)

# Generated at 2022-06-11 11:01:32.699964
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Response:
        def __init__(self):
            self.skipped = False

    class Task(Taggable):
        def __init__(self):
            self.run = Response()

    # test case: Apply tag to task, task should run
    task = Task()
    task.tags = ['dummy']
    assert(task.evaluate_tags(['dummy'], [], {}))

    # test case: Apply no tag to task, task should run
    task = Task()
    assert(task.evaluate_tags(['dummy'], [], {}))

    # test case: Apply tag to task, skip tag given to block, task should not run
    task = Task()
    task.tags = ['dummy']
    assert(not task.evaluate_tags(['dummy'], ['dummy'], {}))

    #

# Generated at 2022-06-11 11:01:45.425921
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role.include import Include
    from ansible.plugins import module_loader

    task = Include()
    task._loader = module_loader
    task._role = None

    # Scenario 1:
    # only_tags is ["all"], skip_tags is [].
    # tags is not empty.
    # Should return True.
    task.tags = ["t1", "t2"]

    assert task.evaluate_tags(["all"], [], {}) is True

    # Scenario 2:
    # only_tags is ["all"], skip_tags is [].
    # tags is empty.
    # Should return False.
    task.tags = []

    assert task.evaluate_tags(["all"], [], {}) is False

    # Scenario 3:
    # only_tags is ["all"], skip_tags is

# Generated at 2022-06-11 11:01:54.787582
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def _test(tags, only_tags, skip_tags, expected_result):
        Taggable._tags.value(None, tags)
        result = Taggable().evaluate_tags(only_tags, skip_tags, dict())
        if result != expected_result:
            raise Exception('expected %s got %s' % (result, expected_result))
    _test(['a','b','c'], ['b','d'], ['f','g'], True)
    _test([], ['d','e'], ['f','g'], False)
    _test(['a','b'], ['b','d'], ['f','g'], True)
    _test(['b','d'], ['b','d'], ['f','g'], True)

# Generated at 2022-06-11 11:02:18.398820
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestModule:
        def __init__(self, tags=None):
            self.tags = tags

    # Three sub-tests with only_tags options
    module = TestModule(tags=["one"])
    assert Taggable.evaluate_tags(module, only_tags=["all"], skip_tags=None, all_vars=None) == True

    module = TestModule(tags=["two", "three"])
    assert Taggable.evaluate_tags(module, only_tags=["three"], skip_tags=None, all_vars=None) == True

    module = TestModule(tags=["four", "five"])
    assert Taggable.evaluate_tags(module, only_tags=["six"], skip_tags=None, all_vars=None) == False

    # Three sub-tests with skip_tags options

# Generated at 2022-06-11 11:02:29.977505
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test1: only_tags: tag1, tag2, tag3, tagged, always, never
    # tags: tag1, tag2, tag3
    # expected result: True
    class obj1(Taggable):
        def __init__(self):
            self.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tag1', 'tag2', 'tag3', 'tagged', 'always', 'never']
    skip_tags = []
    all_vars = {}
    assert obj1().evaluate_tags(only_tags, skip_tags, all_vars)

    # test2: only_tags: tag1, tag2, tag3, tagged, always, never
    # tags: tag1, tag2, tag3
    # expected result: False

# Generated at 2022-06-11 11:02:40.301564
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = None
    all_vars = dict()
    class fake_Taggable(Taggable):
        _loader = loader
        def __init__(self,tags=None):
            tags_attribute = tags if tags else []
            self.tags = tags_attribute
    instance = fake_Taggable()
    assert instance.evaluate_tags([], [], all_vars) == True
    assert instance.evaluate_tags(['all'], [], all_vars) == True
    assert instance.evaluate_tags([], ['all'], all_vars) == True
    assert instance.evaluate_tags([], ['all', 'never'], all_vars) == False
    assert instance.evaluate_tags([], ['tagged'], all_vars) == True

# Generated at 2022-06-11 11:02:51.053684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    # Test no tags
    obj_Taggable = Taggable()
    obj_Taggable.tags = []
    assert obj_Taggable.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert obj_Taggable.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert obj_Taggable.evaluate_tags(only_tags=['all'], skip_tags=[]) == True

    # Test one tag
    obj_Taggable = Taggable()
    obj_Taggable.tags = ['tag']
    assert obj_Taggable.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert obj_Taggable.evaluate_tags(only_tags=[], skip_tags=['all']) == False


# Generated at 2022-06-11 11:03:02.874650
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.variables import Variable
    from collections import MutableMapping

    test_input = {
        'only_tags': ['tag1', 'tag2'],
        'skip_tags': ['tag3', 'tag4'],
        'tags': ['tag1', 'tag2', 'tag3', 'tag4'],
        'all_vars': {'tag1': 'tag1', 'tag2': 'tag2', 'tag3': 'tag3', 'tag4': 'tag4'},
        'templar': Templar(VariableManager(loader=None, variables=dict())),
        'test_case': True,
    }


# Generated at 2022-06-11 11:03:10.899812
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 'empty only_tags and skip_tags'
    obj = Taggable()
    obj.tags = ['test']
    result = obj.evaluate_tags([], [], {})
    assert (result == True), 'test_Taggable_evaluate_tags 1 failed'

    # Test case 'only_tags is all'
    obj = Taggable()
    obj.tags = []
    result = obj.evaluate_tags(['all'], [], {})
    assert (result == True), 'test_Taggable_evaluate_tags 2 failed'

    # Test case 'only_tags is tagged'
    obj = Taggable()
    obj.tags = ['tagged']
    result = obj.evaluate_tags(['tagged'], [], {})

# Generated at 2022-06-11 11:03:21.634417
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test(Taggable):
        pass

    t = Test()
    t.tags = { 'a', 'b' }
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['a', 'b'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['a', 'b', 'unknown'], skip_tags=['unknown'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['unknown'], skip_tags=['unknown'], all_vars={}) == False

    assert t.evaluate_tags(only_tags=[], skip_tags=['a', 'b'], all_vars={}) == False

# Generated at 2022-06-11 11:03:32.482281
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    
    from ansible.errors import AnsibleError
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar
    from ansible.template import Templar

    class UnitTestClass(Taggable):
        untagged = frozenset(['untagged'])
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
                if isinstance(value, list):
                    return [x.strip() for x in value]
                else:
                    return [ds]
            else:
                raise Ans

# Generated at 2022-06-11 11:03:40.447928
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    o = Taggable()
    o.tags = ['a_tag', 'another_tag', 'and_one_more_tag']

    assert o.evaluate_tags(['any_tag'], [], {}) == True
    assert o.evaluate_tags(['a_tag'], [], {}) == True
    assert o.evaluate_tags(['another_tag'], [], {}) == True
    assert o.evaluate_tags(['and_one_more_tag'], [], {}) == True
    assert o.evaluate_tags(['a_tag', 'another_tag'], [], {}) == True
    assert o.evaluate_tags(['and_one_more_tag', 'another_tag'], [], {}) == True

# Generated at 2022-06-11 11:03:49.822943
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    assert obj.evaluate_tags([], [], {}) == True
    obj.tags = ['a']
    assert obj.evaluate_tags([], [], {}) == True
    assert obj.evaluate_tags(['b'], [], {}) == False
    assert obj.evaluate_tags(['a'], [], {}) == True
    assert obj.evaluate_tags([], ['a'], {}) == False
    assert obj.evaluate_tags(['b'], ['a'], {}) == False
    assert obj.evaluate_tags([], ['a', 'b'], {}) == False
    assert obj.evaluate_tags([], ['b', 'c'], {}) == True
    obj.tags = ['a', 'b', 'c']
    assert obj.evaluate_tags([], [], {}) == True


# Generated at 2022-06-11 11:04:25.458799
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create some mock objects
    class MockAllVars(object):
        pass

    all_vars = MockAllVars()

    # Create an object to test
    t = Taggable()

    # For test_should_run_when_only_tags_is_none_and_skip_tags_is_skip_tags, only_tags is None and skip_tags is skip_tags
    skip_tags = frozenset(['skip_tags'])
    should_run = t.evaluate_tags(None, skip_tags, all_vars)
    assert should_run == True

    # For test_should_run_when_only_tags_is_only_tags_and_skip_tags_is_none, only_tags is only_tags and skip_tags is None

# Generated at 2022-06-11 11:04:36.207256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Define class for test
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = ['tag_1']

    # Test case with list of tags ['tag_1'] and tags to run ['all'] ----
    tt = TestTaggable()
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    result = tt.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result, 'Error in test_Taggable_evaluate_tags for list of tags and tags to run'

    # Test case with list of tags ['tag_1'] and tags to skip ['all'] ----
    tt = TestTaggable()
    only_tags = []
    skip_tags = ['all']
    all_vars

# Generated at 2022-06-11 11:04:47.761976
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ['tagged']
    assert(t.evaluate_tags(only_tags=set(['all']), skip_tags=set([]), all_vars={}) == True)
    assert(t.evaluate_tags(only_tags=set([]), skip_tags=set(['all']), all_vars={}) == True)
    assert(t.evaluate_tags(only_tags=set([]), skip_tags=set(['tagged']), all_vars={}) == False)
    assert(t.evaluate_tags(only_tags=set(['tagged']), skip_tags=set([]), all_vars={}) == True)

# Generated at 2022-06-11 11:04:56.794122
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestClass(Taggable):
        def __init__(self):
            self._tags = []
            self._loader = None
    t = TestClass()
    assert t.evaluate_tags(None, None, None) == True
    # only_tags and skip_tags are empty list
    assert t.evaluate_tags([], [], None) == True
    # skip_tags is empty list
    assert t.evaluate_tags(['foo'], [], None) == False
    # only_tags is empty list
    assert t.evaluate_tags([], ['foo'], None) == True
    # neither tags nor only_tags nor skip_tags is empty list
    assert t.evaluate_tags(['foo'], ['foo'], None) == False
    assert t.evaluate_tags(['foo'], ['bar'], None) == True


# Generated at 2022-06-11 11:05:07.728457
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # Test task with no tags and no tags in options
    taggable.tags = []
    assert taggable.evaluate_tags({}, {}, {}) == True

    # Test task with no tags and only_tags option is set
    taggable.tags = []
    assert taggable.evaluate_tags({'only_tag_1'}, {}, {}) == False

    # Test task with no tags and skip_tags option is set
    taggable.tags = []
    assert taggable.evaluate_tags({}, {'skip_tag_1'}, {}) == False

    # Test task with tags and no tags in options
    taggable.tags = ['tag1', 'tag2']
    assert taggable.evaluate_tags({}, {}, {}) == True

    # Test task with

# Generated at 2022-06-11 11:05:17.316627
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTask(Taggable):
        def get_vars(self):
            return dict(foo="bar")

    fake_task = FakeTask()

    assert fake_task.evaluate_tags(only_tags=["mytag", "notmytag"], skip_tags=[], all_vars=fake_task.get_vars())
    assert not fake_task.evaluate_tags(only_tags=["notmytag"], skip_tags=[], all_vars=fake_task.get_vars())
    assert fake_task.evaluate_tags(only_tags=["all"], skip_tags=[], all_vars=fake_task.get_vars())
    assert not fake_task.evaluate_tags(only_tags=["all"], skip_tags=["mytag"], all_vars=fake_task.get_vars())


# Generated at 2022-06-11 11:05:28.017691
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    task = Taggable()
    task._loader = None
    task.tags = list()

    # test case where only_tags = untagged and task's tag is empty
    only_tags = ['untagged']
    skip_tags = []
    assert task.evaluate_tags(only_tags, skip_tags, dict()) is False

    # test case where only_tags = tagged and task's tag is empty
    only_tags = ['tagged']
    skip_tags = []
    assert task.evaluate_tags(only_tags, skip_tags, dict()) is False

    # test case where only_tags = tagged and task's tag is not empty
    task.tags = ['tag1', 'tag2', 'tag3']
    only_tags = ['tagged']
    skip_tags = []

# Generated at 2022-06-11 11:05:38.522086
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class fake_Taggable(Taggable):
        pass
    # default, tasks to run
    assert fake_Taggable().evaluate_tags(only_tags=[] , skip_tags=[] , all_vars={})

    # 'all' in only_tags
    assert fake_Taggable(tags=[]).evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert fake_Taggable(tags=[]).evaluate_tags(only_tags=['all', 'never'], skip_tags=[], all_vars={})
    assert fake_Taggable(tags=['always']).evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:05:49.147531
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeModule(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None

    # FakeModule.evaluate_tags(only_tags, skip_tags, all_vars)
    # only_tags = ["tag_one", "tag_two"]
    # skip_tags = ["skip_tag_one", "skip_tag_two", "tag_three"]
    # all_vars = {
    #       "tag_one": ["a", "b", "c"],
    #       "tag_two": ["b", "c"],
    #       "tag_three": ["d", "e", "f"],
    #       "skip_tag_one": ["a", "e", "f"]
    # }

    # test case - 1
    fake_module_instance = FakeModule

# Generated at 2022-06-11 11:05:59.063283
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(Taggable):
        tags = []
        def __init(self, vars):
            self._loader = None
            self.vars = vars

    task = Task(dict())
    assert(task.evaluate_tags(['all'], ['never'], dict()) == True)
    assert(task.evaluate_tags(['all'], ['never', 'large'], dict()) == True)
    assert(task.evaluate_tags(['all'], ['never', 'all'], dict()) == False)
    assert(task.evaluate_tags(['all'], ['never', 'tagged'], dict()) == True)
    assert(task.evaluate_tags(['all'], ['never', 'always'], dict()) == True)

# Generated at 2022-06-11 11:06:58.689705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a class containing the method evaluate_tags of Taggable class
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = ['TAG1', 'TAG2']
            pass

    # Create an instance of the TestTaggable class
    test = TestTaggable()

    should_run = test.evaluate_tags(['TAG1'], [], {})
    assert(should_run == True)

    should_run = test.evaluate_tags(['TAG3'], [], {})
    assert(should_run == False)

    should_run = test.evaluate_tags([], ['TAG1'], {})
    assert(should_run == False)

    should_run = test.evaluate_tags([], ['TAG3'], {})
    assert(should_run == True)



# Generated at 2022-06-11 11:07:08.084597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    import os

    play_context = PlayContext()
    play_context._set_task_and_variable_override('foo')
    play_context.only_tags.add('foo')
    play_context.only_tags.add('bar')
    play_context.only_tags.add('aaa')
    play_context.only_tags.add('bbb')

    play_context.skip_tags.add('never')
    play_context.skip_tags.add('skip')
    play_context.skip_tags.add('untagged')
    play_context.skip_tags.add('tagged')

    variable

# Generated at 2022-06-11 11:07:18.895129
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    # Tags set to 'all' both in only and skip tags
    assert Taggable.evaluate_tags(
        None,
        only_tags=['all'],
        skip_tags=['all'],
        all_vars={},
    ) == False

    # Tags set to 'all' in only tags and never in skip tags
    assert Taggable.evaluate_tags(
        None,
        only_tags=['all'],
        skip_tags=['never'],
        all_vars={},
    ) == True

    # Tags set to 'all' in only tags, never in skip tags and always in current tags

# Generated at 2022-06-11 11:07:29.250749
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class A(Taggable):
        _tags = ["foo", "bar", "baz"]
    only_tags = set()
    skip_tags = set()
    all_vars = dict()
    a = A()
    assert a.evaluate_tags(only_tags, skip_tags, all_vars) == True
    only_tags = set(["foo"])
    skip_tags = set()
    all_vars = dict()
    a = A()
    assert a.evaluate_tags(only_tags, skip_tags, all_vars) == True
    only_tags = set(["foo", "bar"])
    skip_tags = set()
    all_vars = dict()
    a = A()
    assert a.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-11 11:07:39.237527
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    task = Task()
    task.tags = []
    assert task.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert not task.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={})
    assert not task.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert task.evaluate_tags(only_tags=['tagged'], skip_tags=['tagged'], all_vars={})
    task.tags = ['all']
    assert task.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={})

# Generated at 2022-06-11 11:07:47.927281
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    class TestClass(Taggable):
        pass

    def test(tags, only_tags, skip_tags, expected):
        result = TestClass()
        result.tags = tags
        result.evaluate_tags(only_tags, skip_tags, {})
        assert result.evaluate_tags(only_tags, skip_tags, {}) == expected

    # Should run, because of 'always' tag
    test(['always'], [], [], True)

    test(['always'], ['nosuchtag'], ['nosuchtag'], True)

    # Should not run, because of 'never' tag
    test(['never'], [], [], False)

    test(['never'], ['nosuchtag'], ['nosuchtag'], False)

    # Should run, because of

# Generated at 2022-06-11 11:07:56.098981
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from unittest import TextTestRunner, TestLoader, TestSuite

    class TaggableTester(Taggable):
        def __init__(self, tags):
            self.tags = tags

    class TestEvaluateTags(unittest.TestCase):
        def testTags(self):
            # here are the tests for the tags function
            # as I copy another test case, I add '_testN' to the end
            # so as to not duplicate test names
            self.assertTrue(TaggableTester([ 'test', 'always' ]).evaluate_tags({'always'}, None, None))
            self.assertTrue(TaggableTester([ 'test', 'always' ]).evaluate_tags({'test'}, None, None))

            # ensure and / or combinations both work

# Generated at 2022-06-11 11:08:07.915472
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test for skip tags
    assert Taggable().evaluate_tags(None, ['always'], None) == False
    assert Taggable().evaluate_tags(None, ['instance'], None) == False      # Only the instance tag
    assert Taggable().evaluate_tags(None, ['instance','ebs','vpc'], None) == False      # Only the instance tag
    assert Taggable().evaluate_tags(None, ['instance','vpc'], None) == False      # Only the instance tag
    assert Taggable().evaluate_tags(None, ['all'], None) == False
    assert Taggable().evaluate_tags(None, ['tagged'], None) == False

    # Test for multiple skip tags
    assert Taggable().evaluate_tags(None, ['tagged','vpc'], None) == False


    # Test for

# Generated at 2022-06-11 11:08:16.869466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class MyTaggable(Taggable):
        def __init__(self, data):
            self._attributes = data

    loader = DataLoader()
    variable_manager = VariableManager()
    variables = variable_manager.get_vars(play=dict(name='foo', play_hosts=['all']))

    data = dict(
        tags=['always','never','b','a'],
        vars=dict(
            tags=[],
        )
    )
    taggable = MyTaggable(data=data)
    taggable._loader = loader
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars=variables) == True
   

# Generated at 2022-06-11 11:08:27.230053
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.block import Block

    def test_tags_are_templated(only_tags, skip_tags, all_vars,
                                tags, result):
        b = Block()
        b.block = []
        b.tags = tags
        b.only_tags = only_tags
        b.skip_tags = skip_tags
        assert b.evaluate_tags(b.only_tags, b.skip_tags, all_vars) == result


    all_vars = dict(
        var1="one",
        var2=dict(
            tag="two"
        ),
        var3=3,
        var4=["four", "four_and_a_half"],
        var5=5,
    )

# Generated at 2022-06-11 11:09:25.805265
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task
    import ansible.template
    import ansible.vars.unsafe_proxy

    t = ansible.playbook.task.Task()
    t.tags = ['tag1']
    t._loader = ansible.template.AnsibleTemplarConfig()
    t._loader.set_available_variables(ansible.vars.unsafe_proxy.UnsafeProxy(dict(var1=1, var2=2)))
    assert t.evaluate_tags(['all'], [], [])
    assert t.evaluate_tags([], ['all'], [])
    assert t.evaluate_tags([], ['all', 'never', 'tag1'], [])
    assert t.evaluate_tags(['all'], ['never', 'tag1'], [])


# Generated at 2022-06-11 11:09:35.929461
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.inventory.host import Host

    # Creation of a parentless Host object
    h = Host(name='host1')

    # Check if the method evaluates tags properly:
    # - if tags are present
    # - if tags are not present
    # - if the tags list is empty
    # - if there are only tags
    # - if there are only negative tags
    # - if there are both positive and negative tags

    h.tags = ['tag1', 'tag2']  # regular tags

    assert h.evaluate_tags(None, None, None) == True

    h.tags = ['tag1', 'tag2']

    assert h.evaluate_tags(['tag1', 'tag2'], None, None) == True

    h.tags = ['tag1', 'tag2']


# Generated at 2022-06-11 11:09:46.551684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # used variables
    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    # test class setup
    test_class = Taggable()
    test_class._loader = None
    test_class.tags = []

    # test without only_tags and skip_tags
    should_run = test_class.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run

    # test with empty only_tags and skip_tags
    only_tags = set([])
    skip_tags = set([])
    should_run = test_class.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run

    # test with empty only_tags and skip_tags
    only_tags = set([])
    skip_tags

# Generated at 2022-06-11 11:09:58.157742
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # This class is for test only since it does not inherit from PlaybookBase
    class DummyTaggable(Taggable):
        def __init__(self):
            pass

    # Create a DummyTaggable object
    obj = DummyTaggable()

    # Parameter only_tags = True
    obj.tags = ['test', 'debug']
    assert obj.evaluate_tags(only_tags=['test'], skip_tags=False, all_vars={}) == True

    # Parameter skip_tags = True
    obj.tags = ['test', 'debug']
    assert obj.evaluate_tags(only_tags=False, skip_tags=['test'], all_vars={}) == False

    # No tags passed
    obj.tags = None

# Generated at 2022-06-11 11:10:07.907671
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTask:

        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    task1 = FakeTask("tag1")
    task2 = FakeTask("tag2")
    task3 = FakeTask("tag3")
    task4 = FakeTask("tag4")

    # when there are no --tags and --skip-tags options
    # tasks should run
    assert(task1.evaluate_tags(set(), set(), None) == True)
    assert(task2.evaluate_tags(set(), set(), None) == True)
    assert(task3.evaluate_tags(set(), set(), None) == True)
    assert(task4.evaluate_tags(set(), set(), None) == True)

    # when only --tags option is present
    # only tasks with matching tags should run