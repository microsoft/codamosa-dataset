

# Generated at 2022-06-11 11:00:19.744057
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = {
        'always'
    }
    only_tags = ['always']
    skip_tags = []

    assert(taggable.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars={}))

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:00:28.859356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook import PlayBook
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    play = PlayBook()

    # test the execute with tags
    play.add_group(Group(name='all'))
    play.add_host(Host(name='localhost'))
    play.add_task(dict(action=dict(module='shell', args='ls'), tags=['shell', 'test'], evaluate_tags=True))
    play.add_task(dict(action=dict(module='shell', args='echo "Task 2" | tee ~/output.txt'), tags=['shell', 'test'], evaluate_tags=True))

# Generated at 2022-06-11 11:00:29.379525
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True

# Generated at 2022-06-11 11:00:38.191699
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = FakeLoader()
    results = Results()

    class Fake(Taggable):
        _loader = loader
        _results = results

    playbook_vars = {
        "all_tags": ["all"],
        "any_tags": ["any", "tagged", "all"],
        "no_tags": ["none"],
        "not_any_tag": ["not", "all", "tagged"],
        "not_all_tags": ["not", "all", "none"],
        "not_any_tags": ["not", "any", "none"],
        "not_no_tags": ["not", "none"],
    }

# Generated at 2022-06-11 11:00:48.458083
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    task_include = TaskInclude()

    task_include._tags = ['always','all','test1','test2','test3','test4','test5']
    task_include.tags = ['test1','test2','test3','test4','test5']
    all_vars = dict()
    only_tags = ['all','test2','test3','test4','test5']

    # check conditions:
    # 1) tags = ['test1','test2','test3','test4','test5']
    # 2) only_tags = ['all','test2','test3','test4','test5']
    assert task_include.evaluate_tags(only_tags, None, all_vars) == True

    task_include.tags = ['test1']
    only

# Generated at 2022-06-11 11:00:59.546080
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play

    class TestClass(Taggable):
        def __init__(self):
            self.tags = []

    tc = TestClass()

    play = Play()

    # Test for scenario when self.tags is empty and only_tags is empty
    result = tc.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert result

    # Test for scenario when self.tags is empty and only_tags is not empty
    result = tc.evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[], all_vars={})
    assert not result

    # Test for scenario when self.tags is not empty and only_tags is empty
    tc.tags = ['tag4', 'tag5']
    result = tc.evaluate_

# Generated at 2022-06-11 11:01:08.408272
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from unit.mock.loader import DictDataLoader
    import json



# Generated at 2022-06-11 11:01:19.317312
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import mock
    t = Taggable()
    t.tags =  mock.Mock(return_value=["1","2"])
    t.untagged = mock.Mock(return_value=["untagged"])
    # tags is not empty, skip tags is not empty, should_run false
    assert t.evaluate_tags(["1","2"],["0","3"],[]) == False
    # tags is not empty, skip tags is not empty, should_run true
    assert t.evaluate_tags(["1","2"],["0","3"],[]) == False
    # tags is not empty, skip tags is empty, should_run true
    assert t.evaluate_tags(["1","2"],[],[]) == True
    # tags is not empty, skip tags is empty, should_run true

# Generated at 2022-06-11 11:01:24.114576
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_obj = Taggable()
    test_obj.tags = ['a', 'b']
    test_obj.only_tags = ['all']
    all_vars = {'test_var': 42}
    assert test_obj.evaluate_tags(test_obj.only_tags, None, all_vars) is True

# Generated at 2022-06-11 11:01:32.620536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
        ''' this checks if the current item should be executed depending on tag options '''

        class TaggableTest(Taggable):
            ''' this class is used for unit testing class Taggable '''
            pass

        tt = TaggableTest()
        tt.tags = ['tag1', 'tag2']

        # Test only_tags and skip_tags
        assert tt.evaluate_tags(['tag1'], [], {}) == True
        assert tt.evaluate_tags(['tag1'], ['tag2'], {}) == True
        assert tt.evaluate_tags(['tag1', 'tag2'], ['tag1'], {}) == False
        assert tt.evaluate_tags(['tag1', 'tag2'], ['tag2'], {}) == False

# Generated at 2022-06-11 11:01:50.194805
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    module = Taggable()
    module.tags = ['test_tag', 'attr']

    # test 1
    play_context = PlayContext(only_tags = ['test_tag'], skip_tags = ['skip_tag'])
    out = module.evaluate_tags(play_context.only_tags, play_context.skip_tags, None)
    assert out

    # test 2
    play_context = PlayContext(only_tags = ['not_tag'], skip_tags = ['not_tag'])
    out = module.evaluate_tags(play_context.only_tags, play_context.skip_tags, None)
    assert not out

    # test 3
    play_context = PlayContext(only_tags = ['attr'], skip_tags = ['attr'])

# Generated at 2022-06-11 11:01:58.284719
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['role_a', 'role_b']

    all_vars = dict()

    only_tags = set(['role_a'])
    skip_tags = set()
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = ['role_c']
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = set()
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = set()
    skip_tags = set(['role_b'])
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = ['role_c']

# Generated at 2022-06-11 11:02:07.449061
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # We need to fake a PlayContext and a VariableManager
    my_play_context = PlayContext()
    my_play_context.only_tags = ['test']
    my_play_context.skip_tags = ['notest']

    my_variable_manager = VariableManager(loader=None, inventory=None)

    class MyClass(Taggable):
        pass

    my_class = MyClass()


    # defaults
    my_class.tags = None
    assert my_class.evaluate_tags(my_play_context.only_tags, my_play_context.skip_tags, my_variable_manager.get_vars(my_play_context, None)) == True

    # specify tags
    my_

# Generated at 2022-06-11 11:02:18.034187
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test that tags on a particular object can be run or skipped as expected.
    """
    import ansible
    from ansible.modules.packaging.os import apt
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Construct a fake task
    fake_task = Task(dict(action=dict(module='apt', args=dict(name='test-package'))))
    fake_task._initialize_attributes()

    expected_results = []

    # Only tagged with 'always' should always run
    fake_task.tags = ['always']
    only_tags = []
    skip_tags = []
    fake_task.when = Conditional('True')
    expected_results.append(True)

    # Only tagged with 'never

# Generated at 2022-06-11 11:02:29.604889
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import os
    import json
    import tempfile

    sys.path.append(os.path.abspath("../test"))

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from .utils import AnsibleExitJson, AnsibleFailJson

    from units.mock.loader import DictDataLoader
    from units.compat import unittest
    from  units.mock.path import mock_unfrackpath_noop

    # These variables are used to mock the input parameters for unit testing
    attr = None
    only_tags = set(['always'])
    skip_tags = set(['never'])
    all_vars = {}
    tags = None

    # Mock the Ansible Module class

# Generated at 2022-06-11 11:02:39.940414
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  from ansible.inventory import Inventory
  from ansible.vars import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.task import Task
  from ansible.executor.playbook_executor import PlaybookExecutor

  loader = DataLoader()
  variable_manager = VariableManager()
  inventory = Inventory(loader=loader, variable_manager=variable_manager)
  playbook = PlaybookExecutor(
      playbooks=['./tests/playbooks/tags_playbook_example.yml'],
      inventory=inventory,
      variable_manager=variable_manager,
      loader=loader,
      options=None,
      passwords={}
  )
  playbook.run()


# Generated at 2022-06-11 11:02:50.692341
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def make_mock_taggable(tags=None):
        mock_taggable = Taggable()
        mock_taggable._loader = type('LoaderMock', (), {'get_basedir': lambda s: ''})()
        if tags:
            mock_taggable.tags = tags
        return mock_taggable

    # Test on normal tags
    tag1 = 'normal'
    tag2 = 'normal2'

    mock_taggable = make_mock_taggable([tag1])
    assert mock_taggable.evaluate_tags(only_tags=[tag2], skip_tags=[])
    assert not mock_taggable.evaluate_tags(only_tags=[tag1], skip_tags=[])

# Generated at 2022-06-11 11:03:02.394489
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.template import Templar

    tags = ['tag1', 'tag2', 'tag3']
    vars = {}
    loader = None
    variable_manager = VariableManager(loader=loader, variables=vars)

    # Setup my_task and templar
    my_task = Task()
    my_task.tags = tags
    my_task._variable_manager = variable_manager

    my_task.tags = tags
    templar = Templar(loader=loader, variables=vars)

    # only_tags = ['tag1', 'tag2', 'tag3']
    # only_tags = ['tag2', 'tag3']
    only_tags = ['tag3']
    skip_tags = []

    # (t

# Generated at 2022-06-11 11:03:06.816267
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole


# Generated at 2022-06-11 11:03:16.865327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    untagged = frozenset(['untagged'])
    all_vars = dict()

    # Evaluating a task without tags
    test_task = dict()
    test_task['tags'] = []
    test_task['when'] = '1 == 1'
    test_task = Taggable()
    test_task._load_tags = Taggable._load_tags # monkey patch
    test_task.tags = test_task._load_tags(None, test_task['tags'])
    #
    # Run with no tags, should pass (True)
    #
    assert test_task.evaluate_tags(set(), set(), all_vars) == True
    #
    # Run with no tags but skip 'tagged', should pass (True)
    #

# Generated at 2022-06-11 11:03:38.613064
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestTaggable(Taggable):
        pass

    yield from pytest.importorskip("paramiko")
    class AnsibleOptions(object):
        # options for test
        verbosity = None
        connection = 'smart'
        module_path = None
        forks = 5
        remote_user = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
       

# Generated at 2022-06-11 11:03:47.968221
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._loader = object()
    taggable.tags = ["A","B"]
    only_tags = ["B","C"]
    skip_tags = ["C","D"]

    all_vars={}
    assert taggable.evaluate_tags(only_tags, skip_tags,all_vars)

    taggable.tags = ["C","D"]
    assert not taggable.evaluate_tags(only_tags, skip_tags,all_vars)

    only_tags.extend(["B","C"])
    assert taggable.evaluate_tags(only_tags, skip_tags,all_vars)

    skip_tags.extend(["B","C"])

# Generated at 2022-06-11 11:03:58.605090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = dict()
    only_tags = set(['all'])
    skip_tags = set()

    fake_task = Taggable()
    fake_task.tags = ['all']
    assert(fake_task.evaluate_tags(only_tags, skip_tags, all_vars))

    fake_task.tags = ['never']
    assert(not fake_task.evaluate_tags(only_tags, skip_tags, all_vars))

    fake_task.tags = ['tagged']
    assert(fake_task.evaluate_tags(only_tags, skip_tags, all_vars))

    skip_tags = set(['all'])
    assert(not fake_task.evaluate_tags(only_tags, skip_tags, all_vars))


# Generated at 2022-06-11 11:04:09.756296
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['a', 'always']
    assert t.evaluate_tags(['a', 'never'], [], {}), 'Error in Taggable.evaluate_tags() method, test_Taggable_evaluate_tags() #1'
    assert t.evaluate_tags(['a', 'never'], [], {}), 'Error in Taggable.evaluate_tags() method, test_Taggable_evaluate_tags() #2'
    assert t.evaluate_tags(['a', 'all', 'tagged'], [], {}), 'Error in Taggable.evaluate_tags() method, test_Taggable_evaluate_tags() #3'

# Generated at 2022-06-11 11:04:20.449412
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy(Taggable):
        def __init__(self, tags):
            self._tags = tags
            self._loader = None
    obj = Dummy(tags=["t1", "t2"])
    # Positive test with only tags
    ret_value = obj.evaluate_tags(only_tags=set(["t1", "t2"]), skip_tags=set(), all_vars={})
    assert ret_value == True
    # Positive test with only tags
    ret_value = obj.evaluate_tags(only_tags=set(["always"]), skip_tags=set(), all_vars={})
    assert ret_value == True
    # Positive test with only tags

# Generated at 2022-06-11 11:04:29.188335
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    This is a unit test for the Taggable.evaluate_tags method
    '''

    test_cases = list()

    test_case1 = dict()
    test_case1['tags'] = ['always']
    test_case1['only_tags'] = list()
    test_case1['skip_tags'] = list()
    test_case1['should_run'] = True
    test_cases.append(test_case1)

    test_case2 = dict()
    test_case2['tags'] = list()
    test_case2['only_tags'] = list()
    test_case2['skip_tags'] = list()
    test_case2['should_run'] = True
    test_cases.append(test_case2)

    test_case3 = dict()

# Generated at 2022-06-11 11:04:40.824453
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Setup
    class TestClass:
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            class TestTemplar:
                def __init__(self):
                    pass
                def template(self, tags):
                    return tags

            templar = TestTemplar()

            _temp_tags = set()
            for tag in tags:
                if isinstance(tag, list):
                    _temp_tags.update(tag)
                else:
                    _temp_tags.add(tag)
            tags = _temp_tags
            self.tags = list(tags)

            should_run = True  # default, tasks to run


# Generated at 2022-06-11 11:04:51.152545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class GoodTaggable(Taggable):
        tags=['good','always','tagged']
    class BadTaggable(Taggable):
        tags=['bad','never']
    class EmptyTaggable(Taggable):
        tags=[]
    class UntaggedTaggable(Taggable):
        tags=None

    # positive tests
    gt = GoodTaggable()
    assert gt.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert gt.evaluate_tags(only_tags=['good'], skip_tags=[], all_vars={})
    assert gt.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:05:01.620613
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Obj for method evaluate_tags
    tags = ['tag1','tag2','tag3']
    tags_only = ['tag1','tag2','tag3','tag4','tag5']
    tags_skip = ['tag1','tag2','tag3','tag4','tag5']
    all_vars = {}

    tagable_obj = Taggable()

    # Set all values needed by method evaluate_tags
    tagable_obj.tags = tags
    tagable_obj.all_vars = all_vars

    # Test calling method evaluate_tags with only_tags
    # and skip_tags set
    assert tagable_obj.evaluate_tags(tags_only,tags_skip,all_vars) == True

    # Test calling method evaluate_tags with only_tags
    # and skip_tags set to None
    assert tagable

# Generated at 2022-06-11 11:05:11.993139
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Scenario #1:
    #    Construct a Task with the data 'tags: [ "debug" ]' and perform the test
    #    when result is expected:
    #       - if the options used in the test are:
    #             - only_tags: [ "debug", "all" ]
    #       - if the options used in the test are:
    #             - only_tags: [ "debug" ]
    from ansible.playbook.task import Task
    task_data = dict(
        tags=["debug"]
    )
    task = Task.load(task_data)
    # The result of the test should be True
    assert task.evaluate_tags(only_tags=["debug", "all"], skip_tags=[]) == True

# Generated at 2022-06-11 11:05:38.356178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-11 11:05:48.965653
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # set up task and test
    task = Taggable()

    # test without tags
    task.tags = []
    task.evaluate_tags([], [], {})
    assert task.tags == ['untagged']

    # test tags
    task.tags = ['a', 'b']
    task.evaluate_tags([], [], {})
    assert task.tags == ['a', 'b']

    # test with only all
    task.tags = []
    task.evaluate_tags(['all'], [], {})
    assert task.tags == ['untagged']

    # test with only all and never
    task.tags = ['never']
    task.evaluate_tags(['all'], [], {})
    assert task.tags == ['never']

    # test with only all and always
    task.tags = ['always']


# Generated at 2022-06-11 11:05:58.892065
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    # block with a single task
    mytask = Task()
    mytask._role = None
    mytask._parent = None
    mytask._loader = None
    mytask._block = None
    mytask.action = dict(module='command', args='/bin/true')
    block = Block()
    block.block = [mytask]
    block.always = None
    block.rescue = None
    block.always = None
    block.tags = []
    block.when = []
    block.post_validate()
    should_run = mytask.evaluate_tags([],[],dict())
    assert should_run == True
    # block with a single task and block with a tag
    mytask = Task()
    my

# Generated at 2022-06-11 11:06:08.811461
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    
    # test without only_tags and skip_tags
    task = Base()
    task.tags = ['sometag', 'anothertag']
    assert task.evaluate_tags({}, {}, {}) == True
    task.tags = []
    assert task.evaluate_tags({}, {}, {}) == True

    # test with only_tags
    task.tags = ['sometag', 'anothertag']
    assert task.evaluate_tags({'sometag'}, {}, {}) == True
    assert task.evaluate_tags({'anothertag'}, {}, {}) == True
    assert task.evaluate_tags({'somethingelse'}, {}, {}) == False
    assert task.evaluate_tags({'tagged'}, {}, {}) == True
    

# Generated at 2022-06-11 11:06:20.022935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    class TaggedBlock(Block, Taggable):
        pass

    # initialize all_vars and only_tags
    all_vars = dict(
        hostvar1="value1",
        hostvar2="value2",
        hostvar3="value3",
        )

    only_tags = frozenset(['tag1', 'tag2', 'tag3'])
    skip_tags = frozenset(['tag4', 'tag5', 'tag6'])

    test_block = TaggedBlock(
        parent=None, role=None, task_include=None,
        use_handlers=True,
        exception=None,
        always_run=False,
        loop=None,
        loop_args=None,
        name="test_block"
        )



# Generated at 2022-06-11 11:06:30.713148
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # class Taggable is in ansible/utils/__init__.py
    from ansible.utils import Taggable
    import unittest
    class TestTaggable(unittest.TestCase):
        def test_evaluate_tags(self):
            # mock class, we just need to test the method evaluate_tags of class Taggable
            class MockTask(Taggable):
                def __init__(self):
                    super(MockTask, self).__init__()

                    self._tags = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

                    self._tags.append(['1','2','3','4','5'])
                    self._tags

# Generated at 2022-06-11 11:06:40.175471
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags=None, only_tags=None, skip_tags=None, variables=None):
            self._tags = tags
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.variables = variables

        def run(self):
            return self.evaluate_tags(self.only_tags, self.skip_tags, self.variables)

    import unittest
    class TestTaggableMethods(unittest.TestCase):
        def setUp(self):
            pass

        def test1(self):
            t = TestTaggable(tags=['sometag'], only_tags=['sometag'], skip_tags=None, variables=None)

# Generated at 2022-06-11 11:06:51.231437
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass
    test_taggable = TestTaggable()

    # Test only_tags
    test_taggable.tags = (['foo', 'bar'])
    assert not test_taggable.evaluate_tags(only_tags=('baz',), skip_tags=())
    assert test_taggable.evaluate_tags(only_tags=('foo',), skip_tags=())
    assert test_taggable.evaluate_tags(only_tags=('all',), skip_tags=())
    assert test_taggable.evaluate_tags(only_tags=('tagged',), skip_tags=())
    assert not test_taggable.evaluate_tags(only_tags=('never',), skip_tags=())

    # Test skip_tags
    test_tagg

# Generated at 2022-06-11 11:06:59.368820
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.role_include import IncludeRole

    test_include_role = IncludeRole()

    test_include_role._ds = "a,b"
    test_include_role.tags = None

    try:
        test_include_role.evaluate_tags(only_tags=[], skip_tags=['c','d'], all_vars=[])
        return (False, "Expected a AnsibleError exception to be raised")
    except AnsibleError:
        pass
    except Exception:
        return (False, "Expected a AnsibleError exception to be raised")
    return (True, None)



# Generated at 2022-06-11 11:07:08.709271
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = frozenset(['all', 'never'])
    only_tags = frozenset(['all', 'never'])
    skip_tags = frozenset(['all', 'never'])
    should_run = True
    t = Taggable()
    assert t.evaluate_tags(only_tags, skip_tags, None) == should_run

    tags = frozenset(['all', 'never'])
    only_tags = frozenset(['all'])
    skip_tags = frozenset(['never'])
    should_run = True
    t = Taggable()
    assert t.evaluate_tags(only_tags, skip_tags, None) == should_run

    tags = frozenset(['all', 'never'])
    only_tags = frozenset(['all'])
    skip

# Generated at 2022-06-11 11:08:15.777432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json
    import unittest
    from ansible.module_utils._text import to_text

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    class TestTaggable(Taggable):
        def __init__(self, name, tags):
            self.tags = tags

        def names(self):
            return self.tags

        def serialize(self):
            return ','.join(self.tags)

    class TestOnlyPlayContext(PlayContext):
        def __init__(self):
            super(TestOnlyPlayContext, self).__init__()

# Generated at 2022-06-11 11:08:25.955311
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test with empty tags on Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    data = AnsibleMapping()
    data.name = 'task include'
    tags = []

    ti = TaskInclude(task=data, play_context=play_context)
    ti._load_tags('tags', tags)
    assert ti.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})

    data = AnsibleMapping()
    data.name = 'task include'
    data.tags = []

    ti = TaskInclude(task=data, play_context=play_context)
   

# Generated at 2022-06-11 11:08:36.993811
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        pass

    myTaggable = MyTaggable()
    myTaggable.tags = [ 'tag1', 'tag3' ]

    # Test to see if tags do match the tags option tags
    assert myTaggable.evaluate_tags( ['tag1', 'tag2'], None, None ) == True
    # Test to see if tags do not match the tags option tags
    assert myTaggable.evaluate_tags( ['tag2', 'tag4'], None, None ) == False
    # Test to see if task is skipped because of tags
    assert myTaggable.evaluate_tags( None, ['tag3'], None ) == False
    # Test to see if task is not skipped because of tags
    assert myTaggable.evaluate_tags( None, ['tag2'], None )

# Generated at 2022-06-11 11:08:48.394786
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.vault import VaultAES256
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.playbook.attribute import FieldAttribute

    Taggable_evaluate_tags = Taggable()

    # Tested conditionals
    only_tags = False
    skip_tags = False


    # Tested conditionals
    only_tags = True
    skip_tags = False


    # Tested conditionals
    only_tags = True
    skip_tags = True


    # Tested conditionals
    only_tags = False
    skip_tags = True


    # Test without tags attribute
   

# Generated at 2022-06-11 11:08:56.686111
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # initialize a Taggable class object
    obj = Taggable()

    # Load tags
    attr = 'tags'
    ds = ['tag1','tag2','tag3']
    expected_result = ['tag1','tag2','tag3']
    actual_result = obj._load_tags(attr,ds)
    assert actual_result == expected_result , "Actual and Expected result should be equal"

    # Give both the tags
    tags = ['tag1','tag2']
    only_tags = ['tag1']
    skip_tags = ['tag2']
    # Load all vars
    all_vars = {'tag1': 'tag1', 'tag2': 'tag2', 'tag3': 'tag3'}
    obj.tags = tags
    # Invoke the evaluate_tags method
    actual_result

# Generated at 2022-06-11 11:09:08.173184
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['hello', 'world']
    # Test case when only_tags is empty
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=tags, all_vars={}) == True, "missing only_tags when only_tags is empty"
    # Test case when only_tags is subset of tags
    assert Taggable().evaluate_tags(only_tags=['hello', 'world'], skip_tags=tags, all_vars={}) == True, "missing only_tags when only_tags is subset of tags"
    # Test case when only_tags is not subset of tags
    assert Taggable().evaluate_tags(only_tags=['hello'], skip_tags=tags, all_vars={}) == False, "missing only_tags when only_tags is not subset of tags"
    # Test case when skip_tags

# Generated at 2022-06-11 11:09:17.598525
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test = Taggable()
    test._tags = ['tag1','tag2','tag3']

    res = test.evaluate_tags(['all'],['none'],None)
    assert res == True

    res = test.evaluate_tags(['all'],['tag1'], None)
    assert res == True

    res = test.evaluate_tags(['all'],['tag3'], None)
    assert res == True

    res = test.evaluate_tags(['tag1'],['tag2'], None)
    assert res == True

    res = test.evaluate_tags(['tag1'],['tag3'], None)
    assert res == True

    res = test.evaluate_tags(['tag3'],['tag2'], None)
    assert res == True


# Generated at 2022-06-11 11:09:24.626319
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.helpers import load_list_of_tasks

    play_context = PlayContext()

    only_tags = ['foo']
    skip_tags = ['bar']

    task = Task()
    task._ds = { 'tags' : 'foo, bar','name' : 'Task1' }
    task.load(task._ds, play_context, loader=None)
    
    task_block = Block()

# Generated at 2022-06-11 11:09:34.889703
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Define only_tags and skip_tags
    only_tags = ['all']
    skip_tags = []

    # Define an object of class Taggable
    class Test():
        tags = []
        untagged = frozenset(['untagged'])
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
                if isinstance(value, list):
                    return [x.strip() for x in value]
                else:
                    return [ds]

# Generated at 2022-06-11 11:09:45.201920
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from io import StringIO
    import pytest

    class myTaggable(Taggable, Base):
        def __init__(self, *args, **kwargs):
            super(myTaggable, self).__init__(*args, **kwargs)
            self.tags = []

    vm = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    play_context.update_v