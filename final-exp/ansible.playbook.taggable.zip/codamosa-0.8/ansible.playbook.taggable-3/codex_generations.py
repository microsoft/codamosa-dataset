

# Generated at 2022-06-11 11:00:22.036401
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    templar = Templar(loader=None, variables=dict())

    class TaskInheritTaggable(Taggable):
        pass

    class Task(TaskInheritTaggable):
        pass

    task = Task()
    task._loader = templar._loader

    # Test with only_tags == 'always' and no skip_tags
    task.tags = 'always'

    assert task.evaluate_tags(['always'], None, None) == True, "Failed test with only_tags == 'always' and no skip_tags"

    # Test with only_tags == 'always' and skip_tags == 'never'
    task.tags = 'never'


# Generated at 2022-06-11 11:00:23.461989
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """test --list-tags behavior with both --tags and --skip-tags
    """
    assert False

# Generated at 2022-06-11 11:00:32.908293
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 1: only_tags specified without skip_tags.

    # Case 1.1: only_tags is assigned a non-empty list.

    # Case 1.1.1: only_tags contains a value and Taggable.tags also contains the same value.
    only_tags = ['tag1']
    skip_tags = []
    TestTaggable = Taggable()
    TestTaggable.tags = ['tag1']
    TestTaggable.untagged = None
    expected_value = True
    return_value = TestTaggable.evaluate_tags(only_tags, skip_tags, None)
    assert return_value == expected_value, 'Expected value was not returned'

    # Case 1.1.2: only_tags contains a value and Taggable.tags does not.
    only_tags = ['tag1']

# Generated at 2022-06-11 11:00:42.109065
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    Taggable._tags = lambda x,y: y

    class FakeTaggable(Taggable):
        tags = FieldAttribute(isa='list')

    a = FakeTaggable()
    b = FakeTaggable()

    assert a._load_tags('tags', 'a') == ['a']
    assert a._load_tags('tags', ['a', 'b']) == ['a', 'b']
    assert a._load_tags('tags', 'a,b') == ['a', 'b']

    try:
        a._load_tags('tags', 42)
        assert False, "should have raised error"
    except AnsibleError:
        pass

    # -t test
    a.tags = ['test']
    assert a.evaluate_tags(['test'], [], dict())

# Generated at 2022-06-11 11:00:52.826733
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars

    # Test with roles having multiple tags
    r = Role()
    r.tags = ['k1', 'v2']
    all_vars = dict()

# Generated at 2022-06-11 11:01:03.948235
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest

    # Setup
    class FakeTask(Taggable):
        def __init__(self, name, tags=[]):
            self._name = name
            self._tags = tags


# Generated at 2022-06-11 11:01:15.975949
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    import os

    # This test does a lot of setup - the following are the helper functions
    def get_vars_from_file(playbook, role):
        variable_manager = VariableManager()
        variable_manager.set_inventory(Inventory(loader=Loader(), variable_manager=variable_manager))
        variable_manager.extra_vars = load_extra_vars(loader=Loader(), options=Options(), passwords=None)

        pb = Play.load(playbook, variable_manager=variable_manager, loader=Loader())
        pb.set_loader(Loader())

        if role is not None:
            role_path = pb.get_role_path(role)

# Generated at 2022-06-11 11:01:26.814842
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTask(Taggable):
        _tags = { 'tags': [ 'foo', 'bar', 'all', 'tagged' ] }

    # 1. case: only_tags has value, skip_tags is empty
    only_tags = {'all', 'tagged'}
    skip_tags = set()
    test_task = MockTask(tags=['all', 'tagged', 'baz'])
    assert test_task.evaluate_tags(only_tags, skip_tags, None) is True
    test_task = MockTask(tags=['all'])
    assert test_task.evaluate_tags(only_tags, skip_tags, None) is True
    test_task = MockTask(tags=['tagged'])
    assert test_task.evaluate_tags(only_tags, skip_tags, None) is True


# Generated at 2022-06-11 11:01:35.472593
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class _Taggable(Taggable):
        pass

    play = _Taggable()

    # when no tags specified, it should run
    assert play.evaluate_tags(['foo'], [], {}) is True

    play.tags = ['foo']
    # when tags intersect, it should run
    assert play.evaluate_tags(['foo'], [], {}) is True

    # when tags do not intersect, it should not run
    assert play.evaluate_tags(['no-such-tag'], [], {}) is False

    play.tags = ['always', 'foo']
    # when tags intersect, it should run
    assert play.evaluate_tags(['foo'], [], {}) is True
    assert play.evaluate_tags(['always'], [], {}) is True

# Generated at 2022-06-11 11:01:47.888673
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Imports required for the unit test
    import sys
    import os
    import json
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import BasePlay
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    # Create a Play instance to be used with the test
    class TestPlay(BasePlay):
        # Ansible internal code uses property to get the variable
        # Thus creating property in the test class
        @property
        def vars(self):
            return self._vars


# Generated at 2022-06-11 11:02:00.252074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task

    class MyTaggable(Taggable):
        pass

    class MyTask(Task, MyTaggable):
        pass

    class MyBase(Base, MyTaggable):
        pass

    task = MyTask()
    base = MyBase()

    # Check that the evaluate_tags method of a Taggable task or base object is never None
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is not None
    assert base.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is not None

    # Check that a task with empty tags property is always skipped if skip_tags has 'tagged' in it

# Generated at 2022-06-11 11:02:04.344170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    import types
    class TestClass(Block):
        pass
    TestClass.tags = ['one', 'two']
    assert TestClass.evaluate_tags(None, None, None) == True
    TestClass.tags = ['never']
    assert TestClass.evaluate_tags(None, None, None) == False

# Generated at 2022-06-11 11:02:14.178534
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from collections import namedtuple
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.utils.unicode import to_unicode

    templar = Templar(loader=None, variables=dict())

    # Build a fake object
    FakeObj = namedtuple('FakeObj', ['tags', '_loader'])

    # Test #1: Should run when the task has no tags and
    # the playbook has no only_tags or skip_tags.
    obj = FakeObj(tags={}, _loader=None)
    only_tags = None
    skip_tags = None
    result = obj.evaluate_tags(only_tags, skip_tags, dict())
    assert result == True

    # Test #2: Should not run when the task has no tags and
    # the playbook has only_tags.

# Generated at 2022-06-11 11:02:25.368181
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    class TestClass(Taggable):
        def __init__(self):
            self.tags = ['tag_1', 'tag_2']

    test_item = TestClass()
    task = Task.load({})

    context = PlayContext()
    # Default should_run
    assert test_item.evaluate_tags(only_tags=None, skip_tags=None, all_vars=task.vars)
    assert test_item.evaluate_tags(only_tags=[], skip_tags=[], all_vars=task.vars)

    # Tag options should be list

# Generated at 2022-06-11 11:02:36.866482
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:02:44.287329
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    module = Taggable()
    # set only_tags and skip_tags
    only_tags = {'all'}
    skip_tags = {'debug'}
    # set task tags
    task_tags = ['all', 'debug']
    task_tags_with_never = ['all', 'never', 'debug']
    # set task no tags
    task_no_tags = []
    # set all_vars
    all_vars = {}
    # assert Taggable.evaluate_tags when only_tags and skip_tags is set and
    # task.tags is list type and contains both 'all' and 'debug'
    assert module.evaluate_tags(only_tags, skip_tags, all_vars) == False
    # assert Taggable.evaluate_tags when only_tags and skip_tags is set and
    #

# Generated at 2022-06-11 11:02:55.606494
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash

    only_tags = frozenset(['a', 'b'])
    skip_tags = frozenset(['s'])
    all_vars = {}

    # initialize
    loader = DataLoader()
    inventory = {'host_list': [], 'group_list': [], '_meta': {}}


# Generated at 2022-06-11 11:03:02.095139
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TagClass(Taggable):
        pass

    tag_obj = TagClass()

    assert tag_obj.evaluate_tags(False, False, {}) == True

    tag_obj.tags = ['test', 'another']

    assert tag_obj.evaluate_tags(['test', 'another'], False, {}) == True

    assert tag_obj.evaluate_tags(['test', 'another'], True, {}) == False

# Generated at 2022-06-11 11:03:10.587424
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.vault import VaultLib

    class A(object):
        _loader = None
        all_vars = dict()

    Taggable.evaluate_tags(A(), [], [], None)

    a = A()
    a.tags = [1, 2, 3]
    assert Taggable.evaluate_tags(a, None, None, dict())

    a = A()
    a.tags = None
    assert not Taggable.evaluate_tags(a, 'all', None, dict())

    a = A()
    a.tags = None
    assert Taggable.evaluate_tags(a, 'always', None, dict())

    a = A()
    a.tags = None
    assert not Taggable.evaluate_tags(a, 'never', None, dict())

    a = A()

# Generated at 2022-06-11 11:03:21.330152
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        pass

    taggable = TaggableTest()

    # test 2 tags (name, skip_tags)
    taggable.tags = ['test1', 'test2']
    only_tags = [ 'test1' ]
    skip_tags = [ 'test2' ]
    all_vars = {}
    assert False == taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # test 1 tag (name, skip_tags)
    taggable.tags = ['test2']
    only_tags = [ 'test1' ]
    skip_tags = [ 'test2' ]
    all_vars = {}
    assert False == taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # test

# Generated at 2022-06-11 11:03:41.836053
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Setup a Taggable object
    class Taggable_UnitTest(Taggable):
        tags = []

    # Instantiate a Taggable_UnitTest object
    taggable_unit_test = Taggable_UnitTest()

    # Load test variables
    only_tags = ['all', 'tagged', 'untagged', 'always']
    skip_tags = ['never', 'sometimes', 'all']

    # Run evaluate_tags with test variables
    result = taggable_unit_test.evaluate_tags(only_tags, skip_tags, None)

    # Verify results
    assert(result == True)

    # Setup test variables
    only_tags = ['all', 'tagged', 'untagged', 'sometimes']
    skip_tags = ['never', 'sometimes', 'all']

    # Run evaluate_tags with test variables


# Generated at 2022-06-11 11:03:42.732219
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass


# Generated at 2022-06-11 11:03:52.625985
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    fake_all_vars = dict(fake_all_vars={'my_tags': "tag1, tag2, tag3, tag4, tag5"})
    fake_Taggable_object = dict(tags=["tag1", "tag3", "tag4", "tag5"])
    fake_Taggable_object2 = dict(tags=["tag1", "tag2", "tag4", "tag5"])
    fake_Taggable_object3 = dict(tags=["tag1", "tag2", "tag3", "tag4", "tag5"])
    fake_Taggable_object4 = dict(tags=["tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "tag7"])

    # Check that Taggable object will be executed when only_tags is

# Generated at 2022-06-11 11:04:03.513369
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    playbook_item = Taggable()
    playbook_item.tags = None
    assert playbook_item.evaluate_tags(['tag1'], None, {}) == False
    playbook_item.tags = 'tag1'
    assert playbook_item.evaluate_tags(['tag1'], None, {}) == True
    assert playbook_item.evaluate_tags(['tag2'], None, {}) == False
    playbook_item.tags = ['tag1', 'tag2']
    assert playbook_item.evaluate_tags(['tag1'], None, {}) == True
    assert playbook_item.evaluate_tags(['tag2'], None, {}) == True
    assert playbook_item.evaluate_tags(['tag3'], None, {}) == False
    playbook_item.tags = ['tag1', 'tag2']
    assert playbook_

# Generated at 2022-06-11 11:04:14.772878
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Satisfying "only_tags"
    assert(Taggable().evaluate_tags(['foo', 'bar'], ['never'], {}))
    assert(Taggable(_tags=['foo']).evaluate_tags(['foo', 'bar'], ['never'], {}))
    assert(Taggable(_tags=['all']).evaluate_tags(['foo', 'bar'], ['never'], {}))
    assert(Taggable(_tags=['tagged']).evaluate_tags(['foo', 'bar'], ['never'], {}))
    assert(Taggable(_tags=['always']).evaluate_tags(['foo', 'bar'], ['never'], {}))
    assert(Taggable(_tags=['always']).evaluate_tags(['always'], ['never'], {}))

    # Not satisfying "only_tags"
   

# Generated at 2022-06-11 11:04:25.413074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task

    def test_func(self):
        return dict(update_cache=True)

    test_task = Task()
    test_task.action = 'test'
    test_task._role = None
    test_task._ds = {'tags': ['tag1','tag2','tag3','tag4']}
    test_task._load_ds = test_task._load_tags
    test_task.action = test_func
    test_task._parent = None
    test_task._block = None
    test_task._role = None

    all_vars = dict()

    only_tags = ['tag1', 'tag2', 'tag3', 'tag4']

# Generated at 2022-06-11 11:04:35.964233
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    small_playbook = PlaybookBase()
    test_play = Play()
    test_play.name = "test play"
    test_play.hosts = "all"
    test_task1 = Task()
    test_task1._role = None
    test_task1.name = "test task1"
    test_task1.tags = ["test1"]
    test_task2 = Task()
    test_task2._role = None
    test_task2.name = "test task2"
    test_task2.tags = "test2"
    test_task3 = Task()
    test_task3._role = None
    test_task3.name

# Generated at 2022-06-11 11:04:47.660852
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.insert(0, '../..')
    # This is a class imported from an external module
    from ansible.playbook.task_include import TaskInclude
    # This is what I'm testing
    from ansible.playbook.task import Task

    my_task = TaskInclude.load(dict(
        name="include",
        include="test_plays/test_include.yaml"
    ))

    # Test with tags not specified
    retval = my_task.evaluate_tags(['all'], [], dict(k='v'))
    assert retval is True
    retval = my_task.evaluate_tags(['all'], ['never'], dict(k='v'))
    assert retval is True

# Generated at 2022-06-11 11:04:56.574943
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.vars import VariableManager
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.task import Task

    task_only1_run = Task()
    task_only1_run.tags = ['only1']

    task_only1_nop = Task()
    task_only1_nop.tags = ['only2']

    vm = VariableManager()
    vm.set_inventory(Inventory(host_list=['testhost']))

# Generated at 2022-06-11 11:05:07.557550
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a new instance of the class Taggable
    test = Taggable()

    # Test evaluate_tags function
    test.tags = ['test']
    assert test.evaluate_tags(['test'], [], {}) == True
    assert test.evaluate_tags(['all'], [], {}) == True
    assert test.evaluate_tags(['tagged'], [], {}) == True
    assert test.evaluate_tags([], [], {}) == True
    assert test.evaluate_tags(['test', 'all'], [], {}) == True
    assert test.evaluate_tags(['test', 'all', 'test'], [], {}) == True
    assert test.evaluate_tags(['test', 'all', 'tagged'], [], {}) == True

# Generated at 2022-06-11 11:05:39.942012
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = FakeLoader()
    templar = Templar(loader=loader, variables={})
    base_obj = Taggable()
    base_obj.tags = ['all']
    base_obj.evaluate_tags('all')
    from AnsibleRunner import AnsibleRunner
    ar = AnsibleRunner(hosts, base_obj)
    ar.run()


if __name__ == "__main__":
    """
    python -m Ansible.playbook.taggable 
    """
    import pytest

    pytest.main(['./test/base_modules/test_Taggable.py'])

# Generated at 2022-06-11 11:05:50.911249
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['always']
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['always']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = ['never']
    only_tags = []
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['always']
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)
    t.tags = ['always']
    skip_tags = ['always']

# Generated at 2022-06-11 11:06:00.790046
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''verify the tag evaluation functions'''
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    block_no_tags = Block()
    block_one_tag = Block(tags=[u'one'])
    block_two_tags = Block(tags=[u'one',u'two'])
    block_three_tags = Block(tags=[u'one',u'two','three'])
    block_never_tag = Block(tags=[u'never'])
    block_always_tag = Block(tags=[u'always'])
    block_never_and_always_tag = Block(tags=[u'always',u'never'])
    block_never_and_always_tag_reversed = Block(tags=[u'never',u'always'])

    task_no

# Generated at 2022-06-11 11:06:07.083371
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Syntax :   should_run = self.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    t = Taggable()
    t.tags = ['always']
    only_tags = []
    skip_tags = []
    all_vars = {}
    should_run = t.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    assert should_run == True # As 'always' tag is always run
    print("test 1 passed")

    t.tags = ['never']
    only_tags = []
    skip_tags = []
    all_vars = {}

# Generated at 2022-06-11 11:06:18.075802
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class TestTaggable(Taggable, AnsibleBaseYAMLObject):

        def __init__(self, *args, **kwargs):
            super(TestTaggable, self).__init__(*args, **kwargs)

    def test_evaluate_tags(self, only_tags, skip_tags, all_vars, expected_result):

        result =  self.evaluate_tags(only_tags, skip_tags, all_vars)
        assert result == expected_result

    # test 1
    # only_tags: ['all']
    # skip_tags: ['never']
    # tags: ['x']
    # result: True

    only_tags = ['all']
    skip_tags = ['never']
    all_

# Generated at 2022-06-11 11:06:29.276455
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

        class Dummy(Taggable):

            def __init__(self):
                self._attributes = {}
                self.tags = []

        d = Dummy()

        # Check that having only_tag=[] and skip_tag=[] returns True
        assert d.evaluate_tags([], [], {})

        # Check that having only_tag=[], skip_tag=['never'] returns False
        assert not d.evaluate_tags([], ['never'], {})

        # Check that having only_tag=['always'] and skip_tag=[] returns True
        d.tags = ['always']
        assert d.evaluate_tags(['always'], [], {})

        # Check that having only_tag=['never'] and skip_tag=['never'] returns False
        d.tags = ['never']

# Generated at 2022-06-11 11:06:34.040197
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.role

    pb = ansible.playbook.PlayBook()
    host = ansible.inventory.host.Host(name='testhost')
    host.set_variable('ansible_tags', ['foo'])
    assert host.get_variable('ansible_tags') == ['foo']

    t = ansible.playbook.task.Task()
    t._cached_hosts_and_skip = [host]
    t._loader = pb._loader
    t.tags = ['bar']

    r = ansible.playbook.role.Role()
    pb.add_role(r)
    assert pb.get_roles_with_tags(['foo'], ['bar']) == []

    r.tags

# Generated at 2022-06-11 11:06:44.650066
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:06:55.770189
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class MockTask(Task, Taggable):
        pass

    class MockBaseYAMLObject(AnsibleBaseYAMLObject):
        def __init__(self):
            pass

    def _run_task(skip_tags=None, only_tags=None, task_tags=None):
        if skip_tags is None:
            skip_tags = []
        if only_tags is None:
            only_tags = []
        if task_tags is None:
            task_tags = []
        t = MockTask()
        t.tags = task_tags
        m = MockBaseYAMLObject()
        m.vars = dict()

# Generated at 2022-06-11 11:07:05.238575
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Run tests to ensure the method Taggable.evaluate_tags() is working properly '''

    # Instance of class Task to use in tests
    class Task(Taggable):

        def __init__(self, name, body, tags=None):
            super(Task, self)
            self.name = name
            self.body = body
            self.tags = tags

        def __repr__(self):
            return "<Task(name=%s,body=%s,tags=%s)>" % (self.name, self.body, self.tags)

    # Simple tasks to use in tests
    task1 = Task('name1', 'body1', ['tag1', 'tag2'])
    task2 = Task('name2', 'body2', ['tag3', 'tag4'])

# Generated at 2022-06-11 11:08:13.663392
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:08:19.856655
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    only_tags = set(['tag1', 'tag2'])
    skip_tags = set(['tag3', 'tag4'])
    all_vars = {}

    # test with empty tags: Should always run
    fake_taggable = FakeTaggable([])
    assert fake_taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # test with always tag: Should always run
    fake_taggable = FakeTaggable(['always'])
    assert fake_taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # test with never tag: Should never run
    fake_t

# Generated at 2022-06-11 11:08:25.035960
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Init
    t1 = Taggable()
    t1.tags = ['tag1','tag2','tag3']
    only_tags = ['tag1','tag4','tag5']
    skip_tags = ['tag4','tag6','tag7']

    # Test
    assert t1.evaluate_tags(only_tags, skip_tags, {}) == True

# Generated at 2022-06-11 11:08:36.052178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = AnsibleLoader(None, None)

    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    assert Taggable().evaluate_tags(None, None, variable_manager._fact_cache)

    tags = ['test', 'abc']
    obj = Taggable()
    obj.tags = tags
    assert obj.evaluate_tags(None, None, variable_manager._fact_cache)


# Generated at 2022-06-11 11:08:47.234983
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

    loader = AnsibleLoader(None, variable_manager=None, loader=None)

    data = '''
    - include: fail.yml
      tags:
        - test
    '''

    tasks = AnsibleBaseYAMLObject.load(data)
    task = TaskInclude.load(tasks[0], variable_manager=None, loader=loader)

    assert task.evaluate_tags(['test'], [], combine_vars(None, None)) == True, 'Only tag should match'
    assert task.evaluate_tags

# Generated at 2022-06-11 11:08:56.089783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test for case where item is not tagged
    only_tags = {'some_tag'}
    skip_tags = set()
    all_vars = {}
    obj = Taggable()
    assert not obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test for case where item is tagged
    skip_tags = set()
    obj = Taggable()
    obj.tags = ['some_tag']
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test for case where item is tagged but should be skipped
    only_tags = {'some_tag'}
    skip_tags = {'some_other_tag'}
    obj = Taggable()
    obj.tags = ['some_other_tag']
    assert not obj.evaluate

# Generated at 2022-06-11 11:09:07.852116
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.append('..')
    from ansible.playbook.block import Block
    from ansible.playbook.base import Base

    class BlockMock(Block, Taggable):
        pass

    class BaseMock(Base, Taggable):
        pass

    base_mock = BaseMock()
    block_mock = BlockMock(parent_block=base_mock)
    print('>'*30)
    print('block_mock.tags : ', block_mock.tags)
    print('block_mock.evaluate_tags([], [], {}) : ', block_mock.evaluate_tags([], [], {}))
    assert block_mock.evaluate_tags([], [], {})

    print('>'*30)

# Generated at 2022-06-11 11:09:14.793323
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ..loader import DataLoader
    from ansible.playbook.task import Task

    task = Task()
    task.tags = [['always'],['test_tag']]
    only_tags = set()
    only_tags.add('untagged')
    only_tags.add('test_tag')
    skip_tags = set()

    assert task.evaluate_tags(only_tags, skip_tags, 'fake_variable') == True

    skip_tags.add('always')
    assert task.evaluate_tags(only_tags, skip_tags, 'fake_variable') == False

# Generated at 2022-06-11 11:09:22.953084
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeTask(Taggable):
        pass

    fake_task = FakeTask()
    assert fake_task._load_tags("toto", ["titi", "tata"]) == ["titi", "tata"]
    assert fake_task._load_tags("toto", "titi,tata") == ["titi", "tata"]
    assert fake_task._load_tags("toto", ["titi", "tata", 1]) == ["titi", "tata", 1]


    fake_task = FakeTask()
    fake_task.tags = ["toto", "titi", "tata"]
    assert fake_task.evaluate_tags(["titi", "tata"], [], {})
    assert fake_task.evaluate_tags([], ["toto", "tata"], {})
    assert not fake_

# Generated at 2022-06-11 11:09:33.233516
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host

    host = Host('127.0.0.1')

    # all_vars = dict(ansible_all_ipv4_addresses=['127.0.0.1','192.168.99.100'])
    all_vars = dict()

    # case: no tags, always run
    host.evaluate_tags(['all', 'tagged'], [], all_vars)
    host.evaluate_tags(['all', 'tagged'], ['all'], all_vars)
    host.evaluate_tags(['all', 'tagged'], ['all', 'tagged'], all_vars)

    # case: no tags and in 'skip_tags', don't run
    host.evaluate_tags([], ['all', 'tagged'], all_vars)