

# Generated at 2022-06-11 11:00:21.669803
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.playbook
    f = Play()
    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = ['tag4', 'tag5', 'tag6']
    all_vars = {}
    assert f.evaluate_tags(only_tags, skip_tags, all_vars) == True
    f.tags = ['tag1', 'tag2']
    assert f.evaluate_tags(only_tags, skip_tags, all_vars) == True
    f.tags = ['tag3']
    assert f.evaluate_tags(only_tags, skip_tags, all_vars) == True
    f.tags = ['tag4']

# Generated at 2022-06-11 11:00:30.767638
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest2 as unittest
    class TestTaggable(Taggable):
        loader = None
    only_tags = ['tagged']
    skip_tags = []
    res = TestTaggable(tags=['foo'])
    assert res.evaluate_tags(only_tags, skip_tags, {})
    res = TestTaggable(tags=['always'])
    assert res.evaluate_tags(only_tags, skip_tags, {})
    res = TestTaggable(tags=[])
    assert res.evaluate_tags(only_tags, skip_tags, {})
    res = TestTaggable(tags=['never'])
    assert not res.evaluate_tags(only_tags, skip_tags, {})
    skip_tags = ['foo']

# Generated at 2022-06-11 11:00:39.709180
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """ This is a unit test for the method evaluate_tags of class Taggable """

    class FakeTaggable(Taggable):
        pass

    # Init the class
    ft = FakeTaggable()
    all_vars = dict()
    all_vars["tagged"]=True
    all_vars["untagged"]=True
    all_vars["always"]=True
    all_vars["never"]=True
    all_vars["truthy_string"]=True
    all_vars["falsy_string"]=False
    all_vars["truthy_list"]=[True]
    all_vars["falsy_list"]=[False]
    all_vars["truthy_dict"]={"a":True}

# Generated at 2022-06-11 11:00:50.201201
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_class = Taggable()

    # No tags
    test_class._tags = []
    test_class._load_tags("foo", [])

    fail=False
    if test_class.evaluate_tags(("all", "never"), None, None) is False:
        fail=True

    if test_class.evaluate_tags(("all", "never"), ("all", "always"), None) is False:
        fail=True

    if test_class.evaluate_tags(("all"), None, None) is True:
        fail=True

    if test_class.evaluate_tags(("all"), ("all", "always"), None) is True:
        fail=True

    if test_class.evaluate_tags(("never"), None, None) is False:
        fail=True


# Generated at 2022-06-11 11:01:01.624393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    my_obj = MyTaggable()
    my_obj.tags = ['always', 'test', 'foo']
    assert my_obj.evaluate_tags([], [], {})

    my_obj = MyTaggable()
    my_obj.tags = ['always', 'test']
    assert my_obj.evaluate_tags(['test'], [], {})

    my_obj = MyTaggable()
    my_obj.tags = ['always', 'test']
    assert my_obj.evaluate_tags(['test', 'bar'], [], {})

    my_obj = MyTaggable()
    my_obj.tags = ['always', 'test']
    assert my_obj.evaluate_tags(['foo', 'bar'], [], {})

    my

# Generated at 2022-06-11 11:01:11.048204
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = {'ansible_check_mode': False }
    fake_task = FakeTaggable()

    # Test simple tags, including use of always and never
    fake_task.tags = 'a,b,c'
    # tags can be skipped due to 'c'
    assert not fake_task.evaluate_tags(['a'], ['c'], all_vars)
    # tags can be run due to 'a'
    assert fake_task.evaluate_tags(['a'], [], all_vars)
    # 'always' overrides
    assert fake_task.evaluate_tags(['a'], ['always', 'c'], all_vars)
    # 'never' overrides
    assert not fake_task.evaluate_tags(['a', 'never'], ['c'], all_vars)



# Generated at 2022-06-11 11:01:22.000434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    
    # instantiate Taggable class (here: Task)
    tobj = Taggable()
    tobj.__class__ = Task
    tobj.tags = None
    tobj.untagged = Taggable.untagged
    
    # instantiate task and set tags
    task = Task()
    task.__class__ = Task
    task.tags = None
    task.untagged = Taggable.untagged

    # test body function
    def test_test_evaluate_tags(task, tobj):
        # test with empty tags
        tobj.tags = task.tags
        # test with only_tags
        only_tags = ['all']
        skip_tags = ['tagged']
        task.tags = []

# Generated at 2022-06-11 11:01:31.380871
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
    test_only_tags = ["uat","sqa"]
    test_skip_tags = []
    test_all_vars = {}
    test_taggable_object = MockTaggable(["sqa", "dev"])
    assert test_taggable_object.evaluate_tags(test_only_tags, test_skip_tags, test_all_vars) == True
    test_taggable_object = MockTaggable(["sqa", "dev"])
    test_only_tags = ["uat"]
    assert test_taggable_object.evaluate_tags(test_only_tags, test_skip_tags, test_all_vars) == False
    test_tagg

# Generated at 2022-06-11 11:01:43.937019
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestClass(Taggable):
        pass

    # default
    test_class = TestClass()
    assert test_class.evaluate_tags([], [], {})

    # empty only tags
    test_class = TestClass()
    test_class.tags = ['tag1', 'tag2']
    assert test_class.evaluate_tags([], [], {})

    # empty skip tags
    test_class = TestClass()
    test_class.tags = ['tag1', 'tag2']
    assert test_class.evaluate_tags(['tag1'], [], {})

    # skip tag1
    test_class = TestClass()
    test_class.tags = ['tag1', 'tag2']
    assert not test_class.evaluate_tags(['tag1', 'tag3'], ['tag1'], {})



# Generated at 2022-06-11 11:01:53.560806
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
      def __init__(self, test_id, tag_list):
        self.test_id = test_id
        self.tags = tag_list

    # The tag list is a list of tag strings (can be 'never', 'either', 'both', 'any', 'all', 'always', 'untagged')

# Generated at 2022-06-11 11:02:10.024835
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    myplay = Play().load({'name': 'testplay',
                          'hosts': 'localhost',
                          'tasks': [{'action': 'test', 'tags': ['testtag', 'testtag2']}]},
                         variable_manager={}, loader=None)

    mytask = Task.load(myplay.tasks[0], play=myplay, variable_manager={})

    assert (mytask.evaluate_tags(['testtag'], [], {}) == True)
    assert (mytask.evaluate_tags(['testtag'], [], {'tags': ['testtag']}) == True)

# Generated at 2022-06-11 11:02:21.038163
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    class my_module(Taggable):
        pass

    task = my_module()
    task._loader = None
    task._attributes = None
    task.name = "test_name"

    class args:
        pass

    # default, tasks to run
    should_run = task.evaluate_tags(only_tags=None, skip_tags=None, all_vars=args)
    assert should_run == True

    # Only tags, skip tags
    task.tags = ['always']
    should_run = task.evaluate_tags(only_tags=['always'], skip_tags=['always'], all_vars=args)
    assert should_run == True

    # Only tags
    task.tags = ['always']

# Generated at 2022-06-11 11:02:32.474315
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    myobj = AnsibleBaseYAMLObject()
    myobj.tags = ['test','test2','test3']

    assert myobj.evaluate_tags('','','') is True
    assert myobj.evaluate_tags('','all','') is True
    assert myobj.evaluate_tags('','test','test') is True
    assert myobj.evaluate_tags('','test4','test4') is True
    assert myobj.evaluate_tags('','tagged','tagged') is True

    assert myobj.evaluate_tags(['test','test2'],'','') is True
    assert myobj.evaluate_tags(['test','test2'],'all','') is True

# Generated at 2022-06-11 11:02:41.850466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # init object
    class Task(Taggable):
        pass
    task = Task()

    # test with empty only/skip tags
    only_tags = []
    skip_tags = []
    assert task.evaluate_tags(only_tags, skip_tags, {})

    # test with empty only/skip tags but with 'always' tag
    task.tags = ['always']
    assert task.evaluate_tags(only_tags, skip_tags, {})

    # test with only_tags = ['all'], skip_tags = []
    only_tags = ['all']
    skip_tags = []
    task.tags = []
    assert task.evaluate_tags(only_tags, skip_tags, {})
    task.tags = ['test']
    assert task.evaluate_tags(only_tags, skip_tags, {})

   

# Generated at 2022-06-11 11:02:52.799128
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    test_Taggable = Taggable()
    test_Taggable.tags = ['all']
    assert test_Taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    test_Taggable = Taggable()
    test_Taggable.tags = ['all']
    assert test_Taggable.evaluate_tags(['all'], skip_tags=None, all_vars={}) == True
    test_Taggable = Taggable()
    test_Taggable.tags = ['all']
    assert test_Taggable.evaluate_tags(['all'], ['all'], all_vars={}) == False


# Generated at 2022-06-11 11:03:04.555302
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test tag evaluation flags '''

    # Create a class instance
    t = Taggable()

    # Test the method evaluate_tags of class Taggable
    assert t.evaluate_tags([], [], {})
    assert t.evaluate_tags(['all'], [], {})
    assert t.evaluate_tags(['all'], ['all'], {})
    assert not t.evaluate_tags(['all'], ['never'], {})
    assert not t.evaluate_tags([], ['all'], {})

    assert t.evaluate_tags(['tagged'], [], {})
    assert not t.evaluate_tags(['tagged'], ['tagged'], {})
    assert not t.evaluate_tags(['tagged'], ['never'], {})


# Generated at 2022-06-11 11:03:11.612045
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self):
            pass

    taggable = FakeTaggable()

    # Check no tags
    taggable.tags = []
    assert taggable.evaluate_tags(['all'], [], {}) is True
    assert taggable.evaluate_tags([], ['all'], {}) is True
    assert taggable.evaluate_tags(['foo'], [], {}) is True
    assert taggable.evaluate_tags([], ['foo'], {}) is False
    assert taggable.evaluate_tags(['tagged'], [], {}) is False
    assert taggable.evaluate_tags([], ['tagged'], {}) is True

    # Check tags with only_tags
    taggable.tags = ['foo']
    assert tagg

# Generated at 2022-06-11 11:03:22.434549
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        tags = ['foo']

        def __init__(self, tags=None):
            if tags:
                self.tags = tags

    t = MockTaggable()
    assert t.evaluate_tags(only_tags = None, skip_tags = None, all_vars = None) == True, "No tags passed, so all should run"
    assert t.evaluate_tags(only_tags = ['foo', 'bar'], skip_tags = None, all_vars = None) == True, "Tag foo should run"
    assert t.evaluate_tags(only_tags = ['foo', 'bar'], skip_tags = ['foo'], all_vars = None) == False, "Tag foo skipped"

# Generated at 2022-06-11 11:03:33.121364
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        from ansible.playbook.block import Block
    except ImportError:
        from ansible.playbook.block import Block as Block

    my_block = Block()

    my_block.tags = ['test']

    assert my_block.evaluate_tags(only_tags=['test'], all_vars={}, skip_tags=[]) == True
    assert my_block.evaluate_tags(only_tags=['test'], all_vars={}, skip_tags=['test']) == False

    # ok with empty array, None should be the same
    assert my_block.evaluate_tags(only_tags=None, all_vars={}, skip_tags=None) == True

    # ok with empty array
    assert my_block.evaluate_tags(only_tags=[], all_vars={}, skip_tags=[])

# Generated at 2022-06-11 11:03:40.863916
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a fake object which contains a method evaluate_tags that
    # can be called and which contains the data self._tags.
    class FakeObject:
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            self._tags = ['check_tags', 'default_tags']

    class Loader(object):
        pass

    class Data:
        pass

    only_tags = ['check_tags']
    skip_tags = ['skip_tags']
    all_vars = ['default_tags']

    # Here starts the unit test
    fo = FakeObject()
    l = Loader()
    fo.evaluate_tags(only_tags, skip_tags, all_vars)
    assert fo._tags == ['check_tags', 'default_tags']

# Generated at 2022-06-11 11:04:05.737990
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableX(Taggable):
        tags=['tag1', 'tag2']

    a = TaggableX(tags=['tag1', 'tag2', 'tag3'])
    assert a.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    a = TaggableX(tags=['tag1', 'tag2', 'tag3'])
    assert a.evaluate_tags(only_tags=['tag4'], skip_tags=[], all_vars={}) == False

    a = TaggableX(tags=['tag1', 'tag2', 'tag3'])
    assert a.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={}) == True


# Generated at 2022-06-11 11:04:17.061147
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.play_context import PlayContext

    loader = None

    # Try on a task
    t = Taggable()
    t._loader = loader
    t.tags = ['a', 'b', 'c']

    # Test with no tags
    assert(t.evaluate_tags(None, None, None))

    # Test with only_tags = all
    assert(t.evaluate_tags('all', None, None))

    # Test with skip_tags = all
    assert(not t.evaluate_tags(None, 'all', None))

    # Test with only_tags = a and b
    assert(t.evaluate_tags(['a', 'b'], None, None))

    # Test with only_tags = a,b
    assert(t.evaluate_tags('a,b', None, None))

    #

# Generated at 2022-06-11 11:04:27.074405
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    import ansible.constants as C
    t = Task()
    r = Role()
    # Test if tag all will be triggered
    only_tags = ['all']
    # Test if tag all will be skipped
    skip_tags = ['all']
    assert t.evaluate_tags(only_tags, skip_tags, {}) == False
    assert r.evaluate_tags(only_tags, skip_tags, {}) == False
    # Test if tag always will be triggered
    only_tags = ['always']
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True
    assert r.evaluate_tags(only_tags, skip_tags, {}) == True
    # Test if tag always will

# Generated at 2022-06-11 11:04:38.579467
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Construct for test
    class mytask(Taggable):
        pass

    assert mytask().evaluate_tags(None, None, None)
    assert mytask().evaluate_tags([], None, None)
    assert mytask().evaluate_tags([], [], None)

    mytask_with_tag = mytask()
    mytask_with_tag._tags = ['tag_test']
    assert mytask_with_tag.evaluate_tags(None, None, None)
    assert mytask_with_tag.evaluate_tags([], None, None)
    assert mytask_with_tag.evaluate_tags([], [], None)

    assert mytask_with_tag.evaluate_tags(['tag_test'], None, None)
    assert mytask_with_tag.evaluate_tags([], ['tag_test'], None)
   

# Generated at 2022-06-11 11:04:49.561096
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTask(Taggable):
        pass
    class TestPlay(Taggable):
        pass

    task = TestTask()
    play = TestPlay()

    task.tags = ['always']
    skip_tags = ['skipped']
    only_tags = ['only']
    assert task.evaluate_tags(only_tags, skip_tags, None)

    skip_tags = ['skipped']
    only_tags = ['tagged']
    assert task.evaluate_tags(only_tags, skip_tags, None)

    skip_tags = ['skipped']
    only_tags = ['all']
    assert task.evaluate_tags(only_tags, skip_tags, None)

    # test play evaluate_tags
    play.tags = ['always']
    skip_tags = ['skipped']
    only_tags = ['only']

# Generated at 2022-06-11 11:04:59.986476
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # "always" tag should run the task
    assert True == Taggable().evaluate_tags(['always'], [], {})
    # "never" tag should not run the task
    assert False == Taggable().evaluate_tags([], ['never'], {})
    # "never" and "always" tags should run the task
    assert True == Taggable().evaluate_tags(['always'], ['never'], {})
    # "never" tag should not run the task
    assert False == Taggable().evaluate_tags([], ['never'], {})
    # "never" tag should not run the task, and "always" tag should run the task
    assert True == Taggable().evaluate_tags(['always'], ['never'], {})

    # "tagged" tag should run the task

# Generated at 2022-06-11 11:05:10.502901
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    t = Task()
    t.tags = ['all', 'never']
    assert t.evaluate_tags([], [], {}) == False

    t.tags = ['all', 'never']
    assert t.evaluate_tags(['all'], [], {}) == False

    t.tags = ['all', 'never']
    assert t.evaluate_tags(['never'], [], {}) == False

    t.tags = ['always']
    assert t.evaluate_tags([], [], {}) == True

    t.tags = ['always']
    assert t.evaluate_tags(['all'], [], {}) == True

    t.tags = ['always']

# Generated at 2022-06-11 11:05:20.349001
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include  import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar

    only_tags = ['all']
    skip_tags = ['all']

    # no tags
    test_task = TaskInclude()
    test_task.tags = []
    assert True == test_task.evaluate_tags(only_tags, skip_tags, None)

    # empty tags
    only_tags = []
    skip_tags = []
    assert True == test_task.evaluate_tags(only_tags, skip_tags, None)

    # have tags
    only_tags = ['all']
    skip_tags = ['all']
    test_task.tags = ['test']

# Generated at 2022-06-11 11:05:31.751258
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible import constants as C
    import os

    THIS_DIR = os.path.dirname(os.path.abspath(__file__))
    TASK_INCLUDE_DATA = dict(
        name='include',
        attrs=dict(),
        parent=dict(),
        block=dict(),
        role=dict(),
    )

    def _get_include(new_attrs):
        data = TASK_INCLUDE_DATA.copy()
        data['attrs'].update(new_attrs)
        return TaskInclude.load(data, loader=None, variable_manager=None)

    # No tags given
    include = _get_include(dict())
    assert include.evaluate_tags({}, {}, dict())

# Generated at 2022-06-11 11:05:40.063040
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # If no tags are used, the task should always be executed
    t = Taggable()
    assert(t.evaluate_tags([], [], {}) is True)
    assert(t.evaluate_tags(['all'], [], {}) is True)
    assert(t.evaluate_tags([], ['all'], {}) is True)
    assert(t.evaluate_tags(['all'], ['all'], {}) is True)
    # If a task has a tag, it should always be executed with the option --tags all
    t.tags = ['foo']
    assert(t.evaluate_tags([], [], {}) is True)
    assert(t.evaluate_tags(['all'], [], {}) is True)
    assert(t.evaluate_tags([], ['all'], {}) is True)

# Generated at 2022-06-11 11:06:10.264784
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Taggable_test(Taggable):
        def __init__(self):
            #Taggable.__init__(self)
            pass
    tt = Taggable_test()
    assert tt.evaluate_tags([], [], [])
    assert tt.evaluate_tags([], [], {})
    assert tt.evaluate_tags(['#'], [], {})
    assert tt.evaluate_tags(['#'],[], [])
    assert not tt.evaluate_tags(['#'], ['#'], [])
    assert not tt.evaluate_tags(['#'], ['#'], {})
    assert tt.evaluate_tags(['#'], ['#', '@'], [])

# Generated at 2022-06-11 11:06:21.645225
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test_Taggable_evaluate_tags
    Unit test for method evaluate_tags of class Taggable
    '''
    # Given the empty class Taggable
    class Taggable_Object(Taggable):
        pass

    # And a taggable object with tags :
    # - always
    taggable_object = Taggable_Object()
    taggable_object.tags = ['always']

    # When we run evaluate_tags without any options
    should_run = taggable_object.evaluate_tags(only_tags=[], skip_tags=[], all_vars=[])

    # Then we should run this taggable object
    assert should_run is True

    # When we run evaluate_tags with option to only_tags

# Generated at 2022-06-11 11:06:32.013737
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    only_tags, skip_tags=['odd'], []
    t = Task()
    t.tags = ['odd']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars={})

    only_tags, skip_tags=['odd', 'even'], []
    t = Task()
    t.tags = ['even']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars={})


# Generated at 2022-06-11 11:06:42.297533
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class mockTaggable(Taggable):
            def __init__(self, tags):
                self.tags = tags
    # Testing with a single tag.
    tag1 = ['tag1']
    obj1 = mockTaggable(tag1)
    assert obj1.evaluate_tags(False, False, []) == True
    assert obj1.evaluate_tags([], [], []) == True
    assert obj1.evaluate_tags(['tag1'], [], []) == True
    assert obj1.evaluate_tags(['tag2'], [], []) == False
    # Testing with multiple tags.
    tag2 = ['tag1', 'tag2']
    obj2 = mockTaggable(tag2)
    assert obj2.evaluate_tags(False, False, []) == True

# Generated at 2022-06-11 11:06:53.327578
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # create instance
    from ansible.playbook.task import Task
    from ansible.playbook.base import Base
    test_obj = Task()

    # match
    # set tags
    tags = ['web']
    test_obj._tags = tags

    # set options
    only_tags = ['all']
    skip_tags = []

    # run function
    result = test_obj.evaluate_tags(only_tags, skip_tags, Base._get_base_vars(test_obj))
    assert result == True

    # match
    # set tags
    tags = ['web']
    test_obj._tags = tags

    # set options
    only_tags = ['all']
    skip_tags = ['tagged']

    # run function

# Generated at 2022-06-11 11:07:03.084783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockDS:
        pass
    class MockTagger(Taggable):
        def __init__(self, meta):
            self.tags = meta.get('tags', None)
        def _load_tags(self, attr, ds):
            return ds.tags
        def __repr__(self):
            return "<Tagger %s>" % self.tags
    task = MockTagger({'tags': ['tag-1', 'tag-2']})
    assert task.evaluate_tags(only_tags=['tag-1'], skip_tags=[], all_vars={})
    task = MockTagger({'tags': ['tag-1', 'tag-2']})
    assert task.evaluate_tags(only_tags=['tag-1', 'tag-2'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:07:08.849524
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    TAG_ALWAYS     = ['always']
    TAG_NEVER      = ['never']
    TAG_TEST_TRUE  = ['testtrue']
    TAG_TEST_FALSE = ['testfalse']

    TAG_TAGGED = ['tagged']

    TAG_ALL = ['all']

    t = Taggable()

    skip_tags = []
    only_tags = []

    t.tags = TAG_TEST_FALSE
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True

    t.tags = TAG_TEST_TRUE
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True

    t.tags = TAG_ALWAYS
    assert t.evaluate_tags(only_tags, skip_tags, {}) == True

   

# Generated at 2022-06-11 11:07:19.691288
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Taggable_test(object):
        def __init__(self):
            self.task_name = 'doesnt matter'
            self.tags = ['tag1', 'tag2']
            self._loader = None
    # Test1: should_run: True, only_tags: ['tag1'], skip_tags: []
    obj = Taggable_test()
    only_tags = ['tag1']
    skip_tags = []
    all_vars = None
    result = obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True, "Test1 result: {0}, expected: True".format(result)
    # Test2: should_run: False, only_tags: ['tag1'], skip_tags: ['tag1']
    obj = Taggable_test()

# Generated at 2022-06-11 11:07:30.044193
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeClass(Taggable):
        pass

    fake_vars = {}
    fake_class = FakeClass()
    fake_class.tags = []
    fake_class.evaluate_tags(set(), set(), fake_vars)
    print(str(fake_class.tags))
    assert fake_class.tags == ['untagged']

    fake_class.tags = ['one', 'two']
    fake_class.evaluate_tags(set(['one']), set(), fake_vars)
    print(str(fake_class.tags))
    assert fake_class.tags == ['one', 'two']

    fake_class.tags = ['one', 'two']
    fake_class.evaluate_tags(set(), set(['one']), fake_vars)
    print(str(fake_class.tags))
    assert fake

# Generated at 2022-06-11 11:07:39.951864
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestTaggable(Taggable):

        def __init__(self, play):
            self._play = play

    class TestTask(Task):

        def __init__(self, play):
            self._play = play

    class TestPlay(Play):
        pass

    task = TestTask(TestPlay())
    task._loader = None
    task._variable_manager = VariableManager()
    task._templar = Templar(loader=task._loader, variables=task._variable_manager.get_vars(loader=task._loader, play=task._play))

    result = task.evaluate_tags(None, None, dict())
   

# Generated at 2022-06-11 11:08:49.131920
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):

        def __init__(self, name, tags):
            self.name = name
            self.tags = tags
            from ansible.playbook.play_context import PlayContext
            self._play_context = PlayContext()

    class TestLoader:

        def __init__(self):
            self.vars = {}

    # Set up test context
    loader = TestLoader()

    # Set up test variables
    loader.vars = {}

    # test with only_tags and skip_tags set
    t = TestTaggable(name="test_item_with_tags", tags=['test', '1'])
    assert t.evaluate_tags(only_tags=['test', '2'], skip_tags=[], all_vars=loader.vars) == False

    # test with

# Generated at 2022-06-11 11:08:57.057080
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj=Taggable()
    obj.tags=['all','present','production']
    only_tags=['production','all']
    skip_tags=[]
    all_vars={}
    assert(obj.evaluate_tags(only_tags,skip_tags,all_vars)==True)
    obj.tags=['all','present','test']
    assert(obj.evaluate_tags(only_tags,skip_tags,all_vars)==False)
    obj.tags=['all','present','production','test']
    assert(obj.evaluate_tags(only_tags,skip_tags,all_vars)==True)
    obj.tags=[]
    assert(obj.evaluate_tags(only_tags,skip_tags,all_vars)==False)
    obj.tags=['all','present','production']


# Generated at 2022-06-11 11:09:04.881047
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test for class Taggable method evaluate_tags
    '''
    assert Taggable().evaluate_tags('always', 'never', None) == True
    assert Taggable().evaluate_tags('always', 'never', {}) == True
    assert Taggable().evaluate_tags('never', 'always', None) == False
    assert Taggable().evaluate_tags('untagged', 'always', None) == False
    assert Taggable().evaluate_tags('untagged', 'never', None) == True

test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:09:14.838861
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTask(Taggable):

        def __init__(self):
            self._tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
                if isinstance(value, list):
                    return [x.strip() for x in value]
                else:
                    return [ds]
            else:
                raise AnsibleError('tags must be specified as a list', obj=ds)

    # This tests the fact that the tags attribute is not present in the class object
    my_task1 = MyTask()

# Generated at 2022-06-11 11:09:22.983929
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test using "tags" in a Task

    # Task with no tags
    t1 = Task()
    assert t1.evaluate_tags([], [], {}) == True

    # Task with a tag
    t2 = Task()
    t2.tags = ["tag1"]
    assert t2.evaluate_tags([], [], {}) == True

    # Task with missing tag
    t3 = Task()
    t3.tags = ["tag1"]
    assert t3.evaluate_tags(["tag2"], [], {}) == False

    # Task with one matching tag
    t4 = Task()
    t4.tags = ["tag1"]
    assert t4.evaluate_tags(["tag1"], [], {}) == True



# Generated at 2022-06-11 11:09:33.276809
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    t = TestClass()
    t.tags = []
    assert t.evaluate_tags(["all", "foo"], ["skip_all"], dict())
    assert not t.evaluate_tags(["all"], ["skip_all", "foo", "always"], dict())

    t.tags = ["always"]
    assert t.evaluate_tags(["all", "foo"], ["skip_all"], dict())
    assert not t.evaluate_tags(["all"], ["skip_all", "foo", "always"], dict())

    t.tags = ["all", "foo", "bar"]
    assert t.evaluate_tags(["all"], ["skip_all"], dict())
    assert not t.evaluate_tags(["all"], ["skip_all", "bar"], dict())

    t.tags = []
    assert t

# Generated at 2022-06-11 11:09:43.711041
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        pass
    class Playbook:
        def __init__(self):
            self.tags = {}
    import collections
    test_tags = collections.namedtuple('test_tags', ['only_tags', 'skip_tags', 'tags', 'should_run'])
    tests = []
    all_vars = {}
    taggable = TaggableTest()
    taggable._loader = Playbook()
    # Test: no only_tags, no skip_tags
    tests.append(test_tags(only_tags=None, skip_tags=None, tags=None, should_run=True))
    tests.append(test_tags(only_tags=None, skip_tags=None, tags=[], should_run=True))

# Generated at 2022-06-11 11:09:55.038239
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class myTaggable(Taggable):
        pass

    # Instantiate class
    test_class = myTaggable()

    # Assign all_vars
    all_vars = dict()

    # Test 100: all_vars is not valid
    try:
        test_class.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
        assert False
    except Exception:
        assert True

    # Test 200: only_tags and skip_tags are None
    should_run = test_class.evaluate_tags(only_tags=None, skip_tags=None, all_vars=all_vars)
    assert should_run

    # Create a test object

# Generated at 2022-06-11 11:10:05.742928
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayClass
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    my_templar = Templar(loader=None, variables={})

    mytask = Task()
    mytask.tags = ['test']
    assert mytask.evaluate_tags(['test'], [], {}) == True
    assert mytask.evaluate_tags(['test'], ['skipme'], {}) == False
    assert mytask.evaluate_tags(['test'], ['test'], {}) == False
    assert mytask.evaluate_tags([], ['skipme'], {}) == True
    assert mytask.evaluate_tags([], ['test'], {}) == True
    assert mytask