

# Generated at 2022-06-11 11:00:20.244960
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test = TestTaggable()
    test.tags = ['tag1', 'tag2', 'tag3']

    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3']
    all_vars = {}

    assert test.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-11 11:00:29.270190
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    my_var_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-11 11:00:38.059559
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    tags = ["tag1", "tag2", "tag3"]
    t.tags = tags
    only_tags = []
    skip_tags = []
    all_vars = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True
    only_tags = ["tag1", "always", "tag2", "tag3"]
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True
    skip_tags = ["tag1", "tag2", "tag3"]
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == False
    only_tags = []
    skip_tags = ["tag1", "tag2", "tag3", "always"]
    assert t.evaluate_tags

# Generated at 2022-06-11 11:00:48.306148
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # create a block
    my_block = Block()

    # create a variable manager
    my_vars_manager = VariableManager()

    # create a task
    my_block.block = [{'name': 'first task', 'tags': ['hello', 'world']},
                      {'name': 'second task', 'tags': ['hello', 'foo']},
                      {'name': 'third task', 'tags': 'hello, world'}]

    # create a value for only_tags
    my_only_tags = ['hello']

    # create a value for skip_tags
    my_skip_tags = []

    # create a value for all_vars
    my_all_vars = {'hello': 'world'}



# Generated at 2022-06-11 11:00:59.385474
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # Test with only_tags=['all'], skip_tags=[]
    only_tags = ['all']
    skip_tags = []
    all_vars = dict()

    # With only_tags=['all'] and skip_tags=[], the task should run
    # if it has 'always' in its tags or if it has non-empty tags or
    # if it has no tags at all
    t._tags = ['always']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

    t._tags = ['foo']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

    t._tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-11 11:01:08.379947
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    a = Taggable()

    a.tags = ['tag1', 'tag2']
    all_vars = dict(foo='bar')
    assert a.evaluate_tags([], [], all_vars) == True
    assert a.evaluate_tags(['tag1'], [], all_vars) == True
    assert a.evaluate_tags(['tag2'], [], all_vars) == True
    assert a.evaluate_tags(['tag3'], [], all_vars) == False
    assert a.evaluate_tags(['all'], [], all_vars) == True
    assert a.evaluate_tags([], ['all'], all_vars) == False
    assert a.evaluate_tags(['all'], ['all'], all_vars) == True

# Generated at 2022-06-11 11:01:19.319664
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create an object to test
    class MyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    def evaluate_tags(tags, only_tags, skip_tags):
        return MyTaggable(tags).evaluate_tags(only_tags, skip_tags, dict())


    # Test a simple case
    assert evaluate_tags(['A'], ['A', 'B'], set())
    assert not evaluate_tags(['A'], ['B'], set())

    # Test case sensitivity
    assert evaluate_tags(['a'], ['A', 'B'], set())
    assert not evaluate_tags(['A'], ['a', 'b'], set())

    # Test if only_tags is exhausted

# Generated at 2022-06-11 11:01:29.513579
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    assert t.evaluate_tags(None, None, None)
    assert t.evaluate_tags([], None, None)
    assert t.evaluate_tags(['a'], None, None)
    assert t.evaluate_tags(None, ['b'], None)
    assert t.evaluate_tags(['a'], ['b'], None)
    assert t._load_tags(None, 'a') == ['a']
    assert t._load_tags(None, ['a']) == ['a']
    assert t.tags == []
    t.tags = ['a']
    assert t.tags == ['a']

    t.tags = [1]
    assert t.tags == [1]

    assert t.evaluate_tags(['a'], None, None)

# Generated at 2022-06-11 11:01:34.418402
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types))

    attr = dict(tags=[])
    t = TestTaggable(loader=None, variable_manager=None, templar=None)
    t._load_tags(attr, attr['tags'])
    assert t.tags == ['untagged']


# Generated at 2022-06-11 11:01:47.039113
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class SomethingTaggable(Taggable):
        def __init__(self):
            self.tags = None

    # test always and never tags
    taggable = SomethingTaggable()
    taggable.tags = ['always']
    assert taggable.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert not taggable.evaluate_tags(only_tags=[], skip_tags=['always'], all_vars={})

    # test empty and non-empty tags
    taggable = SomethingTaggable()
    taggable.tags = []
    assert taggable.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})

# Generated at 2022-06-11 11:02:09.621682
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' test_Taggable_evaluate_tags():
    '''
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.vault import VaultLib

    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = None
            self.name = 'test_Taggable_evaluate_tags'


    class TestTaggable(unittest.TestCase):
        ''' test_Taggable_evaluate_tags class
        '''
        def runTest(self):
            ''' Runnable test
            '''
            t = MyTaggable()
            t.tags = ['testtag_for_all']
            v = VaultLib('test_Taggable_evaluate_tags')

# Generated at 2022-06-11 11:02:20.551021
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  class Tagged(Taggable):
    pass

  tagged = Tagged()
  tagged._loader = None
  tagged.tags = []

  # Run a task when no tags are set
  assert tagged.evaluate_tags([],[],{})

  # Default 1) "all" and "untagged" tasks should run 
  # Default 2) "tagged" and "never" tasks should not run

  assert tagged.evaluate_tags(['all'],[] ,{})
  assert tagged.evaluate_tags(['all','never'],[] ,{})
  assert tagged.evaluate_tags(['all','tagged'],[] ,{})
  assert tagged.evaluate_tags(['all','untagged'],[] ,{})
  assert not tagged.evaluate_tags(['never','tagged'],[] ,{})

# Generated at 2022-06-11 11:02:29.442868
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        pass

    taggable = FakeTaggable()
    taggable.tags = list()
    assert taggable.evaluate_tags(tuple(), tuple(), dict()) is True

    only_tags = tuple(["foo", "bar", "baz"])
    skip_tags = tuple()
    assert taggable.evaluate_tags(only_tags, skip_tags, dict()) is False

    taggable.tags = list(["foo"])
    assert taggable.evaluate_tags(only_tags, skip_tags, dict()) is True


# Generated at 2022-06-11 11:02:39.777897
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['foo', 'bar']

    # Check tags option
    obj = Taggable()
    obj.tags = tags
    # Should run for empty filters
    assert obj.evaluate_tags(only_tags=[], skip_tags=[])
    # Should not run for only_tags=['foo', 'bar']
    assert not obj.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[])
    # Should not run for only_tags=['foo']
    assert not obj.evaluate_tags(only_tags=['foo'], skip_tags=[])
    # Should not run for only_tags=['foo', 'bar', 'baz']
    assert not obj.evaluate_tags(only_tags=['foo', 'bar', 'baz'], skip_tags=[])
    # Should run for skip_tags=['

# Generated at 2022-06-11 11:02:50.464257
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    test_Taggable_evaluate_tags
    This unit test checks the method Taggable.evaluate_tags() with different
    scenarios to ensure proper execution of the method.
    '''

    import os
    import sys
    import copy
    our_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, our_path + "/../../module_utils/")
    sys.path.insert(0, our_path + "/../..")
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.my_module import MyModule
    from ansible.module_utils._text import to_text

    # Setup the test environment

# Generated at 2022-06-11 11:03:02.096800
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    fake_play = dict(
        tags = ['endpoint']
    )
    fake_task = dict(
        tags=list(fake_play['tags'])
    )
    fake_res = dict(
        tags=list(fake_play['tags'])
    )
    fake_conn = dict(
        tags=list(fake_play['tags'])
    )
    fake_host = dict(
        name='fake_hostname',
        tags=list(fake_play['tags'])
    )

    t = Taggable()
    t.tags = fake_play['tags']

    assert t.evaluate_tags(['endpoint'], [], fake_host)
    assert t.evaluate_tags(['endpoint'], ['frontend'], fake_host)

# Generated at 2022-06-11 11:03:10.586244
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        pass

    fake_taggable = FakeTaggable()

    # test only_tags - 'all' should run if tags present
    fake_taggable.tags = ['first', 'second']
    only_tags = ['all']
    skip_tags = []
    assert fake_taggable.evaluate_tags(only_tags, skip_tags, {}) is True
    # test only_tags - 'all' should not run if tags not present
    fake_taggable.tags = []
    only_tags = ['all']
    skip_tags = []
    assert fake_taggable.evaluate_tags(only_tags, skip_tags, {}) is False
    # test only_tags - 'all' should not run if tags are ['never']
    fake_taggable.tags

# Generated at 2022-06-11 11:03:21.331117
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import TaskBlock
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    # Test 1
    # case: untagged task, mocked with no tags specified
    t = Task()
    o = set(['tag1', 'tag2'])
    s = set()
    v = {}
    assert t.evaluate_tags(o, s, v)

    # Test 2
    # case: tagged task, mocked with two tags, one of which matches
    t = Task()
    t._tags = ['tag1']
    o = set(['tag1', 'tag2'])
    s = set()
    v = {}

# Generated at 2022-06-11 11:03:32.140696
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils import basic
    from ansible.template import Templar, template_from_str
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager

    context = PlayContext()
    context.only_tags = ['all']
    context.skip_tags = []
    context.tags = ['all']
    localhost = basic.AnsibleModule(templar=Templar,
                                     variable_manager=VariableManager(),
                                     loader=None)
    localhost.play_context = context

    loader = localhost._loader
    templar = Templar(loader=loader, variables={})

    set_of_tags = set(['tag1','tag2','tag3'])

# Generated at 2022-06-11 11:03:40.203044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class FakeItem(Taggable):
        pass

    item = FakeItem()
    item.tags = ['a', 'b', 'c']

    # test only_tags option
    item.evaluate_tags(only_tags=['a', 'd'], skip_tags=[])
    assert item.tags == ['a', 'b', 'c']

    item.evaluate_tags(only_tags=['a'], skip_tags=[])
    assert item.tags == ['a']

    item.evaluate_tags(only_tags=['b'], skip_tags=[])
    assert item.tags == ['b']

    item.evaluate_tags(only_tags=['b', 'c'], skip_tags=[])
    assert item.tags == ['b', 'c']


# Generated at 2022-06-11 11:03:56.869597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True == Taggable().evaluate_tags(['Taggable'], ['Taggable1'], '')
    assert True == Taggable().evaluate_tags(['Taggable'], ['Taggable1'], '')
    assert False == Taggable().evaluate_tags(['Taggable'], ['Taggable1', 'Taggable'], '')
    assert True == Taggable().evaluate_tags(['Taggable1'], [], '')
    assert False == Taggable().evaluate_tags(['Taggable1'], [], '')
    assert True == Taggable().evaluate_tags(['Taggable1'], ['Taggable'], '')
    assert False == Taggable().evaluate_tags(['Taggable'], ['Taggable'], '')
    assert True == Taggable

# Generated at 2022-06-11 11:04:08.130647
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_object = Taggable()

    only_tags = {}
    skip_tags = {}
    all_vars = {}

    # Test with a list containing multiple tags
    test_object.tags = ['All', 'Always', 'Never', 'Tagged']
    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with a list containing a single tag
    test_object.tags = ['All']
    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with a string containing multiple tags
    test_object.tags = 'All, Always, Never, Tagged'
    assert test_object.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with a string containing a single tag
    test_

# Generated at 2022-06-11 11:04:18.936727
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import os
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    from ansible.module_utils.facts import default_collectors

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    def test(only_tags, skip_tags, tags, all_vars, result):
        play = Play.load(dict(
                name = 'foobar',
                hosts = 'all',
                gather_facts = 'no',
                tasks = [dict(
                    action = dict(module='shell', args='ls'),
                    tags = tags,
                )],
            ),
            loader = DictDataLoader({}),
        )

        tqm = Play._make_global_context(play)

        hosts

# Generated at 2022-06-11 11:04:28.302682
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:04:39.918367
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # The test function will be called three times, once with only_tags, once
    # with skip_tags and once with both. In each case, we expect the
    # test_evaluator to return True if the should_run value is true.
    # If should_run is False we expect a RuntimeError.
    class test_evaluator:
        def __init__(self, should_run):
            self.should_run = should_run
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            if not self.should_run:
                raise RuntimeError('not expected')
            return self.should_run

    # Check that only_tags works as expected, if not a RuntimeError will be
    # thown by the test_evaluator

# Generated at 2022-06-11 11:04:50.574569
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Setup test cases

    # Only run if a certain tag is present
    testcase_only_tags = {'tags': ['test_1'],
                          'only_tags': ['test_1'],
                          'skip_tags': [],
                          'should_run': True}

    # Run if a tag is present and avoid all else
    testcase_only_tags_all = {'tags': ['test_1'],
                              'only_tags': ['all'],
                              'skip_tags': [],
                              'should_run': True}

    # Run if a tag is present and avoid all else

# Generated at 2022-06-11 11:05:01.125688
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class t_Taggable(Taggable):
        def __init__(self, tags):
            self.tags = tags


# Generated at 2022-06-11 11:05:11.546243
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    from . import utils
    if sys.version_info[0] < 3:
        from mock import Mock, patch
    else:
        from unittest.mock import Mock, patch
    TaggableMock = utils.make_mock_class('Taggable', Taggable)
    tm = TaggableMock()
    tm.tags = ['tagged']
    tm._loader = Mock()
    tm._loader.get_basedir.return_value = ''
    with patch.object(Templar, 'template', return_value=['tagged']):
        assert tm.evaluate_tags(only_tags=['all']) == True
        assert tm.evaluate_tags(none_tags=['all']) == False

# Generated at 2022-06-11 11:05:21.305043
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Taggable mock class
    class TaggableMock(Taggable):

        def __init__(self, tags):
            self.tags = tags

    # Test parameters
    only_tags = []
    skip_tags = []
    all_vars = {}

    # Test cases
    cases = {}

    # Case 1
    # Test with only_tags = ['tag1', 'tag2'] and skip_tags = ['tag3', 'tag4']
    # and the task only has tag1 and tag2 but does not have tag4
    # and the tag 'never' for the task
    # expected result : True

# Generated at 2022-06-11 11:05:33.193558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    with TestTaggable() as t:
        # Test 1
        t.tags = ['foo','bar','baz']
        assert t.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}), 'should have evaluated to True'

        # Test 2
        t.tags = ['foo','bar','baz']
        assert t.evaluate_tags(only_tags=['foo','bar'], skip_tags=[], all_vars={}), 'should have evaluated to True'

        # Test 3
        t.tags = ['foo','bar','baz']
        assert t.evaluate_tags(only_tags=['foo','bar'], skip_tags=['baz'], all_vars={}), 'should have evaluated to True'



# Generated at 2022-06-11 11:05:48.106415
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True

# Generated at 2022-06-11 11:05:57.921834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    Taggable.untagged = frozenset(['untagged'])

    class TaggableObj:
        _tags = []
        tags = []
        _loader = None
        def __init__(self, _tags = [], tags = []):
            self._tags = _tags
            self.tags = tags

    testObj = TaggableObj()

    # Tasks with no tags
    # Skipping all tasks
    assert (testObj.evaluate_tags(['all'], [], {}) == True)

    # Skipping all tagged tasks
    assert (testObj.evaluate_tags(['tagged'], [], {}) == False)

    # Skipping never and tagged
    assert (testObj.evaluate_tags(['tagged'], ['never'], {}) == False)

    # Run all tasks and skipping tagged

# Generated at 2022-06-11 11:06:07.803395
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("This is a test to see if the Taggable.evaluate_tags() method works correctly")
    obj = Taggable()

    # 1. Test with only_tags and skip_tags both unset
    obj.tags = ["test1","test2","test3"]
    only_tags = False
    skip_tags = False
    all_vars = {}
    should_run = True
    should_run_test = obj.evaluate_tags(only_tags, skip_tags, all_vars)
    if should_run == should_run_test:
        print("Passed test 1")
    else:
        print("Failed test 1")
        print("Should have returned " + str(should_run))
        print("Should have returned " + str(should_run_test))

    # 2. Test with only_tags unset

# Generated at 2022-06-11 11:06:19.026581
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class stub_loader:
        def __init__(self):
            pass

    class stub_taggable(Taggable):
        def __init__(self, loader):
            self._loader = loader

    class stub_vars(dict):
        def __init__(self, dict_):
            dict.__init__(self, dict_)

    class stub_only_tags:
        def __init__(self, list_):
            self.tags = list_

    class stub_skip_tags:
        def __init__(self, list_):
            self.tags = list_

    loader = stub_loader()
    taggable = stub_taggable(loader)
    taggable.tags = ['tag1', 'tag2']
    vars = stub_vars({'tag3': 'tag4'})

# Generated at 2022-06-11 11:06:29.958673
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.utils.display import Display
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    all_vars = dict()
    templar = Templar(loader=None, variables=all_vars)

    # define test cases

# Generated at 2022-06-11 11:06:37.223572
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['server1, server2', 'server3', 'server4, server5,server6']
    skip_tags = ['server1']
    only_tags = ['server2', 'server3']

    class task():
        _variable_manager = None
        _loader = None

    t = task()
    t.tags = tags
    t.evaluate_tags(only_tags, skip_tags, None)
    assert t.tags == ['server1', 'server2', 'server3', 'server4', 'server5', 'server6']
    assert t._tags == ['server1', 'server2', 'server3', 'server4', 'server5', 'server6']

# Generated at 2022-06-11 11:06:48.400436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play


# Generated at 2022-06-11 11:06:58.688986
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class TestClass(Taggable):
        def __init__(self):
            self._loader = DataLoader()
            self.tags = None
            self.name = 'test'

    class TestModule(unittest.TestCase):
        def setUp(self):
            self.class_inst = TestClass()

        def tearDown(self):
            del self.class_inst

        def test_always_tag(self):
            self.class_inst.tags    = ['always']
            self.assertTrue(self.class_inst.evaluate_tags(None, None, {}))

# Generated at 2022-06-11 11:07:08.083482
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Taggable_mock(Taggable):
        def __init__(self):
            self.tags = []

    taggable_mock = Taggable_mock()
    taggable_mock.tags = ['a', 'b', 'c']


# Generated at 2022-06-11 11:07:18.895241
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = dict()
    taggable = Taggable()
    all_vars["foo"] = "baz"
    assert taggable.evaluate_tags(["foo", "bar"], [], all_vars)
    assert taggable.evaluate_tags(["foo", "bar"], [], all_vars)
    taggable.tags = ["foo", "bar"]
    all_vars["foo"] = "foo"
    assert taggable.evaluate_tags(["foo", "bar"], [], all_vars)
    assert taggable.evaluate_tags(["foo", "bar"], [], all_vars)
    assert taggable.evaluate_tags(["bar"], [], all_vars)
    assert taggable.evaluate_tags([], [], all_vars)
    tagg

# Generated at 2022-06-11 11:07:57.174426
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockItem(Taggable):
        def __init__(self, tags):
            self._tags = tags

    mock_item = MockItem(['tag1', 'tag2'])
    assert mock_item.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) == True
    assert mock_item.evaluate_tags(only_tags=['tag1', 'tag3'], skip_tags=[], all_vars={}) == False
    assert mock_item.evaluate_tags(only_tags=['tag1'], skip_tags=['tag1'], all_vars={}) == False
    assert mock_item.evaluate_tags(only_tags=[], skip_tags=['tag1', 'tag2'], all_vars={}) == False
    assert mock_item

# Generated at 2022-06-11 11:08:09.128363
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class task(Taggable):
        pass
    t = task()
    t.tags=['test_tag']
    assert t.evaluate_tags(['test_tag'], [], {'tags': []})
    assert not t.evaluate_tags(['test_tag'], [], {'tags': ['test_tag']})
    assert t.evaluate_tags(['all','always'], ['never','never'], {'tags': ['test_tag']})
    assert t.evaluate_tags(['all'], ['never'], {'tags': ['never']})
    assert not t.evaluate_tags(['never'], ['never'], {'tags': ['never']})
    assert t.evaluate_tags(['all'], [], {'tags': ['never']})

# Generated at 2022-06-11 11:08:17.583101
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # evalute_tags(only_tags, skip_tags, all_vars)
    # return True or False
    import nose
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role


# Generated at 2022-06-11 11:08:27.816081
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    hosts = [Host(name="host1.example.org", port=22), Host(name="host2.example.org", port=22)]
    one_host = [Host(name="host1.example.org", port=22)]

    variables = {
        "test_var": "foo",
        "test_list": [1, 2, 3, 4],
        "test_dict": {"x": "X", "y": "Y", "z": "Z"}
    }

    play_context = PlayContext()

    vars_manager = Variable

# Generated at 2022-06-11 11:08:38.656138
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:08:50.446007
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test that only_tags and skip_tags when specified as a list of strings behave the same way,
    # independently of the order of the strings in the list

    def test_list(tags, only_tags_list, skip_tags_list):
        # Test that only_tags and skip_tags behave the same way when specified as a list of strings
        # independently of the order of the strings in the list
        for only_tags_str in only_tags_list:
            for skip_tags_str in skip_tags_list:
                only_tags = only_tags_str.split(',')
                skip_tags = skip_tags_str.split(',')
                t = Taggable()
                t.tags = tags.split(',')

# Generated at 2022-06-11 11:08:57.540880
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    An example test that is run to validate behavior of class Taggable.
    This is method used by unit tests. Please change when class Taggable changes.
    '''
    # Mock ansible module
    class Module:
        def __init__(self, task_name, task_tags):
            self.task_name = task_name
            self.task_tags = task_tags
    # Create sample tasks to test
    class Task(Taggable):
        def __init__(self, data, task_name, task_tags):
            self._ds = data
            self._loader = None
            self.task_name = task_name
            self.tags = task_tags

    # Initialize test cases
    #                   only_tags               task_name    task_tags                               should_run?

# Generated at 2022-06-11 11:09:08.540623
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # This is a quick and dirty unit test for evaluate_tags method of class Taggable

    # Tasks
    task_1 = dict(tags=['always'])
    task_2 = dict(tags=['never'])
    task_3 = dict(tags=['test'])
    task_4 = dict(tags=['test', 'devel'])
    task_5 = dict(tags=['test', 'never'])
    task_6 = dict(tags=['test', 'never', 'always'])
    task_7 = dict(tags=[])

    # Variables for templating
    all_vars = dict()

    # Tag options
    only_tags = []
    skip_tags = []
    only_tags_1 = ['all']
    only_tags_2 = ['test', 'devel']
    only

# Generated at 2022-06-11 11:09:17.900129
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import types
    import sys
    sys.path.insert(0,"..")
    from ansible.playbook.task import Task
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    tags = ['tag1', 'tag2']
    tags1 = ['tag1']

    only_tags = ['tag2']
    skip_tags = ['tag1']
    tagged = ['tagged']
    all = ['all']
    never = ['never']
    always = ['always']
    always_skip = ['always', 'tag1']

    context = PlayContext()

    t = Task()
    t.tags = tags

# Generated at 2022-06-11 11:09:25.753906
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    For now only the method evaluate_tags is tested.
    """
    from ansible.inventory.host import Host
    from ansible.playbook import Playbook
    from ansible.template import Templar

    play = Playbook()
    play._loader = play._loader._loader
    play._basedir = '.'
    play._vars_plugins = []
    host = Host(name='localhost')
    host.play = play
    host.vars = dict(ansible_connection='local')
    play.inventory.add_host(host)
    play.set_variable_manager(play.inventory.get_variable_manager())

    all_vars = play.get_variable_manager().get_vars(host=host)

    templar = Templar(loader=play._loader, variables=all_vars)

    #