

# Generated at 2022-06-11 11:00:21.132421
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    C.DEFAULT_HOST_LIST = 'localhost'

    class Playbook(PlaybookBase):
        pass
    pb = Playbook()
    loader = DataLoader()
    tqm = TaskQueueManager(loader=loader)

    p = PlayContext(play=pb, telemetry_enabled=False)

# Generated at 2022-06-11 11:00:30.207027
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass

    # default should be True
    mock_taggable = MockTaggable()
    assert mock_taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    # no only or skip tags, should run
    mock_taggable = MockTaggable(tags=['a', 'b'])
    assert mock_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars=None)

    # only tags that don't match
    mock_taggable = MockTaggable(tags=['a'])
    assert not mock_taggable.evaluate_tags(only_tags=['c'], skip_tags=None, all_vars=None)

    # only tags that match

# Generated at 2022-06-11 11:00:39.049651
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Check for both empty lists
    only_tags = []
    skip_tags = []
    all_vars = dict()

    # Make a new task with tags: ansible, always
    task = Task()
    task.tags = ['ansible', 'always']

    # Check that the task should run
    assert task.evaluate_tags(only_tags, skip_tags, all_vars)

    # Make a new task with tags: ansible, never
    task = Task()
    task.tags = ['ansible', 'never']

    # Check that the task should not

# Generated at 2022-06-11 11:00:49.392960
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self):
            super(TaggableTest, self).__init__()
            try:
                self._loader = self.get_loader()
            except Exception as e:
                raise AnsibleError("Need to specify loader when using TaggableTest, error was: %s" % to_text(e))

    t = TaggableTest()

    only_tags = ['tag1', 'tag2']

    skip_tags = ['tag3', 'tag4']

    # tags not defined
    try:
        print("Tags undefined")
        t.evaluate_tags(only_tags, skip_tags, [])
    except Exception as e:
        assert to_text(e) == "tags must be specified as a list"
    print("OK")

    # evaluate_tags

# Generated at 2022-06-11 11:01:00.825839
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    templar = Templar(loader=None, variables={})
    taggable = Taggable()
    
    taggable._loader = None
    taggable._ds = {'tags': ['tag1']}
    taggable.tags = taggable._load_tags('tags', taggable._ds['tags'])
    taggable.evaluate_tags(['tag1'], [], templar.template(None))
    assert taggable.tags == ['tag1']

    taggable._ds = {'tags': ['tag1', 'tag2']}
    taggable.tags = taggable._load_tags('tags', taggable._ds['tags'])
    taggable.evaluate_tags(['tag1', 'tag2'], [], templar.template(None))
    assert tagg

# Generated at 2022-06-11 11:01:08.951197
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Dummy_Taggable(Taggable):
        def __init__(self, tags, all_vars):
            self.tags = tags
            self.item1 = self
            self.item2 = self
            self.all_vars = all_vars
            super(Dummy_Taggable, self).__init__()

        def get_ds(self):
            return None

    only_tags = "a, b".split(',')
    skip_tags = "c, d".split(',')

    taggable_object_1 = Dummy_Taggable(None, {'ansible_start_time': '20150722101818.160749'})

# Generated at 2022-06-11 11:01:19.924342
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags_obj = Taggable()
    tags_obj.tags = ['tag1', 'tag2']
    tags_obj.only_tags = ['tag1']
    tags_obj.skip_tags = ['tag2']
    tags_obj.all_vars = {'var1': 'val1', 'var2': 'val2'}

    # Check for tags that we need to run
    assert tags_obj.evaluate_tags(tags_obj.only_tags, tags_obj.skip_tags, tags_obj.all_vars)

    tags_obj.tags = ['tag3', 'tag4']
    # Check for tags that we need to skip
    assert not tags_obj.evaluate_tags(tags_obj.only_tags, tags_obj.skip_tags, tags_obj.all_vars)


# Generated at 2022-06-11 11:01:29.989450
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create an instance of class Taggable
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import Ans

# Generated at 2022-06-11 11:01:41.816808
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
   import ansible.parsing.dataloader
   from ansible.playbook.task_include import TaskInclude
   from ansible.playbook.block import Block
   from ansible.playbook.play import Play
   from ansible.inventory.manager import InventoryManager
   from ansible.vars.manager import VariableManager

   fake_loader = DictDataLoader(dict())
   fake_inventory = InventoryManager(loader=fake_loader, sources='')
   fake_variable_manager = VariableManager()

   # standard case with no tags
   play_source =  dict(
       name = "Ansible Play",
       hosts = 'localhost',
       gather_facts = 'no',
       tasks = [
         dict(action=dict(module='setup', args=dict()))
       ]
   )
   play = Play().load

# Generated at 2022-06-11 11:01:52.036733
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
	test_only_tags_0 = ['tag_1', 'tag_2']
	test_only_tags_1 = ['all']
	test_only_tags_2 = ['tagged']
	test_only_tags_3 = ['tag_1', 'tag_2', 'tagged']
	test_only_tags_4 = ['all', 'tag_1', 'tag_2']
	test_only_tags_5 = ['tagged', 'tag_1', 'tag_2']
	test_only_tags_6 = ['all', 'tagged']
	test_only_tags_7 = ['all', 'tagged', 'tag_1', 'tag_2']
	test_only_tags_8 = ['always', 'tag_1', 'tag_2']

# Generated at 2022-06-11 11:02:08.503619
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Default should be True
    assert Taggable().evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    # No matching tag should be False
    assert Taggable().evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=['nothing'], skip_tags=None, all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=['absolutely'], skip_tags=None, all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=['something'], skip_tags=None, all_vars={}) == False

# Generated at 2022-06-11 11:02:19.296074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    # Create task, block and role
    task = Task()
    block = Block()
    role = Role()
    all_vars = {}

    # 1. Test Taggable.evaluate_tags without tags on task, block and role
    # Test only_tags
    only_tags = ["tag1"]
    skip_tags = []
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == False
    assert block.evaluate_tags(only_tags, skip_tags, all_vars) == False

# Generated at 2022-06-11 11:02:20.400612
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO: test
    pass

# Generated at 2022-06-11 11:02:31.899423
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    import pytest
    sys.path.append(".")
    sys.modules['_ansible_test_class'] = pytest.Taggable
    from ansible.plugins.test.modules import _ansible_test_class
    obj = _ansible_test_class()
    
    assert obj.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == False
    assert obj.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={}) == False
    assert obj.evaluate_tags(only_tags=['foo'], skip_tags=['foo'], all_vars={}) == False
    

# Generated at 2022-06-11 11:02:41.478254
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Fake_Taggable(Taggable):
        def __init__(self):
            self._loader = None

    fake_taggable = Fake_Taggable()
    fake_taggable.tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag7','tag8','tag9','tag10']

    only_tags = []
    skip_tags = ['tag5','tag6','tag7','tag8','tag9','tag10']
    all_vars = {}

    should_run = fake_taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run, "Evaluate tags should return True"

    only_tags = ['tag5','tag6','tag7','tag8','tag9','tag10']

# Generated at 2022-06-11 11:02:52.342055
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    block = Block()
    global_tags = ['all', 'tagged', 'untagged']
    local_tags = ['tagged', 'untagged']

    block.all_vars = dict(tags=global_tags)

    block._load_tags = Taggable._load_tags
    block.tags = ['tagged']
    local_tags.extend(block.tags)

    res = block.evaluate_tags(['all'], [], block.all_vars)
    assert res == True

    res = block.evaluate_tags(['all'], ['all'], block.all_vars)
    assert res == False

    res = block.evaluate_tags(['all'], ['untagged'], block.all_vars)
    assert res == False


# Generated at 2022-06-11 11:03:04.136908
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    vars = VariableManager()
    loader = DataLoader()
    inventory = loader.load_from_file('./tests/inventory')

# Generated at 2022-06-11 11:03:08.187935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import test_utils as utils
    from ansible.playbook.task import Task

    def verify_tags_evaluate(tags, only_tags, skip_tags, should_run):
        test_task = Task()
        test_task._load_tags(str(tags), tags)
        test_task.evaluate_tags(only_tags, skip_tags, {})
        utils.fail_on(not should_run, msg="Evaluating tags didn't work as expected. Ending tags are %s" % tags)

    verify_tags_evaluate([], [], [], True)
    verify_tags_evaluate(['tag'], [], [], True)
    verify_tags_evaluate(['tag'], [], ['tag'], False)
    verify_tags_evaluate(['tag'], ['tag'], [], True)
    verify_

# Generated at 2022-06-11 11:03:18.759764
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Setup dummy host
    host = Host('localhost')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python3')
    host.set_variable('ansible_connection', 'local')
    host.set_variable('ansible_ssh_common_args', '-o StrictHostKeyChecking=no')
    host.set_variable('ansible_ssh_executable', '/usr/bin/ssh')
    group = Group('ungrouped')
    group.add_host(host)

    # Setup Base class
    base = Base()
    base._add_host(host, group)

    # Setup Taggable class

# Generated at 2022-06-11 11:03:29.364050
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class TestTaggable(Taggable):
        pass

    class TestEvaluateTags(unittest.TestCase):

        instance = TestTaggable()

        # test only_tags
        def test_only_tags(self):
            # given
            self.instance.tags = frozenset(['run'])
            only_tags = set(['run'])
            skip_tags = set(['never'])

            # when
            result = self.instance.evaluate_tags(only_tags, skip_tags, {})

            # then
            self.assertTrue(result)

            # given
            self.instance.tags = frozenset(['always'])
            only_tags = set(['run'])
            skip_tags = set(['never'])

            # when
            result = self

# Generated at 2022-06-11 11:03:52.669354
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableTest(Taggable):
        pass

    only_tags = ['tag1']
    skip_tags = ['tag2', 'tag3']
    all_vars = dict()

    test_obj = TaggableTest(tags=['tag1', 'tag4'])
    should_run = test_obj.evaluate_tags(only_tags, skip_tags, all_vars)
    print('should_run = ' + str(should_run))
    assert should_run

    test_obj = TaggableTest(tags=['tag2', 'tag4'])
    should_run = test_obj.evaluate_tags(only_tags, skip_tags, all_vars)
    print('should_run = ' + str(should_run))
    assert should_run == False

    test_obj = Tagg

# Generated at 2022-06-11 11:04:03.561317
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyInclude(Taggable):
        def __init__(self, tags = None):
            super(DummyInclude, self).__init__()
            self.tags = tags

    # Only match tags if it is a subset of included tags
    test_scenario(DummyInclude(), [], [], [], True)
    test_scenario(DummyInclude(['tagged']), [], [], ['tagged'], True)
    test_scenario(DummyInclude(['tagged']), [], [], ['tagged', 'tagged1'], False)
    test_scenario(DummyInclude(['tagged']), [], [], ['tagged1'], False)

# Generated at 2022-06-11 11:04:14.825964
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ds = dict(tags=['test1','test2','test3'])

    t = Taggable()
    t._ds = ds
    t._load_ds()

    assert t._ds['tags'] == ds['tags']

    only_tags = ['test1','test2']
    skip_tags = []
    all_vars = {}

    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['test1','test2','test4']
    skip_tags = []
    all_vars = {}

    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['test1','test2']
    skip_tags = ['test3']
    all_vars = {}


# Generated at 2022-06-11 11:04:25.458884
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    import ansible.constants as C
    from ansible.vars.manager import VariableManager

    task1 = Task()
    task1._role = None
    task1._loader = None
    task1.action = 'get_url'
    task1.set_loader(task1._loader)
    task2 = Task()
    task2._role = None
    task2._loader = None
    task2.set_loader(task2._loader)
    task2._attributes = task1._attributes.copy()
    task2.action = 'debug'
    task1.tags = ['test']
    task2.tags = []
    vm = VariableManager()
    vm.set_inventory(VarsInventory())

    # Test only tags.

# Generated at 2022-06-11 11:04:36.207750
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host = ""

    task = TaskInclude()
    task.tags = ['tag1', 'tag2']

    only_tags = []
    skip_tags = []
    result = task.evaluate_tags(only_tags, skip_tags, loader)
    assert(result)

    only_tags = ['tag3']
    skip_tags = []
    result = task.evaluate_tags(only_tags, skip_tags, loader)
    assert(not result)

    only_tags = ['tag2']
    skip_tags = []
    result = task.evaluate_tags(only_tags, skip_tags, loader)
    assert(result)


# Generated at 2022-06-11 11:04:47.762904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.module_utils.six.moves import StringIO
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.playbook.included_file import IncludedFile
    import copy

    display = Display(verbosity=3, log_only=None, log_path='/dev/null')

    task_ds = dict(
        action='shell',
        args='ls',
        register='shell_out'
    )
    task = IncludedFile(
        play=None,
        path=dict(
            name='include',
            role=None,
            collection_list=None
        ),
        loader=None,
        variable_manager=None,
        task_include=None
    )

    # The following test plays just check the inclusion of a task based

# Generated at 2022-06-11 11:04:56.795100
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    play = Play()
    handler_block = Handler()
    role_block = Role()
    task_block = Task()
    untagged = frozenset(['untagged'])

    play._loader = None
    handler_block._loader = None
    role_block._loader = None
    task_block._loader = None

    handler_block._parent = play
    role_block._parent = play
    task_block._parent = role_block

    play._only_tags = []
    play._skip_tags = []
    play._tags = []
    play._vars_prompt = {}

# Generated at 2022-06-11 11:05:07.728979
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Import libs
    import os
    import sys
    import unittest

    from ansible.errors import AnsibleError
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar



    # Load module
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    class Taggable2(object):

        untagged = frozenset(['untagged'])

        def _load_tags(self, attr, ds):
            if isinstance(ds, list):
                return ds
            elif isinstance(ds, string_types):
                value = ds.split(',')
               

# Generated at 2022-06-11 11:05:17.318466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Test1(Taggable):
        __metaclass__ = Taggable

    class Test2(Taggable):
        __metaclass__ = Taggable

    class Test3(Taggable):
        __metaclass__ = Taggable
    
    # Test1.tags = None
    Test2.tags = ['tag1', 'tag2']
    Test3.tags = ['tag1', 'tag2', 'tag3', 'tag4']

    # Test1.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], {})
    # (False, None, None)

    Test2.evaluate_tags(['tag1', 'tag2'], [], {})  # (True, ['tag1', 'tag2'], None)

# Generated at 2022-06-11 11:05:20.914375
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import logging
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    def mock_defined_tags():
        return ['when_green', 'when_blue', 'when_purple']

    class MockModuleLoader:
        @staticmethod
        def add_directory(path):
            logging.debug('add_directory %s', path)
        @staticmethod
        def get(module_name, *args, **kwargs):
            logging.debug('get %s %s %s', module_name, args, kwargs)
            return [module_name, args, kwargs]


# Generated at 2022-06-11 11:05:57.079784
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest2 as unittest

    the_tags = [ 'tag1', 'tag2', 'tag3' ]

    class TaggableObject(object):

        _loader = None
        tags = the_tags

        def __init__(self, loader):
            self._loader = loader

        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return super(TaggableObject, self).evaluate_tags(only_tags, skip_tags, all_vars)

    taggable = Taggable()
    taggableObject = TaggableObject(taggable)

    # default, tasks to run
    should_run = taggableObject.evaluate_tags([], [], {})
    assert should_run == True

    # Check for only_

# Generated at 2022-06-11 11:06:07.033379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Obj(Taggable):
        tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)

    # untagged should always run
    assert Obj(tags=[]).evaluate_tags(only_tags=[], skip_tags=['never'])
    assert Obj(tags=[]).evaluate_tags(only_tags=[], skip_tags=['all'])
    assert Obj(tags=[]).evaluate_tags(only_tags=[], skip_tags=['tagged'])

    # try some only_tags
    assert Obj(tags=['foo']).evaluate_tags(only_tags=['foo'], skip_tags=['never'])
    assert Obj(tags=['foo', 'bar']).evaluate_tags(only_tags=['foo', 'bar'], skip_tags=['never'])

# Generated at 2022-06-11 11:06:18.029037
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass
    testInstance = TestClass()

    # There are no only_tags and no skip_tags so all tasks should run
    # Verify
    testInstance.tags = ['always']
    assert testInstance.evaluate_tags(only_tags=None, skip_tags=[], all_vars={}) == True
    testInstance.tags = ['tag1']
    assert testInstance.evaluate_tags(only_tags=None, skip_tags=[], all_vars={}) == True
    testInstance.tags = ['never']
    assert testInstance.evaluate_tags(only_tags=None, skip_tags=[], all_vars={}) == True

    # All tasks are skipped, because skip_tags contains 'all'
    # Verify
    testInstance.tags = ['always', 'tag1']
    assert test

# Generated at 2022-06-11 11:06:29.276268
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Unit test for method evaluate_tags of class Taggable
    '''
    # Tasks with different tags that can be used to test
    task1 = {u'name'     : u'This task should run',
             u'tags'     : [u'run_this_task', u'run_these_tasks','run_all_tasks'],
            }
    task2 = {u'name'     : u'This task should also run',
             u'tags'     : [u'run_this_task', u'run_that_task'],
             }
    task3 = {u'name'     : u'This task should not run',
             u'tags'     : [u'skip_this_task', u'skip_that_task'],
             }

# Generated at 2022-06-11 11:06:34.004484
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test whether evaluate_tags() can handle various only_tags and skip_tags options
    """
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    class MyTask(Task, Taggable):
        pass

    class MyPlay(Play, Taggable):
        pass

    class MyRole(Role, Taggable):
        pass

    # initialize a fake self object for test purpose
    mytask = MyTask()
    mytask._attributes['tags'] = 'one, two, three'
    myplay = MyPlay()
    myplay._attributes['tags'] = 'one, two, three'
    myrole = MyRole()
    myrole._attributes['tags'] = 'one, two, three'

    # test task

# Generated at 2022-06-11 11:06:44.603487
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext

    # Test only with tags
    # No tags, no only_tags, should run
    test_obj = Conditional()
    test_obj._tags = set()
    assert test_obj.evaluate_tags(only_tags=[], skip_tags=[]) == True, 'No tags, no only_tags, should run'

    # No tags, no only_tags, should run
    test_obj._tags = set()
    assert test_obj.evaluate_tags(only_tags=None, skip_tags=None) == True, 'No tags, no only_tags, should run'

    # No tags, only tagged, should not run
    test_obj._tags = set()

# Generated at 2022-06-11 11:06:55.700332
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTask(object):
        def __init__(self):
            self.tags = ['tag1']

    task = FakeTask()
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], ['tag2'], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], ['tag1'], {}) == False

# Generated at 2022-06-11 11:07:05.108771
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert Taggable().evaluate_tags(None, None, None)
    assert Taggable().evaluate_tags([], [], None)

    assert not Taggable().evaluate_tags(['foo'], [], None)
    assert Taggable().evaluate_tags(['foo'], ['foo'], None)
    assert not Taggable(tags=['foo']).evaluate_tags(['foo'], ['foo'], None)
    assert Taggable(tags=['foo']).evaluate_tags(['foo'], [], None)
    assert Taggable(tags=['foo']).evaluate_tags([], ['foo'], None)
    assert Taggable(tags=['foo']).evaluate_tags(None, ['foo'], None)

# Generated at 2022-06-11 11:07:15.309402
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude

    # Evaluate tags with no tag options
    task = TaskInclude()
    task.tags = ['always']
    result = task.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert result is True

    task = TaskInclude()
    task.tags = ['never']
    result = task.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert result is False

    task = TaskInclude()
    task.tags = ['foo1', 'foo2', 'foo3']

# Generated at 2022-06-11 11:07:25.733051
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # create a stub class
    class StubClass(Taggable):
        def __init__(self):
            pass

    # create an instance of the stub class
    stub_instance = StubClass()

    # Unit test for a sequence of tags and skip_tags
    # when only_tags is empty
    tags = ['tag1', 'tag2']
    skip_tags = ['tag1']
    only_tags = []
    should_run = stub_instance.evaluate_tags(only_tags, skip_tags, None)
    assert should_run == True

    # Unit test for a sequence of tags and skip_tags
    # when only_tags is not empty
    tags = ['tag1', 'tag2']
    skip_tags = ['tag1']
    only_tags = ['tag2']
    should_run = stub_instance.evaluate_

# Generated at 2022-06-11 11:08:39.034556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # TODO: This should be a true unit test
    class MyTaggable(Taggable):
        tags = ['always', 'one', 'two']

    class MyClass(object):
        def __init__(self, tags, expected):
            self.expected = expected
            self.instance = MyTaggable()
            self.instance.tags = tags

        def __str__(self):
            return str(self.instance.tags)


# Generated at 2022-06-11 11:08:50.723370
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    import sys
    import unittest
    import ansible.playbook
    import ansible.utils
    import ansible.template
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.six import string_types

    # Ansible may be run from anywhere, so we have to reset the global paths to
    # make sure that relative paths used here to load templates and files
    # will work everywhere.
    ansible_path = os.path.dirname(__file__)

# Generated at 2022-06-11 11:09:00.337016
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task

    # Define some Tag Sets
    t_empty = set([])
    t_foo = frozenset(["foo"])
    t_foo_bar = frozenset(["foo", "bar"])
    t_all_always = frozenset(["all", "always"])
    t_all = frozenset(["all"])
    t_tagged = frozenset(["tagged"])
    t_not_tagged = frozenset(["never"])
    t_all_tagged = frozenset(["all","tagged"])

    # Only Tag Set
    ot_empty = None
    ot_tagged = set(["tagged"])
    ot_all = set(["all"])

# Generated at 2022-06-11 11:09:11.027185
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    only_tags = set(["tag1", "tag2"])
    skip_tags = set(["tag3", "tag4"])
    all_vars = dict(foo="bar")

    my_taggable = MyTaggable()

    # not tagged by user, thus it is always tagged
    my_taggable.tags = []
    assert my_taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    my_taggable.tags = ["tag1"]
    assert my_taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    my_taggable.tags = ["tag3"]

# Generated at 2022-06-11 11:09:20.081423
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    only_tags_all = ['all']
    only_tags_tagged = ['tagged']
    only_tags_never = ['never']
    only_tags_always = ['always']
    only_tags_specific = ['specific']
    only_tags_specific_list = [['specific1', 'specific2']]

    skip_tags_all = ['all']
    skip_tags_tagged = ['tagged']
    skip_tags_never = ['never']
    skip_tags_always = ['always']
    skip_tags_specific = ['specific']
    skip_tags_specific_list = [['specific1', 'specific2']]

    all_vars = {}

    debug = Taggable()
    debug.tags = []

# Generated at 2022-06-11 11:09:29.700836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        pass
    ft = FakeTaggable()

    ft.tags = ['always']
    assert ft.evaluate_tags(skip_tags=['never'], only_tags=['tagged'], all_vars={}) == True
    assert ft.evaluate_tags(skip_tags=['all'], only_tags=['tagged'], all_vars={}) == False

    ft.tags = ['never']
    assert ft.evaluate_tags(skip_tags=['tagged'], only_tags=['tagged'], all_vars={}) == True
    assert ft.evaluate_tags(skip_tags=['always'], only_tags=['tagged'], all_vars={}) == False

    ft.tags = ['x', 'y']

# Generated at 2022-06-11 11:09:39.936633
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        pass

    my_taggable = MockTaggable()
    my_taggable.tags = ['tag1', 'tag2']

    # run() with no tags specified at all
    only_tags = list()
    skip_tags = list()
    assert my_taggable.evaluate_tags(only_tags, skip_tags, dict()) is True

    # run() with only_tags specified and no skip_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = list()
    assert my_taggable.evaluate_tags(only_tags, skip_tags, dict()) is True

    # run() with only_tags and skip_tags specified and no tags matched
    only_tags = ['tag1', 'tag2']

# Generated at 2022-06-11 11:09:51.250202
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import copy

    ## Tag with only_tags, should_run == True
    test_block = Block()
    test_block.only_tags = ['block_1']

    test_play = Play()
    test_play.only_tags = ['play']

    test_task = Task()
    test_task.only_tags = ['only_tags']
    test_task.tags = ['foo', 'bar', 'only_tags']
    # Test Task.evaluate_tags() inheritance from play

# Generated at 2022-06-11 11:10:02.021372
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = {}
    class TestTaggableObject(Taggable): pass
    obj = TestTaggableObject()
    only_tags = ['test']
    obj.tags = ['test']
    assert obj.evaluate_tags(only_tags, None, all_vars) == True
    # Nested template with only_tags in nested value
    only_tags = ['nested_test']
    obj.tags = ["nested_test", "nested_test1", ["nested_test", "nested_test1"]]
    assert obj.evaluate_tags(only_tags, None, all_vars) == True
    # Nested template with only_tags in nested value but with skip tags
    only_tags = ['nested_test']
    skip_tags = ['nested_test1']