

# Generated at 2022-06-11 11:00:26.511633
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''test method Taggable.evaluate_tags method'''

    # Sample data for testing evaluate_tags

# Generated at 2022-06-11 11:00:32.314064
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    class TestObj(Taggable):
        def __init__(self):
            pass

    obj = TestObj()
    obj.tags = ['tag1', 'tag2']
    obj.only_tags = set(['tag1', 'tag2'])
    obj.skip_tags = set(['tag3', 'always'])

    # Act
    should_run = obj.evaluate_tags(obj.only_tags, obj.skip_tags, {})

    # Assert
    assert should_run

# Generated at 2022-06-11 11:00:41.321257
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test helper class which just delegates to the method under test
    class EvaluateTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self._attribute_class = None

    # Test case 1:
    # Test if the method returns 'False' if the item attribute 'tags' contains
    # items which are not specified in 'only_tags'.
    # Test case 2:
    # Test if the method returns 'False' if the item attribute 'tags' contains
    # items which are specified in 'skip_tags'.
    # Test case 3:
    # Test if the method returns 'True' if the item attribute 'tags' contains
    # items which are specified in 'only_tags' and the items specified in
    # 'skip_tags'.
    # Test case 4:
    # Test if the method returns 'True

# Generated at 2022-06-11 11:00:52.014112
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = []

    import pytest

    # test_Taggable_evaluate_tags() takes no arguments
    # pylint: disable=no-value-for-parameter

    # TODO: These tests work, but could be way more exhaustive
    # TODO: This is a very simple class with a single method,
    #       should probably use pytest fixtures here.

    taggable = MyTaggable()
    taggable.tags = ['always']
    assert taggable.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={}) is True
    assert taggable.evaluate_tags(only_tags=['always'], skip_tags=['always'], all_vars={}) is False

# Generated at 2022-06-11 11:00:58.297463
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # create mock objects
    loader = object()
    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    # run method with data and assert
    result = (Taggable(loader=loader)
        .evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    )
    assert result

# tests for _load_tags

# Generated at 2022-06-11 11:01:07.934275
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.base
    import ansible.playbook.task

    yaml_string = '''---
        - hosts: localhost
          tasks:
            - name: test debug
              debug:
                msg: "Hello"
              tags:
                - always
                - never
            - name: test debug2
              debug:
                msg: "Hello"
              tags:
                - always
    '''

    # First test with only_tags=None and skip_tags=None
    yaml_data = ansible.utils.parse_yaml(yaml_string)
    assert type(yaml_data) == list
    assert len(yaml_data) == 1
    assert type(yaml_data[0]) == dict
    assert len(yaml_data[0]) == 2

# Generated at 2022-06-11 11:01:18.992310
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys

    sys.path.append("/opt/ansible/lib/ansible")
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext

    fake_ds = namedtuple("ds", "tags")

    pc = PlayContext()
    pc.only_tags = ['all', 'tagged']
    pc.skip_tags = ['never', 'tagged']

    t = Taggable()

    ds = fake_ds(tags=pc.only_tags)
    assert t.evaluate_tags(pc.only_tags, pc.skip_tags, ds) == True

    ds = fake_ds(tags=pc.skip_tags)
    assert t.evaluate_tags(pc.only_tags, pc.skip_tags, ds) == False

    ds = fake_ds

# Generated at 2022-06-11 11:01:22.504126
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeHost(object):
        name = 'fake_host'
        vars = {}

    class FakeVars(object):
        vars = {}

    class FakePlay(Taggable):
        __slots__ = ('tags')

        def __init__(self, play_ds, play_basedir):
            self.tags = ['one', 'two', 'three']

    class FakeTask(Taggable):
        __slots__ = ('tags')

        def __init__(self, play_ds, play_basedir):
            self.tags = ['one', 'two', 'three']

    class FakeBlock(Taggable):
        __slots__ = ('tags')

        def __init__(self, play_ds, play_basedir):
            self.tags = ['one', 'two', 'three']

    fake

# Generated at 2022-06-11 11:01:31.739915
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTask(Taggable):
        def __init__(self):
            self.name = 'MockTask'

    def assert_task_run(task, only_tags, skip_tags, all_vars, expected_result):
        result = task.evaluate_tags(only_tags, skip_tags, all_vars)
        if expected_result != result:
            raise AssertionError('should run flag should be %s for task %s for only_tags: %s, skip_tags: %s' % (expected_result, task.name, only_tags, skip_tags))

    task = MockTask()
    assert_task_run(task, None, None, None, True)
    assert_task_run(task, [], [], None, True)

# Generated at 2022-06-11 11:01:44.438904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest2 as unittest
    try:
        # Ansible < 2.3
        from ansible.playbook.task import Task
    except ImportError:
        # Ansible >= 2.3
        from ansible.playbook.task.task import Task

    mock_task = Task()

    # Test that only_tags
    mock_task.tags = ['foo', 'bar']
    assert mock_task.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})

    # Test that skip_tags
    assert not mock_task.evaluate_tags(only_tags=[], skip_tags=['foo'], all_vars={})

    # Test that only_tags and skip_tags work together

# Generated at 2022-06-11 11:01:59.343018
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    _all_tags = ["1", "2", "3"]
    _skip_tags = ["3"]
    only_tags = ["1"]

    def test_case(tags, expected):
        assert(Taggable().evaluate_tags(only_tags, _skip_tags, {}, tags=tags) is expected)

    test_case([], True)
    test_case(["1"], True)
    test_case(["2"], False)
    test_case(["3"], True)
    test_case(["all"], True)
    test_case(["4", "3"], False)
    test_case(["4", "1"], True)

    # "always" is an exception
    test_case(["always"], True)
    test_case(["always", "3"], True)

# Generated at 2022-06-11 11:02:08.929240
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude

    item = TaskInclude()
    item.tags = ['correct']
    assert item.evaluate_tags(only_tags=['correct'], skip_tags=['wrong'], all_vars={}) is True

    item.tags = ['correct']
    assert item.evaluate_tags(only_tags=['wrong'], skip_tags=['correct'], all_vars={}) is False

    item.tags = ['correct']
    assert item.evaluate_tags(only_tags=[], skip_tags=['wrong'], all_vars={}) is True

    item.tags = ['correct']
    assert item.evaluate_tags(only_tags=['wrong'], skip_tags=[], all_vars={}) is False

    item.tags = ['correct']

# Generated at 2022-06-11 11:02:19.749135
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Thrunk(object):
        def __init__(self, name):
            self.name = name

        def _get_name(self):
            return self.name

    class Task(Taggable):
        _names_to_tags = {
            'foo': [ 'tag1', 'tag2' ],
            'bar': [ 'tag2' ],
            'baz': [ 'tag3' ],
            'nottagged': []
        }

        def __init__(self, name):
            self._loader = Thrunk(name)
            self.tags = self._names_to_tags[name]
            self.name = name

    assert(Task('foo').evaluate_tags(skip_tags=['tag1', 'tag2'], all_vars={}) == False)

# Generated at 2022-06-11 11:02:24.022728
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    for tags in [['always', 'all'], ['untagged'], ['never'], ['never', 'all']]:
        app = TestTaggable(tags=tags)
        assert app.evaluate_tags(only_tags=set(), skip_tags=set()) == True
        assert app.evaluate_tags(only_tags=set(['all']), skip_tags=set()) == True
        assert app.evaluate_tags(only_tags=set(['tagged']), skip_tags=set()) == True
        assert app.evaluate_tags(only_tags=set(), skip_tags=set(['all'])) == False

# Generated at 2022-06-11 11:02:35.686090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Create TaskInclude instance for tests
    loader_mock = None
    play_context_mock = None
    shared_loader_mock = None
    variable_manager_mock = None
    t = TaskInclude(loader=loader_mock, play_context=play_context_mock, shared_loader=shared_loader_mock, variable_manager=variable_manager_mock)

    # Create Templaar instance for tests
    loader_mock = None
    variables = {}
    templar = Templar(loader=loader_mock, variables=variables)

    # Find difference between two lists

# Generated at 2022-06-11 11:02:43.671601
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import collections
    class FakeTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    t = FakeTaggable()
    f = FakeTaggable()
    class FakeVars:
        def __init__(self, v):
            self.vars = collections.defaultdict(lambda: None)
            for i in v:
                self.vars[i] = v[i]
    f.tags = []
    vars = FakeVars({'loopvar1': 'tag1', 'loopvar2': 'tag2'})
    assert (t.evaluate_tags(only_tags=None, skip_tags=None, all_vars=vars) == True)

# Generated at 2022-06-11 11:02:54.885235
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # For method evaluate_tags of class Taggable
    # Tags passed in from the command line are not actually lists, but
    # strings of comma-delimited tags.
    # only_tags passed in should be a list.
    # skip_tags passed in should be a list.
    # all_vars should be a dict, but currently it is passed in as a dict.
    # tags should be a list.
    # The output is a boolean.

    # Test cases
    # pylint: disable=too-many-locals
    class DummyClass(Taggable):
        def __init__(self):
            self.tags = []

    dummy_object = DummyClass()
    only_tags = []
    skip_tags = []
    all_vars = {}
    tags = []
    expected_output = True
   

# Generated at 2022-06-11 11:03:06.284715
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableClass(Taggable):
        pass

    taggable_instance = TaggableClass()
    # Verify tags without tags
    taggable_instance.tags = []
    res = taggable_instance.evaluate_tags(['run'], ['skip'], {})
    assert res is False

    # Verify tags with tags, skip and run only
    taggable_instance.tags = ['tag1', 'tag2']
    res = taggable_instance.evaluate_tags(['run'], ['skip'], {})
    assert res is False

    # Verify tags with tags, skip and run, and the run tag in only_tags
    taggable_instance.tags = ['run', 'tag1', 'tag2']

# Generated at 2022-06-11 11:03:16.191617
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.base import Base

    class Dummy(Base, Taggable):
        _base_class = "Dummy"
        _valid_attrs = Taggable._valid_attrs.copy()
        _valid_attrs.update(Base._valid_attrs)

        def __init__(self, loader, name, data=None):
            self._name = name
            self._loader = loader

    d = Dummy(None, 'd', data={ 'tags': ["tag1"] })
    assert d.evaluate_tags(['tag1'], None, {}) == True
    assert d.evaluate_tags(['tag1'], ['tag1'], {}) == False
    assert d.evaluate_tags(['tag2'], None, {}) == False

# Generated at 2022-06-11 11:03:26.445837
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class SampleTaggable(Taggable):
        pass
    s = SampleTaggable()
    s.tags = ['a', 'b']
    x = s.evaluate_tags(['a'], ['b'], {})
    assert x == True
    x = s.evaluate_tags(['a'], ['c'], {})
    assert x == True
    x = s.evaluate_tags(['c'], ['b'], {})
    assert x == False
    x = s.evaluate_tags(['c'], ['c'], {})
    assert x == False
    x = s.evaluate_tags(['a', 'b'], ['a'], {})
    assert x == True
    x = s.evaluate_tags(['a', 'b'], ['a', 'b'], {})

# Generated at 2022-06-11 11:03:49.378873
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    from ansible.playbook import Play, Playbook
    from ansible.module_utils.six import string_types

    class TaggableTest(Taggable):

        #_tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types,))

        def __init__(self, play):
            self._loader = play._loader
            self._parent = play
            self._play = play
            self._task = None
            self._block = None
            self._role = None
            self._playbook = play._playbook

        def __repr__(self):
            return "<Taggable object>"

    p = Play()
    t = TaggableTest(p)

# Generated at 2022-06-11 11:04:00.311414
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    AnsibleTaskInclude and AnsibleRoleInclude extend Taggable and
    have their own method evaluate_tags. This method
    is tested in unit test test_playbook_evaluate_tags.
    This test should be re-named when Taggable class is removed.
    '''
    from ansible.playbook.include_list import IncludeList
    from ansible.template.template import AnsibleLoader

    t = IncludeList()
    t._loader = AnsibleLoader()

    t.tags = ['a', 'b']
    all_vars = dict()

    # Test 1: empty tags
    only_tags = []
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test 2: no skip or only tags
    only_tags = []


# Generated at 2022-06-11 11:04:04.099177
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockAllVars:
        hostvars = {}

    class MockTaggable(Taggable):
        pass

    my_mock_all_vars = MockAllVars()
    my_mock_taggable = MockTaggable()

    my_mock_taggable.tags = None
    assert my_mock_taggable.evaluate_tags(['a'], [], my_mock_all_vars) == False, 'Taggable.evaluate_tags() should return False'

    my_mock_taggable.tags = ['a']
    assert my_mock_taggable.evaluate_tags(['a'], [], my_mock_all_vars) == True, 'Taggable.evaluate_tags() should return True'


# Generated at 2022-06-11 11:04:15.397570
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars

    class TestTaggable(Taggable):
        def __init__(self, loader, tags=None, task=None, only_tags=None, skip_tags=None, host=None, vars=None):
            self.tags = tags
            self._loader = loader
            self.task = task
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.host = host
            self.vars = vars

        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return super(TestTaggable, self).evaluate_tags

# Generated at 2022-06-11 11:04:25.943448
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' This tests the evaluate_tags method of the class Taggable '''
    import unittest
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role

    class TestTaggable(Taggable, ansible.playbook.task.Task):
        ''' This class provides an object for testing evaluate_tags method of the class Taggable '''

        def __init__(self, tags):
            ''' This method defines a constructor for the class TestTaggable '''
            super(TestTaggable, self).__init__()
            self.tags = tags

    class TestTaggableBlock(Taggable, ansible.playbook.block.Block):
        ''' This class provides an object for testing evaluate_tags method of the class Taggable '''


# Generated at 2022-06-11 11:04:36.826049
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    block = Task()
    assert block.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert block.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == True
    assert block.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == False
    assert block.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == False
    assert block.evaluate_tags(only_tags=['all'], skip_tags=['all', 'tagged'], all_vars={}) == False

# Generated at 2022-06-11 11:04:48.321445
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 1: only_tags, skip_tags and self.tags are empty
    # Expectation: should_run == True
    t = Taggable()
    t.tags = []
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # Case 2: only always is in tags
    # Expectation: should_run == True
    t = Taggable()
    t.tags = ["always"]
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # Case 3a: all is in only_tags
    # Expectation: should_run == True

# Generated at 2022-06-11 11:04:54.864360
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''Taggable method evaluate_tags should be called with tags 
    argument and skip_tags argument'''
    tags = ['foo1', 'foo2', 'foo3']
    skip_tags = ['foo1', 'foo2', 'foo3']
    yml_blk = {}
    yml_blk.update({'tags': tags})
    yml_blk.update({'tags': skip_tags})
    objtaggable = Taggable()
    objtaggable.tags = tags
    assert 'foo1' in objtaggable
    assert 'foo2' in objtaggable
    assert 'foo3' in objtaggable
    assert 'foo1' in objtaggable
    assert 'foo2' in objtaggable
    assert 'foo3' in objtaggable
# Unit Test ends

# Generated at 2022-06-11 11:05:05.930819
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.utils.boolean import boolean
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.script import InventoryScript
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.errors import AnsibleError
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 11:05:15.646653
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host(name="myhost")
    variable_manager = VariableManager()

    play = Taggable()
    play._loader = 'fake_loader'
    play.hosts = [host]
    play.all_vars = {}

    # check whether a task is in the run of a play if it is tagged with all_tags or not
    play.tags = ['all_tags']
    assert play.evaluate_tags(only_tags=['all_tags'], skip_tags=[], all_vars=play.all_vars) == True
    assert play.evaluate_tags(only_tags=[], skip_tags=[], all_vars=play.all_vars) == True
    play.tags = ['some_tags']

# Generated at 2022-06-11 11:05:43.316106
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #TODO
    pass

# Generated at 2022-06-11 11:05:54.180836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test setting
    settings = dict(
        connection = 'smart',
        module_path = None,
        forks=100,
        remote_user='root',
        private_key_file=None,
        ssh_common_args=None,
        ssh_extra_args=None,
        sftp_extra_args=None,
        scp_extra_args=None,
        become=False,
        become_method=None,
        become_user=None,
        verbosity=None,
        check=False,
    )
    t = Taggable()

    # Test case 1: no tags, no run_tags, no skip_tags
    run_tags = None
    skip_tags = None
    all_vars = dict()

# Generated at 2022-06-11 11:06:03.929756
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:06:14.769947
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    class testPlay(Play):
        pass

    play1 = testPlay()

    # Test with just normal tags
    # Test with only one tag
    task1 = Task()
    task1.tags = ['dummy-tag']
    assert task1.evaluate_tags(set(['dummy-tag']), set(), dict()) == True
    assert task1.evaluate_tags(set(['dummy-tag']), set(['dummy-tag']), dict()) == False
    assert task1.evaluate_tags(set(), set(['dummy-tag']), dict()) == False
    assert task1.evaluate_tags(set(['dummy-tag-other']), set(), dict()) == False

# Generated at 2022-06-11 11:06:15.400314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-11 11:06:26.904385
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Setup objects for testing
    task = TaskInclude()

    # set the context for the tasks
    task._play = Play()
    task.all_vars = dict()
    task._play._context = PlayContext()

    # variables required for this test
    task.tags = ['test001','other','tagged']
    only_tags = ['all', 'other']
    skip_tags = []

    # test the evaluate_tags method
    task.evaluate_tags(only_tags, skip_tags, task.all_vars)

# Generated at 2022-06-11 11:06:35.061374
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TaggableClass(Taggable):
        def __init__(self, loader, tags=[]):
            self._loader = loader
            self.tags = tags

    ## test only_tags logic
    should_run = TaggableClass(
        loader=None,
        tags=[]
    ).evaluate_tags(
        only_tags=[],
        skip_tags=[],
        all_vars={}
    )
    assert should_run

    should_run = TaggableClass(
        loader=None,
        tags=['always']
    ).evaluate_tags(
        only_tags=[],
        skip_tags=[],
        all_vars={}
    )
    assert should_run


# Generated at 2022-06-11 11:06:38.675822
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Unit testing of class Taggable and its method evaluate_tags. '''
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:06:49.796012
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self):
            self.tags = None
            self._loader = None
    t = MyTaggable()

    # only_tags and skip_tags are not set
    t.tags = []
    assert(t.evaluate_tags(None, None, {}))
    t.tags = ['a']
    assert(t.evaluate_tags(None, None, {}))

    # only_tags = b
    t.tags = []
    assert(not t.evaluate_tags(set('b'), None, {}))
    t.tags = ['a']
    assert(not t.evaluate_tags(set('b'), None, {}))
    t.tags = ['b']
    assert(t.evaluate_tags(set('b'), None, {}))

# Generated at 2022-06-11 11:07:00.165379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    try:
        from ansible.parsing.dataloader import DataLoader
    except ImportError:
        # Ansible < 2.8
        from ansible.vars import VariableManager
        from ansible.inventory import Inventory
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager

        variable_manager = VariableManager()
        loader = DataLoader()

        inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='tests/inventory')
        variable_manager.set_inventory(inventory)

    class FakeTaggable(Taggable):
        pass

    fake_taggable1 = FakeTaggable()
    fake_taggable1.tags = ['tag1']
    fake_taggable2 = FakeTaggable()


# Generated at 2022-06-11 11:08:12.003930
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    task = Task()
    task.tags = ['1','2','3','4','5','6','7','8','9','10'] 
    task.vars = {'task_tags': '1,2,3,4,5', 'task_tags_2': ['1','2','3','4','5','6','7','8','9','10']}
    play_context.only_tags = ['tagged']
    play_context.skip_tags = ['tagged']
    play_context.tags = {'always'}
    all_vars = task.vars    
    all_vars.update(play_context.vars)
    all_vars.update

# Generated at 2022-06-11 11:08:19.224321
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    def test(tags, only_tags, skip_tags, should_run):
        role = Role()
        role._load_name('myrole')
        block = Block.load(role, [{'block': None}], [], [])
        task = Task.load(block, [{'task': {'tags': tags }}], [], [])
        assert task.evaluate_tags(only_tags, skip_tags, {}) == should_run

    # simple tests
    test(['tag1'], ['tag1'], [], True)
    test(['tag1'], ['tag2'], [], False)

# Generated at 2022-06-11 11:08:30.045431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self):
            self._attributes = {'tags': frozenset(['always'])}

    b = MyTaggable()
    assert b.evaluate_tags(['always'], [], None) == True
    assert b.evaluate_tags([], ['always'], None) == False
    assert b.evaluate_tags(['always'], ['always'], None) == False
    assert b.evaluate_tags([], [], None) == True

    class MyTaggable(Taggable):
        def __init__(self):
            self._attributes = {'tags': frozenset(['never'])}

    b = MyTaggable()
    assert b.evaluate_tags(['never'], [], None) == False
    assert b.evaluate_

# Generated at 2022-06-11 11:08:40.923889
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    script_args = """
---
- include: test1.yml
- include: test2.yml
- include: test3.yml
- include: test4.yml
    tags:
    - always
- include: test5.yml
- include: test6.yml
        """

# Generated at 2022-06-11 11:08:52.051684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test if Taggable.evaluate_tags() works as expected:
      The method has to return True if the task should be executed and False otherwise.
      The decisions depend on the given task tags and on the --skip-tags and --tags options.
      If other options are passed to the method, the test fails.
    '''
    # test data
    class Options:
        skip_tags = "never"
        tags = "tagged"
    class Task:
        tags = None
    # expected results
    results = {}
    results[0] = {}
    results[0]['skip_tags'] = False
    results[0]['tags'] = True
    results[1] = {}
    results[1]['skip_tags'] = True
    results[1]['tags'] = True
    results[2] = {}
   

# Generated at 2022-06-11 11:09:02.535352
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Fake_Taggable(Taggable):
        def __init__(self):
            pass

    def tagged_tag(tag_name):
        return [tag_name]

    # Default: run.
    fake_self = Fake_Taggable()
    fake_self.tags = []
    fake_self.only_tags = []
    fake_self.skip_tags = []
    only_tags = None
    skip_tags = None
    assert fake_self.evaluate_tags(only_tags, skip_tags, {}) is True

    # only_tags: set to ['foo'].
    fake_self = Fake_Taggable()
    fake_self.tags = []
    fake_self.only_tags = []
    fake_self.skip_tags = []
    only_tags = ['foo']
    skip_

# Generated at 2022-06-11 11:09:12.829249
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        skip_tags=[]
        tags = []

    tags = [ 'tag1', 'tag2', 'tag3' ]

    # Test with empty tags, only_tags and skip_tags
    # should run
    test = TestClass()
    test.tags = []
    only_tags = []
    skip_tags = []
    result = test.evaluate_tags(only_tags, skip_tags, None)
    assert result == True, "Expected True, got %s" % result

    # Test with only_tags and no skip_tags
    # should run
    test = TestClass()
    test.tags = []
    only_tags = ['tag2']
    skip_tags = []
    result = test.evaluate_tags(only_tags, skip_tags, None)

# Generated at 2022-06-11 11:09:21.596688
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import PlayBook

    # TODO: test both the case when we are defined in a role
    #       and when we are in a play

    assert PlayBook.evaluate_tags([1,2,3],None) is True
    assert PlayBook.evaluate_tags([1,2,3],["never"]) is False
    assert PlayBook.evaluate_tags([1,2,3],["tagged","all"]) is True
    assert PlayBook.evaluate_tags([1,2,3],["tagged","never"]) is False
    assert PlayBook.evaluate_tags([1,2,3],["tagged","4"]) is False

    assert PlayBook

# Generated at 2022-06-11 11:09:30.527354
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test setup
    from ansible.playbook.play_context import PlayContext
    mytags=['always']
    myonly_tags=['all', 'never']
    myplay_context = PlayContext()
    myplay_context.only_tags = myonly_tags
    myplay_context.skip_tags = []
    myall_vars = dict()

    class MyTaggable(Taggable):
        tags = mytags

    # test execution
    mytask = MyTaggable()
    result = mytask.evaluate_tags(myplay_context.only_tags, myplay_context.skip_tags, myall_vars)

    # test validation
    assert(result == True)

# Generated at 2022-06-11 11:09:40.805685
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    h = Host(name='localhost')
    assert h.evaluate_tags([], [])
    assert h.evaluate_tags([], [], all_vars={'tags': ['foo']})
    assert h.evaluate_tags(['foo'], [], all_vars={'tags': ['foo']})
    assert h.evaluate_tags(['foo'], [], all_vars={'tags': ['foo', 'bar']})
    assert h.evaluate_tags(['foo', 'bar'], [], all_vars={'tags': ['foo', 'bar']})
    assert h.evaluate_tags(['foo', 'bar'], [], all_vars={'tags': ['foo', 'bar', 'never']})