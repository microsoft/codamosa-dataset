

# Generated at 2022-06-11 11:00:22.888406
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Initialize an instance of class Taggable for testing
    obj = Taggable()

    ###################################################################################################################
    # Unit tests for evaluate_tags method with default parameter values
    ###################################################################################################################

    # test case with only_tags = None, skip_tags = None
    tags = ['A','B','C','D']
    only_tags = None
    skip_tags = None
    expected_result = True

    obj.tags = tags
    result = obj.evaluate_tags(only_tags, skip_tags, dict())

    assert result == expected_result

    # test case with only_tags = ['A','B'], skip_tags = None
    tags = ['B','C','D','E']
    only_tags = ['A','B']
    skip_tags = None
    expected_result = True

    obj

# Generated at 2022-06-11 11:00:32.233462
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:00:41.234178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable.evaluate_tags(None, None, {
        'tags': ['always'],
        'only_tags': ['all']
    }) is True

    assert Taggable.evaluate_tags(None, None, {
        'only_tags': ['all']
    }) == Taggable.evaluate_tags(None, None, {
        'tags': ['always'],
        'only_tags': ['all']
    }) == Taggable.evaluate_tags(None, None, {
        'tags': ['all'],
        'only_tags': ['all']
    }) is True


# Generated at 2022-06-11 11:00:51.914598
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    test_taggable = Taggable()

    # Import AnsibleModule object to be able to set data for the test
    from ansible.module_utils.urls import AnsibleModule

    # Create a AnsibleModule object
    test_ansible_module = AnsibleModule('any', 'any', 'any')

    # Set data for the test
    only_tags = ['all']
    skip_tags = ['never']

# Generated at 2022-06-11 11:01:03.209810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test evaluate_tags method of class Taggable
    '''

    # create a test Taggable object
    class TestTaggable(Taggable):
        _valid_tags = ['always', 'never', 'tagged', 'untagged']

        def __init__(self, *args, **kwargs):
            if 'loader' in kwargs:
                self._loader = kwargs.get('loader')
            super(Taggable, self).__init__(*args, **kwargs)

    # test_1
    # test with only_tags = ['all']
    # expect True for tags = []
    # expect True for tags = ['always']
    # expect False for tags = ['never']

# Generated at 2022-06-11 11:01:14.836783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.vars import VariableManager

    class MyTaggable(Taggable):
        _loader = None
        _variable_manager = VariableManager()

    task1 = dict(tags=['t1', 't2'])
    task2 = dict(tags=['t2', 't3'])
    task3 = dict(tags=['t2', 't3', 't4'])
    task4 = dict(tags=['never'])
    task5 = dict(tags=['always'])
    task6 = dict(tags=['t1', 't2', 't3', 't4'])
    task7 = dict(tags=['t2', 'never'])


    obj1 = MyTaggable()
    obj1.tags = task1['tags']
    obj2 = MyTaggable()


# Generated at 2022-06-11 11:01:25.607143
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    import pytest

    def make_test_data(tags):
        if tags is None:
            tags = set()
        return {'tags': list(tags)}

    # the only_tags parameter is only available since 2.1.0
    if not hasattr(Task(), 'only_tags'):
        return


# Generated at 2022-06-11 11:01:33.286026
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    playbook_vars = dict(foo='bar')

    class MyTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # default (no option given, no tags on object)
    my_taggable = MyTaggable(None)
    assert my_taggable.evaluate_tags(['all', 'tagged'], [], playbook_vars) == True
    assert my_taggable.evaluate_tags([], ['all', 'tagged'], playbook_vars) == True

    # default (no option given, tags on object)
    my_taggable = MyTaggable(['tag1'])
    assert my_taggable.evaluate_tags(['all', 'tagged'], [], playbook_vars) == True
    assert my_taggable

# Generated at 2022-06-11 11:01:45.988233
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    blk = Block()
    assert(blk.evaluate_tags(tags='A') == False)
    assert(blk.evaluate_tags(tags='A', only_tags='A') == True)
    assert(blk.evaluate_tags(tags='A', only_tags=['A','B']) == True)
    assert(blk.evaluate_tags(tags='B', only_tags=['A','B']) == True)
    assert(blk.evaluate_tags(tags='C', only_tags=['A','B']) == False)
    assert(blk.evaluate_tags(tags='C', only_tags=['A','B'], skip_tags='A') == False)

# Generated at 2022-06-11 11:01:55.242964
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test class definition
    test_class = type('TestClass', (Taggable,), {})

    # test only_tags and skip_tags with no tags defined
    tc = test_class()
    assert tc.evaluate_tags([], [], {})

    # test only_tags and skip_tags with no tags defined
    tc = test_class()
    assert tc.evaluate_tags(['my_only_tag'], [], {})

    # test only_tags and skip_tags with no tags defined
    tc = test_class()
    assert tc.evaluate_tags([], ['my_skip_tag'], {})

    # test only_tags and skip_tags with no tags defined
    tc = test_class()
    assert not tc.evaluate_tags(['my_only_tag'], ['my_skip_tag'], {})

# Generated at 2022-06-11 11:02:11.713791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    obj = MyTaggable()

    # Avoid problems when tags are not set
    obj.tags = None

    # tags = []
    # only_tags = ['all']
    # skip_tags = []
    # assert obj.evaluate_tags(only_tags, skip_tags) == True
    #
    # tags = []
    # only_tags = ['tagged']
    # skip_tags = []
    # assert obj.evaluate_tags(only_tags, skip_tags) == False
    #
    # tags = []
    # only_tags = ['tagged']
    # skip_tags = ['all']
    # assert obj.evaluate_tags(only_tags, skip_tags) == False
    #
    # tags = []
    # only_tags = ['

# Generated at 2022-06-11 11:02:22.653227
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block

    block = Block()
    block.vars = {}

    # by default, all tags are empty, so the only_tags should be matched.
    only_tags = ['tagged']
    assert block.evaluate_tags(only_tags, [], {})==True
    only_tags = ['all']
    assert block.evaluate_tags(only_tags, [], {})==True

    only_tags = ['tagged', 'tag 1']
    block.tags = ['tag 1']
    assert block.evaluate_tags(only_tags, [], {})==True
    only_tags = ['all', 'tag 1']
    block.tags = ['tag 1']
    assert block.evaluate_tags(only_tags, [], {})==True

    # Add 'never'
    skip_tags

# Generated at 2022-06-11 11:02:34.333417
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    instance = MyTaggable()

    # Check if tags option is working
    all_vars = {'tags': ['foo', 'bar'], 'role_name': 'test_role'}
    instance.tags = ['all', '{{ role_name }}', '{{ tags }}']

    only_tags = {}
    skip_tags = {}
    assert instance.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['foo']
    skip_tags = {}
    assert instance.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = []
    skip_tags = ['foo']

# Generated at 2022-06-11 11:02:42.967860
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_task = Taggable()

    tagged_task = Taggable()
    tagged_task.tags = ['tag1']
    tagged_task.tags = ['tag1']
    tagged_task.tags = ['tag1']
    tagged_task.tags.extend(['tag2'])

    # Test for simple task without any tags and without any tag filters
    assert test_task.evaluate_tags(only_tags = None, skip_tags = None, all_vars = dict()) == True

    # Test for simple task without any tags and with only_tags filter
    only_tags_filters = ["tag1", "tag2", "tag3"]
    assert test_task.evaluate_tags(only_tags = only_tags_filters, skip_tags = None, all_vars = dict()) == False

    # Test for simple task

# Generated at 2022-06-11 11:02:54.139237
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    def assert_run(tags, skip_tags, all_vars, only_tags=None, expect_run=True):
        obj = Taggable()
        obj.tags = tags
        assert obj.evaluate_tags(only_tags or [], skip_tags, all_vars) == expect_run

    # tagged
    assert_run(
        tags=['foo'],
        skip_tags=[],
        only_tags=[],
        all_vars={},
        expect_run=True)

    # not tagged
    assert_run(
        tags=[],
        skip_tags=[],
        only_tags=[],
        all_vars={},
        expect_run=True)

    # tagged, but should not run

# Generated at 2022-06-11 11:03:05.724593
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TAG:
        tags = ['pkg','mysql','percona','centos','redhat','debian','ubuntu','apt','yum','rpm']
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)
    tag = TAG()
    method = getattr(tag, 'evaluate_tags')
    if not method:
        print("Error: method evaluate_tags of class Taggable not found")
        exit(255)
    # default should_run == True
    if not Taggable.evaluate_tags(tag, ['mysql'], [], {}):
        print("Error: method evaluate_tags of class Taggable does not return expected value")
        exit(255)
    # only_tags=

# Generated at 2022-06-11 11:03:15.331754
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Task
    t = Task()
    assert t.evaluate_tags(['always'], [], {})
    assert t.evaluate_tags([], ['never'], {})
    assert t.evaluate_tags(['always'], ['never'], {})
    assert t.evaluate_tags([], [], {})
    assert not t.evaluate_tags([], ['always'], {})
    assert not t.evaluate_tags([], ['tagged'], {})
    assert not t.evaluate_tags([], ['all'], {})
    assert not t.evaluate_tags(['foo'], ['bar'], {})
    # FIXME: magic 'tagged' not present in task.tags
    #assert not t.evaluate_tags(['tagged'], [], {})
    # FIXME: magic 'all

# Generated at 2022-06-11 11:03:25.559195
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestItem(Taggable):
        def __init__(self, tags):
            self.tags = tags

    assert TestItem(['A']).evaluate_tags(only_tags=[], skip_tags=[])
    assert TestItem(['A']).evaluate_tags(only_tags=['A'], skip_tags=[])
    assert TestItem(['A']).evaluate_tags(only_tags=['B', 'C'], skip_tags=[]) == False
    assert TestItem(['A']).evaluate_tags(only_tags=['A', 'B'], skip_tags=[])
    assert TestItem(['A']).evaluate_tags(only_tags=['A', 'B', 'C'], skip_tags=[])

# Generated at 2022-06-11 11:03:35.879136
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # test when no only_tags
    assert t._tags is not None
    assert t._tags == []

    # test when no skip_tags
    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, None) is False

    # test when only_tags is a list of tags
    only_tags = ['tag1']
    skip_tags = ['tag2', 'tag3']
    t._tags = ['tag1']
    assert t.evaluate_tags(only_tags, skip_tags, None) is True

    # test when self.tags is None
    only_tags = ['tag1']
    skip_tags = ['tag2', 'tag3']
    t._tags = None
   

# Generated at 2022-06-11 11:03:44.401379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Unit test for method evaluate_tags of class Taggable
    '''
    only_tags = set(['all','never','always','tagged']) # Default
    skip_tags = set() # Default

    # Default
    test_obj = Taggable()
    test_obj._loader = None
    test_obj.tags = None
    assert test_obj.evaluate_tags(only_tags,skip_tags,{}) == True

    # Case 1: set(['always'])
    test_obj.tags = ['always']
    assert test_obj.evaluate_tags(only_tags,skip_tags,{}) == True

    # Case 2: set(['all'])
    test_obj.tags = ['all']
    assert test_obj.evaluate_tags(only_tags,skip_tags,{}) == True

# Generated at 2022-06-11 11:04:00.239536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['test', 'test2']
    skip_tags = ['test3', 'test4']
    all_vars = {}

    # object is not tagged, meaning 'untagged' is used as value for variable tags
    # since 'untagged' is not part of set only_tags and set skip_tags,
    # method evaluate_tags of class Taggable
    # should return True for variable should_run
    assert Taggable().evaluate_tags(only_tags, skip_tags, all_vars) == True


# Generated at 2022-06-11 11:04:04.019300
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # There is no need to test that True and False is returned as expected
    # in the different cases. This is already tested in test_playbook.py

    # Test that the tag 'all' is ignored if there are no other tags.
    # Test that the tag 'all' has a 'always' tag
    class Test_Taggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    t = Test_Taggable()
    t.tags = ['all']
    t.evaluate_tags(only_tags=[], skip_tags=[], all_vars=None)
    assert t.tags == ['all', 'always']

    # Test that the tag 'all' is ignored if there are no other tags.
    # Test that the tag 'all' has

# Generated at 2022-06-11 11:04:15.295127
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    class Taggable:
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
    '''
    def test(self, only_tags=None, skip_tags=None, all_vars=None, tags=None, expect=None):
        if only_tags is None:
            only_tags = []
        if skip_tags is None:
            skip_tags = []
        if all_vars is None:
            all_vars = dict()
        if tags is None:
            tags = []

        self.tags = tags
        should_run = self.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:04:25.858175
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    tags = ['tag1','tag2','always','never','all','never','tagged']

    tasks = []

    task = Taggable()
    task.tags = tags
    tasks.append(task)

    task = Taggable()
    task.tags = tags
    tasks.append(task)

    for task in tasks:
        results = task.evaluate_tags(only_tags, skip_tags, all_vars)
        assert results == True


    only_tags = []
    skip_tags = ['tag1']
    all_vars = {}
    tags = ['tag1','tag2','always','never','all','never','tagged']

    tasks = []

    task = Taggable()
    task.tags

# Generated at 2022-06-11 11:04:34.152290
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    all_vars = {
                'tag3':'tag3',
                'tag4':'tag4'
               }
    
    # Initialize an instance of class Taggable
    p = Taggable()

    # Test the functionality of method evaluate_tags
    assert p.evaluate_tags(only_tags, skip_tags, all_vars) == True
    assert p.evaluate_tags(only_tags, {}, all_vars) == True
    assert p.evaluate_tags({}, skip_tags, all_vars) == False

# Generated at 2022-06-11 11:04:46.151497
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self):
            self._tags = []

    t = MockTaggable()
    assert t.evaluate_tags(None, None, {})
    t._tags = ['a', 'b']
    assert t.evaluate_tags(None, None, {})
    assert t.evaluate_tags(['b'], ['c'], {})
    assert t.evaluate_tags(['all'], ['c'], {})
    assert t.evaluate_tags(['tagged'], ['c'], {})

    assert not t.evaluate_tags(['a'], ['c'], {})
    assert not t.evaluate_tags(['b', 'c'], ['c'], {})
    assert not t.evaluate_tags(['all'], ['a'], {})

# Generated at 2022-06-11 11:04:53.935369
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    fake_block = Taggable()
    vars = {'foo': 'bar'}

    # test if only_tags=[] and skip_tags=[]
    assert(fake_block.evaluate_tags([], [], vars) == True)
    fake_block.tags = "tag1"
    assert(fake_block.evaluate_tags([], [], vars) == True)

    # test if only_tags is a list
    fake_block.tags = ["tag1", "tag2"]
    assert(fake_block.evaluate_tags(["tag1"], [], vars) == True)
    assert(fake_block.evaluate_tags(["tag2"], [], vars) == True)
    assert(fake_block.evaluate_tags(["tag3"], [], vars) == False)

# Generated at 2022-06-11 11:05:05.013163
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    block1_content = [{"hosts": "host1", "tags":["test"], "tasks": [{"name": "debug", "debug": {"msg": "test"}}]}]
    block2_content = [{"hosts": "host2", "tags":["test"], "tasks": [{"name": "debug", "debug": {"msg": "test2"}}]}]

    host1 = Host(name="host1")

# Generated at 2022-06-11 11:05:14.842180
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:05:25.258353
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # This is only a minimal test, not a full test of the Taggable class

    only_tags = ['only_tag']
    skip_tags = ['skip_tag']
    all_vars = dict()
    t = Taggable()

    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True
    t.tags = ['only_tag']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True
    t.tags = ['skip_tag']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == False
    t._tags = ['not_in_only_tags']
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == False
    t._tags = []


# Generated at 2022-06-11 11:06:01.681214
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    def mock_init(self):
        self.tags = []
        self.untagged = ['untagged']

    # Redefine __init__ of Taggable
    Taggable.__init__ = mock_init

    only_tags = ['new_tag']
    assert Taggable().evaluate_tags(only_tags=only_tags, skip_tags=[], all_vars={})

    skip_tags = ['untagged']
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=skip_tags, all_vars={})

    skip_tags = ['untagged', 'all']
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=skip_tags, all_vars={})

    only_tags = ['tagged']

# Generated at 2022-06-11 11:06:07.948939
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTask(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test for empty tags
    task = MockTask([])
    only_tags = []
    skip_tags = []
    all_vars = {}
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run

    # test for empty only_tags and not empty skip_tags
    task = MockTask(['fake_tag'])
    only_tags = []
    skip_tags = ['fake_tag']
    all_vars = {}
    should_run = task.evaluate_tags(only_tags, skip_tags, all_vars)
    assert not should_run

    # test for not empty only_tags and empty skip_tags
    task

# Generated at 2022-06-11 11:06:19.186057
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) == True
    assert Taggable().evaluate_tags(only_tags=set(), skip_tags=set(['all']), all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=set(['all']), skip_tags=set(), all_vars={}) == True
    assert Taggable().evaluate_tags(only_tags=set(['all']), skip_tags=set(['all']), all_vars={}) == False
    assert Taggable().evaluate_tags(only_tags=set(['foo']), skip_tags=set(), all_vars={}) == False

# Generated at 2022-06-11 11:06:30.090650
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    t = Taggable()

    # Test with no tags at all
    only_tags = None
    skip_tags = None
    result = t.evaluate_tags(only_tags, skip_tags, {})
    assert result is True

    # Test with only_tags only
    only_tags = ['tag1']
    skip_tags = None
    result = t.evaluate_tags(only_tags, skip_tags, {})
    assert result is False

    # Test with no tags at all and only_tags set
    only_tags = ['tag1']
    skip_tags = None
    result = t.evaluate_tags(only_tags, skip_tags, {})
    assert result is False

    # Test with tags that match and only_tags set

# Generated at 2022-06-11 11:06:39.072078
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    play = Play.load(dict(
        name = "test play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="shell", args="echo hello")),
            dict(action=dict(module="shell", args="echo world")),
            ]
        ), loader=None, variable_manager=None)

    # Test that if no tags are specified, then the tasks should be executed
    assert play.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    assert play.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test

# Generated at 2022-06-11 11:06:50.168751
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.role.definition import RoleDefinition

    name = 'test_Taggable_eval_tags'
    role_name = 'foo'
    parent_name = 'bar'

    # tags = ['test','always','never']
    test_case1 = RoleDefinition(
        name=name,
        role_name=role_name,
        parent_name=parent_name,
        tasks=[],
        tags=['test', 'always', 'never']
    )
    # compare with only_tags=['test']
    only_tags1 = set(['test'])
    assert test_case1.evaluate_tags(only_tags=only_tags1, skip_tags=set([]), all_vars={})

    # compare with only_tags=['always']

# Generated at 2022-06-11 11:06:50.786431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True

# Generated at 2022-06-11 11:07:00.905777
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.hosts import Host
    play = Play()
    host = Host('testhost')
    host_vars = dict()
    host_vars['tags'] = ['apache']
    play.add_task(Taggable(), only_tags=['apache'], skip_tags=['mysql'], tags=['apache'], _host=host, _host_vars=host_vars)

# Generated at 2022-06-11 11:07:10.450095
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Mock(Taggable):
        def __init__(self):
            self.tags = None

    taggable = Mock()
    taggable.tags = ['a', 'b']
    assert taggable.evaluate_tags('', '', '')
    assert not taggable.evaluate_tags('', ['a'], '')
    assert taggable.evaluate_tags(['a'], '', '')
    assert taggable.evaluate_tags('', ['a', 'c'], '')
    assert not taggable.evaluate_tags('', ['a', 'b'], '')
    assert taggable.evaluate_tags(['a', 'b'], '', '')
    assert not taggable.evaluate_tags('', ['all'], '')

# Generated at 2022-06-11 11:07:21.088626
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # need to create and insert a loader
    import os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext

    class DummyTask(Taggable):
        def __init__(self, tags):
            self._tags = tags

    dummy_loader = AnsibleLoader(None, 'my_play', True, None)

    class DummyPlay(AnsibleBaseYAMLObject):
        def __init__(self, data):
            self._data = data
            super(DummyPlay, self).__init__()


# Generated at 2022-06-11 11:08:32.466250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.template
    import ansible.vars
    import ansible.utils
    class TestTaggable(Taggable):
        _field_names = Taggable._field_names
        def __init__(self, tags=[]):
            self._fields = Taggable._fields.copy()
            self.tags = tags
            self._loader = None

    # Test the case where there is no tag specified and the only valid tags are
    # always. This should return True
    item = TestTaggable(tags=None)
    should_run = item.evaluate_tags(only_tags=set('always'), skip_tags=set(), all_vars=dict())
    assert should_run is True

    # Test the case where the item has 'never' specified as a tag. This should
   

# Generated at 2022-06-11 11:08:42.804344
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    play1 = Play()
    play1.tags = ["untagged", "always"]
    assert play1.evaluate_tags(["tagged", "all"], [], {}) == True
    play1.tags = ["untagged", "never"]
    assert play1.evaluate_tags(["tagged", "all"], [], {}) == False
    play1.tags = ["untagged"]
    assert play1.evaluate_tags(["tagged", "all"], [], {}) == True
    assert play1.evaluate_tags(["tagged"], [], {}) == False
    assert play1.evaluate_tags([], ["tagged", "all"], {}) == False
    assert play1.evaluate_tags([], ["tagged"], {}) == True

# Generated at 2022-06-11 11:08:53.238430
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.vars = {}

    # replay with nothing to skip and nothing to run, everything should be run
    assert t.evaluate_tags(None, None, {})

    # replay with nothing to skip and only_tags = [], everything should be run
    assert t.evaluate_tags([], None, {})

    # replay with nothing to skip and only_tags = True, everything should be run
    assert t.evaluate_tags(True, None, {})

    # replay with nothing to skip and only_tags = [all], everything should be run
    assert t.evaluate_tags(['all'], None, {})

    # replay with nothing to skip and only_tags = ['all'], everything should be run
    assert t.evaluate_tags(['all'], None, {})

    # replay with skip_tags = [

# Generated at 2022-06-11 11:09:04.322658
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class test(Taggable):
        pass
    
    t = test()
    
    # Default: all items should be executed
    assert t.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None) == True

    # Run only tasks tagged with 'tag1'
    t.tags = []
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars=None) == False
    t.tags = ['tag1']
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars=None) == True
    t.tags = ['tag1', 'tag2']

# Generated at 2022-06-11 11:09:14.209878
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()
    task6 = Task()

    tasks = [task1, task2, task3, task4, task5, task6]
    play = Play()

    play.only_tags = ['tag1', 'tag2']
    play.skip_tags = ['tag3', 'tag4']

    task1.tags = []
    task1.set_loader(None)
    task2.tags = ['tag1']
    task2.set_loader(None)
    task3.tags = ['tag2']
    task3.set_loader(None)

# Generated at 2022-06-11 11:09:22.609478
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play, Playbook
    from ansible.inventory import Host, Inventory
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    inventory = Inventory("/tmp/ansible_test_evaluate_tags")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    # populate variable
    variable_manager._extra_vars = {"var": "value"}
    playbook = Playbook.load("/tmp/ansible_test_evaluate_tags/playbook.yml", variable_manager=variable_manager, loader=None)
    templar = Templar(loader=None, variables=variable_manager.get_vars(play=playbook.get_plays()[0]))

    play = playbook.get_plays()[0]

    # only_tags
    #

# Generated at 2022-06-11 11:09:32.769754
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.parsing.mod_args import ModuleArgsParser

    parser = ModuleArgsParser(
        task_name='ping',
        task_args='',
        task_vars=dict(
            ansible_ssh_host='192.168.100.100',
            ansible_ssh_port=2222,
            ansible_ssh_user='test',
            ansible_ssh_pass='test',
            ansible_verbosity='v=1'
        ),
        loader=None
    )

    # Test the default behaviour with no tags
    t = Taggable()
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars=dict())

    # Test that tags are respected
    t.tags = ['test']

# Generated at 2022-06-11 11:09:43.318032
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Basic test
    tags = ["host1"]

    only_tags = []
    skip_tags = []
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags) == True

    # test only tags
    only_tags = ["host1"]
    skip_tags = []
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags) == True

    # test skip tags
    only_tags = []
    skip_tags = ["host2"]
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags) == True

    # test negative of only tags
    only_tags = ["host2"]
    skip_tags = []
    assert Taggable.evaluate_tags(tags, only_tags, skip_tags) == False

    # test negative of skip tags
   

# Generated at 2022-06-11 11:09:54.706550
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import copy
    from ansible.playbook.base import PlayBase
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    class TestPlay(PlayBase):
        def __init__(self, play_context):
            self._play_context = play_context

    class TestTask(Task):
        def __init__(self, play_context, loader, task_include):
            self._loader = loader
            self._play_context = play_context
            self._task_include = task_include

    class TestTaskInclude(TaskInclude):
        def __init__(self, parent_block, role=None, task_include=None):
            self.parent = parent

# Generated at 2022-06-11 11:10:05.431252
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    # test 1
    taggable.tags = ["tag1", "tag2"]
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars=None)
    # test 2
    taggable.tags = ["tag1", "tag2"]
    assert not taggable.evaluate_tags(only_tags=["tag2"], skip_tags=[], all_vars=None)
    # test 3
    taggable.tags = ["tag1", "tag2"]
    assert not taggable.evaluate_tags(only_tags=["tag3"], skip_tags=[], all_vars=None)
    # test 4
    taggable.tags = ["tag1", "tag2"]