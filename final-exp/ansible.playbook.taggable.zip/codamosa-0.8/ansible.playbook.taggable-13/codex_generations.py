

# Generated at 2022-06-11 11:00:19.434495
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Taggable_mock(Taggable):
        def __init__(self):
            self._tags = []
    o = Taggable_mock()
    only_tags  = []
    skip_tags  = []

    assert o.evaluate_tags(only_tags, skip_tags, {})

    o.tags    = ['untagged']
    assert o.evaluate_tags(only_tags, skip_tags, {})

    o.tags    = ['tag1']
    assert o.evaluate_tags(only_tags, skip_tags, {})

    o.tags    = []
    only_tags = ['tag1', 'tag2']
    assert not o.evaluate_tags(only_tags, skip_tags, {})

    o.tags    = ['tag1']

# Generated at 2022-06-11 11:00:28.704735
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_variables = {}
    test_data = {}

    # setup
    test_playbook = Taggable()
    test_playbook._loader = "fake_loader"
    test_playbook.tags = ['a_tag']

    # test cases
    # always wins
    assert True == test_playbook.evaluate_tags(['always'], [], test_variables)
    assert False == test_playbook.evaluate_tags(['never'], ['always'], test_variables)

    # tagged wins over tags that are not set
    assert True == test_playbook.evaluate_tags(['tagged'], [], test_variables)
    assert False == test_playbook.evaluate_tags(['tagged'], ['tagged'], test_variables)

    # exact tag match
    assert True == test_play

# Generated at 2022-06-11 11:00:37.313048
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    p = Play()
    t = Task()
    t.tags = ['bar']
    t2 = Task()
    t2.tags = ['foo', 'bar']
    p.tasks = [t, t2]

    assert t.evaluate_tags([], [], {})
    assert t2.evaluate_tags([], [], {})

    assert t.evaluate_tags(['bar'], [], {})
    assert t2.evaluate_tags(['bar'], [], {})

    assert t.evaluate_tags(['foo'], [], {}) == False
    assert t2.evaluate_tags(['foo'], [], {})

    assert t.evaluate_tags([], ['bar'], {}) == False

# Generated at 2022-06-11 11:00:47.594806
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    play_context = PlayContext(remote_addr="127.0.0.1", remote_user="test")

    t = Taggable()
    t.tags = ['always', 'test']
    t.vars = {'action': 'test'}

    assert(t.evaluate_tags(['test'], [], loader.load_from_file(play_context.vars_file)) == True)
    assert(t.evaluate_tags(['test'], ['test'], loader.load_from_file(play_context.vars_file)) == False)

# Generated at 2022-06-11 11:00:58.400082
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):        
        def __init__(self, tags):
            self.tags = tags
    mock_taggable = MockTaggable(tags=['ansible_test'])
    only_tags = ['ansible_test']
    skip_tags = None
    all_vars = None
    result = mock_taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True
    only_tags = ['ansible_test']
    skip_tags = ['ansible_test']
    all_vars = None
    result = mock_taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False
    only_tags = None
    skip_tags = ['ansible_test']
    all

# Generated at 2022-06-11 11:01:07.988414
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    import pytest
    class MyTaggable(Taggable):
        def __init__(self, tags, parent, loader):
            self._tags = tags
            self._parent = parent
            self._loader = loader

    # Helper function to test Taggable.evaluate_tags()
    def test_method(taggable, only_tags, skip_tags, is_expected_to_run):
        assert taggable.evaluate_tags(only_tags, skip_tags, {}) == is_expected_to_run

    # #######################################################
    # Helper data for testing Taggable.evaluate_tags()

    my_t

# Generated at 2022-06-11 11:01:18.992633
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.vars import VariableManager

    class FakePlaybook(Base):
        pass

    class FakeTask(Taggable):
        def _init_global_vars(self):
            pass

    playbook_vars = [
        '---',
        'MY_VAR: foo',
    ]
    fake_playbook = FakePlaybook()
    fake_playbook.all_vars = VariableManager(loader=None, variables=playbook_vars)

    fake_task = FakeTask(play=fake_playbook, loader=None)

    fake_task.tags = None
    should_run = fake_task.evaluate_tags(only_tags=None, skip_tags=None, all_vars=fake_playbook.get_variable_manager())
    assert should

# Generated at 2022-06-11 11:01:29.269323
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyClass(Taggable):
        pass

    import json

    class MyVars(dict):

        def __init__(self, data=None):
            if data is None:
                data = {}
            super(MyVars, self).__init__()
            self.update(data)

        def __str__(self):
            return json.dumps(self)

    vars = MyVars({ "my_tags": ["foo", "bar"] })

    # Creates a Taggable object and sets its tags from a simple list
    t = MyClass()
    t.tags = ["foo", "bar"]
    assert t.evaluate_tags(only_tags=["foo"], skip_tags=[], all_vars=vars) is True

    # Creates a Taggable object and sets its tags from a simple string


# Generated at 2022-06-11 11:01:29.799212
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True

# Generated at 2022-06-11 11:01:36.977006
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None

    t = TaggableMock()
    assert t.evaluate_tags(['dummy'], ['dummy'], {}) == True
    assert t.evaluate_tags(['dummy-1'], ['dummy-2'], {}) == True
    assert t.evaluate_tags(['dummy-1', 'dummy-2'], ['dummy-1'], {}) == False

# Generated at 2022-06-11 11:01:53.730980
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestBlock(Taggable):
        def __init__(self):
            self.tags = ["tag1", "tag2"]

    block = TestBlock()

    # case 1: only_tags: ['tag1']; skip_tags: None
    # expected_result: True
    only_tags = ["tag1"]
    skip_tags = None
    all_vars = {}
    result = block.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    # case 2: only_tags: ['tag1']; skip_tags: ['tag_never']
    # expected_result: True
    only_tags = ["tag1"]
    skip_tags = ["tag_never"]
    all_vars = {}

# Generated at 2022-06-11 11:01:59.484770
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    t = Taggable()
    t.tags = ['all','untagged','test','notest','a',1,2,"a,b,c"]
    assert set(t.tags) == set(["all","untagged","test","notest","a",1,2,"a,b,c"])
    #
    # when no tags are specified, all tasks should be run
    #
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    #
    # test 'all' option
    #
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=[ 'a' ], skip_tags=[], all_vars={}) == True
    assert t.evaluate

# Generated at 2022-06-11 11:02:08.979472
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task_vars = dict()

    #
    # Test the Block class
    #
    block = Block()
    block._attributes = dict()
    block._attributes['tags'] = set()
    task_vars = dict()

    assert block.evaluate_tags(set(), set(), task_vars) == True
    assert block.evaluate_tags(set(['foo']), set(), task_vars) == False
    assert block.evaluate_tags(set(), set(['foo']), task_vars) == True
    block._attributes['tags'] = set(['foo'])
    assert block.evaluate_tags(set(), set(), task_vars) == True

# Generated at 2022-06-11 11:02:19.854781
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    class myClass(object):
        def __init__(self, hosts, play, variables, loader, options):
            self.hosts = hosts
            self.play = play
            self.vars = variables
            self.loader = loader
            self.options = options


# Generated at 2022-06-11 11:02:31.383693
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.task import Task

    t1 = Task()
    t1.tags = ["a","b"]

    t2 = Task()
    t2.tags = []

    t3 = Task()
    t3.tags = ["always"]

    # test with empty only_tags
    assert t1.evaluate_tags([],["x"], {})
    assert t2.evaluate_tags([],["x"], {})
    assert t3.evaluate_tags([],["x"], {})

    # test with only_tags = all
    assert t1.evaluate_tags(["all"], [], {})
    assert t2.evaluate_tags(["all"], [], {})
    assert t3.evaluate_tags(["all"], [], {})

    # test with only_tags = a
    assert t1.evaluate_tags

# Generated at 2022-06-11 11:02:41.158038
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    # only_tags=['example'], skip_tags=['undefined']
    t.tags = ['example', 'example2']
    assert t.evaluate_tags(['example', 'example3'], ['undefined'], {'var': 'var'}) == True
    # only_tags=['undefined'], skip_tags=['example']
    assert t.evaluate_tags(['undefined'], ['example'], {'var': 'var'}) == False
    # only_tags=['undefined'], skip_tags=['undefined']
    assert t.evaluate_tags(['undefined'], ['undefined'], {'var': 'var'}) == True
    t.tags = ['undefined']
    # only_tags=['undefined'], skip_tags=['undefined']
   

# Generated at 2022-06-11 11:02:51.986056
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test for a tagged task
    only_list = ['tag1']
    skip_list = []
    tags = ['tag1']
    a = Taggable()
    a._tags = tags
    assert a.evaluate_tags(only_list, skip_list, None), "tagged task should run"

    # test for a tagged task with --skip-tags
    only_list = []
    skip_list = ['tag1']
    tags = ['tag1']
    a = Taggable()
    a._tags = tags
    assert not a.evaluate_tags(only_list, skip_list, None), "tagged task with '--skip-tags=tag1' should not run"

    # test for a task with no tags
    only_list = []
    skip_list = []
    tags = []
    a = Tagg

# Generated at 2022-06-11 11:02:59.246485
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = [ 'tag1', 'tag2' ]
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert t.evaluate_tags(['tag3'], [], {}) == False
    assert t.evaluate_tags(['all', 'tag3'], [], {}) == True


# Generated at 2022-06-11 11:03:08.985251
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest

    # Test when tags is empty and only_tags is all
    assert Taggable().evaluate_tags(['all'], [], {}) is True

    # Test when tags is empty, skip_tags is all
    assert Taggable().evaluate_tags([], ['all'], {}) is False

    # Test when tags is empty and only_tags is tagged
    assert Taggable().evaluate_tags(['tagged'], [], {}) is False

    # Test when tags is empty and skip_tags is tagged
    assert Taggable().evaluate_tags([], ['tagged'], {}) is True

    # Test when tags is not empty, only_tags is empty, skip_tags is empty
    assert Taggable(tags='all').evaluate_tags([], [], {}) is True

    # Test when tags is not empty, only_

# Generated at 2022-06-11 11:03:19.619120
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_item = TestTaggable()

    test_item.tags = ['t1', 't2', 't3']
    assert test_item.evaluate_tags(only_tags=['t2'], skip_tags=[], all_vars={}) is True
    assert test_item.evaluate_tags(only_tags=['t9'], skip_tags=[], all_vars={}) is False
    assert test_item.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) is True
    assert test_item.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) is False

# Generated at 2022-06-11 11:03:40.896745
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class Task(object):
        def __init__(self, tags=[]):
            self._attributes = {}
            self.tags = tags

    task = Task()
    task.tags = ['always']
    assert task.evaluate_tags(['always'], [], {}) == True
    assert task.evaluate_tags(['never'], [], {}) == False
    assert task.evaluate_tags([], [], {}) == True

    task.tags = ['never']
    assert task.evaluate_tags(['always'], [], {}) == False
    assert task.evaluate_tags(['never'], [], {}) == True
    assert task.evaluate_tags([], [], {}) == False

    task.tags = ['always']
    assert task.evaluate_tags([], ['always'], {}) == False

# Generated at 2022-06-11 11:03:50.370192
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Test(Taggable):

        def __init__(self, tags=None):
            self.tags = tags
            self.name = None
            self.description = None
            self.no_log = False

    # set up some test data
    # untagged, but not always
    t1 = Test(tags=['foo'])

    # always
    t2 = Test(tags=['always'])

    # never
    t3 = Test(tags=['never'])

    # tagged
    t4 = Test(tags=[])

    # tagged
    t5 = Test(tags=['foo', 'bar'])

    # tagged
    t6 = Test(tags=['foo', 'never'])

    # tagged
    t7 = Test(tags=['always', 'never'])

    # all
    t8 = Test

# Generated at 2022-06-11 11:04:01.340752
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import pytest

    # input parameters
    _module_name = 'test_module'
    _module_args = 'test_module_args'
    _ds = {
        'module_name': _module_name,
        'module_args': _module_args,
        'tags': ['test_tag']
    }

    # mocks
    class MockTaggable(Taggable):
        def __init__(self, ds):
            self.module_name = ds['module_name']
            self.module_args = ds['module_args']
            self._ds = ds
            self.tags = self._load_tags('tags', self._ds)


# Generated at 2022-06-11 11:04:12.561870
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # check if the items should run or be skipped

    class ExampleTaggable(Taggable):
        def __init__(self):
            self.tags = []

    # check if the items should run or be skipped

    # positive test case
    # test when only_tags, skip_tags and tags
    # are all specified
    item1 = ExampleTaggable()
    item1.tags = ['tag1', 'tag2']
    item1_only_tags = ['tag1', 'tag3']
    item1_skip_tags = ['tag4', 'tag5']
    item1_all_vars = {}
    assert item1.evaluate_tags(item1_only_tags, item1_skip_tags, item1_all_vars) == True

    # negative test case
    # test when only_tags, skip_tags

# Generated at 2022-06-11 11:04:23.300387
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create test class
    class TestClass(Taggable):
        def __init__(self, tags):
            self._tags = tags

    # Cases to test:
    # - tags=[] with only_tags=['all']
    # - tags=['foo'] with only_tags=['all']
    # - tags=['foo'] with only_tags=['foo']
    # - tags=['foo'] with only_tags=['foo','bar']
    # - tags=['foo','bar'] with only_tags=['foo','baz']
    # - tags=[] with skip_tags=['all']
    # - tags=['foo'] with skip_tags=['all']
    # - tags=['foo','all'] with skip_tags=['all']
    # - tags=['foo'] with skip_tags=['foo']


# Generated at 2022-06-11 11:04:29.733773
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    only_tags = ['TESTING']
    skip_tags = []
    all_vars = {}

    obj.tags = only_tags
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)

    obj.tags = []
    assert not obj.evaluate_tags(only_tags, skip_tags, all_vars)

    obj.tags = skip_tags
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)

    obj.tags = ['always']
    assert obj.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-11 11:04:41.410214
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    task = Task(dict(tags=['a','b']))
    assert task.evaluate_tags(['a'], [], dict())
    assert not task.evaluate_tags(['c'], [], dict())
    assert task.evaluate_tags(['all'], [], dict())
    assert task.evaluate_tags([], ['c'], dict())
    assert not task.evaluate_tags(['all'], ['all'], dict())
    assert not task.evaluate_tags([], ['all'], dict())

    task = Task(dict(tags='a'))
    assert task.evaluate_tags(['a'], [], dict())
    assert not task.evaluate_tags(['c'], [], dict())
    assert task.evaluate_tags(['all'], [], dict())
   

# Generated at 2022-06-11 11:04:51.540546
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    t.tags = ['test-tag', 'all', 'never', 'always']
    only_tags = ['test-tag', 'all', 'another-tag']
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, None)
    only_tags = ['test-tag', 'another-tag']
    assert t.evaluate_tags(only_tags, skip_tags, None)
    only_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, None)
    only_tags = ['another-tag']
    assert not t.evaluate_tags(only_tags, skip_tags, None)
    only_tags = ['always']

# Generated at 2022-06-11 11:05:02.190818
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MyTaggable(Taggable):
        pass

    t = MyTaggable()
    t.tags = ['foo', 'bar']
    assert t.evaluate_tags(['foo'], [], {}) == True
    assert t.evaluate_tags(['foo'], ['bar'], {}) == False
    assert t.evaluate_tags(['foo'], ['all'], {}) == False
    assert t.evaluate_tags(['all'], ['foo'], {}) == True if 'always' in t.tags else False
    assert t.evaluate_tags([], [], {}) == True if 'always' in t.tags else False
    assert t.evaluate_tags([], ['all'], {}) == False
    assert t.evaluate_tags([], ['tagged'], {}) == False

# Generated at 2022-06-11 11:05:12.431060
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    from ansible.playbook.play_context import PlayContext

    class MyTaggable(Taggable):
        def __init__(self):
            super(MyTaggable, self).__init__()
            self._loader = None
            self.tags = None
            self._ds = None

    my_obj = MyTaggable()

    # Test case 1:
    # Tags present in play context
    # Tag from task to be executed matches a tag from play context only_tags
    env = dict(ANSIBLE_TAGS='test_tag')
    my_obj.tags = ['test_tag']
    play_context = PlayContext(play=None, options=None, variables={})
    play_context.only_tags = ['test_tag', 'always']
    play_context.skip_tags = []

   

# Generated at 2022-06-11 11:05:50.687018
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_text

    def _yaml_to_ds(data):
        _ds = None
        if isinstance(data, dict):
            _ds = data
        elif data is not None:
            _ds = json.loads(to_text(data, errors='surrogate_then_replace'))
        return _ds

    # variable "only_tags" is a string
    # variable "skip_tags" is a string
    # variable "all_v

# Generated at 2022-06-11 11:06:00.591171
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a simple class that has the method
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
        def evaluate_tags(self, only_tags, skip_tags, all_vars):
            return Taggable.evaluate_tags(self, only_tags, skip_tags, all_vars)

    # By default, a task has no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None) == True

    # Tags can be set from a string
    tt.tags = 'tag1,tag2,tag3'
    assert tt.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None) == True

# Generated at 2022-06-11 11:06:10.613434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class mock_Taggable(Taggable):
        tags = None
        def __init__(self):
            self._loader = None
    # Evaluate tags for an empty tag list
    mock_Taggable.tags = []
    assert mock_Taggable.evaluate_tags([], [], {}) == True
    assert mock_Taggable.evaluate_tags(['tag1'], [], {}) == False
    assert mock_Taggable.evaluate_tags(['tag1', 'tag2'], [], {}) == False
    assert mock_Taggable.evaluate_tags(['all'], [], {}) == True
    assert mock_Taggable.evaluate_tags(['all', 'tag1'], [], {}) == True

# Generated at 2022-06-11 11:06:21.822255
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    global_vars = {
        'name': 'Jason',
        'year': 2017,
        'favorite_color': 'red',
    }

    # Test 1
    # Tags given: ['always']
    # Only_tags given: ['always']
    # Skip_tags given: ['all']
    # Should_run returned: True
    #
    # The scripts will skip all tasks and blocks except ones tagged as always.
    # This command is given 'always' tags, therefore it should run.
    test1_tags = ['always']
    test1_only_tags = ['always']
    test1_skip_tags = ['all']
    test1_should_run = True
    test1 = Taggable()
    test1.tags = test1_tags

# Generated at 2022-06-11 11:06:32.112649
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Base class
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = []
    
    tt = TestTaggable()
    tt._tags = ['always', 'test']

    # Test for only_tags
    only_tags = ['test', 'tagged']
    assert tt.evaluate_tags(only_tags, [], {})
    assert tt.evaluate_tags(only_tags, [], {'foo': 'bar'})
    assert tt.evaluate_tags(only_tags, [], {'tags': 'test'})
    assert tt.evaluate_tags(only_tags, [], {'tags': 'always,test'})
    assert tt.evaluate_tags(only_tags, [], {'tags': 'always,test,baz'})

# Generated at 2022-06-11 11:06:42.340951
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-11 11:06:45.445299
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print (Taggable.untagged)
    print ("test_Taggable_evaluate_tags")


if __name__ == "__main__":
    test_Taggable_evaluate_tags()

# Generated at 2022-06-11 11:06:56.492268
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    task = dict(tags=["always"])
    assert Taggable().evaluate_tags(only_tags=["tagged"], skip_tags=[], all_vars=task) == True
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=["tagged"], all_vars=task) == False
    assert Taggable().evaluate_tags(only_tags=["always"], skip_tags=[], all_vars=task) == True
    assert Taggable().evaluate_tags(only_tags=["always"], skip_tags=["always"], all_vars=task) == False
    assert Taggable().evaluate_tags(only_tags=[], skip_tags=["always"], all_vars=task) == True

# Generated at 2022-06-11 11:07:05.940334
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Mocks needed to instantiate the tested class
    class MockLoader():
        def __init__(self):
            pass
        class _Loader__available_variables():
            pass
    class MockTemplar():
        def __init__(self):
            pass
        def template(self, tags):
            return tags
    mock_loader = MockLoader()
    mock_templar = MockTemplar()
    mock_templar._loader = mock_loader
    mock_templar.variables = {}
    fake_all_vars = {}

    # Data for tests
    taggable = Taggable()
    taggable._loader = mock_loader
    taggable.templar = mock_templar

    tagged = [1,2,3]
    taggable.tags = tagged

    # Exec

# Generated at 2022-06-11 11:07:16.099860
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Play
    from ansible.playbook import Role
    from ansible.playbook import Task
    from ansible.playbook.role.task import Task as RoleTask
    import os

    # test Taggable on class Play

# Generated at 2022-06-11 11:08:27.230360
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert Taggable().evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    assert Taggable(tags=['tag1', 'tag2', 'tag3']).evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True
    assert Taggable(tags=['tag1', 'tag2', 'tag3']).evaluate_tags(only_tags=[], skip_tags=None, all_vars={}) == True
    assert Taggable(tags=['tag1', 'tag2', 'tag3']).evaluate_tags(only_tags=['tag4', 'tag5'], skip_tags=None, all_vars={}) == False
    assert Taggable(tags=['tag1', 'tag2', 'tag3']).evaluate_tags

# Generated at 2022-06-11 11:08:38.069264
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class TaggableTest(Taggable):
        def setUp(self):
            self.Taggable = Taggable()

        def test_all(self):
            self.assertEqual(self.Taggable.evaluate_tags(['all'], [], {}), True)

        def test_tagged(self):
            self.assertEqual(self.Taggable.evaluate_tags(['tagged','test'], [], {}), True)
            self.assertEqual(self.Taggable.evaluate_tags(['tagged'], [], {}), False)
            self.assertEqual(self.Taggable.evaluate_tags(['tagged','test'], [], {'tags': ['test']}), True)

        def test_only_tags(self):
            self.assertE

# Generated at 2022-06-11 11:08:49.929485
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TestTaggable(Taggable):
        pass

    # Test case where only_tags = ['all'], skip_tags = [] and tags = ['a', 'b']
    # Result: True
    test_taggable = TestTaggable()
    test_taggable.tags = ['a', 'b']
    test_taggable.only_tags = ['all']
    test_taggable.skip_tags = []
    assert test_taggable.evaluate_tags(test_taggable.only_tags, test_taggable.skip_tags, None) == True

    # Test case where only_tags = ['all'], skip_tags = [] and tags = ['never', 'b']
    # Result: False
    test_taggable = TestTaggable()

# Generated at 2022-06-11 11:08:58.450724
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook import Playbook
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.tasks import Task

    # test Taggable
    p = Playbook()
    r = Role()
    t = Task()
    b = Base()


# Generated at 2022-06-11 11:09:09.388591
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    t = Task()
    t.tags = ['tag1','tag2']
    t.name = 'Test'
    
    # Test with no skip_tags nor only_tags
    assert t.evaluate_tags(None, None, None)
    # Test with skip_tags but not in tags
    assert t.evaluate_tags(None, set(['skip1','skip2']), None)
    # Test with only_tags and all in it
    assert t.evaluate_tags(set(['all']), None, None)
    # Test with only_tags and always in it
    assert t.evaluate_tags(set(['always']), None, None)
    # Test with only_tags and tagged in it
    assert t.evaluate_tags(set(['tagged']), None, None)


# Generated at 2022-06-11 11:09:18.669915
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import os
    import sys
    import unittest
    import getpass
    import tempfile
    import shutil

    from ansible.parsing.dataloader import DataLoader

    class Dummy(Taggable):
        def __init__(self, tags):
            self.tags = tags

    class TestTaggable(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp(prefix="ansible-test")
            self.cur_user = getpass.getuser()
            self.loader = DataLoader()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-11 11:09:27.352963
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    # create an instance of Taggable and populate attributes
    tagged_item = Taggable()
    tagged_item.tags = ['untagged']
    # evaluate tags based on presence of 'untagged' in tags
    only_tags = ['untagged']
    skip_tags = []
    assert tagged_item.evaluate_tags(only_tags, skip_tags, all_vars=dict()) is True

    tagged_item.tags = ['untagged', 'foo']
    # evaluate tags based on presence of 'untagged' in tags
    only_tags = ['untagged']
    skip_tags = []

# Generated at 2022-06-11 11:09:37.537175
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import module_loader
    from ansible.utils.display import Display

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager

# Generated at 2022-06-11 11:09:48.229555
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a Taggable object
    class MyTaggable(Taggable):
        tags = ['A']
    my_taggable = MyTaggable()

    # Test 1: Test on tags that are skipped
    result = my_taggable.evaluate_tags(only_tags=['B'], skip_tags=['A', 'C'], all_vars={})
    assert result == False, "Test 1 failed."

    # Test 2: Test on tags that are not skipped
    result = my_taggable.evaluate_tags(only_tags=['A', 'B'], skip_tags=['C'], all_vars={})
    assert result == True, "Test 2 failed."

    # Test 3: Test on not tagged

# Generated at 2022-06-11 11:09:59.633531
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import copy
    from ansible.playbook.base import Base, PlaybookBase
    all_vars = dict(
        this_is_a_dict = dict(
            inside = 'foo'
        ),
        this_is_a_list = [ 'a', 'b', 'c' ]
    )
    taggable = Taggable()
    taggable.tags = 'this_is_a_dict.inside'
    assert taggable.evaluate_tags(None, None, all_vars) == False
    assert taggable.tags == ['foo',]
    taggable.tags = 'this_is_a_list'
    assert taggable.evaluate_tags(None, None, all_vars) == False
    assert taggable.tags == ['a', 'b', 'c']
    tagg