

# Generated at 2022-06-11 11:00:26.411182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_object = Taggable()
    taggable_object.tags = ['alias_foobar']

    assert taggable_object.evaluate_tags(set(['alias_foobar']), set(), {}) == True
    assert taggable_object.evaluate_tags(set(['alias_foobar']), set(['alias_foobar']), {}) == False
    assert taggable_object.evaluate_tags(set(['alias_foobar', 'alias_barfoo']), set(), {}) == True
    assert taggable_object.evaluate_tags(set(['alias_foobar', 'alias_barfoo']), set(['alias_foobar', 'alias_barfoo']), {}) == False

# Generated at 2022-06-11 11:00:34.983278
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test 1: with empty all_vars test defaults of all parameters
    class Test1(Taggable):
        tags = []
    t1 = Test1()
    assert t1.evaluate_tags(only_tags=['test'], skip_tags=['test'], all_vars={}) is True

    # Test 2: with empty all_vars and empty list for only_tags and skip_tags
    class Test2(Taggable):
        tags = []
    t2 = Test2()
    assert t2.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is True

    # Test 3: with empty all_vars and list with one elem for only_tags
    class Test3(Taggable):
        tags = []
    t3 = Test3()
    assert t3.evaluate

# Generated at 2022-06-11 11:00:44.840447
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggableClass(Taggable):
        pass

    # 
    mtc = MyTaggableClass()
    #
    only_tags = ['foo']
    skip_tags = ['bar']
    all_vars = {}
    tags = ['foo']
    mtc.tags = tags
    #
    should_run = mtc.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True
    #
    only_tags = []
    skip_tags = ['bar']
    all_vars = {}
    tags = ['foo']
    mtc.tags = tags
    #
    should_run = mtc.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True
    #

# Generated at 2022-06-11 11:00:55.532397
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    mock_Taggable = type('Taggable', (), {})
    assert Taggable.evaluate_tags(mock_Taggable, [], [], {})

    mock_Taggable_only_tags = type('Taggable', (), {})
    mock_Taggable_only_tags.tags = ['only_tags']
    assert Taggable.evaluate_tags(mock_Taggable_only_tags, ['only_tags'], [], {})
    assert not Taggable.evaluate_tags(mock_Taggable_only_tags, [], [], {})
    assert not Taggable.evaluate_tags(mock_Taggable_only_tags, ['skip_tags'], [], {})

    mock_Taggable_skip_tags = type('Taggable', (), {})
    mock_

# Generated at 2022-06-11 11:01:06.056810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class TempClass(Taggable):

        def __init__(self,tags):
            self.tags = tags
            self._loader = None

    test_obj1 = TempClass(["test","test1","test2"])

    # positive test cases
    if test_obj1.evaluate_tags(["test1","test2"],["skip"],""):
        print("Test case positive 1 Passed")
    else:
        print("Test case positive 1 Failed")

    if test_obj1.evaluate_tags(["test1","test2"],["skip"],""):
        print("Test case positive 2 Passed")
    else:
        print("Test case positive 2 Failed")

    if test_obj1.evaluate_tags(["test"],["skip"],""):
        print("Test case positive 3 Passed")

# Generated at 2022-06-11 11:01:17.631454
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_items = dict()

    test_items[0] = dict(item=dict(tags=['A', 'B', 'C']),
                         only_tags=['A', 'B', 'C'],
                         skip_tags=['D'],
                         should_run=True)
    test_items[1] = dict(item=dict(tags=['A', 'B', 'C']),
                         only_tags=['D'],
                         skip_tags=['D'],
                         should_run=False)
    test_items[2] = dict(item=dict(tags=['A', 'B', 'C']),
                         only_tags=['D'],
                         skip_tags=['A', 'B', 'C'],
                         should_run=False)

# Generated at 2022-06-11 11:01:19.536495
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    How to test this method?
    '''
    print('TODO')

# Generated at 2022-06-11 11:01:24.529899
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.plugins.task.debug import Task as Debug
    block = Block()
    debug_task = Debug()
    only_tags = ['always']
    skip_tags = []
    assert debug_task.evaluate_tags(only_tags,skip_tags,{}) == True

# Generated at 2022-06-11 11:01:32.753275
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    should_run = Taggable()
    # default, tasks to run
    assert should_run.evaluate_tags(None, None, None)

    # No tags specified, so no tags to run
    assert not should_run.evaluate_tags(None, ['never'], None)
    assert not should_run.evaluate_tags(['never'], None, None)
    assert not should_run.evaluate_tags(['never'], ['never'], None)

    # Tags specified, match so tags to run
    should_run.tags = 'always'
    assert should_run.evaluate_tags(None, None, None)
    assert should_run.evaluate_tags(['always'], None, None)
    assert should_run.evaluate_tags(['always'], ['never'], None)
    # One of tags specified, match so tags to

# Generated at 2022-06-11 11:01:40.515843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    # test case 1: when only_tag is 'tag1', skip_tag is 'tag2', tag list is [tag1], should_run should be true
    only_tags = ('tag1',)
    skip_tags = ('tag2',)
    t._tags = only_tags
    assert (t.evaluate_tags(only_tags, skip_tags, {}) == True)


# Generated at 2022-06-11 11:01:59.345467
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj1 = Taggable()
    obj1.tags = ['foo', 'bar', 'baz', 'quux']

    only_tags = ['always', 'foo', 'bar']
    skip_tags = ['never', 'quux', 'baz']

    assert(obj1.evaluate_tags(only_tags, skip_tags, {}) is True)

    obj2 = Taggable()
    obj2.tags = ['always', 'foo', 'bar']

    only_tags = ['always', 'foo', 'bar']
    skip_tags = ['never', 'quux', 'baz']

    assert(obj2.evaluate_tags(only_tags, skip_tags, {}) is True)

    obj3 = Taggable()
    obj3.tags = ['never', 'foo', 'bar']


# Generated at 2022-06-11 11:02:08.929389
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Taggable_obj_for_test(Taggable):
        # mock object for test
        tags = []

    test_tags = ['a','b','c','d','e','f','1','2','3','4','5','6','a','b','c','d','e']
    test_only_tags = ['a','b','c','d']
    test_skip_tags = ['e', 'f']
    test_all_vars = ['a', 'b']

    taggable_obj = Taggable_obj_for_test()
    taggable_obj.tags = test_tags
    result = taggable_obj.evaluate_tags(test_only_tags,test_skip_tags,test_all_vars)
    assert result == True


# Generated at 2022-06-11 11:02:19.749238
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class A(Taggable):
        def __init__(self, tags=None):
            self.tags = tags
    a = A()
    assert a.evaluate_tags(only_tags=set(['test']), skip_tags=set(['test2']), all_vars={})
    a = A(tags=['test', 'test2'])
    assert not a.evaluate_tags(only_tags=set(['test']), skip_tags=set(['test2']), all_vars={})
    a = A(tags=['test2'])
    assert not a.evaluate_tags(only_tags=set(['test']), skip_tags=set(['test2']), all_vars={})
    a = A(tags=['test'])

# Generated at 2022-06-11 11:02:23.987779
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test case 1: should run when there is no tags
    t = Taggable()
    assert t.evaluate_tags({},{},{})
    t = Taggable(tags=["tag-1","tag-2"])
    assert t.evaluate_tags({},{},{})
    t = Taggable(tags=["tag-1","tag-2","never"])
    assert not t.evaluate_tags({},{},{})
    t = Taggable(tags=["tag-1","tag-2","never","always"])
    assert t.evaluate_tags({},{},{})

    # test case 2: filter only-tags
    t = Taggable(tags=["tag-1","tag-2"])
    assert t.evaluate_tags({"tag-1"},{},{})
    assert t.evaluate

# Generated at 2022-06-11 11:02:35.633410
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a mock object
    mock_obj = dict(
        tags=['tagged'],
    )

    # Create a mock templar object
    class mock_templar(object):
        def template(self, tags):
            return tags
    templar = mock_templar()
    class mock_loader:
        pass

    # Create a mock Taggable object
    class mock_taggable(Taggable):
        _tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
        def __init__(self):
            super(mock_taggable, self).__init__()
            self._templar = templar
            self._loader = mock_loader

# Generated at 2022-06-11 11:02:43.336392
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    t1 = Task()
    t1.tags = [ 'a', 'b' ]
    assert t1.evaluate_tags([ 'a' ], [ "nonexistent" ], {}) == True
    assert t1.evaluate_tags([ 'nonexistent' ], [ "nonexistent" ], {}) == False
    assert t1.evaluate_tags([ 'a' ], [ "b" ], {}) == False

    t2 = Task()
    t2.tags = [ 'a', 'b' ]
    r1 = Role()
    r1.tags = [ 'a', 'b' ]
    p1 = Play()
    p1.tags = [ 'a', 'b' ]



# Generated at 2022-06-11 11:02:53.280525
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['test']
    assert taggable.should_run(['test'], [], dict()) == True
    assert taggable.should_run([], [], dict()) == True
    assert taggable.should_run([], ['test'], dict()) == False
    assert taggable.should_run([], ['test', 'foo'], dict()) == False
    assert taggable.should_run(['test'], ['test'], dict()) == False
    assert taggable.should_run(['test'], ['foo'], dict()) == True
    assert taggable.should_run(['foo', 'bar'], ['test'], dict()) == False

# Generated at 2022-06-11 11:03:05.063162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # instantiate class
    my_class = Taggable()

    # define play variables
    all_vars = {
        'some_tags': ['tag1', 'tag2'],
        'some_other_tags': ['tag2', 'tag3']
    }

    # define dictionary of test cases

# Generated at 2022-06-11 11:03:13.926276
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test that given only_tags only tagged tasks run
    test_obj = Taggable()
    test_obj.tags = ['test']
    test_result = test_obj.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={})
    assert test_result == True
    test_result = test_obj.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={})
    assert test_result == True
    test_obj.tags = []
    test_result = test_obj.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={})
    assert test_result == False

    # Test that when only_tags is not specified, all tasks run
    test_obj = Taggable()

# Generated at 2022-06-11 11:03:24.352381
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest

    class FakeTaggable(Taggable):
        pass

    taggable = FakeTaggable()

    # no tags defined, nothing to skip, nothing to run
    only_tags = None
    skip_tags = None
    taggable.tags = None

    assert taggable.evaluate_tags(only_tags, skip_tags) == False

    # no tags, nothing to skip, run all
    only_tags = "all"
    taggable.tags = None
    assert taggable.evaluate_tags(only_tags, skip_tags) == True

    # no tags, skip all, run none
    skip_tags = "all"
    taggable.tags = None
    assert taggable.evaluate_tags(only_tags, skip_tags) == False

    # no tags, skip nothing,

# Generated at 2022-06-11 11:03:55.704863
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable:
        pass
    d = DummyTaggable()
    d.tags = ['tag1', 'tag2']
    assert Taggable.evaluate_tags(d, ['tag1', 'tag3'], [], {}) == True
    assert Taggable.evaluate_tags(d, [], ['tag1'], {}) == False
    assert Taggable.evaluate_tags(d, [], [], {}) == True

# Generated at 2022-06-11 11:04:06.845049
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    mytaggable = Taggable()

    # Check that a task with no tags is always executed
    mytaggable.tags = []
    assert mytaggable.evaluate_tags(set(), set(), {}) == True

    # Check that a task with no tags AND skip_tags does not gets executed
    mytaggable.tags = []
    assert mytaggable.evaluate_tags(set(), set(['foo']), {}) == False

    # Check that a task with no tags AND always_run does get executed
    mytaggable.tags = []
    assert mytaggable.evaluate_tags(set(['always']), set(), {}) == True

    # Check that a task with no tags AND never_run does not get executed
    mytaggable.tags = []

# Generated at 2022-06-11 11:04:17.741857
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Unit test for method evaluate_tags of class Taggable
    '''

    # Test case #1: no tags, no only/skip tags
    class TestTaggable_1(Taggable):
        pass
    tt1 = TestTaggable_1()
    assert tt1.evaluate_tags(only_tags = None, skip_tags = None, all_vars = {})

    # Test case #2: no tags, only/skip tags
    class TestTaggable_2(Taggable):
        pass
    tt2 = TestTaggable_2()
    assert not tt2.evaluate_tags(only_tags = ['foo'], skip_tags = ['bar'], all_vars = {})

    # Test case #3: tags, no only/skip tags

# Generated at 2022-06-11 11:04:27.579212
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.attribute import Attribute
    ds = Taggable()
    for attr in ['_tags']:
        setattr(ds, attr, Attribute(name=attr))
    only_tags = ['t1', 't2']
    skip_tags = ['t3', 't4']
    all_vars = dict()

    # test 1
    ds.tags = []
    assert ds.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # test 2
    ds.tags = ['t1']
    assert ds.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # test 3
    ds.tags = ['t3']

# Generated at 2022-06-11 11:04:39.174700
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    test for method evaluate_tags of class Taggable
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    t = Taggable()
    all_vars = combine_vars(loader=loader, variable_manager=variable_manager)

    def _test_tag(tag, only_tags=None, skip_tags=None, should_run=True):
        t.tags = tag
        s = t.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-11 11:04:50.027489
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.template import Templar
    from ansible.playbook.task import Task

    t = Task()
    t._loader  = 'dummy'
    all_vars = dict()
    templar = Templar(loader=t._loader, variables=all_vars)

    print("")
    print("Test case 1")
    # test case with only_tags = ['all'], skip_tags = ['never'], t.tags = ['all']
    only_tags = ['all']
    skip_tags = ['never']
    t.tags = ['all']
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    print("")
    print("Test case 2")
    # test case with only_tags = ['all'], skip_tags = ['never'

# Generated at 2022-06-11 11:04:55.845591
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    Taggable_instance = Taggable()
    Taggable_instance._tags = ['testtag']
    assert Taggable_instance.tags == ['testtag']
    assert Taggable_instance.evaluate_tags(only_tags=['testtag'], skip_tags=[], all_vars={}) == True
    assert Taggable_instance.evaluate_tags(only_tags=[], skip_tags=['testtag'], all_vars={}) == False

# Generated at 2022-06-11 11:05:06.925090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Tests for Taggable.evaluate_tags
    '''

    import ansible.playbook
    import ansible.template
    import ansible.vars
    import copy

    loader = ansible.template.AnsibleTemplate('', {}, shared_loader=False)
    vars = ansible.vars.VariableManager()
    t = ansible.template.Templar(loader=loader, variables=vars)

    obj = Taggable()
    obj._loader = t._loader
    obj._ds = {}
    obj._ds_params = {}

    # No action if no tags are specified for the current task
    assert obj.evaluate_tags(only_tags = set(['foo', 'bar']), skip_tags = set(['baz', 'qux']), all_vars = vars) == True



# Generated at 2022-06-11 11:05:16.425935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create playbook and add a play to it
    from ansible.playbook import PlayBook
    playbook = PlayBook()
    play = playbook._add_play()

    # Add task to play
    from ansible.playbook import Task
    task = Task()
    play._add_task(task)

    # Create object of class Taggable
    class MockTaggable(Taggable):
        pass
    obj = MockTaggable()

    # Populate obj with all required attributes
    obj.tags = ["test", "test2"]
    obj._loader = None

    # Create data structure for method evaluate_tags
    only_tags = ["test2"]
    skip_tags = ["test"]
    all_vars = []

    # Get expected result
    expected = True

    # Call method

# Generated at 2022-06-11 11:05:27.040639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    t = TestTaggable()
    t.tags = ['tag_a','tag_b','tag_c']
    assert t.evaluate_tags(set(['tag_c']), set(['tag_a']), None)
    assert t.evaluate_tags(set(['tag_c']), set(['tag_d']), None)
    assert not t.evaluate_tags(set(['tag_c']), set(['tag_c']), None)
    assert not t.evaluate_tags(set(['tag_d']), set(['tag_a']), None)
    assert not t.evaluate_tags(set(['tag_d']), set(['tag_c']), None)

# Generated at 2022-06-11 11:06:27.742370
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base

    class MyTaggable(Base, Taggable):
        def __init__(self, loader):
            self._loader = loader

    my_taggable = MyTaggable(loader=None)
    my_taggable.tags = ['blue', 'green']

    all_vars = dict()

    # only_tags: no tags set
    # skip_tags: no tags set
    only_tags = None
    skip_tags = None
    assert my_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # only_tags: no tags set
    # skip_tags: empty list
    only_tags = None
    skip_tags = []

# Generated at 2022-06-11 11:06:35.460753
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = ['foo', 'bar', 'baz']

    t = TestTaggable()

    assert t.evaluate_tags(['foo', 'bar'], [], {})
    assert t.evaluate_tags(['foo', 'bar', 'baz'], [], {})
    assert t.evaluate_tags(['foo', 'bar', 'baz', 'qux'], [], {})
    assert t.evaluate_tags([], [], {})
    assert not t.evaluate_tags(['qux'], [], {})
    assert not t.evaluate_tags(['qux', 'foo'], [], {})
    assert not t.evaluate_tags([], ['foo'], {})

# Generated at 2022-06-11 11:06:46.404192
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # This test class is used for testing Taggable.evaluate_tags() method.
    # It mocks the item for which to evaluate tags.

    class Mock_Taggable(Taggable):
        def __init__(self, tags):
            super(Mock_Taggable, self).__init__()
            self._tags = tags

        def __repr__(self):
            return "%s(tags=%r)" % (self.__class__.__name__, self.tags)

        def __str__(self):
            return "%s(tags=%r)" % (self.__class__.__name__, self.tags)

    # Use test cases to test Taggable.evaluate_tags() method in Taggable class.
    # Each test case includes 4 variables:
    #   tags: content of the tags field from

# Generated at 2022-06-11 11:06:57.233787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class DummyTask:
        pass

    dummy_task = DummyTask()
    dummy_task.current_task =  dummy_task
    dummy_task._ds = dict()

    def _load_tags(attr, ds):
        if isinstance(ds, list):
            return ds
        elif isinstance(ds, string_types):
            value = ds.split(',')
            if isinstance(value, list):
                return [x.strip() for x in value]
            else:
                return [ds]
        else:
            raise AnsibleError('tags must be specified as a list', obj=ds)

    dummy_task._ds['tags'] = 'tagged'

    target = Taggable()
    target._ds = dummy_task._ds
    target._load_tags = _load_tags




# Generated at 2022-06-11 11:07:03.453699
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Unit test for method evaluate_tags of class Taggable '''

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3']
    t = Taggable()
    t.tags = ['always']
    play_context = PlayContext()
    play_context._build_tags(only_tags=only_tags, skip_tags=skip_tags)
    assert t.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict())
    t.tags = ['all']
    assert t.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict())
    t.tags = ['never']
    assert not t.evaluate

# Generated at 2022-06-11 11:07:09.043727
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # Test the class 'Play'
    p = Play()
    p._loader = None
    p.all_vars = {}
    assert p.evaluate_tags(['always'], [], {}) is True
    assert p.evaluate_tags(['never'], [], {}) is False
    assert p.evaluate_tags([], ['always'], {}) is False
    assert p.evaluate_tags([], ['never'], {}) is True

    # Test the class 'Task'
    t = Task()
    t._loader = None
    t.all_vars = {}
    t.tags = ['test']

# Generated at 2022-06-11 11:07:19.932723
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    import unittest
    import sys
    import os

    # Fix the current path to be able to import the module
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))

    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.action import Action

    # This test class is a subclass of unittest.TestCase
    class TestTaggable(unittest.TestCase):

        # This method runs once before all tests
        @classmethod
        def setUpClass(self):

            # Create a temporary directory
            import tempfile
            self.tmpdir = tempfile.mkdtemp()

        # This method

# Generated at 2022-06-11 11:07:30.272882
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    play_context.only_tags = set()
    play_context.skip_tags = set()

    block = Block()
    block.only_tags(['tagged'])
    block.skip_tags(['tagged'])
    block.tags = ['tagged']

    assert block.evaluate_tags(play_context.only_tags, play_context.skip_tags, {}) is True
    play_context.only_tags = set(['tagged'])
    assert block.evaluate_tags(play_context.only_tags, play_context.skip_tags, {}) is True
    play_context.only_tags = set(['untagged'])
    assert block.evaluate

# Generated at 2022-06-11 11:07:40.159064
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Tests for the evaluate_tags() method in the Taggable class.
    '''

    class TaggableImpl(Taggable):
        '''
        Minimal implementation of the Taggable class.
        '''

        attrs = dict()

        def __init__(self):
            self._tags = list()

    #
    # Test cases
    #

    taggable = TaggableImpl()
    taggable.tags.append('always')
    assert taggable.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) == True, "Unexpected False for always"

    taggable = TaggableImpl()
    taggable.tags.append('never')

# Generated at 2022-06-11 11:07:48.832759
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    test_vars = dict()
    test_vars['test_var1'] = 'tag1'
    test_vars['test_var2'] = 'tag2'

    #test if only_tags works
    #set only_tags property to 'tag1'
    #current tags property is empty, so should_run should be false
    taggable._only_tags = 'tag1'
    taggable._tags = []
    should_run = taggable.evaluate_tags(taggable._only_tags, taggable._skip_tags, test_vars)
    assert should_run == False

    #set only_tags property to 'tag2'
    #current tags property is empty, so should_run should be false
    taggable._only_tags = 'tag2'

# Generated at 2022-06-11 11:08:55.013367
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Defining a test class")

    class TestClass_evaluate_tags(Taggable):
        def __init__(self, tags):
            self.tags = tags

        def to_str(self, *args, **kwargs):
            print("Test class to_str: %s %s" % (args, kwargs))
            return str(self.tags)

    # default
    tag_test = TestClass_evaluate_tags(tags=[])
    result = tag_test.evaluate_tags(only_tags=[], skip_tags=[])
    assert result, "Default value with no tags specified should return True"

    # no tags set
    tag_test = TestClass_evaluate_tags(tags=[])
    result = tag_test.evaluate_tags(only_tags=['test'], skip_tags=[])
    assert not result

# Generated at 2022-06-11 11:09:01.494434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #Test 1 -- Only tag testing
    only_tags=['tag1']
    skip_tags=[]
    all_vars={}
    tags = ['tag1', 'tag2']
    T = Taggable()
    assert T.evaluate_tags(only_tags, skip_tags, all_vars) == True

#Unit test for method _load_tags of class Taggable

# Generated at 2022-06-11 11:09:11.854773
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys
    import os

    class AnsibleModuleUtilsTaggableTestCase(unittest.TestCase):

        def setUp(self):
            self.t = Taggable()

        def tearDown(self):
            self.t = None

        def test_Taggable_evaluate_tags_1(self):
            """
            Tests that missing tags cause the object to be run by default
            """

            self.assertTrue(self.t.evaluate_tags([], [], {}))

        def test_Taggable_evaluate_tags_2(self):
            """
            Tests that tag `always` causes the object to be run by default
            """

            self.t._tags = ['always']
            self.assertTrue(self.t.evaluate_tags([], [], {}))


# Generated at 2022-06-11 11:09:20.810257
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class fakeTaggable(Taggable):
        tags = ['foo','bar']
    t = fakeTaggable()
    assert(t.evaluate_tags(['bar'], [], {}) == True)
    assert(t.evaluate_tags(['bar', 'foo'], [], {}) == True)
    assert(t.evaluate_tags(['bar', 'foo', 'spam'], [], {}) == True)
    assert(t.evaluate_tags(['foo'], [], {}) == True)
    # Skip tags
    assert(t.evaluate_tags(['bar'], ['spam'], {}) == True)
    assert(t.evaluate_tags(['bar', 'foo'], ['spam'], {}) == True)

# Generated at 2022-06-11 11:09:30.618195
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    tags_obj = Taggable()
    tags_obj.tags = ["thetag","thetag2","thetag3",["thetag4","thetag5"],"thetag6"]

    # test with only_tags, skip_tags and all_vars parameters
    print(tags_obj.evaluate_tags(["thetag"],["thetag2"],["all_vars"]))
    # test with only_tags, skip_tags and empty all_vars parameters
    print(tags_obj.evaluate_tags(["thetag"],["thetag2"],[]))
    # test with only_tags, empty skip_tags and all_vars parameters
    print(tags_obj.evaluate_tags(["thetag"],[],["all_vars"]))
    # test with skip_tags, empty only_tags and all_vars parameters

# Generated at 2022-06-11 11:09:40.960252
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a sample subclass of Taggable
    class SubTaggable(Taggable):
        pass

    # Create an instance of SubTaggable
    instance = SubTaggable()
    # Set the tags of the instance
    instance.tags = ['foo']

    # Create a dictionary of the variables of the environment
    vars = {'foo': 'bar'}

    # Test evaluate_tags with only-tags condition
    # Check that if no tags are specified, the instance should run
    # The default tags is []
    assert(instance.evaluate_tags([], [], vars) == True)

    # Check that a tag of the instance is present in the only-tags condition
    # And the instance should run
    assert(instance.evaluate_tags(['foo'], [], vars) == True)

    # Check that the instance should run

# Generated at 2022-06-11 11:09:52.281025
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ['tag1', 'tag2', 'tag3']
    res = t.evaluate_tags(only_tags=['tag2', 'tag3'], skip_tags=[], all_vars=None)
    assert res == True

    t.tags = ['tag1', 'tag2', 'tag3']
    res = t.evaluate_tags(skip_tags=['tag2', 'tag3'], only_tags=[], all_vars=None)
    assert res == False

    t.tags = ['tag1', 'tag2', 'tag3']
    res = t.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2', 'tag3'], all_vars=None)
    assert res == True


# Generated at 2022-06-11 11:10:03.167629
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context._start_at = ''
    context.only_tags = set()
    context.skip_tags = set()

    task = Taggable()
    task.tags = []
    assert task.evaluate_tags(context.only_tags, context.skip_tags, {})

    task.tags = ['a', ['b', 'c']]
    assert task.evaluate_tags(context.only_tags, context.skip_tags, {})

    context.only_tags = set(['a'])
    assert task.evaluate_tags(context.only_tags, context.skip_tags, {})

    context.only_tags = set(['a', 'b'])

# Generated at 2022-06-11 11:10:08.239371
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    facts = dict(tags=["flask","nginx"])
    only_tags = list("flask")
    skip_tags = None
    test_object = Taggable()
    ans_result = test_object.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=facts)
    assert ans_result == True
    print("Test case passed")

test_Taggable_evaluate_tags()