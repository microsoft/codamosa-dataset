

# Generated at 2022-06-25 06:05:46.438470
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    taggable_0.tags = ['hadoop', 'spark']
    only_tags = ['hadoop', 'spark']
    skip_tags = ['hive']
    all_vars = {}

    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:05:55.806001
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['always', 'test1']
    taggable_2 = Taggable()
    taggable_2.tags = ['test1', 'test2']
    taggable_3 = Taggable()
    taggable_4 = Taggable()
    taggable_4.tags = ['never']

    assert taggable_1.evaluate_tags(set(['test1', 'test2', 'test3']), set(), dict()) == True
    assert taggable_2.evaluate_tags(set(['test1', 'test2', 'test3']), set(), dict()) == True
    assert taggable_3.evaluate_tags(set(['test1', 'test2', 'test3']), set(), dict()) == True
   

# Generated at 2022-06-25 06:05:59.049792
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tag1', 'tag2']
    only_tags = ['tag2', 'tag3']
    skip_tags = ['tag']
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) is True


# Generated at 2022-06-25 06:06:08.976414
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['test_tag', 'a']
    
    only_tags_1 = ['all', 'test_tag']
    skip_tags_1 = ['test_tag']
    all_vars_1 = {}
    res_1 = taggable_0.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert res_1 == False

    taggable_0.tags = ['test_tag', 'a']
    
    only_tags_2 = ['all', 'test_tag']
    skip_tags_2 = ['all', 'test_tag']
    all_vars_2 = {}

# Generated at 2022-06-25 06:06:18.678545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert True == taggable_0.evaluate_tags(set(['all', 'never']), [], {})
    assert False == taggable_0.evaluate_tags(['tagged'], [], {})
    assert True == taggable_0.evaluate_tags(['always'], [], {})
    assert True == taggable_0.evaluate_tags(['all', 'never'], [], {})
    assert True == taggable_0.evaluate_tags([], ['always', 'test'], {})
    assert True == taggable_0.evaluate_tags(['always'], ['always', 'test'], {})
    assert True == taggable_0.evaluate_tags(['always'], ['never', 'test'], {})
    assert True == tag

# Generated at 2022-06-25 06:06:27.585192
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    taggable_0.tags = ['tagged']

    all_vars = {}

    # test evaluate_tags method with parameter only_tags
    only_tags = ['tagged']
    skip_tags = None

    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['not tagged']
    skip_tags = None

    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # test evaluate_tags method with parameter skip_tags
    only_tags = None
    skip_tags = ['tagged']

    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:06:37.836661
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['a', 'b', 'c']
    taggable._loader = None

    all_vars = dict()
    only_tags = None
    skip_tags = None

    # test_case_1: only_tags=None, skip_tags=None, self.tags=[a,b,c]
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test_case_2: only_tags=['a', 'b'], skip_tags=None, self.tags=[a,b,c]
    only_tags = ['a', 'b']
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # test_case_3: only

# Generated at 2022-06-25 06:06:47.034681
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['test1']
    assert taggable.evaluate_tags(['test1'], ['test2'], {}) == True
    assert taggable.evaluate_tags(['test2'], ['test1'], {}) == False
    assert taggable.evaluate_tags(['test2'], [], {}) == True
    assert taggable.evaluate_tags([], ['test1'], {}) == True
    taggable.tags = ['test1', 'test2']
    assert taggable.evaluate_tags(['test1'], ['test2'], {}) == True
    assert taggable.evaluate_tags(['test2'], ['test1'], {}) == False

# Generated at 2022-06-25 06:06:57.544647
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1_tags = ['tag_1', 'tag_2']
    taggable_1.tags = taggable_1_tags
    taggable_1_only_tags = ['tag_1', 'tag_2', 'tag_3']
    taggable_1_skip_tags = ['tag_1', 'tag_2', 'tag_3']
    taggable_1_all_vars = {'var1': 'value1'}

    taggable_1_should_run = taggable_1.evaluate_tags(taggable_1_only_tags, taggable_1_skip_tags, taggable_1_all_vars)
    taggable_1_expected = True

    assert taggable_1_should

# Generated at 2022-06-25 06:07:06.066571
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create test data
    class_0 = Taggable()
    class_0.tags = ['always', 'tag1']

    # Set up the necessary args for the method call
    only_tags = set(['tag1', 'tag2', 'all'])
    skip_tags = set(['untagged', 'all'])
    all_vars = dict()

    # Call the method
    x = class_0.evaluate_tags(only_tags, skip_tags, all_vars)

    # Assert the result
    assert x == True


# Generated at 2022-06-25 06:07:26.274892
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    tags = ['enabled']
    only_tags = ['enabled']
    skip_tags = ['disabled']
    all_vars = {'tag_value': 'enabled'}

    taggable.tags = tags
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result)

    taggable.tags = tags
    only_tags = ['disabled']
    skip_tags = ['enabled']
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result)

    taggable.tags = tags
    only_tags = ['enabled']
    skip_tags = ['disabled']

# Generated at 2022-06-25 06:07:30.448534
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ""
    skip_tags = ""
    vars = dict()
    ans = taggable_0.evaluate_tags(only_tags, skip_tags, vars)
    assert ans is True
    print('test_Taggable_evaluate_tags: pass')


# Generated at 2022-06-25 06:07:41.632646
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = []
    taggable_1 = Taggable()
    taggable_1.tags = []
    taggable_2 = Taggable()
    taggable_2.tags = []
    taggable_3 = Taggable()
    taggable_3.tags = []
    assert taggable_0.evaluate_tags(only_tags=['untagged'], skip_tags=['untagged'], all_vars={}) is True
    assert taggable_0.evaluate_tags(only_tags=['untagged'], skip_tags=['untagged'], all_vars={'a_list': ['a']}) is True

# Generated at 2022-06-25 06:07:47.723724
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    # test result of evaluate_tags that most likely skipped due to nontrivial condition
    if taggable.evaluate_tags() == True:
        print("test_Taggable_evaluate_tags PASSED")
    else:
        print("test_Taggable_evaluate_tags FAILED")


if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:58.992440
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 0 test evaluate_tags with none of the tag options
    taggable_0 = Taggable()
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = {}
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    expected_0 = True
    assert result_0 == expected_0

    # Test case 1 test evaluate_tags with only_tags
    taggable_1 = Taggable()
    only_tags_1 = []
    skip_tags_1 = []
    all_vars_1 = {}
    result_1 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    expected

# Generated at 2022-06-25 06:07:59.858870
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

# Generated at 2022-06-25 06:08:09.129476
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create an object of class Taggable
    taggable_1 = Taggable()

    # Create a set and add an item to it
    set1 = set()
    set1.add('always')

    # Create a set and add an item to it
    set2 = set()
    set2.add('never')

    # Create a set and add an item to it
    only_tags = set()
    only_tags.add('tagged')

    all_vars = {}
    # Call method evaluate_tags and store result in variable 'should_run'
    should_run = taggable_1.evaluate_tags(only_tags, set2, all_vars)

    # Check if the result of the method evaluate_tags is True
    assert should_run == True

# Generated at 2022-06-25 06:08:15.094854
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    for only_tags in [['role1'], []]:
        for skip_tags in [['role2'], []]:
            for tags in [['role1'], []]:
                is_run = Taggable().evaluate_tags(only_tags, skip_tags, {'tags': tags})
                assert tags == tags
                assert tags == tags
                assert tags == tags

# Generated at 2022-06-25 06:08:23.757551
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 0
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(only_tags=set([]), skip_tags=set([]), all_vars={}) == True

    # Test case 1
    taggable_1 = Taggable()
    taggable_1.tags = ['always']
    assert taggable_1.evaluate_tags(only_tags=set([]), skip_tags=set([]), all_vars={}) == True

    # Test case 2
    taggable_2 = Taggable()
    assert taggable_2.evaluate_tags(only_tags=set(['all']), skip_tags=set(['never']), all_vars={}) == True

    # Test case 3
    taggable_3 = Taggable()

# Generated at 2022-06-25 06:08:30.156516
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = [u"always", "test_2"]
    only_tags = ["always", "test_1"]
    skip_tags = ["never", "test_1", "test_2", "test_3"]
    all_vars = {"test_var": "test_value"}
    # check if method evaluate_tags works properly
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)



# Generated at 2022-06-25 06:08:59.137926
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:08.873938
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = {}
    taggable = Taggable()
    taggable.tags = ['tag1', 'tag2']
    only_tags = ['tag3', 'tag4']
    skip_tags = ['tag1', 'tag2']

    assert(taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False)
    only_tags = ['tag1']
    skip_tags = ['tag3', 'tag4']

    assert(taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True)
    taggable.tags = ['tag1']
    assert(taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True)
    taggable.tags = set()

# Generated at 2022-06-25 06:09:14.664507
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("# Unit test for method evaluate_tags of class Taggable")
    taggable = Taggable(tags=["alice","bob","charlie"])
    only_tags = ["alice"]
    skip_tags = []
    all_vars = None
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run
    print("  -> PASSED")


# Generated at 2022-06-25 06:09:18.848716
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Taggable(only_tags=frozenset(['docker']), skip_tags=[])
    taggable = Taggable()
    taggable.tags = []
    all_vars = {}
    only_tags = frozenset(['docker'])
    skip_tags = []
    retval = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert retval == True


# Generated at 2022-06-25 06:09:21.888615
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ["tag_5"]

    assert taggable_0.evaluate_tags("tag_1,tag_2","tag_3,tag_4",{}) == False


# Generated at 2022-06-25 06:09:31.163124
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Testing evaluate_tags")
    taggable_0 = Taggable()
    only_tags_0 = frozenset(["tag1","tag2","tag3","tag4"])
    skip_tags_0 = frozenset(["tag4","tag5"])
    all_vars_0 = dict()
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True
    only_tags_1 = frozenset(["tag3"])
    skip_tags_1 = frozenset(["tag4"])
    assert taggable_0.evaluate_tags(only_tags_1, skip_tags_1, all_vars_0) == False
    only_tags_2 = frozenset(["tag1"])
    ski

# Generated at 2022-06-25 06:09:40.748462
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()
    only_tags = ['tag_one','tag_two']
    skip_tags = ['tag_three']
    vars = {'key1':'value1'}
    only_tags_exp = set(['tag_one','tag_two'])
    skip_tags_exp = set(['tag_three'])
    assert taggable_obj.evaluate_tags(only_tags, skip_tags, vars)
    only_tags_act = taggable_obj.evaluate_tags(only_tags, skip_tags, vars)
    assert only_tags_act == False
    skip_tags_act = taggable_obj.evaluate_tags(only_tags, skip_tags, vars)
    assert skip_tags_act == True

test_Taggable_evaluate

# Generated at 2022-06-25 06:09:44.216923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from nose.tools import assert_equal
    from nose.tools import assert_not_equal
    from nose.tools import assert_raises
    from nose.tools import raises

    assert_raises(AnsibleError, Taggable().evaluate_tags)


# Generated at 2022-06-25 06:09:49.604969
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = set([])
    skip_tags = set([])
    all_vars = { 'a': 2, 'b': 3 }
    retval = taggable_0.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    assert retval == True


# Generated at 2022-06-25 06:09:56.017286
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    #set untagged to empty list
    taggable_0.untagged = []
    tags = ['tag1']
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {'inventory_hostname':'test', 'groups':['test']}
    if taggable_0.tags:
        templar = Templar(loader=taggable_0._loader, variables=all_vars)
        tags = templar.template(taggable_0.tags)

        _temp_tags = set()
        for tag in tags:
            if isinstance(tag, list):
                _temp_tags.update(tag)
            else:
                _temp_tags.add(tag)
        tags = _temp_tags
        tagg

# Generated at 2022-06-25 06:11:08.307637
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # Note that this test case is specific to Ansible 2.7.8
    # If it breaks, then the test case has to be updated.
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:16.037188
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Test cases for evaluate_tags method of Taggable
    all_vars = {}
    only_tags = set()
    skip_tags = set()
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert taggable_0._tags == []
    only_tags = set()
    skip_tags = set()
    taggable_0._tags = ['a', 'b', 'c']
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert taggable_0._tags == ['a', 'b', 'c']
    only_tags = set()
    skip_tags = set()
    taggable_0._tags = ['always']
    tagg

# Generated at 2022-06-25 06:11:21.841409
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    actual_result = taggable_0.evaluate_tags(True, True, 'all')
    expected_result = True
    assert actual_result == expected_result, "%s != %s" % (actual_result, expected_result)

# Generated at 2022-06-25 06:11:31.005665
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # test_only_tags = ['all', 'never', 'todo', 'todo2', 'todo3']
    # test_skip_tags = ['all', 'never', 'todo', 'todo2', 'todo3']
    test_only_tags = []
    test_skip_tags = []

    # test_tags = []
    # test_tags = ['all', 'never', 'todo', 'todo2', 'todo3']
    test_tags = ['never']
    test_tags = ['all']
    test_tags = ['never', 'all']
    test_tags = ['not_all', 'all']
    test_tags = ['never', 'all', 'not_all']
    test_tags = ['all', 'not_all']
   

# Generated at 2022-06-25 06:11:40.217255
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()

    # only runs if no tags are set
    assert True == t.evaluate_tags([], [], [])
    # only runs if no tags are set
    assert True == t.evaluate_tags(None, [], [])
    # runs if only_tags is set to 'all'
    assert True == t.evaluate_tags(['all'], [], [])
    assert False == t.evaluate_tags(['wrong_tag'], [], [])
    # 'all' is tagged
    assert True == t.evaluate_tags(['all'], [], [])
    # should run if only_tags is 'all' and no skip_tags
    assert True == t.evaluate_tags(['all'], None, [])
    # should run if only_tags is 'all' and no skip_tags

# Generated at 2022-06-25 06:11:42.714359
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # TODO: implement test_evaluate_tags of Taggable


# Generated at 2022-06-25 06:11:52.447963
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case for a single tag in self.tags and only_tag
    # Expectation: we expect to return True
    test_case_1 = (["webservers"], ["webservers"], dict())
    assert Taggable.evaluate_tags(*test_case_1) == True

    # Test case for a single tag in self.tags, only_tag and skip_tags
    # Expectation: we expect to return False
    test_case_2 = (["webservers"], ["webservers"], {}, ["webservers"])
    assert Taggable.evaluate_tags(*test_case_2) == False

    # Test case for multiple tags in self.tags, only_tag and skip_tags
    # Expectation: we expect to return True

# Generated at 2022-06-25 06:11:56.869915
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    input_only_tags = set(['tag_0'])
    input_skip_tags = set()
    input_all_vars = dict()
    output_should_run = taggable_0.evaluate_tags(input_only_tags, input_skip_tags, input_all_vars)

    assert output_should_run == False


# Generated at 2022-06-25 06:12:00.422639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()
    only_tags = ['all']
    skip_tags = ['all']
    all_vars = {}
    ret = taggable_obj.evaluate_tags(only_tags, skip_tags, all_vars)
    assert ret == False, 'taggable_obj.evaluate_tags(only_tags, skip_tags, all_vars) returned ' + str(ret) + ', expected False'

# Generated at 2022-06-25 06:12:06.740705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['a','b','c','d']
    only_tags = ['all']
    skip_tags = ['all']
    all_variables = {}

    if taggable.evaluate_tags(only_tags, skip_tags, all_variables):
        assert True
    else:
        assert False


test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:14:55.876032
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    assert taggable_1.evaluate_tags(["all"], [], {})


# Generated at 2022-06-25 06:15:02.246236
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    tags_1 = taggable_1.evaluate_tags(only_tags = 'all', skip_tags = 'always', all_vars = 'all')
    print(taggable_1.tags)

test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:07.689626
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tags1', 'tags2']
    print(taggable_0.evaluate_tags(only_tags=['tags1', 'tags2'], skip_tags=['tags1', 'tags2'], all_vars={}))



# Generated at 2022-06-25 06:15:13.693455
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    taggable_0 = Taggable()
    only_tags = ['tag','tag1','tag2','tag3']
    skip_tags = ['tag3','tag4']
    all_vars = {}
    # ToDo add more test cases here

    # Test case where tags list is empty
    assert taggable_0.evaluate_tags(only_tags,skip_tags,all_vars) == False

    # Test case where 'all' present in only_tags list
    taggable_0.tags = ['tag']
    assert taggable_0.evaluate_tags(only_tags,skip_tags,all_vars) == True

    # Test case where 'never' present in tags list
    taggable_0.tags = ['tag','never']
    assert taggable_0.evaluate_tags

# Generated at 2022-06-25 06:15:14.847764
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:15:24.432068
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case 1
    taggable_1 = Taggable()
    taggable_1._tags = []
    only_tags = []
    skip_tags = []
    all_vars = {}
    result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result
    
    # Test case 2
    taggable_2 = Taggable()
    taggable_2._tags = ['untagged']
    only_tags = []
    skip_tags = []
    all_vars = {}
    result = taggable_2.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result
    
    # Test case 3
    taggable_3 = Taggable()

# Generated at 2022-06-25 06:15:33.202387
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()

    # Check default behavior
    print(taggable_1.evaluate_tags(None, None, None)) # Expected True

    # Check that should run if in only_tags
    print(taggable_1.evaluate_tags(['all'], None, None)) # Expected True
    print(taggable_1.evaluate_tags(['all', 'test'], None, None)) # Expected True
    print(taggable_1.evaluate_tags(['test', 'all'], None, None)) # Expected True
    print(taggable_1.evaluate_tags(['tagged'], None, None)) # Expected True

    # Check that should skip if in only_tags
    print(taggable_1.evaluate_tags(['never'], None, None)) #