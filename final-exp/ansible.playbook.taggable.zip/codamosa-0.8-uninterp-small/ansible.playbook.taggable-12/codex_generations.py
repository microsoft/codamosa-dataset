

# Generated at 2022-06-25 06:05:54.088913
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags_0 = set(['skip_tags_0'])
    skip_tags_0 = set(['skip_tags_0'])
    all_vars_0 = set()
    try:
        Taggable_0 = Taggable()
        evaluate_tags_ret_0 = Taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    except Exception as exception:
        evaluate_tags_ret_0 = exception
    assert('TypeError' in str(type(evaluate_tags_ret_0)))
    assert(evaluate_tags_ret_0.args[0] == '_get_parent_attribute must be overriden by a class that inherits from Taggable')


# Generated at 2022-06-25 06:05:58.519401
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = dict()
    dict_0['tags'] = ['got', 'to', '7']
    taggable_0 = Taggable(**dict_0)
    expected_output = False
    actual_output = taggable_0.evaluate_tags(['tagged'], ['all'], dict())
    assert actual_output == expected_output


# Generated at 2022-06-25 06:06:08.717885
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # We'll use example 'atmoz/sftp' to test this method because
    # it is the only Role that has tag based plays.
    obj_0 = Taggable()
    # TODO: The tags attribute can only be a list of strings.
    # Look for a better example to test this method.
    obj_0.tags = ['tag_string']
    obj_0.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    # TODO: Assert that the obj_0.tags is a list of strings.

    obj_1 = Taggable()
    # TODO: The tags attribute can only be a list of strings.
    # Look for a better example to test this method.
    obj_1.tags = ['tag_string', 'another_tag']
    obj_

# Generated at 2022-06-25 06:06:13.620303
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = None
    taggable_0 = Taggable(**dict_0)

    assert taggable_0.evaluate_tags(['unified-diff'], ['html'], dict_0) == True
    assert taggable_0.evaluate_tags(['ascii'], ['html'], dict_0) == False
    assert taggable_0.evaluate_tags(['all', 'json'], ['html'], dict_0) == True
    assert taggable_0.evaluate_tags([], ['html'], dict_0) == True
    assert taggable_0.evaluate_tags(['all'], ['html'], dict_0) == True

# Generated at 2022-06-25 06:06:20.192833
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    dict_0 = None
    taggable_0 = Taggable(**dict_0)

    only_tags = '{"__ansible_version__":[1.5,2.0]}'
    skip_tags = '{"__ansible_version__":[1.5,2.0]}'
    all_vars = '{"__ansible_version__":[1.5,2.0]}'
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    assert result is False

test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:06:25.566377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # create an instance of class Taggable
    tags = ['foo', 'bar']
    only_tags = ['foo']
    skip_tags = ['bar']
    all_vars = {'foo': 'foo var', 'bar': 'bar var'}
    taggable_0 = Taggable(tags=tags)
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:06:34.966814
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    test_Taggable_evaluate_tags_obj_0 = Taggable(**dict_0)
    test_Taggable_evaluate_tags_obj_0.tags = ['a']
    only_tags_0 = ['a', 'b', 'c']
    skip_tags_0 = ['d', 'e', 'f']
    all_vars_0 = {"test": "test"}
    test_Taggable_evaluate_tags_ret_0 = test_Taggable_evaluate_tags_obj_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

    assert test_Taggable_evaluate_tags_ret_0 == True


# Generated at 2022-06-25 06:06:39.577349
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    dict_0 = None
    taggable_0 = Taggable(**dict_0)
    dict_1 = None
    dict_1 = dict()
    dict_2 = None
    dict_2 = dict()
    dict_3 = None
    dict_3 = dict()
    taggable_0.evaluate_tags(dict_1, dict_2, dict_3)


# Generated at 2022-06-25 06:06:41.702500
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Calling test case 0")
    test_case_0()
    print("End of test case 0\n")

test_Taggable_evaluate_tags()


# Generated at 2022-06-25 06:06:50.371508
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = dict()
    dict_0['tags'] = None
    dict_0['_loader'] = None
    taggable_0 = Taggable(**dict_0)
    only_tags_0 = set()
    only_tags_0.add('never')
    skip_tags_0 = set()
    skip_tags_0.add('always')
    all_vars_0 = dict()
    res = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert res == False

# Generated at 2022-06-25 06:07:13.382420
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # Test Cases for only_tags = ['aaaa'] and skip_tags = []
    assert taggable.evaluate_tags([], [], {}) == True

    taggable = Taggable()
    taggable._tags = ['aaaa']
    assert taggable.evaluate_tags(['aaaa'], [], {}) == True

    taggable = Taggable()
    taggable._tags = ['aaaa']
    assert taggable.evaluate_tags(['bbbb'], [], {}) == False

    taggable = Taggable()
    taggable._tags = ['aaaa','bbbb']
    assert taggable.evaluate_tags(['aaaa'], [], {}) == True

    taggable = Taggable()

# Generated at 2022-06-25 06:07:19.224999
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    #assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True
    assert True

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:24.353208
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    AnsibleClass.Taggable._evaluate_tags
    """
    taggable_obj = Taggable()
    only_tags = "ansible"
    skip_tags = "ansible"
    all_vars = {}
    assert taggable_obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-25 06:07:34.350121
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag7','tag8','tag9','tag10']
    only_tags = ['tag1','tag5','tag10']
    skip_tags = ['tag7']
    all_vars = {}
    test_1 = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable_2 = Taggable()
    taggable_2.tags = ['tag1','tag2','tag3','tag4','tag5','tag6','tag7','tag8','tag9','tag10']
    only_tags = ['tag3','tag4','tag10']
    skip_tags = ['tag1']
    all_v

# Generated at 2022-06-25 06:07:43.013478
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    context._init_vars()
    context.only_tags = ['linux','windows']
    context.skip_tags = ['desktop']
    taggable_0 = Taggable()
    taggable_0.tags = ['linux']
    taggable_0.evaluate_tags(context.only_tags, context.skip_tags, context.all_vars)
    print ("\nUnit Test: Test evaluate_tags of class Taggable.")
    print ("\nTest Passed")

# Generated at 2022-06-25 06:07:53.549448
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # The method 'evaluate_tags' from the class 'Taggable' is called with the following parameters:
    #    only_tags = [ "tag1" ]
    #    skip_tags = [ "tag2" ]
    #    all_vars = { "tag1": "tag1" }

    # The method 'evaluate_tags' of the class 'Taggable' is called with the following name and parameters:
    #   evaluate_tags(only_tags = [ "tag1" ], skip_tags = [ "tag2" ], all_vars = { "tag1": "tag1" })

# Generated at 2022-06-25 06:08:01.690425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create test object
    taggable_0 = Taggable()
    # Test that object's parameters initialize as expected
    assert taggable_0.tags == list()
    assert taggable_0.untagged == frozenset(['untagged'])
    assert taggable_0._tags == list()
    # Test method evaluate_tags with scenario 1
    # Expected value: False
    only_tags_0 = ['tag_1','tag_2','tag_3','tag_4']
    skip_tags_0 = ['tag_5','tag_6','tag_7','tag_8']

# Generated at 2022-06-25 06:08:09.610545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # False
    only_tags = set()
    skip_tags = set([])
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # True
    only_tags = set(['dummy'])
    skip_tags = set([])
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # True
    only_tags = set([])
    skip_tags = set(['dummy'])
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # True
    only

# Generated at 2022-06-25 06:08:14.491639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    tags = ['tag_a', 'tag_b']
    only_tags = ['tag_b']
    skip_tags = ['tag_c', 'tag_d']
    all_vars = dict()
    res = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert res == True


# Generated at 2022-06-25 06:08:23.650810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    test_taggable_0 = {'tags': ['test'], '_all_tags': ['tagged']}
    test_taggable_1 = {'tags': [], '_all_tags': ['tagged']}
    test_taggable_2 = {'tags': ['always'], '_all_tags': ['always']}
    test_taggable_3 = {'tags': ['never'], '_all_tags': ['never']}
    test_taggable_4 = {'tags': ['never'], '_all_tags': ['always']}
    test_taggable_5 = {'tags': ['test'], '_all_tags': ['never']}


# Generated at 2022-06-25 06:08:54.945556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test when there are no skip_tags or only_tags
    taggable_0 = Taggable()
    taggable_0._tags = ['foo', 'bar']
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = {}
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

# Generated at 2022-06-25 06:08:59.306460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = []
    only_tags = ['all', 'never']
    skip_tags = []
    all_vars = []
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == False


# Generated at 2022-06-25 06:09:04.826513
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # No tags specified
    
    taggable_0 = Taggable()
    
    only_tags_0 = set()
    
    skip_tags_0 = set()
    
    all_vars = {}
    
    expected_return = True
    actual_return = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars)
    assert actual_return == expected_return
    

# Generated at 2022-06-25 06:09:14.214769
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case 1: Asserting false when only_tags is not empty and 'always' tag is not set in tags
    taggable_1 = Taggable()
    taggable_1.tags = ['foo', 'bar']
    assert taggable_1.evaluate_tags(['all', '!never'], [], dict()) == False

    # Test case 2: Asserting false when only_tags is not empty and 'all' tag is not set in tags
    taggable_2 = Taggable()
    taggable_2.tags = ['foo', 'bar']
    assert taggable_2.evaluate_tags(['all'], [], dict()) == False

    # Test case 3: Asserting false when only_tags is not empty and some tags in only_tags set is missing in tags

# Generated at 2022-06-25 06:09:20.207422
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['tag1', 'tag2', 'tag3']
    print("Tags: " + taggable.tags)
    assert (taggable.evaluate_tags(['tag1', 'tag3'],['tag2'],{}))


test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:23.173173
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = list(['test'])
    actual = taggable.evaluate_tags(list(['test']),list(['test_skip']),list())
    expected = True
    assert expected == actual


# Generated at 2022-06-25 06:09:32.688277
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create an object of class Taggable
    taggable_obj = Taggable()

    # Try with no tags
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert taggable_obj.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # Try with only_tags set to ['test']
    only_tags = ['test']
    assert taggable_obj.evaluate_tags(only_tags, skip_tags, all_vars) is False

    # Try with only_tags set to ['all']
    only_tags = ['all']
    assert taggable_obj.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # Try with only_tags set to ['test'] and skip_tags set to ['

# Generated at 2022-06-25 06:09:39.796740
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # default
    taggable_0 = Taggable()
    taggable_0.tags = list()
    assert taggable_0.evaluate_tags(['always'], ['never'], []) == True
    # only_tags specified
    taggable_1 = Taggable()
    taggable_1.tags = list()
    assert taggable_1.evaluate_tags(['never'], ['never'], []) == False
    # skip_tags specified
    taggable_2 = Taggable()
    taggable_2.tags = ['skip_tags']
    assert taggable_2.evaluate_tags(['always'], ['skip_tags'], []) == False
    # only_tags and skip_tags specified
    taggable_3 = Taggable()
    taggable_3

# Generated at 2022-06-25 06:09:46.513746
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    taggable = TestTaggable()
    taggable.tags = ['foo', 'bar']

    only_tags = ['foo','bar']
    skip_tags = ['baz']
    all_vars = None

    assert(taggable.evaluate_tags(only_tags,skip_tags,all_vars)) == True
    #assert(taggable.evaluate_tags(taggable.tags)) == 'True'



# Generated at 2022-06-25 06:09:50.762062
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    tags_0 = set('foo')
    skip_tags_0 = set()
    all_vars_0 = dict()
    try:
        assert taggable_0.evaluate_tags(only_tags=tags_0, skip_tags=skip_tags_0, all_vars=all_vars_0)
    except:
        assert False


# Generated at 2022-06-25 06:11:04.878191
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['a']
    skip_tags = ['b']
    all_vars = {}
    result = taggable_0.evaluate_tags(only_tags,skip_tags,all_vars)
    assert result

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-25 06:11:10.342422
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import json
    fixture = json.load(open('test.json'))
    result = Taggable().evaluate_tags( fixture['only_tags'], fixture['skip_tags'], fixture['all_vars'] )
    assert result == fixture['out']


# Generated at 2022-06-25 06:11:13.247615
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    r = taggable_0.evaluate_tags(only_tags=None, skip_tags=None, all_vars={ u'foobar': 1 })
    assert r == True


# Generated at 2022-06-25 06:11:22.873408
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:11:30.904942
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a test instance of class Taggable
    taggable_0 = Taggable()

    # Create a test value for parameter 'only_tags'
    only_tags_0 = 'all'

    # Create a test value for parameter 'skip_tags'
    skip_tags_0 = None

    # Create a test value for parameter 'all_vars'
    all_vars_0 = dict()

    # Execute the function under test
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

    # Check the results
    if result_0 is not False:
        raise AssertionError()
    assert isinstance(result_0, bool)

# Generated at 2022-06-25 06:11:37.196528
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['foo','bar']
    only_tags = ['foo']
    all_vars = {}
    skip_tags = []
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == True
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
#

# Generated at 2022-06-25 06:11:48.625935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Testing method Taggable.evaluate_tags")
    taggable_0 = Taggable()
    taggable_0.tags = ['always']
    only_tags_0 = ['always']
    all_vars_0 = {}
    # Check result: should_run_0 should be True
    should_run_0 = taggable_0.evaluate_tags(only_tags_0, None, all_vars_0)
    assert should_run_0 == True, "Should be True"
    # Check result: should_run_1 should be True
    should_run_1 = taggable_0.evaluate_tags(only_tags_0, None, all_vars_0)
    assert should_run_1 == True, "Should be True"
    # Check result: should_run_2 should be False

# Generated at 2022-06-25 06:11:57.670740
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    os_family_unix = 'unix'
    tags_var_0 = ['var_0']
    only_tags_var_0 = ['var_0']
    skip_tags_var_0 = ['var_0']
    all_vars_os_family_unix = {'ansible_os_family':'unix'}
    taggable_0.tags = tags_var_0
    taggable_0.evaluate_tags(only_tags_var_0,skip_tags_var_0,all_vars_os_family_unix)



# Generated at 2022-06-25 06:12:04.619891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play import Play
    play_0 = Play()
    task_0 = Task()
    block_0 = Block()
    block_0.task_list.append(task_0)

    task_1 = Task()
    block_0.task_list.append(task_1)

    play_0.block_list.append(block_0)

    # Evaluate the tags in the play
    play_0.evaluate_tags(['tagged'],[],{'tags':['some_tag']})

    # Check the tags in the play


# Generated at 2022-06-25 06:12:12.788786
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_test = Taggable()
    taggable_test._tags = ['tag1', 'tag2']
    only_tags = ['tag9', 'tag2', 'tag1']
    skip_tags = ['not-tag3', 'not-tag2', 'not-tag1']
    all_vars = {}
    assert taggable_test.evaluate_tags(only_tags, skip_tags, all_vars) == True, \
        "called with: taggable_test, only_tags, skip_tags and all_vars = {}".format(all_vars)


# Generated at 2022-06-25 06:15:08.549553
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1._tags = ['tag1', 'tag2']

    assert (taggable_1.evaluate_tags(['tag1'], [], {}) == True)

    taggable_2 = Taggable()
    taggable_2._tags = ['tag3', 'tag4']
    assert (taggable_2.evaluate_tags(['tag1'], [], {}) == False)

    taggable_3 = Taggable()
    taggable_3._tags = ['tag1', 'tag2']
    assert (taggable_3.evaluate_tags(['tag1'], ['tag2'], {}) == False)

    taggable_4 = Taggable()

# Generated at 2022-06-25 06:15:10.152673
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    assert taggable_1.evaluate_tags(['test'], [], {}) == True


# Generated at 2022-06-25 06:15:14.378693
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    tags = ['untagged']
    only_tags = set()
    skip_tags = set()
    all_vars = dict()

    assert(taggable.evaluate_tags(only_tags, skip_tags, all_vars))


# Generated at 2022-06-25 06:15:24.075135
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = None
    only_tags = ["second"]
    skip_tags = ["first"]
    all_vars = {'ansible_tags': "tag1,tag2,tag3"}
    result = taggable_0.evaluate_tags(only_tags,skip_tags,all_vars)
    assert result == True
    taggable_0.tags = None
    only_tags = ["second"]
    skip_tags = ["first"]
    all_vars = {}
    result = taggable_0.evaluate_tags(only_tags,skip_tags,all_vars)
    assert result == True
    taggable_0.tags = ["first"]
    only_tags = ["second"]
    skip_tags = ["first"]


# Generated at 2022-06-25 06:15:29.337176
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():    
    taggable_0 = Taggable()
    taggable_0.tags = None
    tags = taggable_0.tags
    only_tags_0 = set()
    skip_tags_0 = frozenset(['skip_tags_0'])
    all_vars_0 = dict
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result_0 == True

    taggable_1 = Taggable()
    taggable_1.tags = ''
    tags = taggable_1.tags
    only_tags_1 = set()
    skip_tags_1 = frozenset(['skip_tags_1'])
    all_vars_1 = dict
    result_1 = tagg

# Generated at 2022-06-25 06:15:33.250190
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1._tags = ['tag_a', 'tag_b', 'tag_c']

    taggable_2 = Taggable()
    taggable_2._tags = []

    taggable_3 = Taggable()
    taggable_3._tags = ['always']

    taggable_4 = Taggable()
    taggable_4._tags = ['never']

    # Testing with only_tags set
    # scenario 1: taggable with only_tags should be executed
    only_tags = ['tag_a', 'tag_b', 'tag_d']
    skip_tags = []
    vars = {}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, vars) == True
    assert tagg