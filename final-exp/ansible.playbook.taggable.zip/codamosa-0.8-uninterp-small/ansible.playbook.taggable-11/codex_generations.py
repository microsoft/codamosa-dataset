

# Generated at 2022-06-25 06:05:47.008986
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create the base object
    taggable_0 = Taggable()

    # Create the arguments
    only_tags = [u'all', u'always']
    skip_tags = [u'tagged', u'never']
    all_vars = {u'test': u'unit-test'}

    # Run the method
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    # Check the results
    assert result is True

# Generated at 2022-06-25 06:05:48.207789
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:05:56.976767
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tag1', 'tag2']
    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = None
    assert taggable_0.evaluate_tags(only_tags, skip_tags, {})
    # Test with skip_tags
    only_tags = None
    skip_tags = ['tag1', 'tag2']
    assert taggable_0.evaluate_tags(only_tags, skip_tags, {}) == False
    # Test with both
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag1', 'tag2']
    assert taggable_0.evaluate_tags(only_tags, skip_tags, {}) == False
    # Test with

# Generated at 2022-06-25 06:06:02.736930
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable(tags={'always'})
    assert taggable_0.evaluate_tags(only_tags={'always'}, skip_tags={'never'}, all_vars={}) == True
    taggable_1 = Taggable(tags={'never'})
    assert taggable_1.evaluate_tags(only_tags={'always'}, skip_tags={'never'}, all_vars={}) == False
    taggable_2 = Taggable(tags={'always', 'never'})
    assert taggable_2.evaluate_tags(only_tags={'always'}, skip_tags={'never'}, all_vars={}) == True
    taggable_3 = Taggable(tags={'always', 'never'})
    assert taggable_3.evaluate_

# Generated at 2022-06-25 06:06:08.498268
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['A', 'B', 'C']
    assert taggable_0.evaluate_tags(['C', 'D'], ['A'], {})
    assert taggable_0.evaluate_tags([], ['B', 'C'], {})
    assert not taggable_0.evaluate_tags(['A', 'B'], ['C'], {})

# Generated at 2022-06-25 06:06:11.635554
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

# Test case 1:
# Test when only_tags = ['all'], skip_tags = ['docker']
# and this.tags = ['all', 'docker']

# Generated at 2022-06-25 06:06:15.175560
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['all'], ['all'], []) == True
    assert taggable_0.evaluate_tags(['all'], ['all'], []) == True


# Generated at 2022-06-25 06:06:17.250295
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True


# Generated at 2022-06-25 06:06:26.577808
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    skip_tags_0 = None
    only_tags_0 = None
    all_vars_0 = {}
    
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True

    taggable_1 = Taggable()
    skip_tags_1 = ['always']
    only_tags_1 = None
    all_vars_1 = {}
    taggable_1.tags = ['never']
    
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1) == False

    taggable_2 = Taggable()
    skip_tags_2 = ['always']

# Generated at 2022-06-25 06:06:35.473001
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['always', '', 'never']
    only_tags_1 = ['always', '', 'never']
    skip_tags_1 = None
    all_vars_1 = {'test_Taggable_evaluate_tags_1': '2'}
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)

    taggable_2 = Taggable()
    taggable_2.tags = ''
    only_tags_2 = ['always', '', 'never']
    skip_tags_2 = None
    all_vars_2 = {'test_Taggable_evaluate_tags_2': '2'}
    assert taggable_2.evaluate_

# Generated at 2022-06-25 06:06:49.313329
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = 'yw'
    skip_tags = 0.0
    all_vars = -0.01
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    return var_0

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:06:51.758036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

# Generated at 2022-06-25 06:06:55.218541
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:00.744950
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ["ansible_os_family", "RedHat"]
    skip_tags = ["notags"]
    dict_0 = {'tags': tags}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(skip_tags, skip_tags, skip_tags)
    assert var_0 is not False

# Generated at 2022-06-25 06:07:07.128789
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)


# Generated at 2022-06-25 06:07:11.065834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:07:19.434327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('Testing evaluate_tags of Taggable ... ', end='')

    # Test with a provided list of tags
    taggable = Taggable(tags = ['a', 'b', 'c'])
    assert taggable.evaluate_tags(None, None, None) == True
    assert taggable.evaluate_tags(['b'], None, None) == True
    assert taggable.evaluate_tags(['b', 'c', 'd'], None, None) == True
    assert taggable.evaluate_tags(['e'], None, None) == False
    assert taggable.evaluate_tags(['a', 'e'], None, None) == False
    assert taggable.evaluate_tags(None, ['b'], None) == False

# Generated at 2022-06-25 06:07:22.051763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    global str_0, float_0, dict_0, taggable_0, var_0
    
    # Execution of method evaluate_tags
    test_case_0()

    # Verify
    assert var_0 == False



# Generated at 2022-06-25 06:07:28.545292
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {"tags": ["", ""]}
    taggable_0 = Taggable(**dict_0)
    bool_0 = taggable_0.evaluate_tags("", "", "")
    assert bool_0
    assert bool_0


# Generated at 2022-06-25 06:07:33.008122
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:52.464768
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)


# Generated at 2022-06-25 06:07:56.832072
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

# Generated at 2022-06-25 06:08:00.127292
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_1 = 'E$tA.k'
    float_1 = -2101.0
    dict_1 = {}
    taggable_1 = Taggable(**dict_1)
    var_0 = taggable_1.evaluate_tags(str_1, float_1, float_1)

# Generated at 2022-06-25 06:08:09.501169
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = '-p+t*'
    str_1 = 'b2n9.o'
    str_2 = '?8{t/'
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, str_1, str_2)
    assert var_0 is not True
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, str_1, str_2)
    assert var_0 is not True
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_

# Generated at 2022-06-25 06:08:18.190435
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'Lf2'
    str_1 = '4E[B'
    int_0 = -1516
    str_2 = 'm'
    list_0 = [str_1, int_0]
    str_3 = 'fX'
    float_0 = -832.0
    str_4 = '1'
    list_1 = [str_2, str_3, str_4]
    str_5 = 'xG4~'
    str_6 = 'T:_X'
    list_2 = [str_5, str_6]
    list_3 = [list_2]
    str_7 = 'h]_'
    list_4 = [str_7]
    list_5 = [list_4]
    str_8 = 'HA'
    str

# Generated at 2022-06-25 06:08:28.296918
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from sys import exc_info

    try:
        test_case_0()
    except:
        # An error occurred.
        err = exc_info()[1]
        if not isinstance(err, AssertionError):
            # Not the error we were expecting. Reraise it.
            raise
        x = err.args[0]
        print(x)
        assert x == "or(isinstance(x, (list)), isinstance(x, (list)))"

if __name__ == '__main__':
    # pylint: disable=W0101
    # Run unit tests.
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:32.329767
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  ta = Taggable()
  ta.tags = ['a', 'b', 'c']

  ta.evaluate_tags('a', 'b', 'c')

# Generated at 2022-06-25 06:08:34.125539
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Verifies that evaluate_tags properly decodes the tags list of a Taggable object
    assert False

# Generated at 2022-06-25 06:08:35.271058
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('Test case 0')
    test_case_0()

# Generated at 2022-06-25 06:08:38.925718
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)



# Generated at 2022-06-25 06:09:12.449415
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Case 0
    try:
        str_0 = 'E$tA.k'
        float_0 = -2101.0
        dict_0 = {}
        taggable_0 = Taggable(**dict_0)
        var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)
    except SystemExit:
        pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:09:13.344492
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert test_case_0() == None

# Generated at 2022-06-25 06:09:23.907920
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    x_0 = [2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0]
    y_0 = [2.0, 2.0, 2.0]
    z_0 = [2.0, 2.0, 2.0]
    try:
        a_0 = [2.0, 2.0, 2.0]
        b_0 = [2.0, 2.0, 2.0]
        c_0 = [2.0, 2.0, 2.0]
        d_0 = [2.0, 2.0, 2.0]
    except:
        pass

# Generated at 2022-06-25 06:09:25.967482
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        test_case_0()
    except AnsibleError as e:
        pass


# Generated at 2022-06-25 06:09:35.587963
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Method argument types
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    float_1 = -2101.0
    # Test case
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)
    assert isinstance(var_0, bool)
    # Test case
    str_0 = 't'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags

# Generated at 2022-06-25 06:09:42.077182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #instantiate taggable
    taggable_0 = Taggable(**dict())
    #dict value to pass to evaluate_tags
    dict_0 = {}
    #dict_0['key'] = 'value'
    #str value to pass to evaluate_tags
    str_0 = 'E$tA.k'
    #float value to pass to evaluate_tags
    float_0 = -2101.0
    #call method evaluate_tags
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)


# Generated at 2022-06-25 06:09:48.405215
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)



# Generated at 2022-06-25 06:09:55.329623
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2102.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)
    assert var_0 == False


# Generated at 2022-06-25 06:10:05.791597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = '-A+'
    float_0 = 0.8
    list_0 = [str_0, '', float_0]
    int_0 = 10
    str_1 = 'R'
    int_1 = 4
    float_1 = 0.036
    dict_0 = {'_tags': list_0}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_1, int_1, var_0, var_0, var_0, list_0)
    var_1 = taggable_0.evaluate_tags(str_0, int_0, var_0, var_0, var_0, list_0)

# Generated at 2022-06-25 06:10:08.841752
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

# Generated at 2022-06-25 06:11:20.216563
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Check that a function called within a class method returns the correct value to the caller.
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

# Generated at 2022-06-25 06:11:26.827590
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)



# Generated at 2022-06-25 06:11:34.128662
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    play_0 = dict(
        name="This is a test playbook",
        gather_facts=True,
        roles=[],
    )
    playbook_0 = Playbook.load(play_0, variable_manager=None, loader=None)
    variables_0 = {'foo': 'bar'}
    host_0 = Host(name='foo')
    task_0 = Task()
    task_0._role = Role()
    task_0._role.name = 'foo'
    task_0._role.get_path = lambda: 'foo'
    task_0.name = 'foo'
    task_0.tags = ['foo']
    task_0._ds = {'name': 'foo'}
    task_0._role._task_blocks = {'foo': [task_0]}
    task_0._role._

# Generated at 2022-06-25 06:11:41.353905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = '!0M#'
    float_0 = 1514.0
    dict_0 = {'a': '', 'b': ';'}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)
    var_1 = taggable_0.evaluate_tags(dict_0, str_0, float_0)
    var_2 = taggable_0.evaluate_tags(dict_0, float_0, str_0)
    var_3 = taggable_0.evaluate_tags(str_0, dict_0, float_0)
    var_4 = taggable_0.evaluate_tags(str_0, float_0, dict_0)
   

# Generated at 2022-06-25 06:11:47.447772
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'Jm2H3dD'
    float_0 = 0.5
    float_1 = -0.5
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_1)
    assert var_0 == False


# Generated at 2022-06-25 06:11:51.734320
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)




# Generated at 2022-06-25 06:11:54.292399
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = '@'
    float_0 = -0.19
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)


# Generated at 2022-06-25 06:12:03.957529
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    int_0 = 1415
    bool_0 = True
    taggable_0 = Taggable(tags=int_0)
    var_0 = taggable_0.evaluate_tags(int_0, int_0, int_0)
    str_0 = '{z>njC<'
    float_0 = 1207.0
    taggable_1 = Taggable(tags=float_0)
    var_1 = taggable_1.evaluate_tags(str_0, str_0, float_0)
    str_1 = '5C5H]h'
    str_2 = 'PRo:V'
    taggable_2 = Taggable(tags=str_2)

# Generated at 2022-06-25 06:12:06.008709
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        pass


# Generated at 2022-06-25 06:12:12.360316
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:05.979586
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'IyR{&x]~Q'
    list_0 = [4141, 'sOqB8j', 543.389044748, 'k1_xn6U', 748, 0.638748241893]
    list_1 = [0.51453, 'g+fPTJ%c', 944, '^ZpIq)', 0.81798]
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, list_0, list_1)
    assert var_0 == True


# Generated at 2022-06-25 06:15:12.195056
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

# Generated at 2022-06-25 06:15:17.072995
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = '^y2G#1'
    float_0 = 435.347
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)


# Generated at 2022-06-25 06:15:21.861534
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'Rz\xeb'
    int_0 = -16285
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)


# Generated at 2022-06-25 06:15:23.350552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create an instance of Taggable
    verify_0 = test_case_0()


# Generated at 2022-06-25 06:15:30.177183
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test case
    """

    # Test case for Taggable.evaluate_tags

    str_0 = 'E$tA.k'
    float_0 = -2101.0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(str_0, float_0, float_0)

