

# Generated at 2022-06-25 06:05:54.418563
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    # This does not fail and should fail because taggable has no value for tags
    taggable._load_tags(attr='tags', ds=[5,6])

    tags = [ 'one', 'two', 'three' ]
    taggable.tags = tags
    taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    all_vars = {}
    taggable.evaluate_tags(only_tags=tags, skip_tags=tags, all_vars=all_vars)
    taggable.evaluate_tags(only_tags=tags, skip_tags=[], all_vars=all_vars)

# Generated at 2022-06-25 06:06:00.778058
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # data for unit test
    taggable_1 = Taggable()
    taggable_1.tags=['all']
    only_tags = ['all']
    skip_tags = ['all']
    all_vars = {}
    # call the method
    expected = 1
    actual = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert actual == expected, 'actual: %s, expected: %s' % (actual, expected)

# Generated at 2022-06-25 06:06:10.061324
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 0:
    test_case_0()

    # Case 1:
    taggable_1 = Taggable()
    taggable_1.tags = ['test_tags0', 'test_tags1', 'test_tags2' ]
    only_tags = ['test_tags0', 'test_tags1']
    skip_tags = ['test_tags2']
    all_vars = {'tag': {'test_tags0': 'tagged', 'test_tags1': 'tagged', 'test_tags2': 'tagged', 'test_tags3': 'tagged' }}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Case 2:
    taggable_2 = Taggable()

# Generated at 2022-06-25 06:06:14.266971
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = "fake_only_tags"
    skip_tags = "fake_skip_tags"
    all_vars = {}
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:06:25.723247
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['T1', 'T2']

    # Only tags
    assert Taggable().evaluate_tags(tags, None, {}) # No tags

    for t in tags:
        assert Taggable().evaluate_tags(tags, None, {'tags': t}) # One tag

    assert Taggable().evaluate_tags(tags, None, {'tags': ['not-a-tag']}) # Tag that doesn't match

    assert Taggable().evaluate_tags(tags, None, {'tags': tags}) # All tags

    # Skip tags
    assert Taggable().evaluate_tags(None, tags, {}) # No tag

    for t in tags:
        assert not Taggable().evaluate_tags(None, tags, {'tags': t}) # One tag


# Generated at 2022-06-25 06:06:35.427520
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Used to store the result from the evaluation of tags
    result = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by evaluate_tags
    result_should = {}

    # Used to store the value that should have been returned by

# Generated at 2022-06-25 06:06:39.191142
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = ['foo', 'bar']

    # Evaluate the tags
    only_tags = ['foo', 'baz']
    skip_tags = ['tagged', 'foobar']
    all_vars = {}
    should_run = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test if the result is correct
    assert should_run == True, "Tag evaluation failed"

# Generated at 2022-06-25 06:06:42.251555
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['a']
    assert taggable is not None
    assert eval('taggable._tags') == ['a']
    assert taggable.evaluate_tags('b', 'c', 'd') == True

# Generated at 2022-06-25 06:06:51.871738
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    all_vars = dict()
    taggable_obj = Taggable()

# Generated at 2022-06-25 06:07:03.006982
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test with the case where tags = untagged and only_tags = ['tagged','untagged']
    taggable_1 = Taggable()
    taggable_1.tags = Taggable.untagged
    only_tags_1 = ['tagged','untagged']
    all_vars_1 = {}
    assert (taggable_1.evaluate_tags(only_tags_1, set(), all_vars_1) == True)

    # Test with the case where tags = ['untagged'] and only_tags = ['tagged','untagged']
    taggable_2 = Taggable()
    taggable_2.tags = list(Taggable.untagged)
    only_tags_2 = ['tagged','untagged']
    all_vars_2 = {}

# Generated at 2022-06-25 06:07:26.036537
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1._tags=['first', 'second', 'third']
    assert taggable_1.evaluate_tags(['first','second','third'],None,{})==True
    taggable_2 = Taggable()
    taggable_2._tags=['first', 'second', 'third']
    assert taggable_2.evaluate_tags(['first','second','third'],['third'],{})==True
    taggable_3 = Taggable()
    taggable_3._tags=['first', 'second', 'third']
    assert taggable_3.evaluate_tags(['first','second'],['third'],{})==True
    taggable_4 = Taggable()

# Generated at 2022-06-25 06:07:27.394613
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # self.assertTrue(Taggable().evaluate_tags())
    pass

# Generated at 2022-06-25 06:07:36.312092
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    taggable_0.tags = ['test_tag']
    assert taggable_0.evaluate_tags(['test_tag'], [], {})
    assert taggable_0.evaluate_tags(['all'], [], {})
    assert taggable_0.evaluate_tags(['always'], [], {})
    assert taggable_0.evaluate_tags(['tagged'], [], {})
    assert not taggable_0.evaluate_tags([], ['test_tag'], {})
    assert not taggable_0.evaluate_tags([], ['all'], {})
    assert not taggable_0.evaluate_tags([], ['always'], {})

# Generated at 2022-06-25 06:07:47.085389
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test case #1
    taggable_1 = Taggable()
    taggable_1.tags = None
    assert taggable_1.evaluate_tags(None, None, None) == True

    # test case #2
    taggable_2 = Taggable()
    taggable_2.tags = ['tag-1', 'tag-2']
    assert taggable_2.evaluate_tags(None, None, None) == True

    # test case #3
    taggable_3 = Taggable()
    taggable_3.tags = None
    assert taggable_3.evaluate_tags(['tag-1', 'tag-2'], None, None) == False

    # test case #4
    taggable_4 = Taggable()

# Generated at 2022-06-25 06:07:47.613714
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-25 06:07:53.833706
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = [ 'foo' ]
    assert taggable.evaluate_tags(
        only_tags = [ 'foo', 'bar' ],
        skip_tags = [ 'buzz' ],
        all_vars = { 'foo': 'bar' }
    )


# Generated at 2022-06-25 06:08:01.823606
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("test_Taggable_evaluate_tags")

    # All tags
    t = Taggable()

    # No tags to run or skip
    t._tags = []
    assert t.evaluate_tags([], [], []) == True

    # Check if we run all
    t._tags = ['all']
    assert t.evaluate_tags(['all'], [], []) == True

    # Check if we skip all
    t._tags = ['all']
    assert t.evaluate_tags([], ['all'], []) == False

    # Check if we run all
    t._tags = ['all']
    assert t.evaluate_tags(['all'], ['other'], []) == True

    # Check if we run all
    t._tags = ['all']

# Generated at 2022-06-25 06:08:08.437250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test: call evaluate_tags with a specific value for only_tags and skip_tags
    taggable_0 = Taggable()
    taggable_0.tags = 'verified'
    only_tags = ['verified']
    skip_tags = ['verified']
    all_vars = {}
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False


# Generated at 2022-06-25 06:08:17.112769
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    task = dict(name = "test_task", tags = ["foo", "bar"])
    task2 = dict(name = "test_task2", tags = ["baz", "qux"])
    task3 = dict(name = "test_task3", tags = ["foo", "bar", "baz", "qux", "always"])
    task4 = dict(name = "test_task4", tags = ["never"])

    assert taggable.evaluate_tags([], [], task) is True
    assert taggable.evaluate_tags(["all"], [], task) is True
    assert taggable.evaluate_tags(["bar"], [], task) is True
    assert taggable.evaluate_tags(["foo"], [], task) is True
    assert taggable.evaluate

# Generated at 2022-06-25 06:08:21.504933
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    assert taggable.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={
        'inventory_hostname': 'localhost'
    }) == True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:08:42.790752
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Assertions
    assert(taggable_1.evaluate_tags(list_0, list_0, str_0) == True)
    assert(taggable_1.evaluate_tags(list_0, list_0, str_0) == True)
    assert(taggable_1.evaluate_tags(list_0, list_0, str_0) == True)
    assert(taggable_1.evaluate_tags(list_0, list_0, str_0) == True)
    assert(taggable_1.evaluate_tags(list_0, list_0, str_0) == True)
    assert(taggable_1.evaluate_tags(list_0, list_0, str_0) == True)

# Generated at 2022-06-25 06:08:48.218350
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)



# Generated at 2022-06-25 06:08:51.845327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class_0 = Taggable()
    float_0 = None
    tuple_0 = None
    str_0 = 'w4yi'
    var_0 = class_0.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 == True
    pass

# Generated at 2022-06-25 06:08:59.759543
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test zero arg method
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 is None

    # test one arg method
    list_0 = None
    taggable_1 = Taggable(*list_0)
    var_1 = taggable_1
    assert var_1 is not None

# Generated at 2022-06-25 06:09:03.896474
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 == True

# Test for public class method of class Taggable

# Generated at 2022-06-25 06:09:08.680384
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 is not None


# Generated at 2022-06-25 06:09:17.581073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup:
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()

    # Testing
    # assert taggable_0.evaluate_tags(float_0, tuple_0, str_0) is None, \
    #     'AssertionError: assert None == None'
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)

    # Testing
    # assert var_0 is True
    list_0 = None
    taggable_1 = Taggable(*list_0)
    # assert taggable_0._tags is True
    # assert taggable_0.untagged is True
    # assert taggable_0._load_tags(float_0,

# Generated at 2022-06-25 06:09:24.752533
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
	# test_case_0:
	float_0 = None
	tuple_0 = None
	str_0 = 'glSj'
	taggable_0 = Taggable()
	var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
	assert type(var_0) == bool, "Return type should be bool"
	# test_case_1:
	float_0 = None
	tuple_0 = None
	str_0 = 'CNVm'
	taggable_0 = Taggable()
	var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
	assert type(var_0) == bool, "Return type should be bool"

# Generated at 2022-06-25 06:09:34.594938
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = dict
    dict_1 = dict
    str_0 = 'i'
    taggable_0 = Taggable(dict_0, dict_1, *str_0)
    taggable_1 = Taggable(dict_0, dict_1, *str_0)
    taggable_2 = Taggable(dict_0, dict_1, *str_0)
    taggable_3 = Taggable(dict_0, dict_1, *str_0)
    taggable_4 = Taggable(dict_0, dict_1, *str_0)
    taggable_5 = Taggable(dict_0, dict_1, *str_0)
    taggable_6 = Taggable(dict_0, dict_1, *str_0)
   

# Generated at 2022-06-25 06:09:38.441377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)



# Generated at 2022-06-25 06:10:14.083316
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    check_object(var_0, bool, 'equals', True)
    assert var_0 == True
    list_0 = None
    taggable_1 = Taggable(*list_0)
    float_1 = None
    dict_0 = dict()
    str_1 = 'glSj'
    var_1 = taggable_1.evaluate_tags(float_1, dict_0, str_1)
    check_object(var_1, bool, 'equals', True)
    assert var_1 == True

# Generated at 2022-06-25 06:10:17.164014
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 is True


# Generated at 2022-06-25 06:10:21.422676
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    # assert type(var_0) == bool
    # assert var_0 == True


# Generated at 2022-06-25 06:10:25.317415
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 == True


# Generated at 2022-06-25 06:10:29.700592
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)


# Generated at 2022-06-25 06:10:34.107497
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test 1: passing float_0 = None, tuple_0 = None and str_0 = 'glSj'
    test_Taggable_evaluate_tags_1()

    # Test 2: passing list_0 = None
    test_Taggable_evaluate_tags_2()

# This tests the method evaluate_tags() of the class Taggable while passing float_0 = None, tuple_0 = None and str_0 = 'glSj'

# Generated at 2022-06-25 06:10:34.864431
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert 1



# Generated at 2022-06-25 06:10:38.010604
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert True


# Generated at 2022-06-25 06:10:40.255348
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    string_0 = 'Gj.'
    list_0 = []
    string_1 = ':<w'
    taggable_0 = Taggable()
    assert not taggable_0.evaluate_tags(string_0, list_0, string_1)



# Generated at 2022-06-25 06:10:44.408770
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)



# Generated at 2022-06-25 06:11:46.198100
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)



# Generated at 2022-06-25 06:11:54.369397
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # First test case
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    assert(var_0 == True)

    # Test case where the variable self._tags is set
    list_0 = None
    taggable_1 = Taggable(*list_0)
    taggable_1._tags = 'xQxI'
    float_1 = None
    tuple_1 = None
    str_1 = 'lClr'
    var_1 = taggable_1.evaluate_tags(float_1, tuple_1, str_1)
    assert(var_1 == True)

    # Test

# Generated at 2022-06-25 06:12:03.959318
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    list_0 = None
    taggable_1 = Taggable(*list_0)
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    var_1 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    var_2 = taggable_1.evaluate_tags(float_0, tuple_0, str_0)
    var_3 = taggable_1.evaluate_tags(float_0, tuple_0, str_0)
    assert var_0 is True
    assert var_1 is True
    assert var_2 is True
    assert var

# Generated at 2022-06-25 06:12:14.018808
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)
    str_1 = 'CXb'
    taggable_1.tags = str_1
    str_2 = 'zg'
    taggable_1.tags = str_2
    str_3 = 'pE'
    taggable_1.tags = str_3
    str_4 = 'I1'
    taggable_1.tags = str_4
    str_5 = 'J'

# Generated at 2022-06-25 06:12:22.294824
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    import random
    import string
    import json
    import sys
    import ansible.module_utils.basic

    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)
    assert var_0 == True
    assert taggable_1 is not None
    assert taggable_0 is not None
    


# Generated at 2022-06-25 06:12:26.428050
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)

if __name__ == "__main__":
    import sys
    sys.exit(main())

# Generated at 2022-06-25 06:12:34.004432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)
    float_1 = None
    tuple_1 = None
    var_1 = taggable_1.evaluate_tags(float_1, tuple_1, float_0)
    float_2 = None
    tuple_2 = None
    var_2 = taggable_1.evaluate_tags(float_2, tuple_2, float_0)
    float_3 = None
    tuple_3 = None
    var_3 = taggable_1.evaluate_

# Generated at 2022-06-25 06:12:36.556250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)


# Generated at 2022-06-25 06:12:38.297017
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert evaluate_tags(self, float_0, tuple_0, str_0)



# Generated at 2022-06-25 06:12:48.081394
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test with the exact type
    tags = ('untagged',)
    only_tags = ('tagged',)
    skip_tags = ('tagged',)
    all_vars = 'glSj'
    taggable_0 = Taggable(tags)
    var_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert isinstance(var_0, bool)
    assert var_0

    # Test with the exact type
    tags = ('untagged',)
    only_tags = ('tagged', 'all')
    skip_tags = ('untagged', 'tagged', 'all')
    all_vars = 'glSj'
    taggable_0 = Taggable(tags)
    var_0 = taggable_0.evaluate_tags

# Generated at 2022-06-25 06:15:33.293235
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    tuple_0 = None
    str_0 = 'glSj'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(float_0, tuple_0, str_0)
    list_0 = None
    taggable_1 = Taggable(*list_0)
    float_1 = None
    tuple_1 = None
    str_1 = 'glSj'
    var_1 = taggable_1.evaluate_tags(float_1, tuple_1, str_1)

# Generated at 2022-06-25 06:15:35.533748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
   pass

