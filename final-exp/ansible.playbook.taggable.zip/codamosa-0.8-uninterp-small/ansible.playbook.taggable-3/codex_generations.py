

# Generated at 2022-06-25 06:05:50.812156
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    assert taggable.evaluate_tags(set(['a', 'b', 'c']), set(['a']), {})

    assert taggable.evaluate_tags(set(['d']), set(['a', 'b', 'c']), {})

    assert taggable.evaluate_tags(set(['d']), set(['a', 'b', 'c']), {})

    assert not taggable.evaluate_tags(set(['a']), set(['a']), {})

    assert taggable.evaluate_tags(set([]), set([]), {})

    assert taggable.evaluate_tags(set(['always']), set([]), {})

    assert taggable.evaluate_tags(set([]), set(['never']), {})


# Generated at 2022-06-25 06:05:56.592665
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    taggable_0 = Taggable()
    taggable_0.tags = ['tag1']
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = {u'inventory_hostname': u'localhost'}

    # Act
    result = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

    # Assert
    assert result == True


# Generated at 2022-06-25 06:06:02.387859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['TEST_TAG_STRING']
    # Test case config
    only_tags = ['TEST_TAG_STRING']
    skip_tags = []
    all_vars = {}
    # test case
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    if should_run:
        print('Test case \'%s\' passed' % ('test_Taggable_evaluate_tags_0',))

    # test case with an invalid tag
    taggable.tags = ['INVALID_TAG']
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:06:08.185385
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Test case 0
    # Initialize taggable_0
    taggable_0._tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = []
    all_vars = dict()
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result_0 == True

# Generated at 2022-06-25 06:06:18.584617
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:06:27.528201
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    only_tags = ['tag_1', 'tag_2']
    skip_tags = ['tag_3', 'tag_4']
    all_vars = {'tag_1': ['tag_1'], 'tag_3': ['tag_3']}
    taggable.tags = all_vars['tag_1']
    result_0 = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    result_1 = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    result_2 = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    result_3 = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:06:33.266463
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = None
    only_tags = set(['always'])
    skip_tags = set(['never'])
    all_vars = {}
    result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True


# Generated at 2022-06-25 06:06:41.888144
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()

    only_tags = ['all']
    skip_tags = ['all']
    all_vars = {}

    # Run the evaluate_tags method of class Taggable for the following values
    ans = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    # Print error if actual value does not match expected value
    if ans != False:
        print('\nEvaluate_tags method of class Taggable failed for above parameters')
if __name__ == "__main__":
    ''' Main method '''

    # Run the test cases defined
    test_case_0()
    test_Taggable_evaluate_tags()
# Sample code for loading tags for method _load_tags for class Taggable
#
#
#     if isinstance

# Generated at 2022-06-25 06:06:51.818362
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable.tags = ['always', 'devel', 'basic']
    all_vars = dict()

    # Only case 1
    only_tags = ['tagged', 'basic']
    skip_tags = None
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    expected = True
    assert result == expected

    # Only case 2
    only_tags = ['tagged', 'basic']
    skip_tags = ['foobar']
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    expected = True
    assert result == expected

    # Skip case 1
    only_tags = None
    skip_tags = ['basic', 'devel']
    result = taggable.evaluate_

# Generated at 2022-06-25 06:06:55.171738
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass


# Generated at 2022-06-25 06:07:04.883546
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    assert var_0 == True
    taggable_1 = Taggable()

# Generated at 2022-06-25 06:07:08.868832
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test_case_0")
        print(e)

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:17.219338
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xe5)\x92\xfb\xef\xf1@\xef\xd5}\x93\xc0'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = 167
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    taggable_1 = Taggable()


# Generated at 2022-06-25 06:07:26.831006
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    assert var_0 == False
    taggable_1 = Taggable()
    taggable_2 = Taggable()
    taggable_0.tags = list_1
    taggable_0.evaluate_tags(taggable_1, taggable_2, int_0)

# Generated at 2022-06-25 06:07:34.562266
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    var_1 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    taggable_1 = Taggable()


# Generated at 2022-06-25 06:07:40.616332
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    list_1 = []
    int_0 = -276
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    assert var_0 == True


# Generated at 2022-06-25 06:07:48.699895
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    assert var_0 == True
    taggable_1 = Taggable()
    list_2 = []
    list_3 = []
    int_1 = -277
    var_1 = taggable_1.evaluate_tags(list_2, list_3, int_1)
    assert var_1 == True
    list_4 = []

# Generated at 2022-06-25 06:07:50.792598
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True == True
#    test_case_0()

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:00.058440
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = ''
    only_tags = []
    skip_tags = []
    all_vars = []
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable_1 = Taggable()
    taggable_1._tags = ''
    only_tags = []
    skip_tags = []
    all_vars = []
    taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 06:08:07.061726
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)

# Generated at 2022-06-25 06:08:24.765182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_2 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_2, list_1, int_0)


# Generated at 2022-06-25 06:08:30.245984
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Demonstrate the ability to evaluate whether an object should run
    # based on the presence of tags, which is a list of lists 
    list_0 = []

# Generated at 2022-06-25 06:08:37.424936
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('Creating test objects for unit test')
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    print('Testing method evaluate_tags of class Taggable')
    # assert var_0 == False


# Generated at 2022-06-25 06:08:38.521660
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:08:39.409790
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True


# Generated at 2022-06-25 06:08:43.544472
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = [b'\x9e\x01\r\x16\x87', b'\x9e\x01\r\x16\x87', b'\x9e\x01\r\x16\x87']
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)

# Generated at 2022-06-25 06:08:50.487779
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    assert var_0 is False
    list_2 = ['tagged', 'never']
    int_1 = -278
    assert (taggable_0.evaluate_tags(list_0, list_2, int_1) is True)

# Generated at 2022-06-25 06:08:57.951520
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import random, string
    # Randomize inputs
    list_0 = []
    for x in range(100):
        random_string = ''.join(random.choice(string.ascii_letters) for y in range(random.randint(1, 10)))
        list_0.append(random_string)
    list_1 = []
    for x in range(100):
        random_string = ''.join(random.choice(string.ascii_letters) for y in range(random.randint(1, 10)))
        list_1.append(random_string)
    int_0 = random.randint(1, 100000000)

    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    tagg

# Generated at 2022-06-25 06:08:59.995783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = list()
    list_1 = list()
    int_0 = 0
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    #assert var_0 == ???


# Generated at 2022-06-25 06:09:03.180246
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # default values of the arguments of the function
    only_tags = []
    skip_tags = []
    all_vars = 0

    taggable = Taggable()
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) is True

# Generated at 2022-06-25 06:09:37.358309
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = ['pmU\xa5\x97\xd6\xfc\x0c\x13\xda\x9f\xacR', '\x1c\xaf\x8a\xa4\xdf\xdf\x9c\xd6I\xb6\xcc\xc5']

# Generated at 2022-06-25 06:09:45.054700
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case
    taggable_0 = Taggable()
    str_0 = "6\xed\xfa\x12\x9a\xe6\xdf\x05\x85\xce"
    list_0 = [str_0, str_0]
    list_1 = []
    list_2 = []
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(list_0, list_1, list_2)
    

# Generated at 2022-06-25 06:09:51.915074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    assert var_0 == True
    taggable_1 = Taggable()

# Generated at 2022-06-25 06:09:54.146305
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        test_case_0()
    except Exception as err:
        print(err)

# Python 2/3 compatibility
if __name__ == "__main__":
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:10:01.408778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert test_case_0() 

try:
    method_0 = Taggable()
    method_0._load_tags()
except BaseException as err_0:
    bytes_0 = method_0.api_response(method_0.login_account)
    bytes_1 = b'\xe7\xd5\xdb\x8c\x1f\xba\x94\xba\x8e!\xa9'


# Generated at 2022-06-25 06:10:09.665622
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create an instance of Taggable
    taggable_0 = Taggable()
    print('taggable_0 = ' + str(taggable_0))

    # Get a reference to the method evaluate_tags defined in the class Taggable
    method_evaluate_tags = getattr(taggable_0, 'evaluate_tags')

    # The following throws an exception if the method evaluate_tags does not exist.
    if method_evaluate_tags is None:
        raise Exception('Method evaluate_tags in class Taggable does not exist.')

    # The following throws an exception if the method evaluate_tags takes other arguments than those specified.
    args = []

# Generated at 2022-06-25 06:10:10.896376
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    assert True == True


# Generated at 2022-06-25 06:10:15.933758
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:10:17.476649
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()
    assert isinstance(taggable_obj.evaluate_tags(), object)


# Generated at 2022-06-25 06:10:26.299535
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t0 = Taggable()

    # verify that the default value is correct
    assert t0.tags is not None

    # check that a value of None is acceptable
    t0 = Taggable()
    t0._load_tags('tags', None)
    assert t0.tags is None

    t0 = Taggable()
    t0._load_tags('tags', 'a,b,c')
    assert t0.tags == ['a', 'b', 'c']

    t0 = Taggable()
    t0._load_tags('tags', ['a', 'b', 'c'])
    assert t0.tags == ['a', 'b', 'c']

    # check that unknown types are handled
    t0 = Taggable()

# Generated at 2022-06-25 06:11:32.756866
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    int_0 = -36
    bytes_0 = b'\xb6\x94\xef\xc4\x8d\xb1\xdd\x13\xda\x81q\x10'
    list_0 = [bytes_0, bytes_0]
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_0, int_0)


# Generated at 2022-06-25 06:11:38.406021
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    taggable_1 = Taggable()

# Generated at 2022-06-25 06:11:49.080401
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._load_tags(list())
    taggable_1 = Taggable()
    taggable_1._load_tags('')
    taggable_2 = Taggable()
    taggable_2._load_tags('{\n  "stdout": "",\n  "stdout_lines": [\n    \n  ],\n  "stdout_json": null,\n  "failed": false,\n  "changed": true\n}')
    taggable_3 = Taggable()
    taggable_3._load_tags('', list())
    taggable_4 = Taggable()
    taggable_4._load_tags('', '')
    taggable_5 = Taggable()
   

# Generated at 2022-06-25 06:11:58.662280
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert isinstance(test_Taggable_evaluate_tags, object)
    taggable_t = Taggable()
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_1 = [bytes_0, bytes_0, bytes_0]
    list_2 = []
    int_0 = -277
    var_0 = taggable_t.evaluate_tags(list_1, list_2, int_0)
    assert isinstance(var_0, object)

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:12:10.876261
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    bytes_0 = b'\xdd\x03\x1f\xe2\xc5\xb2\x8c\x9f\x9a\x15'
    list_0 = [bytes_0, bytes_0]
    list_1 = []
    int_0 = 12
    assert taggable_0.evaluate_tags(list_0, list_1, int_0) == False
    assert taggable_0.evaluate_tags(list_1, list_0, int_0) == False
    assert taggable_0.evaluate_tags(list_1, list_1, int_0) == False
    assert taggable_0.evaluate_tags(list_0, list_0, int_0) == False
    assert taggable_0

# Generated at 2022-06-25 06:12:12.820839
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:12:16.548381
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    taggable_1 = Taggable()


# Generated at 2022-06-25 06:12:25.958658
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(list_0, list_1, int_0) is True
    taggable_1 = Taggable()
    taggable_1.tags = ['<file_name>', '\x80\xa1\x95\xa0\xda\x0c\xf7\xa6_\x8d\x17\x0c\x9a']
    # test of evaluate_tags with complex objects

# Generated at 2022-06-25 06:12:31.620763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xb3\x9c5\x18\xc7\xff\xecR\xb3\xb4\xe2\xa5'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -277
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    taggable_1 = Taggable()


# Generated at 2022-06-25 06:12:33.012751
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:15:17.275043
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(["*"], [], "*")


if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:18.904376
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Test Taggable()
# Unit Test for Taggable() class

# Generated at 2022-06-25 06:15:30.418545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    Taggable_0 = Taggable()
    list_0 = ['d', 'lV\x0bS\x1d']
    list_1 = []

# Generated at 2022-06-25 06:15:38.293051
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\xa0\xbe\x18\x1d\x04v\xa4\x12\xe7\x9a\x9d'
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = []
    int_0 = -274
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(list_0, list_1, int_0)
    taggable_1 = Taggable()
