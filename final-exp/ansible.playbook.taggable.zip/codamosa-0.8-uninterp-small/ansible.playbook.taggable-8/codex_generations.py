

# Generated at 2022-06-25 06:05:44.308198
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ['foo']
    skip_tags_0 = ['bar']
    all_vars_0 = dict()
    ans_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert ans_0 == False
    print('Pass')


# Generated at 2022-06-25 06:05:52.362347
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = {}
    try:
        taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
        assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True
    except Exception as e:
        print("An exception occurred in test_Taggable_evaluate_tags")
        print(e)


# Generated at 2022-06-25 06:05:59.440830
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1_only_tags = ['tag0', 'tag1', 'tag2']
    taggable_1_skip_tags = ['tag3', 'tag4', 'tag5']
    taggable_1_all_vars = {}
    expected_value_1 = True
    actual_value_1 = taggable_1.evaluate_tags(taggable_1_only_tags, taggable_1_skip_tags, taggable_1_all_vars)

    assert expected_value_1 == actual_value_1

# Generated at 2022-06-25 06:06:03.538955
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    only_tags = 'all'
    skip_tags = 'never'
    all_vars = '{ "inventory_hostname" : "localhost" }'
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) is True

# Generated at 2022-06-25 06:06:06.998449
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(None, None, None) == True

# vim: set expandtab shiftwidth=4 tabstop=4 softtabstop=4

# Generated at 2022-06-25 06:06:18.483263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    tags1 = ['one']
    tags2 = ['two']
    only_tags1 = ['all']
    skip_tags1 = ['all']
    all_vars1 = {}

    taggable_1 = Taggable()
    taggable_1.tags = tags1
    assert taggable_1.evaluate_tags(only_tags1, skip_tags1, all_vars1) == True 

    taggable_2 = Taggable()
    taggable_2.tags = tags2
    assert taggable_2.evaluate_tags(only_tags1, skip_tags1, all_vars1) == True 

    taggable_3 = Taggable()
    taggable_3.tags = None

# Generated at 2022-06-25 06:06:26.892658
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    only_tags = ['t1']
    skip_tags = ['s1']
    all_vars = {}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = ['t1', 't2']
    skip_tags = ['s1', 's2']
    all_vars = {}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:06:37.425115
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['ping']
    only_tags = ['network']
    skip_tags = []
    all_vars = dict()
    assert not taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable_2 = Taggable()
    only_tags = []
    skip_tags = ['network']
    all_vars = dict()
    assert taggable_2.evaluate_tags(only_tags, skip_tags, all_vars)
    taggable_3 = Taggable()
    taggable_3.tags = ['network']
    only_tags = []
    skip_tags = []
    all_vars = dict()
    assert taggable_3.evaluate_tags

# Generated at 2022-06-25 06:06:45.074017
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    expected_value = False
    taggable = Taggable()
    taggable._tags = ['tagged']
    # Taggable.evaluate_tags(only_tags=['tagged', 'tagged2'], skip_tags=['tagged'], all_vars={})
    result = taggable.evaluate_tags(only_tags=['tagged', 'tagged2'], skip_tags=['tagged'], all_vars={})
    assert result == expected_value, "Actual value is %s" % result



# Generated at 2022-06-25 06:06:50.404303
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    # Test the case where a playbook is tagged only with 'init'
    ans = taggable._evaluate_tags(['init'], False, False)
    assert ans == True
    # Test the case where a playbook is tagged with both 'init' and 'runme'
    ans = taggable._evaluate_tags(['init', 'runme'], False, False)
    assert ans == True
    # Test the case where a playbook is tagged with both 'init' and 'runme'
    ans = taggable._evaluate_tags(['init', 'runme'], False, False)
    assert ans == True
    # Test the case where a playbook is tagged with 'init', 'runme' and 'always'

# Generated at 2022-06-25 06:07:09.407110
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._ds = {}
    taggable_0._ds= []
    taggable_0._ds= ['example_1']
    taggable_0._ds= ['example_2']
    taggable_0._ds= ['example_3']
    taggable_0._ds= None
    taggable_0._ds= iter([])
    taggable_0._ds= iter(['example_4'])
    taggable_0._ds= iter(['example_5'])
    taggable_0._ds= iter(['example_6'])

    only_tags_0 = set()
    only_tags_0.add('all')
    only_tags_0.add('tagged')

# Generated at 2022-06-25 06:07:14.211242
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    try:
        taggable_0.evaluate_tags(['tags'], ['tags'], ['tags'])
    except AttributeError:
        pass


# Generated at 2022-06-25 06:07:18.723468
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    ##############
    # test_case_0: only_tags = [], skip_tags = [], tags = []
    taggable_0 = Taggable()
    taggable_0.tags = []
    result = taggable_0.evaluate_tags([], [])
    assert result == True

    ##############
    # test_case_1: only_tags = ['test'], skip_tags = [], tags = ['test']
    taggable_1 = Taggable()
    taggable_1.tags = ['test']
    result = taggable_1.evaluate_tags(['test'], [])
    assert result == True

    ##############
    # test_case_2: only_tags = ['test'], skip_tags = [], tags = []
    taggable_2

# Generated at 2022-06-25 06:07:25.633139
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()


    # Test evaluate_tags when only_tags and skip_tags are none
    taggable.tags = ['a']
    result = taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    assert result == True
    
    
    # Test evaluate_tags when only_tags is one of the tags
    taggable.tags = ['a', 'b']
    result = taggable.evaluate_tags(only_tags=['a'], skip_tags=None, all_vars={})
    assert result == True


    # Test evaluate_tags when only_tags is not one of the tags
    taggable.tags = ['a', 'b']

# Generated at 2022-06-25 06:07:34.810373
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ["always"]
    evaluate_tags_1 = taggable_1.evaluate_tags(["all"],["never"],[])
    assert evaluate_tags_1 == True
    taggable_2 = Taggable()
    taggable_2.tags = ["tagged"]
    evaluate_tags_2 = taggable_2.evaluate_tags(["never"],["tagged"],[])
    assert evaluate_tags_2 == False
    taggable_3 = Taggable()
    taggable_3.tags = ["tagged"]
    evaluate_tags_3 = taggable_3.evaluate_tags(["tagged"],["never"],[])
    assert evaluate_tags_3 == True
    taggable_4 = Taggable()


# Generated at 2022-06-25 06:07:45.700062
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test: tags set to ['always']
    print('test 1')
    taggable_1 = Taggable()
    taggable_1.tags = ['always']
    tag_list = ['always']
    print(taggable_1.evaluate_tags(tag_list, [], {}))
    print(taggable_1.evaluate_tags(tag_list, None, {}))
    print(taggable_1.evaluate_tags(tag_list, tag_list, {}))

    # test: tags set to ['never']
    print('\ntest 2')
    taggable_2 = Taggable()
    taggable_2.tags = ['never']
    tag_list = ['never']
    print(taggable_2.evaluate_tags(tag_list, [], {}))

# Generated at 2022-06-25 06:07:50.374162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
        taggable_obj = Taggable()
        taggable_obj.tags=['tag1','tag2']
        taggable_obj.task = 'taggable_obj is a task'
        taggable_obj.evaluate_tags(['tag1','tag2'],['tag1'])
        try:
            print("No Exception")
        except:
            print("Exception")


# Generated at 2022-06-25 06:08:00.456968
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    tag = Taggable()
    tag.tags = ["tag1", "tag2", "tag3", "tag4"]

    only_tags = frozenset(["tag1", "tag2", "tag3", "tag4", "tag5", "tag6"])
    skip_tags = frozenset(["tag5", "tag6"])
    all_vars = dict(var1=1, var2="var2")

    result = tag.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(result == True)

    # Test exception
    #tag.tags = dict("a","b")
    #result = tag.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:08:07.787880
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['one', 'two']
    only_tags = set(['all', 'never', 'tagged'])
    skip_tags = set()
    all_vars = {}

    # Check for method evaluate_tags()
    print('Check for method evaluate_tags()')
    result0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    print(result0)
# =======================================================================


# Generated at 2022-06-25 06:08:11.303550
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = None
    assert taggable.evaluate_tags(['always'], None, None) == False
    assert taggable.evaluate_tags(['always'], ['always'], None) == False
    assert taggable.evaluate_tags(None, ['never'], None) == True
    assert taggable.evaluate_tags(['never'], None, None) == True
    assert taggable.evaluate_tags(None, ['always'], None) == False
    assert taggable.evaluate_tags(['tested'], ['not_tested'], None) == False
    assert taggable.evaluate_tags(['not_tested'], ['tested'], None) == False

# Generated at 2022-06-25 06:08:40.191159
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable._tags = ['tag']
    only_tags = ['tag']
    skip_tags = []
    all_vars = {}

    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    if result:
        print('PASS')
    else:
        print('FAIL')

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:46.720423
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    taggable_0 = Taggable()

    # Assert that evaluate_tags raises AnsibleError when it is called with a parameter that is not a string
    try:
        taggable_0.evaluate_tags(True, True, "all_vars")
    except Exception as e:
        import sys
        assert(isinstance(e, AnsibleError))
        assert(e.args[0] == "tags must be specified as a list")
        assert(isinstance(e.args[1], Task))
        return
    raise Exception("AnsibleError not raised")


# Generated at 2022-06-25 06:08:50.567696
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    all_vars = {}

    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result

# Generated at 2022-06-25 06:08:57.996262
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('\n\n###### unit tests for method evaluate_tags of class Taggable')

    # case representing skip all tasks
    taggable_0 = Taggable()
    taggable_0.tags = ['run_the_task']
    only_tags = []
    skip_tags = ['all']
    all_vars = {}
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    # case representing skip all tasks
    taggable_1 = Taggable()
    taggable_1.tags = []
    only_tags = []
    skip_tags = ['all']
    all_vars = {}
    taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)

    # case representing that the task will be run

# Generated at 2022-06-25 06:08:59.705482
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    assert(taggable_0.evaluate_tags(only_tags=["tag_string"], skip_tags=["tag_string"], all_vars=["tag_list"]) == True)

# Generated at 2022-06-25 06:09:09.432862
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 0:
    # Task with no tags and no options provided:
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    # Case 1:
    # Task with some tags and no options provided:
    taggable_1 = Taggable()
    taggable_1.tags = ['tag_A', 'tag_B']
    assert taggable_1.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    # Case 2:
    # Task with no tags and --only-tags option provided:
    taggable_2 = Taggable()

# Generated at 2022-06-25 06:09:18.154160
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()

    # Case 1
    only_tags = ['web']
    skip_tags = ['db']
    all_vars = {}
    taggable_1.tags = ['web']
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == True
    taggable_1.tags = []
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == True
    taggable_1.tags = ['web', 'db']
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == True
    taggable_1.tags = ['db']

# Generated at 2022-06-25 06:09:23.259335
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('Testing evaluate_tags of Taggable')
    taggable = Taggable()
    taggable.tags = ['rolling']
    all_vars = {'rolling':4, 'deploy':True}
    only_tags = ['rolling', 'deploy']
    print(taggable.evaluate_tags(only_tags, 'deploy', all_vars))
    return True

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:28.085545
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1._tags = ['taggable', 'test_case']
    assert taggable_1.evaluate_tags(['test_case'], [], {})
    assert not taggable_1.evaluate_tags(['test_case_false'], [], {})


# Generated at 2022-06-25 06:09:35.503594
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Tag is defined as an empty list
    taggable_1 = Taggable()
    tags_1     = []
    only_tags_1 = []
    skip_tags_1 = []
    all_vars_1 = {}
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1) is True

    # Tag is defined as a list
    taggable_2 = Taggable()
    tags_2     = ['database', 'postgresql']
    taggable_2.tags = tags_2
    only_tags_2  = ['database']
    skip_tags_2  = []
    all_vars_2 = {}

# Generated at 2022-06-25 06:10:30.271046
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags([], [], {})


# Generated at 2022-06-25 06:10:34.867965
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ["foo"]
    skip_tags_0 = ["foo"]
    all_vars_0 = dict()
    result = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result == False

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:10:38.970039
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    class in_all_vars:
        pass
    in_all_vars_0 = in_all_vars()
    in_only_tags = ['all']
    taggable_0.tags = ['all']
    assert taggable_0.evaluate_tags(in_only_tags, in_only_tags, in_all_vars_0)



# Generated at 2022-06-25 06:10:40.712734
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    result = taggable_1.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert result is True

# Generated at 2022-06-25 06:10:50.738407
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.module_utils.six import PY3

    # Create the object Taggable
    taggable_1 = Taggable()

    # Create a datastructure
    ds = dict(
        only_tags = ['pizza'],
        skip_tags = ['burritos'],
        all_vars = dict(),
    )

    # Set the datastructure
    taggable_1.only_tags = ds['only_tags']
    taggable_1.skip_tags = ds['skip_tags']

    taggable_1._tags = ['pizza', 'italian']
    flag = taggable_1.evaluate_tags(ds['only_tags'], ds['skip_tags'], ds['all_vars'])

# Generated at 2022-06-25 06:10:59.843223
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(set(), set(), {})
    assert taggable_0._load_tags(list(), [])
    assert taggable_0.evaluate_tags(set(["tagged"]), set(), {})
    assert taggable_0.evaluate_tags(set(["all"]), set(), {})
    assert taggable_0.evaluate_tags(set(["all", "tagged"]), set(), {})
    assert taggable_0.evaluate_tags(set(), set(["all"]), {})
    assert taggable_0.evaluate_tags(set(), set(["tagged"]), {})
    assert taggable_0.evaluate_tags(set(), set(["all", "tagged"]), {})
    assert tag

# Generated at 2022-06-25 06:11:05.825065
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
   taggable_0 = Taggable()
   taggable_0._loader = dict()
   taggable_0.tags = ['f']
   taggable_0._tags = ['n']
   only_tags = ['all']
   skip_tags = ['never', 'tagged']
   all_vars = dict()
   all_vars['ansible_check_mode'] = False
   result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
   assert result == True


# Generated at 2022-06-25 06:11:09.029654
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['rabbitmq']
    only_tags = ['rabbitmq']
    skip_tags = ['linux']
    all_vars = {'foo': 'bar'}
    if taggable_1.evaluate_tags(only_tags, skip_tags, all_vars):
        print("Tags check ok")
    else:
        print("Tags check failed")


test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:12.837734
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['a', 'b']
    only_tags = taggable.evaluate_tags(['a'], [], {})
    assert only_tags == True

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:22.849162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ["t1", "t2", "t3"]
    assert taggable.evaluate_tags(["t1"], None, None)
    assert taggable.evaluate_tags(["t1", "t2"], None, None)
    assert taggable.evaluate_tags(["t2", "t3"], None, None)
    assert taggable.evaluate_tags(["t1", "t2", "t3"], None, None)

    taggable.tags = None
    assert taggable.evaluate_tags([], None, None)
    assert taggable.evaluate_tags(None, None, None)

    taggable.tags = ["t3", "t2", "t1"]

# Generated at 2022-06-25 06:13:26.747096
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['Test', 'Evaluate', 'Tags']
    instance = Taggable()
    instance._tags = tags
    result = instance.evaluate_tags({}, {}, {})
    assert result == True
    

# Generated at 2022-06-25 06:13:33.832752
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case: test_case_0
    taggable_0 = Taggable()

    # Test case: test_case_1
    taggable_1 = Taggable()

    # Test case: test_case_2
    taggable_2 = Taggable()

    # Test case: test_case_3
    taggable_3 = Taggable()

    # Test case: test_case_4
    taggable_4 = Taggable()

    # Test case: test_case_5
    taggable_5 = Taggable()

    # Test case: test_case_6
    taggable_6 = Taggable()

    # Test case: test_case_7
    taggable_7 = Taggable()

    # Test case: test_case_8
    taggable

# Generated at 2022-06-25 06:13:41.994477
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    my_task = Taggable()
    my_task.tags = ['tag1', 'tag2', 'tag3', 'tag4']
    result = my_task.evaluate_tags(only_tags=['tag1', 'tag2', 'tag5'], skip_tags=[], all_vars={})
    assert result

    my_task.tags = ['tag1', 'always', 'tag3', 'tag4']
    result = my_task.evaluate_tags(only_tags=['tag1', 'tag2', 'tag5'], skip_tags=[], all_vars={})
    assert result

    my_task.tags = ['tag1', 'tag2', 'tag3', 'tag4']

# Generated at 2022-06-25 06:13:49.223754
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ["tag1"]
    assert taggable.evaluate_tags(["tag1"], [], {}), "evaluate_tags method of class Taggable failed"
    assert not taggable.evaluate_tags([], ["tag1"], {}), "evaluate_tags method of class Taggable failed"
    assert not taggable.evaluate_tags(["tag1","tag2"], [], {}), "evaluate_tags method of class Taggable failed"
    assert taggable.evaluate_tags([], ["tag1","tag2"], {}), "evaluate_tags method of class Taggable failed"
    assert taggable.evaluate_tags([], ["tag1","tag2","tag3"], {}), "evaluate_tags method of class Taggable failed"

# Generated at 2022-06-25 06:13:55.732757
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Task(Taggable):
        pass

    task = Task()
    task.tags = ['tag_0', 'tag_1']

    task.evaluate_tags(only_tags=['tag_0'], skip_tags=[], all_vars={})
    task.evaluate_tags(only_tags=[], skip_tags=['tag_0'], all_vars={})
    task.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    task.evaluate_tags(only_tags=['tag_0'], skip_tags=['tag_1'], all_vars={})


if __name__ == '__main__':

    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:14:01.105057
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['test_tag']
    result = taggable.evaluate_tags(['test_tag'], [], [])
    assert(result == True)
    result = taggable.evaluate_tags(['not_test_tag'], [], [])
    assert(result == False)
    result = taggable.evaluate_tags(['always'], [], [])
    assert(result == True)
    result = taggable.evaluate_tags([], [], [])
    assert(result == True)

# Generated at 2022-06-25 06:14:03.539837
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    retval = taggable_0.evaluate_tags(['foo', 'bar', 'baz'], ['frobnitz', 'qux'], all_vars={'magic': 'dance'})
    assert retval == False


# Generated at 2022-06-25 06:14:06.121628
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = dict()
    assert(taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True)

# Generated at 2022-06-25 06:14:11.547532
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 1: Tests when only_tags is empty.
    # Expected Result is True
    taggable_1 = Taggable()
    taggable_1.tags = ['all', 'test']
    if taggable_1.evaluate_tags([], ['skip_me'], {}) is False:
        return False

    # Case 2: Tests when skip_tags has 'all' as element
    # Expected Result is False
    taggable_2 = Taggable()
    taggable_2.tags = ['skip_me']
    if taggable_2.evaluate_tags([], ['all'], {}) is True:
        return False

    # Case 3: Tests when skip_tags is empty
    # Expected Result is True
    taggable_3 = Taggable()
    taggable_3.tags

# Generated at 2022-06-25 06:14:15.036387
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t_0 = Taggable()
    tags_0 = ['foo']
    only_tags_0 = ['bar']
    skip_tags_0 = ['baz']
    all_vars_0 = { 'bar': 'bar', 'baz': 'baz' }
    test_result = t_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert test_result == False
