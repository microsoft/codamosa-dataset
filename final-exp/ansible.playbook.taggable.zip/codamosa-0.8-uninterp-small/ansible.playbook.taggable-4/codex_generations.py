

# Generated at 2022-06-25 06:05:50.298924
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['a', 'b']
    assert taggable_1.evaluate_tags(['a'], [], {}) == True
    assert taggable_1.evaluate_tags(['c'], [], {}) == False
    assert taggable_1.evaluate_tags([], ['a'], {}) == False
    assert taggable_1.evaluate_tags([], ['c'], {}) == True
    assert taggable_1.evaluate_tags(['a', 'b'], [], {}) == True
    assert taggable_1.evaluate_tags(['a', 'c'], [], {}) == True
    assert taggable_1.evaluate_tags([], ['a', 'b'], {}) == False
    assert tagg

# Generated at 2022-06-25 06:05:59.441341
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Testing if method evaluate_tags of class Taggable returns correct value
    from ansible.module_utils._text import to_text
    taggable_0 = Taggable()
    taggable_0._tags = to_text('''[u'foo']''')
    taggable_1 = Taggable()
    taggable_1._tags = to_text('''[u'foo']''')
    taggable_2 = Taggable()
    taggable_2._tags = to_text('''[u'foo']''')
    taggable_3 = Taggable()
    taggable_3._tags = to_text('''[u'foo']''')
    taggable_4 = Taggable()

# Generated at 2022-06-25 06:06:04.226068
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    all_vars_0 = dict()
    only_tags_0 = {'all', 'never'}
    skip_tags_0 = set()
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result_0 == False


# Generated at 2022-06-25 06:06:12.224426
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['untagged']
    assert taggable_1.evaluate_tags(['all'], ['never'], dict()) == True
    assert taggable_1.evaluate_tags(['all'], ['untagged'], dict()) == True
    assert taggable_1.evaluate_tags(['all'], ['tagged'], dict()) == False
    assert taggable_1.evaluate_tags(['tagged'], ['never'], dict()) == False
    assert taggable_1.evaluate_tags(['tagged'], ['untagged'], dict()) == False
    taggable_1.tags = ['tag123', 'tag345']
    assert taggable_1.evaluate_tags(['tag123'], [], dict()) == True
   

# Generated at 2022-06-25 06:06:20.872084
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = set()
    skip_tags = set()
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = set()
    skip_tags = set()
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = set()
    skip_tags = set()
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    only_tags = set()
    skip_tags = set()
    all_vars = {}

# Generated at 2022-06-25 06:06:23.505308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True
#    taggable = Taggable()
#    assert taggable.evaluate_tags(only_tags, skip_tags) == expected


# Generated at 2022-06-25 06:06:29.472383
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 0: Test behavior when
    # only_tags and skip_tags both set to None
    taggable = Taggable()
    # Empty list of tags
    taggable._tags = []
    only_tags = None
    skip_tags = None
    all_vars = {}
    # assert(taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    # Case 1: Test behavior when
    # only_tags set to None and skip_tags set to []
    taggable = Taggable()
    # Empty list of tags
    taggable._tags = []
    only_tags = None
    skip_tags = []
    all_vars = {}
    # assert(taggable.evaluate_tags(only_tags, skip_tags, all_vars) ==

# Generated at 2022-06-25 06:06:35.603713
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ["tag1","tag2"]
    only_tags = ["tag1"]
    skip_tags = ["tag2"]
    all_vars = {}
    taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert taggable._tags == ["tag1","tag2"]
    

# Generated at 2022-06-25 06:06:43.754318
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    all_vars = dict()

    result = taggable.evaluate_tags(
        only_tags = [ 'test1' ],
        skip_tags = [ 'test2', 'test3' ],
        all_vars = all_vars
    )
    assert result == True

    result = taggable.evaluate_tags(
        only_tags = [ 'test1', 'test2' ],
        skip_tags = [ 'test2', 'test3' ],
        all_vars = all_vars
    )
    assert result == False

    result = taggable.evaluate_tags(
        only_tags = [ 'test2' ],
        skip_tags = [ 'test3' ],
        all_vars = all_vars
    )
    assert result == False

# Generated at 2022-06-25 06:06:49.914291
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Instanciation
    taggable_0 = Taggable()
    # Test with no tags
    only_tags_taggable_0 = None
    skip_tags_taggable_0 = None
    all_vars_taggable_0 = dict()
    assert taggable_0.evaluate_tags(only_tags_taggable_0, skip_tags_taggable_0, all_vars_taggable_0)
    # Test with 'always' tag
    taggable_0.tags = ['always']
    only_tags_taggable_0 = ['all']
    skip_tags_taggable_0 = None
    all_vars_taggable_0 = dict()

# Generated at 2022-06-25 06:07:07.546644
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    tags = set(['a', 'b'])
    always_tags = set(['always'])
    never_tags = set(['never'])
    combine_never_always_tags = set(['always', 'never'])
    combine_never_always_one_tags = set(['always', 'b'])
    combine_never_always_two_tags = set(['a', 'never'])
    all_tags = set(['always', 'never', 'a', 'b'])
    skip_tags = set()

    # only tags
    taggable = Taggable()
    taggable.tags = tags
    assert taggable.evaluate_tags(tags, skip_tags, {}) is True
    assert taggable.evaluate_tags(never_tags, skip_tags, {}) is False
    assert tagg

# Generated at 2022-06-25 06:07:13.920790
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['a']

    assert taggable.evaluate_tags(['a'], [], dict())
    assert taggable.evaluate_tags(['a', 'b'], [], dict())
    assert taggable.evaluate_tags(['all'], [], dict())
    assert taggable.evaluate_tags(['tagged'], [], dict())
    assert taggable.evaluate_tags(set(['tagged']), [], dict())

    assert not taggable.evaluate_tags(['b'], [], dict())
    assert not taggable.evaluate_tags(set(['a', 'b']), [], dict())
    assert taggable.evaluate_tags(set(['a', 'b']), [], dict())

    assert taggable.evaluate

# Generated at 2022-06-25 06:07:20.390978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    # Get the value returned by the function
    value = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    # Assert the value by using the expected value
    assert value == False


# Generated at 2022-06-25 06:07:22.089174
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    # This should be a list of one or more tags
    return_value = taggable.evaluate_tags()

# Generated at 2022-06-25 06:07:29.224858
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)

# vim: expandtab

# Generated at 2022-06-25 06:07:33.655793
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    string_0 = ')#JZB\'M'
    list_0 = [taggable_0]
    list_1 = [string_0]
    var_0 = taggable_0.evaluate_tags(list_1, list_0, list_0)
    assert var_0 == False


# Generated at 2022-06-25 06:07:40.179451
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    list = [taggable]
    int = 1588
    # No exception should be thrown for these inputs
    taggable.evaluate_tags(taggable, list, int)


if __name__ == "__main__":
    test_case_0()
    print("Success")

# Generated at 2022-06-25 06:07:42.046024
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    eval_0 = Taggable.evaluate_tags(Taggable(), list(), list(), dict())
    assert eval_0 == True

# Generated at 2022-06-25 06:07:44.145352
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Error thrown
    with pytest.raises(AnsibleError):
        taggable_0._load_tags()

# Generated at 2022-06-25 06:07:47.470205
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._loader = None
    # Run test and get result
    result = taggable_0.evaluate_tags(None, None, None)
    # Check type of result is boolean
    assert(isinstance(result, bool))


# Generated at 2022-06-25 06:08:04.056858
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)


# Generated at 2022-06-25 06:08:08.176684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    int_0 = 620
    assert taggable_0.evaluate_tags(list_0, list_0, int_0) is True


# Generated at 2022-06-25 06:08:12.511272
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    taggable_2 = Taggable()
    str_0 = taggable_2.evaluate_tags(taggable_0, list_0, int_0)


# Generated at 2022-06-25 06:08:17.035867
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
    assert var_0 == False

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:08:21.035711
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # TODO: improve test, mock all needed objects by replacing them with mocks
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)

# Generated at 2022-06-25 06:08:26.519074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    assert(taggable_1.evaluate_tags(taggable_0, list_0, int_0) == True)
    taggable_2 = Taggable()
    assert(taggable_2.evaluate_tags(taggable_0, list_0, int_0) == True)
    taggable_3 = Taggable()
    assert(taggable_3.evaluate_tags(taggable_0, list_0, int_0) == True)


# Generated at 2022-06-25 06:08:31.033173
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = ["untagged", "untagged", "untagged", "untagged", "untagged"]
    int_0 = 4874
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
    assert var_0


# Generated at 2022-06-25 06:08:32.252138
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 06:08:37.071355
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    int_0 = 5
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
    assert var_0 == True

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:43.145872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)

if __name__ == "__main__":
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:12.165995
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    var_0 = Taggable()
    var_1 = Taggable()
    var_2 = ['hello world']
    var_3 = var_0.evaluate_tags(var_1, var_2, 1)
    assert var_3 == True

# Generated at 2022-06-25 06:09:19.457555
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable0 = Taggable()
    list0 = list()
    int0 = 1588
    all_vars = dict()
    taggable0.evaluate_tags(list0, list0, all_vars)
    taggable1 = Taggable()
    int1 = 1587
    str0 = str()
    all_vars[str0] = int1
    str1 = str()
    taggable1.evaluate_tags(list0, list0, all_vars)
    taggable2 = Taggable()
    list1 = [int0]
    dict0 = dict()
    str2 = str()
    dict0[str2] = int1
    all_vars[str0] = dict0
    list2 = [str0]
    taggable2.evaluate_tags

# Generated at 2022-06-25 06:09:23.842863
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = Taggable()
    list_0 = []
    list_1 = []
    int_0 = 1588
    int_1 = 0
    str_0 = obj.evaluate_tags(list_0, list_0, int_0)
    str_1 = obj.evaluate_tags(list_0, list_1, int_1)
    assert str_0 == str_1, 'Values do not match'


# Generated at 2022-06-25 06:09:28.795052
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        Taggable()._load_tags(None, None)
    except (TypeError, AttributeError) as e:
        print('FAILURE: test_Taggable_evaluate_tags()')
        print(str(e))
        return
    else:
        print('SUCCESS: test_Taggable_evaluate_tags()')


# Generated at 2022-06-25 06:09:30.368499
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()
    print("Test for evaluate_tags passed")



# Generated at 2022-06-25 06:09:38.508166
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
    assert True == var_0
    taggable_2 = Taggable()
    str_0 = "tagged"
    str_1 = "all"
    str_2 = "never"
    set_0 = set([str_2])
    str_3 = "always"
    list_1 = [str_3]
    taggable_3 = Taggable()
    var_1 = taggable_3.evaluate_tags(set_0, list_1, taggable_2)

# Generated at 2022-06-25 06:09:39.444394
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        assert True
    except AssertionError:
        return False

    return True


# Generated at 2022-06-25 06:09:43.326602
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    skip_tags = [1, 2, 3]
    only_tags = [4, 5, 6]
    all_vars = "test"
    var = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    return var


# Generated at 2022-06-25 06:09:52.419244
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tag_0', 'tag_1']
    taggable_1 = Taggable()
    taggable_1.tags = ['tag_2', 'tag_3']
    taggable_2 = Taggable()
    taggable_2.tags = []
    taggable_3 = Taggable()
    taggable_3.tags = ['tag_2', 'tag_3']
    list_0 = ['tag_1', 'tag_2']
    int_0 = 1588
    assert(taggable_0.evaluate_tags(list_0, int_0) == True)
    list_0 = ['tag_2', 'tag_1']
    int_0 = 1588

# Generated at 2022-06-25 06:09:58.182397
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._loader = None
    only_tags = 'oops'
    skip_tags = ['foo', 'bar', 'tagged', 'all', 'always']
    all_vars = {}
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True


# Generated at 2022-06-25 06:11:03.310155
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)


if __name__ == "__main__":
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:12.825293
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._loader = 'loader'
    taggable_0.tags = 'tags'
    list_0 = ['list']
    int_0 = 2117
    var_0 = taggable_0.evaluate_tags(list_0, int_0, 'all_vars')
    assert var_0 == True
    taggable_0 = Taggable()
    taggable_0._loader = 'loader'
    list_0 = ['list']
    int_0 = -5065
    var_0 = taggable_0.evaluate_tags(list_0, int_0, 'all_vars')
    assert var_0 == True


# Generated at 2022-06-25 06:11:16.496986
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Input
    taggable = Taggable()
    only_tags = []
    skip_tags = []
    all_vars = {
        'hostvars': {
            'hostname': {
                'ansible_host': '127.0.0.1',
                'ansible_port': 514
            },
        }
    }

    # Output
    expected = True

    # Result
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # Assert
    assert expected == result


test_case_0()

# Generated at 2022-06-25 06:11:25.706699
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_1 = Taggable()
    taggable_1._loader = None
    taggable_1._variable_manager = None
    taggable_1._parent = None
    taggable_1._dep_chain = None
    list_0 = ['foo', 'bar']
    taggable_1._load_tags('_tags', list_0)
    taggable_1._ds = None
    list_1 = ['never', 'never']
    taggable_1.tags = list_1
    str_0 = 'foo'
    list_2 = [str_0]
    taggable_1._tags = list_2
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-25 06:11:29.122629
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)


test_case_0()

# Generated at 2022-06-25 06:11:35.698086
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    taggable_2 = Taggable()
    taggable_3 = Taggable()
    taggable_4 = Taggable()
    taggable_5 = Taggable()
    taggable_6 = Taggable()
    taggable_7 = Taggable()
    taggable_8 = Taggable()
    taggable_9 = Taggable()
    taggable_10 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)

# Generated at 2022-06-25 06:11:39.280460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
    assert var_0 == True

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:43.999049
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)


# Generated at 2022-06-25 06:11:50.687551
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()

    assert taggable.evaluate_tags(taggable, [taggable], int) == bool
    assert taggable.evaluate_tags(taggable, [taggable], int) == bool
    assert taggable.evaluate_tags(taggable, [taggable], int) == bool
    assert taggable.evaluate_tags(taggable, [taggable], int) == bool
    assert taggable.evaluate_tags(taggable, [taggable], int) == bool


# Generated at 2022-06-25 06:11:53.905628
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_1 = Taggable()
    list_0 = [taggable_1]
    int_0 = 1578
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, int_0)

# Generated at 2022-06-25 06:14:34.431993
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = [1000]
    taggable_0 = Taggable()
    list_1 = taggable_0.evaluate_tags(list_0)


# Generated at 2022-06-25 06:14:38.061690
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:14:41.783948
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)

# Generated at 2022-06-25 06:14:47.097575
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    list_0 = ['a', 'b', 'c']
    int_0 = 20
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(taggable, list_0, int_0)
    assert var_0 == False



# Generated at 2022-06-25 06:14:52.065332
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    int_0 = 19
    var_0 = taggable_0.evaluate_tags(list_0, list_0, int_0)
    assert var_0 == True


# Generated at 2022-06-25 06:14:56.678597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
    assert var_0 == True

# Generated at 2022-06-25 06:15:02.695697
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)


# Generated at 2022-06-25 06:15:05.305872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:15:09.385460
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        Taggable.evaluate_tags
    except:
        assert False, "evaluate_tags is not defined"
    try:
        test_case_0()
        assert True
    except:
        assert False, "unexpected error"
# Boilerplate syntax for calling the main() function to begin
# the program.
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 06:15:12.152551
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0]
    int_0 = 1588
    taggable_1 = Taggable()
    var_0 = taggable_1.evaluate_tags(taggable_0, list_0, int_0)
