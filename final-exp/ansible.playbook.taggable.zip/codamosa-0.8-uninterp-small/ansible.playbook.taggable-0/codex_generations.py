

# Generated at 2022-06-25 06:05:51.205534
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['all', 'never', 'never', 'never']
    assert taggable_1.evaluate_tags(['all', 'never'], ['never', 'all'], {}) == False
    assert taggable_1.evaluate_tags(['never', 'always'], ['always'], {}) == False
    assert taggable_1.evaluate_tags(['always'], ['all'], {}) == True


# Generated at 2022-06-25 06:06:00.655441
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 0: Test call to evaluate_tags with simple set of input arguments
    taggable_1 = Taggable()
    taggable_1.name = 'taggable_1'
    taggable_1.tags = ["foo", "bar", "baz"]

    all_vars = {"foo": "bar"}

    only_tags = ["foo","baz"]
    skip_tags = ["bar"]
    result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    # Case 1: Test call to evaluate_tags with more complex data structure
    taggable_2 = Taggable()
    taggable_2.name = 'taggable_2'
    taggable_2.tags = {"foo": [1,2,3]}

# Generated at 2022-06-25 06:06:09.968043
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    ret_1 = taggable_1.evaluate_tags(['a'], None, None)
    print(ret_1)
    taggable_2 = Taggable()
    taggable_2._tags = ['tag_in_tags']
    ret_2 = taggable_2.evaluate_tags(['a'], None, None)
    print(ret_2)
    taggable_3 = Taggable()
    taggable_3._tags = ['tag_in_tags']
    ret_3 = taggable_3.evaluate_tags(['tag_in_tags'], None, None)
    print(ret_3)
    taggable_4 = Taggable()
    taggable_4._tags = ['b']
    ret_4

# Generated at 2022-06-25 06:06:18.706359
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("\n############################################################################")
    print("## Testing evaluate_tags (Class Taggable)")

    ########### CASE 0:
    print("\n### CASE 0:")
    taggable_0 = Taggable()

    taggable_0.tags = ['all', 'never']
    print("\tTags: all,never")
    only_tags = ['all']
    skip_tags = ['never']
    print("\tshould run: No")
    assert taggable_0.evaluate_tags(only_tags, skip_tags, {}) == False

    print("\tTags: all,never")
    only_tags = ['all']
    skip_tags = []
    print("\tshould run: Yes")

# Generated at 2022-06-25 06:06:27.478818
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    #test_case_0
    taggable_0 = Taggable()
    only_tags_0 = ['all']
    skip_tags_0 = ['all']
    all_vars_0 = {u'myvar': u'Hello world!'}
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result_0 == False

    # test_case_1
    taggable_0 = Task()
    taggable_0._loader = 'loader_0'
    taggable_0.tags = ['task_0']
    only_tags_0 = ['task_0']
    skip_tags_0 = ['all']

# Generated at 2022-06-25 06:06:33.860356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Fixture ansible.playbook.become.Become
    become = Become()

    # Fixture ansible.playbook.conditional.Conditional
    conditional = Conditional()

    # Fixture ansible.playbook.task.Task
    task = Task()

    # Fixture ansible.playbook.block.Block
    block = Block()

    # Fixture ansible.playbook.handler.Handler
    handler = Handler()

# Generated at 2022-06-25 06:06:36.883664
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    print(taggable_0.evaluate_tags(None, None, None))
    assert taggable_0.evaluate_tags(None, None, None) == True


# Generated at 2022-06-25 06:06:46.483308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['tagged']
    only_tags_1 = ['all', 'tagged']
    skip_tags_1 = []
    all_vars_1 = {}
    expected_1 = True
    observed_1 = taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    if expected_1 != observed_1:
        raise AssertionError('expected %s but got %s for taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)' % (expected_1, observed_1))

# this runs the unit tests above

# Generated at 2022-06-25 06:06:50.290643
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = [u'all']
    skip_tags = [u'playbook_0', u'playbook_1']
    all_vars = {u'localhost': {u'module_setup': True}}
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result_0 == True

# Generated at 2022-06-25 06:06:56.299548
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # Instantiation file: ansible-playbook/playbook/attribute.py should be used as the first
    # parameter of the constructor.
    # Constructor instantiation file: ansible-playbook/playbook/task.py
    # Instantiation line: 144
    # Constructor instantiation line: 104
    ansible_loader = None
    taggable_1 = Taggable(loader=ansible_loader)

    # Instantiation file: ansible-playbook/playbook/attribute.py should be used as the first
    # parameter of the constructor.
    # Constructor instantiation file: ansible-playbook/playbook/block.py
    # Instantiation line: 47
    # Constructor instantiation line: 210
    ansible_loader = None
    taggable_2 = T

# Generated at 2022-06-25 06:07:19.158074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # call test_case_0()
    test_case_0()

    # Create a new object from class Taggable
    taggable = Taggable()

    current_tags = ['junit', 'ansible', 'python']

    # Set current_tags for ansible
    taggable.tags = current_tags

    # Create a temporary list of tags
    temporary_tags = ['ansible', 'python', 'yum', 'tomcat']

    # create a new list of tags that needs to be skipped
    skip_tags = ['python', 'yum', 'tomcat']

    # Call class method evaluate_tags with arguments only_tags and skip_tags
    if taggable.evaluate_tags(temporary_tags, skip_tags, {}):
        print("No skip tags found in the current tags")

# Generated at 2022-06-25 06:07:25.932701
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Assert positive test conditions
    assert taggable_0.evaluate_tags(['always', 'tagged'], ['never'], {}) == True
    assert taggable_0.evaluate_tags(['always'], ['never', 'all'], {}) == True
    assert taggable_0.evaluate_tags(['tagged'], ['all'], {}) == True
    assert taggable_0.evaluate_tags(['all'], ['never'], {}) == True
    assert taggable_0.evaluate_tags([], ['all'], {}) == True
    assert taggable_0.evaluate_tags([], ['always'], {}) == True
    assert taggable_0.evaluate_tags([], ['never'], {}) == False
    assert taggable

# Generated at 2022-06-25 06:07:28.038011
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['tags'], ['tags'], {}) == True

# Generated at 2022-06-25 06:07:36.884724
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tag_0']
    only_tags = ['tag_0']
    skip_tags = []
    all_vars = {}

    try:
        ret = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    except AnsibleError as e:
        print('{0}: {1}'.format(type(e), e))
    else:
        print('{0}: {1}'.format(type(ret), ret))

    try:
        ret = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    except AnsibleError as e:
        print('{0}: {1}'.format(type(e), e))

# Generated at 2022-06-25 06:07:40.939824
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a Taggable object with empty tags
    taggable_0 = Taggable()

    # Create a set to be used as only_tags and one to be used as skip_tags
    only_tags_0 = set(['all'])
    skip_tags_0 = set(['all'])

    # Evaluate tags of the Taggable object with all_vars=None
    should_run = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, None)

    # This should return False since both sets contain all
    assert should_run == True

    # Create another Taggable object with tags=['test']

    taggable_1 = Taggable()
    taggable_1.tags = ['test']

    # Create a set to be used as only_tags and one to be

# Generated at 2022-06-25 06:07:50.103560
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = [ "all", "test1", "test2" ]
    only_tags = [ "test1", "test2" ]
    skip_tags = [ "test4", "test5" ]
    all_vars = {}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == True

    taggable_2 = Taggable()
    taggable_2.tags = [ "test1", "test2" ]
    only_tags = [ "test1", "test2" ]
    skip_tags = [ "test3", "test4" ]
    all_vars = {}

# Generated at 2022-06-25 06:07:59.145859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['database', 'node1', 'node2']
    only_tags = ['node2', 'database']
    skip_tags = []
    all_vars = {}
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True, "Test failed: evaluate_tags(only_tags, skip_tags, all_vars)"

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:03.212999
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = list()
    skip_tags_0 = list()
    all_vars_0 = dict()
    ret_1 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert (ret_1 == True)

# Generated at 2022-06-25 06:08:12.636951
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ["always"]
    skip_tags_0 = ["tagged"]
    all_vars_0 = {}
    taggable_0._tags = "always"
    return_value = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert return_value == True
    only_tags_1 = ["tagged"]
    skip_tags_1 = ["all"]
    all_vars_1 = {}
    taggable_0._tags = "always"
    return_value = taggable_0.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert return_value == False

# Generated at 2022-06-25 06:08:16.571533
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()  # instantiate a class Taggable
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[])    # test the work of method evaluate_tags of class Taggable
 
# Run test methods
test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:51.550149
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test with no tags and no options
    taggable_0 = Taggable()
    only_tags = None
    skip_tags = None
    all_vars = None
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with no tags and only_tags = "something"
    taggable_1 = Taggable()
    only_tags = set(["something"])
    skip_tags = None
    all_vars = None
    assert not taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test with no tags and skip_tags = "something"
    taggable_2 = Taggable()
    only_tags = None
    skip_tags = set(["something"])
    all

# Generated at 2022-06-25 06:09:02.162076
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Testing evaluate_tags()")
    #Success case
    taggable = Taggable()
    taggable._tags = ['test_tag']
    result = taggable.evaluate_tags(['test_tag'], [], dict())
    assert result == True
    result = taggable.evaluate_tags(list(), ['test_tag'], dict())
    assert result == False
    #Failure case
    taggable = Taggable()
    taggable._tags = ['test_tag']
    result = taggable.evaluate_tags(list(), [], dict())
    assert result == True
    result = taggable.evaluate_tags(['test_tag'], ['test_tag'], dict())
    assert result == False

if __name__ == "__main__":
    test_case_0()
   

# Generated at 2022-06-25 06:09:03.782794
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['foo', 'bar', 'baz'], ['car', 'far'], None) is True

# Generated at 2022-06-25 06:09:14.249178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # The following tests should be successful

    # Case 1:
    # The only_tag is a list of strings
    taggable = Taggable()
    taggable.tags = ['tag_1', 'tag_2']
    only_tags = ['tag_1']
    assert taggable.evaluate_tags(only_tags, None, None) == True

    # Case 2:
    # The only_tag is a list of string(s) and one of them is 'all'
    # then all tags are True
    taggable = Taggable()
    taggable.tags = ['tag_1', 'tag_2']
    only_tags = ['tag_3', 'all']
    assert taggable.evaluate_tags(only_tags, None, None) == True

    # Case 3:
    # The only_tag

# Generated at 2022-06-25 06:09:23.966868
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_tag_0 = Taggable()
    test_tag_1 = Taggable()
    test_tag_2 = Taggable()
    test_tag_3 = Taggable()
    test_tag_4 = Taggable()
    test_tag_5 = Taggable()
    test_tag_6 = Taggable()
    test_tag_7 = Taggable()
    test_tag_8 = Taggable()
    test_tag_9 = Taggable()
    test_tag_10 = Taggable()
    test_tag_11 = Taggable()
    test_tag_12 = Taggable()
    test_tag_13 = Taggable()
    test_tag_14 = Taggable()
    test_tag_15 = Taggable()

# Generated at 2022-06-25 06:09:34.283831
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Assert if true is returned when a tag is present in the task
    assert taggable_0.evaluate_tags(['all'], [], {}) is True
    # Assert if false is returned when a tag is not present in the task
    assert taggable_0.evaluate_tags(['bogus'], [], {}) is False
    # Assert if true is returned when a tag is present in the task
    assert taggable_0.evaluate_tags(['tagged'], [], {}) is True
    # Assert if false is returned when a tag is not present in the task
    assert taggable_0.evaluate_tags(['untagged'], [], {}) is False
    # Assert if true is returned when a tag is present in the task
    assert tagg

# Generated at 2022-06-25 06:09:43.400901
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    #test case 0
    # Taggable_0._load_tags(attr,ds)
    # return []
    # Taggable_0.tags = []
    # Taggable_0.tags = Taggable_0._load_tags(attr,ds)
    taggable_0 = Taggable()
    taggable_0._load_tags(attr=None,ds=None)
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = {}
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True
    assert taggable_0.tags == []

    #test case 1
    # Taggable_1._load_tags(attr,ds)
    # return []


# Generated at 2022-06-25 06:09:47.419775
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['always']
    assert taggable.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True



# Generated at 2022-06-25 06:09:54.592628
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['tag1','tag2','tag3']
    assert taggable.evaluate_tags({'tag1'}, [], {})
    assert not taggable.evaluate_tags({'tag4'}, [], {})
    assert taggable.evaluate_tags(set(), {'tag2'}, {})
    assert taggable.evaluate_tags({'tag2'}, {'tag2'}, {})
    assert taggable.evaluate_tags({'tag1', 'tag3'}, {'tag2'}, {})
    assert taggable.evaluate_tags({'tag1', 'tag3'}, {'tag2'}, {})
    assert not taggable.evaluate_tags({'tag1'}, {'tag2', 'tag3'}, {})


# Generated at 2022-06-25 06:10:02.830377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    taggable_0 = Taggable()
    only_tags_arg_0 = frozenset(['all'])
    skip_tags_arg_0 = frozenset(['never'])
    all_vars_arg_0 = dict()
    taggable_0.tags = list()
    excepted_0 = True

    # Execution
    result_0 = taggable_0.evaluate_tags(only_tags_arg_0, skip_tags_arg_0, all_vars_arg_0)
    # Verification
    assert result_0 == excepted_0

# Generated at 2022-06-25 06:11:09.174785
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    with pytest.raises(Exception):
        taggable_0.evaluate_tags()

# Generated at 2022-06-25 06:11:15.207328
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = set(['foo'])
    skip_tags = set([])
    all_vars = dict()
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    taggable_0 = Taggable()
    only_tags = set(['foo'])
    skip_tags = set([])
    all_vars = dict()
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

test_case_0()

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:23.431115
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:11:26.205878
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:11:29.624350
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    _taggable_0 = Taggable()
    only_tags = ['all']
    skip_tags = ['foo', 'bar']
    result = _taggable_0.evaluate_tags(only_tags, skip_tags, )
    #
    # evaluate_tags should be true when a task should be executed
    #



# Generated at 2022-06-25 06:11:38.830536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Testing evaluate_tags() method:\n")
    
    taggable_0 = Taggable()
    taggable_0.tags = ['a','b','c']
    # Test case 0
    print("Check if taggable_0.tags is a list")
    assert(type(taggable_0.tags) is list), "taggable_0.tags is not a list"
    
    # Test case 1
    print("Only_tags = ['a']")
    only_tags_0 = ['a']
    assert(taggable_0.evaluate_tags(only_tags_0, None, None) is True)

    # Test case 2
    print("Only_tags = ['all']")
    only_tags_0 = ['all']

# Generated at 2022-06-25 06:11:45.111466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ["tag1"]
    only_tags_0 = ["tag1"]
    skip_tags_0 = []
    all_vars_0 = None

    taggable_1 = Taggable()
    taggable_1.tags = ["tag2"]
    only_tags_1 = ["tag1"]
    skip_tags_1 = []
    all_vars_1 = { "tag2": "tag3" }

    taggable_2 = Taggable()
    taggable_2.tags = ["tag4"]
    only_tags_2 = ["tag1"]
    skip_tags_2 = ["tag4"]
    all_vars_2 = None

    taggable_3 = Taggable()
    taggable

# Generated at 2022-06-25 06:11:50.639797
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    tag_options = [None]
    only_tags = tag_options[0]
    skip_tags = tag_options[0]
    all_vars = [None]
    result = taggable_0.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    assert result == True
test_Taggable_evaluate_tags()


# Generated at 2022-06-25 06:11:59.245793
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_0 = Taggable()
    test_0.tags = ['always']
    only_tags_0 = ['always']
    all_vars_0 = {}
    skip_tags_0 = []
    result_0 = test_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result_0 == True

    test_1 = Taggable()
    test_1.tags = ['not_always']
    only_tags_1 = []
    all_vars_1 = {}
    skip_tags_1 = ['always']
    result_1 = test_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert result_1 == True

    test_2 = Taggable()
    test_

# Generated at 2022-06-25 06:12:10.950157
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable.tags = ['bar']

    # Check if a playbook should run.
    only_tags=['all']
    skip_tags=[]
    should_run=taggable.evaluate_tags(only_tags, skip_tags, {})
    assert should_run == True

    # Test evaluate_tags with only_tags, skip_tags
    only_tags=['bar']
    skip_tags=['foo']
    should_run=taggable.evaluate_tags(only_tags, skip_tags, {})
    assert should_run == True

    # Test evaluate_tags with only_tags
    only_tags=['bar']
    skip_tags=[]
    should_run=taggable.evaluate_tags(only_tags, skip_tags, {})
    assert should_

# Generated at 2022-06-25 06:14:53.390197
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Case 0: no skip_tags or only_tags and no tags for this task
    taggable_0 = Taggable()
    should_run = taggable_0.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert should_run
    assert taggable_0.tags == []

    # Case 1: skip_tags but no tags for this task
    taggable_1 = Taggable()
    should_run = taggable_1.evaluate_tags(only_tags=[], skip_tags=['test_skip'], all_vars={})
    assert not should_run
    assert taggable_1.tags == []

    # Case 2: only_tags but no tags for this task
    taggable_2 = Taggable()
    should_run = tagg

# Generated at 2022-06-25 06:14:59.622572
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ["apples", "oranges"]
    only_tags = ["apples", "oranges", "bananas"]
    skip_tags = ["bananas", "grapes", "mangoes", "pears"]
    all_vars = {"x": "5", "y": "6"}
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result

test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:07.260594
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case 0
    taggable_0 = Taggable()

    # Test case 1
    taggable_1 = Taggable()
    only_tags_1 = ['all']
    skip_tags_1 = ['always']
    all_vars_1 = {'test_var': 'test_value'}
    expected_1 = True

    result_1 = taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert result_1 == expected_1

    # Test case 2
    taggable_2 = Taggable()
    only_tags_2 = ['all']
    skip_tags_2 = ['never']
    all_vars_2 = {'test_var': 'test_value'}
    expected_2 = True



# Generated at 2022-06-25 06:15:15.482250
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = ['a', 'b', 'c']
    skip_tags = ['d', 'e', 'f']
    only_tags = ['a', 'b', 'c']
    all_vars = {}
    taggable = Taggable()
    taggable.tags = tags
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:19.290288
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test methods in class Taggable
    taggable_0 = Taggable()

    assert hasattr(taggable_0, '_tags') == True

    assert taggable_0.untagged == frozenset(['untagged'])

    assert taggable_0.tags == []

# Generated at 2022-06-25 06:15:24.250705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['test_tags']
    only_tags = ['test_tags']
    skip_tags = []
    all_vars = []
    result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True


# Generated at 2022-06-25 06:15:30.755498
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Arrange
    only_tags = set()
    skip_tags = set()
    all_vars = {}
    taggable = Taggable()
    taggable.tags = ['tag1']
    expected = True

    # Act
    actual = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    # Assert
    assert actual == expected


# Generated at 2022-06-25 06:15:38.948958
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tag_1', 'tag_2', 'tag_3', 'tag_4']
    only_tags = ['tag_1', 'tag_2']
    skip_tags = ['tag_3', 'tag_4']
    all_vars = {}
    actual_result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    expected_result = True
    print("Actual: " + str(actual_result))
    print("Expected: " + str(expected_result))
    assert actual_result == expected_result
