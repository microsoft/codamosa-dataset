

# Generated at 2022-06-25 06:05:54.207837
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test Taggable class name
    assert (Taggable.__name__ == 'Taggable')

    # Test Taggable class parent
    assert (Taggable.__bases__[0].__name__ == 'object')

    # Test Taggable class members
    assert (set(Taggable.__dict__) == set({'__module__', '__dict__', '__init__', '__weakref__', '__doc__', '__init_subclass__', '__str__', 'untagged', '_tags', '_load_tags', 'evaluate_tags'}))

    # Other tests
    dict0 = {'tags':['tag1', 'tag2', 'tag3']}
    taggable0 = Taggable(**dict0)

# Generated at 2022-06-25 06:05:59.568722
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    only_tags_0 = None
    skip_tags_0 = None
    all_vars_0 = None
    result = taggable_0.evaluate_tags(only_tags=only_tags_0, skip_tags=skip_tags_0, all_vars=all_vars_0)
    assert result


# Generated at 2022-06-25 06:06:09.397438
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    dict_1 = {'tags': ['untagged'], '_variable_manager': None, '_loader': None}

    only_tags = 'all'  # Value assigned to argument only_tags of Taggable.evaluate_tags

    try:
        assert taggable_0.evaluate_tags(only_tags)
    except Exception as e:
        print(e)
        assert isinstance(e, AssertionError)

    try:
        assert taggable_0.evaluate_tags(only_tags, **dict_1)
    except Exception as e:
        print(e)
        assert isinstance(e, AssertionError)


# Generated at 2022-06-25 06:06:18.679177
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    only_tags_0 = set()
    skip_tags_0 = set()
    all_vars_0 = {}
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert taggable_0.tags == []
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    only_tags_0 = set()
    skip_tags_0 = set()
    all_vars_0 = {}
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert taggable_0.tags == []
    dict_

# Generated at 2022-06-25 06:06:27.585023
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags_0 = Taggable
    taggable_0 = Taggable()
    all_vars_0 = Taggable
    skip_tags_0 = Taggable
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True

    dict_0 = {}
    only_tags_1 = dict_0
    skip_tags_1 = dict_0
    all_vars_1 = dict_0
    taggable_1 = Taggable(**dict_0)
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1) == True

    dict_0 = {}
    only_tags_3 = dict_0
    skip_tags_3 = dict_

# Generated at 2022-06-25 06:06:37.836685
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = frozenset([])
    skip_tags = frozenset([])
    all_vars = {}
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    assert (taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    only_tags = frozenset(['all'])
    skip_tags = frozenset([])
    all_vars = {}
    dict_1 = {}
    taggable_1 = Taggable(**dict_1)
    assert (taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) == True)

    only_tags = frozenset(['all'])
    skip_tags = frozenset(['never'])


# Generated at 2022-06-25 06:06:47.034670
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # test_case_0
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    only_tags_0 = 'always'
    skip_tags_0 = 'never'
    all_vars_0 = {}
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result_0 == True

    # test_case_1
    dict_1 = {}
    taggable_1 = Taggable(**dict_1)
    only_tags_1 = 'never'
    skip_tags_1 = 'never'
    all_vars_1 = {}

# Generated at 2022-06-25 06:06:51.945747
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Evaluate the test case
    try:
        test_case_0()
    except Exception as e:
        # For debugging purposes
        print(e)
        assert False


# Generated at 2022-06-25 06:07:03.007534
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {
        'tags': [
            'foo',
            'bar'
        ]
    }
    taggable_0 = Taggable(**dict_0)
    taggable_0.evaluate_tags(only_tags=[
        'foo'
    ], skip_tags=[
        'bar'
    ], all_vars={})
    dict_1 = {
        'tags': [
            'tagged'
        ]
    }
    taggable_1 = Taggable(**dict_1)
    taggable_1.evaluate_tags(only_tags=[
        'tagged'
    ], skip_tags=[
        'foo'
    ], all_vars={})
    dict_2 = {
        'tags': []
    }
    taggable_2 = Taggable

# Generated at 2022-06-25 06:07:08.973945
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    test_value = []
    result = taggable_0.evaluate_tags(test_value,test_value,test_value)
    assert result == None

# Generated at 2022-06-25 06:07:34.105305
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # we are testing the method "evaluate_tags" of the class Taggable
    taggable_0 = Taggable()  # TODO: create a Taggable object
    # we are testing the following parameters:
    #   only_tags: ['all', 'never']
    #   skip_tags: ['never', 'always']
    taggable_0.tags = ['never']
    all_vars = dict()
    only_tags = ['all', 'never']
    skip_tags = ['never', 'always']
    # we expect this value: 
    expected_value = False
    # we obtain the value of interest by running the code of interest
    value_of_interest = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    # we check that the value of interest is equal

# Generated at 2022-06-25 06:07:41.227557
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['test']
    assert taggable.evaluate_tags(['test'], [], {}, ), \
        'Evaluated False when it should have been True'
    assert not taggable.evaluate_tags(['test2'], [], {}, ), \
        'Evaluated True when it should have been False'


# Generated at 2022-06-25 06:07:49.477716
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    # Test : with only_tags = None and skip_tags = None and all_vars = None
    assert taggable_1.evaluate_tags(None, None, None) == True
    # Test : with only_tags = [] and skip_tags = [] and all_vars = None
    assert taggable_1.evaluate_tags([], [], None) == True
    # Test : with only_tags = ['all', 'always'] and skip_tags = ['always'] and all_vars = None
    assert taggable_1.evaluate_tags(['all', 'always'], ['always'], None) == False
    # Test : with only_tags = ['all'] and skip_tags = ['untagged'] and all_vars = None
    assert taggable_1.evaluate_

# Generated at 2022-06-25 06:08:00.463443
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Testing for untagged
    taggable_0 = Taggable()
    result_0 = taggable_0.evaluate_tags(['tagged'], [], {})
    assert result_0 == False

    # Testing for tagged
    taggable_1 = Taggable()
    taggable_1.tags = ['tag1', 'tag2', 'tag3']
    result_1 = taggable_1.evaluate_tags(['tagged'], [], {})
    assert result_1 == True

    # Testing for always
    taggable_2 = Taggable()
    taggable_2.tags = ['always']
    result_2 = taggable_2.evaluate_tags([], ['all'], {})
    assert result_2 == True

    # Testing for never
    taggable_3

# Generated at 2022-06-25 06:08:08.132238
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Constructor for class Trivial
    taggable = Taggable()
    taggable._tags = ['unittest']
    # evaluate_tags(only_tags, skip_tags, all_vars)
    assert taggable.evaluate_tags(['unittest'], [], {})
    assert not taggable.evaluate_tags(['unittest2'], [], {})
    assert taggable.evaluate_tags([], ['unittest'], {})
    assert not taggable.evaluate_tags([], ['unittest2'], {})
    assert taggable.evaluate_tags(['unittest'], ['unittest2'], {})
    assert not taggable.evaluate_tags(['unittest2'], ['unittest'], {})
    assert taggable.evaluate

# Generated at 2022-06-25 06:08:15.258503
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    defined_tags = ["tag1", "tag2", "tag3"]
    only_tags = ["tag1", "tag2"]
    skip_tags = ["tag3"]
    all_vars = dict()

    evaluate_tag_result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    taggable_0.tags = defined_tags
    evaluate_tag_result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

test_Taggable_evaluate_tags()
test_case_0()

# Generated at 2022-06-25 06:08:19.433708
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['always']
    taggable.evaluate_tags(['all'], ['never'], {})
    assert taggable.should_run == True


# Generated at 2022-06-25 06:08:29.250857
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

    host_vars = HostVars(play=None, variables=dict())
    vars = combine_vars(loader=None, variables=dict(), iteritems=dict(hostvars=host_vars).iteritems())

    task1 = Task()

    assert(not task1.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], vars))
    assert(task1.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], vars))


test_case_0()

# Generated at 2022-06-25 06:08:31.862227
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['a', 'b', 'c']
    only_tags = ['b'] # should_run = True
    skip_tags = ['d']
    all_vars = {}
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True


# Generated at 2022-06-25 06:08:36.429927
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = frozenset(['all', 'always'])
    skip_tags_0 = frozenset(['all', 'always'])
    all_vars_0 = None
    result = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result

# Generated at 2022-06-25 06:09:04.616256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:09:14.630890
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1._tags = ['always']
    assert taggable_1.evaluate_tags(['always'], [], {}) == True
    assert taggable_1.evaluate_tags(['never'], ['always'], {}) == False
    assert taggable_1.evaluate_tags(['never','all'], ['always'], {}) == False
    assert taggable_1.evaluate_tags(['always', 'all'], [], {}) == True
    assert taggable_1.evaluate_tags(['always', 'all'], ['always', 'always'], {}) == True
    assert taggable_1.evaluate_tags(['never', 'all'], ['never', 'never'], {}) == False
    assert taggable_1.evaluate_tags

# Generated at 2022-06-25 06:09:18.835596
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['test_Taggable_evaluate_tags1', 'test_Taggable_evaluate_tags2']
    result = taggable.evaluate_tags(['test_Taggable_evaluate_tags1', 'test_Taggable_evaluate_tags2'], ['test_Taggable_evaluate_tags3'], {})
    assert result == True


# Generated at 2022-06-25 06:09:23.842221
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0  = ['all']
    skip_tags_0  = ['all']
    all_vars_0   = {'myVars': 'myVarsValue'}
    result_0 = taggable_0.evaluate_tags(only_tags=only_tags_0, skip_tags=skip_tags_0, all_vars=all_vars_0)
    assert result_0 == True


# Generated at 2022-06-25 06:09:30.494228
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ["tag_0", "tag_1", "tag_2"]
    assert taggable_0.evaluate_tags(["tag_0", "tag_1", "tag_2"], [], "test_vars_0") == True
    taggable_1 = Taggable()
    taggable_1.tags = []
    assert taggable_1.evaluate_tags([], [], "test_vars_1") == True

# Generated at 2022-06-25 06:09:34.480163
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['test']
    result = taggable_0.evaluate_tags(['test1'], ['test'], None)
    assert result == False


# Generated at 2022-06-25 06:09:36.017522
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:43.926630
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create new class instance
    taggable_1 = Taggable()
    print(taggable_1)
    # Evaluate state of method evaluate_tags for class Taggable
    actual_result_1 = taggable_1.evaluate_tags
    print(actual_result_1)
    assert actual_result_1 == 'evaluate_tags'


# Generated at 2022-06-25 06:09:52.795999
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    ### Test 0:
    taggable_0 = Taggable()
    taggable_0._tags = ['my_tags','123','abc','456','def','789','ghi','always','skip','lmn','never','abc','abc','abc','abc','abc']
    only_tags_0 = ['all','abc']
    skip_tags_0 = ['never','123']

    result_0 = taggable_0.evaluate_tags(only_tags_0,skip_tags_0)
    assert result_0 == True

Taggable.tags_0 = ['my_tags','123','abc','456','def','789','ghi','always','skip','lmn','never','abc','abc','abc','abc','abc']
Taggable.only_tags_0 = ['all','abc']
Taggable.skip_tags_0

# Generated at 2022-06-25 06:09:57.330052
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ["tag0","tag1","tag2","tag3"]
    only_tags = ["tag0","tag1","tag2","tag3","tag4","tag5","tag6","tag7","tag8","tag9","always"]
    skip_tags = ["tag5","tag6","tag7","tag8","tag9","never","always"]

    assert taggable_1.evaluate_tags(only_tags, skip_tags, None)

# Generated at 2022-06-25 06:11:01.566168
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags('', '', '') == 1


# Generated at 2022-06-25 06:11:05.167986
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # should_run = True  # default, tasks to run
    only_tags = {'always'}
    skip_tags = {}
    # all_vars = {}
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, {})
    assert result_0 == True

# Generated at 2022-06-25 06:11:10.650830
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ["tag1"]
    skip_tags = []
    all_vars = {}
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result_0 == False

# Generated at 2022-06-25 06:11:20.855849
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # If one of 'only_tags' is part of 'tags'
    taggable_1 = Taggable()
    taggable_1.tags = ['my_tag1']
    only_tags = ['my_tag1']
    skip_tags = ['my_tag2']
    assert taggable_1.evaluate_tags(only_tags, skip_tags, None)

    # If one of 'only_tags' is 'tagged' and 'tags' is not empty
    taggable_2 = Taggable()
    taggable_2.tags = ['my_tag1']
    only_tags = ['tagged']
    skip_tags = ['my_tag2']
    assert taggable_2.evaluate_tags(only_tags, skip_tags, None)

    # If one of 'only_tags' is

# Generated at 2022-06-25 06:11:30.939989
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test cases and expected results
    t_0 = dict()
    t_0['only_tags'] = set(['all'])
    t_0['skip_tags'] = set(['all'])
    t_0['tags'] = set(['tagged'])
    t_0['expected_result'] = False
    t_1 = dict()
    t_1['only_tags'] = set(['tagged'])
    t_1['skip_tags'] = set(['tagged'])
    t_1['tags'] = set(['tagged'])
    t_1['expected_result'] = False
    t_2 = dict()
    t_2['only_tags'] = set(['tagged'])
    t_2['skip_tags'] = set(['all'])

# Generated at 2022-06-25 06:11:40.216752
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    # test default values of only_tags and skip_tags - no tags
    assert taggable.evaluate_tags(only_tags = None, skip_tags = None, all_vars = {})

    # test only_tags -- should run
    taggable.tags = ['dev']
    assert taggable.evaluate_tags(only_tags = ['dev'], skip_tags = None, all_vars = {})
    taggable.tags = ['dev', 'rhel7']
    assert taggable.evaluate_tags(only_tags = ['dev'], skip_tags = None, all_vars = {})

    # test only_tags -- should not run
    taggable.tags = ['prod', 'rhel7']

# Generated at 2022-06-25 06:11:50.345556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    assert taggable_0.evaluate_tags(['all'], [], {}) is True, "Test 1 of evaluate_tags failed"
    assert taggable_0.evaluate_tags(['tagged'], [], {}) is True, "Test 2 of evaluate_tags failed"
    assert taggable_0.evaluate_tags([], [], {}) is False, "Test 3 of evaluate_tags failed"
    assert taggable_0.evaluate_tags(['tagged'], ['tagged'], {}) is False, "Test 4 of evaluate_tags failed"
    assert taggable_0.evaluate_tags([], ['all'], {}) is False, "Test 5 of evaluate_tags failed"

# Generated at 2022-06-25 06:11:59.216728
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ["tag0"]
    only_tags_1 = None
    skip_tags_1 = None
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, {})
    taggable_2 = Taggable()
    taggable_2.tags = ["tag0"]
    only_tags_2 = ["tag0"]
    skip_tags_2 = ["tag1"]
    assert taggable_2.evaluate_tags(only_tags_2, skip_tags_2, {})
    taggable_3 = Taggable()
    taggable_3.tags = ["tag0"]
    only_tags_3 = ["tag0"]
    skip_tags_3 = ["tag0"]
   

# Generated at 2022-06-25 06:12:07.252565
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = [ ]
    skip_tags_0 = [ ]
    all_vars_0 = { 'hostvars': { 'host0': { }, }, }
    test_case_0_0 = Taggable.evaluate_tags(taggable_0, only_tags_0, skip_tags_0, all_vars_0)
    assert test_case_0_0 == True


# Generated at 2022-06-25 06:12:08.465612
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    # Just call it to make sure it runs through
    taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

# Generated at 2022-06-25 06:14:57.259458
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    skip_tags = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    all_vars = FieldAttribute(isa='list', default=list, listof=(string_types, int), extend=True)
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) is True

if __name__=="__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:00.081286
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    out = taggable_1.evaluate_tags(set(), set())
    assert out == True

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:05.978445
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = "foo, bar"
    only_tags = {'foo'}
    skip_tags = set()
    all_vars = {}
    expected = True
    returned = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert returned == expected


# Generated at 2022-06-25 06:15:11.140162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = ['server', 'webserver']
    assert taggable_0.evaluate_tags(['tagged'], [], {}) == True


# Generated at 2022-06-25 06:15:22.027858
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1._tags = ["test"]
    assert taggable_1.evaluate_tags(["test"],["other"], {})
    assert taggable_1.evaluate_tags("test", "other", {})
    assert taggable_1.evaluate_tags("test, other", "skip", {})
    assert taggable_1.evaluate_tags("test", "", {})
    assert taggable_1.evaluate_tags("", "skip", {})
    assert taggable_1.evaluate_tags("", "", {})
    assert taggable_1.evaluate_tags("test", "skip", {})
    assert taggable_1.evaluate_tags("", "skip", {})

# Generated at 2022-06-25 06:15:32.858057
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test: tags is not set
    taggable_0 = Taggable()
    taggable_0.tags = None
    assert taggable_0.evaluate_tags(['tag1'], [], [])
    assert taggable_0.evaluate_tags(['tag1', 'tagged'], [], [])
    assert taggable_0.evaluate_tags([], ['tag1'], [])
    assert taggable_0.evaluate_tags(['tagged'], ['tag1'], [])
    
    # Test: tags is set and match
    taggable_0 = Taggable()
    taggable_0.tags = 'tag1'
    assert taggable_0.evaluate_tags(['tag1'], [], [])