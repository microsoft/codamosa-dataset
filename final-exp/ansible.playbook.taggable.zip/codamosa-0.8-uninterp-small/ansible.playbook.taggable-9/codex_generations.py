

# Generated at 2022-06-25 06:05:49.843620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()

    # test in case of only_tags = ['tag1','tag2'] and skip_tags = False
    only_tags = ['tag1','tag2']
    skip_tags = False
    all_vars = dict()

    taggable_0.tags = ['tag1','tag2']
    taggable_0.evaluate_tags(only_tags,skip_tags,all_vars)
    assert taggable_0.tags == ['tag1','tag2']

    taggable_0.tags = ['tag1']
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert taggable_0.tags == ['tag1']

    taggable_0.tags = ['tag2']
    taggable_0

# Generated at 2022-06-25 06:05:58.727073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ('redhat', "gentoo")
    skip_tags_0 = ('ubuntu', "debian")

# Generated at 2022-06-25 06:06:08.905421
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable:
        def __init__(self, tags):
            self.tags = tags

    taggable = FakeTaggable(tags=None)

    # Check if all tags should run
    assert taggable.evaluate_tags(only_tags=['always'], skip_tags=None, all_vars={})
    assert taggable.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={})
    assert taggable.evaluate_tags(only_tags=['tagged'], skip_tags=None, all_vars={})
    assert taggable.evaluate_tags(only_tags=['untagged'], skip_tags=None, all_vars={})

    # Check if all tags should skip

# Generated at 2022-06-25 06:06:18.648469
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = set(['always'])
    assert taggable_0.evaluate_tags(None, None, None) == True
    assert taggable_0.evaluate_tags(None, ['always'], None) == False
    assert taggable_0.evaluate_tags(['never'], None, None) == False
    assert taggable_0.evaluate_tags(['never'], ['never'], None) == False
    assert taggable_0.evaluate_tags(['never'], ['always'], None) == False
    assert taggable_0.evaluate_tags(['always'], None, None) == True
    assert taggable_0.evaluate_tags(['always'], ['never'], None) == True
    assert taggable_

# Generated at 2022-06-25 06:06:27.585214
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['a', 'b', 'c']
    only_tags = ['a', 'b', 'c', 'all', 'tagged', 'always']
    skip_tags = ['a', 'b', 'c', 'never', 'all', 'tagged']
    assert taggable_1.evaluate_tags(only_tags, skip_tags, {})
    only_tags = ['aaa', 'bbb', 'ccc', 'all', 'tagged', 'always']
    assert not taggable_1.evaluate_tags(only_tags, skip_tags, {})
    only_tags = ['a', 'b', 'c', 'all', 'tagged', 'always']

# Generated at 2022-06-25 06:06:37.837665
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test if Tagable.evaluate_tags() evaluates expected results with test_tags
    test_tags = {'should_run': True, 'base_tags': ['tagA'], 'only_tags': ['tagA'], 'skip_tags': ['tagA'], 'all_vars': {}}
    assert Taggable().evaluate_tags(test_tags['only_tags'], test_tags['skip_tags'], test_tags['all_vars']) == test_tags['should_run']

    test_tags = {'should_run': True, 'base_tags': ['tagA'], 'only_tags': ['tagA'], 'skip_tags': ['tagB'], 'all_vars': {}}

# Generated at 2022-06-25 06:06:47.035874
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test evaluate_tags for when tags is an empty list: empty list should be a subset
    # of tagged and all
    taggable_0 = Taggable()
    taggable_0.tags = []
    test_only_tags = ['tagged', 'all', 'something_else']
    test_skip_tags = []
    test_all_vars = {}
    test_should_run = taggable_0.evaluate_tags(test_only_tags, test_skip_tags, test_all_vars)
    assert test_should_run == True

    # Test evaluate_tags for when only_tags is non-empty but contains only 'all' and
    # skip_tags is empty: item should run since 'all' is in only_tags and not in skip_tags
    taggable_1 = Taggable()


# Generated at 2022-06-25 06:06:57.549797
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['foo']
    assert taggable.evaluate_tags(['foo'], [], {}) == True
    assert taggable.evaluate_tags(['foo', 'bar'], [], {}) == True
    assert taggable.evaluate_tags(['bar'], [], {}) == False
    assert taggable.evaluate_tags(['foo', 'bar'], ['foo'], {}) == False
    assert taggable.evaluate_tags(['bar'], ['foo'], {}) == False
    taggable.tags = []
    assert taggable.evaluate_tags(['untagged'], [], {}) == True
    assert taggable.evaluate_tags([], [], {}) == True

# Generated at 2022-06-25 06:07:06.512230
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # instantiate Taggable class
    taggable_instance = Taggable()

    # set tags to "all"
    taggable_instance.tags = "all"

    # set skip_tags to "never"
    skip_tags_values = "never"

    # set only_tags to "always"
    only_tags_values = "always"

    # call method evaluate_tags with skip_tags="never," only_tags="always"
    should_run = taggable_instance.evaluate_tags(skip_tags_values, only_tags_values, None)

    # assert evaluate_tags returns False
    assert should_run == False


# Generated at 2022-06-25 06:07:12.110686
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._load_tags('tags', 'tag_one, tag_two')
    only_tags = ['tag_two']
    skip_tags = []
    all_vars = {}
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert taggable_0.evaluate_tags == False
    assert taggable_0.evaluate_tags == False
    assert taggable_0.evaluate_tags == False
    assert taggable_0.evaluate_tags == False



# Generated at 2022-06-25 06:07:29.511950
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    assert taggable_1.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:35.377074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['all']
    all_vars_0 = {}
    assert taggable_0.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars=all_vars_0) == False
    all_vars_1 = {}
    assert taggable_0.evaluate_tags(only_tags=[], skip_tags=[], all_vars=all_vars_1) == True

# Generated at 2022-06-25 06:07:46.225576
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ast
    import os
    taggable_0 = Taggable()
    # Create an empty list to hold ansible_vars
    ansible_vars = []

    # Get the values from the file "examples/0-test.yml"
    with open("examples/0-test.yml", "rt") as fp:
        for line in fp:
            ansible_vars.append(ast.literal_eval(line))
    fp.close()

    # Create the variable only_tags
    only_tags = ansible_vars[0]["only_tags"]

    # Create the variable skip_tags
    skip_tags = ansible_vars[0]["skip_tags"]

    # Create the variable all_vars

# Generated at 2022-06-25 06:07:57.440738
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create test class
    taggable_0 = Taggable()

    # Test for should_run == False and if tag is never
    only_tags = ['never']
    skip_tags = None
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == False
    
    # Test for should_run == True if tag is never and never is present in skip_tags
    only_tags = ['never']
    skip_tags = ['never']
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == True
    
    # Test for should_run == False if tag is always and only_tags and skip_tags both have some tag

# Generated at 2022-06-25 06:07:59.138630
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-25 06:08:07.437809
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['all'], ['never'], {})
    assert not taggable_0.evaluate_tags(['all'], ['all'], {})
    assert not taggable_0.evaluate_tags(['all'], ['never'], {})
    assert not taggable_0.evaluate_tags(['all'], ['all'], {})
    assert taggable_0.evaluate_tags(['all'], ['all'], {})
    assert taggable_0.evaluate_tags(['all'], ['all'], {})
    assert taggable_0.evaluate_tags(['all'], ['all'], {})
    assert not taggable_0.evaluate_tags(['all'], ['all'], {})

# Generated at 2022-06-25 06:08:13.810264
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ['tag_0']
    skip_tags_0 = ['tag_1']
    all_vars_0 = {}
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    print(result_0)
    print(type(result_0))
    
    
if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:18.344430
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags([], [], []) == True


# Generated at 2022-06-25 06:08:26.439792
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ansible_module_0 = Taggable()
    ansible_module_0._tags = Taggable._load_tags(ansible_module_0, "test_string")
    only_tags_0 = None
    skip_tags_0 = None
    all_vars_0 = None
    result = ansible_module_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert not result

# Generated at 2022-06-25 06:08:29.121599
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # Evaluate if the current item should be executed depending on tag options
    result = taggable_0.evaluate_tags()

    # Check the value against a constant value
    assert result == true

# Generated at 2022-06-25 06:08:48.960125
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    skip_tags = ['skip']
    only_tags = ['only']
    all_vars = {}
    taggable_1.tags = ['skip', 'only']
    var_0 = taggable_1.evaluate_tags(skip_tags, only_tags, all_vars)
    assert var_0 == False


# Generated at 2022-06-25 06:08:51.588425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

# Generated at 2022-06-25 06:08:56.064427
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

# Generated at 2022-06-25 06:08:59.056203
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert var_0 == True


# Generated at 2022-06-25 06:09:03.219108
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Testing taggable_0
    taggable_0 = Taggable()
    list_0 = []
    assert taggable_0.evaluate_tags(taggable_0, list_0, taggable_0), "test_0_evaluate_tags, 1"
    list_1 = []
    assert True, "test_0_evaluate_tags, 2"

# Generated at 2022-06-25 06:09:07.494047
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    taggable_1 = Taggable()
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_1)
    assert var_0 == True

# Generated at 2022-06-25 06:09:11.965583
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_1 = Taggable()
    list_0 = ['always']
    var_0 = taggable_0.evaluate_tags(list_0, taggable_0, taggable_1)
    assert var_0 is True


# Generated at 2022-06-25 06:09:15.519591
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()
    skip_tags = []
    only_tags = []
    taggable_obj.evaluate_tags(taggable_obj, only_tags, skip_tags)


if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:16.642692
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:09:19.039707
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable()
    taggable_0._loader = object()
    var_0 = taggable_0.evaluate_tags(list_0, list_0, list_0)
    assert var_0 == True

# Generated at 2022-06-25 06:09:48.023628
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    list_1 = []
    var_0 = taggable_0.evaluate_tags(list_0, list_1, taggable_0)

# Generated at 2022-06-25 06:09:54.988984
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_1 = Taggable()
    taggable_2 = Taggable()
    taggable_3 = Taggable()

    taggable_0.tags = ['foo', 'bar']
    taggable_1.tags = ['foo','bar','baz']
    taggable_2.tags = ['baz','qux']
    taggable_3.tags = ['qux']

    assert taggable_0.evaluate_tags(['foo','bar','baz'], [], None)
    assert taggable_1.evaluate_tags(['foo','bar','baz'], [], None)
    assert  not taggable_2.evaluate_tags(['foo','bar','baz'], [], None)
    assert  not tagg

# Generated at 2022-06-25 06:09:58.944408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        assert test_case_0() == True, \
            'Expected True, but got %s' % repr(test_case_0())
    except AssertionError as e:
        raise e


# Generated at 2022-06-25 06:10:00.694551
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()
    list_obj = []
    assert Taggable.evaluate_tags(taggable_obj, list_obj, taggable_obj) is True



# Generated at 2022-06-25 06:10:02.749271
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert var_0 == True


# Generated at 2022-06-25 06:10:05.416739
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #
    # Taggable test
    #
    print("")
    test_case_0()


test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:10:08.033860
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    list_1 = []
    var_1 = taggable_1.evaluate_tags(taggable_1, list_1, taggable_1)
    assert var_1 


# Generated at 2022-06-25 06:10:14.788536
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    str_0 = 'tag_0'
    list_1 = []
    var_0 = add_to_list(list_1, str_0)
    taggable_2 = Taggable()
    list_2 = ['tag_0']
    var_0 = taggable_2.evaluate_tags(taggable_0, list_2, taggable_2)


# Generated at 2022-06-25 06:10:21.617528
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()

    # Test Case: when self.tags = list()
    var_0 = []
    var_1 = taggable_0
    var_2 = taggable_0
    try:
        var_2.evaluate_tags(var_0, var_1, taggable_0)
    except:
        var_3 = False
    else:
        var_3 = True
    assert var_3

    # Test Case: when self.tags = ["abc","def"]
    var_4 = ["abc","def"]
    var_5 = taggable_0
    var_6 = taggable_0
    try:
        var_6.evaluate_tags(var_4, var_5, taggable_0)
    except:
        var_7 = False
   

# Generated at 2022-06-25 06:10:25.354927
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = ['test']
    taggable_0.tags = ['abc', 'def']
    list_0 = []
    var_0 = taggable_0.evaluate_tags(list_0, list_0, taggable_0)

# Generated at 2022-06-25 06:11:33.002919
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    print(var_0)

# Generated at 2022-06-25 06:11:33.842791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Unit test class for Taggable

# Generated at 2022-06-25 06:11:36.441309
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert var_0 == True

# Generated at 2022-06-25 06:11:41.123903
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = ['tagged']
    taggable_0 = Taggable()
    taggable_0.tags = list_0
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

# Generated at 2022-06-25 06:11:51.697600
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    list_1 = []
    taggable_1.tags = ['origin', 'net', 'important']
    all_vars_1 = {}
    only_tags_1 = []
    skip_tags_1 = []
    var_0 = taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert var_0 == True

    taggable_2 = Taggable()
    list_2 = []
    taggable_2.tags = 'origin, net, important'
    all_vars_2 = {}
    only_tags_2 = []
    skip_tags_2 = []

# Generated at 2022-06-25 06:11:54.690193
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['tags']
    var_0 = taggable_0.evaluate_tags(taggable_0._tags, taggable_0, taggable_0)
    assert var_0 == True

# Generated at 2022-06-25 06:11:59.162165
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

# Generated at 2022-06-25 06:12:05.965941
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['test']
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert var_0 == True
# Test case for tags attribute of Taggable

# Generated at 2022-06-25 06:12:08.825763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert var_0 == True

# Generated at 2022-06-25 06:12:10.703481
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    param_0 = []
    param_1 = taggable
    param_2 = taggable
    taggable.evaluate_tags(param_0, param_1, param_2)


# Generated at 2022-06-25 06:15:02.279793
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert var_0 is True, 'Expected evaluate_tags to return True'

# Generated at 2022-06-25 06:15:04.854044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert (var_0 == True)

# Generated at 2022-06-25 06:15:07.201090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

# Generated at 2022-06-25 06:15:10.966821
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    list_0 = []
    var_0 = taggable.evaluate_tags(taggable, list_0, taggable)
    assert var_0



# Generated at 2022-06-25 06:15:15.752938
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    list_1 = []
    var_0 = taggable_0.evaluate_tags(list_0, list_1, taggable_0)

test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:18.357553
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

# Generated at 2022-06-25 06:15:23.935475
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['a','b']

    only_tags = set(['a','c','d','z'])
    skip_tags = set(['b','d','e'])

    taggable.evaluate_tags(only_tags, skip_tags, taggable)

test_Taggable_evaluate_tags()
test_case_0()

# Generated at 2022-06-25 06:15:28.714106
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)
    assert str(var_0) == 'True'

# Generated at 2022-06-25 06:15:31.794297
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = []
    var_0 = taggable_0.evaluate_tags(taggable_0, list_0, taggable_0)

