

# Generated at 2022-06-25 06:05:47.304823
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    assert(taggable.evaluate_tags([], [], {}))


# Generated at 2022-06-25 06:05:51.938377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Tag attributes of class
    taggable = Taggable()
    taggable._tags = ['foo', 'bar']

    # Run method evaluate_tags of class Taggable
    result = taggable.evaluate_tags(only_tags = ["foo", "bar", "all"], skip_tags = ["always"], all_vars = {})
    assert result == True



# Generated at 2022-06-25 06:05:54.542772
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['test_case_0'], ['test_case_0'], {}) == False


# Generated at 2022-06-25 06:06:04.153795
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    assert taggable.evaluate_tags(['linux'], [], {}) == True
    assert taggable.evaluate_tags(['windows'], [], {}) == False
    assert taggable.evaluate_tags(['linux', 'windows'], [], {}) == True

    assert taggable.evaluate_tags([], ['linux'], {}) == False
    assert taggable.evaluate_tags([], ['windows'], {}) == True
    assert taggable.evaluate_tags([], ['linux', 'windows'], {}) == False

    assert taggable.evaluate_tags(['linux'], ['windows'], {}) == True
    assert taggable.evaluate_tags(['linux', 'windows'], ['windows'], {}) == True

# Generated at 2022-06-25 06:06:12.173813
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_case = []
    test_case.append(Taggable())
    test_case[0]._tags = ["tag1","tag2"]
    test_case.append(Taggable())
    test_case[1]._tags = ["tag1","tag2","never"]
    test_case.append(Taggable())
    test_case[2]._tags = Taggable.untagged
    test_case.append(Taggable())
    test_case[3]._tags = ["tag1","tag2","always"]

    for case in test_case:
        assert case.evaluate_tags(only_tags = ["tag1","tag2"], skip_tags = ["tag2"], all_vars = {}) == True

# Generated at 2022-06-25 06:06:20.801887
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = [
        'tag_3',
        'tag_2',
        'tag_1',
        'tag_6',
        'tag_5',
        'tag_4',
        'tag_9',
        'tag_8',
        'tag_7',
    ]
    skip_tags_0 = [
        'tag_3',
        'tag_2',
        'tag_1',
        'tag_6',
        'tag_5',
        'tag_4',
        'tag_9',
        'tag_8',
        'tag_7',
    ]

# Generated at 2022-06-25 06:06:28.451331
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['test']
    # Test first branch of if-statement in evaluate_tags
    result = taggable.evaluate_tags(['test'], ['never'], {'test_key':'test_value'})
    if result != True:
        raise AssertionError()
    # test second branch of if-statement
    result = taggable.evaluate_tags(['test'], ['never'], {'test_key': ['test_value','test_value_2']})
    if result != True:
        raise AssertionError()
    # test first branch of else-statement
    result = taggable.evaluate_tags(['test'], ['never'], {'test_key': 'xml'})
    if result != True:
        raise AssertionError()

# Generated at 2022-06-25 06:06:38.678619
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    def test_0():
        # only_tags must be specified as a list of strings
        only_tags_0 = list()
        # skip_tags must be specified as a list of strings
        skip_tags_0 = list()
        all_vars_0 = dict()
        assert (taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True)
        return True
    def test_1():
        # only_tags must be specified as a list of strings
        only_tags_0 = list()
        # skip_tags must be specified as a list of strings
        skip_tags_0 = list()
        all_vars_0 = dict()

# Generated at 2022-06-25 06:06:41.778186
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    args_0 = [set(), set(), {}]
    kwargs_0 = {}
    assert taggable_0.evaluate_tags(*args_0, **kwargs_0) is True


# Generated at 2022-06-25 06:06:51.817822
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.inventory.host import Host
    taggable_0 = Taggable(tags=['test'], loader=None, variable_manager=None, _host=Host('test'))
    taggable_0._ds = dict()
    taggable_0._ds['tags'] = ['test']
    taggable_1 = Taggable(tags=['test'], loader=None, variable_manager=None, _host=Host('test'))
    taggable_1._ds = dict()
    taggable_1._ds['tags'] = ['test']
    taggable_2 = Taggable(tags=['test'], loader=None, variable_manager=None, _host=Host('test'))
    taggable_2._ds = dict()

# Generated at 2022-06-25 06:07:13.452608
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import re
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    shutil.copyfile('test/ansible.cfg', tmp_dir + "/" + 'ansible.cfg')

    playbook_file = open('files/test_evaluate_tags.yml', 'r')
    playbook_file_data= playbook_file.read()

    playbook_file  = open('files/test_evaluate_tags.yml', 'w')

    playbook_file_data = re.sub('<<INVENTORY>>', tmp_dir, playbook_file_data)
    playbook_file.write(playbook_file_data)
    playbook_file.close()

    # Create a temporary inventory file

# Generated at 2022-06-25 06:07:19.026718
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == True


# Generated at 2022-06-25 06:07:26.179197
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    ''' Evaluates if the given tags should be run or skipped. Uses only_tags and skip_tags to
    determine if the current item should be run. Returns True if the current item should run,
    false otherwise. '''

    # valid tag formats
    taggable_0 = Taggable()
    taggable_0.tags = ['0']
    taggable_0.tags = ['0', '1']
    taggable_0.tags = ['0', '1', '2']
    taggable_0.tags = ''
    taggable_0.tags = '0'
    taggable_0.tags = '0, 1'
    taggable_0.tags = '0, 1, 2'

    # invalid tag formats

# Generated at 2022-06-25 06:07:35.247437
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['all'], [], {}), 'Check evaluate_tags when only_tags is [all]'
    assert not taggable_0.evaluate_tags(['other'], [], {}), 'Check evaluate_tags when only_tags is [other]'
    assert taggable_0.evaluate_tags(['all'], ['never'], {}), 'Check evaluate_tags when skip_tags is [never]'
    assert taggable_0.evaluate_tags(['all'], ['other'], {}), 'Check evaluate_tags when skip_tags is [other]'
    assert not taggable_0.evaluate_tags(['all'], ['tagged'], {}), 'Check evaluate_tags when skip_tags is [tagged]'
    assert taggable_0

# Generated at 2022-06-25 06:07:46.115271
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # create a Taggable object
    test_taggable = Taggable()

    # Add tags
    test_taggable.tags = ['tag1']

    # Test 'only_tags' is a string and not a list
    assert test_taggable.evaluate_tags('only_tags', None, None) == False
    test_taggable.tags = ['always']
    assert test_taggable.evaluate_tags('only_tags', None, None) == True

    # Test when 'only_tags' is a list and 'tags' is not tagged
    test_taggable.tags = []
    assert test_taggable.evaluate_tags(['only_tags'], None, None) == False
    test_taggable.tags = ['always']

# Generated at 2022-06-25 06:07:53.882626
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    only_tags = ['tag3','tag4','tag5']
    skip_tags = []
    all_vars = ['tag1', 'tag2']
    tag = 'tag2'
    
    class mystr(str):
        def isdisjoint(self,other):
            return not self==other
        
    tag = mystr(tag)
    
    assert taggable.evaluate_tags(only_tags,skip_tags,all_vars)==False

# Generated at 2022-06-25 06:07:59.987988
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    skip_tags_0 = []
    only_tags_0 = []
    vars_0 = {
        'blahblah': True,
        'foo': 'foo',
        'bar': 'bar'
    }
    taggable_0.tags = ['blahblah']
    expected = True
    result = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, vars_0)
    assert result == expected


# Generated at 2022-06-25 06:08:05.522583
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ["t0", "t1"]
    result_0 = taggable_0.evaluate_tags(set(), set(["t0"]), dict())
    assert result_0 == True


# Generated at 2022-06-25 06:08:14.407902
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_2 = Taggable()
    taggable_3 = Taggable()
    taggable_4 = Taggable()
    taggable_5 = Taggable()
    taggable_6 = Taggable()
    taggable_7 = Taggable()
    taggable_8 = Taggable()
    taggable_9 = Taggable()
    taggable_10 = Taggable()
    taggable_11 = Taggable()

    # Create some test data
    only_tags = set(['tag_a', 'tag_b'])
    skip_tags = {'tag_c'}
    all_vars = {}

    # Test on taggable_1

# Generated at 2022-06-25 06:08:23.650464
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    skip = [
        'critical',
        'debug',
        'devel',
        'fatal'
    ]
    taggable = Taggable()
    # tags: always, security, critical, debug, devel
    # skip_tags: critical, debug, devel
    # only_tags: []
    taggable.tags = ['always', 'security', 'critical', 'debug', 'devel']
    result = taggable.evaluate_tags(only_tags=[],
                                    skip_tags=skip,
                                    all_vars={})
    assert result is False
    # tags: always, critical, debug, devel
    # skip_tags: critical, debug, devel
    # only_tags: []

# Generated at 2022-06-25 06:09:00.759163
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test case when only_tags is set and taggable_1.tags == 'foo, bar'
    test_case_1_only_tags = set(['foo', 'bar'])
    taggable_1 = Taggable()
    taggable_1.tags = 'foo, bar'
    # Test to see if evaluate_tags returns True
    assert(taggable_1.evaluate_tags(test_case_1_only_tags, set([]), dict()) == True)

    # Test case when skip_tags is set and taggable_1.tags == 'foo, bar'
    test_case_2_skip_tags = set(['foo', 'bar'])
    taggable_1 = Taggable()
    taggable_1.tags = 'foo, bar'
    # Test to see if evaluate_

# Generated at 2022-06-25 06:09:06.255747
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()

    taggable_1.tags = ['foo', 'bar']
    assert (taggable_1.evaluate_tags(['foo'], [], {}) == True)
    assert (taggable_1.evaluate_tags(['foo', 'bar'], [], {}) == True)
    assert (taggable_1.evaluate_tags(['baz'], [], {}) == False)

    taggable_1.tags = ['foo', 'bar']
    assert (taggable_1.evaluate_tags([], ['foo'], {}) == False)
    assert (taggable_1.evaluate_tags([], ['foo', 'bar'], {}) == False)
    assert (taggable_1.evaluate_tags([], ['baz'], {}) == True)



# Generated at 2022-06-25 06:09:10.246022
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    assert taggable.evaluate_tags(['all'], [], {}) == True


# Generated at 2022-06-25 06:09:18.740759
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # Test happy path
    tags = ['foo', 'bar']
    only_tags = tags
    skip_tags = set()
    assert taggable.evaluate_tags(only_tags, skip_tags, {})

    # Test happy path
    tags = []
    only_tags = ['all', 'tagged']
    skip_tags = set()
    assert taggable.evaluate_tags(only_tags, skip_tags, {})

    # Test happy path
    tags = ['foo', 'bar']
    only_tags = ['all', 'tagged']
    skip_tags = set()
    assert taggable.evaluate_tags(only_tags, skip_tags, {})

    # Test happy path
    tags = []
    only_tags = []
    skip_tags = set()


# Generated at 2022-06-25 06:09:23.343487
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = None
    skip_tags_0 = None
    all_vars_0 = None
    expected_0 = True
    actual_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert actual_0 == expected_0

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:32.880127
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Taggable object for testing
    taggable = Taggable()

    # set tags
    taggable.tags = ["tag1", "tag2"]

    # run test with only_tags, skip_tags, all_vars passed as None
    # 	should return True
    if (taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)):
        return True

    # run test with only_tags, skip_tags, all_vars passed as None
    # 	should return False
    if (taggable.evaluate_tags(only_tags=None, skip_tags=["tag1"], all_vars=None)):
        return False

    # run test with only_tags, skip_tags, all_vars passed as None
    # 	should return

# Generated at 2022-06-25 06:09:43.290661
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    my_taggable_obj = Taggable()
    assert my_taggable_obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) # True
    assert my_taggable_obj.evaluate_tags([], [], {}) # True
    assert my_taggable_obj.evaluate_tags(['tag1'], ['tag2'], {}) # True
    assert my_taggable_obj.evaluate_tags(['tag1'], ['tag1', 'tag2'], {}) # False
    assert my_taggable_obj.evaluate_tags(['tag2', 'tag3'], ['tag1'], {}) # True

# Generated at 2022-06-25 06:09:52.384370
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test if tags contain all, skip_tags include all, should not return true
    taggable_1 = Taggable()
    taggable_1.tags = ['foo', 'bar']
    only_tags = ['all']
    skip_tags = ['all']
    all_vars = {}
    assert taggable_1.evaluate_tags(only_tags, skip_tags, all_vars) is False

    # test if tags contain all, skip_tags include all, should not return true
    taggable_2 = Taggable()
    taggable_2.tags = ['foo', 'bar']
    only_tags = ['all']
    skip_tags = ['all', 'foo']
    all_vars = {}

# Generated at 2022-06-25 06:09:57.269975
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    tags_0 = taggable_0.tags
    only_tags_0 = taggable_0.only_tags
    skip_tags_0 = taggable_0.skip_tags
    all_vars_0 = taggable_0.vars
    should_run_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:10:02.105323
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("Unit test for method evaluate_tags")
    taggable = Taggable()
    result = taggable.evaluate_tags(['foo'], [], {})
    expected = False
    if result == expected:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 06:11:05.542081
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(['always'], None, {'ansible_check_mode': True}) == True
    assert taggable_0.evaluate_tags(['never'], None, {'ansible_check_mode': True}) == False



# Generated at 2022-06-25 06:11:09.992412
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # When given list (only_tags=['b']) and list (skip_tags=[]), should return False
    assert Taggable().evaluate_tags(only_tags=['b'], skip_tags=[], all_vars=None) == False

    # When given list (only_tags=['b']) and list (skip_tags=['c']), should return True
    assert Taggable().evaluate_tags(only_tags=['b'], skip_tags=['c'], all_vars=None) == True

    # When given list (only_tags=['a']) and list (skip_tags=['c', 'd']), should return True
    assert Taggable().evaluate_tags(only_tags=['a'], skip_tags=['c', 'd'], all_vars=None) == True

    # When

# Generated at 2022-06-25 06:11:13.972913
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ['always']
    skip_tags_0 = []
    all_vars_0 = {}

    # Call menthod evaluate_tags of class Taggable
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == True

# Generated at 2022-06-25 06:11:22.293274
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._loader = None
    only_tags=[""]
    skip_tags=[""]
    all_vars={}
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    taggable_0 = Taggable()
    taggable_0._loader = None
    only_tags=[""]
    skip_tags=[""]
    all_vars={"ansible_check_mode": "True"}
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

# Generated at 2022-06-25 06:11:23.702223
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()

    assert taggable.evaluate_tags(None, None, None) == True



# Generated at 2022-06-25 06:11:29.696149
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    all_vars_0 = dict()
    taggable_0.tags = ['tag']
    assert taggable_0.evaluate_tags(only_tags=None, skip_tags=None, all_vars=all_vars_0)
    #assert False, "Failing."
    return None

#testing
if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:36.062450
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    expected_0 = False
    actual_0 = taggable_0.evaluate_tags(['tag_0', 'tag_1'], ['tag_2', 'tag_3'], {'tag_0': 'tag_0', 'tag_1': 'tag_1', 'tag_2': 'tag_2', 'tag_3': 'tag_3'})
    assert expected_0 == actual_0, 'Expected: %s, Actual: %s' % (expected_0, actual_0)
    expected_1 = True

# Generated at 2022-06-25 06:11:38.931884
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj = Taggable()
    tags = ["1","2"]
    only_tags = ["1"]
    skip_tags = ["2"]
    all_vars = ["1"]
    assert taggable_obj.evaluate_tags(only_tags,skip_tags,all_vars) == True

# Generated at 2022-06-25 06:11:45.167978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # No parameters, return for default value
    evaluate_result0 = taggable_0.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)
    assert evaluate_result0 == True

    # Set only_tags with value 'foo'
    evaluate_result1 = taggable_0.evaluate_tags(only_tags='foo', skip_tags=None, all_vars=None)
    assert evaluate_result1 == True

    # Set only_tags with value 'baz'
    evaluate_result2 = taggable_0.evaluate_tags(only_tags='baz', skip_tags=None, all_vars=None)
    assert evaluate_result2 == True

    # Set skip_tags with value 'foo'
    evaluate_result

# Generated at 2022-06-25 06:11:53.823174
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9', 't10', 't11', 't12', 't13', 't14', 't15', 't16', 't17', 't18', 't19']
    skip_tags = ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9', 't10', 't11', 't12', 't13', 't14', 't15', 't16', 't17', 't18', 't19']
    all_vars = {}
    result = taggable_

# Generated at 2022-06-25 06:14:38.709300
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.playbook.attribute import FieldAttribute


    # Run of test_case_0
    taggable_0 = Taggable()
    taggable_1 = Taggable()

    # Run of test_case_1
    taggable_1._tags.extend(["all"])
    taggable_1.evaluate_tags(tuple(["all"]), tuple([]), dict())
    # Run of test_case_2
    taggable_2 = Taggable()

    # Run of test_case_3
    taggable_3 = Taggable()

    # Run of test_case_4
    taggable_4 = Taggable()
    tagg

# Generated at 2022-06-25 06:14:43.600586
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()

    # test case 0: normal case
    #assert taggable_0.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) is True

    # test case 2: skip_tags is a list
    test_list_2 = ['test_string_3', 'test_string_4']
    #assert taggable_0.evaluate_tags(only_tags=[], skip_tags=test_list_2, all_vars={}) is True

    # test case 3: only_tags is a list
    test_list_3 = ['test_string_5', 'test_string_6']
    #assert taggable_0.evaluate_tags(only_tags=test_list_3, skip_tags=[], all_vars={}) is True


# Generated at 2022-06-25 06:14:49.117552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1
    test_case_1 = dict(
        only_tags=[],
        skip_tags=[],
        all_vars=[],
        expected_result=True)
    taggable_1 = Taggable()
    taggable_1.tags = ['test']
    res = taggable_1.evaluate_tags(test_case_1['only_tags'], test_case_1['skip_tags'], test_case_1['all_vars'])
    assert res == test_case_1['expected_result']

    # Test case 2
    test_case_2 = dict(
        only_tags=['test'],
        skip_tags=[],
        all_vars=[],
        expected_result=True)
    taggable_2 = Taggable()
    taggable

# Generated at 2022-06-25 06:14:51.053750
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # This test is the same as test case 4 except we pass a list of tags instead of a string
    assert taggable.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=['tag3', 'tag4'], all_vars={}) == True



# Generated at 2022-06-25 06:14:55.790161
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = None
    skip_tags = None
    all_vars = dict()
    actual = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert actual is True, actual


# Generated at 2022-06-25 06:15:01.440314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Method evaluate_tags doesn't require any variables, this test is to just check if the method works
    assert(taggable_0.evaluate_tags([], [], {}) == True)

# Generated at 2022-06-25 06:15:11.238032
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable:

        def __init__(self, tags, only_tags, skip_tags, should_run, msg):
            self.tags = tags
            self.only_tags = only_tags
            self.skip_tags = skip_tags
            self.should_run = should_run
            self.msg = msg


# Generated at 2022-06-25 06:15:22.152531
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    var_0 = list()
    var_1 = 'tag'
    taggable_0.tags = var_0
    var_2 = list()
    var_3 = 'tag'
    taggable_0.tags = var_2
    taggable_0.evaluate_tags(var_1, var_3, '{}')
    var_4 = list()
    var_4 = None
    taggable_0.tags = var_4
    taggable_0.evaluate_tags(var_1, var_3, '{}')
    var_5 = list()
    var_6 = 'tag'
    var_5.append(var_6)
    taggable_0.tags = var_5
    taggable_0.evaluate_

# Generated at 2022-06-25 06:15:31.844768
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    # positive test cases
    only_tags = ["test"]
    skip_tags = ["test"]

    taggable.tags = ["test"]
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars=None) == True

    taggable.tags = ["runs"]
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars=None) == False

    # negative test cases
    only_tags = ["test"]
    skip_tags = ["test"]

    taggable.tags = ["test"]
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars=None) == True

    taggable.tags = ["runs"]

# Generated at 2022-06-25 06:15:36.079971
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    only_tags = None
    skip_tags = None
    all_vars = None

    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)