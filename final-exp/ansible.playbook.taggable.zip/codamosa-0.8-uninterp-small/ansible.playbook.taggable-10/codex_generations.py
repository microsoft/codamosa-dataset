

# Generated at 2022-06-25 06:05:50.727060
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = tag_only_tags_0
    skip_tags = tag_skip_tags_0
    all_vars = tag_all_vars_0
    should_run_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert(should_run_0 == False)

# Test data for test method evaluate_tags of class Taggable
tag_only_tags_0 = ['file','bits','bricks','bar','foo','foobar']
tag_skip_tags_0 = ['always','never','baz','qux','files','bits','bricks','bar','foo','foobar']
tag_all_vars_0 = {'foo':'bar'}

# Generated at 2022-06-25 06:06:00.178223
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['a','b','c']
    assert taggable.evaluate_tags(['a','b','c','d','e','f'], None, None) == True
    assert taggable.evaluate_tags(['g'], None, None) == False
    assert taggable.evaluate_tags(['c'], None, None) == True
    assert taggable.evaluate_tags(['a','b'], None, None) == True

    taggable.tags = ['a','c','e']
    assert taggable.evaluate_tags(['b','d'], None, None) == False
    assert taggable.evaluate_tags(['a','e'], None, None) == True

    taggable.tags = ['a','c','e']

# Generated at 2022-06-25 06:06:09.626582
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():                   # pylint: disable=too-many-arguments
    taggable = Taggable()

    assert not taggable.evaluate_tags(['a'], [], {})
    assert not taggable.evaluate_tags([], ['a'], {})
    assert taggable.evaluate_tags([], [], {})

    taggable.tags = ['a']
    assert not taggable.evaluate_tags(['b'], [], {})
    assert taggable.evaluate_tags(['a'], [], {})
    assert not taggable.evaluate_tags(['a'], ['b'], {})
    assert taggable.evaluate_tags(['a'], ['a'], {})
    assert taggable.evaluate_tags([], ['b'], {})
    assert not taggable.evaluate_

# Generated at 2022-06-25 06:06:14.225564
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['all']
    skip_tags = []
    all_vars = {}
    should_run = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True

# Generated at 2022-06-25 06:06:22.852399
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = Taggable()
    tags.tags = ['abc', 'xyz']
    only_tags = ['abc', '123', 'def']
    skip_tags = ['xyz', '123', 'def']
    all_vars = {}
    should_run = tags.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:06:29.183397
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = []
    assert taggable_0.evaluate_tags('', [], {})
    assert taggable_0.evaluate_tags(['all'], [], {})
    assert taggable_0.evaluate_tags(['tagged'], [], {})
    assert not taggable_0.evaluate_tags(['untagged'], [], {})
    assert taggable_0.evaluate_tags('', ['tagged'], {})
    assert not taggable_0.evaluate_tags('', ['untagged'], {})
    taggable_0._tags = ['test-tag']
    assert taggable_0.evaluate_tags(['test-tag'], [], {})
    assert taggable_0.evaluate_tags

# Generated at 2022-06-25 06:06:39.410738
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Creating and initializing an instance of class Taggable
    taggable = Taggable()

    # testing evaluate_tags, with only_tags = ['all'], skip_tags = {'never'}
    only_tags = ['all']
    skip_tags = {'never'}
    assert taggable.evaluate_tags(only_tags, skip_tags,{}) == True

    # testing evaluate_tags, with only_tags = ['all'], skip_tags = {'never'}
    only_tags = ['all']
    skip_tags = {'never'}
    assert taggable.evaluate_tags(only_tags, skip_tags,{}) == True

    # testing evaluate_tags, with only_tags = ['all'], skip_tags = {'never'}
    only_tags = ['all']
    skip

# Generated at 2022-06-25 06:06:46.687488
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    import json
    import pytest
    import sys
    import inspect

    # Get the variables
    filename = inspect.getframeinfo(inspect.currentframe()).filename
    path = os.path.dirname(os.path.abspath(filename))
    file_vars = path + "/../../../lib/ansible/vars/manager.py"

    if not os.path.isfile(file_vars):
        raise Exception('File %s does not exist.' % file_vars)

    with open(file_vars, 'r') as fd_vars:
        content = fd_vars.read()

    var_manager = VariableManager()
    var_

# Generated at 2022-06-25 06:06:47.348436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

# Generated at 2022-06-25 06:06:54.179436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = ["tag_0"]
    skip_tags_0 = ["tag_1", "tag_2", "tag_3", "tag_4"]
    all_vars_0 = {}
    res = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert res == False


# Generated at 2022-06-25 06:07:14.133218
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    print("\n")
    print("Testing evaluate_tags():")
    #tags = ['all']
    #only_tags = ['all']
    #skip_tags = ['all']
    only_tags = ['all']
    print("\n")
    print("1 if only_tags is ['all']:")
    #result = taggable_1.evaluate_tags(tags, only_tags, skip_tags)
    result = taggable_1.evaluate_tags(only_tags, None, None)
    print("Result:")
    print(result)

    print("\n")
    print("2 if only_tags is list:")
    result = taggable_1.evaluate_tags(['all', 'compute1'], None, None)

# Generated at 2022-06-25 06:07:18.485273
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    #  Checks if the task should be executed, for a given set of tag options.
    #  Returns True or False.

    #  Create the list of task tags, if any, from the YAML.
    #  Remove any Jinja2 templating from the task tags, as we
    #  do not want any variables evaluated, just literal strings.
    #  For a task with no tags, set the tags attribute to a list
    #  with the string 'untagged', which will make it easy to
    #  compare against the skip_tags list.
    result_0 = Taggable()
    self.assertEqual(result_0, answer_0)
    assert result_0 == answer_0
    print("Test Passed!")

# Generated at 2022-06-25 06:07:25.526435
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags(): 
    host = Taggable()
    host.tags = ['a', 'b', 'c']

    only_tags = set(['a', 'b', 'c', 'always'])
    skip_tags = set(['d', 'never'])
    assert host.evaluate_tags(only_tags, skip_tags, {})

    only_tags = set(['c', 'd'])
    skip_tags = set(['a', 'b'])
    assert host.evaluate_tags(only_tags, skip_tags, {})

    only_tags = set([])
    skip_tags = set(['never'])
    assert host.evaluate_tags(only_tags, skip_tags, {})

    only_tags = set(['a', 'b', 'c'])
    skip_tags = set([])

# Generated at 2022-06-25 06:07:31.837699
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.only_tags = ['tagged']
    taggable_0.tags = ['tagged']
    taggable_0.evaluate_tags(taggable_0.only_tags, [], {})
    assert True
    # assert taggable_0.evaluate_tags(taggable_0.only_tags, [], {}) == False

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:36.230091
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_1 = 'all'
    skip_tags_1 = ['never', 'all', 'not']
    all_vars_1 = dict()
    result = taggable_0.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert result is True


# Generated at 2022-06-25 06:07:47.006843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test for when only_tags is defined but skip_tags is not.
    # Test class instance
    test_instance = Taggable()
    # Test for when only_tags has value all
    result = test_instance.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={})
    assert result == True
    # Test for when only_tags has value always
    result = test_instance.evaluate_tags(only_tags=['always'], skip_tags=None, all_vars={})
    assert result == True
    # Test for when only_tags has value tagged
    result = test_instance.evaluate_tags(only_tags=['tagged'], skip_tags=None, all_vars={})
    assert result == False

    # Test for when only_tags is not defined but skip_

# Generated at 2022-06-25 06:07:57.603438
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.__setattr__('_tags', [])
    taggable_0.__setattr__('tags', 'always')
    only_tags = taggable_0.__getattr__('_tags')
    skip_tags = taggable_0.__getattr__('_tags')
    all_vars = taggable_0.__getattr__('_tags')
    print('only_tags = ', only_tags)
    print('skip_tags = ', skip_tags)
    print('all_vars = ', all_vars)
#    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == 1

# Generated at 2022-06-25 06:08:06.317184
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    from ansible.playbook.block import Block
    from ansible.playbook import PlayBook
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.encrypt import do_encrypt
    from ansible.template import Templar

    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    taggable0 = Taggable()
    taggable0.tags = ['all', 'never']

    taggable1 = Taggable()
    taggable1.tags = ['all', 'debug']

    taggable2 = Taggable()
    taggable2.tags = ['all', 'debug', 'never']

    taggable3 = Taggable()
    tag

# Generated at 2022-06-25 06:08:11.966508
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("\n")
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    taggable_0 = Taggable()
    assert taggable_0 != None

    # test set 1
    only_tags = ['web', 'db']
    skip_tags = ['db', 'backend']
    all_vars = {}
    assert taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == False

# Generated at 2022-06-25 06:08:20.453730
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case with only_tags 'untagged'
    taggable = Taggable()
    only_tags = ['untagged']
    skip_tags = []
    all_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # Test case with only_tags 'untagged' and 'all'
    taggable = Taggable()
    only_tags = ['untagged', 'all']
    skip_tags = []
    all_vars = {}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # Test case with only_tags 'all'
    taggable = Taggable()
    only_tags = ['all']
    skip_tags = []

# Generated at 2022-06-25 06:08:51.176392
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    excepted_result = True
    taggable = Taggable()
    taggable.tags = ['tag1', 'tag2']
    result = taggable.evaluate_tags(['tag1'], ['tag2'], None)
    assert result == excepted_result



# Generated at 2022-06-25 06:08:57.996236
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Unit test for Taggable method evaluate_tags

    # Setup
    taggable_1 = Taggable()
    taggable_1.tags = []
    taggable_2 = Taggable()
    taggable_2.tags = []
    only_tags_0 = []
    skip_tags_0 = []
    all_vars_0 = {}

    # Invocation
    actual = taggable_1.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

    # Verification
    assert actual == True
    assert actual == taggable_2.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)



# Generated at 2022-06-25 06:09:00.893303
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    if taggable_0.evaluate_tags('', '', ''):
        print('Test Case Passed for evaluate_tags!')
    else:
        print('Test Case Failed for evaluate_tags!')

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:04.743917
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test = Taggable()

    test.tags = ['tags_test']
    only_tags = ['tagged', 'tags_test']
    skip_tags = ['always']
    all_vars = dict()
    assert test.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-25 06:09:07.969329
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(only_tags=["test","test2","test3"], skip_tags=["test"], all_vars={}) == False

# Generated at 2022-06-25 06:09:17.188587
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Unit test for method evaluate_tags of class Taggable
    '''
    taggable_0 = Taggable()
    # FIXME: figure out if we really want to mock self.tags here, there are
    # other tasks that need to be added around that
    taggable_0.tags = ['tag1', 'tag2']

    assert taggable_0.evaluate_tags(['tag1'], [], {})
    assert taggable_0.evaluate_tags([], [], {})
    assert taggable_0.evaluate_tags(['tag2'], [], {})
    assert not taggable_0.evaluate_tags(['tag3'], [], {})
    assert not taggable_0.evaluate_tags(['tag3', 'tag4'], [], {})

# Generated at 2022-06-25 06:09:21.813224
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = ["tag1", "tag2", "tag3"]

    taggable_0.evaluate_tags(['tag1', 'tag2'], [], {})
    taggable_0.evaluate_tags([], ['tag1', 'tag2'], {})
    taggable_0.evaluate_tags([], ['tag1', 'tag2'], {})

# Generated at 2022-06-25 06:09:26.891851
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    only_tags = ['tag1', 'tag2']

    skip_tags = ['tag1', 'tag2']

    all_vars = {"vars": {"key": "value"}}

    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    assert result == True


# Generated at 2022-06-25 06:09:36.289683
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # test case of only_tags option is given but skip_tags option is not given
    taggable_1 = Taggable()
    taggable_1.tags = ["tag1", "tag2"]
    # If a task has one or more tag(s) in the only_tags list, the task should be executed.
    # Case 1: Task's tag is subset of only_tags
    only_tags_1 = ["tag1", "tag2", "tag3"]
    assert taggable_1.evaluate_tags(only_tags_1, None, None) == True
    # Case 2: Task's tag is superset of only_tags
    only_tags_2 = ["tag1"]
    assert taggable_1.evaluate_tags(only_tags_2, None, None) == True
    # Case 3: Task's tag intersect

# Generated at 2022-06-25 06:09:46.347544
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    # method evaluate_tags of class Taggable
    # test cases for only_tags
    taggable.tags = ['all']
    assert taggable.evaluate_tags('all', None, None)

    taggable.tags = ['always']
    assert taggable.evaluate_tags('always', None, None)

    taggable.tags = ['never']
    assert not taggable.evaluate_tags('never', None, None)

    taggable.tags = ['all', 'never']
    assert not taggable.evaluate_tags('never', None, None)

    taggable.tags = ['all', 'always']
    assert taggable.evaluate_tags(['all', 'never'], None, None)

    taggable.tags = []
    assert not taggable

# Generated at 2022-06-25 06:10:51.904104
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    t = taggable._load_tags("first-tag,second-tag, third_tag", ["first-tag", "second-tag", "third_tag"])
    y = taggable.evaluate_tags(t, ["first-tag", "second-tag", "third_tag"], {})
    assert y == True


# main test
if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:00.196471
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()

    taggable.tags = [ 'selftest', 'taggable' ]

    only_tags = set()
    skip_tags = set()

    should_run = taggable.evaluate_tags(only_tags, skip_tags, {})
    assert True == should_run

    only_tags = set()
    skip_tags = set([ 'taggable' ])
    should_run = taggable.evaluate_tags(only_tags, skip_tags, {})
    assert True == should_run

    only_tags = set()
    skip_tags = set([ 'taggable', 'non-existent' ])
    should_run = taggable.evaluate_tags(only_tags, skip_tags, {})
    assert True == should_run

    only_tags = set()


# Generated at 2022-06-25 06:11:11.082936
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Load taggable_0 from yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # Create fake args
    args = type('args', (object,), dict(tags=['this', 'that'],
        skip_tags=['other'], only_tags=None))

    # Create fake play_context
    play_context = PlayContext()
    play_context.verbosity = 0
    play_context.tags = args.tags
    play_context.skip

# Generated at 2022-06-25 06:11:15.007845
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['test_tag']
    assert taggable.evaluate_tags({'test_tag'}, {}, {}) == True
    assert taggable.evaluate_tags({}, {'test_tag'}, {}) == False
    assert taggable.evaluate_tags({'test_tag'}, {'test_tag'}, {}) == False

# Generated at 2022-06-25 06:11:23.373165
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable1 = Taggable()

    only_tags = ['tag1', 'tag2']

    skip_tags = ['tag3', 'tag4']

    all_vars = {'hostvars': {}, 'group_names': {'host1': ['group1', 'group2']},
                'inventory_hostname': 'host1', 'inventory_hostname_short': 'host1', 'groups': {'group1': {},
                                                                                             'group2': {}}}
    taggable1.tags = "tag1,tag2"
    if taggable1.evaluate_tags(only_tags, skip_tags, all_vars) is not True:
        raise AssertionError("taggable1.evaluate_tags(only_tags, skip_tags, all_vars) failed")

    tag

# Generated at 2022-06-25 06:11:29.084859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['always', 'never']
    only_tags = ['always']
    skip_tags = ['never']
    all_vars = {'device': 'R1'}
    taggable.evaluate_tags(only_tags, skip_tags, all_vars)

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:35.674077
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test for empty tags (should run by default)
    taggable_1 = Taggable()
    assert(taggable_1.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True)

    # Test for always (should run by default)
    taggable_2 = Taggable()
    taggable_2.tags = ['always']
    assert(taggable_2.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True)

    # Test for never (shouldn't run by default)
    taggable_3 = Taggable()
    taggable_3.tags = ['never']
    assert(taggable_3.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == False)

# Generated at 2022-06-25 06:11:38.613637
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['all', 'never']
    taggable.evaluate_tags = Taggable.evaluate_tags
    all_vars = {}
    assert taggable.evaluate_tags(['tagged', 'never'], [], all_vars) is False

# Generated at 2022-06-25 06:11:46.197991
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("test_Taggable_evaluate_tags")
    taggable_1 = Taggable()
    assert taggable_1.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False

    taggable_2 = Taggable()
    taggable_2._tags = ['tagged', 'foo']
    assert taggable_2.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == True


# Generated at 2022-06-25 06:11:54.369866
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Add the untagged tag so that isdisjoint can be used for the untagged tag

    taggable_1 = Taggable()
    taggable_1.tags = [None]

    taggable_2 = Taggable()
    taggable_2.tags = ['never']

    taggable_3 = Taggable()
    taggable_3.tags = ['never', 'always']

    taggable_4 = Taggable()
    taggable_4.tags = ['never']

    taggable_5 = Taggable()
    taggable_5.tags = ['never', 'always']

    # Check that the method behaves correctly
    assert taggable_1.evaluate_tags(['always'], [], {'a': 1}) == False
    assert taggable_2.evaluate_

# Generated at 2022-06-25 06:14:42.451745
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Making all_vars dictionary
    all_vars_0 = dict()
    # all_vars_0 = dict(**all_vars_0, **all_vars_0)
    # Making only_tags list
    only_tags_0 = list()
    # Making skip_tags list
    skip_tags_0 = list()
    # Creating instance of Taggable
    taggable_0 = Taggable()
    taggable_0._loader = None
    taggable_0.tags = list()
    # Calling evaluate_tags with parameters taggable_0, only_tags_0, skip_tags_0 and all_vars_0 and storing its return value in variable return_value

# Generated at 2022-06-25 06:14:49.637105
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    module_class = Taggable()
    only_tags = ['tag_1', 'tag_2']
    skip_tags = ['tag_3', 'tag_4']
    all_vars = {'hostvars': 'var'}

    # testing when tags are present
    module_class.tags = ['tag_1', 'tag_3']
    assert module_class.evaluate_tags(only_tags, skip_tags, all_vars) is False

    # testing when tags are present
    module_class.tags = ['tag_1', 'tag_2']
    assert module_class.evaluate_tags(only_tags, skip_tags, all_vars) is True

    # testing when tags are present
    module_class.tags = ['tag_2', 'tag_3']

# Generated at 2022-06-25 06:14:56.146960
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert Taggable().evaluate_tags('only_tags', 'skip_tags', 'all_vars') == True
    assert Taggable().evaluate_tags('only_tags', 'skip_tags', 'all_vars') == True

# Testing taggable:
test_case_0()



# Testing Taggable: evaluate_tags
if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:02.727526
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0._tags = ['tag_01']
    only_tags = ['tag_01', 'tag_02']
    skip_tags = []
    all_vars = {}
    result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result_0

# Generated at 2022-06-25 06:15:04.430413
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print()
    test_case_0()

if __name__ == '__main__':
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:07.606842
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['never']
    skip_tags = ['never']
    all_vars = dict()
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == False


# Generated at 2022-06-25 06:15:13.635056
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class Taggable2(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    taggable_1 = Taggable2(['test1', 'test10'])
    taggable_2 = Taggable2([])
    taggable_3 = Taggable2()

    # first, test with empty set for only_tags
    only_tags = set()
    skip_tags = set()

    if not taggable_1.evaluate_tags(only_tags, skip_tags):
        raise AssertionError('test_case_1 failed')
    elif not taggable_2.evaluate_tags(only_tags, skip_tags):
        raise AssertionError('test_case_2 failed')

# Generated at 2022-06-25 06:15:19.006739
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ["TEST_TAG", "TEST_TAG2"]
    skip_tags = ["TEST_SKIP_TAG", "never"]
    only_tags = ["TEST_ONLY_TAG"]
    all_vars = {"TEST_VARS":"TEST_VALUE"}
    assert taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False

# Generated at 2022-06-25 06:15:25.985354
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    data0 = 'a,b'
    data1 = 'all'
    data2 = True
    data3 = 'a'
    data4 = 'b'
    obj0 = Taggable()
    obj0.tags = data0
    result0 = obj0.evaluate_tags(data1, data2, data3)
    obj1 = Taggable()
    obj1.tags = data4
    result1 = obj1.evaluate_tags(data1, data2, data3)
    obj2 = Taggable()
    result2 = obj2.evaluate_tags(data1, data2, data3)

# Generated at 2022-06-25 06:15:33.887317
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # this is the only case where should_run is True
    assert True, Taggable().evaluate_tags(set(['all', 'tagged']), skip_tags=None, all_vars=None)
    # this is the only case where should_run is False
    assert False, Taggable().evaluate_tags(set(['never']), skip_tags=None, all_vars=None)
    # this is the only case where should_run is True
    assert True, Taggable().evaluate_tags(set(['all', 'tagged']), skip_tags=set(['never']), all_vars=None)
    # this is the only case where should_run is False
    assert False, Taggable().evaluate_tags(set(['never']), skip_tags=set(['never']), all_vars=None)