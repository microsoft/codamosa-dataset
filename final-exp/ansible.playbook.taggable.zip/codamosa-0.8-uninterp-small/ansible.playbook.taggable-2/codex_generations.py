

# Generated at 2022-06-25 06:05:46.329763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = ['always']

    # test case 0
    only_tags = ['always']
    skip_tags = []
    all_vars = {}
    expected = True
    actual = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert actual == expected

# Generated at 2022-06-25 06:05:49.284964
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_obj1 = Taggable()
    only_tags = ['all', 'untagged']
    skip_tags = ['never']
    all_vars = {}
    assert taggable_obj1.evaluate_tags(only_tags, skip_tags, all_vars) == True


# Generated at 2022-06-25 06:05:54.336953
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = [u'test_tag_0']
    only_tags = [u'test_tag_0']
    skip_tags = []
    all_vars = {u'inventory_hostname': u'localhost', u'inventory_hostname_short': u'localhost', u'play_hosts': {u'localhost': {u'hostname': u'localhost'}}, u'omit': u'', u'play_hosts_all': {u'localhost': {u'hostname': u'localhost'}}}
    actual = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert actual == True


# Generated at 2022-06-25 06:06:03.965125
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import random
    taggable_0 = Taggable()
    only_tags_0 = set()
    for i in range(64):
        value = random.randint(0, 128)
        only_tags_0.add(value)

    skip_tags_0 = set()
    for i in range(64):
        value = random.randint(0, 128)
        skip_tags_0.add(value)

    all_vars_0 = dict()
    for i in range(64):
        key = random.randint(0, 128)
        all_vars_0[key] = random.randint(0, 128)


# Generated at 2022-06-25 06:06:12.067253
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    only_tags_1 = None
    skip_tags_1 = None
    all_vars_1 = None
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1) == True

    taggable_2 = Taggable()
    only_tags_2 = None
    skip_tags_2 = None
    all_vars_2 = None
    assert taggable_2.evaluate_tags(only_tags_2, skip_tags_2, all_vars_2) == True

    taggable_3 = Taggable()
    only_tags_3 = None
    skip_tags_3 = None
    all_vars_3 = None
    assert taggable_3.evaluate_tags

# Generated at 2022-06-25 06:06:12.668337
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-25 06:06:20.044616
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['test', 'tag']
    assert taggable_1.evaluate_tags(['test'], ['test'], {}) == False
    assert taggable_1.evaluate_tags(['all'], ['test'], {}) == True
    assert taggable_1.evaluate_tags(['test'], ['all'], {}) == True
    assert taggable_1.evaluate_tags([], ['test'], {}) == True

# Test all supported branches
if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:06:22.558577
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    assert(taggable.evaluate_tags([], [], {}))


# Generated at 2022-06-25 06:06:24.636871
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert test_case_0() is None

# Generated at 2022-06-25 06:06:31.961895
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ["untagged"]
    only_tags = ["always"]
    skip_tags = ["all"]
    all_vars = dict()
    result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True
    #FIXME - add more tests


# Generated at 2022-06-25 06:06:47.062846
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}
    taggable_1 = Taggable

# Generated at 2022-06-25 06:06:57.558187
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:07:07.597396
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = ["", "\x8e\x03\xf0\x15\xe3", "\x8e\x03\xf0\x15\xe3"]
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None

# Generated at 2022-06-25 06:07:13.944368
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_3 = Taggable()
    set_1 = set()
    int_0 = 0
    bool_0 = False
    taggable_3.evaluate_tags(int_0, set_1, bool_0)
    taggable_4 = Taggable()
    list_2 = [0, 0, 0, 0, 0, 0]
    taggable_4.evaluate_tags(list_2, bool_0, bool_0)
    taggable_5 = Taggable()
    str_1 = ":?>"
    bytes_2 = b'\xde\xafh\x8a\xe0\x9e\x98\x85)\xac\x08\xebQ\x80'
    int_1 = 0

# Generated at 2022-06-25 06:07:24.031502
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:07:34.309869
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:07:45.183595
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_3 = Taggable()
    set_1 = frozenset(['T1E', '9Tpt<Q.h=.B\x06\x92\x18\xcd\x1e\x98', '\x1d\x06<\x053\x89\xaa\xbc\xc1\x86'])
    str_1 = 'j\x15\x82\x8ea\xbe\x15\x05H\x90\x8f\x9c'
    bytes_2 = b'\x8b6U\xa6\x00\xb2\xd4\xa4\x81\xd30/Y\x80'
    var_1 = taggable_3.evaluate_tags(set_1, str_1, bytes_2)
    set

# Generated at 2022-06-25 06:07:56.428847
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:07:58.250748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Constructor test case
    test_case_0()


# Generated from test_taggable.py by PyTest


# Generated at 2022-06-25 06:08:01.698893
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    only_tags = [""]
    skip_tags = [""]
    all_vars = [""]
    var = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:08:16.074857
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert test_case_0() == None


# Generated at 2022-06-25 06:08:24.560100
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = "5Nv1\x1f`\xa2Q@\x15\xf9\x9a\xa6\xa8\xd1\x04\x1a\x1b\xa4\x7f"
    bytes_0 = b'\xc8\x7f\x06\xbd\x1eR\xfa\xb9\x9b=\x05\x80\xf3\x91\xaf\xce\x8d\xaa\xa9\x9b\x14'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)

# Generated at 2022-06-25 06:08:26.530074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable._tags = ['A', 'B']
    assert(taggable.evaluate_tags(['A'], None, None))
    assert(not taggable.evaluate_tags(['C'], None, None))
    assert(not taggable.evaluate_tags(['C'], ['A'], None))

# Generated at 2022-06-25 06:08:33.324959
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

    # Test with string type variable
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    assert var_0 == True
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]

# Generated at 2022-06-25 06:08:41.124437
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    list_1 = Taggable.__mro__[1].__init__.__defaults__
    dict_0 = {}

# Generated at 2022-06-25 06:08:42.492905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Run test case 0
    test_case_0()

# Generated at 2022-06-25 06:08:52.205822
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:09:02.784184
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:09:13.307390
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:09:23.918705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [taggable_0, taggable_0, taggable_0]
    str_0 = 'CEG'
    tuple_0 = (str_0, str_0)
    dict_0 = {str_0: list_0, str_0: tuple_0}
    list_1 = list_0
    dict_1 = {str_0: taggable_0, str_0: list_1}
    taggable_0 = Taggable(*list_0, **dict_1)
    set_0 = set()
    list_2 = []

# Generated at 2022-06-25 06:09:52.709785
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    obj = TestClass()
    result = obj.test_evaluate_tags()



# Generated at 2022-06-25 06:09:53.777871
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:10:01.165358
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    assert type(taggable_0.evaluate_tags(list_0, str_0, bytes_0)) is bool, 'AssertionError: wrong type: {}'.format(type(taggable_0.evaluate_tags(list_0, str_0, bytes_0)))

    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list

# Generated at 2022-06-25 06:10:09.477352
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}

# Generated at 2022-06-25 06:10:18.345416
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    assert(var_0 == True)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}
    taggable

# Generated at 2022-06-25 06:10:19.699878
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    f_var_0 = [tuple()]


# Generated at 2022-06-25 06:10:22.258682
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert taggable_0.evaluate_tags() == var_0
    assert taggable_1.evaluate_tags() == var_1

# Generated at 2022-06-25 06:10:23.080886
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:10:31.762767
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    
    # Calls the method under test
    taggable_1 = Taggable()
    set_1 = set()
    list_2 = []
    str_1 = ";F?'\x0cap.EEpJlss^[D"
    bytes_2 = b'\xcb\xa0\xf1\xdc\xcb\xb5\x9f6\x07\xd7}\xcc\xfb\x1b\x0e\xad'
    var_2 = taggable_1.evaluate_tags(list_2, str_1, bytes_2)
    bytes_3 = b'\x9b\x8f\xed'
    tuple_1 = None
    list_3 = [tuple_1, tuple_1, tuple_1]
    dict_1 = {}
   

# Generated at 2022-06-25 06:10:32.568377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert False


# Generated at 2022-06-25 06:11:33.714198
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:11:34.493998
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    test_case_0()

# Generated at 2022-06-25 06:11:36.852367
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:11:40.999053
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    try:
        assert (test_case_0()) == None
        print("Passed all test cases")
    except AssertionError as e:
        print("Test case 0 failed")

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:51.586148
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    int_0 = 0
    float_0 = 0.0
    str_0 = "p \xa8\xb3\x01\xa3\x16\x9c"
    str_1 = "^5"
    tuple_0 = (int_0, float_0, str_0, str_1, int_0)
    str_2 = "p \xa8\xb3\x01\xa3\x16\x9c"
    str_3 = "^5"
    tuple_1 = (int_0, float_0, str_2, str_3, int_0)
    list_0 = [tuple_0, tuple_1]

# Generated at 2022-06-25 06:11:59.300945
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ''
    bytes_0 = b'\x17\xc7,\x14\xd7x\x9c\xeb\x93\x0f\x17\xb2\x1a\xe3\x04\xe1\xf0\xfe\x0f\xbb\xcb\x8c\x08\xe1\x1e\xb5\x9a\x87p\x1c\x05\xd6\xbe\x87'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    assert isinstance(var_0, bool)
    assert var_0 == True

# Unit test

# Generated at 2022-06-25 06:12:10.948952
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    byte_0 = b'\xc8\xa2\xc9\x08\x03\x13T\xbd\xdc\xf1\xfa\x18\xdbC\x9f\xdf\xc2\x8c\x1d\xa1\x1b\x90'

# Generated at 2022-06-25 06:12:21.556084
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]

# Generated at 2022-06-25 06:12:22.844891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert test_case_0()


# Generated at 2022-06-25 06:12:26.930653
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    list_0 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    var_0 = taggable_0.evaluate_tags(list_0, list_0, list_0)
    assert var_0 == False, f"expected False, got {var_0}"


# Generated at 2022-06-25 06:15:18.040831
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:15:19.240905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:15:25.604552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_3 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_3.evaluate_tags(list_0, str_0, bytes_0)
    pass

# Generated at 2022-06-25 06:15:27.893584
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()


# Generated at 2022-06-25 06:15:34.226301
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    set_0 = set()
    list_0 = []
    str_0 = ";F?'\x0cap.EEpJlsSA-S?"
    bytes_0 = b'\xc9\xb5\x07\xff\xa1\x8f\xe2\xf2~\n\xee\xe7L\xa3#'
    var_0 = taggable_0.evaluate_tags(list_0, str_0, bytes_0)
    bytes_1 = b'\xddLCz8\x03\xe9Q\xf7f'
    tuple_0 = None
    list_1 = [tuple_0, tuple_0, tuple_0]
    dict_0 = {}