

# Generated at 2022-06-25 06:05:50.384967
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    y = taggable_0.evaluate_tags(['all'], ['never'], ['ansible_connection', 'network_cli'])
    assert y == True
    y = taggable_0.evaluate_tags(['all'], ['always'], ['ansible_connection', 'network_cli'])
    assert y == True
    y = taggable_0.evaluate_tags(['always'], ['always'], ['ansible_connection', 'network_cli'])
    assert y == False
    y = taggable_0.evaluate_tags([1], [], ['ansible_connection', 'network_cli'])
    assert y == True
    y = taggable_0.evaluate_tags([], ['never'], ['ansible_connection', 'network_cli'])


# Generated at 2022-06-25 06:05:59.527025
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Case 0: Taggable is called with only_tags = ['test_0'], skip_tags = ['test_1'], all_vars = {}, tags = ['test_0']
    taggable_0 = Taggable()
    taggable_0.tags = ['test_0']
    assert Taggable.evaluate_tags(taggable_0, ['test_0'], ['test_1'], {}) == True
    # Case 1: Taggable is called with only_tags = ['test_1'], skip_tags = ['test_0'], all_vars = {}, tags = ['test_0']
    taggable_0.tags = ['test_0']
    assert Taggable.evaluate_tags(taggable_0, ['test_1'], ['test_0'], {}) == False

# Generated at 2022-06-25 06:06:09.359890
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1 - Object without tags
    taggable_0 = Taggable()
    test_0_tags = taggable_0.evaluate_tags(['red', 'blue'], ['green', 'always'], {})
    assert(test_0_tags == True)

    # Test case 2 - Object with tags
    taggable_1 = Taggable()
    taggable_1.tags = ['red', 'blue', 'green', 'always']
    test_1_tags = taggable_1.evaluate_tags(['red', 'blue'], ['green', 'always'], {})
    assert(test_1_tags == True)

    # Test case 3 - Object with tags and skip tags
    taggable_2 = Taggable()

# Generated at 2022-06-25 06:06:18.678856
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Set up the class to be tested
    taggable_0 = Taggable()

    # Test evaluate_tags with only_tags = ['tagged', 'all', 'always'] ,
    # skip_tags = ['all', 'tagged', 'linux'] and all_vars = {'ansible_lsb': {'codename': 'naily', 'id': 'Debian', 'major_release': '9', 'description': 'Debian GNU/Linux 9.4 (stretch)', 'release': '9.4'}}
    # Cases: 1
    # Tags: ['linux']
    # eval_tage_result: False

    # Case 1
    only_tags_1 = ['tagged', 'all', 'always']
    skip_tags_1 = ['all', 'tagged', 'linux']
    all_vars_1

# Generated at 2022-06-25 06:06:24.071447
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = frozenset({})
    skip_tags_0 = frozenset({})
    all_vars_0 = {}
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0), "test_Taggable_evaluate_tags test 0 failed"


# Generated at 2022-06-25 06:06:31.319005
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    #test_case_1
    taggable_1 = Taggable()
    taggable_1.tags = ['test1','test2','test3']
    only_tags_1 = ['test2']
    skip_tags_1 = ['test1']
    all_vars_1 = {'ansible_ssh_host': 'localhost', 'inventory_hostname': 'localhost', 'group_names': ['all']}
    assert taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1) == True
    #test_case_2
    taggable_2 = Taggable()
    taggable_2.tags = ['test1','test2','test3']
    only_tags_2 = ['test']
    skip_tags_2 = ['test']


# Generated at 2022-06-25 06:06:40.410069
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Should run 3 tasks, as follows:
    1. mary - always run
    2. joe - if only_tags 'team'
    3. dave - if not skip_tags 'team'
    '''

    # tests run without skip tags
    taggable_1 = Taggable()
    taggable_1.tags = ['team']

    # tests run without skip tags
    taggable_2 = Taggable()
    taggable_2.tags = ['always']

    # tests run with skip tags
    taggable_3 = Taggable()
    taggable_3.tags = ['team']

    assert taggable_1.evaluate_tags(None, None, None)
    assert taggable_2.evaluate_tags(None, None, None)
    assert taggable_

# Generated at 2022-06-25 06:06:47.386801
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableEnvironment:
        _tagged = ['tagged']
        _skip_tagged = ['skip_tagged']

        _untagged = ['untagged']
        _skip_untagged = ['skip_untagged']

        _all_tags = ['all']
        _skip_all = ['skip_all']

        _always = ['always']
        _skip_always = ['skip_always']

        _never = ['never']

    class TaggableTuple:
        """Tuple returned by Taggable.evaluate_tags method.
        """
        def __init__(self, tagged, untagged, all_tags, always):
            self.tagged = tagged
            self.untagged = untagged
            self.all_tags = all_tags
            self.always = always


# Generated at 2022-06-25 06:06:57.582399
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup input data
    taggable_0 = Taggable()
    taggable_0.tags = (['', ['', '', '', '', '', ''], [], {}, ['', '', '', '', '', ''], ''])
    only_tags_1 = None
    skip_tags_1 = ['', ['', '', '', '', '', ''], [], {}, ['', '', '', '', '', ''], '']
    all_vars_1 = {'', [], [], {}, ['', '', '', '', '', ''], ''}
    # Call the method being tested with the input arguments
    result = taggable_0.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    # Check the result
    assert True
    #

# Generated at 2022-06-25 06:07:06.296866
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['tag1','tag2','tag3','tag4']
    all_vars = {}
    only_tags = ['tag1','tag2']
    skip_tags = ['tag3','tag4']
    if taggable_1.evaluate_tags(only_tags, skip_tags, all_vars):
        print('This should be evaluated')
    else:
        print('Error in evaluating tags')

if __name__ == '__main__':
    test_Taggable_evaluate_tags()
    test_case_0()

# Generated at 2022-06-25 06:07:22.377876
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # print("Running test case 0") 
    test_Taggable_evaluate_tags_0()
    print("Finished testing method evaluate_tags")
    return {'ans': True}


# Generated at 2022-06-25 06:07:34.145090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()

# Generated at 2022-06-25 06:07:40.965889
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags_0 = "always"
    skip_tags_0 = "never"
    all_vars_0 = "foo"
    result_0 = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)
    assert result_0 == True



# Generated at 2022-06-25 06:07:43.073391
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    import doctest
    doctest.testmod(verbose=True)


test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:47.315501
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    try:
        taggable_1 = Taggable()
        taggable_1.tags = ['hello']
        taggable_1.evaluate_tags(['all'], [], {})
    except Exception as err:
        assert(False), "unable to call evaluate_tags: " + str(err)
        pytest.fail("unable to call evaluate_tags: " + str(err))

# Generated at 2022-06-25 06:07:58.566396
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    print("\n*** Test 1  Test Taggable.evaluate_tags() ***")
    # Define a fake task object
    class fake_Taggable(Taggable):
        _tags = ['always']

    # Create object and test if it's taggable
    taggable = fake_Taggable()
    only_tags = ['tagged', 'all']
    skip_tags = ['never']
    all_vars = {}
    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

    # Test with fake_taggable with no tags but with only_tags and skip_tags
    print("\n*** Test 2  Test Taggable.evaluate_tags() ***")

# Generated at 2022-06-25 06:08:00.523412
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    tags = taggable_1.evaluate_tags(['tag1'], [], dict())
    assert tags == False


# Generated at 2022-06-25 06:08:04.321236
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # declare some test data
    taggable_0 = Taggable()
    taggable_0.tags = ["server", "db"]
    taggable_0.only_tags = set(["all"])
    taggable_0.skip_tags = set(["never"])
    taggable_0.all_vars = {}
    taggable_0.evaluateTags()


# Generated at 2022-06-25 06:08:14.239486
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['tag1', 'tag2', 'tag3']
    only_tags_1 = ['tag1', 'tag2', 'tag3']
    only_tags_1 = set(only_tags_1)
    skip_tags_1 = ['tag2']
    skip_tags_1 = set(skip_tags_1)
    all_vars_1 = {}
    expected_1 = True
    actual_1 = taggable_1.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1)
    assert actual_1 == expected_1
    taggable_2 = Taggable()
    taggable_2.tags = ['tag2', 'tag3', 'tag4']
    only_tags_

# Generated at 2022-06-25 06:08:17.894980
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a Taggable object
    taggable = Taggable()

    # add a tags attribute to taggable object
    taggable.tags = ['foo']

    # Note: test fails if the value for only_tags is changed to 'all'
    assert taggable.evaluate_tags(only_tags=['foo'], skip_tags=['never'], all_vars={})


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 06:08:53.876170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments
    # Test call to 'Taggable.evaluate_tags' with given arguments

# Generated at 2022-06-25 06:08:56.986802
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    # Taggable.evaluate_tags() execution
    task_0 = Task()
    assert task_0.evaluate_tags(None, None, None) == True

# Generated at 2022-06-25 06:09:06.267940
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test for evaluate_tags method when no tags are defined
    taggable_0 = Taggable()
    assert(taggable_0.evaluate_tags([], [], {}) == True)
    assert(taggable_0.evaluate_tags(['all'], [], {}) == True)
    assert(taggable_0.evaluate_tags(['foo'], [], {}) == False)
    assert(taggable_0.evaluate_tags([], ['all'], {}) == False)
    assert(taggable_0.evaluate_tags([], ['foo'], {}) == True)

    # Test for evaluate_tags method when tags are defined
    taggable_1 = Taggable()
    taggable_1._tags = ['foo']

# Generated at 2022-06-25 06:09:13.710649
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    t = Taggable()
    t.tags = ["test1", "test2"]

    # call the method
    only_tags = ["test1"]
    skip_tags = []
    all_vars = []
    result = t.evaluate_tags(only_tags, skip_tags, all_vars)

    print(result)


if __name__ == '__main__':

    # test_case_0()

    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:09:22.565977
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    loader = make_loader('config/playbooks/common/test/vars')
    all_vars = loader.load_from_file("../../../../../../../../tests/integration/targets/default/group_vars/all", "yaml")
    taggable_0 = Taggable()
    taggable_0.tags = ['foo', 'bar']
    only_tags = ['foo', 'bar']
    skip_tags = []
    should_run = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run is True

# Generated at 2022-06-25 06:09:31.987438
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # the only_tags is []
    taggable_0 = Taggable()
    taggable_0.tags = []
    res_0 = taggable_0.evaluate_tags([], [], {})
    assert res_0 == True
    # the only_tags is ['all']
    taggable_1 = Taggable()
    taggable_1.tags = []
    res_1 = taggable_1.evaluate_tags(['all'], [], {})
    assert res_1 == True
    # the only_tags is ['ansible','config']
    taggable_2 = Taggable()
    taggable_2.tags = []
    res_2 = taggable_2.evaluate_tags(['ansible','config'], [], {})
    assert res_2 == False


# Generated at 2022-06-25 06:09:39.424796
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create a Taggable object for testing
    taggable_0 = Taggable
    
    #===========================================================================
    # Create a list of temporary variables used in test cases
    #===========================================================================
    all_vars = [
        None
    ]

    only_tags = [
        ['all', 'never', 'always'],
        ['all', 'never', 'always', 'tagged'],
        ['never', 'always'],
        ['always'],
        ['tagged'],
        [],
        ['all'],
        ['all', 'never'],
        ['all', 'never', 'tagged'],
        ['all', 'tagged']
    ]


# Generated at 2022-06-25 06:09:41.833619
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_0 = Taggable()
    taggable_0.tags = ['always']
    # Evaluate only_tags
    assert taggable_0.evaluate_tags (only_tags = ['always'], skip_tags = None, all_vars = None) == True

    # Evaluate skip_tags
    assert taggable_0.evaluate_tags (only_tags = None, skip_tags = ['never'], all_vars = None) == True

# Generated at 2022-06-25 06:09:51.121454
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    tags_0 = ["foo", "bar", "baz"]
    only_tags_0 = ["foo", "baz"]
    skip_tags_0 = []
    all_vars = {}
    retval = taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars)
    assert retval is True
    taggable_0._tags = tags_0

    only_tags_1 = [
        "foo",
        "bar",
        "baz"
    ]
    retval = taggable_0.evaluate_tags(only_tags_1, skip_tags_0, all_vars)
    assert retval is False
    taggable_0._tags = tags_0

# Generated at 2022-06-25 06:09:57.137755
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    taggable.tags = ['test_tag_1']

    only_tags = set(['test_tag_2']);
    skip_tags = set(['test_tag_3']);
    all_vars = dict();
    should_run = taggable.evaluate_tags(only_tags, skip_tags, all_vars)
    assert should_run == True


# Generated at 2022-06-25 06:10:36.647063
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable = Taggable()
    # testing with a single task
    taggable.tags = ['foo']
    only_tags = ['foo']
    skip_tags = ['false']

    test_case_1 = taggable.evaluate_tags(only_tags, skip_tags, dict())
    print ("test_case_1 result: " + str(test_case_1))
    # testing with a task with multiple tags
    taggable.tags = ['foo', 'test']
    only_tags = ['foo', 'test']
    skip_tags = ['false']

    test_case_2 = taggable.evaluate_tags(only_tags, skip_tags, dict())
    print ("test_case_2 result: " + str(test_case_2))
    # testing with a task with one matching and one nonmatch

# Generated at 2022-06-25 06:10:42.395391
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    assert taggable_1.evaluate_tags(None, None, None)

# No Unit test for method _load_tags of class Taggable


# Generated at 2022-06-25 06:10:51.406888
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    only_tags = ['untagged']
    skip_tags = []
    all_vars = ''

    # Run method evaluate_tags
    result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result is False

    # Create a new instance of class Taggable
    taggable_2 = Taggable()

    # Run method evaluate_tags
    result = taggable_2.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result is False

    # Create a new instance of class Taggable
    taggable_3 = Taggable()

    # Run method evaluate_tags

# Generated at 2022-06-25 06:10:57.796385
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    only_tags_2 = ['all']
    skip_tags_3 = ['all']
    all_vars_4 = {}
    result_5 = taggable_1.evaluate_tags(only_tags_2, skip_tags_3, all_vars_4)
    assert result_5 is True


if __name__ == "__main__":
    import __main__
    print(__main__.__file__)

    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:05.775988
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    # Test case with only_tags param - positive
    assert taggable_1.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={'foo':'bar'}) == True
    # Test case with only_tags param - negative
    assert taggable_1.evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={'foo':'foo'}) == False
    # Test case with skip_tags param - positive
    assert taggable_1.evaluate_tags(only_tags=[], skip_tags=['foo', 'bar'], all_vars={'foo':'foo'}) == True
    # Test case with skip_tags param - negative
    assert taggable_1.evaluate_

# Generated at 2022-06-25 06:11:15.362356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    """
    Test case to ensure that evaluate_tags function works correctly
    """
    skip_tags = ['tag2']
    only_tags = ['tag1']

    taggable_1 = Taggable()
    taggable_1.tags = ['tag1']
    taggable_2 = Taggable()
    taggable_2.tags = ['tag2']
    taggable_3 = Taggable()
    taggable_3.tags = ['tag1', 'tag2']
    taggable_4 = Taggable()
    taggable_4.tags = []
    taggable_5 = Taggable()
    taggable_5.tags = ['tag2', 'tag3']

    # Now lets test and see what happens

# Generated at 2022-06-25 06:11:17.957044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert taggable_0.evaluate_tags('only_tags', 'skip_tags', 'all_vars') == True



# Generated at 2022-06-25 06:11:21.645330
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # Calling evaluate_tags method
    print(taggable_0.evaluate_tags(1,1,[]))

if __name__ == "__main__":
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:11:28.141513
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_0.tags = None
    only_tags_0 = ['tag1', 'tag2', 'tag3']
    skip_tags_0 = ['tag1', 'tag2', 'tag3']
    all_vars_0 = None
    assert taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0) == False, "Evaluate tags with no tags"

# Generated at 2022-06-25 06:11:33.579822
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = ['tagged', 'modified']
    skip_tags = ['tagged', 'modified']
    all_vars = dict()
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:12:35.083503
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
  assert True

# Generated at 2022-06-25 06:12:44.796666
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    # test raise error
    with pytest.raises(AnsibleError):
        taggable_0._load_tags(attr="tags", ds="1")
        taggable_0.evaluate_tags(only_tags=['1'], skip_tags=['1'], all_vars={})
    # test skip_tags
    assert taggable_0.evaluate_tags(only_tags=['1', '2'], skip_tags=['2'], all_vars={}) == False
    # test only_tags
    assert taggable_0.evaluate_tags(only_tags=['1', '2'], skip_tags=['3'], all_vars={}) == True
    # test all tags

# Generated at 2022-06-25 06:12:48.700905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = []
    skip_tags = []
    all_vars = []
    result = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert result == True

# Generated at 2022-06-25 06:12:49.520182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# Generated at 2022-06-25 06:12:54.580590
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['all', 'tagged']
    skip_tags = ['some']
    all_vars = {'hostvars': { 'test_host': {'test_var': 123} } }
    test_case_0()
    test_case_0().evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:13:00.637072
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Tag evaluation test 0: all tags are disjoint from the only-tags list,
    so should_run should be False
    '''
    taggable = Taggable()
    all_vars = {}
    only_tags = ["only_tag"]
    skip_tags = []
    taggable.tags = ["tag"]
    # if only_tags is disjoint from tags, should_run should be False
    assert not taggable.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:13:04.676519
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['server']
    test = taggable_1.evaluate_tags(['server'], [], {})
    assert test == True

# Generated at 2022-06-25 06:13:13.848500
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    taggable_1 = Taggable()
    taggable_1.tags = ['test']
    taggable_2 = Taggable()
    taggable_2.tags = ['always']
    taggable_3 = Taggable()
    taggable_3.tags = ['never']
    taggable_4 = Taggable()
    taggable_4.tags = ['never', 'test']
    taggable_5 = Taggable()
    taggable_5.tags = ['never', ' always ']
    taggable_6 = Taggable()
    taggable_6.tags = ['never', 'always', 'test']
    taggable_7 = Taggable()

# Generated at 2022-06-25 06:13:20.930702
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import collections

    taggable_1 = Taggable()

    # Input parameters
    taggable_1.tags = ['not_tagged']
    only_tags = ['tagged']
    skip_tags = ['not_tagged']
    all_vars = {'a': 'b'}

    # Expected result
    expected_result = False

    # Actual result
    actual_result = taggable_1.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test assertions
    assert isinstance(actual_result, bool)
    print('\n')
    print(collections.Counter(actual_result))


# Generated at 2022-06-25 06:13:24.300890
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable.tags = ['test', 'run', 'now']
    only_tags = set(['test', 'run'])
    skip_tags = set()
    all_vars = {}

    result = taggable.evaluate_tags(only_tags, skip_tags, all_vars)

    assert True == result


# Generated at 2022-06-25 06:15:07.943473
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    float_0 = 60.0
    list_0 = []
    bytes_0 = None
    var_0 = taggable_0.evaluate_tags(float_0, list_0, bytes_0)

    assert var_0 == True


# Generated at 2022-06-25 06:15:11.047715
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = 60.0
    list_0 = []
    bytes_0 = None
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(float_0, list_0, bytes_0)
    assert var_0 == True


# Generated at 2022-06-25 06:15:16.108044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = 60.0
    list_0 = []
    bytes_0 = None
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(float_0, list_0, bytes_0)
    assert var_0 == False


# Generated at 2022-06-25 06:15:19.628617
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = None
    list_0 = []
    taggable_0 = Taggable()
    ret_val_0 = taggable_0.evaluate_tags(float_0, list_0)
    assert ret_val_0 is False


# Generated at 2022-06-25 06:15:24.216032
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = 60.0
    list_0 = []
    bytes_0 = None
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(float_0, list_0, bytes_0)
    assert var_0 is True

# Generated at 2022-06-25 06:15:29.583405
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Not enough parameters: self
    taggable_0 = Taggable()
    float_0 = 60.0
    list_0 = []
    bytes_0 = None
    var_0 = taggable_0.evaluate_tags(float_0, list_0, bytes_0)
    return

test_case_0()

# Generated at 2022-06-25 06:15:36.543891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    float_0 = 60.0
    list_0 = []
    bytes_0 = None
    dict_0 = {}
    taggable_0 = Taggable(**dict_0)
    var_0 = taggable_0.evaluate_tags(float_0, list_0, bytes_0)

