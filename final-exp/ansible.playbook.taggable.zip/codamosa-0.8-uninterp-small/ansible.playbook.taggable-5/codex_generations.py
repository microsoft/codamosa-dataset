

# Generated at 2022-06-25 06:05:44.550261
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable(*list_0)
    assert taggable_0.evaluate_tags(None, None, None)


# Generated at 2022-06-25 06:05:49.696793
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    only_tags = ['a']
    skip_tags = ['b']
    all_vars = dict()
    list_0 = []
    taggable_0 = Taggable(*list_0)
    method_result_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

# Generated at 2022-06-25 06:05:54.678654
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Create object instance of class Taggable
    taggable_0 = Taggable()

    # Test method evaluate_tags of class Taggable
    only_tags = 'foo'
    skip_tags = 'bar'
    all_vars = 'ansible_facts'
    taggable_0.tags = 'foo'
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)


# Generated at 2022-06-25 06:06:00.351972
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable(*list_0)
    only_tags_0 = set()
    skip_tags_0 = set()
    all_vars_0 = dict()
    taggable_0.evaluate_tags(only_tags_0, skip_tags_0, all_vars_0)

test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:06:03.451518
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable(*list_0)
    assert taggable_0.evaluate_tags( only_tags = '', skip_tags = '', all_vars = '')



# Generated at 2022-06-25 06:06:07.582058
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create instances and mock input parameters
    list_0 = []
    taggable_0 = Taggable(*list_0)

    # Assert things
    assert(taggable_0.evaluate_tags(only_tags, skip_tags, all_vars) == True)

# Generated at 2022-06-25 06:06:10.902552
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True == True


# Generated at 2022-06-25 06:06:18.127280
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable(*list_0)
    only_tags = None
    skip_tags = None
    all_vars = None
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

    list_0 = []
    taggable_0 = Taggable(*list_0)
    only_tags = []
    skip_tags = []
    all_vars = []
    taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)

# unit tests
test_case_0()
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:06:27.194490
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable(*list_0)
    only_tags_0 = dict()
    skip_tags_0 = dict()
    all_vars_0 = dict()
    # Case: if self.tags:
    taggable_0.tags = list()
    taggable_0.tags = ['tag', 'tag', 'tag', 'tag']
    taggable_0.tags = ['tag', 'tag', 'tag', 'tag']
    taggable_0.tags = ['tag', 'tag', 'tag', 'tag']
    taggable_0.tags = ['tag', 'tag', 'tag', 'tag']
    taggable_0.tags = ['tag', 'tag', 'tag', 'tag']

# Generated at 2022-06-25 06:06:35.128832
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = []
    taggable_0 = Taggable(*list_0)
    
    # Test cases may use the following variables.
    only_tags_1 = 'only_tags_1'
    skip_tags_1 = 'skip_tags_1'
    all_vars_1 = 'all_vars_1'
    
    # Call method with arguments. The result should be "True".
    assert taggable_0.evaluate_tags(only_tags_1, skip_tags_1, all_vars_1) == True


# Generated at 2022-06-25 06:06:49.491868
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

test_case_0()

# Generated at 2022-06-25 06:06:50.104164
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True # implement your test here


# Generated at 2022-06-25 06:06:50.490998
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True

# Generated at 2022-06-25 06:06:54.312889
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert var_0 == True

test_case_0()

# Generated at 2022-06-25 06:06:57.305450
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)



# Generated at 2022-06-25 06:07:05.557622
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert var_0 == True

# Tests for function _load_tags

# Generated at 2022-06-25 06:07:13.484913
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    var_1 = taggable_0._tags()
    var_2 = Taggable(tags=var_1)
    var_3 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    var_4 = taggable_0._tags()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:07:20.245170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:07:24.292782
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:07:34.347607
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert taggable_0._tags == list
    #---------------------------------------------------------------
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    list_0 = [tuple_0, (2, 1), (0, 1)]
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
   

# Generated at 2022-06-25 06:07:58.915076
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    taggable_0 = Taggable()
    tuple_1 = (tuple_0,)
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    var_1 = taggable_0.evaluate_tags(tuple_0, tuple_1, bytes_0)
    var_2 = taggable_0.evaluate_tags(tuple_0, tuple_1, bytes_0)
    var_3 = taggable_0.evaluate_tags(tuple_0, tuple_1, bytes_0)


# Generated at 2022-06-25 06:08:03.292901
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:08:09.176476
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:08:14.412899
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:08:23.650105
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    tuple_1 = ()
    dict_1 = {tuple_0: tuple_0, tuple_1: tuple_1}
    bytes_1 = b'\x83\x1e\xbf\x0c\x8a\xbe\xa0'
    #taggeable_1 = Taggable()

# Generated at 2022-06-25 06:08:30.970767
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

    # assert that evaluation of above test case is True
    assert var_0 is True

test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:36.597398
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

if __name__ == '__main__':
   test_case_0()

# Generated at 2022-06-25 06:08:41.887667
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:08:47.773904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:08:49.079984
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

# end class Taggable



# Generated at 2022-06-25 06:09:21.291434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert type(var_0) == bool


# Generated at 2022-06-25 06:09:26.468458
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:09:35.987329
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar
    try:
        import yaml
    except ImportError:
        raise SkipTest('Skipping as unable to import yaml')
    hasattr(AnsibleModule, 'from_json')

    with open(os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_test_case_0.py')) as testfile:
        testcase = testfile.read()
    module = AnsibleModule(
        argument_spec=dict(
            param1=dict(required=True, type='list'),
            param2=dict(required=True, type='dict'),
            param3=dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-25 06:09:44.148129
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:09:52.994448
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    #assert var_0 == True
    #assert var_0 == False
    #assert var_0 == True
    #assert var_0 == False
    #assert var_0 == False
    #assert var_0 == True
    #assert var_0 == True
    #assert var_0 == True
    #assert var_0 == True
    #assert var_0 == False
    #assert var_0 == True


# Generated at 2022-06-25 06:09:59.674683
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    variable_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    print(variable_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:10:03.547562
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Wrong input
    try:
        taggable_0 = Taggable()
        taggable_0.evaluate_tags()
    except:
        pass

    # Correct input
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:10:06.318115
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_cases = [0]
    for case in test_cases:
        globals()['test_case_{0}'.format(case)]()


# Generated at 2022-06-25 06:10:07.178705
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    assert True == True


# Generated at 2022-06-25 06:10:14.492396
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)



# Generated at 2022-06-25 06:11:24.336954
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:11:26.281371
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

if __name__ == "__main__":
    test_Taggable()

# Generated at 2022-06-25 06:11:30.833283
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tags = Taggable()

    tags.tags = ('tag1', 'tag3')
    assert True == tags.evaluate_tags(('tag1', 'tag2'), (), {}), '{0}'.format(tags.evaluate_tags(('tag1', 'tag2'), (), {}))
    assert True == tags.evaluate_tags(('tag1', 'tag2'), (), None), '{0}'.format(tags.evaluate_tags(('tag1', 'tag2'), (), None))



# Generated at 2022-06-25 06:11:34.700646
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:11:37.342294
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:11:48.625429
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('> Executing test for method evaluate_tags of class Taggable')

    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert var_0 == False

    tuple_0 = ()
    dict_0 = {}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()

# Generated at 2022-06-25 06:11:55.731657
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)



# Generated at 2022-06-25 06:12:01.112422
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Creating a skeleton Taggable object
    obj = Taggable()

    # TODO: Assign appropriate values to the parameters of method evaluate_tags of class Taggable
    # For more details refer to the documentation of method evaluate_tags of class Taggable
    # Expected output: <return value of method evaluate_tags of class Taggable>

# Generated at 2022-06-25 06:12:07.649543
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert var_0 == 1


# Generated at 2022-06-25 06:12:14.172518
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert var_0 == True


# Generated at 2022-06-25 06:15:09.495578
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
    assert var_0 == True


# Generated at 2022-06-25 06:15:12.099504
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


# Generated at 2022-06-25 06:15:17.720006
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)

# Generated at 2022-06-25 06:15:24.604989
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\xb2\xff\xa1\x1f\xb9B\xfe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)


if __name__ == "__main__":
    test_Taggable_evaluate_tags()
    test_case_0()

# Generated at 2022-06-25 06:15:28.184631
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print("-----------test for method evaluate_tags------------")
    test_case_0()
    print("-----------done------------")

# main
test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:15:31.988778
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    bytes_0 = b'\x8d\xe3\xd7\xbf\x05\xeb\xbe'
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(tuple_0, dict_0, bytes_0)
