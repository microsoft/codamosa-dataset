

# Generated at 2022-06-25 06:05:53.254804
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Creation of a Taggable object
    tag0 = Taggable()
    tag0.tags = 'test'

    # Expected result if the current item should be executed
    should_run = True

    # Expected result if the current item should not be executed
    should_not_run = False

    # List of tags given in the play
    only_tags = ['test']
    skip_tags = []

    # Check if the current item should be executed
    assert tag0.evaluate_tags(only_tags, skip_tags, {}) == should_run

    # Test of skip tags
    skip_tags = ['test']
    assert tag0.evaluate_tags(only_tags, skip_tags, {}) == should_not_run

# Generated at 2022-06-25 06:06:02.845804
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.play_context import PlayContext

    class FakePlaybook(object):

        def __init__(self, inventory, vars_dict):
            self._loader = None
            self._tqm = None
            self._inventory = inventory
            self._vars_dict = vars_dict

        def get_variable_manager(self):
            return FakeVariableManager(self._inventory, self._vars_dict)

    class FakeVariableManager(object):

        def __init__(self, inventory, vars_dict):
            self._inventory = inventory
            self._vars_dict = vars_dict

        #def get_vars(self, play=None, host=None, task=None, include_hostvars=True):

# Generated at 2022-06-25 06:06:08.905326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Set up argument values
    taggable_object = Taggable()
    only_tags = ["tag1"]
    skip_tags = ["tag2"]
    all_vars = {"tag1": [1, 2, 3], "tag2": [4, 5, 6]}

    # Invoke method
    should_run = taggable_object.evaluate_tags(only_tags, skip_tags, all_vars)

    # Check the result
    assert should_run == False

# Generated at 2022-06-25 06:06:18.659944
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    taggable_1.tags = ['all']
    print(taggable_1.evaluate_tags(only_tags=['all'],
                                   skip_tags=['never'],
                                   all_vars={}))
    assert(taggable_1.evaluate_tags(only_tags=['all'],
                                    skip_tags=['never'],
                                    all_vars={}) == True)

    taggable_2 = Taggable()
    taggable_2.tags = ['never']
    print(taggable_2.evaluate_tags(only_tags=['all'],
                                   skip_tags=['never'],
                                   all_vars={}))

# Generated at 2022-06-25 06:06:27.566899
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable = Taggable()
    taggable._loader = lambda *args: None
    taggable.tags = [ 'always' ]

    # Test 1:
    # check that the tag 'always' always executes
    assert taggable.evaluate_tags(['all'], [], {}) is True

    # Test 2:
    # check that 'tagged' executes if the task has an associated tag
    taggable.tags = [ 'answer' ]
    assert taggable.evaluate_tags(['tagged'], [], {}) is True

    # Test 3:
    answer = taggable.evaluate_tags(['answer', 'always'], [], {})
    assert answer is True

    # Test 4:
    assert taggable.evaluate_tags(['never'], [], {}) is False

    # Test 5

# Generated at 2022-06-25 06:06:37.745536
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:06:45.458631
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_1 = Taggable()
    taggable_1._tags = []

    only_tags = set()
    skip_tags = set()
    all_vars = dict()
    result = taggable_1.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    # Check result
    assert result == True

    # Check if it is actually an element of set
    assert result in skip_tags
    taggable_1._tags = None

    only_tags = set()
    skip_tags = set()
    all_vars = dict()
    result = taggable_1.evaluate_tags(only_tags=only_tags, skip_tags=skip_tags, all_vars=all_vars)
    # Check result

# Generated at 2022-06-25 06:06:47.949307
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_1 = Taggable()
    assert taggable_1.evaluate_tags(['test_0', 'test_1'], ['test_2'], {}) == True
#
# def test_case_2():
#     taggable_0 = Taggable()
#     taggable_0.tags = ['test_0', 'test_1']
#     taggable_0.evaluate_tags(None, None, {})

# Generated at 2022-06-25 06:06:52.760627
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    result_0 = taggable_0.evaluate_tags('only_tags', 'skip_tags', 'all_vars')
    assert type(result_0) is bool


# Generated at 2022-06-25 06:06:57.420679
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

if __name__ == "__main__":
    test_Taggable_evaluate_tags()

# Generated at 2022-06-25 06:07:13.406578
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = [b'\xd0\x9f\xef\xbf\xbd\xf2\x9f\xbf\xbf\xef\xb8\xb5\xf4\x8f\xbf\xbf']
    taggable_0 = Taggable(*list_0)
    bytes_0 = b'\xe0\xb8\xad\xef\xbf\xbd\xef\xbc\x81'
    str_0 = 'uname'
    int_0 = None
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    taggable_1 = Taggable()
    bytes_1 = b'\xd0\xa8'
    str_1 = 'uname'
    int_1

# Generated at 2022-06-25 06:07:20.767984
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)


# Generated at 2022-06-25 06:07:23.883595
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Testing with str_0 = 'uname'
    str_1 = 'uname'
    with pytest.raises(AnsibleError):
        # Call the method
        Taggable.evaluate_tags(str_1)

# Generated at 2022-06-25 06:07:31.543256
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    str_0 = 'pam_access'
    int_0 = 3
    taggable_0 = Taggable(*[str_0, int_0])
    taggable_1 = Taggable(*[str_0, int_0])
    taggable_2 = Taggable(*[str_0, int_0])
    taggable_3 = Taggable(*[str_0, int_0])
    taggable_3.evaluate_tags(*[str_0, int_0, int_0])


# Generated at 2022-06-25 06:07:42.156528
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Setup
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    # Setup
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

    # Assertions
    assert not taggable_0.evaluate_tags(str_0, int_0, int_0)
    assert not taggable_1.evaluate_tags(str_0, int_0, int_0)
    assert not taggable_2.evaluate_tags(str_0, int_0, int_0)



# Generated at 2022-06-25 06:07:47.085687
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)


# Generated at 2022-06-25 06:07:53.140259
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    assert var_0 == True


# Generated at 2022-06-25 06:08:00.587961
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)
    assert taggable_1.evaluate_tags(taggable_2.tags, int_0, int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:08:08.138947
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

# Generated at 2022-06-25 06:08:16.951891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_1.evaluate_tags(str_0, int_0, int_0)
    taggable_2 = Taggable(*list_0)
    taggable_2.evaluate_tags(str_0, int_0, int_0)



# Generated at 2022-06-25 06:08:37.731028
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'foo'
    str_0 = 'hostname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)
    str_1 = 'hostname'
    int_1 = None
    var_1 = taggable_2.evaluate_tags(int_1, str_0, int_1)



# Generated at 2022-06-25 06:08:44.919580
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)
    taggable_0.evaluate_tags(str_0, int_0, int_0)
    taggable_1.evaluate_tags(str_0, int_0, int_0)
    taggable_2.evaluate_tags(str_0, int_0, int_0)
    str_1 = 'group'
    taggable

# Generated at 2022-06-25 06:08:46.378242
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    print('Testing evaluate_tags()')
    test_case_0()


# Generated at 2022-06-25 06:08:50.526367
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'Y'
    str_0 = 'w'
    int_0 = None
    taggable_0 = Taggable(*[bytes_0, str_0])
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    assert var_0 == True



# Generated at 2022-06-25 06:08:57.998336
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'B\x0c'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)
    assert not var_0


# Generated at 2022-06-25 06:09:01.257243
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

# unit test for method _load_tags of class Taggable

# Generated at 2022-06-25 06:09:03.754375
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)
    assert var_0 == True


# Generated at 2022-06-25 06:09:10.174938
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

# Generated at 2022-06-25 06:09:13.533632
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case with only only_tags (String)
    test_case_0()


if __name__ == '__main__':
    for func in (test_Taggable_evaluate_tags,):
        func()

# Generated at 2022-06-25 06:09:19.711923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

if __name__ == '__main__':
    import pytest
    # The line below may be exchanged with pytest.main()
    test_Taggable_evaluate_tags()
    pytest.main()

# Generated at 2022-06-25 06:09:51.547981
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

# Generated at 2022-06-25 06:09:57.834470
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)


# Generated at 2022-06-25 06:10:02.465466
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    with pytest.raises(NotImplementedError):
        taggable_0 = Taggable()
        str_0 = 'uname'
        int_0 = None
        int_1 = None
        var_0 = taggable_0.evaluate_tags(str_0, int_0, int_1)


# Generated at 2022-06-25 06:10:08.415418
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    taggable_evaluate_tags_Example_0 = 'uname'
    taggable_evaluate_tags_Example_1 = None
    taggable_evaluate_tags_Example_2 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(taggable_evaluate_tags_Example_0, taggable_evaluate_tags_Example_1, taggable_evaluate_tags_Example_2)
    assert var_0 is None


# Generated at 2022-06-25 06:10:15.564628
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    test_case_0()

#print("uname:" + taggable_1._tags)
#taggable_2._tags.append("grep")
#print("uname:" + taggable_1._tags)
#print("uname:" + taggable_2._tags)
#print("uname:" + taggable_0.untagged)
#print("uname:" + taggable_1.untagged)
#print("uname:" + taggable_2.untagged)

# Generated at 2022-06-25 06:10:21.749144
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    global bytes_0
    global str_0
    global int_0
    global taggable_0
    global var_0
    global list_0
    global taggable_1
    global taggable_2
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

# Unit tests for class Taggable

# Generated at 2022-06-25 06:10:27.103964
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)


# Generated at 2022-06-25 06:10:32.331309
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)


# Generated at 2022-06-25 06:10:37.551436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)


# Mocking test for method evaluate_tags of class Taggable

# Generated at 2022-06-25 06:10:46.659375
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    str_0 = 'uname'
    int_0 = None
    bool_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    bool_1 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    assert bool_0 == bool_1
    assert bool_0 is not True
    assert bool_1 is not True
    bytes_0 = b'$'
    bytes_1 = b'X\xafc'
    list_0 = [bytes_0, bytes_1]
    taggable_1 = Taggable(*list_0)
    int_1 = None
    int_2 = None

# Generated at 2022-06-25 06:11:53.233920
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create Taggable with default constructor
    taggable_0 = Taggable()
    # Evaluate expression 'taggable_0.get_tags()'
    var_0 = taggable_0.get_tags()
    # Create an instance of Taggable using the default constructor
    taggable_1 = Taggable()
    # Set attribute 'tags' of taggable_1 to var_0
    taggable_1.set_tags(var_0)
    # Create an instance of Taggable using the default constructor
    taggable_2 = Taggable()
    # Load the attribute 'tags' of taggable_2 with the value of var_0
    taggable_2._load_tags("tags", var_0)



# Generated at 2022-06-25 06:12:03.445288
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    list_0 = [None]
    taggable_0 = Taggable(*list_0)
    str_0 = 'always'
    int_0 = None
    int_1 = None
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_1)
    list_1 = [None]
    taggable_1 = Taggable(*list_1)
    str_1 = 'tags'
    int_2 = None
    int_3 = None
    var_1 = taggable_1.evaluate_tags(str_1, int_2, int_3)
    assert var_0 == var_1, 'var_1 should be var_0'


# Generated at 2022-06-25 06:12:10.424692
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)
    return (taggable_0, taggable_1, taggable_2)


# Generated at 2022-06-25 06:12:14.734676
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'\x1c'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(int_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)



# Generated at 2022-06-25 06:12:23.175850
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True
    assert taggable_0.evaluate_tags(int, int, int) == True

# Generated at 2022-06-25 06:12:24.905597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass


# Generated at 2022-06-25 06:12:33.809282
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    bytes_0 = b'X\xafc'
    list_0 = [bytes_0]
    int_1 = None
    taggable_1 = Taggable(*list_0)
    int_2 = None
    # Execution starts here
    # test for equality of the object values
    if var_0 == var_1:
        print('Pass')
    else:
        print ('Failed')
    # test for equality of the object type
    if type(var_0) == type(var_1):
        print ('Pass')
    else:
        print ('Failed')
    # test for equality of the object id
    if id(var_0) == id(var_1):
        print ('Pass')
    else:
        print ('Failed')


#

# Generated at 2022-06-25 06:12:39.525824
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    taggable_0 = Taggable()
    only_tags = []
    skip_tags = []
    all_vars = {}
    var_0 = taggable_0.evaluate_tags(only_tags, skip_tags, all_vars)
    assert var_0 == True


# Generated at 2022-06-25 06:12:40.014238
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    pass

# Generated at 2022-06-25 06:12:47.819346
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_1 = Taggable(*list_0)
    taggable_2 = Taggable(*list_0)

    assert var_0
    assert taggable_2.evaluate_tags(str_0, int_0, int_0)



# Generated at 2022-06-25 06:15:37.548978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    bytes_0 = b'X\xafc'
    str_0 = 'uname'
    int_0 = None
    taggable_0 = Taggable()
    var_0 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_0 = [bytes_0]
    taggable_0._tags = list_0
    var_1 = taggable_0.evaluate_tags(str_0, int_0, int_0)
    list_1 = [bytes_0]
    taggable_1 = Taggable(*list_1)
    taggable_2 = Taggable(*list_1)

# vim: set et sw=4 ts=4 sts=4  fdm=indent :