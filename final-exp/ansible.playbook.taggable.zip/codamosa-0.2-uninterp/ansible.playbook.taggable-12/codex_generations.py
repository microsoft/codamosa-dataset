

# Generated at 2022-06-17 08:17:39.624308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag1']
    task.skip_tags = ['tag2']
    task.all_vars = dict()

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, task.all_vars) == True

    task.only_tags = ['tag2']
    task.skip_tags = ['tag1']
    play_context.only_tags = ['tag2']
    play_context.skip_tags

# Generated at 2022-06-17 08:17:48.914556
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.block_include import BlockInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults

# Generated at 2022-06-17 08:17:57.839543
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    task = Task()
    task.tags = ['test']
    play_context = PlayContext()
    play_context.only_tags = ['test']
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources=None)
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars(loader=None, play=None, host=None)) == True

    task = Task()
    task.tags = ['test']
    play_context = PlayContext()
    play_context.skip_tags = ['test']
   

# Generated at 2022-06-17 08:18:09.709843
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=['tagged']) == False

# Generated at 2022-06-17 08:18:16.077504
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block_context import BlockContext
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext


# Generated at 2022-06-17 08:18:29.946030
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # test with no tags
    task = Task()
    task.tags = []
    assert task.evaluate_tags(['tag1'], [], variable_manager.get_vars()) == False
    assert task.evaluate_tags(['tag1'], ['tag1'], variable_manager.get_vars()) == False
    assert task

# Generated at 2022-06-17 08:18:42.654749
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars.hostvars import HostVars

# Generated at 2022-06-17 08:18:52.411206
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(None)
    assert t.evaluate_tags(None, None, None) == True

    # Test with only_tags
    t = TestTaggable(['tag1', 'tag2'])
    assert t.evaluate_tags(['tag1', 'tag3'], None, None) == True
    assert t.evaluate_tags(['tag3'], None, None) == False
    assert t.evaluate_tags(['tagged'], None, None) == True
    assert t.evaluate_tags(['all'], None, None) == True
    assert t.evaluate_tags(['always'], None, None) == True
    assert t.evaluate_

# Generated at 2022-06-17 08:19:01.092252
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test with only_tags
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    test_taggable.tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-17 08:19:10.962180
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_path import RolePath

# Generated at 2022-06-17 08:19:24.852158
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag3'], [], {}) == False
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})

# Generated at 2022-06-17 08:19:35.487435
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(tags=[])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

    # Test with tags
    tt = TestTaggable(tags=['foo'])
    assert t

# Generated at 2022-06-17 08:19:44.685746
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:19:54.020470
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-17 08:20:00.381968
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert task.evaluate

# Generated at 2022-06-17 08:20:10.517006
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    # Test case 1:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   -

# Generated at 2022-06-17 08:20:21.030988
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 08:20:32.493408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:20:45.350614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test for only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}

    # Test for only_tags with 'all'
    only_tags = ['all']
    skip_tags = []
    all_vars = {}

    # Test for only_tags with 'tagged'
    only_tags = ['tagged']
    skip_tags = []
    all_vars = {}

    # Test for only_tags with 'always'
    only_tags = ['always']
    skip_tags = []
    all_vars = {}

    # Test for only_tags with 'never'
    only_tags = ['never']
    skip_tags = []
    all_vars = {}

    # Test for skip_tags
    only_tags = []
   

# Generated at 2022-06-17 08:20:54.243520
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault import VaultSecret
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:21:19.526102
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 08:21:30.496597
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(tags=None)
    assert tt.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    # Test with only_tags
    tt = TestTaggable(tags=None)
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars=None)
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=None, all_vars=None)
    assert tt.evaluate_tags(only_tags=['untagged'], skip_tags=None, all_vars=None)

# Generated at 2022-06-17 08:21:36.568847
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {})
    assert not task.evaluate_tags(['tag3'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert not task.evaluate_tags(['tag3', 'tag4'], [], {})
    assert task.evaluate_tags([], ['tag1'], {})


# Generated at 2022-06-17 08:21:41.201776
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    import os
    import sys
    import json


# Generated at 2022-06-17 08:21:48.542203
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Test for Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert t.evaluate_tags(['tag3'], [], {}) == False
    assert t.evaluate_tags(['tag4'], [], {}) == False

# Generated at 2022-06-17 08:21:59.835191
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    only_tags = []
    skip_tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, {})

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    tt.tags = ['tag1']
    assert tt.evaluate_tags(only_tags, skip_tags, {})
    tt.tags = ['tag2']
    assert tt.evaluate_tags(only_tags, skip_tags, {})
    tt.tags = ['tag3']

# Generated at 2022-06-17 08:22:06.898407
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:22:18.740340
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.handler import Handler as RoleHandler

    # Test for Task
    task = Task()

# Generated at 2022-06-17 08:22:26.341418
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:22:33.728639
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.include
    import ansible.playbook.handler
    import ansible.playbook.role_include

    # Test for class Task
    task = ansible.playbook.task.Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False


# Generated at 2022-06-17 08:23:14.162948
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:23:28.613872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test case 1: no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test case 2: only_tags = ['all']
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})

    # Test case 3: only_tags = ['all'], skip_tags = ['all']
    assert not tt.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={})

    # Test case 4: only_tags = ['all'], skip_tags = ['all', 'always']

# Generated at 2022-06-17 08:23:34.996994
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars.hostvars import HostVars

    # Test Taggable.evaluate_tags() for Task
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:23:42.702372
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude

# Generated at 2022-06-17 08:23:53.424128
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self):
            self._tags = []
            self._loader = None

    t = TaggableTest()
    t._tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {})
    assert not t.evaluate_tags(['tag3'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})
    assert not t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag3'], {})

# Generated at 2022-06-17 08:24:01.988456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: no tags specified
    tt = TestTaggable(tags=None)
    assert tt.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test 2: only_tags specified
    tt = TestTaggable(tags=None)
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == False
    tt = TestTaggable(tags=['tag1'])
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == True

# Generated at 2022-06-17 08:24:10.933331
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:24:23.481379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    test_taggable = TestTaggable(None)
    assert test_taggable.evaluate_tags(['all'], [], {})
    assert test_taggable.evaluate_tags(['all'], ['never'], {})
    assert test_taggable.evaluate_tags(['all'], ['tagged'], {})
    assert test_taggable.evaluate_tags(['all'], ['tagged', 'never'], {})
    assert test_taggable.evaluate_tags(['all'], ['tagged', 'never', 'foo'], {})

# Generated at 2022-06-17 08:24:29.245718
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(None, None, None)

    # Test with only_tags
    assert t.evaluate_tags(['all'], None, None)
    assert t.evaluate_tags(['tagged'], None, None)
    assert t.evaluate_tags(['tag1'], None, None)
    assert t.evaluate_tags(['tag1', 'tag2'], None, None)
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], None, None)

# Generated at 2022-06-17 08:24:44.197828
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # test with only_tags
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
   

# Generated at 2022-06-17 08:25:58.537346
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test with only_tags
    assert TestTaggable(['tag1']).evaluate_tags(['tag1'], [], {})
    assert TestTaggable(['tag1']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag2', 'tag1'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

# Generated at 2022-06-17 08:26:08.750072
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-17 08:26:18.543624
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    # Test for TaskInclude
    ti = TaskInclude()
    ti.tags = ['always']
    ti.vars = {}
    ti.tasks = []
    ti.block = Block()
    ti.block.vars = {}
    ti.block.parent_role = Role()
    ti.block.parent_role.vars = {}
    ti.block.parent_role.vars['role_name'] = 'test_role'
    ti.block.parent_role.vars['role_path'] = '/tmp/test_role'
    ti.block.parent_role.vars

# Generated at 2022-06-17 08:26:30.316326
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task

# Generated at 2022-06-17 08:26:40.836354
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={})

# Generated at 2022-06-17 08:26:51.618737
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert test_taggable.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})
    assert test_taggable.evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:27:01.640381
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.groupvars import GroupVars
    from ansible.playbook.vars.filevars import FileVars

# Generated at 2022-06-17 08:27:11.996359
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    # Test with only_tags
    tt = TestTaggable(['a', 'b'])
    assert tt.evaluate_tags(['a'], [], {})
    assert not tt.evaluate_tags(['c'], [], {})
    assert tt.evaluate_tags(['all'], [], {})
    assert tt.evaluate_tags(['tagged'], [], {})
    assert not tt.evaluate_tags(['untagged'], [], {})
    assert not tt.evaluate_tags(['never'], [], {})
    assert tt.evaluate_tags(['always'], [], {})

    # Test with skip_

# Generated at 2022-06-17 08:27:21.280112
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.meta import Meta