

# Generated at 2022-06-17 08:17:33.438798
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeArgs
    from ansible.playbook.task_include import TaskIncludeRole
    from ansible.playbook.task_include import TaskIncludeRoleVars
    from ansible.playbook.task_include import TaskIncludeVars
    from ansible.playbook.task_include import TaskIn

# Generated at 2022-06-17 08:17:43.912532
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    task = Task()
    task.tags = ['tag1']

# Generated at 2022-06-17 08:17:51.670248
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # Create a Base object
    base = Base()

    # Create a Task object
    task = Task()

    # Create a Role object
    role = Role()

    # Create a Play object
    play = Play()

    # Create a Block object
    block = Block()

    # Create a Handler object
    handler = Handler()

    # Create a Taggable object
    taggable = Taggable()

    # Test evaluate_tags method of class Taggable
    # Test with only_tags and skip_tags as None
    # Test

# Generated at 2022-06-17 08:18:01.149659
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag3'], [], {}) == True

# Generated at 2022-06-17 08:18:08.908341
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.block_include import BlockInclude


# Generated at 2022-06-17 08:18:22.657872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_dependency import TaskDependency

# Generated at 2022-06-17 08:18:32.804471
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(['tag1'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2', 'tag3', 'tag4'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2', 'tag3', 'tag4', 'tag5'], [], {})

# Generated at 2022-06-17 08:18:46.569745
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    class MyTask(Task, Taggable):
        pass

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    host = inventory.get_host('localhost')
   

# Generated at 2022-06-17 08:18:57.023045
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags: ['all']
    #   skip_tags: []
    #   tags: ['always']
    #   expected: True
    only_tags = ['all']
    skip_tags = []
    tags = ['always']
    expected = True
    actual = Taggable().evaluate_tags(only_tags, skip_tags, tags)
    assert expected == actual

    # Test case 2:
    #   only_tags: ['all']
    #   skip_tags: []
    #   tags: ['never']
    #   expected: False
    only_tags = ['all']
    skip_tags = []
    tags = ['never']
    expected = False
    actual = Taggable().evaluate_tags(only_tags, skip_tags, tags)
    assert expected == actual

   

# Generated at 2022-06-17 08:19:08.977794
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(None)
    assert tt.evaluate_tags(None, None, None) == True
    assert tt.evaluate_tags(['foo'], None, None) == False
    assert tt.evaluate_tags(None, ['foo'], None) == True
    assert tt.evaluate_tags(['foo'], ['foo'], None) == False

    # Test with tags
    tt = TestTaggable(['foo'])
    assert tt.evaluate_tags(None, None, None) == True
    assert tt.evaluate_tags(['foo'], None, None) == True

# Generated at 2022-06-17 08:19:28.513590
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(None, None, None) == True

    # Test with only_tags
    assert tt.evaluate_tags(['tag1'], None, None) == False
    tt.tags = ['tag1']
    assert tt.evaluate_tags(['tag1'], None, None) == True
    assert tt.evaluate_tags(['tag2'], None, None) == False
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(['tag1'], None, None) == True
    assert tt.evaluate_tags(['tag2'], None, None)

# Generated at 2022-06-17 08:19:34.893087
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(tags=[])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['foo']) == True
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=['foo']) == False

    # Test with tags
    tt = TestTaggable(tags=['foo'])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True

# Generated at 2022-06-17 08:19:42.243327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:19:49.711936
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test with no tags
    t = FakeTaggable(None)
    assert t.evaluate_tags(None, None, None) == True

    # test with only_tags
    t = FakeTaggable(['a', 'b'])
    assert t.evaluate_tags(['a'], None, None) == True
    assert t.evaluate_tags(['b'], None, None) == True
    assert t.evaluate_tags(['c'], None, None) == False

    # test with skip_tags
    t = FakeTaggable(['a', 'b'])
    assert t.evaluate_tags(None, ['a'], None) == False

# Generated at 2022-06-17 08:19:58.317697
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vault import VaultSecret
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.role_dependency import RoleDependency


# Generated at 2022-06-17 08:20:09.125050
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:20:16.352978
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag1', 'tag2']
    #   should_run = True
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    tags = ['tag1', 'tag2']
    should_run = True
    assert Taggable().evaluate_tags(only_tags, skip_tags, tags) == should_run

    # Test case 2:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag3', 'tag4']
    #   should_run = False
    only_

# Generated at 2022-06-17 08:20:31.303346
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3', 'tag4'], [], {}) == True
    assert task.evaluate_tags

# Generated at 2022-06-17 08:20:41.774883
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test for only_tags
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag3', 'tag4'], [], {}) is False

# Generated at 2022-06-17 08:20:51.910538
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test case 1: only_tags = ['tag1', 'tag2'], skip_tags = ['tag3', 'tag4'], tags = ['tag1', 'tag2']
    # Expected result: True
    test_tags = ['tag1', 'tag2']
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    test_taggable = TestTaggable(test_tags)
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == True

    # Test case 2: only_tags = ['tag1', 'tag2'], skip_tags = ['tag3', 'tag4'], tags =

# Generated at 2022-06-17 08:21:18.894154
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:21:30.476073
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
   

# Generated at 2022-06-17 08:21:36.600263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with empty tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-17 08:21:43.660386
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.include
    import ansible.playbook.handler

    class MyTask(ansible.playbook.task.Task):
        pass

    class MyRole(ansible.playbook.role.Role):
        pass

    class MyBlock(ansible.playbook.block.Block):
        pass

    class MyPlay(ansible.playbook.play.Play):
        pass

    class MyInclude(ansible.playbook.include.Include):
        pass

    class MyHandler(ansible.playbook.handler.Handler):
        pass

    # Test for Task
    t = MyTask()

# Generated at 2022-06-17 08:21:54.389728
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test 1: no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test 2: only_tags
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == False
    tt.tags = ['foo']
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == True
    tt.tags = ['foo', 'bar']
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == True


# Generated at 2022-06-17 08:22:02.421194
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    task = Task()
    task._variable_manager = variable_manager
    task._tqm = None
    task.tags = ['tag1']


# Generated at 2022-06-17 08:22:10.522617
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    # Test for Task
    task = Task()
    task._role = Role()
    task._block = Block()
    task._play = Play()
    task._loader = None
    task.tags = ['test']
    task.always_run = False
    task.run_once = False
    task.any_errors_fatal = False
    task.delegate_to = None
    task.delegate_facts = False
    task.notify = []
    task.handlers = []
    task.environment = {}
    task.when = []
    task.register = None
    task.ignore_errors = False

# Generated at 2022-06-17 08:22:21.114439
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.groupvars import GroupVars
    from ansible.playbook.vars.taskvars import TaskVars

# Generated at 2022-06-17 08:22:28.070252
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:22:39.111187
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook


# Generated at 2022-06-17 08:23:14.951734
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask

# Generated at 2022-06-17 08:23:25.989576
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:23:33.320465
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import Include

# Generated at 2022-06-17 08:23:43.276248
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=['bar'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=['foo'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=['foo', 'bar'], all_vars={}) == False

# Generated at 2022-06-17 08:23:55.472132
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:24:04.922589
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import RoleIn

# Generated at 2022-06-17 08:24:14.120083
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.pause import Pause
    from ansible.playbook.import_role import ImportRole

# Generated at 2022-06-17 08:24:25.246411
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_block import RoleBlock
    from ansible.playbook.role_path import RolePath
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

# Generated at 2022-06-17 08:24:37.735678
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 08:24:49.168620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={})
    assert not tt.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={})
    assert not tt.evaluate_tags(only_tags=['never'], skip_tags=['all'], all_vars={})
    assert not tt

# Generated at 2022-06-17 08:26:01.814039
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:26:15.837056
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsInclude

# Generated at 2022-06-17 08:26:29.786239
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    task = Task()
    task._role = None
    task._block = None
    task._play = None
    task._loader = None
    task._variable_manager = VariableManager()
    task._task_vars = dict()
    task._task_vars['tags'] = ['foo', 'bar']
    task._task_vars['always_run'] = False
    task._task_vars['any_errors_fatal'] = False
    task._task_vars['delegate_to'] = None
    task._task_vars['delegate_facts'] = False
    task._task_vars['run_once'] = False
    task._task_

# Generated at 2022-06-17 08:26:39.356981
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with empty tags
    tt = TestTaggable([])
    assert tt.evaluate_tags(None, None, None) == True
    assert tt.evaluate_tags(['all'], None, None) == True
    assert tt.evaluate_tags(['all'], ['all'], None) == False
    assert tt.evaluate_tags(['all'], ['tagged'], None) == False
    assert tt.evaluate_tags(['all'], ['never'], None) == True
    assert tt.evaluate_tags(['tagged'], None, None) == False
    assert tt.evaluate_tags(['tagged'], ['all'], None) == False

# Generated at 2022-06-17 08:26:51.193451
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
    # Test 1
    # Test case:
    #   tags: [tag1, tag2]
    #   only_tags: [tag1]
    #   skip_tags: []
    #   should_run: True
    test_tags = ['tag1', 'tag2']
    test_only_tags = ['tag1']
    test_skip_tags = []
    test_should_run = True
    test_taggable = TestTaggable(test_tags)
    assert test_taggable.evaluate_tags(test_only_tags, test_skip_tags, {}) == test_should_run
    # Test 2
    # Test case:
    #   tags: [tag1, tag

# Generated at 2022-06-17 08:27:01.611668
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test with only_tags
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    tt.tags = ['tag1']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_

# Generated at 2022-06-17 08:27:11.964451
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:27:23.825211
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(None)
    assert t.evaluate_tags(None, None, None) == True

    # Test with only_tags
    t = TestTaggable(['foo'])
    assert t.evaluate_tags(['foo'], None, None) == True
    assert t.evaluate_tags(['bar'], None, None) == False

    # Test with skip_tags
    t = TestTaggable(['foo'])
    assert t.evaluate_tags(None, ['foo'], None) == False
    assert t.evaluate_tags(None, ['bar'], None) == True

    # Test with both only_tags and skip_tags