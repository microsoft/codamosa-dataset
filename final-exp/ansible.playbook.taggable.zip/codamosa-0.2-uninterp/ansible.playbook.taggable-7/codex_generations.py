

# Generated at 2022-06-17 08:17:41.917268
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test 1: no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[])

    # Test 2: only_tags
    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[])
    assert not tt.evaluate_tags(only_tags=['tag3'], skip_tags=[])
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[])
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[])
    assert t

# Generated at 2022-06-17 08:17:51.242444
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:18:00.894807
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = None

    # Test 1: no tags
    tt = TestTaggable()
    tt.tags = None
    assert tt.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test 2: only_tags=None, skip_tags=None
    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test 3: only_tags=['tag1'], skip_tags=None
    tt = TestTaggable()

# Generated at 2022-06-17 08:18:11.741265
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

    # Test with tags
    t = TestTaggable(tags=['foo', 'bar'])
    assert t.evaluate_tags

# Generated at 2022-06-17 08:18:23.441432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:18:34.800841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 08:18:48.336212
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger
    from ansible.playbook.meta import Meta

# Generated at 2022-06-17 08:18:57.024492
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task.tags = ['tag1', 'tag2']
    task.evaluate_tags(['tag1'], [], variable_manager.get_vars())
    task.evaluate_tags(['tag1', 'tag2'], [], variable_manager.get_vars())

# Generated at 2022-06-17 08:19:04.783519
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']

    assert test_taggable.evaluate_tags(['tag1'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag2'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag3'], [], {}) == False
    assert test_taggable.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag3', 'tag4'], [], {})

# Generated at 2022-06-17 08:19:10.660033
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a block with tags
    block = Block()
    block.tags = ['tag3', 'tag4']

    # Create a role with tags
    role = Role()
    role.tags = ['tag5', 'tag6']

    # Create a play with tags
    play = Play()
    play.tags = ['tag7', 'tag8']

    # Create a playbook with tags
    playbook = Playbook()

# Generated at 2022-06-17 08:19:25.003141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:19:30.354164
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never', 'always'], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={})

# Generated at 2022-06-17 08:19:41.356188
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag1']
    task.skip_tags = ['tag2']
    assert task.evaluate_tags(task.only_tags, task.skip_tags, {}) == True

    task = Task()
    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag1', 'tag2']
    task.skip_tags = ['tag2']

# Generated at 2022-06-17 08:19:49.289885
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import As

# Generated at 2022-06-17 08:19:56.098963
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']

    # test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True

    only_tags = ['tag1', 'tag2', 'tag3']
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True

    only_tags = ['tag1', 'tag2', 'tag3', 'tag4']
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True

    only_tags = ['tag3', 'tag4']

# Generated at 2022-06-17 08:20:08.583831
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play with tags
    play = Play()
    play.tags = ['tag3', 'tag4']

    # Create a task with no tags
    task2 = Task()

    # Create a play with no tags
    play2 = Play()

    # Create a task with tags 'never' and 'always'
    task3 = Task()
    task3.tags = ['never', 'always']

    # Create a play with tags 'never' and 'always'
    play3 = Play()
    play3.tags = ['never', 'always']

    # Create a task with tags 'never' and 'always' and 'tag

# Generated at 2022-06-17 08:20:20.038483
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-17 08:20:31.721117
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    t = Task()
    t.tags = ['always']
    assert t.evaluate_tags(['always'], [], {}) == True
    assert t.evaluate_tags(['all'], [], {}) == True

# Generated at 2022-06-17 08:20:45.309438
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude

    # Test for class Task
   

# Generated at 2022-06-17 08:20:53.018132
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['test_tag']
    assert task.evaluate_tags(['test_tag'], [], {}) == True
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {}) == False
    assert task.evaluate_tags([], ['test_tag'], {}) == True
    assert task.evaluate_tags([], [], {}) == True

    # Test for Block
    block = Block()
    block.tags = ['test_tag']

# Generated at 2022-06-17 08:21:19.140834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:21:31.912898
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['always']
    assert task.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert not task.evaluate_tags(only_tags=[], skip_tags=['always'], all_vars={})
    assert not task.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert not task.evaluate_tags(only_tags=['never'], skip_tags=[], all_vars={})
    assert not task

# Generated at 2022-06-17 08:21:38.857839
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(None)
    assert tt.evaluate_tags(None, None, None) == True
    assert tt.evaluate_tags(['all'], None, None) == True
    assert tt.evaluate_tags(['tagged'], None, None) == False
    assert tt.evaluate_tags(['tagged', 'all'], None, None) == True
    assert tt.evaluate_tags(['tagged', 'all', 'never'], None, None) == False
    assert tt.evaluate_tags(['tagged', 'all', 'always'], None, None) == True

# Generated at 2022-06-17 08:21:49.023287
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['test']
    assert task.evaluate_tags(['test'], [], {}) == True
    assert task.evaluate_tags([], ['test'], {}) == False

# Generated at 2022-06-17 08:21:59.896384
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:22:06.925762
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1:
    #   only_tags:
    #       - all
    #       - always
    #   skip_tags:
    #       - never
    #   tags:
    #       - always
    #   expected result: True
    only_tags = ['all', 'always']
    skip_tags = ['never']
    tags = ['always']
    tt = TestTaggable(tags)
    assert tt.evaluate_tags(only_tags, skip_tags, None) == True

    # Test 2:
    #   only_tags:
    #       - all
    #       - always
    #   skip_tags:
    #       - never
    #   tags:
   

# Generated at 2022-06-17 08:22:18.750403
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.groupvars import GroupVars
    from ansible.playbook.vars.taskvars import TaskVars

# Generated at 2022-06-17 08:22:29.629977
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.unvars import Unvars
    from ansible.playbook.debugger import Debugger

    # Test for class Task
    task = Task()
    task.tags

# Generated at 2022-06-17 08:22:35.761889
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    class TestTaggable(unittest.TestCase):
        def setUp(self):
            self.task = Task()
            self.role = Role()
            self.play = Play()
            self.block = Block()
            self.handler = Handler()

        def tearDown(self):
            pass

        def test_task_evaluate_tags(self):
            self.task.tags = ['tag1', 'tag2']
            self.assertTrue(self.task.evaluate_tags(['tag1'], [], {}))

# Generated at 2022-06-17 08:22:43.130083
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    only_tags = []
    skip_tags = []
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == True

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    test_taggable.tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == True
    test_taggable.tags = ['tag2']
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == False

    # Test with skip_tags
   

# Generated at 2022-06-17 08:23:25.305677
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = []

    t = TestTaggable()
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['tagged'], all_vars={}) == True

# Generated at 2022-06-17 08:23:33.131790
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
   

# Generated at 2022-06-17 08:23:43.187058
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:23:55.474719
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    class MyTask(Task, Taggable):
        pass

    task = MyTask()
    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag1']
    task.skip_tags = ['tag2']
    task.all_vars = dict()

    assert task.evaluate_tags(task.only_tags, task.skip_tags, task.all_vars) == True

    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag3']
    task.skip_tags = ['tag2']
    task.all_vars = dict()


# Generated at 2022-06-17 08:24:04.890859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude

    # Test for class Task
   

# Generated at 2022-06-17 08:24:14.121389
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskIncludeRole
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars

# Generated at 2022-06-17 08:24:25.248010
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task
    task = Task()
    task._role = None
    task._block = None
    task._play = None
    task._loader = None
    task._variable_manager = VariableManager()
    task._task_vars = dict()
    task._task_vars['ansible_version'] = dict()
    task._task_vars['ansible_version']['full'] = '2.0.0.0'
    task._task_vars['ansible_version']['major'] = 2
    task._task_vars['ansible_version']['minor'] = 0

# Generated at 2022-06-17 08:24:37.736305
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags = ['all']
    #   skip_tags = []
    #   tags = ['tag1', 'tag2']
    #   expected_result = True
    only_tags = ['all']
    skip_tags = []
    tags = ['tag1', 'tag2']
    expected_result = True
    result = Taggable().evaluate_tags(only_tags, skip_tags, tags)
    assert result == expected_result

    # Test case 2:
    #   only_tags = ['all']
    #   skip_tags = []
    #   tags = ['never']
    #   expected_result = False
    only_tags = ['all']
    skip_tags = []
    tags = ['never']
    expected_result = False
    result = Taggable().evaluate_

# Generated at 2022-06-17 08:24:46.024632
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    task = Task()
    task.tags = ['tag1']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == True


# Generated at 2022-06-17 08:24:57.668345
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency


# Generated at 2022-06-17 08:26:03.561139
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars import Vars

# Generated at 2022-06-17 08:26:16.247930
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsInclude

# Generated at 2022-06-17 08:26:29.968697
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(None)
    assert tt.evaluate_tags(None, None, None) == True
    assert tt.evaluate_tags(['foo'], None, None) == False
    assert tt.evaluate_tags(None, ['foo'], None) == True
    assert tt.evaluate_tags(['foo'], ['foo'], None) == False

    # Test with tags
    tt = TestTaggable(['foo'])
    assert tt.evaluate_tags(None, None, None) == True
    assert tt.evaluate_tags(['foo'], None, None) == True

# Generated at 2022-06-17 08:26:39.578904
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.base import Base
   

# Generated at 2022-06-17 08:26:51.377068
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    # Create a task
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Test with no tags
    assert task.evaluate_tags(None, None, None) == True

    # Test with only_tags
    assert task.evaluate_tags(['tag1'], None, None) == True
    assert task.evaluate_tags(['tag2'], None, None) == True
    assert task.evaluate_tags(['tag3'], None, None) == False
    assert task.evaluate_tags(['tag1', 'tag2'], None, None) == True
    assert task.evaluate_tags(['tag1', 'tag3'], None, None) == True
    assert task.evaluate_tags(['tag3', 'tag4'], None, None)

# Generated at 2022-06-17 08:27:03.301788
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    task = Task()
    task.tags = ['test']
    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(tags=['test']))
    variable_manager.set_inventory(dict(hosts=dict(localhost=dict(ansible_connection='local'))))

    # test with only_tags
    play_context.only_tags = ['test']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars(loader=None, play=None, host=None))

    play_context.only_tags

# Generated at 2022-06-17 08:27:13.762767
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:27:25.749426
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.vault_password import VaultPassword
