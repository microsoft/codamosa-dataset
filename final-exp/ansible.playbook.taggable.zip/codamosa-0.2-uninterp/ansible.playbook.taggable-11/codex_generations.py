

# Generated at 2022-06-17 08:17:34.193992
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class TestTaggable(Taggable):
        pass

    class TestTask(Task, TestTaggable):
        pass

    task = TestTask()
    task.tags = ['tag1', 'tag2']
    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(tags=['tag1', 'tag2']))
    variable_manager.set_nonpersistent_facts(dict(tags=['tag1', 'tag2']))
    variable_manager.set_nonpersistent_facts(dict(tags=['tag1', 'tag2']))
    variable_manager.set_non

# Generated at 2022-06-17 08:17:44.091075
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude


# Generated at 2022-06-17 08:17:51.774244
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:18:01.223867
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    tt = TestTaggable(['tag1'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True
    tt = TestTaggable(['tag2'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == False
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-17 08:18:08.997553
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()
    test_class.tags = ['tag1', 'tag2']
    assert test_class.evaluate_tags(['tag1'], [], {}) == True
    assert test_class.evaluate_tags(['tag2'], [], {}) == True
    assert test_class.evaluate_tags(['tag3'], [], {}) == False
    assert test_class.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_class.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert test_class.evaluate_tags(['tag1', 'tag3'], [], {}) == True

# Generated at 2022-06-17 08:18:22.701840
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    task = Task()
    task._play_context = play_context
    task._variable_manager = variable_manager
    task.tags = ['tag1']

# Generated at 2022-06-17 08:18:32.834162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = set(['tag1', 'tag2'])
    play_context.skip_tags = set(['tag3', 'tag4'])
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:18:46.615149
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task.tags = ['test']
    task.only_tags = ['test']
    task.skip_tags = ['test']
    task.vars = dict()
    task.vars['tags'] = ['test']
    task._play_context = PlayContext()
    task._play_context.only_tags = ['test']
    task._play_context.skip_tags = ['test']

    assert task.evaluate_tags(task.only_tags, task.skip_tags, task.vars) == True
    task.tags = ['test1']
    assert task.evaluate_tags(task.only_tags, task.skip_tags, task.vars) == False
    task.only_tags

# Generated at 2022-06-17 08:18:54.761105
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: no tags given
    t = TaggableTest(None)
    assert t.evaluate_tags(None, None, None) == True

    # Test 2: only_tags given, no tags on task
    t = TaggableTest(None)
    assert t.evaluate_tags(['foo'], None, None) == False

    # Test 3: only_tags given, matching tags on task
    t = TaggableTest(['foo'])
    assert t.evaluate_tags(['foo'], None, None) == True

    # Test 4: only_tags given, non-matching tags on task
    t = TaggableTest(['bar'])

# Generated at 2022-06-17 08:19:03.488919
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test with only_tags
    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(['tag1'], [], {}) == True
    assert tt.evaluate_tags(['tag2'], [], {}) == True
    assert tt.evaluate_tags(['tag3'], [], {}) == False
    assert tt.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert tt.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert tt.evaluate_tags(['tag3', 'tag4'], [], {}) == False

# Generated at 2022-06-17 08:19:22.248276
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    task = Task()
    task.tags = ['tag1', 'tag2']

    # test 1:
    #   only_tags: ['tag1']
    #   skip_tags: []
    #   tags: ['tag1', 'tag2']
    #   expected: True
    only_tags = ['tag1']
    skip

# Generated at 2022-06-17 08:19:33.381158
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    t = TestTaggable()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {})
    assert not t.evaluate_tags(['tag3'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert t.evaluate_tags(['tag3', 'tag4'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3', 'tag4'], [], {})

# Generated at 2022-06-17 08:19:41.484377
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags([], ['tag1'], {}) == False

# Generated at 2022-06-17 08:19:49.909015
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:19:55.681219
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:20:08.499201
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = []
            self._loader = None

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['foo']) == True
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=['foo']) == False

    # Test with tags
    tt._tags = ['foo']
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True

# Generated at 2022-06-17 08:20:19.985252
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.handler.include import IncludeHandler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional


# Generated at 2022-06-17 08:20:32.394657
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-17 08:20:45.349023
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.debugger import Debugger
    from ansible.playbook.meta import MetaTask

# Generated at 2022-06-17 08:20:54.245641
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:21:19.175392
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: only_tags = ['tag1', 'tag2'], skip_tags = [], tags = ['tag1']
    test_taggable = TestTaggable(['tag1'])
    assert test_taggable.evaluate_tags(['tag1', 'tag2'], [], {})

    # Test 2: only_tags = ['tag1', 'tag2'], skip_tags = [], tags = ['tag3']
    test_taggable = TestTaggable(['tag3'])
    assert not test_taggable.evaluate_tags(['tag1', 'tag2'], [], {})

    # Test 3: only_tags = ['tag1', 'tag2'],

# Generated at 2022-06-17 08:21:30.474897
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import Become

# Generated at 2022-06-17 08:21:36.546325
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[])

    # Test with only_tags
    test_taggable._tags = ['tag1', 'tag2']
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[])
    assert not test_taggable.evaluate_tags(only_tags=['tag3'], skip_tags=[])

    # Test with skip_tags
    test_taggable._tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:21:46.806011
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_obj = TestTaggable()

    # Test with no tags
    test_obj.tags = None
    assert test_obj.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test with only_tags
    test_obj.tags = None
    assert test_obj.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == False
    test_obj.tags = ['tag1']
    assert test_obj.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == True
    test_obj.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:21:55.067417
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag1'], {}) == True
    assert task.evaluate_tags

# Generated at 2022-06-17 08:22:02.898193
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:22:10.821702
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:22:21.274430
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.role import RoleDependency
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 08:22:31.585418
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    tt = TestTaggable()

    # Test with only_tags
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(['tag1'], [], {}) == True
    assert tt.evaluate_tags(['tag2'], [], {}) == True
    assert tt.evaluate_tags(['tag3'], [], {}) == False
    assert tt.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert tt.evaluate_tags(['tag1', 'tag3'], [], {}) == True

# Generated at 2022-06-17 08:22:40.186683
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule

# Generated at 2022-06-17 08:23:15.372108
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    task = Task()
    task.tags = ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-17 08:23:29.546478
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:23:41.938706
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test 1: no tags
    t = TestTaggable()
    assert t.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})

    # Test 2: only_tags=['tag1']
    t = TestTaggable()
    t.tags = ['tag1']
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={})
    assert not t.evaluate_tags(only_tags=['tag2'], skip_tags=None, all_vars={})

    # Test 3: skip_tags=['tag1']
    t = TestTaggable()
    t.tags = ['tag1']

# Generated at 2022-06-17 08:23:48.507053
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    tt.tags = ['tag1']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:23:57.574147
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    # Test 1:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   - tags: ['tag1', 'tag2', 'tag3']
    #   - expected: True
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    tags = ['tag1', 'tag2', 'tag3']
    all_vars = {}
    t = TaggableTest(tags)
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    # Test 2:
    #   -

# Generated at 2022-06-17 08:24:05.232223
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']

    task = Task()
    task.tags = ['tag1', 'tag2', 'tag3']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict()) == False

    task.tags = ['tag1', 'tag2', 'tag4']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict()) == False

    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:24:14.146382
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={}) == False

# Generated at 2022-06-17 08:24:25.246151
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:24:37.737379
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:24:46.024182
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()
    task = Task()
    task.tags = ['tag1', 'tag2']
    task.evaluate_tags(['tag1'], [], variable_manager.get_vars(play=play_context))
    assert task.evaluate_tags(['tag1'], [], variable_manager.get_vars(play=play_context)) == True

# Generated at 2022-06-17 08:25:53.030923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import As

# Generated at 2022-06-17 08:26:02.914831
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   - tags: ['tag1', 'tag2']
    #   - should_run: True
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    tags = ['tag1', 'tag2']
    should_run = True
    assert Taggable().evaluate_tags(only_tags, skip_tags, {}) == should_run

    # Test case 2:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   - tags: ['tag3', 'tag4']
    #   - should

# Generated at 2022-06-17 08:26:13.744953
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude

# Generated at 2022-06-17 08:26:23.199123
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:26:32.617178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    taggable = MockTaggable(tags=None)
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    taggable = MockTaggable(tags=['tag1', 'tag2'])
    assert taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not taggable.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})

    # Test with skip_tags

# Generated at 2022-06-17 08:26:41.239841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: no tags
    tt = TestTaggable(tags=[])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[])

    # Test 2: only_tags
    tt = TestTaggable(tags=['tag1'])
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[])
    assert not tt.evaluate_tags(only_tags=['tag2'], skip_tags=[])

    # Test 3: skip_tags
    tt = TestTaggable(tags=['tag1'])
    assert not tt.evaluate_tags(only_tags=[], skip_tags=['tag1'])

# Generated at 2022-06-17 08:26:51.316589
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True

# Generated at 2022-06-17 08:27:03.295117
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:27:13.760263
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']

    # Test with only_tags
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:27:24.974080
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(None)
    assert tt.evaluate_tags(None, None, None) == True

    # Test with only_tags
    tt = TestTaggable(None)
    assert tt.evaluate_tags(['tag1'], None, None) == False
    tt = TestTaggable(['tag1'])
    assert tt.evaluate_tags(['tag1'], None, None) == True
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_tags(['tag1'], None, None) == True