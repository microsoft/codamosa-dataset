

# Generated at 2022-06-17 08:17:40.234436
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test Taggable.evaluate_tags() for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:17:51.058737
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus

# Generated at 2022-06-17 08:18:00.787275
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.playbook.become_flags import BecomeFlags

# Generated at 2022-06-17 08:18:11.668863
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not t.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})

    # Test with skip_tags
    assert t.evaluate_tags(only_tags=[], skip_tags=['tag1'], all_vars={})

# Generated at 2022-06-17 08:18:22.467791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    assert FakeTaggable(None).evaluate_tags(None, None, None) == True

    # Test with only_tags
    assert FakeTaggable(None).evaluate_tags(['all'], None, None) == True
    assert FakeTaggable(None).evaluate_tags(['tagged'], None, None) == False
    assert FakeTaggable(None).evaluate_tags(['untagged'], None, None) == False
    assert FakeTaggable(None).evaluate_tags(['always'], None, None) == False
    assert FakeTaggable(None).evaluate_tags(['never'], None, None) == False
    assert FakeTaggable(None).evaluate

# Generated at 2022-06-17 08:18:32.714761
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable([])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=[], skip_tags=['all']) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['all']) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

# Generated at 2022-06-17 08:18:46.480623
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})

# Generated at 2022-06-17 08:18:54.639860
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    task.tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = ['tag3']
    all_vars = dict()


# Generated at 2022-06-17 08:19:03.389760
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.loop import Loop
    from ansible.playbook.task.when import When
    from ansible.playbook.task.meta import MetaTask
    from ansible.playbook.task.import_role import ImportRole
    from ansible.playbook.task.set_fact import SetFact
    from ansible.playbook.task.include_role import IncludeRole
   

# Generated at 2022-06-17 08:19:12.388791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    task = Task()
    task._variable_manager = variable_manager
    task._play_context = play_context
    task.tags = ['tag1']


# Generated at 2022-06-17 08:19:29.354745
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']

    assert test_taggable.evaluate_tags(['tag1'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert test_taggable.evaluate_tags(['tag3'], [], {}) == False
    assert test_taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag1', 'tag2'], {}) == False
    assert test_tagg

# Generated at 2022-06-17 08:19:41.244910
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    # Test with tags = ['tag1', 'tag2']
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test with tags = ['tag1']
    tt = TestTaggable(['tag1'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test with tags = ['tag2']

# Generated at 2022-06-17 08:19:49.677810
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude

    # Test for class Task
    t = Task()
    t.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:19:58.317614
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True

# Generated at 2022-06-17 08:20:09.124266
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not t.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})

    # Test with skip_tags
    assert not t.evaluate_tags(only_tags=[], skip_tags=['tag1'], all_vars={})

# Generated at 2022-06-17 08:20:16.354343
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # test with no tags
    assert test_taggable.evaluate_tags(only_tags=set(), skip_tags=set(), all_vars={}) == True

    # test with only_tags
    assert test_taggable.evaluate_tags(only_tags=set(['tag1']), skip_tags=set(), all_vars={}) == False
    assert test_taggable.evaluate_tags(only_tags=set(['tag1']), skip_tags=set(), all_vars={}) == False

# Generated at 2022-06-17 08:20:31.561183
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert task.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert task.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True

# Generated at 2022-06-17 08:20:38.248465
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for Task
    task = Task()

# Generated at 2022-06-17 08:20:48.146983
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    task = Task()
    task.tags = ['tag1']

# Generated at 2022-06-17 08:20:55.215636
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:21:20.087847
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for Task
    t = Task()
    t.tags = ['test_tag']

# Generated at 2022-06-17 08:21:30.532237
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1', 'tag3'], ['tag2'], {}) == True

# Generated at 2022-06-17 08:21:36.544850
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become

# Generated at 2022-06-17 08:21:43.609156
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # Create a task with tags
    task = Task()
    task.tags = ['test_tag']

    # Create a play context with no tags
    play_context = PlayContext()
    play_context.only_tags = []
    play_context.skip_tags = []

    # Test that the task should run
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, {})

    # Create a play context with only_tags
    play_context = PlayContext()
    play_context.only_tags = ['test_tag']
    play_context.skip_tags = []

    # Test that the task should run

# Generated at 2022-06-17 08:21:54.359076
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(tags=['foo']).evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['foo']).evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['foo', 'bar']).evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:22:04.927046
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    task.evaluate_tags(['tag1'], [], {})
    task.evaluate_tags(['tag1', 'tag2'], [], {})
    task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    task.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag1'], {})

# Generated at 2022-06-17 08:22:15.544215
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: no tags
    t = TaggableTest([])
    assert t.evaluate_tags(only_tags=[], skip_tags=[])
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[])
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[])
    assert t.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=['all'])
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged'])

# Generated at 2022-06-17 08:22:27.123769
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    task = Task()
    task.tags = ['tag1', 'tag2']
    task.action = 'debug'
    task.args = {'msg': 'test'}
    task.set_loader(None)
    task.set_play_context(PlayContext())
    task.set_variable_manager(VariableManager())

    # Test with only_tags
    assert task.evaluate_tags(['tag1'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert task.evaluate_

# Generated at 2022-06-17 08:22:38.564107
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()

    # test_taggable.tags is None
    assert test_taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # test_taggable.tags is []
    test_taggable.tags = []
    assert test_taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # test_taggable.tags is ['tag1']
    test_taggable.tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # test_taggable.

# Generated at 2022-06-17 08:22:46.224462
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook



# Generated at 2022-06-17 08:23:25.434567
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    test_class.tags = ['tag1', 'tag2']
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True

    test_class.tags = ['tag1', 'tag3']
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True

    test_class.tags = ['tag3']
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Test with skip_tags
    only_tags = []
    skip_

# Generated at 2022-06-17 08:23:33.790458
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 08:23:43.526268
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskIncludeRole
    from ansible.playbook.role.vars import VarsRole
    from ansible.playbook.role.block import BlockRole

# Generated at 2022-06-17 08:23:55.472831
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {})

    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = []
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {})

    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {})

    only

# Generated at 2022-06-17 08:24:03.387912
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:24:08.436781
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 08:24:14.664358
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_obj = TestTaggable()

    # Test case 1: only_tags = [], skip_tags = [], tags = []
    test_obj.tags = []
    assert test_obj.evaluate_tags([], [], {}) == True

    # Test case 2: only_tags = [], skip_tags = [], tags = ['tag1']
    test_obj.tags = ['tag1']
    assert test_obj.evaluate_tags([], [], {}) == True

    # Test case 3: only_tags = [], skip_tags = [], tags = ['tag1', 'tag2']
    test_obj.tags = ['tag1', 'tag2']
    assert test_obj.evaluate_tags([], [], {}) == True

    # Test case 4:

# Generated at 2022-06-17 08:24:22.756817
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import sys
    sys.path.append("/home/vagrant/ansible/lib/ansible/playbook")
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 08:24:28.915365
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 08:24:39.342565
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    # Create a task
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=DataLoader(), sources=[]))

# Generated at 2022-06-17 08:25:53.243891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.groupvars import GroupVars

# Generated at 2022-06-17 08:26:03.026666
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_prompt import VarsPromptContext

# Generated at 2022-06-17 08:26:13.852024
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for class Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag2'], [], {}) == True

# Generated at 2022-06-17 08:26:23.253131
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:26:32.616964
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task

# Generated at 2022-06-17 08:26:44.734748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.meta import Meta

# Generated at 2022-06-17 08:26:54.607812
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_obj = TestClass()

    # Test with only_tags
    test_obj.tags = ['tag1', 'tag2']
    assert test_obj.evaluate_tags(['tag1'], [], {}) == True
    assert test_obj.evaluate_tags(['tag2'], [], {}) == True
    assert test_obj.evaluate_tags(['tag3'], [], {}) == False
    assert test_obj.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_obj.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert test_obj.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert test_obj.evaluate_tags

# Generated at 2022-06-17 08:27:02.329690
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test Task
    task = Task()
    task.tags = ['always']
    assert task.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert not task.evaluate_tags(only_tags=['never'], skip_tags=[], all_vars={})
    assert task.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert not task.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={})


# Generated at 2022-06-17 08:27:09.238506
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.only_tags = ['all']
    play_context.skip_tags = ['never']

    task = Task()
    task.tags = ['always']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == True


# Generated at 2022-06-17 08:27:22.957025
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # Test case 1:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   - tags: ['tag1', 'tag2', 'tag3']
    #   - expected: True
    task = Task()
    task.tags = ['tag1', 'tag2', 'tag3']
    context = PlayContext()
    context.only_tags = ['tag1', 'tag2']
    context.skip_tags = ['tag3', 'tag4']
    assert task.evaluate_tags(context.only_tags, context.skip_tags, {}) == True

    # Test case 2:
    #   - only_tags: ['