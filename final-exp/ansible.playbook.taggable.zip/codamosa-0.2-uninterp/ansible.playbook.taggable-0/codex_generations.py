

# Generated at 2022-06-17 08:17:38.257776
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TaggableTest(tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

    # Test with tags
    t = TaggableTest(tags=['tag1'])

# Generated at 2022-06-17 08:17:45.274335
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsFile

# Generated at 2022-06-17 08:17:53.730813
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    tt.tags = ['tag1']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:17:59.440818
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    t = Task

# Generated at 2022-06-17 08:18:10.678480
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   - only_tags: ['tag1']
    #   - skip_tags: []
    #   - tags: ['tag1']
    #   - expected: True
    only_tags = ['tag1']
    skip_tags = []
    tags = ['tag1']
    expected = True
    assert Taggable.evaluate_tags(None, only_tags, skip_tags, tags) == expected

    # Test case 2:
    #   - only_tags: ['tag1']
    #   - skip_tags: []
    #   - tags: ['tag2']
    #   - expected: False
    only_tags = ['tag1']
    skip_tags = []
    tags = ['tag2']
    expected = False

# Generated at 2022-06-17 08:18:23.353036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[])

    # Test with only_tags
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[])
    assert test_taggable.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[])
    assert test_taggable.evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[])

# Generated at 2022-06-17 08:18:32.993798
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})

    # Test with skip_tags

# Generated at 2022-06-17 08:18:46.744601
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook


# Generated at 2022-06-17 08:18:54.890820
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional

    # Test Task
    task = Task()
    task.tags = ['test_tag']
    assert task.evaluate_tags(['test_tag'], [], {})
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {})
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {})
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {})
    assert task

# Generated at 2022-06-17 08:19:03.519862
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    t = TestTaggable()

    # Test case 1
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag2'], [], {}) == True
    assert t.evaluate_tags(['tag3'], [], {}) == False
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert t.evaluate_tags(['tag3', 'tag4'], [], {}) == False

    # Test case 2
    t.tags = ['tag1', 'tag2']
    assert t

# Generated at 2022-06-17 08:19:22.316864
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()

    # Test with no tags
    tt.tags = []
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=['untagged'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['always'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=['never'], skip_tags=[]) == False

# Generated at 2022-06-17 08:19:29.578622
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups
    from ansible.vars.hostvars import HostVarsAll
    from ansible.vars.hostvars import HostVarsAllGroups
    from ansible.vars.hostvars import HostVarsAllGroupVars

# Generated at 2022-06-17 08:19:41.283098
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:19:49.719571
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:19:55.024479
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert not TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag3'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

# Generated at 2022-06-17 08:20:04.366396
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(['all'], [], {}) == True
    assert tt.evaluate_tags(['all'], ['all'], {}) == False
    assert tt.evaluate_tags(['all'], ['never'], {}) == True
    assert tt.evaluate_tags(['all'], ['tagged'], {}) == True
    assert tt.evaluate_tags(['all'], ['tagged', 'never'], {}) == True
    assert tt.evaluate_tags(['all'], ['tagged', 'always'], {}) == False
    assert tt.evaluate_tags(['all'], ['tagged', 'never', 'always'], {}) == True

# Generated at 2022-06-17 08:20:15.410317
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole

    # Test Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

# Generated at 2022-06-17 08:20:30.777662
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.cleanup_task import CleanupTask
    from ansible.playbook.pre_task import PreTask

# Generated at 2022-06-17 08:20:41.646783
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:20:51.792482
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    task = Task()
   

# Generated at 2022-06-17 08:21:19.454899
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()

    # Test with only_tags
    test_class.tags = ['test1', 'test2']
    assert test_class.evaluate_tags(['test1'], [], {}) == True
    assert test_class.evaluate_tags(['test2'], [], {}) == True
    assert test_class.evaluate_tags(['test3'], [], {}) == False
    assert test_class.evaluate_tags(['test1', 'test2'], [], {}) == True
    assert test_class.evaluate_tags(['test1', 'test3'], [], {}) == True
    assert test_class.evaluate_tags(['test3', 'test4'], [], {}) == False
    assert test_class.evaluate_tags

# Generated at 2022-06-17 08:21:30.496496
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:21:36.636462
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:21:46.657085
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency


# Generated at 2022-06-17 08:21:51.867835
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable([])
    assert t.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

    # Test with tags
    t = TestTaggable(['foo', 'bar'])

# Generated at 2022-06-17 08:22:04.027881
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_obj = TestTaggable()

    # Test 1: tags is None
    test_obj.tags = None
    assert test_obj.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test 2: only_tags is None, skip_tags is None
    test_obj.tags = ['tag1', 'tag2']
    assert test_obj.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test 3: only_tags is not None, skip_tags is None
    test_obj.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:22:15.463683
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert test_taggable.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert test_taggable.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert test_taggable.evaluate_tags(only_tags=['untagged'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-17 08:22:29.596137
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: only_tags = [], skip_tags = [], tags = []
    # Expected result: should_run = True
    tt = TestTaggable([])
    assert tt.evaluate_tags([], [], {}) == True

    # Test 2: only_tags = ['a'], skip_tags = [], tags = ['a']
    # Expected result: should_run = True
    tt = TestTaggable(['a'])
    assert tt.evaluate_tags(['a'], [], {}) == True

    # Test 3: only_tags = ['a'], skip_tags = [], tags = ['b']
    # Expected result: should_run = False


# Generated at 2022-06-17 08:22:36.974050
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import VariableManager
    from ansible.template import Templar

    # Test for Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = ['tag2']
    all

# Generated at 2022-06-17 08:22:43.122186
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self):
            self.tags = []

    taggable = TaggableTest()

    # Test with no tags
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    taggable.tags = ['tag1']
    assert taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not taggable.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})

    # Test with skip_tags
    assert not taggable.evaluate_tags(only_tags=[], skip_tags=['tag1'], all_vars={})
    assert tag

# Generated at 2022-06-17 08:23:17.508433
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # test task
    task = Task()
    task.tags = ['tag1', 'tag2']
    task.evaluate_tags(['tag1'], [], {})
    task.evaluate_tags(['tag1', 'tag2'], [], {})
    task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    task.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag1'], {})

# Generated at 2022-06-17 08:23:30.307105
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    # Test with tags = ['tag1', 'tag2']
    mock_taggable = MockTaggable(['tag1', 'tag2'])
    assert mock_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test with tags = ['tag1']
    mock_taggable = MockTaggable(['tag1'])
    assert mock_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True
    # Test with tags = ['tag2']

# Generated at 2022-06-17 08:23:42.011221
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:23:53.382924
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    # Test 1: no tags
    t = TestTaggable()
    assert t.evaluate_tags(None, None, None) == True

    # Test 2: only_tags = [], skip_tags = []
    t = TestTaggable()
    t.tags = ['tag1']
    assert t.evaluate_tags([], [], None) == True

    # Test 3: only_tags = ['tag1'], skip_tags = []
    t = TestTaggable()
    t.tags = ['tag1']
    assert t.evaluate_tags(['tag1'], [], None) == True

    # Test 4: only_tags = ['tag1'], skip_tags = ['tag1']

# Generated at 2022-06-17 08:24:01.954509
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    # Test case 1:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   -

# Generated at 2022-06-17 08:24:07.524738
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency


# Generated at 2022-06-17 08:24:17.260251
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

# Generated at 2022-06-17 08:24:29.607459
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.handler_include import RoleHandlerInclude

# Generated at 2022-06-17 08:24:44.251046
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude

    # Test for Block
    block = Block()
    block.tags = ['tag1', 'tag2']
    assert block.evaluate_tags(['tag1'], [], {}) == True
    assert block.evaluate_tags(['tag2'], [], {}) == True

# Generated at 2022-06-17 08:24:49.554937
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context with only_tags and skip_tags
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()

    # Check if the task should run
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == True

    # Create a task with tags
    task = Task()
    task.tags

# Generated at 2022-06-17 08:26:01.976752
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars

# Generated at 2022-06-17 08:26:15.885091
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test tags
    tags = ['tag1', 'tag2', 'tag3']

    # Test only_tags
    only_tags = ['tag1', 'tag2']
    assert TestTaggable(tags).evaluate_tags(only_tags, [], {})
    only_tags = ['tag1', 'tag2', 'tag4']
    assert TestTaggable(tags).evaluate_tags(only_tags, [], {})
    only_tags = ['tag1', 'tag2', 'tag3']
    assert TestTaggable(tags).evaluate_tags(only_tags, [], {})
    only_tags = ['tag1', 'tag2', 'tag3', 'tag4']
    assert Test

# Generated at 2022-06-17 08:26:29.818040
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.play
    import ansible.playbook.include
    import ansible.playbook.include_role
    import ansible.playbook.import_role
    import ansible.playbook.import_playbook
    import ansible.playbook.vars
    import ansible.playbook.vars_prompt
    import ansible.playbook.vars_files

    # test for task
    task = ansible.playbook.task.Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {})
    assert not task

# Generated at 2022-06-17 08:26:35.663479
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:26:47.946247
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    fake_taggable = FakeTaggable(None)
    assert fake_taggable.evaluate_tags(None, None, None) == True

    # Test with only_tags
    fake_taggable = FakeTaggable(['tag1', 'tag2'])
    assert fake_taggable.evaluate_tags(['tag1'], None, None) == True
    assert fake_taggable.evaluate_tags(['tag2'], None, None) == True
    assert fake_taggable.evaluate_tags(['tag3'], None, None) == False

# Generated at 2022-06-17 08:26:57.224356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import Become

# Generated at 2022-06-17 08:27:07.202127
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars

# Generated at 2022-06-17 08:27:20.078264
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tagged']
    play_context.skip_tags = ['never']

    task = Task()
    task.tags = ['tagged']