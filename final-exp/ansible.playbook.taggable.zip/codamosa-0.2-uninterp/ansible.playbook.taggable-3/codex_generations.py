

# Generated at 2022-06-17 08:17:43.912787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.task_include import RoleTaskInclude

# Generated at 2022-06-17 08:17:51.642834
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test with only_tags
    assert TestClass(['tag1']).evaluate_tags(['tag1'], [], {})
    assert TestClass(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert TestClass(['tag1', 'tag2']).evaluate_tags(['tag2'], [], {})
    assert TestClass(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestClass(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})

# Generated at 2022-06-17 08:18:01.148740
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_dependency import Task

# Generated at 2022-06-17 08:18:08.908775
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags: ['all', 'tagged']
    #   skip_tags: ['never']
    #   tags: ['always']
    #   expected: True
    only_tags = ['all', 'tagged']
    skip_tags = ['never']
    tags = ['always']
    expected = True
    assert Taggable().evaluate_tags(only_tags, skip_tags, tags) == expected

    # Test case 2:
    #   only_tags: ['all', 'tagged']
    #   skip_tags: ['never']
    #   tags: ['never']
    #   expected: False
    only_tags = ['all', 'tagged']
    skip_tags = ['never']
    tags = ['never']
    expected = False

# Generated at 2022-06-17 08:18:22.657410
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.include import Include
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks

# Generated at 2022-06-17 08:18:32.804136
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_

# Generated at 2022-06-17 08:18:46.570467
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.taggable import Taggable

    # Test Taggable class
    class TestTaggable(Taggable):
        pass

    #

# Generated at 2022-06-17 08:18:54.721961
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['all', 'tagged'], skip_tags=[], all_vars={})
    assert not t.evaluate_tags(only_tags=['never'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:19:03.487793
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.debugger import Debugger
    from ansible.playbook.meta import Meta

# Generated at 2022-06-17 08:19:12.418703
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    play_context.tags = ['tag5', 'tag6']
    play_context.set_options()
    task = Task()
    task._play_context = play_context
   

# Generated at 2022-06-17 08:19:33.228186
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:19:41.380135
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.become import Become

# Generated at 2022-06-17 08:19:49.795717
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag1'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2', 'tag3'], all_vars={}) == False

# Generated at 2022-06-17 08:19:55.166643
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debug import Debug
   

# Generated at 2022-06-17 08:20:04.403434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a mock Taggable object
    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Create a mock loader object
    class MockLoader:
        def __init__(self):
            pass

    # Create a mock variable manager object
    class MockVariableManager:
        def __init__(self):
            pass

    # Create a mock inventory object
    class MockInventory:
        def __init__(self):
            pass

    # Create a mock play object
    class MockPlay:
        def __init__(self, tags):
            self.tags = tags

    # Create a mock task object
    class MockTask(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Create a mock block object

# Generated at 2022-06-17 08:20:15.411150
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag1', 'tag2']
    #   expected = True
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    tags = ['tag1', 'tag2']
    expected = True
    assert Taggable().evaluate_tags(only_tags, skip_tags, tags) == expected

    # Test case 2:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag1', 'tag2', 'tag3']
    #   expected = True

# Generated at 2022-06-17 08:20:30.738694
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2']

    t = TaggableTest()
    assert t.evaluate_tags(['tag1'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert t.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert t.evaluate_tags(['tag3', 'tag4'], ['tag2'], {}) == False
    assert t.evaluate_tags(['tag3', 'tag4'], ['tag1'], {}) == False

# Generated at 2022-06-17 08:20:41.646546
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=['tagged']) == False

# Generated at 2022-06-17 08:20:51.793134
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:21:03.764501
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:21:31.713659
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.async_task import AsyncTask


# Generated at 2022-06-17 08:21:38.642434
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:21:48.871929
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.block import RoleBlock
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:21:59.866030
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.block_include import BlockInclude
    from ansible.playbook.role.handler_include import HandlerInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks


# Generated at 2022-06-17 08:22:06.898362
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable([])
    assert tt.evaluate_tags(['all'], [], {}) == True
    assert tt.evaluate_tags(['all'], ['all'], {}) == False
    assert tt.evaluate_tags(['all'], ['never'], {}) == True
    assert tt.evaluate_tags(['all'], ['tagged'], {}) == True
    assert tt.evaluate_tags(['all'], ['untagged'], {}) == True
    assert tt.evaluate_tags(['all'], ['foo'], {}) == True

# Generated at 2022-06-17 08:22:18.740273
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.blockvars import BlockVars
    from ansible.playbook.vars.rolevars import RoleVars
   

# Generated at 2022-06-17 08:22:29.630861
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {})

# Generated at 2022-06-17 08:22:37.012340
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.unittest.case import AnsiblePlaybookTestCase


# Generated at 2022-06-17 08:22:43.151564
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:22:51.673200
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag3'], [], {}) == False
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag3'], [], {})
   

# Generated at 2022-06-17 08:23:29.217211
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(None)
    assert t.evaluate_tags(None, None, None) == True
    assert t.evaluate_tags(['all'], None, None) == True
    assert t.evaluate_tags(['tagged'], None, None) == False
    assert t.evaluate_tags(['untagged'], None, None) == True
    assert t.evaluate_tags(['foo'], None, None) == False
    assert t.evaluate_tags(['foo', 'bar'], None, None) == False
    assert t.evaluate_tags(['foo', 'bar', 'untagged'], None, None) == True

# Generated at 2022-06-17 08:23:41.935085
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude


# Generated at 2022-06-17 08:23:46.886081
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.task_include import TaskIncludeRole
    from ansible.playbook.role.block import BlockRole
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.task_override import TaskOverride
    from ansible.playbook.role.defaults import Role

# Generated at 2022-06-17 08:23:56.186866
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=[])
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[])
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=['all'])
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged'])
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['all'])

# Generated at 2022-06-17 08:24:03.885635
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

    # test for

# Generated at 2022-06-17 08:24:11.660279
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a block with tags
    block = Block()
    block.tags = ['tag1', 'tag2']

    # Create a role with tags
    role = Role()
    role.tags = ['tag1', 'tag2']

    # Create a play with tags
    play = Play()
    play.tags = ['tag1', 'tag2']

    # Create a playbook with tags
    playbook = Playbook()

# Generated at 2022-06-17 08:24:24.094989
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 08:24:31.665119
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self):
            self._tags = []

    taggable = FakeTaggable()
    taggable.tags = ['tag1', 'tag2']
    assert taggable.evaluate_tags(['tag1'], [], {})
    assert not taggable.evaluate_tags(['tag3'], [], {})
    assert taggable.evaluate_tags([], ['tag1'], {})
    assert not taggable.evaluate_tags([], ['tag2'], {})
    assert taggable.evaluate_tags(['tag1'], ['tag2'], {})
    assert not taggable.evaluate_tags(['tag2'], ['tag1'], {})

# Generated at 2022-06-17 08:24:45.170763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus

# Generated at 2022-06-17 08:24:53.914993
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:26:03.561540
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with empty tags
    tt = TestTaggable([])
    assert tt.evaluate_tags(['all'], [], {}) == True
    assert tt.evaluate_tags(['all'], ['never'], {}) == True
    assert tt.evaluate_tags(['all'], ['tagged'], {}) == True
    assert tt.evaluate_tags(['all'], ['untagged'], {}) == True
    assert tt.evaluate_tags(['all'], ['always'], {}) == True
    assert tt.evaluate_tags(['all'], ['never', 'tagged', 'untagged', 'always'], {}) == True
    assert tt.evaluate_tags

# Generated at 2022-06-17 08:26:16.067883
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1'], ['tag2'], {})

# Generated at 2022-06-17 08:26:29.909967
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    tt.tags = ['tag1']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:26:39.493674
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()

    # Test case 1: only_tags = ['tag1', 'tag2'], skip_tags = [], tags = ['tag1', 'tag2']
    # Expected result: True
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    tags = ['tag1', 'tag2']
    test_taggable.tags = tags
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == True

    # Test case 2: only_tags = ['tag1', 'tag2'], skip_tags = [], tags = ['tag1', 'tag3']
    # Expected result: True
    only_tags = ['tag1', 'tag2']


# Generated at 2022-06-17 08:26:51.304031
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    tt = TestTaggable(['foo', 'bar'])
    assert tt.evaluate_tags(['foo'], [], {})
    assert not tt.evaluate_tags(['baz'], [], {})
    assert tt.evaluate_tags(['all'], [], {})
    assert tt.evaluate_tags(['tagged'], [], {})
    assert not tt.evaluate_tags(['never'], [], {})
    assert tt.evaluate_tags(['always'], [], {})
    assert not tt.evaluate_tags(['never', 'always'], [], {})

    # Test with skip_tags
    t

# Generated at 2022-06-17 08:27:03.299684
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}

    # Test with tags=['tag1']
    tt = TestTaggable(['tag1'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags=['tag2']
    tt = TestTaggable(['tag2'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags=['tag3']
    tt = TestTaggable(['tag3'])
    assert tt

# Generated at 2022-06-17 08:27:13.760314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()
    assert t.evaluate_tags(['all'], [], {})
    assert t.evaluate_tags(['all'], ['all'], {})
    assert t.evaluate_tags(['all'], ['never'], {})
    assert t.evaluate_tags(['all'], ['tagged'], {})
    assert t.evaluate_tags(['all'], ['untagged'], {})
    assert t.evaluate_tags(['all'], ['always'], {})
    assert t.evaluate_tags(['all'], ['always', 'never'], {})
    assert t.evaluate_tags(['all'], ['always', 'tagged'], {})
    assert t

# Generated at 2022-06-17 08:27:24.974376
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    task = Task()
   