

# Generated at 2022-06-17 08:17:40.103129
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Test Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1'], ['tag2'], {}) == True

# Generated at 2022-06-17 08:17:51.058891
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for class Task
    task = Task()

# Generated at 2022-06-17 08:18:00.745780
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(tags=[])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

    # Test with tags
    tt = TestTaggable(tags=['foo'])
    assert t

# Generated at 2022-06-17 08:18:11.630090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(tags=['always']).evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['always']).evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['always']).evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['always']).evaluate_tags(only_tags=['always', 'all'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:18:22.398356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test with only_tags
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    t.tags = ['tag1']
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-17 08:18:32.713014
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test with only_tags
    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']
    assert test_taggable.evaluate_tags(['tag1'], [], {})
    assert not test_taggable.evaluate_tags(['tag3'], [], {})
    assert test_taggable.evaluate_tags(['tag1', 'tag2'], [], {})
    assert test_taggable.evaluate_tags(['tag1', 'tag3'], [], {})
    assert test_taggable.evaluate_tags(['tag3', 'tag4'], [], {})

# Generated at 2022-06-17 08:18:46.480027
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

# Generated at 2022-06-17 08:18:55.745586
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Test case 1:
    #   - only_tags: ['tag1', 'tag2']
    #   - skip_tags: ['tag3', 'tag4']
    #   - tags: ['tag1', 'tag2', 'tag3']
    #   - expected: True
    #   - reason: 'tag1' and 'tag2' are in only_tags and 'tag3' is in tags
    #             'tag3' is in tags and 'tag4' is in skip_tags
    #             'tag3' is in tags and 'tag3' is in skip_tags
    #             'tag3' is in tags and 'tag4' is in skip_tags

# Generated at 2022-06-17 08:19:08.807779
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:19:17.562393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vault import VaultSecret
    from ansible.playbook.role_dependency import RoleDependency

    # test Taggable class
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test Task class

# Generated at 2022-06-17 08:19:34.988554
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    task = Task()
    task.tags = ['tag1']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == True


# Generated at 2022-06-17 08:19:42.317708
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task

    # Test with no tags
    t = Task()
    assert t.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None)

    # Test with only_tags
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars=None)
    assert not t.evaluate_tags(only_tags=['tag3'], skip_tags=None, all_vars=None)

    # Test with skip_tags
    t = Task()
    t.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:19:49.744220
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']

    task = Task()
    task._variable_manager = variable_manager
    task._play_context = play_context

    # Test case 1: task with no tags
    assert task

# Generated at 2022-06-17 08:19:55.110962
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_dependency import TaskD

# Generated at 2022-06-17 08:20:08.406859
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['always']
    assert task.evaluate_tags(['always'], [], {}) == True
    assert task.evaluate_tags(['always'], ['always'], {}) == False

# Generated at 2022-06-17 08:20:19.927381
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test for only_tags
    # Test for 'all' in only_tags
    assert TaggableTest(tags=['all']).evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert TaggableTest(tags=['all']).evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert TaggableTest(tags=['all', 'test']).evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:20:31.683276
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:20:38.328905
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_obj = TestTaggable()
    test_obj.tags = ['test_tag']
    assert test_obj.evaluate_tags(only_tags=['test_tag'], skip_tags=[], all_vars={})
    assert not test_obj.evaluate_tags(only_tags=['test_tag'], skip_tags=['test_tag'], all_vars={})
    assert test_obj.evaluate_tags(only_tags=['test_tag'], skip_tags=['test_tag2'], all_vars={})
    assert test_obj.evaluate_tags(only_tags=['test_tag2'], skip_tags=['test_tag'], all_vars={})

# Generated at 2022-06-17 08:20:48.633439
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        def __init__(self, tags=None):
            self.tags = tags

    # Test with no tags
    my_taggable = MyTaggable()
    assert my_taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={})
    assert my_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert my_taggable.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert my_taggable.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:20:55.830390
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    play_context.tags = ['tag3']
    play_context.set_options()
    task = Task()
    task.tags = ['tag1']

# Generated at 2022-06-17 08:21:20.271178
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {})

# Generated at 2022-06-17 08:21:27.729738
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsFile

# Generated at 2022-06-17 08:21:33.973921
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block

# Generated at 2022-06-17 08:21:39.389251
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    task = Task()
    task.tags = ['tag1']
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == True


# Generated at 2022-06-17 08:21:49.459745
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_plugin import VarsModule
    from ansible.playbook.vars_plugin import VarsInline
    from ansible.playbook.vars_plugin import VarsFile
    from ansible.playbook.vars_plugin import V

# Generated at 2022-06-17 08:21:59.923576
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:22:06.951660
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags

# Generated at 2022-06-17 08:22:18.739903
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a role with tags
    role = Role()
    role.tags = ['tag1', 'tag2']

    # Create a block with tags
    block = Block()
    block.tags = ['tag1', 'tag2']

    # Create a play with tags
    play = Play()
    play.tags = ['tag1', 'tag2']

    # Create a playbook with tags
    playbook = Playbook()

# Generated at 2022-06-17 08:22:30.740097
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:22:37.722710
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context with only_tags and skip_tags
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()

    # Test evaluate_tags
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == False

    # Change the play context
    play_context.only_tags = ['tag2']

# Generated at 2022-06-17 08:23:14.629495
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:23:25.757197
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test case 1: only_tags is None and skip_tags is None
    assert test_taggable.evaluate_tags(only_tags=None, skip_tags=None, all_vars={}) == True

    # Test case 2: only_tags is not None and skip_tags is None
    assert test_taggable.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=None, all_vars={}) == False

    # Test case 3: only_tags is None and skip_tags is not None

# Generated at 2022-06-17 08:23:33.258509
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2']

    t = TestTaggable()
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag2'], [], {}) == True
    assert t.evaluate_tags(['tag3'], [], {}) == False
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert t.evaluate_tags(['tag3', 'tag4'], [], {}) == False

# Generated at 2022-06-17 08:23:41.116636
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None

    # Test for Task
    task = Task()

# Generated at 2022-06-17 08:23:52.223432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert not tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    tt.tags = ['foo']
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['bar'], skip_tags=[], all_vars={})
    tt.tags = ['foo', 'bar']
    assert tt.evaluate_tags

# Generated at 2022-06-17 08:24:00.984477
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_obj = TestTaggable()

    # Test with no tags
    assert test_obj.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test with only_tags
    assert test_obj.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert test_obj.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) == False
    assert test_obj.evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[], all_vars={}) == False
    assert test_obj

# Generated at 2022-06-17 08:24:10.834785
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:24:23.442170
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[]) == True

    # Test with only_tags
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == False
    test_taggable.tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == True
    assert test_taggable.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[]) == True

# Generated at 2022-06-17 08:24:31.322036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._tqm = None
    task._loader = loader
    task._play_context = play_context

    # Test with only_tags
    task.tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags

# Generated at 2022-06-17 08:24:45.078066
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:25:58.462777
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:26:02.272920
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class TestTask(Task, Taggable):
        pass

    class TestPlayContext(PlayContext):
        pass

    class TestVariableManager(VariableManager):
        pass

    class TestInventoryManager(InventoryManager):
        pass

    class TestDataLoader(DataLoader):
        pass

    loader = TestDataLoader()
    inventory = TestInventoryManager(loader=loader)
    variable_manager = TestVariableManager(loader=loader, inventory=inventory)
    play_context = TestPlay

# Generated at 2022-06-17 08:26:13.472500
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TaggableTest(['tag1']).evaluate_tags(['tag1'], [], {})
    assert TaggableTest(['tag1']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

# Generated at 2022-06-17 08:26:23.024151
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:26:31.679861
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:26:43.476394
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = FakeTaggable(None)
    assert t.evaluate_tags(None, None, None) == True
    assert t.evaluate_tags(['all'], None, None) == True
    assert t.evaluate_tags(None, ['all'], None) == True
    assert t.evaluate_tags(['all'], ['all'], None) == True

    # Test with tags
    t = FakeTaggable(['tag1', 'tag2'])
    assert t.evaluate_tags(None, None, None) == True
    assert t.evaluate_tags(['all'], None, None) == True

# Generated at 2022-06-17 08:26:53.777171
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.meta import Meta

# Generated at 2022-06-17 08:27:05.165254
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TaggableTest(['test']).evaluate_tags(['test'], [], {}) == True
    assert TaggableTest(['test']).evaluate_tags(['test', 'test2'], [], {}) == True
    assert TaggableTest(['test']).evaluate_tags(['test2'], [], {}) == False
    assert TaggableTest(['test']).evaluate_tags(['all'], [], {}) == True
    assert TaggableTest(['test']).evaluate_tags(['tagged'], [], {}) == True
    assert TaggableTest(['test']).evaluate_tags(['always'], [], {}) == True

# Generated at 2022-06-17 08:27:13.890439
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:27:25.078185
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
