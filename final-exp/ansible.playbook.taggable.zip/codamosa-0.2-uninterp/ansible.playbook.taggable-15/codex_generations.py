

# Generated at 2022-06-17 08:17:39.069004
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags

# Generated at 2022-06-17 08:17:45.782042
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:17:53.823371
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable([])
    assert t.evaluate_tags(['all'], [], {}) == True
    assert t.evaluate_tags(['all'], ['all'], {}) == False
    assert t.evaluate_tags(['all'], ['tagged'], {}) == True
    assert t.evaluate_tags(['all'], ['never'], {}) == True
    assert t.evaluate_tags(['all'], ['always'], {}) == True
    assert t.evaluate_tags(['all'], ['never', 'always'], {}) == True

# Generated at 2022-06-17 08:17:59.488571
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.role_include import RoleInclude


# Generated at 2022-06-17 08:18:10.723622
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:18:23.401558
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.loop import Loop
    from ansible.playbook.task.when import When
    from ansible.playbook.task.include import Include

# Generated at 2022-06-17 08:18:33.019350
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={}) == False

# Generated at 2022-06-17 08:18:46.786711
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.block import BlockTask
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.block import BlockTask

# Generated at 2022-06-17 08:18:57.199488
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag3'], [], {}) == False
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TestTaggable(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag3'], [], {})
   

# Generated at 2022-06-17 08:19:04.896053
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:19:22.916931
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    task = Task()
    task.tags = ['tag1']
    task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars())
    assert task

# Generated at 2022-06-17 08:19:33.803289
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsFile
    from ansible.playbook.vars_files import VarsInclude


# Generated at 2022-06-17 08:19:41.585274
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block_include import BlockInclude

# Generated at 2022-06-17 08:19:49.391958
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude

    # Test Task

# Generated at 2022-06-17 08:19:55.947490
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:20:04.609361
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    # Test with only_tags
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:20:16.966136
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(None)
    assert t.evaluate_tags(None, None, None)
    assert t.evaluate_tags(['all'], None, None)
    assert t.evaluate_tags(['tagged'], None, None)
    assert t.evaluate_tags(['always'], None, None)
    assert t.evaluate_tags(['never'], None, None)
    assert t.evaluate_tags(['foo'], None, None)
    assert t.evaluate_tags(['foo', 'bar'], None, None)
    assert t.evaluate_tags(['foo', 'bar', 'baz'], None, None)
    assert t.evaluate_

# Generated at 2022-06-17 08:20:23.560463
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars

# Generated at 2022-06-17 08:20:32.791019
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(None)
    assert t.evaluate_tags(None, None, None) == True
    assert t.evaluate_tags(['all'], None, None) == True
    assert t.evaluate_tags(None, ['all'], None) == True
    assert t.evaluate_tags(['all'], ['all'], None) == True
    assert t.evaluate_tags(['tagged'], None, None) == True
    assert t.evaluate_tags(None, ['tagged'], None) == True
    assert t.evaluate_tags(['tagged'], ['tagged'], None) == True

# Generated at 2022-06-17 08:20:45.424610
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'tags': ['tag1', 'tag2']}

    # Create

# Generated at 2022-06-17 08:21:06.301748
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_tags(['tag1'], [], {})
    assert not tt.evaluate_tags(['tag3'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert tt.evaluate_tags(['tag1', 'tag2', 'tag3', 'tag4'], [], {})

# Generated at 2022-06-17 08:21:18.784881
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()

    # Test with only_tags
    test_class.tags = ['tag1', 'tag2']
    assert test_class.evaluate_tags(['tag1'], [], {}) == True
    assert test_class.evaluate_tags(['tag2'], [], {}) == True
    assert test_class.evaluate_tags(['tag3'], [], {}) == False
    assert test_class.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_class.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert test_class.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert test_class.evaluate_tags

# Generated at 2022-06-17 08:21:30.452740
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    # Test case 1:
    #   - only_tags: ['test']
    #   - skip_tags: []
    #   - tags: ['test']
    #   - should_

# Generated at 2022-06-17 08:21:41.492394
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role

    class MyTaggable(Taggable):
        pass

    class MyTask(Task):
        pass

    class MyRole(Role):
        pass

    class MyPlay(Play):
        pass

    class MyBlock(Block):
        pass

    class MyHandler(Handler):
        pass

    class MyInclude(Include):
        pass

    # Test Task
    t = MyTask()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_

# Generated at 2022-06-17 08:21:53.079032
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:22:04.610527
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False

# Generated at 2022-06-17 08:22:15.492901
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger


# Generated at 2022-06-17 08:22:26.882253
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:22:38.374482
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['tag3']
    skip_tags = []
    all_vars = {}
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False

    # Test with skip_tags
    only_tags = []
    skip_tags = ['tag1']
    all_vars = {}
    assert test_tagg

# Generated at 2022-06-17 08:22:46.065693
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    tt = TestTaggable(['foo', 'bar'])
    assert tt.evaluate_tags(['foo'], [], {})
    assert not tt.evaluate_tags(['baz'], [], {})
    assert tt.evaluate_tags(['all'], [], {})
    assert tt.evaluate_tags(['tagged'], [], {})
    assert tt.evaluate_tags(['always'], [], {})
    assert not tt.evaluate_tags(['never'], [], {})

    # Test with skip_tags
    tt = TestTaggable(['foo', 'bar'])
    assert tt.evaluate_

# Generated at 2022-06-17 08:23:25.433935
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test for only_tags
    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = []
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == True

    test_taggable.tags = ['tag1', 'tag2']
    only_tags = ['tag3']
    skip_tags = []
    assert test_taggable.evaluate_tags(only_tags, skip_tags, {}) == False

    test_taggable.tags = ['tag1', 'tag2']
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    assert test_

# Generated at 2022-06-17 08:23:33.251275
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._tags = []

    t = TestTaggable()
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags

# Generated at 2022-06-17 08:23:43.250012
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 08:23:55.474249
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    tt = TestTaggable()

    # Test case 1: only_tags = [], skip_tags = []
    # Expected result: should_run = True
    only_tags = []
    skip_tags = []
    all_vars = {}
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test case 2: only_tags = ['tag1'], skip_tags = []
    # Expected result: should_run = True
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    tt.tags = ['tag1']
    assert tt.evaluate_tags

# Generated at 2022-06-17 08:24:02.571945
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    t = TestTaggable()
    t.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['tag3']
    skip_tags = []
    assert not t.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['tag1', 'tag2']
    skip_tags = []
    assert t.evaluate_tags(only_tags, skip_tags, all_vars)

    only_tags = ['tag1', 'tag2', 'tag3']

# Generated at 2022-06-17 08:24:08.851423
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency


# Generated at 2022-06-17 08:24:19.156281
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-17 08:24:29.994715
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self):
            self.tags = []

    test_obj = TestClass()

    # Test case 1: only_tags = ['all'], skip_tags = ['never'], tags = ['always']
    # Expected result: True
    only_tags = ['all']
    skip_tags = ['never']
    test_obj.tags = ['always']
    assert test_obj.evaluate_tags(only_tags, skip_tags, {})

    # Test case 2: only_tags = ['all'], skip_tags = ['never'], tags = ['never']
    # Expected result: False
    only_tags = ['all']
    skip_tags = ['never']
    test_obj.tags = ['never']

# Generated at 2022-06-17 08:24:44.249906
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt

# Generated at 2022-06-17 08:24:53.224206
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags([], ['tag1'], {}) == False


# Generated at 2022-06-17 08:26:01.239308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert not t.evaluate_tags(['tag3'], [], {})
    assert not t.evaluate_tags(['tag3', 'tag4'], [], {})
    assert t

# Generated at 2022-06-17 08:26:15.836314
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for class Task
    task = Task()

# Generated at 2022-06-17 08:26:29.786305
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:26:39.355821
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import VariableManager
    from ansible.playbook.role.include import RoleInclude

    # Test for class Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag2'], [], {}) == True

# Generated at 2022-06-17 08:26:51.193089
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:27:01.610288
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.blockvars import BlockVars

# Generated at 2022-06-17 08:27:08.867969
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # Create a task
    task = Task()
    task._role = None
    task._block = None
    task._play = None
    task._loader = None
    task._variable_manager = None
    task._task_vars = dict()
    task._task_vars['ansible_version'] = dict()
    task._task_vars['ansible_version']['full'] = '2.0.0.0'
    task._task_vars['ansible_version']['major'] = 2
    task._task_vars['ansible_version']['minor'] = 0
    task._task_vars['ansible_version']['revision'] = 0
    task._task_

# Generated at 2022-06-17 08:27:22.686327
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars