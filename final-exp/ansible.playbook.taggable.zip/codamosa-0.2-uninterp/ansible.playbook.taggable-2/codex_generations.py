

# Generated at 2022-06-17 08:17:39.016404
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()
    test_class.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['tag3']
    skip_tags = []
    all_vars = {}
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == False

    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}

# Generated at 2022-06-17 08:17:48.866924
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:17:57.839540
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    def _get_templar(loader, play_context):
        return Templar(loader=loader, variables=play_context.get_vars())

    # Test for class Task
    task = Task()
    task.tags = ['always']

# Generated at 2022-06-17 08:18:09.715763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task.tags = ['tag1', 'tag2']

    # Test with no tags
    play_context = PlayContext()
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict())

    # Test with only_tags
    play_context = PlayContext(only_tags=['tag1'])
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict())

    play_context = PlayContext(only_tags=['tag3'])
    assert not task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict())


# Generated at 2022-06-17 08:18:16.664408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable([])
    assert t.evaluate_tags(['all'], [], {}) == True
    assert t.evaluate_tags(['all'], ['all'], {}) == False
    assert t.evaluate_tags(['all'], ['tagged'], {}) == False
    assert t.evaluate_tags(['all'], ['never'], {}) == True
    assert t.evaluate_tags(['all'], ['always'], {}) == True
    assert t.evaluate_tags(['tagged'], ['all'], {}) == False
    assert t.evaluate_tags(['tagged'], ['tagged'], {}) == False
    assert t

# Generated at 2022-06-17 08:18:30.293368
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Task()
    t._loader = None
    t.tags = ['tag1', 'tag2']
    t.only_tags = ['tag1']
    t.skip_tags = ['tag2']
    t.all_vars = dict()

    assert t.evaluate_tags(t.only_tags, t.skip_tags, t.all_vars) == True

    t.only_tags = ['tag2']
    t.skip_tags = ['tag1']

    assert t.evaluate_tags(t.only_tags, t.skip_tags, t.all_vars) == False

    t.only_tags = ['tag1']
    t.skip_tags = ['tag2']


# Generated at 2022-06-17 08:18:43.157626
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:18:54.958190
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_path import RolePath


# Generated at 2022-06-17 08:19:08.720446
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsIn

# Generated at 2022-06-17 08:19:13.714334
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars

# Generated at 2022-06-17 08:19:33.259973
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    # Test for Task
    task = Task()
    task.tags = ['always', 'test']
    assert task.evaluate_tags(['always', 'test'], [], {})
    assert not task.evaluate_tags(['never', 'test'], [], {})
    assert task.evaluate_tags(['tagged'], [], {})
    assert not task.evaluate_tags(['never'], [], {})
    assert task.evaluate_tags(['all'], [], {})
    assert not task.evaluate_tags(['all'], ['never'], {})

# Generated at 2022-06-17 08:19:41.407601
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1', 'tag2', 'tag3'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_

# Generated at 2022-06-17 08:19:49.833965
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test with only_tags
    test_taggable = TestTaggable()
    test_taggable.tags = ['always']
    assert test_taggable.evaluate_tags(['always'], [], {})
    assert test_taggable.evaluate_tags(['all'], [], {})
    assert test_taggable.evaluate_tags(['tagged'], [], {})
    assert test_taggable.evaluate_tags(['always', 'tagged'], [], {})
    assert test_taggable.evaluate_tags(['always', 'all'], [], {})
    assert test_taggable.evaluate_tags(['always', 'tagged', 'all'], [], {})

# Generated at 2022-06-17 08:19:55.218281
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block_include import BlockInclude

# Generated at 2022-06-17 08:20:08.452640
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == True

# Generated at 2022-06-17 08:20:19.958894
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    task = Task()
    task._role = None
    task._block = None
    task._play = None
    task._loader = None
    task._variable_manager = variable_manager
    task._task_vars = dict()
    task._task_vars['ansible_tags'] = ['all']
    task._task_vars['ansible_skip_tags'] = ['all']
    task._task_vars['ansible_only_tags'] = ['all']
    task._task_vars['ansible_tags'] = ['all']

# Generated at 2022-06-17 08:20:31.719977
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsFile
    from ansible.playbook.vars_files import VarsInclude


# Generated at 2022-06-17 08:20:38.348109
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsFile

# Generated at 2022-06-17 08:20:48.634574
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
            self._loader = None
    # Test 1
    # only_tags = ['tag1', 'tag2']
    # skip_tags = ['tag3', 'tag4']
    # tags = ['tag1', 'tag2', 'tag5']
    # should_run = True
    t = TestTaggable(['tag1', 'tag2', 'tag5'])
    assert t.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], {}) == True
    # Test 2
    # only_tags = ['tag1', 'tag2']
    # skip_tags = ['tag3', 'tag4']
    # tags = ['tag5']
    # should_run

# Generated at 2022-06-17 08:20:55.817141
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.debugger import Debugger

    # Test for class Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
   

# Generated at 2022-06-17 08:21:19.996515
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile

    # Create a task
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a block
    block = Block()
    block.tags = ['tag1', 'tag2']

    # Create a role
    role = Role()
    role.tags = ['tag1', 'tag2']

    # Create a play
    play = Play()

# Generated at 2022-06-17 08:21:30.530228
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:21:36.544988
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    # Test for tags
    task.tags = ['test']
    assert task.evaluate_tags(only_tags=['test'], skip_tags=[], all_vars={}) == True


# Generated at 2022-06-17 08:21:42.552948
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:21:53.827044
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:22:04.889473
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Create a fake class that inherits from Taggable
    class FakeTaggable(Taggable):
        pass

    # Create a fake object of class FakeTaggable
    fake_taggable = FakeTaggable()

    # Test with no tags
    fake_taggable.tags = []
    assert fake_taggable.evaluate_tags(only_tags=[], skip_tags=[]) == True

    # Test with only_tags
    fake_taggable.tags = []
    assert fake_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == False
    fake_taggable.tags = ['tag1']
    assert fake_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == True

# Generated at 2022-06-17 08:22:15.520357
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:22:26.917921
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})

    # Test with skip_tags
    tt = TestTaggable()

# Generated at 2022-06-17 08:22:38.374562
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags

# Generated at 2022-06-17 08:22:46.065908
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.vars import VariableManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostV

# Generated at 2022-06-17 08:23:25.433620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_context import TaskContext

# Generated at 2022-06-17 08:23:33.251629
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert not tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={})
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:23:43.248678
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}

    # Test with tags = ['tag1', 'tag2']
    test_tags = ['tag1', 'tag2']
    test_taggable = TestTaggable(test_tags)
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags = ['tag1', 'tag2', 'tag3']
    test_tags = ['tag1', 'tag2', 'tag3']
    test_taggable = TestTaggable(test_tags)
    assert test_

# Generated at 2022-06-17 08:23:53.500677
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:24:02.054351
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    tt = TestTaggable(['always'])
    assert tt.evaluate_tags(['always'], [], {}) == True
    tt = TestTaggable(['always'])
    assert tt.evaluate_tags(['always', 'tagged'], [], {}) == True
    tt = TestTaggable(['always'])
    assert tt.evaluate_tags(['tagged'], [], {}) == True
    tt = TestTaggable(['always'])
    assert tt.evaluate_tags(['all'], [], {}) == True
    tt = TestTaggable(['always'])
    assert tt.evaluate

# Generated at 2022-06-17 08:24:07.587926
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

# Generated at 2022-06-17 08:24:17.320541
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.vars import VariableManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 08:24:29.607224
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:24:44.250517
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsFile


# Generated at 2022-06-17 08:24:49.749129
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=dict())
    variable

# Generated at 2022-06-17 08:25:53.175052
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:26:02.999531
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag1', 'tag2']
    task.skip_tags = ['tag3', 'tag4']
    assert task.evaluate_tags(task.only_tags, task.skip_tags, {})

    task.only_tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:26:13.842163
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_path import RolePath
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 08:26:23.252791
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags: ['all', 'tagged']
    #   skip_tags: ['never']
    #   tags: ['always']
    #   should_run: True
    only_tags = ['all', 'tagged']
    skip_tags = ['never']
    tags = ['always']
    should_run = True
    assert Taggable.evaluate_tags(None, only_tags, skip_tags, tags) == should_run

    # Test case 2:
    #   only_tags: ['all', 'tagged']
    #   skip_tags: ['never']
    #   tags: ['never']
    #   should_run: False
    only_tags = ['all', 'tagged']
    skip_tags = ['never']
    tags = ['never']

# Generated at 2022-06-17 08:26:32.618425
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.groupvars import GroupVars

# Generated at 2022-06-17 08:26:41.238945
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:26:51.387786
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_path import RolePath
    from ansible.playbook.unvault import Unvault
   

# Generated at 2022-06-17 08:27:03.296651
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    my_taggable = MyTaggable()
    my_taggable.tags = ['tag1', 'tag2']
    assert my_taggable.evaluate_tags(['tag1'], [], {})
    assert my_taggable.evaluate_tags(['tag2'], [], {})
    assert my_taggable.evaluate_tags(['tag1', 'tag2'], [], {})
    assert my_taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert my_taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag3'], {})

# Generated at 2022-06-17 08:27:13.762172
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_obj = TestClass()

    # Test with only_tags
    test_obj.tags = ['tag1', 'tag2']
    assert test_obj.evaluate_tags(['tag1'], [], {}) == True
    assert test_obj.evaluate_tags(['tag2'], [], {}) == True
    assert test_obj.evaluate_tags(['tag3'], [], {}) == False
    assert test_obj.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_obj.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert test_obj.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert test_obj.evaluate_tags

# Generated at 2022-06-17 08:27:21.456695
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    host = inventory.get_host('localhost')
    hostvars = HostVars(
        host=host,
        variable_manager=variable_manager,
        loader=loader,
    )
    variable_manager.set_host_variable(host, hostvars)