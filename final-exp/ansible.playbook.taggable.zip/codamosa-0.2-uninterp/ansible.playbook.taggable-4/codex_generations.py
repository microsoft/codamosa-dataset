

# Generated at 2022-06-17 08:17:37.202384
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:17:48.189194
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert task

# Generated at 2022-06-17 08:17:57.784235
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.unvars import Unvars

# Generated at 2022-06-17 08:18:09.665246
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test with only_tags
    assert FakeTaggable(tags=['always']).evaluate_tags(only_tags=['always'], skip_tags=None, all_vars=None)
    assert FakeTaggable(tags=['always']).evaluate_tags(only_tags=['all'], skip_tags=None, all_vars=None)
    assert FakeTaggable(tags=['always']).evaluate_tags(only_tags=['tagged'], skip_tags=None, all_vars=None)
    assert FakeTaggable(tags=['always']).evaluate_tags(only_tags=['always', 'tagged'], skip_tags=None, all_vars=None)


# Generated at 2022-06-17 08:18:22.784330
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test case 1: no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test case 2: only_tags
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == False
    test_taggable.tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True

    # Test case 3: skip_tags

# Generated at 2022-06-17 08:18:32.834019
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    t = Task()
    t._loader = None
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert t.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:18:45.459408
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context with tags
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()

    # Check if the task should be executed
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == True

# Generated at 2022-06-17 08:18:53.724138
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()

    # Test with no tags
    test_class.tags = []
    assert test_class.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert test_class.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert test_class.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert test_class.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == False
    assert test_class.evaluate_tags(only_tags=[], skip_tags=['tagged'], all_vars={}) == True

    #

# Generated at 2022-06-17 08:19:04.617459
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})

    # Test with skip_tags
    tt = TestTaggable()

# Generated at 2022-06-17 08:19:13.023391
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:19:29.377267
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    t = TestTaggable()

    # test with no tags
    t.tags = []
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['untagged'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={}) == False

# Generated at 2022-06-17 08:19:41.245265
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:19:49.263889
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    t = TestTaggable()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {})
    assert not t.evaluate_tags(['tag3'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2'], [], {})
    assert not t.evaluate_tags(['tag1', 'tag3'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], ['tag2'], {})

# Generated at 2022-06-17 08:19:55.847976
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:20:08.498882
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class DummyTaggable(Taggable):
        pass

    # Test with no tags
    dt = DummyTaggable()
    assert dt.evaluate_tags(only_tags=None, skip_tags=None, all_vars=None) == True

    # Test with only_tags
    dt = DummyTaggable()
    dt.tags = ['foo']
    assert dt.evaluate_tags(only_tags=['foo'], skip_tags=None, all_vars=None) == True
    assert dt.evaluate_tags(only_tags=['bar'], skip_tags=None, all_vars=None) == False
    assert dt.evaluate_tags(only_tags=['all'], skip_tags=None, all_vars=None) == True
    assert dt.evaluate

# Generated at 2022-06-17 08:20:15.895036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test case 1:
    #   only_tags: ['all', 'tagged']
    #   skip_tags: ['never']
    #   tags: ['always', 'never']
    #   expected: False
    only_tags = ['all', 'tagged']
    skip_tags = ['never']
    tags = ['always', 'never']
    tt = TestTaggable(tags)
    assert tt.evaluate_tags(only_tags, skip_tags, None) == False

    # Test case 2:
    #   only_tags: ['all', 'tagged']
    #   skip_tags: ['never']
    #   tags: ['always', 'never', 'tagged']
    #

# Generated at 2022-06-17 08:20:31.056432
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:20:41.733304
# Unit test for method evaluate_tags of class Taggable

# Generated at 2022-06-17 08:20:51.872456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import As

# Generated at 2022-06-17 08:21:03.765683
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude

    # Create a fake play
    play = Play()
    play.vars = dict()
    play.vars['role_name'] = 'fake_role'
    play.vars['play_hosts'] = ['fake_host']

    # Create a fake role
    role = Role()
    role._role_name = 'fake_role'
    role._parent = play

    # Create a fake

# Generated at 2022-06-17 08:21:30.452610
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role

    # Test for class Task
    t = Task()
    t.tags = ['tag1', 'tag2']
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert t.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True

# Generated at 2022-06-17 08:21:41.491890
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task.tags = ['test']
    task.action = 'debug'
    task.args = {'msg': 'test'}
    task._variable_manager = variable_manager
    task._tqm = None

    # Test case 1: only_tags = ['test'], skip_tags = []
    play

# Generated at 2022-06-17 08:21:53.037481
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:22:04.610037
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:22:15.494261
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    play_context.tags = ['tag5', 'tag6']

# Generated at 2022-06-17 08:22:23.886458
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:22:33.480388
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_file import VarsFile
    from ansible.playbook.vault_password import Vault

# Generated at 2022-06-17 08:22:43.609740
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

# Generated at 2022-06-17 08:22:51.955488
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test only_tags
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={'tags': ['always']})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={'tags': ['never']})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={'tags': ['never', 'always']})

# Generated at 2022-06-17 08:22:56.186771
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.include
    import ansible.playbook.handler
    import ansible.playbook.task_include
    import ansible.playbook.conditional
    import ansible.playbook.role_include

    # Test for class Task
    task = ansible.playbook.task.Task()
    task.tags = ['test_tag']
    assert task.evaluate_tags(['test_tag'], [], {}) == True
    assert task.evaluate_tags([], ['test_tag'], {}) == False
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {}) == False
    assert task.evaluate_

# Generated at 2022-06-17 08:23:32.190051
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self):
            self.tags = []

    test_class = TestClass()

    # Test with no tags
    assert test_class.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert test_class.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not test_class.evaluate_tags(only_tags=['tag2'], skip_tags=[], all_vars={})

    # Test with skip_tags
    assert test_class.evaluate_tags(only_tags=[], skip_tags=['tag1'], all_vars={})

# Generated at 2022-06-17 08:23:42.857550
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    class MockTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: no tags
    t = MockTaggable(tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=[])

    # Test 2: only_tags
    t = MockTaggable(tags=['foo'])
    assert t.evaluate_tags(only_tags=['foo'], skip_tags=[])
    assert not t.evaluate_tags(only_tags=['bar'], skip_tags=[])

    # Test 3: skip_tags
    t = MockTaggable(tags=['foo'])
    assert not t.evaluate_tags(only_tags=[], skip_tags=['foo'])

# Generated at 2022-06-17 08:23:53.462318
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.groupvars import GroupVars
    from ansible.playbook.vars.taskvars import TaskVars

# Generated at 2022-06-17 08:24:02.022469
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:24:08.459098
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable([])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert tt.evaluate_tags(only_tags=[], skip_tags=['tagged']) == True

    # Test with tags
    tt = TestTaggable(['foo'])
    assert tt.evaluate_

# Generated at 2022-06-17 08:24:14.234502
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    t = Task()
    b = Block()
    p = Play()

    # Test for tags
    t.tags = ['tag1', 'tag2']
    b.tags = ['tag1', 'tag2']
    p.tags = ['tag1', 'tag2']

    # Test for only_tags
    assert t.evaluate_tags(['tag1'], [], {}) == True
    assert t.evaluate_tags(['tag2'], [], {}) == True
    assert t.evaluate_tags(['tag3'], [], {}) == False
    assert t.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert t.evaluate

# Generated at 2022-06-17 08:24:25.277999
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.async_task import AsyncTask
   

# Generated at 2022-06-17 08:24:37.771831
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert not t.evaluate_tags(only_tags=['never'], skip_tags=[], all_vars={})
    assert not t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})

    # Test with skip_tags

# Generated at 2022-06-17 08:24:46.023200
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()

    # Test with only_tags
    test_class.tags = ['tag1', 'tag2']
    assert test_class.evaluate_tags(['tag1'], [], {}) == True
    assert test_class.evaluate_tags(['tag2'], [], {}) == True
    assert test_class.evaluate_tags(['tag3'], [], {}) == False
    assert test_class.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert test_class.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert test_class.evaluate_tags(['tag3', 'tag4'], [], {}) == False
    assert test_class.evaluate_tags

# Generated at 2022-06-17 08:24:57.670392
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(['foo']).evaluate_tags(['foo'], [], {})
    assert TestTaggable(['foo']).evaluate_tags(['foo', 'bar'], [], {})
    assert TestTaggable(['foo']).evaluate_tags(['all'], [], {})
    assert TestTaggable(['foo']).evaluate_tags(['tagged'], [], {})
    assert TestTaggable(['foo']).evaluate_tags(['always'], [], {})
    assert TestTaggable(['foo']).evaluate_tags(['always', 'foo'], [], {})

# Generated at 2022-06-17 08:26:04.295112
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    test

# Generated at 2022-06-17 08:26:16.525495
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert task.evaluate_tags(['tag3', 'tag2', 'tag1'], [], {})

# Generated at 2022-06-17 08:26:30.109356
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    task = Taggable()
    task.tags = ['tag1']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == True
    task.tags = ['tag2']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == True
    task.tags = ['tag3']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == False
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(only_tags, skip_tags, all_vars) == True

# Generated at 2022-06-17 08:26:39.825660
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:26:51.484053
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test case 1: only_tags is empty, skip_tags is empty
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True

    # Test case 2: only_tags is not empty, skip_tags is empty
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == True

    # Test case 3: only_tags is not empty, skip_tags is not empty
    tt = TestTaggable(['tag1', 'tag2'])
    assert tt.evaluate_

# Generated at 2022-06-17 08:27:03.296117
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:27:13.760363
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=['tag1'], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True

# Generated at 2022-06-17 08:27:23.623578
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert not t.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['always'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert not t.evaluate_tags