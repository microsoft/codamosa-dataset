

# Generated at 2022-06-17 08:17:39.246107
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude

    # Test Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags([], ['tag1'], {}) == False
    assert task.evaluate_tags

# Generated at 2022-06-17 08:17:48.891679
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:17:57.840088
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], ['tag1'], {}) == False
    assert task.evaluate_

# Generated at 2022-06-17 08:18:09.710236
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debug import Debug

# Generated at 2022-06-17 08:18:15.534812
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self):
            self.tags = []

    taggable = TaggableTest()
    assert taggable.evaluate_tags(['all'], [], {})
    assert taggable.evaluate_tags(['all'], ['never'], {})
    assert taggable.evaluate_tags(['all'], ['never'], {})
    assert taggable.evaluate_tags(['all'], ['never', 'always'], {})
    assert taggable.evaluate_tags(['all'], ['never', 'always'], {})
    assert taggable.evaluate_tags(['all'], ['never', 'always'], {})
    assert taggable.evaluate_tags(['all'], ['never', 'always'], {})
    assert tag

# Generated at 2022-06-17 08:18:29.749016
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_files import VarsModule
    from ansible.playbook.vars_files import VarsInclude

# Generated at 2022-06-17 08:18:42.395325
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_dependency import RoleDependency


# Generated at 2022-06-17 08:18:52.376071
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_dependency import TaskDependency
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:19:03.712663
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self):
            self.tags = []

    taggable = MockTaggable()

    # Test with no tags
    assert taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    taggable.tags = ['tag1', 'tag2']
    assert taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert not taggable.evaluate_tags(only_tags=['tag3'], skip_tags=[], all_vars={})

    # Test with skip_tags
    taggable.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:19:12.567680
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags
    # Test 1: only_tags = ['all'], skip_tags = [], tags = ['tag1', 'tag2']
    # expected: should_run = True
    only_tags = ['all']
    skip_tags = []
    tags = ['tag1', 'tag2']
    tt = TestTaggable(tags)
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True
    # Test 2: only_tags = ['tag1'], skip_tags = [], tags = ['tag1', 'tag2']
    # expected: should_run = True
    only_tags = ['tag1']
    skip_tags = []

# Generated at 2022-06-17 08:19:29.375617
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook


# Generated at 2022-06-17 08:19:41.245031
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude


# Generated at 2022-06-17 08:19:49.717706
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class FakeTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1:
    #   - only_tags: ['all', 'tagged']
    #   - skip_tags: []
    #   - tags: ['tag1', 'tag2']
    #   - expected: True
    only_tags = ['all', 'tagged']
    skip_tags = []
    tags = ['tag1', 'tag2']
    expected = True
    taggable = FakeTaggable(tags)
    actual = taggable.evaluate_tags(only_tags, skip_tags, {})
    assert expected == actual

    # Test 2:
    #   - only_tags: ['all', 'tagged']
    #   - skip_tags: []
    #   -

# Generated at 2022-06-17 08:19:55.054722
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:20:08.319784
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True

# Generated at 2022-06-17 08:20:19.868119
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # test with only_tags
    assert TestTaggable(tags=['tag1']).evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1']).evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['tag1', 'tag2']).evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:20:31.647969
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:20:41.783700
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always', 'never'], all_vars={})

# Generated at 2022-06-17 08:20:51.248047
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context with only_tags and skip_tags
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()

    # Test the method evaluate_tags
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == False

# Generated at 2022-06-17 08:21:03.645179
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}

    # Test with tags = ['tag1']
    tt = TestTaggable(['tag1'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags = ['tag2']
    tt = TestTaggable(['tag2'])
    assert tt.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags = ['tag3']
    tt = TestTaggable(['tag3'])
    assert tt

# Generated at 2022-06-17 08:21:24.336836
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:21:34.585043
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 08:21:42.320609
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    tt = TestTaggable()

    # Test 1: no tags
    tt.tags = []
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True

    # Test 2: only_tags=all
    tt.tags = []
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    tt.tags = ['foo']
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    tt.tags = ['never']

# Generated at 2022-06-17 08:21:53.786763
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test case 1:
    #   only_tags: ['tag1', 'tag2']
    #   skip_tags: ['tag3', 'tag4']
    #   tags: ['tag1', 'tag2', 'tag5']
    #   should_run: True
    tt = TestTaggable(['tag1', 'tag2', 'tag5'])
    assert tt.evaluate_tags(['tag1', 'tag2'], ['tag3', 'tag4'], {})

    # Test case 2:
    #   only_tags: ['tag1', 'tag2']
    #   skip_tags: ['tag3', 'tag4']
    #   tags: ['tag5']
   

# Generated at 2022-06-17 08:22:04.888972
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.include
    import ansible.playbook.include_role
    import ansible.playbook.conditional
    import ansible.playbook.vars
    import ansible.playbook.async_task
    import ansible.playbook.async_status
    import ansible.playbook.pause
    import ansible.playbook.meta
    import ansible.playbook.debug
    import ansible.playbook.import_role
    import ansible.playbook.import_tasks
    import ansible.playbook.set_fact
    import ansible.playbook.wait_for

# Generated at 2022-06-17 08:22:15.519913
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.meta import Meta

# Generated at 2022-06-17 08:22:23.917879
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag3'], [], {}) == True

# Generated at 2022-06-17 08:22:35.602128
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    # Test case 1:
    #   - only_tags: ['all', 'tagged']
    #   - skip_tags: ['never']
    #   - tags: ['always']
    #   - expected: True
    #
    # Test case 2:
    #   - only_tags: ['all', 'tagged']
    #   - skip_tags: ['never']
    #   - tags: ['never']
    #   - expected: False
    #
    # Test case 3:
    #   - only_tags: ['all', 'tagged']
    #   - skip_tags: ['never']
    #   - tags: []
    #   - expected: True


# Generated at 2022-06-17 08:22:43.051036
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_taggable = TestTaggable()

    # Test with no tags
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[])

    # Test with only_tags
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == False
    test_taggable.tags = ['tag1']
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[])
    test_taggable.tags = ['tag1', 'tag2']
    assert test_taggable.evaluate_tags(only_tags=['tag1'], skip_tags=[])
    test_tagg

# Generated at 2022-06-17 08:22:47.845712
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['always']
    assert task.evaluate_tags(['always'], [], {}) == True
    assert task.evaluate_tags(['all'], [], {}) == True
    assert task.evaluate_tags(['tagged'], [], {}) == True
    assert task.evaluate_tags(['never'], [], {}) == False
    assert task.evaluate_tags(['always', 'never'], [], {}) == True

# Generated at 2022-06-17 08:23:29.616162
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True

    only_tags = ['tag3']
    skip_tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == False

    only_tags = ['tag1', 'tag2']
    skip_tags = []
    assert tt.evaluate_tags(only_tags, skip_tags, {}) == True

    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = []

# Generated at 2022-06-17 08:23:41.975118
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:23:48.531591
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test case 1: no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test case 2: only_tags = ['all']
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})

    # Test case 3: only_tags = ['all'], skip_tags = ['all']
    assert not t.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={})

    # Test case 4: only_tags = ['all'], skip_tags = ['all', 'always']
    assert not t.evaluate_

# Generated at 2022-06-17 08:23:57.497394
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt

# Generated at 2022-06-17 08:24:05.202138
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # test with only_tags
    tt.tags = ['foo']
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['bar'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:24:14.146423
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TestTaggable(tags=['foo', 'bar']).evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['foo', 'bar']).evaluate_tags(only_tags=['foo', 'bar'], skip_tags=[], all_vars={})
    assert TestTaggable(tags=['foo', 'bar']).evaluate_tags(only_tags=['foo', 'bar', 'baz'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:24:25.246420
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:24:37.736105
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # Create a task with tags
    task = Task()
    task.tags = ['test_tag']

    # Create a play context with only_tags and skip_tags
    play_context = PlayContext()
    play_context.only_tags = ['test_tag']
    play_context.skip_tags = ['test_tag']

    # Create a variable manager
    variable_manager = VariableManager()

    # Test evaluate_tags with only_tags and skip_tags
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, variable_manager.get_vars()) == False

    # Test evaluate_tags with only_tags
    play_context

# Generated at 2022-06-17 08:24:46.024260
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.blockvars import BlockVars

# Generated at 2022-06-17 08:24:57.668424
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:26:09.393842
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=['tagged', 'all'], skip_tags=[], all_vars={}) == True

# Generated at 2022-06-17 08:26:21.432478
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:26:32.441803
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    # Test for method evaluate_tags of class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True

# Generated at 2022-06-17 08:26:44.502590
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate

# Generated at 2022-06-17 08:26:54.556308
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self._loader = None
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=['tag2'], all_vars={}) == True

# Generated at 2022-06-17 08:27:05.623675
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble


# Generated at 2022-06-17 08:27:13.893675
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MockTaggable(Taggable):
        def __init__(self):
            self._tags = ['tag1', 'tag2']
            self._loader = None
    taggable = MockTaggable()
    assert taggable.evaluate_tags(['tag1'], [], {})
    assert not taggable.evaluate_tags(['tag3'], [], {})
    assert taggable.evaluate_tags([], ['tag1'], {})
    assert not taggable.evaluate_tags([], ['tag2'], {})
    assert taggable.evaluate_tags(['tag1'], ['tag2'], {})
    assert not taggable.evaluate_tags(['tag2'], ['tag1'], {})

# Generated at 2022-06-17 08:27:26.352269
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency