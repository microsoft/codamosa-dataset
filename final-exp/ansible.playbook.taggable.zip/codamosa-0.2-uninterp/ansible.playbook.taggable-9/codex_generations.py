

# Generated at 2022-06-17 08:17:33.971219
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-17 08:17:43.989042
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:17:51.704136
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test'

# Generated at 2022-06-17 08:18:01.174787
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    # Test with no tags
    my_taggable = MyTaggable()
    assert my_taggable.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    my_taggable = MyTaggable()
    my_taggable.tags = ['foo']
    assert my_taggable.evaluate_tags(only_tags=['foo'], skip_tags=[], all_vars={})
    assert not my_taggable.evaluate_tags(only_tags=['bar'], skip_tags=[], all_vars={})

    # Test with skip_tags
    my_taggable = MyTaggable()
    my_taggable.tags = ['foo']

# Generated at 2022-06-17 08:18:08.938941
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude

# Generated at 2022-06-17 08:18:22.699819
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_obj = TestClass()
    test_obj.tags = ['tag1', 'tag2']

    # Test case 1: only_tags = ['tag1']
    # Expected result: True
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test case 2: only_tags = ['tag1', 'tag2']
    # Expected result: True
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    assert test_obj.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test case 3

# Generated at 2022-06-17 08:18:32.834342
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:18:40.424393
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {})
    assert not task.evaluate_tags(['tag3'], [], {})

# Generated at 2022-06-17 08:18:52.404612
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:19:03.999959
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 08:19:22.691062
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-17 08:19:33.411531
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    # Test with only_tags
    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']
    assert test_taggable.evaluate_tags(['tag1'], [], {})
    assert test_taggable.evaluate_tags(['tag2'], [], {})
    assert not test_taggable.evaluate_tags(['tag3'], [], {})
    assert test_taggable.evaluate_tags(['tag1', 'tag2'], [], {})
    assert test_taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})

# Generated at 2022-06-17 08:19:39.674237
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1
    # Input:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag1', 'tag2']
    # Expected output:
    #   should_run = True
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    tags = ['tag1', 'tag2']
    should_run = True
    assert Taggable.evaluate_tags(None, only_tags, skip_tags, tags) == should_run

    # Test case 2
    # Input:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag1',

# Generated at 2022-06-17 08:19:49.020060
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}

    # Test with tags = ['tag1']
    t = TestTaggable(['tag1'])
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags = ['tag2']
    t = TestTaggable(['tag2'])
    assert t.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test with tags = ['tag3']
    t = TestTaggable(['tag3'])

# Generated at 2022-06-17 08:19:58.256575
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    import sys
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude


# Generated at 2022-06-17 08:20:09.125031
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(tags=[])
    assert t.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=[], skip_tags=['all']) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged']) == False
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=['tagged']) == False

# Generated at 2022-06-17 08:20:16.353958
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.become_include import BecomeIn

# Generated at 2022-06-17 08:20:31.303398
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.debugger import Debugger
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.pause import Pause
   

# Generated at 2022-06-17 08:20:41.775213
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag3'], [], {}) == True
    assert task

# Generated at 2022-06-17 08:20:51.911019
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {}) == False

# Generated at 2022-06-17 08:21:18.894754
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []
            self._loader = None

    t = TestTaggable()

    # Test with no tags
    assert t.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert t.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={}) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['all'], all_vars={}) == False
    assert t.evaluate_tags(only_tags=[], skip_tags=['tagged'], all_vars={}) == True

# Generated at 2022-06-17 08:21:31.814657
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self):
            self.tags = []

    test_class = TestClass()

    # Test with only_tags
    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    test_class.tags = ['tag1']
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True
    test_class.tags = ['tag2']
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True
    test_class.tags = ['tag3']
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == False

# Generated at 2022-06-17 08:21:41.630897
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask
    from ansible.playbook.role_dependency import RoleD

# Generated at 2022-06-17 08:21:48.551575
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.debugger import Debugger


# Generated at 2022-06-17 08:21:59.835850
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:22:08.724430
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableMock(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TaggableMock(None)
    assert t.evaluate_tags(None, None, None) == True

    # Test with only_tags
    t = TaggableMock(None)
    assert t.evaluate_tags(['foo'], None, None) == False
    t = TaggableMock(['foo'])
    assert t.evaluate_tags(['foo'], None, None) == True
    t = TaggableMock(['foo', 'bar'])
    assert t.evaluate_tags(['foo'], None, None) == True
    t = TaggableMock(['foo', 'bar'])
    assert t.evaluate_tags

# Generated at 2022-06-17 08:22:20.417643
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import Become

# Generated at 2022-06-17 08:22:31.348858
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:22:40.022090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for Task
    t = Task()
    t.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:22:49.363074
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 08:23:30.184336
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 08:23:42.009918
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1', 'tag2']
    play_context.skip_tags = ['tag3', 'tag4']
    play_context.tags = ['tag5', 'tag6']
    play_context.set_options()

# Generated at 2022-06-17 08:23:53.383784
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    # Test for Task
    task = Task()
    task.tags = ['test_tag']
    assert task.evaluate_tags(['test_tag'], [], {}) == True
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {}) == False

# Generated at 2022-06-17 08:24:01.953769
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a block with tags
    block = Block()
    block.tags = ['tag1', 'tag2']

    # Create a role with tags
    role = Role()
    role.tags = ['tag1', 'tag2']

    # Create a play with tags
    play = Play()
    play.tags = ['tag1', 'tag2']

    # Create a playbook with tags
    playbook = Playbook()

# Generated at 2022-06-17 08:24:08.406191
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    '''
    Test method evaluate_tags of class Taggable
    '''

    # Test case 1:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag1', 'tag2', 'tag3']
    #   expected_result = True
    #   expected_tags = ['tag1', 'tag2', 'tag3']
    #   expected_should_run = True
    #
    # Test case 2:
    #   only_tags = ['tag1', 'tag2']
    #   skip_tags = ['tag3', 'tag4']
    #   tags = ['tag3', 'tag4']
    #   expected_result = True
    #   expected_tags = ['tag3', 'tag4']
   

# Generated at 2022-06-17 08:24:14.651983
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_import import VarsImport
    from ansible.playbook.vars_plugin import VarsPlugin
    from ansible.playbook.async_task import AsyncTask

# Generated at 2022-06-17 08:24:25.490800
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Test for Task
    t = Task()
    t.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:24:38.114923
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:24:49.438757
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 08:25:00.859890
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.action_plugin import ActionBase

# Generated at 2022-06-17 08:26:15.745650
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True

# Generated at 2022-06-17 08:26:29.715771
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    t = TestTaggable(None)
    assert t.evaluate_tags(None, None, None) == True
    assert t.evaluate_tags([], None, None) == True
    assert t.evaluate_tags(None, [], None) == True
    assert t.evaluate_tags([], [], None) == True

    # Test with only_tags
    t = TestTaggable(None)
    assert t.evaluate_tags(['all'], None, None) == True
    assert t.evaluate_tags(['tagged'], None, None) == False
    assert t.evaluate_tags(['untagged'], None, None) == False
    assert t.evaluate_tags

# Generated at 2022-06-17 08:26:36.360831
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()

    # Test with no tags
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={})

    # Test with only_tags
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={})
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[], all_vars={})
    assert not tt.evaluate_tags(only_tags=['never'], skip_tags=[], all_vars={})

# Generated at 2022-06-17 08:26:48.429593
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_class = TestClass()
    test_class.tags = ['tag1', 'tag2']

    # Test with only_tags
    assert test_class.evaluate_tags(only_tags=['tag1'], skip_tags=None, all_vars={}) == True
    assert test_class.evaluate_tags(only_tags=['tag2'], skip_tags=None, all_vars={}) == True
    assert test_class.evaluate_tags(only_tags=['tag3'], skip_tags=None, all_vars={}) == False
    assert test_class.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=None, all_vars={}) == True

# Generated at 2022-06-17 08:26:55.568351
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    class MyTask(Task, Taggable):
        pass

    class MyPlay(Play):
        pass

    play = MyPlay()
    play.vars = dict(foo='bar')

    task = MyTask()
    task.name = 'test'
    task.tags = ['always']
    task.vars = dict(foo='bar')

    play.add_task(task)

    # test with no tags
    assert task.evaluate_tags(only_tags=[], skip_tags=[], all_vars=play.vars) == True

    # test with only_tags
    assert task.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars=play.vars) == True
   

# Generated at 2022-06-17 08:27:05.917832
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 08:27:21.379144
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude