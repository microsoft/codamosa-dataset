

# Generated at 2022-06-17 08:17:39.344832
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

# Generated at 2022-06-17 08:17:45.897134
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['all'], all_vars={}) == False
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['never'], all_vars={}) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=['always'], all_vars={}) == False


# Generated at 2022-06-17 08:17:53.912332
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        pass

    test_obj = TestClass()

    # Test with only_tags
    test_obj.tags = ['tag1', 'tag2']
    assert test_obj.evaluate_tags(['tag1'], [], {}) is True
    assert test_obj.evaluate_tags(['tag2'], [], {}) is True
    assert test_obj.evaluate_tags(['tag3'], [], {}) is False
    assert test_obj.evaluate_tags(['tag1', 'tag2'], [], {}) is True
    assert test_obj.evaluate_tags(['tag1', 'tag3'], [], {}) is True
    assert test_obj.evaluate_tags(['tag3', 'tag4'], [], {}) is False
    assert test_obj.evaluate_tags

# Generated at 2022-06-17 08:18:05.639563
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.cleanup_tasks import CleanupTasks

# Generated at 2022-06-17 08:18:14.011240
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestClass(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test 1: only_tags = ['tag1', 'tag2'], skip_tags = ['tag3', 'tag4'], tags = ['tag1', 'tag2']
    #         should_run = True
    test_class = TestClass(['tag1', 'tag2'])
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3', 'tag4']
    all_vars = {}
    assert test_class.evaluate_tags(only_tags, skip_tags, all_vars) == True

    # Test 2: only_tags = ['tag1', 'tag2'], skip_tags = ['tag3', 'tag4'], tags = ['tag3', 'tag4

# Generated at 2022-06-17 08:18:24.947086
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.groupvars import GroupVars
    from ansible.playbook.vars.taskvars import TaskVars

# Generated at 2022-06-17 08:18:33.485945
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:18:47.133755
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger

# Generated at 2022-06-17 08:18:55.779715
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import os
    import sys
    import json
    import py

# Generated at 2022-06-17 08:19:08.807628
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()

    # Test with empty tags
    test_taggable.tags = []
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert test_taggable.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert test_taggable.evaluate_tags(only_tags=[], skip_tags=['all']) == True
    assert test_taggable.evaluate_tags(only_tags=['all'], skip_tags=['all']) == True
    assert test_taggable.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == False

# Generated at 2022-06-17 08:19:28.495471
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.when import When
    from ansible.playbook.async_task import AsyncTask
    from ansible.playbook.async_status import AsyncStatus
    from ansible.playbook.meta import Meta
    from ansible.playbook.play_context import Play

# Generated at 2022-06-17 08:19:36.041494
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude

# Generated at 2022-06-17 08:19:42.701620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    tt = TestTaggable()
    tt.tags = ['tag1', 'tag2']

    # Test with no tags
    assert tt.evaluate_tags(None, None, None) == True

    # Test with only_tags
    assert tt.evaluate_tags(['tag1'], None, None) == True
    assert tt.evaluate_tags(['tag2'], None, None) == True
    assert tt.evaluate_tags(['tag3'], None, None) == False

    # Test with skip_tags
    assert tt.evaluate_tags(None, ['tag1'], None) == False
    assert tt.evaluate_tags(None, ['tag2'], None) == False

# Generated at 2022-06-17 08:19:53.872341
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    # Test case 1:
    #   only_tags: ['tag1', 'tag2']
    #   skip_tags: ['tag3']
    #   tags: ['tag1', 'tag2', 'tag3']
    #   should_run: True
    #   result: True
    only_tags = ['tag1', 'tag2']
    skip_tags = ['tag3']
    tags = ['tag1', 'tag2', 'tag3']
    should_run = True
    result = Taggable.evaluate_tags(None, only_tags, skip_tags, tags)
    assert result == should_run

    # Test case 2:
    #   only_tags: ['tag1', 'tag2']
    #   skip_tags: ['tag3']
    #   tags: ['tag1', 'tag2']
    #

# Generated at 2022-06-17 08:20:00.257677
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['test_tag']
    assert task.evaluate_tags(['test_tag'], [], {}) == True
    assert task.evaluate_tags(['test_tag'], ['test_tag'], {}) == False
    assert task.evaluate_tags(['test_tag'], ['test_tag_2'], {}) == True
    assert task.evaluate_tags(['test_tag_2'], ['test_tag'], {}) == False

# Generated at 2022-06-17 08:20:10.091412
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    test_taggable = TestTaggable(['tag1', 'tag2'])
    assert test_taggable.evaluate_tags(['tag1'], [], {})
    assert not test_taggable.evaluate_tags(['tag3'], [], {})
    assert test_taggable.evaluate_tags(['tag1', 'tag2'], [], {})
    assert test_taggable.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert test_taggable.evaluate_tags(['tag3', 'tag4'], [], {})

# Generated at 2022-06-17 08:20:20.839952
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency

    # Test for Task
    t = Task()
    t.tags = ['test_tag']

# Generated at 2022-06-17 08:20:32.219989
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Base
    base = Base()
    base.tags = ['tag1', 'tag2']
    assert base.evaluate_tags(['tag1'], [], {}) == True
    assert base.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert base.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True

# Generated at 2022-06-17 08:20:45.349456
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {})
    assert not task.evaluate_tags(['tag3'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2'], [], {})
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {})
    assert task.evaluate_tags(['tag3', 'tag4'], ['tag1'], {})
   

# Generated at 2022-06-17 08:20:54.244251
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.assemble_include import AssembleInclude


# Generated at 2022-06-17 08:21:19.623019
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a play context with only_tags
    play_context = PlayContext()
    play_context.only_tags = ['tag1']

    # Test if the task should run
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict()) == True

    # Create a play context with skip_tags
    play_context = PlayContext()
    play_context.skip_tags = ['tag1']

    # Test if the task should run
    assert task.evaluate_tags(play_context.only_tags, play_context.skip_tags, dict()) == False

# Generated at 2022-06-17 08:21:26.820554
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = Task()
    task._variable_manager = variable_manager
    task._loader = loader
    task._play_context = play_context

    # test with no tags
    task.tags = []
    assert task.evaluate_tags(only_tags=[], skip_tags=[]) == True

    # test with only_tags
    task

# Generated at 2022-06-17 08:21:34.594067
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask

# Generated at 2022-06-17 08:21:42.320237
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    test_obj = TestTaggable()

    # Test with no tags
    assert test_obj.evaluate_tags(None, None, None)

    # Test with only_tags
    assert test_obj.evaluate_tags(['all'], None, None)
    assert test_obj.evaluate_tags(['tagged'], None, None)
    assert test_obj.evaluate_tags(['tag1'], None, None)
    assert test_obj.evaluate_tags(['tag1', 'tag2'], None, None)
    assert test_obj.evaluate_tags(['tag1', 'tag2', 'tag3'], None, None)

# Generated at 2022-06-17 08:21:53.786816
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.block import RoleBlock
    from ansible.playbook.role.handler_task_include import RoleHandlerInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:22:04.900666
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 08:22:15.521090
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']

    # Create a block with tags
    block = Block()
    block.tags = ['tag3', 'tag4']

    # Create a role with tags
    role = Role()
    role.tags = ['tag5', 'tag6']

    # Create a play with tags
    play = Play()
    play.tags = ['tag7', 'tag8']

    # Create a playbook with tags
    playbook = Playbook()

# Generated at 2022-06-17 08:22:26.915809
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class MyTaggable(Taggable):
        pass

    my_taggable = MyTaggable()
    my_taggable.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    assert my_taggable.evaluate_tags(only_tags, skip_tags, None)

    only_tags = ['tag3']
    skip_tags = []
    assert not my_taggable.evaluate_tags(only_tags, skip_tags, None)

    only_tags = ['tagged']
    skip_tags = []
    assert my_taggable.evaluate_tags(only_tags, skip_tags, None)

    only_tags = ['tagged']
    skip_tags = ['tag1']
    assert not my

# Generated at 2022-06-17 08:22:38.374485
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude


# Generated at 2022-06-17 08:22:48.717841
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with no tags
    tt = TestTaggable(tags=[])
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True

    # Test with only_tags
    tt = TestTaggable(tags=[])
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == False
    tt = TestTaggable(tags=['tag1'])
    assert tt.evaluate_tags(only_tags=['tag1'], skip_tags=[]) == True
    tt = TestTaggable(tags=['tag1', 'tag2'])

# Generated at 2022-06-17 08:23:26.025108
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook


# Generated at 2022-06-17 08:23:34.308184
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        def __init__(self):
            self.tags = []

    # Test with no tags
    tt = TestTaggable()
    assert tt.evaluate_tags(only_tags=[], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['all'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['tagged'], skip_tags=[]) == True
    assert tt.evaluate_tags(only_tags=['untagged'], skip_tags=[]) == False
    assert tt.evaluate_tags(only_tags=['foo'], skip_tags=[]) == False

    # Test with tags
    tt.tags = ['foo']

# Generated at 2022-06-17 08:23:43.791872
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.role_include import RoleInclude
   

# Generated at 2022-06-17 08:23:55.471998
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TaggableTest(Taggable):
        def __init__(self, tags):
            self.tags = tags

    # Test with only_tags
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag1'], [], {})
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag2'], [], {})
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag3'], [], {}) == False
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag2'], [], {})
    assert TaggableTest(['tag1', 'tag2']).evaluate_tags(['tag1', 'tag3'], [], {})
   

# Generated at 2022-06-17 08:24:02.572179
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2'], [], {}) == True
    assert task.evaluate_tags(['tag1', 'tag2', 'tag3'], [], {}) == True
    assert task.evaluate_tags(['tag3'], [], {})

# Generated at 2022-06-17 08:24:07.927399
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble
    from ansible.playbook.debugger import Debugger
    from ansible.playbook.meta import Meta

# Generated at 2022-06-17 08:24:13.673433
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.playbook.vault import VaultSecret
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostV

# Generated at 2022-06-17 08:24:25.222657
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.assemble import Assemble

# Generated at 2022-06-17 08:24:37.735699
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task

# Generated at 2022-06-17 08:24:46.023908
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vault_password import VaultPassword
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 08:25:52.510054
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']

    # Test with only_tags
    only_tags = ['tag1']
    skip_tags = []
    all_vars = {}
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['tag1', 'tag2']
    skip_tags = []
    all_vars = {}
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    only_tags = ['tag1', 'tag2', 'tag3']
    skip_tags = []
    all_vars = {}

# Generated at 2022-06-17 08:26:02.610620
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.loop_control import LoopControl
    from ansible.playbook.task.conditional import Conditional
    from ansible.playbook.task.when import When
    from ansible.playbook.task.wait_for import WaitFor
    from ansible.playbook.task.async_task import As

# Generated at 2022-06-17 08:26:13.608069
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_dependency import RoleDependency

    # Test for class Task
    task = Task()
    task.tags = ['test_tag']
    assert task

# Generated at 2022-06-17 08:26:23.114208
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    class TestTaggable(Taggable):
        pass

    test_taggable = TestTaggable()
    test_taggable.tags = ['tag1', 'tag2']
    only_tags = ['tag1']
    skip_tags = ['tag3']
    all_vars = {}
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == True

    test_taggable.tags = ['tag1', 'tag2']
    only_tags = ['tag3']
    skip_tags = ['tag4']
    all_vars = {}
    assert test_taggable.evaluate_tags(only_tags, skip_tags, all_vars) == False

    test_taggable.tags = ['tag1', 'tag2']

# Generated at 2022-06-17 08:26:32.582753
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars import Vars
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook

# Generated at 2022-06-17 08:26:41.238564
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

    # Create a task with tags
    task = Task()
    task.tags = ['tag1', 'tag2']
    task.only_tags = ['tag1']
    task.skip_tags = ['tag2']

# Generated at 2022-06-17 08:26:51.846851
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import VariableManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Create a task with tags
    task

# Generated at 2022-06-17 08:27:03.829295
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test for class Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(only_tags=['tag1'], skip_tags=[], all_vars={}) == True
    assert task.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=[], all_vars={}) == True
    assert task.evaluate_tags(only_tags=['tag1', 'tag2'], skip_tags=['tag1'], all_vars={}) == False
    assert task.evaluate

# Generated at 2022-06-17 08:27:13.789054
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role_include import RoleInclude

    # Test for Task
    task = Task()
    task.tags = ['tag1', 'tag2']
    assert task.evaluate_tags(['tag1'], [], {}) == True
    assert task.evaluate_tags(['tag2'], [], {}) == True
    assert task

# Generated at 2022-06-17 08:27:25.009648
# Unit test for method evaluate_tags of class Taggable
def test_Taggable_evaluate_tags():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.become_include import BecomeInclude