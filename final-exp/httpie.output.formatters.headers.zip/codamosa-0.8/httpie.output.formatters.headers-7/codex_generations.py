

# Generated at 2022-06-11 23:48:18.024172
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('HTTP/1.1 200 OK\r\n'
                                            'Content-Type: text/html\r\n'
                                            'Set-Cookie: a=1;\r\n'
                                            'Set-Cookie: b=2;\r\n'
                                            'Set-Cookie: c=3;\r\n') == \
           'HTTP/1.1 200 OK\r\n' \
           'Content-Type: text/html\r\n' \
           'Set-Cookie: a=1;\r\n' \
           'Set-Cookie: b=2;\r\n' \
           'Set-Cookie: c=3;'

# Generated at 2022-06-11 23:48:27.490194
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""POST / HTTP/1.1
User-Agent: HTTPie/1.0.0-dev
Accept-Encoding: gzip, deflate
Accept: application/json
Connection: keep-alive
Content-Length: 14
Content-Type: application/json
""") == """POST / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 14
Content-Type: application/json
User-Agent: HTTPie/1.0.0-dev
"""



# Generated at 2022-06-11 23:48:35.602655
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-11 23:48:41.639817
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = """
GET / HTTP/1.1
Host: example.org
Connection: close
Accept: */*
Accept-Encoding: gzip, deflate
Cookie: foo=bar
    """
    headers = formatter.format_headers(headers)

    assert headers == """
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Cookie: foo=bar
Host: example.org
    """

# Generated at 2022-06-11 23:48:50.625498
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_input = """\
HTTP/1.1 200 OK
Status: 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 12
Server: Werkzeug/0.15.5 Python/3.7.4
Date: Mon, 17 Feb 2020 21:18:53 GMT

{"test": "headers"}
    """
    headers_output = """\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: application/json; charset=utf-8
Date: Mon, 17 Feb 2020 21:18:53 GMT
Server: Werkzeug/0.15.5 Python/3.7.4
Status: 200 OK

{"test": "headers"}
    """
    assert formatter.format_headers(headers_input) == headers

# Generated at 2022-06-11 23:48:57.421890
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_raw = """GET /test HTTP/1.1\r
Host: localhost:5000\r
User-Agent: HTTPie/0.9.9\r
Accept: */*\r
Connection: keep-alive\r
Accept-Encoding: gzip, deflate\r
\r
"""

    headers_sorted = """GET /test HTTP/1.1\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
Host: localhost:5000\r
User-Agent: HTTPie/0.9.9\r
\r
"""

    assert headers_sorted == HeadersFormatter().format_headers(headers_raw)


plugin_manager.register(HeadersFormatter)

# Generated at 2022-06-11 23:49:04.538619
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("'User-Agent': 'HTTPie/1.0.3'\r\n'Accept-Encoding': 'gzip, deflate'\r\n'Accept': '*/*'\r\n'Connection': 'keep-alive'") == "'User-Agent': 'HTTPie/1.0.3'\r\n'Accept': '*/*'\r\n'Accept-Encoding': 'gzip, deflate'\r\n'Connection': 'keep-alive'"

# Generated at 2022-06-11 23:49:05.936141
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    headers


# Generated at 2022-06-11 23:49:10.389527
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Get current working directory.
    current_directory = os.getcwd()
    # print(f"Current working directory: {current_directory}")

    # # Change to the tests directory.
    # Change directory to the tests directory.
    tests_directory = os.path.join(current_directory, 'tests')
    # print(f"Tests directory: {tests_direc

# Generated at 2022-06-11 23:49:16.409462
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {
            'sort': True
        }
    }
    headers = {
        'b': 'b',
        'a': 'a'
    }

    h = HeadersFormatter(format_options=format_options,
        headers=headers)  # type: HeadersFormatter

    assert h.enabled is True
    assert h.headers == {'b': 'b', 'a': 'a'}



# Generated at 2022-06-11 23:49:28.925640
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
Accept: */*
Content-Length: 0
Accept-Encoding: gzip, deflate
Accept-Language: en-US
Connection: keep-alive
""") == """\
Accept: */*
Content-Length: 0
Accept-Encoding: gzip, deflate
Accept-Language: en-US
Connection: keep-alive
""".lstrip()



# Generated at 2022-06-11 23:49:39.572127
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = formatter.HeadersFormatter()

    actual = headers.format_headers('')
    assert actual == ''
    
    actual = headers.format_headers('Host: localhost:80\r\nContent-Length: 0\r\n\r\n')
    assert actual == 'Host: localhost:80\r\nContent-Length: 0\r\n\r\n'

    actual = headers.format_headers('Host: localhos\r\nContent-Length: 0\r\nHost: localhost\r\nUser-Agent: httpie\r\n\r\n')
    assert actual == 'Host: localhost\r\nContent-Length: 0\r\nHost: localhost\r\nUser-Agent: httpie\r\n\r\n'


# Generated at 2022-06-11 23:49:47.725749
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
POST /post HTTP/1.1
Host: example.com
Content-Length: 7
Content-Type: text/plain
X-Something: 1
X-Something: 2
No-Colon
'''
    expected_headers = '''\
POST /post HTTP/1.1
Content-Length: 7
Content-Type: text/plain
Host: example.com
No-Colon
X-Something: 1
X-Something: 2
'''
    actual_headers = hf.format_headers(headers)
    assert actual_headers == expected_headers

# Generated at 2022-06-11 23:49:55.585878
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_input = '''
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/1.0.2
'''
    headers_output = '''
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/1.0.2
'''
    headers_formatter = HeadersFormatter()
    headers_formatted = headers_formatter.format_headers(headers_input)
    headers_formatted = headers_formatted.strip('\r\n')
    print(headers_formatted)
    assert headers_formatted == headers_output


# Generated at 2022-06-11 23:50:05.572132
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers_sample = '''\
HTTP/1.1 200 OK
Expires: Wed, 21 Oct 2015 07:28:00 GMT
Content-Type: application/json; charset=UTF-8
Date: Wed, 21 Oct 2015 07:28:00 GMT
Cache-Control: private, max-age=0
Content-Encoding: gzip
Server: GSE
Content-Length: 138
X-XSS-Protection: 1; mode=block
Alternate-Protocol: 443:quic,p=1
Alt-Svc: quic=":443"; ma=2592000; v="30,29,28,27,26,25"

'''.lstrip()

# Generated at 2022-06-11 23:50:10.686131
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Hello:World\n\
                                             Foo:Bar\n\
                                             Foo:Baz\n\
                                             Baz:Qux') == 'Hello:World\r\n\
                                                             Foo:Bar\r\n\
                                                             Foo:Baz\r\n\
                                                             Baz:Qux'



# Generated at 2022-06-11 23:50:17.070563
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'User-Agent: user_agent\n' \
              'Content-Length: 2\n' \
              'Accept: */*\n' \
              'Accept-Encoding: gzip, deflate'
    expected_headers = 'User-Agent: user_agent\n' \
                       'Accept: */*\n' \
                       'Content-Length: 2\n' \
                       'Accept-Encoding: gzip, deflate'
    assert HeadersFormatter().format_headers(headers=headers) == \
        expected_headers


if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-11 23:50:26.631911
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    test_string = '''HTTP/1.1 200 OK
Content-Type: application/json;charset=UTF-8
Cache-Control: no-cache, no-store, max-age=0, must-revalidate
Date: Fri, 21 Dec 2018 23:02:10 GMT
Expires: 0
Pragma: no-cache
Content-Length: 2

{}'''

    expected_string = '''HTTP/1.1 200 OK
Cache-Control: no-cache, no-store, max-age=0, must-revalidate
Content-Length: 2
Content-Type: application/json;charset=UTF-8
Date: Fri, 21 Dec 2018 23:02:10 GMT
Expires: 0
Pragma: no-cache

{}'''
   

# Generated at 2022-06-11 23:50:33.948633
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=UTF-8
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
Content-Length: 144
X-Content-Type-Options: nosniff
Date: Thu, 12 Jul 2018 20:55:16 GMT

'''

# Generated at 2022-06-11 23:50:44.269755
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'User-Agent: HTTPie/0.9.9',
        'Accept-Encoding: gzip, deflate',
        'Accept: application/json',
        'Connection: keep-alive'
    ])
    expected = '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept: application/json',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.9',
    ])

    formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}}
    )
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-11 23:50:55.482486
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def compare(input_headers, expected_headers):
        with patch.object(HeadersFormatter, 'write') as write_mock, \
                patch.object(HeadersFormatter, 'enable_formatting',
                             return_value=True):
            hf = HeadersFormatter()
            hf.format_headers(input_headers)
            write_mock.assert_called_with(expected_headers)

    compare(
        input_headers=dedent("""\
        HTTP/1.1 200 OK
        Foo: b
        Foo: a
        Bar: x
        Bar: y"""),
        expected_headers=dedent("""\
        HTTP/1.1 200 OK
        Foo: a
        Foo: b
        Bar: x
        Bar: y"""))

    # Ensure that the order is preserved when there

# Generated at 2022-06-11 23:51:05.072545
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # create new object
    headersFormatter = HeadersFormatter()
    # input string

# Generated at 2022-06-11 23:51:14.926230
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = ("1: aa\r\n"
             "1: bb\r\n"
             "2: cc\r\n"
             "2: dd\r\n"
             "1: ee\r\n"
             "3: ff\r\n")
    output = ("1: aa\r\n"
              "1: bb\r\n"
              "1: ee\r\n"
              "2: cc\r\n"
              "2: dd\r\n"
              "3: ff\r\n")
    assert HeadersFormatter(format_options={"headers": {"sort": True}}).format_headers(input) == output



# Generated at 2022-06-11 23:51:25.074197
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    #
    # Test constructor
    #
    from httpie.plugins import FormatterPlugin

    test_object_01 = HeadersFormatter(format_options = {'headers' : {'sort' : True}})
    assert(isinstance(test_object_01, FormatterPlugin))
    
    test_object_02 = HeadersFormatter(format_options = {'headers' : {'sort' : True}},
                                      stdout=io.StringIO(),
                                      stderr=io.StringIO(),
                                      stdin=io.StringIO())
    assert(isinstance(test_object_02, FormatterPlugin))
    
    test_object_03 = HeadersFormatter(format_options = {'headers' : {'sort' : False}})

# Generated at 2022-06-11 23:51:27.616403
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = "foo: bar\ncontent-type: application-json\nbar: baz"
    output = formatter.format_headers(input)
    assert output == "foo: bar\nbar: baz\ncontent-type: application-json"

# Generated at 2022-06-11 23:51:34.440437
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    response = Response(
        content='{}',
        headers={
            'Content-Type': 'application/json',
            'Content-Length': '2',
            'X-Foo': ['bar', 'baz']
        }
    )
    assert formatter.format(response) == """\
X-Foo: bar
X-Foo: baz
Content-Type: application/json
Content-Length: 2

{}"""



# Generated at 2022-06-11 23:51:38.717380
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = '''\
Accept: */*
Header: value
Header: another value
'''
    output = '''\
Accept: */*
Header: value
Header: another value
'''
    assert HeadersFormatter.format_headers(input) == output

# Generated at 2022-06-11 23:51:46.080439
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = """\
GET / HTTP/1.1
Host: https://httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.0.3
X-Amzn-Trace-Id: Root=1-5d32d4e4-4e4e4ed4e4d4d4e4d4e4d4e4

    """

# Generated at 2022-06-11 23:51:53.282949
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True)))

    input_text = """\
GET / HTTP/1.1
Host: localhost:8080
Accept: */*
Cookie: foo=bar
Cookie: __Host-one=value; __Host-two=value
Cookie: another=value

"""
    correct_output = """\
GET / HTTP/1.1
Accept: */*
Cookie: __Host-one=value; __Host-two=value
Cookie: another=value
Cookie: foo=bar
Host: localhost:8080

"""
    assert formatter.format_headers(input_text) == correct_output

# Generated at 2022-06-11 23:52:01.788147
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class H(HeadersFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.format_options['headers']['sort'] = True


# Generated at 2022-06-11 23:52:13.063103
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create an instance of the HeadersFormatter class
    fmt = HeadersFormatter(format_options={'headers': {'sort': True}})
    # Create a string in the format:
    #   HTTP/1.1 200 OK\r\n
    #   Host: www.example.com\r\n
    #   Content-Length: 30\r\n
    #   Content-Type: text/plain; charset=utf-8\r\n
    #   Foo: A\r\n
    #   Foo: B\r\n

# Generated at 2022-06-11 23:52:17.965792
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
d: a
a: b
'''.lstrip()
    assert '''
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
d: a
a: b
'''.lstrip() == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-11 23:52:28.477487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers("""
    HTTP/1.1 500 Internal Server Error
    Connection: close
    Date: Fri, 22 Jun 2018 16:09:14 GMT
    Server: Apache/2.4.10 (Debian)
    Content-Length: 210
    Content-Type: application/json
    """)
    assert headers == ("\r\n"
                       "HTTP/1.1 500 Internal Server Error\r\n"
                       "Content-Length: 210\r\n"
                       "Content-Type: application/json\r\n"
                       "Connection: close\r\n"
                       "Date: Fri, 22 Jun 2018 16:09:14 GMT\r\n"
                       "Server: Apache/2.4.10 (Debian)")

# Generated at 2022-06-11 23:52:30.378938
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled == True
    assert HeadersFormatter().format_options['headers']['sort'] == True
    return

# Generated at 2022-06-11 23:52:39.724718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter() #
    input_headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Host: https://httpbin.org',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'Connection: keep-alive',
        'Accept-Encoding: gzip, deflate',
    ])
    output_headers = headers_formatter.format_headers(input_headers)

# Generated at 2022-06-11 23:52:48.163559
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    case1_input = '''Content-Type: application/json
X-Foo: Bar
Authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==
X-Foo: Baz
Cache-Control: no-cache
'''
    case1_expected_output = '''Content-Type: application/json
Authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==
X-Foo: Bar
X-Foo: Baz
Cache-Control: no-cache
'''
    case2_input = '''Content-Type: application/json
authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==
X-Foo: Bar
'''
    case2_expected_output

# Generated at 2022-06-11 23:52:55.140539
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter()
    headers = ('Content-Length: 0\r\n'
               'Content-Length: 1\r\n'
               'Content-Type: application/json\r\n')
    assert plugin.format_headers(headers) == ('Content-Length: 0\r\n'
                                              'Content-Length: 1\r\n'
                                              'Content-Type: application/json\r\n')

# Generated at 2022-06-11 23:53:05.512469
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    # Write your test below
    # f is a HeadersFormatter object
    # The following line will format the headers, the second parameter is
    # the headers you want to format, it is a string.
    result = f.format_headers('cache-control: public\ndate: Sat, 27 Apr 2019 10:09:15 GMT\nx-frame-options: SAMEORIGIN')
    # result is the result of formatting, it is a string too.
    # The class  HeadersFormatter has a method called format_format, you can use it to format the result.
    # The format function will produce a string that ends with "\r\n".
    result = f.format_format(result)
    print(result)

# Generated at 2022-06-11 23:53:06.328510
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__

# Generated at 2022-06-11 23:53:12.257574
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = (
        'Accept: application/json\r\n'
        'Content-Type: text/plain\r\n'
        'Content-Length: 1024\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Connection: keep-alive\r\n'
        '\r\n'
    )
    expected_headers = (
        'Accept: application/json\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Content-Length: 1024\r\n'
        'Content-Type: text/plain\r\n'
        'Connection: keep-alive\r\n'
        '\r\n'
    )

    formatter = HeadersFormatter()
    output_headers = formatter.format

# Generated at 2022-06-11 23:53:22.261678
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter('headers', sort=True)
    assert a.format_name == 'headers'
    assert a.format_options['headers']['sort'] is True


# Generated at 2022-06-11 23:53:28.286643
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 7
Accept: application/json
Connection: keep-alive
"""
    expected = """\
HTTP/1.1 200 OK
Accept: application/json
Connection: keep-alive
Content-Length: 7
Content-Type: application/json
"""
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-11 23:53:36.860055
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hs = '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'Accept-Language: en',
        'Cache-Control: no-cache',
        'Connection: keep-alive',
        'Host: httpbin.org',
        'User-Agent: HTTPie/0.9.2',
        'Pragma: no-cache',
        ''
    ])


# Generated at 2022-06-11 23:53:47.587371
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter(columns=80, color=False)
    headers = """\r
HTTP/1.1 200 OK\r
Connection: keep-alive\r
Content-Length: 13\r
Content-Type: application/json\r
Date: Sat, 24 Mar 2018 11:32:44 GMT\r
Server: nginx/1.13.5\r
\r
"""
    assert fmt.format_headers(headers) == """\
HTTP/1.1 200 OK\r
Connection: keep-alive\r
Content-Length: 13\r
Content-Type: application/json\r
Date: Sat, 24 Mar 2018 11:32:44 GMT\r
Server: nginx/1.13.5\r
\r
"""

# Setup for running tests in method headers_format

# Generated at 2022-06-11 23:53:56.784470
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class TestHeadersFormatter(HeadersFormatter):
        def format(self, headers: Union[HeadersDict, str], **kwargs) -> str:
            return self.format_headers(headers)

    test_headers_formatter = TestHeadersFormatter()
    with pytest.raises(TypeError):
        test_headers_formatter.format(headers=None)

    headers_str = '''
        HTTP/1.1 301 Redirect
        Location: https://example.com/foo
        X-Test-Header-1: 111111
        X-Test-Header-2: 222222
        X-Test-Header-2: 333333
        X-Test-Header-1: 444444
        '''

# Generated at 2022-06-11 23:54:06.033173
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create an instance of the class
    hf = HeadersFormatter()
    # Normalize headers
    headers_out = hf.format_headers("""GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.github.com
User-Agent: HTTPie/1.0.2


""")
    # Test that the headers are sorted
    assert headers_out == """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.github.com
User-Agent: HTTPie/1.0.2

"""
    # Test that the headers are still sorted when they are not normal
    # Normalize headers

# Generated at 2022-06-11 23:54:13.689322
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '''HTTP/1.0 200 OK
Content-Type: application/json; charset=utf-8
X-Foo: Bar
Allow: GET, HEAD, POST
X-Spam: Eggs
Set-Cookie: foo=bar; HttpOnly; Path=/'''
    assert hf.format_headers(headers) == '''HTTP/1.0 200 OK
Allow: GET, HEAD, POST
Content-Type: application/json; charset=utf-8
Set-Cookie: foo=bar; HttpOnly; Path=/
X-Foo: Bar
X-Spam: Eggs'''


# Generated at 2022-06-11 23:54:17.967394
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 21
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.2

key=value&key2=value2"""
    assert headers == HeadersFormatter().format_headers(headers)



# Generated at 2022-06-11 23:54:18.749499
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert callable(HeadersFormatter)

# Generated at 2022-06-11 23:54:21.614189
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('abc: 123\r\nX-Header2: bbb\r\nx-header: 456\r\n') == 'abc: 123\r\nX-Header2: bbb\r\nx-header: 456'



# Generated at 2022-06-11 23:54:37.809222
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers("""HTTP/1.1 200 OK
User-Agent: HTTPie/0.9.6
Server: BaseHTTP/0.3 Python/2.7.6
Content-Type: application/json
""") == """HTTP/1.1 200 OK
Content-Type: application/json
Server: BaseHTTP/0.3 Python/2.7.6
User-Agent: HTTPie/0.9.6
"""



# Generated at 2022-06-11 23:54:40.744283
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Create new instance of HeadersFormatter
    head_formatter = HeadersFormatter()

    # Check the enabled flag
    assert head_formatter.enabled == True



# Generated at 2022-06-11 23:54:45.366419
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert(f.format_headers("""HTTP/1.1 200 OK\nContent-Type: application/json\nDate: Sat, 23 Jun 2018 04:39:20 GMT\n\n{}""")
           == """HTTP/1.1 200 OK\nDate: Sat, 23 Jun 2018 04:39:20 GMT\nContent-Type: application/json\n\n{}""")

# Generated at 2022-06-11 23:54:51.112002
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head_formatter = HeadersFormatter.from_values(
        headers=['POST /api/search2/ HTTP/1.1',
                 'Accept: */*',
                 'Connection: close',
                 'Host: example.org',
                 'User-Agent: HTTPie/1.0.2-dev',
                 'Accept-Encoding: gzip, deflate',
                 'Content-Length: 197',
                 'Content-Type: application/x-www-form-urlencoded',
                 'Foo: Bar',
                 'Foo: Baz',
                 'Foo: Qux'],
        **constants.DEFAULT_OPTIONS)

    # Check if the method format_headers sorts headers by name
    # while retaining relative order of multiple headers with the
    # same name.

# Generated at 2022-06-11 23:55:00.224308
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Cache-control: no-cache\r\n'
        'Connection: keep-alive\r\n'
        'Date: Fri, 08 Nov 2019 10:45:59 GMT\r\n'
        'Content-Length: 12\r\n'
        '\r\n'
        '{"content": "foo"}'
    )

# Generated at 2022-06-11 23:55:04.884851
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('GET / HTTP/1.1\r\nContent-Type: text/plain\r\nHost: www.google.com\r\nUser-Agent: curl/7.73.0\r\n') == 'GET / HTTP/1.1\r\nContent-Type: text/plain\r\nHost: www.google.com\r\nUser-Agent: curl/7.73.0'



# Generated at 2022-06-11 23:55:08.480597
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('''\
GET / HTTP/1.1
Host: example.org
K: 2
A: 1
A: 3''') == '''\
GET / HTTP/1.1
A: 1
A: 3
K: 2
Host: example.org'''

# Generated at 2022-06-11 23:55:10.487830
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=None)
    assert formatter.enabled == True

# Generated at 2022-06-11 23:55:15.663898
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(stdin=io.StringIO(), stdout=io.StringIO(), stderr=io.StringIO()).format_headers('Accept: application/json\r\nContent-Type: application/json\r\nContent-Length: 33\r\n\r\n') == 'Accept: application/json\r\nContent-Length: 33\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-11 23:55:23.872410
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    sample = '''
HTTP/1.1 200 OK
Date: Sun, 12 Aug 2018 13:52:21 GMT
Server: Apache/2.4.7 (Ubuntu)
X-Powered-By: PHP/5.5.9-1ubuntu4.20
Set-Cookie: PHPSESSID=v4h4t4j7b4a3t3l7t3e2t2c7f; path=/
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
Access-Control-Allow-Origin: *
Vary: Accept-Encoding
Content-Encoding: gzip
Content-Length: 50
Content-Type: application/json; charset=UTF-8
'''
    f = HeadersForm

# Generated at 2022-06-11 23:55:54.208467
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:55:59.045339
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST /api/v1/personal_access_tokens HTTP/1.1
Host: example.org
Connection: close
Cache-Control: max-age=0
Cookie: a=b
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: navigate
Sec-Fetch-User: ?1
Sec-Fetch-Dest: document
Content-Type: application/json
Accept-Encoding: gzip, deflate, br
Accept-Language: en-US,en;q=0.9
Content-Length: 152
'''
    formatter = Headers

# Generated at 2022-06-11 23:56:07.776021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert headers_formatter.format_headers(
        """\
HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 13
Connection: keep-alive
X-Powered-By: Awesome
Server: Test
Date: Wed, 09 Mar 2016 01:36:24 GMT

Hello world!"""
    ) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: text/plain; charset=utf-8
Date: Wed, 09 Mar 2016 01:36:24 GMT
Server: Test
X-Powered-By: Awesome

Hello world!"""
    # Test for correct

# Generated at 2022-06-11 23:56:11.838506
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Connection: close
Content-Length: 6
Content-Type: text/html
H: x
H: y
H: z'''
    assert HeadersFormatter().format_headers(headers) == '''Connection: close
Content-Length: 6
Content-Type: text/html
H: x
H: y
H: z'''

# Generated at 2022-06-11 23:56:17.502482
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:56:24.961421
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual_headers = (
        'POST /post HTTP/1.1\r\n'
        'User-Agent: httpie\r\n'
        'X-Foo: Bar\r\n'
        'X-Baz: Qux\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: application/json\r\n'
        'Content-Length: 33\r\n'
        'Authorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ=\r\n'
        'Host: localhost:8000\r\n'
        'Connection: keep-alive\r\n'
        '\r\n'
        'username=John+Doe&password=12345'
    )
    expected

# Generated at 2022-06-11 23:56:27.453213
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options={'headers' : {'sort' : False}})
    assert headers.enabled == False
    assert headers.format_options['headers']['sort'] == False


# Generated at 2022-06-11 23:56:36.682467
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Explicitely set the generic dict format_options to the 'default' value
    # (see the internal _DEFAULT_FORMAT_OPTIONS attribute of httpie.context.Environment).
    #
    # This is to make the test independent from any external influence
    # (e.g. configuration file in user's home directory).
    format_options = {
        "escape_all": False,
        "headers": {"sort": True, "unique": False},
        "pretty": False,
        "style": {},
        "syntax": "auto",
    }

# Generated at 2022-06-11 23:56:39.187067
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.enabled is True


# Generated at 2022-06-11 23:56:43.998222
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    hf =HeadersFormatter()
    sut = hf.format_headers("""
User-Agent: curl/7.55.1
accept: */*
Host: postman-echo.com
content-type: application/json
content-length: 2
"""
                    )
    assert sut == """
User-Agent: curl/7.55.1
accept: */*
content-length: 2
content-type: application/json
Host: postman-echo.com
""".lstrip()


# Generated at 2022-06-11 23:57:43.590858
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\nContent-Length: 0\r\nHost: localhost:5432\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n"

# Generated at 2022-06-11 23:57:47.250032
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    GIVEN a HeadersFormatter instance
    WHEN the object is initialized
    THEN check the instance variables
    """
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options == {
        'headers': {
            'sort': False
        }
    }


# Generated at 2022-06-11 23:57:50.087637
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""\
HTTP/2 200
content-type: text/plain
date: Sun, 11 Aug 2019 18:53:36 GMT
server: gunicorn/19.9.0
transfer-encoding: chunked
""") == """\
HTTP/2 200
date: Sun, 11 Aug 2019 18:53:36 GMT
server: gunicorn/19.9.0
content-type: text/plain
transfer-encoding: chunked
"""

# Generated at 2022-06-11 23:58:00.149753
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

# Generated at 2022-06-11 23:58:03.868860
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter({'headers': {'sort': True}})
    assert obj.format_headers('\r\n'.join([
        '',
        'Abc: xyz',
        'Abc: 123',
        'Abc: BcD',
    ])) == '\r\n'.join([
        '',
        'Abc: xyz',
        'Abc: 123',
        'Abc: BcD',
    ])



# Generated at 2022-06-11 23:58:07.045101
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test def __init__(self, **kwargs):
    format_options = {'style': '__httpie__', 'headers': {'sort': True}}
    headers_formatter = HeadersFormatter(format_options)
    assert headers_formatter.format_options == format_options
    assert headers_formatter.enabled == True
