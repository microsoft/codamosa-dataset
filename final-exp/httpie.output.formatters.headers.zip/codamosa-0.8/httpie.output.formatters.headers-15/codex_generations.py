

# Generated at 2022-06-11 23:48:17.149140
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    a = HeadersFormatter(stdout=StringIO(), stderr=StringIO())
    inp = "HTTP/1.1 200 OK\r\n" \
          "Content-Length: 0\r\n" \
          "Cache-Control: no-cache\r\n" \
          "Cache-Control: no-store\r\n" \
          "Content-Type: text/plain\r\n" \
          "\r\n" \
          "\r\n"
    out = "HTTP/1.1 200 OK\r\n" \
          "Cache-Control: no-cache\r\n" \
          "Cache-Control: no-store\r\n" \
          "Content-Length: 0\r\n" \
          "Content-Type: text/plain\r\n" \
         

# Generated at 2022-06-11 23:48:27.899765
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class HeadersFormatter:
        def __init__(self):
            self.format_options = {'headers': {'sort': True}}

    formatter = HeadersFormatter()
    headers = '''\
POST / HTTP/1.1
Content-Type: application/json
X-Foo: Bar
Cookie: cookie1=val1
Accept: application/json
Cookie: cookie1=val1
Cookie: cookie2=val2
X-Bar: foo
'''

    actual = formatter.format_headers(headers)

# Generated at 2022-06-11 23:48:29.498491
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled


# Generated at 2022-06-11 23:48:34.932563
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
User-Agent: httpie/0.9.8
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
X-Custom: foo
X-Custom: bar
X-Custom: baz
Content-Length: 140023
Host: httpbin.org
Content-Type: multipart/form-data; boundary=347a5f5fde074b0889b0f3d54646ffa2"""

# Generated at 2022-06-11 23:48:44.685422
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter.format_headers(
        headers_long)
    expected = ('HTTP/1.1 200 OK\r\n'
                'Connection: keep-alive\r\n'
                'Content-Encoding: gzip\r\n'
                'Content-Length: 124\r\n'
                'Content-Type: application/json; charset=utf-8\r\n'
                'Date: Sun, 10 Jun 2018 10:48:18 GMT\r\n'
                'ETag: W/"7c-rcyBmzRtt7zeuY0lQVfD1eKXujE"\r\n'
                'Server: nginx\r\n'
                'Vary: Accept-Encoding\r\n'
                'X-Powered-By: Express')

# Generated at 2022-06-11 23:48:54.786380
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = (
        'GET / HTTP/1.1\r\n'
        'Accept: application/json\r\n'
        'Accept: application/xml\r\n'
        'Host: www.google.com\r\n'
        'X-Server: 5\r\n'
        'Z: 1\r\n'
        'Z: 2\r\n'
    )

# Generated at 2022-06-11 23:49:05.557010
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    output = HeadersFormatter().format_headers("""\
Host: localhost:5000
User-Agent: HTTPie/1.0.2
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 9
Content-Type: application/json
""")
    assert(output.splitlines()[0] == "Host: localhost:5000")
    assert(output.splitlines()[4] == "Accept: */*")
    assert(output.splitlines()[5] == "Accept-Encoding: gzip, deflate")
    assert(output.splitlines()[6] == "Content-Length: 9")
    assert(output.splitlines()[1] == "User-Agent: HTTPie/1.0.2")

# Generated at 2022-06-11 23:49:13.990948
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Connection: keep-alive
Content-Encoding: gzip
Content-Type: application/json; charset=utf-8
Date: Sun, 19 Jul 2015 17:41:57 GMT
Server: nginx
Set-Cookie: sessionid=t3s3s3; expires=Sun, 02-Aug-2015 17:41:57 GMT; HttpOnly; Max-Age=1209600; Path=/
Transfer-Encoding: chunked
Vary: Accept, Cookie
"""

# Generated at 2022-06-11 23:49:21.736474
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=False)
    sorted_headers = formatter.format_headers("""\
Accept: */*
Content-Type: application/json
Content-Length: 50
Host: www.example.com
Connection: close
Content-Length: 60
Content-Type: application/xml
""")

    expected_headers = """\
Accept: */*
Connection: close
Content-Type: application/json
Content-Type: application/xml
Content-Length: 50
Content-Length: 60
Host: www.example.com
"""
    assert sorted_headers == expected_headers

# Generated at 2022-06-11 23:49:30.360643
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Vary: Accept-Language, Cookie
Content-Language: de-DE
Content-Language: en
Content-Type: text/html; charset=utf-8
Set-Cookie: csrftoken=X; expires=Wed, 08 Nov 2017 04:51:24 GMT; Max-Age=31449600; Path=/
Date: Mon, 09 Oct 2017 04:51:24 GMT
""".strip()

# Generated at 2022-06-11 23:49:42.272701
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options=DEFAULT_OPTIONS)
    headers = 'HTTP/1.1 200 OK\r\n' \
        'Content-Type:  application/json\r\n' \
        'Content-Length:  100\r\n' \
        'Accept-Charset: utf-8\r\n' \
        'Accept-Encoding:  gzip, deflate\r\n' \
        'Accept:  application/json\r\n' \
        'Host:  httpbin.org\r\n' \
        'User-Agent: HTTPie/0.9.6\r\n'
    formatter_headers = headers_formatter.format_headers(headers)
    expected_headers = 'HTTP/1.1 200 OK\r\n'

# Generated at 2022-06-11 23:49:52.625445
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'X-XSS-Protection: 1; mode=block\r\n' \
              'Transfer-Encoding: chunked\r\n' \
              'X-Frame-Options: SAMEORIGIN\r\n' \
              'Content-Length: 15\r\n' \
              'Date: Fri, 21 Apr 2017 13:53:53 GMT\r\n' \
              'Server: nginx\r\n' \
              '\r\n' \
              '[[809,"o{GryL~"]]'

# Generated at 2022-06-11 23:50:01.386484
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(
        '''HTTP/1.1 200 OK
Server: nginx/1.14.0 (Ubuntu)
Content-Type: application/json
Content-Length: 359
Connection: keep-alive
Date: Sun, 09 Sep 2018 11:30:54 GMT
''') == (
        '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 359
Content-Type: application/json
Date: Sun, 09 Sep 2018 11:30:54 GMT
Server: nginx/1.14.0 (Ubuntu)
''')



# Generated at 2022-06-11 23:50:04.411528
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(
        format_options={'headers': {'sort': False}}
    ).enabled == False
    assert HeadersFormatter(
        format_options={'headers': {'sort': True}}
    ).enabled == True


# Generated at 2022-06-11 23:50:09.272788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = "HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\nFoo: Bar\r\nBaz: 1\r\nBaz: 2\r\n"
    expected = "HTTP/1.1 200 OK\r\nBaz: 1\r\nBaz: 2\r\nContent-Encoding: gzip\r\nFoo: Bar\r\n"
    assert formatter.format_headers(input) == expected


# Generated at 2022-06-11 23:50:09.819341
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-11 23:50:15.149426
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
content-length: 123\r
content-type: text/plain\r
host: www.example.com\r
connection: close\r
\r
'''
    assert HeadersFormatter().format_headers(h) == '''\
content-length: 123\r
content-type: text/plain\r
host: www.example.com\r
connection: close\r
\r
'''



# Generated at 2022-06-11 23:50:25.417997
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Cache-Control: no-cache',
        'Content-Length: 181',
        'Vary: Authorization',
        'Vary: Cookie',
        'Content-Type: application/json',
        'Date: Sun, 30 Apr 2017 14:02:18 GMT'
    ])

# Generated at 2022-06-11 23:50:31.161396
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers('''\
HTTP/2 200
content-type: application/json
content-length: 17
server: gunicorn/19.9.0
date: Wed, 18 Dec 2019 00:00:21 GMT

''') == '''\
HTTP/2 200
content-length: 17
content-type: application/json
date: Wed, 18 Dec 2019 00:00:21 GMT
server: gunicorn/19.9.0

'''

# Generated at 2022-06-11 23:50:42.186777
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:50:49.193801
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert True


# Generated at 2022-06-11 23:50:53.966554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = '\r\n'.join([
        'GET / HTTP/1.1',
        'Cookie: foo=bar',
        'Content-Type: application/json',
        'X-Auth: 1234',
        '', ''
    ])
    actual = HeadersFormatter(format_options = {'headers': {'sort': True}}).format_headers(
        '\r\n'.join([
            'GET / HTTP/1.1',
            'X-Auth: 1234',
            'Content-Type: application/json',
            'Cookie: foo=bar',
            '', ''
        ]))
    assert actual == expected, 'Method format_headers of class HeadersFormatter does not sort headers'


# Generated at 2022-06-11 23:50:59.452570
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    text = '''
HTTP/1.1 200 OK
date: Mon, 23 May 2005 22:38:34 GMT
eTag: "10000000565a5-2c-3e94b66c2e680"
content-Type: text/html; charset=UTF-8
Content-Length: 130
Server: Jetty(9.2.15.v20160210)
Connection: close

'''

# Generated at 2022-06-11 23:51:07.663659
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    headers = "GET / HTTP/1.1\r\nAccept: text/html\r\nCookie: a=b\r\nCookie: c=d\r\nAccept: application/json\r\n\r\n"
    formatter = HeadersFormatter()

    # Execute
    result = formatter.format_headers(headers)

    # Verify
    expected = "GET / HTTP/1.1\r\nAccept: text/html\r\nAccept: application/json\r\nCookie: a=b\r\nCookie: c=d\r\n\r\n"
    assert result == expected


# Generated at 2022-06-11 23:51:16.665723
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers1 = '''\
HTTP/1.1 100 Switching Protocols
Upgrade: websocket
Connection: Upgrade
Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=
Sec-WebSocket-Protocol: chat
'''
    headers2 = '''\
HTTP/1.1 100 Switching Protocols
Connection: Upgrade
Upgrade: websocket
Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=
Sec-WebSocket-Protocol: chat
'''
    assert HeadersFormatter.format_headers(headers1) == headers2

# Generated at 2022-06-11 23:51:17.701594
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Generated at 2022-06-11 23:51:27.304569
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter(**{'headers': {'sort': True}})
    assert h.format_headers('GET http://www.google.com/ HTTP/1.1\r\nAccept: */*\r\nConnection: keep-alive\r\nAccept-Encoding: gzip, deflate\r\nCookie: 1=1\r\n') == 'GET http://www.google.com/ HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nCookie: 1=1\r\nConnection: keep-alive\r\n'

# Generated at 2022-06-11 23:51:29.543031
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    args = []
    headers_formatter = HeadersFormatter(
        args=args, format_options=FormatOptions()
    )
    assert headers_formatter.enabled == True
    
    

# Generated at 2022-06-11 23:51:40.815234
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:51:42.604432
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={}, config={})
    assert formatter.enabled == False
    

# Generated at 2022-06-11 23:51:56.883028
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin_name = 'HeaderFormatter'
    plugin_manager = PluginManager(consume_exceptions=True, load_plugins=[HeadersFormatter])
    plugin = plugin_manager.get_plugin('formatter', formatter_plugin_name)
    header = "HTTP/2.0 200 OK\r\nserver: nginx\r\ncontent-length: 13\r\ncontent-type: application/json\r\ncontent-location: https://test.test/test\r\n:status: 200\r\n"
    actual = plugin.format_headers(header)

# Generated at 2022-06-11 23:52:06.749998
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    form_headers = HeadersFormatter.format_headers
    assert form_headers("GET / HTTP/1.1\r\nX-XSS: one\r\nX-XSS: two\r\n\r\n") == "GET / HTTP/1.1\r\nX-XSS: one\r\nX-XSS: two\r\n\r\n"
    assert form_headers("GET / HTTP/1.1\r\nX-XSS: two\r\nX-XSS: one\r\n\r\n") == "GET / HTTP/1.1\r\nX-XSS: one\r\nX-XSS: two\r\n\r\n"

# Generated at 2022-06-11 23:52:14.429119
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('''\
HTTP/1.1 200 OK
Date: Thu, 14 Jun 2018 16:22:31 GMT
Server: Apache
X-Frame-Options: SAMEORIGIN
Vary: Accept-Encoding
Content-Length: 37
Connection: close
Content-Type: text/html; charset=UTF-8''') == '''\
HTTP/1.1 200 OK
Content-Length: 37
Content-Type: text/html; charset=UTF-8
Connection: close
Date: Thu, 14 Jun 2018 16:22:31 GMT
Server: Apache
Vary: Accept-Encoding
X-Frame-Options: SAMEORIGIN'''


# Adding instance of HeadersFormatter class to the list of formatter plugins

# Generated at 2022-06-11 23:52:15.587620
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter().format_options, dict)


# Generated at 2022-06-11 23:52:26.368345
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Transfer-Encoding: chunked\r\n'
        'Server: nginx\r\n'
        'Header: value\r\n'
        'Content-Type: application/json\r\n'
        'Last-Modified: Thu, 10 Sep 2015 07:48:19 GMT\r\n'
    )

# Generated at 2022-06-11 23:52:36.541849
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter.

    """
    headers = "Content-Type: text/plain; charset=utf-8\r\n" \
              "Date: Sun, 21 Aug 2016 01:08:56 GMT\r\n" \
              "Server: WSGIServer/0.1 Python/3.5.2\r\n" \
              "X-Content-Type-Options: nosniff\r\n" \
              "Content-Length: 2\r\n" \
              "X-Frame-Options: DENY\r\n" \
              "X-XSS-Protection: 1; mode=block"


# Generated at 2022-06-11 23:52:44.380973
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = (
        "GET / HTTP/1.1\r\n"
        "Accept: */*\r\n"
        "Content-Length: 11\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\n"
        "Host: httpbin.org\r\n"
        "User-Agent: HTTPie/0.9.9")
    output = (
        "GET / HTTP/1.1\r\n"
        "Accept: */*\r\n"
        "Content-Length: 11\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\n"
        "Host: httpbin.org\r\n"
        "User-Agent: HTTPie/0.9.9")
    hf

# Generated at 2022-06-11 23:52:48.461165
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    string_one = 'Line1\r\nLine2\r\nLine3\r\nLine4'
    string_two = 'Line1\r\nLine3\r\nLine2\r\nLine4'
    assert formatter.format_headers(string_one) == formatter.format_headers(string_two)

# Generated at 2022-06-11 23:52:58.771430
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	formatter = HeadersFormatter()

	headers = 'HTTP/1.1 200 OK\r\nSet-Cookie: 1\r\nSet-Cookie: 2\r\nSet-Cookie: 3\r\nContent-Type: application/json\r\n'
	expected_headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nSet-Cookie: 1\r\nSet-Cookie: 2\r\nSet-Cookie: 3\r\n'
	assert(formatter.format_headers(headers) == expected_headers)


# Generated at 2022-06-11 23:53:08.670218
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(
        """HTTP/1.1 200 OK
Content-Length: 13
Cache-Control: no-cache
X-Some-Header: foo
Content-Length: 13
Set-Cookie: foo=bar
Content-Type: application/json; charset=utf-8
X-Some-Header: spam
Server: waitress\r
\r
"""
    ) == """HTTP/1.1 200 OK
Content-Length: 13
Content-Length: 13
Cache-Control: no-cache
Content-Type: application/json; charset=utf-8
Server: waitress
Set-Cookie: foo=bar
X-Some-Header: foo
X-Some-Header: spam
\r
\r
"""

# Generated at 2022-06-11 23:53:30.044479
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    hfmt = HeadersFormatter()

    headers = """\
HTTP/1.1 200 OK
Date: Thu, 17 Sep 2015 07:05:12 GMT
Server: Apache/2.2.15 (CentOS)
Last-Modified: Mon, 04 May 2015 19:56:58 GMT
ETag: "530ca-51-5189fbb97c5c0"
Accept-Ranges: bytes
Content-Length: 81
Connection: close
Content-Type: text/html

"""


# Generated at 2022-06-11 23:53:38.154183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Date: Thu, 20 Aug 2020 17:26:33 GMT
Server: Apache/2.4.43 (Unix)
Strict-Transport-Security: max-age=63072000; includeSubDomains
X-Xss-Protection: 1; mode=block
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
X-Frame-Options: sameorigin
Content-Security-Policy: default-src 'self'
X-Permitted-Cross-Domain-Policies: none
Content-Security-Policy-Report-Only: default-src 'self'; report-uri https://example.com/csp-report
Content-Length: 45
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: application/json'''


# Generated at 2022-06-11 23:53:48.898802
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

    # Test with only one line
    headers = 'Host: example.com'
    res = headers_formatter.format_headers(headers)
    assert res == headers

    # Test with multiple lines
    headers = """Content-Type: application/json
    Host: example.com
    User-Agent: my-http-client/1.0
    Accept: */*
    Content-Length: 2
    Authorization: Bearer FOOBAR
    """
    res = headers_formatter.format_headers(headers)
    assert res == """Content-Type: application/json
    Accept: */*
    Authorization: Bearer FOOBAR
    Content-Length: 2
    Host: example.com
    User-Agent: my-http-client/1.0"""

# Generated at 2022-06-11 23:53:58.107313
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Unit test for method format_headers of class HeadersFormatter."""
    # Initialization
    formatter = HeadersFormatter(format_options={'headers':{'sort': True}})

    # Input arguments
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 209
Connection: keep-alive
Date: Thu, 02 Jul 2020 00:50:44 GMT
footer: footer
header: header
A: D
C: F
E: H
B: E
D: G'''

    # Expected output

# Generated at 2022-06-11 23:54:04.822022
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """Accept: application/json,*/*
User-Agent: HTTPie/1.0.2
Connection: keep-alive
Host: httpbin.org
Accept-Encoding: gzip, deflate
"""
    expected_headers = """Accept: application/json,*/*
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/1.0.2
Accept-Encoding: gzip, deflate
"""
    assert HeadersFormatter.format_headers(headers) == expected_headers


plugin_cls = HeadersFormatter

# Generated at 2022-06-11 23:54:06.876223
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    assert a.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-11 23:54:15.373931
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test default sorting of headers
    f1 = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert f1.format_headers('HTTP/1.1 200\r\nFoo: One\r\nBar: Two\r\nFoo: Three') == \
           'HTTP/1.1 200\r\nBar: Two\r\nFoo: One\r\nFoo: Three'

    # Test disabled sorting of headers
    f2 = HeadersFormatter(format_options={'headers': {'sort': False}})

# Generated at 2022-06-11 23:54:23.942408
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_str = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Host: localhost
Cache-Control: max-age=63080000
Connection: keep-alive
Date: Thu, 03 Jan 2019 05:19:17 GMT
Via: 1.1 vegur.'''.replace('\n', '\r\n')

# Generated at 2022-06-11 23:54:31.477458
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual_result = HeadersFormatter().format_headers('GET / HTTP/1.1\r\nX-Abc: def\r\n'
                                                     'X-A-B-C: def\r\nX-Test: test\r\n'
                                                     'X-Abc: def\r\nX-Test: test2\r\n')
    expected_result = 'GET / HTTP/1.1\r\nX-A-B-C: def\r\nX-Abc: def\r\nX-Abc: def\r\n' \
                      'X-Test: test\r\nX-Test: test2\r\n'
    assert actual_result == expected_result



# Generated at 2022-06-11 23:54:36.590582
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Make sure the constructor is called correctly
    formatter = HeadersFormatter({}, format_options={'headers': {'sort': False}})
    assert formatter.enabled == False

    # Check the default value of the enabled field
    formatter = HeadersFormatter({}, format_options={'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-11 23:55:18.553801
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    assert obj.format_headers("""\
HTTP/1.1 200 OK
Content-Type: text/plain
Expires: Sun, 17 Jan 2038 19:14:07 GMT
Last-Modified: Sat, 20 May 2017 17:26:38 GMT
Content-Length: 3
Date: Sat, 20 May 2017 17:26:38 GMT

""") == """\
HTTP/1.1 200 OK
Content-Length: 3
Content-Type: text/plain
Date: Sat, 20 May 2017 17:26:38 GMT
Expires: Sun, 17 Jan 2038 19:14:07 GMT
Last-Modified: Sat, 20 May 2017 17:26:38 GMT

"""

# Generated at 2022-06-11 23:55:22.220579
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={
        'headers':
            {
                'sort': True
            }
    })
    assert headers_formatter.format_headers(
        """\
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 75
Connection: keep-alive
"""
    ) == """\
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 75
Connection: keep-alive
"""

# Generated at 2022-06-11 23:55:28.925907
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
HTTP/1.1 200 OK
Date: Sat, 16 Mar 2019 03:18:24 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 38
Server: Werkzeug/0.14.1 Python/3.7.0

<h1>Hello world</h1>
    """
    assert formatter.format_headers(headers) == """
HTTP/1.1 200 OK
Content-Length: 38
Content-Type: text/html; charset=utf-8
Date: Sat, 16 Mar 2019 03:18:24 GMT
Server: Werkzeug/0.14.1 Python/3.7.0

<h1>Hello world</h1>
    """



# Generated at 2022-06-11 23:55:36.513080
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = """
    HTTP/1.1 200 OK
    Content-Type: application/json; charset=utf-8
    Connection: Close
    Set-Cookie: cookie_name=123
    Set-Cookie: cookie_name=456
    """
    output = """
    HTTP/1.1 200 OK
    Connection: Close
    Content-Type: application/json; charset=utf-8
    Set-Cookie: cookie_name=123
    Set-Cookie: cookie_name=456
    """
    assert formatter.format_headers(input) == output

"""
    Sorts querystring keys alphabetically.
"""

# Generated at 2022-06-11 23:55:39.890212
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_text = """
X-API-Token: 123
Content-Type: application/json
Accept: application/json
X-API-Token: 321
"""
    expected_headers_text = """
X-API-Token: 123
X-API-Token: 321
Content-Type: application/json
Accept: application/json
"""
    assert (f.format_headers(headers_text) == expected_headers_text)

# Generated at 2022-06-11 23:55:49.983351
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = """\
GET / HTTP/1.1
Accept: */*
Connection: close
Content-Length: 71
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.3
Accept-Encoding: gzip, deflate, compress
"""
    headers_sorted = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Connection: close
Content-Length: 71
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.3
"""

    out = formatter.format_headers(headers)
    assert out == headers_sorted

    out = form

# Generated at 2022-06-11 23:55:57.488209
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    text = "HTTP/1.1 200 OK\r\nContent-type:text/html; charset=UTF-8\r\nContent-Length: 5\r\nDate: Mon, 05 Oct 2020 10:24:44 GMT"
    expected = "HTTP/1.1 200 OK\r\nContent-Length: 5\r\nContent-type:text/html; charset=UTF-8\r\nDate: Mon, 05 Oct 2020 10:24:44 GMT"
    assert expected == formatter.format_headers(text)


# Generated at 2022-06-11 23:56:06.365414
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Date: Thu, 05 Jul 2018 20:38:44 GMT
Server: Apache/2.4.10 (Ubuntu)
X-Powered-By: PHP/5.5.24
Vary: Accept-Encoding
Content-Length: 2
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=UTF-8

"""

    headers_formatted = headers_formatter.format_headers(headers)

# Generated at 2022-06-11 23:56:14.614628
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:56:18.727419
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter()

    result = plugin.format_headers("""\
HTTP/1.1 200 OK
Header: one
Header: two
Header: three
Header: four
Header: five
""")

    assert result == """\
HTTP/1.1 200 OK
Header: one
Header: two
Header: three
Header: four
Header: five
"""

# Generated at 2022-06-11 23:57:11.437945
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from io import StringIO
    from httpie.plugins import plugin_manager

    plugin_manager.load_installed_plugins()

    # Test single header
    output = StringIO()
    formatter = HeadersFormatter(output_file=output, sort_headers=False)
    formatter.format_headers('Content-Length: 10\r\n')
    assert output.getvalue() == 'Content-Length: 10'

    # Test multiple headers
    output = StringIO()
    formatter = HeadersFormatter(output_file=output, sort_headers=False)
    formatter.format_headers('Content-Length: 10\r\nContent-Type: text/plain\r\n')
    assert output.getvalue() == 'Content-Length: 10\r\nContent-Type: text/plain'

    # Test multiple headers with same

# Generated at 2022-06-11 23:57:20.980748
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers1 = """
HTTP/1.1 200 OK
Server: nginx/1.15.5
Date: Thu, 26 Sep 2019 14:10:23 GMT
Content-Type: application/json
Content-Length: 6
Last-Modified: Wed, 25 Sep 2019 09:03:57 GMT
Connection: keep-alive
ETag: "5d8a1b35-6"
Access-Control-Allow-Origin: *
Allow: GET, HEAD, POST, PUT, PATCH, DELETE, CONNECT, OPTIONS, TRACE
Vary: Accept-Encoding

Hello
"""

# Generated at 2022-06-11 23:57:29.799676
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    input_headers = '''\
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 5
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/2.2.0 
Host: httpbin.org\r\n'''
    expected_headers = '''\
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 5
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/2.2.0 
Host: httpbin.org\r\n'''
    output_headers = headers_formatter.format_headers(input_headers)

# Generated at 2022-06-11 23:57:34.745208
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    h = f.format_headers("""HTTP/1.1 200 OK
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-us
Content-Type: application/json""")
    assert h == """HTTP/1.1 200 OK
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-us
Content-Type: application/json"""

# Generated at 2022-06-11 23:57:45.142114
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    testHeader = '''\
GET / HTTP/1.1
User-Agent: HTTPie/0.13.9
Accept-Encoding: gzip, deflate
Accept: */*
Host: httpbin.org
Connection: keep-alive
Cookie: _gauges_unique=1; _gauges_unique_year=1; _gauges_unique_month=1; _gauges_unique_day=1; _gauges_unique_hour=1\r\n'''
    result = headers.format_headers(testHeader)

# Generated at 2022-06-11 23:57:47.251002
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # TODO: Add unit test
    pass

# Disabled unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:57:51.425786
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    headers = """\
GET / HTTP/1.1
Host: $HOST
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 0
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.2
X-Auth-Token: $TOKEN
Auth-Token: $TOKEN
"""
    # When
    formatter = HeadersFormatter()
    out_headers = formatter.format_headers(headers)
    # Then
    # Whitespace removed for test clarity

# Generated at 2022-06-11 23:58:00.586443
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:58:06.018059
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter
    """