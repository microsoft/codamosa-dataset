

# Generated at 2022-06-11 23:48:16.793982
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    class HeadersFormatter2(HeadersFormatter):

        def __init__(self, **kwargs):

            # Make the formatter 'enabled' despite not requested in format_options
            super().__init__(**kwargs)
            self.enabled = True

    class FormatOptions:
        def __init__(self):
            sort = True
            width = 1
            serialize_json = True

        def __getitem__(self, name: str):
            if name == 'headers':
                return FormatOptions()

    format_options = FormatOptions()
    formatter = HeadersFormatter2(format_options=format_options)
    example_headers = """Content-Type: application/json
Content-Length: 45
Authorization: Basic dXNlcjpwYXNz
"""

# Generated at 2022-06-11 23:48:21.152513
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header = HeadersFormatter(format_options={'headers': {'sort': True} })
    output = header.format_headers("""\
Content-Type: text/csv
Status: 200 OK
Content-Encoding: gzip
Content-Length: 1234
""")
    expected = """\
Content-Type: text/csv
Content-Encoding: gzip
Content-Length: 1234
Status: 200 OK
"""
    assert output == expected



# Generated at 2022-06-11 23:48:31.067136
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True, 'style': 'all'}})
    expected = '''
HTTP/1.1 200 OK\r
Server: nginx/1.10.3 (Ubuntu)\r
Set-Cookie: Bar=bar_val; expires=Mon, 05-Mar-2018 14:22:31 GMT; Max-Age=300; path=/\r
Set-Cookie: Foo=foo_val; expires=Mon, 05-Mar-2018 14:22:31 GMT; Max-Age=300; path=/\r
Content-Length: 22\r
Date: Sun, 04 Mar 2018 14:22:31 GMT\r
Content-Type: text/html; charset=UTF-8\r'''

# Generated at 2022-06-11 23:48:34.413947
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {
            'sort': True
        }
    }

    headers_formatter = HeadersFormatter(format_options)
    assert headers_formatter.enabled == True


# Generated at 2022-06-11 23:48:44.208244
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:48:54.361185
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test case for method format_headers of class HeadersFormatter.
    :return:
    """
    hf = HeadersFormatter()

    # Test case for sorting of multiple headers
    # with same name in a single line
    headers = '''
HTTP/1.1 200 OK
Age: 100
Age: 200
Date: Thu, 09 Jun 2016 12:52:00 GMT
content-type: text/html; charset=UTF-8
cache-control: max-age=0, must-revalidate, no-cache, no-store
Age: 10
Age: 15
'''

# Generated at 2022-06-11 23:48:56.642203
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	try:
		headers_formatter = HeadersFormatter()
	except Exception as e:
		print(e)
	finally:
		assert 1


# Generated at 2022-06-11 23:48:58.403874
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter) == True


# Generated at 2022-06-11 23:49:08.861856
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_obj = HeadersFormatter()

    # Unsorted headers
    headers_str = (
        "HTTP/1.1 200 OK\r\n"
        "Content-Length: 12\r\n"
        "Content-Type: application/json\r\n"
        "Date: Sat, 24 Aug 2019 16:58:30 GMT\r\n"
        "Server: Werkzeug/0.15.3 Python/3.7.3\r\n"
        "X-Powered-By: Flask/1.0.2\r\n"
    )
    headers = headers_formatter_obj.format_headers(headers_str)

# Generated at 2022-06-11 23:49:13.031949
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == False
    hf.format_options['headers']['sort'] = True
    assert hf.enabled == True

# Unit tests for format_headers method of class HeadersFormatter

# Generated at 2022-06-11 23:49:21.520210
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Host: httpbin.org\r\nAccept: application/json\r\nUser-Agent: HTTPie/1.0.0\r\n\r\n') == 'Host: httpbin.org\r\nAccept: application/json\r\nUser-Agent: HTTPie/1.0.0'

# Generated at 2022-06-11 23:49:29.406404
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_string = """Content-Type: application/x-www-form-urlencoded
    Host: users.cecs.anu.edu.au
    Content-Length: 54
    Cookie: auth=PASS
    Connection: Keep-Alive
    User-Agent: HTTPie/0.9.8

    """
    assert HeadersFormatter().format_headers(header_string) == """Content-Type: application/x-www-form-urlencoded
Content-Length: 54
Cookie: auth=PASS
Connection: Keep-Alive
Host: users.cecs.anu.edu.au
User-Agent: HTTPie/0.9.8

    """


# Generated at 2022-06-11 23:49:39.865389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'User-Agent: HTTPie/1.0.0 Darwin/19.2.0',
        'Accept-Encoding: gzip, deflate',
        'Host: localhost:5000',
        'Connection: keep-alive',
        'Accept: */*',
        'Content-Length: 24',
        'Content-Type: application/x-www-form-urlencoded',
    ])

# Generated at 2022-06-11 23:49:49.972262
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'GET /page HTTP/1.1',
        'Content-Type: application/json',
        'If-None-Match: "abc"',
        'If-None-Match: "xyz"',
        'Accept: application/json',
        'Accept: application/xml'
    ])
    result = HeadersFormatter().format_headers(headers)
    assert (
        result ==
        '\r\n'.join([
            'GET /page HTTP/1.1',
            'Accept: application/json',
            'Accept: application/xml',
            'If-None-Match: "abc"',
            'If-None-Match: "xyz"',
            'Content-Type: application/json'
        ])
    )

# Generated at 2022-06-11 23:49:56.650216
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\n'.join([
        'Content-Type: application/json',
        'Accept: application/json',
        'Content-Length: 9982',
        'Connection: keep-alive'
    ])).splitlines() == [
        'Content-Length: 9982',
        'Content-Type: application/json',
        'Connection: keep-alive',
        'Accept: application/json'
    ]


# Generated at 2022-06-11 23:50:04.493823
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """Your IP Address is:
User-Agent: httpie
User-Agent: you-agent/0.9.5
Accept: */*
Accept-Encoding: gzip, deflate
Host: httpbin.org
"""
    assert hf.format_headers(headers) == """Your IP Address is:
Accept: */*
Accept-Encoding: gzip, deflate
Host: httpbin.org
User-Agent: httpie
User-Agent: you-agent/0.9.5
"""


# Class Web: GUI class for webserver

# Generated at 2022-06-11 23:50:10.949365
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter

    """
    import httpie
    formatter = HeadersFormatter(httpie.core.Environment())

# Generated at 2022-06-11 23:50:17.926362
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	# Arrange
	headers = '''HTTP/1.1 200 OK
	X-Crawlera-Cookies: disable=true
	X-Crawlera-Profile: desktop
	X-Crawlera-UA: Mozilla/5.0 (Linux; Android 4.4.4; One Build/KTU84L.H4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.135 Mobile Safari/537.36
	Content-Length: 6913
	X-Crawlera-Error: False
	Date: Sat, 18 Apr 2020 13:07:54 GMT
	Content-Type: text/html; charset=utf-8
	X-Crawlera-Session: 5e9b871f5e9b870005e9b871f'''
	
	# Act
	format

# Generated at 2022-06-11 23:50:23.111059
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter()
    headers = '''GET /path HTTP/1.1
Host: example.com
User-Agent: httpie
Accept: ''
Connection: close
Accept-Encoding: gzip, deflate
Accept-Language: hello world'''

    print(formatter_plugin.format_headers(headers))

# Test httpie plugin

# Generated at 2022-06-11 23:50:31.932944
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers(
        """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Pragma: no-cache
Content-Length: 1919
Content-Type: text/html; charset=utf-8
Expires: -1
Server: Microsoft-IIS/7.5
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Thu, 27 Feb 2020 19:57:36 GMT

"""
)


# Generated at 2022-06-11 23:50:45.003607
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers_in = """
HTTP/1.1 200 OK
Server: nginx/1.6.2
Date: Mon, 04 May 2015 19:37:35 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 305
Connection: keep-alive
Cache-Control: no-cache
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
OkHttp-Received-Millis: 1430788255869
"""

# Generated at 2022-06-11 23:50:53.636681
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-11 23:51:02.770037
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_string = """\
GET / HTTP/1.1
Host: example.com
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 100
Content-Type: application/json
User-Agent: HTTPie/0.9.9
X-Forwarded-For: 10.22.5.5
"""
    formatter = HeadersFormatter()
    new_header_order = formatter.format_headers(header_string)

# Generated at 2022-06-11 23:51:08.671101
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    actual = hf.format_headers('HTTP/1.1 123 OK\r\n'
                               'Content-Type: application/json\r\n'
                               'Cache-Control: no-cache\r\n'
                               'Cache-Control: private\r\n')
    expected = ('HTTP/1.1 123 OK\r\n'
                'Cache-Control: no-cache\r\n'
                'Cache-Control: private\r\n'
                'Content-Type: application/json')
    assert actual == expected


# Generated at 2022-06-11 23:51:19.244212
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "Test-Header-1: test_value\r\n" \
        "Test-Header-2: test_value\r\n" \
        "Test-Header-3: test_value\r\n" \
        "Some-Header: test_value"

    assert formatter.format_headers(headers) == \
        "Test-Header-1: test_value\r\n" \
        "Test-Header-2: test_value\r\n" \
        "Test-Header-3: test_value\r\n" \
        "Some-Header: test_value"


# Generated at 2022-06-11 23:51:21.037971
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:51:28.383183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled
    headers = """\
HTTP/1.1 200 OK
Connection: close
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/1.0.0"""
    expected_headers = """\
HTTP/1.1 200 OK
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Host: httpbin.org
User-Agent: HTTPie/1.0.0"""
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-11 23:51:39.071024
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:51:44.188847
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''Content-Type: application/json; charset=utf-8\r
Date: Mon, 09 Sep 2019 07:32:02 GMT\r
Server: BaseHTTP/0.6 Python/3.7.3\r
Transfer-Encoding: chunked'''

# Generated at 2022-06-11 23:51:51.945889
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Connection: keep-alive
Content-Length: 7
Cookie: session_id=1234
Content-Length: 7
Accept: */*
Cookie: authorization_token=abcd
'''
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    formatter.format_headers(headers)
    expected = '''\
Connection: keep-alive
Accept: */*
Content-Length: 7
Content-Length: 7
Cookie: session_id=1234
Cookie: authorization_token=abcd
'''
    assert expected == formatter.format_headers(headers)


# Generated at 2022-06-11 23:52:02.699412
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Sat, 08 Sep 2018 00:00:00 GMT
...

"""
    assert f.format_headers(headers) == """\
HTTP/1.1 200 OK
Date: Sat, 08 Sep 2018 00:00:00 GMT
...

"""

# Generated at 2022-06-11 23:52:11.568888
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:52:18.876250
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Header-D: 123',
        'Header-A: 1',
        'Header-B: 2',
        'Header-A: 3'
    ])
    assert HeadersFormatter.format_headers(headers) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Header-A: 1',
        'Header-A: 3',
        'Header-B: 2',
        'Header-D: 123',
    ])



# Generated at 2022-06-11 23:52:29.112082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\n'.join([
        'HTTP/1.1 200 OK',
        'Date: Tue, 03 Dec 2013 01:44:20 GMT',
        'Expires: -1',
        'Cache-Control: private, max-age=0',
        'Content-Type: text/html; charset=UTF-8',
        'Content-Encoding: gzip',
        'Server: gws',
        'X-XSS-Protection: 1; mode=block',
        'X-Frame-Options: SAMEORIGIN',
        'Alternate-Protocol: 443:quic',
        'Transfer-Encoding: chunked'
    ])


# Generated at 2022-06-11 23:52:38.678827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Content-Type: text/html\r\nContent-Type:text/css\r\nTransfer-Encoding: chunked') == 'Content-Type: text/html\r\nContent-Type:text/css\r\nTransfer-Encoding: chunked'
    assert headers_formatter.format_headers('Content-Type: text/html\r\nTransfer-Encoding: chunked\r\nContent-Type:text/css') == 'Content-Type: text/html\r\nContent-Type:text/css\r\nTransfer-Encoding: chunked\r\n'

# Generated at 2022-06-11 23:52:47.064379
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK\r
Server: nginx/1.10.3 (Ubuntu)\r
Content-Type: text/html; charset=UTF-8\r
Content-Length: 10645\r
Connection: close\r
Date: Tue, 19 Sep 2017 06:39:07 GMT\r
Cache-Control: no-cache, private\r
X-RateLimit-Limit: 60\r
X-RateLimit-Remaining: 59\r
X-RateLimit-Reset: 1505768948\r\
X-Frame-Options: SAMEORIGIN\r
\r'''


# Generated at 2022-06-11 23:52:57.611219
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:53:07.869982
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_str = "HTTP/1.1 200 OK\r\n" \
                  "Content-Type: text/html; charset=utf-8\r\n" \
                  "Content-Length: 3\r\n" \
                  "Vary: Cookie\r\n" \
                  "Content-Type: application/json\r\n" \
                  "\r\n" \
                  "{}"

# Generated at 2022-06-11 23:53:13.213730
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    a = ['Host: 127.0.0.1:8081', 'Connection: close', 'Content-Length: 20', 'Authorization: Basic YWRtaW46YWRtaW4=', 'Accept: */*', 'User-Agent: HTTPie/2.2.0']
    b = HeadersFormatter().format_headers('\r\n'.join(a))
    assert b == '\r\n'.join(sorted(a))

# Generated at 2022-06-11 23:53:20.891600
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options={'headers': {'sort': True}})
    heads = '''\
HTTP/1.1 200 OK
Server: nginx
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Content-Length: 6
X-Foo: bar
X-Bar: foo
    '''
    assert obj.format_headers(heads) == '''\
HTTP/1.1 200 OK
Content-Length: 6
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Server: nginx
X-Bar: foo
X-Foo: bar
        '''

# Generated at 2022-06-11 23:53:39.171831
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()

# Generated at 2022-06-11 23:53:49.622200
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """GET / HTTP/1.1\r
Host: httpbin.org\r
Accept-Encoding: gzip, deflate\r
Accept: */*\r
User-Agent: HTTPie/0.9.2\r
""" # we expect the order of Accept-Encoding, Host, and User-Agent to remain unchanged
    expected = """GET / HTTP/1.1\r
Host: httpbin.org\r
Accept-Encoding: gzip, deflate\r
Accept: */*\r
User-Agent: HTTPie/0.9.2\r
"""
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': True}}
    assert headers_formatter.format_headers(headers) == expected



# Generated at 2022-06-11 23:53:56.453630
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.enabled == True
    assert h.format_headers('Request Headers\r\nD: 1\r\nB: 2\r\nA: 3\r\nC: 4\r\n') == 'Request Headers\r\nA: 3\r\nB: 2\r\nC: 4\r\nD: 1\r\n'


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-11 23:54:05.606840
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    s = """\
HTTP/1.1 200 OK
Server: nginx/1.4.6 (Ubuntu)
Date: Sat, 12 Dec 2015 12:03:03 GMT
Content-Type: text/html
Content-Length: 19
Last-Modified: Tue, 15 Sep 2015 05:03:22 GMT
Connection: keep-alive
ETag: "55f7c25e-13"
    """

# Generated at 2022-06-11 23:54:14.273720
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
User-Agent: HTTPie/0.9.6
Accept-Encoding: gzip, deflate, compress
Host: httpbin.org
Accept: */*
Content-Type: application/json
Content-Length: 41
"""
    formatted_headers = formatter.format_headers(headers)

    assert formatted_headers == """\
User-Agent: HTTPie/0.9.6
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Length: 41
Content-Type: application/json
Host: httpbin.org
"""
    # Sorted by 'name'
    assert formatted_headers.splitlines() == sorted(headers.splitlines())
    # Multiple headers with the same name are still after each other
    assert formatted_headers.splitlines().index

# Generated at 2022-06-11 23:54:21.407199
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers = '''headers:
        Accept: text/html, application/json
        Accept-Language: en-US
        User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36
        Accept-Encoding: gzip, deflate
        Host: httpbin.org
        Connection: close
        Cookie: _gauges_unique_year=1; _gauges_unique=1; _gauges_unique_hour=1; _gauges_unique_month=1; _gauges_unique_day=1; _gauges_unique_week=1
    '''


# Generated at 2022-06-11 23:54:29.409160
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(parse_options={})
    headers = """
HTTP/1.1 200 OK
Content-Type: application/json
X-Foo: Bar
Link: </foo>; rel=next
Link: </bar>; rel=prev
X-Foo: Baz
X-Baz: Qux

"""
    assert formatter.format_headers(headers) == """
HTTP/1.1 200 OK
Content-Type: application/json
Link: </foo>; rel=next
Link: </bar>; rel=prev
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz

"""

# Generated at 2022-06-11 23:54:38.304313
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''
    :authority: www.reddit.com
    :method: GET
    :path: /top
    :scheme: https
    accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
    accept-encoding: gzip, deflate, br
    accept-language: en-GB,en-US;q=0.9,en;q=0.8
    '''

# Generated at 2022-06-11 23:54:46.007298
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 15
Server: TornadoServer/4.2.1
Date: Thu, 21 Mar 2019 18:25:09 GMT
Cache-Control: private, max-age=0
Content-Encoding: gzip
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: private, max-age=0
Content-Encoding: gzip
Content-Length: 15
Date: Thu, 21 Mar 2019 18:25:09 GMT
Server: TornadoServer/4.2.1
'''

# Generated at 2022-06-11 23:54:51.880283
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:55:23.233538
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = \
        """
        HTTP/1.1 200 OK
        Date: Wed, 09 Jul 2014 23:46:10 GMT
        Server: Apache/2.2.15 (CentOS)
        X-Powered-By: PHP/5.3.3
        Expires: Thu, 19 Nov 1981 08:52:00 GMT
        Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
        Pragma: no-cache
        Access-Control-Allow-Origin: *
        Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept
        Content-Type: application/json
        """
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:55:28.148264
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-type: application/json"""
    assert HeadersFormatter().format_headers(headers) == headers

    headers = """\
X-Header-1: value-1-a
Host: api.example.org
X-Header-2: value-2
X-Header-1: value-1-b"""
    assert HeadersFormatter().format_headers(headers) == """\
X-Header-1: value-1-a
X-Header-1: value-1-b
Host: api.example.org
X-Header-2: value-2"""

# Generated at 2022-06-11 23:55:37.260845
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    class StubFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['headers']['sort']

    headers = '\r\n'.join(['GET / HTTP/1.1', 'Host: localhost',
                          'Connection: keep-alive', 'accept: text/html',
                          'Accept-Encoding: gzip', 'Accept-Language: en-US',
                          'user-agent: Mozilla/5.0'])


# Generated at 2022-06-11 23:55:44.026613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
    HTTP/1.1 200 OK
    X-Foo: Bar
    Content-Type: application/json
    Content-Length: 1337
    X-Foo: Baz
    """
    expected = """
    HTTP/1.1 200 OK
    Content-Length: 1337
    Content-Type: application/json
    X-Foo: Bar
    X-Foo: Baz
    """
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-11 23:55:51.970272
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdr = '''GET / HTTP/1.1
Connection: keep-alive
Pragma: no-cache
Cache-Control: no-cache
User-Agent: HTTPie/1.0.0
Accept: */*
Host: httpbin.org
Accept-Encoding: gzip, deflate'''
    hdr_exp = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Connection: keep-alive
Host: httpbin.org
Pragma: no-cache
User-Agent: HTTPie/1.0.0
'''
    hfr = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hfr.format_headers(hdr) == hdr_exp

# Generated at 2022-06-11 23:55:58.383998
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('\n'.join([
        'GET / HTTP/1.1',
        'B: 2',
        'A: 1',
        'A: 3',
        'C: 4',
        ''
    ])) == '\n'.join([
        'GET / HTTP/1.1',
        'A: 1',
        'A: 3',
        'B: 2',
        'C: 4',
        ''
    ])


plugin_class = HeadersFormatter

# Generated at 2022-06-11 23:56:07.172224
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Assert that method format_headers of class HeadersFormatter
    sort headers by name while retaining relative order of
    multiple headers with the same name.

    """
    headers_formatter = HeadersFormatter(format_options={'headers': {}})
    _headers = 'HTTP/1.1 200 OK\r\n' \
               'Content-Type: application/json\r\n' \
               'Server: Mein-Server\r\n' \
               'Set-Cookie: name=wert, name2=wert2\r\n' \
               'X-Powered-By: PHP/7.0.12\r\n' \
               'Set-Cookie: name=wert3\r\n'
    headers = headers_formatter.format_headers(_headers)

# Generated at 2022-06-11 23:56:15.510167
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:56:23.346161
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()


# Generated at 2022-06-11 23:56:28.843632
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    orig = textwrap.dedent("""
        POST /post HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        Content-Length: 5
        Content-Type: application/json; charset=UTF-8
        Host: httpbin.org
        User-Agent: HTTPie/0.9.2
        X-Custom: Value

        """)

# Generated at 2022-06-11 23:57:24.793391
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('') == ''
    assert formatter.format_headers('\r\n') == '\r\n'
    assert formatter.format_headers('Content-Type: application/json') == 'Content-Type: application/json'
    assert formatter.format_headers('Transfer-Encoding: chunked\r\nContent-Type: application/json') == 'Transfer-Encoding: chunked\r\nContent-Type: application/json'

# Generated at 2022-06-11 23:57:29.697810
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:57:34.957325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers("""\
Content-Length: 5
Content-Type: text/plain

Hello\
""") == """\
Content-Length: 5
Content-Type: text/plain

Hello\
"""

    assert HeadersFormatter.format_headers("""\
Content-Type: text/plain
Content-Length: 5

Hello\
""") == """\
Content-Length: 5
Content-Type: text/plain

Hello\
"""

    assert HeadersFormatter.format_headers("""\
Content-Length: 5
Content-Type: text/plain
X-X: alpha
X-X: bravo

Hello\
""") == """\
Content-Length: 5
Content-Type: text/plain
X-X: alpha
X-X: bravo

Hello\
"""

# Generated at 2022-06-11 23:57:45.141384
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hformatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\ncustom: A\r\ncustom: B\r\ncontent-type: text/plain'
    exp_headers = 'HTTP/1.1 200 OK\r\ncustom: A\r\ncustom: B\r\ncontent-type: text/plain'
    assert hformatter.format_headers(headers) == exp_headers
    headers = 'HTTP/1.1 200 OK\r\ncontent-type: text/plain\r\ncustom: A\r\ncustom: B'
    exp_headers = 'HTTP/1.1 200 OK\r\ncontent-type: text/plain\r\ncustom: A\r\ncustom: B'
    assert hformatter.format_headers(headers) == exp_

# Generated at 2022-06-11 23:57:53.331495
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''content-type: application/json
client: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36
accept-encoding: gzip, deflate, br
accept-language: en-US,en;q=0.9,ru;q=0.8
content-length: 2
accept: application/json, text/javascript, */*; q=0.01
cache-control: no-cache
'''
    result_headers = formatter.format_headers(headers)
    print(result_headers)


# Generated at 2022-06-11 23:58:02.003234
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    output = '''HTTP/1.1 200 OK
Cache-Control: max-age=0, private, must-revalidate
Content-Type: application/json; charset=utf-8
X-Frame-Options: SAMEORIGIN
X-Request-Id: 3f49b1c7-2d47-4acc-9e5a-f5b5bc5192b0
X-Runtime: 0.028445
X-XSS-Protection: 1; mode=block
Content-Length: 262'''
    result = headers.format_headers(output)

# Generated at 2022-06-11 23:58:07.822422
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''GET / HTTP/1.1
User-Agent: curl/7.45.0
Accept: */*
Cache-Control: no-cache
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive

'''
    expected_headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Connection: keep-alive
Host: httpbin.org
User-Agent: curl/7.45.0

'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected_headers