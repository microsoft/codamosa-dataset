

# Generated at 2022-06-11 23:48:18.141548
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
        #
        # Arrange
        #
        headers = """HTTP/1.1 200 OK
Server: gunicorn/19.8.1
Date: Tue, 26 Feb 2019 21:39:06 GMT
Connection: keep-alive
Content-Length: 6
Content-Type: application/json
Access-Control-Allow-Origin: *

"""
        #
        # Act
        #
        formatter = HeadersFormatter()
        result = formatter.format_headers(headers)
        #
        # Assert
        #
        assert result == """HTTP/1.1 200 OK
Access-Control-Allow-Origin: *
Connection: keep-alive
Content-Length: 6
Content-Type: application/json
Date: Tue, 26 Feb 2019 21:39:06 GMT
Server: gunicorn/19.8.1

"""

# Generated at 2022-06-11 23:48:21.182654
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(format_options=dict([('headers', {'sort': False})])).format_headers('Authorization: Basic 123\r\nContent-Type: application/json\r\n')
    assert(h == 'Authorization: Basic 123\r\nContent-Type: application/json\r\n')

# Generated at 2022-06-11 23:48:31.065365
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    test_input = '''\
HTTP/1.1 200 OK\r
Transfer-Encoding: chunked\r
Date: Wed, 03 Apr 2019 11:52:42 GMT\r
Server: Apache\r
Last-Modified: Sun, 22 Sep 2019 15:51:19 GMT\r
ETag: "8a-59b680dcdc687"\r
Content-Encoding: gzip\r
Vary: Accept-Encoding\r
Content-Type: text/html\r
\r
'''

# Generated at 2022-06-11 23:48:40.453850
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {
        'headers': {'sort': True}
    }
    headers = 'Host: localhost:5000\n' \
              'User-Agent: HTTPie/0.9.9\n' \
              'Accept: */*\n' \
              'Accept-Encoding: gzip, deflate\n' \
              'Connection: keep-alive\n' \
              'Content-Length: 2\n' \
              'Content-Type: application/json\n\r\n'

# Generated at 2022-06-11 23:48:48.334121
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter({})
    resp = '''HTTP/1.1 200 OK\r
Server: nginx\r
Content-Type: application/json\r
Content-Length: 2\r
Set-Cookie: resultsPerPage=100; path=/\r
Set-Cookie: isLoggedIn=1; path=/\r
Set-Cookie: lang=en-us; path=/\r
Set-Cookie: lastUser=; path=/\r
Connection: keep-alive\r
ETag: "5d8bd6ed-2"\r
Date: Fri, 16 Aug 2019 12:59:54 GMT\r
\r
{}
'''
    assert formatter.format_headers(headers = resp) == formatter.format_headers(resp)
    assert formatter.format_headers(resp)

# Generated at 2022-06-11 23:48:53.996732
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    output = hf.format_headers( """X-Foo: abc
Foo: def
X-Foo: xyz
Content-Length: 1000
Accept-Encoding: gzip
""" )
    assert output ==  """X-Foo: abc
Foo: def
X-Foo: xyz
Content-Length: 1000
Accept-Encoding: gzip
"""


# Generated at 2022-06-11 23:49:01.863004
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
        GET / HTTP/1.1
        Content-Type: application/json
        Content-Length: 100
        Foo: Bar
        Foo: Baz
        Foo: Qux
        Foo: Biz
        Foo: Boo
        Connection: Keep-Alive
        '''
    assert HeadersFormatter.format_headers(headers) == '''\
        GET / HTTP/1.1
        Connection: Keep-Alive
        Content-Length: 100
        Content-Type: application/json
        Foo: Bar
        Foo: Baz
        Foo: Qux
        Foo: Biz
        Foo: Boo'''

# Generated at 2022-06-11 23:49:06.823922
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('Content-Type: text/plain\r\nContent-Length: 20\r\nX-Foo: Bar') == ('Content-Length: 20\r\n' + 'Content-Type: text/plain\r\n' + 'X-Foo: Bar')



# Generated at 2022-06-11 23:49:14.797897
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Content-Type: multipart/form-data; boundary=---------------L5cH2ae0ae0KM7Ij5gL6cH2gL6ae0GI3
Date: Fri, 27 Jul 2018 15:17:43 GMT
Server: BaseHTTP/0.6 Python/3.6.5+ (Ubuntu)
Content-Length: 1131

"""

# Generated at 2022-06-11 23:49:21.736563
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = """\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/0.9.2


"""
    expected = """\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.2


"""
    output = formatter.format_headers(input)
    assert output == expected

# Generated at 2022-06-11 23:49:31.213656
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    answer = "HTTP/1.1 200 OK\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Length: 0\r\nHost: echo-headers.appspot.com\r\nUser-Agent: HTTPie/0.9.8\r\nX-Appengine-Country: US\r\nx-appengine-user-ip: 0.1.0.2\r\nX-Appengine-City: Mountain View\r\nx-appengine-user-is-admin: 0\r\nX-Appengine-Region: CA\r\n"

# Generated at 2022-06-11 23:49:39.417574
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('\r\nFoo: 1\r\nBar: 2\r\nBaz: 3') == '\r\nBar: 2\r\nBaz: 3\r\nFoo: 1'
    assert headers_formatter.format_headers('\r\nFoo: 1\r\nFoo: 2\r\nFoo: 3') == '\r\nFoo: 1\r\nFoo: 2\r\nFoo: 3'

# Generated at 2022-06-11 23:49:49.884997
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Inputs
    headers_input = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Server: gunicorn/19.9.0',
        'Content-Type: application/json; charset=utf-8',
        'Link: <https://httpbin.org/drip?duration=1&numbytes=1&code=200>;rel="next"',
        'Connection: keep-alive',
        'X-Powered-By: Flask',
        'Access-Control-Allow-Origin: *',
        'Access-Control-Allow-Credentials: true',
        'Date: Wed, 11 Jul 2018 07:43:06 GMT',
        'Content-Length: 1366',
    ])

    # Expected output

# Generated at 2022-06-11 23:49:55.266376
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = f._format_headers("""
Host: httpbin.org
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: python-requests/2.6.0 CPython/3.4.3 Windows/7
""".strip())
    assert headers == """
Host: httpbin.org
User-Agent: python-requests/2.6.0 CPython/3.4.3 Windows/7
Accept: */*
Accept-Encoding: gzip, deflate, compress
""".strip()



# Generated at 2022-06-11 23:50:05.330039
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()

    headers = formatter.format_headers("""
        Server: nginx
        Content-Type: application/json
        Content-Length: 297
        Connection: keep-alive
        Vary: Accept
        Date: Tue, 07 Nov 2017 14:41:50 GMT
        X-Cache-Hits: 0
        X-Cache-Misses: 1
        X-Cache: MISS
        Via: 1.1 varnish-v4
        Age: 0
        X-Served-By: cache-bma1646-BMA
        X-Cache-Key: /v2/listings/active/
        X-Timer: S1510040310.937648,VS0,VE0
    """)


# Generated at 2022-06-11 23:50:13.006633
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options = {'headers' : {'sort' : True}})

    # default request line
    reqline = 'GET /test HTTP/1.1\r\n'
    # headers list
    headers = {'Content-Length': '0', 'Host': 'httpbin.org', 'Accept': '*/*'}
    # sorting headers
    headers = formatter.format_headers(format_headers(headers))

    # Expected result
    exp_headers = 'Accept: */*\r\nHost: httpbin.org\r\nContent-Length: 0'

    assert headers == exp_headers

# Generated at 2022-06-11 23:50:23.386433
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:32.042172
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

    headers = """\
HTTP/1.1 200 OK
Connection: Keep-Alive
Content-Encoding: gzip
Accept-Ranges: bytes
Content-Length: 5
Content-Type: text/html; charset=UTF-8
Date: Sun, 29 Nov 2020 09:54:59 GMT
Keep-Alive: timeout=15, max=94
Server: Apache
Strict-Transport-Security: max-age=15552000; includeSubDomains
Vary: Accept-Encoding
X-Frame-Options: SAMEORIGIN
"""

# Generated at 2022-06-11 23:50:43.093828
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    # Before fix.
    assert f.format_headers('Content-Length: 123\nContent-Type: application/json\nAccept: application/json') == 'Content-Length: 123\nContent-Type: application/json\nAccept: application/json'
    assert f.format_headers('Content-Type: application/json\nContent-Length: 123\nAccept: application/json') == 'Content-Type: application/json\nContent-Length: 123\nAccept: application/json'
    assert f.format_headers('Content-Type: application/json\nAccept: application/json\nContent-Length: 123') == 'Content-Type: application/json\nAccept: application/json\nContent-Length: 123'
    # After fix.

# Generated at 2022-06-11 23:50:52.166434
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:51:04.926137
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''Content-Length: 263
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Accept: application/json, */*
Api-Key: secret
Host: httpbin.org
Cache-Control: no-cache
Content-Type: application/json
User-Agent: HTTPie/0.9.9
'''
    headers_formatted = '''Content-Length: 263
Accept-Encoding: gzip, deflate, br
Accept: application/json, */*
Api-Key: secret
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''

# Generated at 2022-06-11 23:51:15.895929
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Sorts headers by name while retaining relative order of multiple headers
    with the same name.
    """
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Vary: Accept
Vary: Cookie
Allow: GET, POST
X-Frame-Options: SAMEORIGIN
Content-Length: 52

{
    "name": "John Doe"
}"""
    headers = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    }).format_headers(headers)

# Generated at 2022-06-11 23:51:25.870905
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:51:35.498376
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-11 23:51:37.266991
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-11 23:51:42.535137
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class x:
        pass
    x.format_options = {}
    x.format_options['headers'] = {}
    x.format_options['headers']['sort'] = False
    hf = HeadersFormatter(parent=x, format_options=x.format_options)
    assert not hf.enabled
    #
    hf.enabled = True
    assert hf.enabled


# Generated at 2022-06-11 23:51:45.889238
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Content-Length: 12
Cache-Control: private
Content-Type: application/json
Date: Mon, 27 Feb 2017 22:37:25 GMT

'''
    assert formatter.format_headers(headers) == headers



# Generated at 2022-06-11 23:51:54.183972
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert obj.format_headers(headers = "") == ""
    assert obj.format_headers(headers = "HTTP/1.1 200 OK\r\nDate: Fri, 28 Aug 2020 13:27:17 GMT\r\n") == "HTTP/1.1 200 OK\r\nDate: Fri, 28 Aug 2020 13:27:17 GMT\r\n"

# Generated at 2022-06-11 23:51:55.181578
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled

# Generated at 2022-06-11 23:52:02.698191
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # input
    input = """Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: */*
Accept-Language: en
User-Agent: HTTPie/0.9.6
Host: example.com
"""
    # expected
    expected = """Connection: keep-alive
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en
User-Agent: HTTPie/0.9.6
Host: example.com
"""

    # action
    actual = HeadersFormatter().format_headers(input)

    # assert
    assert actual == expected

# Generated at 2022-06-11 23:52:15.709074
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Encoding: gzip
Content-Language: en-US
Content-Language: fr-FR
Content-Type: application/json
Date: Wed, 18 Mar 2015 11:22:59 GMT
""") == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Encoding: gzip
Content-Language: en-US
Content-Language: fr-FR
Content-Type: application/json
Date: Wed, 18 Mar 2015 11:22:59 GMT
"""


# Generated at 2022-06-11 23:52:23.913569
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    assert formatter.format_headers("""POST /post HTTP/1.1
Host: httpbin.org
User-Agent: HTTPie/0.9.5
Accept-Encoding: gzip, deflate, compress
Accept: application/json
Connection: close
Content-Length: 28


""") == """POST /post HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate, compress
Connection: close
Content-Length: 28
Host: httpbin.org
User-Agent: HTTPie/0.9.5


"""

# Generated at 2022-06-11 23:52:34.737381
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Date: Tue, 25 Aug 2020 03:48:11 GMT
Server: Apache/2.4.25 (Debian)
Last-Modified: Tue, 25 Aug 2020 02:39:37 GMT
ETag: "5f44953d-32fb"
Accept-Ranges: bytes
Content-Length: 13123
Content-Type: text/html
"""
    expected = """\
HTTP/1.1 200 OK
Accept-Ranges: bytes
Content-Length: 13123
Content-Type: text/html
Date: Tue, 25 Aug 2020 03:48:11 GMT
ETag: "5f44953d-32fb"
Last-Modified: Tue, 25 Aug 2020 02:39:37 GMT
Server: Apache/2.4.25 (Debian)
"""
    assert HeadersForm

# Generated at 2022-06-11 23:52:41.938121
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # given
    headers = '''
HTTP/1.1 200 OK
Server: nginx
Content-Type: application/json; charset=utf-8
Cache-Control: max-age=0, private, must-revalidate
Content-Encoding: gzip
Vary: Origin
X-Request-Id: 8f6ef9d6-bce0-44c6-b136-35718c5e5238
X-Runtime: 0.051595
Transfer-Encoding: chunked
Connection: close

'''

# Generated at 2022-06-11 23:52:51.912849
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fh = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nServer: nginx\r\nDate: Tue, 18 Jun 2019 09:22:35 GMT\r\nContent-Type: text/html\r\nTransfer-Encoding: chunked\r\nConnection: close\r\nVary: Accept-Encoding\r\nAllow: POST, OPTIONS\r\nX-Frame-Options: SAMEORIGIN\r\nContent-Encoding: gzip\r\nX-XSS-Protection: 1; mode=block\r\nX-Content-Type-Options: nosniff"
    fh.format_headers(headers)

# Generated at 2022-06-11 23:53:01.714639
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # NOTE: The code below is written to check whether
    # the sorting of headers is done correctly for
    # multiple headers with the same name

    # Input headers
    headers = '''
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Accept-Language: en-us
Connection: keep-alive
Content-Length: 5
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: httpbin.org
User-Agent: HTTPie/0.9.9

'''.strip()

    # Expected output headers

# Generated at 2022-06-11 23:53:10.468269
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:53:13.468744
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = Formatter(headers_sort=True)
    assert formatter.format_headers('A: 1\r\nB: 2\r\nA: 3') == 'A: 1\r\nA: 3\r\nB: 2'


# Generated at 2022-06-11 23:53:24.037891
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hd = HeadersFormatter()
    expect = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Accept: image/*;q=0.8,video/*;q=0.8,*/*;q=0.5',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Server: nginx',
        'X-Powered-By: PHP/5.4.4-14+deb7u11'
    ])

# Generated at 2022-06-11 23:53:29.141098
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create an instance of HeadersFormatter
    obj = HeadersFormatter(format_options={'headers': {'sort': True}})
    # Test if header sort is enabled
    obj.enabled
    # Test if header sort is enabled
    obj.enabled
    # Test if header sort is enabled
    assert obj.enabled == obj.format_options['headers']['sort']
    # Test if header sort is enabled
    assert obj.enabled == obj.format_options['headers']['sort']



# Generated at 2022-06-11 23:53:51.310188
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
POST /HTTP/1.1\r
Host: localhost\r
Accept-Encoding: gzip, deflate\r
Accept: */*\r
Connection: keep-alive\r
Content-Length: 5\r
User-Agent: HTTPie/0.9.4\r
Content-Type: application/json; charset=utf-8\r
""".strip()

# Generated at 2022-06-11 23:53:57.810676
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from textwrap import dedent
    inp = dedent("""\
        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate, compress
        Host: httpbin.org

        """)
    exp = dedent("""\
        GET / HTTP/1.1
        Accept-Encoding: gzip, deflate, compress
        Accept: */*
        Host: httpbin.org

        """)
    assert exp == HeadersFormatter().format_headers(inp)




# Generated at 2022-06-11 23:54:04.860855
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        "headers":{"sort": True}})
    string = "HTTP/1.1 200 OK\r\nDate: Tue, 23 Oct 2018 08:22:06 GMT\r\nContent-Type: text/html; charset=UTF-8\r\n"
    expected_string = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nDate: Tue, 23 Oct 2018 08:22:06 GMT\r\n"
    assert formatter.format_headers(string) == expected_string

# Generated at 2022-06-11 23:54:06.243405
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()


# Generated at 2022-06-11 23:54:11.728138
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = 'Host: example.com\nUser-Agent: httpie/2.0.0\nAccept: */*\nAccept-Encoding: gzip, deflate\nConnection: keep-alive'
    expected = 'Host: example.com\nAccept: */*\nAccept-Encoding: gzip, deflate\nConnection: keep-alive\nUser-Agent: httpie/2.0.0'
    assert expected == HeadersFormatter().format_headers(h)

# Generated at 2022-06-11 23:54:19.193601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    # Test: sort by name.
    sorted_h = ('HTTP/1.1 200 OK\r\n'
                'Content-Type: text/plain; charset=utf-8\r\n'
                'Date: Fri, 21 Oct 2016 18:55:28 GMT\r\n'
                'Etag: "abcdefg"\r\n'
                'Server: TornadoServer/4.4.2\r\n'
                'Transfer-Encoding: chunked\r\n'
                'X-Powered-By: Flask\r\n'
                'X-Ua-Compatible: IE=Edge,chrome=1\r\n\r\n')
    result = f.format_headers(sorted_h)
    assert result == sorted_h
    # Test:

# Generated at 2022-06-11 23:54:22.136296
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class test_HeadersFormatter():
        def __init__(self):
            self.format_options = {
                'headers': {
                    'sort': True
                }
            }
        h = HeadersFormatter(**self.format_options)
        assert h.enabled == True
    test_HeadersFormatter()


# Generated at 2022-06-11 23:54:31.045938
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # "Content-Length" header is sorted before "Authorization"
    assert formatter.format_headers('''\
HTTP/1.1 200 OK
Content-Length: 24
Authorization: Basic c2VuZGVyOnNlbmRlcjEyMw==
Content-Type: application/json
''') == '''\
HTTP/1.1 200 OK
Authorization: Basic c2VuZGVyOnNlbmRlcjEyMw==
Content-Length: 24
Content-Type: application/json
'''

    # All "Foo" headers (one or several) are sorted together

# Generated at 2022-06-11 23:54:38.803780
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # arg
    headers = '''\
HTTP/1.0 200 OK
Connection: keep-alive
Content-Type: application/json
Server: gunicorn/19.4.5
Date: Fri, 14 Jul 2017 20:32:43 GMT
Transfer-Encoding: chunked
Connection: close

'''
    # expected
    expected = '''\
HTTP/1.0 200 OK
Connection: keep-alive
Connection: close
Content-Type: application/json
Date: Fri, 14 Jul 2017 20:32:43 GMT
Server: gunicorn/19.4.5
Transfer-Encoding: chunked

'''
    # execution
    hf = HeadersFormatter(options={'headers': {'sort': True}})
    actual = hf.format_headers(headers)
    # test

# Generated at 2022-06-11 23:54:48.133819
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:55:08.605675
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(colors=False, indent=3)
    assert formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'D-Header-1: 1',
        'A-Header-2: 2',
        'A-Header-1: 1',
        'B-Header-Foo-Bar: Baz'
    ])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'A-Header-1: 1',
        'A-Header-2: 2',
        'B-Header-Foo-Bar: Baz',
        'D-Header-1: 1',
    ])



# Generated at 2022-06-11 23:55:17.671440
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Method format_headers of class HeadersFormatter
    # Retain relative order of multiple headers with the same name

    unformatted_header_block1 = '\r\n'.join(lines1)
    formatted_header_block1 = '\r\n'.join(lines1)
    unformatted_header_block2 = '\r\n'.join(lines2)
    formatted_header_block2 = '\r\n'.join(lines2)
    unformatted_header_block3 = '\r\n'.join(lines3)
    formatted_header_block3 = '\r\n'.join(lines3)
    unformatted_header_block4 = '\r\n'.join(lines4)
    formatted_header_block4 = '\r\n'.join(lines4)

    headers_form

# Generated at 2022-06-11 23:55:18.841266
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled == False


# Generated at 2022-06-11 23:55:26.731610
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    str_to_test = '''\
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/2.2.0


hello=world
'''
    expected_str = '''\
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Host: httpbin.org
Content-Length: 18
Content-Type: application/x-www-form-urlencoded
Connection: keep-alive
User-Agent: HTTPie/2.2.0


hello=world
'''
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:55:29.092845
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print("Testing HeadersFormatter constructor")
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-11 23:55:34.035476
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Pass
    formatter = HeadersFormatter()
    assert(formatter.format_options['headers']['sort'] == False)

    # Pass
    sort_enabled = True
    formatter = HeadersFormatter(sort=sort_enabled)
    assert(formatter.format_options['headers']['sort'] == sort_enabled)


# Generated at 2022-06-11 23:55:38.124091
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    # Verify that we have the right constructor
    assert hasattr(fmt, '__init__') and \
           callable(getattr(fmt, '__init__'))
    # Verify that the attributes of the object is correct
    assert fmt.format_options == {'headers': {'sort': True}}
    assert fmt.enabled == fmt.format_options['headers']['sort']


# Generated at 2022-06-11 23:55:47.902298
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "GET / HTTP/1.1\r\nAccept: text/html\r\nAccept: text/plain\r\n" \
              "Accept: json\r\nCache-Control: no-cache\r\n" \
              "Cache-Control: no-store\r\nUser-Agent: HTTPie/1\r\n\r\n"
    assert HeadersFormatter().format_headers(headers) == \
       'GET / HTTP/1.1\r\nAccept: text/html\r\nAccept: text/plain\r\n' \
       'Accept: json\r\nCache-Control: no-cache\r\n' \
       'Cache-Control: no-store\r\nUser-Agent: HTTPie/1\r\n'



# Generated at 2022-06-11 23:55:49.219743
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert 'headers' in FormatterPlugin.format_options

# Generated at 2022-06-11 23:55:53.201154
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers('''\
GET / HTTP/1.1
User-Agent: curl/7.64.1
Host: httpbin.org
Accept: */*
Content-Length: 0
Connection: close
''') == '''\
GET / HTTP/1.1
Accept: */*
Connection: close
Content-Length: 0
Host: httpbin.org
User-Agent: curl/7.64.1
'''

# Generated at 2022-06-11 23:56:22.135690
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    headers_formatter = HeadersFormatter()

    # Act

# Generated at 2022-06-11 23:56:30.405737
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    data = formatter.format_headers("""\
HTTP/1.1 200 OK
Cache-Control: private, max-age=0, must-revalidate
Content-Length: 25
Content-Type: text/html; charset=UTF-8
Expires: Wed, 06 Apr 2016 06:37:25 GMT
Server: GSE

""")

    assert data == """\
HTTP/1.1 200 OK
Cache-Control: private, max-age=0, must-revalidate
Content-Length: 25
Content-Type: text/html; charset=UTF-8
Expires: Wed, 06 Apr 2016 06:37:25 GMT
Server: GSE

""", "Not equal"

# Generated at 2022-06-11 23:56:38.857311
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.core import main as httpie
    import json

    request = {'headers': {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Custom-Header': 'foobar'
    }}

    expected_headers = (
        'GET / HTTP/1.1\r\n'
        'Accept: application/json\r\n'
        'Content-Type: application/json\r\n'
        'X-Custom-Header: foobar\r\n'
        '\r\n'
    )

    stdout = httpie(json.dumps(request) + ' http://httpbin.org/get')
    assert stdout == expected_headers

# Generated at 2022-06-11 23:56:46.163260
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # set up
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8,ru;q=0.6

'''

# Generated at 2022-06-11 23:56:55.785621
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    i = "HTTP/1.1 200 OK\r\n"
    i += "Date: Wed, 29 May 2019 08:15:47 GMT\r\n"
    i += "Content-Type: application/json\r\n"
    i += "Transfer-Encoding: chunked\r\n"
    i += "Server: GitHub.com\r\n"
    i += "Status: 200 OK\r\n"
    i += "X-RateLimit-Limit: 5000\r\n"
    i += "X-RateLimit-Remaining: 4968\r\n"
    i += "X-RateLimit-Reset: 1559120000\r\n"
    i += "Access-Control-Allow-Origin: *\r\n"

# Generated at 2022-06-11 23:57:01.557221
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test for empty headers
    test_headers = HeadersFormatter.format_headers('')
    assert test_headers == ''

    # Test for headers with only one line
    test_headers = HeadersFormatter.format_headers('header1: value1')
    assert test_headers == 'header1: value1'

    # Test for one header with two lines
    test_headers = HeadersFormatter.format_headers('header1: value1\r\nheader2: value2')
    assert test_headers == 'header1: value1\r\nheader2: value2'

    # Test for multiple headers with the same name
    test_headers = HeadersFormatter.format_headers('header1: value1\r\nheader2: value2\r\nheader1: value3')

# Generated at 2022-06-11 23:57:10.550114
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = 'Date: Tue, 19 Jul 2016 14:19:44 GMT\r\n' \
        'Content-Length: 10\r\n' \
        'Content-Type: text/plain\r\n' \
        'Server: BaseHTTP/0.6 Python/3.4.4' \
        '\r\n\r\n'
    assert headers_formatter.format_headers(
        headers) == 'Date: Tue, 19 Jul 2016 14:19:44 GMT\r\n' \
                   'Content-Length: 10\r\n' \
                   'Content-Type: text/plain\r\n' \
                   'Server: BaseHTTP/0.6 Python/3.4.4\r\n\r\n'
# End of unit test for method

# Generated at 2022-06-11 23:57:15.433470
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
User-Agent: HTTPie/0.9.4
Date: Tue, 19 Jul 2016 03:34:52 GMT
Transfer-Encoding: chunked\
'''
    formatted_headers = headers_formatter.format_headers(headers)
    expected_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
Date: Tue, 19 Jul 2016 03:34:52 GMT
Transfer-Encoding: chunked
User-Agent: HTTPie/0.9.4\
'''
    assert formatted_headers == expected_headers

# Generated at 2022-06-11 23:57:24.965507
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_with_duplicate_names = '''\
accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
accept-encoding: gzip, deflate
accept-language: en-us,en;q=0.5
accept-language: em-en,en;q=0.5
'''

# Generated at 2022-06-11 23:57:32.264589
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HeadersFormatter

    headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Pragma: no-cache
Content-Length: 15
Content-Type: application/json; charset=utf-8
Expires: -1
Server: Microsoft-IIS/8.5
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Thu, 20 Sep 2018 22:42:42 GMT

'''
    # httpie_print.py line 515

# Generated at 2022-06-11 23:58:02.864749
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case 1
    h = HeadersFormatter({'headers':{'sort': True}})
    string_1 = '''HTTP/1.1 200 OK
Date: Mon, 04 Mar 2019 12:54:21 GMT
Server: Apache
Last-Modified: Mon, 04 Mar 2019 12:50:00 GMT
ETag: "630-58b47cab14644"
Accept-Ranges: bytes
Content-Length: 1584
Vary: Accept-Encoding
Content-Type: text/html

'''

# Generated at 2022-06-11 23:58:07.356377
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    assert obj.format_headers('Content-Type: application/json \r\n\
                               User-Agent: httpie \r\n\
                               Accept: application/json \r\n\
                               Content-Type: text/plain') == 'Content-Type: application/json \r\n\
                                                              Content-Type: text/plain \r\n\
                                                              User-Agent: httpie \r\n\
                                                              Accept: application/json'