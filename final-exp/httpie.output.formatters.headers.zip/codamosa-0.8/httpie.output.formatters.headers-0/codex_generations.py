

# Generated at 2022-06-11 23:48:17.858931
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_sort_off = 'HTTP/1.1 200 OK\r\nX-Foo: bar\r\nX-Bar: foo\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 12'
    headers_sort_on = 'HTTP/1.1 200 OK\r\nContent-Length: 12\r\nContent-Type: text/plain; charset=utf-8\r\nX-Bar: foo\r\nX-Foo: bar'
    assert headers_formatter.format_headers(headers_sort_off) == headers_sort_on
    assert headers_formatter.format_headers(headers_sort_on) == headers_sort_on

# Generated at 2022-06-11 23:48:24.090695
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from collections import OrderedDict
    from datetime import datetime, timezone
    from httpie import ExitStatus
    from httpie.core import main
    from tempfile import gettempdir
    import os
    import platform
    import pytest

    httpie_temp_folder = os.path.join(gettempdir(), 'httpie')
    if not os.path.exists(httpie_temp_folder):
        os.mkdir(httpie_temp_folder)

    @pytest.fixture(params=[u'utf-8', u'utf-8-sig', u'utf-16'])
    def encoding(request):
        return request.param


# Generated at 2022-06-11 23:48:30.668472
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 \r\n foo: bar\r\n baz: qux\r\n baz: quux\r\n'
    expected_output = 'HTTP/1.1 200 \r\n baz: qux\r\n baz: quux\r\n foo: bar\r\n'
    # test format_headers
    assert formatter.format_headers(headers) == expected_output


# Generated at 2022-06-11 23:48:38.187289
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'X-A: 1',
        'X-B: 4',
        'X-B: 3',
        'X-A: 2'
    ])
    formatted_headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'X-A: 1',
        'X-A: 2',
        'X-B: 4',
        'X-B: 3'
    ])
    assert formatter.format_headers(headers) == formatted_headers


# Generated at 2022-06-11 23:48:39.937278
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    >>> # Use a custom format plugin
    >>> f = HeadersFormatter()
    >>> assert 'key: y\r\nkey: x\r\n' == f.format_headers('key: x\r\nkey: y\r\n')
    """

# Generated at 2022-06-11 23:48:45.956585
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_headers = ('\r\n'
                     'Some-Header: value\r\n'
                     'Some-Other-Header: value\r\n'
                     'Another-Header: value')
    res = HeadersFormatter().format_headers(input_headers)
    expected_headers = ('\r\n'
                        'Another-Header: value\r\n'
                        'Some-Header: value\r\n'
                        'Some-Other-Header: value')

    assert res == expected_headers

# Generated at 2022-06-11 23:48:55.152721
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(
        'Connection: keep-alive\r\n'
        'Content-Length: 400\r\n'
        'Content-Type: application/json\r\n'
        'Date: Sun, 08 Sep 2019 20:58:07 GMT\r\n'
        'Server: Flask\r\n'
    ) == (
        'Connection: keep-alive\r\n'
        'Content-Length: 400\r\n'
        'Content-Type: application/json\r\n'
        'Date: Sun, 08 Sep 2019 20:58:07 GMT\r\n'
        'Server: Flask\r\n'
    )

# Generated at 2022-06-11 23:48:56.775309
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head_formatter = HeadersFormatter()
    assert head_formatter.enabled == False



# Generated at 2022-06-11 23:49:07.770393
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 230
Content-Type: application/json
Date: Fri, 01 Sep 2017 11:07:14 GMT
ETag: W/"e6-D7XnJyN/TLnKTFgiNhkVJgHZ4A"
Server: nginx/1.10.3 (Ubuntu)
Vary: Accept-Encoding
'''

# Generated at 2022-06-11 23:49:18.559923
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(headers).splitlines()[1:3] == [
        'Accept-Encoding: br, gzip',
        'Accept: */*',
    ]

# Generated at 2022-06-11 23:49:29.404911
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # the input headers have a fixed order
    headers = (
        'Content-Length: 321\r\n'
        'Content-Encoding: deflate\r\n'
        'Cookie: JSESSIONID=BDF5E5C6297F7FBD630E6F5574124ECB; '
        '_xsrf=2|715a2c4a|f4b4a6a30e01bca1318c9a45a1c62d41|1589336478\r\n'
    )

    # the output headers should equal

# Generated at 2022-06-11 23:49:30.755804
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test 1
    headers_formatter = HeadersFormatter()
    assert headers_formatter is not None

# Generated at 2022-06-11 23:49:41.134147
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    format_options = {'headers': {'sort': True}}

    headers = """HTTP/1.1 200 OK
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sat, 04 Jan 2020 06:27:57 GMT
Content-Type: application/json; charset=utf-8
Transfer-Encoding: chunked
Allow: GET, OPTIONS
Vary: Accept, Cookie
X-Frame-Options: SAMEORIGIN
"""
    formatter = HeadersFormatter(format_options=format_options)

    # Expected results

# Generated at 2022-06-11 23:49:50.654481
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    headers = '''\
Host: example.org
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Date: Wed, 25 Nov 2015 20:28:26 GMT
Random-Header-1: Value 1
Random-Header-2: Value 2'''

    headers = formatter.format_headers(headers)
    assert headers == '''\
Host: example.org
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Date: Wed, 25 Nov 2015 20:28:26 GMT
Random-Header-1: Value 1
Random-Header-2: Value 2'''

# Generated at 2022-06-11 23:49:51.204725
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = H

# Generated at 2022-06-11 23:49:57.250788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-11 23:50:06.726546
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter is not None

    # Test 1:
    # To sort headers by name while retaining relative order of multiple headers
    # with the same name
    headers_text = '''POST / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 21
Content-Type: application/json
Host: kafka-topic-ui-jmvidalm.c9users.io:8080
User-Agent: HTTPie/1.0.0-dev


'''

# Generated at 2022-06-11 23:50:10.822132
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    The __init__() method should return a HeadersFormatter object with enabled property set to false

    """
    formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert isinstance(formatter, HeadersFormatter)
    assert formatter.enabled == False


# Generated at 2022-06-11 23:50:16.248063
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    logger.debug("In HeadersFormatter.test_HeadersFormatter()")
    formatter = HeadersFormatter()
    try:
        assert True == formatter.enabled
    except AssertionError as e:
        logger.error("In HeadersFormatter.test_HeadersFormatter(): {0}".format(e))
        raise
    except Exception as e:
        logger.error("In HeadersFormatter.test_HeadersFormatter(): {0}".format(e))


# Generated at 2022-06-11 23:50:26.398146
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Cache-Control: public, max-age=60, s-maxage=60
Content-Type: application/json; charset=utf-8
Vary: Accept-Encoding
X-RateLimit-Limit: 30
X-RateLimit-Remaining: 27
Content-Length: 276
X-GitHub-Media-Type: github.v3; format=json
ETag: "bb1d039d82a6a9b6eef26cef1d5c5b5b"
X-RateLimit-Reset: 1431814196
X-GitHub-Request-Id: D4C1E4A8:15CE:1987E78:55512F57"""

# Generated at 2022-06-11 23:50:30.386339
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options=dict(headers=dict(sort=False)))
    assert hf.enabled == False

    hf = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    assert hf.enabled == True



# Generated at 2022-06-11 23:50:36.322224
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
accept: */*
User-agent: httpie/1.0.2
"""
    expected = """\
GET / HTTP/1.1
accept: */*
User-agent: httpie/1.0.2
"""
    actual = HeadersFormatter().format_headers(headers)
    assert actual == expected

# Generated at 2022-06-11 23:50:37.816847
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    HeadersFormatter()



# Generated at 2022-06-11 23:50:47.297298
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    msg = '''
        POST /post HTTP/1.1 
        Host: www.python.org
        Content-Type: text/html; charset=utf-8
        Content-Length: 755 
        X-Header: foo
        X-Header: bar
        Accept: application/json
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        User-Agent: HTTPie/1.0.2
    '''
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-11 23:50:52.947976
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_str = "POST / HTTP/1.1\r\nUser-Agent: a\r\nAccept: b\r\nUser-Agent: c\r\nAccept: d\r\n\r\n"
    assert HeadersFormatter(sort=True).format_headers(header_str) == "POST / HTTP/1.1\r\nAccept: b\r\nAccept: d\r\nUser-Agent: a\r\nUser-Agent: c\r\n\r\n"

# Generated at 2022-06-11 23:51:00.662827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Host: http://httpbin.org\r\n' \
              'Connect-Time: 1.001\r\n' \
              'Connection: close\r\n' \
              'Content-Length: 150\r\n' \
              '\r\n'
    headers_sorted = 'HTTP/1.1 200 OK\r\n' \
                     'Connection: close\r\n' \
                     'Connect-Time: 1.001\r\n' \
                     'Content-Length: 150\r\n' \
                     'Host: http://httpbin.org\r\n' \
                     '\r\n'

# Generated at 2022-06-11 23:51:08.718101
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test case 1
    headers = "HTTP/1.1 200 OK\nDate: Thu, 01 Mar 2018 03:00:00 GMT\n" \
              "Expires: -1\nCache-Control: private, max-age=0\n" \
              "Content-Type: text/html; charset=UTF-8\n" \
              "Content-Encoding: gzip\nServer: gws\n" \
              "X-XSS-Protection: 1; mode=block\n" \
              "X-Frame-Options: SAMEORIGIN\n\r\n"
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers) \
        == "HTTP/1.1 200 OK\nCache-Control: private, max-age=0\n"

# Generated at 2022-06-11 23:51:18.469085
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Header lines are sorted but relative order of multiple
    # headers with the same name is retained.
    result = HeadersFormatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Accept: */*\r\n'
        'Content-Length: 100\r\n'
        'Accept: application/json\r\n'
        'Content-Type: application/json'
    )
    assert result == (
        'HTTP/1.1 200 OK\r\n'
        'Accept: */*\r\n'
        'Accept: application/json\r\n'
        'Content-Length: 100\r\n'
        'Content-Type: application/json'
    )



# Generated at 2022-06-11 23:51:23.978067
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''
HTTP/1.0 200 OK
B: two
B: one
A: one
A: two
C: three
'''
    assert formatter.format_headers(headers) == '''
HTTP/1.0 200 OK
A: one
A: two
B: one
B: two
C: three
'''



# Generated at 2022-06-11 23:51:31.517213
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Connection: Closed
Content-Type: text/html
X-Pad: avoid browser bug
'''.splitlines()

# Generated at 2022-06-11 23:51:35.541060
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']

# Generated at 2022-06-11 23:51:40.561088
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    assert obj.format_headers('GET / HTTP/1.1\r\nContent-Type: application/json\r\nContent-Length: 123\r\n') == 'GET / HTTP/1.1\r\nContent-Length: 123\r\nContent-Type: application/json\r\n'



# Generated at 2022-06-11 23:51:49.949898
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # monkeypatching input
    input_headers = '''\
HTTP/1.1 200 OK
Date: Fri, 17 Jan 2020 00:55:17 GMT
Content-Length: 291
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Fri, 31 Jan 2020 05:54:55 GMT
ETag: "9fe-59c4d4a3-1"
Accept-Ranges: bytes
Cache-Control: max-age=0
Expires: Fri, 17 Jan 2020 00:55:17 GMT
Content-Type: text/html
'''

# Generated at 2022-06-11 23:51:58.100091
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    output = formatter.format_headers('''\
HTTP/1.1 200 OK
Content-Length: 17
Cache-Control: max-age=600
Content-Type: application/json; charset=UTF-8
Date: Mon, 01 Jan 2018 17:00:00 GMT
Expires: Mon, 01 Jan 2018 17:10:00 GMT
X-Powered-By: Express
Accept-Ranges: bytes
Connection: keep-alive
ETag: W/"11-1522574643000"

{ "message": "hello" }''')

# Generated at 2022-06-11 23:52:00.002950
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options=[('headers', 'sort', False)]
    assert HeadersFormatter(format_options=format_options).enabled == False


# Generated at 2022-06-11 23:52:08.650895
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Server: Werkzeug/0.15.2 Python/3.7.4
Date: Wed, 13 Nov 2019 18:43:40 GMT
Content-Length: 11

Hello, World!""") == """\
HTTP/1.1 200 OK
Content-Length: 11
Content-Type: text/plain; charset=utf-8
Date: Wed, 13 Nov 2019 18:43:40 GMT
Server: Werkzeug/0.15.2 Python/3.7.4

Hello, World!"""


# Generated at 2022-06-11 23:52:15.492973
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    x = HeadersFormatter()
    formatted_headers = x.format_headers(
    """\
HTTP/1.1 200 OK
HTTP/1.1 200 OK
Content-Length: 4
Content-Type: text/html; charset=utf-8
Date: Tue, 10 Dec 2019 03:10:29 GMT
Server: Werkzeug/0.15.4 Python/3.7.4
X-Powered-By: Express

test
    """
    )


# Generated at 2022-06-11 23:52:19.004934
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={
            'headers': {
                'sort': True
            }
        }
    )
    assert headers_formatter.enabled == True


# Generated at 2022-06-11 23:52:29.235487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers('HTTP/1.1 200 OK\r\n' +
                                                'Content-Type: application/json\r\n' +
                                                'Server: TornadoServer/6.0.2\r\n' +
                                                'Content-Length: 10000\r\n' +
                                                'Date: Thu, 14 May 2020 21:27:06 GMT\r\n')
    # Check if all headers are present
    assert 'HTTP/1.1 200 OK' in headers
    assert 'Content-Type: application/json' in headers
    assert 'Server: TornadoServer/6.0.2' in headers
    assert 'Content-Length: 10000' in headers
    assert 'Date: Thu, 14 May 2020 21:27:06 GMT' in headers
    # Check if all headers are sorted correctly

# Generated at 2022-06-11 23:52:38.783455
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = ('content-length: 10\n'
               'a: 1\n'
               'a: 2\n'
               'b: 1\n'
               'b: 3\n')
    assert hf.format_headers(headers) == (
        'content-length: 10\n'
        'a: 1\n'
        'a: 2\n'
        'b: 1\n'
        'b: 3\n'
    )


# Generated at 2022-06-11 23:52:45.775095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test case for method format_headers of class HeadersFormatter.
    """
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:52:56.355783
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 3
Content-Type: text/html; charset=UTF-8
ETag: "YGA=="
'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 3
Content-Type: text/html; charset=UTF-8
ETag: "YGA=="
'''


# Generated at 2022-06-11 23:52:57.797085
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled



# Generated at 2022-06-11 23:53:08.049849
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter(raw_format='')

# Generated at 2022-06-11 23:53:16.528882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\n'.join((
        'GET / HTTP/1.1',
        'Content-Length: 0',
        'Content-Type: text/html; charset=utf-8',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'Accept: */*'
    ))) == '\r\n'.join((
        'GET / HTTP/1.1',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Content-Length: 0',
        'Content-Type: text/html; charset=utf-8',
        'Connection: keep-alive'
    ))



# Generated at 2022-06-11 23:53:21.499031
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\n') == 'HTTP/1.1 200 OK\r\nContent-Length: 2\r\nContent-Type: application/json\r\n'

# Generated at 2022-06-11 23:53:30.181668
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    # No headers to sort
    assert hf.format_headers('foo') == 'foo'
    # One header
    assert hf.format_headers('foo\r\nX: 1') == 'foo\r\nX: 1'
    # Two headers in different order
    assert hf.format_headers('foo\r\nX: 1\r\nY: 2') == 'foo\r\nX: 1\r\nY: 2'
    # Two headers in same order
    assert hf.format_headers('foo\r\nX: 1\r\nX: 2') == 'foo\r\nX: 1\r\nX: 2'
    # Two headers in reversed order

# Generated at 2022-06-11 23:53:33.526301
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Unit test for constructor of class HeadersFormatter
    """
    headersFormatter = HeadersFormatter(format_options=config.DEFAULT_FORMAT_OPTIONS)

    assert headersFormatter != None


# Generated at 2022-06-11 23:53:39.685596
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    '''
    Sorts headers by name while retaining relative order
    of multiple headers with the same name.
    '''
    # arrange
    headers_str = b"""GET / HTTP/1.1\r
Connection: keep-alive\r
Cache-Control: max-age=0\r
Accept-Language: en-US,en;q=0.8\r
Upgrade-Insecure-Requests: 1\r
User-Agent: python-requests/2.10.0\r
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r
Accept-Encoding: gzip, deflate, sdch\r
Host: www.google.com\r
"""

# Generated at 2022-06-11 23:53:43.557997
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = {
        "headers": { "sort": True }
    }
    formatter = HeadersFormatter(format_options=options, config=None)
    assert formatter.enabled
    assert formatter.format_options == options



# Generated at 2022-06-11 23:53:53.222787
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Unit test for method format_headers of class HeadersFormatter."""
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Connection: close\r\n' \
              'Content-Length: 18\r\n' \
              'Date: Sun, 05 Nov 2017 04:13:13 GMT\r\n' \
              'Server: BaseHTTP/0.6 Python/2.7.13\r\n'

# Generated at 2022-06-11 23:53:55.534892
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test = HeadersFormatter(format_options=None, **{})
    assert isinstance(test, FormatterPlugin)



# Generated at 2022-06-11 23:54:01.788639
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('\r\n'.join([
        'HTTP/1.1 200 Ok',
        'Content-Encoding: gzip',
        'Content-Type: text/plain; charset=utf-8',
        'Vary: Accept-Encoding',
    ])) == '\r\n'.join([
        'HTTP/1.1 200 Ok',
        'Content-Encoding: gzip',
        'Content-Type: text/plain; charset=utf-8',
        'Vary: Accept-Encoding',
    ])



# Generated at 2022-06-11 23:54:06.405970
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
x-c: 2
x-a: 1
x-b: 3
x-a: 4
    '''
    headers = HeadersFormatter().format_headers(headers)
    assert headers == '''
x-a: 1
x-a: 4
x-b: 3
x-c: 2
    '''.strip()

# Generated at 2022-06-11 23:54:12.841606
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    hdrs = """GET / HTTP/1.1
Accept: */*
Cookie: a=b
Cookie: c=d
Content-Type: application/json
Content-Length: 2
Host: example.org
"""
    sorted_hdrs = """GET / HTTP/1.1
Accept: */*
Content-Type: application/json
Content-Length: 2
Cookie: a=b
Cookie: c=d
Host: example.org
"""
    assert sorted_hdrs == hf.format_headers(hdrs)

# Generated at 2022-06-11 23:54:14.645516
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        "headers": {"sort": True}
    }
    headersFormatter = HeadersFormatter(format_options=format_options)
    assert headersFormatter.enabled == True

# Generated at 2022-06-11 23:54:19.881361
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    
    # Create an instance of class HeadersFormatter
    formatter = HeadersFormatter()
    
    # Create a string with two headers
    headers = '''
Content-Length: 20
Content-Type: application/json
Content-Encoding: gzip
    '''

    # Call the method format_headers
    headers = formatter.format_headers(headers)

    # Test if the expected and actual headers match
    assert headers == '''
Content-Length: 20
Content-Encoding: gzip
Content-Type: application/json
    '''


# Generated at 2022-06-11 23:54:27.894047
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    input_headers = '''
    HTTP/1.1 200 OK
    X-Foo: bar
    Content-Type: application/json
    Content-Length: 52073
    X-Bar: foo
    X-Bar: baz
    '''
    output_headers = '''
    HTTP/1.1 200 OK
    Content-Length: 52073
    Content-Type: application/json
    X-Bar: foo
    X-Bar: baz
    X-Foo: bar
    '''
    assert (headersFormatter.format_headers(input_headers) == output_headers)

# Generated at 2022-06-11 23:54:33.417219
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    code = HeadersFormatter(charset='utf-8')
    to_test = code.format_headers('HTTP/1.1 200 OK\r\n' +
                                  'Server: nginx\r\n' +
                                  'Content-Type: application/json\r\n' +
                                  'Set-Cookie: name=value; Expires=Wed, 09 Jun 2021 10:18:14 GMT\r\n' +
                                  'Date: Tue, 09 Jun 2020 10:18:14 GMT\r\n' +
                                  'Content-Length: 15\r\n' +
                                  'Connection: keep-alive\r\n\r\n' +
                                  '{"red":"blue"}')

# Generated at 2022-06-11 23:54:36.893568
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'Header: value1\nHeader: value2\nHeader2: value2\n'
    assert formatter.format_headers(headers) == 'Header: value1\nHeader: value2\nHeader2: value2\n'

test_HeadersFormatter_format_headers()
        


# Generated at 2022-06-11 23:54:49.111234
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-11 23:54:58.101880
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter.
    """
    # Create an instance of HeadersFormatter with proper inputs
    headers_formatter = HeadersFormatter()
    headers = """
    HTTP/1.1 200 OK
    Content-Type: application/json
    Server: gunicorn/19.9.0
    Date: Sat, 12 Jan 2019 05:45:15 GMT
    Connection: keep-alive
    Content-Length: 359
    Access-Control-Expose-Headers: X-Total-Count
    Access-Control-Allow-Origin: *
    Allow: GET, HEAD, OPTIONS
    X-Total-Count: 4
    """
    # Test method format_headers with the headers string
    new_headers = headers_formatter.format_headers(headers)
    # Assert method format_headers

# Generated at 2022-06-11 23:55:01.494780
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={"headers": {}}).format_options["headers"]["sort"] is False
    assert HeadersFormatter(format_options={"headers": {"sort": True}}).format_options["headers"]["sort"] is True


# Generated at 2022-06-11 23:55:09.381268
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    out = hf.format_headers("""\
HTTP/1.1 200 OK
server: nginx
content-length: 5
x-content-type-options: nosniff
x-frame-options: sameorigin
x-xss-protection: 1; mode=block
set-cookie: cookie1=value1
set-cookie: cookie2=value2
set-cookie: cookie3=value3
x-foo: bar
date: Thu, 15 Oct 2015 17:23:20 GMT
content-type: text/html; charset=utf-8""")


# Generated at 2022-06-11 23:55:18.362959
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert(HeadersFormatter().format_headers('GET /dump.php?foo=bar HTTP/1.1\r\nContent-Type: text/html; charset=utf-8\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n') == 'GET /dump.php?foo=bar HTTP/1.1\r\nContent-Type: text/html; charset=utf-8\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n')

# Generated at 2022-06-11 23:55:20.436752
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = '\r\n'.join((
        'GET /',
        'Host: example.org',
        'Connection: keep-alive',
        'User-Agent: python-httpie',
        'Accept: */*'))

    assert lines == HeadersFormatter().format_headers(lines)

# Generated at 2022-06-11 23:55:24.469765
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from_string_mock = MagicMock()
    from_string_mock.return_value = 'GET https://api.github.com/ HTTP/1.1'
    headers_formatter = HeadersFormatter(from_string_mock)
    assert isinstance(headers_formatter, HeadersFormatter)
    assert headers_formatter.format_options['headers']['sort'] is False
    assert headers_formatter.enabled is False


# Generated at 2022-06-11 23:55:34.850719
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter('headers', sort=False)
    sorted_headers = HeadersFormatter('headers', sort=True)
    assert headers.format_headers(
        DEFAULT_FORMAT_OPTIONS['headers']['truncate'] * 2
    ) == sorted_headers.format_headers(
        DEFAULT_FORMAT_OPTIONS['headers']['truncate'] * 2
    )


# Generated at 2022-06-11 23:55:38.205212
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header = 'Content-Type: application/json;charset=utf-8\r\nContent-Type: application/json;charset=utf-8\r\n'
    expected_header = 'Content-Type: application/json;charset=utf-8\r\nContent-Type: application/json;charset=utf-8\r\n'
    assert HeadersFormatter.format_headers(header) == expected_header



# Generated at 2022-06-11 23:55:45.563525
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_string = '\r\n'.join(['GET / HTTP/1.1',
                         'Accept: application/json',
                         'Content-Type: application/json',
                         'X-Custom-Header: application/json',
                         'X-Custom-Header: application/json'])

    res = requests.post('http://httpbin.org/anything', headers=header_string)
    assert res.headers['Content-Type'] == 'application/json'
    assert res.headers['X-Custom-Header'] == 'application/json'



# Generated at 2022-06-11 23:56:00.360514
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Construction of object to test
    obj = HeadersFormatter()
    # Object to test
    string_to_test = '''HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Sat, 09 Dec 2017 16:43:42 GMT
Vary: Origin, Accept-Encoding
Content-Length: 2
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
Connection: keep-alive

{"a":1}'''

# Generated at 2022-06-11 23:56:05.100026
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    kwargs = {'format_options': {'headers': {'sort': True}}}
    headers_formatter = HeadersFormatter(**kwargs)
    assert headers_formatter is not None

headers_formatter = HeadersFormatter()
assert headers_formatter is not None


# Generated at 2022-06-11 23:56:09.143026
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def test_request(reqf):
        return requests.Request('GET', 'http://httpie.org/',
                                data=reqf.encode('utf-8'))

    def test_formatted(formattedf):
        assert formattedf == formattedf.upper()

    class TestFormatter(HeadersFormatter):
        def __init__(self):
            super().__init__()

        def format_headers(self, headers: str) -> str:
            return super().format_headers(headers).upper()

    formatter = TestFormatter()
    formatter.test_with(test_request, test_formatted)

# Generated at 2022-06-11 23:56:10.740085
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        HeadersFormatter()
    except Exception as e:
        raise AssertionError('Failed to create object: %s' % e)

# Generated at 2022-06-11 23:56:14.084163
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter_plugin = HeadersFormatter.from_options({'headers': {'sort': True}})
    assert formatter_plugin.format_options['headers']['sort'] == True
    assert formatter_plugin.enabled == True


# Generated at 2022-06-11 23:56:22.236184
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:56:31.140544
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    text = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 35
Connection: keep-alive
Date: Fri, 26 Jun 2015 01:55:55 GMT
Server: nginx/1.6.2'''

    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json; charset=utf-8
Date: Fri, 26 Jun 2015 01:55:55 GMT
Server: nginx/1.6.2'''

    formatter = HeadersFormatter()
    assert formatter.format_headers(text) == expected

# Unit test of class MultipleHeadersFormatter
import unittest

from httpie.compat import urlopen
from tests import TestEnvironment, http

# Generated at 2022-06-11 23:56:40.536968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 1551
Connection: keep-alive
Access-Control-Allow-Origin: *
Server: nginx
Strict-Transport-Security: max-age=31536000
Date: Wed, 10 Oct 2018 23:35:53 GMT
x-request-id: 6b23f64a-a163-4409-9b84-bcdccbf41cff
x-frame-options: SAMEORIGIN
ETag: W/"5f6-Oc7PuY/aQ2g498eRSEPwfubNpE"
Via: 1.1 vegur

"""

# Generated at 2022-06-11 23:56:41.612751
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf


# Generated at 2022-06-11 23:56:43.288516
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    plugin = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert plugin.enabled
