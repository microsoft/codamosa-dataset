

# Generated at 2022-06-11 23:48:12.458900
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fm = HeadersFormatter()
    headers = """\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Type: application/json
Content-Length: 4
User-Agent: HTTPie/1.0.0"""
    expected_headers = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 4
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/1.0.0"""
    assert fm.format_headers(headers) == expected_headers


# Generated at 2022-06-11 23:48:21.481535
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.format_headers("\r\n".join([
        'HTTP/1.1 200 OK',
        'Cookie: foo=bar; baz=qux',
        'Content-Type: application/json',
        'Content-Length: 13',
        'Connection: keep-alive',
        '',
        '{ "status": 200 }'
    ])) == "\r\n".join([
        'HTTP/1.1 200 OK',
        'Content-Length: 13',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Cookie: foo=bar; baz=qux',
        '',
        '{ "status": 200 }'
    ])




# Generated at 2022-06-11 23:48:31.254577
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert(f.format_headers("""HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 12
Other: True
Random: True
OtherHeader: 1
OtherHeader: 2
OtherHeader: 3
OtherHeader: 4
OtherHeader: 5
OtherHeader: 6
OtherHeader: 7

""") == """HTTP/1.1 200 OK
Content-Length: 12
Content-Type: application/json; charset=utf-8
Other: True
OtherHeader: 1
OtherHeader: 2
OtherHeader: 3
OtherHeader: 4
OtherHeader: 5
OtherHeader: 6
OtherHeader: 7
Random: True

""")


# Generated at 2022-06-11 23:48:39.611958
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    h = '''\
POST /api/user HTTP/1.1
Connection: keep-alive
Content-Length: 17
Accept: application/json
Content-Type: application/json
Host: example.com
User-Agent: HTTPie/0.9.9
X-API-Token: 12345
'''
    assert headers.format_headers(h) == '''\
POST /api/user HTTP/1.1
Accept: application/json
Content-Length: 17
Content-Type: application/json
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/0.9.9
X-API-Token: 12345
'''


# Generated at 2022-06-11 23:48:45.435389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l
Cache-Control: no-cache
Accept: application/json
'''
    sorted_headers = '''\
Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l
Accept: application/json
Cache-Control: no-cache
'''

    assert HeadersFormatter().format_headers(headers) == sorted_headers

# Generated at 2022-06-11 23:48:48.008882
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    my_class = HeadersFormatter()
    assert my_class.enabled is False
    assert isinstance(my_class.format_options, dict)

# Generated at 2022-06-11 23:48:56.539783
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_headers = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Date: Mon, 12 Jul 2010 19:00:42 GMT
Server: Apache
X-Powered-By: Servlet/2.5 JSP/2.1
ETag: W/\"1049-1278322642000\"
Content-Type: text/plain;charset=UTF-8
Content-Length: 1049
Age: 1
Connection: close

"""
    formatter_headers.format_headers(headers)
    actual = formatter_headers.format_headers(headers)

# Generated at 2022-06-11 23:49:07.554627
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}})
    test_headers = b'HTTP/1.1 200 OK\r\n' \
                   b'Content-Length: 14\r\n' \
                   b'Content-Type: text/plain; charset=utf-8\r\n' \
                   b'Date: Sun, 19 Jan 2020 18:56:38 GMT\r\n' \
                   b'Server: waitress\r\n'

# Generated at 2022-06-11 23:49:18.214959
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "abc: 123\n"
    assert formatter.format_headers(headers) == headers

    headers = "abc: 123\nxyz: x\n"
    expected_headers = "abc: 123\nxyz: x\n"
    sorted_headers = formatter.format_headers(headers)
    assert sorted_headers == expected_headers

    headers = "xyz: x\nabc: 123\n"
    expected_headers = "abc: 123\nxyz: x\n"
    sorted_headers = formatter.format_headers(headers)
    assert sorted_headers == expected_headers

    headers = "xyz: x\nabc: 123\nxyz: y\n"

# Generated at 2022-06-11 23:49:28.095505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:49:41.445331
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    headers = "HTTP/1.1 200 OK\r\nC: 3\r\nA: 1\r\nB: 2\r\nC: 4"
    exp_result = "HTTP/1.1 200 OK\r\nA: 1\r\nB: 2\r\nC: 3\r\nC: 4"
    assert h.format_headers(headers) == exp_result

    h = HeadersFormatter(format_options=dict(headers=dict(sort=False)))
    headers = "HTTP/1.1 200 OK\r\nC: 3\r\nA: 1\r\nB: 2\r\nC: 4"
    exp_result = headers
    assert h.format_

# Generated at 2022-06-11 23:49:52.065268
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:01.018374
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Host: localhost:5000
Accept: application/json, text/html;q=0.9
Connection: close
Content-Length: 20
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.0
"""
    expected = """\
Host: localhost:5000
Accept: application/json, text/html;q=0.9
Connection: close
Content-Length: 20
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.0
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-11 23:50:08.913543
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = textwrap.dedent("""\
        Content-Type: application/json
        Authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==
        Content-Length: 27
        Cookie: cookie1=value1; cookie2=value2
    """)

    formatted_headers = textwrap.dedent("""\
        Content-Type: application/json
        Content-Length: 27
        Cookie: cookie1=value1; cookie2=value2
        Authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==
    """)

    hf = HeadersFormatter(
        format_options = {
            'headers': {
                'sort': True
            }
        }
    )

    assert hf.format_headers(headers) == formatted

# Generated at 2022-06-11 23:50:16.673793
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Server: nginx/1.10.3
Date: Sun, 19 Mar 2017 11:11:49 GMT
Content-Type: text/html; charset=UTF-8
Transfer-Encoding: chunked
Connection: keep-alive
Content-Encoding: gzip"""
    actual = formatter.format_headers(headers)
    expected = """HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Type: text/html; charset=UTF-8
Date: Sun, 19 Mar 2017 11:11:49 GMT
Server: nginx/1.10.3
Transfer-Encoding: chunked"""
    assert actual == expected

# Generated at 2022-06-11 23:50:26.603950
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Goal
    goal = '''\
GET / HTTP/1.1
Accept: application/json
Content-Type: application/json
X-Header: value2
X-Header: value1
'''
    # Specific test case
    hf = HeadersFormatter(None, None)
    headers = '''\
GET / HTTP/1.1
X-Header: value1
Content-Type: application/json
Accept: application/json
X-Header: value2
'''
    assert hf.format_headers(headers) == goal
    # Random header values
    import random, string
    random.seed(0)
    num_headers = 20
    header_names = [''.join([
        random.choice(string.ascii_letters) for _ in range(10)])
        for _ in range(num_headers)]

# Generated at 2022-06-11 23:50:33.932542
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:44.269608
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case: Request headers
    headers_formatter_1 = HeadersFormatter(
        format_options={
            "headers": {
                "sort": True
            }
        }
    )
    assert headers_formatter_1.enabled is True
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.6
'''
    assert headers_formatter_1.format_headers(headers) == '''\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.6
'''

    # Case: Response headers
    headers_formatter_

# Generated at 2022-06-11 23:50:49.855250
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'Header3: value3',
        'Header2: value2',
        'Header1: value1',
    ])) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Header1: value1',
        'Header2: value2',
        'Header3: value3',
    ])



# Generated at 2022-06-11 23:50:54.882946
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_str = \
        'bar: one\n' \
        'foo: one\n' \
        'foo: two\n' \
        'foo: three'
    output_str = \
        'bar: one\n' \
        'foo: one\n' \
        'foo: two\n' \
        'foo: three'
    assert formatter.format_headers(input_str) == output_str


# Generated at 2022-06-11 23:51:09.038252
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''GET / HTTP/1.1\r
Host: localhost:8000\r
Accept-Encoding: gzip, deflate, br\r
User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; BOIE9;ENUS)\r
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r
\r
\r
'''

# Generated at 2022-06-11 23:51:11.869978
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled
    assert headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-11 23:51:17.988355
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # HeadersFormatter.__init__(headers = bool)
    h = HeadersFormatter(headers=True)
    assert h.enabled == True
    assert h.format_options['headers']['sort'] == h.enabled

    # HeadersFormatter.__init__(headers = bool)
    h = HeadersFormatter(headers=False)
    assert h.enabled == False
    assert h.format_options['headers']['sort'] == h.enabled


# Generated at 2022-06-11 23:51:23.514641
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Accept: application/json
Content-Length: 27
Content-Type: application/json
Accept-Encoding: gzip
"""
    expected = """\
Accept: application/json
Accept-Encoding: gzip
Content-Length: 27
Content-Type: application/json
"""
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-11 23:51:25.900502
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = 'Content-Length: 42\r\nContent-Type: application/json\r\nHost: example.com'
    assert headers_formatter.format_headers(headers) == '''\
Content-Length: 42
Content-Type: application/json
Host: example.com'''

# Generated at 2022-06-11 23:51:35.540766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """
        GET / HTTP/1.1
        Host: httpbin.org
        User-Agent: HTTPie/1.0.2
        Accept-Encoding: gzip, deflate, compress
        Accept: */*
        Connection: keep-alive
        Cookie: foo=bar
        Content-Type: application/json
        Content-Length: 15

        """
    ) ==  """
        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate, compress
        Connection: keep-alive
        Content-Length: 15
        Content-Type: application/json
        Cookie: foo=bar
        Host: httpbin.org
        User-Agent: HTTPie/1.0.2

        """.strip()



# Generated at 2022-06-11 23:51:43.970063
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    sorted_headers = headers_formatter.format_headers(
        '''
        HTTP/1.1 200 OK
        Content-Type: application/json; charset=utf-8
        Accept: application/json, */*
        User-Agent: HTTPie/0.9.9
        Accept-Encoding: gzip, deflate, compress
       '''
    )
    assert sorted_headers == '''
        HTTP/1.1 200 OK
        Accept: application/json, */*
        Accept-Encoding: gzip, deflate, compress
        Content-Type: application/json; charset=utf-8
        User-Agent: HTTPie/0.9.9
        '''.strip()



# Generated at 2022-06-11 23:51:51.315007
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers(
        '\r\n'.join(["Content-Type: application/json", "User-Agent: unit-test"]))
    assert headers == '\r\n'.join(["Content-Type: application/json", "User-Agent: unit-test"])


    headers = HeadersFormatter().format_headers(
        '\r\n'.join(["User-Agent: unit-test", "Content-Type: application/json"]))
    assert headers == '\r\n'.join(["Content-Type: application/json", "User-Agent: unit-test"])

# Generated at 2022-06-11 23:51:58.223574
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Example from https://httpie.org/doc#compact
    h1 = 'Content-Type: text/html; charset=utf-8\r\n'
    h2 = 'Content-Type: application/json\r\n'
    h3 = 'Date: Fri, 20 Oct 2017 18:40:40 GMT\r\n'
    h4 = 'Server: WSGIServer/0.2 CPython/3.7.1\r\n'
    h5 = 'X-Powered-By: Flask\r\n'
    h6 = 'X-Processed-Time: 0.001290025634765625\r\n'
    h7 = 'content-length: 0\r\n'
    h8 = 'connection: close\r\n'

# Generated at 2022-06-11 23:51:59.468921
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(headers=dict(sort=True))


# Generated at 2022-06-11 23:52:15.587764
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    arg = {'headers' : {'sort' : False} }
    hf = HeadersFormatter(**arg)
    assert not hf.enabled


# Generated at 2022-06-11 23:52:26.367472
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test when headers are sorted
    headers_string = '\r\n'.join(['GET / HTTP/1.1', 'Accept: application/json',
                                  'User-Agent: HTTPie/0.10.2'])
    # Expected output when headers are sorted
    expected_headers_string = '\r\n'.join(['GET / HTTP/1.1', 'Accept: application/json',
                                           'User-Agent: HTTPie/0.10.2'])
    assert HeadersFormatter(format_options = {
                            'headers':{'sort': True}}).format_headers(headers_string) == expected_headers_string
    # Test when headers are not sorted

# Generated at 2022-06-11 23:52:36.542471
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:52:44.380128
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:52:50.832316
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('GET / HTTP/1.1\r\nContent-Type: application/json\r\nAccept: text/html\r\nContent-Length: 0\r\nAccept-Encoding: gzip') == 'GET / HTTP/1.1\r\nAccept: text/html\r\nAccept-Encoding: gzip\r\nContent-Length: 0\r\nContent-Type: application/json'


# Generated at 2022-06-11 23:52:59.958969
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Generate headers
    headers = 'HTTP/1.1 200 OK\r\n'
    headers += 'Powered-By: ASP.NET\r\n'
    headers += 'Content-Type: application/json; charset=utf-8\r\n'
    headers += 'Cache-Control: no-cache\r\n'
    headers += 'Vary: Accept-Encoding\r\n'
    headers += 'Server: Microsoft-IIS/8.0\r\n'
    headers += 'X-Powered-By: PHP/5.6.30\r\n'
    headers += 'Content-Length: 6192\r\n'
    headers += 'X-AspNet-Version: 4.0.30319\r\n'

# Generated at 2022-06-11 23:53:07.870155
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''
GET / HTTP/1.1
Connection: close
Content-Length: unknown
Host: httpbin.org
User-Agent: HTTPie/1.0.2
'''.strip()[1:]
    h_res = '''
GET / HTTP/1.1
Content-Length: unknown
Connection: close
Host: httpbin.org
User-Agent: HTTPie/1.0.2
'''.strip()[1:]
    
    formatter = HeadersFormatter()
    assert formatter.format_headers(h) == h_res

# Generated at 2022-06-11 23:53:16.686486
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        'Vary: Accept\r\n'
        'X-Custom: one\r\n'
        'X-Custom: two\r\n'
        '\r\n'
    )
    expected_headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        'Vary: Accept\r\n'
        'X-Custom: one\r\n'
        'X-Custom: two\r\n'
        '\r\n'
    )
    assert expected

# Generated at 2022-06-11 23:53:26.889235
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    h = """date: Fri, 26 Jul 2019 15:44:44 GMT
server: ATS/8.0.7
x-frame-options: SAMEORIGIN
content-encoding: gzip
set-cookie: my_cookie=foo
set-cookie: my_other_cookie=bar
"""
    h_sorted = """date: Fri, 26 Jul 2019 15:44:44 GMT
set-cookie: my_cookie=foo
set-cookie: my_other_cookie=bar
server: ATS/8.0.7
x-frame-options: SAMEORIGIN
content-encoding: gzip
"""
    assert hf.format_headers(h) == h_sorted

# Generated at 2022-06-11 23:53:36.462523
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    expected = ''.join([
        'HTTP/1.1 200 OK\r\n',
        'Date: Tue, 14 Jan 2014 22:31:44 GMT\r\n',
        'Host: localhost:5000\r\n',
        'Connection: close\r\n',
        'Content-Length: 2\r\n',
        'Content-Type: application/json\r\n'
    ])
    assert formatter.format_headers(expected) == expected

# Generated at 2022-06-11 23:54:09.253947
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter=HeadersFormatter

    headers1 = '''\
HTTP/1.0 404 NOT FOUND
Server: nginx/1.12.0
Content-Type: text/html
Content-Length: 169
Accept-Ranges: bytes
Connection: keep-alive

'''

# Generated at 2022-06-11 23:54:17.664562
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that headers are sorted by name.

    """
    headers = '''
    Content-Type: application/json
    X-Forwarded-For: 58.64.138.88, 10.0.0.2
    X-Forwarded-For: 127.0.0.1, 10.0.0.2
    Args: none
    Connection: close
    '''
    expected_headers = '''
    Content-Type: application/json
    Args: none
    Connection: close
    X-Forwarded-For: 58.64.138.88, 10.0.0.2
    X-Forwarded-For: 127.0.0.1, 10.0.0.2
    '''

    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-11 23:54:18.781946
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf


# Generated at 2022-06-11 23:54:19.536352
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    pass


# Generated at 2022-06-11 23:54:21.316954
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    d = {'headers': {'sort': True}}
    headerFormatter = HeadersFormatter(format_options = d)
    assert headerFormatter.enabled == True


# Generated at 2022-06-11 23:54:29.312230
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: text/html; charset=UTF-8
Content-Length: 2048
Last-Modified: Sat, 31 Dec 2005 23:59:59 GMT
Server: Apache/2.0.54 (Unix)
"""
    formatted = h.format_headers(headers)
    assert formatted == """\
HTTP/1.1 200 OK
Content-Length: 2048
Content-Type: text/html; charset=UTF-8
Last-Modified: Sat, 31 Dec 2005 23:59:59 GMT
Server: Apache/2.0.54 (Unix)
"""

# Generated at 2022-06-11 23:54:36.530653
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('') == ''
    assert headers_formatter.format_headers('\n') == '\n'
    assert headers_formatter.format_headers('foo:bar') == 'foo:bar'
    assert headers_formatter.format_headers('HTTP/1.1 200 OK\nbar:foo\nFOO:bar\n') == 'HTTP/1.1 200 OK\nbar:foo\nFOO:bar\n'

# Generated at 2022-06-11 23:54:44.994000
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    result = HeadersFormatter(output_options={}).format_headers("""Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 12345
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: jsonplaceholder.typicode.com
User-Agent: HTTPie/1.0.3
""")
    expected = """Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 12345
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: jsonplaceholder.typicode.com
User-Agent: HTTPie/1.0.3
""".strip()
    assert result == expected



# Generated at 2022-06-11 23:54:46.537379
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert headersFormatter.enabled == False


# Generated at 2022-06-11 23:54:49.216059
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # The input data
    data = {}
    assert inspect.isclass(HeadersFormatter) == True
    assert issubclass(HeadersFormatter, FormatterPlugin) == True
    assert HeadersFormatter.__init__(data) != True

# Generated at 2022-06-11 23:55:23.055707
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'accept-type: text/plain\r\nexpires: 0\r\ncontent-type: text/html\r\naccept-type: text/html\r\n'
    formatter = HeadersFormatter()
    result = formatter.format_headers(headers)
    assert result == 'accept-type: text/plain\r\naccept-type: text/html\r\ncontent-type: text/html\r\nexpires: 0\r\n'



# Generated at 2022-06-11 23:55:29.020601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert(hf.format_headers("""HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 269
Foo: 1
Foo: 2
Foo: 3
Server: Werkzeug/0.14.1 Python/3.6.7
Date: Tue, 01 Jan 2019 00:00:00 GMT""")) == """HTTP/1.1 200 OK
Foo: 1
Foo: 2
Foo: 3
Content-Type: application/json; charset=utf-8
Content-Length: 269
Server: Werkzeug/0.14.1 Python/3.6.7
Date: Tue, 01 Jan 2019 00:00:00 GMT"""

# Generated at 2022-06-11 23:55:30.267691
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__.__func__


# Generated at 2022-06-11 23:55:38.733220
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:55:47.115401
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # arrange
    input = '''\
Accept: application/vnd.github.v3+xml
Accept-Encoding: gzip, deflate, compress
User-Agent: HTTPie/0.9.2
Connection: keep-alive
Content-Length: 2'''
    expected = '''\
Accept: application/vnd.github.v3+xml
Accept-Encoding: gzip, deflate, compress
User-Agent: HTTPie/0.9.2
Connection: keep-alive
Content-Length: 2'''
    # act
    actual = HeadersFormatter().format_headers(input)
    # assert
    assert expected == actual


# Generated at 2022-06-11 23:55:53.935232
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Allow: HEAD, GET
Allow: OPTIONS
Content-Encoding: gzip
Content-Length: 438
Content-Type: application/json; charset=utf-8
Date: Fri, 06 Apr 2018 01:56:07 GMT
Server: nginx/1.12.2
'''
    expectedResults = '''\
HTTP/1.1 200 OK
Allow: HEAD, GET
Allow: OPTIONS
Content-Encoding: gzip
Content-Length: 438
Content-Type: application/json; charset=utf-8
Date: Fri, 06 Apr 2018 01:56:07 GMT
Server: nginx/1.12.2
'''
    # Act

# Generated at 2022-06-11 23:55:58.352670
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "Accept-Encoding: deflate\r\nAccept: def\r\nAccept: abc\r\nContent-Length: 7\r\n"
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == "Accept-Encoding: deflate\r\nAccept: abc\r\nAccept: def\r\nContent-Length: 7\r\n"


# Generated at 2022-06-11 23:56:07.140460
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def check_format_headers(expected, inp):
        assert expected == HeadersFormatter(None).format_headers(inp)


# Generated at 2022-06-11 23:56:15.475016
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for HeadersFormatter method format_headers

    """
    headers = """GET /test HTTP/1.1
Host: www.example.com
Connection: keep-alive
Accept-Encoding: gzip, deflate, sdch, br
Accept-Language: en-US,en;q=0.8,de;q=0.6
User-Agent: HeadersFormatterTest"""
    headers_sorted = """GET /test HTTP/1.1
Accept-Encoding: gzip, deflate, sdch, br
Accept-Language: en-US,en;q=0.8,de;q=0.6
Connection: keep-alive
Host: www.example.com
User-Agent: HeadersFormatterTest"""
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:56:23.343865
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    text = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Connection: transfer-encoding
Date: Sun, 08 Dec 2019 17:59:50 GMT

{
    "category": {
        "id": 1,
        "name": "fruit",
        "parent_category": 2
    }
}'''
    assert formatter.format_headers(text) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Connection: transfer-encoding
Content-Type: application/json
Date: Sun, 08 Dec 2019 17:59:50 GMT

{
    "category": {
        "id": 1,
        "name": "fruit",
        "parent_category": 2
    }
}'''


# Generated at 2022-06-11 23:57:28.516983
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Define test variables
    context = Context()
    formatter = HeadersFormatter(format_options=context.format_options)
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Pragma: no-cache
Expires: -1
Server: Microsoft-IIS/8.0
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Tue, 12 Jun 2018 14:24:25 GMT
Content-Length: 466
'''

    # Call method to test
    result = formatter.format_headers(headers)

    # Assert

# Generated at 2022-06-11 23:57:34.312478
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(sort=True)
    input_headers = '''
    Content-Type: application/json
    Bbcookie: bbcookie
    Accept-Encoding: gzip, deflate
    Cookie: bbcookie
    Host: www.bbc.co.uk
    Accept-Language: en-GB,en-US;q=0.9,en;q=0.8
    Accept: application/json,text/*
    User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.142 Chrome/75.0.3770.142 Safari/537.36
    Referer: https://www.bbc.co.uk/
    Connection: close
    '''
   

# Generated at 2022-06-11 23:57:44.808430
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Sample headers obtained by running
    # http --print hb  localhost:5000/headers
    input = """
HTTP/1.0 200 OK
Content-Type: application/json
Content-Length: 45
Server: Werkzeug/0.16.0 Python/3.7.4
Date: Thu, 29 Oct 2020 20:06:52 GMT

{
    "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Host": "localhost:5000"
    }
}"""
    

# Generated at 2022-06-11 23:57:52.827810
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    formatter = HeadersFormatter()

    # Because the HTTP version is not a header to be sorted,
    # the first line in the headers section is not taken into account.
    inputString = "HTTP/1.1 200 OK\r\nD: d\r\nA: a\r\nC: c\r\nB: b\r\n"
    expectedOutput = "HTTP/1.1 200 OK\r\nA: a\r\nB: b\r\nC: c\r\nD: d\r\n"

    outputString = formatter.format_headers(inputString)
    assert outputString == expectedOutput

# Generated at 2022-06-11 23:58:01.656030
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = '\r\n'.join([
        'GET / HTTP/1.1',
        'User-Agent: httpie/1.0.3',
        'Accept-Encoding: gzip, deflate, identity',
        'Host: httpbin.org',
        'Accept: */*',
        'Connection: keep-alive',
    ])
    output = HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(lines)
    # print(output)