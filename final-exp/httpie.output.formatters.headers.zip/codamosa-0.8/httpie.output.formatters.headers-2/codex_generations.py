

# Generated at 2022-06-11 23:48:14.743704
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
Connection: close

'''
    formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: max-age=0, private, must-revalidate
Connection: close
Content-Length: 2
Content-Type: application/json

'''

# Generated at 2022-06-11 23:48:20.513249
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert(HeadersFormatter().format_headers("""\
GET / HTTP/1.1
Connection: close
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/2.0.0
Host: www.example.com\
""") == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Host: www.example.com
User-Agent: HTTPie/2.0.0\
""")

# Generated at 2022-06-11 23:48:30.795877
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        "headers": {"sort": True}
        })
    headers = """
HTTP/1.1 200 OK\r\n
Date:\tMon, 11 May 2015 07:03:00 GMT\r\n
Server:\tWSGIServer/0.1 Python/2.7.6\r\n
Content-Type:\tapplication/json\r\n
Content-Length:\t274\r\n
\r\n
"""

# Generated at 2022-06-11 23:48:40.181433
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
        # Input headers
        headers_str = """
Accept: */*
Accept-Language: en-US,en;q=0.8
Content-Type: application/x-www-form-urlencoded
User-Agent: Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36
"""
        expected = """
Accept: */*
Accept-Language: en-US,en;q=0.8
Content-Type: application/x-www-form-urlencoded
User-Agent: Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36
"""
        #

# Generated at 2022-06-11 23:48:48.184043
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options={})
    assert(
            obj.format_headers('HTTP/1.1 200 OK\r\n'
                               'Server: nginx/1.2.1\r\n'
                               'Date: Sat, 17 Aug 2013 17:20:08 GMT\r\n'
                               'Content-Type: application/json\r\n'
                               'Vary: Accept, Accept-Encoding') ==
            'HTTP/1.1 200 OK\r\n'
            'Content-Type: application/json\r\n'
            'Date: Sat, 17 Aug 2013 17:20:08 GMT\r\n'
            'Server: nginx/1.2.1\r\n'
            'Vary: Accept, Accept-Encoding'
    )

# Generated at 2022-06-11 23:48:56.635552
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    data = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=UTF-8
Date: Thu, 02 May 2019 06:42:21 GMT
Server: Apache/2.4.18 (Ubuntu)
Vary: Accept-Encoding

'''

    assert formatter.format_headers(data) == data

    data = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=UTF-8
Date: Thu, 02 May 2019 06:42:21 GMT
Server: Apache/2.4.18 (Ubuntu)
Vary: Accept-Encoding
X-Foo: 1
X-Bar: 2

'''


# Generated at 2022-06-11 23:49:07.640197
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(output_options={})
    assert headers_formatter.format_headers('line1\r\nline2\r\nline3')=='line1\r\nline2\r\nline3'
    assert headers_formatter.format_headers('line1\r\nline2\r\nline2\r\nline3') == 'line1\r\nline2\r\nline2\r\nline3'
    assert headers_formatter.format_headers('line1\r\nline3\r\nline2\r\nline2\r\nline3') == 'line1\r\nline2\r\nline2\r\nline3\r\nline3'

# Generated at 2022-06-11 23:49:18.342223
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    json = '''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 47
Date: Wed, 13 Feb 2019 23:52:20 GMT
Vary: Origin
Access-Control-Allow-Credentials: true
X-XSS-Protection: 1; mode=block
X-Frame-Options: DENY
ETag: W/"2f-fZ9P+RyL8xtvG1nfIR1nDd2gBz8"
Connection: keep-alive
X-Powered-By: Express
Content-Encoding: gzip

{"x": 1, "y": 2, "z": 3}'''

    formatter = HeadersFormatter()
    assert formatter.format_headers(json) == json



# Generated at 2022-06-11 23:49:28.170993
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    #testing the constructor of the class HeadersFormatter
    from httpie.plugins import FormatterPlugin
    from json import loads as json_loads
    from pytest import raises

    def test_dict_options(data):
        #testing the dictionary values and how it impacts the FormatterOptions
        #setting the options to defaults
        options = {'ugly': False, 'pretty': False, 'colors': False, 'format': '',
                   'headers': {'sort': True, 'regex': ''}, 'style': ''}
        #creating a formatteroptions object with defaults
        formatter_options = FormatterOptions()
        #testing the dictionary values
        assert formatter_options.data == options


# Generated at 2022-06-11 23:49:35.506554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that HeadersFormatter.format_headers sorts headers by name.
    """

# Generated at 2022-06-11 23:49:43.786284
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    http = HeadersFormatter()
    input_headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate, compress',
        'Cache-Control: no-cache',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Pragma: no-cache',
        'User-Agent: HTTPie/1.0.0-dev'
    ])

# Generated at 2022-06-11 23:49:53.780203
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Date: Sun, 26 May 2019 21:56:18 GMT\r\n'
        'Server: Apache\r\n'
        'X-Powered-By: PHP/5.6.40\r\n'
        'Vary: Accept-Encoding\r\n'
        'Content-Length: 1533\r\n'
        'Content-Type: text/html; charset=UTF-8\r\n'
        '\r\n'
    )

# Generated at 2022-06-11 23:50:04.453374
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter that
    sorts headers by name while retaining relative order of
    multiple headers with the same name.

    """
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
ConteNt-TypE: application/json

{"data": 123}
"""
    expected_result = """\
HTTP/1.1 200 OK
ConteNt-TypE: application/json

{"data": 123}
"""
    assert formatter.format_headers(headers) == expected_result

    headers = """\
HTTP/1.1 200 OK
ConteNt-TypE: application/json
ContenT-LeNgtH: 3

{}
"""

# Generated at 2022-06-11 23:50:10.538566
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_input = '''POST /post HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.2
Content-Length: 25
Content-Type: application/json

''' # noqa
    test_output = '''POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 25
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.2

''' # noqa
    formatter = HeadersFormatter(sort=True)
    assert formatter.format_headers(test_input) == test_output

# Generated at 2022-06-11 23:50:17.509880
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fp = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    headers = '''
        HTTP/1.1 200 OK
        x: 2
        a: 1
        b: 1
        a: 3
        x: 1
        Content-Type: application/json; charset=utf-8
        Content-Length: 17
        '''
    assert fp.format_headers(headers) == '''
        HTTP/1.1 200 OK
        a: 1
        a: 3
        b: 1
        Content-Type: application/json; charset=utf-8
        Content-Length: 17
        x: 1
        x: 2
    '''



# Generated at 2022-06-11 23:50:26.300520
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header = HeadersFormatter()
    header_as_string = header.format_headers("""
Content-Type: text/plain; charset=utf-8
Last-Modified: Fri, 04 Nov 2016 16:27:12 GMT
X-RateLimit-Remaining: 999
X-RateLimit-Limit: 1000
A: A
B: B
B: BB
C: C
""")

    assert header_as_string == """
Content-Type: text/plain; charset=utf-8
A: A
B: B
B: BB
C: C
Last-Modified: Fri, 04 Nov 2016 16:27:12 GMT
X-RateLimit-Remaining: 999
X-RateLimit-Limit: 1000
""".strip()

# Generated at 2022-06-11 23:50:33.827079
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """\
HTTP/1.1 404 Not Found
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 05 Dec 2016 17:00:08 GMT
Content-Type: text/html
Content-Length: 193
Connection: close
Vary: Cookie
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
"""
    sorted_headers = hf.format_headers(headers)

# Generated at 2022-06-11 23:50:44.269611
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    hf = HeadersFormatter(format_options={"headers":{"sort":True}}, none_value='\u2194')

    # one name before the other
    assert hf.format_headers("Accept: text/html\r\nContent-Type: text/html\r\n") == "Accept: text/html\r\nContent-Type: text/html\r\n"

    # different order of names
    assert hf.format_headers("Content-Type: text/html\r\nAccept: text/html\r\n") == "Accept: text/html\r\nContent-Type: text/html\r\n"

    # multiple headers with the same name

# Generated at 2022-06-11 23:50:48.894803
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers = ('GET / HTTP/1.1\r\n'
              'Accept: */*\r\n'
              'Accept-Encoding: gzip, deflate\r\n'
              'Connection: keep-alive\r\n'
              'Host: httpbin.org\r\n'
              'User-Agent: HTTPie/1.0.2\r\n'
              'X-Header: value1, value2\r\n\r\n')

    headers_formatter = HeadersFormatter()


# Generated at 2022-06-11 23:50:55.805351
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''
    Accept: text/html
    Connection: close
    Host: httpbin.org
    Accept-Encoding: gzip,deflate
    User-Agent: HTTPie/1.0.2
    Accept: application/json
    Connection: close
    '''
    sorted_headers = '''
    Accept: text/html
    Accept: application/json
    Connection: close
    Connection: close
    Host: httpbin.org
    Accept-Encoding: gzip,deflate
    User-Agent: HTTPie/1.0.2
    '''
    assert headers_formatter.format_headers(headers) == sorted_headers

# Generated at 2022-06-11 23:51:08.099812
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'CONTENT_LENGTH: 0\n' \
              'content-type: text/plain; charset=utf-8\n' \
              'ACCEPT: */*\n' \
              'HOST: wcipeg.com\n' \
              'ACCEPT-ENCODING: gzip, deflate\n' \
              'USER-AGENT: HTTPie/0.9.9\n' \
              'Connection: close\r\n' \
              '\r\n'
    formatter = formatters.HeadersFormatter(indent=2, sort_headers=True)
    output = formatter.format_headers(headers)


# Generated at 2022-06-11 23:51:17.999692
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.format_headers(
        '''Content-Type: application/json
        x-custom-header: abcdef
        X-Custom-Header: 123456
        X-Custom-Header: 789012
        Connection: keep-alive
        Accept-Encoding: gzip, deflate
        ''') == '''Content-Type: application/json
        Connection: keep-alive
        Accept-Encoding: gzip, deflate
        X-Custom-Header: 123456
        X-Custom-Header: 789012
        x-custom-header: abcdef
        '''
    return None

# Generated at 2022-06-11 23:51:25.991963
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f_headers = HeadersFormatter()
    assert f_headers.format_headers("""GET / HTTP/1.1
User-Agent: httpie/1.0.0
Accept: */*
Host: httpbin.org
Connection: keep-alive
Content-Length: 7
Accept-Encoding: gzip, deflate


""") == """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 7
Host: httpbin.org
User-Agent: httpie/1.0.0


""", "Test failed"



# Generated at 2022-06-11 23:51:30.333378
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    
    sort = True

    # Test HeadersFormatter with `sort` option set to `sort`
    try:
        HeadersFormatter(format_options={'headers': {'sort': sort}})
    except:
        assert False

    # Test HeadersFormatter with `sort` option set to `not_sort`
    try:
        HeadersFormatter(format_options={'headers': {'sort': not sort}})
    except:
        assert False


# Generated at 2022-06-11 23:51:41.209477
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print('='*100)
    print('Testing method format_headers of class HeadersFormatter')
    formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
    Connection: close
    Content-Type: application/json
    Content-Length: 36
    Accept-Ranges: bytes
    Date: Mon, 21 Nov 2016 15:14:45 GMT
    Etag: "1492084cbe0b0d1:0"
    Last-Modified: Sun, 20 Nov 2016 18:27:50 GMT
    Server: Microsoft-IIS/8.5
    X-Powered-By: ASP.NET
    Cache-Control: max-age=300'''
    print(formatter.format_headers(headers))

# Generated at 2022-06-11 23:51:50.583895
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Instantiate class HeadersFormatter
    headers_formatter = HeadersFormatter()

    # Test case 1
    headers = '''\
POST /post/ HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 16
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/2.0.0-dev0
X-Amzn-Trace-Id: Root=1-5efb5e5f-c527ccedf0e12069d3ba80b3

'''

# Generated at 2022-06-11 23:51:52.199301
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-11 23:51:57.240708
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Set-Cookie: z=1
Set-Cookie: a=1; Domain=example.com; Path=/

"""
    expected_headers = """\
HTTP/1.1 200 OK
Set-Cookie: a=1; Domain=example.com; Path=/
Set-Cookie: z=1

"""
    assert formatter.format_headers(headers) == expected_headers


__all__ = ('HeadersFormatter', 'test_HeadersFormatter_format_headers',)

# Generated at 2022-06-11 23:52:07.102768
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = """\
HTTP/1.1 200 OK
Server: Apache-Coyote/1.1
Content-Type: text/html;charset=utf-8
Content-Language: en
Content-Length: 54
Date: ???
"""
    sorted_headers = """\
HTTP/1.1 200 OK
Content-Language: en
Content-Length: 54
Content-Type: text/html;charset=utf-8
Date: ???
Server: Apache-Coyote/1.1
"""

    format_options = {
        'headers': {
            'sort': True
        }
    }

    formatter = HeadersFormatter(format_options=format_options)

    assert formatter.format_headers(headers) == sorted_headers

"""
Unit test for constructor of class HeadersFormatter
"""

# Generated at 2022-06-11 23:52:09.732259
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter
    assert formatter.enabled

# Test for method format_headers() using unittest
# headers: header information that we need to sort

# Generated at 2022-06-11 23:52:26.910767
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header = ('Content-Type: application/json\r\nUser-Agent: httpie\r\n'
              'Accept: */*\r\nConnection: keep-alive\r\n'
              'Cache-Control: no-cache\r\n')
    assert HeadersFormatter.format_headers(header) == ('Content-Type: application/json\r\nConnection: keep-alive\r\n'
                                                       'Cache-Control: no-cache\r\n'
                                                       'Accept: */*\r\nUser-Agent: httpie\r\n')

    lines = header.splitlines()
    headers = sorted(lines[1:], key=lambda h: h.split(':')[0])

# Generated at 2022-06-11 23:52:34.596042
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HeadersFormatter
    from httpie.plugins.manager import PluginManager
    assert issubclass(HeadersFormatter, FormatterPlugin)
    assert HeadersFormatter.name
    assert HeadersFormatter.description
    assert not HeadersFormatter.enabled
    assert not HeadersFormatter.enable_in_help
    assert not HeadersFormatter.installed
    assert HeadersFormatter.plugin_manager
    assert isinstance(HeadersFormatter.plugin_manager, PluginManager)


# Generated at 2022-06-11 23:52:41.164796
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    # Currently, the only sorting of headers that
    # takes place is by their names
    assert headers_formatter.format_headers("""\
HTTP/1.1 200 OK
Server: yuangong
Content-Type: application/json
Connection: keep-alive
Content-Length: 6
Vary: Accept-Encoding

{
    "uid": "12345"
}
""") == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 6
Content-Type: application/json
Server: yuangong
Vary: Accept-Encoding

{
    "uid": "12345"
}
"""

# Generated at 2022-06-11 23:52:49.610981
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
User-Agent: HTTPie/0.9.9
Host: httpbin.org
Connection: keep-alive
Accept-Encoding: gzip, deflate, compress
Accept: */*
Content-Type: application/json
Content-Length: 30"""
    headers_sorted = """\
User-Agent: HTTPie/0.9.9
Host: httpbin.org
Connection: keep-alive
Accept-Encoding: gzip, deflate, compress
Accept: */*
Content-Type: application/json
Content-Length: 30"""
    assert HeadersFormatter().format_headers(headers) \
        == headers_sorted
    # Check if it is only sorting the headers
    assert headers == headers_sorted


# Generated at 2022-06-11 23:52:58.429840
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    headers = '\n'.join(
        (
            'X-Foo: Foo',
            'X-Bar: Bar',
            'X-Foo: Baz',
        )
    )
    headers_formatter = HeadersFormatter(
        format_options=dict(
            headers=dict(
                sort=True
            )
        )
    )

    # When
    result = headers_formatter.format_headers(headers)

    # Then
    assert result == '\r\n'.join(
        (
            'X-Foo: Foo',
            'X-Foo: Baz',
            'X-Bar: Bar',
        )
    )



# Generated at 2022-06-11 23:53:08.609818
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdrs_formatter = HeadersFormatter()
    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    Date: Wed, 10 May 2017 10:55:19 GMT
    Last-Modified: Mon, 08 May 2017 10:04:14 GMT
    Server: TornadoServer/4.4.2
    Transfer-Encoding: chunked
    Connection: keep-alive
    X-RateLimit-Limit: 5000
    X-RateLimit-Remaining: 4998
    X-RateLimit-Reset: 1494295519
    Cache-Control: max-age=0, no-cache, no-store
    Pragma: no-cache
    '''
    hdrs_formatter.format_headers(headers)

# Generated at 2022-06-11 23:53:13.298858
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    data_root = os.path.join(project_root, "data")
    headers_txt = open(os.path.join(data_root, "headers.txt")).read()
    assert headers_txt == HeadersFormatter().format_headers(headers_txt)
    assert headers_txt.splitlines()[0] == HeadersFormatter().format_headers(headers_txt).splitlines()[0]
    assert headers_txt.splitlines()[0] == HeadersFormatter().format_headers(headers_txt).splitlines()[0]
    assert headers_txt.splitlines()[1] != HeadersFormatter().format_headers(headers_txt).splitlines()[1]
    assert headers_

# Generated at 2022-06-11 23:53:15.713964
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert 'headers' in formatter.format_options
    assert formatter.enabled == formatter.format_options['headers']['sort']


# Generated at 2022-06-11 23:53:18.209883
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    plugin = HeadersFormatter(format_options)
    assert "sort" == plugin.format_options['headers']['sort']

    assert "False" == str(plugin.enabled)



# Generated at 2022-06-11 23:53:28.689633
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
    Access-Control-Allow-Credentials: true
    Access-Control-Allow-Origin: http://localhost:4200
    Content-Type: application/json;charset=UTF-8
    Date: Thu, 09 Aug 2018 17:26:10 GMT
    Keep-Alive: timeout=5, max=100
    Transfer-Encoding: chunked
    X-Test: foo
    X-Test: bar
    """
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:53:44.760304
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    '''The HeadersFormatter class should be extended from FormatterPlugin'''
    headersformatter = HeadersFormatter(options={'headers': {'sort': True}})
    assert isinstance(headersformatter, FormatterPlugin)


# Generated at 2022-06-11 23:53:47.101381
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HEADERS_FORMATTER = HeadersFormatter()
    assert HEADERS_FORMATTER.format_options['headers']['sort'] == True

# Generated at 2022-06-11 23:53:55.882939
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: text/html; charset=utf-8
Date: Tue, 08 Aug 2017 10:45:13 GMT
Server: Werkzeug/0.12.1 Python/3.6.1

Hello\
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: text/html; charset=utf-8
Date: Tue, 08 Aug 2017 10:45:13 GMT
Server: Werkzeug/0.12.1 Python/3.6.1

Hello\
'''
    assert formatter.format_headers(headers) == expected_headers



# Generated at 2022-06-11 23:54:04.975878
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class Delegate(object):
        def __init__(self):
            super(Delegate, self).__init__()
            self.headers = None

        def on_headers(self, headers: list) -> None:
            self.headers = headers

    delegate = Delegate()
    headers_formatter = HeadersFormatter(sort=True)
    headers_formatter.delegate = delegate

    headers = '''
        Content-Length: 4
        Content-Type: application/json
        X-Powered-By: Flask
        X-Request-Id: ee23f75a-539a-4c5c-a3a3-3e8b9e9c9d9e
        X-Runtime: 0.006950
        '''
    formated_headers = headers_formatter.format_headers(headers)

# Generated at 2022-06-11 23:54:13.801643
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create an instance of the class HeadersFormatter
    headersFormatter = HeadersFormatter()
    # Create a headers string for testing
    headers = '''\
POST / HTTP/1.1\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
Content-Length: 23\r
Content-Type: application/x-www-form-urlencoded\r
Host: httpbin.org\r
User-Agent: HTTPie/0.9.9\r
\r
'''
    # Run the function format_headers
    headers = headersFormatter.format_headers(headers)
    # The result of the function should be as follows

# Generated at 2022-06-11 23:54:19.399073
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert (
        formatter.format_headers("""\
a: 1
b: 2
c: 3
d: 4
""")
        == """\
a: 1
b: 2
c: 3
d: 4
"""
    )
    assert (
        formatter.format_headers("""\
b: 2
b: 4
b: 3
c: 3
a: 1
d: 4
""")
        == """\
b: 2
b: 4
b: 3
c: 3
a: 1
d: 4
"""
    )

# Generated at 2022-06-11 23:54:24.854178
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    result = HeadersFormatter.format_headers.__func__(
        None,
        headers='''\
                        HTTP/1.1 200 OK
                        Content-Length: 8
                        Content-Type: application/json
                        Server: BaseHTTP/0.6 Python/3.6.1
                        allow: GET, HEAD, OPTIONS
                        cache-control: max-age=86400
                        date: Tue, 06 Feb 2018 14:11:11 GMT
                        expires: Wed, 07 Feb 2018 14:11:11 GMT
                        last-modified: Tue, 06 Feb 2018 05:06:06 GMT
                        x-frame-options: SAMEORIGIN''')


# Generated at 2022-06-11 23:54:28.486114
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = '''\
Content-Length: 128
Content-Type: application/json
Host: httpbin.org

    '''.strip()
    assert h.format_headers(headers) == headers

# Generated at 2022-06-11 23:54:31.977549
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        _ = HeadersFormatter()
    _ = HeadersFormatter(
        format_options=dict(headers=dict(sort=True))
    )


# Generated at 2022-06-11 23:54:36.097672
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__base__ == FormatterPlugin
    assert HeadersFormatter.__init__.__defaults__ == (None,)
    assert HeadersFormatter.__init__.__code__.co_varnames == ('self', '**kwargs')


# Generated at 2022-06-11 23:54:56.748470
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('''\
Host: localhost:8080
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
Content-Length: 15

''') == '''\
Host: localhost:8080
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 15
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/0.9.9

'''

# Generated at 2022-06-11 23:55:04.819790
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Legit and non legit tests for method format_headers
    """
    # Legit headers
    headers1 = (
        "HTTP/1.0 200 OK\r\n"
        "Content-Type: application/json; charset=UTF-8\r\n"
        "Server: gunicorn/19.9.0\r\n"
        "Date: Thu, 14 Nov 2019 06:36:41 GMT\r\n"
        "Content-Length: 594\r\n"
        "Connection: close\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Credentials: true\r\n"
        "Via: 1.1 vegur\r\n"
    )
    # Non legit headers

# Generated at 2022-06-11 23:55:09.534634
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        formatter = HeadersFormatter(format_options={'headers' : {'sort': True}})
        assert formatter.enabled is True
        formatter = HeadersFormatter(format_options={'headers' : {'sort': False}})
        assert formatter.enabled is False
    except:
        print("Error in HeadersFormatter()", sys.exc_info()[0])
        raise


# Generated at 2022-06-11 23:55:16.055243
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Dictionary describing headers format options
    format_options = {
        'headers': {
            'sort': True
        }
    }
    # Create an instance of HeadersFormatter
    headers_formatter = HeadersFormatter(format_options=format_options)
    # Check that it inherits from FormatterPlugin
    assert isinstance(headers_formatter, FormatterPlugin)
    # Check the instance attributes
    assert headers_formatter.format_options == format_options
    assert headers_formatter.enabled is True


# Generated at 2022-06-11 23:55:24.224090
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(
        format_options={"headers": {"sort": True}})
    headers = """\
POST / HTTP/1.1
Content-Type: application/json
Accept: application/json; indent=4
Connection: keep-alive
Content-Length: 2
Host: httpbin.org
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/1.0.0
"""
    expected_headers = """\
POST / HTTP/1.1
Accept: application/json; indent=4
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/1.0.0
"""
    assert expected_headers == headers_formatter.format_headers

# Generated at 2022-06-11 23:55:34.516534
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test with case sorted
    fh = HeadersFormatter()
    assert fh.format_headers(header) == '\r\n'.join(result_case_sorted)
    # Test with case not sorted
    fh = HeadersFormatter()
    assert fh.format_headers(header_case_unsorted) == '\r\n'.join(result_case_sorted)
    # Test with name sorted
    fh = HeadersFormatter()
    assert fh.format_headers(header_name_unsorted) == '\r\n'.join(result_name_sorted)


# Generated at 2022-06-11 23:55:36.233687
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(color=None)
    assert headers_formatter.enabled == False
    

# Generated at 2022-06-11 23:55:37.518720
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fh = HeadersFormatter()
    assert fh.__class__.__name__ == 'HeadersFormatter'


# Generated at 2022-06-11 23:55:38.993883
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled


# Generated at 2022-06-11 23:55:49.191721
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:56:21.292664
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:56:29.289028
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'Content-Length: 10\r\n'
        'Content-Type: application/json\r\n'
        'Connection: close\r\n'
        'Content-Length: 9\r\n'
        'Date: Fri, 01 Apr 2016 13:22:01 GMT\r\n'
        'Server: BaseHTTP/0.6 Python/3.5.2'
    )

# Generated at 2022-06-11 23:56:38.712963
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'Content-Type: application/json\r\n' \
              'User-Agent: httpie\r\n' \
              'Accept: application/json\r\n' \
              'Authorization: bearer 039_yq9\r\n' \
              'Accept-Encoding: gzip, deflate\r\n' \
              'Accept-Language: en-US\r\n' \
              'Connection: keep-alive'
    h = HeadersFormatter()
    assert h.format_headers(headers) == \
           'Content-Type: application/json\r\n' \
           'Accept: application/json\r\n' \
           'Accept-Encoding: gzip, deflate\r\n' \
           'Accept-Language: en-US\r\n' \
          

# Generated at 2022-06-11 23:56:41.503619
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('HTTP/1.1 200 OK\r\nB: 2\r\nA: 1') == 'HTTP/1.1 200 OK\r\nA: 1\r\nB: 2'

# Generated at 2022-06-11 23:56:49.125811
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create class object
    headersformatter = HeadersFormatter()
    # Call method
    sorted_headers = headersformatter.format_headers('HTTP/1.1 200 OK\r\nContent-Length: 12\r\nX-Foo: 1\r\nX-Foo: 2\r\nX-Foo: 3\r\nX-Bar: 4\r\nX-Bar: 5\r\nX-Bar: 6\r\n')

    # Check result

# Generated at 2022-06-11 23:56:58.110294
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    assert formatter.format_headers('''
HTTP/1.1 200 OK
Content-Length: 14
Cache-Control: max-age=3600
Accept-Ranges: bytes
Server: Example
Date: Mon, 01 Jan 1970 00:01:00 GMT
Last-Modified: Wed, 01 Apr 2015 13:00:00 GMT
Content-Type: application/json
    ''') == '''
HTTP/1.1 200 OK
Accept-Ranges: bytes
Cache-Control: max-age=3600
Content-Length: 14
Content-Type: application/json
Date: Mon, 01 Jan 1970 00:01:00 GMT
Last-Modified: Wed, 01 Apr 2015 13:00:00 GMT
Server: Example
    '''.strip()



# Generated at 2022-06-11 23:57:01.323204
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers(
        """\
GET / HTTP/1.1
Accept: application/json
Content-Type: application/json
Accept: application/xml"""
    ) == """\
GET / HTTP/1.1
Accept: application/json
Accept: application/xml
Content-Type: application/json"""

# Generated at 2022-06-11 23:57:07.660917
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    data = {'c': 'd', 'a': 'b'}
    formatter = HeadersFormatter()
    headers_str = '\r\n'.join(['Host: www.example.com',
                               'a: b',
                               'c: d'])
    assert formatter.format_headers(headers_str) == '\r\n'.join(['Host: www.example.com',
                                                                 'a: b',
                                                                 'c: d'])


# Unit tests for class HeadersFormatter

# Generated at 2022-06-11 23:57:14.342065
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:57:23.867509
# Unit test for method format_headers of class HeadersFormatter