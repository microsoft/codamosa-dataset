

# Generated at 2022-06-11 23:48:18.026258
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    #Arrange
    formatter = HeadersFormatter()

    #Act
    headers_formatted = str(formatter.format_headers("HTTP/1.1 200 OK\r\nDate: Sun, 11 Aug 2019 15:33:35 GMT\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 515\r\nConnection: keep-alive\r\nServer: nginx/1.2.1\r\nX-Powered-By: Express\r\nETag: W/\"207-1565632415000\"\r\nVary: Accept-Encoding\r\nAllow: GET,HEAD,PUT,PATCH,POST,DELETE\r\n\r\n"))

    #Assert

# Generated at 2022-06-11 23:48:24.149395
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # given
    format_options = {'headers': {'sort': True}}
    formatter = HeadersFormatter(format_options)
    # and
    headers = """GET / HTTP/1.1
Host: localhost
Accept: application/json
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.9
Connection: keep-alive
Cookie: PHPSESSID=blahblahblah
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"""
    # when
    result = formatter.format_headers(headers)
    # then
    assert result

# Generated at 2022-06-11 23:48:29.749028
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test with multiple headers with the same name
    assert HeadersFormatter().format_headers('''\
GET / HTTP/1.1
X-Header: FOO
X-Header: BAR
X-Header: BAZ
''') == '''\
GET / HTTP/1.1
X-Header: FOO
X-Header: BAR
X-Header: BAZ
'''


# Generated at 2022-06-11 23:48:31.377788
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={"headers": {"sort": True}})

    assert headersFormatter.enabled == True


# Generated at 2022-06-11 23:48:33.130323
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-11 23:48:43.067248
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Date: Thu, 17 May 2018 16:04:38 GMT
Server: WSGIServer/0.2 CPython/3.6.5
Vary: Cookie
X-Frame-Options: SAMEORIGIN
Content-Type: text/html; charset=utf-8
Allow: GET, HEAD, OPTIONS

'''

# Generated at 2022-06-11 23:48:49.337674
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers_before = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Access-Control-Allow-Credentials: true',
        'access-control-allow-headers: Authorization',
        'access-control-allow-headers: Content-Type',
        'Connection: keep-alive',
        'Content-Length: 529',
        'Date: Wed, 05 Dec 2018 12:34:56 GMT',
        'ETag: W/"209-UyjLNK2q3TqIcTZyz6ihxrlpE/Kg"',
        'Server: nginx/1.13.10',
        ''
    ])

# Generated at 2022-06-11 23:48:50.818641
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter != None



# Generated at 2022-06-11 23:48:57.640604
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers(
        'HTTP/1.1 200 OK\nZ: z\nY: y\nA: a\nB: b\n') == (
        'HTTP/1.1 200 OK\nA: a\nB: b\nY: y\nZ: z\n')
    assert hf.format_headers(
        'HTTP/1.1 200 OK\nA: a\nA: a\nA: a\n') == (
        'HTTP/1.1 200 OK\nA: a\nA: a\nA: a\n')

# Generated at 2022-06-11 23:49:08.194774
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers_1 = '''\
HTTP/1.1 200 OK
Date: Fri, 05 Dec 2014 22:16:38 GMT
Server: Apache
X-Powered-By: PHP/5.3.3-7+squeeze14
Set-Cookie: wordpress_test_cookie=WP+Cookie+check; path=/
Expires: Wed, 11 Jan 1984 05:00:00 GMT
Cache-Control: no-cache, must-revalidate, max-age=0
Pragma: no-cache
Content-Type: text/html; charset=UTF-8
Content-Length: 604
Connection: Close
'''

# Generated at 2022-06-11 23:49:21.308353
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = parse_options('--headers=sort')
    headers_formatter.setup()
    headers = "HTTP/1.1 200 OK\r\n" \
              "Date: Tue, 14 May 2019 10:27:22 GMT\r\n" \
              "Cache-Control: max-age=0, private, must-revalidate\r\n" \
              "Content-Type: text/html; charset=utf-8\r\n" \
              "Content-Length: 13\r\n" \
              "Content-Encoding: gzip\r\n" \
              "Host: httpbin.org\r\n"
    output = headers_formatter.format_headers(headers)

# Generated at 2022-06-11 23:49:25.765908
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "Custom-Header: Cheez\nOther-Header: Whiz\nOther-Header: Doodles"
    expected = "Custom-Header: Cheez\nOther-Header: Whiz\nOther-Header: Doodles"
    assert (HeadersFormatter().format_headers(headers) == expected)


# Generated at 2022-06-11 23:49:27.268270
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Generated at 2022-06-11 23:49:37.749466
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    order = [
        'Accept', 'Accept-Encoding', 'Accept-Language',
        'Connection', 'Host', 'User-Agent'
    ]
    vals = ['*/*', 'gzip, deflate', 'en-GB,en;q=0.5', 'keep-alive', 'example.com', 'HTTPie/0.9.8']
    d = dict(zip(order, vals))
    headers = '\r\n' + '\r\n'.join(['{}: {}'.format(k,v) for k,v in d.items()])
    assert hf.format_headers(headers) == '\r\n'.join(
        ['{}: {}'.format(k,v) for k,v in sorted(d.items())]
    )

# Generated at 2022-06-11 23:49:39.174288
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter({'headers': {'sort': True}})



# Generated at 2022-06-11 23:49:40.684672
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(**{'headers': {'sort': False}})
    assert not h.enabled


# Generated at 2022-06-11 23:49:51.205208
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test for method format_headers of class HeadersFormatter
    """
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:49:57.250715
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:06.726379
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    text = """
        HTTP/1.1 200 OK
        Content-Type: application/json
        X-Custom-Header: abc123
        X-Custom-Header: 42
        X-Custom-Header: 24
        X-Custom-Header2: def456
        X-Custom-Header3: 24
        Content-Length: 12
        """
    expected = """
        HTTP/1.1 200 OK
        Content-Length: 12
        Content-Type: application/json
        X-Custom-Header: abc123
        X-Custom-Header: 42
        X-Custom-Header: 24
        X-Custom-Header2: def456
        X-Custom-Header3: 24
        """
    assert formatter.format_headers(text) == expected



# Generated at 2022-06-11 23:50:15.654925
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Creating instance of class HeadersFormatter
    test_instance = HeadersFormatter()

    # Test case 1
    test_headers = (
        "GET / HTTP/1.1\r\n"
        "Accept: */*\r\n"
        "Accept-Encoding: gzip, deflate\r\n"
        "Connection: keep-alive\r\n"
        "Host: httpbin.org\r\n"
        "User-Agent: HTTPie/0.9.9\r\n"
        "\r\n"
    )


# Generated at 2022-06-11 23:50:22.544215
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # create an object of class HeadersFormatter
    headersFormatter = HeadersFormatter()
    # get the header by calling a function
    header = headersFormatter.format_headers(headers)
    assert header == "Content-Type: text/plain\r\Content-Length: 26"

# Generated at 2022-06-11 23:50:29.285904
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from collections import namedtuple
    from json import dumps
    # HeadersFormatter() =>
    # __init__(
    #     format_options = {'headers':
    #                           {'headers': ':',
    #                            'separator': ' ',
    #                            'sort': True}},
    #     config = FormatterConfig(colors = 256,
    #                              default_scheme_level = 2,
    #                              is_windows = False,
    #                              schemes = {'BASIC': {'body': 'blue',
    #                                                   'header': 'green',
    #                                                   'hseparator': 'magenta',
    #                                                   'hstring': 'yellow',
    #                                                   'hstring_escaped': 'cyan',
    #                                                   '

# Generated at 2022-06-11 23:50:40.198870
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Allow: GET, HEAD
Accept-Ranges: bytes
Server: Werkzeug/0.12.2 Python/3.6.2
Date: Fri, 01 Dec 2017 03:46:45 GMT
Content-Length: 95
Accept-Ranges: bytes
Via: 1.1 varnish
Via: 1.1 varnish
Age: 0
Connection: keep-alive
X-Served-By: cache-lhr6328-LHR
X-Cache: MISS
X-Cache-Hits: 0
X-Timer: S1512146006.113435,VS0,VE2
Vary: Origin
    '''.strip()

# Generated at 2022-06-11 23:50:49.507252
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        'HTTP/1.1 200 OK\r\n'
        'A: 1\r\n'
        'B: 2\r\n'
        'C: 3\r\n'
        'A: 11\r\n'
    ) == (
        'HTTP/1.1 200 OK\r\n'
        'A: 1\r\n'
        'A: 11\r\n'
        'B: 2\r\n'
        'C: 3\r\n'
    )

# ============================================================================
# Test for '--print=b'
# ============================================================================

# Test for '--print=b': require opt.prettify to be True.
#
# The command line options --headers, --body, --all are aliases to


# Generated at 2022-06-11 23:50:56.922790
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    kwargs = {'format_options': {'headers': {'sort': True}}}
    formatter = HeadersFormatter(**kwargs)

# Generated at 2022-06-11 23:51:04.100390
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Type: application/json
Date: Fri, 15 Jan 2016 21:59:03 GMT
Transfer-Encoding: chunked
''') == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Type: application/json
Date: Fri, 15 Jan 2016 21:59:03 GMT
Transfer-Encoding: chunked
'''

# Generated at 2022-06-11 23:51:14.735349
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 3000\r\n'
        'Content-Type: text/html\r\n'
        'Content-Encoding: gzip\r\n'
        'Cache-Control: max-age=3600\r\n'
        'Date: Sat, 18 Apr 2020 22:00:47 GMT\r\n'
        'Expires: Sat, 18 Apr 2020 23:00:47 GMT\r\n'
        '\r\n'
    )

# Generated at 2022-06-11 23:51:20.512988
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  formatter = HeadersFormatter()
  headers = """HTTP/1.1 200 OK
Content-Length: 3
Content-Type: text/plain
Content-Type: text/html
Connection: close

"""
  expected = """HTTP/1.1 200 OK
Content-Length: 3
Content-Type: text/plain
Content-Type: text/html
Connection: close

"""
  assert formatter.format_headers(headers) == expected


# Generated at 2022-06-11 23:51:28.529378
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ('Content-Type: application/json\r\n'
                   'Accept: application/json\r\n'
                   'Accept-Language: ru\r\n'
                   'Accept-Language: en\r\n'
                   'Accept-Charset: utf-8\r\n')
    expected_headers = ('Content-Type: application/json\r\n'
                        'Accept: application/json\r\n'
                        'Accept-Charset: utf-8\r\n'
                        'Accept-Language: ru\r\n'
                        'Accept-Language: en\r\n')
    assert(HeadersFormatter({}).format_headers(headers) == expected_headers)

# Generated at 2022-06-11 23:51:39.217656
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # input:
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 259
Server: Werkzeug/0.14.1 Python/3.6.4
Date: Tue, 15 May 2018 22:12:40 GMT

'''
    # output:
    e = '''\
HTTP/1.1 200 OK
Content-Length: 259
Content-Type: text/html; charset=utf-8
Date: Tue, 15 May 2018 22:12:40 GMT
Server: Werkzeug/0.14.1 Python/3.6.4

'''
    f = HeadersFormatter()
    a = f.format_headers(headers)
    assert a == e
