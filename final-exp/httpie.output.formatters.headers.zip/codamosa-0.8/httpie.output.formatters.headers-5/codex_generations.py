

# Generated at 2022-06-11 23:48:09.431165
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(
        """
HTTP/1.1 200 OK
Content-Length: 234
Content-Type: application/json
Date: Wed, 11 Jan 2017 15:17:33 GMT
Server: gunicorn/19.7.1

""") == """
HTTP/1.1 200 OK
Content-Length: 234
Content-Type: application/json
Date: Wed, 11 Jan 2017 15:17:33 GMT
Server: gunicorn/19.7.1

"""


headers_formatter = HeadersFormatter

# Generated at 2022-06-11 23:48:19.641060
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:48:30.624503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = 'GET / HTTP/1.1\r\n'
    s += 'Connection: keep-alive\r\n'
    s += 'Accept-Encoding: gzip,deflate\r\n'
    s += 'Accept: */*\r\n'
    s += 'Host: www.example.com\r\n'
    s += 'Content-Length: 18\r\n'
    s += 'User-Agent: httpie-plugin-headers\r\n'
    s += '\r\n'
    s += 'param1=value1&param2=value2'

# Generated at 2022-06-11 23:48:39.981514
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options={'headers': {'sort': True}})
    output_str = obj.format_headers(HEADERS)
    assert 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\n' in output_str
    assert 'Accept-Encoding: identity\n' in output_str
    assert 'Connection: keep-alive\n' in output_str
    assert 'Content-Length: 81\n' in output_str
    assert 'Content-Type: application/x-www-form-urlencoded\n' in output_str
    assert 'Host: httpbin.org\n' in output_str
    assert 'User-Agent: HTTPie/0.3.0\n' in output_str

# Unit

# Generated at 2022-06-11 23:48:44.647497
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test format_headers method of HeadersFormatter class
    """
    kwargs = dict(options=dict(headers=dict(sort=True)))

    formatter = HeadersFormatter(**kwargs)
    formatter.format_headers('GET / HTTP 1.1\r\nB: 2\r\nA: 1')

# Generated at 2022-06-11 23:48:54.785278
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    result_headers = hf.format_headers(input_headers)
    assert result_headers == output_headers

input_headers = """\
GET / HTTP/1.1
Connection: keep-alive
Accept-Encoding: gzip, deflate, sdch
Content-Type: application/json
Accept: */*
Content-Encoding: gzip
Accept-Language: en-US,en;q=0.8,es;q=0.6
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36
Host: somedomain.com
"""

# Generated at 2022-06-11 23:49:05.557325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "\
HTTP/1.1 200 OK\r\n\
Date: Tue, 14 Nov 2017 22:31:20 GMT\r\n\
Server: Apache/2.4.18 (Ubuntu)\r\n\
Last-Modified: Mon, 13 Nov 2017 22:31:19 GMT\r\n\
ETag: \"300000-56386cef79dc0\"\r\n\
Accept-Ranges: bytes\r\n\
Content-Length: 3\r\n\
Vary: Accept-Encoding\r\n\
Content-Type: text/plain\r\n\
\r\n\
xyz"
    headers_formatted = formatter.format_headers(headers)

# Generated at 2022-06-11 23:49:13.991355
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

    # case 1
    headers = "POST / HTTP/1.1\r\nAccept: application/json\r\nConnection: keep-alive\r\nContent-Length: 32\r\nContent-Type: application/x-www-form-urlencoded\r\nHost: localhost:5000\r\nUser-Agent: HTTPie/0.9.9\r\n\r\nfoo=bar&baz=qux&zap=zazzle"

# Generated at 2022-06-11 23:49:24.465954
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:49:26.560884
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(**{'headers': {'sort': True}})
    assert headers_formatter.enabled


# Generated at 2022-06-11 23:49:40.285488
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatted_headers = HeadersFormatter().format_headers("""\
Content-Type: application/json
Cookie: PHPSESSID=1a2b3c4d5e6f7g8h9i
Cookie: lang=en
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
Host: httpbin.org
""")
    assert formatted_headers == """\
Content-Type: application/json
Accept: */*
Accept-Encoding: gzip, deflate
Cookie: PHPSESSID=1a2b3c4d5e6f7g8h9i
Cookie: lang=en
Host: httpbin.org
User-Agent: HTTPie/0.9.9
"""



# Generated at 2022-06-11 23:49:42.936341
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print('Test HeadersFormatter() constructor')
    hf = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert hf != None
    print('Passed!')


# Generated at 2022-06-11 23:49:53.135845
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:50:03.817092
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

# Generated at 2022-06-11 23:50:04.254009
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-11 23:50:10.012532
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    n = '\r\n'
    inp = f'HEAD / HTTP/1.1{n}User-Agent: HTTPie/1.0.3{n}Content-Type: application/x-www-form-urlencoded; charset=utf-8{n}Content-Length: 45{n}'
    out = f'HEAD / HTTP/1.1{n}Content-Length: 45{n}Content-Type: application/x-www-form-urlencoded; charset=utf-8{n}User-Agent: HTTPie/1.0.3{n}'
    expect(HeadersFormatter().format_headers(inp)).to_equal(out)

# Generated at 2022-06-11 23:50:13.235693
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = {'headers': {'sort': True}}
    formatter = HeadersFormatter(format_options = options)
    assert formatter.format_options == options
    assert formatter.enabled == True


# Generated at 2022-06-11 23:50:23.740518
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET /test HTTP/1.1
Host: example.org
Accept: application/json
Accept: application/xml
X-Custom: foo

'''
    headers_sorted = '''\
GET /test HTTP/1.1
Accept: application/json
Accept: application/xml
Host: example.org
X-Custom: foo

'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted
    headers = '''\
GET /test HTTP/1.1
Host: example.org
Accept: application/json


'''
    headers_sorted = '''\
GET /test HTTP/1.1
Accept: application/json
Host: example.org


'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted

# Generated at 2022-06-11 23:50:28.057426
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """GET / HTTP/1.1
Host: example.com
Accept: application/json
Accept: application/xml"""
    ) == """GET / HTTP/1.1
Accept: application/json
Accept: application/xml
Host: example.com"""


# Generated at 2022-06-11 23:50:38.239086
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.cli.formatters import JSONFormatter
    from httpie.cli.formatter import Formatter

    f = HeadersFormatter()
    assert f.format_options == Formatter.format_options
    assert f.enabled is False
    assert f.output_file is None
    assert f.output_encoding == 'utf8'
    assert f.error_handler == JSONFormatter.error_handler
    assert f.should_strip_null_bytes is False
    assert f.should_pretty_print is True
    assert f.cleanup_namespaces is False
    assert f.colors == 0
    assert f.indent == 2
    assert f.max_json_depth == JSONFormatter.max_json_depth
    assert f.max_json_obj_len == JSONFormatter.max_json_obj_len


# Generated at 2022-06-11 23:50:50.248003
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_1 = '''
        Content-Type: application/json
        Accept: application/json
        b: test
        c: test
        a: test
    '''
    headers_2 = '''
        a: test
        b: test
        c: test
        Content-Type: application/json
        Accept: application/json
    '''
    assert HeadersFormatter(FormatOptions()).format_headers(headers_1) == headers_2
    assert HeadersFormatter(FormatOptions()).format_headers(headers_2) == headers_2


from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

from tests.output.streams import MockHexdump, MockRawIO



# Generated at 2022-06-11 23:50:56.244787
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = '''Accept: */*
Authorization: Basic c3VwZXI6c2VjcmV0
Host: localhost:5000
User-Agent: HTTPie/1.0.2


'''.splitlines()
    headers = sorted(lines[1:], key=lambda h: h.split(':')[0])
    assert '\r\n'.join(lines[:1] + headers) == '''Accept: */*
Host: localhost:5000
Authorization: Basic c3VwZXI6c2VjcmV0
User-Agent: HTTPie/1.0.2


'''

# Generated at 2022-06-11 23:51:05.879438
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Order of headers changes if 'sort' format option is true
    assert headers_formatter.format_headers(
        """Test: A \r\nTest: B \r\n""") == """Test: A \r\nTest: B \r\n"""
    headers_formatter.format_options['headers']['sort'] = True
    assert headers_formatter.format_headers(
        """Test: A \r\nTest: B \r\n""") == """Test: A \r\nTest: B \r\n"""

    # Multiple headers with the same name are still kept in relative order

# Generated at 2022-06-11 23:51:11.827297
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(options=Namespace()).format_headers(
        """\
Connection: keep-alive
Content-Length: 10
Content-Type: text/plain; charset=utf-8
"""
    ) == """\
Connection: keep-alive
Content-Length: 10
Content-Type: text/plain; charset=utf-8
"""

# Generated at 2022-06-11 23:51:21.920811
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:51:30.390383
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    in_headers = dedent("""
        POST /get HTTP/1.1
        Host: www.test.com
        WWW-Authenticate: Bearer realm="test", type="test"
        Content-Type: application/x-www-form-urlencoded; charset=utf-8
        Content-Length: 1
        Accept-Encoding: gzip, deflate
        """)
    out_headers = dedent("""
        POST /get HTTP/1.1
        Accept-Encoding: gzip, deflate
        Content-Length: 1
        Content-Type: application/x-www-form-urlencoded; charset=utf-8
        Host: www.test.com
        WWW-Authenticate: Bearer realm="test", type="test"
        """)
   

# Generated at 2022-06-11 23:51:42.015286
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: \"34aa387-d-1568eb00\"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Connection: close
Content-Type: text/plain"""
    headers_formatted = headers_formatter.format_headers(headers)

# Generated at 2022-06-11 23:51:51.281961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    headers = """\
POST / HTTP/1.1
Content-Length: 8
Content-Type: application/json; charset=utf-8
Host: 127.0.0.1:8000
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
"""
    assert fmt.format_headers(headers) == """\
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Content-Type: application/json; charset=utf-8
Host: 127.0.0.1:8000
User-Agent: HTTPie/0.9.9
Content-Length: 8
"""


# Generated at 2022-06-11 23:51:54.145436
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter(None, 'head', 'head', 'head')
    with pytest.raises(TypeError):
        HeadersFormatter('None', 'head', 'head', 'head')

# Generated at 2022-06-11 23:51:55.976029
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	format_options = {'headers': {'sort': False}}
	assert HeadersFormatter(format_options).enabled == False


# Generated at 2022-06-11 23:52:04.735853
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers.enabled is True


# Generated at 2022-06-11 23:52:12.998838
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:52:14.351075
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter()


# Generated at 2022-06-11 23:52:18.360999
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        test_headersformatter_obj1 = HeadersFormatter()
        test_headersformatter_obj1.format_headers("test")
    except Exception as e:
        print(e)
        assert False

# Utility function for testing class HeadersFormatter

# Generated at 2022-06-11 23:52:26.174041
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers('''\
Host: localhost:8080
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 48
Content-Type: application/json
User-Agent: HTTPie/0.9.8

''') == '''\
Host: localhost:8080
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 48
Content-Type: application/json
User-Agent: HTTPie/0.9.8

'''


# Generated at 2022-06-11 23:52:36.463486
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with open("test_headers.txt", "w") as file:
        file.write("GET / HTTP/1.1\n")
        file.write("Content-Length: 47\n")
        file.write("User-Agent: HTTPie/0.9.9\n")

    with open("test_headers.txt", "r") as file:
        headers = file.read()

    should_be = "GET / HTTP/1.1\r\n"\
                "Content-Length: 47\r\n"\
                "User-Agent: HTTPie/0.9.9"

    formatter = HeadersFormatter(test_headers.txt, test_headers.txt)
    assert formatter.format_headers(headers) == should_be

    # Delete the temporary file
    os.remove("test_headers.txt")

# Generated at 2022-06-11 23:52:38.204693
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled
    assert formatter.format_options['headers']['sort']


if __name__ == "__main__":
    test_HeadersFormatter()

# Generated at 2022-06-11 23:52:46.718178
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_orig = ('HTTP/1.1 200 OK\r\n'
                'Content-Type: text/html; charset=utf-8\r\n'
                'Content-Length: 431\r\n'
                'Connection: close\r\n'
                'Server: gunicorn/19.6.0\r\n'
                'Date: Thu, 19 Jan 2017 11:57:58 GMT\r\n'
                '\r\n')


# Generated at 2022-06-11 23:52:57.224262
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options=dict(
        headers=dict(sort=True)
    ))
    headers = """
        HTTP/1.1 200 OK
        Connection: keep-alive
        Server: nginx/1.6.2
        Date: Mon, 10 Jul 2017 16:34:05 GMT
        Content-Type: application/json
        Content-Length: 573
        Last-Modified: Fri, 16 Jun 2017 21:53:00 GMT
        Vary: Origin
        Access-Control-Allow-Origin: *
        X-Content-Type-Options: nosniff
        Etag: W/"571d5e0c-239"
        Allow: GET,HEAD,PUT,PATCH,POST,DELETE
        X-Frame-Options: SAMEORIGIN
        """

# Generated at 2022-06-11 23:52:58.318461
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled


# Generated at 2022-06-11 23:53:18.284312
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter(
        format_options={'headers': {'sort':True}})
    headers = 'HTTP/1.1 200 OK\r\n' \
        + 'Content-Type: application/json\r\n' \
        + 'Connection: close\r\n' \
        + 'Content-Length: 237'
    expected_result = 'HTTP/1.1 200 OK\r\n' \
        + 'Connection: close\r\n' \
        + 'Content-Length: 237\r\n' \
        + 'Content-Type: application/json'
    result = headersFormatter.format_headers(headers)
    assert result == expected_result


# Generated at 2022-06-11 23:53:25.871146
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

    assert headers_formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'B: 2',
        'A: 1',
        'B: 3',
    ])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'A: 1',
        'B: 2',
        'B: 3',
    ])



# Generated at 2022-06-11 23:53:35.671690
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:53:44.164159
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  out = HeadersFormatter().format_headers('HTTP/1.1 200 OK\r\nContent-Length: 10\r\nContent-Type: application/json\r\nX-Foo: Bar\r\nX-Baz: Qux\r\nHost: example.com\r\n')
  assert out == 'HTTP/1.1 200 OK\r\nContent-Length: 10\r\nContent-Type: application/json\r\nHost: example.com\r\nX-Baz: Qux\r\nX-Foo: Bar\r\n'

# Generated at 2022-06-11 23:53:52.597363
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    method_name: test_HeadersFormatter_format_headers
    test_description: Test format_headers method works as expected
    """
    parameters_dict = {}
    headers = '''HTTP/1.1 200 OK\r
Date: Mon, 27 Jul 2009 12:28:53 GMT\r
Server: Apache/2.2.14 (Win32)\r
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r
Content-Length: 88\r
Content-Type: text/html\r
Connection: Closed\r\n\r\n'''

# Generated at 2022-06-11 23:54:01.720260
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """
Origin: https://www.yelp.de
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36
Content-Type: application/x-www-form-urlencoded
"""
    expected = """
Origin: https://www.yelp.de
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36
Content-Type: application/x-www-form-urlencoded
"""
    result = headers_formatter.format_headers(headers)

# Generated at 2022-06-11 23:54:11.210647
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter
    """
    #
    # Test 1:
    #
    expected = '''Content-Type: application/json
X-Custom-Header-1: abc
X-Custom-Header-2: 123


'''
    actual = HeadersFormatter().format_headers('''Content-Type: application/json
X-Custom-Header-2: 123
X-Custom-Header-1: abc


''')
    assert actual == expected

    #
    # Test 2:
    #
    expected = '''X-Api-Key: 2r4j3k4h23k4h2k3j4h
Content-Type: application/json
X-Custom-Header-1: abc
X-Custom-Header-2: 123


'''

# Generated at 2022-06-11 23:54:16.046352
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Location: /hello/
Set-Cookie: name=value
Set-Cookie: other=value
'''
    result = HeadersFormatter(None).format_headers(h)
    assert result == '''\
HTTP/1.1 200 OK
Content-Type: application/json
Location: /hello/
Set-Cookie: name=value
Set-Cookie: other=value
'''

# Generated at 2022-06-11 23:54:21.640031
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('HTTP/1.1 200 OK\r\ncontent-type: application/json\r\npath: /\r\ncookie: csrftoken=abcde\r\nserver: gunicorn/19.7.1') == 'HTTP/1.1 200 OK\r\ncontent-type: application/json\r\ncookie: csrftoken=abcde\r\npath: /\r\nserver: gunicorn/19.7.1'


# Generated at 2022-06-11 23:54:30.745395
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('Content-Type: Foo\nContent-Length: Bar\nUser-Agent: Baz') == 'Content-Type: Foo\nContent-Length: Bar\nUser-Agent: Baz'
    assert formatter.format_headers('Content-Length: Bar\nContent-Type: Foo\nUser-Agent: Baz') == 'Content-Type: Foo\nContent-Length: Bar\nUser-Agent: Baz'
    assert formatter.format_headers('Content-Length: Bar\nUser-Agent: Baz\nContent-Type: Foo') == 'Content-Type: Foo\nContent-Length: Bar\nUser-Agent: Baz'

# Generated at 2022-06-11 23:55:07.162735
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    assert fmt.format_headers("""
                                HTTP/1.1 200 OK
                                Date: Mon, 27 Jul 2009 12:28:53 GMT
                                Server: Apache/2.2.14 (Win32)
                                Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
                                Content-Length: 88
                                Content-Type: text/html
                                Connection: Closed
                                """) == """
                                HTTP/1.1 200 OK
                                Connection: Closed
                                Content-Length: 88
                                Content-Type: text/html
                                Date: Mon, 27 Jul 2009 12:28:53 GMT
                                Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
                                Server: Apache/2.2.14 (Win32)
                                """

# Generated at 2022-06-11 23:55:16.287936
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    result = formatter.format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'User-Agent: httpie',
        'Cookie: a=b',
        'Cookie: x=y',
        'Host: example.org',
        'Accept-Encoding: gzip, deflate',
    ]))
    expected = '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept-Encoding: gzip, deflate',
        'Cookie: a=b',
        'Cookie: x=y',
        'Host: example.org',
        'User-Agent: httpie',
    ])
    assert result == expected
#
#


# Generated at 2022-06-11 23:55:22.039076
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'b: B',
        'c: C',
        'a: A'
    ])
    assert hf.format_headers(headers) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'a: A',
        'b: B',
        'c: C',
    ])
    
test_HeadersFormatter_format_headers()
 

# Generated at 2022-06-11 23:55:27.123832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    hf = HeadersFormatter()
    h = """GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: python-requests/2.22.0
Accept: */*
"""
    assert hf.format_headers(h) == """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: python-requests/2.22.0
"""

# Generated at 2022-06-11 23:55:36.444399
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s0 = "HTTP/1.1 200 OK\r\n" \
        "Content-Type: text/html; charset=utf-8\r\n" \
        "Transfer-Encoding: chunked\r\n" \
        "Server: Werkzeug/0.14.1 Python/3.6.1\r\n" \
        "Date: Fri, 19 Jan 2018 22:25:50 GMT\r\n"

# Generated at 2022-06-11 23:55:40.805326
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    formatter = HeadersFormatter(None, None)
    headers = """
    Content-Type: */*
    Accept-Encoding: gzip, deflate
    Accept: application/json
    User-Agent: httpie/0.9.9
    Accept-Encoding: gzip, deflate
    """

    # Act
    actual = formatter.format_headers(headers)

    # Assert
    expected = """
    Content-Type: */*
    Accept: application/json
    Accept-Encoding: gzip, deflate
    Accept-Encoding: gzip, deflate
    User-Agent: httpie/0.9.9
    """
    assert actual == expected



# Generated at 2022-06-11 23:55:50.386250
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from textwrap import dedent
    """
    Tests: 'sort' options of ['headers'] in JSON_OUTPUT_OPTIONS.
    The method format_headers in class HeadersFormatter
    returns a string of sorted headers while retaining relative
    order of multiple headers with the same name.
    """
    test_instance = HeadersFormatter()

# Generated at 2022-06-11 23:55:59.757734
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdr = '''
Accept: application/json
cache-control: no-cache
Content-Type: application/json
Host: localhost:5000
Postman-Token: 2d80fa44-8c42-4a89-a71b-03a8eaf901a1
User-Agent: PostmanRuntime/7.20.1
'''
    fmt_hdr = '''
Accept: application/json
Content-Type: application/json
Host: localhost:5000
Postman-Token: 2d80fa44-8c42-4a89-a71b-03a8eaf901a1
User-Agent: PostmanRuntime/7.20.1
cache-control: no-cache
'''
    assert HeadersFormatter().format_headers(hdr) == fmt_hdr


# Register the plugin
http

# Generated at 2022-06-11 23:56:07.927821
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.format_headers('HTTP/1.1 200 OK\r\n'
                                    'B: 2\r\n'
                                    'B: 1\r\n'
                                    'A: 4\r\n'
                                    'A: 3\r\n') \
        == 'HTTP/1.1 200 OK\r\n' \
           'A: 4\r\n' \
           'A: 3\r\n' \
           'B: 2\r\n' \
           'B: 1'


if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-11 23:56:16.386568
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

# Generated at 2022-06-11 23:57:15.414909
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-11 23:57:24.965364
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:57:30.343593
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HeadersFormatter as fp
    plugin = FormatterPlugin({'headers': {'sort': False}})
    assert plugin.format_options['headers']['sort'] == False

    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HeadersFormatter as fp
    plugin = FormatterPlugin({'headers': {'sort': True}})
    assert plugin.format_options['headers']['sort'] == True




# Generated at 2022-06-11 23:57:40.327816
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter()

    # simple case
    headers = '''GET / HTTP/1.1
Host: example.org
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html
'''
    assert formatter_plugin.format_headers(headers) == '''GET / HTTP/1.1
Accept: text/html
Cache-Control: max-age=0
Connection: keep-alive
Host: example.org
'''

    # two headers with the same name
    headers = '''GET / HTTP/1.1
Host: example.org
Connection: close
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html
'''

# Generated at 2022-06-11 23:57:45.697438
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    lines = 'cookie: 123\r\na: 1\r\nb: 2\r\ncookie: 456\r\nd\r\n'.splitlines()
    headers = formatter.format_headers('\r\n'.join(lines))
    assert headers == '\r\n'.join(['a: 1', 'b: 2', 'cookie: 123', 'cookie: 456', 'd'])

# Generated at 2022-06-11 23:57:55.412505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Cache-Control: max-age=0\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 13\r\n' \
              'Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-05-14)\r\n' \
              'Date: Fri, 03 Aug 2018 08:41:59 GMT\r\n'

# Generated at 2022-06-11 23:58:02.226716
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
Host: localhost:8080
User-Agent: HTTPie/0.9.8
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive'''.splitlines(keepends=True)
    expected_h = '''\
Host: localhost:8080
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.8'''.splitlines(keepends=True)
    formatter = HeadersFormatter()
    actual_h = formatter.format_headers(''.join(h))
    print(actual_h)
    print(expected_h)
    assert actual_h == ''.join(expected_h)