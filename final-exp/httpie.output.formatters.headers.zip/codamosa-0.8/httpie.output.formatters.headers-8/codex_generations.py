

# Generated at 2022-06-11 23:48:15.759161
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET /api/ HTTP/1.1
Accept: application/json
User-Agent: HTTPie/0.9.9
Accept: */*
Connection: keep-alive
'''
    expected = '''\
GET /api/ HTTP/1.1
Accept: application/json, */*
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-11 23:48:22.979567
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_input_1 = '''HTTP/1.1 200 OK
Server: nginx/1.14.0 (Ubuntu)
Content-Type: application/json
Date: Thu, 10 Jan 2019 10:17:37 GMT
Content-Length: 6
Connection: close

'''
    headers_output_1 = '''HTTP/1.1 200 OK
Connection: close
Content-Length: 6
Content-Type: application/json
Date: Thu, 10 Jan 2019 10:17:37 GMT
Server: nginx/1.14.0 (Ubuntu)

'''

# Generated at 2022-06-11 23:48:32.196619
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(
        stdout=io.StringIO(),
        format_options={'headers': {'sort': True}})
    assert hf.format_headers(
        '''
        !
        b: 2
        d: 0
        a: 1
        c: 3
        '''
        ) == '''
        !
        a: 1
        b: 2
        c: 3
        d: 0
        '''
    hf.format_options['headers']['sort'] = False

# Generated at 2022-06-11 23:48:35.557906
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert headers_formatter.format_options == {"headers": {"sort": True}} and headers_formatter.enabled is True


# Generated at 2022-06-11 23:48:41.598780
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(output_options={})
    headers = """\
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 135
Content-Type: application/json; charset=utf-8
Date: Tue, 09 Feb 2016 16:24:08 GMT
Expires: -1
Pragma: no-cache
Server: Kestrel
Vary: Accept
X-Powered-By: ASP.NET\
"""
    print(hf.format_headers(headers))

# Generated at 2022-06-11 23:48:50.507804
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    connection: close
    content-length: 40
    content-type: text/html; charset=utf-8
    date: Sat, 12 Nov 2016 06:57:30 GMT
    server: nginx/1.6.2
    set-cookie: sessionid=0b7hgxzc1p7vkk8z; expires=Sun, 11-Dec-2016 06:57:30 GMT; HttpOnly; Max-Age=2592000; Path=/
    status: 200
    via: 1.1 vegur
    x-frame-options: SAMEORIGIN
    x-request-id: dade34ec-28e0-4900-8127-02056b9e35a1
    x-runtime: 0.000007
    '''
    formatter = HeadersFormatter()
   

# Generated at 2022-06-11 23:48:54.884743
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("HTTP/1.1 200 OK\r\nCookie: a=b\r\nCookie: c=d\r\nFoo: bar") \
        == 'HTTP/1.1 200 OK\r\nCookie: a=b\r\nCookie: c=d\r\nFoo: bar'

# Generated at 2022-06-11 23:49:05.647701
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = "HTTP/1.1 200 OK\r\nDate: Mon, 23 May 2005 22:38:34 GMT\r\nServer: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)\r\nLast-Modified: Wed, 08 Jan 2003 23:11:55 GMT\r\nEtag: \"3f80f-1b6-3e1cb03b\"\r\nAccept-Ranges: bytes\r\nContent-Length: 438\r\nConnection: close\r\nContent-Type: text/html; charset=utf-8\r\n\r\n"

# Generated at 2022-06-11 23:49:14.064225
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(headers={'sort': True})

# Generated at 2022-06-11 23:49:24.510889
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(options={'headers': {'sort': True}})
    assert f.format_headers('HTTP/1.1 200 OK\r\nB: b\r\nA: a\r\n') == 'HTTP/1.1 200 OK\r\nA: a\r\nB: b\r\n'
    assert f.format_headers('HTTP/1.1 200 OK\r\nA: a\r\nA: a\r\n') == 'HTTP/1.1 200 OK\r\nA: a\r\nA: a\r\n'

# Generated at 2022-06-11 23:49:36.632905
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:49:38.812965
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter._format_options['headers']['sort'] == True


# Generated at 2022-06-11 23:49:48.989890
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    FORMATTED_HEADERS = """HTTP/1.1 200 OK
Accept-Encoding: gzip, deflate
Accept: */*
Date: Fri, 09 Aug 2019 13:37:25 GMT
Server: BaseHTTP/0.6 Python/3.4.4
X-Powered-By: DateTime
"""
    UNFORMATTED_HEADERS = """HTTP/1.1 200 OK
X-Powered-By: DateTime
Server: BaseHTTP/0.6 Python/3.4.4
Date: Fri, 09 Aug 2019 13:37:25 GMT
Accept: */*
Accept-Encoding: gzip, deflate
"""

    h_formatter = HeadersFormatter()
    h_formatter.format_options['headers']['sort'] = True

# Generated at 2022-06-11 23:49:52.613148
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers('Content-Type: text/plain\nContent-Length: 1000\nContent-Type: text/html')
    assert headers == 'Content-Type: text/plain\r\nContent-Type: text/html\r\nContent-Length: 1000'


# Generated at 2022-06-11 23:49:59.116260
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""\
GET / HTTP/1.1
Host: localhost:5000
Accept: application/json
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/1.0.2
""") == """\
GET / HTTP/1.1
Accept: application/json
Accept: */*
Connection: keep-alive
Host: localhost:5000
User-Agent: HTTPie/1.0.2
"""


# Generated at 2022-06-11 23:50:07.932015
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case-insensitive alphabetical sort of HTTP headers by name.
    assert HeadersFormatter().format_headers(
        '''\
GET / HTTP/1.1
Connection: keep-alive
content-Length: 0
Content-Type: text/plain
Accept: */*
foo: bar
'''
    ) == '''\
GET / HTTP/1.1
Accept: */*
Connection: keep-alive
Content-Type: text/plain
content-Length: 0
foo: bar
'''

    # Should retain relative order of multiple headers with the same name.

# Generated at 2022-06-11 23:50:16.488314
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_string = 'HTTP/1.1 200 OK\r\n' \
                     'Content-Type: application/json\r\n' \
                     'Server: gunicorn/19.9.0\r\n' \
                     'Date: Mon, 30 Sep 2019 12:05:58 GMT\r\n' \
                     'Content-Length: 513\r\n' \
                     'Connection: close\r\n' \
                     'X-Powered-By: Flask\r\n' \
                     'Access-Control-Allow-Origin: *\r\n' \
                     '\r\n'

# Generated at 2022-06-11 23:50:26.603724
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    tmp_kwargs = {}
    tmp_kwargs['format_options'] = {}
    tmp_kwargs['format_options']['headers'] = {}
    tmp_kwargs['format_options']['headers']['sort'] = True
    HeadersFormatter_instance = HeadersFormatter(**tmp_kwargs)
    output = HeadersFormatter_instance.format_headers(
"""HTTP/1.1 200 OK
Connection: keep-alive
Content-Type: application/json
Vary: Accept-Encoding
Content-Encoding: gzip
Transfer-Encoding: chunked
Date: Sat, 02 Jul 2016 23:25:53 GMT

""")

# Generated at 2022-06-11 23:50:29.603139
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(parse_options=ParseOptions(), format_options=FormatOptions())
    assert h is not None

# Unit tests for format_headers

# Generated at 2022-06-11 23:50:40.634726
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    out = formatter.format_headers('HTTP/1.1 200 OK\r\n'
                                  'Content-Type: application/json\r\n'
                                  'Cache-Control: no-cache\r\n'
                                  'Cache-Control: must-revalidate\r\n'
                                  'Date: Fri, 01 Dec 2017 15:17:29 GMT\r\n'
                                  'Server: gunicorn/19.9.0\r\n'
                                  'Connection: keep-alive\r\n'
                                  'X-Frame-Options: SAMEORIGIN\r\n'
                                  'Content-Length: 2\r\n'
                                  '\r\n'
                                  '{}')

# Generated at 2022-06-11 23:50:51.664574
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Example headers from curl's user manual.
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed
'''

    lines = headers.splitlines()
    headers = sorted(lines[1:], key=lambda h: h.split(':')[0])
    expected = '\r\n'.join(lines[:1] + headers)

    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-11 23:50:54.782069
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('Header1: Value1\r\nHeader2: Value2\r\nHeader3: Value3\r\n') == 'Header1: Value1\r\nHeader3: Value3\r\nHeader2: Value2\r\n'



# Generated at 2022-06-11 23:50:57.920711
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\n'.join(['GET http://test.test/ HTTP/1.1', 'a: b', 'B: a', 'd: c'])) == '\r\n'.join(['GET http://test.test/ HTTP/1.1', 'B: a', 'a: b', 'd: c'])

# Generated at 2022-06-11 23:51:07.290543
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_string = """POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 11
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.9
X-Amzn-Trace-Id: Root=1-5f22aa59-b0cf30816f8dfe9057e726a6


foo=bar&baz=qux
        """

# Generated at 2022-06-11 23:51:16.274600
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=dict())
    formatter.enabled = True
    formatter.format_options['headers']['sort'] = True
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nAccept: application/json\r\nConnection: close\r\nServer: TornadoServer/4.2\r\n') == 'HTTP/1.1 200 OK\r\nAccept: application/json\r\nConnection: close\r\nContent-Type: text/html\r\nServer: TornadoServer/4.2\r\n'


headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:51:26.234917
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-11 23:51:28.775480
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers('Foo: bar\nBaz: qux\nFoo: fuz') == 'Foo: bar\nFoo: fuz\nBaz: qux'


# Generated at 2022-06-11 23:51:38.816891
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "GET / HTTP/1.1\r\nHost: example.com\r\n" \
        "User-Agent: httpie/dev\r\nAccept-Encoding: gzip, deflate\r\n" \
        "Accept: */*\r\nConnection: keep-alive\r\n"
    assert formatter.format_headers(headers) == \
        "GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\n" \
        "Connection: keep-alive\r\nHost: example.com\r\n" \
        "User-Agent: httpie/dev\r\n"

# Generated at 2022-06-11 23:51:44.929266
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f: HeadersFormatter = HeadersFormatter()

    inputHeaders = """Content-Encoding: gzip
Accept-Ranges: bytes
Vary: Accept-Encoding
Keep-Alive: timeout=5
Connection: Keep-Alive
Content-Type: text/html"""

    expectedOutputHeaders = """Content-Encoding: gzip
Content-Type: text/html
Accept-Ranges: bytes
Vary: Accept-Encoding
Keep-Alive: timeout=5
Connection: Keep-Alive"""

    outputHeaders = f.format_headers(inputHeaders)
    assert expectedOutputHeaders == outputHeaders

# Generated at 2022-06-11 23:51:50.052106
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_headers = '''\
a: 1
b: 2
c: 3'''
    expected_headers = '''\
a: 1
c: 3
b: 2'''
    observed_headers = formatter.format_headers(input_headers)
    assert expected_headers == observed_headers

# Generated at 2022-06-11 23:52:05.740254
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:52:13.756646
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    test_HeadersFormatter_format_headers
    """
    headers_string = '''\
HTTP/1.1 200 OK
Server: Apache/2.4.7 (Ubuntu)
Date: Thu, 30 Mar 2017 17:25:59 GMT
Content-Type: text/html;charset=utf-8
Connection: keep-alive
Content-Length: 235

'''
    headers_string_sorted = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 235
Content-Type: text/html;charset=utf-8
Date: Thu, 30 Mar 2017 17:25:59 GMT
Server: Apache/2.4.7 (Ubuntu)

'''

    headers_formatter = HeadersFormatter()
    headers_sorted = headers_formatter

# Generated at 2022-06-11 23:52:23.808755
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = "\r\n".join([
        "HTTP/1.1 200 OK",
        "Content-type: text/html",
        "WWW-Authenticate: Basic",
        "Content-Length: 100",
        "Server: App Server 1.0",
        "WWW-Authenticate: Digest",
        "Link: </theaters/12>; rel='collection'",
        "WWW-Authenticate: Token",
        "Vary: Accept-Encoding",
    ])


# Generated at 2022-06-11 23:52:34.644552
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Server: nginx\r\n' \
              'Set-Cookie: foo=bar; Path=/\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Content-Length: 4\r\n' \
              'Connection: keep-alive\r\n' \
              'Set-Cookie: baz=qux; Path=/\r\n' \
              '\r\n' \
              'true'
    sorted_headers = formatter.format_headers(headers)

# Generated at 2022-06-11 23:52:38.642893
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    data = "A: foo\r\nB: bar\r\nB: baz\r\nA: qux\r\n"
    formatter = HeadersFormatter()
    assert formatter.format_headers(data) == 'A: foo\r\nA: qux\r\nB: bar\r\nB: baz\r\n'

# Generated at 2022-06-11 23:52:42.640362
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter.format_headers("""\
Content-Type: application/json
Authorization: Basic d2VudHdvcnRobWFuOkNhbmFkYSB3b3JsZCE=
Content-Length: 46
""")
    assert remove_whitespace(headers) == """\
Content-Length: 46
Authorization: Basic d2VudHdvcnRobWFuOkNhbmFkYSB3b3JsZCE=
Content-Type: application/json
"""



# Generated at 2022-06-11 23:52:47.794726
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # httpie.plugins.formatter.HeadersFormatter().format_headers("First line\nHeader1: value 1\nHeader2: value 2\nHeader1: value 3\n")
    # ('First line\r\nHeader1: value 1\r\nHeader1: value 3\r\n'
    #  'Header2: value 2\r\n')

    test_header = "First line\nHeader1: value 1\nHeader2: value 2\nHeader1: value 3\n"
    assert "First line\r\nHeader1: value 1\r\nHeader1: value 3\r\nHeader2: value 2\r\n" == httpie.plugins.formatter.HeadersFormatter().format_headers(test_header)
    # assert "First line\r\nHeader1: value 1\

# Generated at 2022-06-11 23:52:57.076119
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
POST /post HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 11
Content-Type: application/json
X-Custom-Header: 42

'''
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.format_headers(headers) ==
'''
POST /post HTTP/1.1
Content-Length: 11
Content-Type: application/json
X-Custom-Header: 42
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org

''')



# Generated at 2022-06-11 23:53:07.377601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_headers = HeadersFormatter(format_options= {'headers': {'sort': True, 'align': True}, 'body': {'colors': True, 'indent': True}})
    returned_headers = formatter_headers.format_headers("GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nUser-Agent: HTTPie/1.0.0\r\n\r\n")

# Generated at 2022-06-11 23:53:10.756520
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = """\
Connection: close
Host: www.google.de
Content-Length: 1

"""
    msg = f.format_headers(headers)
    assert msg == """\
Connection: close
Content-Length: 1
Host: www.google.de

"""
# End of test_HeadersFormatter_format_headers()



# Generated at 2022-06-11 23:53:26.930222
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers("""HTTP/1.1 404 NOT FOUND
Content-Type: application/json
Content-Language: en-US
Content-Language: fr
Date: Mon, 01 Jul 2019 01:01:01 GMT
Server: WSGIServer/0.2 CPython/3.6.8
Content-Length: 9

body message""")
    assert headers == """HTTP/1.1 404 NOT FOUND
Content-Language: en-US
Content-Language: fr
Content-Length: 9
Content-Type: application/json
Date: Mon, 01 Jul 2019 01:01:01 GMT
Server: WSGIServer/0.2 CPython/3.6.8

body message"""

# Generated at 2022-06-11 23:53:33.996506
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 40
Content-Type: application/x-www-form-urlencoded
'''
    _headers = '''\
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 40
Content-Type: application/x-www-form-urlencoded
'''
    assert _headers == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-11 23:53:39.862803
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test for method HeadersFormatter.format_headers.
    """
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """\
HTTP/1.1 200 OK
X-Frame-Options: SAMEORIGIN
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Content-Type: text/html; charset=utf-8
Location: http://localhost:5000/secure
Content-Length: 0
Date: Tue, 04 Jul 2017 16:22:12 GMT

"""

# Generated at 2022-06-11 23:53:47.719041
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET /test HTTP/1.1
Accept: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
'''
    expected_headers = '''\
GET /test HTTP/1.1
Accept: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-11 23:53:50.933581
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert \
        HeadersFormatter().format_headers('') == ''
    assert \
        HeadersFormatter().format_headers(textwrap.dedent("""\
            hello: one
            foo: two
            zed: three
            """)) == textwrap.d

# Generated at 2022-06-11 23:54:00.136042
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter()

    result = formatter_plugin.format_headers("""\
HTTP/1.1 200 OK
Cache-Control: private
Content-Length: 16
Content-Type: application/json; charset=utf-8
Server: Microsoft-IIS/10.0
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Fri, 09 Sep 2016 02:26:33 GMT
Content-Length: 2

""")

# Generated at 2022-06-11 23:54:08.562850
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # setup
    headers = """PUT / HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Length: 11
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: httpbin.org
User-Agent: HTTPie/1.0.0


"""
    # exercise
    headers1 = HeadersFormatter().format_headers(headers)
    # verify
    print(headers1)
    lines1 = headers1.splitlines()
    headers2 = sorted(lines1[1:], key=lambda h: h.split(':')[0])
    assert lines1[:1] == lines1[:1]
    assert headers2 == headers2

# Generated at 2022-06-11 23:54:17.004426
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test data
    sample = """\
        POST /post HTTP/2
        HOST: www.example.com
        Content-Type: application/json; charset=utf-8
        Content-Length: 18
        User-Agent: httpie/2.1.0
        Accept-Encoding: gzip, deflate
        Accept: */*
        Connection: keep-alive\
    """

    # Expected outcome
    expected = """\
        POST /post HTTP/2
        Accept: */*
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        Content-Length: 18
        Content-Type: application/json; charset=utf-8
        HOST: www.example.com
        User-Agent: httpie/2.1.0\
    """

    # Instantiate the class

# Generated at 2022-06-11 23:54:25.211056
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True, show_all=False)))
    out = formatter.format_headers("""\
HTTP/1.1 200 OK
X-Foo: 3
X-Bar: 1
X-Bar: 2
Content-Type: text/html
""")
    assert 'X-Bar' in out
    assert 'X-Foo' in out
    assert 'Content-Type' in out
    assert out.index('X-Bar') < out.index('X-Foo')
    assert out.index('X-Foo') < out.index('Content-Type')
    assert out.index('X-Bar: 1') < out.index('X-Bar: 2')



# Generated at 2022-06-11 23:54:31.631227
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers('Host: example.com\r\nAccept: */*\r\nContent-Length: 1000\r\nAccept-Encoding: gzip, deflate\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: python-httpie') == 'Host: example.com\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nContent-Length: 1000\r\nContent-Type: application/x-www-form-urlencoded\r\nUser-Agent: python-httpie'


# Generated at 2022-06-11 23:54:47.552766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers = (
        'Authorization: Basic c2VyZW46Q2xhc3MjMDAw\r\n'
        'Proxy-Connection: keep-alive\r\n'
        'Connection: keep-alive\r\n'
        'Accept: */*\r\n'
        'User-Agent: HTTPie/0.11.0-dev\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Host: httpbin.org\r\n'
        '\r\n'
    )


# Generated at 2022-06-11 23:54:53.662879
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

# Generated at 2022-06-11 23:54:58.495321
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers, expected = (
        """\
Accept: application/json, */*
User-Agent: HTTPie/0.11.1
Accept-Encoding: gzip, deflate
Content-Type: application/json
User-Agent: MyHTTPie/0.0.1
Content-Length: 59
Host: localhost:3000
Connection: keep-alive
"""
        """\
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Content-Length: 59
Content-Type: application/json
Connection: keep-alive
Host: localhost:3000
User-Agent: HTTPie/0.11.1
User-Agent: MyHTTPie/0.0.1
""")
    fmt = HeadersFormatter()
    assert fmt.format_headers(headers) == expected

# Generated at 2022-06-11 23:55:06.539342
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter()
    headers_str = '''\
HTTP/1.1 200 OK
Content-Length: 334
Content-Type: application/octet-stream
Connection: close
Date: Sun, 19 May 2019 00:12:59 GMT
Server: Test-Python
X-Test-Header: test1

b'Hello World!'
'''
    expected_str = '''\
HTTP/1.1 200 OK
Content-Length: 334
Content-Type: application/octet-stream
Connection: close
Date: Sun, 19 May 2019 00:12:59 GMT
Server: Test-Python
X-Test-Header: test1

b'Hello World!'
'''
    actual_str = formatter_plugin.format_headers(headers_str)
    assert actual_str == expected_str

# Unit test

# Generated at 2022-06-11 23:55:12.422637
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header = '''\
HTTP/1.1 200 OK
Date: Fri, 02 Aug 2013 23:53:36 GMT
Content-Type: application/json
Content-Length: 2

{}'''
    assert HeadersFormatter().format_headers(header) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Date: Fri, 02 Aug 2013 23:53:36 GMT

{}'''


# Generated at 2022-06-11 23:55:20.900591
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter({})
    if not headers_formatter.enabled:
        raise Exception("HeadersFormatter is not enabled!")
    fmt_headers = headers_formatter.format_headers("""\
HTTP/1.1 200 OK
Server: example.com
Connection: close
X-Powered-By: PHP/1.0
Set-Cookie: session=abcd;
Content-Type: text/html; charset=UTF-8""")
    assert fmt_headers == """\
HTTP/1.1 200 OK
Content-Type: text/html; charset=UTF-8
Connection: close
Set-Cookie: session=abcd;
Server: example.com
X-Powered-By: PHP/1.0
""", fmt_headers
    # This test only works with enabled sorting

# Generated at 2022-06-11 23:55:26.128265
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    line = 'Content-Type: application/json\n'
    line = line + 'Access-Control-Allow-Origin: *'
    headers = HeadersFormatter(sources=['file'],
                               format_options={
                                   'headers': {
                                       'sort': True
                                   }
                               })
    res = headers.format_headers(line)
    expected = 'Access-Control-Allow-Origin: *\r\nContent-Type: application/json'
    assert res == expected

# Generated at 2022-06-11 23:55:32.535033
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
Content-Length: 159
Content-Type: text/plain; charset=utf-8
Cache-Control: max-age=0
Connection: keep-alive
Content-Encoding: gzip'''
    assert formatter.format_headers(headers) == '''\
Content-Type: text/plain; charset=utf-8
Content-Length: 159
Content-Encoding: gzip
Connection: keep-alive
Cache-Control: max-age=0'''

# Generated at 2022-06-11 23:55:39.178105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = test_headers
    output = fmt.format_headers(headers)
    expected_output = '\r\n'.join(
        ['HTTP/1.1 200 OK',
         'content-length: 10',
         'content-type: text/plain',
         'date: Sun, 12 Aug 2018 12:20:56 GMT',
         'server: TwistedWeb/17.9.0',
         'x-frame-options: SAMEORIGIN',
         'x-xss-protection: 1; mode=block',
         'Connection: close'])
    assert output == expected_output

# Generated at 2022-06-11 23:55:49.333687
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Given: I create an instance of class HeadersFormatter
    f = HeadersFormatter(sort=True)

    # When: I set attribute enabled to True, I set attribute format_options to
    # a dictionary with key headers, whose value is a dictionary with key sort,
    # whose value is False
    f.enabled = True
    f.format_options['headers'] = {'sort': False}

    # Then: I expect the attribute enabled to be False
    assert f.enabled == False

    # When: I set attribute enabled to True, I set attribute format_options to
    # a dictionary with key headers, whose value is a dictionary with key sort,
    # whose value is False
    f.enabled = True
    f.format_options['headers'] = {'sort': True}

    # Then: I expect the attribute enabled to be True
   

# Generated at 2022-06-11 23:56:07.807464
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Length: 14
Content-Type: application/json
Set-Cookie: foo=bar; Path=/; Domain=example.org
Cache-Control: private; max-age=0
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: private; max-age=0
Content-Length: 14
Content-Type: application/json
Set-Cookie: foo=bar; Path=/; Domain=example.org
"""
    assert hf.format_headers(headers) == expected



# Generated at 2022-06-11 23:56:15.933771
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # instantiate headers_formatter
    headers_formatter = HeadersFormatter()

    # create a string with unsorted headers
    unsorted_headers = '''
    HTTP/1.1 200 OK
    Date: Fri, 05 Jan 2018 16:47:46 GMT
    Content-Length: 2
    Content-Type: application/json
    Server: ExampleHTTP
    '''
    # create a string with sorted headers
    sorted_headers = '''
    HTTP/1.1 200 OK
    Content-Length: 2
    Content-Type: application/json
    Date: Fri, 05 Jan 2018 16:47:46 GMT
    Server: ExampleHTTP
    '''

    # test format_headers
    assert sorted_headers == headers_formatter.format_headers(unsorted_headers)

# Generated at 2022-06-11 23:56:23.701604
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  # Input, Output
  test_cases = [
    ["""\r
Content-Type: application/json
Authorization: Bearer token1
Cache-Control: no-cache
Content-Type: application/json
Cache-Control: no-cache
Authorization: Bearer token2
X-Custom-Header: right
X-Custom-Header: left\r
""",
    """\r
Content-Type: application/json
Authorization: Bearer token1
Cache-Control: no-cache
Content-Type: application/json
Cache-Control: no-cache
Authorization: Bearer token2
X-Custom-Header: right
X-Custom-Header: left\r
"""],
  ]

  for i,o in test_cases:
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:56:28.562968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create an instance of HeadersFormatter
    headers_formatter = HeadersFormatter()
    # Define input and output data
    input_data = '''\
Content-Type: application/json
X-Foo: Bar
X-Baz: bazinga
'''
    expected_output_data = '''\
Content-Type: application/json
X-Baz: bazinga
X-Foo: Bar
'''
    # Call method format_headers of class HeadersFormatter with input data
    actual_output_data = headers_formatter.format_headers(input_data)
    # Assert expected output and actual output are equal
    assert expected_output_data == actual_output_data

# Generated at 2022-06-11 23:56:33.862501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    out = h.format_headers("""\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 2
Connection: close
Cache-Control: no-cache

""")

    assert out == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: close
Content-Length: 2
Content-Type: text/html; charset=utf-8

"""

# Generated at 2022-06-11 23:56:42.617520
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print("=" * 50, '\nRunning  unit test for method format_headers of class HeadersFormatter')
    headers = """
    HTTP/1.0 200 OK
    Date: Tue, 13 Dec 2016 15:36:43 GMT
    Server: WSGIServer/0.2 CPython/3.5.2
    X-Frame-Options: SAMEORIGIN
    Content-Type: application/json
    Allow: GET, HEAD, POST
"""
    headers_sorted = """
    HTTP/1.0 200 OK
    Allow: GET, HEAD, POST
    Content-Type: application/json
    Date: Tue, 13 Dec 2016 15:36:43 GMT
    Server: WSGIServer/0.2 CPython/3.5.2
    X-Frame-Options: SAMEORIGIN
"""

# Generated at 2022-06-11 23:56:46.363403
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        headers='''\
GET /get HTTP/1.1
Cookie: a=1; b=2
User-Agent: httpie
Cookie: c=3
''') == '''\
GET /get HTTP/1.1
Cookie: a=1; b=2
Cookie: c=3
User-Agent: httpie'''

# Generated at 2022-06-11 23:56:55.942679
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "GET / HTTP/1.1\r\n" \
            + "Host: docs.python.org\r\n" \
            + "Accept: text/html,application/xhtml+xml,application/xml;" \
            + "q=0.9,image/webp,*/*;q=0.8\r\n" \
            + "Accept-Encoding: gzip,deflate,sdch\r\n" \
            + "Accept-Language: en-US,en;q=0.8\r\n" \
            + "User-Agent: Mozilla/5.0 (Macintosh) " \
            + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 " \
            + "Safari/537.36\r\n"

# Generated at 2022-06-11 23:57:03.341604
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\
POST /post HTTP/1.1
User-Agent: httpie
Content-Length: 21
Content-Type: application/x-www-form-urlencoded

key=value+more+val%21ues
""".replace('\n', '\r\n')
    headers_formatted = headers_formatter.format_headers(headers)
    assert headers_formatted == """\
POST /post HTTP/1.1
User-Agent: httpie
Content-Length: 21
Content-Type: application/x-www-form-urlencoded

key=value+more+val%21ues
""".replace('\n', '\r\n')
    headers_formatted = headers_formatter.format_headers(headers_formatted)
    assert headers_

# Generated at 2022-06-11 23:57:12.027825
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nSet-Cookie:' \
              ' id=1; Expires=Thu, 01 Jan 1970 00:00:00 GMT\r\nSet-Cookie: name=test\r\n' \
              'User-Agent: httpie/1.0.2\r\nContent-Length: 3\r\n'

# Generated at 2022-06-11 23:57:31.291775
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:57:41.943163
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    from httpie.formatter import HeadersFormatter
    from httpie.plugins import FormatterPlugin

    class TestFormatter(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True

    output = 'line1\n\tContent-Type: image/jpeg\nline2\n\tContent-Type: text/plain'

    formatter_obj = HeadersFormatter(format_options={'headers': {'sort': True}},
                                     formatter=TestFormatter())
    output_sorted = formatter_obj.format_headers(output)

    assert output_sorted == 'line1\n\tContent-Type: image/jpeg\nline2\n\tContent-Type: text/plain'

# Generated at 2022-06-11 23:57:47.928203
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    result = HeadersFormatter().format_headers(
        headers="""\
HTTP/1.1 200 OK
Content-Length: 4
Date: Mon, 23 May 2005 22:38:34 GMT
ETag: "1000000000000000-10000000-4953b2f65fe2f"
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT

Test
""")
    assert result == """\
HTTP/1.1 200 OK
Content-Length: 4
Date: Mon, 23 May 2005 22:38:34 GMT
ETag: "1000000000000000-10000000-4953b2f65fe2f"
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT

Test
""", 'HeadersFormatter method format_headers failed!'



# Generated at 2022-06-11 23:57:57.628415
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_original = """\
HTTP/1.1 200 OK
Date: Wed, 08 Apr 2020 03:45:59 GMT
Server: Apache/2.4.38 (Debian)
Last-Modified: Wed, 08 Apr 2020 03:45:58 GMT
Etag: "5e8db94c-15"
Accept-Ranges: bytes
Content-Length: 21
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=UTF-8

"""

# Generated at 2022-06-11 23:58:04.942554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # No sorting needed
    headers = """Content-Type: application/json
Content-Length: 445

{"id":"abcdefgh","jsonrpc":"2.0","method":"getblock","params":["00000000000005b12ffd4cd315cd34ffd4a594f430ac814c91184a0d42d2b0fe"]}
"""
    assert formatter.format_headers(headers) == headers

    # Sorting needed

# Generated at 2022-06-11 23:58:10.011374
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter
    """
    # The line below is a workaround for an issue that occurs in Python 3.6
    # An issue has been reported at
    # https://github.com/requests/httpie/issues/380
    httpie_version = '0.9.6'

    # Create an instance of class HeadersFormatter
    headers_formatter = HeadersFormatter(None, {}, '', httpie_version, True)

    # The line below is a workaround for an issue that occurs in Python 3.6
    # An issue has been reported at
    # https://github.com/requests/httpie/issues/380
    assert headers_formatter.enabled
