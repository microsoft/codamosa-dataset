

# Generated at 2022-06-11 23:48:16.136801
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    reformatted_headers = formatter.format_headers(
        'Content-Type: application/json\r\n'
        'Date: Sun, 26 Jul 2020 13:20:39 GMT\r\n'
        'ETag: "5f4f4a2e-2b6a"\r\n'
        'Link: </>; rel="home"\r\n'
        'Link: </lists>; rel="lists"\r\n'
        'Server: gunicorn/19.9.0\r\n'
        'Vary: Accept\r\n'
        'X-Custom-Header: 123\r\n'
    )


# Generated at 2022-06-11 23:48:24.584533
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers="""GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Host: httpbin.org
User-Agent: HTTPie/0.9.9
X-Request-ID: asdf
X-Request-ID: bbbb
X-Request-ID: cccc"""
    #X-Request-ID is not a header (I assume), but it works in this case because it is the first three lines in the headers.txt file
    assert HeadersFormatter().get_line_formatter()(headers) == headers.splitlines()[0] + '\r\n' + \
                                                                 '\r\n'.join(sorted(headers.splitlines()[1:]))

# Generated at 2022-06-11 23:48:33.038322
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = ('Content-Length: 20\r\n'
               'Content-Type: application/json\r\n'
               'Cache-Control: max-age=3600\r\n'
               '\r\n'
               '{}')
    # Before
    resp = Response({'headers': headers, 'url': 'http://example.com/'})
    assert(resp.headers.splitlines() == ['Content-Length: 20',
                                         'Content-Type: application/json',
                                         'Cache-Control: max-age=3600',
                                         '',
                                         '{}'])
    # After
    resp_formatted = h.transform_response(resp)

# Generated at 2022-06-11 23:48:42.986728
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    assert headers_formatter.enabled


# Generated at 2022-06-11 23:48:49.299158
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = _test_content1 = (
        b'Content-Type: application/json\r\n'
        b'Dnt: 1\r\n'
        b'Expires: -1\r\n'
        b'Strict-Transport-Security: max-age=31536000; includeSubDomains; '
        b'preload\r\n'
        b'User-Agent: httpie/1.0.2\r\n'
        b'X-Frame-Options: SAMEORIGIN\r\n'
        b'X-XSS-Protection: 1; mode=block\r\n'
    )

# Generated at 2022-06-11 23:48:56.168183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # setup
    formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    headers = ("""Content-Type: application/json\r
Header_Access: yes\r
Header_Access: no\r
Header_Access: Never""")
    # exercise
    sorted_headers = formatter.format_headers(headers)
    # verify
    expected_headers = ("""Content-Type: application/json\r
Header_Access: yes\r
Header_Access: no\r
Header_Access: Never""")
    assert sorted_headers == expected_headers


# Generated at 2022-06-11 23:49:07.198320
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers_formatter = HeadersFormatter()
    headers = """
HTTP/1.1 404 Not Found
Content-Type: application/json; charset=utf-8
Vary: Accept-Language
Content-Language: en
ETag: W/"5b120d5d5e9f939b48ee5cbe28c6b119"
Date: Fri, 07 Feb 2020 23:44:52 GMT
Connection: keep-alive
Content-Length: 189"""

# Generated at 2022-06-11 23:49:09.775368
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__name__ == 'HeadersFormatter'
    from httpie.plugins import FormatterPlugin
    assert issubclass(HeadersFormatter, FormatterPlugin)


# Generated at 2022-06-11 23:49:19.198770
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'B: b\r\nA: a\r\nC: c\r\nD: d\r\nB: bb\r\nB: bbb\r\nA: aa\r\n'
    assert f.format_headers(headers) == 'HTTP/1.1 200 OK\r\n' \
                                        'A: a\r\nA: aa\r\nB: b\r\nB: bb\r\n' \
                                        'B: bbb\r\nC: c\r\nD: d\r\n'

# Generated at 2022-06-11 23:49:24.190270
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert s.format_headers('Content-Type: application/json; charset=utf-8\r\nContent-Length: 18\r\n') == 'Content-Type: application/json; charset=utf-8\r\nContent-Length: 18\r\n'


# Generated at 2022-06-11 23:49:27.947462
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter([]).enabled == True

# Generated at 2022-06-11 23:49:30.391148
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == True
    assert headers_formatter.enabled == True



# Generated at 2022-06-11 23:49:40.805957
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:49:51.305959
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    string = '''POST /post HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 31
Content-Type: application/x-www-form-urlencoded

bar=foo&foo=bar'''
    assert HeadersFormatter(string).format_headers(string) == '''POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 31
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org

bar=foo&foo=bar'''

# Generated at 2022-06-11 23:49:56.982859
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    input_headers = """GET / HTTP/1.1
User-Agent: python-requests/2.12.4
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Host: github.com"""
    formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert formatter.enabled == True
    assert formatter.format_headers(input_headers) == """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: github.com
User-Agent: python-requests/2.12.4"""

test_HeadersFormatter()

# Generated at 2022-06-11 23:50:05.410098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""\
POST /post HTTP/1.1
User-Agent: HTTPie/0.9.9
Content-Type: application/json
Connection: keep-alive
Accept-Encoding: gzip, deflate, compress
Accept: */*
Content-Length: 18
Host: httpbin.org""") == \
        """\
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9"""


# Generated at 2022-06-11 23:50:08.308470
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.format_options['headers']['sort'] == True
    assert headers_formatter.enabled == True


# Generated at 2022-06-11 23:50:16.752647
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:50:26.603596
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.4.4
Date: Wed, 19 Sep 2012 15:28:14 GMT
Content-Type: application/json;charset=UTF-8
Connection: keep-alive
X-RateLimit-Remaining: 59
X-RateLimit-Limit: 60
X-RateLimit-Reset: 1348238892
Content-Length: 80
'''

# Generated at 2022-06-11 23:50:28.955253
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()
    assert type(HeadersFormatter()) == HeadersFormatter



# Generated at 2022-06-11 23:50:42.802741
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:44.602714
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-11 23:50:53.274978
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    
    headers_formatter = HeadersFormatter()

    # Test initialization
    assert isinstance(headers_formatter, HeadersFormatter)
    assert isinstance(headers_formatter, FormatterPlugin)
    assert headers_formatter.enabled is False
    assert headers_formatter.format_options['headers']['sort'] is False
    
    # Test format_headers()

# Generated at 2022-06-11 23:50:59.089146
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:51:08.227543
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:51:18.854851
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter.

    """
    h = HeadersFormatter()
    test_data = """\
HTTP/1.1 200 OK
Date: Wed, 29 Jul 2020 21:35:33 GMT
Server: Python/3.7 aiohttp/3.6.2
content-length: 0
Content-Type: application/json; charset=utf-8
"""
    if h.enabled:
        expected = """\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Date: Wed, 29 Jul 2020 21:35:33 GMT
Server: Python/3.7 aiohttp/3.6.2
content-length: 0
"""
        result = h.format_headers(test_data)
        assert result == expected

# Generated at 2022-06-11 23:51:27.304269
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
Date: Mon, 12 Mar 2018 13:08:31 GMT
X-Some-Header: One
X-Some-Header: Two
X-Some-Header: Three
"""
    sorted_headers = """\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
Date: Mon, 12 Mar 2018 13:08:31 GMT
X-Some-Header: One
X-Some-Header: Two
X-Some-Header: Three
"""
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers) == sorted_headers

# Generated at 2022-06-11 23:51:33.537369
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    method = 'test_method'
    url = 'https://www.website.com/page1'

# Generated at 2022-06-11 23:51:43.667392
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Prepare a HeadersFormatter instance for testing method format_headers
    content_type = 'application/json'
    user_agent = 'HTTPie/0.9.5'
    accept_encoding = 'gzip, deflate'
    accept = 'application/json, */*'
    conn_headers = {'Accept': accept, 'Accept-Encoding': accept_encoding,
                    'Content-Type': content_type, 'User-Agent': user_agent}
    headers_with_order = '\r\n'.join(['HTTP/1.1 200 OK', 'Content-Type: ' + content_type,
                                      'User-Agent: ' + user_agent, 'Accept: ' + accept,
                                      'Accept-Encoding: ' + accept_encoding])
    headers_without_order = '\r\n'.join

# Generated at 2022-06-11 23:51:51.553654
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
http://docs.python-requests.org

Cookie: foo=bar
Cookie: bar=baz
Content-Type: application/json
Accept-Encoding: gzip, compress
Accept: */*
User-Agent: HTTPie/0.9.2
'''

    assert HeadersFormatter().format_headers(headers) == '''\
http://docs.python-requests.org

Accept: */*
Accept-Encoding: gzip, compress
Cookie: foo=bar
Cookie: bar=baz
Content-Type: application/json
User-Agent: HTTPie/0.9.2
'''.rstrip()


# Generated at 2022-06-11 23:52:02.933931
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Foo: X
Content-Type: application/json
Foo: Y
Content-Length: 5"""
    expected = """HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
Foo: X
Foo: Y"""
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-11 23:52:11.728360
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    F = HeadersFormatter()
    headers = """
    Content-Type: application/json
    Content-Length: 3572
    Authorization: Basic Ym9iOmJhcg==
    X-Custom-Header-1: 1
    X-Custom-Header-2: 222
    X-Custom-Header-3: 3333
    X-Custom-Header-1: 44444
    """

    expected = """
    Content-Type: application/json
    Content-Length: 3572
    X-Custom-Header-1: 1
    X-Custom-Header-1: 44444
    X-Custom-Header-2: 222
    X-Custom-Header-3: 3333
    Authorization: Basic Ym9iOmJhcg==
    """

    assert F.format_headers(headers) == expected

# Generated at 2022-06-11 23:52:20.007022
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nUser-Agent: HTTPie\r\nAccept: */*\r\nContent-Length: 29\r\nContent-Type: application/json\r\n\r\n{\"test\": \"this is a test\"}"
    result = hf.format_headers(headers)
    expected = "HTTP/1.1 200 OK\r\nAccept: */*\r\nContent-Length: 29\r\nContent-Type: application/json\r\nUser-Agent: HTTPie\r\n\r\n{\"test\": \"this is a test\"}"
    assert expected == result

# Generated at 2022-06-11 23:52:26.378478
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    formatter = HeadersFormatter()
    input_headers = """HTTP/1.1 200 OK
B: 2
A: 1
B: 1
C: 3
    """

    output_headers = """HTTP/1.1 200 OK
A: 1
B: 2
B: 1
C: 3
    """
    # Act
    result = formatter.format_headers(input_headers)

    # Assert
    assert result == output_headers

# Generated at 2022-06-11 23:52:34.826552
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    from httpie.compat import str

    headers = (
        'Content-Type: application/json\r\n'
        'Connection: close\r\n'
        'ETag: "6805f2f457e98b5bdfa1c892ddbd8457"\r\n'
        'Server: TornadoServer/5.1.1\r\n'
        'Date: Sat, 08 Dec 2018 02:58:23 GMT\r\n'
        'Content-Length: 18\r\n\r\n'
    )
    assert str(headers) == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-11 23:52:41.988697
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.__init__()
    assert HeadersFormatter.format_headers('')
    assert HeadersFormatter.format_headers('\r\n')
    assert HeadersFormatter.format_headers('\r\n\r\n')

# Generated at 2022-06-11 23:52:52.012752
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert (hf.format_headers("""HTTP/1.1 200 OK
Vary: Authorization
Content-Type: application/json
Allow: GET, HEAD, OPTIONS
Accept-Ranges: bytes
Content-Length: 2
Date: Tue, 04 Feb 2020 11:22:29 GMT

""") == """HTTP/1.1 200 OK
Accept-Ranges: bytes
Allow: GET, HEAD, OPTIONS
Content-Length: 2
Content-Type: application/json
Date: Tue, 04 Feb 2020 11:22:29 GMT
Vary: Authorization

""")

# Generated at 2022-06-11 23:52:52.922967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-11 23:53:03.593431
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers("Content-Type: application/json\r\nContent-Length: 18\r\n") == "Content-Type: application/json\r\nContent-Length: 18\r\n"
    assert hf.format_headers("Content-Length: 18\r\nContent-Type: application/json\r\n") == "Content-Type: application/json\r\nContent-Length: 18\r\n"

    assert hf.format_headers("Content-Type: application/json\r\nContent-Length: 18\r\nHost: httpbin.org\r\n") == "Content-Type: application/json\r\nContent-Length: 18\r\nHost: httpbin.org\r\n"
    assert hf.format_

# Generated at 2022-06-11 23:53:05.469703
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        HeadersFormatter()
    except:
        assert False


# Generated at 2022-06-11 23:53:26.726724
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class Request(object):
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Host': 'httpbin.org',
            'User-Agent': 'HTTPie'
        }
    headers = 'Accept: application/json\r\nContent-Type: application/json\r\nHost: httpbin.org\r\nUser-Agent: HTTPie'
    assert HeadersFormatter().format_headers(headers) == '\r\n'.join(['Accept: application/json', 'Content-Type: application/json', 'Host: httpbin.org', 'User-Agent: HTTPie'])



# Generated at 2022-06-11 23:53:29.352706
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    f = HeadersFormatter()
    assert f.format_options['headers']['sort'] is False
    assert f.enabled is False


# Generated at 2022-06-11 23:53:33.314021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "Authorization: Basic 123\r\nCredentials: 123\r\nAuthorization: Basic 456"
    result = HeadersFormatter().format_headers(headers)
    assert result == "Authorization: Basic 123\r\nAuthorization: Basic 456\r\nCredentials: 123"

# Generated at 2022-06-11 23:53:36.100186
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    try:
        http('--print=H')
    except SystemExit as e:
        assert e.code == ExitStatus.OK
    else:
        assert HTTP_OK

# Generated at 2022-06-11 23:53:47.056403
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-11 23:53:51.154276
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:53:58.756201
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': True}}
    headers = headers_formatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Name: def\r\n'
        'Name: abc\r\n'
        'Name: ghj\r\n')
    assert headers == (
        'HTTP/1.1 200 OK\r\n'
        'Name: def\r\n'
        'Name: abc\r\n'
        'Name: ghj\r\n')

# Generated at 2022-06-11 23:54:07.910717
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import datetime as date
    test = HeadersFormatter(format_options={}, color_options={})
    test.format_options['headers']['sort'] = True
    test.format_options['headers']['case'] = False

# Generated at 2022-06-11 23:54:13.962256
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter(format_options =
        {'headers': {'sort': True}})

    # valid headers example, with HTTP/2.0

# Generated at 2022-06-11 23:54:21.192075
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:54:44.415174
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test sorting of headers
    assert HeadersFormatter().format_headers("""
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 138
Connection: keep-alive
Server: tornado-web Server
Date: Tue, 19 May 2020 16:35:20 GMT

{"type": "success", "value": {"id": 234, "quote": "It's a wonderful world"}}
""".lstrip()) == """
HTTP/1.1 200 OK
Content-Length: 138
Connection: keep-alive
Content-Type: application/json; charset=utf-8
Date: Tue, 19 May 2020 16:35:20 GMT
Server: tornado-web Server

{"type": "success", "value": {"id": 234, "quote": "It's a wonderful world"}}
""".l

# Generated at 2022-06-11 23:54:50.248664
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    header_input = """
        HTTP/1.1 200 OK
        foo: bar
        baz: qux
        foo: quux
        """
    header_output = """
        HTTP/1.1 200 OK
        baz: qux
        foo: bar
        foo: quux
        """
    assert formatter.format_headers(header_input) == header_output


# Generated at 2022-06-11 23:54:59.590486
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test format_headers() in class HeadersFormatter().
    """
    headers_formatter = HeadersFormatter(None)
    test_headers = '''\
Connection: keep-alive
Content-type: application/json
Cache-Control: no-cache
X-Custom-Header: abc
Content-Length: 13
X-Custom-Header: def
User-Agent: httpie/0.9.0
'''
    result = headers_formatter.format_headers(test_headers)
    headers = result.splitlines()
    assert headers[0] == 'Connection: keep-alive'
    assert headers[1] == 'Cache-Control: no-cache'
    assert headers[2] == 'Content-type: application/json'
    assert headers[3] == 'Content-Length: 13'
    assert headers

# Generated at 2022-06-11 23:55:05.965950
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    fmt = HeadersFormatter(None, None)
    input_headers = """\
Host: localhost:8000
Connection: keep-alive
User-Agent: HTTPie/0.9.2
Accept: */*
X-Custom: 42
X-Custom: 43
"""
    expected_headers = """\
Host: localhost:8000
Connection: keep-alive
User-Agent: HTTPie/0.9.2
Accept: */*
X-Custom: 42
X-Custom: 43
"""

    # Execute
    actual_headers = fmt.format_headers(input_headers)

    # Verify
    assert actual_headers == expected_headers


# Generated at 2022-06-11 23:55:14.909431
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # sort headers
    headers = """\
    GET / HTTP/1.1
    Accept-Encoding: gzip, deflate
    User-Agent: HTTPie/0.9.2
    Accept: */*
    Host: www.google.com
    """
    expected_output = """\
    GET / HTTP/1.1
    Accept: */*
    Accept-Encoding: gzip, deflate
    Host: www.google.com
    User-Agent: HTTPie/0.9.2
    """
    output = formatter.format_headers(headers)
    assert output == expected_output

    # don't sort headers
    formatter.enabled = False
    output = formatter.format_headers(headers)
    assert output == headers

# Generated at 2022-06-11 23:55:22.942429
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = formatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Authorization: Basic Zm9vOmJhcg==\r\n'
        'Content-Length: 18\r\n'
    )
    assert headers == (
        'HTTP/1.1 200 OK\r\n'
        'Authorization: Basic Zm9vOmJhcg==\r\n'
        'Content-Length: 18\r\n'
        'Content-Type: application/json\r\n'
    )


# Generated at 2022-06-11 23:55:27.527662
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # desired output
    expected_output = "arg1: content 1\r\narg2: content 2\r\narg3: content 3\r\n"
    # given output
    given_output = "arg2: content 2\r\narg3: content 3\r\narg1: content 1\r\n"
    # initialize class
    headers_formatter = HeadersFormatter()
    # test output
    assert headers_formatter.format_headers(given_output) == expected_output



# Generated at 2022-06-11 23:55:36.757441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:55:39.733133
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    httpie = TestApp(headers=[('Accept', 'application/json'),
                               ('Accept', 'application/xml')])
    r = httpie.get('/headers')
    assert r.text == 'application/json'
    r = httpie.get('/headers',
                   headers=[('Accept', 'text/html'),
                           ('Accept', 'text/plain')])
    assert r.text == 'text/html'




# Generated at 2022-06-11 23:55:46.920475
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers' : {'sort' : True}})
    headers = '''GET / HTTP/1.1
Host: localhost:8000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive'''
    expected = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8000'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-11 23:56:16.176935
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    The method format_headers sorts the response headers alphabetically by name and then by value,
    while retaining the relative order of multiple headers with the same name and value.

    """

    # Create a list of headers to be tested in the format of pairs of tuples.
    # Each tuple contains a test case and the expected result of the method.
    # The list of test headers is sorted alphabetically by name and by value.

# Generated at 2022-06-11 23:56:19.448006
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print("\nTesting method format_headers of class HeadersFormatter")
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:56:26.021888
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_input = '''POST / HTTP/1.1
Host: example.com
Connection: keep-alive
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15
Accept-Language: de-de
Accept-Encoding: gzip, deflate'''

# Generated at 2022-06-11 23:56:35.372288
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    hs = 'header-c: value-c\r\nheader-a: value-a\r\nheader-b: value-b\r\n'
    hs = hf.format_headers(hs)
    assert hs == 'header-a: value-a\r\nheader-b: value-b\r\nheader-c: value-c\r\n'
    hs = 'header-b: value-b-2\r\nheader-c: value-c\r\nheader-a: value-a\r\nheader-b: value-b-1\r\n'
    hs = hf.format_headers(hs)

# Generated at 2022-06-11 23:56:43.897132
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = "GET http://127.0.0.1:8000/ HTTP/1.1\r\n" +\
            "content-type: text/html; charset=utf-8\r\n" +\
            "server: Werkzeug/0.16.0 Python/3.8.5\r\n" +\
            "date: Sat, 29 Aug 2020 18:34:46 GMT\r\n" +\
            "connection: close\r\n" +\
            "content-length: 11\r\n\r\n" +\
            "Hello World!"

    headers_formatter = HeadersFormatter()
    headers_formatter.enabled = True
    formatted_headers = headers_formatter.format_headers(lines)
    assert lines != formatted_headers

# Generated at 2022-06-11 23:56:51.692932
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
    HTTP/1.1 200 OK
    Content-Type: application/json; charset=utf-8
    Content-Length: 19
    Server: Werkzeug/0.14.1 Python/3.8.1
    Date: Mon, 25 Nov 2019 20:41:13 GMT
    """
    assert formatter.format_headers(headers.strip()) == """
    HTTP/1.1 200 OK
    Content-Length: 19
    Content-Type: application/json; charset=utf-8
    Date: Mon, 25 Nov 2019 20:41:13 GMT
    Server: Werkzeug/0.14.1 Python/3.8.1
    """.strip()



# Generated at 2022-06-11 23:56:59.608929
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(None) is None
    assert HeadersFormatter().format_headers('') == ''
    assert HeadersFormatter().format_headers('\r\n') == '\r\n'

    result = HeadersFormatter().format_headers('GET / HTTP/1.1\r\n'
                                               'B: 2\r\n'
                                               'A: 1\r\n'
                                               'A: foo\r\n'
                                               'C: 3')
    expected = 'GET / HTTP/1.1\r\n' \
               'A: 1\r\n' \
               'A: foo\r\n' \
               'B: 2\r\n' \
               'C: 3'
    assert result == expected

# Generated at 2022-06-11 23:57:08.200836
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:57:10.231010
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fh = HeadersFormatter()
    headers_rows = 'Connection: keep-alive\r\n' \
                   'Content-Length: 0\r\n' \
         

# Generated at 2022-06-11 23:57:14.319612
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = '''\
Host: localhost:8000
Cookie: 42
Cookie: 43
Content-Type: text/plain; charset=utf-8
Content-Length: 13
User-Agent: HTTPie
'''
    assert fmt.format_headers(headers) == '''\
Host: localhost:8000
Cookie: 42
Cookie: 43
Content-Length: 13
Content-Type: text/plain; charset=utf-8
User-Agent: HTTPie
'''



# Generated at 2022-06-11 23:57:45.534881
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Should return a string containing formatted headers.
    """
    hf = HeadersFormatter()
    headers = '''\
GET /somepath HTTP/1.1
Content-type: application/json
User-Agent: httpie/0.9.8
Host: www.google.com
Content-Length: 32
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Cache-Control: no-cache
'''

# Generated at 2022-06-11 23:57:55.413429
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:58:02.931565
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 228
Content-Type: application/json
Host: localhost:8000
User-Agent: HTTPie/1.0.0
Version: HTTP/1.1
Accept: application/json
Content-Length: 228
"""
    result = formatter.format_headers(headers)
    print("'" + result + "'")