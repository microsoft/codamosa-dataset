

# Generated at 2022-06-11 23:48:13.668548
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    hf = HeadersFormatter()

    # Tests multiple headers with the same name
    raw_req_headers = """GET /1 HTTP/1.1
Accept: */*
User-Agent: HTTPie
User-Agent: Python
"""
    req_headers = hf.format_headers(raw_req_headers)
    assert raw_req_headers == req_headers



# Generated at 2022-06-11 23:48:22.142467
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    F = HeadersFormatter()
    headers = F.format_headers(
        b'Content-Type: application/json\r\n'
        b'X-Header: Value\r\n'
        b'X-Header: Another\r\n'
        b'Accept: */*\r\n'
        b'User-Agent: HTTPie/1.0\r\n'
        b'Content-Length: 9\r\n'
    )

# Generated at 2022-06-11 23:48:30.358720
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Case 1
    formatter = HeadersFormatter(None, None, None)
    assert formatter.enabled == True
    assert formatter.format_options == {
        'headers': {
            'sort': True
        }
    }

    # Case 2
    formatter = HeadersFormatter(None, None, formatter_options={'headers': {'sort': False}})
    assert formatter.enabled == False
    assert formatter.format_options == {
        'headers': {
            'sort': False
        }
    }

"""
Class to test the method format_headers in plugin class HeaderFormatter.
"""

# Generated at 2022-06-11 23:48:31.616294
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__


# Generated at 2022-06-11 23:48:41.119066
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    A test case can be executed by calling the test method.
    """
    hf = HeadersFormatter()
    hf.format_options = {
        'headers': {
            'sort': True
        }
    }
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nDate: Sun, 24 Jun 2018 11:44:44 GMT\r\nServer: Apache\r\nCache-Control: max-age=0\r\nConnection: close\r\nContent-Language: en\r\nContent-Length: 225\r\nExpires: Sun, 24 Jun 2018 11:44:44 GMT\r\nVary: Accept-Encoding\r\n\r\n"

# Generated at 2022-06-11 23:48:41.756420
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-11 23:48:42.605932
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled is False


# Generated at 2022-06-11 23:48:49.193553
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    instance = HeadersFormatter()

# Generated at 2022-06-11 23:48:50.183584
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Generated at 2022-06-11 23:48:51.978947
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-11 23:49:04.114212
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = """\
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/0.9.2
Accept: */*
Transfer-Encoding: chunked
Host: httpbin.org
X-Amzn-Trace-Id: Root=1-5e7f6a4d-c53d6b9f6a735de1b26f84da
Content-Length: 9

"""

# Generated at 2022-06-11 23:49:13.011112
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()
    headers = """
        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate, br
        Accept-Language: en-US,en;q=0.9
        Connection: keep-alive
        User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6)
        """

    sorted_headers_text = """
        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate, br
        Accept-Language: en-US,en;
        Connection: keep-alive
        User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6)
        """
    sorted_headers = formatter.format_headers(headers)

   

# Generated at 2022-06-11 23:49:23.553666
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    # given
    headers = '''\
HTTP/1.1 200 OK
Content-Encoding: gzip
Cache-Control: private
Content-Type: text/html; charset=utf-8
Content-Length: 1070
Date: Mon, 10 Aug 2020 08:40:29 GMT
Set-Cookie: ARRAffinity=73741e8f1e7f9d3211f33c4316cfb8d1cba6a4174c2a2eba75e3a7e9303d9587;Path=/;HttpOnly;Domain=github.com
'''

    # when
    sorted_headers = headers_formatter.format_headers(headers)

    #

# Generated at 2022-06-11 23:49:29.525496
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'GET / HTTP/1.1\r\nContent-Length: 123\r\n' \
              'Accept: application/json\r\nContent-Type: application/json\r\n'
    result = 'GET / HTTP/1.1\r\nAccept: application/json\r\n' \
             'Content-Length: 123\r\nContent-Type: application/json\r\n'
    assert formatter.format_headers(headers) == result
# <end>

# Generated at 2022-06-11 23:49:30.318012
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ""


# Generated at 2022-06-11 23:49:33.533017
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert formatter.format_options['headers']['sort'] == False



# Generated at 2022-06-11 23:49:42.298212
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import builtin
    builtin.plugins.__all__.extend(['headers_formatter'])
    builtin.plugins.__all__.remove('format')
    builtin.plugins.__all__.remove('pretty')
    builtin.plugins.__all__.remove('colors')
    builtin.plugins.__all__.remove('format_options')
    builtin.plugins.headers_formatter = HeadersFormatter()
    builtin.plugins.format_options = FormatterPlugin()
    headers = '''HTTP/1.0 200 OK
Server: Fake-Server/1.0
Header-A: a
Header-B: b
Header-C: c
'''
    assert builtin.plugins.headers_formatter.format_headers(headers) == headers
    # noinspection PyUnres

# Generated at 2022-06-11 23:49:48.825513
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert (formatter.format_headers("""GET / HTTP/1.1
Host: example.org
B: 2
A: 1
B: 2
""") == """GET / HTTP/1.1
A: 1
B: 2
B: 2
Host: example.org
""")


if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-11 23:49:55.091723
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers':{'sort':True}}, color_options={})
    actual = f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\nLocation: /redirect\r\n\r\n')
    expected = 'HTTP/1.1 200 OK\r\nConnection: Keep-Alive\r\nContent-Type: application/json\r\nLocation: /redirect\r\n\r\n'
    assert actual == expected, 'Method format_headers of class headersFormatter failed.'

# Generated at 2022-06-11 23:49:58.851607
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    assert headers.format_headers('\r\n'.join(['', 'b:1', 'a:2'])) == '\r\n'.join(['','a:2','b:1'])

# Generated at 2022-06-11 23:50:03.496801
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h_f = HeadersFormatter()
    assert isinstance(h_f,HeadersFormatter)


# Generated at 2022-06-11 23:50:04.846066
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hdrf = HeadersFormatter()
    assert hdrf.format_options['headers']['sort'] == True



# Generated at 2022-06-11 23:50:11.114709
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdrs = r"""POST / HTTP/1.1
Content-Length: 12
Content-Type: application/x-www-form-urlencoded
set-cookie: csrftoken=d; expires=Wed, 20 Feb 2019 08:37:51 GMT; Max-Age=31449600; Path=/
set-cookie: sessionid=e; expires=Wed, 24 May 2017 08:37:51 GMT; httponly; Max-Age=1209600; Path=/

X-Request-Start: 1527142816071
X-Request-Id: 9
X-Runtime: 0.038539
X-Pages: 1
"""

# Generated at 2022-06-11 23:50:12.959851
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    item = HeadersFormatter()
    assert isinstance(item, HeadersFormatter)



# Generated at 2022-06-11 23:50:14.726536
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter(**{})
    assert obj.format_options['headers']['sort'] == False


# Generated at 2022-06-11 23:50:23.868523
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = str(Headers([
        ('Content-Type', 'text/plain'),
        ('Content-Length', '1'),
        ('Connection', 'close'),
        ('Content-Encoding', 'gzip'),
        ('Content-Encoding', 'compress'),
    ]))
    expected_headers = str(Headers([
        ('Content-Encoding', 'gzip'),
        ('Content-Encoding', 'compress'),
        ('Content-Length', '1'),
        ('Content-Type', 'text/plain'),
        ('Connection', 'close'),
    ]))
    output = formatter.format_headers(headers)
    assert output == expected_headers

# Generated at 2022-06-11 23:50:28.752698
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    F = HeadersFormatter()
    assert F is not None
    output = F.format_headers("""Accept: */*
Content-Length: 23
Host: example.com
""")
    assert output == '\r\n'.join([
        "Accept: */*",
        "Host: example.com",
        "Content-Length: 23"
    ])

# Generated at 2022-06-11 23:50:30.092916
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-11 23:50:41.240485
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:44.674198
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:50:52.754233
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options == {'headers': {'sort': True}}

# Unit test on method format_headers

# Generated at 2022-06-11 23:50:58.600517
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.14.0 (Ubuntu)
Date: Tue, 24 Jul 2018 07:52:48 GMT
Content-Type: application/json
Content-Length: 119
Connection: keep-alive

{"error": "Mock error"}'''
    test_headers = '''HTTP/1.1 200 OK
Date: Tue, 24 Jul 2018 07:52:48 GMT
Content-Length: 119
Content-Type: application/json
Connection: keep-alive
Server: nginx/1.14.0 (Ubuntu)

{"error": "Mock error"}'''
    assert hf.format_headers(headers=headers) == test_headers


headers = HeadersFormatter()

# Generated at 2022-06-11 23:51:07.854651
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_fragments = ["Date: Thu, 14 Apr 2016 04:20:57 GMT",
                "Server: Apache/2.4.3 (Win32) OpenSSL/1.0.1c PHP/5.4.7",
                "Expires: Thu, 19 Nov 1981 08:52:00 GMT",
                "X-Powered-By: PHP/5.4.7",
                "Content-Length: 15",
                "Content-Type: text/html"]

    # Sort headers
    input_headers = "\r\n".join(header_fragments)
    expected_headers = "\r\n".join(sorted(header_fragments, key=lambda h: h.split(':')[0]))
    # Order headers
    formatter = HeadersFormatter()
    actual_headers = formatter.format_headers

# Generated at 2022-06-11 23:51:16.134616
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.0.0
"""
    expected_headers = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/0.0.0
"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-11 23:51:16.714183
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-11 23:51:22.519325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 Okay
Content-Type: application/json
Content-Length: 123
Set-Cookie: test
Set-Cookie: foo
'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 Okay
Content-Length: 123
Content-Type: application/json
Set-Cookie: test
Set-Cookie: foo
'''

# Generated at 2022-06-11 23:51:30.772171
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    This is a unit test for method format_headers of class HeadersFormatter.
    It ensures that when sorting headers, their relative order is retained.
    """

# Generated at 2022-06-11 23:51:42.464796
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter().format_headers(
        """
        HTTP/1.1 200 OK
        Date: Tue, 14 May 2019 02:18:22 GMT
        Server: Apache/2.4.25 (Debian)
        Last-Modified: Thu, 09 May 2019 13:45:30 GMT
        Etag: "6f-58aadb8a4c4c0"
        Accept-Ranges: bytes
        Content-Length: 111
        Vary: Accept-Encoding
        Keep-Alive: timeout=5, max=100
        Connection: Keep-Alive
        Content-Type: text/html

        """
    )

# Generated at 2022-06-11 23:51:44.543607
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    unit = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert type(unit) == HeadersFormatter


# Generated at 2022-06-11 23:51:48.423079
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        assert (
            HeadersFormatter(
                format_options={'headers': {'sort': True}}).enabled
        )
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-11 23:52:10.267722
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Dummy HTTP request / response headers
    headers = """\
Host: localhost:5000
Content-Type: application/json
Accept: application/json, */*
Authorization: Basic cGxhbjpxd2VydHk=
X-Request-ID: aaae25e8-0e0d-4319-a7f5-8c3955805dc9
X-Trace-Request-ID: ad5a735f-cb1d-499e-a2b5-7daad9c511aa
X-Trace-Server-Name: localhost.localdomain
Content-Length: 13
Connection: keep-alive
User-Agent: HTTPie/2.2.0
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.9
"""

# Generated at 2022-06-11 23:52:16.173246
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()


# Generated at 2022-06-11 23:52:24.362498
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers(HeadersFormatter(), '''\
'Host': 'httpbin.org'
'Content-Type': 'text/plain'
'Content-Length': '16'
'User-Agent': 'HTTPie/1.0.2'
'Accept-Encoding': 'gzip, deflate'
''') == '''\
'Host': 'httpbin.org'
'User-Agent': 'HTTPie/1.0.2'
'Accept-Encoding': 'gzip, deflate'
'Content-Length': '16'
'Content-Type': 'text/plain'
'''

# Generated at 2022-06-11 23:52:35.153943
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    line1 = 'Accept:application/json'
    line2 = 'Content-Type:application/json'
    line3 = 'Accept-Encoding:gzip, deflate'
    line4 = 'Accept-Language:en-US,en;q=0.5'
    line5 = 'Connection:close'
    line6 = 'Content-Length:25'
    line7 = 'Host:127.0.0.1:5000'
    line8 = 'Referer:http://127.0.0.1:5000/'
    line9 = 'User-Agent:Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0'

# Generated at 2022-06-11 23:52:41.465708
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_lines = ['GET / HTTP/1.1',
    'Accept-Encoding: gzip, deflate',
    'Accept: */*',
    'Accept: application/json',
    'User-Agent: HTTPie/2.2.0',
    'Host: 127.0.0.1:8000',
    'Connection: keep-alive']

    headers = '\r\n'.join(headers_lines)

    formatter = HeadersFormatter()

    headers = formatter.format_headers(headers)


# Generated at 2022-06-11 23:52:44.209203
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test format_headers()
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('foo:bar\nbaz:qux') == 'foo:bar\nbaz:qux'

# Generated at 2022-06-11 23:52:54.635434
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_original = ('HTTP/1.1 200 OK\r\n'
                        'Connection: keep-alive\r\n'
                        'Content-Encoding: gzip\r\n'
                        'Content-Length: 48\r\n'
                        'Content-Type: application/json; charset=utf-8\r\n'
                        'Date: Mon, 25 Jul 2016 13:18:19 GMT')

# Generated at 2022-06-11 23:53:04.688388
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = 'HTTP/1.1 200 OK\r\nAccept: application/json\r\nCache-Control: no-cache\r\nHost: www.example.com\r\nContent-Type: application/json\r\n\r\n'
    print(hf.format_headers(headers))
    headers = 'HTTP/1.1 200 OK\r\nHost: www.example.com\r\nAccept: application/json\r\nCache-Control: no-cache\r\nContent-Type: application/json\r\n\r\n'
    print(hf.format_headers(headers))


plugin_manager.register(HeadersFormatter)

# Generated at 2022-06-11 23:53:08.822631
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(stdout=stdout_mock, stderr=stderr_mock, format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True
    assert headers_formatter.stdout == stdout_mock
    assert headers_formatter.stderr == stderr_mock


# Generated at 2022-06-11 23:53:12.682284
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 160
Content-Type: text/plain
Date: Mon, 09 Jun 2014 09:45:46 GMT
Server: python

Hello, world!
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 160
Content-Type: text/plain
Date: Mon, 09 Jun 2014 09:45:46 GMT
Server: python

Hello, world!
'''
    actual = formatter.format_headers(headers)
    assert expected == actual

# Generated at 2022-06-11 23:53:43.511602
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nAccept: text/plain\r\nContent-Type: application/json\r\nAccept: application/json\r\nUser-Agent: HTTPie/2.2.0') == 'GET / HTTP/1.1\r\nAccept: text/plain\r\nAccept: application/json\r\nContent-Type: application/json\r\nUser-Agent: HTTPie/2.2.0'

# Generated at 2022-06-11 23:53:52.190095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "HTTP/1.0 200 OK\r\n" \
              "Date: Fri, 31 Dec 1999 23:59:59 GMT\r\n" \
              "Content-Type: text/plain\r\n" \
              "Content-Length: 9\r\n" \
              "X-Foo: Bar\r\n" \
              "X-Foo: Baz\r\n" \
              "\r\n"

# Generated at 2022-06-11 23:54:01.338160
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test1: standard HTTP header format name:value
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 6
Cookie: _gauges_unique=1; _gauges_unique_year=1
Host: httpbin.org
User-Agent: HTTPie/0.9.8
'''
    expected_headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 6
Cookie: _gauges_unique=1; _gauges_unique_year=1
Host: httpbin.org
User-Agent: HTTPie/0.9.8
'''

# Generated at 2022-06-11 23:54:10.183510
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    #f = HeadersFormatter()
    print(HeadersFormatter.format_headers(":method: GET"))

test_HeadersFormatter_format_headers()

import requests

#r1 = requests.get('http://httpbin.org/headers', ':method: GET')
#print(HeadersFormatter.format_headers(r1.text))
#print(r1.text)
#s = requests.Session()
#s.headers = {'Accept': 'text/plain', 'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3'}
#s.headers = {':method': 'GET', 'User-Agent': 'HTTPie/0.9.9', 'Accept-Encoding': 'gzip, deflate', 'Accept': '

# Generated at 2022-06-11 23:54:18.447186
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(resolve_headers=True)
    head = 'HTTP/1.1 201 CREATED\r\n'
    body = '''
        Content-Type: application/json; charset=UTF-8
        Content-Length: 725
        Vary: Accept-Language, Cookie
        Content-Language: en
        X-Frame-Options: SAMEORIGIN
        Date: Mon, 16 Jan 2017 23:43:14 GMT
        Server: GSE
        Cache-Control: private, max-age=0, must-revalidate, no-transform
        Strict-Transport-Security: max-age=31536000
        Expires: Mon, 16 Jan 2017 23:43:14 GMT
    '''
    expected_body = body[1:]

# Generated at 2022-06-11 23:54:24.295093
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n' \
              'Content-Type: text/html; charset=utf-8\r\n' \
              'Content-Length: 1\r\nOther: foo\r\n' \
              'Content-Length: 3\r\n\r\n'

    formatted_headers = formatter.format_headers(headers)

# Generated at 2022-06-11 23:54:32.058486
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

# Generated at 2022-06-11 23:54:39.096475
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.6.0
Date: Wed, 01 Jun 2016 20:41:40 GMT
Content-Type: application/json; charset=UTF-8
Content-Length: 10
Connection: keep-alive
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: https://app.example.org
Strict-Transport-Security: max-age=15768000

'''
    formatter.format_headers(headers)

# Generated at 2022-06-11 23:54:48.363469
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json; charset=utf-8',
        'Server: TornadoServer/4.2.1',
        'Date: Sun, 29 Nov 2015 03:39:35 GMT',
        'Content-Length: 16',
        '',
        'Hello World!'
    ])
    expected = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Length: 16',
        'Content-Type: application/json; charset=utf-8',
        'Date: Sun, 29 Nov 2015 03:39:35 GMT',
        'Server: TornadoServer/4.2.1',
        '',
        'Hello World!'
    ])
   

# Generated at 2022-06-11 23:54:53.756389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: github.com
User-Agent: curl/7.54.0
Accept: */*
Cache-Control: no-cache
Postman-Token: 3e2b121d-8fde-4a48-b7cd-f0d84891398f
'''
    e_result = '''\
Host: github.com
Accept: */*
Cache-Control: no-cache
Postman-Token: 3e2b121d-8fde-4a48-b7cd-f0d84891398f
User-Agent: curl/7.54.0
'''
    assert HeadersFormatter().format_headers(headers) == e_result


# Generated at 2022-06-11 23:55:46.785306
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    p = HeadersFormatter()

    headers_unsorted = """\
Accept: text/html
Foo: bar
Baz: qux
Foo: baz
""".lstrip()

    headers_sorted = """\
Accept: text/html
Baz: qux
Foo: bar
Foo: baz
""".lstrip()

    assert p.format_headers(headers_unsorted) == headers_sorted



# Generated at 2022-06-11 23:55:53.732845
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = [
        'POST / HTTP/1.1',
        'Host: https://httpie.org',
        'Cookie: foo=bar',
        'Connection: keep-alive',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Upgrade-Insecure-Requests: 1',
        'User-Agent: HTTPie/1.0.3',
        'Cookie: bar=foo',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: en-US,en;q=0.5',
    ]

# Generated at 2022-06-11 23:56:01.527100
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers = HeadersFormatter()

# Generated at 2022-06-11 23:56:05.057976
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create a headers formatter
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    # Check it is enabled
    assert hf.enabled==True


# Generated at 2022-06-11 23:56:09.901555
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Vary: Accept-Language, Cookie
Content-Language: ru
Date: Mon, 30 Oct 2017 10:41:50 GMT
Server: Google Frontend
Alt-Svc: quic=":443"; ma=2592000; v="41,39,38,37,35"
Expires: Mon, 30 Oct 2017 10:41:47 GMT
Cache-Control: private
X-XSS-Protection: 1; mode=block
X-Frame-Options: SAMEORIGIN
Set-Cookie: NID=123=abc; expires=Tue, 30-Apr-2019 10:41:50 GMT; path=/; domain=.google.com; HttpOnly
Content-Encoding: gzip
"""

# Generated at 2022-06-11 23:56:14.095268
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Content-Type: text/html
Content-Length: 1054
X-XSS-Protection: 1; mode=block'''

    assert '''Content-Type: text/html
X-XSS-Protection: 1; mode=block
Content-Length: 1054''' == HeadersFormatter().format_headers(headers)



# Generated at 2022-06-11 23:56:22.269823
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Check that method format_headers sorts headers by name"""
    formatter = HeadersFormatter()
    headers = '''Connection:keep-alive
Content-Length:1314
Set-Cookie:key2=value; Path=/; HttpOnly; key1=value; Domain=.example.com
Content-Type:application/json; charset=utf-8
Cache-Control:private, max-age=0, proxy-revalidate, no-store, no-cache, must-revalidate
Date:Sun, 20 May 2018 17:46:39 GMT
Server:nginx'''.strip()

# Generated at 2022-06-11 23:56:23.971352
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-11 23:56:33.223749
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test with a single header
    headers = "POST / HTTP/1.1\r\n" + "Accept: whatever\r\n"
    assert(HeadersFormatter().format_headers(headers) == headers)

    # Test with multiple headers, some with the same name
    headers = "POST / HTTP/1.1\r\n" + "Accept: whatever\r\n"
    headers += "Content-Length: 324\r\n" + "Accept-Encoding: *\r\n"
    headers += "Accept-Charset: *\r\n" + "Accept-Encoding: gzip"
    headers = "POST / HTTP/1.1\r\n" + "Accept: whatever\r\n"

# Generated at 2022-06-11 23:56:41.972826
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Date: Fri, 12 Feb 2016 12:47:01 GMT
Server: Apache/2.2.16 (Debian)
Last-Modified: Fri, 12 Feb 2016 10:25:57 GMT
Etag: "145526f-a25-52c0cddb8f980"
Accept-Ranges: bytes
Content-Length: 2609
Connection: close
Content-Type: text/html'''