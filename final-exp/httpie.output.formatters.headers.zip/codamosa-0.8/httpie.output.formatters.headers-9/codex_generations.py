

# Generated at 2022-06-11 23:48:16.887256
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h1 = '''
        POST / HTTP/1.1
        Accept: application/json
        X-Extra-Header: 123
        Foo: bar
        Foo: baz
        Content-Type: application/json
    '''

    h2 = '''
        POST / HTTP/1.1
        Accept: application/json
        Content-Type: application/json
        Foo: bar
        Foo: baz
        X-Extra-Header: 123
    '''

    hf = HeadersFormatter()
    assert h1 == h2
    assert hf.format_headers(h1) == h2



# Generated at 2022-06-11 23:48:21.243949
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = """\
Accept: application/json
Content-Type: application/json
X-Auth-Token: 123
X-Auth-Token: 456
X-Auth-Token: 789"""
    assert fmt.format_headers(headers) == """\
Accept: application/json
Content-Type: application/json
X-Auth-Token: 123
X-Auth-Token: 456
X-Auth-Token: 789"""

# Generated at 2022-06-11 23:48:30.240173
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 22\r\n\r\n"
    assert hf.format_headers(headers) == "HTTP/1.1 200 OK\r\nContent-Length: 22\r\nContent-Type: application/json\r\n\r\n"
    headers = "HTTP/1.1 200 OK\r\nContent-Length: 22\r\n\r\n"
    assert hf.format_headers(headers) == "HTTP/1.1 200 OK\r\nContent-Length: 22\r\n\r\n"



# Generated at 2022-06-11 23:48:34.014999
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert headers.enabled == False
    assert headers.format_options['headers']['sort'] == False
    assert headers.format_options['headers']['prefix'] == 'hdr-'



# Generated at 2022-06-11 23:48:43.963836
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Declare and initialize an instance of HeadersFormatter
    headers_formatter = HeadersFormatter()

    # Declare and initialize a dictionary

# Generated at 2022-06-11 23:48:54.103530
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers_in = (
        'GET / HTTP/1.1\r\n'
        'Cache-Control: max-age=0\r\n'
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n'
        'Accept-Language: en-US,en;q=0.5\r\n'
        'Accept-Encoding: gzip, deflate, br\r\n'
        'Accept-Encoding: gzip\r\n'
        'Content-Type: text/html; charset=UTF-8'
    )

# Generated at 2022-06-11 23:49:04.730082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    result = headers_formatter.format_headers('HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nETag: "34aa387-d-1568eb00"\r\nAccept-Ranges: bytes\r\nContent-Length: 51\r\nVary: Accept-Encoding\r\nContent-Type: text/plain\r\nX-Pad: avoid browser bug')

# Generated at 2022-06-11 23:49:12.577848
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Connection: keep-alive
Date: fri, 21 oct 2016 18:39:33 utc
Content-Type: text/html; charset=utf-8
Content-Length: 42
Server: python/3.6 aiohttp/3.1.3
"""
    actual = formatter.format_headers(headers)
    expected = """\
Connection: keep-alive
Content-Length: 42
Content-Type: text/html; charset=utf-8
Date: fri, 21 oct 2016 18:39:33 utc
Server: python/3.6 aiohttp/3.1.3
"""
    assert actual == expected



# Generated at 2022-06-11 23:49:13.736300
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-11 23:49:22.018485
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Visually inspect the output of this test to verify it is sorted.
    """
    plugin_instance = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Expires: -1
Date: Thu, 16 Aug 2018 04:06:29 GMT
Pragma: no-cache
Connection: keep-alive
Content-Length: 0
"""
    result = plugin_instance.format_headers(headers)
    print(result)


# Instance of HeadersFormatter, a plugin, to hook into httpie library
plugin_instance = HeadersFormatter()

# Generated at 2022-06-11 23:49:28.536772
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert fmt.enabled is True
    fmt = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert fmt.enabled is False


# Generated at 2022-06-11 23:49:39.183740
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Date: Sun, 28 May 2017 18:13:11 GMT
Content-Length: 48
Connection: keep-alive
Server: nginx'''
    headers = formatter.format_headers(headers)
    lines = headers.splitlines()
    assert lines[0] == 'HTTP/1.1 200 OK'
    assert lines[1] == 'Content-Length: 48'
    assert lines[2] == 'Content-Type: application/json'
    assert lines[3] == 'Connection: keep-alive'
    assert lines[4] == 'Date: Sun, 28 May 2017 18:13:11 GMT'
    assert lines[5] == 'Server: nginx'


# Generated at 2022-06-11 23:49:49.622618
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Thu, 21 Dec 2017 18:23:46 GMT
Server: Apache
X-Powered-By: PHP/5.4.45-2+deb.sury.org~precise+2
Content-Length: 2
Content-Type: text/html; charset=UTF-8
"""
    sorted_headers = """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: text/html; charset=UTF-8
Date: Thu, 21 Dec 2017 18:23:46 GMT
Server: Apache
X-Powered-By: PHP/5.4.45-2+deb.sury.org~precise+2
"""
    assert sorted_headers == formatter.format_headers(headers)

# Unit

# Generated at 2022-06-11 23:49:55.092166
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9


    """
    result = \
    """GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9


    """
    
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == result


# Generated at 2022-06-11 23:49:59.606221
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}}
    )
    assert formatter.enabled

    formatter = HeadersFormatter(
        format_options={'headers': {'sort': False}}
    )
    assert not formatter.enabled



# Generated at 2022-06-11 23:50:05.789610
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = """\
GET / HTTP/1.1
Accept: */*
Content-Type: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 0"""
    expected = """\
GET / HTTP/1.1
Accept: */*
Content-Type: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 0"""
    actual = HeadersFormatter().format_headers(input)
    assert actual == expected

# Generated at 2022-06-11 23:50:14.920449
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    input_headers = "HTTP/1.1 200 OK\r\n" \
                    "Content-Length: 156\r\n" \
                    "Content-Type: application/json; charset=utf-8\r\n" \
                    "Date: Mon, 22 Apr 2019 21:44:45 GMT\r\n" \
                    "Server: WSGIServer/0.2 CPython/3.7.3\r\n\r\n" \
                    '{"response": "Header sort function testing"}'


# Generated at 2022-06-11 23:50:25.192246
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_headers='Accept-Charset: iso-8859-5, unicode-1-1;q=0.8\r\n'\
                  'Accept-Encoding: compress, gzip\r\n'\
                  'Accept-Charset: utf-8\r\n'\
                  'Accept-Language: en;q=0.5, fr\r\n'\
                  'User-Agent: HTTPie/0.9.2\r\n'\
                  'Content-Length: 4\r\n'\
                  'Content-Type: application/x-www-form-urlencoded\r\n'\
                  'Accept-Language: utf-8\r\n'

# Generated at 2022-06-11 23:50:30.673850
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case: assert that the format method returns expected value.
    # Arguments:
    # - headers: input headers to be formatted.
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
Content-Type: application/json
Something: 1
Something: 2
Something: 3
""") == """\
Content-Type: application/json
Something: 1
Something: 2
Something: 3
"""


# Generated at 2022-06-11 23:50:41.838632
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''HTTP/1.1 200 OK
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 188
Content-Type: application/json; charset=utf-8
Date: Wed, 09 Aug 2017 17:24:31 GMT
ETag: W/"bc-5couIFxHCKdscgkMz0q+tEONJQKQ"
X-Ratelimit-Limit: 60
X-Ratelimit-Remaining: 59
'''

# Generated at 2022-06-11 23:50:47.694337
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Initializes HeadersFormatter
    headers_formatter = HeadersFormatter()

    # Asserts type of headers_formatter
    assert isinstance(headers_formatter, HeadersFormatter)


# Generated at 2022-06-11 23:50:55.219348
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    test_string = 'Content-Type: [application/json]\r\nUser-Agent: [curl/7.35.0]\r\nConnection: [Keep-Alive]\r\nAccept: [*/*]\r\n'
    formatter_string = 'Content-Type: [application/json]\r\nConnection: [Keep-Alive]\r\nAccept: [*/*]\r\nUser-Agent: [curl/7.35.0]\r\n'
    assert formatter.format_headers(test_string) == formatter_string

if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-11 23:51:00.498000
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = '''\
POST / HTTP/1.1
Host: example.org
Authorization: Token AAA
Accept-Encoding: identity
Connection: close

'''
    expected_headers = '''\
POST / HTTP/1.1
Accept-Encoding: identity
Authorization: Token AAA
Connection: close
Host: example.org

'''
    assert formatter.format_headers(headers) == expected_headers


# Generated at 2022-06-11 23:51:04.999456
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nFoo: Two\r\nFoo: One\r\n') == \
        'GET / HTTP/1.1\r\nFoo: One\r\nFoo: Two\r\n'

# Generated at 2022-06-11 23:51:11.384419
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_options == {'headers': {'sort': True}}
    assert HeadersFormatter(format_options={'headers': {'sort': False}}).format_options == {'headers': {'sort': False}}
    assert HeadersFormatter(format_options={}).format_options == {}



# Generated at 2022-06-11 23:51:18.998651
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Length: 21
X-Random-Header: Value
Content-Type: text/html; charset=utf-8
Content-Length: 23
X-Random-Header: Another value
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 21
Content-Length: 23
Content-Type: text/html; charset=utf-8
X-Random-Header: Value
X-Random-Header: Another value
"""
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-11 23:51:26.487032
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.format_headers("") == "")
    assert(headers_formatter.format_headers("foo: bar") == "foo: bar")
    assert(headers_formatter.format_headers("X-Foo: bar\nfoo: bar") == "X-Foo: bar\nfoo: bar")
    assert(headers_formatter.format_headers("foo: bar\nFoo: baz\nfOo: baz") == "fOo: baz\nFoo: baz\nfoo: bar")

# Generated at 2022-06-11 23:51:30.456359
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter
    assert headers_formatter.format_headers(headers_formatter, "ACCEPT: application/json\r\nCONTENT-TYPE: application/json\r\nAUTHORIZATION: bearer token\r\n") == "ACCEPT: application/json\r\nCONTENT-TYPE: application/json\r\nAUTHORIZATION: bearer token"

# Generated at 2022-06-11 23:51:42.102136
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "GET /datatype/ HTTP/1.1\r\nContent-Type: application/json\r\nAccept: application/json\r\nHost: httpbin.org\r\nConnection: keep-alive\r\nAccept-Encoding: gzip\r\nCache-Control: no-cache\r\nUser-Agent: HTTPie/0.9.8\r\nAccept-Language: de,en;q=0.8"
    headersformatter = HeadersFormatter()
    headers = headersformatter.format_headers(headers)

# Generated at 2022-06-11 23:51:47.409556
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    actual = formatter.format_headers(' \r\n a: 1 \r\n A: 2 \r\n b: 3 \r\n c: 4 \r\n')
    expected = ' \r\n a: 1 \r\n A: 2 \r\n b: 3 \r\n c: 4 \r\n'
    assert actual == expected

# Generated at 2022-06-11 23:52:03.222932
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test with header 'Cookie' on top
    actual = HeadersFormatter().format_headers(
        """\
Connection: keep-alive
Host: httpbin.org
Cookie: SessionId=123
Content-Length: 0
Content-Type: application/json
User-Agent: HTTPie/1.0.0-dev"
"""
)
    expected = """\
Connection: keep-alive
Cookie: SessionId=123
Content-Length: 0
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/1.0.0-dev"
"""
    assert actual == expected

    # Test with header 'Cookie' at bottom

# Generated at 2022-06-11 23:52:11.958079
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # arrange
    formatter = HeadersFormatter()
    headers =  '''\
HTTP/1.1 200 OK\r
Server: nginx/1.4.6 (Ubuntu)\r
Content-Type: application/json\r
Vary: Accept-Encoding, Cookie\r
Transfer-Encoding: chunked\r
Allow: GET, HEAD, POST\r
X-Robots-Tag: none\r
X-Content-Type-Options: nosniff\r
Content-Encoding: gzip\r
Date: Sun, 14 Feb 2016 13:55:52 GMT\r
X-Frame-Options: SAMEORIGIN\r
\r
'''
    expected = headers

    # act
    actual = formatter.format_headers(headers)

    # assert
    assert actual == expected

# Generated at 2022-06-11 23:52:17.825331
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Length: 40
Content-Type: application/json
Date: Sat, 09 Sep 2017 01:42:42 GMT
Server: gunicorn/19.7.1
Age: 12
"""
    expected = """\
Content-Length: 40
Content-Type: application/json
Date: Sat, 09 Sep 2017 01:42:42 GMT
Age: 12
Server: gunicorn/19.7.1
"""
    assert HeadersFormatter().format_headers(headers) == expected




# Generated at 2022-06-11 23:52:27.258929
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.core import main
    from httpie import input
    testargs = ['http', '--pretty=all', 'http://localhost:8080/headers',
                'testHeaderName:testHeaderValue', 'testHeaderName:testHeaderValue']
    with mock.patch.object(sys, 'argv', testargs):
        input.init(env=Environment())
        formatter = FormatterPlugin()
        headers_formatter = HeadersFormatter(
            format_options=formatter.format_options,
            config_dir=formatter.config_dir,
            env=formatter.env
        )
        assert headers_formatter.enabled


# Generated at 2022-06-11 23:52:37.299475
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    input_headers = '''HTTP/1.1 200 OK\r
Content-Type: text/html;charset=utf-8\r
Content-Length: 15\r
WWW-Authenticate: Bearer error="invalid_token", error_description="The access token expired"\r
Connection: close\r
\r
'''
    expected_headers = '''HTTP/1.1 200 OK\r
Connection: close\r
Content-Length: 15\r
Content-Type: text/html;charset=utf-8\r
WWW-Authenticate: Bearer error="invalid_token", error_description="The access token expired"\r
\r
'''
    assert hf.format_headers(input_headers) == expected_headers



# Generated at 2022-06-11 23:52:43.737004
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = 'Key1: value1\r\nKey3: value3\r\nKey4: value4\r\nKey2: value2\r\nKey4: value4\r\n'
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.format_headers(s) == 'Key1: value1\r\nKey2: value2\r\nKey3: value3\r\nKey4: value4\r\nKey4: value4\r\n'
    assert hf.format_headers(s) == s


# Generated at 2022-06-11 23:52:53.017848
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    assert formatter.format_headers('\r\nTest: False\r\n') == '\r\nTest: False\r\n'
    assert formatter.format_headers('\r\nX-One: True\r\nX-Two: False\r\n') == '\r\nX-One: True\r\nX-Two: False\r\n'
    assert formatter.format_headers('\r\nCache-Control: max-age=0\r\nAccept: text/html\r\nDate: Tue') == '\r\nAccept: text/html\r\nCache-Control: max-age=0\r\nDate: Tue'



# Generated at 2022-06-11 23:53:03.746579
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    cls = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert cls.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: Close\r\nContent-Length: 12\r\n\r\n') == 'HTTP/1.1 200 OK\r\nConnection: Close\r\nContent-Length: 12\r\nContent-Type: text/html\r\n\r\n'

# Generated at 2022-06-11 23:53:07.147721
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter
    assert FormatterPlugin
    assert FormatterPlugin.enabled
    assert FormatterPlugin.format_options
    assert FormatterPlugin.format_options['headers']
    assert FormatterPlugin.format_options['headers']['sort']


# Generated at 2022-06-11 23:53:08.257505
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    t = HeadersFormatter()
    assert isinstance(t, HeadersFormatter)

# Generated at 2022-06-11 23:53:25.446620
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    _test_HeadersFormatter = HeadersFormatter()
    assert _test_HeadersFormatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nX-Foo: Bar\r\n') == 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nX-Foo: Bar'
    assert _test_HeadersFormatter.format_headers('HTTP/1.1 200 OK\r\nX-Foo: Bar\r\nContent-Type: text/plain\r\n') == 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nX-Foo: Bar'

# Generated at 2022-06-11 23:53:35.166310
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' + '\r\n'.join([
        'Date: Sat, 23 Mar 2019 22:01:20 GMT',
        'Server: Apache',
        'Content-Length: 4718',
        'Vary: Accept-Encoding',
        'Keep-Alive: timeout=2, max=100',
        'Connection: Keep-Alive',
        'Content-Type: text/html; charset=UTF-8',
        'Last-Modified: Sat, 23 Mar 2019 22:00:09 GMT',
    ])
    headers_sorted = formatter.format_headers(headers)

    assert headers_sorted.splitlines()[:1] == headers.splitlines()[:1]

    headers_sorted_lines = headers_

# Generated at 2022-06-11 23:53:46.450261
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = 'HTTP/1.1 200 OK\r\nX-Foo: Lorem\r\nX-Bar: Ipsum\r\n'
    formatted = headers_formatter.format_headers(headers)

    # Check that the headers were sorted
    assert formatted == 'HTTP/1.1 200 OK\r\nX-Bar: Ipsum\r\nX-Foo: Lorem\r\n'

    # Check that relative order of headers with the same key is retained

# Generated at 2022-06-11 23:53:53.848022
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdr = 'GET / HTTP/1.1\r\nContent-Type: text/plain\r\nX-Header: C\r\nX-Header: A\r\nX-Header: B'
    exp1 = 'GET / HTTP/1.1\r\nContent-Type: text/plain\r\nX-Header: A\r\nX-Header: B\r\nX-Header: C'
    exp2 = 'GET / HTTP/1.1\r\nX-Header: B\r\nX-Header: C\r\nContent-Type: text/plain\r\nX-Header: A'

# Generated at 2022-06-11 23:54:03.348302
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """Host: localhost:80
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: sv-SE,sv;q=0.8,en-US;q=0.6,en;q=0.4
"""


# Generated at 2022-06-11 23:54:04.938462
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    inst = HeadersFormatter()
    assert_true(inst.enabled)


# Generated at 2022-06-11 23:54:10.291329
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h1 = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    class Response:
        headers = h1
    class Request:
        pass
    class Session:
        pass
    session = Session()
    request = Request()
    response = Response()
    session.headers = request.headers = response.request.headers = h1
    hf = HeadersFormatter(session=session, request=request, response=response)
    assert hf


# Generated at 2022-06-11 23:54:18.451056
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
            GET / HTTP/1.1
            User-Agent: HTTPie/0.9.6
            accept: */*
            X-some-Header: abc
            Udacity-header: Value1
            Udacity-header: Value2
            Udacity-header: Value3
            Content-Length: 19
            X-Some-Header: def
            Accept-Encoding: gzip, deflate
            Host: httpbin.org
            X-Testing: foo
            '''

# Generated at 2022-06-11 23:54:24.294169
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    """
        # Headers need to be sorted alphabetically
        # for httpie --pretty=format output
    """
    #   1. Single header
    assert headers_formatter.format_headers("""
content-type: text/html; charset=UTF-8
""") == """
content-type: text/html; charset=UTF-8
"""

    #   2. Multiple headers
    assert headers_formatter.format_headers("""
connection: close
content-type: text/html; charset=UTF-8
Host: 127.0.0.1:8000
""") == """
connection: close
content-type: text/html; charset=UTF-8
Host: 127.0.0.1:8000
"""

    #   3. Multiple headers with same name


# Generated at 2022-06-11 23:54:32.059048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    ht = HeadersFormatter({'headers' : {'sort': True}})

# Generated at 2022-06-11 23:54:50.430272
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html
Connection: keep-alive
Content-Length: 25670
Connection: close
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Connection: close
Content-Length: 25670
Content-Type: text/html
'''
    assert headers_formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-11 23:54:58.190613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = """POST / HTTP/1.1
Accept: application/json, */*
Cache-Control: no-cache
Content-Length: 5
Content-Type: application/json
Host: example.org

"""
    actual = """POST / HTTP/1.1
Content-Length: 5
Cache-Control: no-cache
Content-Type: application/json
Host: example.org
Accept: application/json, */*

""".splitlines()
    headers_formatter = HeadersFormatter()
    actual = '\r\n'.join(actual).strip()
    actual = headers_formatter.format_headers(actual)
    assert actual == expected



# Generated at 2022-06-11 23:54:59.640571
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    m = HeadersFormatter()
    assert m.enabled is True


# Generated at 2022-06-11 23:55:07.422832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test with unsorted headers
    data = """HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Thu, 23 Nov 2017 16:42:24 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 399
Connection: keep-alive
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: Content-Type, Accept, X-Requested-With,
    remember-me, Authorization
Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE
Access-Control-Allow-Credentials: true
Allow: POST, OPTIONS
X-Frame-Options: SAMEORIGIN
Vary: Accept-Encoding

<!DOCTYPE html>"""

# Generated at 2022-06-11 23:55:11.702190
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(headers_text) == \
        headers_text_sorted
    # Test for handling headers that do not start w/ header name
    assert HeadersFormatter().format_headers(headers_text2) == \
        headers_text2_sorted



# Generated at 2022-06-11 23:55:20.251262
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert 'headers' not in FormatterPlugin.__dict__
    assert 'headers' not in FormatterPlugin.__dict__['format_options']
    assert 'headers' in HeadersFormatter.__dict__['format_options']
    assert 'sort' in HeadersFormatter.__dict__['format_options']['headers']
    assert 'headers' in HeadersFormatter.__dict__
    assert HeadersFormatter.format_headers
    fh = HeadersFormatter(**{'format_options': {'headers': {'sort': True}}})
    assert fh.enabled
    assert fh.format_headers
    fh = HeadersFormatter(**{'format_options': {'headers': {'sort': False}}})
    assert not fh.enabled
    assert fh.format_headers

# Unit tests for

# Generated at 2022-06-11 23:55:28.312483
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
        Test method format_headers.
    """
    headers = """Connection: close
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.9
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.3
Content-Length: 19
Host: httpbin.org
"""
    assert HeadersFormatter().format_headers(headers) == """Connection: close
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.9
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.3
Content-Length: 19
Host: httpbin.org
""".splitlines()

# Generated at 2022-06-11 23:55:35.767281
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    method = HeadersFormatter().format_headers

    assert method('X: 1\r\nA: 2\r\nB: 3\r\nZ: 4\r\nC: 5') == \
        'X: 1\r\nA: 2\r\nB: 3\r\nC: 5\r\nZ: 4'

    assert method('X: 1\r\nA: 2\r\nA: 3\r\nA: 4') == \
        'X: 1\r\nA: 2\r\nA: 3\r\nA: 4'



# Generated at 2022-06-11 23:55:40.187543
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Arrange
    formatter = HeadersFormatter()
    headers = """\
        HTTPie/0.9.9
        Accept-Encoding: gzip, deflate
        Accept: */*
        User-Agent: HTTPie/0.9.9
        Connection: keep-alive
        """

    # Act
    headers = formatter.format_headers(headers)

    # Assert
    assert headers == """\
        HTTPie/0.9.9
        Accept: */*
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        User-Agent: HTTPie/0.9.9
        """


# Generated at 2022-06-11 23:55:45.193310
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    assert isinstance(formatter, HeadersFormatter)
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.format_options['headers']['sort'] == True
