

# Generated at 2022-06-11 23:48:15.855375
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    HeadersFormatter_instance = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: text/plain
Content-Length: 13
X-Foo: Bar
X-Foo: Baz
"""
    headers_sorted = """\
HTTP/1.1 200 OK
X-Foo: Bar
X-Foo: Baz
Content-Length: 13
Content-Type: text/plain
"""
    headers_sorted_newlines = headers_sorted.replace('\\r\\n', '\n')

    assert HeadersFormatter_instance.format_headers(headers) == headers_sorted_newlines

# Generated at 2022-06-11 23:48:22.804986
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
HTTP/1.1 302 FOUND
X-Powered-By: Express
Access-Control-Allow-Origin: *
Content-Type: application/json; charset=utf-8
Content-Length: 40
ETag: W/"28-Z8IBw0Cp3q3d01G55AnQy1fk5dc"
Date: Sat, 31 Mar 2018 13:09:20 GMT
Connection: keep-alive

{'code': 3, 'message': 'test'}
"""

# Generated at 2022-06-11 23:48:32.081877
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Set-Cookie: a=1\r\n'
        'Set-Cookie: b=2\r\n'
        'Set-Cookie: c=3\r\n'
        'Content-Type: application/json\r\n'
        'Accept: application/json'
    )

# Generated at 2022-06-11 23:48:41.600352
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert "Content-Type: application/json" == HeadersFormatter.format_headers("Content-Type: application/json")
    assert "Accept-Encoding: gzip, deflate" == HeadersFormatter.format_headers("Accept-Encoding: gzip, deflate")
    # Multiple headers of the same type
    assert "Content-Type: application/json\r\nContent-Type: application/xml" == HeadersFormatter.format_headers("Content-Type: application/json\r\nContent-Type: application/xml")
    assert "Content-Type: application/xml\r\nContent-Type: application/json" == HeadersFormatter.format_headers("Content-Type: application/json\r\nContent-Type: application/xml")

    # Request line

# Generated at 2022-06-11 23:48:42.474938
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()

    assert instance.enabled == False

# Generated at 2022-06-11 23:48:48.425766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter(context={}).format_headers("""\
HTTP/1.1 200 OK
Connection:keep-alive
Content-Encoding:gzip
Content-Type:application/json;charset=UTF-8
Date:Wed, 09 Sep 2020 22:18:45 GMT
Transfer-Encoding:chunked

""")
    expected = """\
HTTP/1.1 200 OK
Content-Encoding:gzip
Content-Type:application/json;charset=UTF-8
Connection:keep-alive
Date:Wed, 09 Sep 2020 22:18:45 GMT
Transfer-Encoding:chunked

"""
    assert actual == expected



# Generated at 2022-06-11 23:48:54.065559
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_string = '''HTTP/1.1 200 OK
Header-Two: secondValue
Header-One: firstValue
Header-Two: thirdValue

'''
    expected_output = '''HTTP/1.1 200 OK
Header-One: firstValue
Header-Two: secondValue
Header-Two: thirdValue

'''
    assert formatter.format_headers(input_string) == expected_output

# Generated at 2022-06-11 23:48:56.241040
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert formatter
    assert formatter.enabled


# Generated at 2022-06-11 23:49:07.317560
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    
    # Test sorting of headers
    headers = """GET /post/1 HTTP/1.1
Host: www.example.com
Date: Mon, 27 Jul 2009 12:28:53 GMT
Content-Type: application/x-www-form-urlencoded
"""
    assert formatter.format_headers(headers) == """GET /post/1 HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Date: Mon, 27 Jul 2009 12:28:53 GMT
Host: www.example.com
"""

    # Test sorting of headers when multiple headers with the same name is present

# Generated at 2022-06-11 23:49:15.486461
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
Vary: Accept
Content-Type: application/json
Content-Length: 2
Date: Sun, 18 Aug 2013 16:27:56 GMT
Connection: keep-alive

{}
"""
    expected_headers = """
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 18 Aug 2013 16:27:56 GMT
Vary: Accept

{}
"""
    hf = HeadersFormatter()
    result = hf.format_headers(headers)
    assert result == expected_headers

# Generated at 2022-06-11 23:49:26.903630
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Content-Type: application/json
Content-Length: 6
Host: example.com
X-Request-Id: 3
X-Some-Header: some-value
X-Some-Header: some-other-value"""
    assert formatter.format_headers(headers) == """\
Content-Type: application/json
Content-Length: 6
Host: example.com
X-Request-Id: 3
X-Some-Header: some-value
X-Some-Header: some-other-value"""

# Test for usage of method format_headers of class HeadersFormatter in class FormatterPlugin

# Generated at 2022-06-11 23:49:37.388336
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    test_headers1 = (
        'Content-Length: 15\r\n'
        'Content-Type: text/plain; charset=utf-8\r\n'
        'Date: Thu, 17 Aug 2017 16:12:38 GMT\r\n'
        'Etag: "6c7f0458f21f1f9c3d8da7c59fccb2a7"\r\n'
        'Server: GitHub.com'
    )

# Generated at 2022-06-11 23:49:43.931675
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Date: Wed, 01 Feb 2017 14:41:20 GMT
Server: Apache/2.4.10 (Debian)
Set-Cookie: JSESSIONID=abcdef; Path=/; HttpOnly
Vary: Accept-Encoding
Content-Type: application/json;charset=UTF-8
Content-Length: 19
'''

# Generated at 2022-06-11 23:49:44.886465
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    tmp = HeadersFormatter()


# Generated at 2022-06-11 23:49:52.191185
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = """HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Connection: Upgrade
Content-Length: 2

{"name": "Something"}"""

    expected = """HTTP/1.1 200 OK
Connection: keep-alive
Connection: Upgrade
Content-Length: 2
Content-Type: application/json

{"name": "Something"}"""

    actual = formatter.format_headers(headers)

    assert expected == actual

# Generated at 2022-06-11 23:50:01.930851
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """HTTP/1.1 101 Switching Protocols
Upgrade: websocket
Connection: upgrade
Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=
Sec-WebSocket-Protocol: chat
"""
    formatted_headers = formatter.format_headers(headers)
    assert formatted_headers == """HTTP/1.1 101 Switching Protocols
Connection: upgrade
Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=
Sec-WebSocket-Protocol: chat
Upgrade: websocket
"""



# Generated at 2022-06-11 23:50:09.483197
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    t = 'Accept-Encoding: gzip, deflate\r\n'\
        'Connection: keep-alive\r\nHost: httpbin.org\r\n'\
        'Accept-Encoding: gzip, deflate\r\n'\
        'Accept: application/json\r\n'\
        'User-Agent: python-requests\r\n'\
        'Accept: application/xml\r\n'\
        'User-Agent: python-requests\r\n'\
        'Connection: keep-alive'


# Generated at 2022-06-11 23:50:16.407416
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that 'format_headers' sorts headers by name
    """
    input_str = "HEAD / HTTP/1.1\r\n"\
        "Head: value2\r\n"\
        "HEAD: value1\r\n"\
        "head : value3"
    expected_str = "HEAD / HTTP/1.1\r\n"\
        "Head: value2\r\n"\
        "head : value3\r\n"\
        "HEAD: value1"
    output_str = HeadersFormatter().format_headers(input_str)
    assert output_str == expected_str

# Generated at 2022-06-11 23:50:24.108558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 1354

<!-- html body etc. --> """.lstrip('\n')
    expected = """
HTTP/1.1 200 OK
Content-Length: 1354
Content-Type: text/html; charset=utf-8

<!-- html body etc. --> """.lstrip('\n')
    formatter = HeadersFormatter()
    actual = formatter.format_headers(headers)
    assert actual == expected

# Generated at 2022-06-11 23:50:31.868054
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """\
HTTP/1.1 200 OK
X-Header-1: one
X-Header-2: two
X-Header-3: three
X-Header-1: four
X-Header-1: five"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
X-Header-1: one
X-Header-1: four
X-Header-1: five
X-Header-2: two
X-Header-3: three"""


# Plugin hook to 'httpie.formatter.format_body'

# Generated at 2022-06-11 23:50:51.195544
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    input = '--verbose\r\n' \
            'content-length: 6\r\n' \
            'content-type: application/json\r\n' \
            'date: Tue, 11 Sep 2018 00:14:36 GMT\r\n' \
            'server: gunicorn/19.9.0\r\n' \
            'x-frame-options: SAMEORIGIN'

# Generated at 2022-06-11 23:50:56.474733
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:50:58.788267
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    formatter = HeadersFormatter()

    # When
    headers = formatter.format_headers(date('headers'))

    # Then
    assert headers == date('headers_sorted')



# Generated at 2022-06-11 23:51:04.254047
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
            '''
        Content-Type: application/json
        X-Custom-Header: 42
        X-Custom-Header: 43
        '''
    ) == '''
        Content-Type: application/json
        X-Custom-Header: 42
        X-Custom-Header: 43
    '''

# Generated at 2022-06-11 23:51:14.975746
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-11 23:51:25.117100
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
X-B3-Sampled: 0
X-B3-Flags: 1
X-B3-TraceId: 082cf90324a8cbea
X-Span-Export: true
Content-Type: application/json
Content-Length: 13
Accept: application/json
X-B3-SpanId: e2f8322ccc4a1a4e
'''
    formatter = HeadersFormatter()
    actual = formatter.format_headers(headers)

# Generated at 2022-06-11 23:51:33.278867
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    
    # Unsorted headers

# Generated at 2022-06-11 23:51:35.787874
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # from httpie.formatter import format_headers
    # format_headers()
    pass



# Generated at 2022-06-11 23:51:44.354398
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Input data for test
    headers_input = """
    Content-Type: application/json
    Content-Length: 201
    X-Powered-By: ASP.NET
    Date: Tue, 10 Sep 2019 11:23:06 GMT
    Set-Cookie: ARPT=R509733765; path=/; domain=.somesite.com; HttpOnly; secure
    """
    assert HeadersFormatter().format_headers(headers_input) == """
    Content-Length: 201
    Content-Type: application/json
    Date: Tue, 10 Sep 2019 11:23:06 GMT
    Set-Cookie: ARPT=R509733765; path=/; domain=.somesite.com; HttpOnly; secure
    X-Powered-By: ASP.NET
    """

# Generated at 2022-06-11 23:51:52.258021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """GET / HTTP/1.1
Content-Type: application/json
B: bbb
C: ccc
A: aaa
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.8"""
    wanted = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
A: aaa
B: bbb
C: ccc
Connection: keep-alive
Content-Type: application/json
User-Agent: HTTPie/0.9.8"""
    assert formatter.format_headers(headers) == wanted


# Generated at 2022-06-11 23:52:08.183630
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	initial_headers = '''HTTP/1.1 200 OK
Server: nginx
Content-Type: text/html; charset=UTF-8
X-Powered-By: PHP/5.4.41
Vary: Accept-Encoding
Content-Encoding: gzip
X-Drupal-Cache: HIT
Etag: "1421500626-1"
Content-Length: 500
Accept-Ranges: bytes
Date: Tue, 17 Mar 2015 20:06:23 GMT
X-Varnish: 243564118
Age: 0
Via: 1.1 varnish
Connection: close
X-Cache: MISS'''


# Generated at 2022-06-11 23:52:15.256530
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test sorting
    headers = """\
GET / HTTP/1.1
Host: c.com
Content-Length: 10
Content-Type: application/json
""".strip()

    expected = """\
GET / HTTP/1.1
Content-Length: 10
Content-Type: application/json
Host: c.com
""".strip()

    assert HeadersFormatter.format_headers(headers) == expected

    # Test header that starts with a colon
    headers = """\
GET / HTTP/1.1
Host: c.com
:status: 500
Content-Type: application/json
""".strip()

    expected = """\
GET / HTTP/1.1
:status: 500
Content-Type: application/json
Host: c.com
""".strip()


# Generated at 2022-06-11 23:52:25.808357
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test 1
    headers = '''Content-Type: application/json
Accept: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 52
User-Agent: HTTPie/0.9.9
'''
    formatted_headers = HeadersFormatter().format_headers(headers)
    assert formatted_headers == '''Content-Type: application/json
Accept: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 52
User-Agent: HTTPie/0.9.9
'''

    # Test 2
    headers = '''User-Agent: HTTPie/0.9.9
Content-Length: 38
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Accept: application/json
'''
   

# Generated at 2022-06-11 23:52:36.226701
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter=HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Date: Sun, 31 May 2020 16:34:02 GMT
Content-Type: application/json; charset=utf-8
Vary: Accept
Content-Length: 500
Server: nginx
X-Powered-By: Express
'''

# Generated at 2022-06-11 23:52:40.626170
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'first: line',
        'second: line',
        'third: line',
        'User-Agent: unit-test'
    ])
    expected = '\r\n'.join([
        'first: line',
        'second: line',
        'third: line',
        'User-Agent: unit-test'
    ])
    result = HeadersFormatter.format_headers(headers)
    assert result == expected

# Generated at 2022-06-11 23:52:47.522792
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    headers_input = """
HTTP/1.1 200 OK
Content-Length: 15
Content-Type: application/json
Date: Sat, 11 May 2019 03:00:29 GMT
Origin: http://example.com
Server: gunicorn/19.9.0
    """
    headers_output = """
HTTP/1.1 200 OK
Content-Length: 15
Content-Type: application/json
Date: Sat, 11 May 2019 03:00:29 GMT
Origin: http://example.com
Server: gunicorn/19.9.0
    """
    assert headers.format_headers(headers_input) == headers_output

# Generated at 2022-06-11 23:52:58.058603
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fh = HeadersFormatter()
    s = '''
HTTP/1.1 200 OK
Content-Type: application/json
X-Token: abcde
Cache-Control: max-age=2000
Cache-Control: max-age=10000
X-User-Id: 12345
X-Token: fghij
'''.strip()
    out1 = '''
HTTP/1.1 200 OK
Cache-Control: max-age=2000
Cache-Control: max-age=10000
Content-Type: application/json
X-Token: abcde
X-Token: fghij
X-User-Id: 12345
'''.strip()

# Generated at 2022-06-11 23:53:08.293129
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
cache-control: max-age=604800
content-type: text/html; charset=UTF-8
date: Thu, 20 Dec 2012 18:46:30 GMT
expires: Thu, 27 Dec 2012 18:46:30 GMT
last-modified: Thu, 20 Dec 2012 18:46:30 GMT
server: ECS (sjc/4F57)
vary: Accept-Encoding
x-cache: HIT

'''

# Generated at 2022-06-11 23:53:16.402492
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers("""\
HTTP/1.1 200 OK
ETag: "0b7c2d92f6c7d412a82013728b6c5b6d"
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux""") == """\
HTTP/1.1 200 OK
ETag: "0b7c2d92f6c7d412a82013728b6c5b6d"
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux"""

if __name__ == '__main__':
    # test_HeadersFormatter_format_headers()
    pass

# Generated at 2022-06-11 23:53:27.231027
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """Date: Tue, 29 Sep 2015 15:18:07 GMT
Server: Apache
Vary: Cookie,Accept-Encoding
Content-Encoding: gzip
X-Powered-By: PHP/5.6.11
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
Content-Length: 1864
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=UTF-8"""

# Generated at 2022-06-11 23:53:48.406157
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    p = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert p.enabled
    assert p.format_headers(
        "HTTP/1.1 200 OK\n"
        "B: bbb\n"
        "C: ccc\n"
        "A: aaa\n"
        "D: ddd\n"
        "A: aaa\n"
    ) == (
        "HTTP/1.1 200 OK\n"
        "A: aaa\n"
        "A: aaa\n"
        "B: bbb\n"
        "C: ccc\n"
        "D: ddd\n"
    )

# Generated at 2022-06-11 23:53:57.436223
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test 1. One header name
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nAccept: */*') == 'GET / HTTP/1.1\r\nAccept: */*'

    # Test 2. Multiple headers
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip\r\nUser-Agent: Atom/1.47.0') == 'GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip\r\nUser-Agent: Atom/1.47.0'

    # Test 3. Multiple headers with relative order preserved

# Generated at 2022-06-11 23:54:06.698479
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('Accept: */*\r\n'
                                             'User-Agent: httpie/0.9.9\r\n'
                                             'Content-Type: application/json\r\n'
                                             'Content-Length: 27\r\n'
                                             'Accept-Encoding: gzip, deflate\r\n'
                                             'Host: localhost:8080\r\n'
                                             'Connection: keep-alive') == 'Accept: */*\r\n' \
                                                                          'Accept-Encoding: gzip, deflate\r\n' \
                                                                          'Content-Length: 27\r\n' \
                                                                          'Content-Type: application/json\r\n' \
                                

# Generated at 2022-06-11 23:54:14.613819
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'Etag: "14-1378534053000"\r\n'
        'Expires: Fri, 01 Jan 1990 00:00:00 GMT\r\n'
        'Last-Modified: Fri, 23 Aug 2013 05:00:53 GMT\r\n'
    )
    received = formatter.format_headers(headers)
    expected = (
        'Expires: Fri, 01 Jan 1990 00:00:00 GMT\r\n'
        'Last-Modified: Fri, 23 Aug 2013 05:00:53 GMT\r\n'
        'Etag: "14-1378534053000"\r\n'
    )
    assert received == expected

# Generated at 2022-06-11 23:54:21.673338
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Test whether the sorting works. Consecutive same headers
    may be sorted differently. They should remain on the same order
    as they were before sorting.
    """
    test_headers_not_formatted = """\
User-Agent: httpie/0.9.9
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive
Host: httpbin.org

"""
    test_headers_formatted = """\
User-Agent: httpie/0.9.9
Accept: */*
Accept-Encoding: gzip, deflate, compress
Connection: keep-alive
Host: httpbin.org

"""
    assert HeadersFormatter.format_headers(test_headers_not_formatted) \
        == test_headers_formatted


# Generated at 2022-06-11 23:54:26.327704
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'GET / HTTP/1.1\r\nHeader-A: A\r\nHeader-B: B\r\n'
    assert formatter.format_headers(headers) == 'GET / HTTP/1.1\r\nHeader-A: A\r\nHeader-B: B\r\n'

# Generated at 2022-06-11 23:54:33.075554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class Instance:
        # print_debug = True
        format_options = {
            'headers': {
                'sort': True,
            },
        }

    instance = Instance()
    headers_formatter = HeadersFormatter(instance)


# Generated at 2022-06-11 23:54:38.972565
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.9.8
Cache-Control: no-cache
\r\n'''

    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.8
\r\n'''

    actual = obj.format_headers(headers)
    assert actual == expected



# Generated at 2022-06-11 23:54:48.264003
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that headers are sorted case-insensitively by name while
    retaining relative order of multiple headers with the same name.

    """
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    headers = formatter.format_headers(DEFAULT)
    assert headers == '\r\n'.join([
        'Header-C: 5',
        'Header-A: 1',
        'Header-A: 2',
        'Header-B: 3',
        'Header-B: 4'
    ])


# The following data is modified for testing purposes

# Generated at 2022-06-11 23:54:53.487361
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nServer: nginx\r\nContent-Type: text/html; charset=utf-8\r\nSet-Cookie: foo=bar\r\nSet-Cookie: baz=qux\r\n'
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nServer: nginx\r\nSet-Cookie: foo=bar\r\nSet-Cookie: baz=qux\r\n'


# Generated at 2022-06-11 23:55:25.183622
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.utils import DummyIO

    # Test with multiple headers of the same name
    stdout = DummyIO()
    stdout.isatty = True
    headers_formatter = HeadersFormatter(stdout)
    headers = "HTTP/1.1 200 OK\r\n" + \
        "WWW-Authenticate: x\r\n" + \
        "WWW-Authenticate: y\r\n" + \
        "Content-Type: application/json; charset=utf-8\r\n" + \
        "Content-Length: 13\r\n" + \
        "Connection: keep-alive\r\n" + \
        "WWW-Authenticate: z\r\n"

# Generated at 2022-06-11 23:55:35.368068
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''GET / HTTP/1.1
Connection: keep-alive
Host: localhost:8080
User-Agent: HTTPie/1.0.0-dev
Accept-Encoding: gzip, deflate
Accept: */*
Accept-Encoding: br
'''
    sorted_headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: br, gzip, deflate
Connection: keep-alive
Host: localhost:8080
User-Agent: HTTPie/1.0.0-dev
'''
    Formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert Formatter.format_headers(headers) == sorted_headers


# Generated at 2022-06-11 23:55:44.689171
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create instance of class HeadersFormatter
    formatter = HeadersFormatter(format_options=True)
    # Test method
    headers1 = formatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Connection: close\r\n'
        'Content-Length: 0\r\n'
        'Host: httpbin.org\r\n'
        'User-Agent: HTTPie/1.0.2\r\n'
        '\r\n')

# Generated at 2022-06-11 23:55:52.402317
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_instance=HeadersFormatter()
    headers_formatter_instance.format_options={'headers':{'sort': 1}}
    input_headers = '''\
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    Accept: */*
    Content-Length: 1
    Content-Type: application/json
    Host: httpbin.org
    User-Agent: HTTPie/1.0.2
    '''
    output_headers = headers_formatter_instance.format_headers(input_headers)
    result=output_headers
    print("result="+result)
    assert '\r\n' in output_headers
    myList = output_headers.split("\r\n")
    print("myList="+str(myList))
    assert len(myList)

# Generated at 2022-06-11 23:55:57.874224
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Content-Type: application/json\r
X-API-Token: 12345\r
X-API-Token: 67890\r
X-Test: Test'''
    headers_sorted = '''Content-Type: application/json\r
X-API-Token: 12345\r
X-API-Token: 67890\r
X-Test: Test'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted



# Generated at 2022-06-11 23:56:06.656417
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nX-Auth: 1\r\nX-Csrf: 2\r\nConnection: Close') == 'HTTP/1.1 200 OK\r\nConnection: Close\r\nX-Auth: 1\r\nX-Csrf: 2'
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nX-Auth: 1\r\nX-Csrf: 2\r\nConnection: Close\r\nX-Auth: 3') == 'HTTP/1.1 200 OK\r\nConnection: Close\r\nX-Auth: 1\r\nX-Auth: 3\r\nX-Csrf: 2'
    assert formatter.format_

# Generated at 2022-06-11 23:56:09.630812
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers("GET / HTTP/1.1\r\nHost: localhost\r\nAccept: */*\r\n") == "GET / HTTP/1.1\r\nAccept: */*\r\nHost: localhost\r\n"

# Generated at 2022-06-11 23:56:18.471745
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {'sort': True}
    headers_formatter = HeadersFormatter(format_options)

# Generated at 2022-06-11 23:56:23.228606
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
        Accept: */*
        Foo: Bar
        Some-Header: Some Value
        Foo: Baz
    """
    expected_headers = """
        Accept: */*
        Foo: Bar
        Foo: Baz
        Some-Header: Some Value
    """
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {
        'headers': {'sort': True}
    }
    assert headers_formatter.format_headers(headers) == expected_headers



# Generated at 2022-06-11 23:56:28.779366
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] is True

    # When

# Generated at 2022-06-11 23:57:22.292811
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    input = '''\
HTTP/1.1 200 OK
Content-Length: 5
Accept: */*
Content-Type: text/html; charset=utf-8
'''
    output = '''\
HTTP/1.1 200 OK
Accept: */*
Content-Length: 5
Content-Type: text/html; charset=utf-8
'''
    assert headers_formatter.format_headers(input) == output

# Generated at 2022-06-11 23:57:28.814731
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers(
    """\
Connection: keep-alive
Content-Length: 42
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""
    )
    assert headers == """\
Connection: keep-alive
X-Foo: Baz
X-Foo: Bar
Content-Length: 42
Content-Type: application/json
"""


if __name__ == '__main__':
    # Execute the unit test if running this module standalone
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-11 23:57:36.921712
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    header_str = (
        'HTTP/1.1 200 OK\r\n'
        'Accept-Ranges: bytes\r\n'
        'Server: nginx/1.13.9\r\n'
        'Last-Modified: Thu, 13 Dec 2018 01:27:55 GMT\r\n'
        'ETag: "5c1203f7-2c18a"\r\n'
        'Content-Type: text/html\r\n'
        'Content-Length: 171898\r\n'
        'Date: Tue, 18 Dec 2018 17:45:03 GMT\r\n'
        'Connection: keep-alive'
    )

    res = headers_formatter.format_headers(header_str)

    expected_output

# Generated at 2022-06-11 23:57:45.930423
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-11 23:57:55.527379
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # GIVEN an instance of HeadersFormatter with the default format_options
    formatter = HeadersFormatter()
    # AND a string of headers

# Generated at 2022-06-11 23:58:01.595229
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: baz=qux
Date: Sat, 22 Jun 2019 03:56:21 GMT

"""
    result = headers_formatter.format_headers(headers)
    expected = """\
HTTP/1.1 200 OK
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: baz=qux
Date: Sat, 22 Jun 2019 03:56:21 GMT

"""
    assert result == expected


# Generated at 2022-06-11 23:58:07.467060
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""
HTTP/1.1 200 OK
Server: nginx/1.4.6 (Ubuntu)
Date: Mon, 23 Mar 2015 18:50:53 GMT
Content-Type: text/html
Content-Length: 438
Connection: keep-alive
Status: 200 OK
"""
    ) == """
HTTP/1.1 200 OK
Content-Length: 438
Content-Type: text/html
Connection: keep-alive
Date: Mon, 23 Mar 2015 18:50:53 GMT
Server: nginx/1.4.6 (Ubuntu)
Status: 200 OK
"""

