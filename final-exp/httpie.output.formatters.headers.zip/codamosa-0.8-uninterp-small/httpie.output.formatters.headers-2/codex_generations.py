

# Generated at 2022-06-25 18:39:07.293847
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    expected = 'Content-Length'
    actual = headers_formatter_0.format_headers('Content-Length: 26\r\nContent-Type: application/json')
    assert actual == expected

# Testcase for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:39:13.567025
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nDate: Sat, 09 Jun 2018 15:48:57 GMT\r\nServer: Apache/2\r\nLast-Modified: Sun, 10 Dec 2017 21:07:28 GMT\r\nETag: \"1c24-5611e95904380\"\r\nAccept-Ranges: bytes\r\nContent-Length: 7300\r\nVary: Accept-Encoding\r\nContent-Type: text/html\r\n\r\n"

# Generated at 2022-06-25 18:39:25.023299
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print("Testing format_headers()...", end="")

    headers_formatter = HeadersFormatter()
    headers_str = "HTTP/1.1 200 OK\r\n"
    headers_str += "Content-Type: application/json\r\n"
    headers_str += "Content-Length: 2\r\n"
    headers_str += "Server: Python/3.6 http-prompt/1.2.0\r\n"
    headers_str += "Date: Tue, 22 Jan 2019 19:41:52 GMT\r\n"
    headers_str += "Connection: close\r\n"
    headers_str += "\r\n"
    formatted_headers_str = headers_formatter.format_headers(headers_str)

# Generated at 2022-06-25 18:39:32.605711
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers('Connection: close\r\nHost: localhost:8080\r\nUser-Agent: HTTPie/1.0.2\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\n') == 'Connection: close\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nHost: localhost:8080\r\nUser-Agent: HTTPie/1.0.2\r\n'

# Generated at 2022-06-25 18:39:41.234413
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:39:44.887827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_format_headers_0 = HeadersFormatter()
    headers_formatter_format_headers_0.format_headers()
    assert headers_formatter_format_headers_0.format_options == {"headers": {"sort": True}}


# Generated at 2022-06-25 18:39:56.074113
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

    headers_dict_0 = {'User-Agent': 'httpie', 'Connection': 'keep-alive', 'Accept-Encoding': 'gzip, deflate'}
    headers_str_0 = 'HTTP/1.1 200 OK\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nUser-Agent: httpie'
    headers_str_1 = headers_formatter_0.format_headers(headers_str_0)

    assert isinstance(headers_str_1, str)
    headers_dict_1 = dict([i.split(': ') for i in headers_str_1.split('\r\n')[1:]])
    assert headers_dict_0 == headers_dict_1

''

# Generated at 2022-06-25 18:39:58.279906
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert (HeadersFormatter.__name__ == 'HeadersFormatter')
    assert (HeadersFormatter.__doc__ == '')


# Generated at 2022-06-25 18:40:08.263399
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

# Generated at 2022-06-25 18:40:09.163832
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-25 18:40:23.051590
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_1 = "header_name_1: header_value_1\r\nheader_name_5: header_value_5\r\nheader_name_2: header_value_2\r\nheader_name_4: header_value_4\r\nheader_name_3: header_value_3"
    assert headers_formatter_1.format_headers(headers_1) == "header_name_1: header_value_1\r\nheader_name_2: header_value_2\r\nheader_name_3: header_value_3\r\nheader_name_4: header_value_4\r\nheader_name_5: header_value_5"



# Generated at 2022-06-25 18:40:30.925786
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Initiate objects
    new_headers_formatter = HeadersFormatter()
    # Cases
    headers_string_0 = 'HTTP/1.1 200 OK\r\nAccept: application/json\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\nContent-Encoding: gzip\r\nContent-Length: 612\r\nContent-Type: application/json\r\nDate: Sun, 27 Sep 2020 04:42:56 GMT\r\nExpires: -1\r\nPragma: no-cache\r\nServer: WebService\r\nTransfer-Encoding: chunked\r\nVary: Accept-Encoding\r\nX-IPLB-Instance: 34145\r\n\r\n'

# Generated at 2022-06-25 18:40:32.397016
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False

# Generated at 2022-06-25 18:40:35.002605
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # case 0
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0


# Generated at 2022-06-25 18:40:36.446958
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter(**dict())


# Generated at 2022-06-25 18:40:39.543547
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_options['headers']['sort'] == True


# Generated at 2022-06-25 18:40:47.525282
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 0
    headers_formatter_0 = HeadersFormatter()
    headers_formatter_0.format_options['headers']['sort'] = True
    assert headers_formatter_0.format_headers('a: b\r\na: c\r\n') == 'a: b\r\na: c\r\n'
    headers_formatter_0.format_options['headers']['sort'] = False
    assert headers_formatter_0.format_headers('a: c\r\na: b\r\n') == 'a: c\r\na: b\r\n'

# Generated at 2022-06-25 18:40:57.622660
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK\r\nHost: api.melissadata.net\r\nConnection: keep-alive\r\nContent-Length: 92\r\nUser-Agent: HTTPie/1.0.3\r\nAccept: application/json\r\nAccept-Encoding: gzip, deflate\r\nX-Authentication-Token: 3f44a0871d664e2e8cc50f64cffa1d74\r\n\r\n'''

# Generated at 2022-06-25 18:40:59.517372
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_case_0()

# Generated at 2022-06-25 18:41:01.645446
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, HeadersFormatter)


# Generated at 2022-06-25 18:41:16.057654
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    t_headers = [
        "Content-Length: 3\r\nContent-Type: application/json",
        "x-a: 1\r\ncontent-length: 3\r\ncontent-type: application/json",
        "Content-Type: application/json; charset=utf-8\r\nContent-Length: 3",
        "Content-Length: 3\r\ncontent-type: application/json",
        "x-a: 1\r\ncontent-length: 3\r\nContent-Type: application/json",
    ]

# Generated at 2022-06-25 18:41:26.056521
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected_result = """\
HTTP/1.0 200 OK
Date: Fri, 23 Jun 2017 20:03:37 GMT
Server: Apache/2.4.7 (Ubuntu)
Set-Cookie: JSESSIONID=75D4A1BDD67F4F4A4EB8D36E2A2BE398; Path=/; HttpOnly
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
Content-Length: 50
Connection: close
Content-Type: application/json

{
    "Content": "Hello, World!"
}
""".strip()
    actual_result = HeadersFormatter().format_headers(headers_case_0)

# Generated at 2022-06-25 18:41:37.745073
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Length: 10
Content-Type: text/html
Date: Wed, 14 Oct 2020 08:56:02 GMT
Server: Python/3.8 aiohttp/3.6.2


"""
    headers_formatter = HeadersFormatter()
    result = headers_formatter.format_headers(headers)
    assert result == "\r\n".join([
        "HTTP/1.1 200 OK",
        "Content-Length: 10",
        "Content-Type: text/html",
        "Date: Wed, 14 Oct 2020 08:56:02 GMT",
        "Server: Python/3.8 aiohttp/3.6.2",
        ""
    ])

# Generated at 2022-06-25 18:41:47.755387
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_str_0 = 'HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Python/6.6.6 (custom)\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nETag: "6807-4a7-393f9f923d800"\r\nContent-Type: text/html\r\nContent-Length: 288\r\nX-Powered-By: Coffee\r\nAccept-Ranges: bytes\r\n'

# Generated at 2022-06-25 18:41:49.075771
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__ != None


# Generated at 2022-06-25 18:41:58.942764
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    headers_formatter_1 = HeadersFormatter()

# Generated at 2022-06-25 18:42:09.582747
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = '''Content-Length: 260
Content-Type: application/json
Cookie: _ga=GA1.1.534137228.1512888032; _gid=GA1.1.1759249112.1512888032
Date: Sun, 17 Dec 2017 01:08:56 GMT
Server: nginx
Vary: Accept-Encoding'''

# Generated at 2022-06-25 18:42:17.313904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_0 = 'HTTP/1.1 200 OK\r\nServer: nginx\r\nDate: Sat, 16 Jul 2016 18:10:51 GMT\r\nContent-Type: text/html\r\nContent-Length: 748\r\nLast-Modified: Sun, 01 May 2016 12:20:25 GMT\r\nConnection: keep-alive\r\nETag: "572584e1-2e4"\r\nAccept-Ranges: bytes\r\n\r\n'

# Generated at 2022-06-25 18:42:25.643222
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\r
Host: example.com\r
Connection: close\r
Content-Length: 25\r
X-B3-TraceId: 2f0a63d76b0c8e42\r
X-B3-SpanId: 2f0a63d76b0c8e42\r
X-B3-Sampled: 0\r
X-B3-ParentSpanId: 5e3e42a3e1a3c006\r
Content-Type: application/json\r\n"""

# Generated at 2022-06-25 18:42:29.527851
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.enabled is True
    assert headers_formatter_0.format_options == {'headers': {'sort': True}}
    assert headers_formatter_0.highlight_options == {}


# Generated at 2022-06-25 18:42:37.337725
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-25 18:42:48.289718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:42:55.236220
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    formated_headers = headers_formatter.format_headers("""HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nDate: Sat, 06 May 2017 03:49:31 GMT\r\n\r\n""")
    assert formated_headers == 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nDate: Sat, 06 May 2017 03:49:31 GMT\r\n\r\n'

# Generated at 2022-06-25 18:42:59.167919
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    cases = load_tests('headers', 'HeadersFormatter', 'format_headers')
    for c in cases:
        headers_formatter = HeadersFormatter()
        result = headers_formatter.format_headers(c['input']['headers'])
        assert result == c['expected']['headers']



# Generated at 2022-06-25 18:43:05.891814
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_str = 'HTTP/1.1 200 OK\r\nDate: Sat, 19 Jul 2014 18:49:24 GMT\r\nServer: Apache\r\nX-Powered-By: PHP/5.5.10\r\nSet-Cookie: foo=bar\r\nLast-Modified: Mon, 15 Jul 2013 18:04:58 GMT\r\nETag: "40f-4c9ebb5f5a600"\r\nAccept-Ranges: bytes\r\nContent-Length: 103\r\nKeep-Alive: timeout=1, max=100\r\nConnection: Keep-Alive\r\nContent-Type: text/html\r\n'

# Generated at 2022-06-25 18:43:15.306589
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_formatter_0.format_options = {
        "headers": {
            "sort": True
        }
    }
    # Test case 0

# Generated at 2022-06-25 18:43:24.324146
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled
    assert headers_formatter.format_headers(b'''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 192
Content-Type: application/json
Date: Fri, 10 Apr 2020 09:50:29 GMT
Server: gunicorn/19.9.0
''') == b'''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 192
Content-Type: application/json
Date: Fri, 10 Apr 2020 09:50:29 GMT
Server: gunicorn/19.9.0
'''

# Generated at 2022-06-25 18:43:27.970131
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1
    assert headers_formatter_1.format_options == {'headers': {'sort': True}}

# Generated at 2022-06-25 18:43:28.510812
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-25 18:43:31.070332
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert isinstance(headers_formatter_0, HeadersFormatter)


# Generated at 2022-06-25 18:43:49.927367
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    result = headers_formatter_0.format_headers('Content-Type: application/json\r\nHost: localhost:5000\r\nContent-Length: 97\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nUser-Agent: HTTPie/0.9.9')
    assert result == 'Content-Type: application/json\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nContent-Length: 97\r\nHost: localhost:5000\r\nUser-Agent: HTTPie/0.9.9'

# Generated at 2022-06-25 18:43:58.912667
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Length: 2191\r\nContent-Type: application/json\r\nDate: Fri, 09 Aug 2019 14:51:21 GMT\r\nHost: api.coinpaprika.com\r\nUser-Agent: HTTPie/1.0.2\r\nX-Ratelimit-Limit: 60\r\nX-Ratelimit-Remaining: 58\r\n\r\n'

# Generated at 2022-06-25 18:44:08.917965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

    headers = '''GET / HTTP/1.1
Host: www.example.com
Cookie: cookie1=value1
Cookie: cookie2=value2
Cookie: cookie3=value3;
Referer: http://www.example.com/
User-Agent: HTTPie/0.9.2
'''
    expected = '''GET / HTTP/1.1
Cookie: cookie1=value1
Cookie: cookie2=value2
Cookie: cookie3=value3;
Host: www.example.com
Referer: http://www.example.com/
User-Agent: HTTPie/0.9.2
'''
    assert headers_formatter_1.format_headers(headers) == expected


# Generated at 2022-06-25 18:44:12.192950
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """GET / HTTP/1.1
Host: sh.nu
Connection: close
"""
    assert (headers_formatter.format_headers(headers) == """GET / HTTP/1.1
Connection: close
Host: sh.nu
""")


# Generated at 2022-06-25 18:44:20.470436
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('A: 1\r\nB: 2\r\nA: 3\r\nB: 4') == 'A: 1\r\nA: 3\r\nB: 2\r\nB: 4'
    assert headers_formatter.format_headers('B: 1\r\nB: 2\r\nC: 3\r\nA: 4\r\nB: 5') == 'A: 4\r\nB: 1\r\nB: 2\r\nB: 5\r\nC: 3'

# Generated at 2022-06-25 18:44:21.642131
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-25 18:44:23.370017
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__module__ == 'httpie_plugins.headers'



# Generated at 2022-06-25 18:44:30.468237
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    test_data = '''Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US
Connection: keep-alive
Host: www.google.com
User-Agent: HTTPie/0.9.9
'''
    test_result = '''Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US
Connection: keep-alive
Host: www.google.com
User-Agent: HTTPie/0.9.9
'''.lower()
    assert headers_formatter.format_headers(test_data).lower() == test_result

# Generated at 2022-06-25 18:44:32.940555
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        config=dict(format_options={"headers":{"sort": True}}))
    assert headers_formatter.enabled


# Generated at 2022-06-25 18:44:43.092250
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:45:21.250016
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

    headers_test_0 = """\
HTTP/1.1 200 OK
Date: Sat, 22 Feb 2020 16:13:13 GMT
Server: Apache
Last-Modified: Sat, 19 Jan 2013 17:18:56 GMT
ETag: "2d-4c7b3239b5f5b"
Accept-Ranges: bytes
Content-Length: 45
Connection: close
Content-Type: text/html; charset=UTF-8

"""
    assert headers_formatter_1.format_headers(headers_test_0) == headers_test_0


# Generated at 2022-06-25 18:45:30.261353
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Variants of headers with multiple headers with the same name
    # and headers with no name, but no values
    headers_1 = '''\
Content-Type: application/json
Connection: close
Connection: keep-alive
Connection:
: foo
: bar
:'''
    headers_2 = '''\
Content-Type: application/json
Test-Header: foo
Connection: close
Connection: keep-alive
Connection:
: foo
: bar
:'''
    # Headers with a single header with no name and no value
    headers_3 = '''\
Content-Type: application/json
Connection: close
Connection: keep-alive
Connection:
:'''

# Generated at 2022-06-25 18:45:35.945987
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers = '''\
POST /post HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Foo: bar
Baz: qux
'''
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers(headers) == '''\
POST /post HTTP/1.1
Baz: qux
Content-Type: application/x-www-form-urlencoded
Foo: bar
'''


# Generated at 2022-06-25 18:45:41.047943
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers_formatter_1.format_headers("[a:1,\nb:2,\nc:3,\nd:4]")
    assert headers_formatter_1.headers == "[a:1, b:2, c:3, d:4]"


# Generated at 2022-06-25 18:45:45.359250
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers("User-Agent: HTTPie/2.1.0\nAccept: */*") == "User-Agent: HTTPie/2.1.0\nAccept: */*"

# Generated at 2022-06-25 18:45:51.580878
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    return headers_formatter.format_headers("""\
HTTP/1.1 200 OK
Date: Fri, 31 Dec 1999 23:59:59 GMT
Content-Type: text/plain
Content-Length: 42

""") == """\
HTTP/1.1 200 OK
Content-Length: 42
Content-Type: text/plain
Date: Fri, 31 Dec 1999 23:59:59 GMT

""".encode('ascii')


# Generated at 2022-06-25 18:45:56.100056
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert "HTTP/1.1 200 OK\r\nX-Dd: %34%09%2.d\r\nX-Bb: \"x\"\r\nX-Aa: /\r\n" == headers_formatter_0.format_headers("HTTP/1.1 200 OK\r\nX-Aa: /\r\nX-Bb: \"x\"\r\nX-Dd: %34%09%2.d\r\n")

# Generated at 2022-06-25 18:46:06.172421
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # test case #0
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers('Accept: b\nAccept: a\nAccept: c') == 'Accept: a\nAccept: b\nAccept: c'
    assert headers_formatter_0.format_headers('Accept: d\r\nAccept: b\r\nAccept: a\r\nAccept: c') == 'Accept: a\r\nAccept: b\r\nAccept: c\r\nAccept: d'

# Generated at 2022-06-25 18:46:15.357514
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = b"""HTTP/1.1 200 OK
Server: nginx/1.9.9
Date: Wed, 30 Jan 2019 11:52:38 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 232
Connection: keep-alive
Set-Cookie: cookie_name=cookie_value; Expires=Wed, 30-Jan-2020 11:52:38 GMT; Path=/
Set-Cookie: cookie_name=cookie_value; Expires=Wed, 30-Jan-2020 11:52:38 GMT; Path=/
Keep-Alive: timeout=8

"""

# Generated at 2022-06-25 18:46:24.195826
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers = """
HTTP/1.1 400 Bad Request
Alternate-Protocol: 443:quic,p=0
Cache-Control: no-cache, no-store, max-age=0, must-revalidate
Content-Length: 497
Content-Type: text/html; charset=utf-8
Date: Wed, 19 Aug 2015 20:54:24 GMT
Expires: Fri, 01 Jan 1990 00:00:00 GMT
Pragma: no-cache
Server: GSE
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
"""

# Generated at 2022-06-25 18:47:33.731601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    response_headers_string_1 = '''\
    HTTP/1.1 200 OK\r
    Server: Apache-Coyote/1.1\r
    Set-Cookie: JSESSIONID=4D8FCC8D3BC3AC4CE2F1D9DEBA8B46D4; Path=/; HttpOnly\r
    csp: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'\r
    Content-Type: text/html;charset=utf-8\r
    Transfer-Encoding: chunked\r\n'''

# Generated at 2022-06-25 18:47:41.236789
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_str_1 = """HTTP/1.1 200 OK
Server: nginx/1.12.2
Date: Thu, 26 Jul 2018 18:40:16 GMT
Content-Type: application/json
Content-Length: 27
Connection: keep-alive

"""
    assert headers_formatter_0.format_headers(headers_str_1) == """HTTP/1.1 200 OK
Content-Length: 27
Content-Type: application/json
Connection: keep-alive
Date: Thu, 26 Jul 2018 18:40:16 GMT
Server: nginx/1.12.2

"""

# Generated at 2022-06-25 18:47:52.338083
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """HTTP/1.1 200 OK
Accept-Ranges: bytes
Allow: GET
Cache-Control: max-age=604800
Content-Type: text/html; charset=UTF-8
Date: Thu, 10 May 2018 04:51:42 GMT
Etag: \"1541025663\"
Expires: Thu, 17 May 2018 04:51:42 GMT
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (fcn/8313)
Vary: Accept-Encoding
X-Cache: HIT
x-ec-custom-error: 1
Content-Length: 1270
"""
    headers_formatter_0 = HeadersFormatter()
    headers = headers_formatter_0.format_headers(headers)
    assert "Cache-Control: max-age=604800" in headers

# Generated at 2022-06-25 18:47:55.701421
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('Content-Type: text/plain\r\nFoo: bar\r\n') == 'Content-Type: text/plain\r\nFoo: bar\r\n'

# Generated at 2022-06-25 18:47:56.237882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    pass



# Generated at 2022-06-25 18:48:00.677811
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    input_headers = """HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Cache-Control: no-cache
Content-Length: 17

"""

    expected_headers = """HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 17
Content-Type: text/html; charset=utf-8

"""

    assert headers_formatter.format_headers(input_headers) == expected_headers

# Generated at 2022-06-25 18:48:07.465396
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

    headers_str = """HTTP/1.1 200 OK
Connection: close
Content-Length: 5
Content-Type: application/json
"""

    expected = """HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
Connection: close
"""
    actual = headers_formatter_1.format_headers(headers_str)
    print(actual)
    assert actual == expected

test_HeadersFormatter_format_headers()
test_case_0()

# Generated at 2022-06-25 18:48:20.086670
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers_0 = "GET / HTTP/1.1\r\n" \
                "Host: 127.0.0.1:5000\r\n" \
                "Accept-Encoding: gzip, deflate\r\n" \
                "Accept: */*\r\n" \
                "User-Agent: HTTPie/2.2.0\r\n" \
                "\r\n" \
                "Accept-Charset: {charset}\r\n" \
                "Accept-Language: {language}\r\n"

# Generated at 2022-06-25 18:48:20.931536
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_forma

# Generated at 2022-06-25 18:48:32.647009
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_headers = (
        'POST /post HTTP/1.1\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: */*\r\n'
        'Accept-Language: en\r\n'
        'User-Agent: HTTPie/1.0.2\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 65\r\n'
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8\r\n'
        'Host: httpbin.org\r\n'
        '\r\n'
    )
