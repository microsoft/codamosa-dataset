

# Generated at 2022-06-25 18:39:05.284176
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    
    # Test case 0
    headers_formatter_0 = HeadersFormatter()
    headers_0 = """HTTP/1.1 200 OK
Content-Length: 16
Content-Type: text/plain
Server: Werkzeug/0.14.1 Python/3.5.2
Date: Sun, 03 Dec 2017 16:41:13 GMT

Hello World!"""
    headers_0_expected = """HTTP/1.1 200 OK
Content-Length: 16
Content-Type: text/plain
Date: Sun, 03 Dec 2017 16:41:13 GMT
Server: Werkzeug/0.14.1 Python/3.5.2

Hello World!"""
    assert headers_formatter_0.format_headers(headers_0) == headers_0_expected

    # Test case 1
    headers_formatter_1 = Head

# Generated at 2022-06-25 18:39:13.536803
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    # Case 0
    string_0 = 'HTTP/1.1 200 OK\r\n' \
        'Content-Type: text/plain; charset=UTF-8\r\n' \
        'Vary: Accept-Language, Cookie\r\n' \
        'Etag: "1541025663+gzip+ident"\r\n' \
        '\r\n'
    value_0 = headers_formatter_0.format_headers(string_0)
    assert value_0 == 'HTTP/1.1 200 OK\r\n' \
        'Content-Type: text/plain; charset=UTF-8\r\n' \
        'Etag: "1541025663+gzip+ident"\r\n' \
       

# Generated at 2022-06-25 18:39:24.981342
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers: str = ('GET / HTTP/1.1\r\n'
                    'User-Agent: HTTPie\r\n'
                    'Accept-Encoding: gzip, deflate\r\n'
                    'Accept: */*\r\n'
                    'Connection: keep-alive\r\n'
                    '\r\n')
    result: str = headers_formatter_1.format_headers(headers)

# Generated at 2022-06-25 18:39:28.676295
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        hdr = HeadersFormatter()
        assert hdr is not None
    except NameError:
        pytest.fail("Could not construct class HeadersFormatter")


# Generated at 2022-06-25 18:39:30.602772
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_1 = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert header

# Generated at 2022-06-25 18:39:38.100667
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json; charset=utf-8',
        'X-Custom-Header: abc123',
        'Date: Thu, 23 Mar 2017 15:16:26 GMT',
        'Content-Length: 8',
        'Connection: close',
        ''])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Connection: close',
        'Content-Length: 8',
        'Content-Type: application/json; charset=utf-8',
        'Date: Thu, 23 Mar 2017 15:16:26 GMT',
        'X-Custom-Header: abc123',
        ''])


# Generated at 2022-06-25 18:39:40.665675
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == True
    assert headers_formatter.format_options['headers']['colors'] == True


# Generated at 2022-06-25 18:39:43.070851
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    print(test_case_0())

test_HeadersFormatter()

# Generated at 2022-06-25 18:39:53.655015
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.format_headers("""Content-Length: 175
Content-Type: application/json
Date: Sun, 13 Oct 2019 09:56:58 GMT
Host: newsapi.org
X-Cache-Hits: 0
X-Ratelimit-Limit: 100
X-Ratelimit-Remaining: 99
X-Ratelimit-Reset: 12889960
""") == """Content-Length: 175
Content-Type: application/json
Date: Sun, 13 Oct 2019 09:56:58 GMT
Host: newsapi.org
X-Cache-Hits: 0
X-Ratelimit-Limit: 100
X-Ratelimit-Remaining: 99
X-Ratelimit-Reset: 12889960
""")

# Generated at 2022-06-25 18:40:00.136609
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers("Host: example.com\nUser-Agent: httpie/0.9.6\nAccept-Encoding: gzip, deflate\nAccept: */*\nConnection: keep-alive") == "Host: example.com\nAccept: */*\nAccept-Encoding: gzip, deflate\nConnection: keep-alive\nUser-Agent: httpie/0.9.6"



# Generated at 2022-06-25 18:40:11.724217
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
X-Cache: MISS from localhost
X-Cache-Lookup: MISS from localhost
Accept-Ranges: bytes
Content-Length: 26
Access-Control-Allow-Credentials: true
Content-Type: text/html
Date: Tue, 18 Aug 2020 05:03:57 GMT
Expires: Tue, 18 Aug 2020 05:04:57 GMT
Pragma: no-cache
Server: nginx
Via: 1.1 localhost (squid/3.5.27)
X-Cache: MISS from localhost
X-Cache-Lookup: MISS from localhost:3128

1234 1234 1234 1234 1234
    """
    headers_formatter_0 = HeadersFormatter()

# Generated at 2022-06-25 18:40:19.472655
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    str_arg_0 = """\
HTTP/1.1 200 OK
Date: Wed, 29 Aug 2012 14:37:40 GMT
Server: Apache/2.2.14 (Ubuntu)
Connection: close
Transfer-Encoding: chunked
Content-Type: text/html
"""
    str_return_0 = headers_formatter_0.format_headers(str_arg_0)
    assert str_return_0 == str_arg_0

# Generated at 2022-06-25 18:40:29.040839
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = headers_formatter.format_headers('GET / HTTP/1.1\r\nHost:nghttp2.org\r\nConnection:keep-alive\r\nUser-Agent:HTTPie/0.9.6\r\nAccept-Encoding:gzip, deflate\r\nAccept:*/*\r\n\r\n')
    assert headers ==  'GET / HTTP/1.1\r\nAccept:*/*\r\nAccept-Encoding:gzip, deflate\r\nConnection:keep-alive\r\nHost:nghttp2.org\r\nUser-Agent:HTTPie/0.9.6\r\n\r\n'

# Generated at 2022-06-25 18:40:30.305621
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()


# Generated at 2022-06-25 18:40:32.553459
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers('') == ''

# Generated at 2022-06-25 18:40:35.550904
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        headers_formatter = HeadersFormatter()
    except:
        assert False


# Unit tests for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:40:46.593961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Test 0
    headers = headers_formatter.format_headers(headers_0)
    assert headers == '\r\n'.join(sorted(headers_0.splitlines()[1:]))

    # Test 1
    headers = headers_formatter.format_headers(headers_1)
    assert headers == '\r\n'.join(sorted(headers_1.splitlines()[1:]))

    # Test 2
    headers = headers_formatter.format_headers(headers_2)
    assert headers == '\r\n'.join(sorted(headers_2.splitlines()[1:]))


# Generated at 2022-06-25 18:40:55.403508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert isinstance(headers_formatter_1, HeadersFormatter)
    assert headers_formatter_1.format_headers("Host: example.com\r\nConnection: keep-alive\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, br\r\nAccept-Language: en-US,en;q=0.9") == "Host: example.com\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, br\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: keep-alive"

# Generated at 2022-06-25 18:41:02.834597
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 26
Content-Type: application/json; charset=utf-8
Host: httpbin.org
User-Agent: HTTPie/1.0.2

"""
    print(headers)
    headers_formatter = HeadersFormatter()
    if headers_formatter.enabled:
        headers = headers_formatter.format_headers(headers)

    print(headers)
    assert True

# Generated at 2022-06-25 18:41:12.892515
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

# Generated at 2022-06-25 18:41:28.165520
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

    headers = headers_formatter_0.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-XSS-Protection: 1; mode=block\r\nContent-Type: application/json; charset=UTF-8\r\nDate: Wed, 04 Apr 2018 05:15:27 GMT\r\nServer: Apache\r\nVary: Accept-Encoding\r\nConnection: close\r\nContent-Length: 47\r\n\r\n{\n    "status" : "success",\n    "data" : "ok"\n}')

# Generated at 2022-06-25 18:41:40.142071
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:41:43.199892
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head_format = HeadersFormatter()
    assert head_format.enabled == True
    assert head_format.format_options['headers']['sort'] == True


# Generated at 2022-06-25 18:41:50.833607
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Test 1: httpie.plugins.headers.headers_formatter.HeadersFormatter.format_headers()

# Generated at 2022-06-25 18:41:53.740426
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_options['headers']['sort'] == True


# Generated at 2022-06-25 18:42:05.793351
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:42:14.338723
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Test case 1
    headers_1 = """HTTP/1.1 200 OK
Date: Sun, 04 Sep 2016 17:43:38 GMT
Server: Apache
Set-Cookie: foo=0;
                expires=Sun, 02 Oct 2016 17:43:38 GMT;
                path=/; domain=example.com; HttpOnly
Set-Cookie: bar=1;
                expires=Sun, 02 Oct 2016 17:43:38 GMT;
                path=/; domain=example.com; HttpOnly
Content-Length: 59
Content-Type: text/html; charset=UTF-8

<html>
<body>
foo: 0
bar: 1
</body>
</html>"""


# Generated at 2022-06-25 18:42:21.559597
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_0 = HeadersFormatter(headers=True)
    formatter_0.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Connection: close\r\n'
        'Content-Length: 240\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        'Date: Mon, 03 Aug 2020 12:11:45 GMT\r\n'
        'Server: WSGIServer/0.2 CPython/3.8.2\r\n'
        'Vary: Accept\r\n'
        'X-Frame-Options: SAMEORIGIN\r\n'
        '\r\n'
    )
    formatter_1 = HeadersFormatter(headers=True)

# Generated at 2022-06-25 18:42:30.566330
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter_0 = HeadersFormatter()
    headers_0 = '''HTTP/1.1 200 OK\r\nDate: Mon, 23 May 2005 22:38:34 GMT\r\nServer: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)\r\nLast-Modified: Wed, 08 Jan 2003 23:11:55 GMT\r\nEtag: "3f80f-1b6-3e1cb03b"\r\nAccept-Ranges: bytes\r\nContent-Length: 438\r\nConnection: close\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n'''

    # Pass in any arguments that need to be tested
    headers_formatter_0.format_headers(headers_0)

   

# Generated at 2022-06-25 18:42:42.439879
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = ''
    ret_val_0 = headers_formatter_0.format_headers(headers)
    assert ret_val_0 == '\r\n'
    headers = 'HTTP/1.1 301 Moved Permanently\r\nContent-Length: 0\r\nContent-Type: text/html;'
    ret_val_1 = headers_formatter_0.format_headers(headers)
    assert ret_val_1 == 'HTTP/1.1 301 Moved Permanently\r\nContent-Length: 0\r\nContent-Type: text/html;'
    headers = 'HTTP/1.1 301 Moved Permanently\r\nContent-Length: 0\r\nContent-Type: text/html;'
    ret_val

# Generated at 2022-06-25 18:42:57.946919
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """HeadersFormatter: Constructor of class HeadersFormatter"""
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == False


# Generated at 2022-06-25 18:43:05.357303
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers(
        'Content-Type: application/x-www-form-urlencoded\r\n'
        'Accept: application/json') == 'Content-Type: application/x-www-form-urlencoded\r\n'

# Generated at 2022-06-25 18:43:12.006487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_0 = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Date: Wed, 01 Aug 2018 16:44:08 GMT
Server: waitress
'''
    headers_1 = '''\
HTTP/1.1 200 OK
Date: Wed, 01 Aug 2018 16:44:08 GMT
Content-Type: application/json
Server: waitress
'''
    assert headers_formatter.format_headers(headers_0) == headers_1

# Generated at 2022-06-25 18:43:15.223836
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print("test_HeadersFormatter")
    headers_formatter1 = HeadersFormatter()
    assert isinstance(headers_formatter1, HeadersFormatter)
    assert headers_formatter1.format_options['headers']['sort'] == False


# Generated at 2022-06-25 18:43:24.555833
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Content-Length: 9
X-pT:
X-pT: 1
X-pT: 2
Cache-Control: max-age=604800
X-pT: 3
Cache-Control: max-age=604800


'''
    sorted_headers = '''HTTP/1.1 200 OK
Cache-Control: max-age=604800
Cache-Control: max-age=604800
Content-Length: 9
X-pT:
X-pT: 1
X-pT: 2
X-pT: 3


'''
    assert sorted_headers == headers_formatter.format_headers(headers)

# Generated at 2022-06-25 18:43:35.874493
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:43:43.930119
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == False

    headers_formatter = HeadersFormatter(format_options={'headers':{'sort': True}})
    assert headers_formatter.format_options['headers']['sort'] == True

    headers_formatter = HeadersFormatter(format_options={'headers':{'sort': False}})
    assert headers_formatter.format_options['headers']['sort'] == False



# Generated at 2022-06-25 18:43:55.330023
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # set up
    headers_formatter_0 = HeadersFormatter()
    str_0 = "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Type: application/json\r\nServer: GitHub.com\r\nDate: Fri, 18 Mar 2016 22:14:48 GMT\r\n\r\n"
    # perform test
    str_1 = headers_formatter_0.format_headers(str_0)
    # inspect results
    assert str_0 == "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Type: application/json\r\nServer: GitHub.com\r\nDate: Fri, 18 Mar 2016 22:14:48 GMT\r\n\r\n"

# Generated at 2022-06-25 18:44:07.271490
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Etag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Connection: close
Content-Type: text/plain
X-Pad: avoid browser bug

Some random source code"""

# Generated at 2022-06-25 18:44:17.298129
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.13.10
Date: Wed, 02 May 2018 13:22:55 GMT
Content-Type: application/json
Content-Length: 4
Connection: keep-alive
Cache-Control: no-cache
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
X-Content-Type-Options: nosniff'''

# Generated at 2022-06-25 18:44:49.317963
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(formatter=None, options=None).format_headers('') == ''

# Generated at 2022-06-25 18:44:52.696677
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers_formatter_1.output = io.StringIO("Content-Type: application/json\r\n")
    headers_formatter_1.format_headers("Content-Type: application/json")


# Generated at 2022-06-25 18:45:03.718541
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import FormatterPlugin

    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:45:10.672599
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    httpie_headers_0 = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Transfer-Encoding: chunked\r\n'
        'Server: nginx\r\n'
        'Date: Tue, 26 Feb 2019 15:53:53 GMT\r\n'
        '\r\n'
    )

# Generated at 2022-06-25 18:45:20.524790
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:45:29.816220
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

# Generated at 2022-06-25 18:45:39.488040
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:45:50.118135
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options['headers']['sort'] = False
    assert headers_formatter.format_headers('\r\n'.join((
        'GET / HTTP/1.1',
        'Host: example.org',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'User-Agent: HTTPie/0.9.2'
    ))) == '\r\n'.join((
        'GET / HTTP/1.1',
        'Host: example.org',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'User-Agent: HTTPie/0.9.2'
    ))



# Generated at 2022-06-25 18:45:54.576742
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers_formatter_1.format_headers("""GET / HTTP/1.1
Content-Type: application/x-www-form-urlencoded; charset=utf-8
X-Foo: bar
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
Content-Length: 57
Host: 127.0.0.1:5000""")



# Generated at 2022-06-25 18:46:04.706237
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers = '''HTTP/1.1 200 OK
Connection: close
Content-Length: 16
Content-Type: application/json
Date: Sat, 20 May 2017 13:31:51 GMT
Server: Python/3.6 aiohttp/3.1.3

{"key": "value"}
'''
    expected_headers = '''HTTP/1.1 200 OK
Connection: close
Content-Length: 16
Content-Type: application/json
Date: Sat, 20 May 2017 13:31:51 GMT
Server: Python/3.6 aiohttp/3.1.3

{"key": "value"}
'''
    headers_formatter_0 = HeadersFormatter()
    actual_headers = headers_formatter_0.format_headers(test_headers)
    assert actual_headers == expected_headers

# Generated at 2022-06-25 18:47:06.738928
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Implicit sort
    headers_formatter_1 = HeadersFormatter(format_options={'headers': {'sort': True}})
    input_headers = 'GET / HTTP/1.1\r\nAccept: application/json\r\nX-Foo: Bar\r\nContent-Type: application/json\r\n'
    output_headers = 'GET / HTTP/1.1\r\nAccept: application/json\r\nContent-Type: application/json\r\nX-Foo: Bar\r\n'
    assert headers_formatter_1.format_headers(input_headers) == output_headers
    # Explicit sort
    headers_formatter_2 = HeadersFormatter(format_options={'headers': {'sort': False}})

# Generated at 2022-06-25 18:47:15.639853
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    # Test case 1: verify that method returns correctly sorted headers given correctly sorted headers
    headers = "HTTP/1.1 200 OK\r\nContent-Length: 4\r\nContent-Type: text/html; charset=utf-8\r\nDate: Thu, 23 Mar 2017 15:49:54 GMT\r\nServer: Werkzeug/0.12.1 Python/3.6.0\r\n"
    expected_headers = headers
    output_headers = headers_formatter_1.format_headers(headers)
    if (output_headers != expected_headers):
        print("Failed test case #1")
    else:
        print("Passed test case #1")
    # Test case 2: verify that method returns correctly sorted headers given alphabetically disordered headers

# Generated at 2022-06-25 18:47:25.049114
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()


# Generated at 2022-06-25 18:47:35.192613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers("HTTP/1.1 200 OK\r\nContent-Length: 17\r\nContent-Type: application/json; charset=utf-8") == "HTTP/1.1 200 OK\r\nContent-Length: 17\r\nContent-Type: application/json; charset=utf-8"

# Generated at 2022-06-25 18:47:41.087808
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    input = """
POST /post HTTP/1.1
User-Agent: httpie
Accept-Encoding: gzip, deflate
Accept: */*
Content-Type: application/json
Connection: keep-alive
Content-Length: 18

"""
    expected = """
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
User-Agent: httpie

"""
    actual = headers_formatter.format_headers(input)
    assert actual == expected

# Generated at 2022-06-25 18:47:52.145389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Test-case 0:
    # Test if headers_formatter.format_headers() correctly sort headers in the
    # right order by case.

    # Arrange:
    # Create expected header output.
    header_input = '''\
HTTP/1.1 200 OK\r
Connection: keep-alive\r
Content-Length: 16\r
Content-Type: application/json\r
Date: Wed, 11 Mar 2020 10:42:07 GMT\r
Server: tornado\r
Access-Control-Allow-Origin: *\r
Access-Control-Allow-Credentials: true\r
\r
'''

# Generated at 2022-06-25 18:48:00.496021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin_0 = HeadersFormatter()
    str_arg_0 = 'Foo: bar\nContent-Length: 123\nFoo: baz\n'
    assert formatter_plugin_0.format_headers(str_arg_0) == 'Foo: bar\nFoo: baz\nContent-Length: 123\n'
    str_arg_0 = 'Content-Length: 123\nFoo: bar\nFoo: baz\n'
    assert formatter_plugin_0.format_headers(str_arg_0) == 'Content-Length: 123\nFoo: bar\nFoo: baz\n'
    str_arg_0 = 'Foo: bar\nFoo: baz\nContent-Length: 123\n'

# Generated at 2022-06-25 18:48:06.973720
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    received = headers_formatter_1.format_headers('Content-Type: application/json\r\nContent-Length: 27\r\nHost: localhost:3000\r\nConnection: close\r\n')
    expected = '\r\n'.join(['Content-Length: 27', 'Content-Type: application/json', 'Connection: close', 'Host: localhost:3000'])
    assert received == expected


# Generated at 2022-06-25 18:48:12.311566
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers('HTTP/1.1 200 OK\r\n'
                                              'Content-Type: application/json; charset=utf-8\r\n'
                                              'Content-Length: 16\r\n'
                                              'Server: Werkzeug/0.14.1 Python/3.7.1\r\n'
                                              'Date: Wed, 17 Jul 2019 15:40:31 GMT\r\n\r\n') == 'HTTP/1.1 200 OK\r\n' \
                                                                                               'Content-Length: 16\r\n' \
                                                                                               'Content-Type: application/json; charset=utf-8\r\n' \
                                

# Generated at 2022-06-25 18:48:22.546996
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.enabled == False