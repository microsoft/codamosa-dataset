

# Generated at 2022-06-25 18:39:11.519932
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert (headers_formatter.format_options is None) == False, 'headers_formatter.format_options should not be None'
    format_options = headers_formatter.format_options
    assert format_options['headers']['sort'] == True, "Default value of 'sort' in headers format options dict should be True, but it is %s" % format_options['headers']['sort']
    assert 'headers' in format_options, "Default format options should contain 'headers' as one of its key, but it does not"
    assert 'sort' in format_options['headers'], "Default headers format options should contain 'sort' as one of its key, but it does not"


# Generated at 2022-06-25 18:39:12.745808
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert True


# Generated at 2022-06-25 18:39:24.316676
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json\nServer: meinheld/0.6.1\nDate: Wed, 24 Jun 2020 22:31:58 GMT\nX-Frame-Options: SAMEORIGIN\nContent-Length: 0\nVia: 1.1 vegur\n\n'
    assert headers_formatter_0.format_headers(headers)=='HTTP/1.1 200 OK\nContent-Length: 0\nContent-Type: application/json\nDate: Wed, 24 Jun 2020 22:31:58 GMT\nServer: meinheld/0.6.1\nVia: 1.1 vegur\nX-Frame-Options: SAMEORIGIN\n\n'



# Generated at 2022-06-25 18:39:31.945753
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK\r
X-Powered-By: Flask\r
Transfer-Encoding: chunked\r
Content-Type: application/json\r\n'''
    headers = headers_formatter_0.format_headers(headers)
    assert headers == '''HTTP/1.1 200 OK\r
Content-Type: application/json\r
Transfer-Encoding: chunked\r
X-Powered-By: Flask\r\n'''

# Generated at 2022-06-25 18:39:36.258961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()
    headers_0 = headers_formatter.format_headers('X-A: 1\r\nX-B: 2')
    assert headers_0 == 'X-A: 1\r\nX-B: 2'

    headers_1 = headers_formatter.format_headers('X-B: 2\r\nX-A: 1')
    assert headers_1 == 'X-B: 2\r\nX-A: 1'

# Generated at 2022-06-25 18:39:41.894003
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = '''\
GET / HTTP/1.1
Content-Length: 0
Host: localhost:8081
Connection: keep-alive
Cache-Control: no-cache'''
    assert headers_formatter_0.format_headers(headers) == '''\
GET / HTTP/1.1
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 0
Host: localhost:8081'''

# Generated at 2022-06-25 18:39:52.933048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = (
        'GET / HTTP/1.1\r\n'
        'Accept: application/json, */*\r\n'
        'Connection: keep-alive\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Connection: keep-alive\r\n'
        'Host: httpbin.org\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n\r\n'
    )

# Generated at 2022-06-25 18:39:57.670663
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers('Host: localhost\r\nUser-Agent: HTTPie/0.9.7\r\nAccept: */*') == 'Host: localhost\r\nAccept: */*\r\nUser-Agent: HTTPie/0.9.7'

# Generated at 2022-06-25 18:40:07.823549
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:40:09.050474
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_options == {'headers': {'sort': True}}



# Generated at 2022-06-25 18:40:23.055868
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

    # arguments
    args = ["Accept-Encoding: gzip", "Content-Length: 847", "Content-Type: application/json"]

    # body
    body = """{
    "id": "an-id",
    "name": "Mr. Smith",
    "address": {
        "street": "10 Downing Street",
        "city": "London"
    }
}"""

    # code
    code = 0

    # headers
    headers = {
        "Accept-Encoding": "gzip",
        "Content-Type": "application/json",
        "Content-Length": "847"
    }

    # json

# Generated at 2022-06-25 18:40:30.953767
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert type(headers_formatter_1) == HeadersFormatter
    assert headers_formatter_1.format_headers("abc\r\ndef\r\nghi\r\n") == "abc\r\ndef\r\nghi\r\n"
    assert headers_formatter_1.format_headers("abc\r\ndef\r\nghi") == "abc\r\ndef\r\nghi"
    assert headers_formatter_1.format_headers("") == ""
    assert headers_formatter_1.format_headers("abc: def") == "abc: def"

# Generated at 2022-06-25 18:40:42.590694
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

    case_data = [
        (
            'GET / HTTP/1.1\r\n'
            'Content-Length: 10\r\n'
            'Accept: */*\r\n'
            'Accept-Encoding: gzip, deflate\r\n'
            'Host: httpbin.org\r\n'
            'User-Agent: HTTPie/1.0.3\r\n',
            'GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nContent-Length: 10\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/1.0.3\r\n'
        )
    ]


# Generated at 2022-06-25 18:40:51.529327
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(
        'HTTP/1.1 200 OK\n'
        'Server: Apache-Coyote/1.1\n'
        'Cache-Control: max-age=10\n'
        'Content-Type: text/plain;charset=UTF-8\n'
        'Content-Length: 10\n'
        '\n'
    ) == (
        'HTTP/1.1 200 OK\n'
        'Cache-Control: max-age=10\n'
        'Content-Length: 10\n'
        'Content-Type: text/plain;charset=UTF-8\n'
        'Server: Apache-Coyote/1.1\n'
        '\n'
    )




# Generated at 2022-06-25 18:41:03.348679
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    req = '''GET / HTTP/1.1
Host: 127.0.0.1:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.0.0-dev
'''
    headers_formatter_1.format_headers(req) == '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: 127.0.0.1:5000
User-Agent: HTTPie/1.0.0-dev'''

    headers_formatter_2 = HeadersFormatter()

# Generated at 2022-06-25 18:41:13.044619
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers = headers_formatter_1.format_headers("""POST /post HTTP/1.1
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9


""")
    assert headers == """POST /post HTTP/1.1
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9


"""

# Generated at 2022-06-25 18:41:23.891845
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case 0: Test no-effect-case: when format_options['headers']['sort'] == false
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers('\r\nhello: world\r\nfoo: bar') == '\r\nhello: world\r\nfoo: bar'
    # Case 1: General use-case: when format_options['headers']['sort'] == true
    headers_formatter_1 = HeadersFormatter()
    headers_formatter_1.enabled = True
    assert headers_formatter_1.format_headers('\r\nhello: world\r\nfoo: bar') == '\r\nfoo: bar\r\nhello: world'
    # Case 2: Multi-headers-case: when the request has multiple headers

# Generated at 2022-06-25 18:41:25.308752
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert 1 == 1, 'Test failed'


# Generated at 2022-06-25 18:41:32.628670
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

    assert headers_formatter_0.format_headers('{\r\n    "Content-Type": "application/x-www-form-urlencoded"\r\n}') == '{\r\n    "Content-Type": "application/x-www-form-urlencoded"\r\n}'

# Generated at 2022-06-25 18:41:43.156113
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_0 = "Content-Type: application/json\r\n" \
                "Content-Length: 5\r\n" \
                "User-Agent: HTTPie/0.9.9\r\n" \
                "Host: httpbin.org:80"
    headers_1 = "Content-Length: 5\r\n" \
                 "Content-Type: application/json\r\n" \
                 "Host: httpbin.org:80\r\n" \
                 "User-Agent: HTTPie/0.9.9"
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers(headers_0) == headers_1

# Generated at 2022-06-25 18:41:57.579079
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Provided tests
    assert HeadersFormatter().format_headers("") == ""
    assert HeadersFormatter().format_headers("one: 1\ntwo: 2") == \
        "one: 1\ntwo: 2"
    assert HeadersFormatter().format_headers("one: 1\ntwo: 2\none: 3") == \
        "one: 1\none: 3\ntwo: 2"
    assert HeadersFormatter().format_headers("two: 2\none: 1\none: 3\nfour: 4") == \
        "one: 1\none: 3\nfour: 4\ntwo: 2"

    # Additional tests

# Generated at 2022-06-25 18:42:06.470895
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    headersformatter_0 = HeadersFormatter()
    headersformatter_0.enabled = True
    headers_0 = '''Date: Thu, 11 May 2017 15:40:27 GMT\r
Content-Type: application/json\r
Content-Length: 1234\r
\r
'''
    # Exercise
    str_0 = headersformatter_0.format_headers(headers_0)
    # Verify
    assert str_0 == '''Date: Thu, 11 May 2017 15:40:27 GMT\r
Content-Length: 1234\r
Content-Type: application/json\r
\r
''', 'Assertion failed'


# Generated at 2022-06-25 18:42:14.995168
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    test_value_1 = '''\
'''
    expected_value_1 = '''\
'''
    actual_value_1 = headers_formatter_1.format_headers(test_value_1)
    assert actual_value_1 == expected_value_1

    headers_formatter_2 = HeadersFormatter()
    test_value_2 = '''\
foo: bar'''
    expected_value_2 = '''\
foo: bar'''
    actual_value_2 = headers_formatter_2.format_headers(test_value_2)
    assert actual_value_2 == expected_value_2

    headers_formatter_3 = HeadersFormatter()

# Generated at 2022-06-25 18:42:15.494166
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert True



# Generated at 2022-06-25 18:42:22.291279
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Case with no headers
    input = 'No headers'
    expected = 'No headers'
    actual = headers_formatter.format_headers(input)
    assert actual == expected

    # Case headers are not sorted
    input = '''\
HTTP/1.1 200 OK
Server: CherryPy/3.2.4
Date: Sun, 20 Nov 2016 00:00:00 GMT
Content-Type: application/json;charset=utf-8
Cache-Control: no-cache
Content-Length: 80
'''

# Generated at 2022-06-25 18:42:24.553505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

    # Check if function returns str
    assert type(headers_formatter_1.format_headers("headers")) == str

# Generated at 2022-06-25 18:42:33.046099
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers(' Connection: close\nHost: localhost:8000\nUser-Agent: HTTPie/0.9.9\n\n') == ' Connection: close\nHost: localhost:8000\nUser-Agent: HTTPie/0.9.9\n\n'

# Generated at 2022-06-25 18:42:44.390129
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case 0
    headers_formatter_0 = HeadersFormatter()
    headers_0 = '''HTTP/1.1 200 OK\r
Date: Tue, 14 May 2019 02:18:54 GMT\r
Server: Apache/2.4.43 (Unix)\r
DAV: 1,2,1\r
DAV: <http://apache.org/dav/propset/fs/1>\r
Last-Modified: Tue, 14 May 2019 02:18:54 GMT\r
Accept-Ranges: bytes\r
Content-Length: 5\r
Content-Type: text/plain\r
\r
12345'''

# Generated at 2022-06-25 18:42:55.193200
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.enabled == False
    
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.enabled == False
    
    headers_formatter_2 = HeadersFormatter()
    assert headers_formatter_2.enabled == False
    
    headers_formatter_3 = HeadersFormatter()
    assert headers_formatter_3.enabled == False
    
    headers_formatter_4 = HeadersFormatter()
    assert headers_formatter_4.enabled == False
    
    headers_formatter_5 = HeadersFormatter()
    assert headers_formatter_5.enabled == False
    
    headers_formatter_6 = HeadersFormatter()

# Generated at 2022-06-25 18:43:03.705098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Sample headers
    headers_formatter_sample_headers = HeadersFormatter()
    headers_formatter_sample_headers.format_options['headers']['sort'] = True
    headers_formatter_sample_headers.format_options['headers']['show'] = True
    headers = "HTTP/1.1 200 OK\r\nContent-Length: 10\r\nContent-Type: text/plain; charset=utf-8\r\nDate: Mon, 03 Aug 2015 16:59:10 GMT\r\nServer: nginx/1.6.2\r\nX-Powered-By: Flask\r\n\r\n"
    sample_headers = headers_formatter_sample_headers.format_headers(headers)

# Generated at 2022-06-25 18:43:15.673830
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_test_0 = HeadersFormatter()
    headers_test_1 = HeadersFormatter()
    headers_test_2 = HeadersFormatter()
    assert (headers_test_0.format_options == {'headers': {'sort': True}})
    assert (headers_test_0.format_options == headers_test_1.format_options)
    assert (headers_test_1.format_options == headers_test_2.format_options)


# Generated at 2022-06-25 18:43:25.515820
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Unit test for method format_headers of class HeadersFormatter
    headers_formatter_0 = HeadersFormatter()

    headers = '''connection: close
content-length: 11
content-type: text/html; charset=UTF-8
date: Fri, 05 Oct 2018 09:11:58 GMT
server: meinheld/0.6.1
'''
    result_headers = headers_formatter_0.format_headers(headers)
    assert result_headers == '''connection: close
content-length: 11
content-type: text/html; charset=UTF-8
date: Fri, 05 Oct 2018 09:11:58 GMT
server: meinheld/0.6.1
'''


# Generated at 2022-06-25 18:43:34.836498
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_formatter_0.enabled = True
    result = headers_formatter_0.format_headers("Accept: */*\r\ncache-control: no-cache\r\nUser-Agent: " \
                                                "HTTPie/1.0.0-dev\r\n\r\n")
    assert result == "Accept: */*\r\nUser-Agent: HTTPie/1.0.0-dev\r\ncache-control: no-cache\r\n\r\n"

# Test if method format_headers of class HeadersFormatter does not sort headers if disabled

# Generated at 2022-06-25 18:43:36.336399
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()


# Generated at 2022-06-25 18:43:46.852967
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    input_1 = """\
HTTP/1.1 200 OK
Content-Type: application/json
Link: <https://httpbin.org/get?a=1&b=2>; rel="previous"
Link: <https://httpbin.org/get?a=3&b=4>; rel="next"
Set-Cookie: fake=cookie
Vary: Accept-Encoding

"""

# Generated at 2022-06-25 18:43:47.996788
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False


# Generated at 2022-06-25 18:43:49.139029
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-25 18:43:54.478620
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    r = headers_formatter_1.format_headers("foo: bar\r\nx-x: foo\r\nfoo: baz")
    assert(r == "foo: bar\r\nfoo: baz\r\nx-x: foo")


# Generated at 2022-06-25 18:44:06.837082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test case - 0
    headers_formatter_0 = HeadersFormatter()
    headers_0 = ('HTTP/1.1 200 OK\r\n'
         'Content-Length: 19\r\n'
         'Content-Type: text/html; charset=UTF-8\r\n'
         'Server: Werkzeug/0.10.4 Python/2.7.6\r\n'
         'Date: Mon, 04 Sep 2017 14:07:01 GMT\r\n'
         'X-Frame-Options: SAMEORIGIN')

# Generated at 2022-06-25 18:44:09.456944
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert(HeadersFormatter)


# Generated at 2022-06-25 18:44:25.446286
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_options['headers']['sort'] == False


# Generated at 2022-06-25 18:44:32.724082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter(format_options={'headers':{'sort':True}})

    headers_test_0 = """
"""
    assert headers_formatter.format_headers(headers_test_0) == headers_test_0

    headers_test_1 = """
HTTP/1.1 200 OK
Content-Length: 0
Server: TornadoServer/4.3
"""
    assert headers_formatter.format_headers(headers_test_1) == headers_test_1

    headers_test_2 = """
HTTP/1.1 200 OK
Server: TornadoServer/4.3
Content-Length: 0
"""
    assert headers_formatter.format_headers(headers_test_2) == headers_test_1


# Generated at 2022-06-25 18:44:37.071794
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    i = 0
    while i <= 1000:
        input_headers = ''
        output_headers = headers_formatter_0.format_headers(input_headers)
        assert output_headers == ''
        i += 1


# Generated at 2022-06-25 18:44:45.832630
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nETag: "34aa387-d-1568eb00"\r\nAccept-Ranges: bytes\r\nContent-Length: 51\r\nVary: Accept-Encoding\r\nContent-Type: text/plain'''

# Generated at 2022-06-25 18:44:46.527439
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    pass

# Generated at 2022-06-25 18:44:56.158077
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-25 18:45:06.809589
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers(): 
    raw_headers = '''Content-Type: application/json\r
Accept: application/json\r
User-Agent: HTTPie/0.9.9\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
'''
    expected_headers = '''Content-Type: application/json\r
Accept: application/json\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
User-Agent: HTTPie/0.9.9\r
'''
    headers_formatter = HeadersFormatter()
    headers_formatter.enabled = True
    actual_headers = headers_formatter.format_headers(raw_headers)
    assert actual_headers == expected_headers

# Generated at 2022-06-25 18:45:17.429095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    # Set-Cookie: dict: 18, Time: 1567336765.968072,
    # Set-Cookie: cookie: 18, Time: 1567336765.968072,
    # Content-Type: application/json, Time: 1567336765.968072,


# Generated at 2022-06-25 18:45:27.467291
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    #Test #1
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': False}}
    headers = headers_formatter.format_headers(
        """
Host: httpbin.org
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: HTTPie/0.9.4
"""
    )
    expected_headers = headers
    assert headers == expected_headers

    #Test #2
    headers_formatter.format_options['headers']['sort'] = True
    headers = headers_formatter.format_headers(
        """
Host: httpbin.org
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: HTTPie/0.9.4
"""
    )
    expected

# Generated at 2022-06-25 18:45:36.778960
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = headers_formatter_0.format_headers("X-Auth-Token: b1eab7c8-14b0-46a3-b417-fb7dd22d0e9e\r\nContent-Type: application/json\r\nContent-Length: 489\r\nHost: api.foo.com\r\nUser-Agent: httpie/0.9.9\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nConnection: keep-alive")
    print(headers)

# Generated at 2022-06-25 18:46:32.320710
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    str_1 = headers_formatter_1.format_headers(headers)
    print(str_1)
    print('\n=============================================\n')
    print('headers:\n' + headers)


# Generated at 2022-06-25 18:46:40.589238
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    inputs = {"headers" : ""}
    headers_formatter = HeadersFormatter(inputs)
    actual = headers_formatter.format_headers(inputs["headers"])
    expected = ""
    assert expected == actual, "Actual result is " + actual

    inputs = {"headers" : "HTTP/1.1 200 OK\r\nX-Foo: Bar\r\nConnection: Keep-Alive\r\nContent-Length: 0\r\n"}
    headers_formatter = HeadersFormatter(inputs)
    actual = headers_formatter.format_headers(inputs["headers"])
    expected = "HTTP/1.1 200 OK\r\nConnection: Keep-Alive\r\nContent-Length: 0\r\nX-Foo: Bar\r\n"
    assert expected == actual

# Generated at 2022-06-25 18:46:42.451680
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_headers = HeadersFormatter()
    assert formatter_headers.format_headers('sdd') == 'sdd'

# Generated at 2022-06-25 18:46:46.444770
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
c: d
a: b
C: D
B: E'''

    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
a: b
B: E
C: D
c: d'''



# Generated at 2022-06-25 18:46:56.892832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test 1
    headers_formatter_1 = HeadersFormatter()
    headers_1 = '''\
HTTP/1.1 200 OK
Host: httpbin.org
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.2
'''
    headers_out_1 = headers_formatter_1.format_headers(headers_1)
    headers_expected_1 = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Accept: */*
Accept-Encoding: gzip, deflate
Host: httpbin.org
User-Agent: HTTPie/0.9.2
'''
    assert headers_out_1 == headers_expected_1
    # Test 2
    headers_formatter_2 = Headers

# Generated at 2022-06-25 18:47:04.883733
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print("TEST: method 'format_headers' of class 'HeadersFormatter'")
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-25 18:47:12.171036
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test 0
    def test_HeadersFormatter_format_headers_0():
        headers_formatter_0 = HeadersFormatter()
        headers = "Content-Length: 18\r\nContent-Type: application/x-www-form-urlencoded; charset=utf-8\r\n\r\n"
        assert headers_formatter_0.format_headers(headers=headers) == "Content-Length: 18\r\nContent-Type: application/x-www-form-urlencoded; charset=utf-8\r\n\r\n"


# Generated at 2022-06-25 18:47:15.354594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter_0 = HeadersFormatter()
    headers = 'foo: bar\r\nalpha: beta\r\n'
    assert headers_formatter_0.format_headers(headers) == 'foo: bar\r\nalpha: beta\r\n'

# Generated at 2022-06-25 18:47:15.852922
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    pass



# Generated at 2022-06-25 18:47:25.225813
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    str_arg_0 = "Accept: application/json\nAccept-Encoding: gzip, deflate\nAuthorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==\nConnection: keep-alive\nContent-Length: 43\nContent-Type: application/json\nHost: echo.paw.cloud\nUser-Agent: HTTPie/0.9.9\n"

# Generated at 2022-06-25 18:48:35.097599
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:48:40.263345
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    assert headers_formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type:application/json\r\nContent-Length:1234') == 'HTTP/1.1 200 OK\r\nContent-Length:1234\r\nContent-Type:application/json\r\n'



# Generated at 2022-06-25 18:48:48.827074
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:48:54.078820
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = headers_formatter_0.format_headers("Date: Sat, 29 Sep 2018 18:01:31 GMT\r\nContent-Length: 46\r\n\r\n")
    assert headers == "Date: Sat, 29 Sep 2018 18:01:31 GMT\r\nContent-Length: 46\r\n\r\n"


# Generated at 2022-06-25 18:48:57.145787
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter_0 = HeadersFormatter()

    # Case 0

# Generated at 2022-06-25 18:49:02.005529
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers_0 = '''Host: postman-echo.com\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive'''

    headers_1 = '''Accept: */*\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
Host: postman-echo.com'''

    assert headers_formatter.format_headers(headers_0) == headers_1