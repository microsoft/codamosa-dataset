

# Generated at 2022-06-25 18:39:08.760581
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 47\r
\r
'''
    expected_result = '''\
HTTP/1.1 200 OK\r
Content-Length: 47\r
Content-Type: application/json\r
\r
'''
    result = hf.format_headers(headers)
    assert result == expected_result

# Generated at 2022-06-25 18:39:10.074353
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter() != None


# Generated at 2022-06-25 18:39:15.220823
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    str_arg_0 = "\n        Content-Type: application/json\n        Foo: Bar\n        Foo: Baz\n    "
    assert headers_formatter_0.format_headers(str_arg_0) == "\n        Content-Type: application/json\n        Foo: Bar\n        Foo: Baz\n    "

# Generated at 2022-06-25 18:39:25.888142
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nHost: example.com\r\nContent-Type: text/json; charset=utf-8\r\nContent-Length: 32\r\n\r\n{"foo": "bar", "bar": "foo"}\r\n'
    # Call the method
    result = headers_formatter_0.format_headers(headers)
    # Check the result
    assert result == 'HTTP/1.1 200 OK\r\nContent-Length: 32\r\nContent-Type: text/json; charset=utf-8\r\nHost: example.com\r\n\r\n{"foo": "bar", "bar": "foo"}\r\n'

# Generated at 2022-06-25 18:39:35.980001
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # HTTP/1.1 200 OK
    # Date: Sat, 11 Apr 2020 15:58:14 GMT
    # Server: Apache/2.4.18 (Ubuntu)
    # Vary: Accept-Encoding
    # Content-Length: 799
    # Connection: close
    # Content-Type: text/html

    headers = """HTTP/1.1 200 OK
Date: Sat, 11 Apr 2020 15:58:14 GMT
Server: Apache/2.4.18 (Ubuntu)
Vary: Accept-Encoding
Content-Length: 799
Connection: close
Content-Type: text/html
"""
    headers_formatter = HeadersFormatter()
    headers_out = headers_formatter.format_headers(headers)

# Generated at 2022-06-25 18:39:41.763028
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

    headers_input = '''Host: localhost:5000
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9


'''
    headers_output = '''Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.9


'''

    assert type(headers_formatter_1) == HeadersFormatter
    assert headers_formatter_1.format_headers(headers_input) == headers_output

# Generated at 2022-06-25 18:39:52.810793
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(headers=None)
        assert(excinfo.value.code == 'Header format options are required')
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(headers={'sort': None})
        assert(excinfo.value.code == 'Header sort is required')
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(headers={'sort': True})
        assert(excinfo.value.code == 'Header formatter is required')
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(headers=[])
        assert(excinfo.value.code == 'Header format options are missing')
    with pytest.raises(Exception) as excinfo:
        HeadersForm

# Generated at 2022-06-25 18:40:03.179766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers: str = "GET / HTTP/1.1\r\nUser-Agent: HTTPie/0.9.9\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nHost: localhost\r\nContent-Length: 0\r\nConnection: keep-alive\r\n\r\n"
    expected_headers: str = "GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Length: 0\r\nHost: localhost\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n"

# Generated at 2022-06-25 18:40:10.750696
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Server: gunicorn/19.9.0
Date: Sat, 02 Mar 2019 14:10:58 GMT
Connection: close
Content-Length: 20
Content-Type: text/plain; charset=utf-8
\r\n
"""
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers=headers) == """\
HTTP/1.1 200 OK
Content-Length: 20
Content-Type: text/plain; charset=utf-8
Connection: close
Date: Sat, 02 Mar 2019 14:10:58 GMT
Server: gunicorn/19.9.0
\r\n
"""


# Generated at 2022-06-25 18:40:22.959962
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    input_headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccept: application/json\r\nAuthorization: Basic Zph5bjpzZWM=\r\nConnection: keep-alive\r\nHost: 127.0.0.1:8000\r\nUser-Agent: HTTPie/0.9.9\r\nCookie: sessionid=52310f4551f139f8fd7fd9cee50fda7b'
    sorted_output = headers_formatter.format_headers(input_headers)

# Generated at 2022-06-25 18:40:31.141396
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_1 = HeadersFormatter(formatter=None,
                                           format_options={'headers': {'pretty': False, 'sort': True, 'colors': False}})

    headers_formatter_2 = HeadersFormatter(formatter=None,
                                           format_options={'headers': {'pretty': True, 'sort': False, 'colors': False}})

    headers_formatter_3 = HeadersFormatter(formatter=None,
                                           format_options={'headers': {'pretty': False, 'sort': False, 'colors': False}})

    assert headers_formatter_1.enabled == True
    assert headers_formatter_2.enabled == False
    assert headers_formatter_3.enabled == False


# Generated at 2022-06-25 18:40:42.444206
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(
        """
        GET /get HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        Host: httpbin.org
        User-Agent: HTTPie/0.9.6

        """
    ) == '\r\n    GET /get HTTP/1.1\r\n    Accept: */*\r\n    Accept-Encoding: gzip, deflate\r\n    Connection: keep-alive\r\n    Host: httpbin.org\r\n    User-Agent: HTTPie/0.9.6\r\n\r\n    '


# Generated at 2022-06-25 18:40:44.281305
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter != None


# Generated at 2022-06-25 18:40:52.635742
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

# Generated at 2022-06-25 18:40:58.699381
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 0\r\n'
        'X-Header-1: abc\r\n'
        'X-Header-2: def\r\n'
        'X-Header-1: xyz\r\n'
        '\r\n'
    )
    expected = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 0\r\n'
        'X-Header-1: abc\r\n'
        'X-Header-1: xyz\r\n'
        'X-Header-2: def\r\n'
        '\r\n'
    )
    headers_formatter_0 = HeadersFormatter()
    assert headers

# Generated at 2022-06-25 18:41:01.391956
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.enabled == True


# Generated at 2022-06-25 18:41:11.485822
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\n\
    Date: Tue, 11 May 2021 03:26:59 GMT\n\
    Server: Apache/2.4.46 (Unix)\n\
    Last-Modified: Mon, 10 May 2021 01:45:03 GMT\n\
    ETag: \"3d-5a1d9245a3b73\"\n\
    Accept-Ranges: bytes\n\
    Content-Length: 1073\n\
    Content-Type: text/html\n\
    \n\
    "

# Generated at 2022-06-25 18:41:22.655065
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Initialize object of class HeadersFormatter
    headers_formatter = HeadersFormatter()

    # Assign return of method format_headers to variable headers
    headers=headers_formatter.format_headers('HTTP/1.1 200 OK\r\ncontent-length: 2\r\ncontent-type: text/html; charset=utf-8\r\nServer: Werkzeug/0.15.4 Python/3.7.4\r\ndate: Sat, 27 Jun 2020 10:32:36 GMT\r\n')

# Generated at 2022-06-25 18:41:29.745728
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers('GET / HTTP/1.1\r\nHost: localhost:8080\r\nUser-Agent: HTTPie/0.9.9\r\nAccept-Encoding: gzip, deflate, compress\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n') == 'GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, compress\r\nConnection: keep-alive\r\nHost: localhost:8080\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n'


# Generated at 2022-06-25 18:41:41.824593
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

# Generated at 2022-06-25 18:41:58.151964
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers = "line0\nline1\nline2\nline3\nline4"
    expected_result = "line0\nline1\nline2\nline3\nline4"
    assert expected_result == headers_formatter_1.format_headers(headers)
    headers = "line0\nline3\nline2\nline1\nline4"
    expected_result = "line0\nline1\nline2\nline3\nline4"
    assert expected_result == headers_formatter_1.format_headers(headers)
    headers = "line0\nline3\nline2\nline2\nline1\nline4"

# Generated at 2022-06-25 18:42:03.649917
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        headers_formatter_0 = HeadersFormatter()
    except Exception:
        pytest.fail("Construction of HeadersFormatter failed")
    else:
        assert headers_formatter_0

# Generated at 2022-06-25 18:42:05.488666
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.enabled == True


# Generated at 2022-06-25 18:42:12.786581
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers('Accept: */*\r\nContent-Length: 0\r\nContent-Type: text/plain; charset=utf-8\r\nHost: www.baidu.com\r\nUser-Agent: HTTPie/1.0.3\r\n') == 'Accept: */*\r\nContent-Length: 0\r\nContent-Type: text/plain; charset=utf-8\r\nHost: www.baidu.com\r\nUser-Agent: HTTPie/1.0.3\r\n'


# Generated at 2022-06-25 18:42:20.296744
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers_0 = headers_formatter_1.format_headers(
        'Content-Type: application/json\r\nContent-Length: 9\r\n')
    headers_1 = headers_formatter_1.format_headers(
        'Content-Length: 9\r\nContent-Type: application/json\r\n')

    if headers_0 == headers_1:
        print('\ntest_HeadersFormatter_format_headers')
        print('format_headers() returns the same result as expected!\n')
        print('Expected:', headers_0)
        print('Actual:  ', headers_1)
    else:
        raise Exception('This code should not be reached!')

# Generated at 2022-06-25 18:42:21.724265
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    p1 = HeadersFormatter()
    assert p1 is not None



# Generated at 2022-06-25 18:42:25.043872
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Header1: Value1\nHeader2: Value2\nHeader3: Value3') == 'Header1: Value1\nHeader2: Value2\nHeader3: Value3'



# Generated at 2022-06-25 18:42:30.017406
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    # Arguments: headers
    headers_formatter_1.format_headers(headers="Accept: image/png\r\nContent-Type: image/jpeg\r\n")
    headers_formatter_1.format_headers(headers="Content-Type: image/jpeg\r\nAccept: image/png\r\n")


# Generated at 2022-06-25 18:42:39.713689
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_test = HeadersFormatter()
    assert headers_formatter_test.format_headers('HTTP/1.1 200 OK\r\nBasic:header 1\r\nAB:header 2\r\nAB:header 3\r\nAB:header 4') == 'HTTP/1.1 200 OK\r\nAB:header 2\r\nAB:header 3\r\nAB:header 4\r\nBasic:header 1'
    assert headers_formatter_test.format_headers('HTTP/1.1 200 OK\r\nBasic:header 1') == 'HTTP/1.1 200 OK\r\nBasic:header 1'


# Generated at 2022-06-25 18:42:46.757129
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers = headers_formatter.format_headers("""Content-type: application/json
X-Auth-Token: 41787
Host: 10.0.0.1:8080
Connection: Keep-Alive
Content-Length: 1450""")

    assert headers == """Content-type: application/json
Content-Length: 1450
Connection: Keep-Alive
Host: 10.0.0.1:8080
X-Auth-Token: 41787\r\n"""

# Generated at 2022-06-25 18:43:05.773501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    class socket_0():
        def __init__(self):
            self.headers = "Connection: close\r\nAccept: application/json, */*\r\nContent-Type: application/json\r\n"

# test for case 1 (happy way)
    assert headers_formatter_0.format_headers(socket_0().headers) == "Connection: close\r\nAccept: application/json, */*\r\nContent-Type: application/json"

# test for case 2 (without headers)
    class socket_1():
        def __init__(self):
            self.headers = ""

    assert headers_formatter_0.format_headers(socket_1().headers) == ""

# test for case 3 (with blank headers)

# Generated at 2022-06-25 18:43:15.183064
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_str = '''\
GET / HTTP/1.1
Accept: */*
Connection: keep-alive
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.11.3
'''
    expected_headers_str = '''\
GET / HTTP/1.1
Accept: */*
Connection: keep-alive
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.11.3
'''
    headers_formatter_1 = HeadersFormatter()
    headers_formatter_1.format_options['headers']['sort'] = False
    headers_formatted = headers_formatter_1.format_headers(headers_str)
    assert headers_formatted == expected_headers_str


# Generated at 2022-06-25 18:43:22.581182
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class_0 = HeadersFormatter()
    try:
        assert class_0.format_headers("GET / HTTP/1.1\r\nA: a\r\nB: b\r\n") == "GET / HTTP/1.1\r\nA: a\r\nB: b\r\n"
    except AssertionError:
        print('test_HeadersFormatter_format_headers failed!')
        return
    print('test_HeadersFormatter_format_headers passed!')


# Generated at 2022-06-25 18:43:28.903998
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    result = headers_formatter_1.format_headers("Accept: */*\r\nAccept-Encoding: gzip, deflate\r\n\
        Connection: keep-alive\r\nContent-Type: application/json\r\nDNT: 1\r\nHost: \
        132.230.1.1:5555\r\nUser-Agent: HTTPie/0.9.9\r\nX-Amzn-Trace-Id: Root=1-5f0d2c03-\
        5ab4d9a9e84ca284b3e92b3a\r\nX-Forwarded-For: 100.0.0.1")

# Generated at 2022-06-25 18:43:31.752262
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        headers_formatter_0 = HeadersFormatter()
        headers_formatter_0
    except:
        print('Code did not run')


# Generated at 2022-06-25 18:43:43.164785
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    bytes_str_0 = headers_formatter_0.format_headers('Cookie: JSESSIONID=BC6F23E6D1B551A46C6143D9C6826D9B\r\nContent-Type: application/json\r\nAccept: */*\r\nHost: localhost:8080\r\nUser-Agent: HTTPie/2.0.0\r\nConnection: keep-alive')

# Generated at 2022-06-25 18:43:45.062091
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(True)
    assert HeadersFormatter()
    assert HeadersFormatter(False)


# Generated at 2022-06-25 18:43:53.912566
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = ''
    expected_result = ''
    result = headers_formatter_0.format_headers(headers)
    assert result == expected_result
    headers = '''\
HTTP/1.1 200 OK
b: 1
A: 2
c: 3
'''
    expected_result = '''\
HTTP/1.1 200 OK
A: 2
b: 1
c: 3
'''
    result = headers_formatter_0.format_headers(headers)
    assert result == expected_result


# Generated at 2022-06-25 18:43:55.060037
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__


# Generated at 2022-06-25 18:44:07.060421
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    # list of string
    headers = headers_formatter_0.format_headers('''HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 18\r\nConnection: keep-alive\r\nDate: Mon, 12 Sep 2016 23:45:20 GMT\r\nServer: uvicorn\r\n\r\n{"message": "success"}''')
    assert headers == 'HTTP/1.1 200 OK\r\nConnection: keep-alive\r\nContent-Length: 18\r\nContent-Type: application/json\r\nDate: Mon, 12 Sep 2016 23:45:20 GMT\r\nServer: uvicorn\r\n\r\n{"message": "success"}'

# Generated at 2022-06-25 18:44:28.665680
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

    headers='GET / HTTP/1.1\r\nCache-Control: max-age=0\r\nAuthorization: Basic YWRtaW46YWRtaW4=\r\n' \
    'Accept-Encoding: gzip, deflate\r\nAccept: */*\r\nAccept-Language: en-US,en;q=0.5\r\n' \
    'Connection: keep-alive\r\nHost: httpbin.org\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0\r\n'

    actual = headers_formatter.format_headers(headers)
    print(actual)


# Generated at 2022-06-25 18:44:39.410743
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_formatter_0.format_options['headers']['sort'] = True

# Generated at 2022-06-25 18:44:46.924011
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    headers_1 = '''\
HTTP/1.1 200 OK
Server: nginx/1.8.0
Date: Sat, 19 Aug 2017 08:29:39 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 2
Connection: keep-alive
Etag: W/"2-up+MsLFgI+eL5zBOJnQ/oQg"
Vary: Accept-Encoding
X-Powered-By: Express
ETag: W/"2-up+MsLFgI+eL5zBOJnQ/oQg"
Content-Encoding: gzip
'''

# Generated at 2022-06-25 18:44:53.733640
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter_1 = \
        HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_formatter_2 = \
        HeadersFormatter(format_options={'headers': {'sort': False}})
    headers_formatter_3 = \
        HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_formatter_4 = \
        HeadersFormatter(format_options={'headers': {'sort': False}})

# Tests for method format_headers

# Generated at 2022-06-25 18:44:55.407888
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__(HeadersFormatter()) is not None


# Generated at 2022-06-25 18:45:04.470879
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Call format_headers method of class HeadersFormatter
    headers_formatter_0 = HeadersFormatter()
    # Assert that actual and expected outputs are equal
    assert(headers_formatter_0.format_headers('Accept: */*\r\nContent-Length: 11\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n') == 'Accept: */*\r\nContent-Length: 11\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n')



# Generated at 2022-06-25 18:45:09.025033
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    output = headers_formatter_1.format_headers('''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 23
Date: Mon, 27 Jul 2015 22:33:59 GMT
''')
    assert output == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 23
Date: Mon, 27 Jul 2015 22:33:59 GMT'''

# Generated at 2022-06-25 18:45:18.663299
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()


# Generated at 2022-06-25 18:45:26.717325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    assert headers_formatter_1.format_headers('HTTP_1_1\r\nContent-Type:text\r\ncontent-length:5\r\nDATE:Wed, 13 Sep 2017 16:57:10 GMT\r\nServer:localhost\r\n\r\n') == 'HTTP_1_1\r\nContent-Type:text\r\nDATE:Wed, 13 Sep 2017 16:57:10 GMT\r\ncontent-length:5\r\nServer:localhost\r\n\r\n'



# Generated at 2022-06-25 18:45:30.479712
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    assert headers_formatter_0.format_headers("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 22\r\nConnection: close") == "HTTP/1.1 200 OK\r\nContent-Length: 22\r\nContent-Type: application/json\r\nConnection: close"

# Generated at 2022-06-25 18:46:05.968629
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers_formatter_0.format_headers("""Connection: keep-alive
    Content-Encoding: gzip
    Content-Length: 797
    Content-Type: text/html
    Date: Fri, 15 Apr 2016 18:49:57 GMT
    Server: Apache
    Vary: Accept-Encoding""")


# Generated at 2022-06-25 18:46:15.179904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers_dict_0 = {'Accept-Encoding': 'gzip, deflate', 'Host': 'httpbin.org', 'User-Agent': 'python-requests/2.22.0'}
    headers_0 = '\r\n'.join(['{}: {}'.format(k, v) for k, v in headers_dict_0.items()])
    assert headers_formatter.format_headers(headers_0) == headers_0

    headers_dict_1 = {'Accept-Encoding': 'gzip, deflate', 'Host': 'httpbin.org', 'User-Agent': 'python-requests/2.22.0', 'x-some-header': 'some-value'}

# Generated at 2022-06-25 18:46:24.001847
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()

# Generated at 2022-06-25 18:46:32.813716
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    # Test with the header string from the example in the documentation
    headers = 'Content-Length: 0\r\nConnection: keep-alive\r\nContent-Type: application/json; charset=utf-8\r\nHost: localhost:5000\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\n'
    expected_headers = 'Content-Length: 0\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Type: application/json; charset=utf-8\r\nHost: localhost:5000\r\n'
    assert headers_formatter_0.format_headers(headers) == expected_headers

# Generated at 2022-06-25 18:46:41.190535
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-25 18:46:50.041587
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    result = headers_formatter_0.format_headers("HTTP/1.1 200 OK\r\nDate: Tue, 15 Nov 1994 08:12:31 GMT\r\nServer: Apache/1.1.1\r\n\r\n")
    assert result == "HTTP/1.1 200 OK\r\nDate: Tue, 15 Nov 1994 08:12:31 GMT\r\nServer: Apache/1.1.1\r\n\r\n"
    result = headers_formatter_0.format_headers("HTTP/2.0 200 OK\r\n")
    assert result == "HTTP/2.0 200 OK\r\n"

# Generated at 2022-06-25 18:47:00.030127
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert headers_formatter_0.format_headers(
        'GET / HTTP/1.1\r\nHost: www.google.com\r\nUser-Ag'
        'ent: python-requests/2.18.4\r\nAccept-Encoding: gzip\r\nAcce'
        'pt: */*\r\nConnection: keep-alive\r\n\r\n') == 'GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip\r\nConnection: keep-alive\r\nHost: www.google.com\r\nUser-Agent: python-requests/2.18.4\r\n\r\n'

headers_formatter_0 = HeadersFormatter()


# Generated at 2022-06-25 18:47:06.624274
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import HeadersFormatter
    headers_formatter = HeadersFormatter.HeadersFormatter()

# Generated at 2022-06-25 18:47:15.532804
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_a_original = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 199
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 23 Dec 2018 19:36:40 GMT

'''
    headers_b_original = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Server: gunicorn/19.9.0
Content-Type: application/json
Content-Length: 199
Date: Sun, 23 Dec 2018 19:36:40 GMT

'''

# Generated at 2022-06-25 18:47:20.729054
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    str_arg_0 = "x-header-1: 1\r\nx-header-2: 2\r\nx-header-3: 3"
    assert headers_formatter_0.format_headers(str_arg_0) == "x-header-1: 1\r\nx-header-2: 2\r\nx-header-3: 3"


# Generated at 2022-06-25 18:48:21.349693
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
foo: baz
Content-Type: application/json
foo: bar
"""
    headers_formatter_0 = HeadersFormatter()

    headers_0 = headers_formatter_0.format_headers(headers)
    print(headers_0)
    assert headers_0 == """
HTTP/1.1 200 OK
Content-Type: application/json
foo: bar
foo: baz
"""


# Generated at 2022-06-25 18:48:32.436332
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()
    headers = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.8
"""
    expected = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.8
"""
    headers_formatter_0.enabled = False
    actual = headers_formatter_0.format_headers(headers)
    assert actual == expected


# Generated at 2022-06-25 18:48:43.274145
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_0 = HeadersFormatter()

# Generated at 2022-06-25 18:48:50.095302
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 0
    headers_formatter_0 = HeadersFormatter()
    headers_0 = '''HTTP/1.1 200 OK\r\nCache-Control: no-cache, private\r\nContent-Type: application/json\r\nDate: Wed, 18 Oct 2017 04:11:26 GMT\r\nServer: TornadoServer/4.4.2\r\nX-Frame-Options: DENY\r\nContent-Length: 47\r\n\r\n'''


# Generated at 2022-06-25 18:48:59.855071
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_string = 'HTTP/1.1 200 OK\r\n' \
                     'Connection: keep-alive\r\n' \
                     'Content-Encoding: gzip\r\n' \
                     'Content-Length: 209\r\n' \
                     'Content-Type: text/html\r\n' \
                     'Date: Mon, 23 Jan 2017 16:02:39 GMT\r\n' \
                     'Server: TornadoServer/4.4.2\r\n' \
                     'Vary: Cookie, Accept-Encoding\r\n' \
                     'Via: 1.1 vegur\r\n' \
                     '\r\n'
    headers_formatter = HeadersFormatter()
    test_headers_string = headers_formatter.format_headers(headers_string)
    #

# Generated at 2022-06-25 18:49:09.632994
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_1 = HeadersFormatter()
    input_headers_1 = '''GET / HTTP/1.1\r
User-Agent: httpie\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Host: localhost:8080\r
\r
'''
    assert (headers_formatter_1.format_headers(input_headers_1) == '''GET / HTTP/1.1\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Host: localhost:8080\r
User-Agent: httpie\r
\r
''')