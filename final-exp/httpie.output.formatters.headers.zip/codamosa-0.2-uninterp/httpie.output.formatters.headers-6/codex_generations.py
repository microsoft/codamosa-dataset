

# Generated at 2022-06-17 20:35:20.078617
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: W/"f9f5e7b0f9f5e7b0f9f5e7b0f9f5e7b0"
X-Request-Id: d9a9f9f0-a9a9-4f9f-9f9f-9f9f9f9f9f9f
X-Runtime: 0.002929
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:35:30.026453
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8
'''

# Generated at 2022-06-17 20:35:31.424599
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:33.808716
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:40.876031
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 88
Content-Type: text/html
Connection: Closed
Date: Mon, 27 Jul 2009 12:28:53 GMT
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Server: Apache/2.2.14 (Win32)
'''

# Generated at 2022-06-17 20:35:43.903508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled == True
    assert HeadersFormatter(format_options={'headers': {'sort': False}}).enabled == False


# Generated at 2022-06-17 20:35:52.772558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: aa5c8b5c-d3a1-4c8d-b7a2-b9dc9d6c7d6d
ETag: W/"a7c50c92f5c23f9e9d61ae2e6ef7b406"
X-Runtime: 0.005583
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:35:55.228947
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:00.880868
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:36:05.609585
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 27 Jun 2019 09:05:34 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 27 Jun 2019 09:05:34 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:36:08.716884
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:13.156203
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
Content-Length: 5
Content-Type: application/json
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Length: 5
Content-Type: application/json
Content-Type: application/json
Connection: close
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:24.166193
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 6f5c5e5e-c5a5-4d5e-b5e5-5e5e5e5e5e5e
X-Runtime: 0.012345
Content-Length: 13
Connection: close
Date: Wed, 16 Oct 2013 10:06:20 GMT
Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-05-14)
X-Powered-By: Phusion Passenger 4.0.5
'''

# Generated at 2022-06-17 20:36:25.797359
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:27.359535
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:38.672655
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Tue, 19 May 2020 20:59:44 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00138092041015625
Via: 1.1 vegur

"""

# Generated at 2022-06-17 20:36:48.449858
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:53.460275
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST / HTTP/1.1
Host: example.org
Content-Type: application/json
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2

{}'''
    expected = '''\
POST / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Host: example.org

{}'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:54.622750
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:58.727312
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: keep-alive
Date: Wed, 20 May 2020 09:35:21 GMT
Server: gunicorn/19.9.0
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 12
Content-Type: application/json
Date: Wed, 20 May 2020 09:35:21 GMT
Server: gunicorn/19.9.0
'''

# Generated at 2022-06-17 20:37:09.261918
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 16 Sep 2019 15:22:27 GMT

{}
"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Sep 2019 15:22:27 GMT
Server: gunicorn/19.9.0

{}
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:37:10.919574
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:37:12.224571
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:37:14.478365
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:23.304098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ef8f7b6e-b6d3-4f3e-9e4b-9f6c7b6e8f7b
X-Runtime: 0.001234
Server: WEBrick/1.3.1 (Ruby/2.1.1/2014-02-24)
Date: Mon, 24 Feb 2014 10:36:31 GMT
X-Frame-Options: SAMEORIGIN
Set-Cookie: request_method=GET; path=/

{}'''

# Generated at 2022-06-17 20:37:33.065582
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Tue, 14 Aug 2018 01:01:01 GMT
Server: Apache
Last-Modified: Mon, 13 Aug 2018 01:01:01 GMT
ETag: "10000000-1111-2222-3333-444444444444"
Accept-Ranges: bytes
Content-Length: 1234
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=UTF-8'''


# Generated at 2022-06-17 20:37:41.220104
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Thu, 25 Apr 2019 14:49:15 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 25 Apr 2019 14:49:15 GMT

'''


# Generated at 2022-06-17 20:37:46.554722
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:37:59.140740
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Tue, 07 Jan 2020 16:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0009589195251464844
Content-Encoding: gzip
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:38:08.534573
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 6f7a2f2c-d3a4-4e4c-9f6d-9c9f0b0c8a7d
ETag: "d41d8cd98f00b204e9800998ecf8427e"
X-Runtime: 0.003931
Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-11-22)
Date: Mon, 02 Dec 2013 12:58:35 GMT
Content-Length: 0
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/
'''

# Generated at 2022-06-17 20:38:12.821216
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == True


# Generated at 2022-06-17 20:38:22.646301
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ae7c8c8e-b7d0-4f6b-9f8a-a2a9a2c5f2e1
ETag: "d41d8cd98f00b204e9800998ecf8427e"
X-Runtime: 0.006871
Content-Length: 0
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 25 Apr 2016 12:27:02 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/
'''

# Generated at 2022-06-17 20:38:29.737913
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers(
        '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Set-Cookie: foo=bar
Set-Cookie: baz=qux
'''
    )
    assert headers == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: baz=qux
'''

# Generated at 2022-06-17 20:38:34.661068
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 17 Jan 2019 17:55:22 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
Date: Thu, 17 Jan 2019 17:55:22 GMT

'''

# Generated at 2022-06-17 20:38:41.845915
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: aa3b3c3d3e3f3g3h3i3j3k3l3m3n3o3p3q3r3s3t3u3v3w3x3y3z
X-Runtime: 0.012345
Connection: close

'''

# Generated at 2022-06-17 20:38:48.912242
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

'''

# Generated at 2022-06-17 20:38:53.496301
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-17 20:39:03.342041
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:39:12.062958
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 10 May 2020 16:57:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0014300918579101562
Content-Encoding: gzip
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:18.102827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:28.182855
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Tue, 11 Aug 2015 14:26:16 GMT
Server: Python/3.4 aiohttp/0.16.0

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Tue, 11 Aug 2015 14:26:16 GMT
Server: Python/3.4 aiohttp/0.16.0

{}'''



# Generated at 2022-06-17 20:39:32.893832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Sun, 10 May 2020 17:02:20 GMT
Server: nginx/1.14.0 (Ubuntu)
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sun, 10 May 2020 17:02:20 GMT
Server: nginx/1.14.0 (Ubuntu)
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:43.787087
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Etag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

'''

# Generated at 2022-06-17 20:39:50.129209
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 10 May 2020 14:46:29 GMT
Server: BaseHTTP/0.6 Python/3.8.2

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 10 May 2020 14:46:29 GMT
Server: BaseHTTP/0.6 Python/3.8.2

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:52.570585
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:40:02.033952
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: nginx/1.4.6 (Ubuntu)
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
X-Frame-Options: SAMEORIGIN
'''

# Generated at 2022-06-17 20:40:09.211832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 27 Apr 2017 09:45:45 GMT
Content-Length: 2

{}
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 27 Apr 2017 09:45:45 GMT

{}
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:17.999747
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sat, 20 Oct 2018 16:46:00 GMT
Server: Python/3.6 aiohttp/3.4.4

{}
"""
    expected = """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sat, 20 Oct 2018 16:46:00 GMT
Server: Python/3.6 aiohttp/3.4.4

{}
"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:40:28.219405
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Tue, 14 May 2019 18:27:14 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Mon, 13 May 2019 21:22:07 GMT
ETag: "2d-58f6b1d55a580"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/html

'''

# Generated at 2022-06-17 20:40:29.781863
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:38.847660
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Cache-Control: max-age=0
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
HTTP/1.1 200 OK
Accept: */*
Cache-Control: max-age=0
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
User-Agent: HTTPie/0.9.9
'''
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:40:47.139341
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 4
Connection: keep-alive
Date: Sun, 01 Jan 2017 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:40:57.321390
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:41:07.003203
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Date: Wed, 01 Apr 2020 23:59:59 GMT
Server: Apache
X-Powered-By: PHP/7.2.24
Content-Length: 2
Connection: close

{}
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Wed, 01 Apr 2020 23:59:59 GMT
Server: Apache
X-Powered-By: PHP/7.2.24

{}
'''

# Generated at 2022-06-17 20:41:13.277793
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: gunicorn/19.7.1

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: gunicorn/19.7.1

{}'''



# Generated at 2022-06-17 20:41:17.701662
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
Date: Wed, 21 Oct 2015 07:28:00 GMT
Server: BaseHTTP/0.6 Python/3.5.0

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 5
Content-Type: application/json
Date: Wed, 21 Oct 2015 07:28:00 GMT
Server: BaseHTTP/0.6 Python/3.5.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:19.664924
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:41:24.915598
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Sun, 26 May 2019 10:00:00 GMT

{}'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Sun, 26 May 2019 10:00:00 GMT

{}'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted

# Generated at 2022-06-17 20:41:36.284995
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Pragma: no-cache
Expires: -1
Server: Microsoft-IIS/8.0
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Thu, 11 Apr 2019 14:48:28 GMT
Content-Length: 2

'''

# Generated at 2022-06-17 20:41:47.377768
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sun, 22 Mar 2020 13:22:31 GMT
Server: gunicorn/19.9.0
X-Frame-Options: SAMEORIGIN

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 22 Mar 2020 13:22:31 GMT
Server: gunicorn/19.9.0
X-Frame-Options: SAMEORIGIN

'''


# Generated at 2022-06-17 20:42:00.356325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\nConnection: keep-alive\r\n') == 'HTTP/1.1 200 OK\r\nConnection: keep-alive\r\nContent-Length: 12\r\nContent-Type: text/html; charset=utf-8\r\n'

# Generated at 2022-06-17 20:42:08.380951
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 7d8b0fcd-e9c7-4b0b-b7d1-a9b9f9d9e9e9
ETag: W/"a7c5e5f2f2c9aeef9f8d386d9f1a3a3c"
X-Runtime: 0.012345
Date: Tue, 01 Jan 2019 12:34:56 GMT
Content-Length: 0
Connection: close
'''

# Generated at 2022-06-17 20:42:10.901301
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers':{'sort':True}})


# Generated at 2022-06-17 20:42:20.182799
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:42:27.788687
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Wed, 23 Jan 2019 13:11:45 GMT
Connection: keep-alive

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 23 Jan 2019 13:11:45 GMT

{}'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:42:37.390575
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:42:44.242688
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
ETag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  Hello World, this is a very simple HTML document.
</body>
</html>
'''

# Generated at 2022-06-17 20:42:50.113250
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 24 Jan 2019 15:46:03 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 12
Content-Type: application/json
Date: Thu, 24 Jan 2019 15:46:03 GMT
Server: gunicorn/19.9.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:55.986436
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
Content-Length: 5
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Length: 5
Content-Type: application/json
Connection: close
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:01.958372
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
Connection: keep-alive
'''
    expected = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:11.325530
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:43:14.188131
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == False


# Generated at 2022-06-17 20:43:25.860792
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:43:30.906105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Accept: application/json
X-Custom-Header: abc
X-Custom-Header: def
X-Custom-Header: ghi
'''
    expected = '''\
Content-Type: application/json
Accept: application/json
X-Custom-Header: abc
X-Custom-Header: def
X-Custom-Header: ghi
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:43:40.566279
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Bar: Quuz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Bar: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert hf.format_headers(headers) == expected

# Generated at 2022-06-17 20:43:46.794579
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:49.705617
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:44:01.233023
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.0007870197296142578
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:44:08.953055
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 23 Jan 2020 16:21:22 GMT
Content-Length: 2

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 23 Jan 2020 16:21:22 GMT

{}
"""

# Generated at 2022-06-17 20:44:11.371506
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:44:30.911408
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: close
Date: Fri, 20 Mar 2020 15:14:22 GMT
Server: Python/3.7 aiohttp/3.6.2

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 35
Content-Type: application/json
Date: Fri, 20 Mar 2020 15:14:22 GMT
Server: Python/3.7 aiohttp/3.6.2

'''

# Generated at 2022-06-17 20:44:35.913351
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Mon, 27 Apr 2020 19:42:44 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Mon, 27 Apr 2020 19:42:44 GMT

'''
    # Act
    actual = HeadersFormatter().format_headers(headers)
    # Assert
    assert actual == expected

# Generated at 2022-06-17 20:44:46.731698
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ef6d7c8c-a8e4-4c4d-a4a8-8b9a9b9a9a9a
X-Runtime: 0.005556
Date: Tue, 01 Jan 2019 00:00:00 GMT
Content-Length: 2

{}
'''

# Generated at 2022-06-17 20:44:58.690677
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 16 Jan 2020 17:11:24 GMT
Server: Python/3.7 aiohttp/3.6.2

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 Jan 2020 17:11:24 GMT
Server: Python/3.7 aiohttp/3.6.2

'''

# Generated at 2022-06-17 20:45:04.045498
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 18 Oct 2015 18:27:17 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 18 Oct 2015 18:27:17 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:45:08.352361
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: www.example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.example.com
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:45:14.777619
# Unit test for method format_headers of class HeadersFormatter