

# Generated at 2022-06-17 20:35:13.841751
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 13
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 22 Apr 2018 16:40:51 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: application/json
Date: Sun, 22 Apr 2018 16:40:51 GMT
Server: gunicorn/19.9.0

"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:21.637975
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
    HTTP/1.1 200 OK
    Date: Mon, 23 May 2005 22:38:34 GMT
    Content-Type: text/html; charset=UTF-8
    Content-Encoding: UTF-8
    Content-Length: 138
    Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
    Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
    ETag: "3f80f-1b6-3e1cb03b"
    Accept-Ranges: bytes
    Connection: close
    """

# Generated at 2022-06-17 20:35:24.784064
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:30.060531
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
X-Foo: Quux
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
X-Foo: Quux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:31.423845
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:33.809279
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:41.103599
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 12
Content-Type: application/json
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.0007870197296142578
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 12
Content-Type: application/json
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.0007870197296142578
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:48.588743
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: close
Date: Mon, 13 Apr 2020 12:20:31 GMT
Server: Python/3.7 aiohttp/3.6.2

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 18
Content-Type: application/json
Date: Mon, 13 Apr 2020 12:20:31 GMT
Server: Python/3.7 aiohttp/3.6.2

'''

# Generated at 2022-06-17 20:35:56.510524
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Tue, 17 Apr 2018 09:49:47 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Tue, 17 Apr 2018 09:49:47 GMT

'''

# Generated at 2022-06-17 20:36:02.043192
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 27 Jul 2015 22:32:35 GMT
Content-Length: 2

{}
"""
    assert HeadersFormatter().format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 22:32:35 GMT

{}
"""

# Generated at 2022-06-17 20:36:11.830634
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: close
Server: BaseHTTP/0.6 Python/3.7.0
Date: Sun, 17 Mar 2019 13:18:20 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 18
Content-Type: application/json
Date: Sun, 17 Mar 2019 13:18:20 GMT
Server: BaseHTTP/0.6 Python/3.7.0

'''

# Generated at 2022-06-17 20:36:23.165133
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ea8a12e0-7aea-4f57-b5fb-b6e6b9d6e7f8
X-Runtime: 0.003056
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 03 Oct 2016 13:46:21 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

{}
'''

# Generated at 2022-06-17 20:36:34.418574
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 5c9d3a3f-c9e7-4f5e-8a2a-8b8d7c2c9d0f
ETag: W/"9d7f9a8c1b7e8e8c8d7c2c9d0f5c9d3a3f"
X-Runtime: 0.012775
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:36:37.725633
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})
    assert HeadersFormatter(format_options={'headers': {'sort': False}})


# Generated at 2022-06-17 20:36:46.414835
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Tue, 05 Mar 2019 17:00:00 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Tue, 05 Mar 2019 17:00:00 GMT
Server: gunicorn/19.9.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:49.588098
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:59.220540
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sun, 10 May 2020 20:47:12 GMT
Server: gunicorn/19.9.0
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 10 May 2020 20:47:12 GMT
Server: gunicorn/19.9.0
'''
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:37:08.996080
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:37:13.249705
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Bar: Qux
'''
    expected = '''\
Content-Type: application/json
X-Bar: Qux
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:21.195617
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Wed, 28 Mar 2018 16:10:40 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Wed, 28 Mar 2018 16:10:40 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:29.738385
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-17 20:37:40.666830
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:37:41.669000
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:37:43.086185
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:37:54.629095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:38:04.980435
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:38:09.967631
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 16 Dec 2018 20:55:58 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sun, 16 Dec 2018 20:55:58 GMT
Server: gunicorn/19.9.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:12.585455
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__


# Generated at 2022-06-17 20:38:20.565935
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Tue, 21 May 2019 10:46:02 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Tue, 21 May 2019 10:46:02 GMT
Server: nginx/1.14.0 (Ubuntu)

'''

# Generated at 2022-06-17 20:38:31.568464
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 3f5c5e5d-d5e5-4c5c-b5e5-5c5c5e5e5c5c
X-Runtime: 0.004555
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 04 May 2015 09:46:31 GMT
Content-Length: 2
Connection: Keep-Alive

"""

# Generated at 2022-06-17 20:38:40.595175
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:38:50.621565
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ef3b9c3c-3b3a-4f4b-b7d4-c8a4a4c6f0d1
ETag: "d41d8cd98f00b204e9800998ecf8427e"
X-Runtime: 0.001591
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Thu, 08 Dec 2016 15:17:24 GMT
Content-Length: 0
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/
'''

# Generated at 2022-06-17 20:38:56.704186
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: c9e6f8d0-c1f0-4a8a-9d9b-c9d8b0f8f8f8
X-Runtime: 0.005880
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Thu, 28 Apr 2016 09:43:44 GMT
Content-Length: 2
Connection: Keep-Alive

{}"""

# Generated at 2022-06-17 20:39:05.257757
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 35
Connection: keep-alive
Date: Mon, 04 Feb 2019 21:49:39 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json; charset=utf-8
Date: Mon, 04 Feb 2019 21:49:39 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:39:15.035508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:39:21.885322
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Tue, 26 Jun 2018 04:27:35 GMT
Server: Python/3.6 aiohttp/3.4.4

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Tue, 26 Jun 2018 04:27:35 GMT
Server: Python/3.6 aiohttp/3.4.4

"""

# Generated at 2022-06-17 20:39:27.372015
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:39:37.729636
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Tue, 28 Feb 2017 23:40:32 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: PHP/7.0.15-0ubuntu0.16.04.4
Cache-Control: no-cache

{}
'''

# Generated at 2022-06-17 20:39:43.704847
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:49.777492
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Thu, 23 Mar 2017 12:23:45 GMT
Connection: keep-alive

{}
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: keep-alive
Date: Thu, 23 Mar 2017 12:23:45 GMT

{}
'''

# Generated at 2022-06-17 20:40:06.511835
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: cb6e8c1f-a6a0-4b67-b3b1-d2bf9f8d897d
ETag: "e1ca502697e5c9317743dc078f67693f"
X-Runtime: 0.006834
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:40:08.093931
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:40:18.663766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 02 Mar 2020 20:27:54 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0016250419616699219
Content-Length: 2
Content-Type: application/json
Date: Mon, 02 Mar 2020 20:27:54 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0016250419616699219
'''

# Generated at 2022-06-17 20:40:20.855752
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:28.256948
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.2
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/0.9.2
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:33.136617
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 15
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 15
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-17 20:40:43.199129
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 01 Jan 1970 00:00:00 GMT
Server: Python/3.7 aiohttp/3.6.2

{}
'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 01 Jan 1970 00:00:00 GMT
Server: Python/3.7 aiohttp/3.6.2

{}
'''
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers) == headers_sorted



# Generated at 2022-06-17 20:40:50.287345
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 5a5e5c5d-e5e5-5e5e-5e5e-5e5e5e5e5e5e
X-Runtime: 0.012345
Date: Wed, 01 Jan 2014 12:00:00 GMT
Content-Length: 18
Connection: keep-alive

"""

# Generated at 2022-06-17 20:40:54.256893
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:40:58.479556
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 17 May 2018 11:39:28 GMT
Server: Python/3.6 aiohttp/3.4.4

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 17 May 2018 11:39:28 GMT
Server: Python/3.6 aiohttp/3.4.4

'''


# Generated at 2022-06-17 20:41:33.391450
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Server: nginx
Date: Wed, 20 May 2020 16:37:08 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: PHP/7.2.24
Cache-Control: no-cache, private
Date: Wed, 20 May 2020 16:37:08 +0000
Vary: Accept
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59
"""

# Generated at 2022-06-17 20:41:38.803485
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers(
        '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
''')
    assert headers == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:41:48.716918
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 27 Jul 2015 22:16:56 GMT
Server: WSGIServer/0.1 Python/2.7.9
X-Frame-Options: SAMEORIGIN
Content-Length: 2

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 22:16:56 GMT
Server: WSGIServer/0.1 Python/2.7.9
X-Frame-Options: SAMEORIGIN

{}
"""

# Generated at 2022-06-17 20:41:59.750271
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:42:08.050685
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:42:11.245946
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Date: Tue, 14 May 2019 07:21:14 GMT
Server: Werkzeug/0.14.1 Python/3.7.3

'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: application/json
Date: Tue, 14 May 2019 07:21:14 GMT
Server: Werkzeug/0.14.1 Python/3.7.3

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:20.355282
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:42:25.468652
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json

'''



# Generated at 2022-06-17 20:42:35.604037
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:42:41.408310
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Fri, 24 Apr 2020 13:30:00 GMT
Server: Python/3.7 aiohttp/3.6.2
'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Fri, 24 Apr 2020 13:30:00 GMT
Server: Python/3.7 aiohttp/3.6.2
'''

# Generated at 2022-06-17 20:43:17.175451
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Wed, 21 Oct 2015 07:28:00 GMT
Server: Apache
Last-Modified: Wed, 11 Jan 2006 12:29:43 GMT
ETag: "10c24bc-1b6-4059a80bfd280"
Accept-Ranges: bytes
Content-Length: 444
Vary: Accept-Encoding
Content-Type: text/html
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:43:27.847706
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 8e8f6e18-aac6-4c56-8d3b-aeeb00aa5d5e
X-Runtime: 0.006857
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Sun, 22 May 2016 10:32:57 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

{}
"""

# Generated at 2022-06-17 20:43:36.819613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 13
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 01 Oct 2018 12:00:00 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: application/json
Date: Mon, 01 Oct 2018 12:00:00 GMT
Server: gunicorn/19.9.0

"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:46.250256
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Quux
X-Baz: Corge
X-Baz: Grault
X-Baz: Garply
X-Baz: Waldo
X-Baz: Fred
X-Baz: Plugh
X-Baz: Xyzzy
X-Baz: Thud
'''

# Generated at 2022-06-17 20:44:00.247210
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: a6a0f6c0-6a7a-4c9d-9c6d-5f5b7b8d5c5c
X-Runtime: 0.002879
Connection: close
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Tue, 14 Jul 2015 10:32:49 GMT
Via: 1.1 vegur

{}'''

# Generated at 2022-06-17 20:44:08.798506
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 21 Oct 2015 07:28:00 GMT
Connection: keep-alive
Content-Length: 18

'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Wed, 21 Oct 2015 07:28:00 GMT

'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:15.312235
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Sun, 15 Mar 2020 17:34:47 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sun, 15 Mar 2020 17:34:47 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:26.052832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Thu, 04 Jan 2018 16:01:50 GMT
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-L7MtFluoH/Aq2GBM1mj9Vx5ycg"
Vary: Accept-Encoding

'''

# Generated at 2022-06-17 20:44:32.947841
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 13
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 27 Jan 2019 19:12:15 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: application/json
Date: Sun, 27 Jan 2019 19:12:15 GMT
Server: gunicorn/19.9.0

"""
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:44:38.727480
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''