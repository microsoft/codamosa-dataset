

# Generated at 2022-06-17 20:35:18.762127
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Date: Tue, 19 May 2020 14:19:10 GMT
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 19 May 2020 14:19:10 GMT
'''

# Generated at 2022-06-17 20:35:28.840802
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b9a9c9e8c1f7e8e9b9a9c9e8c1f7e8e9"
X-Request-Id: fb8b8c9e8c1f7e8e9b9a9c9e8c1f7e8e9
X-Runtime: 0.003057
Server: WEBrick/1.3.1 (Ruby/2.1.2/2014-05-08)
Date: Wed, 18 Feb 2015 20:36:22 GMT
Content-Length: 2
Connection: Keep-Alive

{}'''


# Generated at 2022-06-17 20:35:33.568925
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:34.663662
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:44.571420
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:35:55.298590
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 15
Connection: keep-alive
Date: Thu, 19 Oct 2017 13:47:30 GMT
Server: nginx/1.10.3 (Ubuntu)
X-Powered-By: PHP/7.1.12-1+ubuntu16.04.1+deb.sury.org+1
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59
X-RateLimit-Reset: 1508412250

'''

# Generated at 2022-06-17 20:36:03.491343
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:12.129400
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:36:14.406075
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:25.293244
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: keep-alive
Date: Wed, 13 Jun 2018 13:29:51 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0013709163665771484
Via: 1.1 vegur
'''

# Generated at 2022-06-17 20:36:30.508121
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:39.033919
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 4
Connection: close
Date: Mon, 21 Jan 2019 19:24:06 GMT
Server: Python/3.7 aiohttp/3.5.4
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 4
Content-Type: application/json
Date: Mon, 21 Jan 2019 19:24:06 GMT
Server: Python/3.7 aiohttp/3.5.4
'''
    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:36:46.934998
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 24 Feb 2019 17:56:26 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sun, 24 Feb 2019 17:56:26 GMT
Server: gunicorn/19.9.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:58.792088
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Tue, 13 Mar 2018 16:19:51 GMT
Server: gunicorn/19.7.1
X-Frame-Options: SAMEORIGIN

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Tue, 13 Mar 2018 16:19:51 GMT
Server: gunicorn/19.7.1
X-Frame-Options: SAMEORIGIN

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:08.682009
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: aa8c2e3a-3e1c-4d7f-8c67-b7b6d4a7f7d9
X-Runtime: 0.003056
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Wed, 04 Jan 2017 14:01:55 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

'''

# Generated at 2022-06-17 20:37:15.828897
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Content-Length: 3
Connection: close
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Connection: close
Content-Length: 2
Content-Length: 3
Content-Type: application/json
'''



# Generated at 2022-06-17 20:37:24.681072
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 5c9d8c8f-d0c0-4b2a-b8f9-9c9b7b9e9c2d
ETag: W/"d41d8cd98f00b204e9800998ecf8427e"
X-Runtime: 0.004766
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 23 Nov 2015 13:38:01 GMT
Content-Length: 0
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/
'''

# Generated at 2022-06-17 20:37:26.257488
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:36.044981
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug
"""

# Generated at 2022-06-17 20:37:37.734539
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:37:46.657564
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 16 Dec 2018 15:49:33 GMT
'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 16 Dec 2018 15:49:33 GMT
Server: gunicorn/19.9.0
'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted

# Generated at 2022-06-17 20:37:58.215832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Cache-Control: max-age=0
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Accept: */*
Cache-Control: max-age=0
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
User-Agent: HTTPie/0.9.9
'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:38:06.686881
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 16 Sep 2019 11:38:00 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Sep 2019 11:38:00 GMT
Server: gunicorn/19.9.0

{}
"""



# Generated at 2022-06-17 20:38:17.017439
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.4.6 (Ubuntu)
Date: Sun, 11 Jan 2015 23:42:26 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-1421024645000"
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json; charset=utf-8
Date: Sun, 11 Jan 2015 23:42:26 GMT
ETag: W/"2-1421024645000"
Server: nginx/1.4.6 (Ubuntu)
X-Powered-By: Express
'''
    assert Head

# Generated at 2022-06-17 20:38:23.461565
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:25.280645
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:38:32.059915
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 20 May 2020 13:59:20 GMT
Content-Length: 2

{}
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 20 May 2020 13:59:20 GMT

{}
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:38:35.040073
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:41.293946
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Server: gunicorn/19.9.0
Date: Sat, 07 Sep 2019 13:58:37 GMT

{}'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sat, 07 Sep 2019 13:58:37 GMT
Server: gunicorn/19.9.0

{}'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:38:48.444886
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Mon, 13 Jul 2020 15:47:13 GMT

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Mon, 13 Jul 2020 15:47:13 GMT

'''

# Generated at 2022-06-17 20:39:01.557572
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Set-Cookie: foo=bar
Set-Cookie: baz=qux
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: baz=qux
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:39:06.650094
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Date: Mon, 27 Jul 2015 01:12:35 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:12:35 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

{}
'''



# Generated at 2022-06-17 20:39:08.475892
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:13.562344
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "e9e9d9b3c6f9b6e7d4d4c3c2b1b1a1a0"
X-Request-Id: 9c9b8b7b6b5b4b3b2b1b0a0a1a2a3a4a5a6a7a8a9a
X-Runtime: 0.012345
Date: Mon, 01 Jan 2018 00:00:00 GMT
Content-Length: 123
Connection: close
'''

# Generated at 2022-06-17 20:39:23.096830
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 13 Feb 2017 14:34:03 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.00144290924072
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:30.608857
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:39:41.096651
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 15
Connection: keep-alive
Date: Wed, 16 Aug 2017 12:43:10 GMT
Server: gunicorn/19.7.1
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 15
Content-Type: application/json
Date: Wed, 16 Aug 2017 12:43:10 GMT
Server: gunicorn/19.7.1
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:48.868729
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sun, 19 May 2019 11:21:01 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 19 May 2019 11:21:01 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-17 20:39:57.804368
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: bb8d8c4f-e4c4-4d3b-8d9e-9a3c3f8d2c0e
ETag: W/"d7c9e2a0f7e9f9e1b7a1b8f8b0a0a3a3"
X-Runtime: 0.006964
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:40:08.363482
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: cb7a8a3c-e7b9-4e1e-b9c9-f5b5d2f5a5a5
X-Runtime: 0.002993
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 10 Aug 2015 16:38:44 GMT
Content-Length: 2
Connection: Keep-Alive

{}
"""

# Generated at 2022-06-17 20:40:24.993718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 11
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.9

'''
    expected = '''\
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 11
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.9

'''
    assert HeadersFormatter().format_headers(headers) == expected


# Generated at 2022-06-17 20:40:26.429928
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:33.175138
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 16 Apr 2018 20:29:53 GMT
Connection: keep-alive
Content-Length: 2

{}'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Apr 2018 20:29:53 GMT

{}'''


# Generated at 2022-06-17 20:40:38.846938
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 16 May 2019 13:11:12 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 May 2019 13:11:12 GMT
Server: Python/3.7 aiohttp/3.5.4

'''

# Generated at 2022-06-17 20:40:47.138700
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 7c5daeaa-f9a9-4d5f-8c0f-f7b1a2a0a8e1
ETag: W/"7c5daeaa-f9a9-4d5f-8c0f-f7b1a2a0a8e1"
X-Runtime: 0.004789
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:40:59.265968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Foo: Quux
X-Foo: Quuz
X-Foo: Corge
X-Foo: Grault
X-Foo: Garply
X-Foo: Waldo
X-Foo: Fred
X-Foo: Plugh
X-Foo: Xyzzy
X-Foo: Thud
'''

# Generated at 2022-06-17 20:41:05.820461
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fd7b3d3c-0d2e-4f1a-a9d8-c7a0a5c5d5d5
ETag: W/"d6b9a6b7e6b9a6b7e6b9a6b7e6b9a6b7"
X-Runtime: 0.002911
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:41:07.436865
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:41:14.975048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: gunicorn/19.4.5
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:41:24.655448
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
X-Powered-By: Express
ETag: W/"23-lQyW+lIqBJdzZO/9XtLrQ"
Date: Tue, 15 Nov 2016 12:45:26 GMT
'''
    expected = '''\
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Tue, 15 Nov 2016 12:45:26 GMT
ETag: W/"23-lQyW+lIqBJdzZO/9XtLrQ"
X-Powered-By: Express
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:33.467096
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:41:36.360300
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:41:45.215449
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
Connection: keep-alive'''
    expected = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:49.743714
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:42:00.117323
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: f8f8f8f8-f8f8-f8f8-f8f8-f8f8f8f8f8f8
ETag: "f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8"
X-Runtime: 0.012345
X-Ua-Compatible: IE=Edge,chrome=1
Set-Cookie: _some_cookie=bar; path=/
Set-Cookie: _some_other_cookie=foo; path=/
Connection: close
'''
    expected

# Generated at 2022-06-17 20:42:01.830019
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:42:07.733105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:17.555446
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Wed, 14 Nov 2018 14:57:04 GMT

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Wed, 14 Nov 2018 14:57:04 GMT
Server: gunicorn/19.9.0

'''

# Generated at 2022-06-17 20:42:21.566986
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:42:28.099119
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Thu, 14 May 2020 11:05:50 GMT

{}
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 14 May 2020 11:05:50 GMT

{}
'''



# Generated at 2022-06-17 20:42:47.959014
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Connection: keep-alive
Date: Wed, 20 May 2020 12:00:00 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 20 May 2020 12:00:00 GMT

{}'''

# Generated at 2022-06-17 20:42:57.015731
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 21 Jul 2019 08:29:26 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 21 Jul 2019 08:29:26 GMT

'''

# Generated at 2022-06-17 20:43:06.760206
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ae5c5a5e-b9d5-4a6c-a8e7-f4c4d4b4d4b4
ETag: W/"d4b4d4b4d4b4d4b4d4b4d4b4d4b4d4b4"
X-Runtime: 0.001234
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 13 Apr 2015 10:37:51 GMT
Content-Length: 1234
Connection: Keep-Alive

"""

# Generated at 2022-06-17 20:43:09.324473
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-17 20:43:10.844530
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:43:20.485447
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.6.2
Date: Mon, 23 Mar 2015 22:38:34 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 13
Connection: keep-alive
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 56

{ "status": "OK" }'''

# Generated at 2022-06-17 20:43:22.268740
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:43:24.862702
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:43:31.533576
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Connection: keep-alive
Content-Length: 15
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
'''
    expected = '''\
Connection: keep-alive
Content-Length: 15
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:40.609919
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: a1b2c3d4
ETag: "e5f6g7h8"
X-Runtime: 0.012345
Date: Wed, 16 Oct 2013 10:06:20 GMT
Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-05-14)
Content-Length: 133
Connection: Keep-Alive
Set-Cookie: _session_id=abcdefg1234567; path=/; HttpOnly

"""

# Generated at 2022-06-17 20:44:01.964940
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:44:09.803817
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Wed, 26 Jun 2019 09:18:51 GMT

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 26 Jun 2019 09:18:51 GMT

{}
'''

# Generated at 2022-06-17 20:44:18.435832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9c7b3a3c-f7e0-4c8a-9c6a-9b9d8c8e8d8c
ETag: "2aae6c35c94fcfb415dbe95f408b9ce91ee846ed"
X-Runtime: 0.013857
Connection: close
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:44:28.668680
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Tue, 14 May 2019 15:46:12 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 14 May 2019 15:46:12 GMT
ETag: "2d-58f5b1c5b6f40"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/html

"""

# Generated at 2022-06-17 20:44:35.234821
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 23 May 2016 15:57:21 GMT
Server: gunicorn/19.6.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Mon, 23 May 2016 15:57:21 GMT
Server: gunicorn/19.6.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:39.335126
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:44:40.837520
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:44:47.345626
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:53.046259
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:45:00.888488
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: gunicorn/19.4.5
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
Via: 1.1 vegur

'''