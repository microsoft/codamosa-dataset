

# Generated at 2022-06-17 20:35:22.248302
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:35:32.895317
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: b0a9c9f9-d8c8-4d3f-a3b0-f8a8a9d2f9b9
X-Runtime: 0.004519
Date: Mon, 23 Apr 2018 16:20:13 GMT
Content-Length: 2
Connection: keep-alive

{}
'''

# Generated at 2022-06-17 20:35:38.411238
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Date: Thu, 16 Jul 2020 19:47:35 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 Jul 2020 19:47:35 GMT

{}'''



# Generated at 2022-06-17 20:35:47.717178
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ef0c8d3a-f8b2-4e2a-8b9e-e6f9e9f9d0e8
ETag: W/"a7c9d0f6f9f9e9e6b9e2a4e8b2f8a3c8e0d3f8c"
X-Runtime: 0.007571
Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-11-22)
Date: Thu, 05 Dec 2013 14:46:12 GMT
Content-Length: 2
Connection: Keep-Alive

{}
"""


# Generated at 2022-06-17 20:35:50.560416
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:59.705530
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 27 Nov 2017 21:54:35 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-L7UW/Yl5RCv1qZbT3oX/IxDg"
Vary: Origin, Accept-Encoding
Allow: GET, PUT, PATCH, DELETE, HEAD, OPTIONS
'''

# Generated at 2022-06-17 20:36:10.127882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Thu, 08 Aug 2019 01:38:12 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Thu, 08 Aug 2019 01:38:12 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted

# Generated at 2022-06-17 20:36:21.280558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: c8d8e9f7-f8d0-4a7e-8f6a-a6d5f6a5d6a7
X-Runtime: 0.006782
Server: WEBrick/1.3.1 (Ruby/2.3.0/2015-12-25)
Date: Tue, 26 Jan 2016 14:11:12 GMT
Content-Length: 2
Connection: Keep-Alive

{}
"""

# Generated at 2022-06-17 20:36:28.917926
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ae8b0c9d-8c7e-4d1d-b7b8-b8c6b9f6e8d9
X-Runtime: 0.005578
Date: Mon, 16 Mar 2015 13:02:51 GMT
Content-Length: 2
Connection: keep-alive

'''

# Generated at 2022-06-17 20:36:38.502308
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Sat, 13 May 2017 14:10:29 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sat, 13 May 2017 14:10:29 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur

'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:36:47.092519
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 01 Jan 1970 00:00:00 GMT
Content-Length: 2

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 01 Jan 1970 00:00:00 GMT

{}
'''

# Generated at 2022-06-17 20:36:59.590927
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.com
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8,ru;q=0.6
'''

# Generated at 2022-06-17 20:37:07.653932
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Wed, 16 Sep 2015 19:28:12 GMT
Server: BaseHTTP/0.6 Python/3.4.3

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Wed, 16 Sep 2015 19:28:12 GMT
Server: BaseHTTP/0.6 Python/3.4.3

'''

# Generated at 2022-06-17 20:37:16.772614
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 04 Feb 2019 13:47:29 GMT

{}
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 04 Feb 2019 13:47:29 GMT
Server: gunicorn/19.9.0

{}
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:18.732173
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:37:26.726583
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Tue, 24 Jul 2018 16:22:19 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00157904624939
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:37:31.696212
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 4
Connection: keep-alive
Content-Length: 4
Content-Type: application/json
'''
    expected = '''\
Content-Type: application/json
Content-Length: 4
Connection: keep-alive
Content-Length: 4
Content-Type: application/json
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:37.407093
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:44.343164
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:37:52.898522
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sat, 15 Dec 2018 09:00:00 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sat, 15 Dec 2018 09:00:00 GMT
Server: gunicorn/19.9.0

'''

# Generated at 2022-06-17 20:38:04.980132
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:38:08.921351
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:20.296058
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:38:28.216776
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 05 Oct 2016 13:46:32 GMT
Content-Length: 2

{}"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 05 Oct 2016 13:46:32 GMT

{}"""

# Generated at 2022-06-17 20:38:35.465792
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:41.411762
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 10 Jun 2018 12:27:48 GMT
Server: BaseHTTP/0.6 Python/3.6.5

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 10 Jun 2018 12:27:48 GMT
Server: BaseHTTP/0.6 Python/3.6.5

'''

# Generated at 2022-06-17 20:38:42.996144
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:38:45.638154
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:58.577695
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:39:05.001085
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 15
Server: Werkzeug/0.16.0 Python/3.7.4
Date: Sun, 09 Feb 2020 21:29:04 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 15
Content-Type: application/json
Date: Sun, 09 Feb 2020 21:29:04 GMT
Server: Werkzeug/0.16.0 Python/3.7.4

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:16.085531
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Fri, 21 Dec 2018 17:00:00 GMT

{}'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Fri, 21 Dec 2018 17:00:00 GMT
Server: gunicorn/19.9.0

{}'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:24.027040
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9e7d9a9c-e7c1-4e2a-a2d2-9b7c2c8f9d7a
ETag: W/"4a8d8e4b7e4a4d9d9b8f8f9b9d9d9c9d"
X-Runtime: 0.007053
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:39:31.326008
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-17 20:39:41.947843
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Set-Cookie: csrftoken=uw7JNbvVcZjtYG9G1vBZgyNL9gQXOt1U; expires=Sun, 22-Sep-2019 15:41:53 GMT; Max-Age=31449600; Path=/
Date: Sat, 22 Sep 2018 15:41:53 GMT

'''

# Generated at 2022-06-17 20:39:43.462140
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:39:49.848941
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:52.157212
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:53.982252
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:00.791445
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:40:08.026920
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:40:24.012598
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 17 Sep 2015 18:26:14 GMT
Server: Python/3.4 aiohttp/0.16.0

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 17 Sep 2015 18:26:14 GMT
Server: Python/3.4 aiohttp/0.16.0

{}
'''

# Generated at 2022-06-17 20:40:31.682981
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Thu, 12 Dec 2019 12:00:00 GMT
Server: nginx/1.14.0 (Ubuntu)
X-Powered-By: Express

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Thu, 12 Dec 2019 12:00:00 GMT
Server: nginx/1.14.0 (Ubuntu)
X-Powered-By: Express

'''

# Generated at 2022-06-17 20:40:37.937729
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 13
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 09 May 2019 21:35:37 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: application/json
Date: Thu, 09 May 2019 21:35:37 GMT
Server: gunicorn/19.9.0

"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:40:43.272911
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__name__ == 'HeadersFormatter'
    assert HeadersFormatter.__doc__ == 'HeadersFormatter class'
    assert HeadersFormatter.__module__ == 'httpie.plugins.headers'
    assert HeadersFormatter.__bases__ == (FormatterPlugin,)
    assert HeadersFormatter.enabled == True


# Generated at 2022-06-17 20:40:49.137400
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Date: Wed, 23 Oct 2019 12:35:31 GMT
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 23 Oct 2019 12:35:31 GMT
'''

# Generated at 2022-06-17 20:40:59.646367
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.00099730491638
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:41:06.141907
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Sun, 19 Nov 2017 08:52:34 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-Lve95gjOVATpfV8EL5X4nxwjKHE"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:41:11.829539
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 26 Apr 2017 12:04:06 GMT
Content-Length: 2

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 26 Apr 2017 12:04:06 GMT

{}'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:17.876487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 09 Jul 2020 15:53:53 GMT
Server: gunicorn/20.0.4
X-Powered-By: Flask
X-Processed-Time: 0.0017778873443603516
Content-Encoding: gzip
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:41:22.423293
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fb8c8b1a-b9d9-4c3a-8b7a-a6e8b89e8e3a
ETag: W/"2aae6c35c94fcfb415dbe95f408b9ce91"
X-Runtime: 0.006856
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:41:32.227162
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 10 Nov 2019 20:20:20 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 10 Nov 2019 20:20:20 GMT
Server: Python/3.7 aiohttp/3.5.4

'''

# Generated at 2022-06-17 20:41:38.759525
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers(
        '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Wed, 21 Oct 2015 07:28:00 GMT

{}
''')
    assert headers == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 21 Oct 2015 07:28:00 GMT

{}
'''

# Generated at 2022-06-17 20:41:48.939355
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Date: Sat, 23 May 2020 09:15:27 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
X-Powered-By: Express
ETag: W/"2-L7MtFluoYkHnL3z6FV6hN5X9gkM"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:41:59.859682
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-17 20:42:06.322911
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 5
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''



# Generated at 2022-06-17 20:42:07.667632
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:42:17.847810
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Thu, 28 Jun 2018 11:51:16 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Thu, 28 Jun 2018 11:51:16 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:42:27.641102
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Fri, 04 Oct 2019 10:15:27 GMT
Server: nginx/1.14.0 (Ubuntu)
X-Powered-By: Express

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Fri, 04 Oct 2019 10:15:27 GMT
Server: nginx/1.14.0 (Ubuntu)
X-Powered-By: Express

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:35.790118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Thu, 14 May 2020 12:17:09 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Thu, 14 May 2020 12:17:09 GMT
Server: nginx/1.14.0 (Ubuntu)

'''

# Generated at 2022-06-17 20:42:42.907722
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 4a7f2b5f-c7d5-4a1b-9a3c-a5e7b8f5c5c7
ETag: W/"f5a8e9a9c7e9d8c8e7f5f4f3f2f1f0e0d0c0b0a09080706050403020100"
X-Runtime: 0.005902
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:43:04.517801
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
Content-Length: 5
Content-Type: application/json
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Length: 5
Content-Type: application/json
Content-Type: application/json
Connection: close
'''


# Generated at 2022-06-17 20:43:13.483514
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Connection: keep-alive
Date: Thu, 23 May 2019 13:38:14 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 23 May 2019 13:38:14 GMT

{}'''

# Generated at 2022-06-17 20:43:25.823900
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Etag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  Hello World, this is a very simple HTML document.
</body>
</html>
'''

# Generated at 2022-06-17 20:43:33.184113
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
ETag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

'''

# Generated at 2022-06-17 20:43:42.463869
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:43:50.750489
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: aa0a0a0a-0a0a-0a0a-0a0a-0a0a0a0a0a0a
X-Runtime: 0.001234
X-Frame-Options: SAMEORIGIN
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Tue, 28 Jul 2015 13:46:23 GMT

'''

# Generated at 2022-06-17 20:44:01.481531
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b1f9c7f2a2b8e7d9f2c9d7f1a1b8c7e6"
X-Request-Id: b1f9c7f2a2b8e7d9f2c9d7f1a1b8c7e6
X-Runtime: 0.002981
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 13 Apr 2015 10:36:31 GMT
Content-Length: 2
Connection: Keep-Alive
Set-Cookie: request_method=GET

{}
'''

# Generated at 2022-06-17 20:44:08.871700
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:10.375724
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:44:15.273288
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-17 20:44:50.694488
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
    HTTP/1.1 200 OK
    Date: Tue, 14 May 2019 10:25:43 GMT
    Server: Apache/2.4.18 (Ubuntu)
    Last-Modified: Mon, 13 May 2019 19:12:03 GMT
    ETag: "2d-58f6b1d556940"
    Accept-Ranges: bytes
    Content-Length: 45
    Vary: Accept-Encoding
    Content-Type: text/html
    """

# Generated at 2022-06-17 20:44:55.081351
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled == True
    assert HeadersFormatter(format_options={'headers': {'sort': False}}).enabled == False


# Generated at 2022-06-17 20:45:02.734559
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:45:12.159627
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Tue, 17 Jul 2018 11:09:48 GMT
Server: gunicorn/19.9.0
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff

"""