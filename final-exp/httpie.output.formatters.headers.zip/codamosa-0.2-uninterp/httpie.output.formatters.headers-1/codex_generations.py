

# Generated at 2022-06-17 20:35:18.917367
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Tue, 23 May 2017 12:36:30 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Tue, 23 May 2017 12:36:30 GMT

'''


# Generated at 2022-06-17 20:35:25.526784
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b9b5b9b5b9b5b9b5b9b5b9b5b9b5b9b5"
X-Request-Id: b9b5b9b5-b9b5-b9b5-b9b5-b9b5b9b5b9b5
X-Runtime: 0.003057
Server: WEBrick/1.3.1 (Ruby/2.1.5/2014-11-13)
Date: Wed, 25 Mar 2015 12:00:00 GMT
Content-Length: 0
Connection: Keep-Alive
'''

# Generated at 2022-06-17 20:35:30.643776
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
X-Foo: Quux
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
X-Foo: Quux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:37.285980
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:44.414435
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: Example
Date: Tue, 15 Nov 1994 08:12:31 GMT

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Tue, 15 Nov 1994 08:12:31 GMT
Server: Example

"""

# Generated at 2022-06-17 20:35:54.721611
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Quux
X-Bar: Corge
X-Bar: Grault
X-Bar: Garply
X-Bar: Waldo
X-Bar: Fred
X-Bar: Plugh
X-Bar: Xyzzy
X-Bar: Thud
'''

# Generated at 2022-06-17 20:35:57.689861
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:36:04.187340
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Thu, 23 Jul 2015 20:00:00 GMT
Server: Python/3.4.3
X-Powered-By: Flask/0.10.1
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Date: Thu, 23 Jul 2015 20:00:00 GMT
Server: Python/3.4.3
X-Powered-By: Flask/0.10.1
'''

# Generated at 2022-06-17 20:36:12.507749
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:14.480378
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:36:17.965082
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:36:26.431495
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:36:28.105817
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:36:39.129582
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 23 Jul 2020 22:25:39 GMT
Server: Python/3.8 aiohttp/3.6.2

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 23 Jul 2020 22:25:39 GMT
Server: Python/3.8 aiohttp/3.6.2

'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

    # Test case 2

# Generated at 2022-06-17 20:36:48.722851
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fc5d8c0c-02f7-4f1a-9db7-8948afb03c1b
ETag: W/"a7c49c9f4b1a613e6b7e36b0b2e3ae87"
X-Runtime: 0.007534
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:36:54.515766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 1234
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Foo: Quux
X-Foo: Quuz
X-Foo: Corge
X-Foo: Grault
X-Foo: Garply
X-Foo: Waldo
X-Foo: Fred
X-Foo: Plugh
X-Foo: Xyzzy
X-Foo: Thud
'''

# Generated at 2022-06-17 20:36:56.192759
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:06.333356
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 11 Jul 2018 12:00:00 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 11 Jul 2018 12:00:00 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:37:07.219128
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-17 20:37:10.730775
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:37:22.750363
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sat, 23 Mar 2019 09:58:06 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0014450550079345703
Via: 1.1 vegur
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sat, 23 Mar 2019 09:58:06 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.0014450550079345703
'''

# Generated at 2022-06-17 20:37:30.754954
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Wed, 11 Jul 2018 16:36:03 GMT
Server: Python/3.6 aiohttp/3.4.4

'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Wed, 11 Jul 2018 16:36:03 GMT
Server: Python/3.6 aiohttp/3.4.4

'''

# Generated at 2022-06-17 20:37:36.900617
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
"""
    assert headers_formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-17 20:37:45.094982
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 26 Oct 2016 18:07:41 GMT
Server: gunicorn/19.6.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 26 Oct 2016 18:07:41 GMT
Server: gunicorn/19.6.0
Via: 1.1 vegur

'''



# Generated at 2022-06-17 20:37:52.242207
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:38:02.477025
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-17 20:38:09.568822
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT
Connection: keep-alive
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:38:21.027718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: e8c7b0a3-3a2f-4f8b-9c9b-d9b5c8a8f8e0
ETag: W/"7d8f8a8b9c9d9e9f0a1b2c3d4e5f6a7b"
X-Runtime: 0.012345
Date: Wed, 01 Jan 2020 00:00:00 GMT
Content-Length: 123
Connection: close
'''

# Generated at 2022-06-17 20:38:32.262993
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: keep-alive
Date: Thu, 16 Mar 2017 13:19:33 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
X-Processed-Time: 0.00140905380249
Via: 1.1 vegur

"""

# Generated at 2022-06-17 20:38:40.059441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: BaseHTTP/0.6 Python/3.7.0
Date: Mon, 11 Feb 2019 14:54:53 GMT

{}
"""
    expected = """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Mon, 11 Feb 2019 14:54:53 GMT
Server: BaseHTTP/0.6 Python/3.7.0

{}
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:49.416836
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:50.396080
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:56.541037
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: BaseHTTP/0.6 Python/3.6.4
X-Powered-By: PHP/7.1.12

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: BaseHTTP/0.6 Python/3.6.4
X-Powered-By: PHP/7.1.12

{}
'''


# Generated at 2022-06-17 20:39:03.783389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 26 May 2019 14:20:29 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 26 May 2019 14:20:29 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:05.257463
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:15.034817
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fd5c5b4f-e8e4-4a4b-b0d2-f9c8e8a9d9c4
X-Runtime: 0.005906
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 07 Nov 2016 15:44:44 GMT
Content-Length: 2
Connection: Keep-Alive"""

# Generated at 2022-06-17 20:39:23.561912
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:39:28.947984
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:33.167718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
X-Baz: Quux
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:35.800828
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:54.701269
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 2d4e4e0f-b8c4-4e2f-a0b2-d9a9b9d9d9d9
X-Runtime: 0.006880
Date: Mon, 01 Jan 2018 00:00:00 GMT
Content-Length: 2
Connection: close

{}
"""

# Generated at 2022-06-17 20:40:01.645183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Date: Mon, 02 Jan 2017 14:00:00 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 02 Jan 2017 14:00:00 GMT
Server: nginx

{}
'''

# Generated at 2022-06-17 20:40:08.943177
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 02 Dec 2019 12:18:47 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Mon, 02 Dec 2019 12:18:47 GMT

'''



# Generated at 2022-06-17 20:40:15.218407
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Cache-Control: max-age=0, private, must-revalidate
Content-Type: application/json; charset=utf-8
ETag: "a-etag"
X-Request-Id: a-request-id
X-Runtime: 0.012345
Date: Tue, 26 Mar 2013 20:00:00 GMT
Content-Length: 2
Connection: keep-alive

{}
'''

# Generated at 2022-06-17 20:40:25.761913
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 20 May 2020 14:44:44 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.001277923583984375
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:40:34.065665
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:40:41.758842
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Bar: Foo
X-Bar: Foo
X-Bar: Foo
'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Bar: Foo
X-Bar: Foo
X-Bar: Foo
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:40:43.460379
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:50.371978
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 09 May 2018 12:39:56 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.0013120174407958984
X-Request-Id: fb7e5e5c-5a1f-4b0a-a5f5-e9d9b8e9f2f2
'''

# Generated at 2022-06-17 20:40:55.595484
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 23 May 2016 18:25:43 GMT
Server: nginx/1.10.0 (Ubuntu)

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Mon, 23 May 2016 18:25:43 GMT
Server: nginx/1.10.0 (Ubuntu)

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:36.242936
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Tue, 24 Sep 2019 13:46:26 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Tue, 24 Sep 2019 13:46:26 GMT

{}'''

# Generated at 2022-06-17 20:41:45.914146
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 07 Aug 2019 14:51:38 GMT
Content-Length: 2

{}
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 07 Aug 2019 14:51:38 GMT

{}
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:56.608013
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:42:05.719674
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Tue, 28 Jul 2015 01:01:01 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Tue, 28 Jul 2015 01:01:01 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
'''
    assert Head

# Generated at 2022-06-17 20:42:16.791855
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:42:21.598992
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Sat, 23 Jun 2018 09:39:36 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Sat, 23 Jun 2018 09:39:36 GMT

{}'''



# Generated at 2022-06-17 20:42:27.454057
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Host: example.com
Connection: close
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.2
"""
    expected = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Host: example.com
User-Agent: HTTPie/0.9.2
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:34.695252
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 28 May 2020 13:59:05 GMT
Content-Length: 2

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 28 May 2020 13:59:05 GMT

{}
'''

# Generated at 2022-06-17 20:42:42.866472
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:17:36 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:17:36 GMT

{}
"""

# Generated at 2022-06-17 20:42:48.936776
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 19 May 2019 11:11:11 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
Date: Sun, 19 May 2019 11:11:11 GMT
Server: Python/3.7 aiohttp/3.5.4

'''

# Generated at 2022-06-17 20:43:39.912929
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:43:46.205235
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Wed, 25 Mar 2020 11:34:30 GMT

{}'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Wed, 25 Mar 2020 11:34:30 GMT

{}'''


# Generated at 2022-06-17 20:44:00.213755
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Fri, 11 Oct 2019 12:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0012781620025634766
X-Frame-Options: SAMEORIGIN

'''

# Generated at 2022-06-17 20:44:10.673792
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 6b8d8f7c-4d4a-4c4e-8b4a-a4d4c4d4e4f4
X-Runtime: 0.006834
Date: Thu, 01 Jan 1970 00:00:00 GMT
Connection: close
Content-Length: 2

{}
'''

# Generated at 2022-06-17 20:44:17.791118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:44:25.702651
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Content-Type: application/json
Date: Thu, 23 Mar 2017 10:25:07 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Content-Type: application/json
Date: Thu, 23 Mar 2017 10:25:07 GMT

'''



# Generated at 2022-06-17 20:44:32.012005
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 01 Jan 2018 00:00:00 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 01 Jan 2018 00:00:00 GMT

{}'''

# Generated at 2022-06-17 20:44:37.157588
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 19 Sep 2019 10:47:40 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 19 Sep 2019 10:47:40 GMT
Server: gunicorn/19.9.0

"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:45.047481
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 1234
Date: Tue, 15 Nov 1994 08:12:31 GMT
Server: Apache
X-Powered-By: PHP/5.4.0
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Content-Length: 1234
Content-Type: application/json
Date: Tue, 15 Nov 1994 08:12:31 GMT
Server: Apache
X-Powered-By: PHP/5.4.0
'''
    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:44:50.949266
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 12
Connection: close
Server: Werkzeug/0.14.1 Python/3.7.2
Date: Thu, 14 Mar 2019 12:24:59 GMT

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 12
Content-Type: text/html; charset=utf-8
Date: Thu, 14 Mar 2019 12:24:59 GMT
Server: Werkzeug/0.14.1 Python/3.7.2

"""