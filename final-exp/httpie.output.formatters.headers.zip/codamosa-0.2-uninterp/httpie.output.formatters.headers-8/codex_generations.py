

# Generated at 2022-06-17 20:35:15.282713
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:16.780868
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-17 20:35:25.665231
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 16 Apr 2020 15:06:04 GMT
Connection: keep-alive
Content-Length: 2

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 Apr 2020 15:06:04 GMT

{}
'''

# Generated at 2022-06-17 20:35:27.397833
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:34.405848
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Tue, 21 May 2019 09:23:27 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 21 May 2019 09:23:27 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:35:35.802214
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:42.271107
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:35:51.142547
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:01.971386
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ef7d6b0c-8d6c-4a2c-b0a3-0e8c8e5d5d0a
X-Runtime: 0.012600
Server: WEBrick/1.3.1 (Ruby/2.2.4/2015-12-16)
Date: Mon, 14 Mar 2016 11:11:11 GMT
Content-Length: 2
Connection: Keep-Alive'''

# Generated at 2022-06-17 20:36:05.627869
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Wed, 27 May 2020 14:43:03 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 27 May 2020 14:43:03 GMT

{}
"""

# Generated at 2022-06-17 20:36:19.761285
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:36:28.104356
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8,ru;q=0.6
Cookie: _ga=GA1.2.131924726.1449671270
'''

# Generated at 2022-06-17 20:36:30.461722
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:38.260206
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Date: Wed, 25 Jul 2018 09:25:33 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 25 Jul 2018 09:25:33 GMT

{}'''

# Generated at 2022-06-17 20:36:47.129724
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Fri, 01 Dec 2017 20:22:46 GMT
Server: Python/3.6 aiohttp/2.3.10

{}'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Fri, 01 Dec 2017 20:22:46 GMT
Server: Python/3.6 aiohttp/2.3.10

{}'''

# Generated at 2022-06-17 20:36:58.325554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 11 Oct 2015 14:13:29 GMT
Server: gunicorn/19.3.0
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 11 Oct 2015 14:13:29 GMT
Server: gunicorn/19.3.0
'''

# Generated at 2022-06-17 20:37:08.586726
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9d5c8eae-7f58-4c48-9c13-0c7f835d8dce
ETag: W/"a7c49c8c6e3f06e6d9b5d3e2f5f3ae87"
X-Runtime: 0.013687
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:37:17.800002
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:37:19.527723
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:37:21.100454
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:32.752929
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Sun, 10 Nov 2019 21:00:00 GMT
Server: BaseHTTP/0.6 Python/3.7.3

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Date: Sun, 10 Nov 2019 21:00:00 GMT
Server: BaseHTTP/0.6 Python/3.7.3

'''

# Generated at 2022-06-17 20:37:43.425501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 13 Jul 2020 09:52:52 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0012578964233398438
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:37:54.112826
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 12
Cache-Control: max-age=3600
Date: Wed, 21 Oct 2015 07:28:00 GMT
Expires: Wed, 21 Oct 2015 08:28:00 GMT
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: max-age=3600
Content-Length: 12
Content-Type: text/html; charset=utf-8
Date: Wed, 21 Oct 2015 07:28:00 GMT
Expires: Wed, 21 Oct 2015 08:28:00 GMT
'''

# Generated at 2022-06-17 20:38:03.495603
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''

# Generated at 2022-06-17 20:38:08.968084
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 8
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Wed, 20 Feb 2019 14:45:22 GMT

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 8
Content-Type: application/json
Date: Wed, 20 Feb 2019 14:45:22 GMT
Server: gunicorn/19.9.0

"""

# Generated at 2022-06-17 20:38:16.477446
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
""")
    assert headers == """\
HTTP/1.1 200 OK
Content-Length: 5
Content-Length: 5
Content-Type: application/json
Content-Type: application/json
Connection: keep-alive
"""

# Generated at 2022-06-17 20:38:25.179540
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:38:30.607181
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-17 20:38:37.796180
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 16 Apr 2020 11:23:00 GMT
Server: gunicorn/19.9.0
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff
'''

# Generated at 2022-06-17 20:38:41.099543
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled


# Generated at 2022-06-17 20:38:59.460645
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: d5b5d8f5-c9c3-4b3f-9d9f-f6c7a6d3a6b7
X-Runtime: 0.003082
Connection: close
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Fri, 22 Jul 2016 07:09:29 GMT
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:07.377608
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': True}}
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 13
Date: Tue, 13 Mar 2018 16:45:00 GMT
X-Powered-By: Express

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 13
Content-Type: application/json
Date: Tue, 13 Mar 2018 16:45:00 GMT
X-Powered-By: Express

'''



# Generated at 2022-06-17 20:39:09.354070
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:18.129073
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 27 Mar 2017 13:21:58 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 13
Connection: keep-alive
X-Powered-By: Express
ETag: W/"d-Lve95gjOVATpfV8EL5X4nxwjKHE"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:39:23.923397
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:31.245764
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Baz: Qux
X-Baz: Quux
X-Baz: Corge
'''

# Generated at 2022-06-17 20:39:41.870260
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 13 Mar 2019 20:47:02 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00164794921875
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 13 Mar 2019 20:47:02 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.00164794921875

'''
   

# Generated at 2022-06-17 20:39:49.257615
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 16 Mar 2020 16:01:41 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Mar 2020 16:01:41 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''



# Generated at 2022-06-17 20:39:53.225387
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:39:54.748357
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:20.686724
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Content-Encoding: gzip
Date: Fri, 01 Jan 2016 00:00:00 GMT
Server: gunicorn/19.4.5
X-Powered-By: Flask
X-Processed-Time: 0.000997304916382
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:40:28.420846
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Thu, 05 Jan 2017 22:53:03 GMT
Connection: keep-alive

{}
'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 05 Jan 2017 22:53:03 GMT

{}
'''

# Generated at 2022-06-17 20:40:35.485000
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Wed, 26 Jun 2019 14:01:23 GMT
Connection: keep-alive

{}
'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 26 Jun 2019 14:01:23 GMT

{}
'''
    assert headers_formatter.format_headers(headers) == headers_sorted

# Generated at 2022-06-17 20:40:40.017254
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 01 Jul 2018 14:27:32 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Sun, 01 Jul 2018 14:27:32 GMT
Server: gunicorn/19.9.0

'''

# Generated at 2022-06-17 20:40:45.690730
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 16 May 2019 13:29:54 GMT

{}'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 May 2019 13:29:54 GMT

{}'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:40:58.761770
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 25 Oct 2020 14:52:48 GMT
Server: gunicorn/19.9.0

{}
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 25 Oct 2020 14:52:48 GMT
Server: gunicorn/19.9.0

{}
'''
    assert HeadersFormatter.format_headers(headers) == expected_headers

    # Test case 2

# Generated at 2022-06-17 20:41:08.391771
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:41:13.994135
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 18
Date: Wed, 01 May 2019 15:36:10 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Wed, 01 May 2019 15:36:10 GMT

'''
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:22.923859
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 15
Connection: keep-alive
Cache-Control: max-age=0
Accept: */*
User-Agent: HTTPie/0.9.9
Host: httpbin.org
Accept-Encoding: gzip, deflate
'''
    assert HeadersFormatter().format_headers(headers) == '''\
Content-Type: application/json
Content-Length: 15
Cache-Control: max-age=0
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''

# Generated at 2022-06-17 20:41:32.651111
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Mon, 13 Apr 2020 09:48:51 GMT
Server: nginx/1.14.0 (Ubuntu)
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Mon, 13 Apr 2020 09:48:51 GMT
Server: nginx/1.14.0 (Ubuntu)
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:50.805166
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()

# Generated at 2022-06-17 20:42:00.452351
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug
"""

# Generated at 2022-06-17 20:42:04.733142
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Bar: Baz
X-Foo: Qux
'''
    expected = '''\
Content-Type: application/json
X-Bar: Baz
X-Foo: Bar
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:08.510699
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
X-Foo: Bar
X-Foo: Baz
Content-Type: application/json
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:42:19.124436
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ae8f1c7b-9c9c-4b2d-b8a7-b9f6a0c3f8d1
X-Runtime: 0.003725
Server: WEBrick/1.3.1 (Ruby/2.1.5/2014-11-13)
Date: Mon, 24 Aug 2015 16:51:45 GMT
Connection: Keep-Alive

"""

# Generated at 2022-06-17 20:42:26.661260
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Connection: keep-alive
Date: Thu, 16 Apr 2020 16:55:04 GMT
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 Apr 2020 16:55:04 GMT
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:36.675347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: cb9c9f6a-a8c2-4f0f-a4e4-f7c8f8b4d7e9
X-Runtime: 0.006862
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 09 May 2016 14:38:15 GMT
Content-Length: 2
Connection: Keep-Alive

'''

# Generated at 2022-06-17 20:42:42.380308
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 23 Jul 2015 15:34:07 GMT
Server: Python/3.4 aiohttp/0.13.0

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 23 Jul 2015 15:34:07 GMT
Server: Python/3.4 aiohttp/0.13.0

'''

# Generated at 2022-06-17 20:42:48.804913
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 04 Mar 2019 20:46:13 GMT

{}
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: keep-alive
Date: Mon, 04 Mar 2019 20:46:13 GMT
Server: gunicorn/19.9.0

{}
"""
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:43:00.183233
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers('HTTP/1.1 200 OK\r\n'
                                       'Content-Type: application/json\r\n'
                                       'Content-Length: 18\r\n'
                                       'Connection: keep-alive\r\n'
                                       'Server: gunicorn/19.9.0\r\n'
                                       'Date: Mon, 25 Mar 2019 09:51:55 GMT\r\n'
                                       '\r\n'
                                       '{"hello": "world"}')

# Generated at 2022-06-17 20:43:30.323196
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:43:37.593530
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:46.934342
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 16 Jul 2020 12:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0123456789
X-Request-Id: 1234567890abcdef1234567890abcdef
X-Runtime: 0.0123456789
X-XSS-Protection: 1; mode=block
'''

# Generated at 2022-06-17 20:44:00.311524
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:44:10.822877
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fd5c3d5f-b8c1-4c1b-a5e5-5c9b5f5f5f5f
X-Runtime: 0.003056
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 13 Apr 2015 10:56:20 GMT
Content-Length: 2
Connection: Keep-Alive

'''

# Generated at 2022-06-17 20:44:17.364128
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: localhost:8080
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8080
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:26.262292
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sat, 16 May 2020 13:06:00 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sat, 16 May 2020 13:06:00 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:44:32.499033
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
"""
    assert HeadersFormatter().format_headers(headers) == """\
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
"""

# Generated at 2022-06-17 20:44:37.529358
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Fri, 08 Mar 2019 17:13:59 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Fri, 08 Mar 2019 17:13:59 GMT
Server: Python/3.7 aiohttp/3.5.4

'''

# Generated at 2022-06-17 20:44:44.404336
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
"""

