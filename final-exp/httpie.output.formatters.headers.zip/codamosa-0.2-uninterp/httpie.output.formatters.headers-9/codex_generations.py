

# Generated at 2022-06-17 20:35:19.058508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:25.756775
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Bar: Foo
X-Bar: Bar
X-Bar: Baz
'''
    expected = '''\
Content-Type: application/json
X-Bar: Foo
X-Bar: Bar
X-Bar: Baz
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:28.138358
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:30.316261
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:35:36.137683
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 12
Server: Werkzeug/0.15.4 Python/3.7.4
Date: Tue, 12 Nov 2019 16:28:21 GMT

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: application/json; charset=utf-8
Date: Tue, 12 Nov 2019 16:28:21 GMT
Server: Werkzeug/0.15.4 Python/3.7.4

"""

# Generated at 2022-06-17 20:35:46.806990
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Server: nginx
Date: Wed, 29 Jul 2020 12:00:00 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: PHP/7.2.24-1+ubuntu18.04.1+deb.sury.org+1
Cache-Control: no-cache, private
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59
X-RateLimit-Reset: 1596001200

{}
"""

# Generated at 2022-06-17 20:35:58.669075
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:10.929990
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.0 (Ubuntu)
Date: Sun, 19 Feb 2017 12:06:54 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 13
Connection: keep-alive
X-Powered-By: Express
ETag: W/"d-bkFcJL6W4nxh4Pj7qw6jA"
Vary: Accept-Encoding

'''

# Generated at 2022-06-17 20:36:22.317157
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept: text/html
Accept: text/plain
Accept: application/json
Accept: application/xml
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.5
Accept-Charset: utf-8
User-Agent: HTTPie/0.9.9
'''

# Generated at 2022-06-17 20:36:34.226746
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:36.893856
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:36:45.674209
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Date: Sun, 10 May 2020 14:48:00 GMT
Server: Werkzeug/1.0.1 Python/3.8.2

'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 35
Content-Type: application/json
Date: Sun, 10 May 2020 14:48:00 GMT
Server: Werkzeug/1.0.1 Python/3.8.2

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:59.150992
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:37:01.091201
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:37:10.937718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug'''

# Generated at 2022-06-17 20:37:19.879058
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 6a0d9a9f-b0d1-4d2c-a6e3-c5e5d5c5c5c5
X-Runtime: 0.005821
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 11 May 2015 10:45:28 GMT
Content-Length: 0
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

'''

# Generated at 2022-06-17 20:37:26.597313
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept: application/json
Accept: text/plain
Content-Type: application/json
Content-Length: 42
'''
    expected = '''\
GET / HTTP/1.1
Accept: application/json
Accept: text/plain
Content-Length: 42
Content-Type: application/json
Host: example.org
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:34.515238
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept-Language: en
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Accept-Language: en
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/0.9.2
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:44.115201
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "d41d8cd98f00b204e9800998ecf8427e"
X-Request-Id: 9d5b0d3a-e9c1-4b8a-a9f7-b6d5a37b7d8e
X-Runtime: 0.004566
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 20 Jul 2015 13:42:51 GMT
Content-Length: 0
Connection: Keep-Alive
'''

# Generated at 2022-06-17 20:37:54.737644
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Wed, 19 Sep 2018 22:02:04 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Mon, 17 Sep 2018 19:38:53 GMT
ETag: "2d-56f5f1f5e5b40"
Accept-Ranges: bytes
Content-Length: 45
Content-Type: text/html
'''

# Generated at 2022-06-17 20:38:06.332907
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Tue, 26 Mar 2019 08:13:56 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Tue, 26 Mar 2019 08:13:56 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:07.776700
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:10.691529
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:38:13.047559
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:14.823846
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:24.160489
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:38:27.603795
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Content-Encoding: gzip
Server: nginx
"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 5
Content-Type: application/json
Server: nginx
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:33.957854
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Tue, 28 May 2019 15:40:08 GMT
Content-Length: 2

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Tue, 28 May 2019 15:40:08 GMT

{}'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:38:38.316197
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
'''
    assert HeadersFormatter().format_headers(headers) == '''\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
'''



# Generated at 2022-06-17 20:38:41.696239
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:58.378192
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 10 Dec 2018 10:02:37 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 10 Dec 2018 10:02:37 GMT
Server: gunicorn/19.9.0

{}
"""

# Generated at 2022-06-17 20:39:05.258826
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Tue, 23 Apr 2019 16:46:25 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 23 Apr 2019 16:46:25 GMT
Server: gunicorn/19.9.0

{}
"""

# Generated at 2022-06-17 20:39:06.714901
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:15.236327
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Thu, 23 Apr 2020 16:54:46 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Thu, 23 Apr 2020 16:54:46 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:39:23.625925
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Tue, 21 May 2019 11:18:15 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0014450550079345703
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:27.542479
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 5
Accept: application/json
Accept: application/xml
'''
    expected = '''\
Content-Type: application/json
Content-Length: 5
Accept: application/json
Accept: application/xml
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:39:37.332363
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:39:44.945550
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Set-Cookie: foo=bar
Set-Cookie: bar=baz
Connection: keep-alive
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: bar=baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:39:52.296449
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9e0c6d1d-f8b6-4b6d-9a0a-8a9a2f5b6c7d
ETag: W/"a7f3f07a9b9c22b8d9279833976cfb2a"
X-Runtime: 0.013077
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:40:01.890394
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    HTTP/1.1 200 OK
    Date: Mon, 23 May 2005 22:38:34 GMT
    Content-Type: text/html; charset=UTF-8
    Content-Encoding: UTF-8
    Content-Length: 138
    Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
    Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
    ETag: "3f80f-1b6-3e1cb03b"
    Accept-Ranges: bytes
    Connection: close
    '''

# Generated at 2022-06-17 20:40:13.139107
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: www.example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.example.com
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:15.922505
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True
    assert formatter.enabled == True


# Generated at 2022-06-17 20:40:24.056183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Mon, 02 Dec 2019 18:37:17 GMT

{}
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 02 Dec 2019 18:37:17 GMT

{}
'''

# Generated at 2022-06-17 20:40:32.341982
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Quux
X-Baz: Corge
X-Baz: Grault
X-Baz: Garply
X-Baz: Waldo
X-Baz: Fred
X-Baz: Plugh
X-Baz: Xyzzy
X-Baz: Thud
'''

# Generated at 2022-06-17 20:40:36.958361
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 3
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
Content-Type: application/json
Content-Length: 3
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:46.234234
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:40:49.770221
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:59.716541
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: W/"b6a7f8d8e6c3e9a9f9e9b6a7f8d8e6c3"
X-Request-Id: 7a8b9c0d1e2f3g4h5i6j7k8l9m
X-Runtime: 0.012345
Date: Sat, 01 Jan 2000 00:00:00 GMT
Connection: close
Content-Length: 2

{}
'''

# Generated at 2022-06-17 20:41:06.165273
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614

'''
   

# Generated at 2022-06-17 20:41:11.550108
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Thu, 19 Apr 2018 10:03:52 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 19 Apr 2018 10:03:52 GMT

{}'''

# Generated at 2022-06-17 20:41:35.426963
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: nginx

{}'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: nginx

{}'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:41:39.972575
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:47.611882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Wed, 27 May 2015 09:27:53 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 27 May 2015 09:27:53 GMT

{}'''

# Generated at 2022-06-17 20:41:59.295205
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 27 Nov 2017 21:55:11 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
X-Powered-By: Express
ETag: W/"2-L7UWuq5oN9WxlvB2qk6r5Q"
'''

# Generated at 2022-06-17 20:42:05.266094
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:42:09.204936
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
GET / HTTP/1.1
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
"""
    assert formatter.format_headers(headers) == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/0.9.9
"""

# Generated at 2022-06-17 20:42:19.187235
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b7b0b9e8e7f1b8a8b7b0b9e8e7f1b8a8"
X-Request-Id: b7b0b9e8e7f1b8a8b7b0b9e8e7f1b8a8
X-Runtime: 0.001234
Date: Thu, 01 Jan 1970 00:00:00 GMT
Content-Length: 2
Connection: close
'''

# Generated at 2022-06-17 20:42:26.387470
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Mon, 07 Jan 2019 12:33:45 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 07 Jan 2019 12:33:45 GMT

{}'''

# Generated at 2022-06-17 20:42:34.930196
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Connection: keep-alive
Date: Mon, 13 Apr 2020 16:57:19 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 13 Apr 2020 16:57:19 GMT

'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:42:45.817870
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: b0c9b9a9-e3f8-4c2a-a7f6-d0e8e8f8f8f8
X-Runtime: 0.005931
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:43:18.662421
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fb2c2b7f-8b8d-4d8f-9c0f-a8f8a7c8e6b1
ETag: W/"a8f8a7c8e6b1f9c0d8b8d4fb2c2b7f8b"
X-Runtime: 0.006639
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:43:23.153267
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Date: Thu, 16 Jan 2020 16:33:55 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 Jan 2020 16:33:55 GMT

'''

# Generated at 2022-06-17 20:43:30.789634
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers(
        '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: close
Date: Mon, 01 Jan 1970 00:00:00 GMT
Server: SimpleHTTP/0.6 Python/3.7.4

''')
    assert headers == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 12
Content-Type: application/json
Date: Mon, 01 Jan 1970 00:00:00 GMT
Server: SimpleHTTP/0.6 Python/3.7.4

'''

# Generated at 2022-06-17 20:43:40.492270
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:43:46.125189
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:00.216186
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9a1b9d9b-5f9f-4f1d-8c2a-f8b9a0d7e8b1
X-Runtime: 0.007034
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 20 Jul 2015 13:42:18 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

{}"""

# Generated at 2022-06-17 20:44:08.437205
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected


# Generated at 2022-06-17 20:44:14.690820
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 07 Feb 2019 13:22:30 GMT

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 07 Feb 2019 13:22:30 GMT
Server: gunicorn/19.9.0

"""


# Generated at 2022-06-17 20:44:22.476749
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Foo: Bar
X-Foo: Baz
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: keep-alive
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:28.102148
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""