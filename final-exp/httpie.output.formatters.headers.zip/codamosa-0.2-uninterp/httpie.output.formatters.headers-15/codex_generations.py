

# Generated at 2022-06-17 20:35:16.045374
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: close

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 18
Content-Type: application/json

'''

# Generated at 2022-06-17 20:35:23.470134
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.com
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8,ru;q=0.6
'''

# Generated at 2022-06-17 20:35:32.957503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Date: Sun, 16 Aug 2020 17:17:29 GMT
Transfer-Encoding: chunked
Vary: Origin, Accept-Encoding
X-Powered-By: Express

'''
    expected_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/json
Date: Sun, 16 Aug 2020 17:17:29 GMT
Transfer-Encoding: chunked
Vary: Origin, Accept-Encoding
X-Powered-By: Express

'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:35:34.554572
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:35:36.001967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:35:42.367257
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "d41d8cd98f00b204e9800998ecf8427e"
X-Request-Id: ae7f9a1f-6a2a-4d6f-b6d8-6a8c8f9a0a7f
X-Runtime: 0.001234
Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-11-22)
Date: Mon, 02 Dec 2013 10:44:36 GMT
Content-Length: 0
Connection: Keep-Alive
'''

# Generated at 2022-06-17 20:35:46.042899
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 19 Feb 2018 16:54:03 GMT
Content-Length: 2

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 19 Feb 2018 16:54:03 GMT

{}'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:35:58.889182
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Baz: Qux
X-Baz: Quux
X-Baz: Corge
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Baz: Qux
X-Baz: Quux
X-Baz: Corge
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''

# Generated at 2022-06-17 20:36:11.005848
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 27 Nov 2017 21:55:11 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-L7UW/Yj8m3rKs8j3rKsQ"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:36:22.322279
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 18 Oct 2015 21:56:03 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.0008270740509033203
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:36:25.357487
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:36:26.948718
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:38.332177
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 20 May 2020 11:39:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0013480186462402344
Content-Length: 2
Content-Type: application/json
Date: Wed, 20 May 2020 11:39:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0013480186462402344'''

# Generated at 2022-06-17 20:36:45.502545
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:59.083809
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ea9f5c7d-b8d0-4c6d-8b7a-a9f822a93f5e
ETag: W/"2aae1f8f4b0b8b706fbc4058d5229e8b"
X-Runtime: 0.005974
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:37:01.037400
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:08.246246
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Bar: Baz
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Bar: Baz
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:37:10.851808
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:12.155934
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:18.953194
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:37:31.199337
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 22 Sep 2019 19:53:15 GMT
Server: Python/3.7 aiohttp/3.6.2

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 22 Sep 2019 19:53:15 GMT
Server: Python/3.7 aiohttp/3.6.2

'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:37:32.873524
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:41.058218
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 27 Apr 2020 19:13:03 GMT
Content-Length: 2

'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Apr 2020 19:13:03 GMT

'''

# Generated at 2022-06-17 20:37:45.607718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: close
Date: Mon, 11 Mar 2019 12:30:00 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 18
Content-Type: application/json
Date: Mon, 11 Mar 2019 12:30:00 GMT
Server: Python/3.7 aiohttp/3.5.4

'''

# Generated at 2022-06-17 20:37:58.737007
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.1
Date: Sun, 28 Aug 2016 02:56:57 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: PHP/5.6.22-1+deb.sury.org~xenial+1
Set-Cookie: PHPSESSID=r2t5uvjq435r4q7ib3vtdjq120; path=/
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache

{}
'''

# Generated at 2022-06-17 20:38:02.301384
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:38:03.857013
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:09.413890
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Thu, 16 Mar 2017 11:45:10 GMT
Server: gunicorn/19.7.1

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Thu, 16 Mar 2017 11:45:10 GMT
Server: gunicorn/19.7.1

'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:38:19.434434
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Mon, 13 Jul 2015 02:51:38 GMT
Server: gunicorn/19.3.0

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 13 Jul 2015 02:51:38 GMT
Server: gunicorn/19.3.0

{}
'''



# Generated at 2022-06-17 20:38:26.386429
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Qux
X-Baz: Qux
X-Baz: Qux
X-Baz: Qux
'''
    expected = '''\
Content-Type: application/json
X-Bar: Baz
X-Bar: Qux
X-Bar: Qux
X-Baz: Qux
X-Baz: Qux
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:39.829025
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 5
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
'''
    expected = '''\
Content-Type: application/json
Content-Length: 5
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:46.535880
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Accept: application/json
X-Custom-Header: abc
X-Custom-Header: def
X-Custom-Header: ghi'''
    expected = '''\
Content-Type: application/json
Accept: application/json
X-Custom-Header: abc
X-Custom-Header: def
X-Custom-Header: ghi'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:58.047182
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('HTTP/1.1 200 OK\r\n'
                             'Content-Type: application/json\r\n'
                             'Content-Length: 2\r\n'
                             'Connection: close\r\n'
                             '\r\n'
                             '{}') == 'HTTP/1.1 200 OK\r\n' \
                                      'Connection: close\r\n' \
                                      'Content-Length: 2\r\n' \
                                      'Content-Type: application/json\r\n' \
                                      '\r\n' \
                                      '{}'

# Generated at 2022-06-17 20:39:06.821161
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 5b9d7f5a-8f3e-4f5e-b7d3-e8a9c9e0b0d1
ETag: W/"c8f0a8f2c0d7e2a8e9e9f9e9d9d9e9e9"
X-Runtime: 0.005981
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:39:15.035020
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 21 Mar 2017 15:25:24 GMT
Server: gunicorn/19.7.1

{}'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: keep-alive
Date: Tue, 21 Mar 2017 15:25:24 GMT
Server: gunicorn/19.7.1

{}'''

# Generated at 2022-06-17 20:39:21.603569
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:23.507884
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:39:30.193175
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: BaseHTTP/0.6 Python/3.6.4

{}
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
Date: Mon, 01 Jan 2018 00:00:00 GMT
Server: BaseHTTP/0.6 Python/3.6.4

{}
'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:39:33.263857
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept: application/json
Accept: application/xml
User-Agent: HTTPie/0.9.2
'''
    expected_headers = '''\
GET / HTTP/1.1
Accept: application/json
Accept: application/xml
Host: example.org
User-Agent: HTTPie/0.9.2
'''
    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:39:39.508633
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 2
Accept: application/json
Accept: application/xml
'''
    expected = '''\
Content-Type: application/json
Content-Length: 2
Accept: application/json
Accept: application/xml
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:01.649652
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.0 (Ubuntu)
Date: Mon, 27 Mar 2017 13:26:55 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-n4LQ9dDMwtH6bVzR2EK2RJFQ2Y"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:40:10.973292
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
    HTTP/1.1 200 OK
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Server: Apache/2.2.14 (Win32)
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    Content-Length: 88
    Content-Type: text/html
    Connection: Closed
    """
    expected = """
    HTTP/1.1 200 OK
    Connection: Closed
    Content-Length: 88
    Content-Type: text/html
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    Server: Apache/2.2.14 (Win32)
    """
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:13.997960
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:40:14.660775
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:16.307153
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:26.739131
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Thu, 30 Aug 2018 18:17:43 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Mon, 20 Aug 2018 13:43:22 GMT
ETag: "2d-57a6a7a8a8a80"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/html
"""

# Generated at 2022-06-17 20:40:34.102418
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Fri, 15 Mar 2019 14:26:09 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Fri, 15 Mar 2019 14:26:09 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:40:43.863021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Fri, 01 Dec 2017 20:21:25 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: PHP/7.0.22-0ubuntu0.16.04.1
Cache-Control: no-cache, private
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59

{}'''

# Generated at 2022-06-17 20:40:52.021171
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:40:57.627296
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:41:27.879472
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:41:38.084565
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Foo: Quux
X-Foo: Quuz
X-Foo: Corge
X-Foo: Grault
X-Foo: Garply
X-Foo: Waldo
X-Foo: Fred
X-Foo: Plugh
X-Foo: Xyzzy
X-Foo: Thud
X-Foo: Wibble
X-Foo: Wobble
X-Foo: Wubble
X-Foo: Flob
X-Foo: Bob
'''

# Generated at 2022-06-17 20:41:47.094422
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 5
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuux
'''
    expected = '''\
Content-Type: application/json
Content-Length: 5
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:59.091758
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 27 Nov 2017 21:54:35 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-L7UWpfVVb/Fb/qTj+5yDGw"
Vary: Accept-Encoding
Allow: GET,HEAD,PUT,PATCH,POST,DELETE
Content-Encoding: gzip
'''

# Generated at 2022-06-17 20:42:00.768749
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:42:07.356332
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "a7c4a8d06e2c7f1c95f33d90f915b366"
X-Request-Id: 9f5f079a-9b7e-4b16-a4fb-b6ba1e7cc64a
X-Runtime: 0.013678
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 16 Nov 2015 14:29:35 GMT
Content-Length: 66
Connection: Keep-Alive

'''

# Generated at 2022-06-17 20:42:18.753606
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: cb8a2f6c-9b4a-4e7f-b9a6-5e5d5a5b7a8c
ETag: "9b1d0c7f7f0d3e67a3a2ba4cbf458615"
X-Runtime: 0.012557
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:42:29.222051
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b6b3f3f3c9d0d6e8c9e9e0f3f3f3f3f3"
X-Request-Id: 6c8f5a0b-9c9c-4f7a-a8e4-7e4f4a4a4a4a
X-Runtime: 0.001234
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Wed, 13 Apr 2016 10:00:00 GMT
Content-Length: 1234
Connection: Keep-Alive
'''

# Generated at 2022-06-17 20:42:36.640569
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''


# Generated at 2022-06-17 20:42:42.620784
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 26 May 2019 06:56:44 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 26 May 2019 06:56:44 GMT
Server: Python/3.7 aiohttp/3.5.4

'''
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-17 20:43:15.722507
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:22.932021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Tue, 28 May 2019 11:35:36 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Tue, 28 May 2019 11:35:36 GMT

{}'''

# Generated at 2022-06-17 20:43:31.709215
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 01 Jan 1970 00:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0009889602661132812
Via: 1.1 vegur
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 01 Jan 1970 00:00:00 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.0009889602661132812
'''

# Generated at 2022-06-17 20:43:33.406679
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-17 20:43:35.722017
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:43:44.518426
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:43:50.333179
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: www.example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.example.com
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:44:00.427256
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Tue, 28 Jul 2020 09:03:03 GMT
Server: gunicorn/19.9.0

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Tue, 28 Jul 2020 09:03:03 GMT
Server: gunicorn/19.9.0

'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:02.158125
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:44:09.840959
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
'''