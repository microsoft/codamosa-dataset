

# Generated at 2022-06-17 20:35:17.073331
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 12
Connection: close

'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 12
Content-Type: text/html; charset=utf-8

'''

# Generated at 2022-06-17 20:35:19.057714
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled


# Generated at 2022-06-17 20:35:25.629829
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-17 20:35:31.640948
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 20 May 2019 11:33:47 GMT
Content-Length: 2

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 20 May 2019 11:33:47 GMT

{}
"""


# Generated at 2022-06-17 20:35:38.816320
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 26 Jan 2020 21:55:48 GMT
Server: BaseHTTP/0.6 Python/3.7.4

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 26 Jan 2020 21:55:48 GMT
Server: BaseHTTP/0.6 Python/3.7.4

'''

# Generated at 2022-06-17 20:35:45.984529
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 7
Connection: keep-alive
Date: Mon, 13 Apr 2020 15:03:17 GMT
Server: nginx/1.17.5

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 7
Content-Type: application/json
Date: Mon, 13 Apr 2020 15:03:17 GMT
Server: nginx/1.17.5

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:35:58.866443
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:36:08.460117
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Fri, 10 Jul 2020 12:50:00 GMT

{}
""")
    assert headers == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Fri, 10 Jul 2020 12:50:00 GMT

{}
"""

# Generated at 2022-06-17 20:36:17.236998
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 28 Sep 2017 08:28:52 GMT
Server: Python/3.6 aiohttp/2.3.10

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 28 Sep 2017 08:28:52 GMT
Server: Python/3.6 aiohttp/2.3.10

'''



# Generated at 2022-06-17 20:36:27.154798
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Cache-Control: max-age=0, private, must-revalidate
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
X-Request-Id: 8a5f5b5d-8b2a-4f1d-b1a5-c9e9b9f0c4d4
X-Runtime: 0.002753
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Thu, 07 Sep 2017 15:14:42 GMT

{}'''


# Generated at 2022-06-17 20:36:31.478363
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:36:35.108200
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:36:37.348598
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:36:48.062905
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:36:59.878347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:37:09.425939
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Set-Cookie: csrftoken=uw7JNbvVcZjtYG9G9GZl3T1NgQI2IViA; expires=Sun, 22-Dec-2019 22:44:35 GMT; Max-Age=31449600; Path=/
Date: Fri, 20 Dec 2019 22:44:35 GMT

'''

# Generated at 2022-06-17 20:37:16.397770
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
Content-Type: application/json
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:25.424496
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: c0f9a8e8-7a5a-4d1d-a7e0-b9d9b2c2f9a0
X-Runtime: 0.006484
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 28 Nov 2016 16:14:23 GMT
Content-Length: 2
Connection: Keep-Alive

"""

# Generated at 2022-06-17 20:37:31.036965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:37:41.964179
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 11 Apr 2019 13:16:27 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0015759468
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:37:59.645704
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Baz: Qux
X-Baz: Quux
X-Baz: Corge
'''

# Generated at 2022-06-17 20:38:08.565441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Foo: Quux
X-Foo: Quuz
X-Foo: Corge
X-Foo: Grault
X-Foo: Garply
X-Foo: Waldo
X-Foo: Fred
X-Foo: Plugh
X-Foo: Xyzzy
X-Foo: Thud
'''

# Generated at 2022-06-17 20:38:17.920548
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sun, 24 May 2020 14:53:56 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 24 May 2020 14:53:56 GMT
Server: nginx/1.14.0 (Ubuntu)

'''



# Generated at 2022-06-17 20:38:23.836702
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:38:29.694735
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
Connection: close
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:36.198024
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Fri, 16 Oct 2015 18:43:31 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Fri, 16 Oct 2015 18:43:31 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:38:42.038660
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 24 Oct 2019 14:50:08 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 24 Oct 2019 14:50:08 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:38:51.637788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:38:55.555614
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    GET / HTTP/1.1
    Host: httpbin.org
    Accept-Encoding: gzip, deflate
    Accept: */*
    User-Agent: HTTPie/0.9.9
    Connection: keep-alive
    '''
    expected_headers = '''
    GET / HTTP/1.1
    Accept: */*
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    Host: httpbin.org
    User-Agent: HTTPie/0.9.9
    '''
    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:39:04.492589
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Wed, 20 May 2020 09:37:51 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0012478828430175781
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:23.130947
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 26 Jan 2020 21:49:49 GMT
Server: Python/3.7 aiohttp/3.6.2

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 26 Jan 2020 21:49:49 GMT
Server: Python/3.7 aiohttp/3.6.2

'''

# Generated at 2022-06-17 20:39:30.609488
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sat, 14 Mar 2020 17:31:27 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0012578964233398438
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:41.095961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 1a8b012c-b93e-4cbf-9607-b5e8e7f4d4c2
ETag: W/"b7eae427b009f9f3e5ad2f2c7e3358d6"
X-Runtime: 0.013777
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:39:49.560973
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: keep-alive
Date: Mon, 27 Jul 2015 22:45:25 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.00132890701294
Via: 1.1 vegur
'''

# Generated at 2022-06-17 20:39:59.928764
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:40:01.645391
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:40:04.358335
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:11.393017
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: close
Date: Sun, 26 Jul 2015 22:13:43 GMT
Server: BaseHTTP/0.3 Python/2.7.6

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 18
Content-Type: application/json
Date: Sun, 26 Jul 2015 22:13:43 GMT
Server: BaseHTTP/0.3 Python/2.7.6

'''
    assert headers_formatter.format_headers(headers) == expected


# Generated at 2022-06-17 20:40:22.203625
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:40:30.231458
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Server: nginx/1.6.2
Date: Thu, 16 Jul 2015 01:01:48 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 16 Jul 2015 01:01:48 GMT
Server: nginx/1.6.2

"""
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:40:56.802682
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:41:05.538383
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 348
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 16 Apr 2018 14:22:11 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 348
Content-Type: application/json
Date: Mon, 16 Apr 2018 14:22:11 GMT
Server: gunicorn/19.9.0

"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:13.277291
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 3
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fd8d8c7b-5e5c-4b0d-b2f7-a5a9b9c8e8d7
X-Runtime: 0.003075
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Fri, 27 Jan 2017 13:09:31 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

'''

# Generated at 2022-06-17 20:41:21.567160
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Thu, 21 May 2015 20:11:58 GMT
Server: WSGIServer/0.1 Python/2.7.6

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Date: Thu, 21 May 2015 20:11:58 GMT
Server: WSGIServer/0.1 Python/2.7.6

{}
"""

# Generated at 2022-06-17 20:41:24.864369
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Thu, 23 Jul 2020 14:51:12 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Thu, 23 Jul 2020 14:51:12 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:27.195418
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:41:37.570102
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = '''\
HTTP/1.1 200 OK
Date: Wed, 18 Mar 2020 18:22:13 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Wed, 18 Mar 2020 18:22:13 GMT
ETag: "1c-5a5b5c5d5e5f6"
Accept-Ranges: bytes
Content-Length: 28
Content-Type: text/html

'''

# Generated at 2022-06-17 20:41:39.229493
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:41:47.479816
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:41:49.910249
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:42:21.413880
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ae8b2e4c-d4d4-4d1c-8a3a-5f5d5e5f5g5h
ETag: "b7b7b7b7b7b7b7b7b7b7b7b7b7b7b7b7"
X-Runtime: 0.012345
Connection: close
Server: nginx/1.4.6 (Ubuntu)
Date: Wed, 16 Jul 2014 10:18:32 GMT
Content-Length: 13

'''

# Generated at 2022-06-17 20:42:31.315541
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Pragma: no-cache
Expires: -1
Server: Microsoft-IIS/7.5
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Tue, 12 Mar 2019 11:38:40 GMT

{}
"""

# Generated at 2022-06-17 20:42:38.646802
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Thu, 18 Oct 2018 13:53:47 GMT
Server: Python/3.6 aiohttp/3.4.4

'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Thu, 18 Oct 2018 13:53:47 GMT
Server: Python/3.6 aiohttp/3.4.4

'''
    assert headers_formatter.format_headers(headers) == expected_headers


# Generated at 2022-06-17 20:42:45.206677
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:42:54.192347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.0 (Ubuntu)
Date: Mon, 27 Mar 2017 13:26:45 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-n4LQ9dDMdq3t5mbV8KvLxw"
'''

# Generated at 2022-06-17 20:43:03.984777
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Host: example.org
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8,ru;q=0.6
"""

# Generated at 2022-06-17 20:43:08.538436
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Date: Mon, 27 Jul 2015 22:32:00 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 18
Connection: keep-alive
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
Cache-Control: no-cache

'''

# Generated at 2022-06-17 20:43:18.089548
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9e8f4956-1e23-4c40-9f5a-235d26dd3a7f
X-Runtime: 0.005775
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Tue, 21 Jul 2015 10:27:32 GMT
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

{}
'''

# Generated at 2022-06-17 20:43:25.600523
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:43:33.060718
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b9b9d6c9a6f9c8e8a6f9c8e8a6f9c8e8"
X-Request-Id: b9b9d6c9a6f9c8e8a6f9c8e8a6f9c8e8
X-Runtime: 0.001234
Connection: close
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 09 Jan 2017 17:00:00 GMT
Content-Length: 0
'''
    assert formatter.format_

# Generated at 2022-06-17 20:44:01.776410
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
X-Foo: Bar
X-Foo: Baz
X-Bar: Foo
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
X-Bar: Foo
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:44:07.939148
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''



# Generated at 2022-06-17 20:44:12.186475
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 1234
Content-Length: 5678
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 1234
Content-Length: 5678
Content-Type: application/json
"""
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:44:18.972359
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Etag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  Hello World, this is a very simple HTML document.
</body>
</html>
'''

# Generated at 2022-06-17 20:44:27.299746
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 19 Jul 2015 22:10:13 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 19 Jul 2015 22:10:13 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:44:35.147893
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:44:42.120802
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Date: Thu, 18 Jul 2019 11:02:30 GMT

{}'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 18 Jul 2019 11:02:30 GMT

{}'''

# Generated at 2022-06-17 20:44:47.471031
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:59.884660
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Content-Type: application/json\r\nAccept: application/json\r\n') == 'Content-Type: application/json\r\nAccept: application/json\r\n'
    assert headers_formatter.format_headers('Accept: application/json\r\nContent-Type: application/json\r\n') == 'Content-Type: application/json\r\nAccept: application/json\r\n'
    assert headers_formatter.format_headers('Accept: application/json\r\nContent-Type: application/json\r\nAccept: application/json\r\n') == 'Content-Type: application/json\r\nAccept: application/json\r\nAccept: application/json\r\n'
   

# Generated at 2022-06-17 20:45:04.776253
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Mon, 27 Jul 2015 22:32:00 GMT
Server: Python/3.4 aiohttp/0.15.2

{}"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 22:32:00 GMT
Server: Python/3.4 aiohttp/0.15.2

{}"""