

# Generated at 2022-06-17 20:35:17.488166
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:35:24.499126
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT
Connection: keep-alive
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT
Server: gunicorn/19.3.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614

'''
   

# Generated at 2022-06-17 20:35:28.686149
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close

'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 5
Content-Type: application/json

'''

# Generated at 2022-06-17 20:35:35.770624
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: c8e9d9c7-e0e4-4f0d-8f4c-a9d9e9c7e0e4
X-Runtime: 0.002881
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 13 Apr 2015 10:37:30 GMT
Content-Length: 2
Connection: Keep-Alive

"""

# Generated at 2022-06-17 20:35:42.260015
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:35:44.280502
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:35:51.035402
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options['headers']['sort'] = True
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 16 Apr 2018 13:59:22 GMT
Content-Length: 2

{}
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Apr 2018 13:59:22 GMT

{}
'''

# Generated at 2022-06-17 20:35:59.297747
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''

# Generated at 2022-06-17 20:36:09.465882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sun, 24 May 2020 21:17:31 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 24 May 2020 21:17:31 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:18.747086
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sat, 14 Mar 2020 14:54:35 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 18
Content-Type: application/json
Connection: keep-alive
Date: Sat, 14 Mar 2020 14:54:35 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:36:29.499578
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Tue, 16 Jun 2020 17:38:22 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.001589059829711914
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:36:39.590625
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:49.105180
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: cb9c5e3a-9b7c-4e5d-b5d1-b9f7d1d8e8b7
ETag: W/"b7e7d8e8b5d1b9f7d1d8e8b7cbe5d1b9f7d1d8e8b7"
X-Runtime: 0.006821
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:36:55.382134
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Fri, 28 Aug 2020 14:58:42 GMT
Server: gunicorn/20.0.4
X-Powered-By: Flask
X-Processed-Time: 0.00139904022217
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:37:06.322540
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Tue, 11 Jul 2017 17:11:34 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-LkFq/YQv/YQ8eR9pfV6xRw"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:37:07.220077
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-17 20:37:16.215386
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:37:17.993031
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:37:24.906070
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2
Server: gunicorn/19.9.0
Date: Wed, 27 Mar 2019 14:12:47 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 27 Mar 2019 14:12:47 GMT
Server: gunicorn/19.9.0

{}
"""

# Generated at 2022-06-17 20:37:26.462390
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:43.350582
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b9b2c9f5c9b1c9f5c9b2c9f5c9b3c9f5"
X-Request-Id: d8f8f8f8-f8f8-f8f8-f8f8-f8f8f8f8f8f8
X-Runtime: 0.001234
Date: Tue, 01 Jan 2013 17:15:23 GMT
Content-Length: 18
Connection: keep-alive

'''

# Generated at 2022-06-17 20:37:54.112920
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 27 Jun 2018 07:27:53 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 27 Jun 2018 07:27:53 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert f.format_headers(headers) == expected_headers



# Generated at 2022-06-17 20:37:55.968902
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled


# Generated at 2022-06-17 20:38:04.672372
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 14 Mar 2019 15:07:31 GMT

"""
    assert headers_formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Thu, 14 Mar 2019 15:07:31 GMT
Server: gunicorn/19.9.0

"""


# Generated at 2022-06-17 20:38:13.398315
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:38:21.353044
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuux
'''
    expected = '''\
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:30.988921
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Tue, 28 May 2019 12:18:20 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    expected_headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Tue, 28 May 2019 12:18:20 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:38:36.133767
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Tue, 10 Jul 2018 10:00:00 GMT

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Tue, 10 Jul 2018 10:00:00 GMT

{}
'''

# Generated at 2022-06-17 20:38:41.222444
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Cache-Control: no-cache

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: close
Content-Length: 2
Content-Type: application/json

{}
'''



# Generated at 2022-06-17 20:38:51.087264
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Fri, 01 Jan 2016 00:00:00 GMT
Server: gunicorn/19.4.5
X-Powered-By: Flask
X-Processed-Time: 0.000787019729614
Via: 1.1 vegur
'''

# Generated at 2022-06-17 20:39:03.704177
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Tue, 24 Apr 2018 09:13:49 GMT

{}"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Tue, 24 Apr 2018 09:13:49 GMT

{}"""



# Generated at 2022-06-17 20:39:11.499473
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Tue, 12 Mar 2019 15:20:16 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Tue, 12 Mar 2019 15:20:16 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:19.124180
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Baz: Qux
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: close
X-Bar: Baz
X-Bar: Qux
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''



# Generated at 2022-06-17 20:39:25.924399
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Wed, 11 Dec 2019 13:41:36 GMT

{}"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 11 Dec 2019 13:41:36 GMT
Server: gunicorn/19.9.0

{}"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:28.707053
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

'''
    assert hf.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

'''

# Generated at 2022-06-17 20:39:39.966950
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Thu, 21 May 2020 11:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00097799301147461
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Thu, 21 May 2020 11:00:00 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.00097799301147461

'''

# Generated at 2022-06-17 20:39:47.542039
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST / HTTP/1.1
Host: example.org
Content-Type: application/json
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2
User-Agent: HTTPie/0.9.9

'''
    expected = '''\
POST / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Host: example.org
User-Agent: HTTPie/0.9.9

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:54.832627
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:40:01.942325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
'''


# Generated at 2022-06-17 20:40:11.392252
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: e8a8c8b4-4c4f-4b4c-8d8e-e8e8e8e8e8e8
X-Runtime: 0.006896
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 23 Jan 2017 15:42:51 GMT
Content-Length: 2
Connection: Keep-Alive

'''

# Generated at 2022-06-17 20:40:32.494315
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Set-Cookie: csrftoken=uw7JNbfo8oEOJj9XYWfZ75YbvC1grsTD; expires=Sun, 22-Mar-2020 11:51:48 GMT; Max-Age=31449600; Path=/
Date: Sat, 23 Mar 2019 11:51:48 GMT

'''

# Generated at 2022-06-17 20:40:38.514007
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 15 Sep 2019 11:11:11 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 15 Sep 2019 11:11:11 GMT
Server: gunicorn/19.9.0

{}
"""

# Generated at 2022-06-17 20:40:47.109594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Mon, 13 Jul 2020 10:26:17 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0012578964233398438
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:40:58.677683
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Wed, 13 Jun 2018 07:13:53 GMT
Server: Python/3.6 aiohttp/3.4.4

'''
    headers_formatted = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Wed, 13 Jun 2018 07:13:53 GMT
Server: Python/3.6 aiohttp/3.4.4

'''
    assert headers_formatter.format_headers(headers) == headers_formatted

# Generated at 2022-06-17 20:41:08.354611
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Sun, 19 Apr 2020 11:55:13 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.002357006072998047
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:41:13.928106
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 24 Jun 2020 10:41:51 GMT
Content-Length: 2

{}
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 24 Jun 2020 10:41:51 GMT

{}
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:21.472589
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:41:26.196290
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Connection: keep-alive
Date: Tue, 12 Mar 2019 19:45:50 GMT

{}
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 12 Mar 2019 19:45:50 GMT

{}
'''



# Generated at 2022-06-17 20:41:37.518177
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: e9d5d1e9-0f1a-4e2f-b7c6-b9e0c7f8d3f3
X-Runtime: 0.004521
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Mon, 16 Nov 2015 15:49:14 GMT
Content-Length: 2
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/

{}
'''

# Generated at 2022-06-17 20:41:46.100694
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
Server: gunicorn/19.9.0
Date: Wed, 21 Nov 2018 14:17:34 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 5
Content-Type: application/json
Date: Wed, 21 Nov 2018 14:17:34 GMT
Server: gunicorn/19.9.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:05.417315
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Wed, 11 Sep 2019 07:51:59 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Wed, 11 Sep 2019 07:51:59 GMT
Server: gunicorn/19.9.0

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:06.632298
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:42:17.919505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "a7b3c7d9e5f3g7h9i5j3k7l9m5n3o7p9q5r3s7t9u5v3w7x9y5z3"
X-Request-Id: a7b3c7d9e5f3g7h9i5j3k7l9m5n3o7p9q5r3s7t9u5v3w7x9y5z3
X-Runtime: 0.012345
Date: Mon, 13 Apr 2015 18:52:30 GMT
Content-Length: 1337
Connection: close
'''

# Generated at 2022-06-17 20:42:21.212791
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:42:31.192534
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
Content-Length: 5
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Foo: Quux
X-Foo: Quuz
X-Foo: Corge
X-Foo: Grault
X-Foo: Garply
X-Foo: Waldo
X-Foo: Fred
X-Foo: Plugh
X-Foo: Xyzzy
X-Foo: Thud
'''

# Generated at 2022-06-17 20:42:39.397066
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 27 Nov 2017 21:55:29 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 13
Connection: keep-alive
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
X-Powered-By: Express
ETag: W/"d-Lve95gjOVATpfV8EL5X4nxwjKHE"
Vary: Origin, Accept-Encoding
Allow: GET,HEAD,PUT,PATCH,POST,DELETE
Content-Encoding: gzip
'''

# Generated at 2022-06-17 20:42:45.769606
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 8b5a8c8f-6c7e-4d5a-a8c7-9e9d3c7e0a3c
ETag: W/"b2b7c9d6e9c8e4f9f2c4d4d4b8d8c9d2"
X-Runtime: 0.013591
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:42:49.424313
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-17 20:43:00.395145
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9e4e9a8b-d8d4-4c7a-a9c8-a0c8f9b9f9b9
X-Runtime: 0.003058
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 04 Jul 2016 08:05:34 GMT
Content-Length: 2
Connection: Keep-Alive

{}
'''

# Generated at 2022-06-17 20:43:11.543016
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "b7b0a9f6e9f8b8d6b8d6b8d6b8d6b8d6"
X-Request-Id: 4e8c8b7d-a2f4-4a4a-8b4a-8b4a8b4a8b4a
X-Runtime: 0.002386
Date: Thu, 01 Jan 1970 00:00:00 GMT
Content-Length: 2
Connection: close
'''

# Generated at 2022-06-17 20:43:27.195331
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
"""
    expected = """\
HTTP/1.1 200 OK
Content-Type: application/json
X-Bar: Baz
X-Bar: Qux
X-Bar: Quux
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
"""
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-17 20:43:37.920147
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:43:46.933110
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.4.6 (Ubuntu)
Date: Mon, 23 Mar 2015 22:38:34 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-1427193106000"

'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 23 Mar 2015 22:38:34 GMT
ETag: W/"2-1427193106000"
Server: nginx/1.4.6 (Ubuntu)
X-Powered-By: Express

'''

# Generated at 2022-06-17 20:44:00.314323
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Content-Encoding: gzip
Date: Wed, 11 Sep 2019 07:28:15 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur
X-Powered-By: Flask
X-Processed-Time: 0.00145912170410
'''

# Generated at 2022-06-17 20:44:02.005563
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:44:12.217206
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
Connection: keep-alive'''
    expected = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9'''
    assert HeadersFormatter().format_headers(headers) == expected
    # Test case 2
    headers = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
Connection: keep-alive
Accept: application/json'''

# Generated at 2022-06-17 20:44:16.131295
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    expected = '''\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:20.428818
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:01:01 GMT

{}
"""

# Generated at 2022-06-17 20:44:25.563037
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: b5d5f8c8-c7f1-4a2d-9b5f-c9b7f5d9c9b7
X-Runtime: 0.003311
Date: Wed, 05 Dec 2018 21:43:32 GMT
Connection: close

'''

# Generated at 2022-06-17 20:44:34.163147
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:45:01.081926
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:45:08.952284
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/0.9.9
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:45:14.137536
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: BaseHTTP/0.6 Python/3.6.1
Date: Sun, 19 Nov 2017 17:07:07 GMT

{}
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 19 Nov 2017 17:07:07 GMT
Server: BaseHTTP/0.6 Python/3.6.1

{}
"""