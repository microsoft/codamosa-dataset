

# Generated at 2022-06-17 20:35:21.627705
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Baz: Qux
X-Baz: Quux
X-Baz: Quuz
X-Foo: Bar
X-Foo: Baz
X-Foo: Qux
'''
    assert headers_formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:35:31.676909
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Date: Thu, 16 Apr 2020 00:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00138092041015625

{}
'''

# Generated at 2022-06-17 20:35:40.158404
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 23 May 2019 13:53:37 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00165796279907
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:35:41.546345
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:35:50.525791
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 17
Connection: keep-alive
Date: Thu, 23 Apr 2020 22:37:01 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0013170242309570312
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:36:00.233124
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: close
Date: Thu, 16 Jul 2015 14:44:00 GMT
Server: Python/3.4.3
X-Powered-By: Flask
Content-Length: 5
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Length: 5
Content-Type: application/json
Connection: close
Date: Thu, 16 Jul 2015 14:44:00 GMT
Server: Python/3.4.3
X-Powered-By: Flask
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:05.244746
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:36:13.129723
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:36:19.687733
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Date: Sat, 23 Jun 2018 10:07:45 GMT

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Date: Sat, 23 Jun 2018 10:07:45 GMT

'''



# Generated at 2022-06-17 20:36:27.357402
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Connection: keep-alive
Date: Mon, 20 Apr 2020 11:02:37 GMT
Transfer-Encoding: chunked
X-Powered-By: Express
'''
    expected_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/json
Date: Mon, 20 Apr 2020 11:02:37 GMT
Transfer-Encoding: chunked
X-Powered-By: Express
'''
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-17 20:36:36.767101
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 18
Date: Sun, 26 May 2019 14:46:51 GMT

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Sun, 26 May 2019 14:46:51 GMT

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:36:47.431910
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Thu, 09 Nov 2017 23:40:34 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-L7UWuq/Fb/nsr0tBx/N3A"
Vary: Accept-Encoding
'''

# Generated at 2022-06-17 20:36:50.575695
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:00.635414
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:37:08.502354
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 16 Sep 2019 12:51:55 GMT

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Sep 2019 12:51:55 GMT
Server: gunicorn/19.9.0

{}'''

# Generated at 2022-06-17 20:37:10.893945
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:37:19.891101
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Tue, 18 Apr 2017 13:02:51 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-n4FQ5N9sQsK8k3z3FqyDQ"
Vary: Accept-Encoding
"""

# Generated at 2022-06-17 20:37:26.545794
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.6.2
Date: Mon, 23 May 2016 10:36:31 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

{}'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Mon, 23 May 2016 10:36:31 GMT
Server: nginx/1.6.2

{}'''


# Generated at 2022-06-17 20:37:36.314334
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Pad: avoid browser bug

'''

# Generated at 2022-06-17 20:37:44.378315
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 06 Dec 2018 14:32:43 GMT

{}"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 06 Dec 2018 14:32:43 GMT
Server: gunicorn/19.9.0

{}"""
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-17 20:37:50.168441
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__


# Generated at 2022-06-17 20:38:00.122525
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:38:06.209554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Cache-Control: no-cache
Date: Fri, 01 Dec 2017 15:42:55 GMT

"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 12
Content-Type: application/json
Date: Fri, 01 Dec 2017 15:42:55 GMT

"""

# Generated at 2022-06-17 20:38:16.567995
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: W/"a7e3f9f9e9c9fdfb8a7d8e8c9fdfb8a7"
X-Request-Id: 8a9d9e8e-fdfb-8a7d-8e8c-9fdfb8a7d8e8
X-Runtime: 0.005790
Server: WEBrick/1.3.1 (Ruby/2.2.2/2015-04-13)
Date: Wed, 06 May 2015 14:26:51 GMT
Content-Length: 2
Connection: Keep-Alive'''
    assert formatter

# Generated at 2022-06-17 20:38:23.074196
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Thu, 23 Jul 2015 19:45:35 GMT
Content-Length: 2

{}'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Thu, 23 Jul 2015 19:45:35 GMT

{}'''

# Generated at 2022-06-17 20:38:32.611952
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Date: Sun, 18 Oct 2020 12:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0007870197296142578
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:38:35.297513
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:38:41.014171
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Connection: keep-alive
Date: Thu, 03 Jan 2019 18:17:54 GMT

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 03 Jan 2019 18:17:54 GMT

{}'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:38:48.362455
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 16 Aug 2017 20:13:01 GMT
Content-Length: 2

{}
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 16 Aug 2017 20:13:01 GMT

{}
'''
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-17 20:38:51.509364
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:39:00.380730
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 23 Jul 2018 15:42:23 GMT

"""
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 35
Content-Type: application/json
Date: Mon, 23 Jul 2018 15:42:23 GMT
Server: gunicorn/19.9.0

"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:02.526463
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:11.306089
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-17 20:39:17.433799
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Date: Sun, 10 May 2020 09:09:09 GMT
Connection: close

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 18
Content-Type: application/json
Date: Sun, 10 May 2020 09:09:09 GMT

'''

# Generated at 2022-06-17 20:39:19.516478
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:26.669342
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 22 Sep 2019 22:14:41 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Sun, 22 Sep 2019 22:14:41 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:39:32.916137
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Tue, 11 Aug 2020 15:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.00139904022217
Content-Encoding: gzip
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:35.486471
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:39:38.292968
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled


# Generated at 2022-06-17 20:39:40.854860
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:39:54.465403
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 21 May 2015 22:34:05 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.00144505500793
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:39:56.128706
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:03.871681
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Wed, 06 Feb 2019 14:38:59 GMT
Content-Length: 2

{}
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Wed, 06 Feb 2019 14:38:59 GMT

{}
"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-17 20:40:05.995966
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:07.616210
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:40:18.613886
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Thu, 01 Jan 1970 00:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0009479331970214844
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Thu, 01 Jan 1970 00:00:00 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.0009479331970214844
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:25.225229
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Custom-Header: abc
X-Custom-Header: def
X-Custom-Header: ghi
'''
    expected = '''\
Content-Type: application/json
X-Custom-Header: abc
X-Custom-Header: def
X-Custom-Header: ghi
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:40:33.516514
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: e0c6f8b6-b9f7-4c6d-a8a8-d9c7a9f8c8e7
ETag: "d41d8cd98f00b204e9800998ecf8427e"
X-Runtime: 0.003857
Server: WEBrick/1.3.1 (Ruby/2.0.0/2013-11-22)
Date: Tue, 03 Dec 2013 17:31:46 GMT
Content-Length: 0
Connection: Keep-Alive
Set-Cookie: request_method=GET; path=/
"""

# Generated at 2022-06-17 20:40:39.976697
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Tue, 05 May 2020 14:37:15 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.001577138900756836
Content-Length: 2
Content-Type: application/json
Date: Tue, 05 May 2020 14:37:15 GMT
Server: gunicorn/19.9.0
X-Powered-By: Flask
X-Processed-Time: 0.001577138900756836
'''

# Generated at 2022-06-17 20:40:46.733235
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 11 Nov 2019 09:55:35 GMT
Server: nginx/1.10.3 (Ubuntu)

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Mon, 11 Nov 2019 09:55:35 GMT
Server: nginx/1.10.3 (Ubuntu)

'''



# Generated at 2022-06-17 20:41:06.298319
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Tue, 14 May 2019 14:27:13 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Mon, 13 May 2019 16:02:22 GMT
ETag: "2d-58f6c5f8b5180"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/html

'''

# Generated at 2022-06-17 20:41:13.996194
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: e7b9f9f1-d8d6-4c6f-a9a0-c8b2f9d9c7d9
X-Runtime: 0.005033
Connection: close
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Mon, 23 Jan 2017 13:42:20 GMT
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:41:21.489009
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Mon, 27 Jul 2015 01:17:50 GMT

{}
""") == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 27 Jul 2015 01:17:50 GMT

{}
"""

# Generated at 2022-06-17 20:41:25.722087
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 2
Date: Fri, 24 May 2019 11:41:58 GMT

{}
""")
    assert headers == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Fri, 24 May 2019 11:41:58 GMT

{}
"""

# Generated at 2022-06-17 20:41:30.489155
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/1.0.2
'''
    expected_headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/1.0.2
'''
    assert HeadersFormatter().format_headers(headers) == expected_headers

    # Test case 2

# Generated at 2022-06-17 20:41:36.834076
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
X-Foo: Bar
X-Foo: Baz
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 35
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-17 20:41:47.957202
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fd8c8e90-a967-4e71-a4f5-b3b35d250a5f
ETag: W/"2a5ef6a15b45b729aaef2e9a2c6d22c1"
X-Runtime: 0.012685
Transfer-Encoding: chunked
'''

# Generated at 2022-06-17 20:41:58.736091
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 5
Connection: keep-alive
Date: Sun, 20 Aug 2017 20:59:28 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
Date: Sun, 20 Aug 2017 20:59:28 GMT
Server: gunicorn/19.7.1
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:42:01.208756
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False
    assert formatter.format_options['headers']['sort'] == False


# Generated at 2022-06-17 20:42:02.508543
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-17 20:42:37.285076
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: c1b9f9c7-0b5f-4d8e-b9e6-f5b8d8e7c9e9
X-Runtime: 0.001774
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
Date: Thu, 24 Nov 2016 13:11:36 GMT
Content-Length: 2
Connection: Keep-Alive'''

# Generated at 2022-06-17 20:42:38.611028
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:42:43.359806
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Mon, 16 Mar 2020 11:25:01 GMT
Content-Length: 2

{}'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Mon, 16 Mar 2020 11:25:01 GMT

{}'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:42:44.483469
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-17 20:42:46.080136
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:42:57.767319
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Date: Mon, 13 Apr 2020 17:40:40 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
Date: Mon, 13 Apr 2020 17:40:40 GMT
Server: nginx/1.14.0 (Ubuntu)

'''

# Generated at 2022-06-17 20:43:05.345118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Cache-Control: no-cache
Date: Wed, 16 Sep 2020 16:05:35 GMT
Connection: keep-alive

{}'''
    assert HeadersFormatter().format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Wed, 16 Sep 2020 16:05:35 GMT

{}'''

# Generated at 2022-06-17 20:43:15.921153
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:43:18.283600
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-17 20:43:28.641457
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:44:26.196102
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Foo: Bar
X-Bar: Baz
X-Foo: Qux
'''
    expected = '''\
Content-Type: application/json
X-Bar: Baz
X-Foo: Bar
X-Foo: Qux
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:34.693129
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-17 20:44:41.199984
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Foo: Baz
"""
    expected = """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-17 20:44:47.633221
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 10 Jun 2018 15:35:47 GMT

{}
'''
    assert headers_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 2
Content-Type: application/json
Date: Sun, 10 Jun 2018 15:35:47 GMT

{}
'''



# Generated at 2022-06-17 20:44:59.946127
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
'''

# Generated at 2022-06-17 20:45:05.394475
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Tue, 08 Jan 2019 20:38:54 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    expected = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 08 Jan 2019 20:38:54 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur

'''
    assert HeadersFormatter().format_headers(headers) == expected


# Generated at 2022-06-17 20:45:14.325641
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Sun, 26 Jul 2015 20:38:14 GMT
Server: gunicorn/19.3.0
X-Powered-By: Flask
X-Processed-Time: 0.0014591217041
Via: 1.1 vegur

'''