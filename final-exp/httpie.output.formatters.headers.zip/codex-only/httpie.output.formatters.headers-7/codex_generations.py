

# Generated at 2022-06-23 19:19:28.223865
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_input = """\
HTTP/1.1 200 OK
Transfer-Encoding: chunked
foo: bar
Foo: baz
Content-Type: application/json
"""
    headers_expected = """\
HTTP/1.1 200 OK
Content-Type: application/json
Foo: baz
foo: bar
Transfer-Encoding: chunked
"""
    f = HeadersFormatter()
    assert f.format_headers(headers_input) == headers_expected



# Generated at 2022-06-23 19:19:30.389051
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options=json.loads(json.dumps(dict(headers=dict(sort=True)))))

test_HeadersFormatter()


# Generated at 2022-06-23 19:19:31.658969
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.format_options['headers']['sort'] is True


# Generated at 2022-06-23 19:19:36.450904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    actual_headers = f.format_headers('HTTP/1.1 200 OK\r\nContent-Length: 123\r\nContent-Type: text/html\r\nX-Header: x\r\nX-Header: y\r\n\r\n')
    expected_headers = 'HTTP/1.1 200 OK\r\nContent-Length: 123\r\nContent-Type: text/html\r\nX-Header: x\r\nX-Header: y\r\n\r\n'
    assert actual_headers == expected_headers


# Generated at 2022-06-23 19:19:44.034363
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers = """\
HTTP/1.1 200 OK
User-Agent: httpie
Test: test1
Test: test3
Content-Length: 12
Other: test2
Content-Type: application/json
"""
    expected_headers = """\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: application/json
Other: test2
Test: test1
Test: test3
User-Agent: httpie
"""
    assert headers_formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:19:55.433228
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = [
        'Content-Length: 1',
        'Cache-Control: no-store',
        'Set-Cookie: 1',
        'Set-Cookie: 2',
        'Server: Python/3.5',
        'Set-Cookie: 3',
        'Date: Fri, 25 Aug 2017 03:49:55 GMT',
        'Set-Cookie: 4',
        'Set-Cookie: 5',
        'Content-Type: text/html; charset=utf-8',
        'Set-Cookie: 6',
        'Set-Cookie: 7',
    ]
    # headers sorted by name
    expected = '\r\n'.join(['HTTP/1.1 200 OK'] + sorted(headers))
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:20:03.003297
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
POST / HTTP/1.1
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Accept: application/json
Date: Mon, 16 Mar 2020 18:52:48 GMT
Host: jsonplaceholder.typicode.com
Accept-Encoding: gzip, deflate
Content-Length: 9
Connection: close

"""
    h = HeadersFormatter()
    result = h.format_headers(headers)

# Generated at 2022-06-23 19:20:05.107580
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter({'headers': {'sort': True}})



# Generated at 2022-06-23 19:20:10.661501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers('HTTP/1.1 200 OK\r\nA: 2\r\nB: 1\r\nC: 3\r\n\r\n') == 'HTTP/1.1 200 OK\r\nA: 2\r\nB: 1\r\nC: 3\r\n\r\n'


# Generated at 2022-06-23 19:20:21.399245
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_string = '''\
HTTP/1.1 200 OK
Server: nginx
Content-Type: text/html; charset=utf-8
Content-Length: 4343
Connection: keep-alive
Cache-Control: private
Date: Mon, 14 Jan 2019 05:55:47 GMT
Strict-Transport-Security: max-age=15768000; includeSubDomains; preload
    '''

# Generated at 2022-06-23 19:20:27.398432
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
A: 2
B: 1
A: 1
B: 2
'''
    expected_headers = '''\
HTTP/1.1 200 OK
A: 2
A: 1
B: 1
B: 2
'''
    assert fmt.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:20:30.320250
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    key_words = {'headers': {'sort': False}}
    head = HeadersFormatter(format_options=key_words)
    assert head.enabled == False

# Generated at 2022-06-23 19:20:39.001277
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    actual = f.format_headers(
        'GET / HTTP/1.1\r\n'
        'Content-Type: text/plain\r\n'
        'A:1\r\n'
        'A:2\r\n'
        'C:3\r\n'
        'B:1\r\n'
        'B:2\r\n'
        '\r\n')

# Generated at 2022-06-23 19:20:47.731785
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    formatter = HeadersFormatter()
    expected_headers = '''\
HTTP/1.1 200 OK
Accept-Language: en
Connection: keep-alive
Content-Type: text/html
Date: Thu, 14 Aug 2014 17:59:32 GMT
Etag: "359670651+gzip+ident"
Server: nginx/1.4.6 (Ubuntu)
Vary: Accept-Encoding
X-Cache: HIT
X-Cache-Hits: 1
X-Backend-Server: drupal-prod-web-07
X-Powered-By: PHP/5.5.9-1ubuntu4.14
'''

    # Exercise
    actual_headers = formatter.format_headers(expected_headers)

    # Verify
    assert expected_headers == actual_headers



# Generated at 2022-06-23 19:20:49.374721
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    p = HeadersFormatter()
    assert p.format_options == {}
    assert p.enabled == True


# Generated at 2022-06-23 19:20:51.488725
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format='tabulate')
    assert formatter.format == 'tabulate'


# Generated at 2022-06-23 19:20:53.697972
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    config = Config(format_options={'headers': {'sort': True}})
    formatter = HeadersFormatter(config=config)

    assert formatter.enabled


# Generated at 2022-06-23 19:20:55.388881
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf
    assert hf.enabled == False


# Generated at 2022-06-23 19:20:58.286325
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  _ = HeadersFormatter()

# Example of usage of method format_headers:
# print( format_headers('GET / HTTP/1.1\r\nHost: example.com\r\nAccept: application/json\r\nAccept-Language: en-US\r\nAccept-Encoding: gzip, deflate\r\n\r\n') )



# Generated at 2022-06-23 19:21:05.596361
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('') == ''
    assert hf.format_headers('\r\n') == '\r\n'
    assert hf.format_headers('\r\n\r\n') == '\r\n\r\n'

    assert hf.format_headers('a: 1\r\nb: 2\r\nc: 3\r\n\r\n') == 'a: 1\r\nb: 2\r\nc: 3\r\n\r\n'
    assert hf.format_headers('c: 3\r\nb: 2\r\na: 1\r\n\r\n') == 'a: 1\r\nb: 2\r\nc: 3\r\n\r\n'

    assert h

# Generated at 2022-06-23 19:21:09.085134
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter({
        'headers': {
            'sort': True
        }
    })
    assert h.enabled is True


# Generated at 2022-06-23 19:21:20.183883
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:21:28.944301
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    sorted_headers = hf.format_headers("""\
HTTP/1.1 200 OK
Server: BaseHTTP/0.6 Python/3.5.2
Date: Sun, 23 Apr 2017 15:46:14 GMT
Content-type: text/plain; charset=UTF-8
Content-Length: 1
last-modified: Mon, 10 Apr 2017 15:46:14 GMT
x-foooo: Bar
X-Foooo: Baz
""")


# Generated at 2022-06-23 19:21:37.508575
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'Date: Fri, 25 Sep 2015 08:50:11 GMT',
        'Content-Length: 2',
        'Content-Type: application/json',
        'Connection: close',
        '',
        ''])) == '\r\n'.join([
            'HTTP/1.1 200 OK',
            'Connection: close',
            'Content-Length: 2',
            'Content-Type: application/json',
            'Date: Fri, 25 Sep 2015 08:50:11 GMT',
            '',
            ''])



# Generated at 2022-06-23 19:21:39.029506
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert (hf.format_options == {'headers': {'sort': True}})


# Generated at 2022-06-23 19:21:47.345510
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from json import dumps
    from collections import OrderedDict

    json_input = OrderedDict([('one', 1), ('two', 2), ('three', 3)])
    json_output = dumps(json_input)

    hf = HeadersFormatter(format_options={'headers':{'sort':False}})
    assert hf.format_headers(json_output) == json_output

    hf = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert hf.format_headers(json_output) != json_output


# Generated at 2022-06-23 19:21:58.923521
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # A headers string that includes at least one duplicate field
    # is sorted and has its duplicates removed.
    assert HeadersFormatter.format_headers("""\
Connection: keep-alive
Content-Length: 72
Accept: application/json
Connection: close
Content-Type: application/x-www-form-urlencoded
""") == """\
Connection: close
Content-Length: 72
Accept: application/json
Content-Type: application/x-www-form-urlencoded"""

    # A headers string that does not contain duplicate fields
    # is preserved.

# Generated at 2022-06-23 19:22:06.614334
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    header_str1 = '''\
GET /api/reviews/?productId=B00D93M9PA HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: ecs.amazonaws.com
User-Agent: HTTPie/1.0.0
X-Amzn-Authorization: AWS3-HTTPS AWSAccessKeyId=AKIAIIGVM6ULZN7RXQWQ, \
Algorithm=HmacSHA256, Signature=2Ql+CWC4J4sjhV47XlrzqT3J6Y1h6UKEV+92baGwDkg=
X-Amz-Date: Wed, 04 Jan 2017 16:16:11 GMT
'''
    header_

# Generated at 2022-06-23 19:22:08.103239
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled == True


# Generated at 2022-06-23 19:22:13.494419
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('X: foo\r\nB: bar\r\nB: baz\r\nA: qux') == \
           'X: foo\r\nA: qux\r\nB: bar\r\nB: baz'



# Generated at 2022-06-23 19:22:23.425867
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()


# Generated at 2022-06-23 19:22:25.542714
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert (h.enabled == False)


# Generated at 2022-06-23 19:22:35.014054
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:22:47.864236
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    content = ("HTTP/1.1 200 OK\r\n"
               "Date: Wed, 21 Oct 2015 07:28:00 GMT\r\n"
               "Allow: OPTIONS, GET\r\n"
               "Allow: HEAD\r\n"
               "\r\n")

    expected = ("HTTP/1.1 200 OK\r\n"
                "Allow: OPTIONS, GET\r\n"
                "Allow: HEAD\r\n"
                "Date: Wed, 21 Oct 2015 07:28:00 GMT\r\n\r\n")
    assert formatter.format_headers(content) == expected

    content = ("HTTP/1.1 200 OK\r\n"
               "\r\n")
    expected = content

# Generated at 2022-06-23 19:22:59.177404
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:23:07.847751
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """ Unit test for constructor of class HeadersFormatter """

    # Manually create a Config and options
    config = Config()
    config.headers = Options()

    # Object creation
    with pytest.raises(TypeError):
        formatter_plugin = HeadersFormatter(config, True)

    formatter_plugin = HeadersFormatter(config, **{'headers': {'sort': False}})

    # Test protected attribute
    with pytest.raises(AttributeError):
        print(formatter_plugin.format_options)

    # Check enabled attribute
    assert(formatter_plugin.enabled == False)


# Generated at 2022-06-23 19:23:16.418598
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
HTTP/1.1 200 OK
Cookie: flavor=chocolate-chip
Set-Cookie: flavor=mint
Set-Cookie: flavor=chocolate
Cookie: flavor=sugar-cookie
'''
    expected_result = '''\
HTTP/1.1 200 OK
Cookie: flavor=chocolate-chip
Cookie: flavor=sugar-cookie
Set-Cookie: flavor=mint
Set-Cookie: flavor=chocolate
'''
    headers_formatter = HeadersFormatter()
    result = headers_formatter.format_headers(h)
    assert result == expected_result

# Generated at 2022-06-23 19:23:25.901003
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    session = requests.Session()
    options = {'headers': {'user-agent': 'Python3.6', 'accept': 'application/json', 'sort': True}}
    sess = Session()
    format_options = {'headers': {'sort': True, 'style': 'uppercase'}}
    headers_formatter = HeadersFormatter(format_options)
    # Test: Enabled headers formatter
    assert headers_formatter.enabled

    # Test: Run the constructor
    assert isinstance(headers_formatter, FormatterPlugin)

    # Test: Run the format headers

# Generated at 2022-06-23 19:23:35.739843
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 148
Server: DummyHTTP/1.0
Content-Type: text/html
Date: Sun, 10 Sep 2017 07:13:17 GMT

<html>
<body>
Hello world!
</body>
</html>
'''
    headers2 = '''\
HTTP/1.1 200 OK
Server: DummyHTTP/1.0
Content-Type: text/html
Content-Length: 148
Date: Sun, 10 Sep 2017 07:13:17 GMT

<html>
<body>
Hello world!
</body>
</html>
'''
    assert f.format_headers(headers) == headers2

# Generated at 2022-06-23 19:23:37.634821
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False
    assert h.format_options['headers']['sort'] == False

# Generated at 2022-06-23 19:23:47.446815
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Cache-Control: max-age=0\r\n'
        'Content-Length: 60\r\n'
        'Content-Length: 60\r\n'
        'Content-Type: application/json\r\n'
        'Server: nginx/1.1.19'
    ) == (
        'HTTP/1.1 200 OK\r\n'
        'Cache-Control: max-age=0\r\n'
        'Content-Length: 60\r\n'
        'Content-Length: 60\r\n'
        'Content-Type: application/json\r\n'
        'Server: nginx/1.1.19'
    )

# Generated at 2022-06-23 19:23:54.444371
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Before sorting
    headers = """Content-Type: application/json
Accept: application/json
X-MyHeader: 1
Accept: application/xml
X-MyHeader: 2
    """
    # Expected result
    expected = """Content-Type: application/json
Accept: application/json
Accept: application/xml
X-MyHeader: 1
X-MyHeader: 2
    """
    # Unit test
    assert HeadersFormatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:24:00.816829
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """\
GET / HTTP/1.1
User-Agent: httpie
Connection: keep-alive
Host: localhost:8080
Accept-Encoding: gzip, deflate
Accept: */*


""") == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8080
User-Agent: httpie

"""

# Generated at 2022-06-23 19:24:04.011453
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    args = {'headers': {'sort': True}}
    head = HeadersFormatter(args)
    assert head.enabled
    args = {'headers': {'sort': False}}
    head = HeadersFormatter(args)
    assert not head.enabled


# Generated at 2022-06-23 19:24:09.881358
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ('GET / HTTP/1.1\r\n'
               'Connection: keep-alive\r\n'
               'Host: 127.0.0.1:5000\r\n'
               'Content-Length: 1000\r\n'
               'Content-Type: application/json')
    expected_headers = ('GET / HTTP/1.1\r\n'
                        'Content-Length: 1000\r\n'
                        'Content-Type: application/json\r\n'
                        'Connection: keep-alive\r\n'
                        'Host: 127.0.0.1:5000')
    formatter = HeadersFormatter()
    actual_headers = formatter.format_headers(headers)
    assert actual_headers == expected_headers

# Generated at 2022-06-23 19:24:19.798735
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class TestHeadersFormatter(HeadersFormatter):
        def format_headers(*args, **kwargs):
            return super().format_headers(*args, **kwargs)
    # Case-1: when headers exist and check for status code (Status code is always shown at the first line)

# Generated at 2022-06-23 19:24:22.635888
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        hf = HeadersFormatter() # When
        enabled = hf.enabled # Then
        assert True == enabled
    except:
        assert False == True



# Generated at 2022-06-23 19:24:33.758716
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:24:38.905605
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('headers:asdf\r\nX-Foo: bar\r\nX-Bar: baz\r\nheaders:bsdf') == 'headers:asdf\r\nX-Bar: baz\r\nX-Foo: bar\r\nheaders:bsdf'

# Generated at 2022-06-23 19:24:48.147464
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import textwrap

    actual =  '''\
        HTTP/1.1 200 OK
        Content-Type: application/json
        Transfer-Encoding: chunked
        Vary: Accept
        X-Foo: Bar
        Date: Tue, 15 Nov 1994 08:12:31 GMT
        X-Bar: Baz
        Cache-Control: no-cache
    '''
    expected = '''\
        HTTP/1.1 200 OK
        Cache-Control: no-cache
        Content-Type: application/json
        Date: Tue, 15 Nov 1994 08:12:31 GMT
        Transfer-Encoding: chunked
        Vary: Accept
        X-Bar: Baz
        X-Foo: Bar
    '''
    assert HeadersFormatter.format_headers(textwrap.dedent(actual)) == expected


# Generated at 2022-06-23 19:24:51.384317
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:24:54.379856
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  print("Inside test_HeadersFormatter()")
  formatter = HeadersFormatter()
  assert formatter.enabled == formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:25:03.189886
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    params = {
      'format_options': {
        'headers': {
          'sort': True
        }
      }
    }
    f = HeadersFormatter(**params)
    inp_headers = """\
    HTTP/1.1 200 OK
    Pragma: no-cache
    Cache-Control: no-store
    test-header: c
    test-header: a
    test-header: b
    test-header: d
    X-Foo: Bar
    Connection: keep-alive
    Content-Type: application/json
    Content-Length: 11"""

# Generated at 2022-06-23 19:25:12.362355
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    import os, sys
    from os.path import dirname
    sys.path.append(dirname(dirname(dirname(os.path.realpath(__file__)))))

    from httpie.plugins.formatter import FormatterPlugin
    from plugins.formatter.headers import HeadersFormatter

    fp = HeadersFormatter()
    assert fp.__class__.__base__ is FormatterPlugin

    assert fp.format_options == {
        'headers': {
            'sort': True
        }
    }

    assert fp.format_options['headers']['sort']


# Generated at 2022-06-23 19:25:14.651330
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(format_options={"headers": {"sort": False}})
    assert h.format_options == {"headers": {"sort": False}}



# Generated at 2022-06-23 19:25:16.424307
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == True 


# Generated at 2022-06-23 19:25:19.988245
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:25:28.530970
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    result = headers_formatter.format_headers("""\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: identity
User-Agent: HTTPie/1.0.0
Accept: */*


""")
    expected = """\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: identity
User-Agent: HTTPie/1.0.0
Accept: */*


"""
    assert result == expected

    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:25:32.786711
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('HTTP/1.1 200 OK\r\nAccept: text/plain\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,*\r\nUser-Agent: HTTPie/0.9.2\r\n') == 'HTTP/1.1 200 OK\r\nAccept: text/plain\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,*\r\nUser-Agent: HTTPie/0.9.2\r\n'



# Generated at 2022-06-23 19:25:39.799287
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Length: 26
Content-type: application/json; charset=UTF-8
X-Custom-3: third
X-Custom-2: second
Content-Type: application/json; charset=UTF-8
X-Custom-1: first
X-Custom-4: fourth
"""

    headers_expected = """\
Content-Length: 26
Content-type: application/json; charset=UTF-8
X-Custom-1: first
X-Custom-2: second
X-Custom-3: third
Content-Type: application/json; charset=UTF-8
X-Custom-4: fourth
"""

    headers_formatted = HeadersFormatter.format_headers(headers)
    assert headers_formatted == headers_expected

# Generated at 2022-06-23 19:25:40.906697
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:25:49.846433
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = [
        'HTTP/1.1 200 OK',
        'Server: Apache',
        'Cache-Control: max-age=0',
        'Vary: Accept-Encoding',
        'Content-Length: 18',
        'Content-Type: text/html; charset=UTF-8',
        'Date: Sat, 15 Feb 2014 07:57:28 GMT',
        'Expires: Sat, 15 Feb 2014 07:57:28 GMT',
        'X-Frame-Options: SAMEORIGIN',
        'Set-Cookie: PHPSESSID=1234; path=/'
    ]
    headers = '\r\n'.join(lines)
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == '\r\n'.join(sorted(lines))


# Generated at 2022-06-23 19:25:55.859796
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    import pytest
    check=FormatterPlugin()
    check.format_options['headers']['sort']=True
    assert HeadersFormatter(**check.__dict__).enabled==True
    with pytest.raises(ValueError):
        HeadersFormatter(**check.__dict__).enabled=False


# Generated at 2022-06-23 19:26:03.384373
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  str1 = '''Accept: text/html,application/xhtml+xml,application/xml\r\nUser-Agent: Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-us) AppleWebKit/531.22.7 (KHTML, like Gecko) Version/4.0.5 Safari/531.22.7\r\nAccept-Language: en-us\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nHost: www.google.com\r\nContent-type: application/x-www-form-urlencoded\r\nContent-Length: 24'''

# Generated at 2022-06-23 19:26:05.684150
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == hf.format_options['headers']['sort']


# Generated at 2022-06-23 19:26:13.248555
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print('Running unit tests')
    formatter = HeadersFormatter(format_options=
                                 {'headers':
                                  {'sort':
                                   True}})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 13
Connection: keep-alive
Date: Wed, 23 Oct 2019 21:23:02 GMT

'''
    expected = '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: application/json; charset=utf-8
Date: Wed, 23 Oct 2019 21:23:02 GMT

'''
    actual = formatter.format_headers(headers)
    assert expected == actual


# Generated at 2022-06-23 19:26:15.867258
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert isinstance(headers, HeadersFormatter)
    assert headers.enabled == False


# Generated at 2022-06-23 19:26:26.235421
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Fail on input other than formatter_dict, i.e. {str: {str: any}}
    with pytest.raises(TypeError):
        HeadersFormatter(wrong_input = None)
    # Fail on specification of output format other than str
    with pytest.raises(TypeError):
        HeadersFormatter(output_format = None)
    # Fail on specification of format_options other than dict
    with pytest.raises(TypeError):
        HeadersFormatter(format_options = None)

    # Check that the class is properly initialized
    headers_formatter = HeadersFormatter({
        'headers': {'sort': True},
        'body': {'sort': False}
    })

# Generated at 2022-06-23 19:26:32.985986
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
GET / HTTP/1.1
Host: example.org
Connection: keep-alive
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate
Accept: */*
'''
    assert formatter.format_headers(headers) == '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.org
User-Agent: HTTPie/0.9.2
'''


# Generated at 2022-06-23 19:26:43.147264
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = ('Host: httpbin.org\r\n'
              'Connection: keep-alive\r\n'
              'X-Powered-By: PHP/5.6.30\r\n'
              'Accept: application/json')
    expected_headers = ('Host: httpbin.org\r\n'
                        'Accept: application/json\r\n'
                        'Connection: keep-alive\r\n'
                        'X-Powered-By: PHP/5.6.30\r\n')
    assert formatter.format_headers(headers) == expected_headers

print(test_HeadersFormatter_format_headers())

# Generated at 2022-06-23 19:26:46.742617
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(headers={'sort':True})
    assert isinstance(headers_formatter, HeadersFormatter)


# Generated at 2022-06-23 19:26:56.272194
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case:
    # headers = '''
    # Host: httpbin.org
    # User-Agent: HTTPie/0.9.9
    # Accept-Encoding: gzip, deflate, compress
    # Accept: */*
    # Connection: keep-alive
    # '''
    headers = '''
    Accept: application/json
    Accept-Encoding: gzip, deflate
    Content-Type: application/json
    '''
    assert HeadersFormatter().format_headers(headers) == '''
    Accept: application/json
    Accept-Encoding: gzip, deflate
    Content-Type: application/json
    '''

# Generated at 2022-06-23 19:27:06.165738
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options='-h')

# Generated at 2022-06-23 19:27:15.386941
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    response_headers = """
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 17
Date: Fri, 29 Jun 2018 22:10:56 GMT
Server: WSGIServer/0.2 CPython/3.6.4
X-Powered-By: Flask
"""
    # Sort headers
    sorted_response_headers = """
HTTP/1.1 200 OK
Content-Length: 17
Content-Type: application/json
Date: Fri, 29 Jun 2018 22:10:56 GMT
Server: WSGIServer/0.2 CPython/3.6.4
X-Powered-By: Flask
"""
    formatted_headers = headers_formatter.format_headers(response_headers)
    assert formatted_headers == sorted_response_headers

# Generated at 2022-06-23 19:27:23.671871
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class MockParser:
        class MockArgs:
            style = False
            style_errors = False
            sort_keys = False
            indent = 4
            pretty = False
        args = MockArgs()

        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    parser = MockParser(
        format_options={'headers': {'sort': True}}
    )

    cli_formatter = HeadersFormatter(parser=parser)

    assert cli_formatter.format_headers('Accept: application/json\r\n'
                                        'Content-Type: application/json') == 'Accept: application/json\r\nContent-Type: application/json'



# Generated at 2022-06-23 19:27:27.654405
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == False

    hf = HeadersFormatter(headers = {'sort': True})
    assert hf.enabled == True


# Generated at 2022-06-23 19:27:30.106650
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled


# Generated at 2022-06-23 19:27:36.942077
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

    h = """\
Accept: */*
Content-Type: application/json
Content-Length: 2
"""
    assert headers_formatter.format_headers(h) == h

    h = """\
Content-Length: 2
Accept: */*
Content-Type: application/json
"""
    assert headers_formatter.format_headers(h) == """\
Accept: */*
Content-Length: 2
Content-Type: application/json"""


# Generated at 2022-06-23 19:27:38.335679
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options={})


# Generated at 2022-06-23 19:27:40.245242
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.name == "headers"
    assert f.enabled == True


# Generated at 2022-06-23 19:27:46.483425
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = [
        '# Request Headers',
        'content-type: application/json',
        'foo: bar',
        'user-agent: HTTPie/0.9.7',
    ]

    assert HeadersFormatter.format_headers(
        '\r\n'.join(lines)) == '\r\n'.join([
        '# Request Headers',
        'content-type: application/json',
        'foo: bar',
        'user-agent: HTTPie/0.9.7',
    ])

# Generated at 2022-06-23 19:27:57.716242
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:28:00.735469
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:28:05.349902
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hformatter = HeadersFormatter(format_options={ 'headers': { 'sort': True } })
    assert hformatter.enabled == True
    assert hformatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:28:13.861949
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
Transfer-Encoding: chunked\r
Date: Mon, 13 Apr 2020 10:57:23 GMT\r
Server: WSGIServer/0.2 CPython/3.7.4\r
X-Frame-Options: SAMEORIGIN\r
\r
'''
    expected = '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
Date: Mon, 13 Apr 2020 10:57:23 GMT\r
Server: WSGIServer/0.2 CPython/3.7.4\r
Transfer-Encoding: chunked\r
X-Frame-Options: SAMEORIGIN\r
\r
'''

# Generated at 2022-06-23 19:28:22.762010
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print('')
    # headers with only Header_Line
    headers_only_header_line = '''\
GET /api/users/
'''
    # headers with multiple Header_Lines
    headers_multiple_header_lines = '''\
GET /api/users/
Accept: */*
Content-Length: 16
Content-Type: application/json
Connection: close
Host: 127.0.0.1:5000

'''
    # headers with multiple Header_Lines in non-alphabetical order
    headers_wrong_order = '''\
GET /api/users/
Content-Length: 16
Content-Type: application/json
Accept: */*
Connection: close
Host: 127.0.0.1:5000

'''
    headers_formatter = HeadersFormatter()
    assert headers_formatter

# Generated at 2022-06-23 19:28:31.934330
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:28:42.912647
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    with patch('httpie.plugins.builtin.headers.HeadersFormatter.enabled', True):
        fmt = HeadersFormatter()
        headers = '''GET /?foo=bar&foo=baz HTTP/1.1
Accept: application/json, */*
Connection: keep-alive
Content-Length: 43
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9


'''
        formatted_headers = '''GET /?foo=bar&foo=baz HTTP/1.1
Accept: application/json, */*
Connection: keep-alive
Content-Length: 43
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9


'''

# Generated at 2022-06-23 19:28:44.562797
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()
    assert instance.format_options == {'headers': {'sort': True}}



# Generated at 2022-06-23 19:28:48.872114
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	headersFormatter = HeadersFormatter(format_options={'headers': {'sort': True}})
	assert headersFormatter.__init__
	

# Generated at 2022-06-23 19:28:50.307132
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # assert raisers
    assert HeadersFormatter

# Tests Format headers 

# Generated at 2022-06-23 19:28:51.290998
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None


# Generated at 2022-06-23 19:28:53.228129
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    if f.enabled:
        assert True
    else:
        assert False

# Generated at 2022-06-23 19:28:54.222516
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:29:00.218610
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\r\nAccept: application/json\r\nHeader 1: val1\r\nHeader 1: val1a\r\nHeader 2: val2\r\nContent-Type: application/json\r\nHost: example.com\r\n"""
    expected = """\r\nAccept: application/json\r\nContent-Type: application/json\r\nHeader 1: val1\r\nHeader 1: val1a\r\nHeader 2: val2\r\nHost: example.com\r\n"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-23 19:29:00.912226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	headers = HeadersFormatter()


# Generated at 2022-06-23 19:29:10.907121
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Accept-Encoding: identity
Set-Cookie: a=foo
Content-Length: 13
Set-Cookie: b=bar
Connection: close
Server: SimpleHTTP/0.6 Python/3.4.0
Date: Mon, 20 Oct 2014 13:23:38 GMT
Content-type: text/plain

'''
    print(formatter.format_headers(headers))

# Generated at 2022-06-23 19:29:17.409316
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # headers is of type str
    headers = "HTTP/1.1 200 OK\r\nContent-Length: 100\r\nConnection: keep-alive\r\nDate: Tue, 20 Mar 2018 22:13:36 GMT\r\nSet-Cookie: session=abcde\r\nServer: MyServer/1.1\r\n\r\n"
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == "HTTP/1.1 200 OK\r\nConnection: keep-alive\r\nContent-Length: 100\r\nDate: Tue, 20 Mar 2018 22:13:36 GMT\r\nServer: MyServer/1.1\r\nSet-Cookie: session=abcde\r\n\r\n"



# Generated at 2022-06-23 19:29:26.768715
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    def run_test(headers: str) -> str:
        print(headers)
        headers_formatter = HeadersFormatter()
        return headers_formatter.format_headers(headers + '\r\n')

    test_headers_1 = '''\
HTTP/1.1 200 OK
Header1: value1
Header2: value2
Header3: value3
Header4: value4
Header5: value5
'''
    assert run_test(test_headers_1) == test_headers_1

    test_headers_2 = '''\
HTTP/1.1 200 OK
Header2: value2
Header3: value3
Header4: value4
Header5: value5
Header1: value1
'''
    assert run_test(test_headers_2) == test_headers_1

    test_headers_