

# Generated at 2022-06-23 19:19:30.597674
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test 1
    headers1 = (
        'Host: https://httpbin.org\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: */*\r\n'
        'User-Agent: HTTPie/1.0.2\r\n'
    )
    assert (
        HeadersFormatter.format_headers(headers1) ==
        'Host: https://httpbin.org\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'User-Agent: HTTPie/1.0.2\r\n'
    )

    # Test 2

# Generated at 2022-06-23 19:19:31.590399
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter().format_options, dict)


# Generated at 2022-06-23 19:19:32.862960
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:19:36.199814
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert x.format_options["headers"]["sort"]



# Generated at 2022-06-23 19:19:45.927472
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from collections import OrderedDict
    headers = '''\
HTTP/1.1 200 OK
Date: Fri, 09 Aug 2019 18:46:01 GMT
Server: Apache
Last-Modified: Fri, 09 Aug 2019 18:46:01 GMT
ETag: "2-58a6d647e6a00"
Accept-Ranges: bytes
Content-Length: 2
Content-Type: text/html
X-Cache: MISS from localhost
Via: 1.1 localhost (squid)
Connection: close'''

# Generated at 2022-06-23 19:19:46.542600
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-23 19:19:49.057261
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter(format_options={})
    assert fmt.format_options['headers']['sort'] == True

# Generated at 2022-06-23 19:19:51.479139
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None


# Generated at 2022-06-23 19:19:57.699321
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = '\r\n'.join([
        'http: example.org',
        'Content-Length: 0',
        'Content-Type: application/json',
        'Date: Fri, 26 Aug 2016 15:39:20 GMT',
        'Host: example.org',
        'User-Agent: HTTPie/0.9.9',
        'X-Custom-Header: FooBar'
    ])
    assert HeadersFormatter().format_headers(expected) == expected



# Generated at 2022-06-23 19:19:58.974485
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True

# Generated at 2022-06-23 19:20:02.287768
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort' : True}})



# Generated at 2022-06-23 19:20:10.086083
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2
"""
    assert HeadersFormatter().format_headers(headers) == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2
"""

# Generated at 2022-06-23 19:20:11.973732
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.enabled is True

# Generated at 2022-06-23 19:20:22.911550
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head = HeadersFormatter()
    head.format_options['headers']['sort'] = False
    assert head.format_headers("") == ""
    assert head.format_headers("foo:bar") == "foo:bar"
    assert head.format_headers("foo:bar\r\nbaz:qux") == "foo:bar\r\nbaz:qux"
    assert head.format_headers("foo:bar\r\nbar:baz\r\nbaz:qux") == "foo:bar\r\nbar:baz\r\nbaz:qux"

    head.format_options['headers']['sort'] = True
    assert head.format_headers("") == ""
    assert head.format_headers("foo:bar") == "foo:bar"

# Generated at 2022-06-23 19:20:32.697252
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {
        'headers': {
            'sort': True
        }
    }

    headers_string = "HTTP/1.1 200 OK\r\n"
    headers_string += "Content-Type: application/json; charset=utf-8\r\n"
    headers_string += "Connection: close\r\n"
    headers_string += "Content-Length: 14\r\n"
    headers_string += "Server: SimpleHTTP/0.6 Python/3.7.3\r\n"
    headers_string += "\r\n"

    headers_string_modif = "HTTP/1.1 200 OK\r\n"
    headers_string_modif += "Content-Length: 14\r\n"


# Generated at 2022-06-23 19:20:40.157079
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = parse_headers("""
    HTTP/1.1 200 OK
    Connection: keep-alive
    Content-Length: 9
    Content-Type: application/json; charset=utf-8
    Date: Tue, 09 Feb 2016 02:50:28 GMT
    Etag: W/"9-1454702223000"
    X-Powered-By: Express
    """)
    result = hf.format_headers(headers)

# Generated at 2022-06-23 19:20:41.307413
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Generated at 2022-06-23 19:20:43.994156
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(path='/Users/matthew/PycharmProjects/httpie/httpie')
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:20:46.196864
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=None)
    assert formatter.enabled == False


# Generated at 2022-06-23 19:20:56.486941
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "POST / HTTP/1.1\r\n" \
              "from: example.org\r\n" \
              "accept: */*\r\n" \
              "accept: application/json, text/javascript, */*; q=0.01\r\n" \
              "content-type: application/x-www-form-urlencoded\r\n" \
              "user-agent: HTTPie/0.9.3\r\n" \
              "content-length: 25\r\n" \
              "\r\n" \
              "foo=bar&baz=qux"

    formatter_headers = HeadersFormatter()
    formatted_headers = formatter_headers.format_headers(headers)


# Generated at 2022-06-23 19:21:03.160401
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test with a sequence of headers
    input_header = '''\
User-Agent: httpie/0.9.9
Accept-Encoding: gzip, deflate
Host: api.github.com
Accept: */*
Connection: keep-alive
'''

    expected_header = '''\
User-Agent: httpie/0.9.9
Accept-Encoding: gzip, deflate
Host: api.github.com
Accept: */*
Connection: keep-alive
'''

    output_header = HeadersFormatter().format_headers(input_header)
    assert output_header == expected_header



# Generated at 2022-06-23 19:21:09.091621
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    args = {}
    args['headers'] = '''GET / HTTP/1.1
Host: httpbin.org
User-Agent: HTTPie/0.9.7
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive'''
    actual = h.format_headers(args['headers'])
    expected = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.7'''
    assert actual == expected

# Generated at 2022-06-23 19:21:18.242300
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:21:27.935254
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Given
    formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 201 Created
Connection: keep-alive
Content-Length: 117
Content-Type: application/json
Date: Sun, 03 Nov 2019 05:15:39 GMT
Server: gunicorn/19.9.0
Vary: Accept
Begin-End: 2019-11-03 05:15:39.245626
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block

'''

    # When
    headers = formatter.format_headers(headers)

    # Then

# Generated at 2022-06-23 19:21:30.711423
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True
    assert hf.format_options['headers']['sort'] == True

# Generated at 2022-06-23 19:21:32.066654
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert issubclass(HeadersFormatter, FormatterPlugin)


# Generated at 2022-06-23 19:21:33.500379
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter)

# Generated at 2022-06-23 19:21:35.110389
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == True

# Unit tests for sort_headers

# Generated at 2022-06-23 19:21:47.134963
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

# Generated at 2022-06-23 19:21:56.770158
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 35
Authorization: Basic c29vbGFuZW06c29vbGFuZW0=
User-Agent: HTTPie/1.0.0
Connection: close

""") == """\
HTTP/1.1 200 OK
Authorization: Basic c29vbGFuZW06c29vbGFuZW0=
Connection: close
Content-Length: 35
Content-Type: application/json
User-Agent: HTTPie/1.0.0

"""


# Generated at 2022-06-23 19:22:01.780856
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'Header: 1',
        'Other-Header: 2',
        'Header: 3',
    ])) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Other-Header: 2',
        'Header: 1',
        'Header: 3',
    ])

# Generated at 2022-06-23 19:22:03.122431
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-23 19:22:12.876148
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}},
        arg_configs={},
        config={})
    assert headers_formatter.enabled
    #assert headers_formatter.format_headers('\r\n'.join(['a: 1', 'b: 2', 'c: 3'])) \
    #       == '\r\n'.join(['a: 1', 'b: 2', 'c: 3'])
    #assert headers_formatter.format_headers('\r\n'.join(['b: 2', 'c: 3', 'a: 1'])) \
    #       == '\r\n'.join(['a: 1', 'b: 2', 'c: 3'])
    #assert headers_formatter.format_headers('\r\n'.

# Generated at 2022-06-23 19:22:19.514984
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''Content-Type: application/json
            Accept: application/json
            Accept-Encoding: gzip, deflate
            Authorization: Bearer 4e1b7e62-f8a5-4146-b709-0a0d06a67178
            Connection: keep-alive
            User-Agent: HTTPie/2.1.0'''
    expected = '''Content-Type: application/json
            Accept: application/json
            Accept-Encoding: gzip, deflate
            Authorization: Bearer 4e1b7e62-f8a5-4146-b709-0a0d06a67178
            Connection: keep-alive
            User-Agent: HTTPie/2.1.0'''


# Generated at 2022-06-23 19:22:23.380905
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    '''
    Tests the constructor of HeadersFormatter class
    '''
    headers_formatter = HeadersFormatter()
    assert isinstance( headers_formatter, HeadersFormatter)


# Generated at 2022-06-23 19:22:33.100063
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(kwargs={'format_options': {'headers': {'sort': True}}})
    headers = '''HTTP/1.1 200 OK\r
Server: Apache\r
Content-Type: application/json\r
Cache-Control: max-age=60\r
Content-Length: 43\r
Connection: keep-alive\r
\r
'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK\r
Cache-Control: max-age=60\r
Connection: keep-alive\r
Content-Length: 43\r
Content-Type: application/json\r
Server: Apache\r
\r
'''



# Generated at 2022-06-23 19:22:34.826825
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**{'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:22:36.738961
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()
    assert instance is not None


# Generated at 2022-06-23 19:22:40.087033
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__.__name__ == '__init__'


# Generated at 2022-06-23 19:22:43.213199
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(**FORMAT_OPTIONS)
    assert headersFormatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:22:48.540521
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={
            'headers': {'sort': True}
        }
    )
    assert headers_formatter.enabled
    headers_formatter = HeadersFormatter(
        format_options={
            'headers': {'sort': False}
        }
    )
    assert not headers_formatter.enabled
    


# Generated at 2022-06-23 19:22:59.772900
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    headers_formatter = HeadersFormatter(**{
        'color': False,
        'format': 'default',
        'indent': 2,
        'options': {'headers': {'sort': True, 'separator': ': '}},
        'style': None
    })

    # Exercise
    result = headers_formatter.format_headers("""\
GET / HTTP/1.1
Content-length: 10
Content-Type: application/json
Authorization: Basic YWxhZGRpbjpPcGVuU2VzYW1l
""")

    # Verify

# Generated at 2022-06-23 19:23:01.770172
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.enabled


# Test for format_headers

# Generated at 2022-06-23 19:23:04.082635
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.format_options['headers']['sort'] == False
    assert f.enabled == False


# Generated at 2022-06-23 19:23:11.934070
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
        Content-Type: application/json
        Content-Length: 300
        X-Field-1: 1
        Z-Field-2: 2
        Z-Field-1: 1
        X-Field-2: 2
    '''
    expected_output = '''
        Content-Type: application/json
        Content-Length: 300
        X-Field-1: 1
        X-Field-2: 2
        Z-Field-1: 1
        Z-Field-2: 2
    '''
    assert expected_output == HeadersFormatter(format_options={
        'headers': {'sort': True}
    }).format_headers(headers)


# Generated at 2022-06-23 19:23:21.308836
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter.
    """
    head = HeadersFormatter()
    sorted_header = head.format_headers(
        'HTTP/1.1 200 OK\r\n' +
        'Content-Type: text/plain\r\n' +
        'Location: /redirect/1\r\n' +
        'Set-Cookie: foo=bar\r\n' +
        'Set-Cookie: bar=baz\r\n' +
        'Date: Fri, 15 Nov 2019 13:52:11 GMT\r\n\r\n')
    print(sorted_header)

# Generated at 2022-06-23 19:23:22.514157
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert(headers_formatter.enabled)


# Generated at 2022-06-23 19:23:30.525206
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 28
Set-Cookie: a=1
Set-Cookie: b=2
Cookie: a=1
Cookie: b=2
"""
    expected = """\
HTTP/1.1 200 OK
Cookie: a=1
Cookie: b=2
Content-Length: 28
Content-Type: application/json
Set-Cookie: a=1
Set-Cookie: b=2
"""
    actual = formatter.format_headers(headers)
    assert actual == expected



# Generated at 2022-06-23 19:23:32.490443
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-23 19:23:34.825040
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, HeadersFormatter)


# Generated at 2022-06-23 19:23:42.771680
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:23:53.905669
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = [
        'X-Foo: bar',
        'X-Foo: bar',
        'X-Bar: foo',
        'X-Foo: bar',
        'X-Foo: bar',
        'X-Bar: foo',
    ]
    headers_str = '\r\n'.join(headers)
    assert h.format_headers(headers_str) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'X-Bar: foo',
        'X-Bar: foo',
        'X-Foo: bar',
        'X-Foo: bar',
        'X-Foo: bar',
        'X-Foo: bar',
    ])


# Generated at 2022-06-23 19:24:04.011405
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.stdout = io.StringIO()
    headers_formatter.format_headers('''\
GET / HTTP/1.0
Accept: image/jpeg, image/png;q=0.8
Connection: keep-alive
Accept-Encoding: gzip, deflate, sdch
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/50.0.2661.75 Chrome/50.0.2661.75 Safari/537.36
Accept-Language: en-US,en;q=0.8

''')
    

# Generated at 2022-06-23 19:24:05.403168
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False
    k = {"headers": {"sort": True}}
    h = HeadersFormatter(format_options=k)
    assert h.enabled == True



# Generated at 2022-06-23 19:24:13.412904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Server: nginx/1.6.2
Date: Thu, 14 Mar 2014 11:28:30 GMT
Content-Type: application/json; charset=UTF-8
Transfer-Encoding: chunked
Connection: keep-alive
Set-Cookie: foo=bar
Set-Cookie: c=d
Set-Cookie: a=b
X-Foo: bar
X-Bar: foo
'''

# Generated at 2022-06-23 19:24:14.560976
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        formatter = HeadersFormatter()
    except Exception:
        pass

# Generated at 2022-06-23 19:24:22.025916
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    inp = '''\
    HTTP/1.1 200 OK
    Server: nginx/1.0.15
    Date: Wed, 02 Oct 2013 10:42:36 GMT
    Content-Type: text/plain
    Connection: close
    Content-Length: 4

    '''
    exp = '''\
    HTTP/1.1 200 OK
    Connection: close
    Content-Length: 4
    Content-Type: text/plain
    Date: Wed, 02 Oct 2013 10:42:36 GMT
    Server: nginx/1.0.15
    '''
    assert h.format_headers(inp) == exp
    

# Generated at 2022-06-23 19:24:29.496905
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers1 = """\
POST /foo HTTP/1.1
Host: example.com
Content-Length: 5
User-Agent: HTTPie/0.9.9
X-Thing: thing1
X-Thing: thing2"""
    headers2 = """\
POST /foo HTTP/1.1
Host: example.com
User-Agent: HTTPie/0.9.9
Content-Length: 5
X-Thing: thing1
X-Thing: thing2"""
    assert headers1.strip() == h.format_headers(headers2).strip()

# Generated at 2022-06-23 19:24:36.151213
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    result = """Host: example.org
Accept: application/json
Accept: */*
User-Agent: httpie/0.9.9"""
    order = {'Accept': ['application/json', '*/*'], 'Host': 'example.org', 'User-Agent': 'httpie/0.9.9'}
    headers = ['{0}: {1}'.format(key, value) for key in order.keys() for value in order[key]]
    headers_str = '\r\n'.join(headers)
    assert headers_str == result

# Generated at 2022-06-23 19:24:38.473532
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter != None


# Generated at 2022-06-23 19:24:44.478326
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter is not None
    formatter.format_headers("HTTP/1.1 200 OK\r\nHost: localhost\r\nAccept: */*\r\nUser-Agent: HTTPie/0.9.6\r\nAccept-Encoding: gzip, deflate, compress\r\nConnection: keep-alive\r\n\r\n") == "HTTP/1.1 200 OK\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, compress\r\nConnection: keep-alive\r\nHost: localhost\r\nUser-Agent: HTTPie/0.9.6\r\n\r\n"


# Generated at 2022-06-23 19:24:48.764608
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Allow: DELETE, GET, OPTIONS, PATCH, POST, PUT
Content-Length: 9
Content-Type: application/json
Content-Encoding: utf-8
Accept-Encoding: gzip, deflate
X-Powered-By: Express
ETag: W/"9-2a7e259bdfad3dd9056c861a9b9c39ae"
Connection: keep-alive
Date: Fri, 02 Mar 2018 16:29:38 GMT
"""

# Generated at 2022-06-23 19:24:53.519058
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from .mocks import MockEnvironment

    env = MockEnvironment()
    env.stdout = io.StringIO()
    formatter = HeadersFormatter(env)

    assert formatter.format_options['headers']['sort']
    assert formatter.enabled


# Generated at 2022-06-23 19:24:56.485735
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter(format_options={'headers': {'sort': True}})

    # test
    formatted = plugin.format_headers("""\
HTTP/1.1 200 OK
B: 2
A: 1
B: 3
A: 4
""")
    # verify
    assert formatted == """
HTTP/1.1 200 OK
A: 1
A: 4
B: 2
B: 3
""".lstrip('\r\n')


# Generated at 2022-06-23 19:24:59.330605
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}}
    )
    assert formatter.enabled is True
    assert isinstance(formatter, HeadersFormatter)


# Generated at 2022-06-23 19:25:00.539234
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter({'headers': {'sort': True}}).enabled



# Generated at 2022-06-23 19:25:07.177276
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
        headers = "HTTP/1.1 302 Found\nDate: Fri, 26 Apr 2019 16:48:23 GMT\nServer: Apache/2.4.3 (CentOS)\nSet-Cookie: PHPSESSID=4l1apvkce2t7ukbabrfkgjd7s2; path=/\nExpires: Thu, 19 Nov 1981 08:52:00 GMT\nCache-Control: no-store, no-cache, must-revalidate\nPragma: no-cache\nLocation: http://0.0.0.0:8080/SuccessLogin.php\nContent-Length: 0\nContent-Type: text/html; charset=UTF-8\n"
        x = HeadersFormatter()

# Generated at 2022-06-23 19:25:13.184791
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Length: 8
Cookie: a=1
Content-Type: application/json
Cookie: b=1'''
    headers_sorted = '''\
Content-Length: 8
Cookie: a=1
Cookie: b=1
Content-Type: application/json'''
    assert HeadersFormatter().format_headers(headers) == headers_sorted


# Generated at 2022-06-23 19:25:14.143878
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  pass


# Generated at 2022-06-23 19:25:19.888814
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Cookie: foo=bar;
Pragma: no-cache
Set-Cookie:abc=def;
Date: Mon, 22 Apr 2019 16:23:02 GMT
    '''
    expected = '''
HTTP/1.1 200 OK
Cookie: foo=bar;
Date: Mon, 22 Apr 2019 16:23:02 GMT
Pragma: no-cache
Set-Cookie:abc=def;
    '''
    assert expected == formatter.format_headers(headers)


# Generated at 2022-06-23 19:25:23.902631
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Connection: keep-alive',
        'Content-Type: text/plain',
        'Content-Length: 5',
        'Content-Length: 10',
    ])
    headers = HeadersFormatter().format_headers(headers)
    assert headers == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Length: 5',
        'Content-Length: 10',
        'Content-Type: text/plain',
        'Connection: keep-alive',
    ])

# Generated at 2022-06-23 19:25:32.938226
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers(raw_headers)
    expected_headers = """
POST /post HTTP/1.1
User-Agent: httpie
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 41
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Cookie: foo=bar
Host: httpbin.org
X-Header: one
X-Header: two
X-Header: three
""".strip()
    assert headers == expected_headers

# Generated at 2022-06-23 19:25:33.833687
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-23 19:25:40.034968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """\
content-type: text/plain
host: example.org
connection: Keep-Alive
date: Sun, 16 Oct 2016 07:03:37 GMT
"""
    dict1 = {'host': 'example.org', 'connection': 'Keep-Alive', 'date': 'Sun, 16 Oct 2016 07:03:37 GMT', 'content-type': 'text/plain'}
    dict2 = {}
    dict3 = {'content-type': 'text/plain', 'date': 'Sun, 16 Oct 2016 07:03:37 GMT', 'connection': 'Keep-Alive', 'host': 'example.org'}

# Generated at 2022-06-23 19:25:41.849144
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = unit.HeadersFormatter()
    assert isinstance(a, HeadersFormatter)

# Generated at 2022-06-23 19:25:47.999564
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # call constructor of HeadersFormatter with invalid parameter
    with pytest.raises(AssertionError):
        HeadersFormatter(format_options = {'headers':{'sort':'bad_value'}})
    # call constructor of HeadersFormatter with valid parameter
    headers_formatter = HeadersFormatter(format_options = {'headers':{'sort':True}})
    assert headers_formatter.format_options == {'headers':{'sort':True}}


# Generated at 2022-06-23 19:25:53.969235
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = {'headers': {'sort': False, 'show': True}}
    formatter = HeadersFormatter(format_options=options)
    assert formatter.enabled is False
    assert formatter.format_options['headers']['sort'] is False
    assert formatter.format_options['headers']['show'] is True


# Generated at 2022-06-23 19:25:56.911609
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_name == 'headers'
    assert headers_formatter.enabled is False


# Generated at 2022-06-23 19:25:59.769213
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()

    assert formatter.format_options == {
        'headers': {
            'sort': False
        }
    }

# Generated at 2022-06-23 19:26:10.588684
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    HEADERS_IN = '''\
Content-Type: application/json; charset=utf-8
Connection: keep-alive
Accept: application/json
User-Agent: HTTPie/2.2.0
'''
    HEADERS_OUT = '''\
Content-Type: application/json; charset=utf-8
Accept: application/json
Connection: keep-alive
User-Agent: HTTPie/2.2.0
'''
    assert hf.format_headers(HEADERS_IN) == HEADERS_OUT


_help = """
Sort headers alphabetically by name.

To sort headers, set the `--headers` (``-h``) option.

"""
plugin_class = HeadersFormatter

# Unit test plugin_class

# Generated at 2022-06-23 19:26:12.114895
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:26:15.508611
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert isinstance(hf, HeadersFormatter)

# Unit test to check if headers are sorted

# Generated at 2022-06-23 19:26:18.971576
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert type(headers_formatter) == HeadersFormatter
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:26:29.235765
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Method format_headers of class HeadersFormatter
    """
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:26:32.042968
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    foo = HeadersFormatter(format_options = {
        'headers' : {
            'sort' : True
        }
    })
    assert foo.enabled == True, '__init__() of class HeadersFormatter is not working'



# Generated at 2022-06-23 19:26:43.286166
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Cache-Control: max-age=604800
Content-Type: text/html; charset=UTF-8
Date: Sat, 23 Jun 2018 12:44:41 GMT
Etag: "1541025663+ident"
Expires: Sat, 30 Jun 2018 12:44:41 GMT
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (oxr/8313)
Vary: Accept-Encoding
X-Cache: HIT
Content-Length: 1270
"""

# Generated at 2022-06-23 19:26:55.332791
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # Test headers that should be sorted
    unsorted_headers = """\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Content-Type: text/html; charset=UTF-8
Content-Length: 138
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
ETag: "3f80f-1b6-3e1cb03b"
Accept-Ranges: bytes
Connection: close"""

# Generated at 2022-06-23 19:27:01.631688
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '\r\n'.join(['GET /path HTTP/1.1', 'Host: example.com',
                           'User-Agent: IHTTPIE/0.9.1', 'Accept: */*',
                          'Connection: keep-alive'])
    assert formatter.format_headers(headers) == \
        '\r\n'.join(['GET /path HTTP/1.1', 'Accept: */*',
                     'Connection: keep-alive',
                     'Host: example.com', 'User-Agent: IHTTPIE/0.9.1'])



# Generated at 2022-06-23 19:27:07.131268
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] is False
    assert formatter.enabled is False

    formatter = HeadersFormatter(headers_sort=True)
    assert formatter.format_options['headers']['sort'] is True
    assert formatter.enabled is True


# Generated at 2022-06-23 19:27:14.167708
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 16
Content-Type: application/json
Date: Sun, 23 Jun 2019 09:10:56 GMT
Server: nginx/1.15.10'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 16
Content-Type: application/json
Date: Sun, 23 Jun 2019 09:10:56 GMT
Server: nginx/1.15.10'''
    actual = headers_formatter.format_headers(headers)
    assert actual == expected


# Generated at 2022-06-23 19:27:16.510715
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    res = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert res.enabled == True


# Generated at 2022-06-23 19:27:20.861849
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('GET https://www.google.com\nAccept-encoding: foo\nContent-type: text/html\nAccept-encoding: bar') == 'GET https://www.google.com\nAccept-encoding: foo\nAccept-encoding: bar\nContent-type: text/html'

# Generated at 2022-06-23 19:27:24.094496
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header = HeadersFormatter()
    print(header)
    header.format_headers("""Content-Type: application/json
Accept: application/json
User-Agent: HTTPie/0.9.3
Content-Length: 73
""")

# Generated at 2022-06-23 19:27:28.583847
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor
    assert issubclass(HeadersFormatter, FormatterPlugin)
    h = HeadersFormatter()
    assert isinstance(h, HeadersFormatter)
    assert isinstance(h, FormatterPlugin)


# Generated at 2022-06-23 19:27:35.325375
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    self = HeadersFormatter()
    self.output_options['headers'] = True
    self.format_options['headers']['sort'] = True
    assert self.format_headers('Content-Type: application/x-www-form-urlencoded\r\nContent-Length: 0\r\nAccept: */*') == 'Content-Length: 0\r\nContent-Type: application/x-www-form-urlencoded\r\nAccept: */*'


plugin_cls = HeadersFormatter

# Generated at 2022-06-23 19:27:43.909366
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:27:54.706834
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = """\
connection: keep-alive
content-encoding: gzip
content-length: 566
content-type: application/json
accept: */*
host: httpbin.org
accept-encoding: gzip, deflate
user-agent: HTTPie/0.9.9"""

    expected_headers = """\
connection: keep-alive
accept: */*
accept-encoding: gzip, deflate
content-encoding: gzip
content-length: 566
content-type: application/json
host: httpbin.org
user-agent: HTTPie/0.9.9"""

    assert formatter.format_headers(headers) == expected_headers


# Generated at 2022-06-23 19:28:04.077915
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import registry
    registry.installed_plugins.append(HeadersFormatter)
    # Create an instance of the HeadersFormatter class
    hf = HeadersFormatter()

    headers = "Accept: application/json\n" \
              "User-Agent: HTTPie/0.9.0\n" \
              "Accept-Charset: UTF-8,*\n" \
              "Connection: keep-alive\n"

    out = hf.format_headers(headers)
    assert out == "Accept-Charset: UTF-8,*\r\n" \
                  "Accept: application/json\r\n" \
                  "Connection: keep-alive\r\n" \
                  "User-Agent: HTTPie/0.9.0"
    # no need for the plugin to

# Generated at 2022-06-23 19:28:06.126781
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={"headers":{"sort":True},"format":"colors"})
    assert headers_formatter.enabled == True

# Generated at 2022-06-23 19:28:12.845618
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = {'headers': {'format': 'pretty', 'sort': True}}
    form = HeadersFormatter(format_options=head, print_body=False)

    assert form.enabled == head['headers']['sort']
    assert form.format_options == head
    assert form.print_body == False


from httpie.compat import is_windows
from httpie.downloads import (
    parse_content_range, filename_from_content_disposition, filename_from_url,
    get_unique_filename, ContentRangeError, ContentRange, filename_from_headers
)


# Generated at 2022-06-23 19:28:14.741497
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={"headers":{"sort": True}})
    assert headers_formatter
    assert headers_formatter.format_options == {"headers":{"sort": True}}
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:28:22.460807
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    g = HeadersFormatter(format_options = {'headers': {'sort': True}})
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=iso-8859-1
Set-Cookie: a=A;
Set-Cookie: b=B
Set-Cookie: c=C;

'''
    assert g.format_headers(headers) == '''HTTP/1.1 200 OK
Set-Cookie: a=A;
Set-Cookie: b=B
Set-Cookie: c=C;
Content-Type: text/html; charset=iso-8859-1

'''

# Generated at 2022-06-23 19:28:31.796235
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headersFormatter.format_headers('test') == 'test'
    assert headersFormatter.format_headers('test\ntest') == 'test\ntest'
    assert headersFormatter.format_headers('test\ntest: test\na: 1\n') == 'test\na: 1\ntest: test\n'
    assert headersFormatter.format_headers('test\ntest: test\nz: 1\n') == 'test\nz: 1\ntest: test\n'
    assert headersFormatter.format_headers('test\ntest: test\na: 1\nz: 1\n') == 'test\na: 1\ntest: test\nz: 1\n'
    assert headersFormatter.format_headers

# Generated at 2022-06-23 19:28:42.912347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hp = HeadersFormatter()
    headers = hp.format_headers('HTTP/1.1 200 OK\r\n'
                                'Host: github.com\r\n'
                                'Accept: */*\r\n'
                                'Accept-Encoding: gzip, deflate\r\n'
                                'Connection: keep-alive\r\n'
                                'User-Agent: HTTPie/0.9.2')

# Generated at 2022-06-23 19:28:54.442367
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:29:03.409305
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # setup
    header_string1 = '''GET / HTTP/1.1
Host: www.google.com
User-Agent: curl/7.43.0
Accept: */*
Cookie: foo=bar; path=/

'''
    header_string2 = '''GET / HTTP/1.1
Host: www.google.com
User-Agent: curl/7.43.0
Cookie: foo=bar; path=/
Accept: */*

'''
    f1 = HeadersFormatter()
    f2 = HeadersFormatter()

    # operation
    header_string1_formatted = f1.format_headers(header_string1)
    header_string2_formatted = f2.format_headers(header_string2)

    # verification
    assert header_string1_formatted == header_string

# Generated at 2022-06-23 19:29:12.702788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        'GET / HTTP/1.1\r\n'
        'Aa: b\r\n'
        'Ab: c\r\n'
        'Aa: d\r\n'
        'Aa: e\r\n'
        'Aa: f\r\n'
    ) == (
        'GET / HTTP/1.1\r\n'
        'Aa: b\r\n'
        'Aa: d\r\n'
        'Aa: e\r\n'
        'Aa: f\r\n'
        'Ab: c\r\n'
    )

# Generated at 2022-06-23 19:29:24.301965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.formatters import HeadersFormatter
    fp = FormatterPlugin()
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})