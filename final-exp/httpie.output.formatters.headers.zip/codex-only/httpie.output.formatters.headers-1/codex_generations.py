

# Generated at 2022-06-23 19:19:26.944300
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Test HeadersFormatter.__init__()
    """

    # Test if HeadersFormatter object is created correctly
    headers_formatter = HeadersFormatter(
        format_options={"headers": {"sort": True}})
    assert headers_formatter is not None

    # Test if HeadersFormatter object does not store a wrong
    # argument value for 'sort'
    headers_formatter = HeadersFormatter(
        format_options={"headers": {"sort": False}})
    assert headers_formatter.enabled == False



# Generated at 2022-06-23 19:19:34.170319
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    headers.format_options['headers']['sort'] = True
    response = '''HTTP/1.0 200 OK
Content-Type: text/html; charset=utf-8
Server: Werkzeug/0.15.3 Python/3.8.2
Date: Thu, 26 Nov 2020 00:29:53 GMT
Content-Length: 50

'''
    assert headers.format_headers(response) == '''HTTP/1.0 200 OK
Content-Length: 50
Content-Type: text/html; charset=utf-8
Date: Thu, 26 Nov 2020 00:29:53 GMT
Server: Werkzeug/0.15.3 Python/3.8.2

'''

# Generated at 2022-06-23 19:19:37.234834
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	obj = HeadersFormatter()
	assert obj.enabled == obj.format_options['headers']['sort']


# Generated at 2022-06-23 19:19:46.493922
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    instance = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert instance.format_headers('test-headers') == 'test-headers'

    headers = '''\
Host: localhost:8080
Content-Type: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
Content-Length: 29
'''.strip()

    expected_headers = '''\
Host: localhost:8080
Content-Type: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
Content-Length: 29
'''.strip()
    assert instance.format_headers(headers) == expected_headers

    # without sorting
    instance = Headers

# Generated at 2022-06-23 19:19:57.570752
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:20:05.203245
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nZZ: first\r\na: 2\r\nA: 1\r\n') == \
           'HTTP/1.1 200 OK\r\nA: 1\r\na: 2\r\nZZ: first\r\n'

    # Test that multiple headers with the same name
    # retain their relative order
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nA: 1\r\na: 2\r\nA: 1\r\n') == \
           'HTTP/1.1 200 OK\r\nA: 1\r\nA: 1\r\na: 2\r\n'

# Generated at 2022-06-23 19:20:14.217994
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\nExpires: Tue, 28 Apr 2020 14:27:22 GMT\r\nConnection: close'
    formatted_headers = 'HTTP/1.1 200 OK\r\nContent-Length: 12\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\nExpires: Tue, 28 Apr 2020 14:27:22 GMT'
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_headers(headers) == formatted_headers

# Generated at 2022-06-23 19:20:20.982611
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "HTTP/1.1 2\r\n"\
              "z:2\r\n"\
              "b:1\r\n"\
              "a:1\r\n"\
              "a:0\r\n"\
              "a:2\r\n"\
              "c:0\r\n"
    output = "HTTP/1.1 2\r\n"\
             "a:0\r\n"\
             "a:1\r\n"\
             "a:2\r\n"\
             "b:1\r\n"\
             "c:0\r\n"\
             "z:2\r\n"
    assert output == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-23 19:20:31.742918
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    # Test with multiple headers with the same name
    request_headers = '''GET / HTTP/1.1
Host: httpbin.org
Accept: application/json
Accept: application/xml
'''
    expected = '''GET / HTTP/1.1
Host: httpbin.org
Accept: application/json
Accept: application/xml
'''
    assert headers_formatter.format_headers(request_headers) == expected

    # Test with multiple headers with the same name (reverse order keeps the same order)
    request_headers = '''GET / HTTP/1.1
Host: httpbin.org
Accept: application/xml
Accept: application/json
'''

# Generated at 2022-06-23 19:20:33.409562
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled == True
    assert HeadersFormatter(sort=False).enabled == False

# Generated at 2022-06-23 19:20:40.632130
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:20:44.002161
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': 'True'}})
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.enabled == True


# Generated at 2022-06-23 19:20:46.196670
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test for whether all items in the class are initialized correctly
    assert isinstance(HeadersFormatter(), HeadersFormatter)

# Generated at 2022-06-23 19:20:50.969652
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers':{'sort': True}})
    #assert formatter.__class__ == 'HeadersFormatter'
    assert formatter.__class__.__name__ == 'HeadersFormatter'


# Generated at 2022-06-23 19:20:52.984843
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options = {'headers': {'sort': True}}) is not None

# Generated at 2022-06-23 19:20:54.366967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False


# Generated at 2022-06-23 19:20:56.439314
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert fmt.enabled
    assert fmt.format_options['headers']['sort']
    assert fmt.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:21:03.457377
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    text = 'HTTP/1.1 200 OK\r\n'
    text += 'Accept-Ranges: bytes\r\n'
    text += 'Access-Control-Allow-Origin: *\r\n'
    text += 'Age: 0\r\n'
    text += 'Cache-Control: private, max-age=0, no-transform\r\n'
    text += 'Content-Disposition: inline; filename="index.html"\r\n'
    text += 'Content-Encoding: gzip\r\n'
    text += 'Content-Language: en\r\n'
    text += 'Content-Length: 664\r\n'
    text += 'Content-Type: text/html; charset=utf-8\r\n'

# Generated at 2022-06-23 19:21:05.525732
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_format = HeadersFormatter()
    assert header_format.enabled == header_format.format_options['headers']['sort']



# Generated at 2022-06-23 19:21:08.980589
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatterPlugin = HeadersFormatter(format_options={'json': {'sort': False}})
    assert type(formatterPlugin) == HeadersFormatter


# Generated at 2022-06-23 19:21:20.094262
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    from tempfile import NamedTemporaryFile
    from os import linesep

    piped = True

    def init():
        file = NamedTemporaryFile(mode='w', delete=False)
        file.writelines([
            'HEADERS',
            'Cookie: first=1; second=2',
            'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Cookie: first=B; second=A',
        ])
        file.writelines([linesep])  # TODO: linesep is unnecessary?
        file.close()
        return file.name



# Generated at 2022-06-23 19:21:28.867122
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:21:31.568164
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    #Check if HeadersFormatter object is created
    assert isinstance(HeadersFormatter(),HeadersFormatter)

# Generated at 2022-06-23 19:21:33.499864
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test = HeadersFormatter(format_options=_FORMAT_OPTIONS)
    assert test.enabled == True

# Generated at 2022-06-23 19:21:35.734424
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    test HeadersFormatter
    """
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:21:41.065226
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
    :authority: localhost:5000
    :method: GET
    :path: /
    :scheme: http
    accept: application/json
    accept: text/html
    cache-control: no-cache
    content-type: application/json
    """
    assert HeadersFormatter.format_headers(headers) == """
    :authority: localhost:5000
    :method: GET
    :path: /
    :scheme: http
    accept: application/json
    accept: text/html
    cache-control: no-cache
    content-type: application/json
    """



# Plugin #

# Generated at 2022-06-23 19:21:43.712508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is True


# Generated at 2022-06-23 19:21:46.652638
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass
    assert HeadersFormatter({'headers':{'sort': True}}).enabled is True 
    assert HeadersFormatter({'headers':{'sort': False}}).enabled is False


# Generated at 2022-06-23 19:21:55.408430
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Length: 65
Content-Type: application/json
Accept-Encoding: gzip
Connection: close
Host: httpbin.org
Accept: application/json
User-Agent: HTTPie/0.9.9

    '''
    assert HeadersFormatter().format_headers(headers) == '''\
Content-Length: 65
Content-Type: application/json
Accept: application/json
Accept-Encoding: gzip
Connection: close
Host: httpbin.org
User-Agent: HTTPie/0.9.9

    '''


# Generated at 2022-06-23 19:21:57.369267
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == True
    assert h.format_options['headers']['sort'] == True



# Generated at 2022-06-23 19:22:00.407626
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # true
    assert HeadersFormatter.enabled
    # test HeadersFormatter constructor
    assert isinstance(HeadersFormatter(), HeadersFormatter)

# Integration test for constructor of class HeadersFormatter

# Generated at 2022-06-23 19:22:05.021339
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_headers('foo: bar\r\ncontent-type: baz') == 'foo: bar\r\ncontent-type: baz'

# Generated at 2022-06-23 19:22:07.162533
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options == __default_headers_options()
# Unit test: format_headers()

# Generated at 2022-06-23 19:22:14.927065
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    actual_headers_text = "HTTP/1.1 200 OK\r\nUser-Agent: httpie\r\nDate: Sat, 25 May 2019 20:38:12 GMT\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Length: 17\r\nContent-Type: application/json; charset=utf-8\r\nHost: 127.0.0.1:5000\r\n\r\n"

# Generated at 2022-06-23 19:22:16.827187
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert (HeadersFormatter().format_options['headers'] == {'sort': True})


# Generated at 2022-06-23 19:22:23.708842
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter(format_options={
        'headers': {
            'sort': True,
        }
    })
    assert fmt.format_headers('HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nCookie: foo=bar\r\nBaz: bax\r\nCache-Control: public\r\n') == 'HTTP/1.1 200 OK\r\nBaz: bax\r\nCache-Control: max-age=3600\r\nCache-Control: public\r\nCookie: foo=bar'

# Generated at 2022-06-23 19:22:29.770629
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""\
Accept: */*
User-Agent: abc
Cookie: foo=bar
Set-Cookie: baz=qux
""") == """\
Accept: */*
Cookie: foo=bar
Set-Cookie: baz=qux
User-Agent: abc
"""



# Generated at 2022-06-23 19:22:36.976011
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    sort_headers_formatter = FormatterPlugin.get('sort_headers')
    assert sort_headers_formatter.format_headers('Content-Type: text/plain\nContent-Length: 123\nContent-Encoding: gzip') == 'Content-Encoding: gzip\r\nContent-Length: 123\r\nContent-Type: text/plain'
    assert sort_headers_formatter.format_headers('Content-Type: text/html\nContent-Type: text/plain') == 'Content-Type: text/html\r\nContent-Type: text/plain'

# Generated at 2022-06-23 19:22:46.650042
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = '\n'.join((
        'GET / HTTP/1.1',
        'A: 1',
        'B: 2',
        'B: 3',
        'B: 4',
        'A: 5',
        ''
    ))
    actual = HeadersFormatter().format_headers('\n'.join((
        'GET / HTTP/1.1',
        'B: 3',
        'A: 5',
        'B: 4',
        'A: 1',
        'B: 2',
        ''
    )))
    assert actual == expected

# Generated at 2022-06-23 19:22:52.840905
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_data = {
        'args': [
            '--headers',
        ],
        'expected': {
            'sort': True,
        }
    }
    formatter = HeadersFormatter(**test_data)
    # assert formatter.format_options == test_data['expected']
    assert formatter.enabled == test_data['expected']['sort']


# Generated at 2022-06-23 19:22:53.507022
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:23:03.108965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    class TestHeadersFormatter(HeadersFormatter):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def format(self, headers: dict, **kwargs) -> str:
            return str(headers)


# Generated at 2022-06-23 19:23:12.030743
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:23:17.118497
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Headers in header string are in random order and some header fields occur
    # multiple times (e.g. Set-Cookie, Content-Type).
    headers = """\
HTTP/1.1 200 OK
Server: nginx
Date: Mon, 09 Jul 2018 11:15:31 GMT
Content-Type: application/json;charset=UTF-8
Content-Length: 182
Connection: keep-alive
Set-Cookie: crlfauth=xxx;Path=/;HttpOnly;Secure;SameSite=lax
Set-Cookie: sessionid=xxx; httponly; path=/
Set-Cookie: csrftoken=xxx; expires=Mon, 08-Jul-2019 11:15:31 GMT; Max-Age=31449600; Path=/"""

# Generated at 2022-06-23 19:23:26.655433
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import (
        formatter_plugin_registry as formatter_plugin_registry
    )
    hf = formatter_plugin_registry[HeadersFormatter]
    if hf.enabled:
        hf.enabled = False

    # Negative test
    headers = "HTTP/1.1 200 OK\r\n" + \
              "Connection: Keep-Alive\r\n" + \
              "Content-Length: 11\r\n" + \
              "Server: Apache/2.4.6 (CentOS) PHP/7.0.33\r\n" + \
              "X-Powered-By: PHP/7.0.33\r\n"
    assert hf.format_headers(headers) == headers

    # Positive test
    hf.enabled = True
    headers

# Generated at 2022-06-23 19:23:27.323822
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:23:28.598265
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:23:29.970600
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-23 19:23:39.428610
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_input = """GET / HTTP/1.1
Accept: */*
Connection: close
Content-Length: 2
Content-Type: text/plain; charset=UTF-8
Content-Length: 66
Content-Type: application/x-www-form-urlencoded; charset=UTF-8"""
    headers_expected = """GET / HTTP/1.1
Accept: */*
Connection: close
Content-Length: 2
Content-Type: text/plain; charset=UTF-8
Content-Length: 66
Content-Type: application/x-www-form-urlencoded; charset=UTF-8"""
    headers_actual = formatter.format_headers(headers_input)
    assert headers_actual == headers_expected

# Generated at 2022-06-23 19:23:45.582114
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Server: nginx/1.2.1
Date: Mon, 08 Jul 2017 16:42:13 GMT
Content-Type: text/html
Content-Length: 543
Last-Modified: Wed, 28 Jun 2017 16:07:31 GMT
Connection: keep-alive
'''
    expected_headers = '''
HTTP/1.1 200 OK
Content-Length: 543
Content-Type: text/html
Connection: keep-alive
Date: Mon, 08 Jul 2017 16:42:13 GMT
Last-Modified: Wed, 28 Jun 2017 16:07:31 GMT
Server: nginx/1.2.1
'''
    assert headers_formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:23:53.758391
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Type: application/json
X-Foo: Bar
Content-Length: 2
X-Foo: Baz
X-Foo: Quux
X-Bar: Foo
"""
    exp_headers = """\
Content-Type: application/json
X-Bar: Foo
X-Foo: Bar
X-Foo: Baz
X-Foo: Quux
Content-Length: 2
"""
    f = HeadersFormatter()
    assert f.format_headers(headers) == exp_headers



# Generated at 2022-06-23 19:24:04.010314
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:24:06.784284
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    format_options = {
        'headers': {
            'sort': True
        }
    }
    headers_formatter = HeadersFormatter(format_options = format_options)
    assert headers_formatter.format_options == format_options


# Generated at 2022-06-23 19:24:18.423835
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers_before = """\
HTTP/1.1 300 MULTIPLE CHOICES
Allow: GET, HEAD, OPTIONS
Content-Length: 0
Cache-Control: max-age=604800, public
Content-Type: text/html; charset=UTF-8
Date: Tue, 13 Mar 2018 15:49:29 GMT
"""
    headers_after = """\
HTTP/1.1 300 MULTIPLE CHOICES
Allow: GET, HEAD, OPTIONS
Cache-Control: max-age=604800, public
Content-Length: 0
Content-Type: text/html; charset=UTF-8
Date: Tue, 13 Mar 2018 15:49:29 GMT
"""
    assert h.format_headers(headers_before) == headers_after

# Generated at 2022-06-23 19:24:23.026005
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(
        format_options=OrderedDict([
            ('headers', OrderedDict([
                ('sort', True)
            ]))
        ])
    )
    assert formatter.enabled


# Generated at 2022-06-23 19:24:24.037233
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter()


# Generated at 2022-06-23 19:24:26.137082
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter(**{})
    assert instance is not None
    assert isinstance(instance, HeadersFormatter)



# Generated at 2022-06-23 19:24:36.412687
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    header_in = """HTTP/1.1 200 OK
Connection: keep-alive
Accept-Ranges: bytes
Last-Modified: Mon, 19 Feb 2018 05:03:32 GMT
Content-Length: 154
Date: Mon, 19 Feb 2018 05:03:32 GMT
Content-Type: text/html
Server: nginx/1.4.6 (Ubuntu)

"""
    header_out = h.format_headers(header_in)
    #print(header_out)

# Generated at 2022-06-23 19:24:46.659875
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-23 19:24:52.198668
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with requests.Session() as s:
        r = s.get('http://www.example.com/')
        r.encoding = 'utf-8'
        print(r.text)

    assert HeadersFormatter.__name__ == "HeadersFormatter"


# Generated at 2022-06-23 19:24:54.320534
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert type(HeadersFormatter(format_options={'headers': {'sort': True}})) == HeadersFormatter


# Generated at 2022-06-23 19:24:57.820576
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """ Test constructor of class HeadersFormatter """
    print("\nTesting constructor of class HeadersFormatter...")
    plugin = HeadersFormatter()
    assert plugin.enabled == plugin.format_options['headers']['sort']

# Generated at 2022-06-23 19:24:59.755501
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f_options = {'headers':{'sort':False}}
    assert HeadersFormatter(format_options=f_options)


# Generated at 2022-06-23 19:25:00.619976
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:25:10.924181
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    input = """GET http://example.com/ HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/1.0.3
Accept: */*
"""
    output = """GET http://example.com/ HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/1.0.3
"""
    # Exercise
    headers_formatter = HeadersFormatter()
    actual = headers_formatter.format_headers(input)
    # Verify
    assert actual == output
    # Cleanup - none necessary

# Generated at 2022-06-23 19:25:15.201941
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers(
        '''\
    Header1: value 1
    Header2: value 2
    Header1: value 3
  '''.strip()) == '''\
    Header1: value 1
    Header1: value 3
    Header2: value 2
  '''.strip()

# Generated at 2022-06-23 19:25:21.852781
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head = 'HTTP/1.1 200 OK\r\nHeader: Value\r\nAnotherHeader: AnotherValue\r\nHeader: Two Values\r\nHeader: Three Values\r\nHeader: Four Values\r\nHeader: Five Values\r\nHeader: Six Values\r\nHeader: Seven Values\r\nHeader: Eight Values\r\nHeader: Nine Values\r\nHeader: Ten Values\r\nHeader: Eleven Values\r\nHeader: Twelve Values\r\nHeader: Thirteen Values\r\nHeader: Fourteen Values\r\n\r\n{}'

# Generated at 2022-06-23 19:25:23.480538
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled



# Generated at 2022-06-23 19:25:27.033481
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert issubclass(HeadersFormatter, FormatterPlugin)
    assert callable(HeadersFormatter)

# Generated at 2022-06-23 19:25:30.825721
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={"headers": {"sort": True}}).format_options['headers']['sort'] == True
    assert not HeadersFormatter(format_options={"headers": {"sort": False}}).format_options['headers']['sort']


# Generated at 2022-06-23 19:25:39.271342
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:25:40.434616
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    output = HeadersFormatter()

# Generated at 2022-06-23 19:25:42.731539
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert obj.enabled == True



# Generated at 2022-06-23 19:25:50.840582
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:26:00.160373
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # insert a test case
    assert formatter.format_headers("GET / HTTP/1.1\r\nHost: example.org\r\nUser-Agent: HTTPie/0.9.9\r\nAccept-Encoding: gzip, deflate, compress\r\nAccept: */*\r\nConnection: keep-alive\r\n") == "GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, compress\r\nConnection: keep-alive\r\nHost: example.org\r\nUser-Agent: HTTPie/0.9.9\r\n"

# Generated at 2022-06-23 19:26:08.168504
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.__doc__ == HeadersFormatter.__doc__
    assert formatter.__str__ == HeadersFormatter.__str__
    assert formatter.format_headers == HeadersFormatter.format_headers
    assert formatter.format_headers.__doc__ == HeadersFormatter.format_headers.__doc__
    assert formatter.enabled == formatter.format_options['headers']['sort']
    formatter.enabled = False
    assert formatter.enabled == False


# Generated at 2022-06-23 19:26:16.942752
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:26:17.957903
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()



# Generated at 2022-06-23 19:26:20.062628
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Make sure this is an instance of HeadersFormatter
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)


# Generated at 2022-06-23 19:26:23.027402
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    print(x)
    assert x.__class__.__name__ == "HeadersFormatter"
    assert x.__doc__ == "HeadersFormatter(format_options)"
    assert hasattr(x, "format_headers")
    assert callable(getattr(x, "format_headers", None))


# Generated at 2022-06-23 19:26:32.552837
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test non-empty headers
    hf = HeadersFormatter()
    input_headers = '''\
POST /post HTTP/1.1
User-Agent: HTTPie/0.9.9
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 23
Host: httpbin.org

'''

# Generated at 2022-06-23 19:26:35.258874
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter()
    assert isinstance(head, HeadersFormatter)


# Generated at 2022-06-23 19:26:44.243180
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = '''Date: Wed, 25 Apr 2018 10:46:49 GMT
Server: Apache/2.4.7 (Ubuntu)
Content-Length: 433
Content-Type: text/html; charset=UTF-8
X-Powered-By: PHP/5.5.9-1ubuntu4.20
'''
    exp = '''Date: Wed, 25 Apr 2018 10:46:49 GMT
Content-Length: 433
Content-Type: text/html; charset=UTF-8
X-Powered-By: PHP/5.5.9-1ubuntu4.20
Server: Apache/2.4.7 (Ubuntu)
'''
    assert HeadersFormatter().format_headers(s) == exp

# Generated at 2022-06-23 19:26:54.916558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = [
        'Host: example.com',
        'Accept-Encoding: gzip',
        'Accept: */*',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.8',
        'Accept-Encoding: deflate',
    ]
    headers = HeadersFormatter.format_headers('\r\n'.join(headers))
    assert headers.splitlines() == [
        'Host: example.com',
        'Accept: */*',
        'Accept-Encoding: deflate',
        'Accept-Encoding: gzip',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.8',
    ]

# Generated at 2022-06-23 19:27:02.059692
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\n'
                                             'Content-Type: text/plain\r\n'
                                             'Content-Length: 1234\r\n'
                                             'Content-Type: text/html; charset=utf-8\r\n'
                                             '\r\n') == 'GET / HTTP/1.1\r\n' \
                                                        'Content-Length: 1234\r\n' \
                                                        'Content-Type: text/plain\r\n' \
                                                        'Content-Type: text/html; charset=utf-8\r\n' \
                                                        '\r\n'

# Generated at 2022-06-23 19:27:05.120008
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_formatter = HeadersFormatter()
    # we expect new HeadersFormatter() to be enabled
    assert header_formatter.enabled

    

# Generated at 2022-06-23 19:27:13.845533
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    assert obj.format_headers('HTTP/1.1 200 OK\r\nCache-Control: no-cache, must-revalidate\r\nAccept: */*\r\nConnection: keep-alive\r\nAccept-Encoding: gzip, deflate, br\r\nHost: httpbin.org\r\n') == 'HTTP/1.1 200 OK\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, br\r\nCache-Control: no-cache, must-revalidate\r\nConnection: keep-alive\r\nHost: httpbin.org\r\n'



# Generated at 2022-06-23 19:27:16.283768
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert fmt.enabled == fmt.format_options['headers']['sort']


# Generated at 2022-06-23 19:27:22.859894
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('') == ''
    assert HeadersFormatter().format_headers(' ') == ' '
    assert HeadersFormatter().format_headers('') == ''
    assert HeadersFormatter().format_headers('a: 1') == 'a: 1'
    assert HeadersFormatter().format_headers('a: 1\r\nb: 2') == 'a: 1\r\nb: 2'
    assert HeadersFormatter().format_headers('a: 1\r\nb: 2\r\na: 3') == 'a: 1\r\na: 3\r\nb: 2'

# Generated at 2022-06-23 19:27:34.014116
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers("""HTTP/1.1 200 OK
Server: SimpleHTTP/0.6 Python/3.6.4
Date: Mon, 15 Oct 2018 02:02:30 GMT
Content-type: text/html; charset=UTF-8
Content-Length: 8
Last-Modified: Thu, 27 Sep 2018 20:28:45 GMT
""") == """HTTP/1.1 200 OK
Content-Length: 8
Content-type: text/html; charset=UTF-8
Date: Mon, 15 Oct 2018 02:02:30 GMT
Last-Modified: Thu, 27 Sep 2018 20:28:45 GMT
Server: SimpleHTTP/0.6 Python/3.6.4
"""



# Generated at 2022-06-23 19:27:43.110334
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.compat import str
    formatter = HeadersFormatter()
    #
    # Test the method with a simplified header
    #
    headers = '''
GET / HTTP/1.1
Host: localhost:5000
User-Agent: HTTPie/1.0.3
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
'''
    headers_sorted = '''
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:5000
User-Agent: HTTPie/1.0.3
'''
    #
    # Call the method to format the headers
    #
    headers_formatted = formatter.format_headers(headers)
    #
    # Print the results

# Generated at 2022-06-23 19:27:49.046285
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test 1:
    # set
    headers = '''\
HTTP/1.1 200 OK
Server: GitHub.com
Content-Type: application/json; charset=utf-8
x-xss-protection: 1; mode=block
'''
    ## execute
    output_headers = HeadersFormatter.format_headers(headers)
    ## expected result
    expected_headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Server: GitHub.com
x-xss-protection: 1; mode=block
'''
    # assert
    assert output_headers == expected_headers



# Generated at 2022-06-23 19:27:55.070195
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_instance = HeadersFormatter()
    assert headers_formatter_instance.format_headers('Date: Sat,\r\nContent-Type: application/json\r\nContent-Length: 8\r\n') == 'Date: Sat,\r\nContent-Length: 8\r\nContent-Type: application/json\r\n'



# Generated at 2022-06-23 19:28:04.377415
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''Cache-Control: max-age=0
DATE: Sun, 17 May 2020 19:09:21 GMT
ETag: "67f-1632fd8408b80"
EXPIRES: Sun, 17 May 2020 19:09:13 GMT
HOST: 127.0.0.1:5000
LAST-MODIFIED: Thu, 07 May 2020 21:26:31 GMT
SERVER: Werkzeug/1.0.0 Python/3.7.4

'''

# Generated at 2022-06-23 19:28:10.337026
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersformatter=HeadersFormatter()
    print(headersformatter.format_options['headers']['sort'])
    print(headersformatter.format_headers(b'HTTP/1.0 200 OK\r\nServer: Apache/2.4.29 (Ubuntu)\r\nDate: Mon, 19 Oct 2020 10:47:57 GMT\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: 345\r\nConnection: keep-alive\r\n\r\n'))

if __name__ == '__main__':
    test_HeadersFormatter()

# Generated at 2022-06-23 19:28:12.483498
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = raw_formatters.HeadersFormatter(format_options={
        'headers': {'sort': True}, 'colors': {}})
    assert f.enabled


# Generated at 2022-06-23 19:28:13.507664
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == True


# Generated at 2022-06-23 19:28:15.230413
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False
    assert formatter.format_options['headers']['sort'] == False


# Generated at 2022-06-23 19:28:25.235218
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Cache-Control: max-age=0
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/1.0.2
Host: mockingbird.creighton.edu
'''
    headers_sorted = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Cache-Control: max-age=0
Connection: keep-alive
Host: mockingbird.creighton.edu
User-Agent: HTTPie/1.0.2
'''
    assert HeadersFormatter.format_headers(headers) == headers_sorted

# Generated at 2022-06-23 19:28:30.231884
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    json = '''\
{
    "headers": {
        "accept": "application/json",
        "content-type": "application/json"
    },
    "json": {
        "accept": "application/json",
        "content-type": "application/json"
    }
}'''

    formatter = HeadersFormatter()
    headers = formatter.format_headers(json)

    lines = headers.splitlines()
    headers = lines[1:]

    assert len(headers) == 4
    assert headers[0] == 'Accept: application/json'
    assert headers[1] == 'Content-Type: application/json'
    assert headers[2] == 'Accept: application/json'
    assert headers[3] == 'Content-Type: application/json'



# Generated at 2022-06-23 19:28:36.411854
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html
Server:Apache
Connection:keep-alive
Date:Mon, 24 Nov 2014 15:14:58 GMT
Transfer-Encoding:chunked
Last-Modified:Sat, 14 Jan 2012 19:40:02 GMT
Accept-Ranges:bytes\
'''
    expected = '''\
HTTP/1.1 200 OK
Accept-Ranges:bytes
Connection:keep-alive
Content-Type: text/html
Date:Mon, 24 Nov 2014 15:14:58 GMT
Last-Modified:Sat, 14 Jan 2012 19:40:02 GMT
Server:Apache
Transfer-Encoding:chunked\
'''
    assert form

# Generated at 2022-06-23 19:28:43.031840
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    args = ('--headers', '--headers.sort=on')
    cli = httpie.Cli(['--formatter=headers'] + list(args))
    plugin = HeadersFormatter(parse_options_kwargs={}, **cli.format_options)
    assert plugin.enabled is True
    assert plugin.args == ()
    assert plugin.format_options == cli.format_options
    assert plugin.config == cli.formatter_config
    assert plugin.colors == cli.formatter_colors



# Generated at 2022-06-23 19:28:46.849115
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options == {'headers': {'sort': True}}
    assert hf.enabled == True


# Generated at 2022-06-23 19:28:55.941053
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter = HeadersFormatter()
    header_formatter.format_options = {'headers':
                                           {'sort': True}
                                       }
    actual = header_formatter.format_headers(
            """+------------------------+
            || Accept: text/html     |
            || X-My-Header: 1        |
            || Accept: application/json |
            || Accept: text/plain    |
            |+------------------------+"""
    )
    expected = """+------------------------+
    || Accept: application/json |
    || Accept: text/html        |
    || Accept: text/plain       |
    || X-My-Header: 1           |
    |+------------------------+"""
    assert actual == expected

# Generated at 2022-06-23 19:29:03.805503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
Connection: keep-alive
Date: Tue, 07 Jul 2020 13:41:58 GMT
Server: gunicorn/20.0.4
Content-Type: application/json
Content-Length: 2
'''
    expected = '''\
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Tue, 07 Jul 2020 13:41:58 GMT
Server: gunicorn/20.0.4
'''
    assert formatter.format_headers(headers) == expected
# /Unit test for method format_headers of class HeadersFormatter




# Generated at 2022-06-23 19:29:14.187021
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    args = {'headers': {'sort': True}}
    hformatter = HeadersFormatter(format_options=args)

# Generated at 2022-06-23 19:29:18.197549
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert not HeadersFormatter().enabled  # disabled by default

    assert HeadersFormatter(headers__sort=True).enabled

# Generated at 2022-06-23 19:29:23.146079
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__bases__ == (FormatterPlugin, )
    assert HeadersFormatter.__init__.__defaults__ == (None, None, None)
    assert len(HeadersFormatter.__init__.__code__.co_varnames) == 4

# Unit tests for format_headers in class HeadersFormatter