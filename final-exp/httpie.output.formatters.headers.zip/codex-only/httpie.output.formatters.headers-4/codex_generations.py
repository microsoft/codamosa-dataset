

# Generated at 2022-06-23 19:19:22.826743
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    print(x)

test_HeadersFormatter()


# Generated at 2022-06-23 19:19:25.482518
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert formatter.enabled is True


# Generated at 2022-06-23 19:19:27.570338
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled



# Generated at 2022-06-23 19:19:28.841434
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	instance = HeadersFormatter()
	assert isinstance(instance, HeadersFormatter)

# Generated at 2022-06-23 19:19:32.263342
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
X-Foo-Bar: baz
X-Foo: bar
"""
    assert formatter.format_headers(headers) == """HTTP/1.1 200 OK
X-Foo: bar
X-Foo-Bar: baz
"""

# Generated at 2022-06-23 19:19:43.444978
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(**{'headers': {'sort': True}})

# Generated at 2022-06-23 19:19:45.218804
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-23 19:19:51.290530
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import json
    v_json = json.dumps({'headers': {'sort': True}}, indent=2)
    try:
        formatter = HeadersFormatter(format_options=json.loads(v_json))
    except Exception:
        print("Exception: test_HeadersFormatter\n")
    assert formatter.enabled == True


# Generated at 2022-06-23 19:19:52.928343
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_obj = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert test_obj.enabled == True


# Generated at 2022-06-23 19:19:56.807794
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('b: 1\nx: 1\na: 1\nc: 1\nb: 2\n') == 'b: 1\nb: 2\na: 1\nc: 1\nx: 1\n'


# Generated at 2022-06-23 19:19:58.482653
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled is True


# Generated at 2022-06-23 19:20:11.047033
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:20:19.209476
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 13\r\n'
        'Content-Type: text/html\r\n'
        'Connection: Close\r\n'
    )
    expected = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 13\r\n'
        'Content-Type: text/html\r\n'
        'Connection: Close\r\n'
    )
    actual = formatter.format_headers(input)
    assert expected == actual

# Generated at 2022-06-23 19:20:21.009052
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-23 19:20:29.584748
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Sorts headers by name while retaining relative
    order of multiple headers with the same name."""
    headers = '''Content-Type: application/json
X-Custom-Header: abc
Accept: application/json
X-Custom-Header: def
Content-Type: application/json
'''
    expected = '''Content-Type: application/json
Content-Type: application/json
Accept: application/json
X-Custom-Header: abc
X-Custom-Header: def
'''
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-23 19:20:38.641770
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers="""
HTTP/1.1 200 OK
Location: http://localhost:8080/get
Content-Length: 26
Content-Type: text/plain; charset=utf-8
Content-Encoding: gzip
Vary: Accept-Encoding
Server: TornadoServer/4.4.2
Date: Sun, 12 Jun 2016 11:46:06 GMT
"""
    result = obj.format_headers(headers)
    # The original headers had the content-encoding last and the Content-Type
    # first. The content-encoding is sorted last now.

# Generated at 2022-06-23 19:20:41.255993
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert not HeadersFormatter().enabled
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled


# Generated at 2022-06-23 19:20:43.323900
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.format_options['headers']['sort'] == False


# Generated at 2022-06-23 19:20:45.557381
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter( args=None, format_options={'headers': {'sort':True}})


# Generated at 2022-06-23 19:20:46.557765
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:20:56.237410
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def assert_format(headers, expected_headers):
        assert HeadersFormatter().format_headers(headers) == \
            expected_headers

    assert_format(
        """GET / HTTP/1.1
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: python-requests/2.3.0 CPython/2.7.3 Linux/3.8.0-29-generic
Host: httpbin.org

""",
        """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Host: httpbin.org
User-Agent: python-requests/2.3.0 CPython/2.7.3 Linux/3.8.0-29-generic

"""
    )


# Register HeadersFormatter as plugin
http

# Generated at 2022-06-23 19:21:04.241205
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_str = """HTTP/1.1 200 OK
Server: nginx/1.8.0
Date: Sat, 15 Oct 2016 10:38:33 GMT
Content-Type: application/json
Content-Length: 16
Connection: keep-alive
Content-Encoding: gzip
X-Content-Type-Options: nosniff
x-xss-protection: 1; mode=block
"""

# Generated at 2022-06-23 19:21:05.742936
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False
    assert h.format_options['headers']['sort'] == False


# Generated at 2022-06-23 19:21:11.215093
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    value = ['B: b', 'A: a']

    assert formatter.format_headers('\r\n'.join(value)) == '\r\n'.join(sorted(value, key=lambda h: h.split(':')[0]))



# Generated at 2022-06-23 19:21:13.034150
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is True


# Generated at 2022-06-23 19:21:20.846018
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    a = HeadersFormatter(None)
    assert a.format_headers("""GET /test HTTP/1.1
Accept: text/html
Cookie: a=1; b=2
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7
""") == """GET /test HTTP/1.1
Accept: text/html
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7
Cookie: a=1; b=2
"""

# Generated at 2022-06-23 19:21:30.201725
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Arrange
    expected = {
        'headers': {
            'sort': True
            }
        }

    # Act
    hf = HeadersFormatter(**expected)

    # Assert
    assert isinstance(hf, FormatterPlugin)
    assert hf.enabled == expected['headers']['sort']

# Mocks for unit test format_headers
mock_headers_single_line = '''
HTTP/1.1 200 OK\r\n
Date: Sun, 03 Feb 2019 22:53:53 GMT\r\n
Content-Type: application/json\r\n
Content-Length: 28\r\n
Connection: keep-alive\r\n
\r\n'''


# Generated at 2022-06-23 19:21:38.815508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_before = "HTTP1/1 200 OK\r\nContent-type: text/html\r\nAccept:*/*\r\nExample-Header: 0\r\nExample-Header: 1\r\nExample-Header: 2\r\nExample-Header: 3\r\nExample-Header: 4\r\nExample-Header: 5\r\nExample-Header: 6\r\nExample-Header: 7\r\nExample-Header: 8\r\nExample-Header: 9\r\nE-Tag: *\r\nDate: Mon, 15 Jan 2018 21:47:45 GMT\r\nServer: WSGIServer/0.2 CPython/3.6.3\r\n"

# Generated at 2022-06-23 19:21:45.870215
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    actual = f.format_headers('a: b\nc: d\ne: f\n')
    assert actual == 'a: b\nc: d\ne: f\n'
    actual = f.format_headers('a: b\nc: d\ne: f\nc: g\n')
    assert actual == 'a: b\nc: d\nc: g\ne: f\n'

 

# Generated at 2022-06-23 19:21:55.494952
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Unit test for method format_headers of class HeadersFormatter"""
    from httpie.plugins.headersformatterplugin import HeadersFormatter

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 1234\r\nSet-Cookie: csrf=abc123; Max-Age=0'

    expected = 'HTTP/1.1 200 OK\r\nContent-Length: 1234\r\nContent-Type: text/html; charset=utf-8\r\nSet-Cookie: csrf=abc123; Max-Age=0'
    actual = HeadersFormatter().format_headers(headers)
    assert actual == expected


# Generated at 2022-06-23 19:21:59.007719
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.context import Environment
    from httpie.plugins import BuiltinPluginManager
    env=Environment()
    plugin_manager=BuiltinPluginManager(env)
    h=HeadersFormatter(env,plugin_manager)
    assert h


# Generated at 2022-06-23 19:22:00.156040
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__

# Generated at 2022-06-23 19:22:02.265515
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter(highlight=False, sort=False, stream=False,
                           colors=False, indent=False)
    assert obj.enabled == False


# Generated at 2022-06-23 19:22:12.471678
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:22:15.262696
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={
        'headers': {
            'sort': True,
        }
    }).enabled



# Generated at 2022-06-23 19:22:24.100492
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {
        'colors': {
            'headers': {
                'color': 'blue',
            },
        },
        'headers': {
            'sort': True,
        },
    }
    formatter = HeadersFormatter(format_options=format_options)


# Generated at 2022-06-23 19:22:31.540595
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_instance = HeadersFormatter()
    headers_to_format = '''
        ------- Headers --------
        Content-Type: text/html; charset=utf-8
        Content-Length: 120
        Hello: World

        '''
    headers_formatted = headers_formatter_instance.format_headers(headers_to_format)
    expected = '''
        ------- Headers --------
        Content-Length: 120
        Content-Type: text/html; charset=utf-8
        Hello: World
        '''
    assert headers_formatted == expected


# Generated at 2022-06-23 19:22:38.630044
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 2
Server: TestServer
Date: Thu, 30 Nov 2017 08:19:44 GMT
Header-One: One One One
Header-One: One Two One
Header-One: One Three One
Header-Two: Two One One
Header-Two: Two Two One
Header-Two: Two Three One
Header-Three: Three One One
Header-Three: Three Two One
Header-Three: Three Three One
Header-Three: Three Four One""")

# Generated at 2022-06-23 19:22:43.563286
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''GET /index.html HTTP/1.1
Host: thecodingmachine.com
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Referer: http://thecodingmachine.com/index.html
Connection: keep-alive
Upgrade-Insecure-Requests: 1
Cache-Control: max-age=0
'''


# Generated at 2022-06-23 19:22:48.504972
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """Unit test for HeadersFormatter"""
    assert HeadersFormatter.plugin_type == 'formatter'
    assert HeadersFormatter.name == 'headers'
    assert HeadersFormatter.description == 'Sorts headers by name'
    assert HeadersFormatter.format_options == {'headers': {'sort': True}}
    assert HeadersFormatter.enabled == True


# Generated at 2022-06-23 19:22:59.774225
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    string = 'HTTP/1.1 200 OK\r\n'
    string += 'Content-Type: text/html; charset=utf-8\r\n'
    string += 'Content-Length: 12\r\n'
    string += 'X-Foo: Bar\r\n'
    string += 'X-Bar: Foo\r\n'
    expect = 'HTTP/1.1 200 OK\r\n'
    expect += 'Content-Length: 12\r\n'
    expect += 'Content-Type: text/html; charset=utf-8\r\n'
    expect += 'X-Bar: Foo\r\n'
    expect += 'X-Foo: Bar\r\n'
    actual = HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers

# Generated at 2022-06-23 19:23:06.275992
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK\r
Connection: keep-alive\r
Content-Length: 13\r
Content-Type: application/json\r
Date: Wed, 30 May 2018 09:21:41 GMT\r
Server: nginx/1.10.3 (Ubuntu)\r
\r
'''.strip()
    expected = '''\
HTTP/1.1 200 OK\r
Content-Length: 13\r
Content-Type: application/json\r
Connection: keep-alive\r
Date: Wed, 30 May 2018 09:21:41 GMT\r
Server: nginx/1.10.3 (Ubuntu)\r
\r
'''.strip()
    assert hf.format_headers(headers) == expected



# Generated at 2022-06-23 19:23:13.994222
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})

# Generated at 2022-06-23 19:23:24.123057
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # input headers
    headers = '''HTTP/1.1 200 OK
Cache-Control: public, max-age=60, s-maxage=60
Content-Encoding: gzip
Content-Type: application/json; charset=utf-8
Date: Mon, 22 Jul 2019 07:21:27 GMT
ETag: W/"837aec0fbc5d71bc5bf5f5ca5a5ccd00"
Server: nginx/1.8.1
Vary: Accept-Encoding
X-Request-Id: e6bce29e-1c41-47b6-9b6d-7b3fa3b0d7aa
Content-Length: 74
Connection: keep-alive'''


# Generated at 2022-06-23 19:23:33.538654
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
Cache-Control: private
Content-Type: application/json
Transfer-Encoding: chunked
Vary: Origin,Accept-Encoding
Date: Wed, 29 Mar 2017 13:15:27 GMT
Connection: keep-alive
'''
    # The result of calling f with headers is not really important.
    # The important thing is that no exception should be raised.
    f.format_headers(headers)
    
    
    
    
    
    
from httpie.plugins import FormatterPlugin



# Generated at 2022-06-23 19:23:35.783686
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled



# Generated at 2022-06-23 19:23:40.996276
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "POST https://httpbin.org/post HTTP/1.1\r\n" \
              "Accept: */*\r\n" \
              "Accept-Encoding: gzip, deflate\r\n" \
              "Connection: close\r\n" \
              "Content-Length: 40\r\n" \
              "Content-Type: application/json\r\n" \
              "Host: httpbin.org\r\n" \
              "User-Agent: HTTPie/1.0.2\r\n" \
              "\r\n"
    expected_result = "POST https://httpbin.org/post HTTP/1.1\r\n" \
                      "Accept: */*\r\n" \
                      "Accept-Encoding: gzip, deflate\r\n"

# Generated at 2022-06-23 19:23:49.458727
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter_sort = HeadersFormatter()
    header_formatter_unsort = HeadersFormatter()
    header_formatter_sort.format_options['headers']['sort'] = True
    header_formatter_unsort.format_options['headers']['sort'] = False
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.0 (Ubuntu)
Date: Wed, 07 Jun 2017 16:00:59 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-o5PQDnF5W6yJm6kAQ6BTQ9XUYJ8"

'''

# Generated at 2022-06-23 19:23:59.750211
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hformatter = HeadersFormatter()
    headers = ('GET / HTTP/1.1\r\n'
                'Accept: */*\r\n'
                'Content-Type: application/json\r\n'
                'Accept-Encoding: gzip, deflate\r\n'
                'Connection: keep-alive\r\n'
                '\r\n')
    assert hformatter.format_headers(headers) == (
            'GET / HTTP/1.1\r\n'
            'Accept: */*\r\n'
            'Accept-Encoding: gzip, deflate\r\n'
            'Connection: keep-alive\r\n'
            'Content-Type: application/json\r\n'
            '\r\n')

# Generated at 2022-06-23 19:24:10.177730
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(format_options={"headers": {"sort": True}}).format_headers("""\
POST / HTTP/1.1
X-Request-Id: 8318efa4-d4a4-4ca5-ad3b-1d5b5cf5c9ed
X-Request-Id: req-b17d1026-2e86-4a15-b567-3883f9b9e542
""").splitlines() == ['POST / HTTP/1.1',
'X-Request-Id: 8318efa4-d4a4-4ca5-ad3b-1d5b5cf5c9ed',
'X-Request-Id: req-b17d1026-2e86-4a15-b567-3883f9b9e542']


# Generated at 2022-06-23 19:24:18.462801
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = '''\
GET /get HTTP/1.1
Host: 127.0.0.1:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.1.0
'''.splitlines()

    assert HeadersFormatter().format_headers('\r\n'.join(lines)) == '''\
GET /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: 127.0.0.1:5000
User-Agent: HTTPie/1.1.0
'''

# Generated at 2022-06-23 19:24:29.459464
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

    # Test sorting of headers by name
    headers = ('HTTP/1.1 200 OK\r\n'
               'Set-Cookie: sth=abc\r\n'
               'Content-Type: application/json\r\n'
               'Set-Cookie: bar=123; Path=/\r\n'
               'Set-Cookie: foo=123\r\n'
               'Set-Cookie: foo=456\r\n')


# Generated at 2022-06-23 19:24:29.932448
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:24:36.857626
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers("""\
HTTP/1.1 200 OK
Connection: close
Content-Length: 535
Content-Type: application/json
Date: Mon, 16 Nov 2020 07:01:03 GMT
Server: waitress
Via: 1.1 vegur
X-Powered-By: Flask

""")
    expected = """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 535
Content-Type: application/json
Date: Mon, 16 Nov 2020 07:01:03 GMT
Server: waitress
Via: 1.1 vegur
X-Powered-By: Flask

""".strip()
    assert result == expected


# Generated at 2022-06-23 19:24:47.058355
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter().format_headers(
    """
    Date: Sat, 21 Oct 2017 17:28:10 GMT
    Location: http://httpbin.org/get
    Connection: keep-alive
    Server: gunicorn/19.7.1
    Access-Control-Allow-Origin: *
    Access-Control-Allow-Credentials: true
    Content-Type: application/json
    Content-Length: 319
    Via: 1.1 vegur
    Cache-Control: no-cache
    Strict-Transport-Security: max-age=31536000
    X-XSS-Protection: 1; mode=block
    X-Frame-Options: deny"""
)

# Generated at 2022-06-23 19:24:53.351696
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert headersFormatter.enabled == True
    headersFormatter_ = HeadersFormatter(format_options = {'headers': {'sort': False}})
    assert headersFormatter_.enabled == False

# Generated at 2022-06-23 19:25:02.320878
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = (
        'GET / HTTP/1.1\r\n'
        'Host: example.com\r\n'
        'Connection: keep-alive\r\n'
        'Accept: application/json\r\n'
        'Content-Type: application/json\r\n'
    )
    assert formatter.format_headers(headers) == (
        'GET / HTTP/1.1\r\n'
        'Accept: application/json\r\n'
        'Connection: keep-alive\r\n'
        'Content-Type: application/json\r\n'
        'Host: example.com\r\n'
    )

# Generated at 2022-06-23 19:25:13.577365
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

# Generated at 2022-06-23 19:25:20.087359
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={
        'headers': {'sort': True},
        'debug': {'sort': False},
    }).enabled == True

    assert HeadersFormatter(format_options={
        'headers': {'sort': False},
        'debug': {'sort': True},
    }).enabled == False


# Generated at 2022-06-23 19:25:28.639682
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:25:34.091509
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins.builtin import HeadersFormatter
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:25:36.176498
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with patch('httpie.plugins.formatter.headers.KeyValue') as MockClass:
        formatter = HeadersFormatter()
        assert formatter.enabled
        MockClass.assert_called_with([('abc', '123')])



# Generated at 2022-06-23 19:25:37.291468
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True 


# Generated at 2022-06-23 19:25:47.512098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case #1
    headers = """GET / HTTP/1.1
Host: 127.0.0.1:5000
Content-Length: 12
content-type: application/json
Date: Tue, 04 Apr 2017 20:08:22 GMT

"""
    expected = """GET / HTTP/1.1
content-type: application/json
Content-Length: 12
Date: Tue, 04 Apr 2017 20:08:22 GMT
Host: 127.0.0.1:5000

"""
    result = HeadersFormatter().format_headers(headers)
    assert(result == expected)

    # Test case #2

# Generated at 2022-06-23 19:25:48.869021
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter('test_Headers') == 'test_Headers'


# Generated at 2022-06-23 19:25:54.607305
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Ordinary test.
    """
    headers = '''\
Server: example.com
Location: http://example.com/'''
    result = '''\
Server: example.com
Location: http://example.com/'''
    assert HeadersFormatter.format_headers(headers) == result
    return



# Generated at 2022-06-23 19:25:57.115547
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(**{"headers": {"sort": False}})
    assert(not hf.enabled)



# Generated at 2022-06-23 19:25:59.897045
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(None).enabled == False
    assert HeadersFormatter(None, config={'headers': {'sort': True}}).enabled == True

# Generated at 2022-06-23 19:26:09.068765
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    _assert(HeadersFormatter(None, None).format_headers('\r\n'.join(['GET / HTTP/1.1', 'Host: example.org', 'x-test: value', 'X-Test: value', 'Accept: */*', 'Cache-Control: no-cache', 'X-Forwarded-Host: example.org'])), '\r\n'.join(['GET / HTTP/1.1', 'X-Forwarded-Host: example.org', 'x-test: value', 'X-Test: value', 'Accept: */*', 'Cache-Control: no-cache', 'Host: example.org']))


# Generated at 2022-06-23 19:26:11.221438
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        HeadersFormatter()
        assert True
    except:
        assert False


# Generated at 2022-06-23 19:26:21.881389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Connection: close\r\n'
        'Transfer-Encoding: chunked\r\n'
        'Link: </themes/10/theme>; rel="theme"\r\n'
    )
    assert formatter.format_headers(headers) == (
        'HTTP/1.1 200 OK\r\n'
        'Connection: close\r\n'
        'Content-Type: application/json\r\n'
        'Link: </themes/10/theme>; rel="theme"\r\n'
        'Transfer-Encoding: chunked\r\n'
    )


# Generated at 2022-06-23 19:26:29.392821
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = headers_formatter.format_headers('Content-Type: application/json\r\n'
                                               'Authorization: TOKEN\r\n'
                                               'X-Api-Version: 2')
    assert headers == 'Content-Type: application/json\r\nX-Api-Version: 2\r\nAuthorization: TOKEN'

# Generated at 2022-06-23 19:26:35.874015
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers="""Content-Length: 119
Connection: Keep-Alive
Content-Type: application/json; charset=utf-8
Date: Fri, 13 Dec 2019 19:42:42 GMT
Server: gunicorn/19.9.0
"""
    hf = HeadersFormatter(format_options={"headers":{"sort": True}})
    assert hf.format_headers(headers) == """Content-Length: 119
Content-Type: application/json; charset=utf-8
Connection: Keep-Alive
Date: Fri, 13 Dec 2019 19:42:42 GMT
Server: gunicorn/19.9.0
"""
    hf = HeadersFormatter(format_options={"headers":{"sort": False}})

# Generated at 2022-06-23 19:26:37.972747
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    request = {'headers': {'sort': True}}
    formatter = HeadersFormatter(format_options=request)
    assert formatter.enabled == True


# Generated at 2022-06-23 19:26:47.249547
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 48
Content-Type: text/html; charset=utf-8
Date: Thu, 03 Oct 2019 04:04:50 GMT

<html>
<head></head>
<body></body>
</html>
"""
    expected_headers = """\
HTTP/1.1 200 OK
Content-Length: 48
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Date: Thu, 03 Oct 2019 04:04:50 GMT

<html>
<head></head>
<body></body>
</html>
"""
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers) == expected_headers


# Generated at 2022-06-23 19:26:50.478531
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Unittest for method format_headers of class HeadersFormatter"""
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Length: 27
Content-Type: application/json
Date: Sun, 04 Jun 2017 16:50:29 GMT
Accept-Ranges: bytes
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Accept-Ranges: bytes
Content-Length: 27
Content-Type: application/json
Date: Sun, 04 Jun 2017 16:50:29 GMT
"""


# Generated at 2022-06-23 19:26:53.659440
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': True}}
    assert headers_formatter.enabled == True

# Generated at 2022-06-23 19:27:01.890799
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    hf = HeadersFormatter()
    hf.format_options['headers']['sort'] = True
    input_headers = """\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/0.9.2
"""
    expected = """\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.2
"""
    # When
    output = hf.format_headers(input_headers)
    # Then
    assert output == expected



# Generated at 2022-06-23 19:27:12.634697
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    TestsHeadersFormatter::format_headers

    Method format_headers must return a string containing the headers
    of the response sorted by headers name while retaining relative
    order of multiple headers with the same name.

    """
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:27:14.483291
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert(hf.enabled)

# Generated at 2022-06-23 19:27:17.124548
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:27:20.779865
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test default constructor
    headers_formatter = HeadersFormatter()

    # Test class member variables are correctly set
    assert headers_formatter.format_options == {'headers': {'custom': {},
                                                            'sort': False}}
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:27:24.486603
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Case 1: check with enabled == True
    f1 = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert f1.enabled == True
    # Case 2: check with enabled == False
    f2 = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert f2.enabled == False


# Generated at 2022-06-23 19:27:32.646316
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  headers='''Content-Type: application/json
User-Agent: HTTPie/1.0.2
Accept: application/json, */*
Connection: keep-alive
Host: httpbin.org
Content-Length: 16

'''
  assert HeadersFormatter.format_headers(headers) == '''Content-Type: application/json
Accept: application/json, */*
Connection: keep-alive
Content-Length: 16
Host: httpbin.org
User-Agent: HTTPie/1.0.2

'''

# Generated at 2022-06-23 19:27:35.801345
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={"headers":{"sort":True}}, context=None)

    assert hf.format_options['headers']['sort'] == True 


# Generated at 2022-06-23 19:27:43.299245
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

    headers = '''get / HTTP/1.1\r
Content-Length: 6\r
User-Agent: httpie/0.9.2-dev\r
Content-Type: application/x-www-form-urlencoded\r'''
    expected = '''get / HTTP/1.1\r
Content-Type: application/x-www-form-urlencoded\r
Content-Length: 6\r
User-Agent: httpie/0.9.2-dev\r'''
    assert headers_formatter.format_headers(headers) == expected


# Generated at 2022-06-23 19:27:50.056734
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case 1
    headers_original = """\
POST / HTTP/1.1
Content-Type: application/json; charset=UTF-8
Accept-Encoding: gzip, deflate
Accept: application/json
Connection: keep-alive
User-Agent: HTTPie/2.2.0
Content-Length: 165
Host: httpbin.org

"""
    headers_sorted = """\
POST / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 165
Content-Type: application/json; charset=UTF-8
Host: httpbin.org
User-Agent: HTTPie/2.2.0

"""
    assert HeadersFormatter.format_headers(headers_original) == headers_sorted
    # Case 2

# Generated at 2022-06-23 19:27:52.092241
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-23 19:28:02.643399
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter
    """
    hf = HeadersFormatter()

    # 1. test data:
    test_data = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 256
Content-Type: application/json
Vary: Origin
Date: Mon, 22 May 2017 13:47:39 GMT
Server: nginx
'''
    actual = hf.format_headers(test_data)
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 256
Content-Type: application/json
Connection: keep-alive
Date: Mon, 22 May 2017 13:47:39 GMT
Server: nginx
Vary: Origin
'''

    # 2. assert results:
    assert actual == expected



# Generated at 2022-06-23 19:28:12.446280
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:28:18.582529
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    original = '''Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: POST, OPTIONS
Access-Control-Allow-Origin: https://httpbin.org
Access-Control-Max-Age: 3600
Connection: keep-alive
Content-Length: 194
Content-Type: application/json
Date: Thu, 13 Sep 2018 16:01:50 GMT
Referrer-Policy: no-referrer-when-downgrade
Server: nginx
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block'''

# Generated at 2022-06-23 19:28:28.973904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # execute
    got = HeadersFormatter().format_headers("""\
HTTP/1.1 200 OK
Date: Tue, 24 Nov 2015 05:57:14 GMT
Server: Apache
Last-Modified: Mon, 23 Nov 2015 19:27:54 GMT
ETag: "f6-524f07cc58560"
Accept-Ranges: bytes
Content-Length: 2470
Cache-Control: max-age=14400, must-revalidate
Expires: Tue, 24 Nov 2015 09:57:14 GMT
Connection: close
Content-Type: text/html; charset=UTF-8
""")

    # verify

# Generated at 2022-06-23 19:28:31.801820
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert isinstance(headers, FormatterPlugin)
    assert headers.enabled == headers.format_options['headers']['sort']


# Generated at 2022-06-23 19:28:42.916494
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Test with headers that only differ in their case

# Generated at 2022-06-23 19:28:47.029174
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={"headers": {"sort": True}}, 
                                 color_options={})
    assert formatter.__class__ == HeadersFormatter

# Generated at 2022-06-23 19:28:55.394868
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """GET /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en
Connection: keep-alive
DNT: 1
Host: httpbin.org
User-Agent: HTTPie/0.9.9"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == """GET /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en
Connection: keep-alive
DNT: 1
Host: httpbin.org
User-Agent: HTTPie/0.9.9"""

# Generated at 2022-06-23 19:28:56.641659
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-23 19:28:58.577414
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert isinstance(obj, FormatterPlugin)
    assert obj.enabled == obj.format_options['headers']['sort']

# Generated at 2022-06-23 19:29:05.141095
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    
    # Given: A request that requests to sort headers
    request = Request(method='GET', url='http://httpbin.org/headers',
                      headers = {'Foo': 'bar'}, headers_sort = True)
    
    # When: HeadersFormatter class is instantiated with the given request
    headers_formatter = HeadersFormatter(request)
    
    # Then: HeadersFormatter object is created correctly
    assert type(headers_formatter) == HeadersFormatter
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:29:14.918945
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter(format_options=None)

# Generated at 2022-06-23 19:29:25.603433
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    headers = '\r\n'.join([
            'HTTP/1.1 200 OK',
            'Content-Type: application/json',
            'Connection: keep-alive',
            'Transfer-Encoding: chunked',
            'Vary: Origin, Accept-Encoding',
            'Date: Wed, 27 Jun 2018 08:51:14 GMT',
            'X-Powered-By: Express',
            'Etag: W/"2d-ARd1mz+8KtWp99vynq5A5pY"'
            ])
    result = headersFormatter.format_headers(headers)