

# Generated at 2022-06-23 19:19:22.869730
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:19:28.888481
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'header-b: v1',
        'header-a: v3',
        'header-a: v2',
    ])) == '\r\n'.join([
        'GET / HTTP/1.1',
        'header-a: v3',
        'header-a: v2',
        'header-b: v1',
    ])

# Generated at 2022-06-23 19:19:35.670180
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test data
    headers = '''\
HTTP/1.1 200 OK
Server: gunicorn/19.7.1
Date: Thu, 27 Jul 2017 01:59:19 GMT
Connection: keep-alive
Transfer-Encoding: chunked
Content-Type: application/json
Access-Control-Allow-Headers: Content-Type,Authorization
Access-Control-Allow-Methods: GET,PUT,POST,DELETE,OPTIONS
Access-Control-Allow-Origin: *\
'''

# Generated at 2022-06-23 19:19:40.899323
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter=HeadersFormatter
    assert formatter
    
# def test_format_headers():
#     headers="""
#     >>> import httpie
#     >>> from httpie.plugins import FormatterPlugin
#     """
#     formatter=HeadersFormatter
#     assert formatter.format_headers==headers

# Generated at 2022-06-23 19:19:41.539239
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert True

# Generated at 2022-06-23 19:19:43.186965
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers':{'sort': True}})


# Generated at 2022-06-23 19:19:51.207257
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'X-Foo: a',
        'X-Foo: b',
        'X-Bar: c',
        'X-Bar: d',
        'Transfer-Encoding: chunked',
        '',
        '{',
    ])
    assert headers == formatter.format_headers(headers)


# Generated at 2022-06-23 19:20:00.566874
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    def _test(headers, exp):
        act = HeadersFormatter().format_headers(headers)
        assert act == exp

    # First header case-insensitively

# Generated at 2022-06-23 19:20:02.342600
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options={'headers':{'sort':True}})
    headers.enabled = headers.format_options['headers']['sort']
    assert headers.format_options['headers']['sort'] == True
    assert headers.enabled == True


# Generated at 2022-06-23 19:20:05.154438
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert issubclass(HeadersFormatter, FormatterPlugin)
    assert super(HeadersFormatter, HeadersFormatter).__init__


# Generated at 2022-06-23 19:20:07.683234
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
Content-Length: 103
Content-Type: application/json
Content-Length: 104
    '''
    expected_headers_format = '''
Content-Length: 103
Content-Length: 104
Content-Type: application/json
    '''
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers) == expected_headers_format



# Generated at 2022-06-23 19:20:18.124746
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test constructor
    header = HeadersFormatter()

    # test format_headers
    headers_str = 'Connection: keep-alive\r\n'\
        'Server: nginx/1.10.1\r\n'\
        'Content-Length: 13\r\n'\
        'Content-Type: text/html; charset=UTF-8\r\n'\
        'Date: Mon, 30 Apr 2018 11:48:45 GMT\r\n'\
        'X-Powered-By: PHP/7.2.2\r\n'\
        '\r\n'\
        'Hello world!\r\n'

# Generated at 2022-06-23 19:20:30.818246
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """Content-Type: application/json; charset=utf-8
Authorization: Bearer f33a9a9f-396f-4d1a-82e0-b860da2b4a31
Content-Type: application/json; charset=utf-8
Content-Length: 46
User-Agent: HTTPie/0.9.8
Accept-Encoding: gzip, deflate
Accept: */*
Host: petstore.swagger.io
"""

# Generated at 2022-06-23 19:20:39.238242
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-23 19:20:50.671429
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = '''\
text
'''
    assert lines == HeadersFormatter().format_headers(lines)

    lines = '''\
Content-Type: application/json
text
'''
    assert lines == HeadersFormatter().format_headers(lines)

    lines = '''\
Content-Type: application/json
Content-Length: 25
text
'''
    assert lines == HeadersFormatter().format_headers(lines)

    lines = '''\
Content-Length: 25
Content-Type: application/json
text
'''
    assert lines == HeadersFormatter().format_headers(lines)

    lines = '''\
X-Header: abc
Content-Length: 25
Content-Type: application/json
X-Header: 123

text
'''
    assert lines == HeadersFormatter().format_

# Generated at 2022-06-23 19:20:52.634587
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  t = HeadersFormatter()
  assert t.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:20:55.240614
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception) as exception_info:
        assert HeadersFormatter(**kwargs)

# Generated at 2022-06-23 19:20:56.590397
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is True


# Generated at 2022-06-23 19:21:03.780755
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers.enabled is True
    assert headers.format_headers('\r\n'.join(['Content-Type: text/plain', 'Accept-Charset: utf-8'])) == '\r\n'.join(['Content-Type: text/plain', 'Accept-Charset: utf-8'])
    assert headers.format_headers('\r\n'.join(['Accept-Charset: utf-8', 'Content-Type: text/plain'])) == '\r\n'.join(['Content-Type: text/plain', 'Accept-Charset: utf-8'])

# Generated at 2022-06-23 19:21:05.335824
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    u = HeadersFormatter(format_options={"headers": {"sort": True}})



# Generated at 2022-06-23 19:21:06.349838
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()

# Generated at 2022-06-23 19:21:15.479790
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_str = '''Accept: application/json
X-Custom-1: 1
Content-Type: application/json
X-Custom-2: 2
X-Custom-3: 3
X-Custom-4: 4
    '''

    correct_output = '''Accept: application/json
Content-Type: application/json
X-Custom-1: 1
X-Custom-2: 2
X-Custom-3: 3
X-Custom-4: 4
    '''

    x = HeadersFormatter()
    output_str = x.format_headers(input_str)

    assert output_str == correct_output

# Generated at 2022-06-23 19:21:16.448057
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    c = HeadersFormatter()

# Generated at 2022-06-23 19:21:23.676027
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:21:34.654118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    kwargs = {
        'headers': 'fOo:bAr\r\nAbC:123\r\nAbC:456'
    }
    env = TestEnvironment(stdin_isatty=True, stdout_isatty=False)
    r = http('--print=BhH', 'GET', HTTP_OK, **kwargs)
    # 'AbC: 123\n',
    expected_result = ['AbC: 456\r\n', 'AbC: 123\r\n', 'fOo: Bar\r\n']
    assert r.stdout.splitlines() == expected_result
    assert not r.stderr
    assert r.exit_status == ExitStatus.OK


# if __name__

# Generated at 2022-06-23 19:21:47.047417
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers('HTTP/1.1 404 NOT FOUND\r\nContent-type:text/html; charset=UTF-8\r\nContent-Length: 9\r\nConnection: close\r\n\r\nTest test') == 'HTTP/1.1 404 NOT FOUND\r\nConnection: close\r\nContent-Length: 9\r\nContent-type:text/html; charset=UTF-8\r\n\r\nTest test'

# Generated at 2022-06-23 19:21:51.337201
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == 's'

# Unit test to check if method format_headers successfully sorts headers

# Generated at 2022-06-23 19:21:53.539244
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    r_headersFormatter = HeadersFormatter()
    assert isinstance(r_headersFormatter, FormatterPlugin)


# Generated at 2022-06-23 19:21:57.347676
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    opts = {
        'headers': {
            'sort': True
        }
    }
    plugin = HeadersFormatter(format_options=opts)
    assert plugin.enabled == True


# Generated at 2022-06-23 19:22:05.604423
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('GET / HTTP/1.0\r\n'
                             'Cookie: bar\r\n'
                             'Foo: baz\r\n'
                             'one: two\r\n'
                             'a: b\r\n'
                             'B: A\r\n'
                             'one: one\r\n') \
        == 'GET / HTTP/1.0\r\n' \
           'a: b\r\n' \
           'B: A\r\n' \
           'Cookie: bar\r\n' \
           'Foo: baz\r\n' \
           'one: two\r\n' \
           'one: one\r\n'



# Generated at 2022-06-23 19:22:13.548829
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter().format_headers(
        "GET / HTTP/1.1\r\n"
        "Host: localhost:5000\r\n"
        "Content-Length: 0\r\n"
        "Accept-Encoding: gzip, deflate\r\n"
        "Accept: */*\r\n"
        "User-Agent: HTTPie/0.9.9\r\n"
        "Connection: keep-alive\r\n"
        "\r\n"
    )

# Generated at 2022-06-23 19:22:23.430512
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
Date: Sat, 06 Apr 2013 23:06:29 GMT
Server: Apache
Last-Modified: Tue, 12 Mar 2013 16:45:57 GMT
ETag: "7fff8c-152-4d667b161d980"
Accept-Ranges: bytes
Content-Length: 338
Connection: close
Content-Type: text/html

"""
    sorted_headers = """
HTTP/1.1 200 OK
Accept-Ranges: bytes
Connection: close
Content-Length: 338
Content-Type: text/html
Date: Sat, 06 Apr 2013 23:06:29 GMT
ETag: "7fff8c-152-4d667b161d980"
Last-Modified: Tue, 12 Mar 2013 16:45:57 GMT
Server: Apache

"""
    assert sorted_headers

# Generated at 2022-06-23 19:22:33.205347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-23 19:22:37.547141
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        'headers': {'sort': True}
    })
    # Test headers formatter
    headers = '''\
HTTP/1.1 200 OK
Subject: Some Subject
Server: Apache
Content-Length: 5
'''
    
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 5
Server: Apache
Subject: Some Subject
'''

# Generated at 2022-06-23 19:22:40.303923
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)



# Generated at 2022-06-23 19:22:47.296263
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK\r
foo: bar baz\r
baz: foo bar\r
foo: bar baz\r
\r

'''
    assert headers_formatter.format_headers(headers) == '''HTTP/1.1 200 OK\r
baz: foo bar\r
foo: bar baz\r
foo: bar baz\r
\r

'''

# Generated at 2022-06-23 19:22:49.152912
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter != None


# Generated at 2022-06-23 19:22:51.122511
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled is True
    assert f.format_options['headers']['sort'] is True

# Generated at 2022-06-23 19:22:54.242078
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header = HeadersFormatter()
    assert header.enabled == header.format_options['headers']['sort']
    return header


# Generated at 2022-06-23 19:23:03.420643
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-23 19:23:08.407395
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter
    actual = formatter.format_headers("""\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
Connection: close

Hello World! My payload includes a trailing CRLF.
""")

# Generated at 2022-06-23 19:23:10.520686
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == True

# Generated at 2022-06-23 19:23:17.238807
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter("headers.sort")
    result = formatter.format_headers("Host: localhost\nAccept-Encoding: gzip, deflate, br\nAccept: */*\nConnection: keep-alive\nContent-Type: application/json")
    expected = "Host: localhost\nAccept: */*\nAccept-Encoding: gzip, deflate, br\nConnection: keep-alive\nContent-Type: application/json"
    assert result == expected


# Generated at 2022-06-23 19:23:19.001857
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']

# Generated at 2022-06-23 19:23:29.278741
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h_formatter = HeadersFormatter()
    file_name = 'test_HeadersFormatter_format_headers.txt'
    input_file = open(os.path.join(os.path.dirname(__file__), file_name), 'rb')
    input_headers = input_file.read()
    input_file.close()
    output_headers = h_formatter.format_headers(input_headers.decode('utf-8'))
    output_file = open(os.path.join(os.path.dirname(__file__), file_name), 'wb')
    output_file.write(output_headers.encode('utf-8'))
    output_file.close()

# Generated at 2022-06-23 19:23:39.193258
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Date: Sat, 08 Aug 2020 00:59:33 GMT
Server: Apache
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
Link: <https://httpbin.org/drip?duration=5&numbytes=5&code=200&delay=1>; rel="next"
Content-Length: 617
Connection: close
Content-Type: text/html; charset=UTF-8
"""


# Generated at 2022-06-23 19:23:43.110769
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == True
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:23:51.122105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    test_headers = '''Content-Encoding: gzip
Transfer-Encoding: chunked
Vary: Accept-Encoding
Server: Jetty(6.1.26)
'''
    result_headers = '''Content-Encoding: gzip
Server: Jetty(6.1.26)
Transfer-Encoding: chunked
Vary: Accept-Encoding
'''
    assert headers_formatter.format_headers(test_headers) == result_headers


# Generated at 2022-06-23 19:23:57.911458
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(
        """\
HTTP/1.1 200 OK
Content-Type: application/json
Server: TornadoServer/4.5.1
Date: Tue, 27 Oct 2017 05:37:46 GMT
Content-Length: 6
Cache-Control: no-cache

""") == """\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 6
Content-Type: application/json
Date: Tue, 27 Oct 2017 05:37:46 GMT
Server: TornadoServer/4.5.1

"""



# Generated at 2022-06-23 19:24:00.860122
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    http = HeadersFormatter()
    assert http.format_options['headers']['sort'] == False
    assert http.enabled == False



# Generated at 2022-06-23 19:24:04.330190
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # assert
    formatter = HeadersFormatter()
    assert formatter.format_headers(
        'header1: test1\nheader2: test2\nheader1: test3'
    ) == 'header1: test1\nheader1: test3\nheader2: test2'

# Generated at 2022-06-23 19:24:05.029183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers = HeadersFormatter()
    assert headers.forma

# Generated at 2022-06-23 19:24:13.126896
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:24:22.882449
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test default case when sort is set to True
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nEtag: \"cf93b1a12dafa5d2c5e17b5f5c17424b\"\r\n\r\n"
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nEtag: "cf93b1a12dafa5d2c5e17b5f5c17424b"\r\n'

# Generated at 2022-06-23 19:24:29.499149
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    rel_header = 'X-Frame-Options: ALLOW-FROM http://foo.com'
    abs_header = 'Location: http://foo.com'
    headers = '\r\n'.join(['HTTP/1.1 302 Found', rel_header, abs_header])
    assert HeadersFormatter(
        format_options={'headers': {'sort': True}}
    ).format_headers(headers) == '\r\n'.join(
        ['HTTP/1.1 302 Found', abs_header, rel_header]
    )

# Generated at 2022-06-23 19:24:38.052613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    from httpie.plugins.builtin import HeadersFormatter
    import filecmp

    headers = '''
HTTP/1.1 200 OK
Cache-Control: private
Server: Microsoft-IIS/7.5
X-AspNetMvc-Version: 5.2
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Thu, 01 Jun 2017 05:41:42 GMT
Content-Length: 538
Content-Type: text/html; charset=utf-8

'''


# Generated at 2022-06-23 19:24:39.957563
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_headers_formatter = HeadersFormatter()
    assert test_headers_formatter.enabled == True

# Unit tests for format_headers() function of class HeadersFormatter

# Generated at 2022-06-23 19:24:48.869022
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test the constructor of class HeadersFormatter
    # The first argument should be a dictionary, so it should be a set of brackets.
    # Test the format_headers function.
    headers = HeadersFormatter(
        format_options={'headers': {'sort': True}},
        config={},
        stdin=io.StringIO('\r\n'),
        stdout=io.StringIO('\r\n'),
        stderr=io.StringIO('\r\n'),
    )
    # Should get a string of the format:
    # <HTTP_version> <Response_code> <Information about response code>\r\n
    # <Header_Name>: <Header_Data>\r\n

# Generated at 2022-06-23 19:24:51.854303
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # __init__ method
    headers_formatter = HeadersFormatter()

    # Validate default values
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:25:01.423312
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test method format_headers of class HeadersFormatter
    """
    formatter = HeadersFormatter(
                                 format_options={
                                                 'headers': {
                                                             'sort': True
                                                             }
                                                 }
                                 )


# Generated at 2022-06-23 19:25:02.588012
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-23 19:25:09.172257
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter not in globals().values(), 'There is another HeadersFormatter class definition, check your code and delete this line'
    assert issubclass(HeadersFormatter, FormatterPlugin), 'HeadersFormatter must be derived from FormatterPlugin'
    assert HeadersFormatter.__init__.__code__.co_argcount == 2, 'HeadersFormatter constructor must accept 2 arguments'



# Generated at 2022-06-23 19:25:12.265051
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = create_headers_formatter()
    formatted_headers = formatter.format_headers(HEADERS_UNSORTED)
    assert formatted_headers == HEADERS_SORTED



# Generated at 2022-06-23 19:25:14.908692
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()

# Generated at 2022-06-23 19:25:25.751988
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fake_kwargs = {
        'format_options': {
            'headers': {
                'sort': True
                }
            }
        }
    test_obj = HeadersFormatter(**fake_kwargs)
    assert test_obj.enabled == True
    fake_kwargs['format_options']['headers']['sort'] = False
    test_obj = HeadersFormatter(**fake_kwargs)
    assert test_obj.enabled == False

example_headers_input_out = '''
GET / HTTP/1.1
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.0.0

'''


# Generated at 2022-06-23 19:25:27.888905
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    r = HeadersFormatter()
    assert r.enabled == False

# Generated at 2022-06-23 19:25:32.349156
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    config = Config(headers={'sort': True}, pretty=True)
    format_options = FormatOptions(config=config)
    formatter = HeadersFormatter(format_options=format_options)
    assert formatter.enabled
    assert formatter.format_options['headers']['sort']



# Generated at 2022-06-23 19:25:39.542262
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

    headers = """
            HTTP/1.1 200 OK
            Date: Thu, 07 Nov 2019 23:12:51 GMT
            Transfer-Encoding: chunked
            Connection: keep-alive
            Server: nginx/1.17.4
            Content-Type: application/json

            """
    headers = dedent(headers)

    result = hf.format_headers(headers)
    assert(result == """
            HTTP/1.1 200 OK
            Connection: keep-alive
            Content-Type: application/json
            Date: Thu, 07 Nov 2019 23:12:51 GMT
            Server: nginx/1.17.4
            Transfer-Encoding: chunked
            """)



# Generated at 2022-06-23 19:25:41.155783
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    current = HeadersFormatter()
    assert current.enabled == True


# Generated at 2022-06-23 19:25:44.673408
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Arrange
    args = { 'headers': {'sort': True} }

    # Act
    plugin = HeadersFormatter(format_options=args)

    # Assert
    assert plugin.enabled == True



# Generated at 2022-06-23 19:25:57.311595
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:26:00.611400
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort']
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:26:10.876878
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case:
    # Content-type: text/plain; charset=us-ascii
    # DATE: Tue, 19 Jun 2018 09:12:10 GMT
    # Connection: close
    # Transfer-encoding: chunked
    # Server: Apache
    #
    # url: http://httpbin.org/headers

    input_headers = "HTTP/1.1 200 OK\r\nContent-type: text/plain; charset=us-ascii\r\nDATE: Tue, 19 Jun 2018 09:12:10 GMT\r\nConnection: close\r\nTransfer-encoding: chunked\r\nServer: Apache\r\n\r\n"

# Generated at 2022-06-23 19:26:13.038900
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:26:21.619223
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter_obj = HeadersFormatter()
    strings_to_test = [
        '''Accept-Encoding: identity
Host: httpbin.org''',
        '''Accept-Encoding: identity
Host: httpbin.org
Connection: close''',
        '''Host: httpbin.org
Accept-Encoding: identity'''
    ]
    for string_to_test in strings_to_test:
        assert headers_formatter_obj.format_headers(string_to_test) == '''Host: httpbin.org
Accept-Encoding: identity'''
# ^ End unit test ^

formatter.register(HeadersFormatter)

# Generated at 2022-06-23 19:26:23.408439
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:26:32.879623
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter(format_options={'headers':{'sort':True}})

# Generated at 2022-06-23 19:26:38.657515
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    # Check that order of headers is preserved
    assert (
        headers_formatter.format_headers(
            "Header-2: value2\r\nHeader-1: value1\r\n"
        ) ==
        "Header-2: value2\r\nHeader-1: value1\r\n"
    )

# Generated at 2022-06-23 19:26:47.699224
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:26:58.344230
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Wed, 28 Feb 2018 06:39:15 GMT
Server: nginx
Content-Type: application/json
Content-Length: 5184
Last-Modified: Wed, 28 Feb 2018 06:34:05 GMT
Connection: keep-alive
ETag: "5a967cdd-1410"
Accept-Ranges: bytes

'''
    expected = '''\
HTTP/1.1 200 OK
Accept-Ranges: bytes
Connection: keep-alive
Content-Length: 5184
Content-Type: application/json
Date: Wed, 28 Feb 2018 06:39:15 GMT
ETag: "5a967cdd-1410"
Last-Modified: Wed, 28 Feb 2018 06:34:05 GMT
Server: nginx

'''
   

# Generated at 2022-06-23 19:27:00.521200
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:27:02.004769
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:27:06.442107
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_headers('Content-Type: application/json\r\nAccept: application/json\r\n') == 'Content-Type: application/json\r\nAccept: application/json\r\n'

# Generated at 2022-06-23 19:27:09.346152
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.name == 'headers'
    assert issubclass(HeadersFormatter, FormatterPlugin)
    assert HeadersFormatter.__init__.__doc__ == FormatterPlugin.__init__.__doc__



# Generated at 2022-06-23 19:27:11.873419
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hformatter = HeadersFormatter(sort=True)
    assert hformatter.headers() == '\r\n'



# Generated at 2022-06-23 19:27:12.537631
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:27:19.676875
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert (HeadersFormatter().format_headers("""\
Content-Type: text/html; charset=utf-8
Date: Tue, 13 Sep 2016 12:35:07 GMT
Accept-Ranges: bytes
Connection: close
Content-Length: 466
\
""") == """\
Content-Type: text/html; charset=utf-8
Accept-Ranges: bytes
Connection: close
Content-Length: 466
Date: Tue, 13 Sep 2016 12:35:07 GMT
\
""")

# Generated at 2022-06-23 19:27:26.709715
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    formatted_headers = formatter.format_headers('GET / HTTP/1.1\r\n'
                                                 'host: google.com\r\n'
                                                 'Foo: Bar\r\n'
                                                 'User-Agent: Test\r\n'
                                                 'Accept-Encoding: Test\r\n'
                                                 'Foo: Baz\r\n')


# Generated at 2022-06-23 19:27:37.373347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:27:44.262358
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    headers = '''POST /post HTTP/1.1
Content-Type: application/json
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 16
Host: httpbin.org
User-Agent: HTTPie/1.0.3

'''
    expected = '''POST /post HTTP/1.1
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 16
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/1.0.3

'''
    assert formatter.format_headers(headers) == expected

# Unit test

# Generated at 2022-06-23 19:27:55.911406
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class H:
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value
    headers = (
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Encoding: gzip, deflate',
        'Host: httpbin.org',
        'User-Agent: HTTPie/0.9.8'
    )
    expected_headers = '\r\n'.join(
        line for line in headers if 'User-Agent' not in line
    )

# Generated at 2022-06-23 19:27:59.016680
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	formatter = HeadersFormatter(
		format_options = {
			'headers': {'sort': True}
		}
	)

	# Should be true
	assert formatter.enabled == True


# Generated at 2022-06-23 19:28:01.404607
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    options = formatter.format_options
    assert(options['headers']['sort'] == False)


# Generated at 2022-06-23 19:28:11.998581
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
Content-Type: application/json
Date: Sun, 09 Sep 2018 16:24:35 GMT
Server: WSGIServer/0.2 CPython/3.6.5
Vary: Cookie
X-Frame-Options: SAMEORIGIN
cache-control: max-age=0, no-cache, no-store, must-revalidate
content-length: 70
expires: 0
x-content-type-options: nosniff
x-frame-options: SAMEORIGIN
x-xss-protection: 1; mode=block
'''

# https://docs.python.org/3/library/unittest.mock.html
with mock.patch('httpie.plugins.builtin.headers.HeadersFormatter.__init__') as mocked_init:
    mocked_init.return_

# Generated at 2022-06-23 19:28:18.131098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('Content-Type: text/html\r\nContent-Length: 42') == 'Content-Length: 42\r\nContent-Type: text/html'
    assert formatter.format_headers('Foo: 1\r\nFoo: 2') == 'Foo: 1\r\nFoo: 2'
    assert formatter.format_headers('One: 1\r\nTwo: 2') == 'One: 1\r\nTwo: 2'



# Generated at 2022-06-23 19:28:28.753528
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    result = hf.format_headers('HTTP/1.1 200 OK\r\nFoo: 1\r\nBar: 1\r\nBar: 2')
    assert result == 'HTTP/1.1 200 OK\r\nBar: 1\r\nBar: 2\r\nFoo: 1'
    result = hf.format_headers('HTTP/1.1 200 OK\r\nZ: 1\r\nA: 1\r\nA: 2')
    assert result == 'HTTP/1.1 200 OK\r\nA: 1\r\nA: 2\r\nZ: 1'

# Generated at 2022-06-23 19:28:30.812997
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}, config={})

# Generated at 2022-06-23 19:28:31.934441
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()

# Generated at 2022-06-23 19:28:34.084535
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': False}}).enabled == False

# Generated at 2022-06-23 19:28:37.491263
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(httpie=None), FormatterPlugin)
    assert isinstance(HeadersFormatter(httpie=None), object)



# Generated at 2022-06-23 19:28:46.385902
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Mon, 15 Jan 2018 09:16:48 GMT
Server: Apache
X-Powered-By: PHP/5.5.38
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
X-Pingback: http://www.w3schools.com/xml/xml_http.asp
Content-Length: 27821
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html"""

# Generated at 2022-06-23 19:28:56.482979
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:28:58.635140
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:29:00.083551
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled == False


# Generated at 2022-06-23 19:29:08.401932
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import os, pytest, sys
    # The following is a list of the options
    # that the constructor of class HeadersFormatter
    # accepts. This information is obtained
    # from the source code of class HeadersFormatter
    # and from the source code of its superclass.
    # The test uses the list of options to determine
    # the number of arguments required by the
    # constructor of class HeadersFormatter.
    signature = inspect.signature(HeadersFormatter.__init__)
    #
    # Superclass
    #
    # The test determines the number of arguments
    # required by the constructor of class HeadersFormatter
    # by analysing the signature of that constructor.
    # The signature of the constructor of
    # class HeadersFormatter is obtained
    # from the source code of class HeadersFormatter
    # and

# Generated at 2022-06-23 19:29:12.175836
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    header_list = ['Connection: close', 'Content-Length: 200']
    header_string = '\r\n'.join(header_list)
    assert headers_formatter.format_headers(header_string) == "Connection: close\nContent-Length: 200"

# Generated at 2022-06-23 19:29:14.731058
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is False
    assert headers_formatter.format_options['headers']['sort'] is True


# Generated at 2022-06-23 19:29:17.309028
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled is True

# Generated at 2022-06-23 19:29:23.695364
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter = HeadersFormatter()
    headers = """\
Content-Length: 49
Content-Type: application/json
X-Foo: Bar
X-Bar: Baz
"""

    expected = """\
Content-Length: 49
Content-Type: application/json
X-Bar: Baz
X-Foo: Bar
"""
    actual = header_formatter.format_headers(headers)
    assert actual == expected