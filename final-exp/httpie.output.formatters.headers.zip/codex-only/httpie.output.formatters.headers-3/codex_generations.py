

# Generated at 2022-06-23 19:19:31.427293
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
X-Header1: value1
X-Header2: value2
X-Header3: value3""") == """\
X-Header1: value1
X-Header2: value2
X-Header3: value3"""
    assert formatter.format_headers("""\
X-Header2: value2
X-Header1: value1
X-Header3: value3""") == """\
X-Header1: value1
X-Header2: value2
X-Header3: value3"""

# Generated at 2022-06-23 19:19:37.956319
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    input_text = """
    foo: foo
    bar: bar
    a: a
    a: b
    c: c
    """
    assert headers.format_headers(input_text) == """
    foo: foo
    bar: bar
    a: a
    a: b
    c: c
    """.lstrip()



# Generated at 2022-06-23 19:19:40.293564
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert isinstance(headers, HeadersFormatter)


# Generated at 2022-06-23 19:19:52.155814
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter(format_options={"headers": {"sort": True}})
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Host: example.org',
        'Connection: close',
        'Content-Length: 42',
        'Content-Type: application/json; charset=utf-8'
    ])
    headers = h.format_headers(headers)
    assert headers.splitlines() == [
        'HTTP/1.1 200 OK',
        'Connection: close',
        'Content-Length: 42',
        'Content-Type: application/json; charset=utf-8',
        'Host: example.org'
    ]

    # Does not sort headers if not enabled.
    h.enabled = False
    headers = h.format_headers(headers)

# Generated at 2022-06-23 19:19:57.305799
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Tests the constructor of the HeadersFormatter class.

    """
    headersFormatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headersFormatter.enabled == True
    headersFormatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert headersFormatter.enabled == False


# Generated at 2022-06-23 19:20:05.363101
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    # Case 1:
    # Given:
    headers = '''\
Host: localhost:8000
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: HTTPie/0.8.0

'''
    # When:
    headers_formatted = headers_formatter.format_headers(headers)
    # Then:
    assert headers_formatted == '''\
Host: localhost:8000
Accept: */*
Accept-Encoding: gzip, deflate, compress
User-Agent: HTTPie/0.8.0

'''
    # Case 2:
    # Given:

# Generated at 2022-06-23 19:20:10.877232
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers':{'sort': True}})
    _input = '''\
HTTP/1.1 200 OK
b: 2
a: 1
c: 3'''
    _output = '''\
HTTP/1.1 200 OK
a: 1
b: 2
c: 3'''
    assert hf.format_headers(_input) == _output


# Generated at 2022-06-23 19:20:20.903108
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    header = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=UTF-8
Access-Control-Allow-Origin: *
X-Fake-Header: First
Content-Length: 17
Date: Sat, 14 Nov 2020 14:56:40 GMT
X-Fake-Header: Second
Server: Something
'''
    assert(formatter.format_headers(header) == '''\
HTTP/1.1 200 OK
Access-Control-Allow-Origin: *
Content-Length: 17
Content-Type: application/json; charset=UTF-8
Date: Sat, 14 Nov 2020 14:56:40 GMT
Server: Something
X-Fake-Header: First
X-Fake-Header: Second
''')



# Generated at 2022-06-23 19:20:23.811695
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, HeadersFormatter)


# Generated at 2022-06-23 19:20:33.059095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    The method format_headers correctly sorts headers by name
    while retaining relative order of multiple headers with the
    same name.
    """
    headers = """\
HTTP/1.1 200 OK
Server: Caddy
Date: Sun, 30 Dec 2018 06:21:33 GMT
Content-Type: application/json
Set-Cookie: foo=bar; Max-Age=3600; Domain=localhost; Path=/
Set-Cookie: spam=eggs; Domain=localhost; Expires=Wed, 02-Jan-2019 06:21:33 GMT; Path=/
Link: <http://localhost:2015/dashboard/>; rel="dashboard"
Link: <http://localhost:2015/files/>; rel="files"; type="application/json"
Content-Length: 7
Accept-Ranges: bytes
"""
    assert HeadersFormatter.format_headers

# Generated at 2022-06-23 19:20:45.540915
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test with the following input
    # In the example below the headers Content-Type, Accept
    # and Authorization have the same name
    # but have different values
    lines = [
        'POST / HTTP/1.1',
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer abc'
    ]

    headers = '\r\n'.join(lines)
    output = HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers)

    # Expected output is the same headers in sorted order
    # with the same value

# Generated at 2022-06-23 19:20:55.119211
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    hf = h.format_headers("GET /header HTTP/1.1\r\nHeader-B: b\r\nHeader-A: a\r\n")
    assert hf == "GET /header HTTP/1.1\r\nHeader-A: a\r\nHeader-B: b\r\n"
    hf = h.format_headers("GET /header HTTP/1.1\r\nHeader-C: c\r\nHeader-B: b\r\nHeader-A: a\r\n")
    assert hf == "GET /header HTTP/1.1\r\nHeader-A: a\r\nHeader-B: b\r\nHeader-C: c\r\n"

# Generated at 2022-06-23 19:21:03.232146
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Server: nginx
X-Content-Type-Options: nosniff
Content-Type: application/json
Content-Length: 13
Connection: close
X-Cache: MISS
X-Request-Id: fbf3c044-425b-4f25-8ef3-3ab3e9b9f2e2
"""
    expected = """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 13
Content-Type: application/json
Server: nginx
X-Cache: MISS
X-Content-Type-Options: nosniff
X-Request-Id: fbf3c044-425b-4f25-8ef3-3ab3e9b9f2e2
"""

# Generated at 2022-06-23 19:21:08.704056
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = """\
POST / HTTP/1.1
Host: example.org
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
Content-Length: 3
Content-Type: application/json
Connection: keep-alive

"""
    lines = s.splitlines()
    headers = sorted(lines[1:], key=lambda h: h.split(':')[0])
    assert '\r\n'.join(lines[:1] + headers) == HeadersFormatter.format_headers(s)



# Generated at 2022-06-23 19:21:17.795088
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:21:25.864155
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print('Testing HeadersFormatter.format_headers()')
    input_headers = '''Accept: text/html
Accept-Encoding: gzip, deflate
Accept-Language: en-us
User-Agent: HTTPie/0.9.9

'''
    expected_output = '''Accept: text/html
Accept-Encoding: gzip, deflate
Accept-Language: en-us
User-Agent: HTTPie/0.9.9

'''
    formatter = HeadersFormatter()
    output = formatter.format_headers(input_headers)
    assert(output == expected_output)

# Generated at 2022-06-23 19:21:35.772875
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter_plugin.format_headers('HTTP/1.1 200 OK\r\ncontent-type: application/json\r\n') == 'HTTP/1.1 200 OK\r\ncontent-type: application/json\r\n'
    assert formatter_plugin.format_headers('HTTP/1.1 200 OK\r\ncontent-length: 2\r\ncontent-type: application/json\r\n') == 'HTTP/1.1 200 OK\r\ncontent-length: 2\r\ncontent-type: application/json\r\n'

# Generated at 2022-06-23 19:21:47.507913
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'Content-Length : 1\n' \
              'Content-Type : application/json\n' \
              'X-Hello : World\n' \
              'X-Foo : Bar\n' \
              'X-Foo : Baz\n' \
              'Content-Type : text/html\n' \
              'Content-Length : 2\n'
    expect_headers = 'Content-Length : 1\n' \
                     'Content-Length : 2\n' \
                     'Content-Type : application/json\n' \
                     'Content-Type : text/html\n' \
                     'X-Foo : Bar\n' \
                     'X-Foo : Baz\n' \
                     'X-Hello : World\n'
    assert expect_headers

# Generated at 2022-06-23 19:21:58.923405
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that HTTP headers are sorted according
    to their names while keeping the original order
    inside multiple headers with the same name.
    """
    headers = '''
Date: Fri, 23 Aug 2019 17:41:29 GMT
Server: Apache/2.4.39 (Unix) OpenSSL/1.0.2r
X-Powered-By: PHP/7.1.20
Content-Length: 0
Content-Type: text/html
X-Pingback: http://rest/xmlrpc.php
Link: <http://rest/>; rel=shortlink
Connection: close
'''

# Generated at 2022-06-23 19:22:06.613609
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
POST / HTTP/1.1
Host: localhost
Foo: a
Bar: b
Bar: c
Foo: d

""") == """\
POST / HTTP/1.1
Bar: b
Bar: c
Foo: a
Foo: d

"""


with Formatter(headers={'sort': True}) as f:
    pass

f('GET https://github.com/')
## output:
#  GET / HTTP/1.1
#  accept: */*
#  accept-encoding: gzip, deflate
#  connection: keep-alive
#  host: github.com
#  user-agent: HTTPie/0.9.8
#  
#  HTTP/1.1 200 OK


# Generated at 2022-06-23 19:22:17.723334
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:22:22.725284
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:22:32.880596
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head1 = 'HTTP/1.1 200 OK\r\nConnection: keep-alive\r\nContent-Type: application/json;charset=UTF-8\r\nDate: Thu, ' \
            '25 Jul 2019 20:45:04 GMT\r\nServer: nginx\r\nTransfer-Encoding: chunked\r\nVary: Accept-Encoding\r\n' \
            'X-Application-Context: application:prod\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: ' \
            'DENY\r\nX-XSS-Protection: 1; mode=block\r\n\r\n'

# Generated at 2022-06-23 19:22:38.228865
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort']
    assert formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Content-Length: 45',
        'Set-Cookie: session=abcde'
    ])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Length: 45',
        'Content-Type: application/json',
        'Set-Cookie: session=abcde'
    ])

# Generated at 2022-06-23 19:22:40.036645
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-23 19:22:42.365112
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is False


# Generated at 2022-06-23 19:22:43.344352
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:22:44.761336
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_formatter = HeadersFormatter()


# Generated at 2022-06-23 19:22:50.064792
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test for the HeadersFormatter.format_headers() method
    """
    input = """\r\nContent-Type: application/json\r\nContent-Length: 18\r\n"""
    output = """\r\nContent-Length: 18\r\nContent-Type: application/json\r\n"""
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.format_headers(input) == output

# Generated at 2022-06-23 19:23:01.107490
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}})
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Connection: close\r\n' \
              'Content-Length: 0\r\n' \
              'Content-Type: application/json\r\n' \
              'Date: Sun, 22 Apr 2018 20:38:06 GMT\r\n' \
              'Server: TwistedWeb/17.9.0\r\n' \
              'Vary: Accept-Language, Cookie\r\n' \
              'X-Frame-Options: SAMEORIGIN\r\n'

# Generated at 2022-06-23 19:23:05.957090
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Test constructor of class `HeadersFormatter`
    # with acceptable arguments.
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    # Test attribute `enabled`
    assert headers_formatter.enabled is True

    # Test method `format_headers()`
    assert headers_formatter.format_headers(headers="header1: value1\r\nheader2: value2\r\nheader1: value3") == "header1: value1\r\nheader1: value3\r\nheader2: value2"


# Generated at 2022-06-23 19:23:16.596600
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Sorts headers by name while retaining relative order of multiple headers with the same name.
    headers = '''\
Content-Length: 100
Content-Type: application/json
Transfer-Encoding: chunked
Cache-Control: no-cache
Content-Type: application/xml
Cache-Control: no-store
Transfer-Encoding: chunked
Content-Type: text/plain
Hello: World
'''
    hf = HeadersFormatter()
    corrected_headers = hf.format_headers(headers)
    assert corrected_headers == '''\
Content-Length: 100
Transfer-Encoding: chunked
Content-Type: application/json
Content-Type: application/xml
Content-Type: text/plain
Cache-Control: no-cache
Cache-Control: no-store
Hello: World
'''



# Generated at 2022-06-23 19:23:26.076570
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:23:27.022171
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__ != None

# Generated at 2022-06-23 19:23:31.368806
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test default constructor
    assert HeadersFormatter()
    # Test argument constructor
    assert HeadersFormatter('headers')
    assert HeadersFormatter('headers', {'sort': False})
    # Test that constructor returns what it should
    assert HeadersFormatter() != HeadersFormatter('headers', {'sort': False})


# Generated at 2022-06-23 19:23:40.791755
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    lines = ['GET / HTTP/1.1',
             'Accept: */*',
             'Accept-Encoding: gzip, deflate',
             'Connection: keep-alive',
             'Host: httpbin.org',
             'User-Agent: HTTPie/2.2.0']

    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\n'.join(lines)) == '\r\n'.join(lines)

    formatter = HeadersFormatter(headers__sort=True)
    assert formatter.format_headers('\r\n'.join(lines)) == '\r\n'.join(lines[:1] + sorted(lines[1:]))


# Since this is a plugin, it has to be registered to FormatterPlugin.

# Generated at 2022-06-23 19:23:42.110597
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled



# Generated at 2022-06-23 19:23:50.001435
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\
Content-Length: 48
Accept-Encoding: gzip, deflate
Accept: */*
Accept-Language: en
User-Agent: HTTPie/0.9.3
Connection: keep-alive
Content-Type: application/json
Host: jsonplaceholder.typicode.com
\r
'''

# Generated at 2022-06-23 19:23:58.537697
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('POST / HTTP/1.1\r\nB: 2\r\nA: 1\r\n') == \
           'POST / HTTP/1.1\r\nA: 1\r\nB: 2\r\n'
    assert formatter.format_headers('POST / HTTP/1.1\r\nA: 1\r\nA: 2\r\n') == \
           'POST / HTTP/1.1\r\nA: 1\r\nA: 2\r\n'

# Generated at 2022-06-23 19:24:09.319981
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers1 = '''
    Content-Type: application/json
    Date: Fri, 21 Aug 2020 03:33:28 GMT
    Etag: "3147526947"
    Content-Length: 133
    Server: GitHub.com
    Status: 200 OK
    X-RateLimit-Limit: 60
    X-RateLimit-Remaining: 57
    '''
    headers2 = '''
    X-RateLimit-Limit: 60
    Etag: "3147526947"
    Status: 200 OK
    Date: Fri, 21 Aug 2020 03:33:28 GMT
    X-RateLimit-Remaining: 57
    Server: GitHub.com
    Content-Type: application/json
    Content-Length: 133
    '''
    assert headers2 == HeadersFormatter().format_headers(headers1)

# Generated at 2022-06-23 19:24:14.063393
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert repr(obj) == '<HeadersFormatter>'
    assert obj.enabled is True
    assert obj.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:24:16.751378
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    msg = 'FAIL: constructor of HeadersFormatter failed'
    test_class = HeadersFormatter()
    assert isinstance(test_class, HeadersFormatter), msg


# Generated at 2022-06-23 19:24:26.670696
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    assert headers.format_headers('Content-Type: application/json\r\n'\
            'Accept: application/json\r\n'\
            'X-API-Key: abcdefgh1234\r\n') == 'Content-Type: application/json\r\n'\
        'Accept: application/json\r\n'\
        'X-API-Key: abcdefgh1234\r\n'


# Generated at 2022-06-23 19:24:30.229369
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False
    assert formatter.format_options['headers']['sort'] == False



# Generated at 2022-06-23 19:24:38.074186
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    input_headers = ('Cache-Control: no-cache\r\n'
                     'Content-Length: 0\r\n'
                     'Content-Type: text/html; charset=utf-8\r\n'
                     'Date: Fri, 08 Nov 2019 15:33:41 GMT\r\n'
                     'Expires: -1\r\n'
                     'Server: Kestrel\r\n')

# Generated at 2022-06-23 19:24:42.828778
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.name == 'headers'
    assert HeadersFormatter.format_options == {
        'headers': {
            'sort': True
        }
    }
    formatter = HeadersFormatter()
    assert formatter.enabled == True
    assert formatter.format_headers == HeadersFormatter.format_headers


# Generated at 2022-06-23 19:24:47.285145
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter=HeadersFormatter()
    assert formatter.format_headers('abc\r\nabc:def\r\nabc:def\r\nabc:def\r\nabc:def\r\n')=='abc\r\nabc:def\r\nabc:def\r\nabc:def\r\nabc:def\r\n'

# Generated at 2022-06-23 19:24:53.307750
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    headersFormatter = HeadersFormatter()
    headers = '''Date: Mon, 06 May 2019 18:29:38 GMT
Server: Apache/2.4.38 (Debian)
Last-Modified: Wed, 27 Mar 2019 20:27:41 GMT
ETag: "7d-58d05eb5901ca"
Accept-Ranges: bytes
Content-Length: 125
Connection: close
Content-Type: text/plain
'''

# Generated at 2022-06-23 19:24:55.959051
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-23 19:25:00.598143
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers(
        'Content-Type: text/html; charset=utf-8\r\n'
        'Content-Type: text/html\r\n'
        'Content-Length: 34\r\n'
        'Content-Length: 14\r\n'
        'Content-Length: 22\r\n'
        'Content-Type: text/html\r\n'
        'Content-Length: 110\r\n'
        'Content-Length: 148\r\n'
    )

# Generated at 2022-06-23 19:25:12.167086
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_former = HeadersFormatter()
    # assert(headers_former.enable)
    headers = """\
GET / HTTP/1.1
Accept: application/json, text/javascript
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0
Host: example.org
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
"""

# Generated at 2022-06-23 19:25:13.878293
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(headers={"sort": True}, request=None).enabled == True



# Generated at 2022-06-23 19:25:25.168091
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # arrange
    headers = (
        'HTTP/1.0 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'B: b\r\n'
        'A: a\r\n'
        'C: c\r\n'
        'A: a\r\n'
        '\r\n'
    )

    expected_headers = (
        'HTTP/1.0 200 OK\r\n'
        'A: a\r\n'
        'A: a\r\n'
        'B: b\r\n'
        'C: c\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
    )

    # act
    actual_headers = HeadersFormatter

# Generated at 2022-06-23 19:25:29.120896
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(headers_sort=True)
    assert h.enabled
    h = HeadersFormatter(headers_sort=False)
    assert not h.enabled



# Generated at 2022-06-23 19:25:38.271517
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('foo: 1\r\n'
                                    'bar: 2\r\n'
                                    'baz: 3\r\n') == 'foo: 1\r\n' \
                                                      'baz: 3\r\n' \
                                                      'bar: 2\r\n'
    assert formatter.format_headers('foo: 1\r\n'
                                    'foo: 2\r\n'
                                    'baz: 3\r\n') == 'foo: 1\r\n' \
                                                      'foo: 2\r\n' \
                                                      'baz: 3\r\n'

# Generated at 2022-06-23 19:25:48.150048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = [
        'Content-Type: text/html',
        'Content-Length: 1281',
        'Connection: keep-alive',
        'Server: gunicorn/19.7.1',
        'Date: Tue, 13 Nov 2018 21:59:07 GMT',
        'Content-Language: en',
        'Content-Location: http://httpbin.org/',
        'Vary: Cookie',
        'Set-Cookie: fake=cookie',
        'Accept-Ranges: bytes',
        'Referrer-Policy: strict-origin-when-cross-origin',
        'ETag: W/"' + "1009-1542133550" + '"',
        'Via: 1.1 vegur',
    ]
    s = HeadersFormatter().format_headers("\n".join(lines))
   

# Generated at 2022-06-23 19:25:50.720668
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-23 19:26:00.888187
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 7876
Transfer-Encoding: chunked
Content-Type: application/json; charset=utf-8
Connection: keep-alive
Date: Sun, 16 Jun 2019 18:13:13 GMT
Strict-Transport-Security: max-age=15724800
Server: nginx

'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 7876
Content-Type: application/json; charset=utf-8
Date: Sun, 16 Jun 2019 18:13:13 GMT
Server: nginx
Strict-Transport-Security: max-age=15724800
Transfer-Encoding: chunked

'''
    hf = HeadersFormatter()
    assert hf

# Generated at 2022-06-23 19:26:05.887614
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Host: httpbin.org
        Connection: keep-alive
        User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)
        Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
        Accept-Language: en-US,en;q=0.5
        Accept-Encoding: gzip, deflate
        Cookie: _gauges_unique_hour=1; _gauges_unique_day=1; _gauges_unique_month=1; _gauges_unique_year=1; _gauges_unique=1
        Dnt: 1
        Upgrade-Insecure-Requests: 1'''
    expectedHeader

# Generated at 2022-06-23 19:26:14.412710
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
Content-Type: text/html; charset=utf-8
Content-Length: 68
Connection: keep-alive
Set-Cookie: session=471124822
Set-Cookie: session=471124823
Server: meinheld/0.6.1
Date: Tue, 14 May 2019 14:18:32 GMT
'''
    assert headers_formatter.format_headers(headers) == '''\
Content-Type: text/html; charset=utf-8
Content-Length: 68
Connection: keep-alive
Set-Cookie: session=471124822
Set-Cookie: session=471124823
Server: meinheld/0.6.1
Date: Tue, 14 May 2019 14:18:32 GMT
'''


# Generated at 2022-06-23 19:26:22.138598
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Connection: keep-alive
Content-Length: 13
Vary: Origin
Vary: X-Origin


"""
    headers_formatter = HeadersFormatter()
    expected = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 13
Content-Type: text/plain; charset=utf-8
Vary: Origin
Vary: X-Origin


"""
    assert headers_formatter.format_headers(headers) == expected



# Generated at 2022-06-23 19:26:31.955111
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ('Host: localhost:8081\r\n'
               'Accept-Encoding: gzip, deflate\r\n'
               'Accept: */*\r\n'
               'Accept: text/html\r\n'
               'Connection: keep-alive\r\n'
               'User-Agent: HTTPie/0.9.2\r\n')
    assert headers == HeadersFormatter().format_headers(headers)


# Generated at 2022-06-23 19:26:32.983480
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:26:40.350847
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    formatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    # Exercise
    actual = formatter.format_headers("""\
        HTTP/1.1 200 OK
        Foo: Bar
        Bar: Baz
        Foo: Baz
        """)
    # Verify
    expected = """\
        HTTP/1.1 200 OK
        Bar: Baz
        Foo: Bar
        Foo: Baz
        """
    assert actual == expected


# Generated at 2022-06-23 19:26:48.741153
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={"headers": {"sort": True}})
    headers = "HTTP/1.1 200 OK\r\n" + \
              "Host: httpbin.org\r\n" + \
              "Connection: keep-alive\r\n" + \
              "Content-Length: 13098\r\n" + \
              "Accept: */*\r\n" + \
              "Accept-Encoding: gzip, deflate\r\n" + \
              "Content-Type: application/json\r\n" + \
              "User-Agent: HTTPie/0.9.8\r\n" + \
              "\r\n"

# Generated at 2022-06-23 19:26:51.832685
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options = {'headers': {'sort': True}},
                                 configuration = None)
    assert formatter.enabled


# Generated at 2022-06-23 19:26:59.994781
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('''\
Content-Length: 10
Content-Type: text/plain
Content-Type: text/html
Content-Length: 20
''') == '''\
Content-Length: 10
Content-Type: text/plain
Content-Type: text/html
Content-Length: 20
'''
    assert formatter.format_headers('''\
Content-Length: 10
Content-Type: text/plain
Content-Type: text/html
Content-Length: 20
''') == '''\
Content-Length: 10
Content-Type: text/plain
Content-Type: text/html
Content-Length: 20
'''

# Generated at 2022-06-23 19:27:01.248114
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-23 19:27:12.536984
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    default_headers = ('GET / HTTP/1.1')
    headers = ('Accept: application/json')
    headers = ('Accept: text/html')
    headers = ('Accept-Encoding: gzip, deflate')
    headers = ('Accept-Language: en-GB,en-US;q=0.8,en;q=0.6')
    headers = ('Cache-Control: no-cache')
    headers = ('Connection: keep-alive')
    headers = ('Content-Length: 2')
    headers = ('Content-Type: application/x-www-form-urlencoded')
    headers = ('Cookie: __cfduid=d2a88a6b0f9d946b7f5b5ed20e7d5c2e31498983274')

# Generated at 2022-06-23 19:27:21.985502
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
GET / HTTP/1.1
Content-Type: application/json
Cache-Control: no-cache
User-Agent: HTTPie/1.0.0
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.google.com
Content-Length: 2\
'''
    expected = '''\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Host: www.google.com
User-Agent: HTTPie/1.0.0\
'''
    assert HeadersFormatter().format_headers(h) == expected

# Generated at 2022-06-23 19:27:25.215328
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True
    formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert formatter.enabled == False


# Generated at 2022-06-23 19:27:37.069414
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
GET / HTTP/1.1
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: application/json
User-Agent: HTTPie/0.7.0-dev
Accept-Language: en
Cookie: foo=bar; baz=qux
Host: httpie.org
'''
    expected_headers = '''\
GET / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Accept-Language: en
Cookie: foo=bar; baz=qux
Connection: keep-alive
Host: httpie.org
User-Agent: HTTPie/0.7.0-dev
'''
    assert hf.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:27:38.766161
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    assert(a.format_options['headers']['sort'])



# Generated at 2022-06-23 19:27:48.038497
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    instance = HeadersFormatter()
    headers =   'HTTP/1.1 200 OK\r\n' \
                'Server: nginx\r\n' \
                'Date: Mon, 05 Nov 2018 00:19:37 GMT\r\n' \
                'Content-Type: application/json\r\n' \
                'Transfer-Encoding: chunked\r\n' \
                'Connection: keep-alive\r\n' \
                'Vary: Accept-Encoding\r\n' \
                'X-Powered-By: PHP/7.0.33\r\n' \
                'Expires: Thu, 19 Nov 1981 08:52:00 GMT\r\n\r\n'
    assert headers == instance.format_headers(headers)

# Generated at 2022-06-23 19:27:51.545071
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_formatter = HeadersFormatter()
    assert header_formatter.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:27:55.122030
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options['headers']['sort']


# Generated at 2022-06-23 19:28:04.415102
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    content = '\r\n'.join([
        'POST / HTTP/1.1',
        'Content-Type: application/x-www-form-urlencoded',
        'Connection: close',
        'Host: example.org',
        'User-Agent: httpie',
        'Accept-Language: en-us',
        'Accept: */*',
        '',
        'a=1&b=2&c=3,4',
        '',
    ])
    f = HeadersFormatter()

# Generated at 2022-06-23 19:28:05.428913
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Generated at 2022-06-23 19:28:13.921308
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers1 = """\
HTTP/1.1 200 OK\r
Date: Mon, 27 Jul 2009 12:28:53 GMT\r
Server: Apache\r
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r
ETag: "34aa387-d-1568eb00"\r
Accept-Ranges: bytes\r
Content-Length: 51\r
Vary: Accept-Encoding\r
Content-Type: text/plain\r
X-Foo: Bar\r
X-Bar: Baz\r
\r
"""

# Generated at 2022-06-23 19:28:17.843436
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Step 1
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == False

    # Step 2
    headers_formatter = HeadersFormatter(headers__sort=True)
    assert headers_formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:28:24.089255
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers( """\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Foo: bar
X-Baz: qux
X-Foo: box""") == """\
HTTP/1.1 200 OK
X-Baz: qux
X-Foo: bar
X-Foo: box
Content-Type: application/json; charset=utf-8"""

# Generated at 2022-06-23 19:28:29.524837
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert issubclass(HeadersFormatter, FormatterPlugin)
    assert HeadersFormatter.__init__ is not FormatterPlugin.__init__
    assert HeadersFormatter.__init__.__defaults__ == \
        FormatterPlugin.__init__.__defaults__ + \
        (None,) * (1 - len(FormatterPlugin.__init__.__defaults__))



# Generated at 2022-06-23 19:28:32.557191
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    assert a.format_options == {'headers': {'sort': False}}
    assert a.enabled == False


# Generated at 2022-06-23 19:28:34.033958
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({})
    assert formatter.enabled

# Generated at 2022-06-23 19:28:38.231170
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.format_options['headers']['sort']
    assert not x.enabled
    x = HeadersFormatter(sorting_headers=True)
    assert x.enabled


# Generated at 2022-06-23 19:28:40.372521
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options = {
        'headers' : {'sort': True}
    })


# Generated at 2022-06-23 19:28:47.168909
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = [
        {
            'headers': {
                'sort': True
            }
        }
    ]

    headers = '''
        HTTP/1.1 200 OK
        Content-Type: application/json
        Age: 12
        Connection: close
        Cache-Control: private
        Content-Length: 15
    '''
    s = '''
        HTTP/1.1 200 OK
        Age: 12
        Cache-Control: private
        Connection: close
        Content-Length: 15
        Content-Type: application/json
    '''

    assert HeadersFormatter(format_options=headers_formatter).format_headers(headers) == s

# Generated at 2022-06-23 19:28:56.883200
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    hp = HeadersFormatter()
    assert hp.format_headers('GET / HTTP/1.1\r\nHost: localhost:3000\r\nUser-Agent: HTTPie/0.9.6\r\nAccept-Encoding: gzip, deflate, compress\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n') == 'GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, compress\r\nConnection: keep-alive\r\nHost: localhost:3000\r\nUser-Agent: HTTPie/0.9.6\r\n\r\n'


# Generated at 2022-06-23 19:28:57.766942
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:29:06.653931
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  h = HeadersFormatter(format_options=FROZENSEVER_OPTIONS)
  input_headers = """GET /posts/1 HTTP/1.1
content-type: application/json
apikey: 12345
content-type: application/json
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/1.0.0"""
  output_headers = """GET /posts/1 HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/1.0.0
content-type: application/json
content-type: application/json
apikey: 12345"""

# Generated at 2022-06-23 19:29:08.661932
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert fmt.enabled is False
    assert fmt.format_options == {}



# Generated at 2022-06-23 19:29:16.858555
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from copy import copy
    from pprint import pprint

    headers_formatter = HeadersFormatter()


# Generated at 2022-06-23 19:29:19.804406
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:29:25.019202
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(verbose=False)
    assert headers_formatter.format_headers('GET /\r\nX-A: 1\r\nX-B: 2\r\nX-C: 3\r\n\r\n') == 'GET /\r\nX-A: 1\r\nX-B: 2\r\nX-C: 3\r\n'

