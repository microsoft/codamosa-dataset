

# Generated at 2022-06-23 19:19:31.039159
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers(r"HTTP/1.0 200 OK\r\n"
    r"Content-Length: 11\r\n"
    r"Content-Type: text/plain; charset=utf-8\r\n"
    r"Date: Mon, 27 Jul 2015 01:12:16 GMT\r\n"
    r"Server: BaseHTTP/0.6 Python/3.5.0")

# Generated at 2022-06-23 19:19:37.090228
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    headers = 'HTTP/1.1 200 OK\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\n'\
              'Content-Type: application/json; charset=utf-8\r\nDate: Mon, 29 Oct 2018 20:22:07 GMT\r\n'\
              'ETag: W/"6d5b6f35e6f90379f8cbeb035e71c7d4"\r\nX-Powered-By: Express\r\n\r\n'

# Generated at 2022-06-23 19:19:38.466161
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass



# Generated at 2022-06-23 19:19:39.077822
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:19:43.839366
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert x.enabled
    assert x.format_options['headers']['sort']
    assert x.format_options['headers']['all']
    assert x.format_options['headers']['first']
    assert x.format_options['headers']['color']



# Generated at 2022-06-23 19:19:45.846172
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_format = HeadersFormatter()
    assert headers_format.enabled is True

# Generated at 2022-06-23 19:19:56.982720
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    h = """\
HTTP/1.1 200 OK
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 17
Content-Type: text/html; charset=utf-8
Date: Mon, 01 Jan 2018 09:27:55 GMT
Server: BaseHTTP/0.6 Python/3.5.2
Set-Cookie: csrftoken=uw7DJF8rNcx1Vj9ZiFvhC5dnmGEsaFW2; expires=Mon, 30-Jul-2018 09:27:55 GMT; Max-Age=31449600; Path=/
Vary: Cookie
X-Frame-Options: SAMEORIGIN

Hello World!Hello
"""

# Generated at 2022-06-23 19:19:58.886900
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    assert a.format_options['headers']['sort'] == False



# Generated at 2022-06-23 19:20:11.216998
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_string = '''\
HTTP/1.1 100 Continue
Date: Mon, 13 Jul 2015 19:19:47 GMT
Server: Apache/2.2.29 (Unix) DAV/2
Connection: Keep-Alive
Content-Length: 0
Content-Type: text/html; charset=iso-8859-1
'''
    formated_headers = headers_formatter.format_headers(headers_string)
    # to make sure the sort worked, find the location of the
    # http header 'Date'.
    location_of_date_header = formated_headers.find('Date')
    # the header 'Server' should be before the header 'Date'
    location_of_server_header = formated_headers.find('Server')
    # if the sort worked, the location

# Generated at 2022-06-23 19:20:19.330911
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ("Accept-Encoding: gzip, deflate\r\n"
               "Content-Type: application/json\r\n"
               "Accept: application/json\r\n"
               "Accept-Language: en\r\n")
    expected_headers = ("Accept-Encoding: gzip, deflate\r\n"
                        "Accept: application/json\r\n"
                        "Accept-Language: en\r\n"
                        "Content-Type: application/json\r\n")
    assert HeadersFormatter().format_headers(headers) == expected_headers


if __name__ == '__main__':
    # Unit test for method format_headers of class HeadersFormatter
    test_HeadersFormatter_format_headers()

    # Unit test for class HeadersFormatter

# Generated at 2022-06-23 19:20:31.075339
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def test_format_headers(x, y):
        headers_formatter = HeadersFormatter()
        headers_format_options = {'headers': {'sort': True}}
        headers_formatter.format_options = headers_format_options
        assert headers_formatter.format_headers(x) == y


# Generated at 2022-06-23 19:20:37.257277
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = """\
HTTP/1.1 200 OK
Server: gunicorn/19.8.1
Date: Tue, 20 Aug 2019 09:00:54 GMT
Connection: close
Transfer-Encoding: chunked
Content-Type: application/json
X-Frame-Options: SAMEORIGIN
Cache-Control: no-cache, no-store, max-age=0, must-revalidate
Expires: 0
Content-Encoding: gzip
\r\n"""
    print(HeadersFormatter().format_headers(h))

# Generated at 2022-06-23 19:20:39.485751
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:20:40.741006
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()

# Generated at 2022-06-23 19:20:45.641760
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    my_headers = '''
                                 HTTP/1.1 200 OK
                                 Content-Type: text/html; charset=utf-8
                                 Content-Length: 2
                                 Connection: close
                                 '''
    assert HeadersFormatter(format_options=my_headers).enabled == True

# Test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:20:55.209601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    HTTP/1.1 200 OK
    Content-Length: 0
    Content-Encoding: identity
    Connection: close
    x-h: 1
    X-Request-Id: abc
    X-X: 2
    x-z: 333
    x-a: 1
    x-x: 2
    x-b: 2
    X-B: 1
    '''
    # Test for sorting headers
    headers1 = HeadersFormatter().format_headers(headers)

# Generated at 2022-06-23 19:21:02.736614
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    def check_formatter(headers, expected_headers):
        format_options = {'headers': {'sort': True}}
        formatter = HeadersFormatter(format_options)
        formatted_headers = formatter.format_headers(headers)
        assert formatted_headers == expected_headers


# Generated at 2022-06-23 19:21:04.251325
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    assert a is not None



# Generated at 2022-06-23 19:21:06.530369
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()
    assert instance.enabled == False

# Generated at 2022-06-23 19:21:09.493798
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert type(fmt) is HeadersFormatter


# Generated at 2022-06-23 19:21:20.444264
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = "Content-Length: 19\r\n" \
              "User-Agent: httpie/1.0.2\r\n" \
              "Accept-Encoding: gzip, deflate\r\n" \
              "Accept: */*\r\n" \
              "Host: localhost:8081\r\n" \
              "Content-Type: application/json\r\n" \
              "Connection: keep-alive\r\n"

# Generated at 2022-06-23 19:21:22.585923
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-23 19:21:23.494603
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:21:34.435863
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    hf.format_options = {
        'headers': {
            'sort': True
        }
    }
    headers = ('HTTP/1.1 200 OK\r\n'
               'Host: www.example.com\r\n'
               'Cache-Control: max-age=0\r\n'
               'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n'
               'Accept-Encoding: gzip, deflate, br\r\n'
               'Accept-Language: en-US,en;q=0.5\r\n\r\n')

# Generated at 2022-06-23 19:21:41.277065
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
            HTTP/1.1 200 OK
            Content-Type: application/json
            Content-Length: 2
            Connection: Close
            X-Content-Type-Options: nosniff
            X-Frame-Options: DENY
            X-XSS-Protection: 1; mode=block
            Date: Tue, 26 Jun 2018 21:39:51 GMT

            {}
        """.format('x' * 5)

# Generated at 2022-06-23 19:21:46.959604
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(**{
    'debug': False,
    'output_file': None,
    'options': {'headers': {'sort': True},
                'warn': True},
    'stream': None,
    'format_options': {'headers': {'sort': True},
                       'warn': True},
    'config': {}
    })


# Generated at 2022-06-23 19:21:50.517667
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    Myobj=HeadersFormatter()
    assert isinstance(Myobj, HeadersFormatter)


# Generated at 2022-06-23 19:22:00.196533
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Initialization of the class HeadersFormatter
    formatter_obj = HeadersFormatter(
        format_options={'headers': {'sort': True}}
    )
    # Call of the method format_headers

# Generated at 2022-06-23 19:22:02.389813
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options['headers']['sort'] == False


# Generated at 2022-06-23 19:22:09.025851
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assertion = True
    try:
        formatter = HeadersFormatter()
        assert isinstance(formatter, HeadersFormatter)
        formatter = FormatterPlugin()
        assert isinstance(formatter, FormatterPlugin)
    except Exception:
        assertion = False
    assert assertion == True

# Unit tests for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:22:15.263230
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    assert headers_formatter.format_headers('a: 1\r\nb: 2\r\nb: 3\r\na: 4\r\n') == \
                                                'a: 1\r\na: 4\r\nb: 2\r\nb: 3\r\n'



# Generated at 2022-06-23 19:22:19.156202
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter({'headers': {'sort': True}}).enabled == True
    assert HeadersFormatter({'headers': {'sort': False}}).enabled == False
    assert HeadersFormatter({'headers': {'sort': 'true'}}).enabled == False


# Generated at 2022-06-23 19:22:20.427999
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options = {'headers': {'sort': True}})

# Generated at 2022-06-23 19:22:26.903756
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Server: nginx
Date: Sat, 30 Dec 2017 02:24:34 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
ETag: W/"2-xHrRi33RgTLkfv7zIbgWfxy5B5Y"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 841c5b5f-e8e1-4893-b5f5-9514d8fe3f3f
X-Runtime: 0.008038
Date: Sat, 30 Dec 2017 02:24:34 GMT
"""


# Generated at 2022-06-23 19:22:30.499979
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options=('headers',{'sort': True}))
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:22:33.590120
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': False}}
    headers_formatter = HeadersFormatter(format_options=format_options)
    assert(isinstance(headers_formatter, HeadersFormatter))
    assert(headers_formatter.enabled == False)
    

# Generated at 2022-06-23 19:22:35.329075
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(
        format_options=__builtins__['__httpie_format_options__'])
    assert formatter.enabled

# Generated at 2022-06-23 19:22:47.899116
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    resp_headers = '''
{
    "Server": "cloudflare",
    "Date": "Mon, 09 Mar 2020 16:15:28 GMT",
    "Content-Type": "text/html",
    "Transfer-Encoding": "chunked",
    "Connection": "keep-alive",
    "Set-Cookie": "__cfduid=d4ae1633b534d8ffa16b5c5b5d5446d6d1583826128; expires=Wed, 08-Apr-20 16:15:28 GMT; path=/; domain=.meraki.com; HttpOnly; SameSite=Lax",
    "CF-RAY": "59fe3b84c9b88d3e-IAD"
}
'''
    
HeadersFormatter()(None, resp_headers)

# Generated at 2022-06-23 19:22:59.172944
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_case_headers_formatter = HeadersFormatter()
    test_headers = '''HTTP/1.1 200 OK
X-Auth-Token: 5a8d7c5d1f067eeb18c2f2e99f96e28d
Content-Type: application/json; charset=UTF-8
Server: TORNADO
Date: Tue, 21 Aug 2018 07:30:21 GMT
Content-Length: 8
Connection: close'''

# Generated at 2022-06-23 19:23:09.736080
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_string_1 = """POST https://www.google.com/ HTTP/1.1
Content-Length: 15
Content-Type: application/x-www-form-urlencoded
Host: www.google.com
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive"""
    
    test_string_2 = """POST https://www.eliftech.com/school-task HTTP/1.1
Content-Length: 154
Content-Type: application/json
Host: www.eliftech.com
User-Agent: HTTPie/1.0.2
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive"""
    

# Generated at 2022-06-23 19:23:11.591443
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h is not None


# Generated at 2022-06-23 19:23:18.776692
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-23 19:23:28.979863
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ("POST / HTTP/1.1\r\n"
             "Host: example.org\r\n"
             "Connection: keep-alive\r\n"
             "X-Requested-With: XMLHttpRequest\r\n"
             "User-Agent: FakeAgent\r\n"
             "X-Custom-Header: somevalue\r\n"
             "Accept: */*\r\n"
             "Accept-Encoding: gzip, deflate\r\n"
             "Accept-Language: en-US,en;q=0.5\r\n"
             "Content-Length: 20\r\n"
             "Content-Type: application/json\r\n"
             )

# Generated at 2022-06-23 19:23:38.813310
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    format_options = {'headers': {'sort': True}}
    formatter.format_options = format_options

    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 103
X-Something-Else: 123
X-Something: 123
"""
    expected_headers = """\
HTTP/1.1 200 OK
X-Something: 123
X-Something-Else: 123
Content-Length: 103
Content-Type: application/json
"""
    assert formatter.format_headers(headers) == expected_headers
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 103
X-Something-Else: 123
X-Something: 123
"""
    expected_headers

# Generated at 2022-06-23 19:23:45.243624
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    headers = 'Content-Length: 100\r\nContent-Type: text/plain\r\nX-Foo: 1\r\nX-Foo: 2\r\nA: b\r\nA: c\r\nA: a'
    result = formatter.format_headers(headers)
    assert result == 'Content-Length: 100\r\nX-Foo: 1\r\nX-Foo: 2\r\nA: b\r\nA: c\r\nA: a\r\nContent-Type: text/plain'
'''

HEADERS_SORT_TEST_CODE_C = '''
#include "test.h"


# Generated at 2022-06-23 19:23:51.792203
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {
            'sort': True
        }
    }

    formatter=HeadersFormatter(format_options=format_options)
    assert formatter.enabled == True
    assert headers_format.__doc__ == headers_format.format_headers.__doc__
    assert headers_format.__doc__ == HeadersFormatter.format_headers.__doc__


# Generated at 2022-06-23 19:24:00.816955
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_str = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 590
Date: Sun, 19 Jul 2015 00:13:45 GMT
Via: 1.1 vegur

'''
    assert headers_formatter.format_headers(headers_str) == '''\
HTTP/1.1 200 OK
Content-Length: 590
Content-Type: application/json
Connection: keep-alive
Date: Sun, 19 Jul 2015 00:13:45 GMT
Via: 1.1 vegur

'''

# Generated at 2022-06-23 19:24:07.828109
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    headers_formatter = HeadersFormatter()

    # When
    headers = headers_formatter.format_headers("""\
POST / HTTP/1.1
X-Powered-By: Flask
Content-Length: 32
content-type: application/json
user-agent: HTTPie/0.9.9
""")

    # Then
    assert headers == """\
POST / HTTP/1.1
content-type: application/json
content-length: 32
user-agent: HTTPie/0.9.9
x-powered-by: Flask
"""


# Invoke the unittest module by explicitly calling it
test_HeadersFormatter_format_headers()

# Register the test plugin
httpie.plugins.register(HeadersFormatter)

# Generated at 2022-06-23 19:24:09.671865
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert type(obj) == HeadersFormatter
    assert obj.enabled == True


# Generated at 2022-06-23 19:24:15.597844
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    config = TestApp()
    config._runtime_conf["output_options"] = {
    "headers": {
        "sort": True,
        "all": True,
    }
}
    hf = HeadersFormatter(config=config)
    assert hf.enabled == True
    assert hf.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:24:27.040357
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    headers_original = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nDate: Fri, 15 Feb 2019 18:50:23 GMT\r\nServer: nginx/1.14.0 (Ubuntu)\r\nContent-Length: 19596\r\nConnection: keep-alive"
    headers_expected = "HTTP/1.1 200 OK\r\nContent-Length: 19596\r\nContent-Type: application/json; charset=utf-8\r\nConnection: keep-alive\r\nDate: Fri, 15 Feb 2019 18:50:23 GMT\r\nServer: nginx/1.14.0 (Ubuntu)"

# Generated at 2022-06-23 19:24:33.016700
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers(
        'HTTP/1.1 200\r\nContent-Type: application/json\r\nAccept: application/json\r\nAccept: text/html\r\n') == \
        'HTTP/1.1 200\r\nAccept: application/json\r\nAccept: text/html\r\nContent-Type: application/json\r\n'

# Generated at 2022-06-23 19:24:40.547543
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Date: Sun, 04 Aug 2019 22:34:58 GMT
Expires: -1
Cache-Control: private, max-age=0
Content-Type: text/html; charset=UTF-8
Content-Encoding: gzip
Server: GSE
X-XSS-Protection: 0
X-Frame-Options: SAMEORIGIN
Alt-Svc: quic=":443"; ma=2592000; v="46,44,43,39"
Accept-Ranges: none
Vary: Accept-Encoding'''
    result = hf.format_headers(headers)

# Generated at 2022-06-23 19:24:42.314867
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is False


# Generated at 2022-06-23 19:24:47.764965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
foo: 1
content-type: application/json
foo: 2
foo: 3
bar: 4
'''
    expected_headers = '''\
HTTP/1.1 200 OK
bar: 4
content-type: application/json
foo: 1
foo: 2
foo: 3
'''
    hf.format_headers(headers) == expected_headers


# Generated at 2022-06-23 19:24:51.670823
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Test that the constructor of HeadersFormatter
    is working properly.
    """
    header = HeadersFormatter(format_options=None)
    assert header.enabled == True



# Generated at 2022-06-23 19:24:59.670185
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter(): 
    class A:
        def __init__(self):
            self.headers = {'Content-Length': 0,\
                            'Host': '127.0.0.1',\
                            'Content-Type': 'application/json'}
            self.content = '{"message": "Hello World"}'

    resp = A()
    expected = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 0\r\nHost: 127.0.0.1'

    assert expected in HeadersFormatter().format_headers(str(resp.headers))


# Generated at 2022-06-23 19:25:01.750042
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers':{'sort': False}})
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:25:13.007053
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    passed_headers = """
    GET / HTTP/1.1
    Host: example.com
    Content-Length: 123
    Content-Type: application/json; charset=UTF-8
    X-Custom-Header: Value
    X-Custom-Header: Other value
    Accept-Encoding: gzip, deflate
    Accept: */*
    """
    expected_headers = """
    GET / HTTP/1.1
    Accept: */*
    Accept-Encoding: gzip, deflate
    Content-Length: 123
    Content-Type: application/json; charset=UTF-8
    Host: example.com
    X-Custom-Header: Value
    X-Custom-Header: Other value
    """
    formatter = HeadersFormatter()
    assert formatter.format_headers(passed_headers) == expected_

# Generated at 2022-06-23 19:25:24.477316
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = (
        '''HTTP/1.1 200 OK\r\n'''
        '''Content-Type: application/json\r\n'''
        '''Link: <http://localhost:8080/customers/1>; rel="self"\r\n'''
        '''Link: <http://localhost:8080/customers/1/addresses>; rel="addresses"\r\n'''
        '''Link: <http://localhost:8080/customers/1/addresses/1>; rel="addresses"\r\n'''
        '''X-My-Header: one\r\n'''
        '''X-My-Header: two\r\n'''
        '''X-My-Header: three\r\n'''
    )

# Generated at 2022-06-23 19:25:27.369040
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(AssertionError):
        HeadersFormatter(headers=None)


# Generated at 2022-06-23 19:25:29.835743
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True
    assert formatter.enabled == True


# Generated at 2022-06-23 19:25:38.807403
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers("HTTP/1.1 200 OK\r\n"
                                            "X-Case-Insensitive-Header: A\r\n"
                                            "X-Case-Insensitive-Header: B\r\n"
                                            "X-Case-Insensitive-Header: C\r\n"
                                            "x-case-insensitive-header: D\r\n"
                                            "x-case-insensitive-header: E\r\n"
                                            "X-Case-Insensitive-Header: F\r\n"
                                            "x-case-insensitive-header: G\r\n"
                                            "X-Case-Insensitive-Header: H\r\n")

# Generated at 2022-06-23 19:25:48.584082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import formatter
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.output.formatters import JSONFormatter
    formatter.__registry__.update({
        JSONFormatterPlugin: dict(
            name='json',
            help='Formats JSON data.',
            format_options=dict(
                json=dict(
                    sort_keys=False,
                    indent=None,
                    separators=None,
                )
            )
        )
    })
    httpie = dict(formatter=JSONFormatter)
    h = HeadersFormatter(httpie = httpie)

# Generated at 2022-06-23 19:25:57.013176
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_headers = """\
GET / HTTP/1.1
Host: example.org
Connection: close
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.9
"""
    expected_headers = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Host: example.org
User-Agent: HTTPie/0.9.9
"""
    assert HeadersFormatter().format_headers(input_headers) == expected_headers

# Generated at 2022-06-23 19:26:04.796484
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    lines = ['GET / HTTP/1.1',
             'User-Agent: httpie/0.9.8',
             'Accept-Encoding: gzip, deflate',
             'Accept: */*',
             'Connection: keep-alive',
             '',
             'content']

    assert '\r\n'.join(lines) == HeadersFormatter().format_headers('\r\n'.join(lines))



# Generated at 2022-06-23 19:26:09.419684
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    sorted_headers = formatter.format_headers("""\
HTTP/1.1 200 OK
X-header: 1
X-HEADER: 2
a-Header: 3
""")
    assert sorted_headers == """\
HTTP/1.1 200 OK
a-Header: 3
X-header: 1
X-HEADER: 2
"""

# Generated at 2022-06-23 19:26:18.633347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers = """\
Content-Length: 590
Cache-Control: max-age=604800
Content-Type: application/octet-stream
Date: Fri, 10 Feb 2017 18:22:48 GMT
Etag: "359670651"
Expires: Fri, 17 Feb 2017 18:22:48 GMT
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (oxr/8313)
x-Cache: HIT
x-Content-Type-Options: nosniff
x-Frame-Options: SAMEORIGIN
x-Xss-Protection: 1; mode=block
Connection: keep-alive
"""

    hf = HeadersFormatter()

# Generated at 2022-06-23 19:26:28.941938
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json;charset=UTF-8
Content-Length: 16
Server: nginx
Date: Thu, 07 Sep 2017 20:00:32 GMT
X-XSS-Protection: 1; mode=block
Connection: keep-alive
Vary: Accept-Encoding
'''
    headers_formatted = '''\
HTTP/1.1 200 OK
Content-Length: 16
Content-Type: application/json;charset=UTF-8
Connection: keep-alive
Date: Thu, 07 Sep 2017 20:00:32 GMT
Server: nginx
Vary: Accept-Encoding
X-XSS-Protection: 1; mode=block
'''

# Generated at 2022-06-23 19:26:32.554141
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    http = Http()
    headers_formatter = HeadersFormatter(output_options={},
                                         format_options={"headers": {"sort": True}})
    assert isinstance(headers_formatter, HeadersFormatter)
    assert headers_formatter.format_options['headers']['sort'] and headers_formatter.enabled


# Generated at 2022-06-23 19:26:36.016155
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:26:36.982524
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	foo = HeadersFormatter()
	assert foo


# Generated at 2022-06-23 19:26:43.786412
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("Host: localhost:5000\r\nAccept: text/html\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Length: 13\r\nContent-Type: application/json\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n") == "Host: localhost:5000\r\nAccept: text/html\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nContent-Length: 13\r\nContent-Type: application/json\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n"

# Generated at 2022-06-23 19:26:54.501770
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = """DELETE / HTTP/1.1
Content-Length: 10
Connection: keep-alive
Content-Type: application/json
Accept: application/json
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate
Host: httpbin.org
"""
    expected = """DELETE / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Content-Length: 10
Content-Type: application/json
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2
"""

    assert HeadersFormatter().format_headers(headers) == expected


# Generated at 2022-06-23 19:26:59.679155
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:27:07.321495
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:27:12.237593
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    def mock_super():
        return None
    mocker = Mocker()
    mock_super = mocker.replace(FormatterPlugin.__init__(**kwargs))
    with mocker:
        mock_super()
        assert HeadersFormatter(**kwargs).format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:27:15.397418
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == 1


# Generated at 2022-06-23 19:27:25.687220
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Length: 24
connection: keep-alive
Content-Type: text/html; charset=utf-8
Date: Sat, 20 Feb 2016 10:13:21 GMT
Server: BaseHTTP/0.3 Python/3.4.3
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 24
Content-Type: text/html; charset=utf-8
Date: Sat, 20 Feb 2016 10:13:21 GMT
Server: BaseHTTP/0.3 Python/3.4.3
connection: keep-alive
"""
    assert HeadersFormatter().format_headers(headers) == expected


FormatterPlugin = FormatterPlugin  # noqa
FormatterPlugin = FormatterPlugin  # noqa

# Generated at 2022-06-23 19:27:27.703773
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter is not None

# Generated at 2022-06-23 19:27:32.993567
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Tests if the method format_headers of class HeadersFormatter
    sorts the headers by name
    """
    headers_formatter = HeadersFormatter()
    headers_string = 'Content-Type: application/json'
    sorted_headers_string = headers_formatter.format_headers(headers_string)
    assert sorted_headers_string == headers_string



# Generated at 2022-06-23 19:27:34.370327
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test = HeadersFormatter()
    assert test is not None


# Generated at 2022-06-23 19:27:36.338192
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-23 19:27:37.384170
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:27:45.228427
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.formatter import get_parser
    from httpie.cli import parser
    args = parser.parse_args([])
    format_options = get_parser().parse_args(args.formats or [])
    headers_formatter = HeadersFormatter(format_options=format_options)
    assert headers_formatter.format_headers('httpie') == 'httpie'
    assert headers_formatter.format_headers('httpie\r\nContent-Type: application/json\r\nAccept: application/json') == 'httpie\r\nAccept: application/json\r\nContent-Type: application/json'

# Generated at 2022-06-23 19:27:56.859759
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # headers_format_unordered
    headers = formatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Connection: keep-alive\r\n'
        'Server: nginx\r\n'
        'Transfer-Encoding: chunked\r\n'
        'X-RateLimit-Limit: 600\r\n'
        "Date: Fri, 15 Dec 2017 19:50:02 GMT\r\n"
    )

# Generated at 2022-06-23 19:28:05.919684
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 12
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.6
accept-encoding: gzip, deflate
connection: keep-alive
host: httpbin.org
user-agent: HTTPie/0.9.6
'''

# Generated at 2022-06-23 19:28:10.692975
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    actual = formatter.format_headers('a: 1\r\nContent-Type: application/x-www-form-urlencoded\r\nc: 2\r\nb: 1')
    expected = 'a: 1\r\nb: 1\r\nc: 2\r\nContent-Type: application/x-www-form-urlencoded'
    assert actual == expected

# Generated at 2022-06-23 19:28:14.838113
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    h1 = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-Foo: bar\r\nBaz: qux\r\n'
    h2 = 'HTTP/1.1 200 OK\r\nBaz: qux\r\nContent-Type: application/json\r\nX-Foo: bar\r\n'
    assert f.format_headers(h1) == h2


# Generated at 2022-06-23 19:28:22.268550
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected_headers = (
        'Accept-Encoding: identity\r\n'
        'Accept: */*\r\n'
        'Accept-Language: en,en-US;q=0.8,zh-CN;q=0.6\r\n'
        'Content-Type: application/x-www-form-urlencoded\r\n'
        'User-Agent: HTTPie/0.9.2\r\n'
        'Content-Length: 17\r\n'
        '\r\n'
    )
    assert HeadersFormatter.format_headers(expected_headers) == expected_headers

# Generated at 2022-06-23 19:28:27.364736
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter({'headers': {'sort': True}})
    assert isinstance(f, HeadersFormatter)
    assert isinstance(f.format_options, dict)
    assert f.enabled
    assert f.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-23 19:28:30.507192
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test if the constructor successfully created an object of class HeadersFormatter
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert isinstance(formatter, HeadersFormatter)


# Generated at 2022-06-23 19:28:41.817684
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    args = ['--headers', '--headers=sort']
    cli = httpie.CLI(args=args, env=Env(colors=0))
    cli.initialize()
    formatter = HeadersFormatter(use_colors=False,
                                format_options=cli.format_options)
    headers = """\
HTTP/1.1 200 OK
Age: 1
Content-Length: 4
Content-Type: application/json
Server: gunicorn/19.9.0
X-Xss-Protection: 1; mode=block
Cache-Control: max-age=0, no-cache
Date: Tue, 05 Nov 2019 16:37:22 GMT
"""

# Generated at 2022-06-23 19:28:43.036727
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_obj = HeadersFormatter()
    exp_headers = None
    assert test_obj.enabled == exp_headers



# Generated at 2022-06-23 19:28:48.313699
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
Host: github.com
Proxy-Connection: keep-alive
Referer: https://github.com/jkbrzt/httpie/issues/139
User-Agent: Python-urllib/2.7
'''
    expected = '''\
Host: github.com
Referer: https://github.com/jkbrzt/httpie/issues/139
Proxy-Connection: keep-alive
User-Agent: Python-urllib/2.7
'''
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:28:49.202181
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == False


# Generated at 2022-06-23 19:28:49.812102
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:28:58.925263
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:29:07.343332
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    user-agent: Mozilla/5.0
    accept: text/html
    x-custom: 1

    """
    headers = """\
GET / HTTP/1.1
user-agent: Mozilla/5.0
accept: text/html
x-custom: 1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive


"""
    expected = """\
GET / HTTP/1.1
accept: text/html
Host: httpbin.org
user-agent: Mozilla/5.0
Accept-Encoding: gzip, deflate
Connection: keep-alive
x-custom: 1


"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-23 19:29:08.303487
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__

# Generated at 2022-06-23 19:29:12.800766
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # kwargs are the arguments that will be passed to the constructor
    format_options = {
        'verbose': True,
        'headers': {
            'sort': True
        }
    }
    H = HeadersFormatter(format_options = format_options)
    assert H.enabled == format_options['headers']['sort']


# Generated at 2022-06-23 19:29:13.757701
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == True


# Generated at 2022-06-23 19:29:19.464558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    fmt = HeadersFormatter()

    # Sample headers sorted manually in the format generated by httpie
    headers_lines = ('HTTP/1.1 200 OK\r\n'
                     'Content-Length: 3\r\n'
                     'Content-Type: application/json\r\n'
                     'Date: Sun, 04 Feb 2018 21:56:36 GMT\r\n'
                     'Server: python-http-client\r\n'
                     'Status: 200\r\n'
                     '\r\n')

    # Headers with same name should be sorted together
    # without affecting the relative order of headers with different names
    # and without affecting the first 2 lines representing response line
    # and a blank line

# Generated at 2022-06-23 19:29:20.546726
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	fmt=HeadersFormatter()


# Generated at 2022-06-23 19:29:27.415577
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('headers\r\nCookie: cookie-value\r\nX-Test: first\r\nX-Test: second') \
        == 'headers\r\nCookie: cookie-value\r\nX-Test: first\r\nX-Test: second'
    assert formatter.format_headers('headers\r\nX-Test: first\r\nX-Test: second\r\nCookie: cookie-value') \
        == 'headers\r\nCookie: cookie-value\r\nX-Test: first\r\nX-Test: second'
    assert formatter.format_headers('headers\r\nX-Test: first\r\nCookie: cookie-value\r\nX-Test: second')