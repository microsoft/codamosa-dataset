

# Generated at 2022-06-23 19:19:25.341117
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    header = '\r\n'.join((
        'HTTP/1.1 200 OK',
        'Date: Thu, 12 Oct 2017 17:39:49 GMT',
        'Content-Length: 6',
        'Content-Encoding: gzip',
        'Content-Type: application/json; charset=utf-8',
        'Server: nginx'
    ))
    assert formatter.format_headers(header) == header.replace('GMT', 'UTC')



# Generated at 2022-06-23 19:19:27.035024
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.sort_headers == True


# Generated at 2022-06-23 19:19:31.670306
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
User-Agent: httpie
Content-Type: application/json
Foo: Bar
Content-type: application/json
Foo: Baz
"""
    expected = """\
User-Agent: httpie
Content-Type: application/json
Content-type: application/json
Foo: Bar
Foo: Baz
"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-23 19:19:38.455810
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    raw_headers = """
        Header1: value1
        Header3: value3
        Header2: value2
        Header2: value2
        """
    expected_headers = """
        Header1: value1
        Header2: value2
        Header2: value2
        Header3: value3
        """
    formatter = HeadersFormatter()
    assert formatter.format_headers(raw_headers) == expected_headers



# Generated at 2022-06-23 19:19:44.604973
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test when sort is enabled
    options = {'headers': {'sort': True}}
    headers_formatter = HeadersFormatter(format_options=options)
    assert headers_formatter is not None
    assert headers_formatter.enabled is True

    # Test when sort is disabled
    options = {'headers': {'sort': False}}
    headers_formatter = HeadersFormatter(format_options=options)
    assert headers_formatter is not None
    assert headers_formatter.enabled is False



# Generated at 2022-06-23 19:19:56.069555
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = (
        'HTTP/1.1 200 OK\r\n'
        'Date: Tue, 26 Apr 2016 14:27:40 GMT\r\n'
        'Server: Apache\r\n'
        'Content-Length: 0\r\n'
        'Connection: close\r\n'
        'Content-Type: text/xml; charset=utf-8\r\n'
        'X-Random-Header: foo\r\n'
        'X-Random-Header: bar\r\n'
        'X-Another-Random-Header: baz\r\n\r\n'
    )

# Generated at 2022-06-23 19:19:59.390913
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    def main(**kwargs):
        print(kwargs)
    kwargs = {'--headers': '--sort'}
    headers = HeadersFormatter(output_file=main, args=kwargs)
    assert headers.enabled == True


# Generated at 2022-06-23 19:20:03.180095
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': False}})

    assert hf.enabled == hf.format_options['headers']['sort']

# Generated at 2022-06-23 19:20:04.870052
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    plugin = HeadersFormatter()



# Generated at 2022-06-23 19:20:08.534719
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'format_name': 'headers', 'headers': {'sort': True}})
    assert isinstance(headers_formatter, HeadersFormatter)

# Unit tests for format_headers method

# Generated at 2022-06-23 19:20:18.307501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    input_str = """HTTP/1.1 200 OK
Content-Type: application/json; charset=UTF-8
Cache-Control: no-cache
Date: Tue, 04 Jun 2019 13:22:49 GMT
Server: Microsoft-IIS/8.5
X-Powered-By: ASP.NET

body
"""
    output_str = """HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Type: application/json; charset=UTF-8
Date: Tue, 04 Jun 2019 13:22:49 GMT
Server: Microsoft-IIS/8.5
X-Powered-By: ASP.NET

body
"""
    assert headers_formatter.format_headers(input_str) == output_str

# Generated at 2022-06-23 19:20:21.985901
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:20:25.831954
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert sorted(['a: b', 'b: c', 'c: d'], key=lambda h: h.split(':')[0]) == ['a: b', 'b: c', 'c: d']


# Generated at 2022-06-23 19:20:27.913224
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options={"headers":{"sort":True}}
    HeadersFormatter(format_options=options)


# Generated at 2022-06-23 19:20:30.742609
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    formatter = HeadersFormatter({
        'headers': {
            'sort': True
        }
    })
    assert formatter != None
    assert formatter.enabled == True


# Generated at 2022-06-23 19:20:37.294026
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Type: application/json
X-XSS-Protection: 1; mode=block
X-TEST-HEADER: 1234
X-Test-Header: 5678
X-TEST-HEADER: 9012
"""
    expected = """\
Content-Type: application/json
X-TEST-HEADER: 1234
X-Test-Header: 5678
X-TEST-HEADER: 9012
X-XSS-Protection: 1; mode=block
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-23 19:20:39.371510
# Unit test for constructor of class HeadersFormatter

# Generated at 2022-06-23 19:20:41.289349
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.name == 'headers'
    assert HeadersFormatter.alias == 'h'
    assert HeadersFormatter.description == 'Sort headers alphabetically.'


# Generated at 2022-06-23 19:20:49.375137
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = """
POST / HTTP/1.1
Host: example.org
Connection: close
Content-Length: 2
Content-Type: application/x-www-form-urlencoded
Cookie: sessionid=123"""

    expected = """
POST / HTTP/1.1
Content-Length: 2
Content-Type: application/x-www-form-urlencoded
Cookie: sessionid=123
Connection: close
Host: example.org"""

    formatter = HeadersFormatter()
    assert formatter.format_headers(input) == expected
    assert formatter.format_headers(input) == input.replace('\n', '\r\n')


# Generated at 2022-06-23 19:20:50.731433
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter != None


# Generated at 2022-06-23 19:20:56.812216
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""Content-Type: application/json
Server: TornadoServer/5.0.2
Date: Sun, 29 Mar 2020 07:57:30 GMT
Content-Length: 5
Connection: keep-alive

""") == """Content-Type: application/json
Server: TornadoServer/5.0.2
Date: Sun, 29 Mar 2020 07:57:30 GMT
Content-Length: 5
Connection: keep-alive

"""

# Generated at 2022-06-23 19:20:59.513623
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  format_options = {'headers': {'sort': True}}
  headers_formatter = HeadersFormatter(format_options)
  assert headers_formatter.format_options == format_options


# Generated at 2022-06-23 19:21:06.420772
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Content-Encoding: gzip
Content-Type: text/html; charset=utf-8
Vary: Cookie
Content-Length: 648
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff
Server: GSE
X-Frame-Options: SAMEORIGIN
Cache-Control: private, max-age=0
Date: Fri, 11 May 2018 06:58:52 GMT
"""

# Generated at 2022-06-23 19:21:06.992267
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:21:08.978346
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()

# Generated at 2022-06-23 19:21:11.557953
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True

# Test format_headers() method

# Generated at 2022-06-23 19:21:13.780343
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**{'headers': {'sort': True}})
    assert formatter.enabled


# Generated at 2022-06-23 19:21:24.413852
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head = 'HTTP/1.1 200 OK\r\n' \
           'Server: nginx\r\n' \
           'Date: Wed, 11 Apr 2018 06:08:41 GMT\r\n' \
           'Content-Type: application/json\r\n' \
           'Content-Length: 2\r\n' \
           'Last-Modified: Wed, 11 Apr 2018 06:08:41 GMT\r\n' \
           'Connection: keep-alive\r\n' \
           'ETag: "5acc192d-2"\r\n' \
           'Accept-Ranges: bytes\r\n' \
           '\r\n'
    head1 = 'HTTP/1.1 200 OK\r\n' \
            'Server: nginx\r\n' \
           

# Generated at 2022-06-23 19:21:27.883757
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import json
    # Given
    options = {'json': {'indent': 4}}
    headersFormatter = HeadersFormatter(format_options=options)

    # When
    actual = headersFormatter.format_options

    # Then
    assert actual == options



# Generated at 2022-06-23 19:21:31.799947
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test no params
    head = HeadersFormatter()
    assert isinstance(head, HeadersFormatter)
    assert isinstance(head, FormatterPlugin)

if __name__ == '__main__':
    test_HeadersFormatter()

# Generated at 2022-06-23 19:21:37.219755
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test instantiation
    testClass = HeadersFormatter()
    assert isinstance(testClass, HeadersFormatter)

    # Test that the super.__init__ method was properly executed
    assert testClass.format_options['headers']['sort'] == True

    # Test that:
    #   1 - The 'enabled' property was properly set based on the format_options
    #   2 - The 'enabled' property is now true
    assert testClass.enabled == True


# Generated at 2022-06-23 19:21:48.732310
# Unit test for constructor of class HeadersFormatter

# Generated at 2022-06-23 19:21:58.535371
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    test_headers_str = '''GET / HTTP/1.1
Host: localhost:5000
User-Agent: HTTPie/0.9.8
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive'''

    test_headers_str_formatted = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:5000
User-Agent: HTTPie/0.9.8'''

    headers_formatter = HeadersFormatter()

    # Exercise
    formatted_headers_str = headers_formatter.format_headers(test_headers_str)

    # Verify
    assert formatted_headers_str == test_headers_str_formatted



# Generated at 2022-06-23 19:22:09.865452
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Cache-Control: max-age=0, private, must-revalidate
Connection: close
Content-Length: 78
Content-Type: application/json
Date: Mon, 20 May 2019 02:49:57 GMT
ETag: "912f36c017dd1864c8f7fa01b58a73ea"
Server: WEBrick/1.3.1 (Ruby/2.6.0/2018-12-25)
X-Request-Id: ef3bc73e-9a0e-4a06-8680-0c8b0c02c118
X-Runtime: 0.002912
X-Xss-Protection: 1; mode=block
'''

# Generated at 2022-06-23 19:22:10.381395
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter

# Generated at 2022-06-23 19:22:13.274944
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']



# Generated at 2022-06-23 19:22:14.354017
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    return

# Generated at 2022-06-23 19:22:16.099019
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled == False

# Generated at 2022-06-23 19:22:18.233390
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options['headers']['sort']


# Generated at 2022-06-23 19:22:24.100506
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def _test(headers):
        formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
        assert formatter.format_headers(headers) == headers1

    headers1 = '''\
HTTP/1.0 200 OK
Sorted: one
Unsorted: two
Unsorted: one
Sorted: two
'''
    headers2 = '''\
HTTP/1.0 200 OK
Unsorted: two
Unsorted: one
Sorted: one
Sorted: two
'''
    _test(headers2)


# Generated at 2022-06-23 19:22:33.392160
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit testing of method format_headers of class HeadersFormatter
    """
    formatter = HeadersFormatter()
    res = formatter.format_headers('\n'.join([
       "HTTP/1.1 200 OK",
       "Content-Type: application/json",
       "Date: Thu, 13 Oct 2016 02:05:50 GMT",
       "Content-Length: 2",
       "",
       '{}',
    ]))
    expected = '\n'.join([
        "HTTP/1.1 200 OK",
        "Content-Length: 2",
        "Content-Type: application/json",
        "Date: Thu, 13 Oct 2016 02:05:50 GMT",
        "",
        '{}'
    ])
    assert expected == res



# Generated at 2022-06-23 19:22:37.052300
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class T(FormatterPlugin):
        format_options = {}

    with pytest.raises(AssertionError):
        HeadersFormatter(format_options=T.format_options)

# Generated at 2022-06-23 19:22:39.770006
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == False

# Generated at 2022-06-23 19:22:42.086502
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()
    assert isinstance(instance, FormatterPlugin)


# Generated at 2022-06-23 19:22:46.244760
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled

    formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert not formatter.enabled


# Generated at 2022-06-23 19:22:57.918184
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_raw = "HTTP/1.0 200 OK\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate, compress\r\nAccept-Language: en\r\nDNT: 1\r\nReferer: http://localhost:5000/test\r\nUser-Agent: HTTPie/0.9.8\r\nConnection: keep-alive\r\nContent-Length: 0"
    headers_formatted = formatter.format_headers(headers_raw)

# Generated at 2022-06-23 19:23:00.057547
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled



# Generated at 2022-06-23 19:23:05.833705
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fh = HeadersFormatter()
    s = 'Content-Length: 6\r\nLocation: /\r\nHeader: One\r\nHeader: Two\r\n'
    s_correct = 'Content-Length: 6\r\nHeader: One\r\nHeader: Two\r\nLocation: /\r\n'
    assert fh.format_headers(s) == s_correct


# Generated at 2022-06-23 19:23:12.593881
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_headers = """
POST / http/1.1
Authorization: Bearer AAA
X-Custom-Header-1: custom value 1
X-Custom-Header-2: custom value 2
Accept: application/json
Accept: text/plain
"""
    actual_headers = formatter.format_headers(input_headers)
    expected_headers = """
POST / http/1.1
Accept: application/json
Accept: text/plain
Authorization: Bearer AAA
X-Custom-Header-1: custom value 1
X-Custom-Header-2: custom value 2
"""
    assert actual_headers == expected_headers

# Generated at 2022-06-23 19:23:15.480055
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']



# Generated at 2022-06-23 19:23:20.070805
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    python -m pytest tests/test_HeadersFormatter.py::test_HeadersFormatter
    """
    # test __init__
    fp = HeadersFormatter(content_type='application/json', format_options={'headers':{'sort': True}})
    assert fp.enabled == True
    assert fp.content_type == 'application/json'



# Generated at 2022-06-23 19:23:24.166938
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Calling constructor of class HeadersFormatter for testing.
    headers_formatter = HeadersFormatter(format_options={'headers_sort': 'True'})
    assert isinstance(headers_formatter, HeadersFormatter)
    assert headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:23:25.671231
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Unit tests 

# Generated at 2022-06-23 19:23:27.871394
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    headersformatter = HeadersFormatter(format_options = {'headers' : {'sort' : True}})
    assert headersformatter.enabled == True

# Generated at 2022-06-23 19:23:29.424798
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options = {'sort':False})


# Generated at 2022-06-23 19:23:33.435819
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "X-User-Name: ant\r\nX-User-Age: 100\r\n"
    assert HeadersFormatter().format_headers(headers) == "X-User-Age: 100\r\nX-User-Name: ant\r\n"

# Generated at 2022-06-23 19:23:35.695375
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hp = HeadersFormatter()
    assert hp.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:23:38.577378
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(pretty=False)
    headers = formatter.format_headers(format_options['headers']['test_string'])
    assert headers == format_options['headers']['test_string_expected']

# Generated at 2022-06-23 19:23:40.145405
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
# Test for 'format_headers(headers: str) -> str' method

# Generated at 2022-06-23 19:23:49.286621
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = '''\
'''
    output = h.format_headers(headers)
    assert output == headers

    headers = '''\
HTTP/1.1 200 OK
A: 1
Foo: 1
Foo: 2
A: 2
B: 1
C: 1
'''
    output = h.format_headers(headers)
    expected_output = '''\
HTTP/1.1 200 OK
A: 1
A: 2
B: 1
C: 1
Foo: 1
Foo: 2
'''
    assert output == expected_output

    headers = '''\
Foo: 1
Foo: 2
A: 1
A: 2
B: 1
C: 1
'''
    output = h.format_headers(headers)
    expected_output

# Generated at 2022-06-23 19:23:59.532578
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()


# Generated at 2022-06-23 19:24:02.066473
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter(sort=True)
    assert fmt.enabled == True
    assert isinstance(fmt, HeadersFormatter)



# Generated at 2022-06-23 19:24:11.367207
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Given the following input of HTTP headers
    # and the constant that defines the
    # format options for headers
    test_headers = '''GET /foo HTTP/1.1
Host: example.com
User-Agent: httpie/0.9.8
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
'''
    test_headers_format_options = {
        'headers': {
            'sort': False
        },
        'compact': False
    }
    # When the __init__ function is called with the input headers
    # and the constant defining the format options
    # Then it creates an instance of the class HeadersFormatter
    # with the headers sorted in ascending order by header name
    # and the headers format options

# Generated at 2022-06-23 19:24:19.621733
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    fmt.format_options['headers']['sort'] = True
    headers = '''\
GET / HTTP/1.1
Connection: keep-alive
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.9
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''
    assert fmt.format_headers(headers) == expected

# Generated at 2022-06-23 19:24:29.643382
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # With-proxy
    headers = """
        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        Host: httpbin.org
        User-Agent: HTTPie/1.0.2

        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate
        Connection: keep-alive
        Host: httpbin.org
        User-Agent: HTTPie/1.0.2
        Proxy-Authorization: Basic dXNlcjpwYXNz
        """

# Generated at 2022-06-23 19:24:37.368871
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print('Unit test 🔨  -  test_HeadersFormatter_format_headers()  -  FormatterPlugin.py')
    h = HeadersFormatter()
    o1 = '# Headers: \r\n' \
         '# \r\n' \
         '#   Accept: */*\r\n' \
         '#   User-Agent: HTTPie/0.11.0-dev\r\n' \
         '#   Accept-Encoding: gzip, deflate\r\n' \
         '#   Connection: keep-alive\r\n' \
         '#   Host: httpbin.org\r\n' \
         '\r\n'

# Generated at 2022-06-23 19:24:39.536776
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()

    assert headers_formatter.format_options is not None
    assert headers_formatter.format_options['headers']['sort'] is True
    assert headers_formatter.enabled is True


# Generated at 2022-06-23 19:24:48.609376
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_1 = '\n'.join([
        'HTTP/1.1 200 OK',
        'Server: nginx/1.10.1',
        'Date: Fri, 23 Jun 2017 14:05:59 GMT',
        'Content-Type: application/json',
        'Transfer-Encoding: chunked',
        'Connection: keep-alive',
        'X-Powered-By: PHP/7.1.4-1~ubuntu14.04.1+deb.sury.org+1',
        'Cache-Control: no-cache',
        'X-Debug-Token: d96e19',
        'X-Debug-Token-Link: http://localhost/_profiler/d96e19',
        'Name: Luke Skywalker',
        'Height: 172'
    ])

# Generated at 2022-06-23 19:24:51.621534
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    p = HeadersFormatter()
    assert not p.enabled
    assert p.format_options == { 'headers': { 'sort': False } }


# Generated at 2022-06-23 19:25:01.199601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_string = """
    HTTP/1.1 200 OK
    Cookie: a=b;
    Set-Cookie: c=d; path=/
    Content-Type: text/html; charset=UTF-8
    Set-Cookie: a=b
    Server: nginx
    """
    headers_string_expected = """
    HTTP/1.1 200 OK
    Content-Type: text/html; charset=UTF-8
    Cookie: a=b;
    Set-Cookie: c=d; path=/
    Set-Cookie: a=b
    Server: nginx
    """
    headers_string_formatted = formatter.format_headers(headers_string.strip())
    assert headers_string_formatted == headers_string_expected.strip()



# Generated at 2022-06-23 19:25:02.587784
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled


# Generated at 2022-06-23 19:25:11.669364
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Tue, 21 Jun 2016 09:16:11 GMT
Server: Apache
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
Content-Encoding: deflate
Vary: Accept-Encoding
Content-Length: 30
Connection: close
Content-Type: text/html; charset=UTF-8

'''
    HeadersFormatter().format_headers(headers) == headers

# Generated at 2022-06-23 19:25:19.678300
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    expected = '''HTTP/1.1 200 OK
Accept-Ranges: bytes
Age: 12
Cache-Control: max-age=3600
Content-Type: text/html; charset=UTF-8
Date: Tue, 14 May 2019 10:18:20 GMT
Etag: "1541025663"
Expires: Tue, 14 May 2019 11:18:20 GMT
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (ewr/15BD)
X-Cache: HIT
Content-Length: 1270
'''
    assert formatter.format_headers(expected) == expected

# Generated at 2022-06-23 19:25:25.069676
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Type: text/plain; charset=utf-8
X-Custom-Header: abc
X-Custom-Header: def
"""
    expected_headers = """\
Content-Type: text/plain; charset=utf-8
X-Custom-Header: def
X-Custom-Header: abc
"""
    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:25:34.488943
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test unit for method format_headers of class HeadersFormatter
    """

    # Sends a request to the server
    response = requests.get(url)

    # Check if request is OK
    if response.status_code == 200:

        # Get the response's headers
        headers = response.headers

        # Initialize a new object of the class HeadersFormatter
        headerFormatter = HeadersFormatter()

        # Format the headers
        headersFormated = headerFormatter.format_headers(headers)

        # Check if response headers is formated
        assert re.match("'^.+:.+$'", headersFormated)

# Generated at 2022-06-23 19:25:40.622261
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Using a real instance of HeadersFormatter
    headers_formatter = HeadersFormatter()

    # The headers list is sorted
    headers = headers_formatter.format_headers('''\
HTTP/1.1 200 OK
Content-type: application/json
Content-length: 8
Connection: keep-alive
Date: Mon, 28 Sep 2020 13:35:14 GMT
Content-type: application/json
Content-length: 8
Connection: keep-alive
Date: Mon, 28 Sep 2020 13:35:14 GMT
''')

# Generated at 2022-06-23 19:25:45.530973
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers="""\
POST /post HTTP/1.1
Content-Type: application/x-www-form-urlencoded; charset=utf-8
User-Agent: HTTPie/0.9.3
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 42

"""
    expected="""\
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 42
Content-Type: application/x-www-form-urlencoded; charset=utf-8
User-Agent: HTTPie/0.9.3

"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-23 19:25:51.455490
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_string = '''\
GET /post/1 HTTP/1.1
Host: test.com
Accept: application/json, text/javascript
Content-Type: application/json
Cookie: key1=value1; key2=value2
Connection: close

'''

    sorted_header_string = '''\
GET /post/1 HTTP/1.1
Accept: application/json, text/javascript
Content-Type: application/json
Cookie: key1=value1; key2=value2
Connection: close
Host: test.com

'''

    headers = HeadersFormatter()
    assert headers.format_headers(header_string) == sorted_header_string

# Generated at 2022-06-23 19:25:52.159951
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # _ = HeadersFormatter({})
    assert True


# Generated at 2022-06-23 19:26:01.502093
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Date: Sat, 08 Jun 2013 10:11:12 GMT\r\n' \
              'Content-Length: 100\r\n' \
              'Content-Type: text/html\r\n' \
              '\r\n' \
              '...'

    expected = expected = 'HTTP/1.1 200 OK\r\n' \
                          'Content-Length: 100\r\n' \
                          'Content-Type: text/html\r\n' \
                          'Date: Sat, 08 Jun 2013 10:11:12 GMT\r\n' \
                          '\r\n' \
                          '...'

    assert expected == HeadersFormatter().format_headers(headers)



# Generated at 2022-06-23 19:26:11.109879
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h1 = '''\
User-Agent: HTTPie/0.9.8
Accept-Encoding:  gzip, deflate
Connection: keep-alive
Host: localhost:8080
Content-Length: 2
Accept: */*
Content-Type: application/json

    '''
    h2 = '''\
Accept: */*
Accept-Encoding:  gzip, deflate
Content-Length: 2
Content-Type: application/json
Connection: keep-alive
Host: localhost:8080
User-Agent: HTTPie/0.9.8

    '''
    formatter = HeadersFormatter()
    assert formatter.format_headers(h1) == h2


# Generated at 2022-06-23 19:26:21.709763
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    assert formatter.format_headers(None) is None

    print(formatter.format_headers(headers=None))

    # headers must be of type str
    with pytest.raises(TypeError):
        formatter.format_headers(headers=[])
    with pytest.raises(TypeError):
        formatter.format_headers(headers=1)

    # headers must be a multi line string
    with pytest.raises(ValueError):
        formatter.format_headers(headers='abc')

    # no headers, is this a bug?
    with pytest.raises(ValueError):
        formatter.format_headers(headers='\r\n')

    # empty header value

# Generated at 2022-06-23 19:26:24.217349
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:26:32.988974
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter(
                format_options=dict(headers=dict(sort=True)))
    headers = fmt.format_headers('HTTP/1.1 200 OK\r\n'
    'Server: nginx/1.14.0 (Ubuntu)\r\n'
    'Content-Type: application/json\r\n'
    'Content-Length: 18\r\n'
    'Connection: keep-alive\r\n'
    'Date: Mon, 16 Sep 2019 21:58:17 GMT\r\n'
    '\r\n'
    '{"id": 1, "name": "A green door"}'
    )
    # prints true if test passes
    print(headers == headers)

test_HeadersFormatter_format_headers()

# Generated at 2022-06-23 19:26:36.970599
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

	# Instance of HeadersFormatter is created
	formatter = HeadersFormatter(format_options={'headers':{'sort': True}})
	assert isinstance(formatter, HeadersFormatter)



# Generated at 2022-06-23 19:26:46.572196
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Returns empty headers if received empty headers
    assert HeadersFormatter().format_headers('') == ''

    # Returns headers with relative order of multiple headers
    # with the same name retained
    assert HeadersFormatter().format_headers(\
    '''GET / HTTP/1.1
    Accept-Encoding: gzip
    Cache-Control: no-cache
    Cache-Control: no-store
    Connection: keep-alive
    Content-Length: 0''') == \
    '''GET / HTTP/1.1
    Accept-Encoding: gzip
    Cache-Control: no-cache
    Cache-Control: no-store
    Connection: keep-alive
    Content-Length: 0'''

    # Returns headers ordered by name

# Generated at 2022-06-23 19:26:48.179719
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert callable(HeadersFormatter)


# Generated at 2022-06-23 19:26:57.487031
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = '''GET http://example.org HTTP/1.1
User-Name: John Doe
Content-Type: application/json
User-Name: Jane Doe
Content-Length: 0
Connection: close
Host: example.org
'''.splitlines()

    headers = '\r\n'.join(lines)
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers) == \
        '''GET http://example.org HTTP/1.1
Content-Length: 0
Content-Type: application/json
Connection: close
Host: example.org
User-Name: John Doe
User-Name: Jane Doe
'''

# Generated at 2022-06-23 19:27:06.452837
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options['headers']['sort'] = True
    headers = ('HTTP/1.1 200 OK\r\n'
               'Server: example.org\r\n'
               'Content-Length: 600\r\n'
               'Content-Type: text/html; charset=utf-8\r\n'
               'Date: Mon, 23 Oct 2017 18:25:43 GMT\r\n'
               '\r\n'
               'text')

# Generated at 2022-06-23 19:27:14.080828
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Date: Tue, 12 Feb 2019 18:48:28 GMT
Server: Apache
Last-Modified: Sun, 04 Feb 2018 00:00:14 GMT
ETag: "d54e-56d6ac68f6c00"
Accept-Ranges: bytes
Content-Length: 54958
Content-Type: text/html
'''
    formatted_headers = headers_formatter.format_headers(headers)

    assert formatted_headers.splitlines()[0] == 'HTTP/1.1 200 OK'

# Generated at 2022-06-23 19:27:16.460717
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_plugin = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_plugin.enabled



# Generated at 2022-06-23 19:27:17.388262
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:27:18.656298
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(header='test') != None


# Generated at 2022-06-23 19:27:26.055984
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_string = ('HTTP/1.1 200 OK\r\n'
            + 'Server: Werkzeug/0.11.15 Python/3.6.4\r\n'
            + 'Date: Tue, 01 Aug 2017 14:49:06 GMT\r\n'
            + 'Content-Type: application/json\r\n'
            + 'Content-Length: 18\r\n'
            + 'X-Header: A\r\n'
            + 'X-Header: B\r\n'
            + 'X-Header: C\r\n'
            + 'Connection: keep-alive\r\n\r\n'
            + '{"message": "hi"}')
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:27:34.574399
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers("""\
HTTP/1.1 200 OK
Accept: *
Cache-Control: no-cache
Cookie: sessionid=123
Content-Language: en-US
Content-Type: application/json
Set-Cookie: sessionid=123
""")
    expected = """\
HTTP/1.1 200 OK
Accept: *
Cache-Control: no-cache
Cookie: sessionid=123
Content-Language: en-US
Content-Type: application/json
Set-Cookie: sessionid=123
"""
    assert result == expected


# Generated at 2022-06-23 19:27:43.461636
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # initialise object of class HeadersFormatter
    obj = HeadersFormatter(**{
        'format_options': {'headers': {'sort': True}},
        'session': None
    })
    # compare expected output with output of method format_headers
    assert obj.enabled == True

# Generated at 2022-06-23 19:27:48.437168
# Unit test for constructor of class HeadersFormatter

# Generated at 2022-06-23 19:27:51.701120
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options['headers']['sort']


# Generated at 2022-06-23 19:27:55.464194
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    actual_result = HeadersFormatter()
    expected_result = None
    assert actual_result == expected_result


# Generated at 2022-06-23 19:28:04.782022
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    test_value_1 = formatter.format_headers(
        """\
Content-Length: 1357
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.2
\r\n"""
    )
    test_value_2 = formatter.format_headers(
        """\
Content-Length: 1357
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Type: application/json
Host: httpbin.org
Content-Type: text/html
User-Agent: HTTPie/0.9.2
\r\n"""
    )

# Generated at 2022-06-23 19:28:05.570511
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeaderFormatter()


# Generated at 2022-06-23 19:28:08.633129
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # set up test
    args = {
        'format': 'headers.sort',
    }
    formatter = HeadersFormatter(**args)
    # check values
    assert formatter.format_options == {'headers': {'sort': True}}
    assert formatter.enabled == True



# Generated at 2022-06-23 19:28:09.921204
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(parse_options={'headers': {'sort': True}})


# Generated at 2022-06-23 19:28:16.212628
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers('Content-type: blah\r\nAccept: blah\r\nAccept: blah\r\nAccept: blah')
    assert result == 'Content-type: blah\r\nAccept: blah\r\nAccept: blah\r\nAccept: blah'

    # Order multiple headers of the same name
    result = formatter.format_headers('Content-type: blah\r\nContent-type: blah\r\nContent-type: blah')
    assert result == 'Content-type: blah\r\nContent-type: blah\r\nContent-type: blah'

    # Order multiple headers of different name

# Generated at 2022-06-23 19:28:19.811246
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test instantiation
    headers_formatter = HeadersFormatter()
    assert headers_formatter # Test __init__(self, **kwargs)


# Generated at 2022-06-23 19:28:28.214107
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    result = headers_formatter.format_headers("""GET / HTTP/1.1
Host: httpbin.org
Content-Length: 1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 1
Content-Type: application/json
User-Agent: HTTPie""")

    assert result == """GET / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 1
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie"""

# Generated at 2022-06-23 19:28:33.474474
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = """\
GET / HTTP/1.1
Accept: */*
Content-Type: application/json
Content-Type: application/json; charset=utf-8

{}
"""
    formatter = HeadersFormatter()
    actual = formatter.format_headers(expected)
    assert actual == expected


# Generated at 2022-06-23 19:28:37.639857
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Tests for the constructor of class HeadersFormatter
    """
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == False
    assert formatter.enabled == False



# Generated at 2022-06-23 19:28:39.490589
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Expect: No error is raised
    obj = HeadersFormatter(arg='test')



# Generated at 2022-06-23 19:28:42.430989
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Server: nginx
Content-Type: text/html; charset=utf-8
Content-Length: 20
"""
    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Length: 20
Content-Type: text/html; charset=utf-8
Server: nginx
"""

# Generated at 2022-06-23 19:28:43.446377
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()

    assert headers_formatter.enabled is True


# Generated at 2022-06-23 19:28:52.577045
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = FormatterPlugin()
    headers = HeadersFormatter()
    headers.format_options = formatter.format_options
    headers.format_options['headers']['sort'] = True
    v = '''\
HTTP/1.1 200 OK
X-Foo: foo
X-Bar: bar
X-Foo: baz

'''
    assert headers.format_headers(v) == '''\
HTTP/1.1 200 OK
X-Bar: bar
X-Foo: foo
X-Foo: baz

'''

# Generated at 2022-06-23 19:29:00.641538
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter
    """

# Generated at 2022-06-23 19:29:08.731123
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ''.join(
    [
        'HTTP/1.1 200 OK\r\n',
        'Transfer-Encoding: chunked\r\n',
        'Expires: -1\r\n',
        'Server: Microsoft-IIS/10.0\r\n',
        'Cache-Control: no-store\r\n',
        'Set-Cookie:',
        ' cookie1=123; path=/; HttpOnly,',
        ' cookie2=456; path=/; HttpOnly\r\n',
        'Date: Wed, 02 Oct 2019 13:18:12 GMT\r\n'
    ])

# Generated at 2022-06-23 19:29:15.466434
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    # prepare sample data

# Generated at 2022-06-23 19:29:23.569355
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers("GET / HTTP/1.1\r\nAccept: application/json\r\nAccept-Encoding: gzip, deflate\r\nHost: localhost:3000\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n") == "GET / HTTP/1.1\r\nAccept: application/json\r\nAccept-Encoding: gzip, deflate\r\nHost: localhost:3000\r\nUser-Agent: HTTPie/0.9.9\r\n"

