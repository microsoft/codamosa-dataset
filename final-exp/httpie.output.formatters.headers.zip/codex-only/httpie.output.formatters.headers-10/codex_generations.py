

# Generated at 2022-06-23 19:19:32.768879
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert (HeadersFormatter.format_headers(
        '''\r\n
            Date: Tue, 18 Aug 2009 12:28:53 GMT\r\n
            Server: Apache\r\n
            Content-Length: 88\r\n
            Content-Type: text/html\r\n
            X-Pad: avoid browser bug\r\n
        '''
    )
        ==
        '''\r\n
            Date: Tue, 18 Aug 2009 12:28:53 GMT\r\n
            Content-Length: 88\r\n
            Content-Type: text/html\r\n
            Server: Apache\r\n
            X-Pad: avoid browser bug\r\n
        '''
    )

    # Multiple headers with the same name are sorted by the order of the first
    # occurrence of that header

# Generated at 2022-06-23 19:19:39.519811
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = '''Connection: close
User-Agent: httpie/0.9.9
Host: localhost:5000
Accept-Encoding: gzip, deflate
Accept: */*'''
    headers_formatter = HeadersFormatter(headers=headers,
                                         format_options={'headers': {'sort': True}})
    assert headers_formatter.format_headers(headers) == headers


# Generated at 2022-06-23 19:19:47.821652
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

    # test method with 1 header
    actual = f.format_headers('HTTP/1.1 200 Ok\r\nHost: api.github.com\r\n')
    expected = 'HTTP/1.1 200 Ok\r\nHost: api.github.com\r\n'
    assert actual == expected

    # test method with multiple headers
    actual = f.format_headers(
        'HTTP/1.1 200 Ok\r\nHost: api.github.com\r\n'
        'Accept: application/vnd.github.v3+json\r\n'
        'Content-type: application/json\r\n')
    expected = 'HTTP/1.1 200 Ok\r\nHost: api.github.com\r\n'

# Generated at 2022-06-23 19:19:57.526763
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    n = HeadersFormatter()

# Generated at 2022-06-23 19:20:05.391526
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_string = 'HTTP/1.1 200 OK\r\n' \
        'Date: Wed, 01 Jul 2020 17:34:05 GMT\r\n' \
        'Connection: keep-alive\r\n' \
        'Transfer-Encoding: chunked\r\n' \
        'Server: gunicorn/20.0.4\r\n' \
        'X-Frame-Options: DENY\r\n' \
        'Content-Type: application/json\r\n' \
        'Access-Control-Allow-Origin: *\r\n' \
        'Allow: POST, OPTIONS\r\n\r\n'

# Generated at 2022-06-23 19:20:13.933227
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = """\
HTTP/1.0 200 OK
Content-Type: text/plain;charset=utf-8
X-Amzn-Trace-Id: amzn-request-id
Host: localhost
My-Weird-Header: foo bar

"""

    expected_headers = """\
HTTP/1.0 200 OK
Content-Type: text/plain;charset=utf-8
Host: localhost
My-Weird-Header: foo bar
X-Amzn-Trace-Id: amzn-request-id

"""

    assert formatter.format_headers(headers) == expected_headers


# Generated at 2022-06-23 19:20:25.738930
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:20:34.034836
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    headers = 'Content-Type: application/json\r\nX-Authorization: token wxedcba\r\n'
    expected = 'Content-Type: application/json\r\nX-Authorization: token wxedcba\r\n'
    actual = headersFormatter.format_headers(headers)
    assert actual == expected

    headers = 'Content-Type: application/json\r\nX-Authorization: token qwerty\r\n'
    expected = 'Content-Type: application/json\r\nX-Authorization: token qwerty\r\n'
    actual = headersFormatter.format_headers(headers)
    assert actual == expected


# Generated at 2022-06-23 19:20:45.846280
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for format_headers
    """

    # Test existing headers
    hf = HeadersFormatter(format_options={"headers":{"sort":True}})
    headers = "HTTP/1.1 200 OK\r\n" + \
              "Content-Type: application/json\r\n" + \
              "Accept: application/json\r\n" + \
              "Content-Length: 100\r\n"+ \
              "Accept-Language: en\r\n"+ \
              "Connection: keep-alive\r\n" + \
              "\r\n"

    result = hf.format_headers(headers)

# Generated at 2022-06-23 19:20:47.690040
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hdrs_formatter = HeadersFormatter()
    assert isinstance(hdrs_formatter, FormatterPlugin)


# Generated at 2022-06-23 19:20:50.063294
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    expected = {
        'headers': {
            'sort': False
        }
    }
    assert headers.format_options == expected


# Generated at 2022-06-23 19:20:51.441378
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    m = HeadersFormatter()
    assert m.enabled == True


# Generated at 2022-06-23 19:20:55.343858
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled is True
    assert formatter.format_headers('a: b\nc: d\nb: c') == 'a: b\nb: c\nc: d'

# Generated at 2022-06-23 19:21:02.401553
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\n'.join([
        'HTTP/1.1 204 No Content',
        'Content-Length: 0',
        'Server: Werkzeug/0.11.15 Python/3.6.1',
        'Date: Wed, 04 Apr 2018 11:58:59 GMT',
        'Connection: keep-alive'
    ])) == '\r\n'.join([
        'HTTP/1.1 204 No Content',
        'Content-Length: 0',
        'Connection: keep-alive',
        'Date: Wed, 04 Apr 2018 11:58:59 GMT',
        'Server: Werkzeug/0.11.15 Python/3.6.1',
    ])

# Generated at 2022-06-23 19:21:09.529592
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

    # Format headers
    headers = '''
HTTP/1.1 200 OK
Content-Encoding: gzip
Content-Length: 575
Content-Type: application/json
Date: Fri, 31 Mar 2017 05:39:37 GMT
Etag: W/"23b-17a5a5a5c5b5"
Server: nginx/1.10.3
Vary: Origin
X-Rate-Limit-Limit: 1000
X-Rate-Limit-Remaining: 999
X-Rate-Limit-Reset: 1490648788
X-Xss-Protection: 1; mode=block
'''
    headers = hf.format_headers(headers)

# Generated at 2022-06-23 19:21:16.214220
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers("""\
HTTP/1.1 200 OK
content-type: text/html; charset=utf-8
Content-Length: 123
x-foo: bar
x-baz: quux
x-foo: gazonk
""") == """\
HTTP/1.1 200 OK
content-type: text/html; charset=utf-8
Content-Length: 123
x-baz: quux
x-foo: bar
x-foo: gazonk
"""

# Generated at 2022-06-23 19:21:19.247417
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**{'format_options': {'headers': {'sort': True}, 'headers': {'sort': True}}})
    assert formatter.format_options['headers']['sort'] == True
    assert formatter.format_options['headers'] == {'sort': True}


# Generated at 2022-06-23 19:21:21.443799
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled is False
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled is True

# Generated at 2022-06-23 19:21:23.118144
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:21:28.086961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ('foo:bar\n'
               'bar:baz\n'
               'foo:biz\n')
    expected = ('foo:bar\n'
                'foo:biz\n'
                'bar:baz\n')

    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-23 19:21:35.169558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(sort_parameters=True, sort_headers=True)
    # check parameters and headers are sorted
    assert hf.format_headers('GET /?a=c&b=3&b=2 HTTP/2\r\nUser-Agent: httpie\r\nAccept-Language: en-US') == \
           'GET /?a=c&b=2&b=3 HTTP/2\r\nAccept-Language: en-US\r\nUser-Agent: httpie'
    # check relative header order is preserved

# Generated at 2022-06-23 19:21:37.405496
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:21:48.915829
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    frmt = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:21:59.091606
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import json
    import pytest
    url = 'http://httpbin.org/post'
    data = {
        'some': 'data',
        'number': 42
    }
    headers = {
        'User-Agent': 'foobar',
        'Content-Type': 'application/json'
    }
    # Note: the order of the headers still depends on the operating system
    expected = ''.join([
        'POST /post HTTP/1.1',
        'Host: httpbin.org',
        'User-Agent: foobar',
        'Content-Length: 26',
        'Content-Type: application/json',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        '',
        '{"number": 42, "some": "data"}',
        ''])
    actual

# Generated at 2022-06-23 19:22:10.201348
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    actual = formatter.format_headers(headers)
    expected = '\r\n'.join(sorted(raw_headers[1:], key=lambda h: h.split(':')[0]))
    assert actual == expected




# Generated at 2022-06-23 19:22:21.210202
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Call constructor and check that correct type is returned
    class HeadersFormatterTest(HeadersFormatter):  # noqa
        format_options = {}
    f = HeadersFormatterTest(format_options={})
    assert isinstance(f, HeadersFormatter)
    # Check that correct type is returned if no 'headers' section is given
    f = HeadersFormatter(format_options={})
    assert isinstance(f, HeadersFormatter)
    # Check that correct type is returned if no 'sort' option is given
    f = HeadersFormatter(format_options={'headers': {}})
    assert isinstance(f, HeadersFormatter)
    # Check that correct type is returned if 'sort' option is given but false
    f = HeadersFormatter(format_options={'headers': {'sort': False}})


# Generated at 2022-06-23 19:22:25.307471
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hs = HeadersFormatter()
    assert hs.enabled == False
    try:
        hs.format_headers('header-a: value-a\nheader-b: value-b')
    except NotImplementedError:
        pass


# Generated at 2022-06-23 19:22:27.174439
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(foobar=None)
    assert formatter.enabled is False


# Generated at 2022-06-23 19:22:32.851705
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers(
        '''Content-Type: application/json
x-header: 1
x-header: 2
x-other-header: 1
X-Header: 3
X-Header: 4
''') == \
        '''Content-Type: application/json
X-Header: 3
X-Header: 4
x-header: 1
x-header: 2
x-other-header: 1
'''

# Generated at 2022-06-23 19:22:34.412638
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Unit test for constructor of class HeadersFormatter
    """
    headers_formatter = HeadersFormatter()



# Generated at 2022-06-23 19:22:36.330433
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']
    

# Generated at 2022-06-23 19:22:39.714973
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert type(headers_formatter) != None



# Generated at 2022-06-23 19:22:49.705328
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_string = "HTTP/1.1 200 OK\r\n" \
                   + "Host: localhost:8080\r\n" \
                   + "Connection: keep-alive\r\n" \
                   + "Content-Length: 26\r\n" \
                   + "Content-Type: text/plain; charset=utf-8\r\n" \
                   + "Date: Mon, 20 Apr 2020 13:45:36 GMT\r\n" \
                   + "Via: 1.1 vegur\r\n"

# Generated at 2022-06-23 19:22:55.027945
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.formatters import JSONFormatter
    from argparse import Namespace
    mapping={"headers": {"sort": True}}
    args=Namespace(json='json', stdin='stdin', verify='verify', proxies='proxies', max_redirects='max_redirects', timeout='timeout',
                headers='headers', auth='auth', download='download', files='files', data='data', form='form', output='output')
    json_fmt=JSONFormatter(format_options=mapping, args=args)
    assert HeadersFormatter(format_options=mapping, args=args).enabled==True

# Generated at 2022-06-23 19:23:00.992832
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    assert obj.format_headers('Host: httpbin.org\nAccept-Encoding: gzip, deflate\nAccept: */*\nConnection: keep-alive\nUser-Agent: HTTPie/2.2.0\n') == 'Host: httpbin.org\nUser-Agent: HTTPie/2.2.0\nAccept: */*\nAccept-Encoding: gzip, deflate\nConnection: keep-alive\n'

# Generated at 2022-06-23 19:23:10.557500
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:23:19.834273
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fp = HeadersFormatter()
    headers_str = '''\
GET / HTTP/1.1
Content-Type: image/jpeg
Accept: text/plain
Cookie: csrftoken=8e3e3ccd22c63787f6c1a87965672429; sessionid=d87ed0c8ecb5a5ddb7d4e0f4b8bc3cc4
Content-Length: 3000000
Host: httpbin.org:80
Connection: keep-alive
Accept-Encoding: gzip, deflate
User-Agent: SomeAgent/1.2.3
'''

# Generated at 2022-06-23 19:23:30.226927
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:23:32.595265
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter({'headers': {'sort': True}})
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:23:34.052556
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
   assert HeadersFormatter(sort=True)


# Generated at 2022-06-23 19:23:42.347619
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters import netstring_JSON;
    from httpie.compat import OrderedDict
    from httpie.plugins import FormatterPlugin
    testString = """\
    HTTP/1.1 200 OK
    Transfer-Encoding: chunked
    X-Content-Type-Options: nosniff
    Access-Control-Allow-Methods: HEAD, GET, POST, PUT, DELETE
    Vary: Origin
    Content-Type: application/json
    Access-Control-Allow-Origin: http://petstore.swagger.io
    Date: Fri, 17 Feb 2017 20:33:12 GMT
    X-Application-Context: application:8080
    Access-Control-Allow-Headers: Content-Type, api_key
    Connection: close
    """
   

# Generated at 2022-06-23 19:23:46.906429
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # headers contains 2 headers with the same name in different order
    header = 'Content-Type: application/json\nFoo: Bar\nFoo: Baz'
    # calling method format_headers will keep their order unchanged
    assert HeadersFormatter().format_headers(header) == 'Content-Type: application/json\nFoo: Bar\nFoo: Baz'

# Generated at 2022-06-23 19:23:56.984392
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_headers = """
Content-Length: 902
Content-Type: application/json
Connection: keep-alive
Content-Length: 903
Content-Type: application/json
Connection: keep-alive
Content-Length: 904
Content-Type: application/json
Connection: keep-alive
    """
    output_headers = formatter.format_headers(input_headers)
    assert output_headers == """
Content-Length: 902
Content-Length: 903
Content-Length: 904
Content-Type: application/json
Content-Type: application/json
Content-Type: application/json
Connection: keep-alive
Connection: keep-alive
Connection: keep-alive
    """

# Generated at 2022-06-23 19:24:04.569041
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options == {'headers': {'sort': False}}
    hf = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert hf.format_options == {'headers': {'sort': False}}
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.format_options == {'headers': {'sort': True}}
    hf = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert hf.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:24:06.530967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.formatters import BaseStringifier

    assert issubclass(HeadersFormatter, BaseStringifier)


# Generated at 2022-06-23 19:24:09.121272
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.enabled
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:24:19.694997
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test data
    headers = ('GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Connection: keep-alive\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
        '\r\n')
    # Expected result
    expected = ('GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Connection: keep-alive\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
        '\r\n')
    # Code to be tested

# Generated at 2022-06-23 19:24:22.122053
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	try:
		headerFormat = HeadersFormatter()
		assert headerFormat != None
	except:
		assert False


# Generated at 2022-06-23 19:24:31.669392
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:24:39.304871
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    GET / HTTP/1.1
    Host: httpbin.org
    Connection: keep-alive
    Cache-Control: max-age=0
    Accept-Encoding: gzip, deflate, br
    Accept-Language: en-US,en;q=0.8
    User-Agent: HTTPie/0.9.2
    Accept: */*
    '''
    headers = ''.join(headers.split())


# Generated at 2022-06-23 19:24:48.415394
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(session=object())

    # Case 1: Normal Case

# Generated at 2022-06-23 19:24:50.118461
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Unit tests for the format_headers method.

# Generated at 2022-06-23 19:24:59.866808
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_input = '''\
HTTP/1.1 200 OK
Cache-Control: max-age=600
Server: nginx
Connection: keep-alive
Vary: Cookie
Pragma: public
Content-Type: text/html; charset=UTF-8
Last-Modified: Mon, 09 May 2016 12:40:28 GMT
X-Frame-Options: SAMEORIGIN
ETag: "8b892c7-2623-530918d318aea"
Content-Length: 10435
X-XSS-Protection: 1; mode=block
'''


# Generated at 2022-06-23 19:25:09.176219
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter({})
    headers = """
HTTP/1.1 200 OK
Server: nginx
Date: Mon, 16 Mar 2015 18:06:27 GMT
Content-Type: application/json
Content-Length: 38
Connection: keep-alive
X-Runtime: 0.002287
"""
    assert formatter.format_headers(headers) == """
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 38
Content-Type: application/json
Date: Mon, 16 Mar 2015 18:06:27 GMT
Server: nginx
X-Runtime: 0.002287
"""

# Generated at 2022-06-23 19:25:13.360115
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class TestFormatter:
        format_options = {'headers': {'sort': True}}
        enabled = False
    
    test = TestFormatter()
    head = HeadersFormatter()
    assert test.format_options == head.format_options
    assert test.enabled == head.enabled


# Generated at 2022-06-23 19:25:20.716301
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case where headers are not sorted
    hp = HeadersFormatter()
    headers = """GET / HTTP/1.1
Content-Length: 5
Host: httpbin.org
X-Custom-Header: foo
Content-Type: application/json
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/1.0.0
"""
    expected = hp.format_headers(headers)
    actual = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 5
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/1.0.0
X-Custom-Header: foo
"""
    assert expected == actual
    # Case where multiple headers are present
    hp = HeadersFormatter()
   

# Generated at 2022-06-23 19:25:29.011158
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers('\r\n'.join([
        'Content-Type: application/json',
        'Content-Length: 123',
        'X-Foo: 1',
        'X-Foo: 2',
        'Content-Length: 321',
        'X-Foo: 3',
        '',
        '']))
    assert result == '\r\n'.join([
        'Content-Length: 123',
        'Content-Length: 321',
        'Content-Type: application/json',
        'X-Foo: 1',
        'X-Foo: 2',
        'X-Foo: 3',
        '',
        ''])

# Generated at 2022-06-23 19:25:31.573271
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = {'headers': {'sort': True}}
    headers_formatter = HeadersFormatter(options)
    assert headers_formatter.enabled == True

    options = {'headers': {'sort': False}}
    headers_formatter = HeadersFormatter(options)
    assert headers_formatter.enabled == False



# Generated at 2022-06-23 19:25:37.089692
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """\
HTTP/1.1 200 OK
Cookie: foo=bar
Set-Cookie: bar=foo
\r\n"""
    format_headers = formatter.format_headers(headers)
    assert format_headers == """\
HTTP/1.1 200 OK
Cookie: foo=bar
Set-Cookie: bar=foo
\r\n"""



# Generated at 2022-06-23 19:25:39.891637
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    hf.init()
    assert hf.format_options == {'headers': {'sort': True}}



# Generated at 2022-06-23 19:25:49.213012
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '''\
Host: localhost:8080
Connection: keep-alive
Pragma: no-cache
Cache-Control: no-cache
Accept: application/json, text/plain, */*
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8
'''

# Generated at 2022-06-23 19:25:50.234617
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-23 19:25:52.562110
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options['headers']['sort'] == False


# Generated at 2022-06-23 19:25:54.136134
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().__class__.__name__ == 'HeadersFormatter'

# Generated at 2022-06-23 19:25:56.657763
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(formatter, format_options=format_options)
    assert formatter.enabled is True


# Generated at 2022-06-23 19:25:58.595213
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().__init__(**kwargs)

# Generated at 2022-06-23 19:26:01.337134
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:26:09.840435
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Assert that HeadersFormatter is a child class of FormatterPlugin
    class ChildClass(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
    assert issubclass(HeadersFormatter, ChildClass)

    # Assert that HeadersFormatter object is an instance of class HeadersFormatter
    class_headers_formatter = HeadersFormatter()
    assert isinstance(class_headers_formatter, HeadersFormatter)

    # Assert that object instantiated from constructor of class HeadersFormatter
    # is of type dict
    assert type(class_headers_formatter.format_options) is dict



# Generated at 2022-06-23 19:26:15.505667
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = '''
GET /a HTTP/1.1
Host: example.com
Connection: close
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US,*
Cookie: key1=value1;key2=value2
Other: foo
X-Other: bar

'''.strip()

    expected_headers = '''
GET /a HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en-US,*
Connection: close
Cookie: key1=value1;key2=value2
Host: example.com
Other: foo
X-Other: bar

'''.strip()

    actual_headers = formatter.format_headers(headers)
    assert actual_headers == expected_

# Generated at 2022-06-23 19:26:17.372646
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf
    assert hf.enabled


# Generated at 2022-06-23 19:26:27.852142
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    object = HeadersFormatter()

    # Test case 1
    headers = '''\
HTTP/1.1 200 OK\r
Date: Sat, 04 Nov 2017 22:24:30 GMT\r
Server: Apache/2.4.7 (Ubuntu)\r
Content-Length: 24\r
Cache-Control: max-age=0, private, must-revalidate\r
Content-Type: application/json; charset=utf-8\r
X-Request-Id: 7a676c08-3e84-43d3-a7b0-e83c3de3d787\r
X-Runtime: 0.014519\r
Cache-Control: max-age=0, private, must-revalidate\r
'''

# Generated at 2022-06-23 19:26:28.299616
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:26:29.297663
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass



# Generated at 2022-06-23 19:26:31.084572
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(output_file=None, options=['--headers'])



# Generated at 2022-06-23 19:26:33.466134
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options == {"headers" : {"sort" : False}}


# Generated at 2022-06-23 19:26:40.213686
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Connection: keep-alive
Content-Type: application/json; charset=utf-8
Accept-Encoding: gzip, deflate
Accept: */*
Host: localhost:8888
User-Agent: HTTPie/1.0.0
Content-Length: 49
'''
    sut = HeadersFormatter()
    expected = '''\
'''
    actual = sut.format_headers(headers)
    assert expected == actual



# Generated at 2022-06-23 19:26:46.741671
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ['Header-A: Value-a', 'Header-b: Value-b',
             'Header-c: Value-c', 'Header-B: Value-d']
    expected = '\r\n'.join(['Content-Type: application/json',
                            'Header-A: Value-a',
                            'Header-B: Value-d',
                            'Header-b: Value-b',
                            'Header-c: Value-c'])
    assert HeadersFormatter().format_headers('\r\n'.join(lines)) == expected

# Generated at 2022-06-23 19:26:49.405800
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:26:52.627532
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Test constructor of class HeadersFormatter.
    """
    headers_formatter = HeadersFormatter()
    assert headers_formatter is not None


# Generated at 2022-06-23 19:27:00.426806
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST /path HTTP/1.1
Host: example.com
User-Agent: HTTPie/0.9.2
Content-Length: 7
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive

name=HTTPie
'''
    expected = '''\
POST /path HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 7
Host: example.com
User-Agent: HTTPie/0.9.2

name=HTTPie
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:27:08.294355
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(options=Options(headers={'sort': 'True'}))
    headers = formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nAccept: application/json\r\n')
    expected_headers = 'HTTP/1.1 200 OK\r\nAccept: application/json\r\nContent-Type: text/html; charset=utf-8\r\n'
    assert headers == expected_headers


# Generated at 2022-06-23 19:27:18.219639
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from tempfile import NamedTemporaryFile
    from textwrap import dedent
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins.formatter.headers import HeadersFormatter

    # Set up an instance of the plugin manager
    fpm = FormatterPluginManager()
    fpm.load_installed_plugins()
    # Get the headers formatter instance
    headers_formatter = fpm.get('headers')
    # Create a temp file to write the plugin output to
    with NamedTemporaryFile(suffix='.txt') as temp_file:
        # Format the headers using the formatter instance
        headers_formatter.start(temp_file.name, {'headers': {'sort': True}})
        # Write a request to the plugin instance

# Generated at 2022-06-23 19:27:25.961891
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nC: 1\r\nB: 2\r\nA: 3') == \
        'GET / HTTP/1.1\r\nA: 3\r\nB: 2\r\nC: 1'
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nA: 1\r\nA: 2\r\nA: 3') == \
        'GET / HTTP/1.1\r\nA: 1\r\nA: 2\r\nA: 3'

# Generated at 2022-06-23 19:27:28.219449
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x=HeadersFormatter()
    print(x.format_options)


# Generated at 2022-06-23 19:27:33.953147
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(ValueError):
        HeadersFormatter(indent=-1)
    with pytest.raises(ValueError):
        HeadersFormatter(width=-1)
    with pytest.raises(ValueError):
        HeadersFormatter(sort=None)
    with pytest.raises(ValueError):
        HeadersFormatter(indent=1, width=1)
    with pytest.raises(ValueError):
        HeadersFormatter(indent="1", width=1)
    with pytest.raises(ValueError):
        HeadersFormatter(indent=1, width="1")
    with pytest.raises(ValueError):
        HeadersFormatter(indent="1", width="1")
    with pytest.raises(ValueError):
        HeadersFormatter

# Generated at 2022-06-23 19:27:40.047391
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter({})
    # Testing if HeadersFormatter is indeed a Subclass of FormatterPlugin
    assert HeadersFormatter.__bases__ == (FormatterPlugin,)
    assert type(fmt.format_options) is dict
    assert type(fmt.format_options['headers']) is dict
    assert fmt.format_options['headers']['sort'] == False
    assert type(fmt.enabled) is bool
    assert fmt.enabled == False


# Generated at 2022-06-23 19:27:41.260301
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header = HeadersFormatter()
    assert header.enabled is True



# Generated at 2022-06-23 19:27:47.418966
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(
        stdin=io.BytesIO(b'{ "headers": { "sort": true } }'))
    assert f.enabled
    assert f.format_options['headers']['sort']

try:
    import pytest
except ImportError:
    pass

# Generated at 2022-06-23 19:27:58.622690
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    H = HeadersFormatter(format_options={'headers':{'sort': True}})
    assert H.format_headers("""\
HTTP/1.1 200 OK
Content-Length: 16
Content-Type: application/json
Connection: close
Date: Thu, 31 Oct 2019 21:15:42 GMT
""") == """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 16
Content-Type: application/json
Date: Thu, 31 Oct 2019 21:15:42 GMT
"""

# Generated at 2022-06-23 19:28:01.860384
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(headers={'sort': True})
    assert headers_formatter.enabled is True
    headers_formatter = HeadersFormatter(headers={'sort': False})
    assert headers_formatter.enabled is False


# Generated at 2022-06-23 19:28:06.161185
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    _kwargs = {'format_options': {'headers': {'sort': False}}}
    headers_formatter = HeadersFormatter(**_kwargs)
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:28:14.483616
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:28:16.618531
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test that there is no error
    assert HeadersFormatter()


# Unit tests for function format_headers in class HeadersFormatter

# Generated at 2022-06-23 19:28:22.393916
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """Accept-Encoding: gzip
Content-Length: 2
Connection: keep-alive
Content-Type: application/json
"""
    headers_expected = """Accept-Encoding: gzip
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
"""
    assert headers_formatter.format_headers(headers) == headers_expected

# Generated at 2022-06-23 19:28:28.682669
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "foo: bar\r\ncontent-type: text/plain\r\ntwo-words: header"
    expected = "foo: bar\r\ncontent-type: text/plain\r\ntwo-words: header"
    formatter = HeadersFormatter(format_options = {'headers' : {'sort' : True}})
    result = formatter.format_headers(headers)
    assert expected == result

# Unit tests

# Generated at 2022-06-23 19:28:31.075338
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    t = HeadersFormatter({'headers': {'sort': True}})
    assert t.enabled == True


# Generated at 2022-06-23 19:28:41.284011
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.format_headers(
        '''Content-Type: text/plain
        Date: Mon, 01 Jan 1990 00:00:00 GMT
        Transfer-Encoding: chunked
        X-Test: xyz
        Vary: Origin
        Vary: Accept
        Content-Encoding: gzip
        '''
    ) == '''Content-Type: text/plain
Date: Mon, 01 Jan 1990 00:00:00 GMT
Transfer-Encoding: chunked
X-Test: xyz
Vary: Origin
Vary: Accept
Content-Encoding: gzip
'''

# Generated at 2022-06-23 19:28:41.676724
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert 0

# Generated at 2022-06-23 19:28:47.171613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={
        "headers": {
            "sort": True
        }
    })
    headers = """\
HTTP/1.1 200 OK

Server: nginx
Date: Fri, 26 Jun 2020 08:36:31 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 46
Connection: keep-alive
Strict-Transport-Security: max-age=63072000
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
"""

# Generated at 2022-06-23 19:28:48.766327
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled


# Generated at 2022-06-23 19:28:51.395351
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    test_format = FormatterPlugin.__init__(HeadersFormatter(**kwargs), **kwargs)


# Generated at 2022-06-23 19:28:53.709472
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert f.enabled


# Generated at 2022-06-23 19:29:01.412854
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test for sort option of headers.
    """
    # From Python 3.8 the output of headers
    # is not sorted.
    from httpie.plugins import HeadersFormatter

    headers1 = '''Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 7
Content-Type: application/json
Host: localhost:5000
User-Agent: HTTPie/2.2.0
'''
    headers2 = '''Accept: */*
Connection: keep-alive
Content-Length: 7
Content-Type: application/json
Host: localhost:5000
User-Agent: HTTPie/2.2.0
Accept-Encoding: gzip, deflate
'''


# Generated at 2022-06-23 19:29:02.488284
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter(**{'format_options':{'headers':{'sort':False}}})

# Generated at 2022-06-23 19:29:12.960479
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__('a',)
    assert HeadersFormatter.__init__('a',**{})
    assert HeadersFormatter.__init__('a',format_options={})
    assert HeadersFormatter.__init__('a',**{'format_options': {'headers':{'sort':True}}})
    assert HeadersFormatter.__init__('a',**{'format_options': {'headers':{'sort':True}}})
    assert HeadersFormatter.__init__('a',**{'format_options': {'headers':{'sort':False}}})
    assert HeadersFormatter.__init__('a',**{'format_options': {'headers':{'sort':0}}})

# Generated at 2022-06-23 19:29:14.387318
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hdr = HeadersFormatter()
    assert hdr is not None


# Generated at 2022-06-23 19:29:16.500255
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-23 19:29:19.413671
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-23 19:29:22.760860
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {}
    format_options['headers'] = {}
    format_options['headers']['sort'] = True

    formatter = HeadersFormatter(format_options)
    assert formatter.enabled == True


# Generated at 2022-06-23 19:29:30.175848
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'AAA: 111\r\n'
        'BBB: 222\r\n'
        'AAA: 333\r\n'
        'CCC: 444\r\n'
    ) == (
        'HTTP/1.1 200 OK\r\n'
        'AAA: 111\r\n'
        'AAA: 333\r\n'
        'BBB: 222\r\n'
        'CCC: 444\r\n'
    )

