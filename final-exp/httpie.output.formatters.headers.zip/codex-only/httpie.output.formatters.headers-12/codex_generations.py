

# Generated at 2022-06-23 19:19:24.922565
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    result = HeadersFormatter(
        format_options={'headers': {'sort': True}},
        config={'default_options': {'headers': None}}
    )
    assert result.enabled
    assert result.prettify_headers == 'on-off'


# Generated at 2022-06-23 19:19:29.780003
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers("""\
HTTP/1.1 200 OK
Content-Type: text/plain
X-Custom: custom
X-Custom: custom2
X-Custom: custom3

""") == """\
HTTP/1.1 200 OK
X-Custom: custom
X-Custom: custom2
X-Custom: custom3
Content-Type: text/plain
"""

# Generated at 2022-06-23 19:19:41.537985
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:19:43.839329
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    actual = formatter.format_headers(headers_example)
    assert actual == headers_example_sorted


# Generated at 2022-06-23 19:19:49.258890
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Constructor for HeadersFormatter outputs True for enabled
    assert(HeadersFormatter(format_options = {'headers': {'sort': True}}).enabled)
    # Constructor for HeadersFormatter outputs False for not enabled
    assert(not HeadersFormatter(format_options = {'headers': {'sort': False}}).enabled)


# Generated at 2022-06-23 19:19:55.437291
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin

    # a = HeadersFormatter("ab")
    instance = FormatterPlugin("ab")
    print("\nCheck type and value of created class instance")
    print("Type is: " + str(type(instance)))
    print("Value is: " + str(instance))
    print("Enable is: " + str(instance.enabled))
    assert type(instance) == FormatterPlugin
    assert instance.enabled == False

# Generated at 2022-06-23 19:20:03.663711
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:20:12.009487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
User-Agent: HTTPie/1.0.3
X-API-Token: 123456
<<<<<<< HEAD
Content-Type: application/json
Accept: application/json
Cache-Control: no-cache
Accept-Encoding: gzip, deflate'''
    expected_headers = '''\
User-Agent: HTTPie/1.0.3
Accept: application/json
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Content-Type: application/json
X-API-Token: 123456'''
    assert HeaderFormatter().format_headers(headers) == expected_headers



# Generated at 2022-06-23 19:20:20.955501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Sample data
    headers_input = 'HTTP/1.1 200 OK\r\nHost: www.example.com\r\nUser-Agent: httpie\r\nAccept: */*\r\n\r\n'
    headers_output = 'HTTP/1.1 200 OK\r\nAccept: */*\r\nHost: www.example.com\r\nUser-Agent: httpie\r\n\r\n'
    # Initialise an instance of class HeadersFormatter
    headers_formatter = HeadersFormatter()
    # Unit test for method format_headers
    assert headers_formatter.format_headers(headers_input) == headers_output

# Generated at 2022-06-23 19:20:24.053222
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Unit test for constructor
    filename = 'test_HeadersFormatter_file.txt'
    requests_kwargs = {'headers': {'sort': False}, 'filter': {'status-code': {'sort': False}}}
    headers_formatter = HeadersFormatter(filename=filename, requests_kwargs=requests_kwargs)
    assert headers_formatter.filename == filename
    assert not headers_formatter.enabled



# Generated at 2022-06-23 19:20:33.172118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter().format_headers('\r\n'.join((
        'GET / HTTP/1.1',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.2',
        'Accept: application/json',
        'X-Custom-Header: foo',
        ''
    )))

# Generated at 2022-06-23 19:20:45.539928
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    'Host': 'httpbin.org'
    'Connection': 'keep-alive'
    'Content-Length': '17'
    'Content-Type': 'application/json'
    'Accept-Encoding': 'gzip, deflate'
    'Accept': '*/*'
    'User-Agent': 'HTTPie/0.9.9'
    'Dnt': '1'
    'Accept-Language': 'en-US,en;q=0.8'
    'Cookie': '__cfduid=da2d2d62a43874e6c1fad03f9a9ac9acb1480949158'
    'Origin': 'chrome-extension://fdmmgilgnpjigdojojpjoooidkmcomcm'
    '''

# Generated at 2022-06-23 19:20:54.749640
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    assert headers.format_headers(
        '''\
HTTP/1.1 200 OK
Content-Length: 5
Content-Type: text/plain; charset=utf-8
Content-Type: text/plain; charset=utf-8
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: close
User-Agent: HTTPie/0.9.8
''') == '''\
HTTP/1.1 200 OK
Accept-Encoding: gzip, deflate
Connection: close
Content-Length: 5
Content-Type: text/plain; charset=utf-8
Content-Type: text/plain; charset=utf-8
Host: httpbin.org
User-Agent: HTTPie/0.9.8
'''

# Generated at 2022-06-23 19:21:02.878058
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # test_headers = 'GET / HTTP/1.1\r\ntest: foo\r\nd: bar\r\nc: b\r\nb: a\r\na: c\r\n\r\n'
    test_headers = 'GET / HTTP/1.1\r\ntest: foo\r\nd: bar\r\nc: b\r\nb: a\r\na: c\r\n\r\n'

# Generated at 2022-06-23 19:21:07.432367
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Accept: */*
Content-Type: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2
'''
    assert (HeadersFormatter.format_headers(headers) == '''\
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
''')

# Generated at 2022-06-23 19:21:17.484189
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Host: localhost:5000
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive
Content-Length: 11
Content-Type: application/json
Cookie: cookie

'''
    headers_expected = '''Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Length: 11
Content-Type: application/json
Connection: keep-alive
Cookie: cookie
User-Agent: HTTPie/0.9.2

'''
    headers_actual = HeadersFormatter().format_headers(headers)
    assert headers_expected == headers_actual

# Generated at 2022-06-23 19:21:25.854175
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Accept: */*
User-Agent: HTTPie/1.0.3
Accept-Encoding: gzip, deflate, compress
Accept-Language: en-US,en;q=0.5
Content-Type: application/json"""

    # Setup
    headers_formatter = HeadersFormatter()

    # Exercise
    headers_sorted = headers_formatter.format_headers(headers)

    # Verify
    assert headers_sorted == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Accept-Language: en-US,en;q=0.5
Content-Type: application/json
User-Agent: HTTPie/1.0.3"""

    # Cleanup - none necessary

# Generated at 2022-06-23 19:21:27.355016
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    inst = HeadersFormatter()
    assert isinstance(inst, HeadersFormatter)


# Generated at 2022-06-23 19:21:29.077836
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']

# Generated at 2022-06-23 19:21:32.375759
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	
	# Constructor test
	headers_formatter = HeadersFormatter()
	assert headers_formatter.format_options['headers']['sort'] == False
	

# Generated at 2022-06-23 19:21:34.082040
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    rv = HeadersFormatter()
    assert rv.format_options['headers']['sort'] is True

# Generated at 2022-06-23 19:21:35.618698
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is False


# Generated at 2022-06-23 19:21:37.875083
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class MockHeaders():
        def get(self, key):
            return 'value'
    h = HeadersFormatter()
    assert h.format_headers(MockHeaders()) == 'value'

# Generated at 2022-06-23 19:21:40.050767
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Test constructor of HeadersFormatter class

    """
    m = HeadersFormatter(sort=True)
    assert type(m) == HeadersFormatter
    assert type(m.format_options) == dict



# Generated at 2022-06-23 19:21:48.350901
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    format_options = {
        'headers': {'sort': True},
        'body': {'sort': False, 'indent': 2},
        'unformatted': []
    }

    sut = HeadersFormatter(
        format_options=format_options,
        colors=None,
        style=None,
        is_terminal=True)

    assert sut.enabled == True
    assert sut.format_options == format_options
    assert sut.colors == None
    assert sut.style == None
    assert sut.is_terminal == True



# Generated at 2022-06-23 19:21:51.556016
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True

# Generated at 2022-06-23 19:21:57.755663
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Content-Length: 148',
        'Connection: keep-alive',
    ])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Length: 148',
        'Content-Type: application/json',
        'Connection: keep-alive',
    ])

# Generated at 2022-06-23 19:21:59.176018
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__name__ == 'HeadersFormatter'


# Generated at 2022-06-23 19:22:06.779107
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:22:10.308781
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    lines = f.format_headers('\r\nHeader-Two: a\r\nHeader-One: b')
    assert lines == '\r\nHeader-One: b\r\nHeader-Two: a'


# Generated at 2022-06-23 19:22:12.526536
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-23 19:22:22.778083
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatted_headers = HeadersFormatter().format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Server: Redis/4.0.8\r\n'
        'Date: Fri, 09 Jun 2017 17:06:36 GMT\r\n'
        'Connection: keep-alive\r\n'
        'Content-Type: text/plain\r\n'
        'Content-Length: 0\r\n'
        '\r\n')

# Generated at 2022-06-23 19:22:32.913725
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class MyHeadersFormatter(HeadersFormatter):
        def format_headers(self, headers: str) -> str:
            return super(MyHeadersFormatter, self).format_headers(headers)
    sc = MyHeadersFormatter()

# Generated at 2022-06-23 19:22:36.314665
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options= {'headers': {'sort': False}})
    assert HeadersFormatter(format_options= {'headers': {'sort': True}})


# Generated at 2022-06-23 19:22:42.269431
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual_output = HeadersFormatter().format_headers('HTTP/1.1 200 OK\r\n\r\n')
    expected_output = '''\
HTTP/1.1 200 OK\r
\r
'''
    assert actual_output == expected_output

# Generated at 2022-06-23 19:22:50.560005
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
b: 1
a: 2
b: 3
c: 4
'''
    headers_formatted = formatter.headers_formatter(headers)
    assert headers_formatted == '''\
HTTP/1.1 200 OK
a: 2
b: 1
b: 3
c: 4
'''



# Generated at 2022-06-23 19:23:01.562163
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_header = '''
    HTTP/1.1 200 OK
    Date: Thu, 10 Dec 2020 10:56:38 GMT
    Server: Apache/2.4.29 (Ubuntu)
    X-Powered-By: PHP/7.2.24
    X-Pingback: https://www.example.com/xmlrpc.php
    Link: <https://www.example.com/?p=233>; rel=shortlink
    Vary: Accept-Encoding
    Content-Encoding: gzip
    Content-Length: 20303
    Keep-Alive: timeout=5, max=100
    Connection: Keep-Alive
    Content-Type: text/html; charset=UTF-8
    '''
    # Get the result
    result = HeadersFormatter().format_headers(test_header)
    # Select

# Generated at 2022-06-23 19:23:11.013444
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    formatter = HeadersFormatter(format_options={"headers": {"sort": True}})

    # Exercise
    format_headers = formatter.format_headers

    # Verify
    assert format_headers('''.
'''.strip()) == '''\
'''.strip(), '''\
Expected the following, received {}
{}
{}
'''.format('"' + format_headers('''.
'''.strip()) + '"', '-' * 80, '''
'''.strip())


# Generated at 2022-06-23 19:23:19.959639
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Accept: application/json; indent=4',
        'Content-Type: application/json; charset=utf-8',
        'X-RateLimit-Remaining: 60',
        'X-RateLimit-Limit: 60',
        'X-RateLimit-Reset: 1372700873',
    ])

# Generated at 2022-06-23 19:23:21.700338
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()



# Generated at 2022-06-23 19:23:32.124864
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.enabled = True
    actual_headers = headers_formatter.format_headers(headers_input)
    assert actual_headers == headers_expected


# Generated at 2022-06-23 19:23:34.876296
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    H = HeadersFormatter(format_options={
        'headers': {
            'sort': False
        }
    })
    print(H.enabled)



# Generated at 2022-06-23 19:23:41.558611
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_text = '''
        GET / HTTP/1.1
        C: c
        Host: 127.0.0.1:5000
        X: x
        Accept: */*
        B: b
        A: a
        X: y
    '''
    expected_text = '''
        GET / HTTP/1.1
        A: a
        B: b
        C: c
        Host: 127.0.0.1:5000
        X: x
        X: y
        Accept: */*
    '''
    assert HeadersFormatter().format_headers(input_text.strip()) == expected_text.strip()

# Generated at 2022-06-23 19:23:47.481460
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
X-Test: one
Content-Length: 123
Accept: */*
X-Test: two
X-Test: three
'''
    expected = '''\
HTTP/1.1 200 OK
Accept: */*
Content-Length: 123
X-Test: one
X-Test: two
X-Test: three
'''
    assert hf.format_headers(headers) == expected

# Generated at 2022-06-23 19:23:54.115545
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # First argument is the format_options, which is present in kwargs
    headers = HeadersFormatter(format_options={'headers': {'sort': True}})

    # Asserting check for FormatterPlugin's __init__
    assert headers.enabled is True

    # Asserting check for HeadersFormatter's __init__
    assert headers.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-23 19:24:04.084043
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = "Host: localhost:5000\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\n\r\n"
    assert HeadersFormatter(format_options={'headers': {'sort': False}}).format_headers(s) == s
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(s) == "Host: localhost:5000\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\n\r\n"
    s = "Host: localhost:5000\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nContent-Length: 0\r\n\r\n"

# Generated at 2022-06-23 19:24:12.485434
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Host: www.google.com',
        'User-Agent: HTTPie/0.9.3',
        'Accept: */*',
        'Connection: keep-alive'
    ])
    output_headers = formatter.format_headers(headers)
    print(output_headers)
    output_headers = output_headers.splitlines()
    output_headers[1:1] = sorted(output_headers[1:], key=lambda h: h.split(':')[0])
    print(output_headers)

test_HeadersFormatter_format_headers()

# Generated at 2022-06-23 19:24:22.391768
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter()
    plugin.format_options = {'headers': {'sort': True}}
    assert plugin.format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'Content-Type: application/json',
        'Accept: application/json',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive'
    ])) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept: application/json',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'Content-Type: application/json'
    ])


__all__ = (
    'HeadersFormatter',
    'test_HeadersFormatter_format_headers'
)

# Generated at 2022-06-23 19:24:24.624865
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()

    # Test if enabled is set to True
    assert formatter.enabled


# Generated at 2022-06-23 19:24:33.582231
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:24:44.305965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '''HTTP/1.1 200 OK\r
Server: nginx/1.14.0 (Ubuntu)\r
Date: Sun, 06 Jan 2019 06:37:29 GMT\r
Content-Type: text/html; charset=UTF-8\r
Connection: keep-alive\r
Vary: Accept-Encoding\r
X-Content-Type-Options: nosniff\r
X-XSS-Protection: 1; mode=block\r
X-Frame-Options: SAMEORIGIN\r
Content-Length: 1045\r
\r
'''

# Generated at 2022-06-23 19:24:45.275234
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled == obj.format_options['headers']['sort']


# Generated at 2022-06-23 19:24:49.371508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert h.enabled
    assert h.format_options['headers']['sort'] is True


# Generated at 2022-06-23 19:24:59.548488
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_input = '''\
POST / HTTP/1.1
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 4
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.3

foo=bar'''

    headers_expected = '''\
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 4
Content-Type: application/x-www-form-urlencoded
Host: example.org
User-Agent: HTTPie/1.0.3

foo=bar'''
    headers_actual = HeadersFormatter().format_headers(headers_input)
    assert headers_

# Generated at 2022-06-23 19:25:00.311684
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-23 19:25:01.638843
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:25:11.268201
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head_format = HeadersFormatter()
    head = """GET / HTTP/1.1
Host: 127.0.0.1:55001
Content-Length: 0
Connection: keep-alive
content-type: application/json
cache-control: no-cache
cookie: cookieName=cookieValue
"""
    expected_heade = """GET / HTTP/1.1
cache-control: no-cache
Connection: keep-alive
Content-Length: 0
cookie: cookieName=cookieValue
content-type: application/json
Host: 127.0.0.1:55001
"""
    assert head_format.format_headers(head) == expected_heade


# Generated at 2022-06-23 19:25:17.195250
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdr = '''\
Content-Type: application/json
Authorization: Basic 0123456789abcdefABCDEF
Content-Type: application/json
Authorization: Basic 0123456789abcdefABCDEF'''
    result = '''\

Authorization: Basic 0123456789abcdefABCDEF
Authorization: Basic 0123456789abcdefABCDEF
Content-Type: application/json
Content-Type: application/json'''
    hdr = HeadersFormatter()
    assert hdr.format_headers(hdr) == result

# Generated at 2022-06-23 19:25:24.110574
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ["GET / HTTP/1.1",
        "User-Agent: HTTPie/1.0.2",
        "Accept-Encoding: gzip, deflate",
        "Accept: */*",
        "Host: localhost",
        "Content-Length: 2",
        "Connection: keep-alive"
    ]
    headers = '\r\n'.join(lines)
    assert HeadersFormatter.format_headers(headers) == headers


# Generated at 2022-06-23 19:25:27.530460
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	header1 = HeadersFormatter(sort=True)
	header2 = HeadersFormatter(sort=False)
	header3 = HeadersFormatter()

# Generated at 2022-06-23 19:25:33.524881
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('Content-Length: 123\nabc: def\nContent-Type: text/html\n') == 'Content-Length: 123\nContent-Type: text/html\nabc: def\n'
    assert hf.format_headers('A: 1\nB: 2\nA: 3\n') == 'A: 1\nA: 3\nB: 2\n'

# Generated at 2022-06-23 19:25:39.537098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    headers_object = HeadersFormatter()

    headers_input = """Content-Type: application/json; charset=UTF-8
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 42
Host: httpbin.org
User-Agent: HTTPie/0.9.9"""

    # Act
    headers_output = headers_object.format_headers(headers_input)

    # Assert
    assert headers_output == """Content-Type: application/json; charset=UTF-8
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 42
Host: httpbin.org
User-Agent: HTTPie/0.9.9"""



# Generated at 2022-06-23 19:25:49.112634
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=True)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Location: https://httpbin.org/get
Server: nginx
Date: Fri, 24 Jul 2020 10:39:27 GMT
Content-Length: 934
Connection: keep-alive
Allow: GET, HEAD, OPTIONS'''
   
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Allow: GET, HEAD, OPTIONS
Connection: keep-alive
Content-Length: 934
Content-Type: text/html; charset=utf-8
Date: Fri, 24 Jul 2020 10:39:27 GMT
Location: https://httpbin.org/get
Server: nginx'''

# Generated at 2022-06-23 19:26:00.124744
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    request = '''GET / HTTP/1.1
Host: www.google.com
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Connection: keep-alive
Upgrade-Insecure-Requests: 1'''

# Generated at 2022-06-23 19:26:03.487930
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options == {"headers":{"sort":False}}


# Generated at 2022-06-23 19:26:04.648885
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:26:12.854511
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    formatter = HeadersFormatter()
    headers = '''\
'''
    expected = headers
    # Act
    actual = formatter.format_headers(headers)
    # Assert
    assert actual == expected
    # Arrange
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:26:23.329339
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options = {'headers':{'sort': True}})
    # Test with a single set of headers
    headers = 'POST http://localhost:5000/api/v1/status HTTP/1.1\r\nkey: value'
    assert headers_formatter.format_headers(headers) == 'POST http://localhost:5000/api/v1/status HTTP/1.1\r\nkey: value'
    # Test with multiple sets of headers
    headers = 'POST http://localhost:5000/api/v1/status HTTP/1.1\r\nkey: value\r\nPOST http://localhost:5000/api/v1/status HTTP/1.1\r\nkey: value'

# Generated at 2022-06-23 19:26:24.896493
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    cls = HeadersFormatter
    assert not cls.enabled

# Generated at 2022-06-23 19:26:33.735026
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:26:35.738144
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert type(HeadersFormatter()) == HeadersFormatter


# Generated at 2022-06-23 19:26:45.659613
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_str = """\
HTTP/1.1 200 OK
Transfer-Encoding: chunked
Cache-Control: public, max-age=0
Content-Type: text/html; charset=utf-8
Content-Language: en
Etag: "5a3af2101f9f8d52e4ce4e4c4fadb47c"
"""

# Generated at 2022-06-23 19:26:46.673375
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass # Constructor is tested implicitly by the superclass


# Generated at 2022-06-23 19:26:57.689516
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """
        GET / HTTP/1.1


        """
    ) == """
        GET / HTTP/1.1


        """
    assert HeadersFormatter().format_headers(
        """
        GET / HTTP/1.1

        Host: github.com
        Accept: */*

        """
    ) == """
        GET / HTTP/1.1

        Accept: */*
        Host: github.com

        """
    assert HeadersFormatter().format_headers(
        """
        GET / HTTP/1.1

        B: b
        A: a
        B: b

        """
    ) == """
        GET / HTTP/1.1

        A: a
        B: b
        B: b

        """



# Generated at 2022-06-23 19:26:59.690292
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:27:02.295139
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__doc__ != None
    assert HeadersFormatter.format_headers.__doc__ != None
    assert HeadersFormatter.__init__ != None


# Generated at 2022-06-23 19:27:12.680621
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    result = f.format_headers("""\
Host: httpbin.org
Connection: keep-alive
X-Something: spam
Accept: image/webp,*/*;q=0.8
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36
Accept-Encoding: gzip,deflate,sdch
Accept-Language: en-US,en;q=0.8
X-Something: eggs
""")

# Generated at 2022-06-23 19:27:21.454018
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers=['GET / HTTP/1.1', 'Accept-Encoding: gzip, deflate', 'Host: httpbin.org',
             'Accept: */*', 'User-Agent: HTTPie/0.9.9', 'Connection: keep-alive']
    headers_str='\r\n'.join(headers)
    formatter=HeadersFormatter(format_options={'headers':{'sort':True}})
    formatter.set_environment()
    assert formatter.format_headers(headers_str) == '\r\n'.join(sorted(headers[1:], key=lambda h: h.split(':')[0]))

# Generated at 2022-06-23 19:27:23.062807
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f is not None

# Generated at 2022-06-23 19:27:25.208802
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:27:35.172960
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    self = HeadersFormatter(format_options = { 'headers' : { 'sort' : True }})
    assert self.format_headers('Content-Type: text/html') == 'Content-Type: text/html'
    assert self.format_headers('Content-Type: text/html\r\nContent-Length: 0') == 'Content-Length: 0\r\nContent-Type: text/html'
    assert self.format_headers('Content-Type: text/html\r\nContent-Length: 0\r\nContent-Type: text/html') == 'Content-Length: 0\r\nContent-Type: text/html\r\nContent-Type: text/html'

# Generated at 2022-06-23 19:27:41.784968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''
blah
Content-Type: application/json; charset=utf-8
Content-Length: 241
Server: httpbin.org
Date: Thu, 24 Aug 2017 18:07:06 GMT
'''
    assert headers_formatter.format_headers(headers) == '''
blah
Content-Length: 241
Content-Type: application/json; charset=utf-8
Date: Thu, 24 Aug 2017 18:07:06 GMT
Server: httpbin.org
'''


# Generated at 2022-06-23 19:27:49.295888
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:27:55.392436
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_input = '''
Accept: application/json
Content-Type: application/json
Cookie: id=12; name=foo;
'''
    
    header_output = '''
Accept: application/json
Content-Type: application/json
Cookie: id=12; name=foo;
'''
    assert HeadersFormatter().format_headers(header_input) == header_output

# Generated at 2022-06-23 19:27:56.331918
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-23 19:27:57.677534
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-23 19:28:00.778314
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {
            'sort': True
        }
    }
    hf = HeadersFormatter(format_options)
    assert hf.format_options == format_options
    assert hf.enabled == True
    assert hf.disabled == False


# Generated at 2022-06-23 19:28:08.873887
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """
    Connection: close
    Authorization: Basic
    Accept: */*
    Content-Length: 0
    Content-Type: application/json
    User-Agent: HTTPie/1.0.3
    """
    expected_headers = """\
Connection: close
Authorization: Basic
Accept: */*
Content-Length: 0
Content-Type: application/json
User-Agent: HTTPie/1.0.3
"""
    assert hf.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:28:10.405131
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()
    assert isinstance(instance, HeadersFormatter)


# Generated at 2022-06-23 19:28:12.261084
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == True



# Generated at 2022-06-23 19:28:13.297201
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled == True


# Generated at 2022-06-23 19:28:15.053737
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:28:18.705045
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print('----------test_HeadersFormatter----------')
    hf = HeadersFormatter()
    hf.format_options = object()
    hf.format_options.headers = object()
    hf.format_options.headers.sort = True
    print(hf.enabled)


# Generated at 2022-06-23 19:28:28.101215
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    head = """\
HTTP/1.1 301 Moved Permanently
Server: nginx
Date: Sun, 27 Dec 2015 12:21:04 GMT
Content-Type: text/html; charset=UTF-8
Content-Length: 0
Connection: keep-alive
Location: http://httpbin.org/
"""
    assert hf.format_headers(head) == """\
HTTP/1.1 301 Moved Permanently
Connection: keep-alive
Content-Length: 0
Content-Type: text/html; charset=UTF-8
Date: Sun, 27 Dec 2015 12:21:04 GMT
Location: http://httpbin.org/
Server: nginx
"""

# Generated at 2022-06-23 19:28:39.269160
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    assert headers.format_headers('X-Z: 1\nX-A: 2\nX-B: 3\n') == 'X-Z: 1\r\nX-A: 2\r\nX-B: 3'

assert isinstance(HeadersFormatter.prepare_request_headers, Callable), \
    'Method prepare_request_headers must be defined in class HeadersFormatter'

assert isinstance(HeadersFormatter.prepare_response_headers, Callable), \
    'Method prepare_response_headers must be defined in class HeadersFormatter'

assert isinstance(HeadersFormatter.prepare_response_headers, Callable), \
    'Method prepare_response_headers must be defined in class HeadersFormatter'

# Generated at 2022-06-23 19:28:43.661928
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """GET / HTTP/1.1
Connection: keep-alive
User-Agent: HTTPie/0.9.0
Accept-Encoding: gzip, deflate
Accept: application/json
Id: 123
Id: 456
Id: 789"""

    res = HeadersFormatter().format_headers(headers)

    print(res)
    assert (res == """GET / HTTP/1.1
Id: 123
Id: 456
Id: 789
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.0""")


# Generated at 2022-06-23 19:28:55.438969
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    HTTP_200_OK = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Tue, 18 Dec 2018 21:56:13 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 656
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
Via: 1.1 vegur

'''

# Generated at 2022-06-23 19:28:56.998371
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert(isinstance(hf, FormatterPlugin))


# Generated at 2022-06-23 19:29:06.335989
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {
        'headers': {
            'sort': True
        }
    }
    f = HeadersFormatter(format_options=format_options)
    # f.format_headers(headers)
    headers = dedent("""
    CONTENT-TYPE: application/json
    CONTENT-LENGTH: 437
    X-POWERED-BY: Express
    ACCEPT-RANGES: bytes
    ETAG: W/"1c1-4288e0ddf4"
    DATE: Mon, 02 Sep 2019 11:03:29 GMT
    CONNECTION: close
    """).strip()

# Generated at 2022-06-23 19:29:13.252570
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    h = """\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Date: Fri, 05 Oct 2018 18:11:12 GMT
Content-Length: 9
"""
    assert hf.format_headers(h) == """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 9
Content-Type: application/json
Date: Fri, 05 Oct 2018 18:11:12 GMT
"""
    print('test_HeadersFormatter_format_headers ok')

test_HeadersFormatter_format_headers()

# Generated at 2022-06-23 19:29:17.991606
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter()
    assert obj.format_headers("""\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8888
User-Agent: HTTPie/0.9.3

""") == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8888
User-Agent: HTTPie/0.9.3
"""


# Generated at 2022-06-23 19:29:26.788521
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter()
    headers_input = (
        'GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Transfer-Encoding: chunked\r\n'
        'Content-Type: application/x-www-form-urlencoded\r\n'
        'Host: httpbin.org\r\n'
        'User-Agent: HTTPie/0.9.8\r\n'
        '\r\n'
        'data=foo'
    )