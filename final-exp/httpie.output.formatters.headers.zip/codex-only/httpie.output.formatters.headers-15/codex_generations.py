

# Generated at 2022-06-23 19:19:26.581447
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Header1: Value1\r\nHeader2: Value2\r\nHeader3: Value3') == 'Header1: Value1\r\nHeader2: Value2\r\nHeader3: Value3'

# Generated at 2022-06-23 19:19:29.587143
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    headers = """GET / HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Accept: */*"""
    assert formatter.format_headers(headers) == headers

# Generated at 2022-06-23 19:19:32.796775
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create a new object from class FormatterPlugin
    headers_formatter = HeadersFormatter()
    
    # Check if object is from class HeadersFormatter
    assert isinstance(headers_formatter, HeadersFormatter)
    # Check if object is from class FormatterPlugin
    assert isinstance(headers_formatter, FormatterPlugin)


# Generated at 2022-06-23 19:19:43.057978
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_set1 =\
"""User-Agent: Moc
Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 40
Content-Type: application/x-www-form-urlencoded; charset=utf-8"""

    header_set2 =\
"""Content-Type: application/x-www-form-urlencoded; charset=utf-8
Content-Length: 40
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: */*
Host: localhost:5000
User-Agent: Moc"""
    assert HeaderFormatter().format_headers(header_set1) == header_set2

# Generated at 2022-06-23 19:19:48.168804
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert not headers_formatter.enabled


# Generated at 2022-06-23 19:19:51.572681
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # HeadersFormatter is a class
    assert HeadersFormatter
    # HeadersFormatter is a subclass of FormatterPlugin
    assert issubclass(HeadersFormatter, FormatterPlugin)


# Generated at 2022-06-23 19:19:54.112036
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__name__ == 'HeadersFormatter'
    assert HeadersFormatter.__init__.__name__ == '__init__'



# Generated at 2022-06-23 19:19:56.552413
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:20:03.538723
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import typing
    plugin_name: str = "headers"
    formatter_plugin: HeadersFormatter = HeadersFormatter((plugin_name,))
    assert formatter_plugin.enabled == False
    assert type(formatter_plugin.name) is str
    assert formatter_plugin.name == plugin_name
    assert type(formatter_plugin.format_options) is dict
    assert type(formatter_plugin.format_options[plugin_name]) is dict
    assert type(formatter_plugin.format_options[plugin_name]['sort']) is bool
    assert formatter_plugin.format_options[plugin_name]['sort'] == False


# Generated at 2022-06-23 19:20:05.977077
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is True


# Generated at 2022-06-23 19:20:15.737212
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:20:20.468455
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:20:30.240788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fomatter = HeadersFormatter()
    request_line = 'GET / HTTP/1.1'
    headers = 'Accept: text/html\r\nUser-Agent: HTTPie/1.0.0\r\nContent-Type: text/xml'
    headers_out = 'Accept: text/html' + '\r\n' + 'Content-Type: text/xml' + '\r\n' + 'User-Agent: HTTPie/1.0.0'
    request = request_line + '\r\n' + headers
    result = fomatter.format_headers(request)
    assert result == request_line + '\r\n' + headers_out

# Generated at 2022-06-23 19:20:37.257309
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    e = 'Content-Type: text/plain; charset=utf-8\r\n' \
        'Content-Length: 12\r\n' \
        'X-Foo: Bar\r\n' \
        'X-Bar: Foo'
    a = formatter.format_headers('X-Bar: Foo\r\n'
                                 'Content-Type: text/plain; charset=utf-8\r\n'
                                 'Content-Length: 12\r\n'
                                 'X-Foo: Bar')
    assert a == e



# Generated at 2022-06-23 19:20:45.896860
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
   headers = '''Accept:        */*
Accept-Encoding: gzip, deflate
Connection:     keep-alive
Content-Length: 0
Content-Type:   application/json
Host:           localhost:3000
User-Agent:     HTTPie/0.9.9

'''
   headers = '''Accept:        */*
Content-Type:   application/json
Content-Length: 0
Accept-Encoding: gzip, deflate
Connection:     keep-alive
Host:           localhost:3000
User-Agent:     HTTPie/0.9.9

'''
   assert headers == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-23 19:20:54.750768
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: text/html
Date: Wed, 02 Oct 2019 12:14:46 GMT
Elapsed-Time: 0.000
Server: Werkzeug/0.14.1 Python/3.7.4

"""
    expected_headers = """\
HTTP/1.1 200 OK
Content-Length: 12
Content-Type: text/html
Date: Wed, 02 Oct 2019 12:14:46 GMT
Elapsed-Time: 0.000
Server: Werkzeug/0.14.1 Python/3.7.4

"""
    assert formatter.format_headers(headers) == expected_headers
    
    

# Generated at 2022-06-23 19:20:56.694302
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert type(headers_formatter) is HeadersFormatter


# Generated at 2022-06-23 19:21:01.056591
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # when
    headers = HeadersFormatter().format_headers("""
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
a: 3
b: 4
a: 5
       """)

    # then
    assert headers == """
HTTP/1.1 200 OK
a: 3
a: 5
b: 4
Content-Type: application/json; charset=utf-8
    """



# Generated at 2022-06-23 19:21:07.354741
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins.headers import HeadersFormatter
    import json
    import os
    
    # Create a config dir for tests
    os.makedirs('./test_dir/config/httpie', exist_ok=True)

    # Define input args for the HttpieHeadersFormatter constructor
    input_stream = sys.stdin
    env = httpie.env.Environment(vars={
        'config_dir': os.path.join(os.path.dirname(__file__), 'config')
    })
    stdin = None
    stdin_isatty = sys.stdin.isatty()
    output_file = sys.stdout
    output_isatty = sys.stdout.isatty()
    config_dir = httpie.get_config_dir(env)
    format

# Generated at 2022-06-23 19:21:18.479298
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ("GET / HTTP/1.1\r\n"
               "Accept-Encoding: gzip, deflate\r\n"
               "Connection: keep-alive\r\n"
               "Content-Length: 0\r\n"
               "Content-Type: application/x-www-form-urlencoded\r\n"
               "Host: httpbin.org\r\n"
               "User-Agent: HTTPie/1.0.2\r\n"
               "\r\n")

# Generated at 2022-06-23 19:21:20.809077
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h


# Generated at 2022-06-23 19:21:28.867057
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test to check if method works with strings
    that contain multiple headers with the same name, retaining
    relative order of multiple headers with the same name.
    """
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_1 = '''HTTP/1.1 200 OK\r
Content-Length: 17\r
X-Foo: Bar\r
X-Foo: Baz\r
\r
'''
    headers_2 = '''HTTP/1.1 200 OK\r
X-Foo: Baz\r
X-Foo: Bar\r
Content-Length: 17\r
\r
'''
    headers_formatter.format_headers(headers_1) == headers_2

# Generated at 2022-06-23 19:21:31.194805
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception):
        formatter = HeadersFormatter("JSON", "JSON")


# Generated at 2022-06-23 19:21:38.446103
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = """\
GET / HTTP/1.1
Accept: text/html, */*
X-Foo: Bar
Content-Type: application/json
X-Baz: Qux
Connection: close"""
    lines = lines.splitlines()
    headers = sorted(lines[1:], key=lambda h: h.split(':')[0])

# Generated at 2022-06-23 19:21:40.944513
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter()


# Generated at 2022-06-23 19:21:50.650906
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    formatted_headers = formatter.format_headers(
        "HTTP/1.1 200 OK\r\n"
        "Cache-Control: no-cache\r\n"
        "Content-Length: 3\r\n"
        "Content-Type: application/json\r\n"
        "Date: Sun, 16 Mai 2017 15:42:44 GMT\r\n"
        "Expires: -1\r\n"
        "Pragma: no-cache\r\n"
        "\r\n"
        "{}"
    )

# Generated at 2022-06-23 19:21:54.523393
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_headers('Host: bing.com\r\nContent-Type: plain/text\r\nConnection: closed') == 'Host: bing.com\r\nContent-Type: plain/text\r\nConnection: closed'


# Generated at 2022-06-23 19:22:03.509223
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    header_lines = '''HTTP/1.1 200 OK
Date: Sun, 10 May 2020 17:35:57 GMT
Content-Type: text/html
Content-Length: 17450
Last-Modified: Sat, 09 May 2020 02:39:10 GMT
Connection: keep-alive
ETag: "5eb5d0ee-44f6"
Server: openresty
Accept-Ranges: bytes
Cache-Control: max-age=0
Expires: Sun, 10 May 2020 17:35:57 GMT'''.splitlines()


# Generated at 2022-06-23 19:22:10.126781
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    f.format_options['headers']['sort'] = True
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 8\r\n\r\n') == 'HTTP/1.1 200 OK\r\nContent-Length: 8\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-23 19:22:14.220443
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter_plugin = HeadersFormatter()
    assert isinstance(formatter_plugin, FormatterPlugin)
    assert formatter_plugin.enabled
    assert formatter_plugin.format_options['headers']['sort']


# Generated at 2022-06-23 19:22:21.036283
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: httpbin.org
Connection: Keep-Alive
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: python-requests/2.22.0
'''
    assert HeadersFormatter().format_headers(headers) == '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: Keep-Alive
User-Agent: python-requests/2.22.0
'''

# Generated at 2022-06-23 19:22:29.847117
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': False}})
    assert headers_formatter.enabled == False

    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': None}})
    assert headers_formatter.enabled == False

    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True

    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': 10}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:22:36.976227
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Test when there is only one header in the string
    assert formatter.format_headers('Accept: application/json') == 'Accept: application/json'
    # Test when there are multiple headers but they are already sorted
    assert formatter.format_headers('Accept: application/json\r\nUser-Agent: HTTPie/0.9.9') == 'Accept: application/json\r\nUser-Agent: HTTPie/0.9.9'
    # Test when there are multiple headers and they are not sorted
    assert formatter.format_headers('User-Agent: HTTPie/0.9.9\r\nAccept: application/json') == 'Accept: application/json\r\nUser-Agent: HTTPie/0.9.9'
    # Test when there are multiple headers with the same name

# Generated at 2022-06-23 19:22:47.380075
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers_old = """\
Content-Length: 100
Content-Type: application/json
Content-Type: application/json
Set-Cookie: foo=bar
User-Agent: HTTPie
X-Foo: bar
X-Foo: baz
"""
    headers_new = """\
Content-Length: 100
Content-Type: application/json
Content-Type: application/json
Set-Cookie: foo=bar
User-Agent: HTTPie
X-Foo: bar
X-Foo: baz
"""

    assert formatter.format_headers(headers_old) == headers_new

# Generated at 2022-06-23 19:22:49.339324
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = """\
HTTP/1.1 200 OK
Content-Length: 234
Content-Type: application/json
Server: TornadoServer/4.2.1
X-Powered-By: Tornado/4.2.1

"""
    assert expected == HeadersFormatter().format_headers(examples.valid_response_headers)


# Generated at 2022-06-23 19:22:50.602418
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.enabled is False


# Generated at 2022-06-23 19:22:57.105517
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
   formatter = HeadersFormatter()
   assert formatter.format_headers("Connection: keep-alive\r\nHost: localhost\r\nContent-Length: 8\r\n\r\n") == "Connection: keep-alive\r\n\r\nHost: localhost\r\nContent-Length: 8"




# Generated at 2022-06-23 19:23:04.775138
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    assert f.format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'Connection: keep-alive',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'User-Agent: HTTPie/0.9.5',
        'Accept-Language: en-US'
    ])) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: en-US',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.5'
    ])

# Generated at 2022-06-23 19:23:12.733847
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # // case 1
    # format = HeadersFormatter()
    # assert format.format_options['headers']['sort'] == True
    # assert format.enabled == True

    # // case 2
    format = HeadersFormatter()
    assert format.format_options['headers']['sort'] == True
    assert format.enabled == True

    # // case 3
    format = HeadersFormatter(headers={"sort": False})
    assert format.format_options['headers']['sort'] == False
    assert format.enabled == False



# Generated at 2022-06-23 19:23:21.234674
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
        Test that multiple headers with different names have correct order
        sorted by name.
    """
    headers_formatter = HeadersFormatter()

    headers_string = "HTTP/1.1 200 OK\n" \
                     "Date: Fri, 25 Oct 2019 07:46:33 GMT\n" \
                     "Server: Apache\n" \
                     "Vary: Accept-Encoding\n" \
                     "Transfer-Encoding: chunked\n" \
                     "Content-Type: text/html; charset=UTF-8\n" \
                     "test_header: \n" \
                     "Content-Language: en-US\n" \
                     "Content-Encoding: gzip"


# Generated at 2022-06-23 19:23:28.053971
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    formatter.format_headers('''
GET / HTTP/1.1
Connection: close
Host: www.example.com
User-Agent: HTTPie
Accept: */*
Accept-Encoding: gzip, deflate''') == '''
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Host: www.example.com
User-Agent: HTTPie'''

# Generated at 2022-06-23 19:23:38.214618
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:23:39.391153
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # No errors are raised
    HeadersFormatter()


# Generated at 2022-06-23 19:23:48.847219
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    string = 'HTTP/1.1 200 OK \r\nfoo:bar\r\nbazz:quux\r\nContent-Type: application/json; charset=utf-8\r\ncontent-length: 17\r\nConnection: Keep-Alive\r\n'
    string_expected = 'HTTP/1.1 200 OK \r\ncontent-length: 17\r\nContent-Type: application/json; charset=utf-8\r\nConnection: Keep-Alive\r\nfoo:bar\r\nbazz:quux\r\n'
    headers = HeadersFormatter(string)
    assert headers.original_string == string
    assert headers.format(headers.original_string) == string_expected
    
    

# Generated at 2022-06-23 19:23:50.894377
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert isinstance(headers, HeadersFormatter)


# Generated at 2022-06-23 19:23:53.215357
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options == {"headers": {"sort": False}}


# Generated at 2022-06-23 19:24:03.784349
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    # Check a sane example
    h = "HTTP/1.1 200 OK\r\n" + \
        "b: 2\r\n" + \
        "a: 1\r\n" + \
        "c: 3\r\n" + \
        "\r\n"
    assert f.format_headers(h) == \
        "HTTP/1.1 200 OK\r\n" + \
        "a: 1\r\n" + \
        "b: 2\r\n" + \
        "c: 3\r\n" + \
        "\r\n"
    # Check that multiple headers with the same name are sorted
    h = "HTTP/1.1 200 OK\r\n" + \
        "b: 2\r\n"

# Generated at 2022-06-23 19:24:06.924506
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert type(formatter) == HeadersFormatter
    assert formatter.enabled == True
    assert 'headers' in formatter.format_options
    assert formatter.format_options['headers']['sort'] == True

# Generated at 2022-06-23 19:24:14.232162
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed
    '''
    expected = '''\
HTTP/1.1 200 OK
Connection: Closed
Content-Length: 88
Content-Type: text/html
Date: Mon, 27 Jul 2009 12:28:53 GMT
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Server: Apache/2.2.14 (Win32)'''
    assert hf.format_headers(headers) == expected


# Generated at 2022-06-23 19:24:19.473223
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersformatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert headersformatter.format_options == {'headers': {'sort': False}}
    assert headersformatter.enabled == False

    headersformatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headersformatter.format_options == {'headers': {'sort': True}}
    assert headersformatter.enabled == True



# Generated at 2022-06-23 19:24:29.563223
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class Request(object): pass
    class Response(object): pass

    formatter = HeadersFormatter()
    request = Request()
    request.headers = {'Content-Type': 'text/plain',
                       'Connection': 'keep-alive',
                       'Host': 'httpbin.org'}
    formatter.write_request(request)

    response = Response()

# Generated at 2022-06-23 19:24:37.307086
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Should return the string with sorted headers
    while retaining relative order of multiple headers with the same name.
    """
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Date: Sun, 25 Feb 2018 17:19:03 GMT
Content-Type: application/json
Content-Length: 234
Connection: keep-alive
Cache-Control: private, must-revalidate, max-age=0
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Cache-Control: private, must-revalidate, max-age=0
Connection: keep-alive
Content-Length: 234
Content-Type: application/json
Date: Sun, 25 Feb 2018 17:19:03 GMT
Server: nginx
'''

# Generated at 2022-06-23 19:24:40.200338
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    object1 = HeadersFormatter()
    assert object1.enabled == object1.format_options['headers']['sort']


# Generated at 2022-06-23 19:24:49.056043
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Date: Sat, 03 Mar 2018 20:02:29 GMT
Server: Apache/2.2.34 (Unix)
Last-Modified: Sat, 22 Jan 2005 19:46:03 GMT
ETag: "8ef-432a5e4a73a80"
Accept-Ranges: bytes
Content-Length: 2303
Connection: close
Content-Type: text/html; charset=UTF-8"""

# Generated at 2022-06-23 19:24:57.198940
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    headersformatter = HeadersFormatter(**{'format_options': {'headers': {'sort': True}}})
    assert(headersformatter.format_options['headers']['sort'] == True)


# Generated at 2022-06-23 19:25:03.568788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test scenario #1 - headers are not sorted, no two headers with the same name
    # Given: an instance of class HeadersFormatter and string with headers without sorting
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 201 Created
Connection: close
Content-Type: application/json
Date: Sat, 03 Jan 2015 16:13:03 GMT
Server: BaseHTTP/0.3 Python/2.7.6
Content-Length: 2
Access-Control-Allow-Origin: *

{}'''
    # When: I call method format_headers
    new_headers = formatter.format_headers(headers)
    # Then: Headers should be sorted by name

# Generated at 2022-06-23 19:25:07.717020
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('2: a\n1: b\n1: c\n') == '2: a\n1: c\n1: b\n'



# Generated at 2022-06-23 19:25:14.008935
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class Dummy(HeadersFormatter): pass
    assert '\r\n'.join(['', 'HTTP/1.1 200 OK', 'header-x: x', 'header-b: b', 'header-a: a', '']) == Dummy().format_headers('\r\n'.join(['', 'HTTP/1.1 200 OK', 'header-b: b', 'header-x: x', 'header-a: a', '']))

# Generated at 2022-06-23 19:25:20.131491
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = hf.format_headers("""\
GET /example HTTP/1.1
A: 1
A: 2
B: 3
A: 4
""")
    assert headers == """\
GET /example HTTP/1.1
A: 1
A: 2
A: 4
B: 3
"""

# Generated at 2022-06-23 19:25:23.767099
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
X-Test: Foo
Content-Type: application/json
X-Test: Bar'''
    formatted_headers = f.format_headers(headers)
    assert formatted_headers == headers

# Generated at 2022-06-23 19:25:35.394507
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:25:37.013322
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:25:45.557106
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    line = 'GET / HTTP/1.1\r\nHost: example.org\r\n' \
           'A: 234\r\nB: 678\r\nContent-Type: application/json\r\n' \
           'A: 123\r\n'

    assert f.format_headers(line) == \
        'GET / HTTP/1.1\r\nA: 123\r\nA: 234\r\nB: 678\r\n' \
        'Content-Type: application/json\r\nHost: example.org\r\n'

# Generated at 2022-06-23 19:25:47.233831
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert fmt.enabled



# Generated at 2022-06-23 19:25:51.008325
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    method = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/xml; charset=UTF-8
Server: Apache-Coyote/1.1
Set-Cookie: JSESSIONID=<cut>
Content-Length: 682
Date: Wed, 26 Aug 2015 18:08:16 GMT

'''
    assert method.format_headers(headers) == headers


# Generated at 2022-06-23 19:25:53.245000
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter('', '')


# Generated at 2022-06-23 19:26:01.626175
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Date: Sat, 23 Feb 2019 02:15:16 GMT
Server: SimpleHTTP/0.6 Python/3.7.3
Content-Length: 2

{}'''

    output_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 2
Content-Type: application/json
Date: Sat, 23 Feb 2019 02:15:16 GMT
Server: SimpleHTTP/0.6 Python/3.7.3

{}'''
    assert formatter.format_headers(input_headers) == output_headers



# Generated at 2022-06-23 19:26:11.119614
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    instance = HeadersFormatter()
    h = '''\
HTTP/1.1 200 OK
Accept-Ranges: bytes
Age: 25
Allow: GET, HEAD, OPTIONS
Cache-Control: max-age=604800
Content-Type: text/html; charset=UTF-8
Date: Tue, 03 Jul 2018 09:26:08 GMT
Etag: "1541025663"
Expires: Tue, 10 Jul 2018 09:26:08 GMT
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (fcn/4E0A)
X-Cache: HIT
Content-Length: 1270
'''

# Generated at 2022-06-23 19:26:12.482323
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is HeadersFormatter


# Generated at 2022-06-23 19:26:23.065923
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter() #format_options['headers']['sort']: False
    formatter.format_options['headers']['sort'] = True

    # input headers:
    # 'Connection: close\r\n'
    # 'Content-Length: 0\r\n'
    # 'Date: Sun, 03 Nov 2019 18:12:18 GMT\r\n'
    # 'Server: BaseHTTP/0.6 Python/3.7.4\r\n'

    # output headers:
    # 'Connection: close\r\n'
    # 'Content-Length: 0\r\n'
    # 'Date: Sun, 03 Nov 2019 18:12:18 GMT\r\n'
    # 'Server: BaseHTTP/0.6 Python/3.7.4\r\n'

    assert form

# Generated at 2022-06-23 19:26:24.687287
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={"headers": {"sort": True}})

# Generated at 2022-06-23 19:26:25.849066
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:26:34.382362
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    This method tests the method format_headers of class HeadersFormatter
    """
    formatter = HeadersFormatter()
    test_string = '\r\n'.join(["Content-Type: application/json",
                               "Connection: keep-alive",
                               "Content-Length: 30",
                               "Connection: close",
                               "X-Powered-By: PHP/5.4.36-0deb7u3",
                               "Content-Type: application/json",
                               "Vary: Accept-Encoding",
                               "Server: Apache/2.4.10 (Debian)"])
    actual_result = formatter.format_headers(test_string)

# Generated at 2022-06-23 19:26:37.964913
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    headers_formatter = HeadersFormatter(format_options)
    assert headers_formatter.format_options == format_options
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:26:39.664877
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header = HeadersFormatter()
    assert header.enabled


# Unit tests for function format_headers()

# Generated at 2022-06-23 19:26:48.324704
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Date: Wed, 09 Sep 2015 15:46:52 GMT',
        'Connection: close',
        'Content-Length: 170',
        'Content-Type: text/html',
        'Server: Apache/2.2.8 (Unix) mod_ssl/2.2.8 OpenSSL/0.9.8g',
        'Last-Modified: Sun, 23 Mar 2008 07:32:05 GMT',
        'Expires: Thu, 01 Jan 1970 00:00:00 GMT',
        'Cache-Control: post-check=0, pre-check=0',
        'Etag: "e3e3c1f-2a8-45f3d3c0"'
    ])
   

# Generated at 2022-06-23 19:26:58.809753
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    formatter.format_options['headers']['sort'] = True
    assert formatter.format_headers('a: 1\nb: 2\nc: 3\n') == 'a: 1\nb: 2\nc: 3\n'
    assert formatter.format_headers('b: 2\na: 1\nc: 3\n') == 'a: 1\nb: 2\nc: 3\n'
    assert formatter.format_headers('c: 3\nb: 2\na: 1\n') == 'a: 1\nb: 2\nc: 3\n'
    assert formatter.format_headers('c: 3\na: 1\nb: 2\n') == 'a: 1\nb: 2\nc: 3\n'

# Generated at 2022-06-23 19:27:06.988877
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = ('HTTP/1.1 200 OK\r\n'
               'Content-Length: 1552\r\n'
               'Server: Werkzeug/0.16.1 Python/3.6.9\r\n'
               'Date: Sat, 08 Aug 2020 17:19:29 GMT\r\n'
               'Content-Type: text/html; charset=utf-8\r\n')

# Generated at 2022-06-23 19:27:15.373049
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_str = (
        'Content-Type: application/x-www-form-urlencoded; charset=utf-8\r\n'
        'Content-Length: 31\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
    )
    formatter = HeadersFormatter()
    result = formatter.format_headers(headers_str)

# Generated at 2022-06-23 19:27:25.111727
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """ test_HeadersFormatter_format_headers()
        Given a string of multi-line headers
        When the string is passed to method format_headers  of class HeadersFormatter
        Then the method sorts the headers by name while retaining the relative
             order of multiple headers with the same name,
             returns a formatted string of the sorted headers
    """
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    # sort headers before passing string to format_headers
    sorted_headers = '\r\n'.join(sorted(headers.splitlines()))
    assert formatter.format_headers(headers) == sorted_headers

# Generated at 2022-06-23 19:27:36.716661
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Tests if method HeadersFormatter.format_headers sorts headers
    by name while retaining relative order of multiple headers
    with the same name.

    """


# Generated at 2022-06-23 19:27:44.795577
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:27:56.267167
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(**{})


# Generated at 2022-06-23 19:28:05.462797
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

    # Test for unsorted headers

# Generated at 2022-06-23 19:28:06.364958
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter() == HeadersFormatter()

# Generated at 2022-06-23 19:28:14.597789
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

    headers = """\
HTTP/1.1 200 OK
Cache-Control: max-age=691200
Content-Type: application/json; charset=UTF-8
Date: Tue, 18 Aug 2015 12:51:48 GMT
Expires: Fri, 27 Aug 2015 12:51:48 GMT
Server: nginx
Set-Cookie: djdt=hide; max-age=0; path=/; expires=Tue, 19-Aug-2014 12:51:48 GMT; httponly
Vary: Accept-Encoding
Content-Length: 214
Connection: keep-alive
X-Frame-Options: SAMEORIGIN
"""
    assert f.format_headers(headers) == headers.strip()


# Generated at 2022-06-23 19:28:24.628946
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """HTTP/1.1 200 OK
Content-Type: application/json
X-Api-Key: 1234
User-Agent: httpie
x-B: f
X-A: b
X-B: a
X-A: c
X-B: e
X-A: a
X-B: d
X-A: c
X-B: b

"""
    expected = """HTTP/1.1 200 OK
Content-Type: application/json
X-Api-Key: 1234
User-Agent: httpie
X-A: b
X-A: c
X-A: a
X-A: c
X-B: f
X-B: a
X-B: e
X-B: d
X-B: b

"""


# Generated at 2022-06-23 19:28:32.428605
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET /get HTTP/1.1\r
Content-Type: application/json\r
Accept: application/json\r
Accept: text/plain\r
Accept: */*\r
User-Agent: HTTPie/0.9.3\r
\r
'''
    expected_headers = '''\
GET /get HTTP/1.1\r
Accept: application/json\r
Accept: text/plain\r
Accept: */*\r
Content-Type: application/json\r
User-Agent: HTTPie/0.9.3\r
\r
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:28:43.070575
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers(
        'GET / HTTP/1.1\r\n'
        'To: http://example.org/\r\n'
        'From: {0}\r\n'
        'From: {1}\r\n'
        'From: {2}\r\n'
        'X-B: b\r\n'
        'X-A: a\r\n'
        'X-A: c\r\n'
        .format(FIELDS['from'][0], FIELDS['from'][1], FIELDS['from'][2])
    )

# Generated at 2022-06-23 19:28:49.811815
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert (HeadersFormatter({'headers': {'sort': True}}).
            format_headers('header-a: value-a\nheader-b: value-b\nheader-a: value-aa\nheader-c: value-c') ==
            'header-a: value-a\nheader-a: value-aa\nheader-b: value-b\nheader-c: value-c')

# Generated at 2022-06-23 19:28:58.933740
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from io import StringIO
    from httpie.plugins import FormatterPluginsHolder, FormatterPlugin

    class DummyPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '!'

    plugins_holder = FormatterPluginsHolder({
        'headers': {'sort': True},
        'formatted': FormatterPluginsHolder({
            'headers': {'sort': True}
        })
    })
    plugins_holder.set_plugins([DummyPlugin()])
    print("Plugins Holder:", plugins_holder)

    headers = "POST / HTTP/1.1\n" \
              "Content-Type: application/json\n" \
              "Accept: application/json\n"

    print(headers)

# Generated at 2022-06-23 19:29:00.714144
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options == {'headers': {'sort': False}}
    assert h.enabled is False


# Generated at 2022-06-23 19:29:02.433548
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']



# Generated at 2022-06-23 19:29:03.720281
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter({'headers':{'sort':True}})

# Generated at 2022-06-23 19:29:05.594929
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(**{'headers': {'sort': True}})
    assert headers_formatter.enabled


# Generated at 2022-06-23 19:29:12.376289
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test sorting headers with the same name
    headers = """POST / HTTP/1.1
Accept-Encoding: gzip, deflate
Content-Type: application/json; charset=UTF-8
Cookie: session=abcdefghi
Content-Length: 30
Accept: application/json
Content-Type: application/json; charset=UTF-8
Cookie: session=abcdefghi
Cookie: session=abcdefghi
User-Agent: HTTPie/0.9.2
"""

# Generated at 2022-06-23 19:29:17.913105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Server: nginx
Set-Cookie: user_id=1234; Domain=example.org; Path=/; Secure
Set-Cookie: guest_id=5678; Domain=example.org; Path=/'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Type: application/json
Server: nginx
Set-Cookie: guest_id=5678; Domain=example.org; Path=/
Set-Cookie: user_id=1234; Domain=example.org; Path=/; Secure'''


# Generated at 2022-06-23 19:29:19.559895
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	HeadersFormatter()


# Generated at 2022-06-23 19:29:20.645451
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:29:26.936232
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    assert (
        HeadersFormatter.format_headers(
            'HTTP/1.1 200 OK\r\n'
            'B: 2\r\n'
            'A: 1\r\n'
            'C: 3\r\n'
            'D: 4\r\n'
            'A: 5\r\n'
        ) ==
        'HTTP/1.1 200 OK\r\n'
        'A: 1\r\n'
        'A: 5\r\n'
        'B: 2\r\n'
        'C: 3\r\n'
        'D: 4\r\n'
    )