

# Generated at 2022-06-23 19:19:22.868035
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = formatter.HeadersFormatter()
    assert headers.enabled


# Generated at 2022-06-23 19:19:24.783364
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options={'headers':{'sort':False}})


# Generated at 2022-06-23 19:19:33.603282
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    input_headers = """HTTP/1.1 200 OK
Accept-Ranges: bytes
Cache-Control: max-age=604800
Content-Type: text/html; charset=UTF-8
Date: Fri, 03 Jul 2020 13:49:13 GMT
Etag: "3147526947"
Expires: Fri, 10 Jul 2020 13:49:13 GMT
Last-Modified: Thu, 17 Oct 2019 07:18:26 GMT
Server: ECS (dcb/7F6D)
Vary: Accept-Encoding
X-Cache: HIT
Content-Length: 648
"""
    output_headers = headers_formatter.format_headers(input_headers)

# Generated at 2022-06-23 19:19:41.438858
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
        GET /api/ HTTP/1.1
        Content-Type: application/json
        API-Token: 123
        API-Token: xyz
    """.strip()
    expected = """
        GET /api/ HTTP/1.1
        API-Token: 123
        API-Token: xyz
        Content-Type: application/json
    """.strip()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:19:43.810526
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled == True
    assert HeadersFormatter(format_options={'headers' : {'sort':False}}).enabled == False


# Generated at 2022-06-23 19:19:46.178483
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options)
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:19:49.793451
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={"headers": {"sort": True}})

    assert "sort" in headersFormatter.format_options["headers"]
    assert headersFormatter.enabled



# Generated at 2022-06-23 19:19:58.157702
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = """
    HTTP/1.1 200 OK
    Date: Mon, 23 May 2005 22:38:34 GMT
    Content-Type: text/html; charset=UTF-8
    Content-Encoding: UTF-8
    Content-Length: 138
    Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
    Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
    Etag: "3f80f-1b6-3e1cb03b"
    Accept-Ranges: bytes
    Connection: close

    """

# Generated at 2022-06-23 19:20:05.091263
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    headers_input = '''\
Cache-Control: no-cache
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 469
Content-Type: application/json
Date: Sat, 10 Feb 2018 13:53:46 GMT
Host: api.github.com
'''
    headers_output = '''\
Cache-Control: no-cache
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 469
Content-Type: application/json
Date: Sat, 10 Feb 2018 13:53:46 GMT
Host: api.github.com
'''
    assert headersFormatter.format_headers(headers_input) == headers_output



# Generated at 2022-06-23 19:20:08.788056
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True
    assert headers_formatter.format_options['headers']['sort'] == True



# Generated at 2022-06-23 19:20:17.555440
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''GET /api/v1/user/profile HTTP/1.1
Content-Type: application/json
Authorization: Bearer 8e2d3f3f-6a1d-4052-9f9a-bbc221e7e872
Accept: application/json
Host: localhost:8080'''
    check = '''GET /api/v1/user/profile HTTP/1.1
Accept: application/json
Authorization: Bearer 8e2d3f3f-6a1d-4052-9f9a-bbc221e7e872
Content-Type: application/json
Host: localhost:8080'''
    formatter = HeadersFormatter(headers=True)
    result = formatter.format_headers(headers)
    ##print(result)
    assert result

# Generated at 2022-06-23 19:20:25.925024
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()

    assert headers_formatter.format_headers(
        """\
GET / HTTP/1.1
Authorization: Basic dGVzdDp0ZXN0
Content-Type: application/json
Accept: application/json

"""
    ) == """\
GET / HTTP/1.1
Accept: application/json
Authorization: Basic dGVzdDp0ZXN0
Content-Type: application/json

"""



# Generated at 2022-06-23 19:20:26.648930
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-23 19:20:28.152339
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter is not None


# Generated at 2022-06-23 19:20:30.667093
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()

    assert h.name == 'headers'
    assert h.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:20:32.662857
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.format_options['headers']['sort']



# Generated at 2022-06-23 19:20:34.290605
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
   headersFormatter = HeadersFormatter()
   assert headersFormatter.enabled == False

# Generated at 2022-06-23 19:20:36.176603
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled == True


# Generated at 2022-06-23 19:20:44.259058
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hdrs = '''\
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Host: httpbin.org
'''
    hdrs = HeadersFormatter().format_headers(hdrs)

    expected = '''\
User-Agent: HTTPie/0.9.2
Accept: */*
Accept-Encoding: gzip, deflate, compress
Host: httpbin.org
'''
    assert expected == hdrs



# Generated at 2022-06-23 19:20:54.320656
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('HTTP/1.1 200 OK\r\n'
                              'Date: Sat, 12 Oct 2013 08:37:58 GMT\r\n'
                              'Content-Type: application/json; charset=utf-8\r\n'
                              'Content-Length: 2\r\n'
                              'Connection: keep-alive\r\n'
                              'Server: waitress\r\n'
                              '\r\n'
                              '{}') == 'HTTP/1.1 200 OK\r\n'

# Generated at 2022-06-23 19:20:55.253574
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersformatter = HeadersFormatter()

# Generated at 2022-06-23 19:21:01.316773
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is True
    headers = """\
GET / HTTP/1.1
Host: www.google.com
User-Agent: HTTPie/1.0.2
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
"""
    assert formatter.format_headers(headers) == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.google.com
User-Agent: HTTPie/1.0.2
"""

# Generated at 2022-06-23 19:21:08.741598
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': 'yes'}}
    headers = """Accept-Encoding: gzip, deflate
    Authorization: Basic xxxxxxxxx
    Host: httpbin.org
    User-Agent: HTTPie/1.0.3
    X-Amzn-Trace-Id: Root=xxxxxxxxxxxxxxxxxxxxxxxxxxxx
    X-Forwarded-For: xxxxxxxxxx
    X-Forwarded-Port: 80
    X-Forwarded-Proto: http
    X-Test-Header: abcdefghijklmnopqrstuvwxyz
    """

# Generated at 2022-06-23 19:21:16.514064
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Type: application/json;charset=utf-8
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 26 Aug 2018 20:49:21 GMT
Content-Length: 2
"""
    formatted = """\
Content-Type: application/json;charset=utf-8
Connection: keep-alive
Content-Length: 2
Date: Sun, 26 Aug 2018 20:49:21 GMT
Server: gunicorn/19.9.0
"""
    assert formatted == HeadersFormatter.format_headers(headers)

# Generated at 2022-06-23 19:21:17.618871
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    _ = HeadersFormatter()

# Unit tests for method format_headers

# Generated at 2022-06-23 19:21:26.016371
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options = {'headers': {'sort': 'True'}})
    assert formatter.enabled == True

    assert formatter.format_headers("""\
    http://httpbin.org/headers
    Accept: application/json
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    Host: httpbin.org
    User-Agent: HTTPie/0.9.9
    \r\n
    """) == """\
    http://httpbin.org/headers
    Accept: application/json
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    Host: httpbin.org
    User-Agent: HTTPie/0.9.9
    \r\n
    """


# Generated at 2022-06-23 19:21:27.841171
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter(format_options)
    assert instance is not None
    assert instance.enabled is True


# Generated at 2022-06-23 19:21:37.293441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from_ = '''\
Connection: keep-alive
Content-Length: 64
Accept: */*
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip, deflate
User-Agent: python-requests/2.22.0
Host: httpbin.org
'''
    assert HeadersFormatter().format_headers(from_) == '''\
Connection: keep-alive
Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 64
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: python-requests/2.22.0
'''


# Class for writing to a file object and storing a copy of the data.

# Generated at 2022-06-23 19:21:39.697814
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert repr(HeadersFormatter)


# Unit tests for function format_headers

# Generated at 2022-06-23 19:21:48.988132
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\nContent-Length: 57\nContent-Type: application/json; charset=UTF-8\nDate: Fri, 18 May 2018 12:40:26 GMT\nServer: nginx/1.10.3 (Ubuntu)"
    headers_sorted = "HTTP/1.1 200 OK\nContent-Length: 57\nContent-Type: application/json; charset=UTF-8\nDate: Fri, 18 May 2018 12:40:26 GMT\nServer: nginx/1.10.3 (Ubuntu)"
    assert headers_formatter.format_headers(headers) == headers_sorted


# Generated at 2022-06-23 19:21:58.750554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    from httpie.plugins.formatters import formatters_manager
    headers_formatter = formatters_manager.instantiate(
            'headers',
            sort=True)

    # Act
    output_headers = headers_formatter.format_headers(
            """\
HTTP/1.1 200 OK
Content-Length: 35
Content-Type: application/json
X-Foo: Bar
Date: Sat, 24 Oct 2015 02:53:53 GMT
Server: waitress

""")

    # Assert
    assert output_headers == """\
HTTP/1.1 200 OK
Content-Length: 35
Content-Type: application/json
Date: Sat, 24 Oct 2015 02:53:53 GMT
Server: waitress
X-Foo: Bar

"""



# Generated at 2022-06-23 19:22:00.568440
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(**{'headers': {'sort': True}})


# Generated at 2022-06-23 19:22:07.451684
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    cases = [
        """
        user-agent: HTTPie/0.9.2
        accept-encoding: gzip, deflate
        accept: */*
        host: httpbin.org
        """,
        """
        accept: text/plain
        accept: application/json
        Content-Type: application/json
        X-Header-1: value-1
        X-Header-2: value-2
        x-header-3: value-3
        """,
        """
        accept: text/plain
        Host: httpbin.org:80
        content-type: application/json
        """,
    ]

# Generated at 2022-06-23 19:22:13.317852
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '{"Content-type": "application/json"}'
    print('Headers are:', headers)
    print('Formatted headers after sorting:', instance.format_headers(headers))

# Testing the 'format_headers' function of class HeadersFormatter

# Generated at 2022-06-23 19:22:23.151804
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers = '''\
GET / HTTP/1.1
Host: example.org
User-Agent: httpie
X-My-Header: The first X-My-Header
DNT: 1
Referer: http://httpie.org
Accept-Encoding: gzip, deflate
Accept: */*
X-My-Header: The second X-My-Header
Cache-Control: no-cache
'''
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:22:31.817563
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    h1 = hf.format_headers("""
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Dup: 1
X-Dup: 2
X-Dup: 3
X-Baz
""")
    h2 = hf.format_headers("""
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
X-Foo: Bar
X-Baz
X-Dup: 3
X-Dup: 2
X-Dup: 1
""")
    assert h1 == h2

# Generated at 2022-06-23 19:22:32.949629
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter)

# Generated at 2022-06-23 19:22:39.580746
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # test case 1:
    headers = '''\
HTTP/1.1 404 Not Found
User-Agent: HTTPie/0.9.9
Content-Length: 36
Cache-Control: max-age=0
Host: 127.0.0.1:8000
Accept: application/json
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7
Accept-Encoding: gzip,deflate
Accept-Language: en;q=0.5'''

# Generated at 2022-06-23 19:22:49.652216
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ""
    result = HeadersFormatter.format_headers(headers)
    assert result == ""
    headers = "HTTP/1.1 200 OK\r\nDate: Tue, 03 Jul 2012 06:07:34 GMT"
    result = HeadersFormatter.format_headers(headers)
    assert result == "HTTP/1.1 200 OK\r\nDate: Tue, 03 Jul 2012 06:07:34 GMT"

# Generated at 2022-06-23 19:22:50.946174
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  h = HeadersFormatter()
  assert(h.enabled)


# Generated at 2022-06-23 19:23:01.877076
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.3

    '''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.3

    '''
    headersFormatted = headers.replace('\n', '\r\n')
    headersFormatted = headersFormatted.replace('\r\r', '\r')

    #assert_equal(HeadersFormatter().format_headers(headers), expected)

# Generated at 2022-06-23 19:23:11.270711
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import httpie.input
    import httpie.plugins.builtin

    httpie.input.get_response = Mock(
        return_value = Mock(headers = dedent(
            """\
            HTTP/1.1 200 OK
            foo: baz
            bar: foo
            """
        )
    ))

    args = ['-f', 'headers', 'https://httpie.org']

    runner = CliRunner()
    with runner.isolated_filesystem():
        result = runner.invoke(
            Cli(httpie.plugins.builtin.load_plugins()),
            args=args,
            input="",
            env={},
            catch_exceptions=False
        )

        assert result.exit_code == ExitStatus.OK
        assert result.stdout.startswith('HTTP/1.1 200 OK')

# Generated at 2022-06-23 19:23:16.888239
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    assert headers.format_headers('''\
Content-Type: application/json
Accept: application/json
Accept-Charset: utf-8
Accept-Charset: iso-8859-1''') == '''\
Content-Type: application/json
Accept: application/json
Accept-Charset: utf-8
Accept-Charset: iso-8859-1'''

# Generated at 2022-06-23 19:23:19.267623
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Check that HeadersFormatter object is created
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, HeadersFormatter)

# Unit tests for format_headers() method

# Generated at 2022-06-23 19:23:29.570696
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that headers are sorted by name while retaining relative
    order of multiple headers with the same name.

    """
    headers = """
HTTP/1.1 200 OK
Server: nginx/1.1.19
Date: Thu, 17 Oct 2013 18:27:52 GMT
Content-Type: application/json
Transfer-Encoding: chunked
Connection: keep-alive
Allow: GET, POST, PUT
X-Powered-By: Phusion Passenger (mod_rails/mod_rack) 3.0.19
Set-Cookie: request_method=GET; path=/
X-Request-Id: 47dbc53d01ba50e6c8de70f1b5ab19b9
X-Runtime: 0.012572
Cache-Control: no-cache

"""
    # Call method format_headers with class Head

# Generated at 2022-06-23 19:23:31.700994
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert repr(headers_formatter) == '<HeadersFormatter: sort>'


# Generated at 2022-06-23 19:23:41.000048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    sorted_headers = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    }).format_headers("""
        HTTP/1.1 200 OK
        Date: Fri, 17 Nov 2017 12:00:48 GMT
        Content-Type: application/json
        Content-Length: 55
        Server: Gunicorn/19.7.1
        Connection: close
        X-Powered-By: Flask
        X-Processed-Time: 0.002619266128540039
    """)

# Generated at 2022-06-23 19:23:49.458633
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_input = """\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Content-Type: text/plain
X-Foo: Bar
X-Foo: Baz
"""

# Generated at 2022-06-23 19:23:55.273424
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
X-Foo: bar
Content-Length: 000000000
X-Foo: baz
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 000000000
X-Foo: bar
X-Foo: baz
"""
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-23 19:24:04.705603
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersPlugin
    class NewHeadersFormatter(HeadersFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True

# Generated at 2022-06-23 19:24:07.011552
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    plugin = HeadersFormatter(format_options={'headers':{'sort':False}},
                              config_dir='')
    assert plugin.enabled == False


# Generated at 2022-06-23 19:24:07.912659
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().__class__ == HeadersFormatter


# Generated at 2022-06-23 19:24:09.197394
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert "HeadersFormatter" == formatter.__class__.__name__


# Generated at 2022-06-23 19:24:10.937331
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	formatter = HeadersFormatter(format_options={'headers':{'sort': True}})
	assert formatter.enabled == True


# Generated at 2022-06-23 19:24:19.867796
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        '\r\n'.join(['Host: www.httpie.org',
                     'Accept: */*',
                     'Accept-Encoding: gzip, deflate',
                     'Content-Length: 18',
                     'Accept: application/json',
                     'Content-Type: application/json',
                     'Connection: keep-alive'])) == \
           '\r\n'.join(['Host: www.httpie.org',
                        'Accept: */*',
                        'Accept: application/json',
                        'Accept-Encoding: gzip, deflate',
                        'Connection: keep-alive',
                        'Content-Length: 18',
                        'Content-Type: application/json'])


# Generated at 2022-06-23 19:24:24.279745
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """\r\n
        a: 1
        b: 2
        a: 3
        a: 2
        """
    ) == """\r\n
        a: 1
        a: 2
        a: 3
        b: 2
        """

# Generated at 2022-06-23 19:24:26.007604
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(NotImplementedError):
        HeadersFormatter()




# Generated at 2022-06-23 19:24:33.020855
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    http = Http()
    http.formatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert http.formatter.format_headers('Content-Type: text/plain\r\nContent-Length: 3\r\nContent-Encoding: gzip\r\nContent-Length: 9999') == \
        'Content-Encoding: gzip\r\nContent-Length: 3\r\nContent-Length: 9999\r\nContent-Type: text/plain'

# Generated at 2022-06-23 19:24:34.669395
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    myobject = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert myobject


# Generated at 2022-06-23 19:24:41.137890
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '\r\n'.join(['HEADERS 1', 'Header-B: Value B', 'Header-A: Value A'])
    headers_formatted = headers_formatter.format_headers(headers)
    assert headers_formatted == '\r\n'.join(['HEADERS 1', 'Header-A: Value A', 'Header-B: Value B'])



# Generated at 2022-06-23 19:24:43.322533
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:24:50.258831
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: text/html
Connection: keep-alive
Content-Length: 1354
Cache-Control: max-age=0
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.4"""

    assert formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Accept: */*
Accept-Encoding: gzip, deflate
Cache-Control: max-age=0
Connection: keep-alive
Content-Length: 1354
Content-Type: text/html
User-Agent: HTTPie/0.9.4"""

# Generated at 2022-06-23 19:24:52.168054
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fp = HeadersFormatter()
    assert fp is not None


# Generated at 2022-06-23 19:25:01.569532
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        '''\
Content-Type: application/json
Connection: keep-alive
Cookie: cookie1=value1; cookie2=value2
''') == '''\
Content-Type: application/json
Cookie: cookie1=value1; cookie2=value2
Connection: keep-alive
'''


# Generated at 2022-06-23 19:25:12.780909
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

# Generated at 2022-06-23 19:25:23.222350
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    headers_formatter = HeadersFormatter()
    headers_in = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.google.com
User-Agent: HTTPie/1.0.0
'''
    # Exercise
    headers_out = headers_formatter.format_headers(headers_in)

    # Verify
    assert headers_out == '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.google.com
User-Agent: HTTPie/1.0.0
'''


# Generated at 2022-06-23 19:25:35.267909
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import pytest
    with pytest.raises(ValueError) as excinfo:
        formatter = HeadersFormatter(parse_kwargs={})
    assert excinfo.value.args[0] == 'format_options is required'

    with pytest.raises(ValueError) as excinfo:
        formatter = HeadersFormatter(parse_kwargs={'format_options': {}})
    assert excinfo.value.args[0] == 'format_options.headers is required'

    with pytest.raises(ValueError) as excinfo:
        formatter = HeadersFormatter(parse_kwargs={'format_options': {'headers': {}}})
    assert excinfo.value.args[0] == 'format_options.headers.sort is required'


# Generated at 2022-06-23 19:25:46.018394
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''POST / HTTP/1.1
Content-Length: 228
Content-Type: application/x-www-form-urlencoded
x-api-token: a4b4f1026a4a1dd8
Content-Encoding: gzip

'''
    f = HeadersFormatter()
    print(f.format_headers(headers), end='')
    # expected output
    # POST / HTTP/1.1
    # Content-Encoding: gzip
    # Content-Length: 228
    # Content-Type: application/x-www-form-urlencoded
    # x-api-token: a4b4f1026a4a1dd8
    #
    # <BLANKLINE>

# Generated at 2022-06-23 19:25:47.587437
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert  formatter.enabled == True


# Generated at 2022-06-23 19:25:50.395559
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:26:00.688720
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_str = """GET / HTTP/1.1
Host:   somedomain.com
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Referer: http://j1.m0.m2/
Connection: keep-alive
Cookie: PHPSESSID=r2t5uvjq435r4q7ib3vtdjq120"""

# Generated at 2022-06-23 19:26:03.094616
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = '\r\n'.join([
        'Multiple headers with the same name',
        'Header: value',
        'Header: value 2',
        'Another header: with a value',
    ])
    actual = HeadersFormatter().format_headers(expected)
    assert actual == expected

# Generated at 2022-06-23 19:26:06.515399
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert FormatterPlugin in HeadersFormatter.mro()
    assert FormatterPlugin.__init__ in HeadersFormatter.__init__.__func__.__globals__.values()

    assert HeadersFormatter.enabled == True


# Generated at 2022-06-23 19:26:08.977247
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    head_formatter = HeadersFormatter(format_options)
    assert head_formatter.enabled == True


# Generated at 2022-06-23 19:26:18.235361
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # setup
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    long_headers = """\
HTTP/1.1 200 OK
Date: Thu, 11 Jul 2019 07:06:24 GMT
Server: Apache/2.4.6 (CentOS) mod_fcgid/2.3.9 PHP/5.6.40
X-Powered-By: PHP/5.6.40
Content-Length: 506
Connection: close
Content-Type: text/html; charset=UTF-8

"""

# Generated at 2022-06-23 19:26:20.890562
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert format_headers('ABC:123\nDEF:456\nABC:789\n') == \
        'ABC:123\nABC:789\nDEF:456\n'

# Generated at 2022-06-23 19:26:22.301425
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:26:24.418534
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:26:33.419901
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ('POST / HTTP/1.1\r\n'
               'Host: example.org\r\n'
               'Content-Type: text/html; charset=utf-8\r\n'
               'Referer: http://demo.org\r\n'
               'Accept-Encoding: gzip, deflate, br\r\n'
               'Accept-Language: en-US\r\n'
               'Cookie: id=1001\r\n'
               '\r\n')


# Generated at 2022-06-23 19:26:44.402304
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # First set the environment variable called httpie_format
    # to headers.sort before running this test
    unittest.defaultTestLoader.loadTestsFromTestCase(HeadersFormatter)

    # declare variables to be used in the test

    # First set of headers
    first_set = """\
Accept-Language: en
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: text/html
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4)
                        AppleWebKit/537.78.2 (KHTML, like Gecko)
                        Version/7.0.6 Safari/537.78.2"""

    # Second set of headers

# Generated at 2022-06-23 19:26:47.892965
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert h.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-23 19:26:58.509312
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.9.9
"""
    headers_formatted = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9
"""
    assert HeadersFormatter(request_method='', request_url='', format_options={
        'headers': {
            'sort': True
        },
        'style': {
            'highlight': False
        }
    }).format_headers(headers) == headers_formatted


# TODO: Add unit test for method format_headers for

# Generated at 2022-06-23 19:27:01.552546
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Input pattern
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    # Expected output
    assert formatter.enabled == True


# Generated at 2022-06-23 19:27:07.344453
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert (formatter.format_headers('Content-Type: application/json\r\n'
                                     'Accept-Encoding: gzip, deflate\r\n'
                                     'Accept: */*\r\n'
                                     'User-Agent: HTTPie/0.9.2\r\n') ==
            'Content-Type: application/json\r\n'
            'Accept: */*\r\n'
            'Accept-Encoding: gzip, deflate\r\n'
            'User-Agent: HTTPie/0.9.2\r\n')

# Generated at 2022-06-23 19:27:09.938240
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:27:13.338169
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class E:
        pass
    e = E()
    e.format_options = E()
    e.format_options.headers = E()
    e.format_options.headers.sort = True
    t = HeadersFormatter(**e.__dict__)
    assert t.enabled == e.format_options.headers.sort

# Generated at 2022-06-23 19:27:20.452250
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert headers_formatter.enabled == False
    headers_formatter = HeadersFormatter(format_options={'headers': {}})
    assert headers_formatter.enabled == False
    headers_formatter = HeadersFormatter(format_options={})
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:27:28.177169
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Content-Type: application/json
Authorization: Token
User-Agent: httpie/0.9.9
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 41
Host: httpbin.org

'''

    formatter = HeadersFormatter()
    output = formatter.format_headers(headers)  # type: ignore

    lines = output.splitlines()

    assert lines[0] == '''Content-Type: application/json
'''
    assert lines[1] == '''Accept: */*
'''
    assert lines[2] == '''Accept-Encoding: gzip, deflate
'''
    assert lines[3] == '''Authorization: Token
'''

# Generated at 2022-06-23 19:27:30.598412
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Age: 12
Content-Length: 348
Content-Type: application/json; charset=utf-8
Date: Tue, 17 May 2016 05:58:45 GMT
X-Ratelimit-Limit: 10000
X-Ratelimit-Remaining: 9980

'''
    assert formatter.format_headers(headers) == headers

# Generated at 2022-06-23 19:27:36.192557
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	p = HeadersFormatter()
	assert p.format_headers("GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\n\r\n") == \
"GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\n\r\n"

# Generated at 2022-06-23 19:27:44.471814
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    input_headers = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Content-Length': '40',
        'Content-Type': 'application/json',
        'Host': '127.0.0.1:5000',
        'User-Agent': 'python-requests/2.21.0',
        'X-Amzn-Trace-Id': 'Root=1-5d6a68db-193c4d65eb4df2030e4b4d3f'
    }
    input_format_options = {
        'headers': {
            'sort': True
        }
    }

# Generated at 2022-06-23 19:27:46.915008
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter


# Generated at 2022-06-23 19:27:50.489603
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.headers() == "Headers:")

# Test for format_headers() method

# Generated at 2022-06-23 19:27:51.694885
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-23 19:28:02.643257
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

# Generated at 2022-06-23 19:28:05.546660
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:28:14.032641
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers_string = """HTTP/1.1 200 OK
Accept-Ranges: bytes
Allow: GET, HEAD
Content-Length: 478
Content-Type: text/html
Date: Sat, 20 Jul 2019 13:57:09 GMT
Etag: "1541025663+ident"
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (dcb/7EE6)
Vary: Accept-Encoding"""
    formatted_headers = hf.format_headers(headers_string)

# Generated at 2022-06-23 19:28:16.462765
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter({'headers':{'sort':True}},
                         {'headers':{'sort':True}})

    assert f.enabled == True

# Generated at 2022-06-23 19:28:21.967819
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(
        formatter=None,
        format_options={'headers': {'sort': True}},
        colors=None,
        stdin_isatty=True,
        stdout_isatty=True,
        style=None
    )

    assert hf.enabled == True
    assert hf.data == 'headers'


# Generated at 2022-06-23 19:28:23.806523
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:28:25.875180
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.format_options['headers']['sort']


# Generated at 2022-06-23 19:28:33.598594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def format_headers(headers: str) -> str:
        return HeadersFormatter().format_headers(headers)

    assert (
        format_headers(
            headers='''
            FOO: 1
            X-Foo: 2
            bar: 3
            x-Bar: 4
            '''
        )
    ==
        '''
        FOO: 1
        X-Foo: 2
        bar: 3
        x-Bar: 4
        '''
    )

# Generated at 2022-06-23 19:28:35.664896
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter()


# Generated at 2022-06-23 19:28:38.436765
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Given
    hf = HeadersFormatter()

    # Then
    assert hf.enabled is False


# Generated at 2022-06-23 19:28:41.642409
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled

    formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert not formatter.enabled

# Generated at 2022-06-23 19:28:43.064148
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options='')
    assert isinstance(headers, HeadersFormatter)
    assert headers.enabled == False


# Generated at 2022-06-23 19:28:54.675966
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup of a response with sorted headers
    response = Response(
        status_code=200,
        http_version='1.1',
        headers={'header-two': 'value-two', 'header-one': 'value-one'},
        body='')
    line1 = 'HTTP/1.1 200 OK\r\n'
    headers_sorted = f'header-one: value-one\r\nheader-two: value-two'
    sorted_response = f'{line1}{headers_sorted}\r\n\r\n'
    # Setup of a response with unsorted headers

# Generated at 2022-06-23 19:29:03.760591
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter({'user-agent': "httpie", 'accept': "*/*", 'cookie': '_ga=GA1.2.1624672911.1539234048; user_session=d21oCoR_b46-LzAFmDvhC3Nq1Ntlb5GtJ5X5eGyd0nPYBH09'})

# Generated at 2022-06-23 19:29:10.887838
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter().format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Content-Length: 15\r\n'
        'Server: Werkzeug/0.14.1 Python/3.7.3\r\n'
        'Date: Sun, 12 Jan 2020 18:34:17 GMT\r\n'
        '\r\n'
        '{ "json": "object" }\r\n'
    )

# Generated at 2022-06-23 19:29:12.116436
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert not bool(formatter.enabled)


# Generated at 2022-06-23 19:29:17.431072
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Content-Type: application/json
Accept: */*
Content-Length: 2
Cookie: foo=bar
Cookie: baz=qux
Connection: close
"""
    expected = """\
GET / HTTP/1.1
Accept: */*
Connection: close
Content-Length: 2
Content-Type: application/json
Cookie: foo=bar
Cookie: baz=qux
"""
    actual = HeadersFormatter().format_headers(headers)
    assert actual == expected



# Generated at 2022-06-23 19:29:20.389067
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert isinstance(h, HeadersFormatter)


# Generated at 2022-06-23 19:29:22.156834
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers':{'sort':True}}) is not None
