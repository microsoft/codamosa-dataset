

# Generated at 2022-06-23 19:19:23.885687
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.enabled
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-23 19:19:25.897734
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options['headers']['sort'] is True

# Generated at 2022-06-23 19:19:28.351365
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    hf.format_headers("asdf")
    assert hf.format_options['headers']['sort'] == 1


# Generated at 2022-06-23 19:19:31.283161
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options == {
        'headers': {
            'sort': False,
            'style': None
        }
    }
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:19:32.767966
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter()
    assert(head.format_options == {'headers': {'sort': True}})


# Generated at 2022-06-23 19:19:34.586994
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter is not None


# Generated at 2022-06-23 19:19:40.600601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersformatter = HeadersFormatter()
    assert headersformatter.format_headers('Host: 127.0.0.1:80\r\nAccept: text/html\r\nHost: localhost') == 'Host: 127.0.0.1:80\r\nHost: localhost\r\nAccept: text/html'


# Generated at 2022-06-23 19:19:46.552346
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options['headers']['sort'] = True
    input = '''\
Date: Sat, 10 Oct 2020 10:50:00 GMT
Date: Sat, 11 Oct 2020 10:50:00 GMT
Content-Length: 0
'''
    output = '''\
Date: Sat, 10 Oct 2020 10:50:00 GMT
Date: Sat, 11 Oct 2020 10:50:00 GMT
Content-Length: 0
'''
    assert headers_formatter.format_headers(input) == output


# Generated at 2022-06-23 19:19:47.756278
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()


# Generated at 2022-06-23 19:19:58.152533
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = textwrap.dedent('''
        HTTP/1.0 200 OK
        date: Thu, 03 Sep 2020 13:22:12 GMT
        content-type: text/html; charset=utf-8
        content-length: 13
        status: 200''')
    expected_headers = textwrap.dedent('''
        HTTP/1.0 200 OK
        content-length: 13
        content-type: text/html; charset=utf-8
        date: Thu, 03 Sep 2020 13:22:12 GMT
        status: 200''')
    actual_headers = formatter.format_headers(headers)
    assert expected_headers == actual_headers



# Generated at 2022-06-23 19:20:04.574242
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create instance of class HeadersFormatter
    formatter = HeadersFormatter()
    # print(formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccept: application/json\r\nContent-Type: application/json\r\n\r\n'))
    # print(formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccept: application/json\r\nContent-Type: application/json\r\n\r\n'))
    # print(formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccept: application/json\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-23 19:20:14.173364
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = HeadersFormatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: text/plain\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 4\r\n'
        'Link: <https://httpbin.org/>; rel="next"'
    )

    print(actual)

    expected = (
        'HTTP/1.1 200 OK\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 4\r\n'
        'Content-Type: text/plain\r\n'
        'Link: <https://httpbin.org/>; rel="next"'
    )

    assert actual == expected



# Generated at 2022-06-23 19:20:15.671809
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, FormatterPlugin)


# Generated at 2022-06-23 19:20:21.806796
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = '''
    HTTP/1.1 200 OK
    Cache-Control: no-cache
    Content-Type: application/json
    Date: Thu, 12 Oct 2017 20:07:17 GMT
    Expires: -1
    Pragma: no-cache
    Server: Microsoft-IIS/8.0
    X-AspNet-Version: 4.0.30319
    X-Powered-By: ASP.NET
    Content-Length: 5014
    '''


# Generated at 2022-06-23 19:20:25.239719
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is False
    headers_formatter = HeadersFormatter(sort=True)
    assert headers_formatter.enabled is True
    headers_formatter = HeadersFormatter(sort=False)
    assert headers_formatter.enabled is False


# Generated at 2022-06-23 19:20:33.763057
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={"headers": {"sort": "False"}})
    assert formatter.enabled is False

# Generated at 2022-06-23 19:20:38.566974
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # create the formatter object
    headers_formatter = HeadersFormatter()
    # check the output of the method is a string
    assert isinstance(headers_formatter.format_headers(os.environ.get('http_proxy')), str)

# Generated at 2022-06-23 19:20:40.664071
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:20:44.814643
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Length: 123\r\n' \
              'Content-Type: text/html\r\n' \
              'Server: BaseHTTP/0.6 Python/3.6.1\r\n' \
              'Date: Sun, 26 Nov 2017 02:31:25 GMT\r\n'
    expected = 'HTTP/1.1 200 OK\r\n' \
               'Content-Length: 123\r\n' \
               'Content-Type: text/html\r\n' \
               'Date: Sun, 26 Nov 2017 02:31:25 GMT\r\n' \
               'Server: BaseHTTP/0.6 Python/3.6.1'
    assert formatter.format_

# Generated at 2022-06-23 19:20:47.394786
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})
    assert not HeadersFormatter(format_options={'headers': {'sort': False}})


# Generated at 2022-06-23 19:20:56.056617
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(
        """User-Agent: Dummy Client 1.0
Accept: application/json
Accept: text/plain
Date: Sun, 01 Apr 2018 10:56:51 GMT
Host: localhost:5000
X-Session-ID: abcdef
Content-Length: 0
Connection: keep-alive
""") == """User-Agent: Dummy Client 1.0
Accept: application/json
Accept: text/plain
Content-Length: 0
Connection: keep-alive
Date: Sun, 01 Apr 2018 10:56:51 GMT
Host: localhost:5000
X-Session-ID: abcdef
"""


# Generated at 2022-06-23 19:20:58.055514
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled == True


# Unit tests for format_headers method of class HeadersFormatter

# Generated at 2022-06-23 19:20:59.513708
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)


# Generated at 2022-06-23 19:21:03.607264
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(
        format_options = {'headers': {'sort': True}})
    out = formatter.format_headers('\r\n'.join(['', 'k: c', 'a: b', 'k: a']))
    assert out == '\r\n'.join(['', 'a: b', 'k: c', 'k: a'])



# Generated at 2022-06-23 19:21:04.456333
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-23 19:21:16.558126
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test for default sort option = True (sorts headers alphabetically)
    formatter = HeadersFormatter(styles={}, format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:21:23.790525
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter()
    assert str(excinfo.value) == 'format_options not provided!'
    
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(format_options={})
    assert str(excinfo.value) == 'format_options[\'headers\'] missing!'
    
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(format_options={'headers': {}})
    assert str(excinfo.value) == 'format_options[\'headers\'][\'sort\'] missing!'
    
    with pytest.raises(Exception) as excinfo:
        HeadersFormatter(format_options={'headers': {'sort': 1, 'color': 2}})

# Generated at 2022-06-23 19:21:26.550689
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**{'headers':{'sort':True}})
    assert formatter.enabled is True


# Generated at 2022-06-23 19:21:28.899801
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test default constructor
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True
    

# Generated at 2022-06-23 19:21:30.480847
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-23 19:21:39.000460
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:21:42.700531
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h
    assert h.format_options['headers']['sort']
    assert not h.format_options['headers']['sort']['enabled']


# Generated at 2022-06-23 19:21:45.720050
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled
# Test to see if headers are sorted

# Generated at 2022-06-23 19:21:47.007583
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter


# Generated at 2022-06-23 19:21:56.599269
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    lines = [
        'Content-Length: 130',
        'Connection: Keep-Alive',
        'Accept: text/plain',
        'Content-Length: 130',
        'Keep-Alive: 300',
        'Content-Type: text/html',
        'Content-Length: 130',
    ]
    headers = '\r\n'.join(lines)
    assert formatter.format_headers(headers) == '\r\n'.join(
        lines[:1] + sorted(lines[1:], key=lambda h: h.split(':')[0])
    )

# Generated at 2022-06-23 19:22:01.932903
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    expected = "\
HTTP/1.1 200 OK\r\n\
a: 1\r\n\
Content-Type: text/html\r\n\
Content-Length: 11\r\n\
Server: TestServer\r\n\
\r\n\
<h1>Test</h1>"
    assert formatter.format_headers(expected) == expected


# Generated at 2022-06-23 19:22:05.735534
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()
    assert len(HeadersFormatter.format_options) == 1, "No 'headers' key in format_options"
    assert HeadersFormatter.format_options['headers']['sort'] == False, "No 'sort' key for 'headers' key in format_options"
    assert HeadersFormatter.__doc__ is not None, "No __doc__ attribute"


# Generated at 2022-06-23 19:22:11.207168
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h1 = 'Accept: text/html\r\n\
Accept-Encoding: gzip, deflate\r\n\
Accept-Language: en-US, en'
    h2 = 'Accept-Language: en-US, en\r\n\
Accept: text/html\r\n\
Accept-Encoding: gzip, deflate'
    f = HeadersFormatter()
    assert h2 == f.format_headers(h1)

# Generated at 2022-06-23 19:22:14.753357
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create an instance of HeadersFormatter
    inst = HeadersFormatter()
    # Test default values of instance attributes
    assert inst.format_options['headers']['sort'] == False
    assert inst.enabled == False

# Generated at 2022-06-23 19:22:23.542690
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(headers_input) == headers_output

# Input and output data for method format_headers of class HeadersFormatter
headers_input = """\
Content-Type: application/json
User-Agent: HTTPie/0.9.8
Host: httpbin.org
Accept: application/json, */*
Connection: keep-alive
Accept-Encoding: gzip, deflate
Content-Length: 2
"""
headers_output = """\
Content-Type: application/json
User-Agent: HTTPie/0.9.8
Host: httpbin.org
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: application/json, */*
Content-Length: 2
"""

# Generated at 2022-06-23 19:22:26.834176
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter({'headers': {'sort': True}})
    assert hf.enabled
    assert hf.format_options['headers']['sort']
    assert hf.format_options['verbose'] == 4


# Generated at 2022-06-23 19:22:35.759337
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = (
        'Content-Type: application/json\r\n'
        'Host: localhost:4999\r\n'
        'Accept: */*\r\n'
        'Connection: keep-alive\r\n'
        'User-Agent: HTTPie/0.9.9'
    )
    # Checks if the sorting of the headers is done correctly
    expected_headers = (
        'Content-Type: application/json\r\n'
        'Accept: */*\r\n'
        'Connection: keep-alive\r\n'
        'Host: localhost:4999\r\n'
        'User-Agent: HTTPie/0.9.9'
    )

# Generated at 2022-06-23 19:22:40.854047
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert \
    '''f: 0
a: 2
a: 1''' == \
    HeadersFormatter({}).format_headers('''a: 1
f: 0
a: 2''')


__plugin__ = HeadersFormatter

# Generated at 2022-06-23 19:22:50.370617
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case 1
    headers = """GET / HTTP/1.1\r
Host: foo.com\r
User-Agent: httpie/0.7.0\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
\r
"""
    expected_headers = """GET / HTTP/1.1\r
Accept: */*\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
Host: foo.com\r
User-Agent: httpie/0.7.0\r
\r
"""
    formatter = HeadersFormatter()

    result = formatter.format_headers(headers)

    assert result == expected_headers
    # Test case 2

# Generated at 2022-06-23 19:22:56.905701
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:23:07.448934
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(**{'format_options': {'headers': {'sort': True}}})
    assert formatter.format_headers("""\
HTTP/1.1 200 OK
Connection: close
Date: Wed, 29 Mar 2017 17:58:23 GMT
Server: Werkzeug/0.12.1 Python/3.5.2
Content-Type: text/html; charset=utf-8
Content-Length: 11

Hello world""") == """\
HTTP/1.1 200 OK
Content-Length: 11
Content-Type: text/html; charset=utf-8
Connection: close
Date: Wed, 29 Mar 2017 17:58:23 GMT
Server: Werkzeug/0.12.1 Python/3.5.2

Hello world"""

# Generated at 2022-06-23 19:23:08.520623
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled is False


# Generated at 2022-06-23 19:23:18.961461
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:23:24.243138
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h1 = 'Content-Type: application/json\r\n'
    h2 = 'User-Agent: HTTPie\r\n'
    h3 = 'Content-Type: text/plain'
    headers_str = h1 + h2 + h3
    assert HeadersFormatter.format_headers(headers_str).splitlines() == ['Content-Type: application/json',
        'User-Agent: HTTPie', 'Content-Type: text/plain']

# Generated at 2022-06-23 19:23:33.644283
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    method format_headers of class HeadersFormatter
    """

    headers = """\
HTTP/1.0 200 OK
Content-Length: 123
Content-Type: application/json
Date: Tue, 05 Mar 2019 08:41:58 GMT
Server: WSGIServer/0.2 CPython/3.7.2
"""
    expected_headers = """\
HTTP/1.0 200 OK
Content-Length: 123
Content-Type: application/json
Date: Tue, 05 Mar 2019 08:41:58 GMT
Server: WSGIServer/0.2 CPython/3.7.2
"""

    assert expected_headers == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-23 19:23:38.536044
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Tests if method format_headers of class HeadersFormatter formats headers as expected."""
    assert HeadersFormatter.format_headers("""
    1: abc
    2: def
    1: 123
    1: aaa
    2: efg
    """
    ) == """
    1: abc
    1: 123
    1: aaa
    2: def
    2: efg
    """

# Generated at 2022-06-23 19:23:39.193525
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:23:48.651465
# Unit test for constructor of class HeadersFormatter

# Generated at 2022-06-23 19:23:58.016594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()

# Generated at 2022-06-23 19:24:08.880851
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test case for the method format_headers of class HeadersFormatter
    """
    input = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Transfer-Encoding: chunked',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Date: Mon, 27 Apr 2020 15:33:05 GMT',
        '\r\n'
    ])
    output = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Date: Mon, 27 Apr 2020 15:33:05 GMT',
        'Transfer-Encoding: chunked',
        '\r\n'
    ])

# Generated at 2022-06-23 19:24:12.075306
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == False


# Generated at 2022-06-23 19:24:17.748047
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    head = HeadersFormatter()

    headers = '''Content-Type: text/html; charset=utf-8
Date: Sun, 08 Nov 2015 04:45:45 GMT
Server: gunicorn/19.4.5
Connection: close
Content-Length: 0
Cache-Control: no-cache
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
'''

    print(head.format_headers(headers))


# Generated at 2022-06-23 19:24:29.111585
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:24:35.748826
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(**{'headers': {'sort': True}})
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Length: 123\r\nfoo: 1\r\nbar: 2\r\nfoo: 2\r\nAccept: */*\r\nContent-Type: application/json\r\n') == 'HTTP/1.1 200 OK\r\nAccept: */*\r\nContent-Length: 123\r\nContent-Type: application/json\r\nbar: 2\r\nfoo: 1\r\nfoo: 2\r\n'



# Generated at 2022-06-23 19:24:45.860950
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = (
        "HTTP/1.1 200 OK\r\n"
        "Connection: close\r\n"
        "Content-Length: 1715\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Date: Sun, 28 Jan 2018 01:05:49 GMT\r\n"
        "Server: nginx/1.13.3\r\n"
        "Set-Cookie: lang=en; Expires=Tue, 27-Feb-18 01:05:49 GMT; Path=/\r\n"
        "Via: 1.1 vegur\r\n"
        "\r\n"
        "foo"
    )
    assert HeadersFormatter().format_headers(expected) == expected



# Generated at 2022-06-23 19:24:47.057479
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled == False

# Generated at 2022-06-23 19:24:50.802870
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-23 19:24:58.950892
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Tests that method format_headers of class HeadersFormatter
    sorts headers by name while retaining relative
    order of multiple headers with the same name.
    """
    # Create a HeadersFormatter object.
    headers_formatter = HeadersFormatter()
    result = headers_formatter.format_headers("""\
HTTP/1.1 200 OK
Date: Tue, 04 Dec 2018 21:45:58 GMT
Content-Type: text/html

""")
    assert result == """\
HTTP/1.1 200 OK
Content-Type: text/html
Date: Tue, 04 Dec 2018 21:45:58 GMT
"""


# Generated at 2022-06-23 19:25:06.081677
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers':{'sort': True}})
    headers = """HTTP/1.1 200 OK
Content-Length: 7
Content-Type: text/plain; charset=utf-8
Server: ExampleServer
"""
    actual = formatter.format_headers(headers)
    expected = """HTTP/1.1 200 OK
Content-Length: 7
Content-Type: text/plain; charset=utf-8
Server: ExampleServer
"""
    assert actual == expected

# Generated at 2022-06-23 19:25:13.835741
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import BASIC_OPTIONS, DEFAULT_OPTIONS_MAP
    test_formatter = HeadersFormatter(**BASIC_OPTIONS)
    assert isinstance(test_formatter, FormatterPlugin)
    assert test_formatter.format_options == DEFAULT_OPTIONS_MAP
    assert test_formatter.enabled == test_formatter.format_options['headers']['sort']


# unit test for format_headers method

# Generated at 2022-06-23 19:25:15.403222
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(None)
    assert isinstance(formatter, HeadersFormatter)


# Generated at 2022-06-23 19:25:19.265876
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print('Testing constructor of class HeadersFormatter')
    headers_formatter = HeadersFormatter(sort=True)
    print(headers_formatter)


# Generated at 2022-06-23 19:25:30.101161
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create a new instance of class HeadersFormatter
    headers_formatter = HeadersFormatter()

    # Assert the value of method "format_headers" for the given inputs
    assert headers_formatter.format_headers('Accept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nHost: example.com\r\nUser-Agent: HTTPie/1.0.2\r\n') == 'Accept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nHost: example.com\r\nUser-Agent: HTTPie/1.0.2'

# Generated at 2022-06-23 19:25:33.305792
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled is True


# Generated at 2022-06-23 19:25:39.539013
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import httpie
    headers = (
        "GET / HTTP/1.1\r\n"
        "Accept: application/json\r\n"
        "Accept-Encoding: gzip, deflate\r\n"
        "Host: test.test\r\n"
        "Connection: keep-alive\r\n"
        "User-Agent: HTTPie/1.0.0\r\n"
        "Accept-Language: en-us\r\n"
        "X-My-Header: first\r\n"
        "X-My-Header: second\r\n"
    )
    formatter = HeadersFormatter(format_options=httpie.cli.FormatOptions())

# Generated at 2022-06-23 19:25:44.427964
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = 'foo: 1\r\nbar: 2\r\nbaz: 3\r\n'.splitlines()
    assert HeadersFormatter().format_headers(
        '\r\n'.join(lines)
    ) == '\r\n'.join(sorted(lines, key=lambda h: h.split(':')[0]))

# Generated at 2022-06-23 19:25:45.742575
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled is not None

# Generated at 2022-06-23 19:25:47.509932
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is True


# Generated at 2022-06-23 19:25:55.242748
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
X-B: 2
X-A: 1
X-B: 3
Content-Length: 2'''
    expected_headers = '''\
HTTP/1.1 200 OK
X-A: 1
X-B: 2
X-B: 3
Content-Length: 2'''
    assert header_formatter.format_headers(headers) == expected_headers



# Generated at 2022-06-23 19:25:58.561964
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create an object of the class HeadersFormatter
    headers_formatter = HeadersFormatter()
    # Assert that the 'headers' attribute is a dictionary
    assert isinstance(headers_formatter.headers, dict)


# Generated at 2022-06-23 19:26:09.673395
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = [
        'HTTP/1.1 200 OK',
        'Server: nginx/1.4.6 (Ubuntu)',
        'Date: Sun, 15 Oct 2017 07:02:49 GMT',
        'Content-Type: application/json',
        'Connection: keep-alive',
        'X-Powered-By: PHP/5.5.9-1ubuntu4.20',
        'Access-Control-Allow-Origin: *',
        'Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, PATCH, DELETE',
        'Access-Control-Allow-Headers: Authorization, Content-Type',
        'Access-Control-Allow-Credentials: true',
        'Content-Length: 4'
    ]


# Generated at 2022-06-23 19:26:13.257425
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = {
            'headers': {
                'sort': True
                }
            }
    headers_formatter = HeadersFormatter(format_options=options)
    assert headers_formatter.format_options == options
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:26:21.461218
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # arrange
    formatter_plugin_headers_formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nHeader-A: 1\r\nHeader-B: 2\r\nHeader-A: 3'

    # act
    result = formatter_plugin_headers_formatter.format_headers(headers)

    # assert
    assert 'Header-A: 1' == result.splitlines()[1]
    assert 'Header-A: 3' == result.splitlines()[2]
    assert 'Header-B: 2' == result.splitlines()[3]

# Generated at 2022-06-23 19:26:31.343241
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # prepare test data
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:26:40.397377
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Host: example.org
host: 127.0.0.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/x-www-form-urlencoded
"""
    expected = """\
Host: example.org
host: 127.0.0.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/x-www-form-urlencoded
"""
    assert HeadersFormatter().format_headers(headers) == expected

# Generated at 2022-06-23 19:26:43.096304
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head_format = HeadersFormatter()
    assert head_format.enabled == head_format.format_options['headers']['sort']


# Generated at 2022-06-23 19:26:46.356985
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.enabled


# Generated at 2022-06-23 19:26:52.240508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({}, {})
    assert formatter.enabled is False
    assert formatter.get_options().get('headers').get('sort') is False
    assert formatter.format_headers("Content-Length: 1\r\n\r\n") == \
    "Content-Length: 1\r\n\r\n"


# Generated at 2022-06-23 19:26:56.747484
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin

    # Create dict and set options
    format_options = {}
    format_options['headers'] = {}
    format_options['headers']['sort'] = True

    obj = HeadersFormatter(format_options=format_options)
    assert obj.enabled == True



# Generated at 2022-06-23 19:26:59.700283
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test for headers constructor
    headers = HeadersFormatter()
    print(headers)


# Generated at 2022-06-23 19:27:07.322875
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    assert(fmt.format_headers('foo: bar\nbar: foo\nbaz: foo')
           == 'foo: bar\nbar: foo\nbaz: foo')
    assert(fmt.format_headers('foo: bar\nbar: foo\nbaz: foo\nbar: bar')
           == 'foo: bar\nbar: foo\nbar: bar\nbaz: foo')
    assert(fmt.format_headers('foo: bar\nbar: foo\nbaz: foo\nbar: bar\nbar: baz')
           == 'foo: bar\nbar: foo\nbar: bar\nbar: baz\nbaz: foo')

# Generated at 2022-06-23 19:27:15.039848
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = '''
    GET / HTTP/1.1
    Accept: application/json, */*
    Content-Length: 5
    Content-Type: application/x-www-form-urlencoded
    Host: httpbin.org
    User-Agent: HTTPie/0.9.4
    '''

    expected_headers = '''
    GET / HTTP/1.1
    Accept: application/json, */*
    Content-Length: 5
    Content-Type: application/x-www-form-urlencoded
    Host: httpbin.org
    User-Agent: HTTPie/0.9.4
    '''

    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-23 19:27:23.707043
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
User-Agent: curl/7.24.0 (x86_64-apple-darwin12.0) libcurl/7.24.0 OpenSSL/0.9.8x zlib/1.2.5
Accept: */*
Host: localhost
Content-Length: 5
Content-Type: multipart/form-data; boundary=----------------------------f9148957d0f0

'''

# Generated at 2022-06-23 19:27:35.275772
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance_HeadersFormatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    instance_HeadersFormatter.format_headers('GET / HTTP/1.1\r\n'
                                             'Host: example.com\r\n'
                                             'Accept: text/plain\r\n'
                                             'Accept: text/html\r\n'
                                             '\r\n'
                                             '')

# Generated at 2022-06-23 19:27:41.562068
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    fixed = headersFormatter.format_headers('HTTP/1.1 200 OK\r\nCookie: foo\r\nContent-type: image/png\r\nAccept: text/html\r\nContent-Encoding: gzip\r\n')
    assert fixed == 'HTTP/1.1 200 OK\r\nAccept: text/html\r\nContent-Encoding: gzip\r\nContent-type: image/png\r\nCookie: foo\r\n'

# Generated at 2022-06-23 19:27:43.495418
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'enabled': True, 'sort': True}})
    assert hf.enabled


# Generated at 2022-06-23 19:27:45.056848
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert hf.enabled



# Generated at 2022-06-23 19:27:56.490760
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # arrange
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    string = 'HTTP/1.1 200 OK\r\nfoo: bar\r\nx-x: 3\r\nContent-Type: application/json\r\nA: 1\r\nA: 2\r\nA: 3\r\n\r\n'
    expected = 'HTTP/1.1 200 OK\r\nA: 1\r\nA: 2\r\nA: 3\r\nContent-Type: application/json\r\nfoo: bar\r\nx-x: 3\r\n\r\n'

    # act
    actual = formatter.format_headers(string)

    # assert
    assert actual == expected


# Generated at 2022-06-23 19:27:58.582470
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert issubclass(HeadersFormatter, FormatterPlugin)
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-23 19:27:59.478800
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-23 19:28:00.972369
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter is not None


# Generated at 2022-06-23 19:28:04.486490
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    assert fmt.enabled


# Generated at 2022-06-23 19:28:05.348495
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()



# Generated at 2022-06-23 19:28:07.479471
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:28:08.341666
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter


# Generated at 2022-06-23 19:28:12.523460
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(**{'format_options': {'headers': {'sort': False}}}) is not None
    assert HeadersFormatter(**{'format_options': {'headers': {'sort': False}}}).enabled is False
    assert HeadersFormatter(**{'format_options': {'headers': {'sort': True}}}).enabled is True


# Generated at 2022-06-23 19:28:20.632935
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected_headers = (
        'HTTP/1.1 200 OK\r\n'
        'Link: <https://github.com>; rel="github"\r\n'
        'Set-Cookie: foo=bar; Domain=example.com\r\n'
        'Set-Cookie: baz=foo; Domain=example.com\r\n'
        'Set-Cookie: baz=foo; Domain=example.com\r\n'
        'X-Foo: 1\r\n'
        'X-Foo: 2\r\n'
        'X-Foo: 3\r\n'
    )

    headers_formatter = HeadersFormatter()

# Generated at 2022-06-23 19:28:24.778337
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Copy-paste of the above __init__ method due to it being a
    magic method.
    """
    formatter = HeadersFormatter(**{
        'format_options': {
            'headers': {
                'sort': True
            }
        }
    })

    assert formatter.enabled


# Generated at 2022-06-23 19:28:31.577708
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = ('X-Foo: 1\r\n'
               'X-Bar: 2\r\n'
               'X-Foo: 3\r\n'
               'X-Baz: 4')
    expected_headers = ('X-Bar: 2\r\n'
                        'X-Baz: 4\r\n'
                        'X-Foo: 1\r\n'
                        'X-Foo: 3')
    assert hf.format_headers(headers) == expected_headers


# Generated at 2022-06-23 19:28:38.233095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    H = HeadersFormatter()
    string = '\r\n'.join(['First-Header: value', 'Second-Header: value', 'First-Header: another value'])
    expected = '\r\n'.join(['First-Header: value', 'First-Header: another value', 'Second-Header: value'])
    actual = H.format_headers(string)
    assert actual == expected

# Generated at 2022-06-23 19:28:43.731822
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers_input = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        'Content-Length: 18\r\n'
        'Connection: close\r\n'
        'Date: Thu, 07 Nov 2019 07:35:25 GMT\r\n'
        'Server: Python/3.7 aiohttp/3.6.2\r\n'
        '\r\n')

# Generated at 2022-06-23 19:28:46.669751
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor
    assert HeadersFormatter


# Generated at 2022-06-23 19:28:49.760172
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Unit: Constructor for Headers Formatter
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)
    assert formatter.enabled == False


# Generated at 2022-06-23 19:28:58.890428
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    def format_function(headers: str) -> str:
        formatter = HeadersFormatter()
        return formatter.format_headers(headers)

    headers = '''\
Connection: close
Content-Type: application/json
Date: Thu, 27 Apr 2017 12:58:50 GMT
Transfer-Encoding: chunked

'''
    expected = '''\
Connection: close
Content-Type: application/json
Date: Thu, 27 Apr 2017 12:58:50 GMT
Transfer-Encoding: chunked

'''
    assert format_function(headers) == expected

    # Insert a new header
    headers = '''\
Connection: close
X-Header: 123
Content-Type: application/json
Date: Thu, 27 Apr 2017 12:58:50 GMT
Transfer-Encoding: chunked

'''

# Generated at 2022-06-23 19:29:00.149249
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort':True}})


# Generated at 2022-06-23 19:29:06.944700
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 235
Date: Thu, 02 Aug 2018 15:37:23 GMT""".replace('\n', '\r\n')
    expected = """\
Content-Type: application/json
Cache-Control: no-cache
Content-Length: 235
Date: Thu, 02 Aug 2018 15:37:23 GMT""".replace('\n', '\r\n')
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:29:15.712485
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Length: 151
Content-Type: application/json
Date: Tue, 20 Oct 2020 08:27:05 GMT
ETag: W/"97-AjKJ3xzqDkqQ2Kz+1D99XlZJiE"
Server: Cowboy
Connection: keep-alive
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 9a39a4eb-3199-4e3c-b2ce-7415f7af8d08
X-Runtime: 0.023689
Vary: Origin
Transfer-Encoding: chunked\
'''
    assert headers_formatter.format_headers(headers) == headers

# Generated at 2022-06-23 19:29:25.838416
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers= '''\
HTTP/1.1 200 OK
Accept-Encoding: gzip, deflate
Cache-Control: max-age=0
Connection: keep-alive
Content-Length: 170
Content-Type: application/json; charset=utf-8
Date: Fri, 9 Feb 2018 07:22:31 GMT
ETag: W/"aa-zUiqnFncoW6jKOL6h5Q2n5YHb5k"
Vary: Accept-Encoding
X-Powered-By: Express

'''
    fp = HeadersFormatter(**{'headers':{'sort':True}})