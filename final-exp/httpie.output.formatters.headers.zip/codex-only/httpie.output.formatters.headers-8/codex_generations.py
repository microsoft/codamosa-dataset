

# Generated at 2022-06-23 19:19:21.538044
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.__class__.__name__ == 'HeadersFormatter'


# Generated at 2022-06-23 19:19:29.779549
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    headersFormatter.format_options = {'headers': {'sort': True}}
    headers = '''Accept: text/plain
From: person <email@example.com>
X-Custom-Header: blahblah
X-Custom-Header: yadayada
Y-Custom-Header: blahblah
Y-Custom-Header: yadayada
'''
    assert headersFormatter.format_headers(headers) == '''Accept: text/plain
X-Custom-Header: blahblah
X-Custom-Header: yadayada
Y-Custom-Header: blahblah
Y-Custom-Header: yadayada
From: person <email@example.com>
'''

# Generated at 2022-06-23 19:19:36.292271
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class
    HeadersFormatter.
    """

    # Test case 1
    headers = """HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Content-Type: text/plain
X-Pad: avoid browser bug
X-Pad: avoid browser bug

"""


# Generated at 2022-06-23 19:19:40.246839
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter.format_options, dict)
    assert isinstance(headers_formatter.enabled, bool)
    assert headers_formatter.enabled == True
    

# Generated at 2022-06-23 19:19:42.390315
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.format_options["headers"]["sort"]) == True


# Generated at 2022-06-23 19:19:54.069782
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nCookie: cookie1=value1; cookie2=value2\r\n'\
              'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n'\
              'Cookie: cookie3=value3\r\n'\
              'Accept-Encoding: gzip,deflate,sdch\r\nAccept-Language: en-US,en;q=0.8\r\n'

# Generated at 2022-06-23 19:19:58.239166
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert not headers_formatter.enabled
    assert headers_formatter.format_options == {'headers': {'sort': False}}
    assert headers_formatter.name == 'headers.formatter'
    assert headers_formatter.priority == 100


# Generated at 2022-06-23 19:20:01.090581
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert x.__class__ == HeadersFormatter
    assert x.enabled == True
    assert x.format_options['headers']['sort'] == True



# Generated at 2022-06-23 19:20:04.246797
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = HeadersFormatter().format_options
    assert options['headers']['sort'] == False

# Unit test of method format_headers when headers to sort are in the proper format

# Generated at 2022-06-23 19:20:05.413463
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-23 19:20:15.260914
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    HeadersFormatter_object = HeadersFormatter(format_options={'headers':{'sort':True}})
    # Test case 1: first header should be Content-Length
    headers1 = "HTTP/1.1 200 OK\r\nCache-Control: max-age=0, private, must-revalidate\r\nContent-Length: 0\r\nContent-Type: application/json\r\nDate: Wed, 23 Jan 2019 19:54:22 GMT\r\nX-Request-Id: a0f53e7f-54d4-4278-8f0b-d0b977e9c4a4\r\n"

# Generated at 2022-06-23 19:20:19.591098
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    response_header = """\
HTTP/1.1 200 OK
Content-Length: 246
Content-Type: text/html
Server: gunicorn/19.3.0
"""
    assert headers_formatter.format_headers(response_header) == """\
HTTP/1.1 200 OK
Content-Length: 246
Content-Type: text/html
Server: gunicorn/19.3.0"""


# Generated at 2022-06-23 19:20:21.114995
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert True


# Generated at 2022-06-23 19:20:30.351870
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'Content-Type: text/html\r\nAccept-Charset: UTF-8\r\nAccept: */*\r\nAccept-Language: en-US\r\nAccept-Encoding: gzip, deflate\r\n\r\n'
    assert HeadersFormatter.format_headers(headers) == 'Content-Type: text/html\r\nAccept: */*\r\nAccept-Charset: UTF-8\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US\r\n\r\n'

# Test output of http --headers.sort

# Generated at 2022-06-23 19:20:33.495573
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == True
    assert headers_formatter.enabled == True



# Generated at 2022-06-23 19:20:38.513703
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter(): # pragma: no cover
    import json
    import httpie.cli
    import httpie.plugins
    import httpie.formats

    formatter = HeadersFormatter()

    # simply call the constructor
    if formatter:
        pass



# Generated at 2022-06-23 19:20:41.653314
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        assert HeadersFormatter()
    except Exception as e:
        print("HeadersFormatter() raises exception: " + repr(e))


# Generated at 2022-06-23 19:20:43.591748
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    print(a.format_options)
    a.format_headers("keywords")

# Generated at 2022-06-23 19:20:53.661459
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

# Generated at 2022-06-23 19:20:54.981461
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fm = HeadersFormatter()
    assert fm


# Generated at 2022-06-23 19:21:01.335658
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: baz=quux
Server: httpie
'''
    assert formatter.format_headers(headers) == headers.lstrip()

    headers = '''\
HTTP/1.1 200 OK
Set-Cookie: baz=quux
Set-Cookie: foo=bar
Server: httpie
Content-Type: application/json
'''
    assert formatter.format_headers(headers) == headers.lstrip()


# Generated at 2022-06-23 19:21:07.332236
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''Host: localhost:8080
Accept: */*
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/0.9.9


'''
    assert headers_formatter.format_headers(headers) == '''Host: localhost:8080
Accept: */*
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/0.9.9


'''

# Generated at 2022-06-23 19:21:17.158258
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(format_options={
        'headers': {'sort': True}}).format_headers('\r\n'.join([
            'HTTP/1.1 200 OK',
            'Set-Cookie: foo=bar; path=/',
            'Set-Cookie: baz=qux; path=/',
            'Content-Type: application/json',
            ''])) == '\r\n'.join([
            'HTTP/1.1 200 OK',
            'Content-Type: application/json',
            'Set-Cookie: foo=bar; path=/',
            'Set-Cookie: baz=qux; path=/',
            ''])

# Generated at 2022-06-23 19:21:17.931441
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-23 19:21:20.577179
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    plugin = HeadersFormatter(format_options={'headers':{'sort':'True'}})
    assert plugin.enabled

# Generated at 2022-06-23 19:21:26.757340
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    formatted_headers = formatter.format_headers("""GET / HTTP/1.1
Accept: */*
Content-Type: application/json
User-Agent: HTTPie/0.9.6
""")
    assert formatted_headers == """GET / HTTP/1.1
Accept: */*
Content-Type: application/json
User-Agent: HTTPie/0.9.6
"""


# Fetch content-type of response.
# returns: str, content-type of request.

# Generated at 2022-06-23 19:21:35.997067
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '''Host: httpbin.org
User-Agent: HTTPie/1.0.2
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 18
Content-Type: application/x-www-form-urlencoded
'''
    assert obj.format_headers(headers) == '''Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/1.0.2'''


# Generated at 2022-06-23 19:21:47.711500
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hformatter = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.0 200 OK',
        'Content-Type: text/plain',
        'Content-Length: 3',
        'Set-Cookie: csrftoken=abcdefghijklmnopqrstuvwxyz123456789; expires=Wed, 23-Aug-2017 05:03:54 GMT; Max-Age=31449600; Path=/',
        'Set-Cookie: sessionid=abcdefghijklmnopqrstuvwxyz123456789; expires=Wed, 13-Sep-2017 05:03:54 GMT; httponly; Max-Age=1209600; Path=/',
        'Allow: GET, HEAD, OPTIONS',
    ])

# Generated at 2022-06-23 19:21:52.979387
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=DEFAULT_FORMAT_OPTIONS)
    assert formatter.format_options == DEFAULT_FORMAT_OPTIONS
    assert formatter.enabled == formatter.format_options['headers']['sort']

# Generated at 2022-06-23 19:22:02.340357
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    assert '\r\n'.join(('|> Content-Length: 5', '|> Content-Type: image/jpeg',
                        '|> X-Pad: space', '|> X-Pad: space', '|> X-Pad: space')) == (
            HeadersFormatter(options={'headers': {'sort': True}}).
                format_headers('\r\n'.join(('|> Content-Length: 5',
                                            '|> Content-Type: image/jpeg',
                                            '|> X-Pad: space',
                                            '|> X-Pad: space',
                                            '|> X-Pad: space'))))


# Generated at 2022-06-23 19:22:12.531560
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    Output = StringIO()
    formatter = HeadersFormatter()
    formatter.format_headers("""\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
X-Powered-By: Express
ETag: "1c48-a0-3e1cb03b2e680"
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive

hello world
""")

# Generated at 2022-06-23 19:22:22.778712
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case #1
    assert HeadersFormatter().format_headers(
        """
        GET / HTTP/1.1
        Accept: */*
        User-Agent: HTTPie/1.0.0
        Host: 127.0.0.1:5000
        Accept-Encoding: gzip, deflate, compress
        Content-Type: application/json
        Content-Length: 3

        foo
        """.lstrip()
    ) == """
        GET / HTTP/1.1
        Accept: */*
        Accept-Encoding: gzip, deflate, compress
        Content-Length: 3
        Content-Type: application/json
        Host: 127.0.0.1:5000
        User-Agent: HTTPie/1.0.0

        foo
        """.lstrip()
    # Test case #2
   

# Generated at 2022-06-23 19:22:25.979879
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert isinstance(hf, HeadersFormatter)
    assert hf.format_options == {'headers':{'sort':False}}



# Generated at 2022-06-23 19:22:32.126769
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """\
foo=bar
baz:42
bar:
    foo
    bar
    baz
baz:      """.strip()
    expected = """\
foo=bar
bar:
    foo
    bar
    baz
baz:42
baz:      """.strip()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:22:34.789153
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': 'True'
        }
    })

    assert headers_formatter.format_options['headers']['sort'] == 'True'


# Generated at 2022-06-23 19:22:42.035739
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': False}})
    assert headers_formatter.enabled == False


# Generated at 2022-06-23 19:22:50.710969
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Testing the method format_headers of class HeadersFormatter
    """

    # inputs and assignations
    headers = """HTTP/1.1 200 OK
Content-Length: 12
Cache-Control: max-age=604800
Content-Type: text/html; charset=UTF-8
Date: Wed, 04 Mar 2020 05:51:14 GMT
Expires: Wed, 11 Mar 2020 05:51:14 GMT
Server: ECS (dca/29EC)
Vary: Accept-Encoding
X-Cache: HIT"""

# Generated at 2022-06-23 19:23:01.446802
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    HeadersFormatter_instance = HeadersFormatter()
    headers_original = '''\
header-name-0: value-0
Header-Name-0: value-1
header-name-1: value-2
HEADER-NAME-1: value-3
Header-Name-2: value-4
header-name-2: value-5
'''
    headers_sorted = '''\
header-name-0: value-0
Header-Name-0: value-1
header-name-1: value-2
HEADER-NAME-1: value-3
Header-Name-2: value-4
header-name-2: value-5
'''
    assert HeadersFormatter_instance.format_headers(headers_original) == headers_sorted

# Generated at 2022-06-23 19:23:04.856201
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    headersFormatter = HeadersFormatter(format_options=format_options)
    assert "HeadersFormatter" == headersFormatter.__class__.__name__


# Generated at 2022-06-23 19:23:13.166186
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    c = HeadersFormatter()
    # Test headers with multiple headers with the same name
    txt = c.format_headers('GET http://httpbin.org/headers HTTP/1.1\r\n' +\
                               'User-Agent: HTTPie/0.9.2\r\n' +\
                               'Accept-Encoding: gzip, deflate, compress\r\n' +\
                               'Accept: */*\r\n' +\
                               'User-Agent: curl/7.27.0\r\n' + \
                               'Host: httpbin.org\r\n' + \
                               'Content-Length: 2\r\n' +\
                               'Content-Type: text/plain; charset=utf-8\r\n')

# Generated at 2022-06-23 19:23:21.358663
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: meinheld/0.6.1
Date: Sat, 29 Oct 2016 15:41:35 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 197
Connection: keep-alive
X-Powered-By: Flask
X-Processed-Time: 0.00097393989563
Expires: Sat, 29 Oct 2016 15:41:35 GMT
Cache-Control: public, max-age=0
ETag: "a5f6ee5c5c9d6a5f6ee5c5c9d6a5f6ee5c5c9d6"
''' # noqa

# Generated at 2022-06-23 19:23:24.622772
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class HeadersFormatterTest(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = self.format_options['headers']['sort']

    return HeadersFormatterTest()


# Generated at 2022-06-23 19:23:33.349449
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:23:41.943904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

    fmt.format_options['headers']['sort'] = True


# Generated at 2022-06-23 19:23:49.923941
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter()

    headers = "HTTP/1.1 200 OK\r\nContent-Length: 40\r\nContent-Type: text/plain\r\n"
    headers_formatted = "HTTP/1.1 200 OK\r\nContent-Length: 40\r\nContent-Type: text/plain\r\n"
    assert plugin.format_headers(headers) == headers_formatted

    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 40\r\n"
    headers_formatted = "HTTP/1.1 200 OK\r\nContent-Length: 40\r\nContent-Type: text/plain\r\n"
    assert plugin.format_headers(headers) == headers_formatted


# Generated at 2022-06-23 19:23:51.514013
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled


# Generated at 2022-06-23 19:24:02.192788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = 'Accept: application/json; indent=4\r\n' \
        'Content-Type: application/json\r\n' \
        'Content-Length: 35\r\n' \
        'Accept-Encoding: gzip, deflate\r\n' \
        'Host: httpie.org\r\n' \
        'Connection: keep-alive\r\n' \
        'User-Agent: HTTPie/0.9.2\r\n' \
        'X-Amzn-Trace-Id: Root=1-5c8b0f0a-f5e6b0b6c8b0838e1ed45a7e\r\n' \
        '\r\n'


# Generated at 2022-06-23 19:24:07.917946
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie import input
    from httpie.config import Config
    inp = input.ArgumentParser()
    config = Config(output_options=inp.parse_args(['json']).output_options )
    formatter = HeadersFormatter(format_options=config.output_options)
    assert formatter.enabled
    assert not formatter.format_options['stylish']


# Test the basic functionality of the headers formatter

# Generated at 2022-06-23 19:24:18.809346
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_headers('''\
HTTP/1.1 200 OK
Date: Tue, 26 Apr 2016 09:32:29 GMT
Set-Cookie: a=b; Domain=example.org; Path=/
Set-Cookie: c=d; Domain=example.org; Path=/
Content-Type: application/json
Content-Length: 2
''') == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Date: Tue, 26 Apr 2016 09:32:29 GMT
Set-Cookie: a=b; Domain=example.org; Path=/
Set-Cookie: c=d; Domain=example.org; Path=/
'''

# Generated at 2022-06-23 19:24:26.477308
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers1 = '''GET / HTTP/1.1
Connection: close
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/1.0.2
'''
    headers2 = '''GET / HTTP/1.1
User-Agent: HTTPie/1.0.2
Connection: close
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
'''
    assert HeadersFormatter().format_headers(headers1) == headers2

# Generated at 2022-06-23 19:24:36.684167
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()
    input_headers = "HTTP/1.1 200 OK\r\n"\
                    "Header_1: Value_1\r\n"\
                    "Header_1: Value_1_1\r\n"\
                    "Header_2: Value_2\r\n"\
                    "Content-Type: application/json\r\n"\
                    "Content-Length: 191\r\n\r\n"

# Generated at 2022-06-23 19:24:46.923666
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
ETag: "a"
ETag: "b"
ETag: "c"
ETag: "d"
ETag: "e"
Content-Length: 1
Accept-Ranges: bytes
Date: Mon, 08 Apr 2019 04:55:55 GMT
Content-Type: application/json
'''
    expected_output = '''\
HTTP/1.1 200 OK
Accept-Ranges: bytes
Content-Length: 1
Content-Type: application/json
Date: Mon, 08 Apr 2019 04:55:55 GMT
ETag: "a"
ETag: "b"
ETag: "c"
ETag: "d"
ETag: "e"
'''
    output = headers_formatter.format

# Generated at 2022-06-23 19:24:58.834714
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	temp_headers = '''\
GET /basic-auth/user/passwd HTTP/1.1
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2
Authorization: Basic dXNlcjpwYXNzd2Q='''
	output = HeadersFormatter().format_headers(temp_headers)

# Generated at 2022-06-23 19:25:00.815156
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.get_headers() == []



# Generated at 2022-06-23 19:25:12.412411
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_str = (
        'HTTP/1.1 200 OK\r\n' +
        'Set-Cookie: a=12\r\n' +
        'Content-Length: 42\r\n' +
        'Set-Cookie: b=3;\r\n' +
        'Set-Cookie: zz=12\r\n' +
        'Content-Type: text/plain\r\n'
    )
    # It should sort headers by name while retaining relative
    # order of multiple headers with the same name.

# Generated at 2022-06-23 19:25:20.142864
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'Content-Length: 149',
        'Content-Type: application/x-www-form-urlencoded',
        'Host: httpbin.org',
        'User-Agent: HTTPie/0.9.8',
        '',
        'name=John+Smith&age=31'
    ])

# Generated at 2022-06-23 19:25:25.934995
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected_headers = (
        'Accept: application/json\r\n'
        'Content-Type: application/json\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
    )
    formatter = HeadersFormatter(verbose=False)
    assert formatter.format_headers(expected_headers) == expected_headers
    formatter.enabled = True
    assert formatter.format_headers(expected_headers) == expected_headers


# Generated at 2022-06-23 19:25:36.346398
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:25:46.592975
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n'\
              'Content-Type: application/json\r\n'\
              'Cache-Control: no-cache\r\n'\
              'Cache-Control: no-store\r\n'\
              'Some-Other-Header: value'

    expected_headers = 'HTTP/1.1 200 OK\r\n'\
                   'Cache-Control: no-cache\r\n'\
                   'Cache-Control: no-store\r\n'\
                   'Content-Type: application/json\r\n'\
                   'Some-Other-Header: value'

    formatted_headers = formatter.format_headers(headers)
    assert formatted_headers == expected_headers

# Generated at 2022-06-23 19:25:47.679225
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-23 19:25:59.208812
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:26:00.154182
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-23 19:26:10.841820
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Checks that headers are sorted while retaining the
    relative order of multiple headers with the same name
    """

# Generated at 2022-06-23 19:26:21.305224
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()


# Generated at 2022-06-23 19:26:23.449211
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter is not None

# Unit tests for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:26:31.725502
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = """
HTTP/1.1 200 OK
Server: Apache
Content-Type: text/plain
Date: Mon, 19 Aug 2013 18:23:35 GMT
Set-Cookie: a=1
Set-Cookie: b=2
Set-Cookie: c=3
"""
    output = formatter.format_headers(input)
    assert output == """
HTTP/1.1 200 OK
Content-Type: text/plain
Date: Mon, 19 Aug 2013 18:23:35 GMT
Server: Apache
Set-Cookie: a=1
Set-Cookie: b=2
Set-Cookie: c=3
"""

# Generated at 2022-06-23 19:26:34.372898
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_formatter = HeadersFormatter()
    assert header_formatter.enabled is True


# Generated at 2022-06-23 19:26:36.064988
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """Objective: test constructor."""
    HeadersFormatter()

# Generated at 2022-06-23 19:26:37.427016
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()


# Generated at 2022-06-23 19:26:46.876828
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = """HTTP/1.1 204 NO CONTENT
Server: nginx/1.13.7
Date: Tue, 01 May 2018 13:11:00 GMT
Content-Type: application/json
Content-Length: 0
Connection: keep-alive
X-Request-Id: a4a748b2-4d55-4c4a-bc1d-3c6dcc53e8da
X-Runtime: 0.021285
ETag: W/"86c5e5a127b1eec9b957f2a09d557acc"
Cache-Control: max-age=0, private, must-revalidate
X-Powered-By: Phusion Passenger Enterprise 5.1.7
X-Rack-Cache: invalidate, pass"""


# Generated at 2022-06-23 19:26:57.943632
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers('GET / HTTP/1.1\r\nHost: example.com\r\nContent-Type: text/plain\r\nAccept-Encoding: deflate\r\nContent-Type: application/json\r\nAccept: application/json\r\nAccept-Encoding: gzip') == 'GET / HTTP/1.1\r\nAccept: application/json\r\nAccept-Encoding: deflate\r\nAccept-Encoding: gzip\r\nContent-Type: text/plain\r\nContent-Type: application/json\r\nHost: example.com'

# Generated at 2022-06-23 19:27:05.963631
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    data = 'Host: example.org\r\n' \
           'User-Agent: httpie\r\n' \
           'Accept-Encoding: gzip, deflate\r\n' \
           'Accept: */*\r\n' \
           'Connection: keep-alive\r\n' \
           '\r\n'
    assert HeadersFormatter().format_headers(data) == '\r\n'.join([
        'Host: example.org',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'User-Agent: httpie',
        '',  # End with only one newline
    ])


# Generated at 2022-06-23 19:27:06.530918
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-23 19:27:15.160679
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "Content-Type: text/html; charset=UTF-8\r\nCookie: PHPSESSID=rxvtffsuimkvb8p1n03m1iclk6; path=/; HttpOnly\r\nX-Powered-By: PHP/7.2.10"
    formatter = HeadersFormatter()

    actual = formatter.format_headers(headers)
    expected = "Content-Type: text/html; charset=UTF-8\r\nCookie: PHPSESSID=rxvtffsuimkvb8p1n03m1iclk6; path=/; HttpOnly\r\nX-Powered-By: PHP/7.2.10"
    assert actual == expected


# Generated at 2022-06-23 19:27:21.946065
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Exception if format_options and **kwargs both empty
    with pytest.raises(KeyError):
        HeadersFormatter()

    # Exception
    with pytest.raises(KeyError):
        HeadersFormatter(format_options={})

    # Enabled if format_options 'headers' 'sort': True
    assert HeadersFormatter(
        format_options={'headers': {'sort': True}}
    ).enabled

    # Disabled if format_options 'headers' 'sort': False
    assert not HeadersFormatter(
        format_options={'headers': {'sort': False}}
    ).enabled


# Generated at 2022-06-23 19:27:28.894167
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    def mock_init(self, **kwargs):
        pass
    header = HeadersFormatter()

# Generated at 2022-06-23 19:27:29.890750
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    u = HeadersFormatter()


# Generated at 2022-06-23 19:27:32.550050
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)
    assert formatter.format_options is not None



# Generated at 2022-06-23 19:27:41.077656
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nHeader-A: Value A\r\nHeader-B: Value B\r\nHeader-B: Value B\r\nHeader-C: Value C\r\nHeader-C: Value C\r\n"
    formatted_headers = headers_formatter.format_headers(headers)
    assert formatted_headers == "HTTP/1.1 200 OK\r\nHeader-A: Value A\r\nHeader-B: Value B\r\nHeader-B: Value B\r\n\
Header-C: Value C\r\nHeader-C: Value C\r\n"

# Generated at 2022-06-23 19:27:46.372458
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    formatter.format_headers('GET / HTTP/1.1\r\nAccept: text/html\r\nFoo: 12\r\nBar: 34\r\nBar: 56\r\n\r\n')
    assert formatter.output == 'GET / HTTP/1.1\r\nAccept: text/html\r\nBar: 34\r\nBar: 56\r\nFoo: 12\r\n\r\n'
# Unit test call to HeadersFormatter
test_HeadersFormatter()

# Generated at 2022-06-23 19:27:50.696671
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter({'headers':{'sort':True},
                                           'styles':{'auth':'red'}})
    assert headers_formatter.enabled


# Unit tests for format_headers function

# Generated at 2022-06-23 19:27:52.986688
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	hf = HeadersFormatter()
	assert hf.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:28:01.271352
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    rmtree(temp_path(), ignore_errors=True)
    test_file_name = os.path.join(temp_path(), 'test_formatter_httpie_headers.json')
    test_file_data = {'headers': {'sort': True}}
    with open(test_file_name, 'w') as test_file:
        json.dump(test_file_data, test_file)
    test_plugin_manager = FormatterPluginManager(['--formatter', test_file_name])
    test_formatter = HeadersFormatter(options=test_plugin_manager._formatter_options)
    assert test_formatter.enabled == True

# Generated at 2022-06-23 19:28:11.882845
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: Apache/2.2.15 (CentOS)
Expires: Mon, 26 Jul 1997 05:00:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
Content-Length: 0
Connection: close
Content-Type: text/html; charset=UTF-8
'''

# Generated at 2022-06-23 19:28:12.892827
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	pass
	

# Generated at 2022-06-23 19:28:15.206267
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Unit test for constructor of class HeadersFormatter
    headers = HeadersFormatter()
    # kwargs = {"format_options": "", "config_dir": "/home/lidongdong/.config/httpie", "output_options": {}}
    print(headers.__dict__)


# Generated at 2022-06-23 19:28:16.775065
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options) == HeadersFormatter()


# Generated at 2022-06-23 19:28:27.748254
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    x = HeadersFormatter()
    assert x.format_headers("HTTP/1.1 200 OK\r\n" + \
                            "Content-Type: application/json\r\n" + \
                            "Set-Cookie: first=value; Domain=.example.com; Path=/\r\n" + \
                            "Set-Cookie: second=value; Domain=.example.com; Path=/") == \
                            "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n" + \
                            "Set-Cookie: first=value; Domain=.example.com; Path=/\r\n" + \
                            "Set-Cookie: second=value; Domain=.example.com; Path=/"


# Generated at 2022-06-23 19:28:37.978163
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # A very simple test
    assert formatter.format_headers('Host: example.com\r\nA: b\r\nD: c') == \
        'Host: example.com\r\nA: b\r\nD: c'
    # A more complete test
    assert formatter.format_headers('GET / HTTP/1.1\r\nHost: abc.com\r\nB: b\r\nD: c\r\nE: a') == \
        'GET / HTTP/1.1\r\nB: b\r\nD: c\r\nE: a\r\nHost: abc.com'

# Generated at 2022-06-23 19:28:46.703040
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # given
    format_options = {
            'headers': {
                'sort': True
            }
        }
    formatter = HeadersFormatter(format_options=format_options)
    headers = \
"""
HTTP/1.1 200 OK
Content-Length: 20
Content-Type: text/html; charset=UTF-8
Date: Thu, 28 Jun 2018 09:07:09 GMT
Server: Jetty(9.4.6.v20170531)
"""

    # when
    actual = formatter.format_headers(headers)
    
    # then

# Generated at 2022-06-23 19:28:49.815807
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert isinstance(hf, HeadersFormatter)
    assert hf.enabled
    assert hf.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:28:58.925135
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    input_headers = '''Connection: keep-alive
Content-Length: 11
Content-Type: application/json
Date: Thu, 28 Nov 2019 11:24:53 GMT
Host: localhost:5000
Server: Werkzeug/0.15.6 Python/3.7.4
'''
    expected_headers = '''Connection: keep-alive
Content-Length: 11
Content-Type: application/json
Date: Thu, 28 Nov 2019 11:24:53 GMT
Host: localhost:5000
Server: Werkzeug/0.15.6 Python/3.7.4
'''
    assert hf.format_headers(input_headers) == expected_headers

if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-23 19:29:04.221926
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 0\r\nHost: www.google.com:443\r\n\r\n"
    assert f.format_headers(headers) == "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Type: text/html; charset=utf-8\r\nHost: www.google.com:443\r\n\r\n"



# Generated at 2022-06-23 19:29:06.335998
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    _f = HeadersFormatter(format_options={'headers':{'sort': True}})
    _f.session = MagicMock()
    assert _f.enabled


# Generated at 2022-06-23 19:29:08.662163
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	import pytest
	formatter=HeadersFormatter(**{'headers':{'sort':True}})
	assert formatter.enabled == True


# Generated at 2022-06-23 19:29:09.569775
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled == True

# Generated at 2022-06-23 19:29:11.566470
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hasattr(hf,'format_headers')
    assert hf.enabled == True




# Generated at 2022-06-23 19:29:13.825578
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.format_options['headers']['sort'] is True


# Generated at 2022-06-23 19:29:25.441074
# Unit test for method format_headers of class HeadersFormatter