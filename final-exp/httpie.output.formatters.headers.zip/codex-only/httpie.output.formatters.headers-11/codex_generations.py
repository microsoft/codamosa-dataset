

# Generated at 2022-06-23 19:19:24.828101
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__doc__ is not None


# Generated at 2022-06-23 19:19:31.981332
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: python-requests/2.23.0
Content-Type: application/json
Accept-Language: en
Content-Length: 2
Host: httpbin.org
'''
    formatted_headers = '''Connection: keep-alive
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en
Content-Length: 2
Content-Type: application/json
Host: httpbin.org
User-Agent: python-requests/2.23.0
'''
    assert HeadersFormatter().format_headers(headers) == formatted_headers

# Generated at 2022-06-23 19:19:33.667386
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert f.enabled is True


# Generated at 2022-06-23 19:19:34.925083
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf=HeadersFormatter()

# Generated at 2022-06-23 19:19:40.899722
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert (HeadersFormatter(format_options={'headers': {'sort': True}})
            .format_headers('HTTP/1.1 200 OK\r\nheader: x\r\nheader: y\r\n')
            == 'HTTP/1.1 200 OK\r\nheader: x\r\nheader: y\r\n')

# Generated at 2022-06-23 19:19:48.939856
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter=HeadersFormatter()
    headers = [
        'HTTP/1.1 200 OK',
        'Content-Type: text/html; charset=UTF-8',
        'Date: Mon, 27 Jul 2009 12:28:53 GMT',
        'Server: Apache',
        'X-Powered-By: PHP/5.2.4-2ubuntu5wm1',
        'X-Pingback: /blog/xmlrpc.php',
        'Content-Length: 4916',
        'Connection: close'
    ]

# Generated at 2022-06-23 19:19:50.987448
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers':{'sort':0}}).enabled



# Generated at 2022-06-23 19:19:58.482469
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('test:test1\r\ndate:test2\r\ncontent-type:test3') == 'test:test1\r\ndate:test2\r\ncontent-type:test3'
    assert formatter.format_headers('test:test1\r\ndate:test2\r\ncontent-type:test3\r\ncontent-type:test4') == 'test:test1\r\ndate:test2\r\ncontent-type:test3\r\ncontent-type:test4'

# Generated at 2022-06-23 19:20:01.715521
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={"headers": {"sort": True}})


# Generated at 2022-06-23 19:20:03.969474
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    o = HeadersFormatter()
    assert (isinstance(o, HeadersFormatter))
    assert (isinstance(o, FormatterPlugin))
    assert (isinstance(o.format_options, dict))
    assert (isinstance(o.format_options['headers'], dict))


# Generated at 2022-06-23 19:20:08.128987
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=None)
    assert formatter.enabled == False
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-23 19:20:17.058426
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(**{'headers': {'sort': True}})
    headers = '''
HTTP/1.1 200 OK
Cache-Control: max-age=0, private, must-revalidate
Etag: W/"47c8697df6b4cf611f4bd4b4d8ecdd08"
Server: thin 1.6.2 codename Doc Brown
X-Request-Id: b9a69d89-f842-4c60-a765-bb07bcc73b3b
X-Runtime: 0.014524
Content-Type: application/json; charset=utf-8
Transfer-Encoding: chunked
'''

# Generated at 2022-06-23 19:20:21.399750
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(
        output_file=sys.stdout, format='default', colors=False)
    assert isinstance(headersFormatter, HeadersFormatter)


# Generated at 2022-06-23 19:20:23.761588
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  headers_formatter = HeadersFormatter(None)
  assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:20:26.713585
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert str(headers_formatter.__class__) == "<class 'httpie.formatters.headers_formatter.HeadersFormatter'>"

# Generated at 2022-06-23 19:20:28.690055
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-23 19:20:38.362831
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    # -
    headers = '''\
HTTP/1.1 200 OK
Transfer-Encoding: chunked
Server: cloudflare
Connection: keep-alive
Strict-Transport-Security: max-age=15552000; includeSubDomains
X-XSS-Protection: 1; mode=block
Last-Modified: Mon, 28 Aug 2017 15:40:17 GMT
CF-RAY: 3b85f1e2a68d3a1b-EWR
Accept-Ranges: bytes
Date: Thu, 26 Apr 2018 10:33:03 GMT
Content-Type: text/html
'''

# Generated at 2022-06-23 19:20:41.920154
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert [HeadersFormatter().enabled, HeadersFormatter().format_options['headers']['sort']] == [False, False]
    assert HeadersFormatter(headers={'sort': True}).enabled



# Generated at 2022-06-23 19:20:50.765476
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = '''\
GET / HTTP/1.1\r
Host: localhost\r
Content-Length: 0\r
Accept: application/json\r
Accept: application/xml\r
X-Header: Foo\r
'''

    expected_headers = '''\
GET / HTTP/1.1\r
Accept: application/json\r
Accept: application/xml\r
Content-Length: 0\r
Host: localhost\r
X-Header: Foo\r
'''

    actual_headers = formatter.format_headers(headers)

    assert actual_headers == expected_headers



# Generated at 2022-06-23 19:21:00.015811
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:21:08.612498
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = hf.format_headers(headers_example)
    assert headers == headers_example_sorted

# Example headers with new lines
headers_example = \
"""POST /post HTTP/1.1
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Content-Length: 45
Content-Type: application/x-www-form-urlencoded

user=jose&password=swordfish&file=hackers+3.txt"""

# Same example but with headers sorted

# Generated at 2022-06-23 19:21:18.726667
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception):
        headers_formatter = HeadersFormatter()
        assert isinstance(headers_formatter, HeadersFormatter)
        assert headers_formatter.format_headers('header1: value1\r\nheader2: value2') == 'header1: value1\r\nheader2: value2'

# Generated at 2022-06-23 19:21:25.118953
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ['GET / HTTP/1.1',
            'Host: httpbin.org',
            'Accept: */*',
            'Accept-Encoding: gzip, deflate',
            'Content-Length: 0']
    to_check = HeadersFormatter().format_headers('\r\n'.join(lines))
    assert 'Content-Length' in to_check
    assert not to_check.startswith('Content-Length')



# Generated at 2022-06-23 19:21:25.683199
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-23 19:21:26.552053
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter() != None


# Generated at 2022-06-23 19:21:34.174279
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    s = "Content-Type: application/json; charset=UTF-8\r\nAccept: text/html\r\n"
    s_expected = "Content-Type: application/json; charset=UTF-8\r\nAccept: text/html\r\n"
    formatter = HeadersFormatter()
    s_result = formatter.format_headers(s)
    assert s_result == s_expected
    print("Unit test for method format_headers of class HeadersFormatter: PASSED")
    return

test_HeadersFormatter_format_headers()

# Generated at 2022-06-23 19:21:38.845527
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test a positive situation
    try:
        str = "GET / HTTP/1.1\nHost: httpbin.org\nAccept-Encoding: gzip, deflate\nAccept: */*\nUser-Agent: HTTPie/1.0.2\n\n"
        headers = HeadersFormatter(color_options=None, format_options=None)
        headers.format_headers(str)
        assert 1
    except:
        assert 0


# Generated at 2022-06-23 19:21:49.175375
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'POST / HTTP/1.1\r\n'\
            'User-Agent: ie\r\n'\
            'a: 0\r\n'\
            'a: 1\r\n'\
            'b: 2\r\n'\
            'Host: localhost\r\n'
    expected = 'POST / HTTP/1.1\r\n'\
            'a: 0\r\n'\
            'a: 1\r\n'\
            'b: 2\r\n'\
            'Host: localhost\r\n'\
            'User-Agent: ie\r\n'

    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:21:59.093605
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    obj = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:22:02.525550
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled is True

    formatter = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert formatter.enabled is False



# Generated at 2022-06-23 19:22:12.639852
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """Accept: text/html, application/xhtml+xml, application/xml; q=0.9, */*; q=0.8
Accept-Charset: ISO-8859-1, utf-8; q=0.7, *; q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: en-us, en; q=0.5
Accept-Language: fr
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0"""
    # Tabs and spaces are normalized to a single space,
    # and newlines to a single newline

# Generated at 2022-06-23 19:22:13.282010
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-23 19:22:23.117487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    assert fmt.format_headers(headers) == headers_sorted

# HTTP response with headers
blob_0 = b"""HTTP/1.1 200 OK
Server: nginx
Date: Fri, 18 Apr 2014 15:56:39 GMT
Content-Type: application/json; charset=utf-8
Connection: keep-alive
Vary: Accept-Encoding
ETag: "8e8b6c77484e9aef27f2cd8a078059f6"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: d8ad2a0991ef2c38f2728757a8c0f6e5
X-Runtime: 0.007739
Content-Length: 1169
"""

# HTTP request with headers

# Generated at 2022-06-23 19:22:33.060088
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    test_case_1 = formatter.format_headers("""HTTP/1.1 200 OK
Date: Thu, 01 Nov 2018 21:52:08 GMT
Content-Length: 3
Content-Type: text/html; charset=utf-8

abc\r\n""")
    assert test_case_1 == """HTTP/1.1 200 OK
Content-Length: 3
Content-Type: text/html; charset=utf-8
Date: Thu, 01 Nov 2018 21:52:08 GMT

abc\r\n"""

# Generated at 2022-06-23 19:22:38.256643
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers_original = '''someheader1: somevalue1
someheader2: somevalue2
someheader3: somevalue3
someheader4: somevalue4
someheader5: somevalue5
someheader6: somevalue6
someheader7: somevalue7'''
    test_headers_sorted = '''someheader1: somevalue1
someheader2: somevalue2
someheader3: somevalue3
someheader4: somevalue4
someheader5: somevalue5
someheader6: somevalue6
someheader7: somevalue7'''
    headers = HeadersFormatter().format_headers(test_headers_original)
    assert(headers == test_headers_sorted)

# Generated at 2022-06-23 19:22:42.560391
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(FormatterPluginInitError):
        HeadersFormatter(**{'headers': {'sort': True}, 'body': {'sort_keys': True}})



# Generated at 2022-06-23 19:22:45.897578
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hk = HeadersFormatter(format_options=None)
    assert hk.enabled is False
    assert hk.format_options is None
    assert hk.__init__ is not None


# Generated at 2022-06-23 19:22:48.255027
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-23 19:22:59.538766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:23:09.776801
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:23:18.439458
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: localhost:8080
Date: Thu, 02 Apr 2020 11:27:40 +0300
Connection: close
Content-Length: 23
Content-Type: application/json
Accept: application/json
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/2.2.0

    '''
    assert HeadersFormatter.format_headers(headers) == '''\
Host: localhost:8080
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: close
Content-Length: 23
Content-Type: application/json
Date: Thu, 02 Apr 2020 11:27:40 +0300
User-Agent: HTTPie/2.2.0

    '''
    print('test_HeadersFormatter_format_headers: pass')

# Generated at 2022-06-23 19:23:22.009217
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	assert HeadersFormatter.__init__(headers={'sort': False})
	assert HeadersFormatter.__init__(headers={'sort': True})
	assert HeadersFormatter.__init__(headers={})
	assert HeadersFormatter.__init__()


# Generated at 2022-06-23 19:23:24.372631
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.get_name() == 'headers'
    assert headers_formatter.format_options['headers']['sort'] == 0


# Generated at 2022-06-23 19:23:35.425979
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test one header per line
    headers_1 = b'GET / HTTP/1.1\r\nHost: www.example.com\r\nDate: 01-01-2000\r\n\r\n'
    assert len(headers_1.splitlines()) == 4

    # Test multiple headers per line
    headers_2 = b'GET / HTTP/1.1\r\nHost: www.example.com\r\nDate: 01-01-2000\r\n\r\n'
    assert len(headers_2.splitlines()) == 4

    # Test with only one header
    headers_3 = b'GET / HTTP/1.1\r\n\r\n'
    assert len(headers_3.splitlines()) == 2

    # Test with no headers

# Generated at 2022-06-23 19:23:40.746938
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    fmt = HeadersFormatter()

    # A string that is not a collection of Headers,
    # and is processed as any other string.
    test_str = "I am a test string."
    assert fmt.format_headers(test_str) == test_str

    # A string that is a collection of Headers,
    # and is processed so that the Headers are
    # each sorted by name while retaining the
    # relative order among them.
    test_headers_str = """
HTTP/1.1 200 OK\r
Date: Thu, 01 Jan 1970 00:00:01 GMT\r
\r
"""
    solution_headers_str = """
HTTP/1.1 200 OK\r
Date: Thu, 01 Jan 1970 00:00:01 GMT\r
\r
"""

# Generated at 2022-06-23 19:23:43.380226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] is True


# Generated at 2022-06-23 19:23:45.357867
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter is not None


# Generated at 2022-06-23 19:23:52.883043
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """POST / HTTP/1.1
Host: www.httpbin.org
Accept: application/json
Content-Type: application/json
Content-Length: 2

"""
    target = """POST / HTTP/1.1
Accept: application/json
Content-Length: 2
Content-Type: application/json
Host: www.httpbin.org

"""
    assert(hf.format_headers(headers) == target)


# Generated at 2022-06-23 19:23:54.786308
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()

# Generated at 2022-06-23 19:24:04.364368
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie import __version__
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins.builtin.headers import HeadersFormatter
    from httpie.prettifiers import JSONPrettifier
    from httpie.prettifiers import NdjsonPrettifier
    from httpie.prettifiers import XmlPrettifier
    from httpie.plugins.builtin.colors import ColorsPlugin


    class _HelpfulJSONPrettifier(JSONPrettifier):
        @property
        def coloured_headers(self):
            return '\n'.join([f'Header{c}s{w}!', f'{c}^^^^^^^^{w}'])


# Generated at 2022-06-23 19:24:10.326208
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_string = '''POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 10
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9
X-Amzn-Trace-Id: Root=1-5eb1f6b0-0b0d8bfc4d48b4aee92642f5

{
    "a": "b"
}'''
    headers = header_string.splitlines()
    sorted_headers = sorted(headers[1:], key=lambda header: header.split(':')[0])
    sorted_header_string = '\r\n'.join(headers[:1] + sorted_headers)

# Generated at 2022-06-23 19:24:15.235913
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    settings = Settings(headers={'sort': True})
    formatter = HeadersFormatter(settings)
    assert formatter.enabled == True
    settings = Settings(headers={'sort': False})
    formatter = HeadersFormatter(settings)
    assert formatter.enabled == False


# Generated at 2022-06-23 19:24:26.683943
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    sample_headers = """
HTTP/1.1 401 Unauthorized
Date: Mon, 26 Oct 2015 03:42:17 GMT
Server: Apache
Strict-Transport-Security: max-age=31536000
Content-Length: 476
Content-Type: text/html; charset=iso-8859-1
Date: Mon, 26 Oct 2015 03:42:17 GMT
Server: Apache
Strict-Transport-Security: max-age=31536000
"""


# Generated at 2022-06-23 19:24:36.853050
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''
POST /post HTTP/1.1
Content-Type: application/json
Cache-Control: no-cache
Postman-Token: d7e0ab9a-1d2e-0d3c-7e51-c2432ec73736
User-Agent: PostmanRuntime/7.24.1
Accept: */*
Host: 127.0.0.1:5000
Accept-Encoding: gzip, deflate
Content-Length: 144
Connection: keep-alive
Cookie: JSESSIONID=B753239E1D363F9280704B9E984E4FC4

'''

# Generated at 2022-06-23 19:24:38.795162
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == True


# Generated at 2022-06-23 19:24:40.461229
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()
    assert isinstance(instance, FormatterPlugin)
    assert instance.enabled == True


# Generated at 2022-06-23 19:24:44.491436
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Defines a new object of class HeadersFormatter named headers_formatter
    headers_formatter = HeadersFormatter()
    # Prints headers_formatter
    print(headers_formatter)
    # Prints type of headers_formatter
    print(type(headers_formatter))



# Generated at 2022-06-23 19:24:53.890356
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    old_headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/1.0.0
'''.strip()
    new_headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: example.com
User-Agent: HTTPie/1.0.0
'''.strip()
    assert formatter.format_headers(old_headers) == new_headers



# Generated at 2022-06-23 19:25:02.778365
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-23 19:25:04.491977
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()
    assert HeadersFormatter.name == 'header'


# Generated at 2022-06-23 19:25:15.560032
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hp = HeadersFormatter(format_options={
        'headers': {
            'sort': True
            }
        })

    result = hp.format_headers('HTTP/1.1 200 OK\r\n'
                               'X-Header-2: Value-2\r\n'
                               'X-Header-1: Value-1\r\n')
    expected = 'HTTP/1.1 200 OK\r\n' \
               'X-Header-1: Value-1\r\n' \
               'X-Header-2: Value-2\r\n'
    assert result == expected

    # Test multiple headers with the same name

# Generated at 2022-06-23 19:25:19.944780
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    args = ArgumentParser().parse_args([])
    format_options = Configuration().format_options
    hf = HeadersFormatter(args=args, format_options=format_options)
    assert hf.format_options == format_options
    assert hf.format_options['headers']['sort'] == False
    assert hf.enabled == False
    assert hf.prettify_headers('g') == 'g'

# Unit tests for method format_headers

# Generated at 2022-06-23 19:25:28.204184
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-cache
Content-Type: text/html
Transfer-Encoding: chunked
Connection: keep-alive
Date: Thu, 10 Mar 2016 13:29:34 GMT
\r\n\
'''
    headers_out = headers_formatter.format_headers(headers)
    assert headers_out == '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/json
Content-Type: text/html
Date: Thu, 10 Mar 2016 13:29:34 GMT
Transfer-Encoding: chunked
\r\n\
'''

# Generated at 2022-06-23 19:25:30.919597
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    result = formatter.format_headers(all_headers_with_repeat)
    assert result == all_headers_with_repeat_sorted

    result = formatter.format_headers(all_headers_with_duplicate)
    assert result == all_headers_with_duplicate_sorted


# Generated at 2022-06-23 19:25:35.400186
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter= HeadersFormatter()
    headers = """foo:          foo
bar:          bar
baz:          baz
Content-Type: application/json

"""
    assert formatter.format_headers(headers) == """foo:          foo
bar:          bar
baz:          baz
Content-Type: application/json

"""

# Generated at 2022-06-23 19:25:46.811788
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins.formatters.raw import RawFormatter

    token = 'test'
    value = 'httpie is awesome'
    cookie = '{}={}'.format(token, value)

    # Request
    request_1 = Request(method='GET', url='httpbin.org/get', headers={token: value})
    assert HeadersFormatter().format_headers(RawFormatter().format_headers(request_1)) == \
        'Host: httpbin.org\r\n{}: {}\r\n'.format(token, value)
    request_2 = Request(method='GET', url='httpbin.org/get', headers={token: value, 'Accept': '*/*'})

# Generated at 2022-06-23 19:25:58.354105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {'headers': {'sort': True}}
    formatter = HeadersFormatter(format_options)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 20
Content-Length: 58
Content-Length: 60

{
    "key": "value"
}
'''
    expected = '''\
HTTP/1.1 200 OK
Content-Length: 20
Content-Length: 58
Content-Length: 60
Content-Type: application/json; charset=utf-8

{
    "key": "value"
}
'''
    formatted_headers = formatter.format_headers(headers)
    assert formatted_headers == expected

name_formatter = HeadersFormatter

# Generated at 2022-06-23 19:26:02.113148
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled is True
    assert hf.format_options['headers']['sort'] is True


# Generated at 2022-06-23 19:26:09.261551
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(request=None, response=None, format_options={'headers': {'sort': True}})
    expected = """Content-Type: application/json; charset=utf-8
Cache-Control: no-cache
Content-Length: 292
Accept: application/json; charset=utf-8
Accept-Charset: iso-8859-1,*,utf-8
Connection: close"""
    actual = headers_formatter.format_headers(headers)
    assert actual == expected

# Integration test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:26:16.338007
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Unit test
    # Check if allowed_options is of type list
    allowed_options = HeadersFormatter.options['headers'].allowed_options
    assert isinstance(allowed_options, list)
    # Check if headers is in allowed_options
    assert 'headers' in allowed_options
    # Check if sort is in allowed_options
    assert 'sort' in allowed_options
    # Check if headers is in option_names
    option_names = HeadersFormatter.option_names
    assert 'headers' in option_names
    # Check if headers is in name
    name = HeadersFormatter.name
    assert 'headers' in name


# Generated at 2022-06-23 19:26:26.888459
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Strict-Transport-Security: max-age=63072000
Transfer-Encoding: chunked
ETag: W/"2b6-Bxi6YimJhZl+fH2GjKncCsgjsBw"
Content-Encoding: gzip
Server: nginx/1.13.3
X-Content-Type-Options: nosniff
Date: Sun, 21 Jan 2018 12:35:31 GMT
Connection: keep-alive
Vary: Accept-Encoding
"""

# Generated at 2022-06-23 19:26:34.755918
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    x = HeadersFormatter()
    assert (
        x.format_headers('GET / HTTP/1.1\r\nC: 2\r\nA: 1\r\nA: 3\r\nC: 4\r\nB: 3\r\n')
        == 'GET / HTTP/1.1\r\nA: 1\r\nA: 3\r\nB: 3\r\nC: 2\r\nC: 4\r\n')

# Generated at 2022-06-23 19:26:41.470465
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""HTTP/1.1 200 OK\r
Content-Type: text/html; charset=utf-8\r
Content-Length: 12\r
Connection: keep-alive\r
Date: Sun, 09 Feb 2014 00:31:03 GMT\r
Cache-Control: private, max-age=0\r
\r
""") == """HTTP/1.1 200 OK\r
Cache-Control: private, max-age=0\r
Connection: keep-alive\r
Content-Length: 12\r
Content-Type: text/html; charset=utf-8\r
Date: Sun, 09 Feb 2014 00:31:03 GMT\r
\r
"""

# Generated at 2022-06-23 19:26:49.105988
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\r
Host: example.org\r
Connection: keep-alive\r
user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36\r
accept-encoding: gzip, deflate, br\r
accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3\r
sec-fetch-site: none\r
sec-fetch-mode: navigate\r
accept-language: en-US,en;q=0.9\r
"""


# Generated at 2022-06-23 19:26:57.359596
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    formatter = HeadersFormatter()
    
    # Act
    result = formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-Foo: 1\r\nX-Bar: 2\r\nX-Baz: 3\r\n')

    # Assert
    assert result == 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-Bar: 2\r\nX-Baz: 3\r\nX-Foo: 1\r\n'

# Generated at 2022-06-23 19:27:03.769594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
    Content-Type: application/json
    X-Forwarded-For: 127.0.0.1
    X-Forwarded-For: 127.0.0.2
    X-Forwarded-For: 127.0.0.3
    X-Request-Id: 1234
    '''
    expected_headers = '''
    Content-Type: application/json
    X-Forwarded-For: 127.0.0.1
    X-Forwarded-For: 127.0.0.2
    X-Forwarded-For: 127.0.0.3
    X-Request-Id: 1234
    '''
    formatter = HeadersFormatter()
    formatted_headers = formatter.format_headers(headers)
    assert formatted_headers == expected_headers

    # Without sort
    formatter

# Generated at 2022-06-23 19:27:13.689931
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  formatter = HeadersFormatter()
  result = formatter.format_headers("""
HTTP/1.1 200 OK
Server: nginx
Date: Sun, 14 Apr 2019 14:47:07 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 79832
Connection: keep-alive
Last-Modified: Sat, 23 Mar 2019 00:00:00 GMT
ETag: "5c951908-0358"
Accept-Ranges: bytes
Vary: Accept-Encoding

""")

# Generated at 2022-06-23 19:27:20.657081
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from unittest.mock import Mock

    args = Mock()
    args.headers = 'key1: value1\r\n' \
                   'key2: value2\r\n' \
                   'key2: value3\r\n'

    instance = HeadersFormatter(args)

    assert instance.enabled == True
    assert instance.format_headers(args.headers) == 'key1: value1\r\n' \
                                                    'key2: value2\r\n' \
                                                    'key2: value3\r\n'



# Generated at 2022-06-23 19:27:27.340203
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-23 19:27:38.016389
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_input = """\
HTTP/1.1 200 Ok
Content-Encoding: gzip
Content-Type: text/html; charset=utf-8
Date: Mon, 27 Jul 2015 10:05:55 GMT
Server: Werkzeug/0.10.4 Python/3.5.0
Vary: Cookie

"""
    headers_output = """\
HTTP/1.1 200 Ok
Content-Encoding: gzip
Content-Type: text/html; charset=utf-8
Date: Mon, 27 Jul 2015 10:05:55 GMT
Server: Werkzeug/0.10.4 Python/3.5.0
Vary: Cookie

"""
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.format_headers(headers_input)

# Generated at 2022-06-23 19:27:43.216262
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    sorted_headers = '''Accept-Encoding: gzip, deflate
Content-Length: 32
Content-Type: text/plain
X-Authorization: 123
X-Authorization: abc
'''

    unsorted_headers = sorted_headers.splitlines()
    unsorted_headers.reverse()
    unsorted_headers = '\r\n'.join(unsorted_headers)
    assert h.format_headers(unsorted_headers) == sorted_headers


# Generated at 2022-06-23 19:27:46.690690
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options == {'headers': {'sort': False}}
    assert formatter.enabled == False
    formatter.format_options = {'headers': {'sort': True}}
    assert formatter.format_options == {'headers': {'sort': True}}
    assert formatter.enabled == True

# Generated at 2022-06-23 19:27:50.643582
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    myformatter = HeadersFormatter(stdin="", stdout="", stderr="")
    assert myformatter.format_options['headers']['sort'] == True


# Generated at 2022-06-23 19:28:01.481290
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        "HTTP/1.1 200 OK\r\n"
        "Vary: Accept\r\n"
        "Content-Length: 47\r\n"
        "Cache-Control: no-cache\r\n"
        "Content-Type: application/json\r\n"
        "Content-Type: text/html\r\n"
        "Cache-Control: private\r\n"
    )

# Generated at 2022-06-23 19:28:06.160355
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    class Dummy(HeadersFormatter):

        def __init__(self, **kwargs):
            assert kwargs
            super().__init__(**kwargs)

    Dummy(a=1)


# Generated at 2022-06-23 19:28:08.957559
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(**{
        'format_options': {
            'headers': {
                'sort': True,
            }
        }
    })
    assert hf.enabled


# Generated at 2022-06-23 19:28:12.446335
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-23 19:28:12.979884
# Unit test for constructor of class HeadersFormatter

# Generated at 2022-06-23 19:28:16.462066
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatted_headers = HeadersFormatter().format_headers(headers)
    assert headers_sorted == formatted_headers

formatted_headers = HeadersFormatter().format_headers(headers)
print(formatted_headers)

# General testing
assert headers_sorted == formatted_headers

# Generated at 2022-06-23 19:28:27.448781
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_headers = 'HTTP/1.1 200 OK\r\nContent-length: 34\r\nContent-type: application/json\r\nDate: Sun, 10 Nov 2019 01:50:26 GMT\r\n\r\n{ "foo": "bar" }\r\n'
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']
    assert formatter.format_headers(test_headers) == 'HTTP/1.1 200 OK\r\nContent-length: 34\r\nContent-type: application/json\r\nDate: Sun, 10 Nov 2019 01:50:26 GMT\r\n\r\n{ "foo": "bar" }\r\n'

# Generated at 2022-06-23 19:28:37.927157
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('''\
GET / HTTP/1.1
Host: example.com
Accept: */*
Content-Length: 100
Content-Type: application/json
Accept-Encoding: gzip
Cookie: site=https%3A%2F%2Fexample.com
Accept-Language: en-US,en;q=0.5''') == '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip
Accept-Language: en-US,en;q=0.5
Cookie: site=https%3A%2F%2Fexample.com
Content-Length: 100
Content-Type: application/json
Host: example.com'''

# Generated at 2022-06-23 19:28:41.554044
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatterInstance = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert HeadersFormatterInstance.enabled == False
    assert HeadersFormatterInstance.format_options == {'headers': {'sort': False}}


# Generated at 2022-06-23 19:28:48.653985
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST / HTTP/1.1
User-Agent: HTTPie/1.1.0
b: a
Content-Type: application/x-www-form-urlencoded
A: x
B: y
Accept-Encoding: gzip, deflate
Host: example.com
Connection: keep-alive
Content-Length: 11
\r\n'''
    expected_headers = '''\
POST / HTTP/1.1
Accept-Encoding: gzip, deflate
A: x
B: y
Connection: keep-alive
Content-Length: 11
Content-Type: application/x-www-form-urlencoded
Host: example.com
User-Agent: HTTPie/1.1.0
b: a
\r\n'''
    head_format = HeadersFormatter()


# Generated at 2022-06-23 19:28:51.747182
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert(HeadersFormatter().format_headers("Content-Type: text/html\nContent-Type: text/xml") == "\nContent-Type: text/html\nContent-Type: text/xml")

# Generated at 2022-06-23 19:28:55.506155
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_string = """"""
    headers_dict = {'headers': {'sort': True}}
    headers_test = HeadersFormatter(format_options=headers_dict)
    assert headers_test.enabled
    assert headers_test.format_headers(headers=headers_string) == """"""

# Generated at 2022-06-23 19:29:02.126424
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert (HeadersFormatter().format_headers(
        """POST /post HTTP/1.1
Host: www.python.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 66
Content-Type: application/x-www-form-urlencoded
User-Agent: HTTPie/0.9.9


"""
    ) == """POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 66
Content-Type: application/x-www-form-urlencoded
Host: www.python.org
User-Agent: HTTPie/0.9.9


""")

# Generated at 2022-06-23 19:29:03.514734
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter


# Generated at 2022-06-23 19:29:13.826318
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = ("HTTP/1.1 200 OK\r\n"
              "B: bar\r\n"
              "A: foo\r\n"
              "C: baz\r\n"
              "C: qux\r\n"
              "A: quux\r\n"
              "B: quuux\r\n")
    expected = ("HTTP/1.1 200 OK\r\n"
              "A: foo\r\n"
              "A: quux\r\n"
              "B: bar\r\n"
              "B: quuux\r\n"
              "C: baz\r\n"
              "C: qux\r\n")
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-23 19:29:19.413918
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    This unit test is to test the constructor of class HeadersFormatter
    """
    headers_formatter = FormatterPlugin()
    assert headers_formatter.format_options['headers']['sort'] == False



# Generated at 2022-06-23 19:29:27.092378
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    The function format_headers of class HeadersFormatter is called
    with headers value as a parameter. The http request is sent and
    the headers of the request are returned as a response.

    The received headers are then sorted by name and the sorted headers
    are returned.
    """

    headers_formatter = HeadersFormatter()

    example_headers = (
        'Content-Type: application/json\n'
        'Content-Length: 32\n'
        'Host: localhost:3000\n'
        'Accept-Encoding: gzip, deflate\n'
        'Accept: */*\n'
        'User-Agent: HTTPie/2.2.0-dev0\n'
    )

    result = headers_formatter.format_headers(example_headers)

    # The assertEqual() method of