

# Generated at 2022-06-21 14:03:08.808747
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
POST /api/auth HTTP/1.1
Host: localhost
Content-Length: 33
Connection: Keep-Alive
Content-Type: application/x-www-form-urlencoded
'''
    headers_formatted = '''\
POST /api/auth HTTP/1.1
Content-Length: 33
Content-Type: application/x-www-form-urlencoded
Connection: Keep-Alive
Host: localhost
'''
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers) == headers_formatted

# Generated at 2022-06-21 14:03:11.050181
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(config={'headers': {'sort': True}})
    assert formatter.enabled is True

# Unit tests for format_headers() function of HeadersFormatter class

# Generated at 2022-06-21 14:03:22.977557
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # -----------------------------------------------------------------------
    # Given
    headers = '''
HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 15
Content-Type: text/html; charset=UTF-8
Date: Sat, 16 Feb 2013 11:20:12 GMT
Server: meinheld/0.6.1
Vary: Cookie,Accept-Encoding
'''.strip()
    # -----------------------------------------------------------------------
    fh = HeadersFormatter()
    # -----------------------------------------------------------------------
    # When
    sorted_headers = fh.format_headers(headers)
    # -----------------------------------------------------------------------
    # Then

# Generated at 2022-06-21 14:03:31.942379
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled

# Generated at 2022-06-21 14:03:43.091082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeaders

    http_headers = """HTTP/1.1 200 OK
Content-Length: 212
Content-Encoding: gzip
Set-Cookie: csrftoken=B; Domain=.httpbin.org; expires=Sun, 22-Dec-2019 21:55:01 GMT; Max-Age=31449600; Path=/
Cache-Control: max-age=604800
Server: gunicorn/19.9.0
Access-Control-Allow-Credentials: true
X-Powered-By: Flask
Access-Control-Allow-Origin: *
Content-Type: application/json
Date: Sun, 22 Dec 2019 21:55:01 GMT

"""

# Generated at 2022-06-21 14:03:52.475789
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = (
        'Access-Control-Allow-Credentials: true'
        '\r\n'
        'Access-Control-Allow-Origin: *'
        '\r\n'
        'Connection: keep-alive'
        '\r\n'
        'Content-Length: 142'
        '\r\n'
        'Content-Type: application/json'
        '\r\n'
        'Date: Thu, 07 May 2020 11:03:51 GMT'
        '\r\n'
        'ETag: W/"8e-elbW8MtjJnPuiDyvTkmTtW8nhE"'
        '\r\n'
        'Server: Cowboy'
    )
    assert HeadersFormatter.format_headers(headers=headers)

#

# Generated at 2022-06-21 14:03:58.467414
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
User-Agent: IE 9
Accept: */*
Content-Type: application/json
Connection: close
Host: 127.0.0.1\
"""
    formatter = HeadersFormatter()
    formatted_headers = formatter.format_headers(headers)

    assert formatted_headers == """\
User-Agent: IE 9
Accept: */*
Connection: close
Content-Type: application/json
Host: 127.0.0.1\
"""

# Generated at 2022-06-21 14:04:03.331189
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(options={'headers': {'sort': 'True'}})
    assert formatter.headers == {'sort': 'True'}
    assert formatter.enabled == True
    assert formatter.name == 'headers'


# Generated at 2022-06-21 14:04:06.187406
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options=None)
    assert headers_formatter.enabled == True

# Test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:04:17.958884
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    v_headers: str = ""
    v_headers += "Content-Length: 200\r\n"
    v_headers += "Content-Type: application/json\r\n"
    v_headers += "Accept: application/xml\r\n"
    v_headers += "Accept: application/json\r\n"
    v_headers += "Accept: */*\r\n"
    v_headers += "Connection: close"
    assert HeadersFormatter().format_headers(v_headers) == "\r\n".join([
        "Content-Length: 200",
        "Content-Type: application/json",
        "Accept: application/xml",
        "Accept: application/json",
        "Accept: */*",
        "Connection: close"
    ])



# Generated at 2022-06-21 14:04:22.445816
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    sort_option = {'sort': True}
    formatter = HeadersFormatter(headers = sort_option)
    assert formatter.enabled == True



# Generated at 2022-06-21 14:04:24.125588
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)



# Generated at 2022-06-21 14:04:26.523571
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': False}})
    assert formatter

print(test_HeadersFormatter())


# Generated at 2022-06-21 14:04:28.762431
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:04:36.668177
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create instance of HeadersFormatter
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    # Create an unsorted list of headers

# Generated at 2022-06-21 14:04:39.685571
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create an instance of HeadersFormatter
    obj = HeadersFormatter()
    
    # Test __init__() returns an instance of HeadersFormatter
    assert isinstance(obj, HeadersFormatter)
    assert obj.__class__.__name__ == 'HeadersFormater'
    assert obj.__doc__ == 'Custom headers formatter.'
    

# Generated at 2022-06-21 14:04:42.988739
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert (HeadersFormatter.instance is None)  # _instance is empty
    assert (HeadersFormatter.name == 'headers')  # name is 'headers'
    assert (HeadersFormatter.format_options['headers']['sort'] is True)  # sort option is true
    assert (HeadersFormatter.enabled is True)  # enabled is true

# Generated at 2022-06-21 14:04:48.646989
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options \
    = {'headers': {'sort': True}, 'style': {'__root__': {}}}
    formatter = HeadersFormatter(format_options=format_options)

    headers = """POST / HTTP/1.1
User-Agent: HTTPie/2.2.0
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 0
Content-Type: application/json
Host: httpbin.org
"""
    expected = """POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 0
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/2.2.0
"""

# Generated at 2022-06-21 14:04:53.586197
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # headers with a single occurrence of each name
    assert formatter.format_headers('\r\n'.join([
        'GET / HTTP/1.1',
        'Content-Length: 4444',
        'Host: localhost',
        'User-Agent: httpie',
    ])) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Content-Length: 4444',
        'Host: localhost',
        'User-Agent: httpie',
    ])

    # headers with multiple occurrences of the same name

# Generated at 2022-06-21 14:05:00.245050
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_str = """GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Host: httpbin.org"""
    expected = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org"""
    assert HeadersFormatter.format_headers(headers_str) == expected

# Generated at 2022-06-21 14:05:03.350642
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter({}), HeadersFormatter)


# Generated at 2022-06-21 14:05:05.586712
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True



# Generated at 2022-06-21 14:05:08.392585
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-21 14:05:11.528238
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h is not None
    assert h.format_options['headers']['sort'] is True
    assert h.enabled is True


# Generated at 2022-06-21 14:05:20.642829
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test that headers are sorted by name, with multiple headers
    # of the same name retaining order
    input_headers = """\
Connection: keep-alive
Content-Length: 154
Content-Type: text/plain
Content-Type: text/html
Content-Type: text/css
Date: Fri, 11 Aug 2017 05:39:07 GMT
"""
    expected_output = """\
Connection: keep-alive
Content-Length: 154
Content-Type: text/plain
Content-Type: text/html
Content-Type: text/css
Date: Fri, 11 Aug 2017 05:39:07 GMT
"""
    assert HeadersFormatter().format_headers(input_headers) == expected_output

# Main program for unit test
if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-21 14:05:24.984370
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    formatter = HeadersFormatter(format_options = {'headers': {'sort': 'on'}})
    assert formatter.format_options == {'headers': {'sort': 'on'}}
    assert formatter.enabled == 'on'


# Generated at 2022-06-21 14:05:32.843681
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
User-Agent: TerminalBrowserSetter/0.1
Content-Type: text/html
Accept: */*
Connection: close
"""
    fmt = HeadersFormatter()
    formatted_headers = fmt.format_headers(headers)
    assert formatted_headers == """\
HTTP/1.1 200 OK
Accept: */*
Connection: close
Content-Type: text/html
User-Agent: TerminalBrowserSetter/0.1
"""

# Generated at 2022-06-21 14:05:39.589898
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = ('HTTP/1.1 200 OK\r\n'
               'Foo: B\r\n'
               'Foo: A\r\n'
               'Bar: C\r\n')
    expected = ('HTTP/1.1 200 OK\r\n'
                'Foo: B\r\n'
                'Foo: A\r\n'
                'Bar: C\r\n')
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-21 14:05:46.880677
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """Accept: application/json, text/javascript
         X-Custom: value
         X-Custom: another value
         Content-Type: application/x-www-form-urlencoded
         Cookie: foo=bar
         Cookie: baz=bar
         """
    ) == """
Accept: application/json, text/javascript
Content-Type: application/x-www-form-urlencoded
Cookie: foo=bar
Cookie: baz=bar
X-Custom: value
X-Custom: another value
         """

# Generated at 2022-06-21 14:05:48.965400
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin

    assert issubclass(HeadersFormatter, FormatterPlugin)
    HeadersFormatter()


# Generated at 2022-06-21 14:06:03.800040
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Cache-Control: private
X-Content-Type-Options: nosniff
Content-Type: text/html; charset=utf-8
X-Frame-Options: SAMEORIGIN
Date: Mon, 22 Jul 2019 20:47:59 GMT
Server: Microsoft-IIS/10.0
Set-Cookie: foo=bar; domain=localhost
X-XSS-Protection: 1; mode=block
Content-Length: 678770
Connection: close
"""

# Generated at 2022-06-21 14:06:05.816407
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter()
    assert head.enabled == True



# Generated at 2022-06-21 14:06:06.867020
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-21 14:06:08.469586
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:06:11.986707
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    # test property 'enabled'
    assert f.enabled == True
    # test property 'format_options'
    expected_format_options = {'headers': {'sort': True}}
    assert f.format_options == expected_format_options


# Generated at 2022-06-21 14:06:19.351961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Method format_headers of class HeadersFormatter
    """
    headers_formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }})
    text = headers_formatter.format_headers('''
    Content-Type: application/json
    Authorization: Bearer a.b.c
    '''.strip())
    assert 'Authorization' in text
    assert text[text.find('Authorization'):].startswith('Authorization:')



# Generated at 2022-06-21 14:06:24.448879
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:06:36.192995
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_headers = HeadersFormatter()

    # Test that the headers are sorted by name
    f = formatter_headers.format_headers
    assert f('HTTP/1.1 200 OK\r\nHeader-A: a\r\nHeader-B: b\r\n') == \
           'HTTP/1.1 200 OK\r\nHeader-A: a\r\nHeader-B: b\r\n'
    assert f('HTTP/1.1 200 OK\r\nHeader-B: b\r\nHeader-A: a\r\n') == \
           'HTTP/1.1 200 OK\r\nHeader-A: a\r\nHeader-B: b\r\n'

    # Test that the relative order of multiple headers with the same name is retained

# Generated at 2022-06-21 14:06:44.320992
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Scenario: HTTPie request output with headers formatted
    # Given A httpie object with headers of a request
    # When the headers are sorted
    # Then the headers are sorted by name and relative order of multiple headers with the same name is retained
    headers = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Cookie: a=a; b=b
Cookie: c=c
Cookie: b=b; d=d;
Host: httpbin.org
User-Agent: HTTPie/0.9.9
"""
    formatter = HeadersFormatter(format_options={"headers": {}})
    sorted_headers = formatter.format_headers(headers)

# Generated at 2022-06-21 14:06:48.791291
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    headers_formatter = HeadersFormatter(format_options=format_options)
    assert headers_formatter.format_options == format_options


# Generated at 2022-06-21 14:07:06.094603
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'content-Length: 345',
        'Content-type: text/html',
        'Connection: keep-alive',
    ])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Connection: keep-alive',
        'Content-type: text/html',
        'content-Length: 345',
    ])

# Generated at 2022-06-21 14:07:08.992893
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(headers= {'sort': True})
    assert formatter.enabled == formatter.format_options['headers']['sort']

# UnitTest for the format_headers method of class HeadersFormatter

# Generated at 2022-06-21 14:07:13.192082
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {
            'sort': True
        }
    }
    headers_formatter = HeadersFormatter(format_options=format_options)
    assert headers_formatter.enabled == True
    assert headers_formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:07:19.003216
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('Content-Type: text/html\nX-Foo: Bar\nX-Bar: Foo\nContent-Length: 18\n') == 'Content-Type: text/html\nX-Foo: Bar\nX-Bar: Foo\nContent-Length: 18\n'

# Generated at 2022-06-21 14:07:24.435608
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
Accept: application/json
Content-Type: application/json
X-Auth-Token: 123456
Host: example.org
Content-Length: 10
"""
    assert formatter.format_headers(text=headers) == """\
Accept: application/json
Content-Length: 10
Content-Type: application/json
Host: example.org
X-Auth-Token: 123456
"""

# Generated at 2022-06-21 14:07:35.793265
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:07:40.612236
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head_format = {'headers': {'sort': True}}
    head_formatter = api.HeadersFormatter(**head_format)
    assert head_formatter.enabled == True
    head_format = {'headers': {'sort': False}}
    head_formatter = api.HeadersFormatter(**head_format)
    assert head_formatter.enabled == False


# Generated at 2022-06-21 14:07:51.999118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_before = """\
HTTP/1.1 200 OK
Content-Type: application/json
Link: </api/123/comments>; rel="comments"
Link: </api/123/re-runs>; rel="re-runs"
Link: </api/123/re-runs?page=2>; rel="next"
Link: </api/123/re-runs?page=5>; rel="last"
"""

# Generated at 2022-06-21 14:08:00.265736
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_str = """\
POST /post HTTP/1.1
Content-Type: application/json
content-length: 100
B: bar
B: baz
A: foo
"""
    headers = HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers_str)
    assert headers == """\
POST /post HTTP/1.1
A: foo
B: bar
B: baz
Content-Type: application/json
content-length: 100
"""

# Generated at 2022-06-21 14:08:07.231196
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers':{'sort':True}})

# Generated at 2022-06-21 14:08:29.023354
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_before = '''
HTTP/1.1 200 OK
Date: Wed, 27 Mar 2019 18:39:49 GMT
Content-Type: application/octet-stream
Content-Length: 0
Last-Modified: Wed, 27 Mar 2019 03:38:21 GMT
Connection: keep-alive
ETag: "5c9a8a35-0"
Server: nginx/1.14.0 (Ubuntu)
X-Ratelimit-Limit: 60
X-Ratelimit-Remaining: 59

'''


# Generated at 2022-06-21 14:08:30.227603
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head_formatter = HeadersFormatter()
    assert head_formatter.enabled == True

# Generated at 2022-06-21 14:08:31.513754
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:08:40.217927
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers':{'sort':True}})
    input_string = '''HTTP/1.1 200 OK\r
Content-Type: application/json\r
Date: Mon, 10 Dec 2018 17:24:43 GMT\r
Content-Length: 531\r
\r
'''
    result = f.format_headers(input_string)
    assert result == '''HTTP/1.1 200 OK\r
Content-Length: 531\r
Content-Type: application/json\r
Date: Mon, 10 Dec 2018 17:24:43 GMT\r
\r
'''


# Generated at 2022-06-21 14:08:47.149882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: max-age=0, private, must-revalidate
ETag: "e8b2d5fd5fd5fd5fd5fd5fd5fd5fd5fd"
X-Request-Id: e8b2d5fd-5fd5-fd5f-d5fd-5fd5fd5fd5fd
X-Runtime: 0.001742
Date: Mon, 06 Apr 2020 06:43:26 GMT
Transfer-Encoding: chunked

"""

# Generated at 2022-06-21 14:08:50.095742
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled
    assert not formatter.enabled


# Generated at 2022-06-21 14:08:59.260097
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
   headers_string = "GET /api/order/%d HTTP/1.1\r\nHost: localhost:8000\r\nUser-Agent: HTTPie/1.0.0\r\nAccept: application/json, */*\r\n\r\n" % (1)
   headers_expected = "GET /api/order/%d HTTP/1.1\r\nAccept: application/json, */*\r\nHost: localhost:8000\r\nUser-Agent: HTTPie/1.0.0\r\n\r\n" % (1)
   formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
   headers_sorted = formatter.format_headers(headers_string)
   assert(headers_sorted == headers_expected)

# Generated at 2022-06-21 14:09:04.556134
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import httpie
    test_param_1 = httpie.plugins.FormatterPlugin()
    test_param_2 = httpie.cli.parser.parser()
    test = HeadersFormatter(test_param_1, test_param_2)
    return (test_param_1, test_param_2, test)


# Generated at 2022-06-21 14:09:12.960373
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from io import StringIO

    # Testcase:
    # Request is a JSON-RPC request and the request data
    # contains three headers with the same name.
    #
    # Constraints:
    # * Headers must be sorted and their relative order must be retained
    # * The first line is a special case and must be excluded (header_list)
    # * The initial value of the headers field is an empty string
    # * The headers are terminated by CRLF
    # * The CRLF must be replaced by LF
    # * The result of the method must be saved in a StringIO object
    request = {
        'request_method': 'POST',
        'headers': '',
        'data': '{"jsonrpc":"2.0","method":"echoheaders","params":[],"id":123456789}'
    }
   

# Generated at 2022-06-21 14:09:15.549125
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options == None
    assert hf.enabled == False


# Generated at 2022-06-21 14:09:43.515167
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter(**{'headers': {'sort': True}})
    # Test whether the steps of the constructor are executed correctly
    assert head.enabled == True


# Generated at 2022-06-21 14:09:47.208839
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # assign
    format_options = {'headers':{'sort':True}}

    # act
    formatter = HeadersFormatter(format_options=format_options)

    # assert
    print(formatter.format_headers.__code__.co_code)
    assert formatter.enabled


# Generated at 2022-06-21 14:09:51.673015
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersformatter = HeadersFormatter()
    actual = headersformatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nA: A\r\nC: C\r\nB: B\r\n')
    expected = 'HTTP/1.1 200 OK\r\nA: A\r\nB: B\r\nC: C\r\nContent-Type: application/json\r\n'
    assert actual == expected


# Generated at 2022-06-21 14:10:01.775588
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert 'Header1: Value1\r\nHeader2: Value2\r\nHeader3: Value3\r\n' == headers_formatter.format_headers('Header2: Value2\r\nHeader3: Value3\r\nHeader1: Value1\r\n')
    assert 'Header1: Value1\r\nHeader2: Value2\r\nHeader3: Value3\r\n' == headers_formatter.format_headers('Header2: Value2\r\nHeader1: Value1\r\nHeader3: Value3\r\n')

# Generated at 2022-06-21 14:10:10.891812
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Sat, 01 May 2021 02:01:11 GMT
Server: Apache/2.4.38 (Debian)
Last-Modified: Fri, 18 Dec 2020 15:46:34 GMT
ETag: "1731-5a64cc76fcd68"
Accept-Ranges: bytes
Content-Length: 5929
Vary: Accept-Encoding
Content-Type: text/html

'''

# Generated at 2022-06-21 14:10:16.069523
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert (
        HeadersFormatter().format_headers('HTTP/1.0 200 OK\r\n'
                                          'Bar: one\r\n'
                                          'Foo: two\r\n'
                                          'Foo: three\r\n')
        ==
        'HTTP/1.0 200 OK\r\n'
        'Foo: two\r\n'
        'Foo: three\r\n'
        'Bar: one\r\n')

# Generated at 2022-06-21 14:10:16.542226
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    pass

# Generated at 2022-06-21 14:10:18.723130
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-21 14:10:27.616038
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # method
    headers = """
        Date: Sat, 25 Feb 2017 14:09:29 GMT
        Server: Apache/2.4.7 (Ubuntu)
        Vary: Accept-Encoding
        Content-Encoding: gzip
        Content-Length: 3381
        Keep-Alive: timeout=5, max=100
        Connection: Keep-Alive
        Content-Type: text/html; charset=UTF-8
    """.strip()
    formatter = HeadersFormatter()
    result = formatter.format_headers(headers)
    # assert
    print(repr(result))
    print(repr(headers))
    assert result == headers



# Generated at 2022-06-21 14:10:35.516480
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    
    # Arguments:
    headers = '''\
* Connected to api.github.com (140.82.118.4) port 443 (#0)
> GET / HTTP/1.1
> Host: api.github.com
> User-Agent: curl/7.54.0
> Accept: */*
>
'''
    # Return:
    '''\
* Connected to api.github.com (140.82.118.4) port 443 (#0)
> GET / HTTP/1.1
> Accept: */*
> Host: api.github.com
> User-Agent: curl/7.54.0
>
'''

# Generated at 2022-06-21 14:11:31.083331
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
GET / HTTP/1.1
Accept: application/json
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Connection: keep-alive
    """
    expected = """
GET / HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
"""
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(headers) == expected

# Generated at 2022-06-21 14:11:34.157608
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**{'indent': 2, 'expand': False, 'format': None, 'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-21 14:11:43.401954
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:11:45.244975
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = HeadersFormatter()
    assert format_options.enabled


# Generated at 2022-06-21 14:11:51.236766
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("GET / HTTP/1.1\r\nHost: example.org\r\nHeader: value\r\nAnotherHeader: another_value") == "GET / HTTP/1.1\r\nAnotherHeader: another_value\r\nHeader: value\r\nHost: example.org"
    assert HeadersFormatter().format_headers("GET / HTTP/1.1\r\nHeader: value\r\nAnotherHeader: another_value\r\nHost: example.org") == "GET / HTTP/1.1\r\nAnotherHeader: another_value\r\nHeader: value\r\nHost: example.org"

# Generated at 2022-06-21 14:12:01.821932
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test set-up:
    fp = HeadersFormatter()
    # Default set-up:

# Generated at 2022-06-21 14:12:08.977581
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Content-Type: text/html; charset=utf-8
Content-Length: 1270
Connection: close
Etag: "57a7aec2-4e2"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: d4b4c19f-3ec3-4a03-97e3-849c8e2f2849
X-Runtime: 0.073600
'''

# Generated at 2022-06-21 14:12:11.146311
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled == False


# Unit tests for the format_headers method

# Generated at 2022-06-21 14:12:20.866013
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    input = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        'Vary: Cookie\r\n'
        'Vary: Accept-Encoding\r\na: b\r\n'
        'Server: gunicorn/19.9.0\r\n'
        'Date: Tue, 14 Jan 2020 10:11:29 GMT\r\n'
        'Content-Length: 2\r\n\r\n'
    )

# Generated at 2022-06-21 14:12:28.348694
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from httpie import ExitStatus
    from pygments.token import Token

    class MockSession:
        def __init__(self):
            self.exit_status = ExitStatus.OK

    session = MockSession()
    f = HeadersFormatter(
        get_lexer=get_lexer,
        options={
            'headers': {
                'all': False,
                'sort': True
            }
        },
        session=session
    )
    assert f._should_enable()
    assert f.enabled
    assert 'headers' not in f.format_options
    assert f.format_options['headers']['all'] == False
    assert f.format_options['headers']['sort'] == True