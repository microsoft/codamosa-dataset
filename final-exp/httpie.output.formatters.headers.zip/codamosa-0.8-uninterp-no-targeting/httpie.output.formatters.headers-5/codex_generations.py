

# Generated at 2022-06-21 14:03:06.006128
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    except Exception as e:
        print(f'Got an exception: {e}')
        assert False

    assert formatter.enabled == True



# Generated at 2022-06-21 14:03:13.394377
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {'headers': {'sort': True}, 'pretty': False}
    headers_formatter = HeadersFormatter(format_options=format_options)
    headers = '\r\n'.join((
        'HTTP/1.1 200 OK',
        'Connection: keep-alive',
        'Content-Encoding: gzip',
        'Content-Length: 175',
        'Server: nginx',
        'Content-Type: application/json',
    ))
    expected_headers = '\r\n'.join((
        'HTTP/1.1 200 OK',
        'Content-Encoding: gzip',
        'Content-Length: 175',
        'Content-Type: application/json',
        'Connection: keep-alive',
        'Server: nginx',
    ))
    assert headers_formatter

# Generated at 2022-06-21 14:03:14.869252
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(None, None, None)

# Generated at 2022-06-21 14:03:26.159486
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    output = f.format_headers("""HTTP/1.1 200 OK
Host: localhost:5000
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/0.9.2
Content-Length: 49""")
    assert output == """HTTP/1.1 200 OK
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 49
Host: localhost:5000
User-Agent: HTTPie/0.9.2"""



# Necessary to allow plugins to be loaded as modules
from httpie.plugins import FormatterPlugin
from httpie.plugins.builtin import FormattedHTTPiePlugin
from httpie.utils import get_response_body_as_unicode




# Generated at 2022-06-21 14:03:26.892737
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-21 14:03:34.311422
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test input and expected output.
    # Test input is a string derived from a set of headers, with
    # the first 'line' being \r\n. The headers are not sorted
    # and contain duplicates, e.g. the second and third lines
    # begin with Host:
    test_input = \
        '\r\n' \
        'Host: httpbin.org\r\n' \
        'Host: httpbin.org\r\n' \
        'User-Agent: HTTPie/1.0.3\r\n' \
        'Accept-Encoding: gzip, deflate\r\n' \
        'Accept: application/json\r\n' \
        'Connection: keep-alive\r\n' \
        '\r\n'

# Generated at 2022-06-21 14:03:43.091265
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Content-Length: 5',
        'Content-Type: application/json',
        'Host: localhost',
        'Transfer-Encoding: chunked'
    ])
    assert HeadersFormatter().format_headers(headers) == '\r\n'.join([
        'GET / HTTP/1.1',
        'Content-Length: 5',
        'Content-Type: application/json',
        'Host: localhost',
        'Transfer-Encoding: chunked'
    ])


# Generated at 2022-06-21 14:03:46.557303
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hasattr(hf, 'format_headers')
    assert hasattr(hf, 'format_response')
    assert hasattr(hf, 'format_request')
# Unit tests for method HeadersFormatter.format_headers()

# Generated at 2022-06-21 14:03:54.964635
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

    # Unsorted header
    s = '''
HTML/1.1 200 OK
Content-Length: 8
Content-Type: application/json; charset=UTF-8
Pragma: no-cache
Server: Jetty(7.6.13.v20130916)
'''
    # Sorted header
    s_sorted = '''
HTML/1.1 200 OK
Content-Length: 8
Content-Type: application/json; charset=UTF-8
Pragma: no-cache
Server: Jetty(7.6.13.v20130916)
'''
    assert h.format_headers(s) == s_sorted



# Generated at 2022-06-21 14:03:56.930942
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:04:10.918410
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\n" \
              "Date: Tue, 15 Nov 1994 12:45:26 GMT\r\n" \
              "Server: Apache/1.3.27 (Unix) (Red-Hat/Linux)\r\n"\
              "Last-Modified: Wed, 21 Oct 2015 07:28:00 GMT\r\n" \
              "ETag: \"3f80f-1b6-556e9853e3bdd\"\r\n" \
              "Accept-Ranges: bytes\r\n" \
              "Content-Length: 438\r\n" \
              "Connection: close\r\n" \
              "Content-Type: text/html\r\n\r\n"

# Generated at 2022-06-21 14:04:20.594311
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fp = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Content-Length: 34
Content-Type: text/html; charset=UTF-8
Server: Example
'''
    headers_sorted = '''\
HTTP/1.1 200 OK
Content-Length: 34
Content-Type: text/html; charset=UTF-8
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Example
'''
    assert fp.format_headers(headers) == headers_sorted



# Generated at 2022-06-21 14:04:30.825477
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers(test_headers) == test_headers_sorted

# Input string used for testing method format_headers of class HeadersFormatter
test_headers = textwrap.dedent('''\
    Host: api.github.com
    User-Agent: httpie/1.0.2
    Accept: application/vnd.github.v3+json
    Authorization: token 3f444d6c736df6b0fd6c8bad81208e8072a5d5a5
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    ''')

# Expected output string used for testing method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:04:41.138533
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_before = '''\
        { 'Connection': 'keep-alive',
          'Content-Encoding': 'gzip',
          'Content-Type': 'application/json',
          'Date': 'Sun, 17 Dec 2017 01:04:52 GMT',
          'Server': 'nginx/1.12.2',
          'Transfer-Encoding': 'chunked',
          'Vary': 'Origin' }
        '''

# Generated at 2022-06-21 14:04:47.043174
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Connection: keep-alive\r\n'
        'Transfer-Encoding: chunked\r\n'
        'Keep-Alive: timeout=60\r\n'
        'Server: gunicorn/19.9.0\r\n'
        'Date: Sun, 09 Dec 2018 14:09:03 GMT\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'X-Powered-By: Flask\r\n'
        'Allow: GET, POST\r\n'
    )

# Generated at 2022-06-21 14:04:58.850398
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	hf = HeadersFormatter(**{'headers': {'sort': True}})
	assert hf.format_headers('GET /test HTTP/1.1\r\nHost: localhost:5000\r\nConnection: keep-alive\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\n\r\n') == 'GET /test HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nConnection: keep-alive\r\nHost: localhost:5000\r\n\r\n'

# Generated at 2022-06-21 14:05:00.606778
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter({})
    assert headers_formatter.enabled is False


# Generated at 2022-06-21 14:05:12.732095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = (
        "HTTP/1.1 200 OK\r\n"
        "\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: 2\r\n"
        "X-Auth-Token: abcdefghijklmn\r\n"
        "X-Auth-Token: 1234567890123\r\n"
    )
    expected = (
        "HTTP/1.1 200 OK\r\n"
        "\r\n"
        "Content-Length: 2\r\n"
        "Content-Type: application/json\r\n"
        "X-Auth-Token: abcdefghijklmn\r\n"
        "X-Auth-Token: 1234567890123\r\n"
    )
   

# Generated at 2022-06-21 14:05:13.523211
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()


# Generated at 2022-06-21 14:05:18.739262
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    value = {
        'headers': {
            'all': 'always',
            'pretty': 'always',
            'redact': ['authorization'],
            'sort': True,
        }
    }
    instance = HeadersFormatter(format_options=value)
    assert isinstance(value, dict)
    assert value == instance.format_options
    assert instance.enabled == instance.format_options['headers']['sort']


# Generated at 2022-06-21 14:05:23.994819
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled


# Generated at 2022-06-21 14:05:33.861657
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers = '''\
date: Mon, 16 Dec 2019 18:14:47 GMT
server: Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.2.26
location: http://localhost/time
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(test_headers) == '''\
date: Mon, 16 Dec 2019 18:14:47 GMT
location: http://localhost/time
server: Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.2.26'''

# Generated at 2022-06-21 14:05:43.158925
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    input_ = """\
Connection: keep-alive
Content-Length: 422
Content-Type: application/json
Cache-Control: max-age=0
Accept-Language: en-US,en;q=0.8
Accept-Encoding: gzip, deflate, sdch
Accept: */*
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/39.0.2171.65 Chrome/39.0.2171.65 Safari/537.36
"""

# Generated at 2022-06-21 14:05:45.366934
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert(HeadersFormatter is not None)


# Generated at 2022-06-21 14:05:49.789057
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "Content-Type: application/json\r\nContent-Type: text/html\r\n"
    expected = "Content-Type: application/json\r\nContent-Type: text/html\r\n"
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-21 14:06:01.977288
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    NOTE: This unit test is 'disabled' (in the sense that the test name
        starts with 'test_x') to avoid test discovery, since the test
        requires a File 'test_HeadersFormatter_format_headers.txt' to be present
        in the subdirectory 'tests'.
        The test is only 'activated' when the script
        'test_HeadersFormatter_format_headers.sh' is called.
    """
    # Set the file path to store the headers
    my_file_path = 'tests/test_HeadersFormatter_format_headers.txt'
    # Print the header lines to the file

# Generated at 2022-06-21 14:06:05.900455
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter.__new__(HeadersFormatter)
    assert formatter.enabled == True

    formatter.enabled = False
    assert formatter.enabled == False


# Generated at 2022-06-21 14:06:07.984422
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is False
    assert formatter.format_options['headers']['sort']

# Generated at 2022-06-21 14:06:12.526942
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_headers("""
    Content-Type: application/json
    Content-Length: 35
    Accept-Encoding: gzip
    Accept: */*
    User-Agent: HTTPie/0.9.9
    """)

    assert headers_formatter.format_options['headers']['sort'] == True

# Generated at 2022-06-21 14:06:20.554678
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = dict(style='solarized', truncate_ok=True, sort=True)
    headers = dict(style='solarized', truncate_ok=True, sort=True)
    formatter = dict(style='solarized', max_length=200, sort=True,
                 truncate_body=True, headers=headers)
    format_options = dict(options=options, formatter=formatter)

    formatter = HeadersFormatter(**format_options)
    assert formatter.format_options == format_options
    assert formatter.enabled == True


# Generated at 2022-06-21 14:06:32.386166
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert formatter.format_options['headers']['sort']
    assert formatter.enabled


# Generated at 2022-06-21 14:06:33.345462
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()

# Generated at 2022-06-21 14:06:34.528951
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeaderFormatter() != None


# Generated at 2022-06-21 14:06:40.974159
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter("headers")
    headers = """
        HTTP/1.1 200 OK
        Content-Length: 1507
        Content-Type: text/html; charset=UTF-8
        Content-Encoding: gzip
        Content-Length: 1507
        Content-Type: text/html; charset=UTF-8
        Connection: keep-alive
        """.strip()
    sorted_headers = fmt.format_headers(headers)


# Generated at 2022-06-21 14:06:42.783732
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter(format_options=dict())
    assert obj.enabled is False


# Generated at 2022-06-21 14:06:54.974619
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test if method format_headers of class HeadersFormatter
    sorts headers by name while retaining relative
    order of multiple headers with the same name.
    """

    inputText = '''HTTP/1.1 200 OK
Cache-Control: no-cache
Pragma: no-cache
Content-Type: application/json; charset=utf-8
Expires: -1
Server: Microsoft-IIS/8.0
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Date: Thu, 23 Mar 2017 07:31:14 GMT
Content-Length: 55
'''


# Generated at 2022-06-21 14:07:02.355885
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    fmt: HeadersFormatter = HeadersFormatter(format_options={
        'headers': {'sort': True}
    })
    headers: str = ('GET / HTTP/1.1\r\n'
                    'Host: www.example.com\r\n'
                    'Accept-Encoding: gzip, deflate\r\n'
                    'Accept: */*\r\n'
                    'Accept-Language: en\r\n'
                    'User-Agent: HTTPie/1.0.3\r\n'
                    'Connection: keep-alive\r\n'
                    '\r\n')

    # When
    result: str = fmt.format_headers(headers)

    # Then

# Generated at 2022-06-21 14:07:04.239501
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == True


# Generated at 2022-06-21 14:07:05.284168
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert(HeadersFormatter)


# Generated at 2022-06-21 14:07:06.405218
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        HeadersFormatter(format_options={'headers': {'sort': True}})
    except:
        assert False


# Generated at 2022-06-21 14:07:19.110839
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Normal case 1
    headersFormatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert headersFormatter.enabled

    # Normal case 2
    headersFormatter = HeadersFormatter(format_options={
        'headers': {
            'sort': False
        }
    })
    assert not headersFormatter.enabled


# Generated at 2022-06-21 14:07:19.713017
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-21 14:07:28.306138
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """
REQUEST_METHOD: GET
HTTP_HEADER1: value1
HTTP_HEADER2: value2
HTTP_HEADER3: value3
    """.strip()
    assert headers == headers_formatter.format_headers(headers)

    headers = """
REQUEST_METHOD: GET
HTTP_HEADER1: value1
HTTP_HEADER1: value2
HTTP_HEADER3: value3
    """.strip()
    assert headers == headers_formatter.format_headers(headers)

    headers = """
REQUEST_METHOD: GET
HTTP_HEADER3: value3
HTTP_HEADER1: value1
HTTP_HEADER1: value2
    """.strip()
    assert headers == headers_formatter.format_headers(headers)


# Generated at 2022-06-21 14:07:39.337372
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers = 'HTTP/1.1 200 OK\r\n' +\
                   'Date: Tue, 04 Aug 2020 05:23:12 GMT\r\n' +\
                   'Cache-Control: max-age=60\r\n' +\
                   'Cache-Control: max-age=120\r\n' +\
                   'Cache-Control: max-age=80\r\n' +\
                   'Cache-Control: max-age=40\r\n'

# Generated at 2022-06-21 14:07:50.962624
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(format_options={'headers':{'sort': True}})
    res = h.format_headers("""HTTP/1.1 200 OK
Content-Length: 1234
Accept: application/json, */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.9
X-Amzn-Trace-Id: Root=1-5a62a159-0aaddbb58971d5fb2f5b5c83
Date: Wed, 07 Feb 2018 16:51:41 GMT
Via: 1.1 vegur

""")

# Generated at 2022-06-21 14:07:58.488943
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:08:06.215033
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """HTTP/1.1 200 OK
Content-Encoding: gz
Content-Length: 206
Content-Type: text/html; charset=UTF-8
Date: Mon, 17 Feb 2020 04:40:47 GMT
Server: Apache
Vary: Accept-Encoding,Cookie
X-Powered-By: PHP/7.2.18
"""
    hf = HeadersFormatter()
    result = hf.format_headers(headers)
    # The order of `Vary` and `X-Powered-By` can change, so simulate
    # the case where they change and compare the sorted headers to the
    # formatted result.
    lines = headers.splitlines()
    vary_header = lines[7]
    x_powered_by_header = lines[8]
    lines[7] = x_powered_by

# Generated at 2022-06-21 14:08:11.198535
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = b'Content-Length: 113\r\nContent-Type: application/json\r\n\r\n'
    assert formatter.format_headers(headers.decode("utf-8")) == headers.decode("utf-8")

# Generated at 2022-06-21 14:08:20.962473
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {
        'headers': {'sort': True}
    }
    headers_input = '''
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Language: en-US
Content-Length: 265
Content-Type: text/html; charset=utf-8
Expires: Sat, 26 Jul 1997 05:00:00 GMT
Last-Modified: Mon, 31 Aug 2020 20:48:46 GMT
Server: ASERV
X-Frame-Options: SAMEORIGIN
'''.strip()

    headers_output = headers_formatter.format_headers(headers_input)


# Generated at 2022-06-21 14:08:22.574074
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print("Test constructor of class HeadersFormatter")
    hf = HeadersFormatter()


# Generated at 2022-06-21 14:08:42.435972
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter
    assert fmt.format_headers(
        'GET / HTTP/1.1\r\n'
        'Connection: close\r\n'
        'Content-Length: 5\r\n'
        'Accept: */*\r\n'
        '\r\n'
    ) == (
        'GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Connection: close\r\n'
        'Content-Length: 5\r\n'
        '\r\n'
    )



# Generated at 2022-06-21 14:08:55.084618
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test for alphabetical headers
    headers = (
        'Content-Type: text/html; charset=UTF-8\r\n'
        'Content-Transfer-Encoding: 8bit\r\n'
        'Content-Length: 6\r\n'
        'Accept-Ranges: bytes\r\n'
        'Vary: Accept-Encoding')
    expected_headers = (
        'Content-Type: text/html; charset=UTF-8\r\n'
        'Content-Length: 6\r\n'
        'Content-Transfer-Encoding: 8bit\r\n'
        'Accept-Ranges: bytes\r\n'
        'Vary: Accept-Encoding')
    hf = HeadersFormatter()
    hf.enabled = True
    actual_headers = hf

# Generated at 2022-06-21 14:09:06.702443
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:09:11.592357
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()

    assert f.format_headers("") == ""
    assert f.format_headers("x: 1") == "x: 1"
    assert f.format_headers("x: 1\r\nz: 2") == "x: 1\r\nz: 2"

    assert f.format_headers("x: 1\r\nz: 2\r\nx: 3") == "x: 1\r\nx: 3\r\nz: 2"

# Generated at 2022-06-21 14:09:15.451222
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    head = HeadersFormatter(format_options)
    assert isinstance(head, FormatterPlugin)
    assert head.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:09:18.735080
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert formatter.enabled is True
    assert formatter.format_options == {"headers": {"sort": True}}


# Generated at 2022-06-21 14:09:21.267880
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hitems = {'headers': {'sort': True}}
    hformatter = HeadersFormatter(format_options=hitems)
    assert hformatter.enabled == True


# Generated at 2022-06-21 14:09:23.721437
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers={'headers': {'sort': True}}
    obj=HeadersFormatter(format_options=headers)
    assert obj is not None


# Generated at 2022-06-21 14:09:29.190062
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    http_request = '''\
GET / HTTP/1.1
Host: www.example.com
Connection: close
Accept-Encoding: gzip
Accept-Encoding: deflate
Accept: */*
User-Agent: HTTPie/0.9.8


'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip
Accept-Encoding: deflate
Connection: close
Host: www.example.com
User-Agent: HTTPie/0.9.8


'''

    assert expected == HeadersFormatter.format_headers(http_request)



# Generated at 2022-06-21 14:09:39.453203
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:10:10.475027
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {
            'sort': True
        }
    }
    headersFormatter = HeadersFormatter(format_options=format_options)
    assert headersFormatter.enabled
    assert headersFormatter.format_options == format_options


# Generated at 2022-06-21 14:10:19.285518
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    sorted_header = hf.format_headers('''\
Connection: keep-alive
User-Agent: HTTPie/0.9.9
Accept: */*
Accept-Encoding: gzip, deflate
Content-Type: application/json; charset=utf-8
Accept-Language: zh-CN,zh;q=0.8,en;q=0.6
Content-Length: 26
Host: www.baidu.com''')

# Generated at 2022-06-21 14:10:28.041965
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    fmt.format_options = {
        'headers': {
            'sort': True
        }
    }
    assert fmt.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'X-Test-1: first\r\n'
        'X-Test-2: other\r\n'
        'X-Test-2: second\r\n') == (
            'HTTP/1.1 200 OK\r\n'
            'X-Test-1: first\r\n'
            'X-Test-2: other\r\n'
            'X-Test-2: second\r\n')

# Generated at 2022-06-21 14:10:35.820858
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:10:44.997977
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create a HeadersFormatter object and check it is enabled
    hdrs_fmt = HeadersFormatter()
    assert hdrs_fmt.enabled == True

    # Create a sample HTTP headers string
    headers = """GET /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9


"""

    # Check that the method format_headers sorts the headers
    assert hdrs_fmt.format_headers(headers) == """GET /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9


"""

# Generated at 2022-06-21 14:10:53.747961
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Fri, 01 Apr 2016 17:45:17 GMT
Server: Apache/2.4.7 (Ubuntu)
Cache-Control: no-cache
Content-Length: 198
Content-Type: text/html; charset=utf-8\
'''
    expected = '''\
HTTP/1.1 200 OK
Cache-Control: no-cache
Content-Length: 198
Content-Type: text/html; charset=utf-8
Date: Fri, 01 Apr 2016 17:45:17 GMT
Server: Apache/2.4.7 (Ubuntu)\
'''
    assert hf.format_headers(headers) == expected



# Generated at 2022-06-21 14:10:55.694226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled



# Generated at 2022-06-21 14:10:56.894376
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:10:58.419086
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-21 14:11:09.243911
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
        hf = HeadersFormatter()
        r = hf.format_headers('''\
HTTP/1.1 200 OK
Date: Wed, 13 Mar 2019 17:00:47 GMT
Content-Type: application/json
Connection: close
Transfer-Encoding: chunked
Server: mw1270.eqiad.wmnet
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
Content-Language: en
X-Powered-By: HHVM/3.18.6-dev
X-Varnish: 1623292211
Age: 0
Via: 1.1 varnish (Varnish/5.1)
Accept-Ranges: bytes
''')

# Generated at 2022-06-21 14:12:52.476201
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:12:55.491933
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True} }).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': False} }).enabled


# Generated at 2022-06-21 14:13:01.308966
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Setup
    formatter = HeadersFormatter()
    headers = '''
Content-Type: application/json
X-Foo: Bar
Content-Length: 42
    '''

    # Exercise
    actual_headers = formatter.format_headers(headers)

    # Assert
    expected_headers = '''
Content-Type: application/json
Content-Length: 42
X-Foo: Bar
    '''
    assert actual_headers == expected_headers
