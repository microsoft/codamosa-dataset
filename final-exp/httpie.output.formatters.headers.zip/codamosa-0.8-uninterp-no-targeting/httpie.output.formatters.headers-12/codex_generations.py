

# Generated at 2022-06-21 14:03:10.902607
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = ('Host: example.org' + '\r\n' +
               'User-Agent: httpie' + '\r\n' +
               'Accept-Encoding: gzip, deflate' + '\r\n' +
               'Accept: */*' + '\r\n' +
               'Connection: keep-alive' + '\r\n')
    expected = ('Host: example.org' + '\r\n' +
                'Accept: */*' + '\r\n' +
                'Accept-Encoding: gzip, deflate' + '\r\n' +
                'Connection: keep-alive' + '\r\n' +
                'User-Agent: httpie' + '\r\n')

# Generated at 2022-06-21 14:03:17.602515
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Given
    formatter = HeadersFormatter()
    # When
    output = formatter.format_headers("""X-Something: true\r\nX-Other: ok\r\nA-Header: 1\r\n""")
    # Then
    assert output == """X-Something: true\r\nX-Other: ok\r\nA-Header: 1\r\n"""


# Generated at 2022-06-21 14:03:21.237232
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter(format_options={'headers': {'sort': 'False'}})
    assert x.__class__.__name__ == 'HeadersFormatter'
    assert x.format_options['headers']['sort'] == False


# Generated at 2022-06-21 14:03:23.874730
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(
    ).format_headers(
        HTTP_HEADERS_OUTPUT
    ) == HTTP_HEADERS_OUTPUT_SORTED


# Generated at 2022-06-21 14:03:27.557226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    hf = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert hf.enabled == False
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.enabled == True

# Generated at 2022-06-21 14:03:30.511170
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('a: b\nx:ab\nz:ab\nc:d') == 'a: b\nc:d\nx:ab\nz:ab'

##############


# Generated at 2022-06-21 14:03:36.223430
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Host: httpbin.org
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.3
Accept-Encoding: gzip,deflate,sdch
Accept-Language: en-US,en;q=0.8
Accept: */*
User-Agent: HTTPie/0.6.0
"""
    h = HeadersFormatter()

# Generated at 2022-06-21 14:03:38.224614
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is True


# Generated at 2022-06-21 14:03:48.240600
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\n" \
              "Date: Sun, 27 Oct 2019 07:52:13 GMT\r\n" \
              "Server: Apache\r\n" \
              "Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\n" \
              "Etag: \"34aa387-d-1568eb00\"\r\n" \
              "Accept-Ranges: bytes\r\n" \
              "Content-Length: 51\r\n" \
              "Connection: close\r\n" \
              "Content-Type: text/plain\r\n" \
              "\r\n" \
              "The example from RFC 2616 Section 14.21\n"
    headers = formatter.format

# Generated at 2022-06-21 14:03:52.252508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        HeadersFormatter(output_stream=sys.stdout)
    except TypeError as e:
        print(e)  # Passes if no type error is raised
    except NameError as e:
        print(e)  # Passes if no name error is raised


# Generated at 2022-06-21 14:04:00.397107
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = HeadersFormatter.format_headers(formatter,
                                              '''
HTTP/1.1 200 OK
Server: nginx/1.0.4
Date: Wed, 13 Jul 2011 18:01:12 GMT
Content-Type: application/json; charset=utf-8
Transfer-Encoding: chunked
Connection: keep-alive
Status: 200 OK
X-Runtime: 10ms
Cache-Control: private, max-age=0, must-revalidate
Expires: Tue, 31 Mar 1981 05:00:00 GMT
ETag: "b3c1e8af1b9127afc000f0f46fa17a3e"
Content-Encoding: gzip
Vary: Accept-Encoding
Content-Length: 442
''')

# Generated at 2022-06-21 14:04:09.658229
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter(format_options={'headers':{'sort':True}}).format_headers('GET / HTTP/1.1\r\nContent-Type: application/json\r\nAccept: application/xml\r\nCookie: foo=bar\r\nContent-Length: 42\r\n') == 'GET / HTTP/1.1\r\nAccept: application/xml\r\nCookie: foo=bar\r\nContent-Length: 42\r\nContent-Type: application/json\r\n'

# Generated at 2022-06-21 14:04:21.004842
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\n' + \
              'Transfer-Encoding: chunked\n' + \
              'Connection: close\n' + \
              'Set-Cookie: a=1\n' + \
              'Set-Cookie: b=2\n' + \
              '\r\n'
    print(headers)
    headers = formatter.format_headers(headers)
    print(headers)

# Generated at 2022-06-21 14:04:25.318720
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ['name: age',
             'age: 22']
    headers = '\r\n'.join(lines)
    expected_headers = '\r\n'.join(sorted(lines, key=lambda h: h.split(':')[0]))
    assert HeadersFormatter().format_headers(headers) == expected_headers

# Generated at 2022-06-21 14:04:34.694558
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import formatter
    from httpie.input import ParseError

    formatter.__class__ = HeadersFormatter


# Generated at 2022-06-21 14:04:44.486748
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:04:56.595306
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    s = '''GET /test HTTP/1.1
Host: 127.0.0.1:5000
Connection: keep-alive
Cache-Control: max-age=0
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8'''
    actual = f.format_headers(s)

# Generated at 2022-06-21 14:04:57.925632
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    
    headersFormatter = HeadersFormatter()
    assert headersFormatter.enabled != 1 
    assert headersFormatter.format_options['headers']['sort'] != 1 



# Generated at 2022-06-21 14:04:59.157885
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == True

# Generated at 2022-06-21 14:05:09.651380
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
Date: Thu, 19 Jul 2018 11:28:41 GMT
Content-Type: application/json; charset=UTF-8
Content-Length: 2
Strict-Transport-Security: max-age=15552000; preload

"""
    assert(formatter.format_headers(headers) == """HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json; charset=UTF-8
Date: Thu, 19 Jul 2018 11:28:41 GMT
Strict-Transport-Security: max-age=15552000; preload
""")

INSTALLED_PLUGINS = [HeadersFormatter]

# Generated at 2022-06-21 14:05:21.813913
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK\r
Content-Type: aa\r
Content-Length: xx\r
Content-Type: bb\r
Content-Type: cc\r
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Length: xx\r
Content-Type: aa\r
Content-Type: bb\r
Content-Type: cc\r
'''


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-21 14:05:33.629551
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import DEFAULT_OPTIONS
    httpie = Httpie(options=DEFAULT_OPTIONS)
    formatter = HeadersFormatter(httpie, DEFAULT_OPTIONS)
    headers_input = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nDate: Mon, 06 Apr 2020 05:08:51 GMT\r\nServer: nginx\r\nTransfer-Encoding: chunked\r\nX-Frame-Options: SAMEORIGIN"

# Generated at 2022-06-21 14:05:34.599237
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-21 14:05:43.776436
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test with invalid parameters
    try:
        with pytest.raises(Exception):
            HeadersFormatter(name=2, version=2, format_options=2)
        with pytest.raises(Exception):
            HeadersFormatter(name=2, version="2", format_options=2)
        with pytest.raises(Exception):
            HeadersFormatter(name="2", version=2, format_options=2)
    except Exception as e:
        print("TEST PASS: HeadersFormatter", e)

    # Test with valid parameters
    try:
        HeadersFormatter(name="headers", version="0.1.1",
                         format_options={"headers": {"sort": False}})
    except Exception as e:
        print("TEST FAIL: HeadersFormatter", e)



# Generated at 2022-06-21 14:05:47.455109
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}},
                                         config={'headers': {'sort': True}})
    assert headers_formatter.enabled

# Generated at 2022-06-21 14:05:49.201077
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    my_headers_formatter = HeadersFormatter()
    assert my_headers_formatter


# Generated at 2022-06-21 14:05:53.117218
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # create a new class for testing purposes
    class HeadersFormatterTest(HeadersFormatter):
        def format(self, **kwargs):
            pass

    # initialize with the constructor
    HeadersFormatterTest(format_options={})



# Generated at 2022-06-21 14:05:55.951396
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert headersFormatter.enabled == True


# Generated at 2022-06-21 14:06:05.767594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Wed, 28 Aug 2019 14:50:00 GMT
Transfer-Encoding: chunked
Content-Type: application/json
X-Powered-By: Flask
X-Processed-Time: 57.0
Allow: GET, POST, HEAD, OPTIONS, PUT, PATCH, DELETE
Vary: Accept
Content-Encoding: gzip
X-Content-Type-Options: nosniff
"""
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:06:13.110516
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Accept: application/json
Content-Type: application/json
X-Foo: Bar
Content-Length: 57
Set-Cookie: foo=bar
Set-Cookie: baz=qux
X-Bar: Foo
"""
    expected = """\
HTTP/1.1 200 OK
Accept: application/json
Content-Length: 57
Content-Type: application/json
Set-Cookie: foo=bar
Set-Cookie: baz=qux
X-Bar: Foo
X-Foo: Bar
"""
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-21 14:06:24.127669
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """\
Content-Type: application/json
X-Foo: Bar
X-Foo: Baz
X-Baz: Qux
        """
    ) == """\
Content-Type: application/json
X-Baz: Qux
X-Foo: Bar
X-Foo: Baz
        """

# Generated at 2022-06-21 14:06:29.158511
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    # Test if the constructor works
    assert isinstance(hf, HeadersFormatter)
    # Test if the constructor correctly sets the attribute 'enabled'
    assert hf.enabled == True


# Generated at 2022-06-21 14:06:38.862334
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers ="""
POST / HTTP/1.1
Accept: application/json
Accept-Language: es
Authorization: Basic YWRtaW46cGFzc3dvcmQ=
Content-Length: 92
Content-Type: application/x-www-form-urlencoded
"""
    sorted_headers = """
POST / HTTP/1.1
Accept: application/json
Accept-Language: es
Authorization: Basic YWRtaW46cGFzc3dvcmQ=
Content-Length: 92
Content-Type: application/x-www-form-urlencoded
"""
    assert sorted_headers == headers_formatter.format_headers(headers)

# Generated at 2022-06-21 14:06:42.237864
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
  assert formatter.enabled is True, "The sort option is not enabled"
  assert isinstance(formatter, FormatterPlugin), "The HeadersFormatter class is not a subclass of FormatterPlugin"
	

# Generated at 2022-06-21 14:06:50.492215
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('''
HTTP/1.0 201 CREATED
Location: http://www.example.com/
Vary: Cookie
Content-Type: text/html; charset=utf-8
Content-Length: 10
''') == '''
HTTP/1.0 201 CREATED
Content-Length: 10
Content-Type: text/html; charset=utf-8
Location: http://www.example.com/
Vary: Cookie
'''

# Generated at 2022-06-21 14:06:59.780947
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Server: TornadoServer/4.3',
        'Date: Sun, 20 Nov 2016 08:56:19 GMT',
        'Content-Length: 66',
        '',
        '{"key":"value","num":123,"list":[1,2],"dict":{"key":"value"}}'
    ])
    formatter = HeadersFormatter()
    formatted_headers = formatter.format_headers(headers)
    assert formatted_headers == headers


# Generated at 2022-06-21 14:07:02.649402
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert isinstance(headers, HeadersFormatter) == True

# Generated at 2022-06-21 14:07:03.200570
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()



# Generated at 2022-06-21 14:07:09.650539
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Headers in random order.
    headers = """\
User-Agent: httpie
Accept-Encoding: gzip, deflate
Host: github.com
Connection: keep-alive
Accept: */*
X-RateLimit-Limit: 5000
"""
    expected_headers = """\
User-Agent: httpie
Accept-Encoding: gzip, deflate
Host: github.com
Connection: keep-alive
Accept: */*
X-RateLimit-Limit: 5000
"""
    assert HeadersFormatter(format_options={}).format_headers(headers) == expected_headers

# Generated at 2022-06-21 14:07:12.044191
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(clean_headers=True)
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:07:26.850014
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'first: 1',
        'b: 2',
        'a: 3',
        'first: 4',
    ])) == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'a: 3',
        'b: 2',
        'first: 1',
        'first: 4',
    ])


# Generated at 2022-06-21 14:07:38.350488
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Server: cloudflare
Date: Wed, 10 Jan 2018 16:40:02 GMT
Content-Type: text/plain; charset=utf-8
Transfer-Encoding: chunked
Connection: keep-alive
Set-Cookie: __cfduid=d14d3daee2b1dfb6c5b8aaa501049c5fb1515571201; expires=Thu, 10-Jan-19 16:40:01 GMT; path=/; domain=.httpbin.org; HttpOnly
Set-Cookie: fakedns=1; path=/
Access-Control-Allow-Credentials: true
Cache-Control: max-age=60
CF-RAY: 3c6ea49e4ca33676-VIE

"""

# Generated at 2022-06-21 14:07:40.417446
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter(**{'headers': {'sort': False}})
    assert instance.enabled == False

# Generated at 2022-06-21 14:07:48.652142
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '\r\n'.join([
        "HTTP/1.1 200 OK",
        "header: value",
        "headerC: value C",
        "headerA: value A",
        "headerB: value B",
    ])
    assert HeadersFormatter().format_headers(headers) == '\r\n'.join([
        "HTTP/1.1 200 OK",
        "header: value",
        "headerA: value A",
        "headerB: value B",
        "headerC: value C",
    ])



# Generated at 2022-06-21 14:07:57.115686
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from os import path
    from json import loads
    from httpie.plugins import FormatterPlugin, FormatterDict
    from httpie.plugins.builtin import JSONFormatter, sort_fields
    from libhttp.plugins import headers

    # Create a JSON instance
    JSON = JSONFormatter()
    # Create a Headers instance
    Headers = headers.HeadersFormatter()
    # Create a Formatter instance
    Formatter = FormatterPlugin()

    # Create a JSON format options
    opts = FormatterDict()
    opts['format'] = 'json'
    opts['sort_keys'] = True
    opts['indent'] = 4
    opts['separators'] = (',', ': ')
    # Create a JSON options
    o = FormatterDict()
    o['json'] = opts

   

# Generated at 2022-06-21 14:08:00.858474
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('\r\nHost: example.org\r\nAccept: text/html\r\n') == '\r\nAccept: text/html\r\nHost: example.org\r\n'

# Generated at 2022-06-21 14:08:07.532145
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test = HeadersFormatter()
    normal_headers = "Host: test.com\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\n\r\n"
    assert test.format_headers(normal_headers) == normal_headers
    unsorted_headers = "Host: test.com\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\n\r\n"
    assert test.format_headers(unsorted_headers) == normal_headers
    unsorted_headers_2 = "Host: test.com\r\nAccept: */*\r\nAccept: text/html\r\n\r\n"
    assert test.format_headers(unsorted_headers_2) == unsorted_headers_2
    unsorted_

# Generated at 2022-06-21 14:08:08.020209
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-21 14:08:17.310037
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from collections import namedtuple

    FormatOptions = namedtuple('FormatOptions', 'headers')
    format_options = FormatOptions(headers={'sort': True})
    headers_formatter = HeadersFormatter(format_options=format_options)
    assert headers_formatter.format_options == format_options
    assert headers_formatter.enabled == format_options.headers['sort']

if __name__ == '__main__':
    test_HeadersFormatter()
    headers_formatter = HeadersFormatter()
    headers = '''Host: www.python.org
Accept-Encoding: identity
Connection: close
User-Agent: HTTPie/0.9.0
'''
    print(headers_formatter.format_headers(headers))

# Generated at 2022-06-21 14:08:28.404426
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers(
        'GET / HTTP/1.1\r\n'
        'Accept-Encoding: gzip, deflate, compress\r\n'
        'Accept: */*\r\n'
        'User-Agent: HTTPie/0.8.0\r\n'
        'Host: localhost:5000\r\n'
    ) == (
        'GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate, compress\r\n'
        'Host: localhost:5000\r\n'
        'User-Agent: HTTPie/0.8.0\r\n'
    )

# Generated at 2022-06-21 14:08:54.238358
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.format_options['headers']['sort'] == True
    assert x.enabled == True


# Generated at 2022-06-21 14:08:56.000499
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-21 14:08:58.177495
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f is not None
    

# Generated at 2022-06-21 14:09:08.834849
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_before = [
        'X-Auth-Token: adzcvcxzvbxz',
        'Content-Type: application/json',
        'Accept: application/json',
        'Connection: keep-alive',
        'Content-Length: 44',
        'Host: www.example.com',
        'X-Real-IP: 23.34.45.56',
        'X-Forwarded-For: 23.34.45.56',
        'X-Forwarded-Proto: https',
        'User-Agent: HTTPie/1.0.3',
    ]

# Generated at 2022-06-21 14:09:18.606257
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:09:25.635442
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.format_headers('Content-Type: application/json\r\nX-XSS-Protection: 1; mode=block\r\nX-Frame-Options: SAMEORIGIN\r\nX-Content-Type-Options: nosniff') == 'Content-Type: application/json\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: SAMEORIGIN\r\nX-XSS-Protection: 1; mode=block'
    
    
    

# Generated at 2022-06-21 14:09:36.255562
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    text_original = '\r\n'.join([
        'POST http://httpbin.org/post HTTP/1.1',
        'Accept: text/plain, application/json',
        'Content-Type: application/json',
        'Content-Length: 0',
        'Accept-Encoding: gzip, deflate',
        'Host: httpbin.org',
        'User-agent: HTTPie/0.9.9'
    ])


# Generated at 2022-06-21 14:09:44.491827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers_input) == '\r\n'.join(result)

# Generated at 2022-06-21 14:09:46.398892
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == h.format_options['headers']['sort']
    assert h.enabled == False


# Generated at 2022-06-21 14:09:51.567395
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    FormatterPlugin1 = HeadersFormatter()
    text = 'X-Frame-Options: ALLOW-FROM https://www.facebook.com/\r\n' \
           'X-Frame-Options: ALLOWALL\r\n' \
           'Strict-Transport-Security: max-age=31536000\r\n' \
           'Content-Security-Policy: default-src https://staticxx.facebook.com https://www.facebook.com https://facebook.com;'
    assert FormatterPlugin1.format_headers(text) == text
# end


# Generated at 2022-06-21 14:10:55.659511
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter()

# Generated at 2022-06-21 14:11:02.451083
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from io import StringIO

    hf = HeadersFormatter(file=StringIO())
    assert hf.format_headers('Content-Type: application/json\r\n'
                             'Content-Length: 27\r\n'
                             'X-My-Header: 1\r\n'
                             'Date: ') == \
                             'Content-Length: 27\r\n' \
                             'Content-Type: application/json\r\n' \
                             'Date: \r\n' \
                             'X-My-Header: 1'

# Generated at 2022-06-21 14:11:04.156902
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter(output_options={'headers': {'sort': None}})


# Generated at 2022-06-21 14:11:14.020066
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    string = 'HTTP/1.1 201\r\n' \
             'Date: Thu, 23 Jun 2016 20:07:26 GMT\r\n' \
             'Server: Apache/2.4.18 (Ubuntu)\r\n' \
             'X-Powered-By: PHP/7.0.6-1+deb.sury.org~xenial+2\r\n' \
             'Vary: Accept-Encoding\r\n' \
             'Content-Length: 0\r\n' \
             'Connection: close\r\n' \
             'Content-Type: text/html; charset=UTF-8\r\n'
    out = formatter.format_headers(string)

# Generated at 2022-06-21 14:11:19.801418
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers_formatter = HeadersFormatter()
    test_headers_formatter.format_options = {"headers": {"sort": True}}

# Generated at 2022-06-21 14:11:21.078024
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_formatter = HeadersFormatter()


# Generated at 2022-06-21 14:11:21.853359
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert True



# Generated at 2022-06-21 14:11:31.532516
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Test with default arguments
    headers_formatter = HeadersFormatter()

    assert headers_formatter.format_options == {
        'headers': {
            'sort': False
        }
    }

    with pytest.raises(AttributeError):
        assert headers_formatter.enabled is False

    # Test with headers option sort
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}}
    )

    assert headers_formatter.enabled is True

    # Test with header option no sort
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': False}}
    )

    assert headers_formatter.enabled is False

# Generated at 2022-06-21 14:11:34.197120
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert formatter.format_options['headers']['sort']

# Generated at 2022-06-21 14:11:35.706776
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersformatter = HeadersFormatter()
    assert headersformatter.enabled is True
