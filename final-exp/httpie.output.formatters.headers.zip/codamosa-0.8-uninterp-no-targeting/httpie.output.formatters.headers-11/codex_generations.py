

# Generated at 2022-06-21 14:03:05.230686
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('foo: 123\nbar: baz\nbar: qux\n') == \
        'foo: 123\nbar: baz\nbar: qux'


plugin_cls = HeadersFormatter

# Generated at 2022-06-21 14:03:09.732567
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # pylint: disable=protected-access,unused-variable
    assert HeadersFormatter._options().is_valid()
    assert HeadersFormatter._options().exists('headers', 'sort')
    assert HeadersFormatter._options().get('headers', 'sort')
    assert HeadersFormatter._options().is_bool('headers', 'sort')
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-21 14:03:16.040489
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = hf.format_headers("""Host: localhost:9000
Connection: keep-alive
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
User-Agent: Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36
Referer: http://localhost:9000/
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8""")

# Generated at 2022-06-21 14:03:21.238460
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Constructor of class HeadersFormatter
    formatter = HeadersFormatter()
    assert isinstance(formatter, HeadersFormatter)
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.enabled is True
    assert formatter.format_options['headers']['sort'] is True


# Generated at 2022-06-21 14:03:30.674728
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter
    """
    formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nHost: www.google.com\r\nUser-Agent: HTTPie\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nConnection: keep-alive\r\n'
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nHost: www.google.com\r\nUser-Agent: HTTPie\r\n'

if __name__ == '__main__':
    test_HeadersFormatter

# Generated at 2022-06-21 14:03:33.711515
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test creation of object
    HeadersFormatter()
    # Test addition of methods to object
    assert hasattr(HeadersFormatter, "format_headers")
    

# Generated at 2022-06-21 14:03:36.268354
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    expected = True
    actual = headersFormatter.enabled
    assert actual == expected


# Generated at 2022-06-21 14:03:37.854262
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()


# Generated at 2022-06-21 14:03:47.976636
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class Options(collections.namedtuple('Options', 'headers')):
        def __bool__(self):
            return True

    class OptionsPlugin(object):
        def __init__(self, **kwargs):
            self.options = Options(headers=kwargs)

    class File(object):
        def __init__(self, *args, **kwargs):
            self.closed = False

        def close(self):
            self.closed = True

    class Response(object):
        def __init__(self, content, encoding, status, headers):
            self.content = content
            self.encoding = encoding
            self.status = status
            self.headers = headers

        def close(self):
            self.content = None


# Generated at 2022-06-21 14:03:50.729943
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().format_options['headers']['sort'] == False
    assert HeadersFormatter(sort=True).format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:04:01.119822
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter=HeadersFormatter()
    dict={'Content-Type': 'text/html; charset=utf-8', 'Date': 'Sun, 04 Nov 2018 03:32:51 GMT', 'Server': 'WSGIServer/0.2 CPython/3.7.1', 'X-Frame-Options': 'SAMEORIGIN', 'content-length': '8157', 'set-cookie': 'sessionid=3qf3s8s3rkpcaqrk0y0i06m8w58mra2c; expires=Sun, 25-Nov-2018 03:32:51 GMT; httponly; Max-Age=1209600; Path=/'}
    dict_serialized = json.dumps(dict)
    dict_deserialized = json.loads(dict_serialized)
    str=formatter.format_

# Generated at 2022-06-21 14:04:04.243838
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
     formatter = HeadersFormatter()
     assert formatter.enabled == True



# Generated at 2022-06-21 14:04:11.878602
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    headers = '''\
Content-Type: application/json
Accept: application/json
Date: Sat, 16 Nov 2019 21:42:14 GMT
Status: 200 OK
Server: gunicorn/19.9.0
'''
    assert fmt.format_headers(headers) == '''\
Content-Type: application/json
Date: Sat, 16 Nov 2019 21:42:14 GMT
Accept: application/json
Status: 200 OK
Server: gunicorn/19.9.0
'''

# Generated at 2022-06-21 14:04:21.321716
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\
GET / HTTP/1.1
Connection: keep-alive
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/1.0.2


'''
    assert hf.format_headers(headers) == '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.0.2


'''

# Generated at 2022-06-21 14:04:23.111053
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header = HeadersFormatter()
    assert header.color == 'blue'
    assert header.enabled


# Generated at 2022-06-21 14:04:24.770091
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})


# Generated at 2022-06-21 14:04:27.570780
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options = {
        'headers': {
            'sort': True
        }
    })
    return(type(formatter))


# Generated at 2022-06-21 14:04:36.260355
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=False)

# Generated at 2022-06-21 14:04:41.021719
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().format_options['headers']['sort']
    assert HeadersFormatter(disable_sort=True).format_options['headers']['sort']
    assert HeadersFormatter(headers__sort=False).format_options['headers']['sort']
    assert not HeadersFormatter(headers__sort=True).format_options['headers']['sort']
    assert not HeadersFormatter(sort=False).format_options['headers']['sort']
    assert HeadersFormatter(sort=True).format_options['headers']['sort']


# Generated at 2022-06-21 14:04:42.842830
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Arrange
    my_formatter = HeadersFormatter(**{'headers':{'sort': False}})
    # Act
    # Assert
    assert my_formatter.enabled == False

# Generated at 2022-06-21 14:04:56.286841
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """POST /post HTTP/1.1
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
Host: httpbin.org
Content-Length: 10
"""
    expected_headers = """POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 10
Host: httpbin.org
User-Agent: HTTPie/0.9.9
"""

    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected_headers


if __name__ == "__main__":
    test_HeadersFormatter_format_headers()
    print("All tests passed")

# Generated at 2022-06-21 14:05:04.869628
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test if HeadersFormatter(headers=False) still formats
    # headers if headers is explicitly enabled True.
    formatter = HeadersFormatter(headers=False)
    headers = formatter.format_headers('Accept: application/json\r\n'
                                       'Cookie: csrftoken=abc; sessionid=def\r\n'
                                       'Content-Type: text/plain')
    assert headers == 'Accept: application/json\r\n'\
                      'Content-Type: text/plain\r\n'\
                      'Cookie: csrftoken=abc; sessionid=def'

# Generated at 2022-06-21 14:05:15.279383
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers1 = '''Content-Type: application/json\r\nContent-Length: 14\r\nServer: gunicorn/19.9.0\r\nDate: Fri, 12 Apr 2019 17:36:11 GMT\r\n\r\n'''
    headers2 = '''Content-Length: 14\r\nContent-Type: application/json\r\nDate: Fri, 12 Apr 2019 17:36:11 GMT\r\nServer: gunicorn/19.9.0\r\n\r\n'''
    assert headers_formatter.format_headers(headers1) == headers2


# Generated at 2022-06-21 14:05:21.536910
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('Content-Type: application/json\r\nAccept: application/json\r\n') == \
        'Content-Type: application/json\r\nAccept: application/json\r\n'
    assert hf.format_headers('Content-Type: application/json\r\nAccept: application/json\r\nContent-Length: 0\r\n') == \
        'Content-Length: 0\r\nContent-Type: application/json\r\nAccept: application/json\r\n'



# Generated at 2022-06-21 14:05:28.770890
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Args:
        headers: Response headers
        format_options: Formatting options
    """
    headers_formatter = HeadersFormatter(headers="{'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Host': 'httpbin.org', 'User-Agent': 'HTTPie/0.9.9'}", format_options={"headers":{"sort":True}})
    assert headers_formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:05:30.676474
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(headers={})
    assert headersFormatter is not None

# Generated at 2022-06-21 14:05:32.562751
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False


# Generated at 2022-06-21 14:05:39.988564
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Date: Tue, 05 Aug 2014 21:47:37 GMT
Content-Length: 1533
Connection: keep-alive

'''
    headers_sorted = '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 1533
Content-Type: application/json; charset=utf-8
Date: Tue, 05 Aug 2014 21:47:37 GMT

'''
    assert formatter.format_headers(headers) == headers_sorted

# Generated at 2022-06-21 14:05:42.467750
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.name == 'headers'
    assert formatter.format_options == {
        'headers': {'sort': False}
    }



# Generated at 2022-06-21 14:05:44.298519
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter is not None


# Generated at 2022-06-21 14:05:58.905622
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 12
    Connection: keep-alive
    Host: localhost:8080
    """
    headers = formatter.format_headers(headers)
    expected = """
    HTTP/1.1 200 OK
    Connection: keep-alive
    Content-Length: 12
    Content-Type: application/json
    Host: localhost:8080
    """
    assert headers == expected

# Generated at 2022-06-21 14:06:07.690370
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:06:09.301256
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert('HeadersFormatter' == formatter.name)


# Generated at 2022-06-21 14:06:11.512784
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert repr(formatter) == "<HeadersFormatter format_options={'headers': {'sort': True}}>"


# Generated at 2022-06-21 14:06:18.695771
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
GET / HTTP/1.1
Accept: */*
Content-Length: 5
X-Key: val-1
X-Key: val-2
Content-Type: application/json
"""

    assert formatter.format_headers(headers) == """\
GET / HTTP/1.1
Accept: */*
Content-Length: 5
Content-Type: application/json
X-Key: val-1
X-Key: val-2
"""

# Generated at 2022-06-21 14:06:19.396029
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-21 14:06:25.574157
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatOptions = {
        'headers' : {
            'sort' : True
        },
        'pretty': {
            'colors': False,
            'format': False,
            'full_stack_trace': True,
            'theme': 'solarized',
            'verbose': False
        }
    }
    headersFormatter = HeadersFormatter(format_options = formatOptions)
    headersFormatter.format_headers()


# Generated at 2022-06-21 14:06:28.641258
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert f.format_options['headers']['sort']



# Generated at 2022-06-21 14:06:32.721700
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test of __init__(self, **kwargs)
    assert hasattr(HttpieFormatter, '__init__')
    assert callable(HttpieFormatter.__init__)
    HttpieFormatter()


# Generated at 2022-06-21 14:06:37.647418
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Create an instance of HeadersFormatter
    test = HeadersFormatter(option=1)
    # Check if 'option' has received the right value
    assert test.option == 1
    # Check if class FormatterPlugin has been super() initialized
    # and its attribute 'enabled' has received the right value
    assert test.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:06:52.512680
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
GET /foo HTTP/1.1
Accept: application/json
X-Foo: Bar
Content-Type: text/plain; charset=utf8
Content-Length: 1\
"""
    assert formatter.format_headers(headers) == """\
GET /foo HTTP/1.1
Accept: application/json
Content-Length: 1
Content-Type: text/plain; charset=utf8
X-Foo: Bar\
"""

# Generated at 2022-06-21 14:07:00.913446
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Cache-Control: public, max-age=60, s-maxage=60\r\n' \
              'X-Ratelimit-Limit: 100\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Date: Tue, 11 Feb 2020 09:19:43 GMT\r\n' \
              'X-Ratelimit-Remaining: 49\r\n' \
              'Content-Length: 13\r\n' \
              'X-Ratelimit-Reset: 1581430783\r\n' \
              'Via: 1.1 vegur\r\n'

# Generated at 2022-06-21 14:07:03.573944
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.enabled == False)


# Generated at 2022-06-21 14:07:07.412805
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    formatter = HeadersFormatter(color=True, indent=3, sort=True)

    assert formatter.color is True
    assert formatter.indent == 3
    assert formatter.enabled is True
    assert formatter.__class__.__name__ == 'HeadersFormatter'



# Generated at 2022-06-21 14:07:10.668503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('content-type:\tjson\nAccept:\t\tjson\n') == 'content-type:\tjson\nAccept:\t\tjson'


# Generated at 2022-06-21 14:07:18.348680
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:07:20.206812
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:07:21.184150
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    out = HeadersFormatter()

# Generated at 2022-06-21 14:07:29.245701
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hello_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-store
a: 0
a: 3
b: 1
a: 1
b: 0
b: 2
a: 2
'''
    expected_hello_headers = '''\
HTTP/1.1 200 OK
a: 0
a: 3
a: 1
a: 2
b: 1
b: 0
b: 2
Cache-Control: no-store
'''
    assert HeadersFormatter.format_headers(hello_headers) == expected_hello_headers

    bye_headers = '''\
HTTP/1.1 200 OK
Cache-Control: no-store
'''
    assert HeadersFormatter.format_headers(bye_headers) == bye_headers

    empty_headers = ''
    assert HeadersFormatter.format

# Generated at 2022-06-21 14:07:32.461609
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    args = AttrDict()
    args.output_options = []
    headers_formatter = HeadersFormatter(args)
    assert headers_formatter.enabled == False


# Generated at 2022-06-21 14:07:59.439601
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter(format_options={'headers':
                                            {
                                                'sort': True
                                            }
                                         })
    assert a.enabled
    assert a.format_options == {'headers':
                                    {
                                        'sort': True
                                    }
                                }

# Generated at 2022-06-21 14:08:00.309054
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-21 14:08:07.252566
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''
        Content-Type: application/json
        Location: https://httpbin.org/get
        Link: <https://httpbin.org/stylesheets/main.css>; rel=preload
        Link: <https://httpbin.org/image/png>; rel=preload; as=image
    '''
    expected_headers = '''
        Content-Type: application/json
        Location: https://httpbin.org/get
        Link: <https://httpbin.org/stylesheets/main.css>; rel=preload
        Link: <https://httpbin.org/image/png>; rel=preload; as=image
    '''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected_headers

pp = pprint.PrettyPrinter

# Generated at 2022-06-21 14:08:13.474228
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Sorts headers by name while retaining relative
    order of multiple headers with the same name.

    """

    headers = HeadersFormatter()

    s = '''\
    foo: baz
    foo: bar
    bar: baz
    bar: bar
    '''

    assert headers.format_headers(s) == '''\
    foo: baz
    foo: bar
    bar: baz
    bar: bar
    '''



# Generated at 2022-06-21 14:08:21.376664
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Make sure that the format_headers method of HeadersFormatter class returns
    sorted headers based on first index of element (header name)
    """
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json; encoding=utf-8
Content-Length: 425
Connection: keep-alive
'''
    headers_sorted = '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 425
Content-Type: application/json; encoding=utf-8
'''
    headers_formatted = HeadersFormatter().format_headers(headers)
    assert headers_formatted == headers_sorted

# Generated at 2022-06-21 14:08:25.161215
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Unit test without parameter
    test1 = HeadersFormatter()

    # Unit test with parameter
    test2 = HeadersFormatter(format_options={'headers': {'sort': True}})

    assert test1.format_options == test2.format_options



# Generated at 2022-06-21 14:08:31.334352
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

    headers = """\
HTTP/1.1 200 OK
Content-Length: 4
X-Header: 2
X-Header: 1
"""
    assert fmt.format_headers(headers) == """\
HTTP/1.1 200 OK
X-Header: 2
X-Header: 1
Content-Length: 4
"""

    headers = """\
HTTP/1.1 200 OK
Content-Length: 4
X-Header: 1
X-Header: 2
"""
    assert fmt.format_headers(headers) == """\
HTTP/1.1 200 OK
X-Header: 1
X-Header: 2
Content-Length: 4
"""

# Generated at 2022-06-21 14:08:41.711028
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """
HTTP/1.1 200 OK
Date: Tue, 12 Jun 2018 04:34:05 GMT
Connection: keep-alive
Content-Length: 14
Content-Type: application/json
Server: gunicorn/19.9.0
Vary: Origin, Accept-Encoding
X-Frame-Options: SAMEORIGIN
"""
    assert headers_formatter.format_headers(headers) == """
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 14
Content-Type: application/json
Date: Tue, 12 Jun 2018 04:34:05 GMT
Server: gunicorn/19.9.0
Vary: Origin, Accept-Encoding
X-Frame-Options: SAMEORIGIN
"""


# Generated at 2022-06-21 14:08:48.064110
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_list = 'Content-Length: 13\n' +\
                   'Connection: close\n' +\
                   'Content-Type: text/plain\n' +\
                   'Date: Tue, 25 Dec 2018 16:00:04 GMT\n' +\
                   'Server: Python/3.6 aiohttp/3.5.4'

# Generated at 2022-06-21 14:08:58.380277
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Server: nginx/1.4.1
Date: Fri, 03 Oct 2014 09:26:52 GMT
Content-Type: application/json; charset=utf-8
Connection: keep-alive
Vary: Accept-Encoding
X-Powered-By: PHP/5.3.21
Set-Cookie: laravel_session=...; expires=Fri, 03-Oct-2014 11:26:52 GMT; path=/; httponly
Cache-Control: no-cache"""


# Generated at 2022-06-21 14:09:57.580050
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    headers_formatter = HeadersFormatter(format_options=dict(
        verbose=True,
        headers=dict(
            sort=True,
        )
    ))
    headers = """\
GET / HTTP/1.1
Host: localhost:9999
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/1.0.0


    """
    # When
    formatted_headers = headers_formatter.format_headers(headers)
    # Then
    assert formatted_headers == """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Host: localhost:9999
User-Agent: HTTPie/1.0.0


    """

# Generated at 2022-06-21 14:10:08.403968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {'headers': {'sort': True}}
    # Sort headers
    upstream_headers = dedent("""\
        HTTP/1.1 200 OK
        Content-Type: text/plain; chartset=utf-8
        Content-Length: 12
        Connection: keep-alive
        Server: gunicorn/19.9.0
        Date: Wed, 20 Jun 2018 11:39:49 GMT
    """)

# Generated at 2022-06-21 14:10:14.472423
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    input = """Content-Type: text/html;charset=ISO-8859-4
Accept: text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5
Cache-Control: no-cache
Server: Jetty(9.0.z-SNAPSHOT)
"""
    output = h.format_headers(input)
    assert output == """Content-Type: text/html;charset=ISO-8859-4
Accept: text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5
Cache-Control: no-cache
Server: Jetty(9.0.z-SNAPSHOT)
"""

# Generated at 2022-06-21 14:10:25.545395
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Unit test for method format_headers of class HeadersFormatter
    formatter = HeadersFormatter()
    headers = '''\
GET / HTTP/1.1
Host: www.google.com
Connection: keep-alive
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML,
like Gecko) HeadlessChrome/61.0.3163.100 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,
image/apng,*/*;q=0.8
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.8
'''
    assert formatter.format

# Generated at 2022-06-21 14:10:33.884459
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """\
HTTP/1.1 200 OK
Content-Length: 3
Content-Type: text/plain; charset=utf-8
Content-Type: text/html
X-API-token: secret
Set-Cookie: foo=bar; domain=example.com
Set-Cookie: fizz=buzz
"""
    assert headers_formatter.format_headers(headers) == """\
HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Type: text/html
Content-Length: 3
Set-Cookie: foo=bar; domain=example.com
Set-Cookie: fizz=buzz
X-API-token: secret
"""

# Generated at 2022-06-21 14:10:42.484655
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input_string = '''HTTP/1.1 200 OK
Date: Fri, 25 Oct 2019 01:07:00 GMT
Content-Type: text/html; charset=UTF-8
Content-Length: 0
Connection: keep-alive
Keep-Alive: timeout=15
Keep-Alive: max=100\r\n'''
    expected = '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 0
Content-Type: text/html; charset=UTF-8
Date: Fri, 25 Oct 2019 01:07:00 GMT
Keep-Alive: timeout=15
Keep-Alive: max=100\r\n'''
    actual = HeadersFormatter().format_headers(input_string)
    assert actual == expected


# Generated at 2022-06-21 14:10:45.034312
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter is not None
    assert headers_formatter.enabled is True


# Generated at 2022-06-21 14:10:49.244049
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    assert HeadersFormatter(format_options).enabled == True
    format_options = {'headers': {'sort': False}}
    assert HeadersFormatter(format_options).enabled == False


# Generated at 2022-06-21 14:10:57.072587
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:10:58.632212
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options['headers']['sort']


# Generated at 2022-06-21 14:12:54.385298
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort':True}}).enabled == True



# Generated at 2022-06-21 14:13:00.846505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-Foo: Bar\r\nX-Baz: qux\r\n"
    assert formatter.format_headers(headers) == "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-Baz: qux\r\nX-Foo: Bar\r\n"
    assert formatter.format_headers("") == ""