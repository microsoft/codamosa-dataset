

# Generated at 2022-06-21 14:03:02.716177
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    rt = HeadersFormatter(format_options={'headers': {'sort': 'True'}})
    assert rt.enabled == True

if __name__ == '__main__':
    test_HeadersFormatter()

# Generated at 2022-06-21 14:03:05.193603
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    print("Unit test started: ")
    try:
        hf = HeadersFormatter()
    except SyntaxError:
        print("HeadersFormatter() failed.")
        raise


# Generated at 2022-06-21 14:03:12.697388
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.enabled

    headers = '''\
HTTP/1.0 200 OK
User-Token: abcdefghijklmnopqrstuvwxyz123456789
User-Agent: HTTPie/1.0.2
X-API-Token: abcdefghijklmnopqrstuvwxyz123456789'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.0 200 OK
X-API-Token: abcdefghijklmnopqrstuvwxyz123456789
User-Agent: HTTPie/1.0.2
User-Token: abcdefghijklmnopqrstuvwxyz123456789'''


# Generated at 2022-06-21 14:03:15.173007
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert headersFormatter.enabled


# Generated at 2022-06-21 14:03:18.930784
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter({'headers': {'sort': True}})
    assert a.enabled
    assert(a.options, {'headers': {'sort': True}})

# Generated at 2022-06-21 14:03:22.230250
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': False}})
    # test headers.sort configuration
    assert hf.format_options["headers"]["sort"] == False



# Generated at 2022-06-21 14:03:31.402896
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    formatter.enabled = True
    headers = '''\
'''
    assert formatter.format_headers(headers) == headers

    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Date: Tue, 17 Jul 2018 16:43:29 GMT
Content-Type: application/json; charset=utf-8
Allow: GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS

'''

# Generated at 2022-06-21 14:03:37.743987
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    output = HeadersFormatter().format_headers('Host: localhost\r\nAccept-Encoding: utf-8\r\nAccept: */*\r\nUser-Agent: HTTPie/0.9.6')
    assert output == 'Host: localhost\r\nAccept: */*\r\nAccept-Encoding: utf-8\r\nUser-Agent: HTTPie/0.9.6'

# Generated at 2022-06-21 14:03:39.691022
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={"headers": {"sort": True}})


# Generated at 2022-06-21 14:03:42.468698
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    head = HeadersFormatter(format_options=format_options)
    assert head.enabled is True


# Generated at 2022-06-21 14:03:46.569418
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-21 14:03:47.523130
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None


# Generated at 2022-06-21 14:03:57.334354
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\nContent-Type: text/html; charset=utf-8\r\nDate: Thu, 07 Dec 2017 09:07:57 GMT\r\nTransfer-Encoding: chunked\r\nVary: Cookie, Accept-Encoding\r\nX-Ua-Compatible: IE=Edge,chrome=1\r\n"

    # Case 1: Headers are in a correct order

# Generated at 2022-06-21 14:03:59.672880
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Given
    httpie_headers = HttpieHeaders()
    format_options = {}
    format_options['headers'] = {'sort': True}
    httpie_headers.constructor(format_options)
    # When
    result = httpie_headers.enabled
    # Then
    assert result == True


# Generated at 2022-06-21 14:04:12.253180
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Check __init__() for a non-default value for format_options
    assert HeadersFormatter(format_options={'a': 'b'}).format_options == {'a': 'b'}

    # Check __init__() for a non-default value for format_options
    assert HeadersFormatter(format_options={'a': 'b'}).format_options == {'a': 'b'}

    # Check __init__() for a default value for format_options
    assert HeadersFormatter().format_options == {'headers': {'sort': True}}

    # Check sorting of multiple headers with the same name

# Generated at 2022-06-21 14:04:20.635226
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'Content-Type: application/json\r\n'\
              'A: c\r\n'\
              'A: b\r\n'\
              'A: a\r\n'

    expected_headers = 'Content-Type: application/json\r\n'\
                       'A: c\r\n'\
                       'A: b\r\n'\
                       'A: a\r\n'

    result = HeadersFormatter().format_headers(headers)

    assert result == expected_headers


# Generated at 2022-06-21 14:04:22.172571
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled == True


# Generated at 2022-06-21 14:04:24.271226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options["headers"]["sort"] == False


# Generated at 2022-06-21 14:04:26.658749
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert hf.enabled is True



# Generated at 2022-06-21 14:04:35.658959
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    fmt = HeadersFormatter()

    header_string = """
HTTP/1.1 200 OK
Content-Length: 4
Content-Type: text/html; charset=utf-8
X-Powered-By: Werkzeug/0.14.1 Python/3.4.3
Date: Sat, 09 Jul 2016 14:26:40 GMT
Via: 1.1 vegur

data
"""

    expected_header_string = """
HTTP/1.1 200 OK
Content-Length: 4
Content-Type: text/html; charset=utf-8
Date: Sat, 09 Jul 2016 14:26:40 GMT
Via: 1.1 vegur
X-Powered-By: Werkzeug/0.14.1 Python/3.4.3

data
"""

    assert fmt.format_headers(header_string)

# Generated at 2022-06-21 14:04:45.682336
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Connection: close
Content-Length: 16
Content-Type: text/plain; charset=utf-8
Connection: keep-alive
Transfer-Encoding: chunked"""
    expected_headers = """\
HTTP/1.1 200 OK
Connection: close
Connection: keep-alive
Content-Length: 16
Content-Type: text/plain; charset=utf-8
Transfer-Encoding: chunked"""
    formatted_headers = formatter.format_headers(headers)
    assert expected_headers == formatted_headers

# Generated at 2022-06-21 14:04:50.085190
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter['httpie:headers'] == HeadersFormatter
    assert HeadersFormatter['httpie/headers'] == HeadersFormatter

    assert HeadersFormatter()
    assert HeadersFormatter(format_options={})


# Generated at 2022-06-21 14:05:01.549205
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:05:11.926914
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert "headers" in headers.format_options
    assert "sort" in headers.format_options["headers"]
    assert headers.format_options["headers"]["sort"] == False
    assert headers.enabled == False
    foptions = {}
    foptions["headers"] = {}
    foptions["headers"]["sort"] = True
    headers2 = HeadersFormatter(format_options=foptions)
    assert "headers" in headers2.format_options
    assert "sort" in headers2.format_options["headers"]
    assert headers2.format_options["headers"]["sort"] == True
    assert headers2.enabled == True


# Generated at 2022-06-21 14:05:14.372076
# Unit test for constructor of class HeadersFormatter

# Generated at 2022-06-21 14:05:16.440819
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert fmt.format_options['headers']['sort'] == True
    assert fmt.enabled == True


# Generated at 2022-06-21 14:05:21.255259
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import registry
    registry.INSTALLED_PLUGINS.append(HeadersFormatter)

    from httpie.main import main
    output = main(args=['--headers', 'get', 'httpbin.org/headers'])
    assert 'X-Test: true' in output
    assert 'User-Agent: HTTPie' in output
    assert 'Content-Type: application/json' in output
    assert 'X-Test: true' in output



# Generated at 2022-06-21 14:05:28.493828
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nAAA: bbb\r\nAAA: bbb\r\nCCC: bbb\r\n"
    assert hf.format_headers(headers) == "HTTP/1.1 200 OK\r\nAAA: bbb\r\nAAA: bbb\r\nCCC: bbb\r\nContent-Type: text/html"



# Generated at 2022-06-21 14:05:36.851445
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
POST / HTTP/1.1
Content-type: application/json
Content-Length: 1234
Cache-Control: max-age=0
Cache-Control: no-cache
'''
    assert formatter.format_headers(headers) == \
        '''\
POST / HTTP/1.1
Cache-Control: max-age=0
Cache-Control: no-cache
Content-Length: 1234
Content-type: application/json
'''


PluginManager.register(HeadersFormatter)

# Generated at 2022-06-21 14:05:43.510729
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    argv = "http -H 'X-My-Header: test' example.org"
    parsed_args = parse(docopt(doc, argv.split(' ')))
    config = Config(parsed_args)
    formatter_plugin = HeadersFormatter(config)
    assert formatter_plugin.enabled
    assert formatter_plugin.format_options['headers'] is not None
    assert formatter_plugin.format_options['headers']['sort'] is not None
    assert formatter_plugin.format_options['headers']['sort'] is True


# Generated at 2022-06-21 14:05:54.258845
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\n'
        'Server: nginx/1.14.0\n'
        'Date: Sun, 26 May 2019 16:53:44 GMT\n'
        'Content-Type: application/json\n'
        'Content-Length: 5\n'
        'Connection: keep-alive\n'
        'Strict-Transport-Security: max-age=15724800; includeSubDomains\n'
    )

# Generated at 2022-06-21 14:05:58.169120
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    assert headers_formatter.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-21 14:06:00.219681
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    real_headers_formatter = HeadersFormatter("1")
    assert real_headers_formatter != None

# Generated at 2022-06-21 14:06:08.695591
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled

    assert headers_formatter.format_headers('''.
Connection: close
Content-Length: 0
Content-Type: application/json
Date: Wed, 03 Sep 2014 16:19:38 GMT
Server: gunicorn/19.0.0
''') == '''Connection: close
Content-Length: 0
Content-Type: application/json
Date: Wed, 03 Sep 2014 16:19:38 GMT
Server: gunicorn/19.0.0
'''


# Generated at 2022-06-21 14:06:10.257049
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-21 14:06:21.336756
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  # Test 1: format_headers
  print("Test 1: format_headers")

  # 1.1. Test case 1
  print("  1.1. Test case 1:")
  formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
  assert(formatter.format_headers('HTTP/1.0 200 OK\r\nX-Foo: bar\r\nBaz: qux\r\n') == 'HTTP/1.0 200 OK\r\nBaz: qux\r\nX-Foo: bar\r\n')

  # 1.2. Test case 2
  print("  1.2. Test case 2:")
  formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-21 14:06:32.031954
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # given
    args_dict = {'headers': {'sort': True}}
    formatter_plugin = HeadersFormatter(args_dict)
    headers = ("No: 1\r\n"
               "Name: Fran\r\n"
               "Name: Bob\r\n"
               "No: 2\r\n"
               "Name: Alice")

    # when
    result = formatter_plugin.format_headers(headers)

    # then
    expected_result = ("No: 1\r\n"
                       "No: 2\r\n"
                       "Name: Fran\r\n"
                       "Name: Bob\r\n"
                       "Name: Alice")
    assert result == expected_result

# Generated at 2022-06-21 14:06:33.834539
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == True


# Generated at 2022-06-21 14:06:42.962508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    headers_formatter = HeadersFormatter()


# Generated at 2022-06-21 14:06:54.976390
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import builtin

    # Test sort headers in response
    response = b'HTTP/1.1 200 OK\r\n' \
               b'Host: host.com\r\n' \
               b'Content-Type: txt/html\r\n' \
               b'Content-Length: 42\r\n' \
               b'Custom-Header: abc\r\n' \
               b'\r\n' \
               b'abc'
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:07:19.471634
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:07:23.819584
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = 'Content-Type: image/png\r\nContent-Type: image/jpeg'
    assert 'Content-Type: image/png' in formatter.format_headers(headers)
    assert 'Content-Type: image/jpeg' in formatter.format_headers(headers)

# Generated at 2022-06-21 14:07:30.701170
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:07:33.309849
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options["headers"]["sort"] == False


# Generated at 2022-06-21 14:07:39.376550
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('HTTP/1.1 200 OK\r\nX-Foo: Baz\r\nHost: example.org\r\nContent-Length: 0\r\nX-Foo: 12')\
           == 'HTTP/1.1 200 OK\r\nContent-Length: 0\r\nHost: example.org\r\nX-Foo: Baz\r\nX-Foo: 12'

# Generated at 2022-06-21 14:07:51.008897
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:07:51.855237
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']

# Generated at 2022-06-21 14:08:03.084846
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:08:11.024570
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = ['POST / HTTP/1.1', 'Accept: application/json', 'X-Test: foo', 'X-Test: bar', 'Content-Type: application/json']
    lines2 = ['POST / HTTP/1.1', 'Accept: application/json', 'Content-Type: application/json', 'X-Test: foo', 'X-Test: bar']
    headers = '\r\n'.join(lines)
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == '\r\n'.join(lines2)

# Generated at 2022-06-21 14:08:17.795529
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        """\
GET / HTTP/1.1
Content-Type: application/json
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Connection: keep-alive

"""
    ) == """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Type: application/json
User-Agent: HTTPie/0.9.9

"""


# Generated at 2022-06-21 14:08:52.033755
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
POST /path HTTP/1.1
User-Agent: httpie
Content-Type: application/json
Accept: application/json
Connection: keep-alive
Content-Length: 4
Host: httpbin.org

{}
""".lstrip()
    headers_sorted = """\
POST /path HTTP/1.1
Accept: application/json
Connection: keep-alive
Content-Length: 4
Content-Type: application/json
Host: httpbin.org
User-Agent: httpie

{}
""".lstrip()
    assert HeadersFormatter().format_headers(headers) == headers_sorted

# Generated at 2022-06-21 14:08:52.929211
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == False


# Generated at 2022-06-21 14:08:54.998291
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:08:58.519257
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter()
    assert not head.enabled
    head = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert head.enabled


# Generated at 2022-06-21 14:09:09.100506
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:09:11.353546
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    # test if type is correct
    assert type(headersFormatter) == HeadersFormatter
    assert headersFormatter.enabled == False


# Generated at 2022-06-21 14:09:21.508197
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(stdin=io.StringIO(), format_options={
        'headers': {
            'sort': True
        }
    })

# Generated at 2022-06-21 14:09:29.030311
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled is False
    assert hf.format_options['headers']['sort'] is False
    
    assert hf.format_headers('HTTP/1.1 200\r\nDate: Tue, 03 Jul 2018 15:38:58 GMT') == 'HTTP/1.1 200\r\nDate: Tue, 03 Jul 2018 15:38:58 GMT'
    assert hf.format_headers('HTTP/1.1 200\r\nDate: Tue, 03 Jul 2018 15:38:58 GMT\r\nServer: Apache/2.4.7 (Ubuntu)') == 'HTTP/1.1 200\r\nDate: Tue, 03 Jul 2018 15:38:58 GMT\r\nServer: Apache/2.4.7 (Ubuntu)'
    assert hf.format_

# Generated at 2022-06-21 14:09:38.506048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_headers = """
POST /foo HTTP/1.1
Authorization: Basic Zm9vOmJhcg==
Date: Tue, 14 May 2013 20:30:00 GMT
Content-Type: application/x-www-form-urlencoded; charset=UTF-8"""
    expected_result = """
POST /foo HTTP/1.1
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Date: Tue, 14 May 2013 20:30:00 GMT
Authorization: Basic Zm9vOmJhcg=="""
    assert formatter.format_headers(input_headers) == expected_result

# Generated at 2022-06-21 14:09:45.117510
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "GET / HTTP/1.1\r\n" \
              "C: d\r\n" \
              "B: c\r\n" \
              "C: e\r\n" \
              "A: b\r\n"

    expected_headers = "GET / HTTP/1.1\r\n" \
                       "A: b\r\n" \
                       "B: c\r\n" \
                       "C: d\r\n" \
                       "C: e\r\n"

    assert expected_headers == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-21 14:10:45.033974
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    headers_in = '''\
HTTP/1.1 200 OK
Connection: close
Content-Length: 5
Content-Type: text/html; charset=UTF-8
Date: Fri, 23 Oct 2020 01:59:05 GMT
Server: Python/3.8 aiohttp/3.7.2
Set-Cookie: cookie1=value1; Domain=domain1; Path=/path1
Set-Cookie: cookie2=value2; Domain=domain2; Path=/path2

'''
    # Case 1: which=name, order=asc
    headers_out = headers.format_headers(headers_in)

# Generated at 2022-06-21 14:10:47.252728
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.format_options['headers']['sort'] is False


# Generated at 2022-06-21 14:10:52.067986
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
  headers = '''
content-length: 4
content-type: text/plain
data: gg
    '''
  expected_headers = '''
content-length: 4
content-type: text/plain
data: gg
    '''
  formatter = HeadersFormatter()
  actual_headers = formatter.format_headers(headers)
  print(actual_headers)
  assert actual_headers == expected_headers

# Generated at 2022-06-21 14:10:54.360797
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled is True
    assert headers_formatter.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-21 14:11:03.322554
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    HeadersFormatter_instance = HeadersFormatter()
    headers = """GET / HTTP/1.1
Accept: */*
Connection: keep-alive
Accept-Encoding: gzip, deflate, br
Accept-Language: en-US,en;q=0.9,sv;q=0.8
Host: httpbin.org
Referer: https://www.google.com/
User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64) httpie/1.1.2
"""
    result = HeadersFormatter_instance.format_headers(headers)

# Generated at 2022-06-21 14:11:13.405515
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'Content-Length: 10\r\n' \
              'Accept: */*\r\n' \
              'Accept-Encoding: gzip, deflate\r\n' \
              'Host: httpbin.org\r\n' \
              'User-Agent: HTTPie/0.9.2\r\n' \
              'Connection: keep-alive'
    expected = 'Content-Length: 10\r\n' \
               'Accept: */*\r\n' \
               'Accept-Encoding: gzip, deflate\r\n' \
               'Connection: keep-alive\r\n' \
               'Host: httpbin.org\r\n' \
               'User-Agent: HTTPie/0.9.2'

# Generated at 2022-06-21 14:11:15.129379
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.enabled == headersFormatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:11:16.866135
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled == True


# Generated at 2022-06-21 14:11:18.613221
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # TODO
    pass

# Generated at 2022-06-21 14:11:29.570338
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nX-API-KEY: 1111\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nEtag: \"34aa387-d-1568eb00\"\r\nAccept-Ranges: bytes\r\nContent-Length: 51\r\nX-First-Header: abc\r\nX-Second-Header: def\r\nX-Third-Header: ghi\r\nConnection: close\r\nContent-Type: application/json\r\n"