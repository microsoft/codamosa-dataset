

# Generated at 2022-06-21 14:03:02.110566
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options = {'headers' : {'sort' : True}})
    assert headersFormatter

# Generated at 2022-06-21 14:03:07.819440
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    input_ = 'HTTP/1.1 200 OK\rz: 1\rX-C: 1\rY-C: 2\rY-C: 4\rX-C: 3\ry: 1'
    res = hf.format_headers(input_)
    exp = 'HTTP/1.1 200 OK\rX-C: 1\rX-C: 3\rY-C: 2\rY-C: 4\rz: 1\ry: 1'
    assert res == exp



# Generated at 2022-06-21 14:03:14.740646
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Thu, 21 Dec 2017 16:41:26 GMT
Expires: -1
Content-Type: text/html; charset=UTF-8
Cache-Control: private, max-age=0
Content-Encoding: gzip
Content-Length: 843
Server: GSE
X-XSS-Protection: 1; mode=block
X-Frame-Options: SAMEORIGIN
Alt-Svc: quic=":443"; ma=2592000; v="41,39,38,37,35"

'''

# Generated at 2022-06-21 14:03:17.181147
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter


# Generated at 2022-06-21 14:03:25.034650
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class MockOptions():
        format = 'json'
        colors = False
        indent = 4
        pretty = True
        stream = False
        styles = {}
        print_body = True
        output_file = None
        headers = {'sort': False}

    options = MockOptions()

    formatter = HeadersFormatter(
        format_options=options,
        colors=options.colors,
        styles=options.styles,
        print_body=options.print_body,
        output_file=options.output_file
    )

    assert not formatter.enabled


# Generated at 2022-06-21 14:03:29.843526
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: example.com
Accept: application/json
Accept: application/xml
Cache-Control: no-cache
Content-Type: application/json\
'''
    assert HeadersFormatter().format_headers(headers) == '''\
Host: example.com
Accept: application/json
Accept: application/xml
Cache-Control: no-cache
Content-Type: application/json\
'''

# Generated at 2022-06-21 14:03:34.490985
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # GIVEN: A HeadersFormatter.
    h = HeadersFormatter()

    # WHEN: Calling method format_headers
    # THEN: A sorted version of the headers input is retrieved.
    assert h.format_headers('Accept: application/json\r\nFoo: bar') == 'Accept: application/json\r\nFoo: bar'
    assert h.format_headers('Foo: bar\r\nAccept: application/json') == 'Accept: application/json\r\nFoo: bar'



# Generated at 2022-06-21 14:03:45.664254
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:03:52.501547
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "\r\n".join([
        "HTTP/1.1 200 OK",
        "Content-Type: application/json",
        "Content-Length: 55",
        "Vary: Accept",
        "Vary: Accept-Encoding",
        "Date: Tue, 03 Mar 2020 22:11:54 GMT",
        "Server: nginx/1.14.2",
        "X-Powered-By: PHP/5.5.9-1ubuntu4.29",
        "X-Proxy-Cache: MISS",
    ])
    assert sorted_headers == HeadersFormatter().format_headers(headers)

# Generated at 2022-06-21 14:04:01.337105
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from io import StringIO

    class MockArgs:
        format = 'headers'
        sort = True

    class MockParser:
        def __init__(self):
            self.formatter_options = {}

    args = MockArgs()
    parser = MockParser()
    headers = ('Date: Thu, 19 Sep 2019 06:42:57 GMT\r\n'
               'Content-Type: text/html; charset=utf-8\r\n')

    headers_formatter = HeadersFormatter()
    headers_formatter.parser = parser
    try:
        out_file = StringIO()
        headers_formatter.write_to_output_stream(out_file, headers, args)
        headers_formatted = out_file.getvalue()
    finally:
        out_file.close()


# Generated at 2022-06-21 14:04:15.316434
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()

    headers = """\
Content-Length: 61
User-Agent: HTTPie/0.9.2
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Transfer-Encoding: chunked
"""
    headers = h.format_headers(headers)
    print(headers)
    assert headers == """\
Content-Length: 61
Accept: */*
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: httpbin.org
Transfer-Encoding: chunked
User-Agent: HTTPie/0.9.2
"""

# Generated at 2022-06-21 14:04:19.225464
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    actual = 'Host: www.google.com\nContent-Type: text'
    print(HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(actual))


# Generated at 2022-06-21 14:04:29.539815
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers(
        '''Cache-Control: max-age=0
Upgrade-Insecure-Requests: 1
User-Agent: HTTPie/0.9.9
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
Accept-Encoding: gzip, deflate''') == '''Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
Accept-Encoding: gzip, deflate
Upgrade-Insecure-Requests: 1
User-Agent: HTTPie/0.9.9'''


# Generated at 2022-06-21 14:04:39.162930
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        'Content-Length: 35\r\n'
        'Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n'
    )
    expected = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 35\r\n'
        'Content-Type: application/json\r\n'
        'Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n'
    )

    # Run
    actual = HeadersFormatter().format_headers(headers)

    # Verify
    assert expected == actual

# Generated at 2022-06-21 14:04:40.145784
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()

# Generated at 2022-06-21 14:04:43.923018
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers('header: value\r\rheader2: value2\r\rheader: value3\r\r') == 'header: value\r\rheader2: value2\r\rheader: value3\r\r'


# Generated at 2022-06-21 14:04:50.338140
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('''\
''') == ''
    assert hf.format_headers('''\
accept: text/html
cookies:
    chocolate-chip=yum
''') == '''\
accept: text/html
cookies:
    chocolate-chip=yum
'''
    assert hf.format_headers('''\
cookies:
    chocolate-chip=yum
accept: text/html
''') == '''\
cookies:
    chocolate-chip=yum
accept: text/html
'''

# Generated at 2022-06-21 14:04:57.116546
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """GET / HTTP/1.1
Host: indeego.github.io
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie"""
    expected = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Host: indeego.github.io
User-Agent: HTTPie"""
    form = HeadersFormatter()
    assert form.format_headers(headers) == expected

# Generated at 2022-06-21 14:05:03.730120
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    class MockHeaders:
        def __init__(self, headers):
            self.headers = headers
            
        def splitlines(self):
            return self.headers.splitlines()


# Generated at 2022-06-21 14:05:04.706559
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-21 14:05:10.769225
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_headersFormatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert test_headersFormatter.enabled == True


# Generated at 2022-06-21 14:05:15.279665
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter(format_options={'headers':{'sort': True}})
    got = headers.format_headers('c: 2\nb: 2\na: 1\nb: 1\n')
    assert got == 'b: 2\nb: 1\na: 1\nc: 2\n'

# Generated at 2022-06-21 14:05:23.009671
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Set up
    headers_formatter = HeadersFormatter()

    headers_unsorted = [
        'Content-Type: application/json',
        'Authorization: Basic cm9vdDpwYXNzd29yZA==',
        'User-agent: MyUserAgent/8.0',
        'Accept: application/json',
        'X-forwarded-for: 123.456.78.90',
        'Accept-Encoding: gzip, deflate',
    ]

    # Test
    result = headers_formatter.format_headers(
        '\r\n'.join(headers_unsorted))

    # Assert

# Generated at 2022-06-21 14:05:34.272475
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('HTTP/1.1 200 OK\r\n'
                            'Accept-Encoding: UTF-8\r\n'
                            'Content-Length: 25\r\n'
                            'Content-Type: application/json; charset=UTF-8\r\n'
                            'Vary: Accept-Language,Accept-Encoding') == \
           'HTTP/1.1 200 OK\r\n' \
           'Accept-Encoding: UTF-8\r\n' \
           'Content-Length: 25\r\n' \
           'Content-Type: application/json; charset=UTF-8\r\n' \
           'Vary: Accept-Language,Accept-Encoding'

# Generated at 2022-06-21 14:05:43.546544
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:05:45.415168
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-21 14:05:47.005148
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert True == hf.enabled



# Generated at 2022-06-21 14:05:58.271278
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
    HTTP/1.1 200 OK
    Date: Tue, 01 Mar 2016 16:54:47 GMT
    Server: Apache
    WWW-Authenticate: Basic realm="Access to staging site"
    Connection: close
    Transfer-Encoding: chunked
    Content-Type: text/html; charset=UTF-8
    """
    assert formatter.format_headers(headers) == """
    HTTP/1.1 200 OK
    Connection: close
    Content-Type: text/html; charset=UTF-8
    Date: Tue, 01 Mar 2016 16:54:47 GMT
    Server: Apache
    Transfer-Encoding: chunked
    WWW-Authenticate: Basic realm="Access to staging site"
    """

# Generated at 2022-06-21 14:06:07.347095
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test with no headers
    assert HeadersFormatter.format_headers('') == ''

    # Test with no headers and non-empty body
    assert HeadersFormatter.format_headers('\r\n') == '\r\n'

    # Test with one header
    assert HeadersFormatter.format_headers('X-Header: Value') == 'X-Header: Value'

    # Test with case insensitivity
    assert HeadersFormatter.format_headers('X-Header: Value\r\nx-hEadEr: Value') \
           == 'X-Header: Value\r\nX-Header: Value'

    # Test with non-empty body

# Generated at 2022-06-21 14:06:08.963107
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.format_options['headers']['sort']



# Generated at 2022-06-21 14:06:25.962957
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from json import loads
    from pathlib import Path

    from pytest import raises
    from requests import Request, Session
    from requests.structures import CaseInsensitiveDict

    # Construct an instance of HeadersFormatter
    plugin = HeadersFormatter()

    # Verify that an instance of HeadersFormatter has 5 methods
    assert len(list(filter(lambda m: not (m.startswith('_') and m.endswith('_')), dir(plugin)))) == 5

    # Verify that an instance of HeadersFormatter has 2 instance attributes
    assert len(list(filter(lambda m: not m.startswith('__'), dir(plugin)))) == 2

    # Assert that an instance of HeadersFormatter.__init__() raises a TypeError
    # when not passed a keyword argument

# Generated at 2022-06-21 14:06:27.577201
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
   headersFormatter = HeadersFormatter()


# Generated at 2022-06-21 14:06:31.883750
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled == True
    assert headers_formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:06:41.500620
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = textwrap.dedent("""\
        HTTP/1.1 200 OK
        Cache-Control: no-cache
        Content-Length: 12
        Content-Type: application/json
        Date: Sun, 26 Jan 2014 10:11:12 GMT
        Server: BaseHTTP/0.6 Python/3.4.0+
        X-Powered-By: httpie
        """)
    headers = formatter.format_headers(headers)


# Generated at 2022-06-21 14:06:44.896020
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.format_options['headers']['sort'] == True
    return


# Generated at 2022-06-21 14:06:56.310262
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
Content-Type: application/json; charset=utf-8
WWW-Authenticate: Bearer realm="api"
WWW-Authenticate: Basic realm="api"
Date: Fri, 15 Mar 2019 19:42:19 GMT
Content-Length: 14

""") == """\
Content-Type: application/json; charset=utf-8
WWW-Authenticate: Basic realm="api"
WWW-Authenticate: Bearer realm="api"
Date: Fri, 15 Mar 2019 19:42:19 GMT
Content-Length: 14

"""

# Generated at 2022-06-21 14:06:58.297967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False



# Generated at 2022-06-21 14:06:59.961608
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    u = HeadersFormatter(PropertiesObject())
    assert u.enabled == True
    assert hasattr(u, 'format_headers')


# Generated at 2022-06-21 14:07:03.342961
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	kv = "k1:v1,k2:v2"
	f = HeadersFormatter(kv)
	assert f.header == kv

# Generated at 2022-06-21 14:07:12.575602
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers(
        'No\r\n'
        'Alpha: alpha\r\n'
        'Alpha: beta\r\n'
        'Delta: delta\r\n'
        'Charlie: charlie\r\n'
        'Beta: beta\r\n'
        'Echo: echo\r\n'
    ) == (
        'No\r\n'
        'Alpha: alpha\r\n'
        'Alpha: beta\r\n'
        'Beta: beta\r\n'
        'Charlie: charlie\r\n'
        'Delta: delta\r\n'
        'Echo: echo\r\n'
    )


# Enter your test code below


# Do not change any code below this

# Generated at 2022-06-21 14:07:30.568294
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersformat = HeadersFormatter(format_options={'headers':{'sort': False}})
    assert headersformat.format_options['headers']['sort'] == False
    assert headersformat.enabled == False
    headersformat = HeadersFormatter(format_options={'headers':{'sort': True}})
    assert headersformat.format_options['headers']['sort'] == True
    assert headersformat.enabled == True

# Generated at 2022-06-21 14:07:34.336043
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert 'sort' in headers_formatter.format_options['headers']
    assert 'delimiter' not in headers_formatter.format_options['headers']


# Generated at 2022-06-21 14:07:41.947496
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    raw_headers = """GET https://httpbin.org/ HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Accept: */*
Accept-Language: en
User-Agent: HTTPie/1.0.2
"""
    expected = """GET https://httpbin.org/ HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: en
Connection: keep-alive
User-Agent: HTTPie/1.0.2
"""
    formatter = HeadersFormatter()
    formatted = formatter.format_headers(raw_headers)
    assert formatted == expected


# Generated at 2022-06-21 14:07:44.705714
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(**{
        'format_options': {'headers': {'sort': True}}
    })


# Generated at 2022-06-21 14:07:54.719882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    header_string = \
'''GET https://docs.python.org/3/ HTTP/1.1
Host: docs.python.org
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive
Cookie: csrftoken=0; sessionid=1

'''
    real_result = '''GET https://docs.python.org/3/ HTTP/1.1
Host: docs.python.org
Accept: */*
Accept-Encoding: gzip, deflate, compress
Cookie: csrftoken=0; sessionid=1
Connection: keep-alive
User-Agent: HTTPie/0.9.9

'''

# Generated at 2022-06-21 14:08:04.233501
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers_in = textwrap.dedent("""\
        HTTP/1.1 200 OK
        Cache-Control: public, max-age=31536000

        Content-Type: text/html; charset=UTF-8
        Content-Encoding: UTF-8
        Content-Length: 24

        Date: Mon, 26 May 2014 20:32:46 GMT
        Etag: "a"
        Server: Apache
        Vary: Cookie
    """)


# Generated at 2022-06-21 14:08:10.882035
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__.__name__ == '__init__'
    assert HeadersFormatter.__init__.__doc__ == '\n    Sorts headers by name while retaining relative\n    order of multiple headers with the same name.\n\n    '
    assert HeadersFormatter.__init__.__annotations__ == {'self': HeadersFormatter, '**kwargs': dict}


# Generated at 2022-06-21 14:08:20.695877
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test case for method HeadersFormatter.format_headers()
    """

    # Test case 1
    formatter = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Server: nginx
Content-Type: application/json; charset=utf-8
Content-Length: 100
Date: Fri, 13 Jul 2018 09:01:56 GMT
Connection: keep-alive
Vary: Accept-Encoding'''
    formatter.format_headers(headers)

# Generated at 2022-06-21 14:08:29.720708
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-21 14:08:40.480538
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Prepare data
    headers = "Host: localhost:8080\r\n" \
              "User-Agent: HTTPie/0.9.9\r\n" \
              "Accept-Encoding: gzip, deflate\r\n" \
              "Accept: */*\r\n" \
              "Connection: keep-alive\r\n" \
              "Content-Length: 7\r\n" \
              "Content-Type: application/x-www-form-urlencoded\r\n" \
              "X-Custom-Header: 42\r\n"

    # Create test object
    testObj = HeadersFormatter()

    # Run test
    test_result = testObj.format_headers(headers)

    # Compare results