

# Generated at 2022-06-21 14:03:06.417745
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers': {'sort': True}})
    assert HeadersFormatter(format_options={'headers': {'sort': False}})


# Generated at 2022-06-21 14:03:13.671225
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    
    # Test where headers are already sorted

# Generated at 2022-06-21 14:03:17.899308
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert(HeadersFormatter(format_options={'headers':{'sort':True}}) == HeadersFormatter)
    assert(HeadersFormatter(format_options={'headers':{'sort':False}}) is None)


# Generated at 2022-06-21 14:03:27.908417
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	headersFormatter = HeadersFormatter({'headers': {'sort': False}})

	if headersFormatter.format_options!= {'headers': {'sort': False}}:
		raise AssertionError("Expected {'headers': {'sort': False}}")

	if headersFormatter.enabled!= False:
		raise AssertionError("Expected False")

	headersFormatter2 = HeadersFormatter({'headers': {'sort': True}})
	if headersFormatter2.format_options!= {'headers': {'sort': True}}:
		raise AssertionError("Expected {'headers': {'sort': True}}")

	if headersFormatter2.enabled!= True:
		raise AssertionError("Expected True")


# Generated at 2022-06-21 14:03:30.803101
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Initialize the HeadersFormatter class
    header_formatter = HeadersFormatter(
        format_options={
            'headers': {
                'sort': True,
            },
        },
    )
    # Test the state of the class
    assert header_formatter.enabled

# Generated at 2022-06-21 14:03:37.382297
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test data
    headers = ["HTTP/1.0 200 OK",
        "Content-Type: application/json",
        "X-Foo: Bar",
        "X-Bar: foo",
        "Cache-Control: private",
        "Date: Tue, 14 Nov 2017 13:38:19 GMT",
        "Content-Length: 18",
        "",
        "{\"key\": \"value\"}"]

    sut = HeadersFormatter()
    result = sut.format_headers('\r\n'.join(headers))
    # Test result
    assert not result == '\r\n'.join(headers)
    assert result == '\r\n'.join(headers[:1] + sorted(headers[1:], key=lambda h: h.split(':')[0]))
    # Test operations after invoking format_headers

# Generated at 2022-06-21 14:03:44.501440
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    assert hf.format_headers('GET / HTTP/1.1\r\n'
                             'C: bar\r\n'
                             'A: foo\r\n'
                             'C: baz') ==\
        'GET / HTTP/1.1\r\n'\
        'A: foo\r\n'\
        'C: bar\r\n'\
        'C: baz'


# Generated at 2022-06-21 14:03:46.045800
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, HeadersFormatter)


# Generated at 2022-06-21 14:03:55.839566
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    raw_headers = 'HTTP/1.0 200 OK\r\nfirst: a\r\nsecond: b\r\nfirst: c\r\n'
    sorted_headers = 'HTTP/1.0 200 OK\r\nfirst: a\r\nfirst: c\r\nsecond: b\r\n'
    assert headers_formatter.format_headers(raw_headers) == sorted_headers



# class JsonLinesFormatter(KeyValueFormatter):
#
#     # def format_headers(self, headers):
#     #
#     #     # Sort headers while retaining relative order of multiple headers with the same name.
#     #
#     #     lines = headers.splitlines()
#     #     headers = sorted(lines[1:], key=

# Generated at 2022-06-21 14:03:57.799616
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class HeadersFormatterTest(HeadersFormatter):
        pass
    assert HeadersFormatterTest().enabled



# Generated at 2022-06-21 14:04:13.618317
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    assert HeadersFormatter.format_headers(None) == ''
    assert HeadersFormatter.format_headers('')  == ''

    # Example 1
    headers = '''\
Foo: 123
BAR: abc
Content-Length: 0
BAR: 123
Foo: abc'''

    expected = '''\
Foo: 123
BAR: abc
Content-Length: 0
BAR: 123
Foo: abc'''

    assert HeadersFormatter.format_headers(headers) == expected

    # Example 2
    headers = '''\
Accept: text/html
Accept-Encoding: identity
Connection: close
Accept-Language: en-GB
Content-Length: 0
'''


# Generated at 2022-06-21 14:04:16.550489
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options=None) is not None


# Test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:04:18.301935
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fm = HeadersFormatter()
    assert fm.enabled == False

# Generated at 2022-06-21 14:04:21.558528
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        a = HeadersFormatter(**{"headers":{"sort":True}})
    except:
        print("Error initializing class HeadersFormatter")
        assert False
    assert True


# Generated at 2022-06-21 14:04:30.826503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = "GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/0.9.9"
    expected_headers = "GET / HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/0.9.9"
    assert hf.format_headers(headers) == expected_headers

# Class HeadersFormatterPlugin

# Generated at 2022-06-21 14:04:35.942519
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    h1 = 'A: a\r\nB: b\r\nC: c\r\nB: b2\r\n'

    h2 = HeadersFormatter().format_headers(h1)

    assert h2 == 'A: a\r\nB: b\r\nB: b2\r\nC: c\r\n'

# Generated at 2022-06-21 14:04:36.979564
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter != None


# Generated at 2022-06-21 14:04:41.138288
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options.keys() == ['headers']
    assert hf.format_options['headers'].keys() == ['sort']
    assert hf.format_options['headers']['sort'] == True
    assert hf.enabled == True


# Generated at 2022-06-21 14:04:42.044907
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-21 14:04:49.264469
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersStr= """\
HTTP/1.1 200 OK
Date: Sun, 25 Sep 2016 01:46:56 GMT
Server: Apache/2.2.14 (Ubuntu)
X-Powered-By: PHP/5.3.2-1ubuntu4.18
Expect: 100-continue
X-Mod-Pagespeed: 1.9.32.3-4023
Connection: Keep-Alive
Transfer-Encoding: chunked
Content-Type: text/html
"""


# Generated at 2022-06-21 14:04:55.166886
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(headers={"sort": True})
    assert headersFormatter.format_options['headers']['sort']

# Unit tests for method format_headers

# Generated at 2022-06-21 14:04:56.008978
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter()
    assert head.enabled is False

# Generated at 2022-06-21 14:05:02.306968
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    expected = \
"""POST / HTTP/1.1
Content-Type: application/json
Accept: application/json; indent=4
Transfer-Encoding: chunked
Host: httpbin.org

{
  "a": "b",
  "c": "d"
}"""
    formatter = HeadersFormatter()
    assert formatter.format_headers(expected) == expected
    formatter.dispose()

# Generated at 2022-06-21 14:05:14.322823
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print (HeadersFormatter.format_headers.__doc__)


# Generated at 2022-06-21 14:05:22.429839
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test that the format_headers method sorts headers by name
    """
    headersFormatter = HeadersFormatter()

# Generated at 2022-06-21 14:05:34.246176
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = 'GET / HTTP/1.1\r\nRequest-line: 1\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Type: text/html\r\nContent-Type: text/plain\r\nContent-Type: text/html\r\nContent-Type: text/plain\r\nDNT: 1\r\nContent-Type: text/html\r\nContent-Type: text/x-c\r\nUser-Agent: curl/7.69.1\r\nHost: 127.0.0.1:8080\r\nAccept: *'

# Generated at 2022-06-21 14:05:43.508618
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Date: Mon, 20 May 2019 20:17:39 GMT
Server: WSGIServer/0.2 CPython/3.5.2
Vary: Accept, Cookie
X-Frame-Options: SAMEORIGIN
'''
    assert(hf.format_headers(headers) == headers)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Date: Mon, 20 May 2019 20:17:39 GMT
Server: WSGIServer/0.2 CPython/3.5.2
Vary: Accept
X-Frame-Options: SAMEORIGIN
Vary: Cookie
'''

# Generated at 2022-06-21 14:05:47.704555
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # create session object
    sess = Request()
    # create HeadersFormatter object
    t = HeadersFormatter(options=Options(), format_options=Options())
    # test assertion
    assert isinstance(t, HeadersFormatter)

# Generated at 2022-06-21 14:05:49.054850
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled is False


# Generated at 2022-06-21 14:06:01.175305
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nSet-Cookie: foo=bar; HttpOnly; Path=/\r\nSet-Cookie: session=38afes7a8\r\nX-Foo: Bar\r\nContent-Length: 13\r\n\r\n'
    formatted_headers = HeadersFormatter(format_options={'headers': {'sort': False}}).format_headers(headers)
    assert formatted_headers == headers
    formatted_headers = HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers)
    assert formatted_headers != headers

# Generated at 2022-06-21 14:06:13.180880
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """Unit test for method format_headers of class HeadersFormatter"""
    headers_formatter = HeadersFormatter()
    headers = """\
GET / HTTP/1.1\r
Content-Type: application/json\r
Accept: application/json\r
Connection: close\r
Accept-Encoding: identity\r
"""
    assert headers_formatter.format_headers(headers) == """\
GET / HTTP/1.1\r
Accept: application/json\r
Accept-Encoding: identity\r
Connection: close\r
Content-Type: application/json\r
"""

# Generated at 2022-06-21 14:06:18.233289
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import sys
    import os
    import json
    import pytest
    import inspect
    # reload the module
    import importlib
    importlib.reload(sys.modules['plugins._headers_formatter'])
    from plugins._headers_formatter import HeadersFormatter

    # captured variables
    # call our unit
    hf = HeadersFormatter()
    # assert return values and captured arguments
    # this test is not so good since it only check the content of class
    # adding more test here
    assert hf.format_options == {'headers': {'sort': False}, 'colors': False}


# Generated at 2022-06-21 14:06:29.454922
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''GET / HTTP/1.1
Cache-Control: max-age=0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36
Accept-Encoding: gzip, deflate, sdch
Accept-Language: en-US,en;q=0.8
Cookie: _ga=GA1.2.1722569238.1463012376
'''
    hf.format_headers(headers)

# Generated at 2022-06-21 14:06:40.181328
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:06:50.249278
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter = HeadersFormatter()
    headers = '''GET https://www.example.com/ HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.0.3
Host: www.example.com
'''
    assert header_formatter.format_headers(headers) == '''GET https://www.example.com/ HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: www.example.com
User-Agent: HTTPie/1.0.3
'''


# Generated at 2022-06-21 14:06:57.468225
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create a headers string
    headers = 'HTTP/1.1 200 OK\r\nLocation:https://example/\r\nContent-Type:application/json\r\nContent-Length:45\r\n'
    # Create a HeadersFormatter
    formatter = HeadersFormatter()
    # Check if the headers are properly sorted
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-Length:45\r\nContent-Type:application/json\r\nLocation:https://example/\r\n'

# Generated at 2022-06-21 14:07:00.090742
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter(format_options = {
        'headers': {
            'sort': True
        }
    })
    assert instance.format_options['headers']['sort'] == True
    assert instance.enabled == True


# Generated at 2022-06-21 14:07:03.791628
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled


# Generated at 2022-06-21 14:07:04.582939
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter != None


# Generated at 2022-06-21 14:07:07.709764
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert(HeadersFormatter(format_options={"headers": {"sort": False}}).enabled == False)
    assert(HeadersFormatter(format_options={"headers": {"sort": True}}).enabled == True)


# Generated at 2022-06-21 14:07:24.118909
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
Connection: keep-alive
Host: httpbin.org
Accept-Encoding: identity
Accept: */*
User-Agent: HTTPie/0.9.9
'''

    f = '''\
Connection: keep-alive
Accept: */*
Accept-Encoding: identity
Host: httpbin.org
User-Agent: HTTPie/0.9.9
'''

    assert HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(h) == f

# Generated at 2022-06-21 14:07:25.671403
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter()
    assert x.format_options['headers']['sort'] == False


# Generated at 2022-06-21 14:07:29.183303
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h_fmt = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert h_fmt.enabled == True



# Generated at 2022-06-21 14:07:34.816775
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {
        'headers': {'sort': True},
        'body': {'formatted': False},
        'colors': {'header': 'blue', 'body': 'yellow'}
    }
    headers_formatter = HeadersFormatter(format_options=format_options)
    assert headers_formatter.enabled == True



# Generated at 2022-06-21 14:07:40.429050
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        'headers': {'sort': True}
    })
    assert formatter.format_headers('Content-Length: 100\r\n'
                                    'Content-Type: application/json\r\n'
                                    'Cookie: a=b; c=d\r\n') == \
        'Content-Length: 100\r\n' \
        'Content-Type: application/json\r\n' \
        'Cookie: a=b; c=d'



# Generated at 2022-06-21 14:07:43.181531
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:07:53.704441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nHost: example.com\r\n' \
        'Content-Type: application/json\r\nAccept-Encoding: gzip, deflate\r\n' \
        'Accept: */*\r\nAccept-Language: en-US,en;q=0.9,nb;q=0.8\r\n'

# Generated at 2022-06-21 14:07:56.461781
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    new_instance = HeadersFormatter()
    assert new_instance != None


# Generated at 2022-06-21 14:08:05.299077
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.9
X-Amzn-Trace-Id: Root=1-5e5d8043-1b6e8aa6ec3f979d4a2b2fd8
"""

# Generated at 2022-06-21 14:08:08.662274
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    u = HeadersFormatter(format_options=({'headers': {'sort': True}},))
    assert u.enabled == True


# Generated at 2022-06-21 14:08:39.713216
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = io.StringIO('''\
HTTP/1.1 200 OK
abc: 123
abc: 456
def: 789
def: 000
''')
    headers = hf.format_headers(headers.getvalue())
    assert headers == '''\
HTTP/1.1 200 OK
abc: 123
abc: 456
def: 789
def: 000
'''


# Generated at 2022-06-21 14:08:41.264231
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled


# Generated at 2022-06-21 14:08:43.259865
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_headers('asd') == 'asd'


test_HeadersFormatter_format_headers()

# Generated at 2022-06-21 14:08:51.073570
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('Host: example.com\r\nAccep: */*\r\n') == 'Host: example.com\r\nAccep: */*\r\n'
    assert formatter.format_headers('Host: example.com\r\nAccep: */*\r\n') != 'Accep: */*\r\nHost: example.com\r\n'

# Generated at 2022-06-21 14:08:54.041819
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter is not None

# Unit test to check whether the headers are sorted or not

# Generated at 2022-06-21 14:09:05.230090
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Length: 57\r\n' \
              'Content-Type: text/html; charset=utf-8\r\n' \
              'Server: Werkzeug/0.9.6 Python/2.7.3\r\n' \
              'Date: Sun, 03 Mar 2013 11:58:54 GMT'

# Generated at 2022-06-21 14:09:07.579427
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	test_HeadersFormatter_instance = HeadersFormatter()
	assert test_HeadersFormatter_instance


# Generated at 2022-06-21 14:09:14.885109
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import CorePlugin
    from httpie.plugins import make_formatter
    from httpie.formatters import JSONFormatter
    from httpie.formatters import PrettyJsonFormatter
    
    # Check if HeadersFormatter is instance of FormatterPlugin
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, FormatterPlugin)
    
    # Check if HeadersFormatter is instance of CorePlugin
    assert isinstance(headers_formatter, CorePlugin)
    assert not hasattr(headers_formatter, 'load_file')

    # Check if format_headers is a method of HeadersFormatter
    assert 'format_headers' in dir(headers_formatter)

    # Unit test for format_options in constructor of class HeadersFormatter


# Generated at 2022-06-21 14:09:21.539838
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    test_string = f.format_headers(headers)
    assert test_string ==  'HTTP/1.1 200 OK\r\nContent-Length: 12\r\nContent-Type: application/json\r\nETag: "12345"'

# Test string for method format_headers of class HeadersFormatter
headers = '''HTTP/1.1 200 OK
ETag: "12345"
Content-Type: application/json
Content-Length: 12'''

# ---

# Generated at 2022-06-21 14:09:29.048065
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    FormatterPlugin.parse_options = MagicMock(return_value = {'headers': {'sort': True}})
    formatter = HeadersFormatter()
    formatter.parse_options = MagicMock(return_value = {'headers': {'sort': True}})
    headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Host: example.org',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'User-Agent: HTTPie/0.9.2',
        'Cookie: foo=bar; bar=baz',
        'Referer: http://httpbin.org/',
        '', '',])
    actual = formatter.format_headers(headers)

# Generated at 2022-06-21 14:10:32.693020
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header = HeadersFormatter()

# Generated at 2022-06-21 14:10:33.850137
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__name__ == 'HeadersFormatter'


# Generated at 2022-06-21 14:10:42.798157
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = ("HTTP/1.1 200 OK\r\n"
               "Host: example.org\r\n"
               "Connection: close\r\n"
               "Accept-Encoding: gzip, deflate\r\n"
               "Accept: */*\r\n"
               "User-Agent: HTTPie/0.9.9\r\n"
               "Accept-Language: en-US,en;q=0.5\r\n"
               "Content-Length: 2\r\n")

# Generated at 2022-06-21 14:10:50.768800
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Unit test for method format_headers of class HeadersFormatter
    plugin = HeadersFormatter(headers={'sort': True})
    assert 'User-Agent' in plugin.format_headers('""""\nUser-Agent: httpie\nContent-Type: text/html\nX-Forwarded-For: 127.0.0.1\nConnection: keep-alive')
    assert 'X-Forwarded-For' in plugin.format_headers('""""\nUser-Agent: httpie\nContent-Type: text/html\nX-Forwarded-For: 127.0.0.1\nConnection: keep-alive')

# Generated at 2022-06-21 14:10:51.954186
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled


# Generated at 2022-06-21 14:10:53.959243
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter({'headers': {'sort': False}}).enabled == False
    assert HeadersFormatter({'headers': {'sort': True}}).enabled == True


# Generated at 2022-06-21 14:10:54.993192
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf != None


# Generated at 2022-06-21 14:10:58.350314
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # case 1: headers doesn't have sort
    obj = HeadersFormatter(headers={'sort': False})
    assert obj.enabled == False
    # case 2: headers has sort
    obj = HeadersFormatter(headers={'sort': True})
    assert obj.enabled == True


# Generated at 2022-06-21 14:11:05.883448
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input_headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Date: Wed, 30 Sep 2015 11:06:25 GMT
Connection: keep-alive
Transfer-Encoding: chunked
Server: nginx/1.4.6 (Ubuntu)
Cache-Control: no-cache
Access-Control-Allow-Origin: *
Vary: Accept-Encoding
'''
    output_headers = formatter.format_headers(input_headers)
    assert output_headers == input_headers

# Generated at 2022-06-21 14:11:15.341910
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'Accept: application/json\r\n' \
              'Accept: application/xml\r\n' \
              'Connection: keep-alive\r\n' \
              'Http-version: HTTP/1.1\r\n' \
              'Content-Length: 550\r\n' \
              'Content-Type: application/json\r\n'
    expected = 'HTTP/1.1 200 OK\r\n' \
               'Accept: application/json\r\n' \
               'Accept: application/xml\r\n' \
               'Content-Length: 550\r\n' \
               'Content-Type: application/json\r\n' \
               'Connection: keep-alive\r\n' \
               'Http-version: HTTP/1.1\r\n'