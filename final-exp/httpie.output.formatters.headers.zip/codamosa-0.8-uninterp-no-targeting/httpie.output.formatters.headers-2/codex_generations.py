

# Generated at 2022-06-21 14:03:07.937017
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = """
        foo: 1
        bar: 2
        spam: 3
        foo: bar
    """
    expected = """
        foo: 1
        foo: bar
        bar: 2
        spam: 3
    """
    assert headers_formatter.format_headers(headers) == expected



if __name__ == "__main__":
    test_HeadersFormatter_format_headers()
    

## [parsers.py](https://github.com/jakubroztocil/httpie/blob/master/httpie/compat.py)


# Generated at 2022-06-21 14:03:09.339498
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter()

    assert isinstance(instance, HeadersFormatter)

# Generated at 2022-06-21 14:03:15.808441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines = [
        'DELETE / HTTP/1.1',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: en-US,en;q=0.5',
        'Cache-Control: max-age=0',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.9',
        'X-test-header-1: test value 1',
        'X-test-header-2: test value 2',
        'Host: localhost:',
        'DNT: 1',
        'Upgrade-Insecure-Requests: 1'
    ]

# Generated at 2022-06-21 14:03:17.447941
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter


# Generated at 2022-06-21 14:03:19.387946
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter.__init__(self, **kwargs)


# Generated at 2022-06-21 14:03:23.465224
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class_ = HeadersFormatter
    h1 = class_({'headers': {'sort': False}})
    assert not h1.enabled
    h2 = class_({'headers': {'sort': True}})
    assert h2.enabled


# Generated at 2022-06-21 14:03:32.292489
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:03:37.132159
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatterPlugin = HeadersFormatter()
    expected_args = {}
    expected_kwargs = {'headers': {'sort': True}}
    actual_args = formatterPlugin.args
    actual_kwargs = formatterPlugin.format_options
    assert (expected_args == actual_args) and (expected_kwargs == actual_kwargs)

# Generated at 2022-06-21 14:03:45.380452
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers("""\
Connection: keep-alive
Content-Length: 20
Content-Type: application/json
Host: localhost:8080
User-Agent: HTTPie
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Type: application/json
""") == """\
Connection: keep-alive
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Type: application/json
Content-Length: 20
Host: localhost:8080
User-Agent: HTTPie
"""

# Generated at 2022-06-21 14:03:46.658226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(session=None)
    

# Generated at 2022-06-21 14:03:58.215800
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Input: arbitrary headers
    # Output: headers sorted on name, ignoring case
    #         multiple headers with same name are
    #         retained in relative order

    headers = """\
Host: httpbin.org
Content-Length: 973
Accept-Encoding: identity
Content-Type: application/json
Connection: keep-alive
Accept: */*
Content-Length: 973
User-Agent: HTTPie/1.0.3
Accept-Encoding: identity
"""

# Generated at 2022-06-21 14:03:59.377546
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert type(HeadersFormatter()) == HeadersFormatter


# Generated at 2022-06-21 14:04:03.171497
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter({'headers': {'format': 'pretty', 'sort': True}})
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:04:11.237257
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    h = """Host: www.google.com
X-Delimiters: foo:bar
Content-Length: 9
Content-Type: application/x-www-form-urlencoded; charset=UTF-8

"""
    assert hf.format_headers(h) == """Host: www.google.com
X-Delimiters: foo:bar
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Content-Length: 9

"""



# Generated at 2022-06-21 14:04:22.069722
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Sort headers.
    """
    formatter = HeadersFormatter({'headers': {'sort': True}})

# Generated at 2022-06-21 14:04:31.894183
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	formatter = HeadersFormatter()
	headers = b'Content-Type: text/plain; charset=utf-8\r\n' \
          b'Content-Disposition: inline\r\n' \
          b'Content-Length: 67\r\n' \
          b'Content-Transfer-Encoding: 8bit\r\n' \
          b'Content-Security-Policy: style-src \'unsafe-inline\''

# Generated at 2022-06-21 14:04:34.867614
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test normal constructor
    HeadersFormatter(
        format_options = {
            "headers": {
                "sort": True
            },
            "pretty": False,
            "colors": False
        },
        config = None
    )


# Generated at 2022-06-21 14:04:43.664116
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    http_headers = """
    HTTP/1.1 200 OK
    Content-Type: application/json
    X-HTTP-Header-1: Value 1
    X-HTTP-Header-2: Value 2
    X-HTTP-Header-1: Value 3
    X-HTTP-Header-3: Value 4
    """
    assert formatter.format_headers(http_headers) == """
    HTTP/1.1 200 OK
    Content-Type: application/json
    X-HTTP-Header-1: Value 1
    X-HTTP-Header-1: Value 3
    X-HTTP-Header-2: Value 2
    X-HTTP-Header-3: Value 4
    """

# Generated at 2022-06-21 14:04:52.120495
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """GET / HTTP/1.1
Host: dummy-endpoint.com
Content-Type: application/json
Connection: keep-alive"""
    expectedHeaders = """GET / HTTP/1.1
Connection: keep-alive
Content-Type: application/json
Host: dummy-endpoint.com"""
    assert formatter.format_headers(headers) == expectedHeaders
    assert formatter.format_headers(headers) != headers

# Generated at 2022-06-21 14:05:03.452549
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test for sorting headers by name
    headers = '''
GET http://httpbin.org/get
Accept: application/json
Content-Type: application/json
Connection: keep-alive
Host: httpbin.org
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.6
'''
    r = ('GET http://httpbin.org/get\r\n'
         'Accept: application/json\r\n'
         'Connection: keep-alive\r\n'
         'Content-Type: application/json\r\n'
         'Host: httpbin.org\r\n'
         'User-Agent: HTTPie/0.9.6\r\n'
         'Accept-Encoding: gzip, deflate\r\n')
    assert HeadersFormatter

# Generated at 2022-06-21 14:05:18.890953
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\n'\
              'Date: Thu, 28 Sep 2017 17:08:52 GMT\r\n'\
              'X-Powered-By: Flask\r\n'\
              'Content-Length: 24\r\n'\
              'Server: Werkzeug/0.12.2 Python/3.5.3\r\n'\
              'Content-Type: text/html; charset=utf-8\r\n'
    formatted_headers = h.format_headers(headers)

# Generated at 2022-06-21 14:05:19.859572
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None


# Generated at 2022-06-21 14:05:31.871676
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Cache-Control: public, max-age=60, s-maxage=60
Last-Modified: Thu, 04 Jan 2018 01:27:21 GMT
Vary: Accept-Encoding
X-Ratelimit-Limit: 1200
X-Ratelimit-Remaining: 1198
Date: Thu, 04 Jan 2018 01:26:21 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 4856
Etag: W/"bc1-QkLbWZkx1xI5M5oJaC5ywLw"
Connection: keep-alive'''

# Generated at 2022-06-21 14:05:41.428049
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = """\
Host: example.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.2
"""
    expected = """\
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.2
"""
    assert h.format_headers(headers) == expected


# Generated at 2022-06-21 14:05:48.692857
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test:
    #   1. HeadersFormatter()
    #   2. returns the expected value
    #   3. no exception is thrown
    h = HeadersFormatter(format_options=dict())
    assert h.format_options == dict()
    assert h.enabled == False
    h = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    assert h.format_options == dict(headers=dict(sort=True))
    assert h.enabled == True
    return


# Generated at 2022-06-21 14:06:00.739320
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    sorted_headers = (
        'Connection: keep-alive\r\n'
        'Date: Wed, 26 Apr 2017 17:27:47 GMT\r\n'
        'Server: nginx/1.12.0\r\n'
        'Strict-Transport-Security: max-age=315360000\r\n'
        'Transfer-Encoding: chunked\r\n'
        '\r\n'
    )

# Generated at 2022-06-21 14:06:01.778619
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__

# Generated at 2022-06-21 14:06:07.810318
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
GET / HTTP/1.1
Host: httpbin.org
Accept: application/json
Connection: keep-alive
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.5
"""
    assert formatter.format_headers(headers) == headers


# integration test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:06:09.759552
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert formatter.enabled is True


# Generated at 2022-06-21 14:06:11.311845
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:06:16.930429
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert headers_formatter.enabled


# Generated at 2022-06-21 14:06:28.384289
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:06:30.849493
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False
    

# Generated at 2022-06-21 14:06:33.061085
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	headersFormatter = HeadersFormatter(format_options = {})
	assert headersFormatter.enabled == False


# Generated at 2022-06-21 14:06:36.147389
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert fmt.format_options['headers']['sort']
    assert fmt.enabled


# Generated at 2022-06-21 14:06:37.835636
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-21 14:06:39.073826
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    foo = HeadersFormatter()
    assert foo.enabled == foo.format_options['headers']['sort']


# Generated at 2022-06-21 14:06:41.775468
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert hf.enabled
    # The instance variable format_options is not defined implicitly,
    # and must be initialized.
    # However, the class variable format_options is not defined implicitly
    # and doesn't need to be initialized.
    assert hf.format_options['headers']['sort']


# Generated at 2022-06-21 14:06:43.836301
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hFormatter = HeadersFormatter()
    assert hFormatter.format_options['headers']['sort'] == True

# Generated at 2022-06-21 14:06:55.506587
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:07:02.753965
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()

# Generated at 2022-06-21 14:07:12.122088
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    This test checks whether the HeadersFormatter
    class is defined correctly
    """

    # Test 1: is HeadersFormatter declared correctly
    assert HeadersFormatter.__name__ == 'HeadersFormatter'
    assert type(HeadersFormatter).__name__ == 'type'
    assert isinstance(HeadersFormatter, FormatterPlugin) is True
    assert issubclass(HeadersFormatter, FormatterPlugin) is True

    # Test 2: is __init__ defined correctly
    assert HeadersFormatter.__init__.__name__ == '__init__'
    assert callable(HeadersFormatter.__init__) is True
    assert HeadersFormatter.__init__.__doc__ is None

    # Test 3: is format_headers defined correctly
    assert HeadersFormatter.format_headers.__name__

# Generated at 2022-06-21 14:07:23.245487
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    from httpie.plugins.builtin import HeadersFormatter
    from unittest.mock import patch

    hf = HeadersFormatter()

    # Test case where order of headers is preserved
    with patch.object(hf, '_is_cli_mode', return_value=False):
        headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

        hf.format_headers(headers)
        assert headers == hf.format_headers(headers)


# Generated at 2022-06-21 14:07:27.075458
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers("Age: 25\nAccept: application/json\nAccept-Language: en-US,en;q=0.9") == "Age: 25\nAccept: application/json\nAccept-Language: en-US,en;q=0.9"

# Generated at 2022-06-21 14:07:27.754514
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-21 14:07:31.493611
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.format_options == {
        'headers': {
            'sort': False
        },
        'pretty': False
    }
    assert not f.enabled


# Generated at 2022-06-21 14:07:34.905968
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Code coverage testing for HeadersFormatter class
    # Create an object of HeadersFormatter class
    f = HeadersFormatter()
    assert type(f.enabled) == bool
    
    

# Generated at 2022-06-21 14:07:41.969976
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = ('ACCEPT: application/json\r\n'
              'CONTENT-TYPE: application/json\r\n'
              'ACCEPT-LANGUAGE: en\r\n'
              'CONTENT-LENGTH: 0\r\n')
    assert headers_formatter.format_headers(headers) == "HTTP/1.1 200 OK\r\nACCEPT: application/json\r\nACCEPT-LANGUAGE: en\r\nCONTENT-LENGTH: 0\r\nCONTENT-TYPE: application/json\r\n"



# Generated at 2022-06-21 14:07:53.013056
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    class _Dummy:  # Dummy class for testing constructor
        headers = {'a': 'b'}

    class _Dummy2:  # Dummy class for testing constructor
        headers = {'a': ['b', 'c']}  # One header with two values

    class _Dummy3:  # Dummy class for testing constructor
        headers = {'a': 'b', 'c': 'd'}  # Two headers

    class _Dummy4:  # Dummy class for testing constructor
        headers = {'a': ['b', 'c'], 'd': 'e'}  # One header with two values and another header

    assert _Dummy().headers == {'a': 'b'}
    assert _Dummy2().headers == {'a': ['b', 'c']}

# Generated at 2022-06-21 14:07:54.964006
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-21 14:08:16.343857
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    text = """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 0
Content-Type: application/json
Cookie: cookie1=abc; cookie2=123
Host: www.example.com
Postman-Token: 387a4ff5-5f5a-4f01-8d27-b1c0f5a7e2a2
User-Agent: HTTPie/0.9.9
X-Forwarded-Host: www.example.com
"""

# Generated at 2022-06-21 14:08:24.589255
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:08:29.226208
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    in_headers = """\
POST /post HTTP/1.1
User-Agent: httpie/1.0.2
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Length: 11
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: httpbin.org
"""
    out_headers = """\
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Length: 11
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Host: httpbin.org
User-Agent: httpie/1.0.2
"""
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(in_headers)

# Generated at 2022-06-21 14:08:37.595859
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
HTTP/1.1 200 OK
Content-length: 0
Connection: Closed
Content-type: text/plain; charset=utf-8
Content-length: 10
Content-type: text/plain; charset=utf-8
"""
    expected = """
HTTP/1.1 200 OK
Connection: Closed
Content-type: text/plain; charset=utf-8
Content-type: text/plain; charset=utf-8
Content-length: 0
Content-length: 10
"""

    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-21 14:08:39.205350
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter


# Generated at 2022-06-21 14:08:41.429289
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # myheaders = HeadersFormatter()
    myheaders = HeadersFormatter("headers")
    assert isinstance(myheaders, HeadersFormatter)


# Generated at 2022-06-21 14:08:42.544449
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().enabled == None


# Generated at 2022-06-21 14:08:55.126780
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    unordered_headers = '''HTTP/1.1 200 OK
Date: Thu, 11 Jan 2018 16:46:36 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 24
Connection: keep-alive
X-Powered-By: Express
Etag: W/"18-f6TZdWzfNgvMlfGXHpOoqcWWhEg"
Vary: Accept-Encoding

'''

# Generated at 2022-06-21 14:09:05.689409
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: text/plain',
        'Content-Length: 2',
        'Accept: text/html',
        'Accept: image/png',
        'Content-Type: text/css'
    ])
    expected = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Accept: text/html',
        'Accept: image/png',
        'Content-Type: text/plain',
        'Content-Type: text/css',
        'Content-Length: 2'
    ])
    assert formatter.format_headers(headers) == expected


# Generated at 2022-06-21 14:09:07.662230
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # TODO: Use a Mock object
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-21 14:09:33.542032
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter() is not None


# Generated at 2022-06-21 14:09:40.666368
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headerstring = "HTTP/1.1 204 No Content\r\nDate: Wed, 22 Apr 2020 20:28:54 GMT\r\nServer: nginx\r\nContent-Length: 0\r\nConnection: keep-alive\r\n\r\n"
    headers = HeadersFormatter()
    result = headers.format_headers(headerstring)
    assert "Connection: keep-alive" in result
    assert "Content-Length: 0" in result
    assert "Date: Wed, 22 Apr 2020 20:28:54 GMT" in result
    assert "HTTP/1.1 204 No Content" in result
    assert "Server: nginx" in result


# Generated at 2022-06-21 14:09:44.752083
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Mock for class HeadersFormatter
    class MockHeadersFormatter():
        def __init__(self):
            self.format_options = {
                'headers': {
                    'sort': False
                }
            }

    mock_headers_formatter = MockHeadersFormatter()
    assert mock_headers_formatter.enabled is False
    

# Generated at 2022-06-21 14:09:50.725374
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''\r
HTTP/1.1 200 OK\r
X-Foo: 1\r
X-Bar: 2\r
X-Bar: 3\r
X-Foo: 4\r
X-Bar: 5\r
'''
    expected = '''\r
HTTP/1.1 200 OK\r
X-Bar: 2\r
X-Bar: 3\r
X-Bar: 5\r
X-Foo: 1\r
X-Foo: 4\r
'''
    actual = hf.format_headers(headers)
    assert actual == expected



# Generated at 2022-06-21 14:10:00.710920
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    input = """Date: Wed, 24 Aug 2016 22:54:33 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 4
Server: Werkzeug/0.11.15 Python/3.6.0
Content-Encoding: gzip
Cache-Control: no-cache, no-store
Etag: W/"4-6bbfce6c8efcc64c"
X-Frame-Options: SAMEORIGIN
Content-Language: en-US
Pragma: no-cache
Expires: 0

Foo""".strip()

# Generated at 2022-06-21 14:10:09.706667
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "headers\r\ncookie: a=b; c=d\r\nX-Forwarded-Proto: https\r\naccept-language: en-us\r\ncontent-type: application/json"
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    formatter.format_headers(headers=headers) == "headers\r\naccept-language: en-us\r\ncontent-type: application/json\r\ncookie: a=b; c=d\r\nX-Forwarded-Proto: https"
#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#tested, functions as expected

# Generated at 2022-06-21 14:10:10.703134
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-21 14:10:19.662069
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.12.2
Date: Wed, 26 Jul 2017 11:39:54 GMT
Content-Type: text/html; charset=utf-8
Connection: keep-alive
X-Powered-By: Flask
X-Processed-Time: 0.00137996673584
Content-Length: 754
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: Content-Type,Authorization
Access-Control-Allow-Methods: GET,PUT,POST,DELETE
'''

# Generated at 2022-06-21 14:10:29.496938
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 3927
X-Content-Type-Options: nosniff
Date: Mon, 05 Oct 2015 14:09:21 GMT

<!DOCTYPE html>
<html>
<head>
  <title>Example Web Page</title>
'''
    headers_y = '''HTTP/1.1 200 OK
Content-Length: 3927
Content-Type: text/html; charset=utf-8
Date: Mon, 05 Oct 2015 14:09:21 GMT
X-Content-Type-Options: nosniff

<!DOCTYPE html>
<html>
<head>
  <title>Example Web Page</title>
'''
    headers

# Generated at 2022-06-21 14:10:30.028395
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-21 14:11:15.779079
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None


# Generated at 2022-06-21 14:11:18.768891
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter()
    assert headersFormatter.format_options['headers']['sort'] == True
    assert headersFormatter.enabled == True


# Generated at 2022-06-21 14:11:20.238024
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert isinstance(formatter, FormatterPlugin)


# Generated at 2022-06-21 14:11:27.611151
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(headers={"sort": True})
    headers = """GET http://example.com/
Accept-Encoding: identity
Dnt: 1
User-Agent: HTTPie/0.9.9

"""
    result = headers_formatter.format_headers(headers)
    assert result == """GET http://example.com/
Accept-Encoding: identity
Dnt: 1
User-Agent: HTTPie/0.9.9

"""

# Generated at 2022-06-21 14:11:30.173112
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.name == 'headers'
    assert HeadersFormatter.defaults == {
        'headers': {'sort': False}
    }


# Generated at 2022-06-21 14:11:33.236123
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options={'headers':{'sort':True}}) is not None
    assert HeadersFormatter(format_options={'headers':{'sort':False}}) is not None


# Generated at 2022-06-21 14:11:35.744745
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(sort_headers=True);

    assert formatter.format_options['headers']['sort'] == True

    assert isinstance(formatter, HeadersFormatter)



# Generated at 2022-06-21 14:11:37.194929
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception):
        headersformatter = HeadersFormatter(**kwargs);

# Generated at 2022-06-21 14:11:41.083787
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Unit test for method format_headers of class HeadersFormatter
    """
    # Given
    formatter = HeadersFormatter()
    headers = """"""
    # When
    result = formatter.format_headers(headers)
    # Then
    expected = """"""
    assert result == expected
    
    



# Generated at 2022-06-21 14:11:43.812071
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.format_options['headers']['sort'] == True

