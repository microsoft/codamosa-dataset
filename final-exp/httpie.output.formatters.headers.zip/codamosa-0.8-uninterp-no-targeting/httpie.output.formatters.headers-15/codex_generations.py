

# Generated at 2022-06-21 14:03:07.676179
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        '''\
POST / HTTP/1.1
Accept: application/json
Content-Length: 54
Content-Type: application/json
User-Agent: HTTPie/0.9.6
Host: 127.0.0.1:5000
'''
    ) == '''\
POST / HTTP/1.1
Accept: application/json
Content-Length: 54
Content-Type: application/json
User-Agent: HTTPie/0.9.6
Host: 127.0.0.1:5000
'''



# Generated at 2022-06-21 14:03:09.367709
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert not formatter.enabled
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:03:10.489486
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-21 14:03:22.326534
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:03:24.528591
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()  # Again, this is not making sense.
    assert(hf.enabled == False)


# Generated at 2022-06-21 14:03:27.775893
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class Dummy():
        pass
    Dummy.format_options = Dummy()
    Dummy.format_options.headers = Dummy()
    Dummy.format_options.headers.sort = True
    HeadersFormatter(Dummy)

# Generated at 2022-06-21 14:03:29.196812
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options={'headers': {'sort': False}})


# Generated at 2022-06-21 14:03:36.198259
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_object = HeadersFormatter(**{'format_options': {'headers': {'sort': True}}})

    test_object_2 = HeadersFormatter(**{'format_options': {'headers': {'sort': False}}})


# Generated at 2022-06-21 14:03:46.788370
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:03:54.816489
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "HTTP/1.1 200 OK\r\nHeader-One: value 1\r\nHeader-Two: value 2\r\nHeader-Two: value 3\r\nHeader-One: value 4\r\nHeader-Two: value 5\r\n"
    assert HeadersFormatter(format_options = {'headers': {'sort': True}}).format_headers(headers) == "HTTP/1.1 200 OK\r\nHeader-One: value 1\r\nHeader-One: value 4\r\nHeader-Two: value 2\r\nHeader-Two: value 3\r\nHeader-Two: value 5\r\n"