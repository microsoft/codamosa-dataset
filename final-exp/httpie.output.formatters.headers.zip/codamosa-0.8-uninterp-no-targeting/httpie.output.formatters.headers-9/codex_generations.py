

# Generated at 2022-06-21 14:03:04.201277
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {'headers': {'sort': True}}
    assert HeadersFormatter(format_options=format_options)


# Generated at 2022-06-21 14:03:11.901066
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        'Content-Length: 348\r\n'
        'Connection: keep-alive\r\n'
        'Server: gunicorn/19.9.0\r\n'
        'Date: Sat, 23 Mar 2019 15:54:29 GMT\r\n'
        '\r\n'
        )

# Generated at 2022-06-21 14:03:15.223612
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    settings = {'headers': {'sort': True}}
    test = HeadersFormatter(format_options=settings)
    assert test.format_options == settings


# Generated at 2022-06-21 14:03:21.654948
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    headers = ('foo: bar\r\n'
               'baz: qux\r\n'
               'baz: quux')
    assert formatter.format_headers(headers) == ('foo: bar\r\n'
                                                 'baz: qux\r\n'
                                                 'baz: quux')



# Generated at 2022-06-21 14:03:29.416725
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
User-Agent: curl/7.54.0
Accept: */*
Host: localhost:4433
Cookie: cookie1=value1
Cookie: cookie2=value2
Cookie: cookie3=value3
Cookie: cookie4=value4
'''
    assert HeadersFormatter().format_headers(headers) == '''\
User-Agent: curl/7.54.0
Cookie: cookie1=value1
Cookie: cookie2=value2
Cookie: cookie3=value3
Cookie: cookie4=value4
Accept: */*
Host: localhost:4433
'''

# Generated at 2022-06-21 14:03:31.175203
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})
    assert formatter.enabled == True


# Generated at 2022-06-21 14:03:42.668635
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Generates header lines with random names and values, shuffles them and
    # reformats them. Then, verifies that the order of header lines is
    # retained while the names are sorted.

    lines = []
    for i in range(30):
        lines.append('{}: {}'.format(
            random_string(10), random_string(10)
        ))
    lines.sort(key=lambda h: h.split(':')[0])
    random.shuffle(lines)
    lines = ['GET / HTTP/1.1'] + lines

    fmt = HeadersFormatter()
    fmt.enabled = True
    fmt.format_options['headers']['sort'] = True
    headers = fmt.format_headers('\r\n'.join(lines))


# Generated at 2022-06-21 14:03:45.696131
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled
    assert 'headers' in formatter.format_options
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:03:48.432991
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(**{'format_options': {'headers': {'sort': True}}})
    assert hf.format_options['headers']['sort'] == True
    assert hf.enabled == True

# Generated at 2022-06-21 14:03:58.216469
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Tests the method format_headers of class HeadersFormatter.

    """
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Accept-Ranges: bytes
Cache-Control: max-age=604800
Content-Type: text/html; charset=UTF-8
Date: Sun, 11 Nov 2018 10:44:22 GMT
Etag: "1541025663"
Expires: Sun, 18 Nov 2018 10:44:22 GMT
Last-Modified: Fri, 09 Aug 2013 23:54:35 GMT
Server: ECS (oxr/8313)
Vary: Accept-Encoding
X-Cache: HIT
Content-Length: 1270
"""