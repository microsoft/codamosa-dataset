

# Generated at 2022-06-21 14:03:07.199133
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    input = '''\
Authorization: Basic YmFyOnNreQ==
user-agent: foo/1.0
accept: application/json
Content-Type: application/json
Accept-Charset: utf-8
content-length: 15
'''
    output = HeadersFormatter().format_headers(input)
    assert output == '''\
Authorization: Basic YmFyOnNreQ==
Accept-Charset: utf-8
Accept: application/json
Content-Type: application/json
content-length: 15
user-agent: foo/1.0
'''

# Generated at 2022-06-21 14:03:11.496823
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter.format_headers('''\
Content-Type: text/plain; charset=utf-8
Content-Length: stats.st_size
X-Foo: Bar
X-Foo: Baz
''') == '''\
Content-Type: text/plain; charset=utf-8
Content-Length: stats.st_size
X-Foo: Bar
X-Foo: Baz
'''



# Generated at 2022-06-21 14:03:17.808987
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter() != HeadersFormatter(**{'headers': {'sort': True}})
    assert HeadersFormatter() == HeadersFormatter(**{'headers': {'sort': False}})
    assert HeadersFormatter(**{'headers': {'sort': True}}) == HeadersFormatter(**{'headers': {'sort': True}})


# Generated at 2022-06-21 14:03:26.011353
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """
    Connection: keep-alive
    Content-Length: 28
    Content-Type: application/x-www-form-urlencoded
    Cookie: name=user
    Host: example.com
    """
    lines = headers.splitlines()
    headers_formatter = HeadersFormatter(
        env=None,
        format_options={
            'headers': {
                'sort': 1
            }
        }
    )
    sorted_headers = headers_formatter.format_headers(headers)
    assert sorted_headers == '\r\n'.join(sorted(lines[1:]))

# Generated at 2022-06-21 14:03:30.902808
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # call HeadersFormatter without arguments to test with defaults
    formatter = HeadersFormatter()
    assert formatter.enabled is False
    # call HeadersFormatter with arguments to test
    formatter = HeadersFormatter(
            format_options={'headers':{'sort': True}},
            humanize_options={'body':{'sort': True}},
            print_options={'style': {}}
    )
    assert formatter.enabled is True

# Generated at 2022-06-21 14:03:34.255824
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    fmt = HeadersFormatter()
    assert not fmt.enabled
    fmt = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert fmt.enabled



# Generated at 2022-06-21 14:03:37.909079
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_options = {}
    httpie_args = type('Namespace', (object,), {})
    assert isinstance(HeadersFormatter(format_options, httpie_args), FormatterPlugin)


# Generated at 2022-06-21 14:03:48.016667
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Link: <https://api.github.com/resource?page=2>; rel="next",
      <https://api.github.com/resource?page=5>; rel="last"
Link: <https://api.github.com/resource?page=1>; rel="first",
      <https://api.github.com/resource?page=1>; rel="prev"
X-RateLimit-Limit: 5000
X-RateLimit-Remaining: 4999
'''

# Generated at 2022-06-21 14:03:51.119140
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter_plugin = HeadersFormatter()
    assert isinstance(formatter_plugin, FormatterPlugin)
    assert hasattr(formatter_plugin, 'format_headers')
    assert callable(formatter_plugin.format_headers)


# Generated at 2022-06-21 14:03:52.965368
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(format_options={
        'headers': {'sort': True}
    })

# Generated at 2022-06-21 14:04:01.962442
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
POST /post HTTP/1.1
Transfer-Encoding: chunked
Accept: */*
Connection: keep-alive
Host: httpbin.org
Content-Type: application/json
Custom-Header: 
User-Agent: HTTPie/1.0.2
"""
    expected_headers = """\
POST /post HTTP/1.1
Accept: */*
Connection: keep-alive
Content-Type: application/json
Custom-Header: 
Host: httpbin.org
Transfer-Encoding: chunked
User-Agent: HTTPie/1.0.2
"""
    assert formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-21 14:04:13.991420
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:04:15.419456
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled == True


# Generated at 2022-06-21 14:04:23.872223
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: HTTPie/0.9.8
'''
    expected_headers_after_sort = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.8
'''
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers(test_headers) == expected_headers_after_sort



# Generated at 2022-06-21 14:04:33.436260
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # initialize the class instance
    instance = HeadersFormatter(
        format_options = {
            "headers": {
                "sort": True
            }
        }
    )
    # create the header string
    header_str = ''
    header_str += 'X-Foo: 1\r\n'
    header_str += 'Connection: close\r\n'
    header_str += 'Accept: */*\r\n'
    header_str += 'X-Bar: 1\r\n'
    header_str += 'Host: httpbin.org\r\n'
    header_str += 'User-Agent: HTTPie/1.0.3\r\n'
    header_str += 'Content-Length: 0\r\n'

# Generated at 2022-06-21 14:04:35.389907
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == False


# Generated at 2022-06-21 14:04:39.263447
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert h.enabled
    h = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert not h.enabled


# Generated at 2022-06-21 14:04:41.300883
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == True
    assert headers_formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:04:48.580877
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Server: Werkzeug/1.0.0 Python/3.7.3
Date: Wed, 10 Jul 2019 18:45:50 GMT
Content-Length: 188
'''
    expected = '''
HTTP/1.1 200 OK
Content-Length: 188
Content-Type: text/html; charset=utf-8
Date: Wed, 10 Jul 2019 18:45:50 GMT
Server: Werkzeug/1.0.0 Python/3.7.3
'''

    # Act
    actual = formatter.format_headers(headers)

    # Assert
    assert actual == expected

# Generated at 2022-06-21 14:04:52.044227
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
content-length: 50
Content-Length: 41
Host: httpbin.org
user-agent: HTTPie/1.0.3
Accept-Encoding: gzip, deflate
Connection: keep-alive
'''
    f = HeadersFormatter()
    headers = f.format_headers(headers)

    assert headers == '''\
content-length: 50
Content-Length: 41
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
user-agent: HTTPie/1.0.3
'''


# Generated at 2022-06-21 14:04:59.966428
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    str = 'Content-Type:text/html'
    assert h.format_headers(str) == str
    str = 'Content-Type:text/html\r\n' \
          'Content-Type:text/css'
    assert h.format_headers(str) == str

# Generated at 2022-06-21 14:05:11.978598
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Just show a header in the first line and in the second line with a header
    # that has the same name as the header in the first line
    headers = '''\
Host: host
Accept: application/json
Accept: text/html
X-First-Header: value1
X-Second-Header: value2
'''
    expected_headers = '''\
Host: host
X-First-Header: value1
X-Second-Header: value2
Accept: application/json
Accept: text/html
'''
    assert formatter.format_headers(headers) == expected_headers
    # Just show a header in the first line and in the second line with a header
    # that has the same name as the header in the first line

# Generated at 2022-06-21 14:05:19.954495
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-21 14:05:32.018078
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:05:34.488891
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Setting options for HeadersFormatter
    options = {'headers': {'sort':True}}
    HeadersFormatter(format_options=options)


# Generated at 2022-06-21 14:05:43.702499
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options=None, config=None)
    result = formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'Server: example.org',
        'Content-Type: application/json',
        'Content-Length: 10',
        'Cache-Control: private, max-age=0',
        'X-Content-Type-Options: nosniff',
        'Date: Tue, 16 May 2017 20:08:07 GMT'
    ]))

# Generated at 2022-06-21 14:05:51.259351
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    a = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Sun, 12 Mar 2017 06:25:37 GMT
Content-Type: application/json; charset=UTF-8
Content-Length: 21

'''
    formatted_headers = a.format_headers(headers)
    assert formatted_headers == '''\
HTTP/1.1 200 OK
Content-Length: 21
Content-Type: application/json; charset=UTF-8
Date: Sun, 12 Mar 2017 06:25:37 GMT

'''

# Generated at 2022-06-21 14:06:02.238546
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    t = HeadersFormatter()
    headers = t.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'B: 1\r\n'
        'A: 1\r\n'
        'C: 1\r\n'
        'A: 2\r\n'
        'B: 2\r\n'
    )
    assert headers == (
        'HTTP/1.1 200 OK\r\n'
        'A: 1\r\n'
        'A: 2\r\n'
        'B: 1\r\n'
        'B: 2\r\n'
        'C: 1\r\n'
    )

# Generated at 2022-06-21 14:06:10.984882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import json
    import os
    from httpie.core import main

    input_file = os.path.dirname(__file__) + '/data/input1.json'

    with open(input_file) as f:
        data = json.load(f)

    for input_headers in data:
        headers = HeadersFormatter().format_headers(input_headers)
        # print(headers)
        r = main(['--print=h', '--headers', '-H', headers])
        # print(r.stdout)
        assert r.exit_status == 0
        assert r.stderr == ''
        assert r.stdout == input_headers



# Generated at 2022-06-21 14:06:22.011599
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter(format_options={'headers': {'sort': 'enabled'}})
    headers = '''HTTP/1.1 200 OK\r
Content-Type: text/html; charset=utf-8\r
Content-Length: 1110\r
Connection: close\r
Set-Cookie: session_id=1234567890; expires=Wed, 21 Oct 2015 07:28:00 -0000; HttpOnly; Max-Age=36000\r
Access-Control-Allow-Origin: *\r
Access-Control-Allow-Methods: GET, POST, OPTIONS\r
Access-Control-Allow-Headers: Content-Type'''

# Generated at 2022-06-21 14:06:27.574091
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h=HeadersFormatter()
    assert type(h) == HeadersFormatter

# Unit test to check sort functionality

# Generated at 2022-06-21 14:06:36.328229
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = '''\
HTTP/1.0 200 Ok
Server: Server
ETag: 1
Cache-Control: no-cache
Set-Cookie: a=b
Set-Cookie: c=d
Server: Server
Date: today
'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.0 200 Ok
Date: today
ETag: 1
Cache-Control: no-cache
Server: Server
Set-Cookie: a=b
Set-Cookie: c=d'''

# Generated at 2022-06-21 14:06:44.411569
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:06:55.889350
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    sorted_headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Host: httpbin.org',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.8',
        ''
    ])
    unsorted_headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Host: httpbin.org',
        'Connection: keep-alive',
        'User-Agent: HTTPie/0.9.8',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        ''
    ])
    assert HeadersFormatter().format_headers(unsorted_headers) == sorted_headers

# Generated at 2022-06-21 14:06:57.965010
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter_plugin = HeadersFormatter()
    assert formatter_plugin.enabled == True


# Generated at 2022-06-21 14:06:59.232536
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(Exception):
        HeadersFormatter(format_options, **kwargs)


# Generated at 2022-06-21 14:07:01.650660
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert(hf.enabled == True)


# Generated at 2022-06-21 14:07:03.832504
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == False


# Generated at 2022-06-21 14:07:07.937704
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    HEADERS = """\
Content-Length: 43
X-Header: Header: Line
Connection: keep-alive
Content-Type: application/json
Date: 14.05.2018, 12:46:35
X-Header: Header: Line
"""
    expected_headers = """\
Content-Length: 43
Content-Type: application/json
Date: 14.05.2018, 12:46:35
Connection: keep-alive
X-Header: Header: Line
X-Header: Header: Line
"""
    f = HeadersFormatter()
    actual_headers = f.format_headers(HEADERS)
    assert actual_headers == expected_headers

# Generated at 2022-06-21 14:07:09.416620
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    plugin = HeadersFormatter()
    assert isinstance(plugin, HeadersFormatter)



# Generated at 2022-06-21 14:07:17.663680
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor with all arguments from FormatterPlugin
    formatter = HeadersFormatter(stdout=sys.stdout.buffer, stderr=sys.stderr.buffer,
            format_options={'headers': {'sort': True}})
    assert formatter is not None


# Generated at 2022-06-21 14:07:26.927520
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={'headers':{'sort': True}})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Date: Wed, 15 Mar 2017 11:39:36 GMT
Server: nginx/1.10.3 (Ubuntu)
Transfer-Encoding: chunked
X-Instance-ID: i-46f1d20e
X-Powered-By: Express
X-Trace-ID: 688ceb1c8b5f47b5b5dd5a5a5e4f4d4e

'''

# Generated at 2022-06-21 14:07:38.393836
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h_f = HeadersFormatter(format_options={
            'headers': {'sort': False}
            })
    # Simple test
    assert h_f.format_headers('HTTP/1.1 200 OK\r\n'
                                'e: 1\r\n'
                                'c: 3\r\n'
                                'a: 4\r\n'
                                'b: 5\r\n') == 'HTTP/1.1 200 OK\r\n' \
                                                'a: 4\r\n' \
                                                'b: 5\r\n' \
                                                'c: 3\r\n' \
                                                'e: 1\r\n'
    # Multiple headers with the same name

# Generated at 2022-06-21 14:07:48.448463
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    testargs = ['GET', 'foo_url']
    headers = """
            GET /foo HTTP/1.1

            Content-Type: application/json
            Foo: Foo-value-1
            Bar: Bar-value-1
            Foo: Foo-value-2
            """
    output = formatter.format_headers(headers)
    assert output == """
            GET /foo HTTP/1.1

            Content-Type: application/json
            Bar: Bar-value-1
            Foo: Foo-value-1
            Foo: Foo-value-2
            """



# Generated at 2022-06-21 14:07:50.357815
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-21 14:07:51.626372
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__() is not None


# Generated at 2022-06-21 14:07:53.440904
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled
    assert callable(headers_formatter.format_headers)


# Generated at 2022-06-21 14:08:01.464503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "HTTP/1.1 200 OK\r\nServer: test\r\nContent-Length: 10\r\nContent-Type: text/html; charset=utf-8\r\n"
    hf = HeadersFormatter()
    headers = hf.format_headers(headers)
    expected = "HTTP/1.1 200 OK\r\nContent-Length: 10\r\nContent-Type: text/html; charset=utf-8\r\nServer: test"
    assert headers == expected


# Generated at 2022-06-21 14:08:07.812246
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_lines = [
        'Content-type: text/html; charset=utf-8',
        'Content-Length: 167',
        'Connection: keep-alive',
        'Server: gunicorn/19.7.1',
        'Date: Tue, 11 Sep 2018 20:05:48 GMT',
        'X-XSS-Protection: 1; mode=block',
        'X-Content-Type-Options: nosniff',
    ]
    headers = '\r\n'.join(header_lines)
    formatter = HeadersFormatter()
    formatted = formatter.format_headers(headers)
    expected_lines = sorted(header_lines, key=lambda h: h.split(':')[0])
    expected = '\r\n'.join(expected_lines)
    assert formatted == expected



# Generated at 2022-06-21 14:08:08.179465
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert 1 == 1

# Generated at 2022-06-21 14:08:19.576755
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers = """\
HTTP/1.1 200 OK
Date: Fri, 02 Nov 2018 13:32:01 GMT
Server: WSGIServer/0.2 CPython/3.6.6
Content-Type: application/json
Content-Length: 5
"""
    assert formatter.format_headers(headers) == headers

# Generated at 2022-06-21 14:08:21.450303
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.enabled == False


# Generated at 2022-06-21 14:08:29.308513
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers(
        '''\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 43
Cache-Control: max-age=100
Cookie: bar=baz; foo=bar
Date: Sat, 01 Jan 2000 00:00:00 GMT

''')
    assert headers == '''\
HTTP/1.1 200 OK
Cache-Control: max-age=100
Cookie: bar=baz; foo=bar
Content-Length: 43
Content-Type: text/html; charset=utf-8
Date: Sat, 01 Jan 2000 00:00:00 GMT

'''



# Generated at 2022-06-21 14:08:39.074642
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_str = 'Content-Type: application/json\r\n'\
                + 'Cache-Control: no-cache\r\n'\
                + 'Content-Type: application/json\r\n'\
                + 'Access-Control-Allow-Credentials: true\r\n'
    headers = HeadersFormatter().format_headers(headers_str)
    assert 'Content-Type: application/json' in headers
    assert headers.index('Cache-Control') < headers.index('Content-Type: application/json')
    assert headers.index('Content-Type: application/json') < headers.index('Access-Control-Allow-Credentials')


http.output_options['headers']['sort'] = True

# Generated at 2022-06-21 14:08:41.304977
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(**{})
    assert headers_formatter.format_options['headers']['sort'] == False


# Generated at 2022-06-21 14:08:47.202139
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.formatters import JSONFormatter
    from httpie.plugins import JSONPrettyFormatterPlugin
    from httpie.plugins import JSONCompactFormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import HeaderSortFormatterPlugin
    import pytest
    f_plugin = FormatterPlugin(format_options={})
    assert f_plugin == f_plugin
    req = {}
    assert f_plugin.format(req, None) == (req, None)
    req['headers'] = "GET / HTTP/1.1\r\nTest:Value\r\nTest:Value2\r\nOther:Value\r\nOther:OtherValue"
    format(req)



# Generated at 2022-06-21 14:08:57.634912
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(httpbin=True)
    response = formatter.format_response(dump.dump_response,
        dump.dump_headers, dump.dump_body)
    response_lines = response.splitlines()

    assert 'Transfer-Encoding: chunked' in response_lines
    assert 'Date: ' in response_lines
    assert 'Connection: keep-alive' in response_lines
    assert 'Server: nginx' in response_lines
    assert 'X-Powered-By: Flask' in response_lines
    assert 'Content-Type: application/json' in response_lines
    assert 'Access-Control-Allow-Origin: *' in response_lines
    assert 'Access-Control-Allow-Credentials: true' in response_lines

# Generated at 2022-06-21 14:09:07.458280
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert fmt.format_headers(raw_headers_unsorted) == raw_headers_sorted

raw_headers_unsorted = '''\
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.8.0
'''

raw_headers_sorted = '''\
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.8.0
'''


# Generated at 2022-06-21 14:09:08.948461
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    format_HeadersFormatter = HeadersFormatter()
    assert type(format_HeadersFormatter) == HeadersFormatter

# Generated at 2022-06-21 14:09:14.261313
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = 'POST / HTTP/1.1\r\nAccept: */*\r\nConnection: close\r\nContent-Length: 2\r\nContent-Type: json\r\n\r\n{}'
    headers_formatted = 'POST / HTTP/1.1\r\nAccept: */*\r\nContent-Length: 2\r\nContent-Type: json\r\nConnection: close\r\n\r\n{}'
    sorter = HeadersFormatter()
    assert sorter.format_headers(headers) == headers_formatted

# Generated at 2022-06-21 14:09:36.988723
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={
        'headers': {'sort': True}
    })
    headers = (
        'Accept: */*\r\n'
        'Host: example.org\r\n'
        'Content-Type: application/json\r\n'
        'Foo: Bar\r\n'
        'Foo: Bar2\r\n'
        'Foo: Bar3\r\n'
        'Www-Authenticate: Basic realm="foo"\r\n'
    )
    actual = headers_formatter.format_headers(headers)

# Generated at 2022-06-21 14:09:45.154318
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    header_str = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Custom-Header: abc
X-Custom-Header: xyz
Connection: close
Server: BaseHTTP/0.6 Python/3.5.2
Date: Sun, 11 Dec 2016 02:15:13 GMT
Content-Length: 4
'''

# Generated at 2022-06-21 14:09:54.500244
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        'headers': {'sort': True}
    })

# Generated at 2022-06-21 14:10:05.132805
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Format headers
    headers_formatter = HeadersFormatter()
    headers_formatter.format_options = {}
    headers_formatter.format_options['headers'] = {}
    headers_formatter.format_options['headers']['sort'] = True
    headers = headers_formatter.format_headers("""HTTP/1.1 200 OK
Date: Fri, 4 Oct 2019 00:32:00 GMT
Content-Type: text/html; charset=utf-8
Server: Werkzeug/0.14.1 Python/3.7.3
Content-Length: 21
Connection: close

<!DOCTYPE html>
""")

# Generated at 2022-06-21 14:10:08.361300
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(
        format_options={'headers': {'sort': True}}
    ).enabled
    assert not HeadersFormatter(
        format_options={'headers': {'sort': False}}
    ).enabled


# Generated at 2022-06-21 14:10:12.625473
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Content-Type: application/json
X-Test-Header: test-header-value
User-Agent: HTTPie/1.0.0
X-Test-Header: test-header-value2
Content-Length: 14
Host: httpbin.org

"""
    headers_sorted = """\
POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Content-Length: 14
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/1.0.0
X-Test-Header: test-header-value
X-Test-Header: test-header-value2

"""

# Generated at 2022-06-21 14:10:15.405427
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=None)
    assert formatter.enabled is False
    assert formatter.format_options is None
    assert formatter.format_options['headers']['sort'] is None

# Generated at 2022-06-21 14:10:17.709227
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert(formatter.enabled == True)


# Generated at 2022-06-21 14:10:19.808005
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert 1 == headers_formatter.enabled


# Generated at 2022-06-21 14:10:22.613816
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={
            'headers': {'sort': True}
        })
    assert formatter
    assert formatter.enabled


# Generated at 2022-06-21 14:10:53.042103
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_test_obj = HeadersFormatter()
    headers = """\
POST /post HTTP/1.1
Content-Type: application/json
Cookie: hello=world
Cookie: foo=bar
Cookie: bar=baz

"""
    headers = formatter_test_obj.format_headers(headers)
    assert headers == """\
POST /post HTTP/1.1
Cookie: hello=world
Cookie: foo=bar
Cookie: bar=baz
Content-Type: application/json

""".replace('\n', '\r\n')

# Generated at 2022-06-21 14:11:00.262601
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # test_HeadersFormatter_format_headers()
    H = HeadersFormatter(format_options={'headers': {'sort': True}})
    headers_headers = '''\
ACCEPT: application/json
CONTENT-TYPE: application/json
COOKIE: a=100
COOKIE: b=200
'''
    headers_expected = '''\
ACCEPT: application/json
CONTENT-TYPE: application/json
COOKIE: a=100
COOKIE: b=200
'''
    headers_headers_formatted = H.format_headers(headers_headers)
    assert headers_headers_formatted == headers_expected
    # test_HeadersFormatter_format_headers()

# Generated at 2022-06-21 14:11:01.351742
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert hasattr(HeadersFormatter, '__init__')



# Generated at 2022-06-21 14:11:12.264871
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    H = HeadersFormatter
    assert H.format_headers(None, None) == '\r\n'
    assert H.format_headers(None, 'Hello') == 'Hello'
    assert H.format_headers(None, 'World') == 'World'
    assert H.format_headers(None, 'Hello\r\nWorld') == 'Hello\r\nWorld'
    assert H.format_headers(None, 'Hello\r\nWorld\r\n') == 'Hello\r\nWorld\r\n'
    assert H.format_headers(None, 'Hello\r\nWorld\r\n') == 'Hello\r\nWorld\r\n'

# Generated at 2022-06-21 14:11:13.651901
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Instantiates class HeadersFormatter

    """
    HeadersFormatter()


# Generated at 2022-06-21 14:11:18.116862
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = ("Content-Type: application/json\r\n"
               "Content-Length: 42\r\n"
               "\r\n")
    headers_sorted = ("Content-Length: 42\r\n"
                      "Content-Type: application/json\r\n"
                      "\r\n")
    headers_formatter = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert headers_formatter.format_headers(headers) == headers_sorted

# Generated at 2022-06-21 14:11:25.262465
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError) as te:
        HeadersFormatter.__init__()
    assert 'descriptor \'__init__\' of HeadersFormatter object ' \
           'needs an argument' in str(te.value)
    # Passing a wrong parameter
    with pytest.raises(TypeError) as te:
        HeadersFormatter(test=1)
    assert "__init__() got an unexpected keyword argument 'test'" in str(te.value)


# Generated at 2022-06-21 14:11:35.143185
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """The HeadersFormatter class has a method named format_headers.
    """
    headers = '''GET / HTTP/1.1\r
Host: example.org\r
Foo: Bar\r
Foo: Bar-2\r
Hello: World\r
A: B\r
X-A: B\r
X-B: A\r
X-C: C'''
    expected = '''GET / HTTP/1.1\r
Host: example.org\r
Foo: Bar\r
Foo: Bar-2\r
Hello: World\r
A: B\r
X-A: B\r
X-B: A\r
X-C: C'''
    assert HeadersFormatter(
        headers=dict(sort=True)
    ).format_headers(headers) == expected


# Generated at 2022-06-21 14:11:44.464709
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test that the order of the headers is not changed
    headers = '''\
GET / HTTP/1.1
Host: example.org
Accept: */*
User-Agent: HTTPie/1.0.2
Accept-Encoding: gzip, deflate
Connection: keep-alive
'''
    formatter = HeadersFormatter()
    formatted_headers = formatter.format_headers(headers)
    assert headers == formatted_headers
    # Test that the order of the headers is changed
    headers = '''\
GET / HTTP/1.1
Accept: */*
User-Agent: HTTPie/1.0.2
Host: example.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
'''
    formatted_headers = formatter.format_headers(headers)

# Generated at 2022-06-21 14:11:47.188887
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf is not None
    assert hf.enabled == True


# Generated at 2022-06-21 14:12:51.624843
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    dt = HeadersFormatter()
    assert dt.enabled is False

# Generated at 2022-06-21 14:12:57.756460
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 8\r\nConnection: close\r\n\r\n'
    control = 'HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Length: 8\r\nContent-Type: application/json\r\n\r\n'
    assert f.format_headers(headers) == control

# Generated at 2022-06-21 14:13:06.534594
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = formatter.format_headers('Content-Type: application/json\r\n'
                                       'Accept: */*\r\n'
                                       'Accept-Encoding: gzip, deflate\r\n'
                                       'User-Agent: HTTPie/1.0.0\r\n'
                                       'Connection: keep-alive\r\n')
    expected = ('Content-Type: application/json\r\n'
                'Accept: */*\r\n'
                'Accept-Encoding: gzip, deflate\r\n'
                'User-Agent: HTTPie/1.0.0\r\n'
                'Connection: keep-alive')
    assert headers == expected