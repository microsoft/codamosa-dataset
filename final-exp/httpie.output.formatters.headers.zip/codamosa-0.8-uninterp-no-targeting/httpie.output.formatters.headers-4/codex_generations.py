

# Generated at 2022-06-21 14:03:07.090181
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from urllib.parse import urlparse


# Generated at 2022-06-21 14:03:08.779923
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:03:14.319816
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(sort=True)
    headers = """\
Host: example.org
Content-Type: application/json
Connection: keep-alive
X-My-Header: abc
X-My-Header: xyz
Content-Length: 42
Accept-Encoding: gzip
"""
    result = formatter.format_headers(headers)
    expected_result = """\
Host: example.org
Content-Length: 42
Connection: keep-alive
Content-Type: application/json
Accept-Encoding: gzip
X-My-Header: abc
X-My-Header: xyz
"""
    assert result == expected_result

# Generated at 2022-06-21 14:03:18.057526
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    defaults = dict()
    defaults["headers"] = dict()
    defaults["headers"]["sort"] = True
    formatter = HeadersFormatter(defaults)
    assert formatter is not None


# Generated at 2022-06-21 14:03:20.357799
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': False}})
    assert not formatter.enabled



# Generated at 2022-06-21 14:03:22.024785
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == False


# Generated at 2022-06-21 14:03:29.374603
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Set-Cookie: foo=bar; Domain=.example.org
Set-Cookie: bar=baz; Domain=.example.org
Content-Length: 13
"""
    expected = """\
HTTP/1.1 200 OK
Content-Length: 13
Content-Type: application/json
Set-Cookie: foo=bar; Domain=.example.org
Set-Cookie: bar=baz; Domain=.example.org
"""
    actual = HeadersFormatter().format_headers(headers)
    assert actual == expected

# Generated at 2022-06-21 14:03:30.521325
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert 'HeadersFormatter' in globals()


# Generated at 2022-06-21 14:03:41.626421
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    actual_headers = headers_formatter.format_headers(
        """\
HTTP/1.1 200 OK
Host: github.com
Connection: keep-alive
Content-Length: 80752
Cache-Control: max-age=0
Accept: text/html
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0
"""
    )
    expected_headers = """\
HTTP/1.1 200 OK
Accept: text/html
Cache-Control: max-age=0
Connection: keep-alive
Content-Length: 80752
Host: github.com
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0
"""
    assert actual_headers == expected_headers



# Generated at 2022-06-21 14:03:43.939945
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    tester = HeadersFormatter()
    assert tester.enabled == tester.format_options['headers']['sort']


# Generated at 2022-06-21 14:03:55.118082
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    assert formatter.format_headers('') == ''
    assert formatter.format_headers('HTTP/1.1 200 OK') == 'HTTP/1.1 200 OK'
    assert formatter.format_headers('HTTP/1.1 200 OK\n') == 'HTTP/1.1 200 OK\n'
    assert formatter.format_headers('HTTP/1.1 200 OK\n\n') == 'HTTP/1.1 200 OK\n\n'

    headers = 'HTTP/1.1 200 OK\n' \
              'Date: Mon, 20 May 2019 11:12:22 GMT\n' \
              'Content-Type: text/html; charset=utf-8'


# Generated at 2022-06-21 14:04:00.027026
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 88
Content-Type: application/json
Content-Encoding: gzip
Connection: close
Server: nginx
Date: Thu, 12 Jul 2018 11:13:41 GMT

Hello HTTPie!
"""
    expected = """\
HTTP/1.1 200 OK
Connection: close
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 88
Content-Type: application/json
Date: Thu, 12 Jul 2018 11:13:41 GMT
Server: nginx

Hello HTTPie!
"""
    sorted_headers = hf.format_headers(headers)
    assert sorted_headers == expected

# Generated at 2022-06-21 14:04:03.600181
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    assert formatter.enabled == True


# Generated at 2022-06-21 14:04:12.094691
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = ('Content-Type: application/json\r\n'
               'Content-Type: text/plain\r\n'
               'Content-Length: 123\r\n'
               'Content-Length: 45\r\n')
    assert f.format_headers(headers) == ('Content-Length: 123\r\n'
                                         'Content-Length: 45\r\n'
                                         'Content-Type: application/json\r\n'
                                         'Content-Type: text/plain\r\n')


# Generated at 2022-06-21 14:04:22.605352
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

# Generated at 2022-06-21 14:04:32.341547
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
HTTP/1.1 200 OK
Content-Type: application/json
Server: GitHub.com
Status: 200 OK
X-RateLimit-Limit: 5000
X-RateLimit-Remaining: 4999
X-RateLimit-Reset: 1443091681
X-OAuth-Scopes: repo, admin:org, user
Connection: close
Date: Tue, 23 Jun 2015 11:32:35 GMT
Transfer-Encoding: chunked

"""
    output = formatter.format_headers(headers)
    assert len(output.split("\n")) == len(headers.split("\n"))
    for line in output.split("\n"):
        if line != '':
            assert line == output.split("\n")[0] or line.split(": ")[0]

# Generated at 2022-06-21 14:04:39.249576
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import pytest

    headers = [
        'GET / HTTP/1.1',
        'Content-Length: 5',
        'cache-control: no-cache',
        'connection: keep-alive',
        'content-type: application/json',
        'host: localhost:8080',
        'postman-token: 0c0b058a-0c3f-2a7a-c9e8-7483b27c2458',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        ''
    ]

# Generated at 2022-06-21 14:04:45.521655
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    test_input = """\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 0
Content-Type: text/html; charset=utf-8
Date: Mon, 01 Jan 1990 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
"""
    expected_output = """\
HTTP/1.1 200 OK
Content-Length: 0
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Date: Mon, 01 Jan 1990 00:00:00 GMT
Server: gunicorn/19.7.1
X-Powered-By: Flask
"""
    result = hf.format_headers(test_input)
    print(result)
    assert result == expected_

# Generated at 2022-06-21 14:04:54.961777
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()

    # From RFC 2616 #14.10
    headers_str = """
        Date: Tue, 15 Nov 1994 08:12:31 GMT
        Cte: "this is a quoted string"
        Cte: this is an unquoted string
        content-length: 3495
    """

    sorted_headers = """
        Date: Tue, 15 Nov 1994 08:12:31 GMT
        Cte: "this is a quoted string"
        Cte: this is an unquoted string
        content-length: 3495
    """

    assert fmt.format_headers(headers_str) == sorted_headers

# Generated at 2022-06-21 14:04:56.267242
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled is False
    assert obj.format_options == {'headers': {'sort': False}}



# Generated at 2022-06-21 14:05:08.925017
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Length: 16
X-Foo: Bar
Content-Type: application/json; charset=utf-8
X-Foo: Baz
X-Bar: Qux
"""
    headers_sorted = """\
Content-Length: 16
X-Bar: Qux
X-Foo: Bar
X-Foo: Baz
Content-Type: application/json; charset=utf-8
"""
    formatter = HeadersFormatter(format_options={
        'headers': {'sort':True}
    })
    formatter.enable()
    assert formatter.format_headers(headers) == headers_sorted

# Generated at 2022-06-21 14:05:19.081199
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '\r\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Length: 9',
        'Connection: keep-alive',
        'Content-Type: text/html',
        'Date: Wed, 10 Feb 2016 03:46:52 GMT',
        'ETag: "56b9f947-7"',
        'Last-Modified: Thu, 05 Nov 2015 18:09:35 GMT',
        'Server: TornadoServer/4.3',
        'X-Content-Type-Options: nosniff',
        'X-Frame-Options: DENY',
        'X-XSS-Protection: 1; mode=block'
    ])

# Generated at 2022-06-21 14:05:20.000652
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter != None

# Generated at 2022-06-21 14:05:21.678120
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled



# Generated at 2022-06-21 14:05:26.839850
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = """\
Content-Length: 11
Accept-Encoding: gzip,deflate
Accept: */*"""
    headers_sorted = """\
Content-Length: 11
Accept: */*
Accept-Encoding: gzip,deflate"""
    assert headers_sorted == HeadersFormatter().format_headers(headers)



# Generated at 2022-06-21 14:05:31.723289
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test no sort
    formatter = HeadersFormatter({'headers': {'sort': False}})
    assert not formatter.enabled
    # test sort
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.enabled


# Generated at 2022-06-21 14:05:34.177329
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled is False
    assert formatter.format_options == {'headers': {'sort': False}, 'pretty': 'all'}

# Generated at 2022-06-21 14:05:36.801390
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    headers_formatter.format_headers('Accept-Encoding: gzip\r\nContent-Type: application/json\r\n')

# Generated at 2022-06-21 14:05:39.229714
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # HeadersFormatter: constructor
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options['headers']['sort'] == False



# Generated at 2022-06-21 14:05:49.011258
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Create an instance x of class HeadersFormatter.
    """
    class get_config:
        def __init__(self):
            self.config = {
                'output_options': {
                    'format': 'colors'
                },
                'format_options': {
                    'headers': {
                        'sort': 'on',
                        'colors': 'on'
                    }
                }
            }


# Generated at 2022-06-21 14:05:57.696000
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert(headers_formatter.enabled == True)


# Generated at 2022-06-21 14:06:06.767471
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    lines_in = [
        'GET /hello HTTP/1.1',
        'Host: example.com',
        'Connection: keep-alive',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Upgrade-Insecure-Requests: 1',
        'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64)',
        'Accept-Encoding: gzip, deflate, sdch',
        'Accept-Language: en-US,en;q=0.8',
        'DNT: 1',
        'Cookie: cookie1=val1; cookie2=val2',
        ''
    ]

# Generated at 2022-06-21 14:06:09.052585
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={
        'headers': {
            'sort': True
        }
    })
    assert hf.enabled is True


# Generated at 2022-06-21 14:06:14.510862
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def test(headers, expected_headers):
        actual_headers = HeadersFormatter().format_headers(headers)
        print(actual_headers)
        assert actual_headers == expected_headers
    test(headers="""\r\nContent-Type: application/json\r\nX-Api-Key:c0ffee\r\n\r\n""",
         expected_headers="""\r\nX-Api-Key:c0ffee\r\nContent-Type: application/json\r\n\r\n""")


# Generated at 2022-06-21 14:06:21.082893
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers("""\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
a: 4
X-Foo: 2
B: 3
A: 1
YY: 2
""") == """\
HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
A: 1
a: 4
B: 3
X-Foo: 2
YY: 2
"""

# Generated at 2022-06-21 14:06:30.586312
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_headers = FormatterPlugin.format_headers
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Server: Test
X-Foo: Foo
X-Bar: Bar
X-Foo: Baz
'''
    assert format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Length: 2
Content-Type: application/json
Connection: keep-alive
Server: Test
X-Bar: Bar
X-Foo: Foo
X-Foo: Baz
'''



# Generated at 2022-06-21 14:06:32.084105
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert not obj.enabled

# Generated at 2022-06-21 14:06:37.420347
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    data = '''
POST /post HTTP/1.1
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Connection: close
Content-Length: 10

'''
    data = formatter.format_headers(data)
    assert 'Connection:' in data
    assert data.index('Connection:') < data.index('Content-Length:')

# Generated at 2022-06-21 14:06:45.038912
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from tempfile import NamedTemporaryFile as tmp
    f = tmp(mode='w+', newline='\r\n')
    f.write("""\
Host: httpbin.org
Connection: keep-alive
Content-Length: 22
Content-Type: application/json
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.8
X-Requested-With: XMLHttpRequest
X-Custom-Header: Custom Value

""")
    f.seek(0)
    headers = f.readlines()

# Generated at 2022-06-21 14:06:56.352415
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
GET / HTTP/1.1
Content-Type: multipart/form-data, application/json
Host: 127.0.0.1:5000
Accept-Encoding: gzip, deflate
Connection: close
User-Agent: python-requests/2.22.0
Accept: */*
Content-Length: 20
"""
    expected = """\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
Content-Length: 20
Content-Type: multipart/form-data, application/json
Host: 127.0.0.1:5000
User-Agent: python-requests/2.22.0
"""
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-21 14:07:17.236571
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter(format_options={'headers': {'sort': True}})

# Generated at 2022-06-21 14:07:19.802416
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False
    assert formatter.format_options['headers']['sort'] == False

# Generated at 2022-06-21 14:07:24.131128
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import httpie.plugins.builtin
    import httpie.output.formatters
    builtin_plugins = httpie.plugins.builtin.__all__
    formatters = httpie.output.formatters.__all__
    assert 'HeadersFormatter' in formatters
    assert 'headers' in builtin_plugins


# Generated at 2022-06-21 14:07:32.308441
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    headers = '''\
GET /test HTTP/1.1
Host: localhost
User-Agent: HTTPie/0.9.2
Foo: bar
Foo: baz
\r\n
'''
    expected_result = '''\
GET /test HTTP/1.1
Foo: bar
Foo: baz
Host: localhost
User-Agent: HTTPie/0.9.2
\r\n
'''
    assert f.format_headers(headers) == expected_result


# Generated at 2022-06-21 14:07:41.811137
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import JsonLinesFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import FormatterPlugin
    from httpie.status import ExitStatus
    from pytest import raises
    from requests.structures import CaseInsensitiveDict

    headers_formatter = HeadersFormatter()
    if headers_formatter.enabled:
        assert headers_formatter.format_headers('''
HEADERS
        ''') == '''
HEADERS
'''

# Generated at 2022-06-21 14:07:52.885569
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    content = """
HTTP/1.1 200 OK
User-Agent: HTTPie/0.9.3
Connection: close
Content-Type: application/json
Date: Thu, 24 Aug 2017 02:37:50 GMT
Server: WSGIServer/0.2 CPython/3.6.2
Content-Length: 428

"""
    content = content.strip()
    result = formatter.format_headers(content)
    correct = """
HTTP/1.1 200 OK
Connection: close
Content-Length: 428
Content-Type: application/json
Date: Thu, 24 Aug 2017 02:37:50 GMT
Server: WSGIServer/0.2 CPython/3.6.2
User-Agent: HTTPie/0.9.3
"""
    correct = correct.strip()
   

# Generated at 2022-06-21 14:08:02.159288
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    fmt.enabled = True
    result = fmt.format_headers('HTTP/1.1 200 OK\r\nCache-Control: no-cache\r\nCache-Control: no-store\r\nContent-Length: 0\r\nDate: Sun, 31 Mar 2019 12:22:53 GMT\r\n\r\n')
    assert result == 'HTTP/1.1 200 OK\r\nCache-Control: no-cache\r\nCache-Control: no-store\r\nContent-Length: 0\r\nDate: Sun, 31 Mar 2019 12:22:53 GMT\r\n\r\n'

# Generated at 2022-06-21 14:08:06.731241
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert hf.enabled == False
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.enabled == True


# Generated at 2022-06-21 14:08:16.035429
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    head_str = '''\
HTTP/1.1 301 Moved Permanently
Location: http://httpbin.org/
Connection: keep-alive
Server: nginx
Date: Sun, 01 Jan 2017 14:13:59 GMT
Content-Length: 178
Content-Type: text/html
Via: 1.1 vegur
'''
    assert hf.format_headers(head_str) == '''\
HTTP/1.1 301 Moved Permanently
Connection: keep-alive
Content-Length: 178
Content-Type: text/html
Date: Sun, 01 Jan 2017 14:13:59 GMT
Location: http://httpbin.org/
Server: nginx
Via: 1.1 vegur
'''

# Generated at 2022-06-21 14:08:19.119416
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    import pdb; pdb.set_trace()
    assert HeadersFormatter(**{'format_options': {'headers': {'sort': True}}})
