

# Generated at 2022-06-21 14:03:02.531745
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**{'headers': {'sort': True}})
    assert formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:03:10.504354
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()

    # Test if this formatter is enabled by default
    assert headers.enabled is True

    # Test sort function funtionality
    test_headers = "POST / HTTP/1.1\r\nContent-Type: application/json\r\n" \
                   "X-token: abc123\r\nContent-Type: application/json\r\n" \
                   "X-token: def456\r\n"
    expected_result = "POST / HTTP/1.1\r\nContent-Type: application/json\r\n" \
                      "Content-Type: application/json\r\n" \
                      "X-token: abc123\r\nX-token: def456\r\n"

    assert headers.format_headers(test_headers) == expected_result



# Generated at 2022-06-21 14:03:14.410813
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    expected = """
    foo: foo1
    foo: foo2
    bar: bar
    baz: baz
    """
    assert formatter.format_headers(expected) == expected

# Generated at 2022-06-21 14:03:25.760844
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Accept-Encoding: gzip
Content-Type: application/json; charset=utf-8
Host: github.com
Connection: keep-alive
X-RateLimit-Remaining: 49
X-RateLimit-Limit: 50
Cache-Control: no-cache
User-Agent: HTTPie/0.9.3
Accept: */*
'''.strip()
    expected = '''\
Accept-Encoding: gzip
Cache-Control: no-cache
Connection: keep-alive
Host: github.com
User-Agent: HTTPie/0.9.3
X-RateLimit-Limit: 50
X-RateLimit-Remaining: 49
'''.strip()
    assert HeadersFormatter(format_options={'headers': {'sort': True}})\
        .format_headers(headers) == expected



# Generated at 2022-06-21 14:03:30.474155
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    
    formatter = HeadersFormatter()
    headers = """HTTP/0.9 200 OK
b: 5
a: 4
B: 1
A: 3
B: 2"""
    result = """HTTP/0.9 200 OK
A: 3
B: 1
B: 2
a: 4
b: 5"""
    
    assert (formatter.format_headers(headers)) == result




# Generated at 2022-06-21 14:03:37.145973
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    cli_args = {'--headers': 'sort'}
    fmt = HeadersFormatter(cli_args=cli_args)


# Generated at 2022-06-21 14:03:39.543081
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:03:44.050984
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter(format_options = {
        'headers': {
            'sort': True
        }
    })
    assert isinstance(head, HeadersFormatter)
    assert head.format_options['headers']['sort'] == True
    assert head.enabled == True


# Generated at 2022-06-21 14:03:53.325248
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    # Case: just '\r\n'
    assert formatter.format_headers('\r\n') == '\r\n'

    # Case: single header (no ':'
    assert formatter.format_headers('\r\nContent-Type') == '\r\nContent-Type'

    # Case: single header (no '\n'
    assert formatter.format_headers('Content-Type: application/json') == 'Content-Type: application/json'

    # Case: multiple headers

# Generated at 2022-06-21 14:03:56.158577
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert type(HeadersFormatter(format_options={
        "headers":{
            "sort":True
        }
    })) == HeadersFormatter


# Generated at 2022-06-21 14:04:11.290505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Sorts headers by name while retaining relative
    order of multiple headers with the same name.

    """
    headers = '''Accept: text/html
Content-Type: multipart/form-data; boundary=---------------------------7e3f8a00a0fd0
Cookie: csrftoken=e8c1a7fbbd3f88e3cf3a8379545e0b0f
User-Agent: python-requests/2.18.4
Accept-Encoding: gzip, deflate
Content-Length: 379
Host: 127.0.0.1
Connection: keep-alive
'''

# Generated at 2022-06-21 14:04:22.104329
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Test case: Simple headers (same order)
    h = (
        'GET / HTTP/1.1\r\n'
        'User-Agent: HTTPie\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: */*\r\n'
        'Host: httpbin.org\r\n'
        '\r\n'
    )
    expected = (
        'GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Host: httpbin.org\r\n'
        'User-Agent: HTTPie\r\n'
        '\r\n'
    )
    #process
    formatter = Head

# Generated at 2022-06-21 14:04:25.045452
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.sort_headers == False
    headers_formatter = HeadersFormatter(sort_headers=True)
    assert headers_formatter.sort_headers == True


# Generated at 2022-06-21 14:04:34.446670
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:04:44.330791
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    header_formatter = HeadersFormatter()

    header_formatter.format_options = {'headers': {'sort': True}}

    headers_string = "GET / HTTP/1.1\r\n\r\nContent-Type: application/json\r\nContent-Length: 42\r\nAccept: x-y-z\r\nAccept: a-b-c\r\nAccept: 1-2-3\r\n"

    formatted_headers_string = "GET / HTTP/1.1\r\n\r\nAccept: x-y-z\r\nAccept: a-b-c\r\nAccept: 1-2-3\r\nContent-Length: 42\r\nContent-Type: application/json\r\n"


# Generated at 2022-06-21 14:04:56.599010
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Set up
    # Instantiate object that is to be tested
    formatter = HeadersFormatter()
    # Case 1: Not sorted by name
    headers = (
        'Content-Type: text/plain charset=utf-8\r\n'
        'user-agent: HTTPie/0.9.9\r\n'
        'Connection: keep-alive\r\n'
        'x-header: header-value\r\n'
        'X-Header: header-value\r\n'
        'X-Header2: header-value2\r\n'
    )

# Generated at 2022-06-21 14:04:59.809057
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    header_formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert header_formatter.enabled == True


# Generated at 2022-06-21 14:05:04.241298
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_instance = HeadersFormatter()
    assert formatter_instance.format_headers(
        """
        Content-Type: application/json
        Content-Length: 25
        """
    ) == """
        Content-Length: 25
        Content-Type: application/json
        """



# Generated at 2022-06-21 14:05:16.171985
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'A: 1\r\n'
        'B: 2\r\n'
        'B: 1\r\n'
    ) == 'HTTP/1.1 200 OK\r\n' \
        'A: 1\r\n' \
        'B: 2\r\n' \
        'B: 1\r\n'

# Generated at 2022-06-21 14:05:18.094058
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.format_options == {
        'headers': {
            'sort': True
        }
    }


# Generated at 2022-06-21 14:05:27.320616
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class dummy():
        self.format_options = {'headers': {'sort': True}}
        
    x = HeadersFormatter()


# End of HeadersFormatter class


# Generated at 2022-06-21 14:05:34.489523
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # To check if the default values are initialised correctly
    assert HeadersFormatter().enabled == False
    assert HeadersFormatter(sort_headers=True).enabled == True
    assert HeadersFormatter(sort_headers=False).enabled == False
    assert HeadersFormatter(format_options={'headers': {'sort': True}}).enabled == True
    assert HeadersFormatter(format_options={'headers': {'sort': False}}).enabled == False


# Generated at 2022-06-21 14:05:35.978096
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers


# Generated at 2022-06-21 14:05:38.864649
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter(format_options=headers_args, configuration=headers_args)
    assert x.format_options == headers_args
    assert x.configuration == headers_args



# Generated at 2022-06-21 14:05:48.916104
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    '''
    Test method format_headers of class HeadersFormatter.

    Method sort headers of HTTP response.

    '''
    formatter_plugin = HeadersFormatter()

# Generated at 2022-06-21 14:05:53.455538
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Necessary for exact comparison, as trailing whitespaces are stripped by
    # the parser.
    headers_input = '''
HTTP/1.1 200 OK
Content-Type: application/json
Via: 1.1 vegur
Connection: close
Content-Length: 280

'''
    # Expected result if headers are sorted
    headers_output = '''
HTTP/1.1 200 OK
Connection: close
Content-Length: 280
Content-Type: application/json
Via: 1.1 vegur

'''
    formatter = HeadersFormatter()
    headers = formatter.format_headers(headers_input)
    assert headers == headers_output



# Generated at 2022-06-21 14:06:04.434591
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''
HTTP/1.1 200 OK
Server: nginx
Date: Tue, 10 Jul 2018 22:21:07 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 3
Connection: keep-alive
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
X-Powered-By: Express
Vary: Origin, Accept-Encoding
Content-Encoding: gzip
{}
    '''.strip()

# Generated at 2022-06-21 14:06:12.787824
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter(format_options={
                                            'headers': {
                                                'sort': True,
                                            },
                                        })
    assert headers_formatter.format_headers(
        '''\
GET /get?a=b&c=d&c=e HTTP/1.1
Cookie: a=b
Cookie: c=d
Connection: close
Accept-Encoding: gzip
''') == (
        '''\
GET /get?a=b&c=d&c=e HTTP/1.1
Connection: close
Cookie: a=b
Cookie: c=d
Accept-Encoding: gzip
''')



# Generated at 2022-06-21 14:06:23.665848
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # To-do: Test for multiple headers with same name
    # To-do: Test for headers with values not separated by ': '
    # To-do: Test for headers with continuations
    assert (HeadersFormatter(format_options={'headers': {'sort': True}}).enabled)
    assert (not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled)
    # To-do: Test for format_options={}
    # To-do: Test for format_options={'headers': {}}
    # To-do: Test for format_options={'headers': {'sort': None}}
    assert (HeadersFormatter(format_options={'headers': {'sort': True}, 'something_else': {'sort': False}}).enabled)
    assert (HeadersFormatter().enabled)

# Generated at 2022-06-21 14:06:32.184669
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """
        GET / HTTP/1.1
        Content-Type: application/json
        User-Agent: HTTPie/0.9.6
        X-Custom-Header: custom_value
    """
    headers = formatter.format_headers(headers)
    expected = """
        GET / HTTP/1.1
        Content-Type: application/json
        User-Agent: HTTPie/0.9.6
        X-Custom-Header: custom_value
    """
    assert headers == expected

# Generated at 2022-06-21 14:06:46.144360
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hfm = HeadersFormatter(
        format_options={'headers': {'sort': True}}
    )
    assert hfm.enabled == True


# Generated at 2022-06-21 14:06:56.882862
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = "Accept: application/json\r\nX-With-Dashes: 1\r\nX-multiple: foo\r\nx-multiple: bar\r\nX-With-Dashes: 2\r\nContent-Type: text/plain"
    expected = "Accept: application/json\r\nContent-Type: text/plain\r\nX-With-Dashes: 1\r\nX-With-Dashes: 2\r\nX-multiple: foo\r\nx-multiple: bar"
    actual = HeadersFormatter({'headers': {'sort': True}}).format_headers(headers)
    assert actual == expected, "Expected '%s', got '%s':\n%s" % (expected, actual, hexdump(actual))



# Generated at 2022-06-21 14:06:58.728864
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_input = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert test_input.enabled == True



# Generated at 2022-06-21 14:07:01.348656
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={
            'headers': {'sort': True}
        }
    )

    assert headers_formatter.enabled == True
    assert headers_formatter.format_options['headers']['sort'] == True

# Generated at 2022-06-21 14:07:08.953316
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Content-Type: application/json
X-Custom-Header-1: abc
X-Custom-Header-2: def
X-Custom-Header-1: ghi
X-Custom-Header-3: jkl
'''.strip()
    expected = '''\
Content-Type: application/json
X-Custom-Header-1: abc
X-Custom-Header-1: ghi
X-Custom-Header-2: def
X-Custom-Header-3: jkl
'''.strip()
    assert HeadersFormatter().format_headers(headers) == expected



# Generated at 2022-06-21 14:07:19.937073
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Unit test for constructor of class HeadersFormatter
    """
    # Test case 1
    with patch("httpie.plugins.formatter.get_config_dir") as mock_get_config_dir:
        mock_get_config_dir.return_value = "./httpie"
        with patch("httpie.plugins.formatter.os.path.exists") as mock_path_exists:
            mock_path_exists.return_value = False
            formatter = HeadersFormatter(color=Color())
            assert isinstance(formatter, HeadersFormatter) == True
            assert formatter.format_options['headers']['sort'] == True

            # Test case 2
            with patch("httpie.plugins.formatter.os.path.exists") as mock_path_exists2:
                mock_

# Generated at 2022-06-21 14:07:24.349847
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    text = '''
GET / HTTP/1.1
Accept: */*
Content-Type: application/json
Accept-Encoding: gzip, deflate
Accept-Language: sk-SK,sk;q=0.8,en-US;q=0.5,en;q=0.3
Connection: keep-alive
Host: httpbin.org
Referer: http://httpbin.org/
User-Agent: Mozilla/5.0
'''

    print(text)
    h = HeadersFormatter()
    print(h.format_headers(text))

# Generated at 2022-06-21 14:07:35.705827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = headers_formatter.format_headers(
        '''
HTTP/1.1 200 OK
Date: Tue, 22 Aug 2017 01:31:58 GMT
Server: Apache
Set-Cookie: JSESSIONID=abc123; Path=/; HttpOnly
Location: http://www.example.com
Content-Length: 578
Connection: close
Content-Type: text/html; charset=UTF-8
''')

# Generated at 2022-06-21 14:07:39.968736
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_headers('one: 1\r\ncontent-type: application/json\r\nAccept: application/json\r\n') \
           == 'one: 1\r\nAccept: application/json\r\ncontent-type: application/json'

# Generated at 2022-06-21 14:07:42.780967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(**formatter_kwargs)

    


# Generated at 2022-06-21 14:08:09.856258
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    
    # Test for the correct initialisation of instance fields
    assert formatter.enabled is True
    
    
    

# Generated at 2022-06-21 14:08:15.946084
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # The class constructor should take in format_options and assign it's headers sort value to
    #   the enabled variable
    assert HeadersFormatter(format_options={"headers": {"sort": True}}).enabled == True
    assert HeadersFormatter(format_options={"headers": {"sort": False}}).enabled == False

# Unit tests for format_headers()
#   Will create a HeadersFormatter instance and then call the format_headers() method with
#   a variety of inputs to confirm that the expected output is provided

# Generated at 2022-06-21 14:08:24.412703
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    test_input = '''
    Content-Type: application/json
    Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l
    X-Request-ID: 987
    X-Request-ID: 654
    X-Request-ID: 321
    X-Request-ID: 123
    '''.strip()
    expected_output = '''
    Content-Type: application/json
    X-Request-ID: 123
    X-Request-ID: 321
    X-Request-ID: 654
    X-Request-ID: 987
    Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l
    '''.strip()
    formatter = HeadersFormatter()
    assert formatter.format_headers(test_input) == expected_output


# Unit

# Generated at 2022-06-21 14:08:28.477923
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': False}})
    assert formatter.enabled == False
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.enabled == True
    assert formatter.format_options == {'headers': {'sort': True}}



# Generated at 2022-06-21 14:08:29.239008
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:08:31.514769
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test_header_formatter = HeadersFormatter()
    assert test_header_formatter.enabled == False


# Generated at 2022-06-21 14:08:34.240245
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test constructor
    formatter = HeadersFormatter(format_options=None, config_dir=None)
    assert formatter != None

# Generated at 2022-06-21 14:08:43.467356
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()
    raw_headers = '''HTTP/1.1 200 OK
Cache-Control: private, max-age=0
Content-Length: 15267
Content-Type: text/html; charset=UTF-8
Date: Tue, 23 Apr 2019 04:06:23 GMT
Etag: "1a78"
Expires: Tue, 23 Apr 2019 04:06:23 GMT
Last-Modified: Tue, 23 Apr 2019 04:06:22 GMT
Server: gws
X-Frame-Options: SAMEORIGIN
'''

# Generated at 2022-06-21 14:08:54.699306
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given the following request headers
    headers = '''\
GET /h HTTP/1.1
User-Agent: curl/7.37.1
Host: httpbin.org
Accept: */*
Content-Type: text/plain
Connection: close
'''
    # When the method format_headers is called
    f = HeadersFormatter()
    output = f.format_headers(headers)
    # Then the header fields should be sorted alphabetically
    assert output == '''\
GET /h HTTP/1.1
Accept: */*
Connection: close
Content-Type: text/plain
Host: httpbin.org
User-Agent: curl/7.37.1
'''


# Generated at 2022-06-21 14:08:57.477346
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.format_options == {'headers' : {'sort': False}}


# Generated at 2022-06-21 14:10:36.308827
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    string = '\r\n'.join([
        'POST /post HTTP/1.1',
        'User-Agent: HTTPie/0.7.2',
        'Accept-Encoding: gzip, deflate',
        'Accept: */*',
        'Connection: keep-alive',
        'Content-Length: 16',
        'Content-Type: application/json; charset=utf-8'
    ])

# Generated at 2022-06-21 14:10:45.408840
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Any headers that contain spaces or special characters will be replaced by
    # appropriate values as required
    # by the RFC 7230 specification.
    headers = """Content-Type: application/x-www-form-urlencoded
    User-Agent: HTTPie/1.0.2
    Accept-Encoding: gzip, deflate
    Accept: */*
    Host: localhost:5000
    Content-Length: 15"""

    expected = """Content-Type: application/x-www-form-urlencoded
    Accept: */*
    Accept-Encoding: gzip, deflate
    Content-Length: 15
    Host: localhost:5000
    User-Agent: HTTPie/1.0.2"""

    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == expected

# Generated at 2022-06-21 14:10:54.134960
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create an instance of class HeadersFormatter
    headers_formatter = HeadersFormatter()
    # Create a sample headers
    headers = '''
Content-Length: 16
Connection: keep-alive
Content-Type: application/json; charset=utf-8
Accept: */*
Host: httpbin.org
User-Agent: HTTPie/1.0.3
'''
    # Assert that the headers are sorted by name
    assert headers_formatter.format_headers(headers) == '''
Content-Length: 16
Content-Type: application/json; charset=utf-8
Accept: */*
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/1.0.3
'''

# Generated at 2022-06-21 14:10:54.903849
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	ses = HeadersFormatter()


# Generated at 2022-06-21 14:10:56.263125
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()
    assert HeadersFormatter().format_headers(headers="")


# Generated at 2022-06-21 14:10:57.966075
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter_plugin = HeadersFormatter(output_file=StringIO())
    assert formatter_plugin.format_options['headers']['sort'] == False

# Generated at 2022-06-21 14:11:06.564507
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Accept-encoding: gzip, deflate
Accept: */*
User-Agent: python-requests/2.5.1 CPython/2.7.6 Linux/3.13.0-24-generic
Connection: keep-alive
'''
    sorted_headers = '''\
Accept-encoding: gzip, deflate
Accept: */*
Connection: keep-alive
User-Agent: python-requests/2.5.1 CPython/2.7.6 Linux/3.13.0-24-generic
'''
    formatter = HeadersFormatter()
    assert formatter.format_headers(headers) == sorted_headers



# Generated at 2022-06-21 14:11:12.301470
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nServer: nginx\r\nContent-Type: text/html\r\nConnection: Keep-Alive') == 'HTTP/1.1 200 OK\r\nConnection: Keep-Alive\r\nContent-Type: text/html\r\nServer: nginx'


# Generated at 2022-06-21 14:11:20.624607
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Create an instance of class HeadersFormatter
    headers_formatter = HeadersFormatter(format_options=None)

    # Declare and initialize parameters

# Generated at 2022-06-21 14:11:31.747315
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Expires: -1
Cache-Control: private, max-age=0
Content-Type: text/html; charset=UTF-8
Content-Encoding: gzip
Server: gws
Content-Length: 0
X-XSS-Protection: 0
X-Frame-Options: SAMEORIGIN

'''
