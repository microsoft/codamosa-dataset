

# Generated at 2022-06-21 14:03:04.870852
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options = {})


# Generated at 2022-06-21 14:03:06.977403
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert f.format_options['headers']['sort'] is True


# Generated at 2022-06-21 14:03:14.089267
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {'headers': {'sort': True}, 'pretty': True}
    headers_formatter: HeadersFormatter = HeadersFormatter(format_options)
    before_sorted_headers: str = """HTTP/1.1 200 OK
Age: 2
Connection: keep-alive
Content-Type: application/json; charset=utf-8
Date: Thu, 04 Apr 2019 06:34:15 GMT
Server: nginx/1.14.0 (Ubuntu)
Via: 1.1 vegur
X-Powered-By: Express
Content-Length: 12
ETag: W/"c-7Qdih1MuhjZehB6Sv8UNjA"
"""

# Generated at 2022-06-21 14:03:16.437297
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()

    assert h.format_options['headers']['sort'] == True



# Generated at 2022-06-21 14:03:24.430573
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    format_options = {'headers': {'sort': True}}
    formatter = HeadersFormatter(format_options, 'utf-8')
    headers = """\
GET / HTTP/1.1
accept: application/json
User-Agent: HTTPie
Accept-Encoding: gzip, deflate
Connection: keep-alive
"""
    assert formatter.format_headers(headers) == """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
accept: application/json
Connection: keep-alive
User-Agent: HTTPie
"""

# Generated at 2022-06-21 14:03:26.620715
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == headers.format_options['headers']['sort']


# Generated at 2022-06-21 14:03:31.129636
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """HTTP/1.1 200 OK
        C:
        A: a
        B: b
        A: aa
        B: bb"""
    assert formatter.format_headers(headers) == """HTTP/1.1 200 OK
        A: a
        A: aa
        B: b
        B: bb
        C:"""

# Generated at 2022-06-21 14:03:37.612669
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers(
        'GET / HTTP/1.1\r\n'
        'Content-Type: application/json\r\n'
        'Cookie: a=1; b=2\r\n'
        'Cookie: bb=3; cc=4\r\n'
    ) == (
        'GET / HTTP/1.1\r\n'
        'Content-Type: application/json\r\n'
        'Cookie: a=1; b=2\r\n'
        'Cookie: bb=3; cc=4\r\n'
    )

# Generated at 2022-06-21 14:03:47.818918
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    def test_headers(headers: str) -> str:
        return HeadersFormatter(format_options={'headers': {'sort': True}}).format_headers(headers)
    assert test_headers('GET / HTTP/1.1\r\nContent-Type: text/html; charset=utf-8\r\nAccept: text/html\r\n\r\n') == 'GET / HTTP/1.1\r\nContent-Type: text/html; charset=utf-8\r\nAccept: text/html\r\n\r\n'

# Generated at 2022-06-21 14:03:55.839818
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h1 = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\nA: 3\r\nA: 1\r\nA: 2\r\n'
    h1 = HeadersFormatter.format_headers(h1)
    h2 = 'HTTP/1.1 200 OK\r\nA: 3\r\nA: 1\r\nA: 2\r\nContent-Length: 2\r\nContent-Type: application/json\r\n'
    assert h1 == h2


__version__ = '0.0.3'

# Generated at 2022-06-21 14:04:11.610166
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:04:13.933081
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert f.enabled

# Generated at 2022-06-21 14:04:23.722922
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:04:24.595890
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-21 14:04:28.306863
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options = {'headers': {'sort': True}})
    assert formatter.enabled == True
    assert formatter.format_options['headers']['sort'] == True


# Generated at 2022-06-21 14:04:36.393904
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter
    formatter.format_options = {}
    formatter.format_options['headers'] = {}
    formatter.format_options['headers']['sort'] = True
    formatter.format_options['headers']['split'] = False
    formatter.format_options['headers']['color'] = False

# Generated at 2022-06-21 14:04:37.774305
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test = HeadersFormatter

    test = HeadersFormatter()

    assert type(test) == HeadersFormatter



# Generated at 2022-06-21 14:04:46.700534
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Case 1: Valid input
    input_str = """\
Content-Type: application/json; charset=utf-8
Accept: application/json
X-CustomHeader1: custom_value1
X-CustomHeader2: custom_value2

{
    "key": "Value"
}
      """
    expected_str = """\
Content-Type: application/json; charset=utf-8
Accept: application/json
X-CustomHeader1: custom_value1
X-CustomHeader2: custom_value2

{
    "key": "Value"
}
      """

    plugin = HeadersFormatter()
    assert plugin.format_headers(input_str) == expected_str

    # Case 2: Invalid input

# Generated at 2022-06-21 14:04:58.953048
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from collections import OrderedDict
    from httpie.compat import str
    from httpie.output.formatters import _BaseFormatter

    # Init _BaseFormatter
    class HFP(_BaseFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    hf = HFP()

# Generated at 2022-06-21 14:05:01.047753
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
   formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
   assert formatter.enabled == True


# Generated at 2022-06-21 14:05:15.496986
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    print('test method format_headers ... ', end='')
    f = HeadersFormatter()
    headers = """POST /get HTTP/1.1
user-agent: HTTPie
content-type: application/json
content-length: 31
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Host: www.httpbin.org
"""
    assert f.format_headers(headers) == """POST /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
content-length: 31
content-type: application/json
Host: www.httpbin.org
user-agent: HTTPie
"""
    print('passed')


# Generated at 2022-06-21 14:05:23.137503
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # setup
    formatter = HeadersFormatter()
#    headers = """Content-Security-Policy: default-src 'none'\r\nContent-Length: 3\r\nContent-Security-Policy: default-src 'self'\r\n"""
    headers = """HTTP/1.1 200 OK\r\nContent-Security-Policy: default-src 'none'\r\nContent-Length: 3\r\nContent-Security-Policy: default-src 'self'\r\n"""
    # test
    sorted_headers = formatter.format_headers(headers)
    # assert

# Generated at 2022-06-21 14:05:34.791520
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test 1 : Normal case
    lines = '''POST / HTTP/1.1
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Host: httpbin.org
Content-Length: 8
Content-Type: application/json

{"test":1}'''
    fmt = HeadersFormatter()
    expected_return = '''POST / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Length: 8
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.2

{"test":1}'''
    assert fmt.format_headers(lines) == expected_return

    # Test 2 : Empty case
    fmt = HeadersFormatter()


# Generated at 2022-06-21 14:05:43.919508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    '''
    Test method format_headers of class HeadersFormatter.
    Test case:
        Headers are sorted by their names.
    '''
    # Create a headers formatter object
    hf = HeadersFormatter()
    # Create a headers string to be sorted

# Generated at 2022-06-21 14:05:47.608926
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.format_name == 'headers'
    assert formatter.format_options == {'sort': True}
    assert formatter.enabled is True


# Generated at 2022-06-21 14:05:48.966312
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled

# Generated at 2022-06-21 14:05:49.872811
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None

# Generated at 2022-06-21 14:06:02.060872
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={
        "headers": {
            "sort": True
        }
    })
    headers = '''GET / HTTP/1.1
foo: bar
baz: qux
Host: example.com
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.2
Connection: keep-alive'''

# Generated at 2022-06-21 14:06:05.256034
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter({'headers': {'sort':True}})
    assert instance is not None
    assert instance.enabled is True


# Generated at 2022-06-21 14:06:06.996195
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == False


# Generated at 2022-06-21 14:06:24.323975
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Verify that the headers are being sorted by name
    # even when multiple headers with the same name exist
    headers = '''GET / HTTP/1.1\r
X-Foo: 1\r
X-Foo: 2\r
X-Bar: 1\r
X-Baz: 1\r
X-Foo: 3\r
X-Foo: bar\r
X-Quux: 1\r
X-Foo: 42\r
\r'''

    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:06:33.914089
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = '''\
GET / HTTP/1.1
Content-Type: application/json
User-Agent: HTTPie/0.9.6
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Accept: */*\
'''
    expected = '''\
GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 18
Content-Type: application/json
User-Agent: HTTPie/0.9.6\
'''
    actual = HeadersFormatter().format_headers(h)
    assert actual == expected

# Generated at 2022-06-21 14:06:40.018681
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	# no input
	assert HeadersFormatter() != None

	# input all parameters
	assert HeadersFormatter(format_options=True, session=True, config=True) != None

	# input only format_options
	assert HeadersFormatter(format_options=True) != None

	# input only session
	assert HeadersFormatter(session=True) != None

	# input only config
	assert HeadersFormatter(config=True) != None


# Generated at 2022-06-21 14:06:41.981226
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={"headers":{"sort":"True"}})
    assert headersFormatter is not None


# Generated at 2022-06-21 14:06:44.170905
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(AttributeError):
        HeadersFormatter()


# Generated at 2022-06-21 14:06:48.025181
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    #GIVEN
    headersFormatter = HeadersFormatter()
    
    #WHEN

    #THEN
    assert(headersFormatter.enabled == headersFormatter.format_options['headers']['sort'])

# Generated at 2022-06-21 14:06:49.660108
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    print(f)


# Generated at 2022-06-21 14:06:53.001015
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=False)))


# Generated at 2022-06-21 14:06:55.200032
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class TestHeadersFormatter(HeadersFormatter):
        def format_headers(self, headers: str) -> str:
            ()

# Generated at 2022-06-21 14:06:57.389956
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={'headers': {'sort': True }})
    assert headers_formatter.enabled == True


# Generated at 2022-06-21 14:07:13.192082
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter({'headers': {'sort': True}}, None)
    assert headers_formatter.enabled
    assert isinstance(HeadersFormatter, FormatterPlugin)


# Generated at 2022-06-21 14:07:17.782161
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    options = {'headers': {'sort': True},
               'body': {'sort': False},
               'pretty': True,
               'ugly': False}
    formatter = HeadersFormatter(format_options=options)
    assert formatter.enabled == True



# Generated at 2022-06-21 14:07:18.750716
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass



# Generated at 2022-06-21 14:07:27.668591
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={})
    formatter.enabled = True

    # no header
    headers = ''
    result = formatter.format_headers(headers)
    assert result == headers

    # one header
    headers = 'header1: value1'
    result = formatter.format_headers(headers)
    assert result == headers

    # multi headers
    headers = '''
header1: value1
header2: value2
header3: value3
header4: value4
    '''
    result = formatter.format_headers(headers)
    assert result == '''
header1: value1
header2: value2
header3: value3
header4: value4
    '''.strip()

    # multiple headers with the same name

# Generated at 2022-06-21 14:07:35.786615
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    line = "Accept: application/json\r\n"
    line = line + "User-Agent: HTTPie/0.9.2\r\n"
    line = line + "Content-Length: 0\r\n"
    line = line + "Connection: keep-alive\r\n"
    line = line + "Host: httpbin.org\r\n"
    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert hf.format_headers(line) == line


# Generated at 2022-06-21 14:07:43.977841
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Server: nginx/1.8.0
Content-Type: application/json; charset=utf-8
Content-Length: 177
Connection: keep-alive
Vary: Accept
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: http://httpbin.org
Date: Sat, 30 Apr 2016 11:37:35 GMT
X-XSS-Protection: 1; mode=block
X-Frame-Options: DENY

"""

# Generated at 2022-06-21 14:07:48.293841
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter(format_options={'headers': {'sort': True}})
    
    # Test enabled and format_options for headers
    assert(f.enabled == True)
    assert(f.format_options['headers']['sort'] == True)



# Generated at 2022-06-21 14:07:50.961446
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  headers_formatter = HeadersFormatter()
  assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:08:01.205282
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    assert h.format_headers('Content-Type: text/html Data: 123') == 'Content-Type: text/html Data: 123'
    assert h.format_headers('Content-Type: text/html Data: 123\nData: 456') == 'Content-Type: text/html Data: 123\nData: 456'
    assert h.format_headers('Content-Type: text/html Data: 123\nData: 456\nContent-Type: text/css') == 'Content-Type: text/html Data: 123\nData: 456\nContent-Type: text/css'

# Generated at 2022-06-21 14:08:02.465641
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert type(HeadersFormatter()) is HeadersFormatter


# Generated at 2022-06-21 14:08:54.741670
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers(None) == None
    assert formatter.format_headers('') == ''
    assert formatter.format_headers('a: b\r\nc: d\r\n') == 'a: b\r\nc: d\r\n'
    assert formatter.format_headers('g: d\r\nc: b\r\n') == 'c: b\r\ng: d\r\n'

# Generated at 2022-06-21 14:09:06.232133
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 3
Connection: keep-alive
Content-Encoding: gzip
Cache-Control: public, max-age=0, must-revalidate
Date: Wed, 05 Jul 2017 21:11:20 GMT
Expires: Wed, 05 Jul 2017 21:11:20 GMT
Last-Modified: Wed, 05 Jul 2017 20:48:12 GMT
Server: gunicorn/19.7.1
Vary: Accept-Encoding'''

# Generated at 2022-06-21 14:09:14.078436
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup for the test
    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})

    # Function under test

# Generated at 2022-06-21 14:09:23.759218
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_str = '''
POST /post HTTP/1.1
Host: www.httpbin.org
Accept-Encoding: gzip, deflate, br
Accept: application/json
Connection: keep-alive
User-Agent: HTTPie/1.0.0-dev
Content-Length: 29
Content-Type: application/json

'''
    headers_str_sorted = '''
POST /post HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 29
Content-Type: application/json
Host: www.httpbin.org
User-Agent: HTTPie/1.0.0-dev

'''

    headers = HeadersFormatter(format_options={'headers': {'sort': False}})

# Generated at 2022-06-21 14:09:29.973126
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange & Act
    formatter = HeadersFormatter()
    output = formatter.format_headers(
        headers='HTTP/1.1 200 OK\r\n'
                'Content-Type: text/plain\r\n'
                'Set-Cookie: cookie1=value1;\r\n'
                'Set-Cookie: cookie2=value2;\r\n'
                'Set-Cookie: cookie3=value3;\r\n'
                'MyHeader: value1\r\n'
                'MyHeader: value2')

    # Assert
    assert output == \
        'HTTP/1.1 200 OK\r\n' \
        'Content-Type: text/plain\r\n' \
        'Set-Cookie: cookie1=value1;\r\n'

# Generated at 2022-06-21 14:09:33.911462
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(color=False, indent=4, sort=True)
    assert not HeadersFormatter(color=False, indent=4, sort=False)


# Generated at 2022-06-21 14:09:35.406190
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert (formatter.format_options['headers']['sort'] == False)
    assert (formatter.enabled == False)


# Generated at 2022-06-21 14:09:37.213004
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hF = HeadersFormatter()
    assert hF.format_options['headers']['sort'] == hF.enabled



# Generated at 2022-06-21 14:09:42.225089
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """\
Content-Type: application/json
Accept: */*
Content-Length: 8
Host: httpbin.org
User-Agent: HTTPie/2.2.0
"""
    assert hf.format_headers(headers) == """\
Content-Type: application/json
Accept: */*
Content-Length: 8
Host: httpbin.org
User-Agent: HTTPie/2.2.0
"""



# Generated at 2022-06-21 14:09:42.999721
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter



# Generated at 2022-06-21 14:10:40.322720
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()



# Generated at 2022-06-21 14:10:50.128004
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headersFormatter = HeadersFormatter()

# Generated at 2022-06-21 14:10:50.682508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass

# Generated at 2022-06-21 14:10:55.231506
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from httpie.context import Environment
    env = Environment()
    env.session.options['headers']['sort'] = True
    plugin = HeadersFormatter(env)
    assert plugin.enabled == True
    assert plugin.format_headers("""
        GET / HTTP/1.1
        Host: localhost:8880
        Accept-Encoding: gzip, deflate
        Accept: */*
        User-Agent: HTTPie/1.0.2

    """) == """
        GET  /  HTTP/1.1\r
        Accept: */*\r
        Accept-Encoding: gzip, deflate\r
        Host: localhost:8880\r
        User-Agent: HTTPie/1.0.2\r

    """


# Generated at 2022-06-21 14:10:59.403473
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 0\r\nCookie: sessionToken=cHVaZw==') == 'HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Type: application/json\r\nCookie: sessionToken=cHVaZw=='

# Generated at 2022-06-21 14:11:10.586053
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    hh = "Content-Type:application/json\nContent-Length:123\nHost:localhost:5000\nAccept-Encoding:gzip;q=1.0,deflate;q=0.6,identity;q=0.3\nAccept:*/*\nUser-Agent:python-requests/2.22.0\n"
    one = hf.format_headers(hh)
    two = "Content-Type:application/json\nAccept:*/*\nHost:localhost:5000\nAccept-Encoding:gzip;q=1.0,deflate;q=0.6,identity;q=0.3\nUser-Agent:python-requests/2.22.0\nContent-Length:123\n"
    assert(one == two)

# Generated at 2022-06-21 14:11:16.796987
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Normal headers
    assert formatter.format_headers('Content-type: application/json\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nEtag: "12345"') == 'Content-type: application/json\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nEtag: "12345"'
    # Headers with different case

# Generated at 2022-06-21 14:11:19.865757
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    hf = HeadersFormatter()
    assert hf.enabled == False, 'Constructor initializer of HeadersFormatter is not working properly'



# Generated at 2022-06-21 14:11:22.245109
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Unit test for constructor
    hf = HeadersFormatter()
    assert isinstance(hf, HeadersFormatter)


# Generated at 2022-06-21 14:11:33.275427
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter_headers = HeadersFormatter()

    assert formatter_headers.format_headers("") == ""
    assert formatter_headers.format_headers("a:1") == "a:1"
    assert formatter_headers.format_headers("a:1\nb:2") == "a:1\nb:2"
    assert formatter_headers.format_headers("a:1\na:2") == "a:1\na:2"

    assert formatter_headers.format_headers("a:1\nb:2") == "a:1\nb:2"
    assert formatter_headers.format_headers("a:1\nb:2\nc:3") == "a:1\nb:2\nc:3"