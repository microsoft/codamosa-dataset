

# Generated at 2022-06-21 14:03:01.765690
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, FormatterPlugin)
    assert headers_formatter.enabled
    assert headers_formatter == headers_formatter


# Generated at 2022-06-21 14:03:03.404150
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-21 14:03:11.247428
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('GET / HTTP/1.1\r\nHost: example.org\r\nAccept: */*\r\nAccept: */*\r\n') == 'GET / HTTP/1.1\r\nAccept: */*\r\nAccept: */*\r\nHost: example.org\r\n'

# Generated at 2022-06-21 14:03:23.219372
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie import ExitStatus
    from utils import TestEnvironment, http
    from requests.models import PreparedRequest, Response

    class Dummy():
        def __init__(self, body):
            self.body = body

    ############################
    # Ensure method format_headers can handle response with no headers
    r = Dummy(body='test')
    if isinstance(r, Response):
        s = r.raw._fp.fp._sock
        if isinstance(s, socket.socket):
            s.__class__ = socket.socket
            s.filename = None
    hf = HeadersFormatter()
    assert hf.format_headers(r) == r.body
    ############################

    args = http('--headers')

# Generated at 2022-06-21 14:03:30.303409
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
Date: Fri, 10 Apr 2020 15:03:36 GMT
X-XSS-Protection: 0
X-Content-Type-Options: nosniff
Cache-Control: no-cache, must-revalidate
Pragma: no-cache
Expires: Sat, 26 Jul 1997 05:00:00 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 114
Keep-Alive: timeout=5
Connection: Keep-Alive"""

    print(formatter.format_headers(headers) == headers)

# Generated at 2022-06-21 14:03:31.732074
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_format = HeadersFormatter()
    assert isinstance(headers_format, FormatterPlugin)



# Generated at 2022-06-21 14:03:33.480531
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headerFormatter = HeadersFormatter()
    assert headerFormatter.enabled == False

# Generated at 2022-06-21 14:03:41.268375
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
	hf = HeadersFormatter()
	headers = """HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
X-Powered-By: PHP/7.1.26
Cache-Control: no-cache
Date: Fri, 12 Apr 2019 01:35:55 GMT
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59

"""
	hf.format_options = {'headers': {'sort': True}}
	hf.format_headers(headers)



# Generated at 2022-06-21 14:03:49.798744
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('GET /a HTTP/1.1\r\n'
                                    'Host: example.org\r\n'
                                    'Content-Type: text/plain\r\n'
                                    'Accept: application/json\r\n'
                                    'Accept: application/xml\r\n'
                                    '\r\n') == \
                                    'GET /a HTTP/1.1\r\n' \
                                    'Accept: application/json\r\n' \
                                    'Accept: application/xml\r\n' \
                                    'Content-Type: text/plain\r\n' \
                                    'Host: example.org\r\n\r\n'



# Generated at 2022-06-21 14:03:52.741770
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__name__ == 'HeadersFormatter'
    assert HeadersFormatter.__doc__ == 'Pretty formatter plugin for HTTPie.'

# Unit tests for format_headers method

# Generated at 2022-06-21 14:03:56.336181
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert isinstance(headers_formatter, FormatterPlugin)

# Generated at 2022-06-21 14:04:00.829608
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    result = hf.format_headers('HTTP/1.1 200 OK\r\nfoo: bar\r\nbar: foo\r\nspam: ham')
    assert result == 'HTTP/1.1 200 OK\r\nbar: foo\r\nfoo: bar\r\nspam: ham'
    result = hf.format_headers('HTTP/1.1 200 OK\r\nbar: foo\r\nfoo: bar\r\nspam: ham')
    assert result == 'HTTP/1.1 200 OK\r\nbar: foo\r\nfoo: bar\r\nspam: ham'

# Generated at 2022-06-21 14:04:10.647743
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    formatted_headers = headers_formatter.format_headers("""HTTP/1.1 200 OK
Server: Apache
Content-Type: text/html; charset=UTF-8
Connection: close
Date: Thu, 31 Dec 2009 20:35:27 GMT
Content-Length: 24""");

    assert formatted_headers == """HTTP/1.1 200 OK
Connection: close
Content-Length: 24
Content-Type: text/html; charset=UTF-8
Date: Thu, 31 Dec 2009 20:35:27 GMT
Server: Apache"""

# Generated at 2022-06-21 14:04:18.992118
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = '''\
Host: localhost:5000
User-Agent: HTTPie/0.9.7
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 24
'''
    assert HeadersFormatter().format_headers(headers) == '''\
Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 24
User-Agent: HTTPie/0.9.7
'''

# Generated at 2022-06-21 14:04:21.606079
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headersFormatter.enabled == True



# Generated at 2022-06-21 14:04:23.773733
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    e = HeadersFormatter()
    assert e.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-21 14:04:31.732433
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hstr = """\
HTTP/1.1 201 Created
Server: nginx/1.1.19
Date: Thu, 23 Jan 2014 15:15:29 GMT
Content-Type: application/json
Connection: keep-alive
Cache-Control: no-cache
Content-Length: 21

"""
    out = HeadersFormatter().format_headers(hstr)
    assert out == """\
HTTP/1.1 201 Created
Connection: keep-alive
Content-Length: 21
Content-Type: application/json
Date: Thu, 23 Jan 2014 15:15:29 GMT
Server: nginx/1.1.19

"""

# Generated at 2022-06-21 14:04:32.259815
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    pass

# Generated at 2022-06-21 14:04:33.118689
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()


# Generated at 2022-06-21 14:04:42.356308
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        hf = HeadersFormatter()
    with pytest.raises(TypeError):
        hf = HeadersFormatter('abc')
    with pytest.raises(TypeError):
        hf = HeadersFormatter(True)
    with pytest.raises(TypeError):
        hf = HeadersFormatter(1)
    with pytest.raises(TypeError):
        hf = HeadersFormatter(1.1)
    hf = HeadersFormatter(**{'headers': {'sort': True}})
    assert hf.enabled
    assert hf.format_options['headers']['sort']



# Generated at 2022-06-21 14:04:46.573312
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
	assert HeadersFormatter().enabled == 1

# Generated at 2022-06-21 14:04:58.799510
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter()
    headers = 'User-Agent: Httpie\r\n' \
              'Content-Encoding: UTF-8\r\n' \
              'Accept: */*\r\n' \
              'X-Im-Ur-Header: 1\r\n' \
              'X-Im-Ur-Header: 2\r\n' \
              'X-Im-Ur-Header: 3'

    assert h.format_headers(headers) == \
        'User-Agent: Httpie\r\n' \
        'Accept: */*\r\n' \
        'Content-Encoding: UTF-8\r\n' \
        'X-Im-Ur-Header: 1\r\n' \
        'X-Im-Ur-Header: 2\r\n'

# Generated at 2022-06-21 14:04:59.809758
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    pass


# Generated at 2022-06-21 14:05:02.309141
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    h = HeadersFormatter()
    assert h.format_options['headers']['sort'] is False
    assert h.enabled is False


# Generated at 2022-06-21 14:05:13.001562
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test with all keys
    hformat1 = HeadersFormatter(
        ['headers', 'sort']
    )
    assert hformat1.enabled == True, "Error in initializing HeadersFormatter with all keys"
    # test with default values - dictonary key 'sort' must be True
    hformat2 = HeadersFormatter()
    assert hformat2.enabled == True, "Error in initializing HeadersFormatter with default values"
    # test with incorrect keys - dictonary key 'sort' must be True
    hformat3 = HeadersFormatter(
        ['headers']
    )
    assert hformat3.enabled == True, "Error in initializing HeadersFormatter with incorrect keys"


# Generated at 2022-06-21 14:05:21.643782
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    from urllib.parse import urlparse
    from collections import namedtuple, OrderedDict

    class MockOutputOptions: pass
    MockOutputOptions.__dict__.update({
        'style': 'UNSET',
        'style_variables': None
    })

    MockFormatOptions = namedtuple('format_options', 'headers')
    MockFormatOptionHeaders = namedtuple('headers', 'sort')

    MockFormatOptionHeaders.__dict__.update({
        'sort': True,
    })

    MockFormatOptions.__dict__.update({
        'headers': MockFormatOptionHeaders
    })

    format_options = MockFormatOptions()
    output_options = MockOutputOptions()


# Generated at 2022-06-21 14:05:27.228174
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = 'Host: localhost:8998\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nUser-Agent: HTTPie/0.9.8\r\n'
    assert headers_formatter.format_headers(headers) == headers

# Generated at 2022-06-21 14:05:29.822416
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']



# Generated at 2022-06-21 14:05:40.288510
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Verify format_headers is a method of class HeadersFormatter
    assert isinstance(HeadersFormatter.format_headers, MethodType)
    # Verify that when format_headers is called with
    # a string containing the headers of a request,
    # the headers are returned in the order
    # in which they appear in the string
    assert formatter.format_headers("""\
POST /post HTTP/1.1
Host: www.httpbin.org
Content-Type: application/x-www-form-urlencoded
Content-Length: 11

foo=bar""") == """\
POST /post HTTP/1.1
Host: www.httpbin.org
Content-Type: application/x-www-form-urlencoded
Content-Length: 11

foo=bar"""
    # Verify

# Generated at 2022-06-21 14:05:43.047789
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options={'headers': {'sort': True}})
    assert headers_formatter.enabled
    assert headers_formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:05:54.018225
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()

# Generated at 2022-06-21 14:05:58.426798
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    instance = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert instance.__class__.__name__ in [
        'HeadersFormatter'
    ]
    assert instance.enabled == True


# Generated at 2022-06-21 14:06:05.183028
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Sort headers
    """
    headers = ('connection: close\r\n'
               'content-type: application/json\r\n'
               'transfer-encoding: chunked\r\n'
               'content-encoding: gzip')
    sorted_headers = ('connection: close\r\n'
                      'content-encoding: gzip\r\n'
                      'content-type: application/json\r\n'
                      'transfer-encoding: chunked')
    assert HeadersFormatter.format_headers(headers) == sorted_headers

# Generated at 2022-06-21 14:06:08.338507
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    with pytest.raises(TypeError):
        HeadersFormatter(stream=sys.stdout)

    with pytest.raises(TypeError):
        HeadersFormatter(options=dict(pretty=True))



# Generated at 2022-06-21 14:06:09.926625
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter(
        format_options={'headers':{'sort': True}},
    )


# Generated at 2022-06-21 14:06:11.150510
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj = HeadersFormatter()
    assert obj.enabled


# Generated at 2022-06-21 14:06:12.294069
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter()
    assert headers.enabled == True


# Generated at 2022-06-21 14:06:18.861168
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    h = HeadersFormatter(format_options=DEFAULT_FORMAT_OPTIONS)
    expected = (
        'HTTP/1.1 200 OK\r\n'
        'Server: nginx\r\n'
        'Content-Length: 17\r\n'
        'Content-Type: application/json\r\n'
        'Connection: keep-alive\r\n'
        'X-Foo: Bar\r\n'
        'X-Foo: Baz\r\n'
        'X-Bar: Foo\r\n'
    )
    actual = h.format_headers(expected)
    assert expected == actual
    assert 'X-Foo: Bar' in actual
    assert 'X-Foo: Baz' in actual

# Generated at 2022-06-21 14:06:30.318092
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

# Generated at 2022-06-21 14:06:31.547227
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # test_HeadersFormatter_object_created_successfully()
    headers_formatter = HeadersFormatter()
    assert headers_formatter



# Generated at 2022-06-21 14:06:55.285079
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:07:02.581679
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter_plugin = HeadersFormatter()
    headers = """\
HTTP/1.1 200 OK
content-length: 35
content-type: text/html; charset=utf-8
connection: close
set-cookie: csrftoken=uw7NO3RZG10i0s1xCmCYYI8nKZF0j8oT; expires=Sun, 08-Mar-2020 10:51:55 GMT; Max-Age=31449600; Path=/
date: Tue, 28-Jan-2020 10:51:55 GMT
server: WSGIServer/0.2 CPython/3.6.9
x-frame-options: SAMEORIGIN"""

    result = formatter_plugin.format_headers(headers)

# Generated at 2022-06-21 14:07:04.321550
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headf = HeadersFormatter()
    assert(headf.enabled)


# Generated at 2022-06-21 14:07:06.746123
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(
        format_options=dict(headers=dict(sort=False)))
    assert not headers_formatter.enabled



# Generated at 2022-06-21 14:07:08.892443
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter(format_options='sort')
    assert formatter.format_options == 'sort'


# Generated at 2022-06-21 14:07:17.826910
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    class HeadersFormatter():
        format_options = {'headers': {'headers': {'sort': True}}}
        def __init__(self, **kwargs):
            pass
            #super(HeadersFormatter, self).__init__(**kwargs)
            #self.enabled = self.format_options['headers']['sort']

        def format_headers(self, headers):
            lines = headers.splitlines()
            headers = sorted(lines[1:], key=lambda h: h.split(':')[0])
            return '\r\n'.join(lines[:1] + headers)


# Generated at 2022-06-21 14:07:27.074467
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Vary: Accept-Encoding
Connection: close
Content-Type: text/plain
X-My-Custom-Header: foo
X-Another-Custom-Header: bar
'''

# Generated at 2022-06-21 14:07:29.131508
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().format_options == {'headers': {'sort': False}}

# Generated at 2022-06-21 14:07:39.603386
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from io import BytesIO
    from requests.packages.urllib3.response import HTTPResponse
    
    # Headers in the order of appearance in request
    test_headers_str = '''\
x-amz-id-2: H0SAhGKf0DibtCmfDPa/1ldRdM+/ZH/oM3qo3YOJN1e5O5cKj+U6dKUq3X9CvJ8xDlg7VuYfKGc=
x-amz-request-id: E36BC9BC7FE8D6C4
Date: Tue, 27 Nov 2018 23:30:08 GMT
x-amz-bucket-region: us-east-2
Server: AmazonS3
'''
    # Headers

# Generated at 2022-06-21 14:07:50.358490
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Vary: Accept
Content-Length: 20
Connection: keep-alive
Content-Encoding: gzip

'''
    expected_headers = headers.splitlines()
    expected_headers = '\r\n'.join(sorted(expected_headers[1:], key=lambda h: h.split(':')[0]))
    expected_headers = headers.splitlines()[0] + '\r\n' + expected_headers
    assert formatter.format_headers(headers) == expected_headers


if __name__ == '__main__':
    test_HeadersFormatter_format_headers()

# Generated at 2022-06-21 14:08:34.679945
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headerFormatter = HeadersFormatter()
    assert headerFormatter.enabled == True


# Generated at 2022-06-21 14:08:37.267761
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']



# Generated at 2022-06-21 14:08:39.205349
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter(format_options= {'headers' : {'sort' : False}})


# Generated at 2022-06-21 14:08:46.476092
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    test = HeadersFormatter()
    assert test.format_headers('abc\n') == 'abc\n'
    assert test.format_headers('abc\na: b\n') == 'abc\na: b\n'
    assert test.format_headers('abc\nc: b\na: d\n') == 'abc\na: d\nc: b\n'
    assert test.format_headers('abc\nc: b\na: d\na: e\n') == 'abc\na: d\na: e\nc: b\n'
    assert test.format_headers('abc\nc: b\na: d\na: e\na: c\n') == 'abc\na: d\na: e\na: c\nc: b\n'

# Generated at 2022-06-21 14:08:49.845935
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert callable(HeadersFormatter)
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-21 14:08:58.170372
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    def check(headers: str, expected: str) -> None:
        formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
        actual = formatter.format_headers(headers)
        assert actual == expected, '\nExpected: {}\nActual: {}\n'.format(expected, actual)


    headers = '''\
Connection: keep-alive
User-Agent: HTTPie/1.0.3
Accept-Encoding: gzip, deflate
Accept: */*
Host: httpbin.org
'''
    check(headers, '\r\n'.join(sorted(headers.splitlines())))


# Generated at 2022-06-21 14:09:00.400399
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    obj_HeadersFormatter = HeadersFormatter()
    assert isinstance(obj_HeadersFormatter, HeadersFormatter)

# Generated at 2022-06-21 14:09:04.511939
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = HeadersFormatter(format_options={'headers': {'sort': True}})
    assert headers.enabled

    headers = HeadersFormatter(format_options={'headers': {'sort': False}})
    assert not headers.enabled



# Generated at 2022-06-21 14:09:09.479950
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    plugin = HeadersFormatter()
    text = '''\
User-Agent: TestApp/1.0.0
Foo: Baz
Bar: Bar
Foo: Foo'''
    expected_text = '''\
User-Agent: TestApp/1.0.0
Bar: Bar
Foo: Baz
Foo: Foo'''
    assert expected_text == plugin.format_headers(text)

# Generated at 2022-06-21 14:09:14.882839
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headersFormatTest = HeadersFormatter(host="httpbin.org", port=80, scheme="https", format_options={}, https=True, user_agent="BingBot", verbose=False, body={})
    expected_dict = {'host': 'httpbin.org', 'port': 80, 'scheme': 'https', 'format_options': {}, 'https': True, 'user_agent': 'BingBot', 'verbose': False, 'body': {}}
    assert type(headersFormatTest) == HeadersFormatter
    assert headersFormatTest.__dict__ == expected_dict


# Generated at 2022-06-21 14:10:12.528708
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers = '"My-Header: my-value\\r\\nAnother-Header: other-value"\n'
    formatter = HeadersFormatter(format_options=dict(headers=dict(sort=True)))
    result = formatter.format_headers(headers)
    assert result == '"My-Header: my-value\\r\\nAnother-Header: other-value"\n'
    assert type(result) == str


# Generated at 2022-06-21 14:10:22.654388
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test the format_headers method of the HeadersFormatter class with
    headers that are unsorted.

    """
    formatter = HeadersFormatter()
    headers = ('HTTP/1.1 200 OK\r\n'
               'Content-Type: application/json; charset=utf-8\r\n'
               'Content-Length: 13\r\n'
               'Host: localhost:8000\r\n'
               'X-Powered-By: Django\r\n'
               'Connection: keep-alive\r\n\r\n'
               '{"name":"John"}\r\n'
               )

    # Remove the trailing newline character

# Generated at 2022-06-21 14:10:28.262199
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    headers = '''POST / HTTP/1.1
User-Agent: HTTPie
Cookie: foo=bar
Cookie: bar=baz
'''
    expected_headers = '''POST / HTTP/1.1
Cookie: foo=bar
Cookie: bar=baz
User-Agent: HTTPie
'''
    assert headers_formatter.format_headers(headers) == expected_headers

# Generated at 2022-06-21 14:10:29.845707
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': True}})
    assert formatter.enabled

# Generated at 2022-06-21 14:10:31.307060
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter(format_options={"headers": {"sort": True}})
    assert headers_formatter.format_options["headers"]["sort"]

headers_formatter = HeadersFormatter

# Generated at 2022-06-21 14:10:35.874489
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    tf = HeadersFormatter()
    headers_in = 'GET / HTTP/1.1\r\nCache-Control: no-cache\r\nAccept: */*\r\nUser-Agent: HTTPie/1.0.2'
    headers_out = 'GET / HTTP/1.1\r\nAccept: */*\r\nCache-Control: no-cache\r\nUser-Agent: HTTPie/1.0.2'
    assert tf.format_headers(headers_in) == headers_out

# Generated at 2022-06-21 14:10:38.960681
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter({'headers': {'sort': True}})

    assert formatter.format_options['headers']['sort'] == True
    assert formatter.enabled == True



# Generated at 2022-06-21 14:10:48.486901
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    assert formatter.format_headers('Accept: application/json\r\nContent-Type: application/json\r\n') == 'Accept: application/json\r\nContent-Type: application/json\r\n'
    assert formatter.format_headers('Content-Type: application/json\r\nAccept: application/json\r\n') == 'Accept: application/json\r\nContent-Type: application/json\r\n'
    assert formatter.format_headers('Content-Type: application/json\r\nAccept: application/json\r\nAccept: application/json\r\n') == 'Accept: application/json\r\nAccept: application/json\r\nContent-Type: application/json\r\n'


# Generated at 2022-06-21 14:10:50.558528
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == formatter.format_options['headers']['sort']


# Generated at 2022-06-21 14:10:51.411232
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter is not None


# Generated at 2022-06-21 14:12:59.969196
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = """\
Content-Type: application/json
ETag: "a"
ETag: "b"
ETag: "c"
"""
    expected = """\
Content-Type: application/json
ETag: "a"
ETag: "b"
ETag: "c"
"""
    assert hf.format_headers(headers) == expected