

# Generated at 2022-06-21 14:02:59.115117
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  pass



# Generated at 2022-06-21 14:03:07.161450
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatted_headers = HeadersFormatter().format_headers(
        'Content-Type: application/json\r\n'
        'Authorization: Basic 123\r\n'
        'Accept-Language: en\r\n'
        'Accept: application/json'
    )
    assert formatted_headers == (
        'Content-Type: application/json\r\n'
        'Authorization: Basic 123\r\n'
        'Accept-Language: en\r\n'
        'Accept: application/json'
    )


# Generated at 2022-06-21 14:03:11.460753
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('''\
HTTP/1.1 200 OK
content-length: 99
Content-Type: application/json; charset=utf-8
Content-Type: application/pdf

{}''') == '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Type: application/pdf
content-length: 99

{}'''

# Generated at 2022-06-21 14:03:15.116031
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
        assert formatter.enabled is True
    except:
        raise Exception



# Generated at 2022-06-21 14:03:16.158493
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert True



# Generated at 2022-06-21 14:03:18.205434
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    assert formatter.enabled == False


# Generated at 2022-06-21 14:03:28.514848
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Test HeadersFormatter constructor
    """
    # Create a sample arg parser
    arg_parser = argparse.ArgumentParser()
    # Add a sample argument
    arg_parser.add_argument('--headers', default='', type=str)
    # Create sample args from the argument parser
    args = arg_parser.parse_args()
    # Create a sample options object with that argument
    options = object()
    options.headers = args.headers
    # Create a format_options dict with the options
    format_options = dict()
    format_options['headers'] = options
    # Create a HeadersFormatter object with the format options
    headersFormatter = HeadersFormatter(format_options=format_options)
    # Check the constructor worked by checking that the enabled property is equal to the sort option
    assert headersFormatter.enabled

# Generated at 2022-06-21 14:03:29.607201
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter('headers').enabled is True


# Generated at 2022-06-21 14:03:36.511190
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    fmt = HeadersFormatter()
    assert fmt.format_headers(headers_1) == headers_2

# The following cases cover the range of headers that we want to format
#   - Headers with multiple instances of the same header name
#   - Headers with continuation lines
#   - Headers with leading/trailing spaces
#   - Headers with empty lines
headers_1 = """\
HTTP/1.1 200 OK
Content-Type: text/plain
Date: Mon, 23 Apr 2018 23:19:15 GMT
Server: Apache/2.4.18 (Amazon) OpenSSL/1.0.2k-fips PHP/5.6.31
Vary: Cookie

"""


# Generated at 2022-06-21 14:03:47.000552
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Testing the method format_headers of class HeadersFormatter in plugin.py
    """
    formatter1 = HeadersFormatter()
    header1 = ('\r\n'
               'Content-Type: application/json\r\n'
               'Set-Cookie: A=B\r\n'
               'Set-Cookie: C=D\r\n'
               'Set-Cookie: E=F\r\n'
               'Aaa: BBB\r\n'
               'Zzz: XXX\r\n')

# Generated at 2022-06-21 14:03:58.632288
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter(format_options={'headers':{'sort':True}})

# Generated at 2022-06-21 14:04:08.957975
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = 'HTTP/1.1 200 OK\r\nContent-Length: 17\r\nContent-Type: text/html\r\nSet-Cookie: session1=abcde; path=/;\r\nSet-Cookie: session2=xyz; path=/;'
    # call the method format_headers
    assert hf.format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-Length: 17\r\nContent-Type: text/html\r\nSet-Cookie: session2=xyz; path=/;\r\nSet-Cookie: session1=abcde; path=/;'

# Generated at 2022-06-21 14:04:11.182901
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter().__class__.__name__ == 'HeadersFormatter'



# Generated at 2022-06-21 14:04:12.252289
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-21 14:04:13.311017
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter() != None


# Generated at 2022-06-21 14:04:22.031814
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    assert HeadersFormatter().format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'Transfer-Encoding: chunked',
        'Set-Cookie: c=a',
        'Set-Cookie: b=c',
        'Set-Cookie: a=d'
    ])) == '\r\n'.join((
        'HTTP/1.1 200 OK',
        'Set-Cookie: c=a',
        'Set-Cookie: b=c',
        'Set-Cookie: a=d',
        'Transfer-Encoding: chunked',
    ))


# Generated at 2022-06-21 14:04:28.762194
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nAccept: *" \
              "/*\r\nContent-Length: 17\r\n"
    assert(formatter.format_headers(headers) == \
            "HTTP/1.1 200 OK\r\nAccept: */*\r\nContent-Length: 17" \
            "\r\nContent-Type: text/plain\r\n")



# Generated at 2022-06-21 14:04:36.667939
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter(format_options={'headers': {}})
    assert hf.format_headers('C: 1\r\nB: 2\r\nA: 3') == 'C: 1\r\nB: 2\r\nA: 3'
    assert hf.format_headers('C: 1\r\nB: 2\r\nA: 3\r\nB: 4') == 'C: 1\r\nB: 2\r\nB: 4\r\nA: 3'
    assert hf.format_headers('B: 2\r\nA: 3\r\nB: 4') == 'B: 2\r\nB: 4\r\nA: 3'

# Generated at 2022-06-21 14:04:40.490586
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    
    class args():
        def __init__(self):
            self.verbose = 1
            self.headers = {'sort' : 1}
            
    headers_formatter = HeadersFormatter(args)

    assert headers_formatter.enabled == 1



# Generated at 2022-06-21 14:04:47.093882
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    header_lines = ['Content-Type: text/html', 'Content-Length: 0', '', 'Other: something']
    assert headers_formatter.format_headers('\n'.join(header_lines)) == '\n'.join(header_lines)

    header_lines = ['Content-Length: 0', 'Content-Type: text/html', '', 'Other: something']
    assert headers_formatter.format_headers('\n'.join(header_lines)) == '\n'.join(['Content-Length: 0', 'Content-Type: text/html', '', 'Other: something'])

# Generated at 2022-06-21 14:04:59.299229
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    formatter.format_options = {'headers': {'sort': True}}
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 15
Content-Length: 10
Connection: Close
Connection: Keep-Alive
'''
    expected = '''\
HTTP/1.1 200 OK
Connection: Close
Connection: Keep-Alive
Content-Length: 15
Content-Length: 10
Content-Type: application/json; charset=utf-8
'''
    assert formatter.format_headers(headers) == expected



# Generated at 2022-06-21 14:05:06.304300
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test function for the method format_headers of the class HeadersFormatter.
    """
    h = HeadersFormatter()
    header1 = 'header : header'
    header2 = 'header2 : header2'
    header3 = 'header3 : header3'
    headers = '\r\n'.join([header1, header2, header3])
    assert h.format_headers(headers) == '\r\n'.join([header1, header3, header2])


# Generated at 2022-06-21 14:05:17.736506
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    import io
    from httpie.compat import is_py26

    formatter = HeadersFormatter(format_options={'headers': {'sort': True}})
    formatter.stdout = io.StringIO()

    headers = '''\
    HTTP/1.1 200 OK
    Content-Type: application/json
    Vary: Accept-Language, Cookie
    Vary: Accept-Encoding
    Content-Language: en
    Content-Length: 1234
    '''
    res = formatter.format_headers(headers)
    assert res == '''\
    HTTP/1.1 200 OK
    Content-Language: en
    Content-Length: 1234
    Content-Type: application/json
    Vary: Accept-Language, Cookie
    Vary: Accept-Encoding
    '''

# Generated at 2022-06-21 14:05:18.648308
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter, object)



# Generated at 2022-06-21 14:05:19.903323
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    head = HeadersFormatter()
    assert head.enabled


# Generated at 2022-06-21 14:05:28.534649
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = ('Content-Type: application/json\r\n'
               'Connection: keep-alive\r\n'
               'Keep-Alive: timeout=5\r\n'
               'Content-Type: application/xml\r\n')
    expected = ('Content-Type: application/json\r\n'
                'Content-Type: application/xml\r\n'
                'Connection: keep-alive\r\n'
                'Keep-Alive: timeout=5\r\n')
    assert expected == HeadersFormatter().format_headers(headers)



# Generated at 2022-06-21 14:05:39.456000
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers = HeadersFormatter()
    test_input_text = """\
HTTP/1.1 200 OK
Cache-Control: max-age=0, private, must-revalidate
Content-Length: 661
Content-Type: application/json; charset=utf-8
ETag: "0c800b70f9445a68764c2d443b81efb6"
Server: WEBrick/1.3.1 (Ruby/2.3.1/2016-04-26)
X-Request-Id: aa0d6d65-eda2-45c2-b7f9-a9cb8f449770
X-Runtime: 0.056281
Bender: an awesome robot
Fry: a cool guy
Leela: not cool.
"""

# Generated at 2022-06-21 14:05:49.281437
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()

    # simple test, tested again in other test
    assert hf.format_headers('HTTP/1.1 200 OK\r\nabc: 1\r\nx-X: 2\r\n') == 'HTTP/1.1 200 OK\r\nabc: 1\r\nx-X: 2\r\n'

    # space between colon and value is preserved
    assert hf.format_headers('HTTP/1.1 200 OK\r\nabc: 1\r\nx-X: 2 \r\n') == ('HTTP/1.1 200 OK\r\n'
                                                                              'abc: 1\r\n'
                                                                              'x-X: 2 \r\n')

    # no space between colon and value is preserved

# Generated at 2022-06-21 14:05:50.375245
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter()


# Generated at 2022-06-21 14:05:57.695716
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    f = HeadersFormatter()
    h = f.format_headers("""
HTTP/1.1 200 OK
Content-Type: text/html
B: 2
B: 1
A: 1
A: 2
""".strip('\n'))

    assert h == """
HTTP/1.1 200 OK
A: 1
A: 2
B: 2
B: 1
Content-Type: text/html
""".strip('\n')

# Generated at 2022-06-21 14:06:11.352005
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    actual = formatter.format_headers("""Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8082
User-Agent: HTTPie/0.9.4\r\n""")
    expected = """Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost:8082
User-Agent: HTTPie/0.9.4\r\n"""
    assert actual == expected


# Generated at 2022-06-21 14:06:15.049643
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    """
    Unit test for constructor of class HeadersFormatter
    """
    try:
        obj=HeadersFormatter()
        print(obj.__dict__)
    except Exception as error:
        print(
            'Error in HeadersFormatter.__init__(): {}'.format(
                str(error)
            )
        )

# Test function

# Generated at 2022-06-21 14:06:17.809119
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Test case  1
    hf = HeadersFormatter()
    assert hf.enabled, \
        "Expected: 'True', Actual: 'False'"



# Generated at 2022-06-21 14:06:21.704722
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        HF = HeadersFormatter()
    except AttributeError:
        print("TEST FAILED - HeadersFormatter")
        return
    print("TEST PASSED - HeadersFormatter")


#Unit test for format_headers method of class HeadersFormatter

# Generated at 2022-06-21 14:06:33.542622
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()

    """
    Test case with multiple headers with the same name
    (from https://enable-cors.org/server_nginx.html)
    """
    headers = """\
Access-Control-Allow-Credentials:true
Access-Control-Allow-Origin:*
Access-Control-Allow-Origin:http://example.com
Access-Control-Allow-Methods:PUT, DELETE
Access-Control-Allow-Headers:X-Custom-Header, Upgrade-Insecure-Requests
Access-Control-Max-Age:123"""

# Generated at 2022-06-21 14:06:35.502967
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        formatter = HeadersFormatter()
    except:
        assert False


# Generated at 2022-06-21 14:06:40.856091
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    hf = HeadersFormatter()
    headers = '''Content-Type: text/plain; charset=utf-8
Content-Length: 14
Connection: keep-alive
Date: Mon, 02 Dec 2013 14:38:08 GMT
Server: gunicorn/18.0'''

# Generated at 2022-06-21 14:06:53.206624
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    # Order is not important
    assert formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 5\r\n') == 'HTTP/1.1 200 OK\r\nContent-Length: 5\r\nContent-Type: application/json\r\n'
    # But order of headers with the same name is important

# Generated at 2022-06-21 14:06:55.017884
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    x = HeadersFormatter(headers_sort=True)
    assert x.enabled == True


# Generated at 2022-06-21 14:06:57.546102
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    headers_formatter = HeadersFormatter()
    assert headers_formatter.enabled == headers_formatter.format_options['headers']['sort']
    assert headers_formatter.enabled == False


# Generated at 2022-06-21 14:07:17.370809
# Unit test for method format_headers of class HeadersFormatter

# Generated at 2022-06-21 14:07:19.161448
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f1 = HeadersFormatter()
    assert f1.format_options['headers']['sort'] == False

# Generated at 2022-06-21 14:07:27.930906
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Sort headers with multiple headers of the same name:
    my_headers = '''\
        HTTP/1.1 200 OK
        Date: Mon, 27 Jul 2009 12:28:53 GMT
        Server: Apache
        Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
        ETag: "34aa387-d-1568eb00"
        Accept-Ranges: bytes
        Vary: Accept-Encoding
        Content-Encoding: gzip
        Content-Length: 51
        Connection: close
        Content-Type: text/html
        Set-Cookie: name=value
        Set-Cookie: name=value
        '''

# Generated at 2022-06-21 14:07:39.061042
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Given
    h = '''\
{
    "Host": "httpbin.org",
    "accept": "application/json",
    "Connection": "keep-alive",
    "User-Agent": "HTTPie/0.9.8",
    "Accept-Encoding": "gzip, deflate"
}
'''
    # When
    s = HeadersFormatter().format_headers(h)
    # Then
    assert isinstance(s, str)
    exp = '''\
{
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
    "Host": "httpbin.org",
    "User-Agent": "HTTPie/0.9.8",
    "accept": "application/json"
}
'''
    assert s == exp

# Generated at 2022-06-21 14:07:50.692920
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    from httpie.plugins import builtin
    builtin.plugins.register(HeadersFormatter, 'format_headers')
    headers = '''\
GET / HTTP/1.1
Content-Type: application/json
User-Agent: HTTPie/0.9.9
Accept: application/json
Accept-Encoding: gzip, deflate, compress
Connection: keep-alive
Host: httpbin.org
Origin: httpbin.org
Referer: http://httpbin.org/
Accept-Language: en
Accept-Charset: utf-8, iso-8859-1;q=0.5
DNT: 1
Content-Length: 0'''

# Generated at 2022-06-21 14:07:56.324240
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Arrange
    headers_input = '''\
HTTP/1.0 200 OK
X-Powered-By: Flask
Content-Type: text/html; charset=utf-8
Content-Length: 26
Set-Cookie: session=eyJfcGVybWFuZW50IjogZmFsc2V9.D8WUQg.1SccmD6oFuzN8Ww7Vq3KO5u5QVs; HttpOnly; Path=/
Server: Werkzeug/0.15.6 Python/3.7.5
Date: Fri, 19 Jul 2019 16:41:45 GMT\
'''

# Generated at 2022-06-21 14:08:01.898257
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Init
    formatter = HeadersFormatter()

    # Test
    headers = formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'b: 1',
        'A: 2'
    ]))

    assert headers == '\r\n'.join([
        'HTTP/1.1 200 OK',
        'A: 2',
        'b: 1',
    ])



# Generated at 2022-06-21 14:08:03.438638
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    a = HeadersFormatter()
    assert a.format_options['headers']['sort'] == False


# Generated at 2022-06-21 14:08:08.063838
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    kwargs = {'format_options': {'headers': {'sort': True}}}
    h = HeadersFormatter(**kwargs)
    assert h.enabled == True
    assert h.format_options == {'headers': {'sort': True}}


# Generated at 2022-06-21 14:08:11.683207
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    formatter = HeadersFormatter()
    result = formatter.format_headers('HTTP/1.1 200 OK\r\n'
                                      'Content-Length: 123\r\n'
                                      'X-Auth-Token: 123\r\n'
                                      'Accept: */*\r\n'
                                      'Content-Type: text/html; charset=utf-8\r\n'
                                      'Cache-Control: max-age=0\r\n'
                                      'Connection: close')
    assert 'Cache' in result
    assert result.index('Cache') < result.index('X-')

# Generated at 2022-06-21 14:08:36.403452
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()

# Generated at 2022-06-21 14:08:37.683316
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert HeadersFormatter.__init__



# Generated at 2022-06-21 14:08:39.289677
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-21 14:08:44.856652
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formatter = HeadersFormatter()
    res = formatter.format_headers('GET / HTTP/1.1\r\nhost: www.google.co.in\r\nconnection: close\r\naccept-language: en-US,en;q=0.9,hi;q=0.8')
    assert res == 'GET / HTTP/1.1\r\naccept-language: en-US,en;q=0.9,hi;q=0.8\r\nconnection: close\r\nhost: www.google.co.in'


# Generated at 2022-06-21 14:08:47.137774
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    formats = {
        'headers': {'sort': True}
    }
    HeadersFormatter(formats)


# Generated at 2022-06-21 14:08:49.689924
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert isinstance(HeadersFormatter(), HeadersFormatter)


# Generated at 2022-06-21 14:08:59.186687
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():

    # Test case 1:
    h1 = """\
Host: 127.0.0.1
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
Content-Length: 0\
    """
    h2 = """\
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 0
Host: 127.0.0.1
User-Agent: HTTPie/0.9.2\
    """
    assert HeadersFormatter.format_headers(h1) == h2

    # Test case 2:

# Generated at 2022-06-21 14:09:00.548670
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    H = HeadersFormatter()
    assert H.enabled == True


# Generated at 2022-06-21 14:09:10.604505
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # GIVEN
    formatter = HeadersFormatter(format_options={'headers': 
        { 'sort': True }})
    original = """GET / HTTP/1.1
Accept: application/json
Cache-Control: no-cache, no-store
Content-Type: application/json
Host: example.com
Connection: close
Upgrade-Insecure-Requests: 1
User-Agent: Test

"""
    expected = """GET / HTTP/1.1
Accept: application/json
Cache-Control: no-cache, no-store
Connection: close
Content-Type: application/json
Host: example.com
Upgrade-Insecure-Requests: 1
User-Agent: Test

"""
    # WHEN
    actual = formatter.format_headers(original)
    # THEN
    assert actual == expected



# Generated at 2022-06-21 14:09:20.606839
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    args = Namespace()
    args.headers = True
    args.headers_sort = True
    # Create HeadersFormatter object
    headers_formatter = HeadersFormatter(args)
    # Store headers for test case
    multiple_lines = (
        'Content-Type: application/json\r\n'
        'Content-Length: 8\r\n'
        'Cache-Control: no-cache\r\n'
        'Authorization: Basic 123456'
    )
    # Perform the test
    output = headers_formatter.format_headers(multiple_lines)
    # Check the output

# Generated at 2022-06-21 14:10:21.768423
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    raw_headers = '''\
HTTP/1.1 200 OK
Date: Wed, 04 Mar 2020 09:15:46 GMT
Server: Apache/2.4.18 (Ubuntu)
X-Powered-By: PHP/7.0.33
Content-Length: 341
Connection: close
Content-Type: application/json
X-Powered-By: ASP.NET
Allow: GET, HEAD, POST, PUT, DELETE, TRACE, OPTIONS, PATCH
Cache-Control: private, s-maxage=0'''

# Generated at 2022-06-21 14:10:29.320508
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    """
    Test for method format_headers of class HeadersFormatter
    """
    headers = 'HTTP/1.1 200 OK\nContent-Type: text/html; charset=UTF-8\nConnection: keep-alive\n\n'

    hf = HeadersFormatter(format_options={'headers': {'sort': True}})
    formatted_headers = hf.format_headers(headers)
    assert formatted_headers == 'HTTP/1.1 200 OK\r\nConnection: keep-alive\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n'

# Generated at 2022-06-21 14:10:31.503878
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled is True
    assert f.format_options['headers']['sort'] is True


# Generated at 2022-06-21 14:10:32.328980
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    HeadersFormatter()


# Generated at 2022-06-21 14:10:34.894371
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    # Initialization
    formatter_plugin = HeadersFormatter()
    assert formatter_plugin.enabled is True


# Generated at 2022-06-21 14:10:43.969358
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    # Setup
    formatter = HeadersFormatter()

    # Exercise and verify
    assert '\r\n'.join([
        'HTTP/1.1 200 OK',
        'foo: 1',
        'bar: 2',
    ]) == formatter.format_headers('\r\n'.join([
        'HTTP/1.1 200 OK',
        'bar: 2',
        'foo: 1',
    ]))


# Generated at 2022-06-21 14:10:47.105000
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        assert HeadersFormatter(format_options={"headers": {"sort": True}})
    except AssertionError:
        print("Test HeadersFormatter fails")
        return


# Generated at 2022-06-21 14:10:50.325636
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    try:
        formatter = HeadersFormatter(verbose=True)
        assert formatter is not None
    except Exception as error:
        print("Unit test exception occurred launching constructor of HeadersFormatter")
        print(str(error))


# Generated at 2022-06-21 14:10:51.218556
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
  assert HeadersFormatter != None


# Generated at 2022-06-21 14:10:52.279285
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():

    # Calling method
    formatter = HeadersFormatter()

    # Assertion
    assert formatter.enabled == True

# Generated at 2022-06-21 14:12:52.362852
# Unit test for method format_headers of class HeadersFormatter
def test_HeadersFormatter_format_headers():
    headers_formatter = HeadersFormatter()
    formatted_headers = headers_formatter.format_headers(unformatted_headers)
    assert formatted_headers == formatted_headers_expected


# Fixture of unformatted headers
unformatted_headers = """
HTTP/1.1 200 OK
Date: Tue, 18 Jul 2017 20:31:13 GMT
Server: Apache/2.4.10 (Ubuntu)
Vary: Accept-Encoding
Content-Length: 1934
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=UTF-8

"""

# Fixture of expected result after applying method format_headers

# Generated at 2022-06-21 14:12:55.492870
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    assert not HeadersFormatter(format_options={'headers': {'sort': False}}).enabled
    assert not HeadersFormatter(format_options={'headers': {'sort': True}}).enabled


# Generated at 2022-06-21 14:12:56.675477
# Unit test for constructor of class HeadersFormatter
def test_HeadersFormatter():
    f = HeadersFormatter()
    assert f.enabled == False
