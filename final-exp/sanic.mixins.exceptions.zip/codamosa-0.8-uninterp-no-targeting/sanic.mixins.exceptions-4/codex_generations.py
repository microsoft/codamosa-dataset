

# Generated at 2022-06-21 23:09:29.517816
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    class MyApp(ExceptionMixin, Sanic):
        pass

    app = MyApp()

    @app.exception(Exception)
    def test(request, exception):
        return exception

    assert app.error_handler.has_handler_for(Exception) is True
    assert app.error_handler.has_handler_for(KeyError) is False
    assert app.error_handler.handlers[Exception] == test
    assert len(app.error_handler.handlers) == 1
    assert FutureException(test, (Exception,)) in app._future_exceptions



# Generated at 2022-06-21 23:09:36.657123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    @Blueprint.exception(TypeError, apply = True)
    def exception_handler(request, exception):
        return text(*exception.args)
    bp = Blueprint('test1')
    assert bp._future_exceptions == {FutureException(exception_handler, (TypeError))}


# Generated at 2022-06-21 23:09:39.415286
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = TestExceptionMixin()
    assert test
    assert test._future_exceptions == set()

# Generated at 2022-06-21 23:09:42.864761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # blueprint = Blueprint()
    # blueprint.exception(ZeroDivisionError)(ZeroDivisionError)
    # blueprint._future_exceptions == {(ZeroDivisionError)}
    assert True

# Generated at 2022-06-21 23:09:46.074750
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    test = Blueprint('test')
    assert isinstance(test, ExceptionMixin)

# Generated at 2022-06-21 23:09:48.784645
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:09:58.491957
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler():
        print("handler")
    arguments_exception = [Exception]
    arguments_apply = True
    arguments_handler = handler
    test_exception_mixin = get_ExceptionMixin_fake_instance()
    result_exception_mixin_exception = test_exception_mixin.exception(*arguments_exception, apply=arguments_apply)(arguments_handler)
    assert result_exception_mixin_exception == arguments_handler


# Generated at 2022-06-21 23:10:02.653142
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionmixin = ExceptionMixin()
    assert exceptionmixin._future_exceptions == set()


# Generated at 2022-06-21 23:10:07.040917
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestStudent:
        def __init__(self, name = '', id = 0):
            self.name = name
            self.id = id
    assert ExceptionMixin().exception(TestStudent)



# Generated at 2022-06-21 23:10:16.477377
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exceptions_mixin = MyExceptionMixin()
    # test exception tuple
    exceptions_mixin.exception(Exception)(lambda x: x)
    assert len(exceptions_mixin._future_exceptions) == 1

    # test excetion list
    exceptions_mixin.exception([Exception])(lambda x: x)
    assert len(exceptions_mixin._future_exceptions) == 2

    # test excetion list and tuple
    exceptions_mixin.exception([Exception], (Exception,))(lambda x: x)
    assert len(exceptions_mixin._future_exceptions) == 3

    # test excetion list, tuple and function
    exceptions_mixin.ex

# Generated at 2022-06-21 23:10:30.252166
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint, _match_for_exceptions
    from sanic.handlers import ErrorHandler

    a = Blueprint('b1')

    @a.exception(Exception)
    def exception_handler(request, exception):
        pass

    request = object()

    # test case _match_for_exceptions
    error_exception = Exception()
    error_handler = a._future_exceptions.pop()
    assert _match_for_exceptions(Exception, error_exception, error_handler)

    # test case _apply_exception_handler
    a._apply_exception_handler(error_handler)
    assert ErrorHandler._error_handlers[Exception]



# Generated at 2022-06-21 23:10:33.901540
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint.create(__name__)
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:10:43.973334
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    test_ExceptionMixin_exception is the unit test function for exception function of class ExceptionMixin
    """

    # Initialize the ExceptionMixin instance to test
    test_exception_mixin = ExceptionMixin()

    # Test normal condition
    class test_exception1(Exception):
        pass

    def test_function1():
        pass

    def test_decorator1(handler):
        nonlocal apply
        nonlocal exceptions

        exceptions = (test_exception1,)

        future_exception = FutureException(handler, exceptions)
        test_exception_mixin._future_exceptions.add(future_exception)
        return handler

    test_function1 = test_exception_mixin.exception(test_exception1)(test_function1)
    assert test_function1 == test_decor

# Generated at 2022-06-21 23:10:53.912188
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException, abort
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from unittest.mock import patch

    def handler(request: Request, exception: SanicException) -> HTTPResponse:
        return abort(code=500, message='Some error')

    @patch.object(Blueprint, 'add_exception_handler')
    def test(add_exception_handler_mock, *args, **kwargs):

        async def handler(request: Request, exception: SanicException) -> HTTPResponse:  # noqa
            return abort(code=500, message='Some error')

        bp = Blueprint(*args, **kwargs)

# Generated at 2022-06-21 23:11:00.808704
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            import sanic
            handler.apply(sanic.Sanic())

    app_blueprint = TestExceptionMixin()

    @app_blueprint.exception(InvalidUsage)
    def ignore_invalid_usage(request, exception):
        return text("You did something wrong!")

    def test_ignore_invalid_usage(request, exception):
        return text("You did something wrong!")

    # Test for ExceptionMixin.exception
    a = Blueprint("test")
    a.exception(InvalidUsage)(test_ignore_invalid_usage)

    # Test for testing

# Generated at 2022-06-21 23:11:07.602766
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('/')
    blueprint.exception(Exception)(lambda e: e)

    assert len(blueprint._future_exceptions) == 1
    future_exception = next(iter(blueprint._future_exceptions))
    assert future_exception.handler(Exception)

# Generated at 2022-06-21 23:11:14.486124
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic.response import text
    from sanic.exceptions import NotFound, InternalServerError
    from sanic.models.route import Route

    def handler_1(request, exception):
        return text('Internal Server Error', status=500)

    def handler_2(request, exception):
        return text('Not Found', status=404)

    app = sanic.Sanic('test')
    em = ExceptionMixin()

    # Test add exception handler
    em.exception([NotFound, InternalServerError])(handler_1)
    em.exception([NotFound])(handler_2)

    assert len(em._future_exceptions) == 2

    exception_1 = FutureException(handler_1, (NotFound, InternalServerError))

# Generated at 2022-06-21 23:11:18.025115
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert (exception_mixin._future_exceptions == set())


# Generated at 2022-06-21 23:11:19.976669
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception()
    def test():
        return True

    assert test()


# Generated at 2022-06-21 23:11:22.772617
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test', url_prefix='test')
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:11:30.631717
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    bp = Blueprint()
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:11:32.642013
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance._future_exceptions, set)

# Generated at 2022-06-21 23:11:41.750552
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.testing import HOST, PORT, SanicTestClient

    class ExceptionMixinClient(ExceptionMixin):
        def __init__(self):
            super().__init__()

    # Setup exception handler for Blueprint
    bp: Blueprint = Blueprint('test_bp', host=HOST, port=PORT)

    @bp.route('/bp-future-exception', methods=['GET'])
    def bp_future_exception(request):
        raise Exception('failed')

    # Setup exception handler for client
    client = ExceptionMixinClient()
    @client.exception(Exception)
    def exception_handler(request, exception):
        return text('Exception: %s' % exception)

    return SanicTestClient(bp.as_handler(), client)

# Generated at 2022-06-21 23:11:49.085827
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mock(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.count = 0
            
        def _apply_exception_handler(self, handler):
            self.count += 1
            assert count == 1, "count should be 1"

    mock = Mock()
    @mock.exception([Exception])
    def blah():
        pass
        
    assert mock.count == 1, "count should be 1"

# Generated at 2022-06-21 23:11:59.044232
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    app = Sanic('test_ExceptionMixin_exception')

    @app.route('/test_ExceptionMixin_exception')
    def foo(request):
        return request

    @ExceptionMixin.exception(Exception)
    def simple_exception(request, exception):
        return text('simple_exception')

    simple_exception(app)

    request, response = app.test_client.get('/test_ExceptionMixin_exception')

    assert response.text == 'simple_exception'

# Generated at 2022-06-21 23:12:02.502520
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_ExceptionMixin(): pass
    new_exception = test_ExceptionMixin()
    assert new_exception._future_exceptions == set()

# Generated at 2022-06-21 23:12:04.651815
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert exception._future_exceptions == set()

# Generated at 2022-06-21 23:12:06.819670
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    app = Sanic(__name__)
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:12:15.649472
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models import blueprint
    bp = blueprint.Blueprint("", url_prefix="")
    # first use to test action of method exception
    # create a function
    def dummy_handler(request, *args, **kwargs):
        pass
    # use exception method to register handler
    bp.exception((UserWarning,), apply=True)(dummy_handler)
    # test dummy_handler has been registered in _future_exceptions
    assert dummy_handler.im_func in bp._future_exceptions
    # test dummy_handler is returned
    assert bp.exception(UserWarning, apply=True)(dummy_handler) == dummy_handler
    # second use to test action of decorator of method exception
    # create a function

# Generated at 2022-06-21 23:12:21.092673
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class NewExceptionMixin(ExceptionMixin):
        def __init__(self, app, *args, **kwargs):
            self.add_global_handler = lambda *args: True
            self.exception_handlers = set()

        def _apply_exception_handler(self, handler):
            self.exception_handlers.add(handler)

    @NewExceptionMixin.exception(ValueError, TypeError)
    async def exception_handler(*exceptions):
        pass

    mixin = NewExceptionMixin(None)
    assert exception_handler in mixin.exception_handlers
    assert hasattr(exception_handler, "__exception_wrapped_handler")

# Generated at 2022-06-21 23:12:33.921622
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)
    x = ExceptionMixin()
    assert isinstance(x, ExceptionMixin)
    assert x._future_exceptions == set()


# Generated at 2022-06-21 23:12:34.513906
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-21 23:12:42.589446
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    import pytest

    app = Sanic(__name__)
    blueprint = Blueprint('test_bp', url_prefix='test')

    @blueprint.exception
    def handle_exception(request, exception):
        pass

    with pytest.raises(NotImplementedError):
        blueprint._apply_exception_handler(FutureException(handle_exception, tuple()))

    assert blueprint.exception(int) == handle_exception

    with pytest.raises(TypeError):
        blueprint.exception(None)

# Generated at 2022-06-21 23:12:44.696681
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)


# Generated at 2022-06-21 23:12:47.983910
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptionMixin = ExceptionMixin()

    @exceptionMixin.exception
    def test():
        return "hello world"

    assert callable(test)

# Generated at 2022-06-21 23:12:52.496742
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException

    class A(ExceptionMixin):
        pass

    a = A()

    @a.exception(SanicException)
    def handler(request, exception):
        return request

    assert len(a._future_exceptions) == 1
    assert a._future_exceptions == {FutureException(handler, (SanicException,))}

# Generated at 2022-06-21 23:13:02.673985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return

    class _MockSanicApp:
        def __init__(self, *args, **kwargs) -> None:
            self.blueprints = []

    class _Blueprint:
        def __init__(self, *args, **kwargs) -> None:
            self.exception_handler_parameters = {}

    class _MockSanic:
        def __init__(self, *args, **kwargs) -> None:
            self.app = _MockSanicApp()


# Generated at 2022-06-21 23:13:04.239114
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin


# Generated at 2022-06-21 23:13:08.867842
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint_base = Blueprint('blueprint_base')

    def other_method():
        pass

    def decorator(handler):
        return handler

    blueprint_base.exception = ExceptionMixin.exception


# Generated at 2022-06-21 23:13:20.915065
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class testclass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """

            def decorator(handler):
                nonlocal apply
                nonlocal exceptions


# Generated at 2022-06-21 23:13:38.148287
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:13:42.352070
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import json
    from sanic.exceptions import NotFound
    blueprint = Blueprint("Test bluprint", url_prefix="/test")
    blueprint.exception(NotFound)

    @blueprint.route("/")
    async def test(request):
        raise NotFound("View not found", request=request)

    app = sanic.app.Sanic("Test App")
    app.blueprint(blueprint)
    assert not app.exception_handlers

    with pytest.raises(NotFound) as err:
        _, response = app.test_client.get("/test/")

    assert response.status == 404
    assert "View not found" in err.value.args

# Generated at 2022-06-21 23:13:48.850246
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        class A(ExceptionMixin):
            def __init__(self, *args, **kwargs) -> None:
                ExceptionMixin.__init__(self, *args, **kwargs)

        a = A()
        # print(a._future_exceptions)
    except:
        assert False



# Generated at 2022-06-21 23:13:51.887707
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    f = ExceptionMixin()
    assert f._future_exceptions == set()


# Generated at 2022-06-21 23:14:00.224675
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import BluePrint
    bp = BluePrint.__new__(BluePrint)
    exceptionMixin = ExceptionMixin.__new__(ExceptionMixin)
    exceptionMixin.__init__(bp, 'str', a=1, b=2, c=3)
    assert exceptionMixin._future_exceptions == set()
    assert bp == 'str'
    assert bp.a == 1
    assert bp.b == 2
    assert bp.c == 3


# Generated at 2022-06-21 23:14:06.566327
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    a = A()
    assert bool(a._future_exceptions) == False

    @a.exception(ValueError, apply=True)
    def error_handler(request, exception):
        pass

    assert len(a._future_exceptions) == 1

# Generated at 2022-06-21 23:14:15.963853
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.views import HTTPMethodView

    class HttpMethodView(HTTPMethodView, ExceptionMixin):
        @ExceptionMixin.exception(ValueError, apply=True)
        async def exception_handler(request, exception: ValueError):
            pass

    http_method_view = HttpMethodView()
    http_method_view.exception(ValueError)

    assert len(http_method_view._future_exceptions) == 1

    (exception, ) = http_method_view._future_exceptions

    assert isinstance(exception, FutureException)

# Generated at 2022-06-21 23:14:18.484501
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
    except:
        print("Error: unexpected error : constructor of class ExceptionMixin")

# Generated at 2022-06-21 23:14:29.876418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic.blueprints import Blueprint
    bp = Blueprint('test', url_prefix='/test')

    @bp.exception(Exception)
    def handle_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

    @bp.exception(sanic.exceptions.InvalidUsage)
    def handle_invalid_usage(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

    @bp.exception([Exception, sanic.exceptions.InvalidUsage])
    def handle_multiple_exceptions(request, exception):
        pass


# Generated at 2022-06-21 23:14:32.379363
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-21 23:15:11.281119
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class HttpException(Exception):
        def __init__(self, status_code: int, message: str = None) -> None:
            self.status_code = status_code
            self.message = message

    class MyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def exception_handler(request, exception):
        return 'exception handle!'

    my_class = MyClass()
    my_class.exception(HttpException)(exception_handler)
    assert len(my_class._future_exceptions) == 1
    future_exception = my_class._future_exceptions.pop()
    assert future_ex

# Generated at 2022-06-21 23:15:13.825915
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    routing = ExceptionMixin()
    assert routing._future_exceptions == set()


# Generated at 2022-06-21 23:15:19.108293
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorator(handler):
        return handler
    def exception(self,*exceptions,apply=True):
        def decorator(handler):
            return handler
        return decorator
    obj = ExceptionMixin()
    obj.exception = exception
    obj.__init__()
    assert(obj._future_exceptions == set())
    assert(obj.exception() == decorator)

# Generated at 2022-06-21 23:15:22.465034
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:15:27.443045
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_blueprint = TestExceptionMixin()
    @test_blueprint.exception()
    def test_handler():
        pass

    future_exception = FutureException(test_handler, ())
    assert test_blueprint._future_excepti

# Generated at 2022-06-21 23:15:34.070023
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    sut = ExceptionMixin()
    assert isinstance(sut._future_exceptions, Set)
    assert len(sut._future_exceptions) == 0


# Generated at 2022-06-21 23:15:35.363479
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:15:41.671146
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    exception_mixin_test = ExceptionMixinTest()
    assert not exception_mixin_test._future_exceptions

# Generated at 2022-06-21 23:15:43.571523
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    assert callable(obj.exception)

# Generated at 2022-06-21 23:15:48.100583
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    from sanic.response import json

    app = Sanic("test_ExceptionMixin_exception")
    blueprint = Blueprint("test_ExceptionMixin_exception")

    class MyError(Exception):
        pass

    @blueprint.exception(MyError)
    def handler_error(request, exception):
        return json({"code": 1, "message": str(exception)})

    @app.get("/")
    def handler_request(request):
        raise MyError("my error")

    app.blueprint(blueprint)

    request, response = app.test_client.get("/")
    assert response.json == {"code": 1, "message": "my error"}

# Generated at 2022-06-21 23:17:10.215817
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    def decorator(Mockself):
        return Mockself
    def test_exception(*args, **kwargs) -> Set[FutureException]:
        return Set[FutureException]
    
    instance = ExceptionMixin()
    instance.exception = test_exception
    assert isinstance(instance.exception(), Set)
    assert instance.exception.__qualname__ == 'ExceptionMixin.test_exception'
    
    


# Generated at 2022-06-21 23:17:18.909086
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    class MyException(Exception):
        pass


    class MySubException(MyException):
        pass


    class MySecondSubException(MyException):
        pass


    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test_exception_blueprint')
    @blueprint.route('/test')
    def test(request):
        raise MyException('Error')


    @blueprint.exception(MyException)
    def handler(request, exception):
        assert isinstance(exception, MyException)
        return text('Test')



# Generated at 2022-06-21 23:17:20.776995
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert(ExceptionMixin._future_exceptions == set())


# Generated at 2022-06-21 23:17:24.732873
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            ...

    blueprint = Blueprint()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:17:33.132722
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    testExceptionMixin = TestExceptionMixin()
    try:
        testExceptionMixin.exception()
    except TypeError as err:
        assert 'required argument' in str(err)


# Generated at 2022-06-21 23:17:40.277869
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    Ex = ExceptionMixinTester()
    Ex._future_exceptions = set()

# Generated at 2022-06-21 23:17:42.512197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin().exception()
    assert result is not None


# Generated at 2022-06-21 23:17:51.203411
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler in self._future_exceptions

    @TestExceptionMixin.exception(AssertionError)
    def handler():
        pass
    # TODO: add more cases ...

# Generated at 2022-06-21 23:18:02.328437
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin.__init__(ExceptionMixin, *(1, 2), **{'foo': 'bar'}) is None
    assert ExceptionMixin.__init__('foo', *(1, 2), **{'foo': 'bar'}) is None
    assert ExceptionMixin.__init__(1, *(1, 2), **{'foo': 'bar'}) is None
    assert ExceptionMixin.__init__(True, *(1, 2), **{'foo': 'bar'}) is None
    assert ExceptionMixin.__init__(ExceptionMixin, *(1, 2), **{'foo': 'bar'})._future_exceptions == set()
    assert ExceptionMixin.__init__('foo', *(1, 2), **{'foo': 'bar'})._future_exceptions == set()
   

# Generated at 2022-06-21 23:18:06.456926
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)

    blueprint = Blueprint(__name__)

    @blueprint.exception(ZeroDivisionError)
    def zero_division_error_handler(request, exception):
        return "Oh no! You divided by zero.", 500

    app.blueprint(blueprint)

    assert app.exception_handler.handlers[0].args == (ZeroDivisionError,)

### Unit tests related to method _apply_exception_handlers of class ExceptionMixin