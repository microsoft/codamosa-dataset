

# Generated at 2022-06-21 23:09:26.413696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    b = ExceptionMixin()
    # pass a single exception
    @b.exception(Exception)
    def handle_exception(request, e):
        return "An exception occurred"
    assert isinstance(handle_exception, collections.Callable)
    assert b._future_exceptions


# Generated at 2022-06-21 23:09:27.871005
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:09:40.647724
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Define a series of unit tests to test the functionality of method
    exception of class ExceptionMixin.
    """

    import sys
    import unittest

    class FakeException(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # prepare basic infos for testing

    fake_exception = FakeException()

    def fake_handler_func(request, *args, **kwargs):
        pass

    # perform unit test for method exception of class ExceptionMixin

    @fake_exception.exception(Exception)
    def fake_handler_func_1(request, *args, **kwargs):
        pass

    @fake_exception.exception([Exception])
    def fake_handler_func_2(request, *args, **kwargs):
        pass


# Generated at 2022-06-21 23:09:48.418920
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic

    app = sanic.Sanic()
    class ExceptionMixin_exception(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert True # noqa

    exceptionMixin = ExceptionMixin_exception()

    def test_handler(*args1, **arg2):
        return "test_handler"

    exceptionMixin.exception(Exception)(test_handler)

# Generated at 2022-06-21 23:09:59.176364
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @DummyException.exception(Exception, apply=False)
    def handler(request, exception):
        pass

    assert len(DummyException._future_exceptions) == 1

    for item in DummyException._future_exceptions:
        assert item.handler is handler
        assert Exception in item.exceptions

# Generated at 2022-06-21 23:10:11.258666
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):

        TEST_EXCEPTION = "TestException"

        def __init__(self, app=None):
            ExceptionMixin.__init__(self)
            self.exception(TestExceptionMixin.TEST_EXCEPTION)(self.test_exc)

        def test_exc(self, request, exception):
            return "test"

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions is not None
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin.test_exc(
        mock.Mock(), TestExceptionMixin.TEST_EXCEPTION) == "test"

# Generated at 2022-06-21 23:10:14.317877
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BlahException(ExceptionMixin):
        pass
    x = BlahException()
    assert x._future_exceptions == set()

# Generated at 2022-06-21 23:10:18.049797
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    excm = ExceptionMixin()
    assert excm._future_exceptions.__class__.__name__ == 'set'
    assert len(excm._future_exceptions) == 0


# Generated at 2022-06-21 23:10:19.796594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:10:21.253931
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(), ExceptionMixin)

# Generated at 2022-06-21 23:10:25.884725
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)
    x = ExceptionMixin()
    assert x


# Generated at 2022-06-21 23:10:35.291481
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from contextlib import contextmanager
    from unittest.mock import Mock
    from sanic.blueprints import Blueprint
    from sanic.request import Request

    @contextmanager
    def _patch_apply_exception_handler(return_value):
        '''Patches the apply_exception_handler method'''
        with patch('sanic.blueprints.exception_mixin.\
ExceptionMixin._apply_exception_handler') as m_apply_exception_handler:
            m_apply_exception_handler.return_value = return_value
            yield m_apply_exception_handler

    # test_ExceptionMixin_exception_is_decorator
    class _DummyExceptionMixin(ExceptionMixin, Blueprint):
        pass

    test_exception = _DummyExceptionMixin()


# Generated at 2022-06-21 23:10:36.236353
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:10:37.720912
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import doctest
    result = doctest.testmod()
    assert result.failed == 0

# Generated at 2022-06-21 23:10:38.809386
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    print(em)

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-21 23:10:47.331524
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint:
        def __init__(self):
            self.__functions = []
            self.__exception_handlers = []

        def exception(self, *exceptions, apply=True):
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions
                self.__functions.append((handler, apply, exceptions))
                return handler

            return decorator

        def _apply_exception_handler(self, handler):
            self.__exception_handlers.append(handler)

        def get_exception_handlers(self):
            return self.__exception_handlers

        def get_functions(self):
            return self.__functions
    blueprint = Blueprint()
    assert blueprint.get_functions() == []
    assert blueprint.get_exception_handlers() == []
   

# Generated at 2022-06-21 23:10:53.257402
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self,handler: FutureException):
            pass

    test_exception_mixin=TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

#Unit test for _apply_exception_handler function. This function has been
# implemented in the class Sanic.

# Generated at 2022-06-21 23:10:54.961591
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    blueprint = Blueprint('test')
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:10:58.095617
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from sanic.models.futures import FutureException
    blueprint = Blueprint()
    expected_future_exceptions = set()

    # test whether the field `_future_exceptions` is assigned correctly
    assert blueprint._future_exceptions == expected_future_exceptions


# Generated at 2022-06-21 23:10:59.383699
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Example(ExceptionMixin):
        pass

    result = Example()

    assert result._future_exceptions == set()



# Generated at 2022-06-21 23:11:05.880290
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with pytest.raises(NotImplementedError):
        ExceptionMixin().exception("not implemented")

# Generated at 2022-06-21 23:11:08.610328
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:11:11.075571
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    a = A()
    assert a._future_exceptions == set()


# Generated at 2022-06-21 23:11:15.903981
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    t = ExceptionMixin()
    assert isinstance(t, ExceptionMixin)
    assert t.__class__ == ExceptionMixin
    assert t._future_exceptions == set()


# Generated at 2022-06-21 23:11:20.167160
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_tmp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    _ = ExceptionMixin_tmp()

# Generated at 2022-06-21 23:11:23.459513
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        class test_class(ExceptionMixin):
            pass
        test_class()


# Generated at 2022-06-21 23:11:25.204644
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()

# Generated at 2022-06-21 23:11:27.750678
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()
    assert isinstance(A()._future_exceptions, set)



# Generated at 2022-06-21 23:11:40.237346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    @a.exception(Exception)
    def handler(*args, **kwargs):
        pass
    assert {handler} == a._future_exceptions
    try:
        from unittest.mock import Mock
        h = Mock(name='handler')
        a.exception(h)
        h.assert_not_called()
    except ImportError:
        print('Skipping ExceptionMixin.exception() unit test due to missing dependency '
              'unittest.mock')
    except Exception as e:
        print(f'Skipping ExceptionMixin.exception() unit test due to unexpected exception {e}')

test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:11:43.969308
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    exc_mixin = TestExceptionMixin()
    assert not exc_mixin._future_exceptions

# Generated at 2022-06-21 23:11:55.531114
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exp = ExceptionMixinTest()
    assert exp._future_exceptions == set()

# Generated at 2022-06-21 23:11:56.531710
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert (ExceptionMixin()._future_exceptions) == set()


# Generated at 2022-06-21 23:12:01.593555
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class FakeApplication:
        pass

    class FakeBlueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self,*args, **kwargs)
            self.application = FakeApplication()

    
    fake_blueprint = FakeBlueprint()
    assert fake_blueprint._future_exceptions == set()
    assert fake_blueprint.application == FakeApplication()


# Generated at 2022-06-21 23:12:08.100386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    def handler(*args, **kwargs):
        raise ServerError()

    my_blueprint = Blueprint(__name__, url_prefix='/my-blueprint')
    my_blueprint.exception(Exception)(handler)
    assert isinstance(my_blueprint._future_exceptions, set)
    assert isinstance(my_blueprint._future_exceptions.pop(), FutureException)
    ExceptionMixin.exception()

# Generated at 2022-06-21 23:12:08.694575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:12:11.089872
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BluePrint(ExceptionMixin):
        pass
    blue_print = BluePrint()
    assert blue_print._future_exceptions == set()


# Generated at 2022-06-21 23:12:14.016521
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class User(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    u = User()
    assert u._future_exceptions == set()


# Generated at 2022-06-21 23:12:18.584144
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import mock
    #from sanic.exceptions import BaseSanicException

    class MockSanic(ExceptionMixin):
        pass

    sanic = MockSanic()
    cb = mock.MagicMock()

    sanic.exception(Exception)(cb)
    sanic._apply_exception_handler.assert_called_with(sanic._future_exceptions.pop())
    assert getattr(cb, '_exception_handler', False)
    

# Generated at 2022-06-21 23:12:24.983964
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.views import HTTPMethodView

    class MyBase(ExceptionMixin, HTTPMethodView):
        def __init__(self, *args, **kwargs):
            super(MyBase, self).__init__(*args, **kwargs)

    instance = MyBase()

    assert len(instance._future_exceptions) == 0
    assert isinstance(instance, ExceptionMixin)


# Generated at 2022-06-21 23:12:27.409363
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class E:
        def __init__(self):
            ExceptionMixin.__init__(self)
    e=E()
    assert e._future_exceptions==set()



# Generated at 2022-06-21 23:12:52.311071
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

            self.exceptions = set()
            self.handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions = handler.exceptions
            self.handler = handler.handler

    exception_mixin = ExceptionMixinTest()

    @exception_mixin.exception(Exception)
    async def my_exception_handler(request, exception):
        pass

    assert exception_mixin.exceptions == {Exception}
    assert exception_mixin.handler == my_exception_handler

# Generated at 2022-06-21 23:12:58.082325
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    test_obj = TestClass()
    assert isinstance(test_obj, ExceptionMixin)
    assert isinstance(test_obj._future_exceptions, set)

# Generated at 2022-06-21 23:13:02.205219
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    @TestExceptionMixin.exception(ValueError, AttributeError, apply=True)
    def test():
        raise ValueError("Test")

    assert len(TestExceptionMixin._future_exceptions) == 1



# Generated at 2022-06-21 23:13:06.698163
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(Exception):
        pass
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler(TestException()) == None
    test = TestExceptionMixin()
    test.exception(TestException)(lambda e: None)
    test.exception(TestException, apply=False)
    assert isinstance(test._future_exceptions.pop(), FutureException)
    assert isinstance(test._future_exceptions.pop(), FutureException)


# Generated at 2022-06-21 23:13:10.847453
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set(), "The attribute _future_exceptions in class ExceptionMixin isn't empty at initialization."
    assert obj.__init__() == None, "The method __init__ in class ExceptionMixin doesn't return None."


# Generated at 2022-06-21 23:13:20.961715
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass
    blueprint = Blueprint()
    assert len(blueprint._future_exceptions) == 0

    @blueprint.exception(ValueError, apply=False)
    def value_error_handler(request, exception):
        pass
    assert len(blueprint._future_exceptions) == 1

    # other base classes of Exception
    @blueprint.exception([Exception, ImportError, ReferenceError])
    def handler(request, exception):
        pass
    assert len(blueprint._future_exceptions) == 4

    assert isinstance(blueprint._future_exceptions, set)

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:13:30.770520
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureException

    @Blueprint.group("/1")
    def exception_handler(request, exception):
        return json("")

    bp = Blueprint("/2")

    @bp.exception(ServerError, apply=False)
    def exception_handler(request, exception):
        return json("")

    assert len(bp._future_exceptions) == 1
    future_exception = bp._future_exceptions.pop()
    assert future_exception == FutureException(exception_handler, ServerError)

# Generated at 2022-06-21 23:13:32.977381
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:13:37.015767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Blueprint(ExceptionMixin):
        pass

    blueprint = Blueprint()
    blueprint.exception(ValueError)(1)
    assert len(blueprint._future_exceptions)==1

# Generated at 2022-06-21 23:13:38.098376
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert len(exception_mixin._future_exceptions) == 0

# Generated at 2022-06-21 23:14:19.056448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicException
    import inspect
    
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    em = TestExceptionMixin()
    @em.exception([SanicException])
    def handle_exception(request, exception):
        pass

    assert len(em._future_exceptions) == 1
    assert inspect.iscoroutinefunction(handle_exception)

# Generated at 2022-06-21 23:14:30.546424
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):

        def __init__(self) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):

            nonlocal test_exception_handler_called
            nonlocal test_exception_handler_args
            nonlocal test_exception_handler_kwargs
            test_exception_handler_called = True
            test_exception_handler_args = args
            test_exception_handler_kwargs = kwargs


# New object for ExceptionMixin for Unit test
    test_exception_mixin_object = TestExceptionMixin()

    # For unit testing
    test_exception_handler_called = False
    test_exception_handler_args = None
    test_exception_handler_kwargs = None

   

# Generated at 2022-06-21 23:14:32.693770
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Create an instance of ExceptionMixin
    exception_mixin = ExceptionMixin()

    # Check if _future_exceptions has been successfully created
    assert len(exception_mixin._future_exceptions) == 0, \
        "Error: _future_exceptions is not empty"

# Generated at 2022-06-21 23:14:40.368442
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.router import RouteExists

    class TestClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            if handler.exceptions == (RouteExists,):
                print("Test Pass")
            else:
                print("Test Fail")

    test = TestClass()
    @test.exception(RouteExists)
    def test_func():
        pass

# Generated at 2022-06-21 23:14:51.008271
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic()

    def custom_exception_handler(request, exception):
        return json({"exception": "{}".format(exception)}, status=500)

    @app.exception(ZeroDivisionError)
    def zero_division(request, exception):
        return json({"exception": "zero division"}, status=500)

    @app.exception([ValueError, NameError])
    def value_error(request, exception):
        return json(
            {"exception": "{}".format(exception)}, status=500
        )

    @app.route("/custom")
    def handler(request):
        return json({})

    # Used with assertion, thus the noqa

# Generated at 2022-06-21 23:14:53.636144
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert isinstance(exc_mixin._future_exceptions, set)

# Generated at 2022-06-21 23:14:57.308309
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  e1 = ExceptionMixin()
  assert len(e1._future_exceptions) == 0
  assert e1._future_exceptions == set()



# Generated at 2022-06-21 23:14:59.495172
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-21 23:15:04.418633
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class dummyclass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return
    d=dummyclass()
    assert d._future_exceptions==set()


# Generated at 2022-06-21 23:15:07.168289
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__)
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:16:25.566113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test with errorr with wrong parameter
    class TestError(ExceptionMixin):
        def __init__(self):
            super().__init__()

        async def my_await(self):
            for i in range(10):
                yield i

        def do_something(self, a, b):
            return a + b

    test = TestError()
    @test.exception([KeyError, ZeroDivisionError])
    def error_handler(request, exception):
        return True

    assert test._future_exceptions

    # Test with errorr with right parameter
    class TestError(ExceptionMixin):
        def __init__(self):
            super().__init__()

        async def my_await(self):
            for i in range(10):
                yield i


# Generated at 2022-06-21 23:16:34.519895
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp", url_prefix="/test")
    assert repr(bp) == "<Blueprint (test_bp)>"
    assert len(bp._future_exceptions) == 0

    @bp.exception(Exception)
    def handler(request, exception):
        return

    assert len(bp._future_exceptions) == 1
    assert (
        str(next(iter(bp._future_exceptions)))
        == "<FutureException(name=<function handler at 0x7f43a8b70950>), exceptions=(<class 'Exception'>,)>"
    )

# Generated at 2022-06-21 23:16:39.275696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint()
    blueprint.exception(IndexError)(echo)
    blueprint.exception(ValueError)(echo)
    blueprint.exception([IndexError, ValueError])(echo)
    assert blueprint._future_exceptions == {
        FutureException(echo, ({IndexError},)),
        FutureException(echo, ({ValueError},)),
        FutureException(echo, ({IndexError, ValueError},)),
    }



# Generated at 2022-06-21 23:16:42.377162
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp_obj = Blueprint('bp_name', url_prefix='/bp_prefix')
    bp_obj._future_exceptions = set()
    global_exception_handler = bp_obj.exception(Exception)
    assert isinstance(global_exception_handler, FunctionType)

# Generated at 2022-06-21 23:16:45.181541
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import ExceptionMixin
    from sanic.models.futures import FutureException
    foo = ExceptionMixin()
    assert type(foo._future_exceptions) == set
    assert foo._future_exceptions == set()
    assert foo._apply_exception_handler(FutureException) is None

# Generated at 2022-06-21 23:16:46.393229
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert not exc._future_exceptions

# Generated at 2022-06-21 23:16:47.650823
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-21 23:16:49.057848
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = sp.Blueprint()
    blueprint.exception(Exception)
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:16:54.726394
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from random import random
    from time import time

    bp = Blueprint('test_bp', url_prefix=f"/test_bp{int(random() * time())}")

    assert bp._future_exceptions == set()
    assert bp._exception_handlers == []
    assert bp.name == 'test_bp'
    assert bp.error_handler == Blueprint.error_handler
    assert bp.static('/test', '/test') == bp.static

# Generated at 2022-06-21 23:16:57.269919
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    new_ExceptionMixin = ExceptionMixin()
    assert isinstance(new_ExceptionMixin, ExceptionMixin)
    assert new_ExceptionMixin._future_exceptions == set()
