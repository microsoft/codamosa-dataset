

# Generated at 2022-06-21 23:09:19.255629
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-21 23:09:20.245943
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ExceptionMixin()


# Generated at 2022-06-21 23:09:30.696342
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create ExceptionMixin
    exception_mixin = ExceptionMixin()
    # assert _future_exceptions of ExceptionMixin is empty before use method exception
    assert exception_mixin._future_exceptions == set()
    # use exception method
    @exception_mixin.exception(AssertionError)
    def _handle_assertion_error(request, exception):
        return 'handle assertion error'
    # assert _future_exceptions of ExceptionMixin is not empty after apply method exception
    assert len(exception_mixin._future_exceptions) == 1
    # assert _future_exceptions of ExceptionMixin contains the right FutureException
    assert exception_mixin._future_exceptions.pop() == FutureException(handler = _handle_assertion_error, exceptions = (AssertionError,))

# Generated at 2022-06-21 23:09:32.443074
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO

    pass

# Generated at 2022-06-21 23:09:38.943279
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    app = Sanic('test_ExceptionMixin')

    @app.route('/')
    async def handler(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'

# Generated at 2022-06-21 23:09:44.814019
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureException:
        def __init__(self, handler, exceptions):
            pass

    class FakeExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            assert isinstance(handler, FutureException)

    fake_exception = FakeExceptionMixin()
    fake_exception._future_exceptions = set()
    fake_exception._apply_exception_handler = lambda x: x

    # Unit test for decorator
    assert not fake_exception._future_exceptions

    @fake_exception.exception()
    def fake_handler():
        pass

    assert len(fake_exception._future_exceptions) == 1

    # Unit test for decorator with exceptions
    @fake_exception.exception((RuntimeError, ))
    def fake_handler2():
        pass



# Generated at 2022-06-21 23:09:46.749569
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-21 23:09:59.252404
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test the case when the exception handler is applied
    blueprint = ExceptionMixin()
    blueprint.exception(Exception)(print)
    while blueprint._future_exceptions:
        future_exception = blueprint._future_exceptions.pop()
        future_exception.handler(e=Exception)
    # Test the case when the exception handler is not applied
    blueprint = ExceptionMixin()
    blueprint.exception(Exception, apply=False)(print)
    while blueprint._future_exceptions:
        future_exception = blueprint._future_exceptions.pop()
        future_exception.handler(e=Exception)

# Generated at 2022-06-21 23:10:04.119474
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    new_obj = ExceptionMixin()

    # Assert the class has been correctly initialized
    assert new_obj.__init__()
    assert new_obj._future_exceptions == set()

# Generated at 2022-06-21 23:10:08.910289
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_exception_mixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    t_exception_mixin = test_exception_mixin()

    assert len(t_exception_mixin._future_exceptions) == 0


# unit test for applying exception_handler

# Generated at 2022-06-21 23:10:18.291550
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        def __init__(self, message):
            self.message = message
            super().__init__(self.message)

    @ExceptionMixin.exception("a", "b=2")
    def handler():
        print("Hello")

    assert handler.exceptions[0] == "a"
    assert handler.exceptions[1] == ("b", 2)
    assert handler.handler == "handler"


# Generated at 2022-06-21 23:10:30.191210
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    def handler():
        raise NotImplementedError  # noqa

    exception_mixin = TestExceptionMixin()
    exception_mixin.exception(Exception)(handler)
    assert len(exception_mixin._future_exceptions) == 1

    handler_ = exception_mixin._future_exceptions.pop()
    assert handler_.handler == handler
    assert handler_.exceptions == (Exception,)

# Generated at 2022-06-21 23:10:35.158723
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    testExceptionMixin = TestExceptionMixin()

    assert isinstance(testExceptionMixin, TestExceptionMixin)


# Generated at 2022-06-21 23:10:44.428512
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Required
    def f1(req, res):
        pass

    # Applicable
    def f2(req, res):
        pass

    # Incorrect
    def f3(req, res, a):
        pass

    # Correct
    def f4(req, res, a, b):
        pass

    # Optional
    def f5(req, res, a, b, c=1):
        pass

    # Exceptions
    def f6(req, res, exc):
        pass

    assert ExceptionMixin._exception(None, f1) is None
    assert ExceptionMixin._exception(None, f2, apply=False) is None
    try:
        assert ExceptionMixin._exception(None, f3) is None
    except TypeError:
        assert True

# Generated at 2022-06-21 23:10:45.834631
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:10:52.244220
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class B:
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler):
            self._future_exceptions.add(handler)
    b = B()
    @b.exception(Exception)
    def handler(request, exception):
        return "done"
    assert b._future_exceptions == {FutureException(handler, (Exception,))}

# Generated at 2022-06-21 23:10:57.984258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  """
  Test the exception method of the ExceptionMixin class
  """
  # Test case 1:
  #   Test that the object is successfully instantiated
  assert ExceptionMixin() != None

  # Test case 2:
  #   Test that the method handles the 'Exception' argument with the
  #   'apply' argument as 'True'
  exception_mixin = ExceptionMixin()
  class TestException(Exception):
      pass
  exception_mixin.exception(TestException)(lambda a: a)("Hello")
  try:
    raise TestException
  except Exception:
    pass

# Generated at 2022-06-21 23:10:59.278434
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    Test()


# Generated at 2022-06-21 23:11:06.268731
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json
    from sanic.blueprints import Blueprint

    blue_print = Blueprint('testing')

    @blue_print.exception(Exception)  # noqa: F811
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert blue_print._future_exceptions

# Generated at 2022-06-21 23:11:11.145250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    url = 'https://www.google.com/'

    def handler(request, ex):
        return url

    exception_handler = ExceptionMixin().exception(ZeroDivisionError)(handler)

    assert isinstance(exception_handler, FutureException)
    assert exception_handler.handler is handler
    assert handler(None, None) == url

# Generated at 2022-06-21 23:11:19.226238
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            pass
    assert MyExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:11:23.577640
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView

    class AView(HTTPMethodView, ExceptionMixin):
        def get(self):
            pass

        def post(self):
            pass

    view = AView()
    future_exception = FutureException(None, None)

    assert len(view._future_exceptions) == 0

    assert view.exception(BaseException)
    assert view.exception(BaseException, apply=False)

    assert len(view._future_exceptions) == 2

# Generated at 2022-06-21 23:11:30.218246
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixinTest, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return None
    # test for blank paramter
    exception_mixin_test = ExceptionMixinTest()
    try:
        exception_mixin_test.exception()
    except NotImplementedError:
        pass
    else:
        raise Exception("ExceptionMixin_exception test should pass, but it faild!")
    # test for normal parameter
    future_exception = FutureException(ExceptionMixin._apply_exception_handler, Exception)
    exception_

# Generated at 2022-06-21 23:11:41.112988
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic.app import Sanic

    # TODO: This test will be updated by next ticket
    # https://github.com/huge-success/sanic/issues/1524
    app = Sanic("test_ExceptionMixin_exception")

    @app.post("/")
    async def handler(request):
        return (request, response)

    @app.exception(AppException)
    def request_validation_exception_handler(request, exception):
        response = json({"status": "failed", "error": str(exception)})
        response.status_code = 400

    @app.exception(KeyError)
    def custom_error_handler(request, exception):
        response = json({"status": "failed", "error": str(exception)})
        response.status_code = 400

    request

# Generated at 2022-06-21 23:11:46.480014
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixin, self).__init__(args, kwargs)
    t = Test()
    assert t._future_exceptions == set()


# Generated at 2022-06-21 23:11:50.409428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class A:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return NotImplementedError

    ex = A()
    assert ex.exception is ExceptionMixin.exception

# Generated at 2022-06-21 23:12:00.976947
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FuncUnitTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    # Test apply=True
    test = FuncUnitTest()
    assert len(test._future_exceptions) == 0
    result = test.exception(apply=True)(lambda f, *args, **kwargs: 'unit test')('unit test')
    assert result == 'unit test'
    assert len(test._future_exceptions) == 1
    # Test apply=False
    test = FuncUnitTest()
    assert len(test._future_exceptions) == 0
    result = test.ex

# Generated at 2022-06-21 23:12:04.841657
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    instance = ExceptionMixin()

    # Act
    # Assert
    assert instance is not None
    assert instance._future_exceptions is not None


# Generated at 2022-06-21 23:12:08.364338
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint')

    # Act
    blueprint.exception(Exception)(print)

    # Assert
    expected = FutureException(print, (Exception,))
    assert blueprint._future_exceptions == {expected}

# Generated at 2022-06-21 23:12:16.622938
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.exceptions import add_exception_handler

    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()

    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception, apply=True)
    def test_function(request, exception, *args, **kwargs):
        return exception

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop() == FutureException(test_function, (Exception,))

    assert add_exception_handler((Exception,), test_function)["status_code"](None, None) == 500



# Generated at 2022-06-21 23:12:28.312816
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    assert isinstance(Test(), ExceptionMixin)


# Generated at 2022-06-21 23:12:29.639361
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert isinstance(em, ExceptionMixin)


# Generated at 2022-06-21 23:12:32.813204
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  from sanic.exceptions import add_exception_handler

  class Blueprint(ExceptionMixin):
    def __init__(self):
      super().__init__()

    def _apply_exception_handler(self, handler):
      add_exception_handler(handler, *handler.exceptions)

  def foo(request):
    raise Exception('bar')

  bp = Blueprint()
  bp.exception(KeyError, apply=True)(foo)

# Generated at 2022-06-21 23:12:34.867066
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
        class _ExceptionMixin(ExceptionMixin):
            def _apply_exception_handler(self, handler: FutureException):
                raise NotImplementedError  # noqa
        obj = _ExceptionMixin()
        assert obj.exception(ZeroDivisionError,apply=True)(lambda x:x)

# Generated at 2022-06-21 23:12:37.030476
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj is not None
    assert isinstance(obj, ExceptionMixin)
    assert obj._future_exceptions is not None

# Generated at 2022-06-21 23:12:37.667363
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:12:40.511993
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SanicBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    rv = SanicBlueprint()
    rv.exception

# Generated at 2022-06-21 23:12:42.677145
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert not exception_mixin._future_exceptions


# Generated at 2022-06-21 23:12:46.641196
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    bp = Blueprint(__name__, url_prefix='test')
    assert isinstance(bp, ExceptionMixin)

# Generated at 2022-06-21 23:12:49.974032
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionClass(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return {str(handler.handler)}
    result = ExceptionClass().exception("string")("string")
    assert("string" in result)

# Generated at 2022-06-21 23:13:13.483687
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    app = Sanic(__name__)

    class ExceptionMixin(object):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """

            def decorator(handler):
                nonlocal apply
                nonlocal exceptions

                if isinstance(exceptions[0], list):
                    exceptions = tuple(*exceptions)

                future_ex

# Generated at 2022-06-21 23:13:22.108369
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.exceptions import ServerError
    from sanic.exceptions import add_status_code

    # Mock function
    def on_error():
        pass

    blueprint = Blueprint('test', url_prefix='/test')
    blueprint_exception = blueprint.exception(SanicException, apply=False)
    blueprint_exception(on_error)

    # Mock the class which is inherited the class ExceptionMixin
    class Sandbox(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self, 'test', url_prefix='/test')

    sandbox = Sandbox()

    # Unit test for exceptions
    assert len(sandbox._future_exceptions) == 0

# Generated at 2022-06-21 23:13:24.502971
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a is not None


# Generated at 2022-06-21 23:13:28.126526
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestCls(ExceptionMixin):
        pass

    test_instance = TestCls()

    assert test_instance._future_exceptions is not None


# Generated at 2022-06-21 23:13:34.642922
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create the blueprint
    blueprint = Blueprint("TestExceptionMixin", url_prefix="test")

    # Test the blueprint
    blueprint.exception(InvalidUsage, apply=False)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().exceptions == [InvalidUsage]

# Generated at 2022-06-21 23:13:44.086692
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.server import HttpProtocol
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import SanicException

    # Should not throw any exception
    bp = Blueprint("test_ExceptionMixin_exception")

    @bp.exception(SanicException)
    def handler(request, exception):
        return text("OK")

    server = HttpProtocol(Request({}), lambda x: x)
    handler = bp.routes[0][1]
    handler(server, request=server.request, exception=SanicException())

# Generated at 2022-06-21 23:13:46.739669
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert isinstance(exc_mixin._future_exceptions, set)

# Generated at 2022-06-21 23:13:51.474487
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    x = TestExceptionMixin()
    assert isinstance(x, TestExceptionMixin) and isinstance(x, ExceptionMixin)


# Generated at 2022-06-21 23:13:52.932902
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print(ExceptionMixin())



# Generated at 2022-06-21 23:13:55.488924
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass
    assert isinstance(ExceptionMixinTest(), ExceptionMixin)

# Generated at 2022-06-21 23:14:30.781787
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinChild(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    exception_mixin = ExceptionMixinChild()
    exception_handler = exception_mixin.exception(KeyError)

    assert(exception_mixin._future_exceptions != None)

# Generated at 2022-06-21 23:14:40.406070
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # create mock object
    mock_args = ("mock_args", )
    mock_kwargs = {"mock_kwargs": "mock_kwargs"}

    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    mock_exception_mixin = MockExceptionMixin(*mock_args, **mock_kwargs)

    check_future_exceptions = getattr(mock_exception_mixin, "_future_exceptions")
    assert check_future_exceptions == set()
    assert isinstance(check_future_exceptions, set)

# Generated at 2022-06-21 23:14:44.582770
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    b = Blueprint('b', url_prefix='/b')
    assert isinstance(b, ExceptionMixin)


# Generated at 2022-06-21 23:14:45.376098
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:14:49.879656
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class TestExceptionMixin(ExceptionMixin):

        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    etm = TestExceptionMixin()
    assert (etm._future_exceptions == set())



# Generated at 2022-06-21 23:15:00.813094
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models import SanicBase
    from sanic.models.futures import FutureException
    from sanic.models.endpoints import Endpoint
    from sanic.exceptions import NotFound
    class TestExceptionMixin(ExceptionMixin, SanicBase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def handle_exception(self, request, exception):
            if isinstance(exception, NotFound):
                return '404 Not Found'
            return None

    class TestEndpoint(Endpoint):
        def __init__(self, request, path_args, **kwargs):
            super().__init__(request, path_args, **kwargs)
        def execute(self):
            raise NotFound

# Generated at 2022-06-21 23:15:05.155172
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    instance = ExceptionMixin()
    instance = instance.exception(TypeError)

    assert(len(instance._future_exceptions) == 1)
    assert(instance._future_exceptions is not None)

# Generated at 2022-06-21 23:15:07.010000
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    class bp(Blueprint):
        pass

    assert hasattr(bp(), "_future_exceptions")

# Generated at 2022-06-21 23:15:19.268938
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin
    assert test_exception_mixin._future_exceptions == set()

    def handler1(request, exception):
        pass

    def handler2(request, exception):
        pass

    def handler3(request, exception):
        pass

    test_exception_mixin.exception(handler1)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions == set([FutureException(handler1, ())])
    exception_mixin1 = test_exception_mixin.exception(handler2)
    assert exception_mixin1 == handler2
    assert test_exception_

# Generated at 2022-06-21 23:15:20.380082
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mix = ExceptionMixin()
    assert len(mix._future_exceptions) == 0


# Generated at 2022-06-21 23:16:33.456645
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

  print("\n\n\n--- [Running test_ExceptionMixin] ---\n")
  mixin = ExceptionMixin()
  assert not mixin._future_exceptions


# Generated at 2022-06-21 23:16:35.464417
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:16:38.139509
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    assert TestExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:16:39.305786
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert hasattr(ExceptionMixin, '__init__')
    assert callable(ExceptionMixin.__init__)


# Generated at 2022-06-21 23:16:42.155280
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    my_blueprint= Blueprint('my_blueprint', url_prefix='/v1')
    ExceptionMixin.__init__(my_blueprint)
    assert my_blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:16:43.181379
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert not ex._future_exceptions

# Generated at 2022-06-21 23:16:44.666054
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin._future_exceptions, set)


# Generated at 2022-06-21 23:16:53.511366
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.handler_called = False
            self.exceptions_called_with = set()

        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions_called_with.add(handler)

    te = TestExceptionMixin()
    assert te._future_exceptions == set()
    assert te.exceptions_called_with == set()

    # Test for single exception
    @te.exception(Exception)
    def _single_exception_handler(request, exception):
        te.handler_called = True
        assert isinstance(exception, Exception)

    assert te.handler_called == True

# Generated at 2022-06-21 23:16:54.801859
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    c = ExceptionMixin()
    assert not c._future_exceptions

# Generated at 2022-06-21 23:17:00.605362
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError()

    class Exception:
        pass

    @Blueprint.exception([Exception])
    def exception_handler():
        pass

    assert Exception in Blueprint._future_exceptions.pop().exceptions