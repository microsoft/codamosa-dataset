

# Generated at 2022-06-21 23:09:22.210110
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    assert TestExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:09:22.803635
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:09:31.126540
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException) -> None:
            '''
            Regular method for testing purposes
            '''
            pass
        
    test_class = TestClass()
    @test_class.exception(exceptions=Exception)
    def test_function(request):
        print("Test")
        
    print("TestClass.exception passed")


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:09:33.537963
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin().__init__() == None



# Generated at 2022-06-21 23:09:39.236297
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Server(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    server = Server()
    @server.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(server._future_exceptions) == 1
    assert Exception in server._future_exceptions[0].exceptions

# Generated at 2022-06-21 23:09:41.252072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:09:48.346098
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    def decorator(handler):
        return handler
    test_object = ExceptionMixin()
    assert test_object._future_exceptions == set()
    assert test_object.exception(1, 2, apply=False, a=1) == decorator
    test_object._future_exceptions.add(1)
    assert test_object._future_exceptions == set([1,])


# Generated at 2022-06-21 23:09:51.633201
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    def test(request):
        pass
    obj.exception(test)

# Generated at 2022-06-21 23:10:01.452299
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.response import text
    from sanic.blueprints import Blueprint

    app = Sanic("test_ExceptionMixin")
    blueprint = Blueprint("test_blueprint")

    @blueprint.exception(Exception)
    def handler(request, exception):
        return text("You caused a {} exception".format(exception), 500)

    app.blueprint(blueprint)

    @app.route("/")
    def handler(request):
        1 / 0
        return text("You should not see this message")

    request, response = app.test_client.get("/")
    assert response.status == 500
    assert response.text == "You caused a division by zero exception"


# Generated at 2022-06-21 23:10:07.079598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Unit test for method exception of class ExceptionMixin
    """

    class ExceptionMixin_(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Apply
    ExceptionMixin_().exception('a')
    ExceptionMixin_().exception(['a', 'b'])

    # Not Apply
    ExceptionMixin_().exception('a', apply=False)
    ExceptionMixin_().exception(['a', 'b'], apply=False)

# Generated at 2022-06-21 23:10:15.488474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    app = sanic.Sanic('test_exception_mixin')
    exception_mixin = ExceptionMixin()
    @exception_mixin.exception(ValueError, apply=False)
    def handler(request, exception):
        pass
    assert isinstance(exception_mixin, ExceptionMixin)

# Generated at 2022-06-21 23:10:16.210404
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass


# Generated at 2022-06-21 23:10:22.078949
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    import sanic.exceptions
    import pytest

    app = Sanic('test_ExceptionMixin')
    app_name = 'test_exception_mixin'

    @app.exception(Exception)
    async def internal_server_error(request, exception):
        raise sanic.exceptions.ServerError(
            "It's not you, it's me", status_code=500)

    @app.exception(sanic.exceptions.ServerError)
    async def server_error(request, exception):
        return await response.text('OK', status=500)

    @app.exception(sanic.exceptions.NotFound)
    async def not_found(request, exception):
        return response.text('Not Found', status=404)


# Generated at 2022-06-21 23:10:22.951634
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e is not None


# Generated at 2022-06-21 23:10:23.350409
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin

# Generated at 2022-06-21 23:10:27.582450
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    blueprint = Blueprint("b")
    blueprint.exception.__name__ == "exception"

# Generated at 2022-06-21 23:10:33.618712
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

    t = TestExceptionMixin()
    assert t is not None
    assert len(t._future_exceptions) == 0

    assert t.exception is TestExceptionMixin.exception


# Generated at 2022-06-21 23:10:39.716894
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from unittest import TestCase

    class DummyExceptionHandler:
        pass

    bp = Blueprint(__name__)
    bp.exception(NotImplementedError)(DummyExceptionHandler)

    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:10:49.538844
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions = set()
            self._future_exceptions.add(FutureException(None, [ValueError]))

        def _apply_exception_handler(self, handler: FutureException):
            return

    a = DummyExceptionMixin()
    assert isinstance(a.exception(ValueError), type(a.exception))

# Generated at 2022-06-21 23:10:55.895851
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

    testExceptionMixin = TestExceptionMixin()
    assert testExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:11:02.904342
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception
    def exception():
        print("exception")
        return None
    assert exception() is None

# Generated at 2022-06-21 23:11:11.469782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_restplus import Api
    api = Api()
    from sanic.response import text
    from unittest import mock

    @api.exception(Exception)
    def test(error):
        return text(error.args[0])

    assert api._future_exceptions
    assert len(api._future_exceptions) == 1
    assert callable(api._future_exceptions.pop().handler)

    with mock.patch.object(api.__class__, '_apply_exception_handler'):
        assert api.exception(Exception)(text)

# Generated at 2022-06-21 23:11:18.853816
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestingExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    testing_exception_mixin = TestingExceptionMixin()
    assert testing_exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:11:24.098228
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception.__doc__ == """
        This method enables the process of creating a global exception
        handler for the current blueprint under question.

        :param args: List of Python exceptions to be caught by the handler
        :param kwargs: Additional optional arguments to be passed to the
            exception handler

        :return a decorated method to handle global exceptions for any
            route registered under this blueprint.
        """
    assert ExceptionMixin.exception.__name__ == "exception"
    assert ExceptionMixin.exception.__qualname__ == "ExceptionMixin.exception"
    assert ExceptionMixin.exception.__module__ == "sanic.models.app"

# Generated at 2022-06-21 23:11:28.302400
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    import pytest
    with pytest.raises(AttributeError):
        # Test exception when blueprint has not been initialized with the blueprint method
        blueprint = Blueprint('blueprint')
        blueprint.exception()



# Generated at 2022-06-21 23:11:30.973244
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    assert obj.exception()

# Generated at 2022-06-21 23:11:41.305392
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import InvalidUsage

    # Given
    class Handler1:
        def __await__(self):
            pass
    class Handler2:
        def __await__(self):
            pass

    # When
    bp = Blueprint("test_bp")
    h1 = Handler1()
    h2 = Handler2()
    ret1 = bp.exception(InvalidUsage)(h1)
    ret2 = bp.exception([InvalidUsage])(h2)

    # Then
    assert ret1 is h1
    assert ret2 is h2
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 2
    for exception in bp._future_exceptions:
        assert isinstance(exception, FutureException)

# Generated at 2022-06-21 23:11:51.264725
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)
            assert handler.function(1) == future_exception.function(1)
            assert handler.exceptions == future_exception.exceptions

    future_exception = FutureException(lambda x: x, (ValueError,))

    test_sanic = TestExceptionMixin()
    assert len(test_sanic._future_exceptions) == 0
    test_sanic.exception(ValueError)(lambda x: x)
    assert len(test_sanic._future_exceptions) == 1
    assert future_exception in test_sanic._future_exceptions


__all__ = ["ExceptionMixin"]

# Generated at 2022-06-21 23:11:56.805030
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    def any_handler(*args):
        return "Exception handler"

    class Blueprint(ExceptionMixin):
        pass

    bp = Blueprint()

    # Act
    bp.exception(TypeError)(any_handler)

    future_exceptions = bp._future_exceptions

    # Assert
    assert len(future_exceptions) == 1

    future_exception = future_exceptions.pop()
    assert future_exception.exceptions == (TypeError,)
    assert future_exception.handler == any_handler

# Generated at 2022-06-21 23:12:05.504969
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class SoruceExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, future_handler):
            print(future_handler.handler)

    bluep = SoruceExceptionMixin()
    print(f'1. : {bluep._future_exceptions}')
    @bluep.exception(IndexError, NameError)
    def fun(*args, **kwargs):
        print('excetion handler')

    print(f'2. : {bluep._future_exceptions}')

    # print(f'3. : {getattr(fun, 'exceptions')}')


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:12:13.711588
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception(): pass

#Unit test for method _apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-21 23:12:16.728991
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_ExceptionMixin', url_prefix='test')
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:12:18.289766
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    obj = TestExceptionMixin()
    assert obj.exception()

# Generated at 2022-06-21 23:12:20.161193
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert {} == obj._future_exceptions


# Generated at 2022-06-21 23:12:20.681757
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:12:25.726121
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler is not None

    blueprint = Blueprint()
    assert blueprint._future_exceptions is not None



# Generated at 2022-06-21 23:12:30.810199
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Base:
        def _apply_exception_handler(handler):
            pass

    class A(ExceptionMixin, Base):
        def __init__(self):
            self._blueprint_exceptions = set()
            super().__init__()

    a = A()
    @a.exception(IndexError)
    def handler():
        pass

    assert len(a._blueprint_exceptions) == 1
    assert len(a._future_exceptions) == 1
    assert a._future_exceptions.pop().handler == handler

# Generated at 2022-06-21 23:12:39.841628
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    Test Case:
    1: Test whether future_exceptions have been initialized
    2: Ensure that ExceptionMixin is an abstract class.
    3: Ensure that the Exception class is throwing an error with not implemented abstract method.
    """
    from sanic.blueprints  import Blueprint
    bp = Blueprint("Test_ExceptionMixin")
    assert bp._future_exceptions == set()
    try:
        bp._apply_exception_handler(Exception)
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 23:12:41.926669
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    If user call this method then decorator function should return

    '''
    class Mixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    def handler():
        pass

    def decorator(handler):
        return handler

    mixin = Mixin()
    assert mixin.exception(handler) == decorator(handler)

# Generated at 2022-06-21 23:12:45.914292
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test exception of ExceptionMixin
    """
    #Arrange
    import sanic.response
    import sanic.exceptions

    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    exceptionMixin = _ExceptionMixin()
    #Act
    @exceptionMixin.exception(sanic.exceptions.UnsupportedMediaType)
    async def unsupported_media_type_handler(request, exception):
        pass

    #Assert
    assert(exceptionMixin._future_exceptions)
    assert(len(exceptionMixin._future_exceptions) == 1)

# Generated at 2022-06-21 23:13:01.254874
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:13:05.702648
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    obj = TestExceptionMixin()
    assert len(obj._future_exceptions) == 0
    @obj.exception(Exception)
    def test():
        pass
    assert len(obj._future_exceptions) == 1

# Generated at 2022-06-21 23:13:09.120018
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        _future_exceptions: Set[FutureException]

    test = Test()
    assert test._future_exceptions == set()


# Generated at 2022-06-21 23:13:18.250882
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import TestCase
    from sanic import Blueprint

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException): ...

    blueprint = Blueprint(__name__)
    test = TestExceptionMixin()
    @test.exception(Exception)
    def exception_handler(request: Request, exception: Exception): ...

# Generated at 2022-06-21 23:13:28.242937
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    GIVEN: A class of ExceptionMixin
    WHEN: Call the constructor of ExceptionMixin
    THEN: The constructor will initialize the self._future_exceptions to an
    empty set
    """
    class TestExceptionMixin1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
    mock_mixin1 = TestExceptionMixin1()

    assert(not mock_mixin1._future_exceptions)


# Generated at 2022-06-21 23:13:32.388787
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('my_blueprint', url_prefix='/blueprint')
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:13:38.606225
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    _emp = _ExceptionMixin()
    assert(_emp._future_exceptions == set())

# Generated at 2022-06-21 23:13:44.496870
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    foo = Foo()
    result = foo.exception(Exception)
    assert 'decorator' in str(result)

# Generated at 2022-06-21 23:13:47.102042
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert ex._future_exceptions == set()


# Generated at 2022-06-21 23:13:50.774637
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class App(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    @App.exception(ValueError)
    def handler(request, exception):
        pass

    assert len(App._future_exceptions) == 1

# Generated at 2022-06-21 23:14:22.396610
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert (isinstance(e,ExceptionMixin))


# Generated at 2022-06-21 23:14:23.554245
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blue = Blueprint('foo-blueprint')
    blue.exception(ValueError)(print)

# Generated at 2022-06-21 23:14:27.191027
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    bp = Blueprint('test_bp')
    assert(set() == bp._future_exceptions)



# Generated at 2022-06-21 23:14:29.016360
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e=ExceptionMixin()
    assert e._future_exceptions==set()


# Generated at 2022-06-21 23:14:37.577680
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    class b(Blueprint):
        def __init__(self, *args, **kwargs):
            super(b,self).__init__(*args, **kwargs)
    bb=b()

    @bb.exception(Exception)
    def handler(request, exception):
        return response.text('Internal server error', 500)
    assert isinstance(handler, Blueprint)

# Generated at 2022-06-21 23:14:38.367874
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()


# Generated at 2022-06-21 23:14:50.059479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.server import HttpProtocol
    from sanic.response import json
    from sanic.exceptions import abort

    @HttpProtocol.exception(ZeroDivisionError)
    def zero_exception_handler(request, exception):
        return json({"error": "can not divide by zero "}, status=500)

    class TestException(Exception):
        pass

    @HttpProtocol.exception(TestException)
    def test_exception_handler(request, exception):
        return json({"error": str(exception)}, status=501)

    @HttpProtocol.exception([ValueError, TypeError])
    def value_type_exception_handler(request, exception):
        return json({"error": str(exception)}, status=502)


# Generated at 2022-06-21 23:14:50.461014
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
   ExceptionMixin()

# Generated at 2022-06-21 23:14:54.199591
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    exception_mixin = TestExceptionMixin()

    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:14:58.197361
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint("blueprint")
    FutureException.add(blueprint, None)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-21 23:16:08.344313
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    test = Test()
    assert test._future_exceptions == set()

# Generated at 2022-06-21 23:16:08.894388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-21 23:16:17.780869
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test', 'test', url_prefix='/test')
    @bp.exception(IndexError)
    def handle_index_error(request, exception):
        pass

    @bp.exception([IndexError, ZeroDivisionError], apply=False)
    def handle_index_and_zero_division_error(request, exception):
        pass

    assert len(bp._future_exceptions) == 2
    assert bp._future_exceptions.pop().handler == handle_index_and_zero_division_error
    assert bp._future_exceptions.pop().handler == handle_index_error

# Generated at 2022-06-21 23:16:23.530310
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with patch('os.path.isfile', return_value=True):
        # Create instance of class ExceptionMixin
        instance = ExceptionMixin()
        assert isinstance(instance, ExceptionMixin) is True
        # Create moc of decorator
        def decorator(handler):
            # Return handler
            return handler
        instance.exception = decorator
        # Call method exception of class ExceptionMixin
        result = instance.exception('a', 'b', 'c')
        assert isinstance(result, str) and result == 'a'

# Generated at 2022-06-21 23:16:28.882237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():


    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler
    from sanic.exceptions import SanicException
    from sanic import Sanic
    from sanic.wrappers.request_wrapper import RequestParameters

    blueprint = Blueprint(__name__, url_prefix="/")

    @blueprint.exception(SanicException)
    def test_handler(request: RequestParameters, exception: SanicException):
        return exception.status_code, exception.message

    @blueprint.listener("before_server_start")
    def attach(app: Sanic, loop):
        app.error_handler.add(blueprint)

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(blueprint)
    app.blueprint(blueprint)


# Generated at 2022-06-21 23:16:32.218067
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        setattr(ExceptionMixin, 'exception', lambda *args : 1/0)
        assert False, 'Exception not raised'
    except ZeroDivisionError:
        pass

# Generated at 2022-06-21 23:16:32.757491
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:16:40.534267
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def valueError_handler(request, exception):
        pass
    assert str(valueError_handler) == '<function ExceptionMixin.exception.<locals>.decorator.<locals>.handler at 0x7f4c2d4ef3b0>' # noqa
    assert valueError_handler.__name__ == 'handler'
    assert str(valueError_handler.__code__) == '<code object handler at 0x7f4c2d4efa30, file "sanic/models/exception_mixin.py", line 32>' # noqa

# Generated at 2022-06-21 23:16:44.644951
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a class inheriting from ExceptionMixin
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert len(self._future_exceptions) == 1
            assert handler == next(iter(self._future_exceptions))


    def handler():
        pass

    # use instance of the class to test the exception method
    b = Blueprint()
    b.exception(Exception)(handler)

# Generated at 2022-06-21 23:16:47.940096
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    obj = Test_ExceptionMixin()
    assert obj._future_exceptions == set()