

# Generated at 2022-06-21 23:09:18.904627
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    Unit test for method exception of class ExceptionMixin
    '''
    
    mixin = ExceptionMixin()
    mixin.exception(NotImplementedError, apply=False)

    # Should not be of type FunctionType since apply=False
    assert not isinstance(mixin.exception, type(test_ExceptionMixin_exception))

    # Should be of type FunctionType since apply=True
    assert isinstance(mixin.exception(NotImplementedError), type(test_ExceptionMixin_exception))

# Generated at 2022-06-21 23:09:29.040928
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__( *args, **kwargs)
            self.app = 'app'

        def test_handler(self, request, exception):
            raise NotImplementedError

        def _apply_exception_handler(self, handler):
            return handler

    test_class = TestClass()
    test_class.exception(Exception, apply=True)(test_class.test_handler)
    assert len(test_class._future_exceptions) == 1
    assert len(test_class._future_exceptions.pop().exceptions) == 1

# Generated at 2022-06-21 23:09:40.643808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # create class to be tested
    class ClassExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    obj = ClassExceptionMixin()

    # test exception method
    @obj.exception(AssertionError, apply=False)
    def add(x, y):
        return x + y

    @add.exception(KeyError, apply=False)
    def sub(x, y):
        return x - y

    @add.exception(ZeroDivisionError, apply=False)
    def mul(x, y):
        return x * y

    @add.exception(Exception, apply=False)
    def div(x, y):
        return x / y


# Generated at 2022-06-21 23:09:51.708256
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest

    class ExceptionMixinTest(ExceptionMixin, dict):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)
            dict.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self['handler'] = handler
            self['exception'] = handler.exceptions
            self['fn'] = handler.fn

    test_obj = ExceptionMixinTest()
    def fn(request, exception):
        return '1'

    test_obj.exception(Exception)(fn)

    # handler type
    assert isinstance(test_obj['handler'], FutureException)
    # handler fn
    assert test_obj['fn'] == fn


# Generated at 2022-06-21 23:10:01.782092
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    TestExceptionMixin.__bases__ += (ExceptionMixin,)
    from sanic.response import text
    from sanic.exceptions import ServerError, InvalidUsage, NotFound

    @TestExceptionMixin.exception(InvalidUsage)
    def handler_invalid_usage_1(request, exception):
        return text('Invalid Usage')

    @TestExceptionMixin.exception(NotFound)
    def handler_not_found(request, exception):
        return text('Not Found')


# Generated at 2022-06-21 23:10:06.244157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with pytest.raises(NotImplementedError):
        class BlueprintExceptionMixin(ExceptionMixin): ...
        b = BlueprintExceptionMixin()
        def handler(): ...
        b.exception(Exception)(handler)()

# Generated at 2022-06-21 23:10:13.867236
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    Sanic = Sanic()

    @Sanic.exception
    def exception(request, exception):
        return text('Internal server error', 500)

    assert len(Sanic._future_exceptions) == 1
    assert Sanic._future_exceptions.pop().handler == exception

# Generated at 2022-06-21 23:10:17.417092
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    @ExceptionMixin.exception(ValueError, apply=False)
    def test_function(request, exception):
        return request

    ExceptionMixin(test_function)

# Generated at 2022-06-21 23:10:22.856440
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic.exceptions import NotFound, ServerError, abort
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = sanic.Sanic()
    test_bp = sanic.Blueprint("test_bp")

    @test_bp.exception(NotFound)
    def handle_404(request, exception):
        return text("You are lost", status=404)

    @test_bp.exception(ServerError)
    def handle_500(request, exception):
        return text("We messed up", status=500)

    test_bp.add_route(
        HTTPMethodView.as_view("test_route", get=lambda *args, **kwargs: abort(404)),
        "/exception")


# Generated at 2022-06-21 23:10:27.839849
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    obj = TestExceptionMixin()

    assert len(obj._future_exceptions) == 0


# Generated at 2022-06-21 23:10:39.332033
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Unit test for method exception
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test', url_prefix='test')
    assert blueprint.exception
    assert blueprint.exception(Exception)
    assert blueprint.exception(Exception, Exception, apply=False)
    assert blueprint.exception(Exception, Exception, ValueError, apply=True)
    assert blueprint.exception([Exception, Exception], apply=True)
    assert blueprint.exception([Exception, Exception], apply=False)



# Generated at 2022-06-21 23:10:42.472962
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	except1 = ExceptionMixin()
	assert except1._future_exceptions == set()


# Generated at 2022-06-21 23:10:50.707951
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test1(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    class Me():
        pass

    me = Me()

    @me.exception(Exception)
    def handler(request, exception):
        pass

    test = test1()

    assert len(test._future_exceptions) == 0
    test.exception(Exception)(handler)
    assert len(test._future_exceptions) == 1

# Generated at 2022-06-21 23:10:51.724818
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-21 23:10:53.717606
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprint import Blueprint
    bp = Blueprint('somename')
    assert isinstance(bp, ExceptionMixin)

# Generated at 2022-06-21 23:10:57.457769
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    m = ExceptionMixin()
    # example:
    #   m.exception(NameError, AttributeError)(foo_exception)
    #   m.exception(NameError, AttributeError, apply=False)(bar_exception)
    assert m.exception(NameError, AttributeError)
    assert m.exception(NameError, AttributeError, apply=False)

# Generated at 2022-06-21 23:10:59.147559
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp_test = BlueprintTest()
    bp_test.exception(1, "abc")(123)
    assert bp_test._future_exceptions


# Generated at 2022-06-21 23:11:04.721861
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ClassExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    class_ = ClassExceptionMixin()
    handler = class_.exception(IndexError)(handler)
    assert handler.exceptions == (IndexError, )
    assert handler.handler is handler

# Generated at 2022-06-21 23:11:10.480310
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    mock_exception_mixin = MockExceptionMixin()
    assert isinstance(mock_exception_mixin, MockExceptionMixin)
    assert isinstance(mock_exception_mixin, ExceptionMixin)

# Generated at 2022-06-21 23:11:13.220743
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-21 23:11:23.273679
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        async def _apply_exception_handler(self, handler: FutureException):
            return self._future_exceptions.add(handler)

    bp = TestExceptionMixin()
    assert len(bp._future_exceptions) == 0

    @bp.exception(ZeroDivisionError)
    async def handler(request, exception):
        return 'hello'

    assert len(bp._future_exceptions) == 1
    expected = FutureException(handler, (ZeroDivisionError,))
    assert bp._future_exceptions.pop() == expected

# Generated at 2022-06-21 23:11:23.761092
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-21 23:11:28.300089
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args):
            super().__init__(*args)
    a = A()
    assert isinstance(a._future_exceptions, set)
    assert not a._future_exceptions

# Generated at 2022-06-21 23:11:38.599525
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp")

    # The method exception does not have any logic, we test it by
    # verifying the returned FutureException has the expected attributes.

    @bp.exception(Exception)
    def test_exception_handler(request, exception):
        return

    assert len(bp._future_exceptions) == 1
    future_exception = next(iter(bp._future_exceptions))
    assert future_exception.handler == test_exception_handler
    assert future_exception.exceptions == (Exception,)

# Generated at 2022-06-21 23:11:50.798628
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def create_mixin(should_raise=False):
        class _Mixin(ExceptionMixin):
            def __init__(self):
                self._applied_exception = None
            def _apply_exception_handler(self, handler):
                self._applied_exception = handler
                if should_raise:
                    raise ValueError("Failed")

        return _Mixin()

    x = create_mixin()

    def handler(request, exception): return None

    x.exception(handler)

    assert isinstance(next(iter(x._future_exceptions)), FutureException)
    assert len(x._future_exceptions) == 1

    assert len(next(iter(x._future_exceptions)).exceptions) == 1
    assert next(iter(x._future_exceptions)).handler == handler

    assert x._

# Generated at 2022-06-21 23:11:52.237541
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: How to unit test?
    pass

# Generated at 2022-06-21 23:11:56.562986
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    b: Blueprint = Blueprint()
    assert b._future_exceptions == set()

# Generated at 2022-06-21 23:12:00.653901
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # GIVEN
    class ExceptionMixinStub(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # WHEN
    sut = ExceptionMixinStub()

    # THEN
    assert sut.exception((Exception,))

# Generated at 2022-06-21 23:12:02.693098
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert (ExceptionMixin)


# Generated at 2022-06-21 23:12:08.019194
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blueprint = Blueprint("Test", url_prefix="/")

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        pass

    #will fail if assertion error because decorator will add exception_handler
    # to a dictionary, and if it has more than one means it's been re-added
    assert len(blueprint.exception_handlers) == 1

# Generated at 2022-06-21 23:12:20.637158
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Get function to test
    import Blueprint
    blup = Blueprint.Blueprint('abc')
    obj = ExceptionMixin(blup)
    exception_func = obj.exception

    # Explanation
    assert exception_func != None, "The method exception does not exist"
    assert callable(exception_func) == True, "The method exception does not callable"

    # Test
    # class error
    # def error():
    #     print("error")
    # obj = exception_func(error)

    # assert isinstance(obj, FutureException) == True, "The method exception does not return a FutureException object"

# Generated at 2022-06-21 23:12:25.686470
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    class Main(ExceptionMixin):
        pass
    test = Main()
    @test.exception(ValueError)
    def test_func(request, exception):
        return exception
    assert isinstance(test_func, tuple)
    assert callable(test_func[0])
    sanic.response.HTTPResponse

# Generated at 2022-06-21 23:12:30.301888
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    # Test intialization without parameters
    my_mixin = TestExceptionMixin()
    assert my_mixin._future_exceptions is set()

    # Test initialization with wrong parameters
    with pytest.raises(TypeError):
        my_mixin = TestExceptionMixin("a", "b")

# Generated at 2022-06-21 23:12:42.311568
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class M:
        def __init__(self, throw_exception=False):
            self.handler = None
            self.exception_list = None
            self.throw_exception = throw_exception
        def _apply_exception_handler(self, handler: FutureException):
            self.exception_list = handler.exception_list
            self.handler = handler.handler
            if self.throw_exception:
                raise Exception('Unable to apply handler')

    # 1. exception method returns decorator
    args = ('my_exception',)
    decorator = M().exception(*args)
    assert callable(decorator)

    # 2. decorator returns handler
    handler = decorator(lambda x: x)

# Generated at 2022-06-21 23:12:43.794796
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    mixin = ExceptionMixin()

    assert mixin._future_exceptions == set()
    assert isinstance(mixin._future_exceptions, Set)


# Generated at 2022-06-21 23:12:48.392257
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp1=Blueprint(__name__, url_prefix='test', host='test', strict_slashes=True)
    assert isinstance(bp1._future_exceptions, set)


# Generated at 2022-06-21 23:12:49.691475
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:12:56.482139
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test_ExceptionMixin_exception')
    blueprint.exception(Exception)(lambda request, exception: print('internal server error'))

    @blueprint.route('/test_ExceptionMixin_exception')
    def handler(request):
        from sanic import SanicException
        raise SanicException('error')
    app.blueprint(blueprint)
    request, response = app.test_client.get('/test_ExceptionMixin_exception')
    assert response.text == 'internal server error'

# Generated at 2022-06-21 23:12:57.470624
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()


# Generated at 2022-06-21 23:12:58.826485
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    app = ExceptionMixin()
    assert app._future_exceptions == set()

# Generated at 2022-06-21 23:13:19.127295
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return Null

    exception_mixin_test = ExceptionMixinTest()
    assert exception_mixin_test._future_exceptions == set()

# Generated at 2022-06-21 23:13:30.902737
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.app = sanic.Sanic('Test ExceptionMixin')

        def _apply_exception_handler(self, handler: FutureException):
            self.app.error_handler.add(handler.exceptions, handler.handler)
            self.app.error_handler.default(handler.handler)

    instance = TestExceptionMixin()
    #
    handler = instance.exception('a')
    assert callable(handler)
    assert handler.__name__ == 'a'
    #
    handler = instance.exception(['a'])
    assert callable(handler)
    assert handler.__name__ == 'a'
    #

# Generated at 2022-06-21 23:13:38.484760
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    exm = TestExceptionMixin()
    assert exm is not None
    assert exm._future_exceptions is not None


# Generated at 2022-06-21 23:13:40.120262
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler(None)

# Generated at 2022-06-21 23:13:45.393068
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    emt = ExceptionMixinTest()
    assert emt._future_exceptions == set()


# Generated at 2022-06-21 23:13:48.148999
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    bp = Blueprint('test')
    assert isinstance(bp, ExceptionMixin)
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 0


# Generated at 2022-06-21 23:13:51.728735
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin is not None
    assert len(exception_mixin._future_exceptions) == 0

# Generated at 2022-06-21 23:13:54.343449
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint_instance = ExceptionMixin()
    assert blueprint_instance._future_exceptions == set()


# Generated at 2022-06-21 23:13:58.282767
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test1 = ExceptionMixin()
    assert test1._future_exceptions == set()
    assert test1._future_exceptions == test1._future_exceptions


# Generated at 2022-06-21 23:13:59.253965
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-21 23:14:42.004761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test the exception attribute of ExceptionMixin

    # Define a class TestExceptionMixin to test ExceptionMixin
    class TestExceptionMixin():
        def __init__(self):
            from sanic.blueprints import Blueprint
            self.blueprint = Blueprint('TestExceptionMixin')
            self.uri_template = '/test'
            self.url = '/test'
            self._future_exceptions = []
            self.exception = ExceptionMixin.exception

    # Test the situation that Blueprint_exception_handler has not been created before exception
    # of ExceptionMixin is called
    test_ExceptionMixin = TestExceptionMixin()
    @test_ExceptionMixin.blueprint.exception(ZeroDivisionError)
    def test1(request, exception):
        pass

    # Test the situation that Blueprint_exception_handler has been

# Generated at 2022-06-21 23:14:44.241962
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Object(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    obj = Object()
    assert obj._future_exceptions == set()


# Generated at 2022-06-21 23:14:48.520685
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTestClass(ExceptionMixin):
        def test_function(self):
            pass

    exceptionMixinTestClass = ExceptionMixinTestClass()

    assert exceptionMixinTestClass._future_exceptions is not None
    assert exceptionMixinTestClass._future_exceptions == set()

# Generated at 2022-06-21 23:14:57.819522
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json

    class TestException(ExceptionMixin):
        pass

    @TestException.exception(ValueError, apply=False)
    def exception_handler(request, exception):
        return json({"error": str(exception)}, 400)

    assert isinstance(TestException, ExceptionMixin)
    assert isinstance(TestException._future_exceptions, set)
    assert isinstance(TestException._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:15:00.252084
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)

# Generated at 2022-06-21 23:15:10.081021
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    app.config.REQUEST_MAX_SIZE = None

    bp = Blueprint('test_bp', url_prefix='/bp')

    exceptions = ZeroDivisionError, ArithmeticError
    
    @bp.exception(*exceptions, apply=True)
    def handler(request, exception):
        return text('Milky Way')

    @bp.route('/', methods=['GET'])
    async def handler2(request):
        return text('Milky Way')

    expected = 'Milky Way'
    app.blueprint(bp)

    _, response = app.test_client.get('/bp/')
    result = response.text

    assert expected == result


# Generated at 2022-06-21 23:15:12.667274
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m._future_exceptions == set()



# Generated at 2022-06-21 23:15:15.722587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Support for classmethod

    # TODO: Exception handler
    
    # TODO: apply=False
    pass

# Generated at 2022-06-21 23:15:22.990173
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    exceptions = (ValueError, TypeError)
    fake_object = FakeExceptionMixin()
    @fake_object.exception(*exceptions)
    def handler():
        return 0

    fake_object._future_exceptions

    future_exception = FutureException(handler, exceptions)
    assert future_exception in fake_object._future_exceptions

    def test_exception_1():
        """
        Test the method exception for exception which is not a tuple, but
        a list of exceptions.
        """

        class FakeExceptionMixin(ExceptionMixin):
            def _apply_exception_handler(self, handler):
                pass

        exceptions = [ZeroDivisionError, TypeError]
        fake_object

# Generated at 2022-06-21 23:15:29.709123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(test_ExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, exception_handler):
            assert isinstance(exception_handler, FutureException)

    def test_handler(*args, **kwargs):
        args_len = len(args)
        assert args_len > 0

    obj = test_ExceptionMixin()
    obj.exception(Exception)(test_handler)()

# Generated at 2022-06-21 23:16:44.101362
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    class ExceptionMixin1(ExceptionMixin):
        pass
    
    exception_mixin = ExceptionMixin1()

    # Act
    # Assert
    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(exception_mixin, ExceptionMixin1)


# Generated at 2022-06-21 23:16:47.773673
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            return
    
    mock = MockExceptionMixin()
    assert mock._future_exceptions == set()


# Generated at 2022-06-21 23:16:50.084813
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test_bp")
    assert isinstance(blueprint, ExceptionMixin)
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:16:59.500545
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    test_blueprint = Blueprint("test",url_prefix="test")
    @test_blueprint.exception(TypeError)
    async def test_handler():
        return "test_handler"
    future_exception = test_blueprint._future_exceptions.pop()
    assert future_exception.handler == test_handler
    assert future_exception.exceptions == (TypeError,)
    @test_blueprint.exception([TypeError,OSError])
    async def test_handler1():
        return "test_handler1"
    future_exception = test_blueprint._future_exceptions.pop()
    assert future_exception.handler == test_handler1
    assert future_exception.exceptions == (TypeError,OSError)

# Generated at 2022-06-21 23:17:01.141918
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert(type(exception_mixin._future_exceptions) == set)



# Generated at 2022-06-21 23:17:09.946978
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(handler):
            pass

    def f(exception):
        assert exception.f == f
        assert exception.args == (RuntimeException,)
        assert exception.kwargs == {'key': 'value'}

    c = TestClass()
    _ = c.exception(RuntimeException, key='value')(f)
    assert len(c._future_exceptions) == 1
    assert c._future_exceptions == set([FutureException(f, (RuntimeException,))])

# Generated at 2022-06-21 23:17:11.337145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO
    assert False

# Generated at 2022-06-21 23:17:23.073110
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    class TestClass(ExceptionMixin):
        # arrange
        @property
        def _exception_handler(self):
            return {}

        # arrange
        def _add_exception_handler(self, *args, **kwargs):
            pass

        # arrange
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    # act
    test_class = TestClass()
    test_class.exception(ValueError, KeyError, apply=True)(print)

    # assert
    test_exception = test_class._future_exceptions.pop()
    assert test_exception.handler == print
    assert test_exception.exceptions == (ValueError, KeyError)

# Generated at 2022-06-21 23:17:24.516476
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)

# Generated at 2022-06-21 23:17:26.895279
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions is not None