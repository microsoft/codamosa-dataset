

# Generated at 2022-06-21 23:09:29.409294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}

    mixin = ExceptionMixin()
    decorator = mixin.exception(*args, **kwargs)
    handler = lambda : None
    decorator(handler)

    future_exception = future_exception = FutureException(handler, args)
    assert future_exception in mixin._future_exceptions



# Generated at 2022-06-21 23:09:38.140640
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)
            assert isinstance(handler.handler, type(lambda x: None))

    test = Test()
    test.exception(ZeroDivisionError, IOError)(lambda x: None)

# Generated at 2022-06-21 23:09:40.737987
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:09:42.348973
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():    
    exception_mixin = ExceptionMixin("arg1", "arg2")

    assert exception_mixin is not None

# Generated at 2022-06-21 23:09:52.246012
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('bp', url_prefix='bp')
    assert hasattr(bp, '_future_exceptions')
    assert bp._future_exceptions == set()
    assert callable(bp.exception)
    @bp.exception(404)
    def test_handler(request, exception, args, kwargs):
        'test'

    assert callable(test_handler)
    assert 'test' == test_handler('request', 'exception', 'args', 'kwargs')

    # assert the test_handler was added to _future_exceptions in bp
    raised = False
    try:
        assert test_handler in bp._future_exceptions
    except AssertionError:
        raised = True
    finally:
        assert not raised

    #assert test_

# Generated at 2022-06-21 23:09:58.371508
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)
    testexceptionmixin = TestExceptionMixin()
    assert type(testexceptionmixin._future_exceptions) is set

# Generated at 2022-06-21 23:10:11.453356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import exceptions as sanic_exceptions
    from sanic.web import Blueprint
    blueprint = Blueprint('test', url_prefix='')
    thrown = False
    @blueprint.exception([sanic_exceptions.InvalidUsageException, ValueError, Exception])
    def exception_handler(request, exception):
        nonlocal thrown
        thrown = True
    try:
        raise ValueError('Testing')
    except:
        blueprint.exception_handler(None, None)
    assert thrown
    try:
        raise sanic_exceptions.InvalidUsageException('Testing InvalidUsageException')
    except:
        blueprint.exception_handler(None, None)
    assert thrown
    try:
        raise Exception('Testing Exception')
    except:
        blueprint.exception_handler(None, None)
    assert thrown
   

# Generated at 2022-06-21 23:10:17.749008
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

    emt = ExceptionMixinTest()
    assert _future_exceptions in emt.__dict__
    assert emt._future_exceptions == set()

# Class used as a unit test for method ExceptionMixin.exception

# Generated at 2022-06-21 23:10:20.164230
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    assert ExceptionMixin
    assert TestExceptionMixin
    test = TestExceptionMixin()
    assert test

# Generated at 2022-06-21 23:10:21.115178
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:10:28.684226
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test = Test()
    test.exception(Exception)
    # Check if there is one future_exception
    assert len(test._future_exceptions) == 1
    # Check if the future_exception is an instance of FutureException
    assert isinstance(list(test._future_exceptions)[0], FutureException)

# Generated at 2022-06-21 23:10:36.430747
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyClass(ExceptionMixin):
        pass

    init_tuple = (1, 2, 3)
    init_dict = {'first': 1, 'second': 2, 'third': 3}

    my_class = MyClass(*init_tuple, **init_dict)

    assert isinstance(my_class, ExceptionMixin)

# Generated at 2022-06-21 23:10:40.074560
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class myclass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    myclass()

# Generated at 2022-06-21 23:10:43.601037
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Type hinting test
    em = ExceptionMixin()
    em._future_exceptions = set()
    em._future_exceptions.add(1)

# Generated at 2022-06-21 23:10:46.200835
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin
    em.__init__(em)
    assert em is not None

# Generated at 2022-06-21 23:10:48.903067
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Handler:
        pass

    handler = Handler()
    assert isinstance(handler, Handler)

# Generated at 2022-06-21 23:10:56.064712
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException

    class FakeExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(FakeExceptionMixin, self).__init__(self)

        def _apply_exception_handler(self, handler):
            assert True

    fake_exception_mixin = FakeExceptionMixin()
    @fake_exception_mixin.exception(SanicException)
    def handle_exception(request, exception):
        pass

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:10:58.937767
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler(None)


# Generated at 2022-06-21 23:11:01.588905
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo:
        def __init__(self):
            pass

    o = Foo()
    o.__class__.__bases__ = (ExceptionMixin,)

    def handler(request):
        return True

    o.exception(TypeError)(handler)

# Generated at 2022-06-21 23:11:10.035987
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestObject(ExceptionMixin):
        pass
    try:
        t = TestObject()
        # Test only the handler is called.
        result = t.exception(ValueError)(lambda route, exception: 42)
        assert result == 42
        # Test that exception is added to future exceptions.
        assert result in t._future_exceptions
    except AssertionError:
        print("Method exception of class ExceptionMixin does not work")
        raise AssertionError


# Generated at 2022-06-21 23:11:18.329252
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test_bp')
    try:
        @bp.exception(apply=True)
        def test_handler():
            return

    except NotImplementedError:
        pass

    else:
        assert False

# Generated at 2022-06-21 23:11:19.716497
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(AttributeError)
    def get_404(request, exception):
        return text('404', status=404)

    assert get_404(AttributeError) == text('404', status=404)

# Generated at 2022-06-21 23:11:25.013226
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

    a_blueprint = test_blueprint()
    assert a_blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:11:27.013318
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)
    assert ExceptionMixin.exception.__name__ == "exception"

# Generated at 2022-06-21 23:11:28.688821
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint('blueprint')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:11:36.109660
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return True

    TestClass().exception(LookupError)
# End unit test

# Generated at 2022-06-21 23:11:36.898971
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception("abc")

# Generated at 2022-06-21 23:11:37.976251
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        pass
    bp = Blueprint()
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:11:50.195277
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.request import Request
    class Request(Request):
        def is_json(self):
            return True
    blueprint = Blueprint('test', url_prefix='/blueprint')
    @blueprint.exception(Exception)
    def custom_exception(request, exception):
        return text("An exception occurred: {}".format(exception))
    request = Request(url='/blueprint/hello', headers={}, version='1.1', method='GET', ip='127.0.0.1', app=None)
    e = Exception("A test exception.")
    response = Request.handle_request(request, None)
    assert response.text == "An exception occurred: A test exception."

# Generated at 2022-06-21 23:12:00.769163
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException

    @Blueprint.exception(SanicException)
    def test_err_handler(request, exception):
        return 'Exception: %s' % exception


    blueprint = Blueprint("Test", url_prefix="/")

    # Test if FutureException is added to future exception set
    assert blueprint._future_exceptions == {FutureException(test_err_handler, (SanicException,))}

    # Test if FutureException is added to future exception set
    blueprint.exception(SanicException)
    assert blueprint._future_exceptions == {FutureException(test_err_handler, (SanicException,))}


# Generated at 2022-06-21 23:12:06.609298
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(ExceptionMixin):
        pass
    
    MyException_inst = MyException()
    assert hasattr(MyException_inst, 'exception')
    assert isinstance(MyException_inst.exception, MethodType)
    assert callable(MyException_inst.exception)

# Generated at 2022-06-21 23:12:11.130913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)
    from sanic import Blueprint
    blueprint = Blueprint('test_blueprint', url_prefix='/test')
    blueprint.exception(ZeroDivisionError)
    blueprint.exception([ZeroDivisionError])
    blueprint.exception(ZeroDivisionError, apply=False)
    blueprint.exception([ZeroDivisionError], apply=False)

# Generated at 2022-06-21 23:12:15.980788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MethodExceptionTestClass:
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise Exception

    test_obj = MethodExceptionTestClass()

    def decorator():
        def handler():
            pass

        return handler

    test_obj.exception(Exception(), AssertionError())

    assert len(test_obj._future_exceptions) == 2

# Generated at 2022-06-21 23:12:22.078816
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Initialize a Sanic app
    app = Sanic(__name__)

    @app.exception(Exception)
    def test_exception_handler(request, exception):
        return text('Exception: %s' % exception)

    # Initialize an exception mixin instance
    exception_mixin = ExceptionMixin()

    # Test an exception handler
    @exception_mixin.exception(Exception)
    def test_exception_handler2(request, exception):
        return text('Exception: %s' % exception)

    # Test excetion decorator
    @app.route('/test/')
    async def test(request):
        raise Exception('test')

    request, response = app.test_client.get('/test/')
    assert response.text == 'Exception: test'

    # Test if exception was registered

# Generated at 2022-06-21 23:12:23.346359
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m._future_exceptions is not None

# Generated at 2022-06-21 23:12:28.163066
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_bool = True
    try:
        class TestExMixin(ExceptionMixin):
    
            def _apply_exception_handler(self, handler: FutureException):
                raise NotImplementedError  # noqa

        test_ExMixin = TestExMixin()
    except:
        test_bool = False

    assert test_bool == True


# Generated at 2022-06-21 23:12:35.149458
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test_bp")
    test_future_exception = FutureException(lambda x:x, (Exception, ))
    blueprint._future_exceptions.add(test_future_exception)

    assert blueprint.future_exceptions == {test_future_exception}


# Generated at 2022-06-21 23:12:46.831942
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            handler.exception = handler.exceptions[0]

    test = Test()
    assert test.exception
    assert test.exception()
    assert test.exception(KeyError)
    assert test.exception(KeyError, apply=False)
    assert test.exception([KeyError, ValueError])
    assert test.exception([KeyError, ValueError], apply=False)
    assert test.exception([KeyError, ValueError], apply=False)

    def exception_handler():
        pass


# Generated at 2022-06-21 23:12:48.466012
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:12:49.048327
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:13:01.227687
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exception import CompletionHandler, SanicNullHandlerException

    class TestException(Exception):
        pass

    class TestExceptionMixin(ExceptionMixin):
        __apply_exception_handler = False

        def _apply_exception_handler(self, handler: FutureException):
            if self.__apply_exception_handler:
                try:
                    handler.apply_handler(
                        request=None,
                        exception=TestException(),
                    )
                except TestException:
                    pass

    exception_mixin = TestExceptionMixin()

    @exception_mixin.exception(TestException)
    def exception_handler():
        raise TestException

    with pytest.raises(TestException):
        exception_handler()

    exception_mixin.__apply_exception_handler = True
    exception_handler()



# Generated at 2022-06-21 23:13:03.176954
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test = ExceptionMixinTest()
    assert isinstance(test._future_exceptions, set)


# Generated at 2022-06-21 23:13:11.066948
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BluePrint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print("Apply handler")

    def exception_handler_1():
        print("Test handler_1")

    def exception_handler_2():
        print("Test handler_2")

    blueprint = BluePrint()
    blueprint.exception()(exception_handler_1)
    blueprint.exception(apply=False)(exception_handler_2)

    assert len(blueprint._future_exceptions) == 2
    # no exception handler applied so far
    assert not blueprint.exceptions.exception_handlers

# Generated at 2022-06-21 23:13:15.291044
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('foo')
    @bp.exception(Exception)
    def catch_all(request, exception):
        return 'exception'

# Generated at 2022-06-21 23:13:17.867511
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()
    assert exceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:13:23.258281
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class exception_handler:
        def __init__(self, function, exceptions):
            self.function = function
            self.exceptions = exceptions

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            self._exception_handler = handler

        def TestException(self):
            self._exception_handler.function()

    test_ExceptionMixin = TestExceptionMixin()
    decorated_function_1 = test_ExceptionMixin.exception(ValueError, apply=False)
    decorated_function_2 = test_ExceptionMixin.exception(KeyError, apply=True)


# Generated at 2022-06-21 23:13:25.920024
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert instance._future_exceptions == set()


# Generated at 2022-06-21 23:13:27.321397
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()

# Generated at 2022-06-21 23:13:30.352254
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            super().__init__()

    a = ExceptionMixin1('/')
    assert a._future_exceptions == set()
    assert isinstance(a._future_exceptions, set)


# Generated at 2022-06-21 23:13:32.829759
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """description of test"""
    obj = ExceptionMixin()
    assert obj

# Generated at 2022-06-21 23:13:46.265922
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint()
    assert len(bp._future_exceptions) == 0
    bp.exception(Exception)(lambda x: None)
    
    assert isinstance(bp._future_exceptions[0], FutureException)
    assert bp._future_exceptions[0].handler is not None
    assert bp._future_exceptions[0].exceptions is not None
    assert bp._future_exceptions[0].handler(Exception) is None
    assert bp._future_exceptions[0].exceptions == Exception

# Generated at 2022-06-21 23:13:48.922847
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.config import Config
    config_object = Config()
    blueprint = Blueprint("B40", name="B40", url_prefix="/B40",
                          version="0.0.1", config=config_object)
    blueprint.exception(Exception)

# Generated at 2022-06-21 23:13:52.566314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint', url_prefix='/test/')
    blueprint.exception()

# Generated at 2022-06-21 23:13:57.029777
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()
    assert isinstance(exceptionMixin, ExceptionMixin)
    assert isinstance(exceptionMixin._future_exceptions, set)


# Generated at 2022-06-21 23:14:02.846328
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class TestException(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class TestException1(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    test = TestException(1)
    test1 = TestException1(2)
    assert test._future_exceptions == test1._future_exceptions

# Generated at 2022-06-21 23:14:06.124707
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SampleExceptionMixin(ExceptionMixin):
        pass
    assert SampleExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:14:13.093578
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = MockExceptionMixin()

    assert exception_mixin._future_exceptions == set()

    @exception_mixin.exception(Exception)
    def test(self, req: Request, exception: Exception):
        pass

    assert len(exception_mixin._future_exceptions) == 1

    @exception_mixin.exception(Exception, apply=False)
    def test(self, req: Request, exception: Exception):
        pass

    assert len(exception_mixin._future_exceptions) == 2

# Generated at 2022-06-21 23:14:16.468152
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    exceptions = ['error1', 'error2']
    def handler_exception(error):
        return 'exception handler'
    # act
    class Test(ExceptionMixin):
        pass
    test = Test()
    result = test.exception(*exceptions)(handler_exception)
    # assert
    assert result == handler_exception

# Generated at 2022-06-21 23:14:19.360764
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  # test creation of object for ExceptionMixin
  a=ExceptionMixin()
  print(a)

test_ExceptionMixin()

# Generated at 2022-06-21 23:14:21.774293
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:14:39.879230
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = Blueprint("", None, None, None)
    assert getattr(bp, "_future_exceptions", None) == set()


# Generated at 2022-06-21 23:14:43.133817
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:14:47.436203
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    app = Sanic()
    from sanic.blueprints import Blueprint
    bp = Blueprint('test', url_prefix='bp_test')
    from sanic.exceptions import ServerError
    @bp.exception(ServerError)
    def test(request, exception): pass
    app.blueprint(bp)
    assert bp._future_exceptions
    assert len(bp._future_exceptions) == 1
    exception = list(bp._future_exceptions)[0]
    assert exception.exceptions == (ServerError,)
    assert exception.handler
    assert bp.error_handler_spec

# Generated at 2022-06-21 23:14:55.546245
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import inspect
    class Foo(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    foo = Foo()
    foo.exception(Exception)
    assert next(iter(foo._future_exceptions)).handler == Foo.__dict__['exception'].__dict__['decorator'].__dict__['handler']

# Generated at 2022-06-21 23:14:57.756049
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions is not None

# Generated at 2022-06-21 23:14:58.508189
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:15:09.511771
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mixin = MyMixin()
    
    @mixin.exception(ValueError)
    def exception_handler():
        pass

    assert len(mixin._future_exceptions) == 1
    assert exception_handler in [x.handler for x in mixin._future_exceptions]
    
    @mixin.exception([ValueError])
    def exception_handler():
        pass

    assert len(mixin._future_exceptions) == 1
    assert exception_handler in [x.handler for x in mixin._future_exceptions]

    @mixin.exception(ValueError, apply = False)
    def exception_handler():
        pass


# Generated at 2022-06-21 23:15:20.184717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class Mock():
        def __init__(self) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._apply_exception_handler = lambda x: None

        def exception(self, *exceptions, apply=True):
            def decorator(handler):
                nonlocal self, exceptions, apply

# Generated at 2022-06-21 23:15:21.303108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-21 23:15:29.727638
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ''' Test of ExceptionMixin method exception '''

    class EmptyClass:

        def __init__(self):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class EmptyClassWithoutApplyMethod(ExceptionMixin, EmptyClass):
        pass

    # test for not implemented _apply_exception_handler
    class EmptyClassWithoutApplyMethod(ExceptionMixin, EmptyClass):
        pass

    empty_class = EmptyClassWithoutApplyMethod()
    with pytest.raises(NotImplementedError):
        @empty_class.exception(IndexError)
        def index_error_handler(request, exception):
            print("Index Error")

    # test for calling _apply_exception_handler:
    class EmptyClassApplyMethod(ExceptionMixin, EmptyClass):
        pass

    empty_

# Generated at 2022-06-21 23:16:08.138237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:16:09.997028
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    
    bp = Blueprint('')
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:16:19.997244
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    foo = []
    class MockClass:
        def __init__(self) -> None:
            self._future_exceptions: Set[FutureException] = set()
        def exception(self, *exceptions):
            def decorator(handler):
                nonlocal exceptions
                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                return handler
            return decorator

    c = MockClass()

    @c.exception(IndexError, "test")
    async def test(request):
        print("test")
        foo.append(1)

    assert len(c._future_exceptions) == 1
    assert foo == []
    test()
    assert foo == [1]

# Generated at 2022-06-21 23:16:20.678986
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:16:23.565004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # Create a new blueprint
    blueprint = Blueprint('test', url_prefix='test')

    assert '_future_exceptions' in blueprint.__dict__
    assert 'exception' in blueprint.__dict__



# Generated at 2022-06-21 23:16:28.135535
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    app = Sanic('test_app')
    blueprint = Blueprint('test_blueprint')
    blueprint.init_app(app)
    assert blueprint._future_exceptions == set()
    assert isinstance(blueprint._future_exceptions, set)

# Generated at 2022-06-21 23:16:35.540748
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from sanic.server import HttpProtocol
    from sanic.response import text
    app = Blueprint('Test Blueprint')
    @app.exception(Exception)
    def handler(request, exception):
        raise exception
    sanic_server = HttpProtocol(app, None)
    sanic_server._auto_apply_exception_handler()
    @app.route('/1')
    def handler(request):
        raise Exception('Test')



# Generated at 2022-06-21 23:16:37.602333
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance, ExceptionMixin)
    assert instance._future_exceptions == set()


# Generated at 2022-06-21 23:16:39.052337
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    def test_init(self):
        assert self._future_exceptions == set() # noqa



# Generated at 2022-06-21 23:16:39.951561
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:18:05.214767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            setattr(self, "handler", handler)

    e = ExceptionMixinTest()
    assert getattr(e, "handler", None) == None
    @e.exception(ValueError)
    def handler(request, err):
        print("handling")

    assert isinstance(getattr(e, "handler"), FutureException)
    assert getattr(e, "handler").handler == handler
    assert ValueError in getattr(e, "handler").exceptions
    assert e._future_exceptions == {getattr(e, "handler")}

    @e.exception([ValueError])
    def handler2(request, err):
        print("handling")


# Generated at 2022-06-21 23:18:05.975589
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-21 23:18:10.501277
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Subclass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self)

    s = Subclass()
    assert (s._future_exceptions == set())



# Generated at 2022-06-21 23:18:13.327731
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blue = Blueprint('test', url_prefix='test')
    assert blue._future_exceptions == set()

# Generated at 2022-06-21 23:18:18.078188
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler(Exception())
    assert not ExceptionMixin()._future_exceptions



# Generated at 2022-06-21 23:18:23.419818
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        exception_mixin = ExceptionMixin()
        assert exception_mixin._future_exceptions
    except Exception as err:
        print(err)
        assert False
    finally:
        print ("========== Unit test for constructor of class ExceptionMixin finished ==========")

# Generated at 2022-06-21 23:18:30.847251
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)

    @Test_ExceptionMixin().exception(ValueError, apply=False)
    def handler(request, exception):
        pass

    assert isinstance(handler, types.FunctionType)

# Generated at 2022-06-21 23:18:34.783780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # 1. Test if the method correctly assigns the passed in exceptions to an attribute
    # of the current route
    @app.route('/test', methods = ["GET"])
    @app.exception(ArithmeticError)
    def test(request):
        raise ArithmeticError
    
    assert test._exceptions == (ArithmeticError,)

# Generated at 2022-06-21 23:18:37.021818
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    sanic = Sanic()

    @sanic.exception()
    async def handler():
        pass

    assert len(sanic._future_exceptions) == 1

# Generated at 2022-06-21 23:18:46.248401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint()
    @bp.exception(ValueError)
    def value_error_handler(request, exception):
        return request, exception
    assert "value_error_handler" in bp.exception_handlers
    assert isinstance(bp.exception_handlers["value_error_handler"], tuple)
    assert ValueError in bp.exception_handlers["value_error_handler"]

# # Unit test for method exception of class Blueprint
# def test_Blueprint_exception():
#     from sanic.blueprints import Blueprint
#     bp = Blueprint()
#     @bp.exception(ValueError)
#     def value_error_handler(request, exception):
#         return request, exception
#     assert "value_error_handler" in bp.ex