

# Generated at 2022-06-21 23:09:20.392795
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass
    a = A()
    assert isinstance(a, ExceptionMixin)

# Generated at 2022-06-21 23:09:22.094898
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em

# Generated at 2022-06-21 23:09:30.191154
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print("test_ExceptionMixin_exception", "-"*20)
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self.exception_called = 0
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_called += 1

    test = MyExceptionMixin()
    def test_handler(request, exception):
        pass
    test.exception(test_handler)
    assert test.exception_called == 1


# Generated at 2022-06-21 23:09:34.337989
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(exception_mixin._future_exceptions, set)

# Generated at 2022-06-21 23:09:37.006638
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(FutureException, apply = True)
    def handler(request, exception):
        return request, exception
    test = ExceptionMixin(exceptions=set())
    test._apply_exception_handler = MagicMock()
    assert test._future_exceptions.clear() == None
    assert test.exception(exceptions = set()) == None

# Generated at 2022-06-21 23:09:39.314286
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # setUp:
    exception_mixin = ExceptionMixin()

    # Assertion:
    assert isinstance(exception_mixin._future_exceptions, set)


# Generated at 2022-06-21 23:09:45.248898
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    errormixin = ExceptionMixin()
    assert isinstance(errormixin, ExceptionMixin)
    assert hasattr(errormixin, '_future_exceptions')
    assert not errormixin._future_exceptions


# Generated at 2022-06-21 23:09:46.073949
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()

# Generated at 2022-06-21 23:09:59.252984
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint

    class BlueprintTest(Blueprint):
        pass

    bp = BlueprintTest("test-blueprint")
    
    @bp.exception(IndexError)
    def handle_index_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    exception = bp._future_exceptions.pop()
    assert isinstance(exception, FutureException)
    assert exception.handler == handle_index_exception
    assert exception.exceptions[0] == IndexError

# Generated at 2022-06-21 23:10:05.969214
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)

    @blueprint.exception(Exception)
    def not_found_handler(request, exception):
        return text("Internal server error", 500)

    assert blueprint._future_exceptions

# Generated at 2022-06-21 23:10:18.389719
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.exception_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler

    testClass = TestClass()
    exception_handler = testClass.exception(Exception)(print)
    assert isinstance(exception_handler, types.FunctionType)
    assert len(testClass._future_exceptions) == 1
    assert testClass.exception_handler is not None

# Generated at 2022-06-21 23:10:24.797603
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_class = TestExceptionMixin()

    assert isinstance(
        test_class.exception(Exception), types.FunctionType
    )

# Generated at 2022-06-21 23:10:29.319487
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        from sanic.models.exceptions import ExceptionMixin
    except ImportError:
        assert 0, 'Could not import ExceptionMixin ()'
    assert callable(ExceptionMixin.exception), \
        'ExceptionMixin.exception() is not callable'

# Generated at 2022-06-21 23:10:40.964474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)

    blueprint = MockBlueprint()

    @blueprint.exception(ValueError, NotImplementedError)
    def handler():
        return "handler!"  # pragma: no cover

    @blueprint.exception([ValueError, NotImplementedError], apply=False)
    def handler_no_apply():
        return "handler!"  # pragma: no cover

    # Check that the handler is applied when no kwarg is given
    assert handler.__name__ == 'handler'

    # Check that the handler is not applied when the apply kwarg is given
    assert handler_no_apply.__name__ == 'handler_no_apply'

# Generated at 2022-06-21 23:10:52.444991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import (
        ServerError,
        URLRequired,
    )

    class TestClass(ExceptionMixin):
        _future_exceptions = set()

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    instance = TestClass()

    @instance.exception(ServerError, URLRequired)
    def handle_my_exception():
        pass

    assert len(instance._future_exceptions) == 1

    @instance.exception([ServerError, URLRequired])
    def handle_my_exception_with_list():
        pass

    assert len(instance._future_exceptions) == 2



# Generated at 2022-06-21 23:10:55.293181
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinDerr(ExceptionMixin):
        _future_exceptions: Set[FutureException]

    exception_mixin_derr = ExceptionMixinDerr()
    assert type(exception_mixin_derr._future_exceptions) is set

# Generated at 2022-06-21 23:10:57.616406
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert type(e) == ExceptionMixin
    assert e._future_exceptions == set()

# Generated at 2022-06-21 23:11:01.904445
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    b = Blueprint('b', url_prefix='/b')

    @b.exception(Exception)
    def handler(request, exception):
        print(exception)
        return text('Exception')

    assert handler in b._exception_handlers
    assert handler in b._future_exceptions
    assert b._exception_handlers[handler] == (Exception,)



# Generated at 2022-06-21 23:11:12.729377
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a Blueprint object that inherits from ExceptionMixin
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json
    class TempBlueprint(ExceptionMixin, Blueprint):
        pass
    bp = TempBlueprint("test")
    # use the decorated exception handler to raise a NotFound exception
    @bp.route("/")
    def handler(): #test_sanic_blueprints.test_ExceptionMixin_exception.<locals>.handler
        raise NotFound("example")
    # test the exception handler
    @bp.exception(NotFound)
    async def handler(request, exception):
        return json({"message": str(exception)})
    request, response = bp.test_client.get("/")
    assert response.status == 404
    assert response

# Generated at 2022-06-21 23:11:13.613671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:11:20.317679
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(ExceptionMixin, object)
    assert isinstance(exception_mixin._future_exceptions, set)


# Generated at 2022-06-21 23:11:24.077036
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    blueprint = Blueprint("name",url_prefix="url_prefix")
    blueprint.exception(IndexError)(print("Hello World!"))
    assert blueprint._future_exceptions

# Generated at 2022-06-21 23:11:32.102096
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.response import text

    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test_ExceptionMixin_exception_blueprint')
    router = Router(app)

    @blueprint.exception(Exception)
    def handle_exception(request, exception):
        return text('Internal server error', 500)

    router.add_route(blueprint, '/', handle_exception)
    router.register_blueprint(blueprint)

    request, response = app.test_client.get('/')

    assert response.text == 'Internal server error'

# Generated at 2022-06-21 23:11:34.694042
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        assert ExceptionMixin()
    except:
        assert False


# Generated at 2022-06-21 23:11:37.268665
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SanicTest(ExceptionMixin):
        pass
    from sanic.response import HTTPResponse
    a = SanicTest()
    assert isinstance(a, ExceptionMixin)
    assert a._future_exceptions is set()


# Generated at 2022-06-21 23:11:45.259307
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        class TestExceptionMixin(ExceptionMixin):
            def __init__(self, *args, **kwargs) -> None:
                self._future_exceptions: Set[FutureException] = set()
        assert False, "TestExceptionMixin didn't throw NotImplementedError"
    except NotImplementedError:
        pass


# Generated at 2022-06-21 23:11:46.058340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-21 23:11:48.327481
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()


# Generated at 2022-06-21 23:11:56.493410
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_mixin = TestExceptionMixin()

    @test_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_mixin._future_exceptions) == 1

# Generated at 2022-06-21 23:12:00.203784
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass:
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
            if hasattr(self, '_future_exceptions'):
                print("Test Passes")
            else:
                print("Test Failed")

    test1 = TestClass()

test_ExceptionMixin()

# Generated at 2022-06-21 23:12:09.652067
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    app = Sanic('test_ExceptionMixin')
    assert isinstance(app, ExceptionMixin) is True

# Generated at 2022-06-21 23:12:15.652535
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class CustomException(SanicException):
        pass

    bp = Blueprint('test', url_prefix='')

    @bp.exception(CustomException)
    def handler(request, exception):
        return "Wow, CustomException was raised"

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions[0].handler == handler
    assert bp._future_exceptions[0].exceptions == (CustomException,)

# Generated at 2022-06-21 23:12:16.113995
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:12:25.846643
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    testObj = ExceptionMixin()

    # test 1: check if decorator generates a FutureException object
    # with correct fields
    @testObj.exception(Exception)
    def test_handler(*args, **kwargs):
        return 'exception'

    # Test if FutureException objects are registered in _future_exceptions
    assert len(testObj._future_exceptions) == 1

    # Test if FutureException object contains correct fields
    future_exception = list(testObj._future_exceptions)[0]
    assert future_exception.handler == test_handler
    assert future_exception.args == (Exception,)

    # Test if the FutureException object handler is the same as the
    # exception handler
    assert future_exception.handler() == 'exception'

    # test 2: Test if exception handlers are registered properly

# Generated at 2022-06-21 23:12:29.359587
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    '''
    Function to test ExceptionMixin class.
    '''
    try:
        em = ExceptionMixin()
        assert em is not None
    except AssertionError as e:
        print("AssertionError:", e)
    except Exception as e:
        print("Exception:", e)

test_ExceptionMixin()

# Generated at 2022-06-21 23:12:30.808949
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models import Blueprint
    bp=Blueprint('name')
    assert dir(ExceptionMixin)==dir(bp)

# Generated at 2022-06-21 23:12:34.603432
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint("blueprint_name")
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:12:39.496189
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinStub(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixinStub, self).__init__(args, kwargs)
    assert ExceptionMixinStub._future_exceptions is not None
    assert ExceptionMixinStub._future_exceptions == set()


# Generated at 2022-06-21 23:12:51.142097
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import text
    from sanic.blueprints import Blueprint

    # Exception type can be tuple
    exception_mixin = ExceptionMixin()
    exc = (Exception,)
    my_handler = exception_mixin.exception(exc)(text)
    assert any([e.handler == my_handler for e in exception_mixin._future_exceptions])

    # Exception type can be list
    exception_mixin = ExceptionMixin()
    exc = [Exception]
    my_handler = exception_mixin.exception(exc)(text)
    assert any([e.handler == my_handler for e in exception_mixin._future_exceptions])

    # when apply=True, _apply_exception_handler() will be called
    with pytest.raises(NotImplementedError):
        exception_mixin._apply_

# Generated at 2022-06-21 23:12:56.756603
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    bp_test = Blueprint('bp_test')

    @bp_test.exception(ZeroDivisionError)
    def div_by_zero(request, exception):
        return request, exception

# Generated at 2022-06-21 23:13:15.574577
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(TypeError, IOError)
    def test_handler():
        print('Got an exception')

    assert isinstance(test_handler, types.FunctionType)

# Generated at 2022-06-21 23:13:19.756121
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException): pass

    @Blueprint.exception(ZeroDivisionError)
    def test_exception_handler(request, exception):
        raise NotImplementedError

    assert Blueprint._future_exceptions

# Generated at 2022-06-21 23:13:29.507118
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Class ExceptionMixin
    # Init func_exception_handler and func_exception
    class TestExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self.func_exception_handler()

        def func_exception_handler():
            pass
    # Unit test
    tt1 = TestExceptionMixin()
    tt1.exception(ValueError, ZeroDivisionError)

# Generated at 2022-06-21 23:13:32.609070
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_class = ExceptionMixin()
    assert test_class._future_exceptions == set()

# Generated at 2022-06-21 23:13:41.374234
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin.exception(KeyError)(KeyError)
    assert test_exception_mixin.exception(KeyError)(KeyError) == KeyError

# Generated at 2022-06-21 23:13:45.831052
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class a(ExceptionMixin):
        def __init__(self):
            super().__init__()
    x = a()
    assert len(x._future_exceptions) == 0


# Generated at 2022-06-21 23:13:51.568464
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    app = Sanic('test_ExceptionMixin_exception')
    @app.exception(ZeroDivisionError)
    def zerodivision(request, exception):
        return text('division by zero', status=500)

    @app.route('/')
    async def handler(request):
        return 0 / 0

    request, response = app.test_client.get('/')

    assert response.status == 500
    assert response.text == 'division by zero'

# Generated at 2022-06-21 23:13:55.342942
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionmixin = ExceptionMixin()
    print('Unit test for constructor of class ExceptionMixin')
    print(exceptionmixin)
    print('Pass!')


# Generated at 2022-06-21 23:13:56.127378
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:13:57.100186
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-21 23:14:31.195028
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class bp:
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    bp = bp()
    bp.exception(Exception)
    


# Generated at 2022-06-21 23:14:33.489886
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:14:34.914106
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin is not None

# Generated at 2022-06-21 23:14:42.037039
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.bp import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint(__name__, url_prefix='/test')

    @bp.exception(Exception)
    def handler(request, exception):
        return None

    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

    app = Sanic(__name__)
    app.blueprint(bp)
    assert len(app.exception_handler_functions) == 1

# Generated at 2022-06-21 23:14:42.979144
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()

    assert mixin._future_exceptions == set()

# Generated at 2022-06-21 23:14:43.725782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:14:46.687490
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin,ExceptionMixin)


# Generated at 2022-06-21 23:14:48.695928
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    #Instantiate ExceptionMixin
    exceptionMixin1 = ExceptionMixin()
    assert exceptionMixin1._future_exceptions == set()


# Generated at 2022-06-21 23:14:51.441809
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()

    assert blueprint is not None


# Generated at 2022-06-21 23:14:57.710023
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin, object):
        def _apply_exception_handler(self, handler):
            pass

    test_blueprint = Blueprint('')
    test_exception = test_blueprint.exception(Exception)

    assert test_blueprint._future_exceptions is not None
    assert callable(test_exception)

# Generated at 2022-06-21 23:16:09.440723
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    emi = TestExceptionMixin()

    @emi.exception(ZeroDivisionError)
    def handle_exception(request, exception):
        print('Go to hell')

    assert len(emi._future_exceptions) == 1
    assert isinstance(emi._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:16:10.896085
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:16:16.698181
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    msg = "test"
    class TestExceptionMixin(ExceptionMixin):pass
    a = TestExceptionMixin()
    @a.exception(Exception)
    def exception_handler(request, exception): return msg

    assert str(exception_handler(None, None)) == msg
    assert str(a._future_exceptions.pop().handler(None, None)) == msg

# Generated at 2022-06-21 23:16:20.623374
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Check whether class ExceptionMixin have some attribute
    assert hasattr(ExceptionMixin, '_future_exceptions')
    assert hasattr(ExceptionMixin, '_apply_exception_handler')
    assert hasattr(ExceptionMixin, 'exception')


# Generated at 2022-06-21 23:16:27.352647
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    
    class Dummy:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    d = Dummy()
    try:
        @d.exception(Exception)
        def error_handler(self, request, exception):
            return 'Error'
    except NotImplementedError:
        pass
    
    assert len(d._future_exceptions) == 1
    assert isinstance(list(d._future_exceptions)[0], FutureException)
    assert list(d._future_exceptions)[0].handler.__name__ == 'error_handler'
    assert len(list(d._future_exceptions)[0].exceptions) == 1

# Generated at 2022-06-21 23:16:33.496697
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint(__name__, url_prefix='/test')
    try:
        @bp.exception([ZeroDivisionError, TypeError])
        def fail_divide(request, exception):
            return text('Dude, you tried to divide by zero or wrong type!')
    except Exception:
        raise
    else:
        assert callable(fail_divide)

# Generated at 2022-06-21 23:16:42.659870
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin, object):
        def _apply_exception_handler(self, handler):
            assert handler.handler == test_handler
            assert handler.exceptions == (Exception, ValueError)
            assert handler.kwargs == {}

    def test_handler(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == { 'one': 1, 'two': 2, 'three': 3 }

    test_class = TestClass()

    #Test1: apply = False
    test_class.exception((Exception, ValueError), apply=False)(test_handler)

    #Test2: apply = True
    test_class.exception((Exception, ValueError), apply=True)(test_handler)

    #Test3: no exception

# Generated at 2022-06-21 23:16:44.174452
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance, ExceptionMixin)
    assert len(instance._future_exceptions) == 0


# Generated at 2022-06-21 23:16:45.899258
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Obj(ExceptionMixin):
        pass
    obj = Obj()
    assert obj._future_exceptions == set()

# Generated at 2022-06-21 23:16:49.006276
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    b = Blueprint()
    assert type(b._future_exceptions) == set
    assert b._future_exceptions == set()