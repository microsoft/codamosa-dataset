

# Generated at 2022-06-21 23:09:26.413725
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from typing import Any, Callable, List, Tuple

    from sanic.blueprints import BlueprintExceptionMixin
    from sanic.models.futures import FutureException

    class ContextManager(BlueprintExceptionMixin):
        def __init__(self, apply: bool = True) -> None:
            self._future_exceptions = set()

        async def __aenter__(self) -> "ContextManager":
            return self

        async def __aexit__(
            self,
            exc_type: Exception,
            exc_value: Exception,
            traceback: TracebackType,
        ) -> bool:
            return False

        def _apply_exception_handler(self, handler: FutureException):
            handler._handler(None, {})


# Generated at 2022-06-21 23:09:28.541501
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test = ExceptionMixin()
    assert isinstance(test, ExceptionMixin)
    assert test._future_exceptions == set()


# Generated at 2022-06-21 23:09:30.861733
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Generated at 2022-06-21 23:09:41.070076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, args, kwargs)

        def _apply_exception_handler(self, handler):
            return handler

    exception_mixin_test = ExceptionMixClass()
    @exception_mixin_test.exception(ZeroDivisionError)
    def zero_division_handler(request, exception):
        return 'Functionality to handle zero division exception.'

    @exception_mixin_test.exception(ZeroDivisionError, IndexError)
    def default_handler(request, exception):
        return 'Functionality to handle default exception.'

    assert exception_mixin_test._future_exceptions
    assert exception_mixin_test._future_exceptions.pop() is not None


# Generated at 2022-06-21 23:09:51.784023
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def exception_handler(request, exception):
        print(exception)
        print('call custom exception handler')

    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

        def test_ExceptionMixin_exception_inner(self):
            self.exception(KeyError, apply=False)(exception_handler)
            self.exception(apply=False)(exception_handler)
            self.exception(exception_handler)
            self.exception(exception_handler, KeyError)


    ExceptionMixinTest().test_ExceptionMixin_exception_inner()

# Generated at 2022-06-21 23:09:58.028732
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    args = "handler",
    kwargs = {'apply' : True}
    def handler():
        print("Exception")
    # Init the class ExceptionMixin
    a = ExceptionMixin()
    # Call the method exception
    b = a.exception(*args, **kwargs)
    assert b(handler)

# Generated at 2022-06-21 23:10:08.996121
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from unittest.mock import Mock

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass
    # Arrange
    test = TestExceptionMixin()

    # Act
    result = test

    # Assert
    assert isinstance(result, TestExceptionMixin)


# Generated at 2022-06-21 23:10:17.263167
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test = TestExceptionMixin()

    def test_handler():
        pass

    # Check for original
    assert len(test._future_exceptions) == 0
    test.exception(ValueError)(test_handler)
    assert test._future_exceptions is not None
    assert len(test._future_exceptions) == 1
    assert isinstance(tuple(*test._future_exceptions)[0].exceptions, tuple)

    # Check for list
    test.exception(ValueError, TypeError)(test_handler)
    assert test._future_exceptions is not None
    assert len(test._future_exceptions) == 2

    # Check for tuple

# Generated at 2022-06-21 23:10:21.049565
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.called = False
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self.called = True

    test = TestExceptionMixin()
    test.exception(RuntimeError)(lambda *args, **kwargs: False)
    assert test.called

# Generated at 2022-06-21 23:10:22.817334
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_handler(request, exception):
        pass

    class TestExceptionMixin(ExceptionMixin):
        pass

    test_em = TestExceptionMixin()
    result = test_em.exception(Exception, apply=True)(test_handler)

    assert result



# Generated at 2022-06-21 23:10:25.846197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:10:30.489351
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin_test = ExceptionMixin(None)
    assert isinstance(exception_mixin_test, ExceptionMixin)
    assert isinstance(exception_mixin_test, object)
    assert hasattr(exception_mixin_test, '_future_exceptions')
    assert isinstance(exception_mixin_test._future_exceptions, set)

# Generated at 2022-06-21 23:10:34.393912
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    b = Blueprint("test_ExceptionMixin")
    assert b.__class__.__bases__[0].__name__ == "ExceptionMixin"



# Generated at 2022-06-21 23:10:36.771243
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em=ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:10:38.266080
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert not e._future_exceptions


# Generated at 2022-06-21 23:10:44.688582
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeClass:
        def __init__(self):
            self._apply_exception_handler: Set[FutureException] = set()
        def _apply_exception_handler(self, handler: FutureException):
            self._apply_exception_handler.add(handler)
    def fake_handler():
        pass
    fake_class = FakeClass()
    exception_mixin = ExceptionMixin(fake_class)
    fake_exception = TypeError
    exception_mixin.exception(fake_exception)(fake_handler)
    assert len(exception_mixin._future_exceptions) == 1



# Generated at 2022-06-21 23:10:47.827973
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert isinstance(em, ExceptionMixin)
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:10:51.057747
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  obj = ExceptionMixin()
  assert type(obj) == ExceptionMixin
  assert type(obj._future_exceptions) == set


# Generated at 2022-06-21 23:11:00.541655
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    t1 = TestExceptionMixin()
    t2 = TestExceptionMixin()
    # Test in different classes
    assert t1.exception is not t2.exception

    # Test in the same class
    assert TestExceptionMixin.exception(TestExceptionMixin) is \
        TestExceptionMixin.exception(TestExceptionMixin)

    # Test in the same object
    assert t1.exception is t1.exception

# Generated at 2022-06-21 23:11:06.708953
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            pass

        def _apply_exception_handler(self, handler):
            pass

    test = TestExceptionMixin()
    assert test._future_exceptions == set()


# Generated at 2022-06-21 23:11:22.675421
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import abort
    from sanic.blueprints import Blueprint, ExceptionMixin
    from sanic.utils import sanic_endpoint_test

    class Blueprint(Blueprint, ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.exception(apply=False)(self.exception_handler)
            self.exception(ZeroDivisionError, apply=False)(self.the_exception_handler)

        def exception_handler(self, request, exception):
            return text("Oops! That operation is not allowed.")

        def the_exception_handler(self, request, exception):
            return text("I see, you are dividing by zero.")

    blueprint = Blueprint("TestBlueprint", url_prefix="test")


# Generated at 2022-06-21 23:11:31.710856
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SomeException(Exception):
        pass

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)
            for exception in handler.exception_types:
                assert isinstance(exception, type)

    exception_mixin_test = ExceptionMixinTest()
    @exception_mixin_test.exception(KeyError, apply=False)
    def test_KeyError_handler():
        pass

    @exception_mixin_test.exception(KeyError, TypeError, apply=False)
    def test_KeyError_TypeError_handler():
        pass


# Generated at 2022-06-21 23:11:35.459067
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    MyExceptionMixin()

# Generated at 2022-06-21 23:11:42.080368
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    def my_handler(request: Request, exc: Exception):
        return HTTPResponse(status=500)

    bp = Blueprint(name="bp", url_prefix="/bp")
    bp.exception(Exception)(my_handler)

    assert len(bp._future_exceptions) == 1

    bp.exception(ValueError, apply=0)(my_handler)

    assert len(bp._future_exceptions) == 2

    app = Sanic()
    app.get('/', bp)
    assert '/bp/' in app.router.routes_names

# Generated at 2022-06-21 23:11:49.445735
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class Blueprint(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = Blueprint()
    # Act
    @blueprint.exception()
    def handler():
        print("handle error")

    # Assert
    assert isinstance(blueprint._future_exceptions, set)
    future_exception = next(iter(blueprint._future_exceptions))
    assert isinstance(future_exception, FutureException)
    assert future_exception.handler == handler



# Generated at 2022-06-21 23:11:52.883793
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # corner case
    with pytest.raises(Exception):
        ExceptionMixin()



# Generated at 2022-06-21 23:12:01.716708
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    test_exception_handler = test_exception_mixin.exception(Exception)
    assert test_exception_handler != None
    assert len(test_exception_mixin._future_exceptions) == 1
    assert type(list(test_exception_mixin._future_exceptions)[0]) == FutureException

# Generated at 2022-06-21 23:12:02.317787
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-21 23:12:09.609006
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self,handler:'FutureException'):
            pass
    e = TestExceptionMixin()
    @e.exception(Exception)
    def exception_test(request, exception):
        print(exception)
        return "exception"
    assert isinstance(e._future_exceptions,set)
    assert isinstance(e._future_exceptions.pop(), FutureException)
    assert isinstance(exception_test(None,None), str)

# Generated at 2022-06-21 23:12:17.593063
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    import inspect

    blueprint = Blueprint('test_bp')

    blueprint.exception(IndexError)
    blueprint.exception(KeyError)

    blueprint.exception([ValueError, TypeError])

    blueprint.exception(IndexError, apply=False)

    assert blueprint._future_exceptions

    for future_exception in blueprint._future_exceptions:
        assert isinstance(future_exception.exception_handler, types.FunctionType)
        assert isinstance(future_exception.exceptions, tuple)

        for exception in future_exception.exceptions:
            assert issubclass(exception, BaseException) is True

        assert inspect.getfile(future_exception.exception_handler) == __file__

# Generated at 2022-06-21 23:12:27.370776
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyException(ExceptionMixin):
        pass
    myException = MyException()
    assert not myException._future_exceptions



# Generated at 2022-06-21 23:12:35.047198
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_ExceptionMixin', url_prefix='/test_ExceptionMixin')

    assert isinstance(bp, ExceptionMixin) , "bp is not an instance of ExceptionMixin"
    assert bp._future_exceptions == set() , "bp._future_exceptions != empty set"

# Unit tests for method _apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-21 23:12:39.878722
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    instance = ExceptionMixin1()
    assert instance is not None

# Generated at 2022-06-21 23:12:43.826852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Router(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler == FutureException(handler, ())

    router = Router()
    router.exception(IndexError)(lambda x: x)

# Generated at 2022-06-21 23:12:54.196631
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.models.futures import FutureException
    from sanic import Blueprint
    import asyncio
    import pytest

    app = Sanic()
    blueprint = Blueprint('test_blueprint', url_prefix='test')

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        return text("error")

    @blueprint.exception(Exception, apply=False)
    def exception_handler2(request, exception):
        return text("error")

    @blueprint.route("/test_handler1")
    async def test_handler1(request):
        asyncio.sleep(0.5)
        1 / 0

    @blueprint.route("/test_handler2")
    async def test_handler2(request):
        asyncio.sleep

# Generated at 2022-06-21 23:12:57.385921
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_blp = ExceptionMixin()
    # Unit test for method exception of class ExceptionMixin
    @my_blp.exception(ValueError)
    def handler():
        pass
    assert()

# Generated at 2022-06-21 23:12:59.417188
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    et = ExceptionMixin()
    assert isinstance(et, ExceptionMixin)
    assert et._future_exceptions == set()
    

# Generated at 2022-06-21 23:13:03.543379
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    t = TestExceptionMixin()
    assert t._future_exceptions == set()



# Generated at 2022-06-21 23:13:10.205331
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_bp', url_prefix='test')
    blueprint.exception(Exception)(lambda request, exception: None)
    assert blueprint._future_exceptions

    app = Sanic('test_sanic_exception')
    app.blueprint(blueprint)
    assert app.exception_handlers

    with pytest.raises(Exception):
        raise Exception

# Generated at 2022-06-21 23:13:13.274834
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()


# Generated at 2022-06-21 23:13:40.349414
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blues import Blueprint
    from mock import MagicMock
    from sanic.models.futures import FutureException
    blueprint = Blueprint('test', url_prefix='/test', version=1)
    blueprint.app = MagicMock()
    blueprint.app.register_blueprint = MagicMock()
    blueprint.exception(ValueError)(lambda x: x)
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions == set([
        FutureException(lambda x: x, (ValueError,))
    ])

# Generated at 2022-06-21 23:13:48.849697
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint

    blueprint = Blueprint('test')
    blueprint._exception_handler_func = lambda e: e

    @blueprint.exception(Exception)
    def handler():
        return 'error'

    assert len(blueprint._future_exceptions) == 1

    for e in blueprint._future_exceptions:
        assert e.handler() == 'error'
        assert e.exceptions == (Exception,)

# Generated at 2022-06-21 23:14:01.969323
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic import Sanic
    from sanic.exceptions import ServerError
    app = Sanic('test_ExceptionMixin_exception')

    # Given
    class BlueprintExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return True

    # When
    bp = BlueprintExceptionMixin('test_ExceptionMixin_exception')

    @bp.exception(ServerError)
    async def server_error_handler(request, exception):
        return text('Server Internal Error', 500)

    app.blueprint(bp)

    client = app.test_client

    rv = client.get('/')


# Generated at 2022-06-21 23:14:12.528385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException, ServerError

    class TestException(SanicException):
        pass
    
    class TestMethodView(HTTPMethodView, ExceptionMixin):
        pass

    bp = Blueprint('test', url_prefix='/')
    bp.method_view(TestMethodView, 'test_route')

    @bp.exception(TestException)
    def test_exception(request, exception):
        return response.text('test')

    @bp.get('/test_route')
    def test_view(request):
        raise TestException()
    
    @bp.exception(ServerError, apply=False)
    def test_exception(request, exception):
        return response

# Generated at 2022-06-21 23:14:20.535684
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import response

    bp = Blueprint('test_bp')
    assertExceptionMixin(bp)

    @bp.exception(ValueError)
    async def value_error(request, exception):
        return response.text('value error')

    assert bp._future_exceptions
    assert len(bp._future_exceptions) == 1
    assert bp._exception_handler
    assert len(bp._exception_handlers) == 1



# Generated at 2022-06-21 23:14:23.913478
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test with args
    def my_function_g(request):
        pass

    # test with args
    def my_function_f(request):
        pass

    bp: Blueprint = Blueprint("exception_mixin")

    es = ExceptionMixin()
    es.exception(TypeError)(my_function_g)
    es.exception(TypeError, KeyError)(my_function_f)

# Generated at 2022-06-21 23:14:24.686091
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:14:25.542197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:14:31.357160
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    @Blueprint.exception(apply=True)
    def func_handler(request, exception):
        ...

    @Blueprint.exception(apply=True)
    def func_handler():
        ...

    @Blueprint.exception(apply=True)
    def func_handler(request, exception, *args, **kwargs):
        ...

    @Blueprint.exception()
    def func_handler(request, exception):
        ...

    assert True

# Generated at 2022-06-21 23:14:37.647782
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    exception_mixin_impl = ExceptionMixinImpl()
    assert isinstance(exception_mixin_impl, ExceptionMixin)


# Generated at 2022-06-21 23:15:12.075306
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Generated at 2022-06-21 23:15:12.881317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:15:15.951237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    m = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        m.exception(RuntimeError)

# Generated at 2022-06-21 23:15:16.961154
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ins = ExceptionMixin()
    assert ins

# Generated at 2022-06-21 23:15:20.022279
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    blueprint = Blueprint("blueprint", url_prefix="/blueprint")
    assert blueprint.__init__(blueprint) is None

# Generated at 2022-06-21 23:15:22.807628
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e=ExceptionMixin()
    assert e._future_exceptions == set()


# Generated at 2022-06-21 23:15:26.128347
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Mock
    class Sanic(ExceptionMixin):
        pass
    # Test
    sanic = Sanic()
    assert sanic._future_exceptions == set()



# Generated at 2022-06-21 23:15:37.117296
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic.models.futures import FutureException
    class InvalidClass:
        pass
    instance = ExceptionMixin()
    request = Mock()
    # Test when apply is True
    assert len(instance._future_exceptions) == 0
    instance.exception(Exception)
    assert len(instance._future_exceptions) == 1
    assert type(instance._future_exceptions.pop()) is FutureException
    # Test when apply is False
    instance.exception(Exception, apply=False)
    assert len(instance._future_exceptions) == 1
    assert type(instance._future_exceptions.pop()) is FutureException
    # Test when a non-list of exception is passed
    instance.exception([Exception])
    assert len(instance._future_exceptions) == 1
   

# Generated at 2022-06-21 23:15:42.868667
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super(TestClass, self).__init__()
    
    test = TestClass()
    assert isinstance(test, ExceptionMixin)
    assert test._future_exceptions == set()

# Generated at 2022-06-21 23:15:46.417484
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class ChildClass(ExceptionMixin):
        pass

    child_class = ChildClass()

    blueprint = Blueprint("test_ExceptionMixin_exception")

    def handler_func():
        pass

    blueprint.exception(TypeError, ValueError)(handler_func)

    assert handler_func in blueprint._future_exceptions
    assert child_class.exception(TypeError, ValueError)(handler_func)

# Generated at 2022-06-21 23:17:03.881493
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinStub:
        def __init__(self, *args, **kwargs):
            return

# Generated at 2022-06-21 23:17:11.042452
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class T(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class E(T):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            super().__init__(*args, **kwargs)

    assert len(E()._future_exceptions) == 0
    
    

# Generated at 2022-06-21 23:17:14.094347
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert type(m) == ExceptionMixin
    assert m._future_exceptions == set()


# Generated at 2022-06-21 23:17:15.689207
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert (exception_mixin._future_exceptions == set())


# Generated at 2022-06-21 23:17:21.177285
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    a = A()
    @a.exception(Exception)
    def handler():
        pass
    assert isinstance(a._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:17:24.671884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("my_bp", url_prefix="/test")

    # Case: exception
    bp.exception(Exception)(lambda r, e: "test")

    assert bp._future_exceptions[0].handler(None, Exception("test")) == "test"

# Generated at 2022-06-21 23:17:33.314018
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blue = Blueprint(__name__)

    @blue.exception(ZeroDivisionError, apply=True)
    def handler(request, exception):
        return json({
            'status': 500,
            'error': 'Division by zero'
        })

    assert handler.__name__ == "handler"
    assert blue._future_exceptions._nodes[0] == (handler, (ZeroDivisionError,))

# Generated at 2022-06-21 23:17:36.453411
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-21 23:17:42.850088
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_fake(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
    fake_obj = ExceptionMixin_fake()
    assert fake_obj._future_exceptions == set()


# Generated at 2022-06-21 23:17:45.719322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    em = ExceptionMixin()
    em._apply_exception_handler(None)
    assert em._future_exceptions == set()