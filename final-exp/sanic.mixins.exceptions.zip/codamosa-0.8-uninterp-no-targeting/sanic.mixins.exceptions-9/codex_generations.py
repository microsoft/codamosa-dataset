

# Generated at 2022-06-21 23:09:29.732338
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic import Sanic
    from sanic.response import text
    bp = Blueprint("name", url_prefix="test", version=1)

    @bp.exception(NotFound)
    def handle_exception(req, ex):
        return text("Exception Raised", status=ex.status_code)

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)
    request, response = app.test_client.get("/")
    assert response.text == "Exception Raised"
    assert response.status == 404

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-21 23:09:31.141076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

ExceptionMixin()

# Generated at 2022-06-21 23:09:34.702218
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test_bp', url_prefix='test')
    assert bp.exception
    

# Generated at 2022-06-21 23:09:35.550523
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:09:41.764654
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    import functools
    bp = Blueprint("test_bp", url_prefix="/test")

    @bp.route("/test")
    def test():
        return "ok"

    def handler(request, exception):
        return "ok"

    bp.exception(Exception)(handler)

    handler_with_bb = bp.exception(Exception)(handler)

    assert handler_with_bb.__code__ is handler.__code__
    assert handler_with_bb.__closure__[0].cell_contents is handler.__closure__[0].cell_contents
    assert handler_with_bb.__globals__ is handler.__globals__

# Generated at 2022-06-21 23:09:44.834067
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()
    


# Generated at 2022-06-21 23:09:48.511455
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self, *args, **kwargs):
            self._example_exception = 'Exception'

        def example_exception(self, *args, **kwargs):
            return self._example_exception

    a = A()
    assert a._example_exception == 'Exception'
    assert a.example_exception() == 'Exception'

# Generated at 2022-06-21 23:10:00.053014
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    blueprint = ExceptionMixin()
    blueprint.is_global = True
    blueprint.exception_handler = None
    blueprint.exception_handler_args = None
    blueprint.exception_handler_kwargs = None

    @blueprint.exception
    def blueprint_handler(request, exception):
        assert request is not None
        print(exception)

    # Act
    blueprint._apply_exception_handler(blueprint._future_exceptions)

    # Assert
    assert blueprint.exception_handler is blueprint_handler
    assert blueprint.exception_handler_args is not None
    assert blueprint.exception_handler_kwargs is not None

# Generated at 2022-06-21 23:10:06.879047
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound

    app = Sanic('test_ExceptionMixin')

    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            app.error_handler.add(handler.exceptions, handler.handler)

    test_class = TestClass()

    @test_class.exception(NotFound)
    def exception_handler(request, exception):
        return text('Oops! I could swear this page was here!', 404)

    @app.route('/')
    def handler(request):
        raise NotFound()

    request, response = app.test_client.get('/')

    assert response.text == 'Oops! I could swear this page was here!'
    assert response.status == 404

# Generated at 2022-06-21 23:10:15.566575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # init
    exception_mixin = ExceptionMixin()
    future_exception = ()
    # use method exception(decorator) of class ExceptionMixin
    def decorator(handler):
        nonlocal exception_mixin
        nonlocal future_exception
        future_exception = FutureException(handler, ())
        exception_mixin._future_exceptions.add(future_exception)
        return handler
    # assert statements
    assert exception_mixin._future_exceptions == set()
    # assert method exception
    assert exception_mixin.exception(decorator) == decorator
    assert exception_mixin._future_exceptions == set(future_exception)


# Generated at 2022-06-21 23:10:19.646583
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError) as excinfo:
        ExceptionMixin()
    assert "object has no attribute '_future_exceptions'" in str(excinfo.value)

# Generated at 2022-06-21 23:10:21.715598
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert ex._future_exceptions == set()

# Generated at 2022-06-21 23:10:29.522291
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint(app, url_prefix='test_ExceptionMixin_exception')
    @bp.exception()
    def handle_exception(request, exception):
        return text('Exception handler works!')
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:10:31.413606
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert True

# Generated at 2022-06-21 23:10:32.236878
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-21 23:10:35.757033
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()

    assert (
        type(exception_mixin._future_exceptions) == set
    ), "The exceptions set should be initialized with an empty set"

# Generated at 2022-06-21 23:10:41.891898
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTester(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler.handler

    exceptions = ExceptionMixinTester()

    @exceptions.exception(ValueError, apply=False)
    def exception_value(request, exception):
        return exception.args[0]

    assert "exception_value" == exception_value(None, ValueError("Test Value Error"))

# Generated at 2022-06-21 23:10:43.380154
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass # TODO


# Generated at 2022-06-21 23:10:52.212381
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception('Exception1', 'Exception2', apply=True)
    def handler():
        return "return"

    print(test_exception_mixin._future_exceptions)

#test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:10:59.785069
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import RequestTimeout

    class TempExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception = ExceptionMixin()
    blueprint = Blueprint("test", url_prefix="test")
    temp = TempExceptionMixin()

    @temp.exception(apply=False)
    async def handler(request: Request, exception: Exception):
        return HTTPResponse("OK")

    @temp.exception(RequestTimeout, apply=False)
    async def handler(request: Request, exception: Exception):
        return HTTPResponse("OK")


# Generated at 2022-06-21 23:11:13.245328
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    URL_RESULTS = {
        "/test1": {"status": "OK", "data": "exception1"},
        "/test2": {"status": "OK", "data": "exception2"},
    }

    class ExceptionWithGet(ExceptionMixin):
        def apply_middleware(self, request, response):
            pass

        def register(self, bp, options):
            pass

        async def get(self):
            return "Success"

    bp = ExceptionWithGet()
    bp.url_prefix = "/test"

    @bp.exception(Exception)
    def default_exception(request, exception):
        return exception.__str__()

    @bp.exception(NameError, apply=False)
    def name_error(request, exception):
        return exception.__str__()

    app = Sanic

# Generated at 2022-06-21 23:11:18.629329
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    class User(ExceptionMixin, Blueprint):
        def __init__(self):
            super().__init__()

    obj = User()
    assert len(obj._future_exceptions) == 0

# Generated at 2022-06-21 23:11:20.317721
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    obj = TestExceptionMixin()


# Generated at 2022-06-21 23:11:26.482381
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintMock(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return True

    blueprint = BlueprintMock()

    @blueprint.exception(KeyError)
    def handler(exception_object):
        return exception_object

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler

# Generated at 2022-06-21 23:11:33.660628
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import Blueprint
    from unittest.mock import MagicMock
    from sanic.models.futures import FutureException
    from sanic.models.functions import HandlerFunction

    # A class inheriting from ExceptionMixin
    blueprint = Blueprint(__name__)

    # Define a method handler
    handler = MagicMock(spec=HandlerFunction)
    handler.to_exception.return_value = Exception

    # Check if the instance of FutureException is added to blueprint
    blueprint.exception(Exception)(handler)
    assert blueprint._future_exceptions == set([FutureException(handler,
                                                                 (Exception,))])
    assert blueprint._apply_exception_handler.called is True

# Generated at 2022-06-21 23:11:39.490036
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    emt = ExceptionMixinTest()

    @emt.exception(Exception)
    def global_handler(request):
        pass

    assert emt._future_exceptions.pop() == FutureException(global_handler, (Exception,))

# Generated at 2022-06-21 23:11:41.578665
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-21 23:11:50.919850
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self)
            self.route_list = []

        def _apply_exception_handler(self, handler):
            self.route_list.append(handler)

    bp = Blueprint()

    @bp.exception(ValueError)
    def handler(request, exception):
        return request, exception

    assert len(bp.route_list) == 1
    assert isinstance(bp.route_list[0], FutureException)
    assert bp.route_list[0].handler == handler
    assert bp.route_list[0].exceptions[0] == ValueError



# Generated at 2022-06-21 23:12:01.124192
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import inspect

    class ExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """

            def decorator(handler):
                nonlocal apply

# Generated at 2022-06-21 23:12:08.663405
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest

    class TestSanicException(unittest.TestCase):
        def testExceptionMixin(self):
            from sanic.app import Sanic

            app = Sanic(__name__)

            with self.assertRaises(NotImplementedError):
                app.exception(Exception)(lambda x: x)

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-21 23:12:19.083150
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    app = Sanic()
    @app.exception(*[Exception])
    def error_handler(request, exception):
        return "Something bad happened"
    assert app.error_handler_spec[Exception] == error_handler

test_ExceptionMixin()

# Generated at 2022-06-21 23:12:22.706182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Init
    exception_mixin_instance = ExceptionMixin()
    # Ok
    assert exception_mixin_instance.exception is not None
    # Apply should be false by default
    decorator = exception_mixin_instance.exception(Exception)
    result = decorator(lambda: 1/0)
    assert result == 0
    # Can be passed
    decorator = exception_mixin_instance.exception(Exception, apply=False)
    try:
        assert decorator(lambda: 1/0) == 0
    except Exception:
        pass

# Generated at 2022-06-21 23:12:27.333528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    em = ExceptionMixin()
    assert em is not None
    def call_exception_mixin_exception():
        em.exception()
    assert ExceptionMixin.exception.__doc__ == "This method enables the process of creating a global exception handler for the current blueprint under question."
    assert call_exception_mixin_exception() is None

# Generated at 2022-06-21 23:12:28.422178
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:12:38.164179
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    em = TestExceptionMixin()
    assert em._future_exceptions == set()
    def myhandler():
        pass
    em.exception(myhandler)
    assert em._future_exceptions == set([FutureException(myhandler, ())])
    em.exception(ValueError)(myhandler)
    assert em._future_exceptions == set([FutureException(myhandler, ()),
                                         FutureException(myhandler, (ValueError,))])

# Generated at 2022-06-21 23:12:44.938609
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(ValueError)
    def handler(*args, **kwargs):
        pass

# Generated at 2022-06-21 23:12:46.689601
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em

# Generated at 2022-06-21 23:12:48.491848
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin_test = ExceptionMixin()
    exceptionMixin_test.__init__()

# Generated at 2022-06-21 23:12:51.883622
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin._apply_exception_handler(1)

# Generated at 2022-06-21 23:13:02.019517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMockup(ExceptionMixin):
        def __init__(self, state):
            super().__init__()
            self.state = state

        def _apply_exception_handler(self, handler: FutureException):
            self.state.set_state(handler)
            pass

    class State:
        def __init__(self):
            self.future_exception = None

        def set_state(self, future_exception):
            self.future_exception = future_exception

    state = State()
    exceptionMixin = ExceptionMixinMockup(state)
    handler = exceptionMixin.exception(apply=True)(1)
    assert 1 == handler
    assert 1 == state.future_exception.handler

# Generated at 2022-06-21 23:13:20.623676
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test:
        def fun1(self):
            pass
    test = Test()
    ExceptionMixin.__init__(test)
    @test.exception(Exception)
    def fun2(self):
        return "hello world"
    assert (test.fun2() == "hello world")

# Generated at 2022-06-21 23:13:23.811846
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:13:26.517000
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Test for constructor
    ex = ExceptionMixin()
    assert isinstance(ex._future_exceptions, set)

# Generated at 2022-06-21 23:13:33.951516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Temp1(ExceptionMixin):
        def __init__(self):
            super().__init__()

    class Temp2(ExceptionMixin):
        def __init__(self):
            super().__init__()

    t1 = Temp1()
    t2 = Temp2()

    @t1.exception(Exception)
    def handler1(request, exception):
        pass

    @t2.exception(Exception)
    def handler2(request, exception):
        pass

    assert t1._future_exceptions
    assert t2._future_exceptions
    assert handler1.__name__ == "handler1"
    assert handler2.__name__ == "handler2"

# Generated at 2022-06-21 23:13:38.887117
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    t = Test()
    assert(t._future_exceptions == set())


# Generated at 2022-06-21 23:13:40.191666
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Unit test of function _apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-21 23:13:44.862721
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    
    bp = Blueprint('my_bp', url_prefix='')
    
    
    
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:13:48.117093
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex_mixin = ExceptionMixin()
    assert isinstance(ex_mixin._future_exceptions, set) == True


# Generated at 2022-06-21 23:13:50.747053
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler is self._future_exceptions.pop()
    ExceptionMixinTest().exception(Exception)

# Generated at 2022-06-21 23:13:55.703150
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class testclass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    testobj = testclass()
    assert isinstance(testobj, ExceptionMixin)

# Generated at 2022-06-21 23:14:28.128659
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:14:29.363435
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception is not None

# Generated at 2022-06-21 23:14:38.003409
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blueprint = Blueprint(__name__)

    @blueprint.exception(Exception)
    def handler(request, exception):
        return 'this is an exception'
    
    assert len(blueprint._future_exceptions) == 1
    test = False
    for item in blueprint._future_exceptions:
        if item.handler == handler:
            test = True
    assert test


# Generated at 2022-06-21 23:14:42.366544
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()



# Generated at 2022-06-21 23:14:47.344598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_router.exception_mixin import ExceptionMixin
    from sanic.models.futures import FutureException
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    # make a test blueprint
    blueprint = Blueprint('bp_exception', url_prefix='/bp_exception')

    @blueprint.exception()
    def my_exception_handler(request, exception):
        return request
        pass

    # get the first exception registered
    fe: FutureException = list(blueprint._future_exceptions)[0]

    assert fe.handler == my_exception_handler

    assert fe.args == tuple()


# Generated at 2022-06-21 23:14:48.704262
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:15:00.467022
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.views import HTTPMethodView
    from sanic.response import json

    # Create an instance of class ExceptionMixin
    exception_mixin = ExceptionMixin()

    # Test for __init__()
    assert isinstance(exception_mixin._future_exceptions, set)

    @exception_mixin.exception(Exception)
    def handler(*args, **kwargs):
        return

    exception_mixin._apply_exception_handler(handler)

    class TestExceptionMixin(HTTPMethodView):
        decorators = [exception_mixin.exception(Exception), ]

        def get(self, request):
            raise Exception

        def post(self, request):
            return json({'result': "post method"})

    # Test for method exception

# Generated at 2022-06-21 23:15:03.784945
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        exc = ExceptionMixin()
    except:
        print("Failed to run test_ExceptionMixin")


# Generated at 2022-06-21 23:15:05.724267
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()

# Generated at 2022-06-21 23:15:09.424995
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print(handler._exceptions)
            print(handler._handler)

    bp = Bp()
    @bp.exception(list(Exception))
    def handler(request):
        raise Exception


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:16:19.692277
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    bp = Blueprint("bp")
    bp._future_exceptions = set()
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-21 23:16:23.124749
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    
    t_mixin = TestExceptionMixin()
    assert t_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:16:26.907409
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinClass(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            print("called _apply_exception_handler")


    emc = ExceptionMixinClass()
    emc.exception(Exception)

    # TODO

# Generated at 2022-06-21 23:16:32.259300
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

        def mock_exception(self, *exceptions, apply=True):
            pass
    a = MockExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-21 23:16:37.716160
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Given
    class Foo(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    exception_mixin = Foo()

    # When, Then
    assert isinstance(exception_mixin, ExceptionMixin)
    assert len(exception_mixin._future_exceptions) == 0


# Generated at 2022-06-21 23:16:38.557341
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m is not None

# Generated at 2022-06-21 23:16:39.939029
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    if exception._future_exceptions != set():
        raise ValueError

# Generated at 2022-06-21 23:16:43.819967
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from pprint import pprint

    app = Blueprint(name="app", url_prefix="/app")
    
    @app.route("/")
    async def handler(request):
        return

    assert isinstance(app, ExceptionMixin)


# Generated at 2022-06-21 23:16:45.034490
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blue = Blueprint()
    assert blue._future_exceptions == set()

# Generated at 2022-06-21 23:16:49.501729
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions_list=["CustomExceptions","OtherCustomException"]

    def handler(self):
        return 0

    class BluePrint:
        def register(self, *args, **kwargs):
            pass

    bp=BluePrint()

    # calling exception method
    @bp.exception(exceptions_list)
    def handler(self):
        return 0
