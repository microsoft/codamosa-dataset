

# Generated at 2022-06-21 23:09:17.888162
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    

    def handler():
        return 1

    bp = Blueprint("test")
    fe = FutureException(handler, (Exception,))
    bp._future_exceptions.add(fe)
    result = bp._apply_exception_handler(fe)
    assert result == app.error_handler.add(fe)

# Generated at 2022-06-21 23:09:23.247306
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    bp = Blueprint(__name__)
    bp.exception(NotFound)
    app = Sanic()
    bp.register(app)
    app.run()

# Generated at 2022-06-21 23:09:26.949336
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass

    blueprint = Blueprint()
    @blueprint.exception(ValueError, apply=True)
    def handler(request, exceptions):
        pass
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-21 23:09:28.564688
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    testExceptionMixin = ExceptionMixin()
    assert testExceptionMixin
    assert isinstance(testExceptionMixin._future_exceptions, set)


# Generated at 2022-06-21 23:09:38.136788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_exception_mixin = TestExceptionMixin()
    def test_handler():
        return True
    test_exception_mixin.exception(Exception)(test_handler)
    assert True

# Generated at 2022-06-21 23:09:41.865788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception([Exception])
    def handle_exception(request, exception):
        pass
    handle_exception()

# Generated at 2022-06-21 23:09:42.870448
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Test for class ExceptionMixin
    class Test(ExceptionMixin):
        pass
    test = Test()
    assert test._future_exceptions == set()

# Generated at 2022-06-21 23:09:48.460391
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from sanic.models.futures import FutureException
    blueprint = Blueprint('ExceptionMixin')
    assert blueprint._future_exceptions == set()
    assert isinstance(blueprint._future_exceptions, set)
    assert not isinstance(blueprint._future_exceptions, list)
    assert not isinstance(blueprint._future_exceptions, tuple)


# Generated at 2022-06-21 23:10:01.054469
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

    from sanic.handlers import ErrorHandler
    from sanic.exceptions import ServerError
    from sanic.exceptions import Forbidden

    a = TestExceptionMixin()
    a.exception([ServerError, Forbidden])(ErrorHandler)
    assert a._future_exceptions
    assert len(a._future_exceptions) == 1

    a = TestExceptionMixin()
    a.exception(ServerError, Forbidden)(ErrorHandler)
    assert a._future_exceptions
    assert len(a._future_exceptions) == 1

    a = TestExceptionMixin()
    a.exception(ServerError, Forbidden, apply=False)(ErrorHandler)
    assert a._future_

# Generated at 2022-06-21 23:10:05.840508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import TestCase, main
    from unittest.mock import MagicMock

    class ExceptionMixinTest(TestCase, ExceptionMixin):
        __slots__ = ()

        def test__apply_exception_handler(self):
            self._apply_exception_handler = MagicMock()
            self.exception(Exception)

            self._apply_exception_handler.assert_called()
            self._apply_exception_handler.assert_called_with(
                self._future_exceptions.pop())

    main()

# Generated at 2022-06-21 23:10:19.762169
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    someObject = ExceptionMixinTest()
    # Input: handler = None, exceptions = Exception
    # Output: expectedFutureException = FutureException(None, (Exception,))
    try:
        expectedFutureException = someObject.exception(Exception)
    except Exception as e:
        assert str(e) == "The decorated function is missing a parameter. \
Add parameters 'handler' and/or 'apply'"

    def testFunction(request, exception):
        return "No exception"

    # Input: handler = testFunction, exceptions = Exception
    # Output: expectedFuture

# Generated at 2022-06-21 23:10:25.995101
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    my_exception_mixin = ExceptionMixin()
    assert isinstance(my_exception_mixin, ExceptionMixin)
    assert isinstance(my_exception_mixin._future_exceptions, set)
    assert my_exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:10:27.436072
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    tester = ExceptionMixin()
    assert tester._future_exceptions == set()


# Generated at 2022-06-21 23:10:28.190029
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert hasattr(ExceptionMixin, "exception")

# Generated at 2022-06-21 23:10:29.645255
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('blueprint')

    assert blueprint    # to pass flake8 unused variable check


# Generated at 2022-06-21 23:10:39.974571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

    def exception_handler(request, exception):
        try:
            raise exception
        except OSError:
            return text('OSError')
        except IndexError:
            return text('IndexError')
        except Exception:
            return text('Exception')

    exception_wrapper = TestClass().exception(OSError, IndexError, KeyError)
    handler = exception_wrapper(exception_handler)
    handler(text('a'))
    exception_wrapper(exception_handler)

# Generated at 2022-06-21 23:10:42.396559
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert isinstance(bp, ExceptionMixin)

# Generated at 2022-06-21 23:10:50.668018
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.models.futures import FutureException

    blueprint = Blueprint('test blueprint', 'test_blueprint', url_prefix='test')
    assert isinstance(blueprint, ExceptionMixin)

    @blueprint.exception(apply=False)
    def handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:10:59.007883
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.test_exception_mixin = self

    test_exception_mixin = TestExceptionMixin()
    assert isinstance(test_exception_mixin, TestExceptionMixin)
    assert isinstance(test_exception_mixin, ExceptionMixin)



# Generated at 2022-06-21 23:11:01.171609
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    test()

 # Unit test for method _apply_exception_handler() of class ExceptionMixin

# Generated at 2022-06-21 23:11:04.721080
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: add test
    pass

# Generated at 2022-06-21 23:11:10.968718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.routes import Blueprint

    blueprint = Blueprint()

    @blueprint.exception(Exception)
    def handler(request, exception):
        return (request, exception)

    future_exception = FutureException(handler, (Exception,))
    assert (
        future_exception ==
        Blueprint._future_exceptions.pop())

# Generated at 2022-06-21 23:11:22.335329
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_ExceptionMixin_exception", url_prefix="/t")

    @bp.get("/")
    def handler(request):
        raise Exception("test")

    @bp.exception(Exception)
    def handler_exception(request, exception):
        return exception.args[0]

    bp.register(app)
    request, response = app.test_client.get("/t/")
    assert response.text == "test"
    app.blueprint.clear_exception(Exception)
    app.blueprint._future_exceptions.clear()


# Generated at 2022-06-21 23:11:30.123843
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = Blueprint()
    @blueprint.exception(ValueError)
    def handler(request, exception):
        pass
    @blueprint.exception([ValueError, NameError])
    def handler_list(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 2
    assert handler in blueprint._future_exceptions
    assert handler_list in blueprint._future_exceptions

# Generated at 2022-06-21 23:11:32.989461
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Initialization
    a = ExceptionMixin()
    assert(isinstance(a, ExceptionMixin))

# Generated at 2022-06-21 23:11:41.819561
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    from sanic.blueprints import Blueprint
    from sanic.router import RouteExpectation

    bp = Blueprint("test_bp", url_prefix="/test")
    bp.exception(Exception)(print)
    bp.add_route(bp.exception(Exception)(print), "/route", methods=["GET"])

    # act
    global_exception_handler, global_handler_args, global_handler_kwargs = bp._get_exception_handler()
    route = bp._url_rules[1]

    # assert
    assert len(bp._future_exceptions) == 2
    assert global_exception_handler == print
    assert global_handler_args == (Exception,)
    assert global_handler_kwargs == {}
    assert isinstance(route, RouteExpectation)

# Generated at 2022-06-21 23:11:50.797611
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    
    class FutureException(object):
        def __init__(self, handler, exceptions):
            self.handler = handler
            self.exceptions = exceptions
    
    
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            self.handler = handler
            
    s = Sanic()
    
    @s.exception([Exception, ValueError, TypeError])
    def err_handler(request, exception):
        return "Internal Server Error"
    
    assert s.handler.exceptions == (Exception, ValueError, TypeError)
    assert s.handler.handler("request", "exception") == "Internal Server Error"

# Generated at 2022-06-21 23:11:55.217442
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    test = Blueprint('test', url_prefix='test')
    @test.exception(apply=True)
    async def exception_handler():
        print('test')


# Generated at 2022-06-21 23:12:01.694799
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def test_method(self, *args, **kwargs):
            pass
    # test exception(apply=False)
    mixin = TestExceptionMixin()
    mixin.exception(ValueError)(mixin.test_method)
    assert mixin._future_exceptions == {FutureException(handler=mixin.test_method, exceptions=(ValueError,))}
    # test exception(apply=True)
    mixin = TestExceptionMixin()
    with pytest.raises(NotImplementedError):
        mixin.exception(ValueError, apply=True)(mixin.test_method)

# Generated at 2022-06-21 23:12:04.913790
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    e = ExceptionMixin()

    assert(e._future_exceptions == set())
    assert(isinstance(e, Blueprint))

# Generated at 2022-06-21 23:12:08.692723
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:12:09.650402
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert exception is not None

# Generated at 2022-06-21 23:12:13.677880
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.route_model import RouteModel
    import sanic
    @ExceptionMixin.exception(KeyError, apply=False)
    def global_exception_handler(request: sanic.request, exception: KeyError):
        return request, exception

    assert isinstance(global_exception_handler, RouteModel)

# Generated at 2022-06-21 23:12:16.693377
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    t = test_ExceptionMixin()
    assert t._future_exceptions == set()

# Generated at 2022-06-21 23:12:17.189011
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:12:20.643731
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('name')
    bp = Blueprint('name')

    assert isinstance(app, ExceptionMixin)
    assert isinstance(bp, ExceptionMixin)



# Generated at 2022-06-21 23:12:22.483687
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import pytest

    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()

    

# Generated at 2022-06-21 23:12:30.781150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    t = TestExceptionMixin()
    l = []
    @t.exception([Exception])
    def fn(handler, *args, **kwargs):
        l.append(handler)
    fn()
    assert len(l) == 1
    t._future_exceptions.add(l[0])
    assert len(t._future_exceptions) == 1
    f = set(t._future_exceptions)
    assert len(f) == 1
    assert type(f) == set
    f = list(f)
    assert len(f) == 1
    assert type(f) == list
    f = f[0]
    assert f.handler == fn
    assert f.args == (Exception,)

# Generated at 2022-06-21 23:12:38.211279
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    assert(obj is not None)

    # Test exception with a function as a handler
    def handle_exception():
        return

    obj.exception(Exception)(handle_exception)

    # Test exception with a list of exceptions as an argument
    exceptions_list = [TypeError, RuntimeError]
    obj.exception(exceptions_list)(handle_exception)

test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:12:42.209176
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    app = Sanic()
    class DummyView(HTTPMethodView, ExceptionMixin):
        def get(self):
            raise Exception
        def post(self):
            raise IOError
    app.add_route(DummyView.as_view(), '/dummy')

    @DummyView.exception(Exception)
    def exception_handler(request, exception):
        return 'Exception has been caught'

    @DummyView.exception(IOError)
    def ioerror_handler(request, exception):
        return 'IOError has been caught'

    # Exception raised in the get method but is not handled by method exception,
    # so the method returns None.
    assert app.test_

# Generated at 2022-06-21 23:12:48.144799
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin_test = ExceptionMixin()
    exceptionMixin_test.__init__()


# Generated at 2022-06-21 23:12:49.830853
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert type(bp._future_exceptions) is set


# Generated at 2022-06-21 23:12:51.767016
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def exception1(handler):
        print(handler)
        return handler
    exception1('test')

test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:13:02.604908
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()
        def _apply_exception_handler(self, handler: FutureException):
            print("apply exception handling!")
    def test_exception_handler1(request, exception):
        print("exception handler1")
    def test_exception_handler2(request, exception):
        print("exception handler2")
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    # noqa

# Generated at 2022-06-21 23:13:05.025635
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("name")
    blueprint.exception(Exception)
    blueprint.exception(Exception)

# Generated at 2022-06-21 23:13:12.612774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create instance of ExceptionMixin
    expected_excpetions = (ValueError, TypeError)
    test_ExceptionMixin = ExceptionMixin()

    # add Exception to test_ExceptionMixin._future_exceptions
    test_ExceptionMixin.exception(expected_excpetions)

    # assert that _future_exceptions of test_ExceptionMixin is as expected
    actual_future_exceptions = test_ExceptionMixin._future_exceptions
    expected_future_exceptions = [FutureException(None, expected_excpetions)]

    for future_exception in actual_future_exceptions:
        assert future_exception in expected_future_exceptions

# Generated at 2022-06-21 23:13:15.214866
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert type(exception_mixin._future_exceptions) == set

# Generated at 2022-06-21 23:13:18.709268
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint('')
    handler = ExceptionMixin(blueprint)
    assert handler
    assert handler._future_exceptions == set()


# Generated at 2022-06-21 23:13:23.079772
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()

    a = A()
    assert type(a._future_exceptions) == set

# Generated at 2022-06-21 23:13:30.264207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    @Blueprint.exception(Exception)
    def exception_handler(request, exception):
        return "Bar"
    assert len(Blueprint._future_exceptions) == 1

# Generated at 2022-06-21 23:13:46.345232
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    bp = Blueprint()
    assert not bp._future_exceptions
    @bp.exception(AttributeError)
    def test_click(*args, **kwargs):
        assert True
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-21 23:13:47.480507
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert isinstance(e._future_exceptions, set)


# Generated at 2022-06-21 23:13:52.150961
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    from sanic import Blueprint, Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    application = Blueprint(__name__)
    class MyView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse()

    @application.exception(Exception)
    def catch_all_exception(request, exception):
        return HTTPResponse(text="Internal server error", status=500)
    # Act
    application.add_route(MyView.as_view(), '/')
    app = Sanic(__name__)
    app.blueprint(application)
    # Assert
    request, response = app.test_client.get('/')

# Generated at 2022-06-21 23:13:54.773407
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_test = ExceptionMixin()
    assert isinstance(exception_test, ExceptionMixin)

# Generated at 2022-06-21 23:14:00.473571
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    app = Sanic(__name__)

    class NewExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    new_instance = NewExceptionMixin(app)
    assert new_instance._future_exceptions == set()

# Generated at 2022-06-21 23:14:09.026274
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test = TestExceptionMixin()
    assert test._future_exceptions == set()


# Generated at 2022-06-21 23:14:19.722399
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = (
        FakeExceptionMixin()
    )

    # Call exception method of class ExceptionMixin
    exception_mixin.exception(
        Exception,
        apply=True
    )

    # Check that instance method apply_exception_handler was called
    called = exception_mixin.apply_exception_handler_called
    assert called

    # Check that target of instance method apply_exception_handler is
    # FutureException
    target = exception_mixin.apply_exception_handler_target
    assert isinstance(target, FutureException)


# Generated at 2022-06-21 23:14:30.927259
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class fake_ExceptionMixin(ExceptionMixin):
        
        def _apply_exception_handler(self, handler: FutureException):
            fake_ExceptionMixin._apply_exception_handler_called = True
            fake_ExceptionMixin._apply_exception_handler_called_handler = handler

        def reset():
            fake_ExceptionMixin._apply_exception_handler_called = False
            fake_ExceptionMixin._apply_exception_handler_called_handler = None

    fake_ExceptionMixin.reset()
    def handler():
        pass
    fake_ExceptionMixin().exception('fake_error')(handler)
    assert fake_ExceptionMixin._apply_exception_handler_called == True
    assert fake_ExceptionMixin._apply_exception_handler_called_handler.handler == handler
    assert fake_ExceptionMixin

# Generated at 2022-06-21 23:14:42.166833
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            self._apply_exception_handler_called: bool = False
            self._apply_exception_handler_exception: FutureException = None

        def _apply_exception_handler(self, handler: FutureException):
            self._apply_exception_handler_called = True
            self._apply_exception_handler_exception = handler

    def handler():
        pass

    exception_mixin = MockExceptionMixin()

# Generated at 2022-06-21 23:14:42.634831
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:15:05.623659
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    _list = [1, 2, 3]
    _tuple = (1, 2, 3)
    _exception = ExceptionMixin()
    _exception._apply_exception_handler = lambda x: None

    func_test_ExceptionMixin_exception = _exception.exception(_tuple)
    func_test_ExceptionMixin_exception(_tuple)

    assert FutureException(exception=_tuple).exception == _tuple

    func_test_ExceptionMixin_exception = _exception.exception(_tuple)
    func_test_ExceptionMixin_exception(_tuple)
    assert FutureException(exception=_tuple).exception == _tuple

    func_test_ExceptionMixin_exception = _exception.exception(_list)
    func_test_ExceptionMixin_

# Generated at 2022-06-21 23:15:08.086624
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    # Act
    exception_mixin = ExceptionMixin()
    # Assert
    assert type(exception_mixin._future_exceptions) is set


# Generated at 2022-06-21 23:15:18.251219
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import SanicBlueprint

    app = Sanic('test_ExceptionMixin_exception')
    bp = SanicBlueprint('test_bp', url_prefix='/test/bp')
    @bp.exception(ZeroDivisionError)
    def handle_exception(request, exception):
        pass

    bp.record(app)
    assert app.exception_handler.handlers[ZeroDivisionError] == handle_exception
    assert app.exception_handler.handlers[ZeroDivisionError].__module__ == __name__



# Generated at 2022-06-21 23:15:20.228349
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert(ExceptionMixin()._future_exceptions == set())

# Generated at 2022-06-21 23:15:22.806167
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: Exception):
            return handler
    assert TestExceptionMixin()

# Generated at 2022-06-21 23:15:25.303266
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()
    assert exceptionMixin._future_exceptions == set()



# Generated at 2022-06-21 23:15:31.047841
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """

            def decorator(handler):
                nonlocal apply
                nonlocal exceptions


# Generated at 2022-06-21 23:15:35.650709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ClassWithExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(ClassWithExceptionMixin, self).__init__()

        async def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler.__name__ == 'my_exception_handler'
            assert handler.exceptions == (KeyError, ValueError)

    class_with_exception_mixin = ClassWithExceptionMixin()
    @class_with_exception_mixin.exception(KeyError, ValueError)
    def my_exception_handler():
        return ""

# Generated at 2022-06-21 23:15:42.470953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("unit-test-blueprint")

    @blueprint.exception(Exception)
    def catch_all_exceptions(request, exception):
        pass

    assert blueprint.get_exception_handler(Exception) == catch_all_exceptions

# Generated at 2022-06-21 23:15:46.308873
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = None

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    em = _ExceptionMixin()
    assert em._future_exceptions is not None


# Generated at 2022-06-21 23:16:33.457312
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # test creating blueprint without exception handler
    bp = Blueprint("test_bp", url_prefix="/test_bp")

    # test creating blueprint with exception handler
    bp2 = Blueprint("test_bp2", url_prefix="/test_bp2")
    @bp2.exception(Exception)
    def exception_handler(request, exception):
        return text('I am the exception handler for test_bp2')

# Test for create exception handler for blueprint
# Test case 1: global exception handler and main app exception handler

# Generated at 2022-06-21 23:16:35.792999
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:16:39.644875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = [ValueError, Exception]
    apply = True
    handler = lambda: None

    mixin = ExceptionMixin()
    assert len(mixin._future_exceptions) == 0

    assert mixin.exception(*exceptions, apply=apply)(handler) == handler
    assert len(mixin._future_exceptions) == 1

# Generated at 2022-06-21 23:16:45.405665
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    # when
    test_exception_mixin = TestExceptionMixin()
    def test_handler():
        pass

    test_future_exception = test_exception_mixin.exception(Exception)(test_handler)

    # then
    assert test_future_exception is test_handler
    assert test_exception_mixin._future_exceptions.pop() == FutureException(test_handler, (Exception,))

# Generated at 2022-06-21 23:16:46.014838
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:16:48.496504
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test')
    bp.exception(IndexError)
    assert ExceptionMixin._future_exceptions != None


# Generated at 2022-06-21 23:16:49.313581
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    _ = ExceptionMixin()

# Generated at 2022-06-21 23:16:50.960751
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("TestExceptionMixin")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:16:53.146706
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def handler():
        print('test')


test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:16:59.387011
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create blueprint instance
    blueprint = Blueprint("test_blueprint")

    # create exception handler
    @blueprint.exception(Exception)
    async def exception_handler(request, exception):
        raise Exception("exception")

    # get exception handler
    future_exception = blueprint._future_exceptions.pop()

    # check
    assert isinstance(future_exception, FutureException)
    assert future_exception._handler == exception_handler
    assert future_exception._exceptions == (Exception,)

# Generated at 2022-06-21 23:18:24.290133
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    args = ()
    kwargs = {}
    em = ExceptionMixin(*args, **kwargs)
    assert em is not None
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:18:34.049598
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import pytest

    @pytest.mark.parametrize("args", [(), (1,), ("haha",)])
    def _test_constructor(args, mocker):
        mock_init = mocker.patch("sanic.models.exceptions.ExceptionMixin.__init__")
        exception_mixin = ExceptionMixin(*args)
        mock_init.assert_called_once_with(*args)
        assert exception_mixin._future_exceptions == set()

    _test_constructor(*test_ExceptionMixin.parametrize("args"))


# Generated at 2022-06-21 23:18:45.750175
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    from sanic.models.exceptions import BlueprintException

    app = Sanic()
    bp = BlueprintException("test_bp", url_prefix="/test_bp")

    @bp.exception(ZeroDivisionError)
    def internal_error(request, exception):
        response = jsonify({"error": "internal error"})
        response.status_code = 500
        return response

    assert (len(bp._future_exceptions)) == 1
    assert (len(app._future_exceptions)) == 0
    bp.register(app)
    assert (len(bp._future_exceptions)) == 1
    assert (len(app._future_exceptions)) == 1

    @bp.exception(ZeroDivisionError)
    def internal_error(request, exception):
        response = json

# Generated at 2022-06-21 23:18:49.778206
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    app = Blueprint.create(None, url_prefix='/')
    assert isinstance(app, ExceptionMixin)


# Generated at 2022-06-21 23:18:56.496534
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    # Instance ExceptionMixin
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            return

    exception_mixin = MyExceptionMixin()
    excep_mix_future_exceptions = exception_mixin._future_exceptions
    # Check set _future_exceptions is empty
    assert(isinstance(excep_mix_future_exceptions, set))
    assert(len(excep_mix_future_exceptions) == 0)


# Generated at 2022-06-21 23:19:04.502168
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException

    app = Sanic('test_ExceptionMixin_exception')

    @app.exception(SanicException)
    def exception_handler(request, exception):
        return text('Internal server error', 500)

    @app.route('/')
    async def handler(request):
        raise NotImplementedError("Not implemented")

    request, response = app.test_client.get('/')
    assert response.status == 500
    assert response.text == 'Internal server error'

# Generated at 2022-06-21 23:19:10.109451
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    @ExceptionMixin.exception(Exception)
    def test_handler(*args,**kwargs):
        print("test handler")

    exception_mixin = ExceptionMixin()

    exception_mixin.exception(Exception)

    test_handler()