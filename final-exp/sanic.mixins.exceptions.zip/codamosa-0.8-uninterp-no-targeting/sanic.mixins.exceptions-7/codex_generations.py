

# Generated at 2022-06-21 23:09:22.360550
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test(ExceptionMixin):
        pass

    @test.exception(Exception)
    def decorator(handler):
        pass

    assert True

# Generated at 2022-06-21 23:09:32.137109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinEx:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)
    class aa:
        def asdf(error, *args, **kwargs):
            return error

    # testing with the list of exeptions
    exConf = ExceptionMixinEx()
    exConf.exception([keyboardInterrupt, SystemExit])(aa().asdf)
    assert len(exConf._future_exceptions) == 1

    # testing with the tuple of exeptions
    exConf = ExceptionMixinEx()
    exConf.exception(keyboardInterrupt, SystemExit)(aa().asdf)

# Generated at 2022-06-21 23:09:36.110085
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test = ExceptionMixin()
    assert isinstance(test, object)
    assert isinstance(test._future_exceptions, set)


# Generated at 2022-06-21 23:09:38.310720
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass

    A()
    try:
        A().exception()
        assert False
    except NotImplementedError:
        pass



# Generated at 2022-06-21 23:09:46.545040
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return None

    test_mixin = TestExceptionMixin()
    assert isinstance(test_mixin, TestExceptionMixin)

# Generated at 2022-06-21 23:09:48.784562
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:09:58.170259
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models import Blueprint
    blueprint = Blueprint('Test', 'test')

    blueprint._apply_exception_handler = lambda exception: None

    blueprint.exception(Exception, apply=False)(lambda request, exception: None)
    assert blueprint._future_exceptions.pop() is not None

    blueprint.exception([Exception, TypeError])(lambda request, exception: None)
    assert blueprint._future_exceptions.pop() is not None

# Generated at 2022-06-21 23:10:01.518447
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Not implemented
    pass

# Generated at 2022-06-21 23:10:11.324212
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blue_print = Blueprint("blue", url_prefix='/blue')

    def test(request):
        return request

    @blue_print.exception(ZeroDivisionError)
    def zde(request, exception):
        print("ZeroDivisionError")
        return "Ran into ZeroDivisionError"

    @blue_print.exception(ValueError, apply=False)
    def ve(request, exception):
        print("ValueError")
        return "Ran into ValueError"

    assert len(blue_print._future_exceptions) == 2
    assert blue_print.listeners[ZeroDivisionError] == zde
    assert blue_print.listeners[ValueError] is None

# Generated at 2022-06-21 23:10:16.006864
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    exception_mixin = TestExceptionMixin()
    assert len(exception_mixin._future_exceptions) == 0

# Generated at 2022-06-21 23:10:30.070214
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Blueprint.exception
    import unittest

    from sanic.blueprints import Blueprint

    BLUEPRINT_NAME = "test"
    blueprint = Blueprint(BLUEPRINT_NAME)

    HANDLER_NAME = "testHandler"
    HANDLER_RETURN_VAL = "return"

    @blueprint.exception(Exception)
    def test_handler(request, *args, **kwargs):
        return HANDLER_RETURN_VAL

    assert len(blueprint._future_exceptions) == 1
    future_exception = list(blueprint._future_exceptions)[0]
    assert future_exception.receiver.__name__ == HANDLER_NAME



# Generated at 2022-06-21 23:10:39.366444
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = []
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.append(handler)

    # When
    impl = ExceptionMixinImpl()
    def handler():
        pass
    impl.exception(ValueError, apply=False)(handler)

    # Then
    assert len(impl._future_exceptions) == 1

# Generated at 2022-06-21 23:10:46.129945
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    test_class = TestClass()
    assert test_class._future_exceptions is not None,\
        "Unexpected None for _future_exceptions after initialization"


# Generated at 2022-06-21 23:10:48.104034
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert(ExceptionMixin()._future_exceptions == set())

# Generated at 2022-06-21 23:10:53.236487
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    obj = TestExceptionMixin()
    assert obj._future_exceptions == set()



# Generated at 2022-06-21 23:10:54.020314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:10:58.392021
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        
        def _apply_exception_handler(self, handler: FutureException):
            assert handler is not None

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(TerminatedWorkerError)
    def some_exception_handler(request, exception):
        assert isinstance(exception, TerminatedWorkerError)

    test_exception_mixin.exception(TerminatedWorkerError)

# Generated at 2022-06-21 23:11:09.844482
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # 1. Define a fake blueprint and decorated function
    class FakeBlueprint:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    def fake_handler(*args, **kwargs):
        1

    # 2. Create an instance of FakeBlueprint
    fake_blueprint = FakeBlueprint()

    # 3. Apply the decorated function fake_handler to the instance of ExceptionMixin
    fake_blueprint.exception(ValueError)(fake_handler)

    # 4. Check whether fake_handler can be found within fake_blueprint._future_exceptions
    assert (
        fake_handler in fake_blueprint._future_exceptions
    )

# Generated at 2022-06-21 23:11:11.487954
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a is not None

# Generated at 2022-06-21 23:11:17.128717
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return

    emc = ExceptionMixinClass()
    assert isinstance(emc._future_exceptions, set)

# Generated at 2022-06-21 23:11:29.636888
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic import Blueprint
    bp = Blueprint('test', url_prefix='test')
    # TODO: how to mock the method _apply_exception_handler?
    ## bp._apply_exception_handler = MagicMock()
    @bp.exception(Exception)
    def exception_handler(request, exception):
        return response.text('Internal server error', 500)

    assert isinstance(exception_handler, types.FunctionType)
    assert exception_handler in bp._future_exceptions
    ### bp._apply_exception_handler.assert_called_once_with(exception_handler)
    pytest.skip('Need to mock _apply_exception_handler')

# Generated at 2022-06-21 23:11:34.406896
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    em = TestExceptionMixin()
    assert isinstance(em, ExceptionMixin)
    assert isinstance(em._future_exceptions, set)

# Generated at 2022-06-21 23:11:38.060849
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
    te = TestExceptionMixin()
    assert isinstance(te._future_exceptions, set)

# Generated at 2022-06-21 23:11:45.985613
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A:
        def __init__(self,*argc,**kwargs):
            self._future_exceptions=set()

        def _apply_exception_handler(self,handler):
            pass

    obj=A()
    assert type(obj._future_exceptions)==type(ExceptionMixin.__init__(obj)._future_exceptions)

# Generated at 2022-06-21 23:11:54.314885
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    class MyException(Exception):
        pass

    class ExceptionMixin:
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            pass

    class MyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

    class MyApp(Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

            self.exception_handler_kwargs = {}

    def exception_handler(request, exception):
        pass

    app = MyApp()
    m = MyClass()

    m

# Generated at 2022-06-21 23:12:00.243156
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException
    from sanic.utils import sanic_endpoint_test

    @sanic_endpoint_test
    async def handler(request):
        return request.json

    assert isinstance(handler, types.FunctionType)

    @handler.exception(SanicException)
    async def handler(request, exception):
        return text('fail')

    assert len(handler._sanic_handler_list) == 2
    assert len(handler._sanic_handler_list[0]._exceptions) == 0
    assert len(handler._sanic_handler_list[1]._exceptions) == 1



# Generated at 2022-06-21 23:12:10.526943
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    t1 = TestExceptionMixin()
    assert len(t1._future_exceptions) == 0

    @t1.exception(ZeroDivisionError, RuntimeError)
    def exception_handler(request, exception):
        assert exception is not None

    assert len(t1._future_exceptions) == 1

    for future_exception in t1._future_exceptions:
        assert future_exception.exceptions[0] == ZeroDivisionError
        assert future_exception.exceptions[1] == RuntimeError

    t2 = TestExceptionMixin()
    assert len(t2._future_exceptions) == 0


# Generated at 2022-06-21 23:12:18.517178
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-21 23:12:28.351159
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test = test_ExceptionMixin()

    # test with one exception
    @test.exception(Exception)
    def handler(request, exception):
        return exception
    assert handler == test._future_exceptions.pop().handler

    # test with multiple exceptions
    @test.exception(Exception, ValueError)
    def handler2(request, exception):
        return exception
    assert handler2 == test._future_exceptions.pop().handler

    # test with multiple exceptions as a list
    @test.exception([Exception, ValueError])
    def handler3(request, exception):
        return exception

# Generated at 2022-06-21 23:12:29.950473
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    bp = Blueprint("test", url_prefix="test")
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:12:40.887585
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError()

    exception_mixin = ExceptionMixinTest()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:12:45.292399
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_Mock(ExceptionMixin):
        pass
    exception_mixin = ExceptionMixin_Mock()
    assert exception_mixin._future_exceptions == set()
    assert exception_mixin is not None



# Generated at 2022-06-21 23:12:47.399567
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert_true(ExceptionMixin._apply_exception_handler)



# Generated at 2022-06-21 23:12:49.514803
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print("-----------test_ExceptionMixin-----------")
    mixin = ExceptionMixin()
    assert mixin
    print("Passed!")


# Generated at 2022-06-21 23:12:55.845617
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json
    bp = Blueprint('test_bp')

    @bp.exception([ValueError])
    def handle_value_error(request, exception):
        # Do something with the exception
        return json({"exception": "value error"})

    @bp.exception([ZeroDivisionError])
    def handle_zero_division_error(request, exception):
        # Do something with the exception
        return json({"exception": "zero division"})

    assert bp._future_exceptions

# Generated at 2022-06-21 23:13:00.689136
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import Forbidden

    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exceptionMixin = TestExceptionMixin()

    @test_exceptionMixin.exception(Forbidden)
    def handler(request, exception):
        return "forbidden"

    # Success to add handler with exception in future exceptions
    assert len(test_exceptionMixin._future_exceptions) == 1

# Generated at 2022-06-21 23:13:03.688265
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            for future_exception in self._future_exceptions:
                raise Exception
    ExceptionMixinTest().exception(Exception)(Exception)



# Generated at 2022-06-21 23:13:13.028726
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.layouts import Layout
    # test default constructor
    obj = ExceptionMixin()
    assert type(obj) == ExceptionMixin
    assert obj.__doc__ != None
    assert hasattr(obj, '_future_exceptions')
    assert type(obj._future_exceptions) == set

    # test argument constructor
    obj = ExceptionMixin(__name__)
    assert type(obj) == ExceptionMixin
    assert obj.__doc__ != None
    assert hasattr(obj, '_future_exceptions')
    assert type(obj._future_exceptions) == set

    # test other argument constructor
    obj = ExceptionMixin(__name__, False)
    assert type(obj) == ExceptionMixin
    assert obj.__doc__ != None

# Generated at 2022-06-21 23:13:15.883422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    owner_class = ExceptionMixin
    decorator = owner_class.exception(Exception)
    assert callable(decorator)

# Generated at 2022-06-21 23:13:19.262858
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixinTest, self).__init__()
            self._future_exceptions = set()

    assert ExceptionMixinTest()._future_exceptions == set()

# Generated at 2022-06-21 23:13:39.048166
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
        def _apply_exception_handler(self, handler: object) -> None:
            pass

    tester = ExceptionMixinTester()


# Generated at 2022-06-21 23:13:49.122387
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprint import Blueprint
    from sanic.models.futures import FutureException

    class ExceptionTest(ExceptionMixin, Blueprint):
        pass

    bp = ExceptionTest("Test", "/test")
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 0
    assert bp._future_exceptions == set()
    assert bp.exception(KeyError)(1) is 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:14:02.092386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def _handler(request, exception):
        print("Exception handler called.")

    from unittest.mock import Mock
    from sanic.blueprints import Blueprint

    # 不传参数
    bp = Blueprint("test_exception_mixin")
    bp._apply_exception_handler = Mock()
    bp.exception(_handler)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(_handler, None)
    bp._apply_exception_handler.assert_called_once_with(FutureException(_handler, None))

    # 指定异常处理
    bp = Blueprint("test_exception_mixin")
    bp._apply_exception_handler = Mock()
    bp

# Generated at 2022-06-21 23:14:09.779285
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_class = TestExceptionMixin()
    test_class.exception(Exception)
    assert len(test_class._future_exceptions)==1

# Generated at 2022-06-21 23:14:13.050949
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin_ = ExceptionMixin()
    assert len(exception_mixin_._future_exceptions) == 0

# Generated at 2022-06-21 23:14:16.102463
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class H:
        pass

    class F:
        pass

    e = ExceptionMixin()
    e.exception(H)(F)

# Generated at 2022-06-21 23:14:22.397161
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def mock_handler(req, exc):
        return 'handler'

    mock = Mock()
    mock_exception_handler = mock.exception(mock_handler)
    assert mock_exception_handler == mock_handler
    assert mock_exception_handler() == 'handler'

# Generated at 2022-06-21 23:14:28.401601
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Model(ExceptionMixin):
        pass
    model=Model()
    exceptions = Exception('test')
    apply = True
    def decorator(handler):
        assert handler==test_handler
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        model._future_exceptions.add(future_exception)
        if apply:
            model._apply_exception_handler(future_exception)
        return handler
        
    @model.exception(exceptions, apply=apply)
    def test_handler():
        pass
    assert len(model._future_exceptions) == 1
    result = model._future_exceptions.pop()
    assert result.handler == test_handler
   

# Generated at 2022-06-21 23:14:41.147735
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SavedRequest

    def exception_handler():
        pass

    # try to register a handler for exceptions raised in the blueprint
    blueprint = Blueprint(None)
    blueprint.exception(exception_handler)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(exception_handler, (Exception,))

    # check that the handler is registered to be applied
    blueprint = Blueprint(None)
    blueprint.apply_request(SavedRequest())
    blueprint.exception(exception_handler)
    assert len(blueprint.error_handler.handlers) == 1

    # check that the handler is not registered to be applied
    blueprint = Blueprint(None)

# Generated at 2022-06-21 23:14:41.658967
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:15:21.016137
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint, response
    sanic = Sanic('sanic')

    blueprint = Blueprint('test_sanic', url_prefix='blueprint')
    blueprint.exception(ValueError)(lambda request, exception: response.text("This is a ValueError"))
    blueprint.exception(IndexError, apply=False)(lambda request, exception: response.text("This is a IndexError"))
    blueprint.exception(Exception, apply=False)(lambda request, exception: response.text("This is a Exception"))

    @blueprint.route('/exc')
    def exc(request):
        raise Exception('Some exception')


# Generated at 2022-06-21 23:15:23.987681
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # initialize a new object with empty parameters
    object = ExceptionMixin()
    assert len(object._future_exceptions) == 0


# Generated at 2022-06-21 23:15:26.168015
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  exceptionMixin = ExceptionMixin()
  assert exceptionMixin._future_exceptions == set()

# Generated at 2022-06-21 23:15:28.146661
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin().exception(Exception)
    assert callable(result)

# Generated at 2022-06-21 23:15:29.444859
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-21 23:15:33.417665
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        class TestClass(ExceptionMixin):
            pass
        d = TestClass()
        d._apply_exception_handler(None)



# Generated at 2022-06-21 23:15:35.075629
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert ex


# Generated at 2022-06-21 23:15:37.512135
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """Test that object is properly initialized"""
    ExceptionMixin()

# Generated at 2022-06-21 23:15:40.533021
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    exceptionMixin = ExceptionMixin()
    assert exceptionMixin._future_exceptions == set()



# Generated at 2022-06-21 23:15:44.790501
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints.exception_mixin import ExceptionMixin
    exception_mixin = ExceptionMixin()
    assert type(exception_mixin) == ExceptionMixin
    assert len(exception_mixin._future_exceptions) == 0

# Generated at 2022-06-21 23:16:56.233737
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    @app.exception(Exception)
    def handler():
        return None
    assert isinstance(app, ExceptionMixin)

# Generated at 2022-06-21 23:16:58.400862
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-21 23:17:05.049150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage
    from sanic.response import text

    # class Blueprint(ExceptionMixin, Blueprint):
    #     pass
    bp = Blueprint(__name__, url_prefix="/")

    @bp.exception(InvalidUsage)
    def handle_invalid_usage(request, exception):
        return text(str(exception), status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    future_exception = bp._future_exceptions.pop()
    assert len(future_exception.exceptions) == 1



# Generated at 2022-06-21 23:17:07.177367
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert set() == exception_mixin._future_exceptions

# Generated at 2022-06-21 23:17:10.720017
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin._future_exceptions, set)
    assert not tuple(mixin._future_exceptions)


# Generated at 2022-06-21 23:17:11.549509
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:17:14.358746
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em is not None
    assert em._future_exceptions is not None


# Generated at 2022-06-21 23:17:17.285271
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    assert TestExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:17:23.026212
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_class = TestClass()
    assert test_class._future_exceptions == set()

    def handler(request, exception):
        pass

    test_class.exception(Exception)(handler)
    assert len(test_class._future_exceptions) == 1

    def raise_exception():
        raise Exception


# Generated at 2022-06-21 23:17:24.663375
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    myclass=ExceptionMixin()
