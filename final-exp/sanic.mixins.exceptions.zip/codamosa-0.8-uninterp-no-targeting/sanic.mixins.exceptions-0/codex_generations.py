

# Generated at 2022-06-21 23:09:23.687282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_error = Exception([RuntimeError])
    test_exception = TestExceptionMixin()

    @test_exception.exception(apply=True)
    def test_function(request, exception):
        raise test_error

    with pytest.raises(Exception) as ex:
        test_function({}, Exception())
    assert ex.type == RuntimeError

# Generated at 2022-06-21 23:09:31.580157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self.exception_handler = None
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            self.exception_handler = handler

    bp = _ExceptionMixin()
    @bp.exception(Exception)
    def global_handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert global_handler in bp._future_exceptions
    assert bp.exception_handler is global_handler

# Generated at 2022-06-21 23:09:38.174782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self): pass
        def _apply_exception_handler(self, handler: FutureException): pass

    a = A()
    @a.exception(ValueError)
    def foo(): pass
    
    assert len(a._future_exceptions) == 1
    assert isinstance(a._future_exceptions[0], FutureException)

# Generated at 2022-06-21 23:09:39.611581
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-21 23:09:50.834678
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # a dummy decorator
    def dummy_decorator(*args, **kwargs):
        def decorator(handler):
            return handler
        return decorator

    # trick: just overwrite the method _apply_exception_handler
    def wrap(self, handler: FutureException):
        handler.handler()

    ExceptionMixin._apply_exception_handler = wrap

    # Use the dummy decorator
    import sanic.blueprints
    sanic.blueprints.Blueprint.exception = dummy_decorator

    class ExceptionMixinTest(ExceptionMixin):
        pass

    emt = ExceptionMixinTest()

    @emt.exception(Exception)
    def exception_handler():
        pass

    exception_handler()



# Generated at 2022-06-21 23:09:54.845293
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass
    exMixTest = ExceptionMixinTest()
    assert isinstance(exMixTest,ExceptionMixinTest)

# Generated at 2022-06-21 23:09:59.571058
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    def test():
        class ExceptionMixinTester(ExceptionMixin):
            def __init__(self):
                ExceptionMixin.__init__(self)

        obj = ExceptionMixinTester()
        assert obj._future_exceptions == set()   # noqa
    # end of test
    test()

# Generated at 2022-06-21 23:10:11.632448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import json
    from sanic.router import Router
    from sanic.server import HttpProtocol
    from sanic.server import serve
    from tests.asyncio_utils import TestServer, create_test_server

    app = Blueprint(__name__)

    @app.exception(Exception)
    def all_exception_handler(request, exception):
        return json({"status": "exception", "reason": str(exception)})

    @app.exception(KeyError)
    def key_error_handler(request, exception):
        return json({"status": "exception", "reason": str(exception)})

    @app.route("/exception")
    def exception(request):
        a = {}
        a["foo"]

# Generated at 2022-06-21 23:10:15.804382
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    
    test = TestExceptionMixin()
    assert isinstance(test, TestExceptionMixin)
    assert isinstance(test, ExceptionMixin)


# Generated at 2022-06-21 23:10:19.096296
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler

    bp = Blueprint(__name__, error_handler=ErrorHandler())

    # Act
    bp.exception(Exception)(lambda request, exception: {})
    # Assert
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-21 23:10:23.629372
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()



# Generated at 2022-06-21 23:10:25.023799
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)

# Generated at 2022-06-21 23:10:28.896447
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ex_mixin = ExceptionMixin()
        assert True
    except Exception as e:
        assert False, "case1:Constructor of class ExceptionMixin failed: {}".format(e)


# Generated at 2022-06-21 23:10:40.921581
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class Test1(ExceptionMixin):
        pass

    test = Test()
    # Test1
    # exception -> Test1->ExceptionMixin
    Test1.exception(test)

    with pytest.raises(NotImplementedError):
        Test1.exception(test, *[], apply=True)

    # exception -> Test1 -> ExceptionMixin
    test1 = Test1()
    test1.exception(test)
    assert test._future_exceptions == set()

    test1.exception(test, *[], apply=True)

# Generated at 2022-06-21 23:10:45.317983
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    assert TestExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:10:49.175355
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprint import Blueprint
    blueprint = Blueprint('blueprint_test')

    assert blueprint._future_exceptions == set()


if __name__ == '__main__':
    test_ExceptionMixin()

# Generated at 2022-06-21 23:10:57.984569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    app = Sanic()

    blueprint = Blueprint('test_bp')

    @blueprint.exception(ServerError)
    def handler_exception(request, exception):
        return text(str(exception), status=500)

    @blueprint.route('/')
    def handler(request):
        raise ServerError("Something went wrong")

    app.blueprint(blueprint)

    assert app.error_handler.keys == {ServerError}

    request, response = app.test_client.get('/')

    assert response.status == 500
    assert response.text == 'Something went wrong'

    # Test using list exception

# Generated at 2022-06-21 23:11:02.533012
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    Unit test for method exception of class ExceptionMixin
    '''

    class mock():
        def __init__(self, *args, **kwargs):
            self._future_exceptions= set()


    def handler(request, ex):
        return  'exception handler'

    exceptions = [Exception]

    decorator = ExceptionMixin(mock).exception(*exceptions)
    result = decorator(handler)
    assert result('request', 'ex') == 'exception handler'

# Generated at 2022-06-21 23:11:04.505369
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex_mixin = ExceptionMixin()
    assert ex_mixin


# Generated at 2022-06-21 23:11:09.960211
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request

    @Blueprint.exception(apply=False)
    def global_exception_handler(request: Request, exception: Exception):
        return response.text('Exception: %s' % exception, 500)


# Generated at 2022-06-21 23:11:19.426373
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint(__name__)

    @blueprint.exception([Exception])
    def handler(request, exception):
        return 'Hello Sanic!'

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-21 23:11:23.646861
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global exception_mixin
    exception_mixin = ExceptionMixin()
    handle = exception_mixin.exception(Exception)
    assert handle
    @handle
    def handle1(request, exception):
        return 'Something went wrong!'


# Generated at 2022-06-21 23:11:33.200379
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinSub(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    obj = ExceptionMixinSub()
    assert len(obj._future_exceptions) == 0
    # exception decorator with arguments
    arg_list = (ValueError,)
    obj.exception(*arg_list)(lambda x: True)

    assert len(obj._future_exceptions) == 1
    future_exc = list(obj._future_exceptions)[0]
    assert future_exc.handler(None) == True
    assert future_exc.exceptions == arg_list

    # exception decorator with no arguments
    obj.exception()(lambda x: True)
    assert len(obj._future_exceptions) == 2

# Generated at 2022-06-21 23:11:40.100972
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            super(MockExceptionMixin, self).__init__(*args, **kwargs)

    mock_exception_mixin = MockExceptionMixin()

    assert type(mock_exception_mixin) == MockExceptionMixin
    assert mock_exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:11:51.094248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import unittest.mock
    from sanic.models.exceptions import ExceptionMixin
    import inspect

    mock_object = unittest.mock.Mock()
    mock_object.__class__ = ExceptionMixin
    mock_object._apply_exception_handler = unittest.mock.Mock()

    @mock_object.exception(Exception)
    def handle_exception(request, exception):
        '''
        Handle global exception.
        '''
        pass

    assert mock_object._apply_exception_handler.call_count == 1
    # check the docstring of handle_exception is 'Handle global exception.'
    assert inspect.getdoc(mock_object._future_exceptions.pop()) == \
        'Handle global exception.'

# Generated at 2022-06-21 23:11:54.344685
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    dummy = DummyBlueprint()
    assert dummy._future_exceptions == set()



# Generated at 2022-06-21 23:11:57.098244
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    # Test ExceptionMixin object
    ExceptionMixin_test()



# Generated at 2022-06-21 23:12:02.552916
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self):
            self._future_exceptions= set()
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)
    exceptions = [ZeroDivisionError, ValueError]
    def handler(*args, **kwargs):
        pass
    A().exception(exceptions)(handler)
    assert(len(A()._future_exceptions) == 1)

# Generated at 2022-06-21 23:12:11.924562
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test", url_prefix="/test")
    assert bp.exception._func is ExceptionMixin.exception
    assert bp._future_exceptions == set()

    @bp.exception(ZeroDivisionError)
    def handle_zero(request, exception):
        pass

    assert bp._future_exceptions == {FutureException(handle_zero, (ZeroDivisionError,))}

    @bp.exception([ZeroDivisionError])
    def handle_zero_2(request, exception):
        pass

    assert bp._future_exceptions == {FutureException(handle_zero, (ZeroDivisionError,)),
                                     FutureException(handle_zero_2, (ZeroDivisionError,))}


# Generated at 2022-06-21 23:12:16.622525
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #1
    class BluePrint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass
    blueprint = BluePrint()
    assert blueprint is not None
    @blueprint.exception()
    def handler1():
        return 1

    # 2
    blueprint2 = BluePrint()
    assert blueprint2 is not None
    @blueprint.exception(handler2=[2, 3])
    def handler2():
        return 1

# Generated at 2022-06-21 23:12:31.754529
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sys import version_info
    from sanic import Sanic

    app = Sanic('ExceptionContainer')
    assert app.exception_handler is None

    @app.exception(Exception)
    def default_exception_handler(request, exception):
        pass

    @app.exception([AssertionError])
    def assertion_exception_handler(request, exception):
        pass

    class Response:
        pass

    @app.middleware
    def custom_middleware(request):
        if request.url == '/custom_middleware':
            raise AssertionError('Testing custom middleware')
        else:
            return Response()

    @app.route('/custom_middleware')
    def handler(request):
        return 2

# Generated at 2022-06-21 23:12:34.219888
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a is not None


# Generated at 2022-06-21 23:12:34.998469
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-21 23:12:43.523882
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixinClass, self).__init__(*args, **kwargs)
    
        def _apply_exception_handler(self, handler: FutureException):
            print('_apply_exception_handler')

    ExceptionMixinClass().exception(ValueError, apply=False)(lambda: print('Exception handler'))
    ExceptionMixinClass().exception({ValueError}, apply=False)(lambda: print('Exception handler'))

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:12:48.490646
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    # test that constructor of ExceptionMixin initializes the empty set()
    assert a._future_exceptions == set()

# Generated at 2022-06-21 23:12:50.937488
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import ExceptionMixin as E
    em = E()
    assert isinstance(em._future_exceptions, set)



# Generated at 2022-06-21 23:12:58.992896
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    exception_mixin = TestExceptionMixin()
    assert exception_mixin._future_exceptions == set()
    exception_mixin._apply_exception_handler = lambda x: print("called")

    @exception_mixin.exception(ValueError)
    def test(request, exc):
        pass

    assert len(exception_mixin._future_exceptions) == 1

# Generated at 2022-06-21 23:13:00.220667
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # TODO:  Implement unit test
    assert(0)



# Generated at 2022-06-21 23:13:06.634439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test case 1
    case1 = {
        'args': (),
        'kwargs': {},
        'apply': True,
        'output': {
            '_future_exceptions': {},
            '_apply_exception_handler': 'NotImplementedError'
        }
    }

    # test case 2
    case2 = {
        'args': (object,),
        'kwargs': {},
        'apply': True,
        'output': {
            '_future_exceptions': {},
            '_apply_exception_handler': 'NotImplementedError'
        }
    }

    # test case 3

# Generated at 2022-06-21 23:13:11.385398
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class ClassForExceptionMixin(ExceptionMixin):
        def __init__(self):
            pass

    instance = ClassForExceptionMixin()

    # Act
    def decorator(handler):
        return handler
    result = instance.exception(decorator, apply=True)

    # Assert
    assert result.__name__ == 'decorator'

# Generated at 2022-06-21 23:13:30.441797
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestException(ExceptionMixin):
        pass
    test_object = TestException()
    assert test_object._future_exceptions == set()
    assert len(test_object.__init__.__code__.co_varnames) == 2
    assert test_object.__init__.__code__.co_argcount == 2



# Generated at 2022-06-21 23:13:33.487191
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

# Generated at 2022-06-21 23:13:38.559262
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    assert A()._future_exceptions == set()


# Generated at 2022-06-21 23:13:50.807604
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    apply = True
    exceptions = (Exception,)
    kwargs = {}
    handler = lambda x: x

    # Act
    em = ExceptionMixin()
    handler_decorator = em.exception(exceptions, apply, **kwargs)
    decorated_handler = handler_decorator(handler)

    # Assert
    assert callable(handler_decorator)
    assert callable(decorated_handler)
    assert len(em._future_exceptions) == 1
    future_exception = list(em._future_exceptions)[0]
    assert future_exception.handler == decorated_handler
    assert future_exception.exceptions == exceptions
    assert future_exception.kwargs == kwargs


# Generated at 2022-06-21 23:14:01.088626
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    a = A()
    @a.exception(AttributeError)
    def test_function(request):
        pass
    print(a._future_exceptions)
    print(len(a._future_exceptions))
    assert len(a._future_exceptions) == 1
    assert AttributeError in a._future_exceptions

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:14:12.198488
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.exceptions import ServerError
    from sanic.response import text

    my_exception = ServerError('my_exception')
    my_exception2 = ServerError('my_exception2')
    my_handler = None
    my_app = None

    # initialize
    my_bp = Blueprint('testing_bp', url_prefix='/testing_bp', host=None)
    my_handler = my_bp.exception(my_exception)(my_handler)

    # check if it is added to future exceptions
    assert len(my_bp._future_exceptions) == 1
    my_future_exception = my_bp._future_exceptions.pop()

# Generated at 2022-06-21 23:14:20.399118
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    exception_mixin = Blueprint.__bases__[0]

    class Handler:
        def __call__(self):
            assert True

    @exception_mixin.exception(Exception, apply=False)
    def handler():
        pass

    assert len(exception_mixin._future_exceptions) == 1
    assert type(exception_mixin._future_exceptions.pop()).__name__ == "FutureException"


# Generated at 2022-06-21 23:14:23.279002
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class MockException(ExceptionMixin):
        pass

    fm = MockException()
    fm.exception(AssertionError)

# Generated at 2022-06-21 23:14:29.909281
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mock:
        _future_exceptions: Set[FutureException] = set()
        _apply_exception_handler = MagicMock()

    mock = Mock()
    mixin = ExceptionMixin()
    mixin.__init__()

    @mixin.exception(AssertionError, apply=True)
    def handler():
        pass

    assert handler in mock._future_exceptions
    assert mock._apply_exception_handler.called

# Generated at 2022-06-21 23:14:37.064359
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.exceptions import ServerError
    from sanic.blueprints import Blueprint

    bp = Blueprint('name')
    assert bp._future_exceptions == set()

    @bp.exception(ServerError, apply=False)
    def server_error(request, exception):
        return text('Server Error')

    assert bp._future_exceptions

# Generated at 2022-06-21 23:15:08.322993
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin

# Generated at 2022-06-21 23:15:16.571101
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureException
    bp = Blueprint()

    assert bp._future_exceptions == set()

    @bp.exception(ServerError)
    def _handler(request, exception):
        return request, exception

    assert bp._future_exceptions == {FutureException(_handler, (ServerError,))}


# Generated at 2022-06-21 23:15:19.606780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @app.exception(Exception)
    def handler(request, exception):
        return response.text('OK')
    assert handler in app._future_exceptions

# Generated at 2022-06-21 23:15:22.879435
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()
    def handle(request, exception):
        pass
    assert handle(a.exception(ZeroDivisionError)) == handle

# Generated at 2022-06-21 23:15:25.905145
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint as SanicBlueprint
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    SanicBlueprint.__bases__ = (ExceptionMixin,)
    blueprint = SanicBlueprint('test')
    blueprint.before_request(None)

# Generated at 2022-06-21 23:15:27.896702
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:15:35.765084
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class XXX(ExceptionMixin):
        pass

    x = XXX()
    # Note:
    #   We do not actually decorate the Foo method in the unit test
    #   It is too complicated to test it
    @x.exception(ZeroDivisionError)
    def Foo():
        pass

    assert len(x._future_exceptions) == 1

    exc = x._future_exceptions.pop()
    assert exc.exc_types == (ZeroDivisionError,)
    assert exc.handler == Foo

# Generated at 2022-06-21 23:15:45.646145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SubClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(SubClass, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    sub_class = SubClass()

    @sub_class.exception(Exception)
    def handler():
        pass

    future_exceptions = sub_class._future_exceptions
    assert len(future_exceptions) == 1
    fe = next(iter(future_exceptions))
    assert fe.handler == handler
    assert fe.exceptions == (Exception,)

# Generated at 2022-06-21 23:15:55.470789
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    
    app = Sanic()
    bp = Blueprint('bp', url_prefix='/bb')

    @bp.exception(Exception)
    def handler():
        pass

    assert handler.__name__ == 'handler'
    assert handler.__module__ == __name__
    assert bp._future_exceptions == {FutureException(handler, (Exception,))}

    app.blueprint(bp)

    assert app.error_handler.handlers == {(Exception,): handler}

# Generated at 2022-06-21 23:15:58.652141
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:17:18.709930
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint
    from sanic.models.futures import FutureException
    from sanic.exceptions import InternalServerError
    app = Sanic(__name__)
    bp = Blueprint("test_bp")
    bp2 = Blueprint("test_bp2")

    @bp.exception(InternalServerError)
    def default_exception_handler(request, exception):
        return text("Internal Server Error")

    @bp.exception(InternalServerError)
    def default_exception_handler2(request, exception):
        return text("Internal Server Error")

    @bp.exception()
    def default_exception_handler3(request, exception):
        return text("Internal Server Error")

    app.blueprint(bp)
    app.blueprint(bp2)

# Generated at 2022-06-21 23:17:21.636487
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Derived(ExceptionMixin): pass
    derived = Derived()
    assert len(derived._future_exceptions) == 0

# Generated at 2022-06-21 23:17:26.863509
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    dc = DummyClass()

    # Testing if exception is added to list of future_exceptions
    dc.exception(*[Exception])(lambda response: response)
    assert 1 == len(dc._future_exceptions)


# Generated at 2022-06-21 23:17:28.517975
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-21 23:17:32.432040
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin().exception(NameError)
    assert result == decorator
    assert ExceptionMixin()._future_exceptions == {FutureException(decorator, (NameError,))}


# Generated at 2022-06-21 23:17:33.949900
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


# Generated at 2022-06-21 23:17:36.454476
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj=ExceptionMixin()
    assert obj._future_exceptions=={}

# Generated at 2022-06-21 23:17:43.290410
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SanicTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print("Apply exception")

    sanic_test = SanicTest()
    @sanic_test.exception(Exception)
    def func():
        print("something")
    func()

# Generated at 2022-06-21 23:17:54.471616
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic import Sanic
    app = Sanic("TestExceptionMixin")
    @app.route("/")
    def testroute(request):
        pass
    @app.exception(Exception)
    def testexcepthandler(request, exception):
        pass
    # check that the decorate method exist
    assert hasattr(app, "exception")
    # check that the decorated method exists
    assert "testexcepthandler" in dir(app)
    # check that the set of future exceptions is initialized
    assert len(app._future_exceptions) == 1


# Generated at 2022-06-21 23:18:05.143903
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    class TestException(Exception):
        pass

    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == (TypeError, IndexError)
            assert handler.handler == handler_exception
            assert len(self._future_exceptions) == 1

    class TestBlueprint(MyExceptionMixin, Blueprint):
        pass

    test_bp = TestBlueprint("TestBlueprint", url_prefix='/test',
                            strict_slashes=True)

    @test_bp.exception(TypeError, IndexError)
    def handler_exception(request, exception):
        assert exception is exception_throw

    exception_throw = TestException("Testing Exception")
    exception_catch = TypeError("TypeError exception")