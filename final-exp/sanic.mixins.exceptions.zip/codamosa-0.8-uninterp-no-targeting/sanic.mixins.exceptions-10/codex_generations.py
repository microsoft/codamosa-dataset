

# Generated at 2022-06-21 23:09:12.366756
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:09:20.457914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import abort
    from sanic.exceptions import NotFound as NotFoundException
    from sanic.exceptions import ServerError
    from sanic.exceptions import SanicException
    from sanic.exceptions import URLBuildError
    from sanic.exceptions import InvalidUsage as InvalidUsageException
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import StreamConsumedError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import InvalidHeader
    from sanic.exceptions import InvalidRangeType
    from sanic.exceptions import FileConfigMisMatch
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import WriteOnlyMode
    from sanic.exceptions import InvalidContentType


# Generated at 2022-06-21 23:09:29.190630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            exceptionMixinTest._future_exceptions.add(handler)

    exceptionMixinTest = ExceptionMixinTest()

    test_exception = ValueError

    @exceptionMixinTest.exception(test_exception)
    def handler():
        raise test_exception

    assert len(exceptionMixinTest._future_exceptions) == 0
    handler()
    assert len(exceptionMixinTest._future_exceptions) == 1

# Generated at 2022-06-21 23:09:40.642907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinTest(ExceptionMixin):

        def _apply_exception_handler(self, future_exception: FutureException):
            '''
            This method will apply future exception (i.e. exception which will be raised in future)
            on sanic handler and blueprints.
            :param future_exception:Exception
            :return:
            '''
            pass

    # Create object of class 'ExceptionMixinTest'
    ExceptionMixinTestObj = ExceptionMixinTest()

    # Call exception method of class ExceptionMixinTest
    # Note: Just returned decorated handler
    handler = ExceptionMixinTestObj.exception(Exception)

    # Note: Now we will call handler method which returned by exception method
    # If pass only 1 parameter i.e. 'string' then below method will treat it as exception
    # cause it will handle the exception

# Generated at 2022-06-21 23:09:50.624938
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinImp(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions: Set[FutureException] = set()
            self.aplied_exception_handler: FutureException = None

        def _apply_exception_handler(self, handler: FutureException):
            self.aplied_exception_handler = handler

    mixin = ExceptionMixinImp()

    # Test the decorator.
    @mixin.exception()
    def exception_handler():
        pass

    assert len(mixin._future_exceptions) == 1
    assert mixin.aplied_exception_handler == mixin._future_exceptions.pop()

# Generated at 2022-06-21 23:09:51.484928
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:09:55.440327
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin, ExceptionMixin)
    assert hasattr(mixin, "_future_exceptions")


# Generated at 2022-06-21 23:09:58.633624
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    exception = ExceptionMixin()

    assert len(exception._future_exceptions) == 0
    assert isinstance(exception, Blueprint)


# Generated at 2022-06-21 23:10:03.844626
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Cls(ExceptionMixin):
        pass

    cls = Cls()
    assert isinstance(cls, ExceptionMixin)
    assert cls._future_exceptions == set()

# Generated at 2022-06-21 23:10:10.767682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinImpl(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = ExceptionMixinImpl()
    @exception_mixin.exception(IndexError)
    def index_error(request, exception):
        pass
    @exception_mixin.exception(KeyError)
    def key_error(request, exception):
        pass

    assert len(exception_mixin._future_exceptions) == 2

# Generated at 2022-06-21 23:10:17.157230
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExampleException(ExceptionMixin):
        pass

    @ExampleException.exception()
    def exception_handler_1():
        pass

    @ExampleException.exception()
    def exception_handler_2():
        pass

    assert example_exception._future_exceptions == {exception_handler_1, exception_handler_2}

# Generated at 2022-06-21 23:10:20.138368
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = FakeBlueprint()
    blueprint.exception(Exception)
    blueprint.exception([Exception], apply=False)
    assert len(blueprint._future_exceptions) == len([Exception, Exception])

# Generated at 2022-06-21 23:10:21.122025
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    assert hasattr(ExceptionMixin, 'exception')
    assert callable(ExceptionMixin.exception)

# Generated at 2022-06-21 23:10:21.854803
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exc import T

# Generated at 2022-06-21 23:10:26.295594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyStaticSitesBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)
    ssb = DummyStaticSitesBlueprint()
    function_to_return = ssb.exception(ValueError)(lambda: "got here")
    assert function_to_return() == "got here"

# Generated at 2022-06-21 23:10:27.400045
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert(e._future_exceptions == set())

# Generated at 2022-06-21 23:10:31.731962
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == handler_func
            assert handler.exceptions == (Exception,)

    def handler_func(): pass
    TestClass().exception(Exception)(handler_func)



# Generated at 2022-06-21 23:10:33.526313
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin


# Generated at 2022-06-21 23:10:40.278952
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Application(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    app=Application()
    assert len(app._future_exceptions)==0
    app._apply_exception_handler(1)
    assert len(app._future_exceptions)==0


# Generated at 2022-06-21 23:10:46.055752
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    app = Sanic(__name__)
    def first():
        pass
    app.exception(TypeError, apply=True)(first)
    try:
        raise TypeError
    except TypeError:
        pass



# Generated at 2022-06-21 23:10:55.569422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinClass(ExceptionMixin):   # noqa
        def __init__(self):
            pass
    ref = ExceptionMixinClass()
    result = ref.exception(1, 2, 3)(4)
    assert result == 4

# Generated at 2022-06-21 23:10:59.005477
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert isinstance(ex, ExceptionMixin)
    assert isinstance(ex._future_exceptions, Set)


# Generated at 2022-06-21 23:11:03.783403
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    test_class = TestClass()

    assert test_class._future_exceptions == set()
    assert type(test_class._future_exceptions) == set


# Generated at 2022-06-21 23:11:07.528059
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    exceptions = ValueError
    assert bp._future_exceptions == set()
    assert bp.exception(exceptions)

# Generated at 2022-06-21 23:11:10.893733
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    t = TestExceptionMixin()
    assert t._future_exceptions == set()


# Generated at 2022-06-21 23:11:20.318944
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test1:
        def __init__(self):
            self._future_exceptions: Set[FutureException] = {}
            self.apply = False
            self.exceptions = {}

        def _apply_exception_handler(self, handler):
            return True

    test = Test1()
    exception_handler = test.exception([Exception], apply=test.apply)
    exception_handler(test)
    assert(test.apply)
    assert(test.exceptions.__len__() == 1)



# Generated at 2022-06-21 23:11:21.517043
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()

    assert len(mixin._future_exceptions) == 0

# Generated at 2022-06-21 23:11:23.641592
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .exception import test_Exception_exception
    test_Exception_exception(ExceptionMixin, '_apply_exception_handler')

# Generated at 2022-06-21 23:11:27.055831
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestException(ExceptionMixin):
        pass
    test_exc = TestException()
    assert isinstance(test_exc, TestException)


# Generated at 2022-06-21 23:11:34.421231
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptionMixin = ExceptionMixin()

    def exceptionHandler(handler):
        return handler

    def exceptionHandler2(handler):
        return handler

    exceptions = [Exception]
    exceptions2 = [ValueError]

    exceptionMixin.exception(exceptions[0], apply=True)(exceptionHandler)
    exceptionMixin.exception(exceptions2[0], apply=False)(exceptionHandler2)

    assert exceptionHandler in [e.handler for e in exceptionMixin._future_exceptions]
    assert exceptionHandler2 in [e.handler for e in exceptionMixin._future_exceptions]

    assert Exception in [e.exceptions for e in exceptionMixin._future_exceptions]
    assert ValueError in [e.exceptions for e in exceptionMixin._future_exceptions]

# Generated at 2022-06-21 23:11:50.367305
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import ExceptionMixin
    from sanic.utils import _unhandled_exception
    from sanic.models.exceptions import FutureException
    import functools

    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            print('apply exception')

    a = A()


    def exception_handler(request, *args, **kwargs):
        print('global exception')

    a.exception(Exception, apply=True)(exception_handler)

# Generated at 2022-06-21 23:11:58.349747
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler(None)
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler(None)
    with pytest.raises(TypeError):
        ExceptionMixin()
    instance = ExceptionMixin()
    assert isinstance(instance, ExceptionMixin)
    assert isinstance(instance, set)

# Generated at 2022-06-21 23:12:09.734847
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    Bp = ExceptionMixin
    bp = Bp()
    assert bp._future_exceptions == set()

    @bp.exception(Exception, apply=False)
    def exception_handler():
        pass

    assert bp._future_exceptions == {FutureException(exception_handler, (Exception,))}
    assert bp._future_exceptions.pop().handler() is None

    assert bp._future_exceptions == set()

    @bp.exception([Exception, Exception])
    def exception_handler():
        pass

    assert bp._future_exceptions == {FutureException(exception_handler, (Exception, Exception))}
    assert bp._future_exceptions.pop().handler() is None

    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:12:11.739686
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    bp = Blueprint('test')
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:12:19.373461
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blah(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._apply_exception_handler = self._noop
        def _noop(self, *args, **kwargs):
            return
    b = Blah()
    def handler(*args, **kwargs):
        return
    b.exception(Exception)(handler)
    assert b._future_exceptions is not None, "b._future_exceptions is None"
    assert len(b._future_exceptions) == 1, "b._future_exceptions has wrong length"
    assert b._future_exceptions.pop().handler == handler, "handler not saved as expected"

if __name__ == "__main__":
    test_ExceptionMixin_exception

# Generated at 2022-06-21 23:12:21.845771
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Mixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    assert len(Mixin()._future_exceptions) == 0

# Generated at 2022-06-21 23:12:23.482989
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    app = Sanic("")
    assert app._future_exceptions == set()

# Generated at 2022-06-21 23:12:30.493950
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BExceptionMixin:
        def __init__(self):
            self.x = 0

    class AExceptionMixin(ExceptionMixin, BExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self.x = 1
            return

        # Unit test for method del_future_exception of class ExceptionMixin
        def test_del_future_exception(self):
            assert self.x == 1

    AExceptionMixin().exception(ValueError)(lambda x, y: 1)

# Generated at 2022-06-21 23:12:39.878554
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound
    from sanic.handlers import ErrorHandler

    app = Sanic()
    @app.exception(NotFound)
    def exc_handler(request, exception):
        return request.form

    assert app.exception_handler == ErrorHandler().default
    assert app.exception_handler(None, None)

    app._apply_exception_handler(FutureException(exc_handler, (NotFound,)))

    assert app.exception_handler != ErrorHandler().default
    assert app.exception_handler(None, None)

# Generated at 2022-06-21 23:12:45.083821
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Step 1: Create object of ExceptionMixin
    blueprint = ExceptionMixin()
    # Step 2: Create a decorator function with function exception
    @blueprint.exception(Exception)
    def handler(request, exception):
        pass
    assert len(blueprint._future_exceptions) == 1



# Generated at 2022-06-21 23:13:01.452455
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #TODO: Need to find a way to test method
    return True

# Generated at 2022-06-21 23:13:05.861379
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    app = Sanic(__name__)
    @app.exception(ValueError)
    def test(request, exception):
        pass
    assert(app.error_handler.keys() == {ValueError})
    assert(app.error_handler[ValueError] == test)
    app.blueprint(ExceptionMixin(), url_prefix='/api')
    assert(app.error_handler.keys() == {ValueError})
    assert(app.error_handler[ValueError] == test)

# Generated at 2022-06-21 23:13:08.868920
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    assert TestExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:13:20.915480
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.exceptions import SanicException
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import FileNotFound

    app = Sanic(__name__)
    blueprint = Blueprint('test_blueprint')

    # test whether the method exception in class ExceptionMixin works correctly
    @blueprint.exception(ServerError, RequestTimeout, InvalidUsage, NotFound, FileNotFound)
    def test_exception(request, exception):
        raise SanicException('Test Exception')


# Generated at 2022-06-21 23:13:31.564469
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException


    class ExTestException(SanicException):
        status_code = 400

    bp = Blueprint('bp')
    app = Sanic(__name__)

    @bp.exception(ExTestException)
    def handler(request, exception):
        return json({"error": exception.args})

    assert handler in (x.handler for x in bp._future_exceptions)

    @bp.route('/')
    def handler(request):
        raise ExTestException('Test error')

    app.blueprint(bp)
    request, response = app.test_client.get('/')
    assert response.status == 400

# Generated at 2022-06-21 23:13:34.714588
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BP(ExceptionMixin):
        pass
    bp = BP()
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:13:44.978819
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import types
    from sanic.blueprint import Blueprint
    from sanic.models.futures import FutureException

    class ExceptionMixin_test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixin_test, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # test the _future_exceptions was created with empty Set
    test_exceptionMixin = ExceptionMixin_test()
    assert test_exceptionMixin._future_exceptions is not None
    assert len(test_exceptionMixin._future_exceptions) == 0
    assert isinstance(test_exceptionMixin._future_exceptions, set)



# Generated at 2022-06-21 23:13:47.368878
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test(ExceptionMixin):
        pass
    x = test()
    #x._future_exceptions.add(1)
    assert(x._future_exceptions == set())
    # ExceptionMixin must initialize _future_exceptions with a set
    



# Generated at 2022-06-21 23:13:50.447513
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    class ExceptionHandler:
        pass
    test_instance = TestExceptionMixin()
    test_instance._apply_exception_handler(ExceptionHandler())
    test_instance.exception([Exception])(ExceptionHandler())

# Generated at 2022-06-21 23:13:54.774388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass

    a = A()
    assert a._future_exceptions == set()
    assert len(a._future_exceptions) == 0

# Generated at 2022-06-21 23:14:33.409819
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from types import MethodType
    from unittest.mock import patch

    from sanic.models.exception_handler import FutureException
    from sanic.models.exception_handler import ExceptionMixin

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self) -> None:
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            if handler in self._future_exceptions:
                self._future_exceptions.remove(handler)

    test_ExceptionMixin = TestExceptionMixin()
    test_execption_handler = lambda *_, **__: None

    test_ExceptionMixin.exception(
        ValueError,
        TypeError,
        apply=True
    )(test_execption_handler)

    excepted_set

# Generated at 2022-06-21 23:14:43.091600
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Class(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class ClassOfException:
        pass

    class ClassOfException2:
        pass

    list_of_exceptions = [ClassOfException, ClassOfException2]
    obj = Class()
    assert len(obj._future_exceptions) == 0
    exception_handler = obj.exception(list_of_exceptions)

    def test_function():
        # this should not be for unit test, just for testing
        return "hello world"

    assert obj.exception(ClassOfException)(test_function) == test_function
   

# Generated at 2022-06-21 23:14:43.853704
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 1 == 1

# Generated at 2022-06-21 23:14:45.176264
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-21 23:14:51.553968
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints.blueprint import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    def exception_handler(request, exception):
        return text('I caught an exception: {}'.format(exception), 500)

    blueprint = Blueprint('test', url_prefix='blueprints')

    blueprint.exception(ServerError)(exception_handler)

    app = Sanic()
    blueprint.register(app, blueprint)

    assert blueprint._exception_handlers[ServerError] == exception_handler

    # Clean
    blueprint._exception_handlers.clear()

# Generated at 2022-06-21 23:14:57.485147
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint("test")
    assert bp._future_exceptions == set()
    @bp.exception(Exception, apply=True)
    def handler(request, exception):
        return exception
    assert bp._future_exceptions != set()



# Generated at 2022-06-21 23:15:05.865802
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.base import SanicModel
    from sanic.models.futures import FutureException

    model = SanicModel()
    model.exception(ValueError, apply=False)
    model.exception((ValueError, TypeError), apply=False)

    assert model._future_exceptions == {
        FutureException(None, (ValueError,)),
        FutureException(None, (ValueError, TypeError)),
    }

# Generated at 2022-06-21 23:15:09.537772
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint

    bp = Blueprint("name", url_prefix="test")
    @bp.exception(InvalidUsage)
    def error_handler(request, exception):
        pass

    exception_handler = bp._future_exceptions.pop()
    assert exception_handler.handler == error_handler
    assert exception_handler.exceptions == (InvalidUsage,)

# Generated at 2022-06-21 23:15:20.213601
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.models.middlewares import Middleware
    from sanic.models import Route
    from unittest.mock import MagicMock, patch
    from sanic.exceptions import NotFound
    from sanic import Sanic

    blueprint = Blueprint('test_bp', url_prefix='test')
    blueprint.add_route(lambda x: x, '/test_one', methods=['GET'])
    blueprint.add_route(lambda x: x, '/test_two', methods=['GET'])

    def exception_handler(*args, **kwargs):
        pass

    # The handler will be set to the blueprint['error_handler'].
    # If a new exception is raised, the handler will be applied.
    blueprint.exception(NotFound, apply=True)(exception_handler)
    assert blueprint

# Generated at 2022-06-21 23:15:23.045361
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)
    blueprint.exception(AssertionError)(lambda req, res, ex: None)
    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions[0], FutureException)

# Generated at 2022-06-21 23:16:38.596322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @BlueprintTest().exception(AssertionError)
    def test():
        raise AssertionError

    test()
    assert True

# Generated at 2022-06-21 23:16:45.780232
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException
    from typing import Callable, Set

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._exception_handler: Callable = None

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handler = handler

    app = Sanic()
    TestExceptionMixin(app)
    TestExceptionMixin(app).exception(SanicException)
    assert isinstance(TestExceptionMixin(app)._exception_handler, FutureException)
    assert isinstance(TestExceptionMixin(app)._exception_handler._handler(), SanicException)

# Generated at 2022-06-21 23:16:51.241788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinStub(ExceptionMixin):
        def __init__(self, *args):
            self._exception_handlers = []

        def _apply_exception_handler(self, handler):
            self._exception_handlers.append(handler)

    exception_mixin_stub = ExceptionMixinStub()
    exception_mixin_stub.exception(Exception)(lambda request, exception: None)
    assert len(exception_mixin_stub._future_exceptions) == 1

# Generated at 2022-06-21 23:16:57.808350
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    class CustomBlueprint(Blueprint, ExceptionMixin):
        pass

    app = Sanic(__name__)
    blueprint = CustomBlueprint(__name__)

    @blueprint.exception(ValueError)
    def handler_exception_ValueError(request, exception):
        return text('Value Error exception!')

    app.blueprint(blueprint)
    request, response = app.test_client.get('/')
    assert response.text == 'Value Error exception!'

# Generated at 2022-06-21 23:17:06.382570
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler._callback == 'handler'
            assert handler._exceptions == ('Exception',)
            assert handler._kwargs == {'kwarg1': 'value1'}

    class ExceptionMixin2(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler._callback == 'handler'
            assert handler._exceptions == ['Exception']
            assert handler._kwargs == {}


# Generated at 2022-06-21 23:17:11.548105
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
    testExceptionMixin = TestExceptionMixin()
    assert testExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:17:19.181428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        return None

    assert isinstance(test_exception_mixin._future_exceptions, set)


# Generated at 2022-06-21 23:17:21.044429
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyClass(ExceptionMixin):
        pass
    obj = MyClass()

# Generated at 2022-06-21 23:17:24.366091
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExampleExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
    
    exampleExceptionMixin = ExampleExceptionMixin()
    field = exampleExceptionMixin._future_exceptions
    assert isinstance(field, set)

# Generated at 2022-06-21 23:17:28.775594
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExtensionMixin(None)
    assert bp.extensions
    assert bp.extensions == {"static", "reverse_url"}
