

# Generated at 2022-06-21 23:09:24.469113
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    myTestExceptionMixin = ExceptionMixin()
    assert myTestExceptionMixin._future_exceptions == set()
    return


# Generated at 2022-06-21 23:09:31.970749
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    test_bp = Blueprint('test_bp')

    @test_bp.exception([ZeroDivisionError, TypeError])
    async def custom_error_handler(request, exception):
        return text('Exception occurred: {}'.format(exception), 500)

    @test_bp.exception
    async def other_handler(request, exception):
        return text('Other handler', 500)

    @test_bp.route('/divide/<one:int>/<two:int>')
    async def divide(request, one, two):
        return text(str(one / two))

    test_bp.exception(apply=False)(lambda: print('Should not be applied'))

    assert len(test_bp._future_exceptions) == 3
   

# Generated at 2022-06-21 23:09:35.842945
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert isinstance(a._future_exceptions, set)
    assert len(a._future_exceptions) == 0


# Generated at 2022-06-21 23:09:38.176865
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert isinstance(m, object)
    assert isinstance(m._future_exceptions, set)


# Generated at 2022-06-21 23:09:45.842145
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    '''
    Test the constructor of this class
    '''
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

    exception_mixin = TestExceptionMixin()

    assert not exception_mixin._future_exceptions


# Generated at 2022-06-21 23:09:56.196139
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    This function creates an instance of ExceptionMixin class,
    and test the initialization of the class.
    """
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin._future_exceptions, set)
    assert exception_mixin._future_exceptions == set()

# Unit tests for ExceptionMixin's method exception

# Generated at 2022-06-21 23:10:02.287822
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TempClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_temp_class = TempClass()
    assert type(test_temp_class._future_exceptions) is set

test_ExceptionMixin()



# Generated at 2022-06-21 23:10:04.464274
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()

# Generated at 2022-06-21 23:10:11.969004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass

    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixinImpl, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    exception_mixin = ExceptionMixinImpl()
    @exception_mixin.exception(MyException, apply=True)
    def handler(self, exception):
        pass

    assert len(exception_mixin._future_exceptions) == 1
    assert handler not in exception_mixin._future_exceptions

# Generated at 2022-06-21 23:10:13.785443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinClass():
        def __init__(self):
            pass

    assert hasattr(ExceptionMixinClass(), 'exception')

# Generated at 2022-06-21 23:10:21.424913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic()
    class MyException(Exception):
        pass
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_class = TestExceptionMixin(app)

    # Create exception handler
    @test_class.exception(MyException)
    async def test(request, exception):
        pass
    # The decorated method is added to the set of future exception handlers
    assert len(test_class._future_exceptions) == 1


# Generated at 2022-06-21 23:10:25.351324
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorator(handler):
        return handler

    # Check with method exception
    exception_mixin = ExceptionMixin()
    assert exception_mixin.exception()(decorator) == decorator

    # Check with method exception with argument apply
    exception_mixin = ExceptionMixin()
    assert exception_mixin.exception(apply=False)(decorator) == decorator

# Generated at 2022-06-21 23:10:28.294072
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixinClass, self).__init__(*args, **kwargs)
    ExceptionMixinClass()
    return True


# Generated at 2022-06-21 23:10:37.158606
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.server import Sanic
    from sanic.request import Request
    from sanic.response import Stream

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = Sanic()
    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(IndexError, apply = True)
    async def rejected_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    # one function was decorated with @test_exception_mixin.exception
    assert hasattr(rejected_handler, '__exception_handler__')
    assert rejected_handler.__exception_handler__ is True

# Generated at 2022-06-21 23:10:42.476853
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test_bp', url_prefix='test_bp', version=2)

    @blueprint.exception(Exception)
    async def handler1(request, exception):
        pass

    @blueprint.exception(Exception, Exception)
    async def handler2(request, exception1, exception2):
        pass

    assert len(blueprint._future_exceptions) == 2
    assert len(blueprint.exception_handlers) == 2

    future_exception1 = FutureException(handler1, (Exception,))
    future_exception2 = FutureException(handler2, (Exception, Exception))

    assert future_exception1 in blueprint._future_exceptions
    assert future_exception2 in blueprint._future_exceptions
    assert future_exception1

# Generated at 2022-06-21 23:10:49.721874
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_handler():
        print("This is test handler")

    def test_handler_one():
        print("This is test handler 1")

    test_mixin = ExceptionMixin()
    test_mixin.exception(test_handler)
    exc_list = [test_handler_one, test_handler]
    test_mixin.exception(exc_list)

# Generated at 2022-06-21 23:11:01.803732
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    exceptions = (TypeError, RuntimeError)
    bp = Blueprint(__name__)
    @bp.exception(*exceptions)
    def handler(request, exception):
        return 'error'
    
    # Test _future_exceptions
    assert len(bp._future_exceptions) == 1
    exception = FutureException(handler, exceptions)
    assert bp._future_exceptions == {exception}
    # Test types of handler and exceptions
    assert isinstance(handler, type(bp.exception(*exceptions)))
    assert isinstance(exceptions, type(bp.exception(*exceptions).__code__.co_varnames))
    assert isinstance(handler, type(exception.handler))
    assert isinstance(exceptions, type(exception.exceptions))


# Generated at 2022-06-21 23:11:09.564769
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self):
            super().__init__()
        def _apply_exception_handler(self, handler: FutureException):
            pass

    ex = ExceptionMixinImpl()
    ex.exception(Exception)

    assert len(ex._future_exceptions) > 0
    assert isinstance(ex._future_exceptions.pop(), FutureException)

# Generated at 2022-06-21 23:11:16.459220
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.base_models import BaseModel
    model = BaseModel(__name__, __doc__)
    assert model is not None
    test_exception_model = ExceptionMixin(model)
    assert test_exception_model._future_exceptions == set()


# Generated at 2022-06-21 23:11:18.478537
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()
    assert x._future_exceptions == set()

# Generated at 2022-06-21 23:11:24.012471
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SampleExceptionMixin(ExceptionMixin):
        pass

    sampleExceptionMixin = SampleExceptionMixin()
    assert isinstance(sampleExceptionMixin, ExceptionMixin)
    assert isinstance(sampleExceptionMixin._future_exceptions, set)


# Generated at 2022-06-21 23:11:27.518903
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()
    assert hasattr(ExceptionMixin, '_apply_exception_handler')
    assert callable(ExceptionMixin.exception)

# Generated at 2022-06-21 23:11:37.417612
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    def exception_handler():
        pass

    a = A()
    a.exception(Exception)(exception_handler)

    assert len(a._future_exceptions) == 1

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:11:50.266197
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockApp:
        def __init__(self):
            self.extend_callback_list = []

        def exception(self, *exceptions, apply=True):
            def decorator(handler):
                exception = FutureException(handler, exceptions)
                self.extend_callback_list.append(exception)

            return decorator

    app = MockApp()
    em = ExceptionMixin()
    em.exception(IndexError)(lambda:1)
    em.exception(KeyError)
    em.exception(KeyError)[2]
    em.exception(KeyError)[2][1]
    em.exception(KeyError)[2][1][3](apply=False)(lambda:2)

    # Register exception callback with the app
    em.register_events(app)

    assert app.extend_callback_

# Generated at 2022-06-21 23:11:59.887909
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints.blueprint import Blueprint

    bp = Blueprint("exception_mixin")
    assert bp._future_exceptions == set()

    # test __init__ decorator future_exceptions
    @bp.exception()
    def test_decorator():
        pass

    assert len(bp._future_exceptions) == 1

    # test _apply_exception_handler
    # bp._apply_exception_handler(test_decorator)
    # assert len(bp.routes_all["exception"]["GET"]) == 1

    assert isinstance(bp, ExceptionMixin)


# Generated at 2022-06-21 23:12:08.871158
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class C(ExceptionMixin):
        pass
    obj = C()

    assert obj._future_exceptions == set()

    def decorator(handler):
        exceptions = ("a", "b")
        future_exception = FutureException(handler, exceptions)
        obj._future_exceptions.add(future_exception)
        return handler

    handler = lambda: 1
    obj.exception()(handler)

    assert len(obj._future_exceptions) == 1
    assert obj._future_exceptions == set([FutureException(handler, tuple())])

# Generated at 2022-06-21 23:12:10.168230
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj is not None


# Generated at 2022-06-21 23:12:13.140856
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    e = ExceptionMixin()
    exception = e.exception(KeyError)

    def exception_handler(request, exception):
        return "ok"

    r = exception(exception_handler)

    assert callable(r)

# Generated at 2022-06-21 23:12:13.981783
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception()

# Generated at 2022-06-21 23:12:14.515489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:12:26.436695
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import falcon
    import pytest

    class A(ExceptionMixin):
        def  _apply_exception_handler(self, handler: FutureException):
            pass

    a = A()

    # test decorator
    @a.exception(falcon.HTTPUnauthorized)
    def unauthorized_handler(request: Request, exception: falcon.HTTPUnauthorized) -> HTTPResponse:
        return HTTPResponse('test', status=401)

    # test raise exception
    with pytest.raises(falcon.HTTPUnauthorized):
        unauthorized_handler('', 1)


# Generated at 2022-06-21 23:12:27.540113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    instance = ExceptionMixin()
    instance.exception(ValueError, KeyError, apply=True)

# Generated at 2022-06-21 23:12:28.931965
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-21 23:12:29.396664
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:12:38.966047
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Test method exception of class ExceptionMixin"""

    class FakeExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixin, self).__init__(*args, **kwargs)
    
    fake_obj = FakeExceptionMixin()
    @fake_obj.exception(ValueError)
    def fake_handler():
        return 'fake_handler'

    assert len(fake_obj._future_exceptions) == 1
    assert fake_obj._future_exceptions.pop().handler == fake_handler


# Generated at 2022-06-21 23:12:50.679036
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest.mock as mock

    exception_handler1 = mock.MagicMock()
    exception_handler2 = mock.MagicMock()

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.applied_exception_handlers = []

        def _apply_exception_handler(self, handler: FutureException):
            self.applied_exception_handlers.append(handler)

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(IOError)(exception_handler1)
    assert len(test_exception_mixin._future_exceptions) == 1

    applied_exception_handlers = test_

# Generated at 2022-06-21 23:13:01.256623
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint(__name__)

    @bp.exception(IndexError)
    def handler(request, exception):
        assert isinstance(exception, IndexError)

    @bp.raw_route("/")
    async def test(request):
        raise IndexError

    request, response = bp.create_request(uri="/")
    view = bp.get_route(request)
    response = view(request)

    global_exceptions = bp.global_exceptions
    assert len(global_exceptions) == 1

    exceptions = global_exceptions[IndexError]
    assert len(exceptions) == 1

# Generated at 2022-06-21 23:13:03.375687
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testing_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @testing_ExceptionMixin.exception()
    def handler(): pass

    assert len(testing_ExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-21 23:13:05.172415
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

if __name__ == '__main__':
    test_ExceptionMixin()

# Generated at 2022-06-21 23:13:07.812717
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-21 23:13:21.741587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.utils import SanicException, SanicBoom, SanicHTTPException
    from sanic.models.blueprints.blueprint import Blueprint

    exception_mixin = ExceptionMixin()
    decorator = exception_mixin.exception(SanicException)
    assert len(exception_mixin._future_exceptions) == 1
    assert isinstance(exception_mixin._future_exceptions.pop(), FutureException)

    decorator = exception_mixin.exception([SanicHTTPException,SanicBoom])
    assert len(exception_mixin._future_exceptions) == 1
    assert isinstance(exception_mixin._future_exceptions.pop(), FutureException)


# Generated at 2022-06-21 23:13:30.581371
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints.decorators import ExceptionMixin

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def exception_handler(exception_parameter):
        pass

    exception_mixin_test = ExceptionMixinTest()
    assert len(exception_mixin_test._future_exceptions) == 0
    exception_mixin_test.exception(ZeroDivisionError, apply=False)(exception_handler)
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-21 23:13:39.286405
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass

    class MySanic(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler):
            return "apply"

    test = MySanic()
    test.exception(MyException)(None)
    assert isinstance(test._future_exceptions.pop(), FutureException)



# Generated at 2022-06-21 23:13:43.316590
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        pass

    mixin = MockExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-21 23:13:48.331072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    _ExceptionMixin().exception() # TODO: No unit test?

# Generated at 2022-06-21 23:13:53.536938
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BluePrintClass(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass
        
    blueprint = BluePrintClass()

    assert blueprint._future_exceptions == set()



# Generated at 2022-06-21 23:14:00.988545
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint('test', url_prefix='test')

    @bp.route('/test')
    def handler(request):
        return text('OK')

    @bp.exception([NotFound])
    async def handler_2(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == {FutureException(handler_2, (NotFound,))}

# Generated at 2022-06-21 23:14:07.921103
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:14:12.933348
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import RequestTimeout

    bp = Blueprint('bp', url_prefix='/bp', version=1)
    assert bp.exception is ExceptionMixin.exception

    @bp.exception(RequestTimeout)
    def handle_request_timeout_exception(request, exception):
        return text('Custom handler for RequestTimeOutException')

    assert bp.exception_handlers
    assert bp.exception_handlers[0].handler is handle_request_timeout_exception

# Generated at 2022-06-21 23:14:21.249172
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinExample(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def test(self):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            handler.add_to_app(self.test)

    exceptionMixinExample = ExceptionMixinExample()
    @exceptionMixinExample.exception()
    def test(*args, **kwargs):
        pass
    assert len(exceptionMixinExample._future_exceptions) == 1

# Generated at 2022-06-21 23:14:35.462578
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print("Test 1 : Testing constructor of class ExceptionMixin")
    app = Blueprint("test", url_prefix="/test")
    assert isinstance(app, ExceptionMixin)
    assert app._future_exceptions == set()
    print("Passed")

# Generated at 2022-06-21 23:14:42.779537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def f(self,*args,**kwargs):
            pass
    class B:
        def __init__(self,*args,**kwargs):
            self._future_exceptions=set()
            pass
        def _apply_exception_handler(self,handler):
            pass
        def i(self,*args,**kwargs):
            pass
    a=A()
    b=B()
    a.exception=ExceptionMixin.exception
    b.exception=ExceptionMixin.exception
    a.exception()(a.f)
    b.exception()(b.i)

# Generated at 2022-06-21 23:14:44.446609
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A (ExceptionMixin):
        def _apply_exception_handler(self, handler):
            print(handler)
    a = A()
    a.__init__()



# Generated at 2022-06-21 23:14:46.906042
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    tester = ExceptionMixin()
    assert not tester._future_exceptions


# Generated at 2022-06-21 23:14:49.537489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    a = A()
    def handler():
        pass
    a.exception(Exception)(handler)
    assert handler in {fe.handler for fe in a._future_exceptions}

# Generated at 2022-06-21 23:15:00.762844
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.apply_exception_called = False

        def _apply_exception_handler(self, future_exception):
            self.future_exception = future_exception
            self.apply_exception_called = True

    @TestExceptionMixin.exception(TypeError)
    def exception_handler(request, exception):
        pass

    test_exception_mixin = TestExceptionMixin()

    # Test that exception() does not call _apply_exception_handler
    assert not test_exception_mixin.apply_exception_called

    # The handler does not raise an exception.
    exception_handler(None, None)



# Generated at 2022-06-21 23:15:07.906122
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Mock_ExceptionMixin(ExceptionMixin):
        @property
        def _blueprint(self):
            return None

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    def _handler(*args, **kwargs):
        pass

    mixin = Mock_ExceptionMixin()
    mixin.exception(_handler)
    assert len(mixin._future_exceptions) == 1

# Generated at 2022-06-21 23:15:14.943100
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self):
            self.__super().__init__()
            self.test_attrib = 'test'

    mixin = _ExceptionMixin()
    assert mixin.test_attrib == 'test'
    assert isinstance(mixin._future_exceptions, set)


# Generated at 2022-06-21 23:15:22.343824
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    app = Sanic(__name__)
    bp = Blueprint('test', url_prefix='/test')
    em = ExceptionMixinTest()
    em.add_exception(RuntimeError)
    em._future_exceptions = set()
    em.exception(RuntimeError)
    em.exception(RuntimeError, apply=False)
    em.exception(RuntimeError)
    em.exception([RuntimeError])
    em.exception([RuntimeError], apply=False)
    em.exception([RuntimeError])

# Generated at 2022-06-21 23:15:23.669029
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint_object = ExceptionMixin()
    assert blueprint_object._future_exceptions == set()


# Generated at 2022-06-21 23:15:46.448103
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

    bp = Blueprint("Test", url_prefix='/')
    assert bp._future_exceptions == set()


# Generated at 2022-06-21 23:15:57.377238
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Router(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    router = Router()
    route1 = router.exception(Exception)
    assert len(router._future_exceptions) == 1
    assert router._future_exceptions.pop() == FutureException(route1, (Exception,))

    route2 = router.exception(Exception, ValueError)
    assert len(router._future_exceptions) == 1
    assert router._future_exceptions.pop() == FutureException(route2, (Exception, ValueError))

    route3 = router.exception([Exception, ValueError], apply=False)
    assert len(router._future_exceptions) == 1
    assert router._future_exceptions.pop() == FutureException(route3, (Exception, ValueError))

# Generated at 2022-06-21 23:16:00.145528
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert not a._future_exceptions


# Generated at 2022-06-21 23:16:07.750325
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # 1. Normal case
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()
    # 2. Exception case
    with pytest.raises(NotImplementedError):
        mixin._apply_exception_handler(None)

# # Unit test for function exception() of class ExceptionMixin
# def test_ExceptionMixin_exception():
#     # 1. Normal case
#     mixin = ExceptionMixin()
#     # 2. Exception case
#     with pytest.raises(TypeError):
#         mixin.exception("")

# Generated at 2022-06-21 23:16:09.669910
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.module import Module
    module = Module('sanic.module')
    assert module._future_exceptions == set()


# Generated at 2022-06-21 23:16:10.581957
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin is not None

# Generated at 2022-06-21 23:16:13.150222
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler('handler')


# Generated at 2022-06-21 23:16:15.841465
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()

    assert isinstance(em, ExceptionMixin)
    assert type(em._future_exceptions) == set


# Generated at 2022-06-21 23:16:21.709565
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def li():
        return ["TypeError"]

    def test():
        return "test"

    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == test
            assert handler.exceptions == ("TypeError",)
    t = Test()
    t.exception(li())()(test)


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:16:23.587303
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_ExceptionMixin = ExceptionMixin()
    assert isinstance(test_ExceptionMixin, ExceptionMixin)
    assert isinstance(test_ExceptionMixin._future_exceptions, set)
    assert isinstance(test_ExceptionMixin._apply_exception_handler,
                      NotImplementedError)

# Generated at 2022-06-21 23:17:16.179355
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import inspect

    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    # function type
    def test_function(req):
        pass

    test_class = Test()
    test_class.exception(Exception)(test_function)
    assert len(test_class._future_exceptions) == 1
    assert test_class._future_exceptions.pop() == FutureException(test_function, Exception)

    # class type
    class TestClass():
        def test_method(self, req):
            pass

    test_class = TestClass()
    test_class.exception([Exception])(test_class.test_method)
    assert isinstance(test_class, TestClass)
    assert len(test_class._future_exceptions) == 1


# Generated at 2022-06-21 23:17:21.413887
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import json
    from sanic.models.futures import FutureException
    from sanic.blueprints import BlueprintMixin

    app = Blueprint("test_blueprint")

    # Test that exception handler is registered in _future_exceptions
    @app.exception(Exception)
    async def async_test_handler(request: Request, exc):
        return json({"test": "Test successful!"})

    assert len(app._future_exceptions) == 1
    assert isinstance(
        list(app._future_exceptions)[0], FutureException)
    assert list(app._future_exceptions)[0].handler == async_test_handler
    assert len(list(list(app._future_exceptions)[0].exceptions)) == Exception

    # Test

# Generated at 2022-06-21 23:17:25.609289
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from unittest.mock import MagicMock

    app = MagicMock()
    bp = Blueprint('test', url_prefix='test', host='test', strict_slashes=True)
    bp.name = 'test'
    bp.host = 'test'
    bp.url_prefix = 'test'
    bp.strict_slashes = True
    bp.app = app
    bp.exception(Exception)
    future_exception = FutureException(None, (Exception,))
    assert bp._future_exceptions
    assert future_exception in bp._future_exceptions

# Generated at 2022-06-21 23:17:34.941728
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception): pass

    assert len(test_exception_mixin._future_exceptions) == 1
    exceptions = test_exception_mixin._future_exceptions
    for exception in exceptions:
        assert exception.handler == test_handler
        assert exception.exceptions == (Exception,)

    print('test_ExceptionMixin_exception passed!')


# Generated at 2022-06-21 23:17:44.237178
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    assert len(bp._future_exceptions) == 0

    def handler(request, exception):
        return 'hello world'

    bp.exception(IndexError, AssertionError)(handler)
    assert len(bp._future_exceptions) == 1
    exception = next(iter(bp._future_exceptions))
    assert exception._handler is handler
    assert exception._exceptions == (IndexError, AssertionError)
    assert exception._kwargs == {}

# Generated at 2022-06-21 23:17:48.075392
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    assert TestExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:17:50.064929
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    inst = ExceptionMixin()
    assert(inst._future_exceptions == set())

# Generated at 2022-06-21 23:17:51.414311
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(1)

# Generated at 2022-06-21 23:17:54.786138
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    my_blp = SanicBlueprint('my_blp')
    my_blp2 = SanicBlueprint('my_blp2')
    e = ExceptionMixin
    assert isinstance(e,ExceptionMixin)
 

# Generated at 2022-06-21 23:17:58.915164
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_class(ExceptionMixin):
        pass
    test_exception_mixin = test_class()
    assert test_exception_mixin._future_exceptions == set()

