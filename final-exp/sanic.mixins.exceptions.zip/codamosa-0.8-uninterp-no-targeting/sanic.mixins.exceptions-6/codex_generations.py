

# Generated at 2022-06-21 23:09:26.413719
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class _test_method_exception(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    bp = _test_method_exception()
    handler = bp.exception(ValueError)
    assert isinstance(handler, collections.Callable)
    assert len(bp._future_exceptions) == 1
    for future_exception in bp._future_exceptions:
        assert future_exception.handler == handler
        assert future_exception.exceptions == [ValueError]

    handler = bp.exception((ValueError, UnicodeDecodeError))
    assert isinstance(handler, collections.Callable)
    assert len(bp._future_exceptions) == 2

# Generated at 2022-06-21 23:09:35.221467
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.models.future import Future
    from sanic.models.blueprint import Blueprint

    app = Sanic("test_future_exception")
    blueprint = Blueprint("test_future_exception", url_prefix="test")
    future = Future()
    future2 = Future()
    future3 = Future()
    future._apply_exception_handler(future._handler, Exception)
    future3._apply_exception_handler(future._handler, Exception)
    future4 = Future()
    future4._apply_exception_handler(future._handler, Exception)

    # test app
    assert isinstance(app, Sanic)
    assert isinstance(blueprint, Blueprint)
    assert isinstance(future, Future)
    assert isinstance(future2, Future)

# Generated at 2022-06-21 23:09:36.841587
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockSanicBlueprint(ExceptionMixin):
        pass
    blueprint = MockSanicBlueprint()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:09:39.817630
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixinTest, self).__init__()

    # Act
    blueprint =  ExceptionMixinTest()

    # Assert
    assert blueprint is not None


# Generated at 2022-06-21 23:09:48.583388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.blah = 1

        def _apply_exception_handler(self, handler: FutureException):
            self.blah += 1

    em = TestExceptionMixin()
    em.exception(Exception)
    assert em.blah == 2
    assert type(em._future_exceptions) == set
    assert len(em._future_exceptions) == 1
    assert type(list(em._future_exceptions)[0]) == FutureException

# Generated at 2022-06-21 23:09:57.395065
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

    c = MyExceptionMixin()

    @c.exception(Exception)
    def foo(request: str, exception: str):
        return (request, exception)

    assert isinstance(c._future_exceptions, set)

# Generated at 2022-06-21 23:10:11.483720
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import error_handler
    from sanic.exceptions import Exception

    app = Sanic('test_ExceptionMixin_exception')

    @app.exception(Exception)
    def ignore_all_exceptions(request, exception):
        pass

    # Exception Mixin must be able to apply exception handler
    assert app.find(ignore_all_exceptions).handler == ignore_all_exceptions

    # And it must work with arguments
    @app.exception(Exception('error'))
    def ignore_specific_exception(request, exception):
        pass

    # Exception Mixin must be able to apply exception handler
    assert app.find(ignore_specific_exception).handler == ignore_specific_exception  # noqa

    # Exception Mixin must be able to apply exception

# Generated at 2022-06-21 23:10:20.138374
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.response import json
    import pytest
    from itertools import cycle
    from sanic.websocket import WebSocketProtocol
    # 创建一个sanic应用
    sanic_app = Sanic("sanic-test")

    # 处理正常的GET请求
    @sanic_app.route("/")
    async def test(request):
        return json({"test": True})

    # 处理未找到的路由
    @sanic_app.exception(Exception)
    async def error_handler(request, exception):
        return json({"error_msg": "未找到路由！"}, status=404)



# Generated at 2022-06-21 23:10:20.906779
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-21 23:10:30.430762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin

    Test whether method exception of class ExceptionMixin can execute without error
    """

    # Create a class named TestExceptionMixin which inherits from class ExceptionMixin
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, args, kwargs)

    # Create an object of class TestExceptionMixin
    exception_mixin_obj = TestExceptionMixin()

    # Call method exception of class ExceptionMixin
    handler = exception_mixin_obj.exception(Exception)(print)

# Generated at 2022-06-21 23:10:33.289521
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:10:39.007423
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    class TestExceptionMixinException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixinException, self).__init__()
        def _apply_exception_handler(self, handler): # noqa
            return
    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')
    args = tuple()
    kwargs = {'apply':True}
    def handler():
        print("Exception handler")
    
    test_exception_mixin_exception = TestExceptionMixinException(*args,**kwargs)

# Generated at 2022-06-21 23:10:45.906568
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic("test_ExceptionMixin_constructor")
    bp1 = Blueprint('test_ExceptionMixin_constructor', 
    url_prefix='/v1')
    assert bp1._future_exceptions == set()

# Generated at 2022-06-21 23:10:46.696496
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:10:54.791995
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from types import FunctionType
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_app')
    blueprint.exception(ValueError)(lambda request: None)
    blueprint.exception(TrueError, TrueError2)(lambda request: None)
    blueprint.exception(list, dict)(lambda request: None, apply=False)
    blueprint.exception([TrueError, TrueError2])(lambda request: None)
    expected_exceptions = [
        (ValueError,),
        (TrueError, TrueError2,),
        (list, dict,)
    ]
    assert len(blueprint._future_exceptions) == 4
    assert blueprint._future_exceptions[-1].args == (TrueError, TrueError2,)

# Generated at 2022-06-21 23:10:56.171900
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test method exception of a class ExceptionMixin
    # call function exception
    # check the result is expected or not
    pass

# Generated at 2022-06-21 23:10:58.009826
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    interface = ExceptionMixin()
    assert len(interface._future_exceptions) == 0

# Generated at 2022-06-21 23:11:08.897074
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import BluePrint
    exception_mixin = ExceptionMixin()
    blue_print = BluePrint('test')
    blue_print.exception = exception_mixin.exception

    @blue_print.exception(Exception)
    def handle_exception(request, exception):
        return 'ok'

    assert len(exception_mixin._future_exceptions) == 1
    assert type(exception_mixin._future_exceptions) is set
    assert FutureException(handle_exception, (Exception,)) in exception_mixin._future_exceptions
    assert FutureException(handle_exception, (ValueError,)) not in exception_mixin._future_exceptions



# Generated at 2022-06-21 23:11:14.782240
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # No parsing for exceptions
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = TestExceptionMixin()

    # Test case: normal
    # Input:
    #   - exception_mixin: ExceptionMixin
    # Expect:
    #   - No exception raised
    def exception_handler():
        pass
    exception_mixin.exception(exception_handler)

    # Test case: duplicate
    # Input:
    #   - exception_mixin: ExceptionMixin
    # Expect:
    #   - No exception raised
    exception_mixin.exception(exception_handler)

    # Test case: last exception is list of exceptions
    # Input:
    #   - exception_mixin: ExceptionMixin
   

# Generated at 2022-06-21 23:11:16.606691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Test not implemented
    pass

# Generated at 2022-06-21 23:11:19.716755
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex_mixin = ExceptionMixin()
    assert ex_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:11:27.742751
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # use mock instead of real object
    class Blueprint:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    blueprint = Blueprint()
    blueprint.exception(ArgumentError)
    blueprint.exception(IndexError, BadHeaderError)


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-21 23:11:32.005732
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(ExceptionHandler)
    assert len(exception_mixin._future_exceptions) == 1

# Generated at 2022-06-21 23:11:38.062020
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.server import HttpProtocol
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_ExceptionMixin')
    blueprint.exception('error')
    blueprint.exception_handler({'error': None})
    
    protocol = HttpProtocol(blueprint, None)
    
    assert 'error' in protocol.exceptions

# Generated at 2022-06-21 23:11:50.502908
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    exception_mixin=ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

    @exception_mixin.exception(Exception)
    def test1(request, *args, **kwargs):
        return request
    assert test1(request='request') == 'request'
    #test the attributes of exception_mixin
    assert len(exception_mixin._future_exceptions)==1
    assert exception_mixin._future_exceptions=={FutureException(handle=test1,exceptions=(Exception,))}

    #test the passed of exceptions
    @exception_mixin.exception([Exception])
    def test2(request, *args, **kwargs):
        return request
    assert test2(request='request') == 'request'
    assert len

# Generated at 2022-06-21 23:11:58.349803
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-21 23:12:03.015131
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()
    a = A()
    assert isinstance(a, ExceptionMixin)


# Generated at 2022-06-21 23:12:11.610804
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .router_test import RouterTest
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import text

    app = RouterTest()
    app.testing = True

    bp = Blueprint('test', url_prefix='test')

    @bp.exception(ZeroDivisionError)
    def except_handler(request: Request, exception):
        return text('internal error', 500)

    @bp.route('/')
    def handler(request: Request):
        raise ZeroDivisionError

    app.blueprint(bp)

    request, response = app.test_client.get('/')

    assert response.text == 'internal error'
    assert response.status == 500


# Generated at 2022-06-21 23:12:14.514302
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    assert TestExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-21 23:12:15.990122
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(NotImplementedError)

# Generated at 2022-06-21 23:12:26.161195
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    class ExceptionMixinTests(unittest.TestCase):
        def test_ExceptionMixin(self):
            app = Sanic("test_ExceptionMixin")
            blueprint = Blueprint("test_ExceptionMixin")

            self.assertTrue(len(blueprint._future_exceptions) == 0)

    unittest.main()

# Generated at 2022-06-21 23:12:31.901610
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
# TODO: fix this test. It fails on the line
#       self._future_exceptions.add(future_exception)
    from sanic.blueprints import Blueprint

    @Blueprint.exception(Exception)
    def exception_handler(request, exception):
        return text("I caught an exception: " + exception.__class__.__name__)

    blueprint = Blueprint(name="test_ExceptionMixin_exception")

    @blueprint.route("/test")
    async def handler(request):
        raise Exception

    blueprint.exception(Exception)
    blueprint.exception(Exception, apply=True)

    assert len(blueprint._future_exceptions) == 2

# Generated at 2022-06-21 23:12:34.938048
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicExceptionHandler

    class FakeBlueprint(ExceptionMixin):
        pass

    fake = FakeBlueprint()
    fake.exception(Exception, apply=False)(SanicExceptionHandler)
    assert len(fake._future_exceptions) == 1

    for future in fake._future_exceptions:
        assert isinstance(future, FutureException)
        assert isinstance(future.handler, SanicExceptionHandler)
        assert future.exceptions == (Exception,)

# Generated at 2022-06-21 23:12:36.317895
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-21 23:12:48.095858
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic.Blueprint import Blueprint

    class MyView(HTTPMethodView, ExceptionMixin):
        def get(self, request):
            return text('I am get method')

        def post(self, request):
            return text('I am post method')

    app = Sanic(__name__)
    bp = Blueprint('test', url_prefix='test')
    myview = MyView.as_view()
    bp.add_route(myview, '/1')

    # Test for method exception of class ExceptionMixin
    # when there is only argument
    @app.exception(Exception)
    def test1(request, exception):
        return text('Exception')

    # Test for method exception of class ExceptionMix

# Generated at 2022-06-21 23:12:50.159673
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyClass(ExceptionMixin):
        pass
    assert DummyClass()._future_exceptions == set()


# Generated at 2022-06-21 23:12:59.016091
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @sanic.blueprint(name="test_ExceptionMixin_exception")
    class MyBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler

    bp = MyBlueprint()

    # case 1. class exceptioin 1
    @bp.exception(Exception)
    def exception_handler(request, exception):
        assert exception

    # case 2. class exceptioin 2
    @bp.exception([Exception, NameError, IndexError], apply=False)
    def exception_handler_2(request, exception):
        assert exception

    # case 3. class exceptioin 2
    @bp.exception([Exception, NameError, IndexError], apply=False)
    def exception_handler_2(request, exception):
        assert exception

# Generated at 2022-06-21 23:13:02.939294
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    blueprint = Blueprint()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:13:08.057039
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.sanic import Sanic
    from sanic.server import HttpProtocol
    from sanic.app import SanicException
    from sanic.handlers import ErrorHandler

    import asyncio

    # create a mock blueprint
    blueprint1 = Blueprint("test_blueprint1", url_prefix="test1")
    blueprint2 = Blueprint("test_blueprint2", url_prefix="test2")

    # create a mock sanic object
    app = Sanic("test_sanic")

    # add it to the sanic object
    app.blueprint(blueprint1)
    app.blueprint(blueprint2)

    # create a mock HttpProtocol

# Generated at 2022-06-21 23:13:20.076318
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintExceptionMixin(ExceptionMixin):
        def __init__(self) -> None:
            super().__init__()
        
        def _apply_exception_handler(self, handler: FutureException):
            return handler
        
    class MyBlueprint(BlueprintExceptionMixin):
        def __init__(self):
            super().__init__()

    bp = MyBlueprint()

    @bp.exception(Exception)
    def handle_exception(request, exception):
        return response.text('Internal Server Error', 500)
    
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handle_exception
    assert bp._future_exceptions.pop() is None

# Generated at 2022-06-21 23:13:33.921132
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = TestExceptionMixin()
    assert test._future_exceptions == set()

# Generated at 2022-06-21 23:13:44.908653
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    """
    GIVEN the params below:
    """
    name = 'error_handler'
    apply = True
    exception_class1 = FutureException
    exception_class2 = FutureException
    exception_classes = (exception_class1, exception_class2)

    """
    WHEN instance of ExceptionMixin is created and method exception is called,
    """
    class ExceptionMixinTests(ExceptionMixin):
        def _apply_exception_handler(self, handler: ExceptionMixin):
            pass

    exception_mixin_instance = ExceptionMixinTests()
    exception_mixin_instance.exception(exception_classes, apply=apply)(name)

    """
    THEN the _future_exceptions of the ExceptionMixin class should have the
    expected values.
    """
    assert exception_mix

# Generated at 2022-06-21 23:13:46.345258
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em is not None

# Generated at 2022-06-21 23:13:48.330439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Implement test_ExceptionMixin_exception
    pass


# Generated at 2022-06-21 23:13:50.615298
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:14:00.224772
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint(__name__)
    bp_exception_mixin = ExceptionMixin(__name__)

    @bp.exception(ValueError)
    def handle_value_error(request, exception):
        return text("Catching a ValueError")

    bp_exception_mixin.exception(ValueError)(handle_value_error)

    expected_result = {FutureException(handle_value_error, (ValueError,))}
    assert bp._future_exceptions == expected_result

# Generated at 2022-06-21 23:14:08.269476
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            print("Test Passed")
    test_object = ExceptionMixinTestClass()
    test_object.exception(Exception)(lambda : "hello")
    assert(test_object._future_exceptions.pop() is not None)

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-21 23:14:13.990746
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class X:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()

    x = X()
    x.exception(Exception)(print)
    assert len(x._future_exceptions) == 1

# Generated at 2022-06-21 23:14:16.372354
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass (ExceptionMixin):
        pass
    test = TestClass()
    assert test._future_exceptions == set()

# Generated at 2022-06-21 23:14:19.286564
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    M = ExceptionMixin()
    assert isinstance(M, ExceptionMixin)
    assert isinstance(M._future_exceptions, set)

# Generated at 2022-06-21 23:14:41.448707
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == 'test'
            assert handler.exceptions == 1

    test = TestMixin()
    test.exception(1, apply=False)('test')


# Generated at 2022-06-21 23:14:44.514929
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class foo_ExceptionMixin(ExceptionMixin):
        pass

    assert ExceptionMixin.__init__
    assert foo_ExceptionMixin.__init__

# Generated at 2022-06-21 23:14:46.406635
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()

    assert em._future_exceptions == set()

# Generated at 2022-06-21 23:14:49.820849
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    TestMixin = ExceptionMixin(TestExceptionMixin)

    TestObject = TestMixin()

    assert True

# Generated at 2022-06-21 23:14:53.459514
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Test normal flow
    exc = ExceptionMixin()
    assert isinstance(exc, ExceptionMixin)
    assert exc._future_exceptions == set()

# Generated at 2022-06-21 23:15:00.436001
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    # test creating an object of class ExceptionMixin
    obj = ExceptionMixin()
    assert obj is not None
    assert isinstance(obj, ExceptionMixin)
    assert obj._future_exceptions == set()

    import exceptions
    @obj.exception(exceptions.NotImplementedError)
    def on_exception(request, exception):
        return 'internal error'

    assert obj._future_exceptions != set()
    for future_exception in obj._future_exceptions:
        assert future_exception(request=None, exception=None) == 'internal error'

# Generated at 2022-06-21 23:15:01.821825
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(0, 0) == None

# Generated at 2022-06-21 23:15:08.821984
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    global future_exception_test
    future_exception_test = None

    blueprint = Blueprint(__name__)

    @blueprint.exception(NotFound, apply=True)
    def global_handler(request, exception):
        global future_exception_test
        future_exception_test = exception

    assert isinstance(blueprint, ExceptionMixin)
    assert future_exception_test is None



# Generated at 2022-06-21 23:15:12.529263
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print("Unit test for ExceptionMixin constructor")
    x = ExceptionMixin()

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-21 23:15:17.917839
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return

    class BlueprintException(ExceptionMixin):
        pass

    bp_exception = BlueprintException()
    assert isinstance(bp_exception, BlueprintException)
    assert isinstance(bp_exception, ExceptionMixin)



# Generated at 2022-06-21 23:16:06.464119
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.exception_handler_called = False

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler_called = True

    tmp = TestExceptionMixin()
    assert tmp._future_exceptions == set()
    assert tmp.exception_handler_called == False

    @tmp.exception(Exception)
    def exception_handler(request, exception):
        print("Hello World")

    assert tmp._future_exceptions != set()
    assert tmp.exception_handler_called == True

# Generated at 2022-06-21 23:16:16.983195
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.endpoint import _Endpoint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.models.rule import Rule

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_ExceptionMixin')
    app.blueprint(bp)
    endpoint = _Endpoint('/test')
    endpoint_name = 'test'
    rule = Rule('/test', endpoint_name)
    endpoint.add_rule(rule)
    bp.endpoints.append(endpoint)

    def exception_handler(request: Request,
                          exception: ServerError) -> HTTPResponse:
        return HTT

# Generated at 2022-06-21 23:16:24.448162
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            self._future_exceptions.add(handler)

    test_exception_mixin = TestExceptionMixin()
    def test_function(request, *args, **kwargs):
        pass

    @test_exception_mixin.exception(ValueError)
    def test_exception_function(request, exception):
        '''
        Exception handler for all errors occurred in the whole blueprint
        '''

# Generated at 2022-06-21 23:16:26.536715
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-21 23:16:34.836678
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # GIVEN
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            pass

    fixture = TestExceptionMixin()

    # WHEN
    @fixture.exception([Exception])
    def handler():
        pass
    result = fixture

    # THEN
    assert isinstance(result, ExceptionMixin)
    assert len(fixture._future_exceptions) == 1


# Generated at 2022-06-21 23:16:38.058458
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler):
            return

    # test initialization
    t = TestExceptionMixin()
    assert t._future_exceptions == set()



# Generated at 2022-06-21 23:16:39.768310
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("Test", "/test")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-21 23:16:43.127508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    test_obj = ExceptionMixin()
    exceptions = "Exception"
    apply = True
    # act
    result = test_obj.exception(exceptions, apply)
    # assert
    expected = 1
    actual = len(test_obj._future_exceptions)
    assert actual == expected

# Generated at 2022-06-21 23:16:45.182068
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_exception_blueprint', url_prefix='/')

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        pass

# Generated at 2022-06-21 23:16:50.226327
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    from sanic.response import json

    blueprint = Blueprint('test')

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        return json({"error": str(exception)}, status=500)

    # test constructor
    assert blueprint._future_exceptions == {FutureException(exception_handler, (Exception, ))}

# Generated at 2022-06-21 23:18:17.387151
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.handler import Handler
    from sanic.models.rule import Rule
    from sanic.models.stage import Stage
    from sanic.models.stage_manager import StageManager
    from sanic.models.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse

    from sanic.exceptions import SanicException

    from sanic.models.futures import FutureHandler

    # initialize
    bp = Blueprint('bp')
    rule = Rule()
    stage = Stage()
    stage_manager = StageManager()
    router = Router()
    request = Request('GET', '/')

    # start test

# Generated at 2022-06-21 23:18:19.736405
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-21 23:18:26.208020
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    blueprint = Blueprint(__name__, url_prefix='/')

    @blueprint.route('/test')
    def test(request):
        raise ServerError("Something went wrong!", status_code=500)

    @blueprint.exception(ServerError)
    def handle_invalid_usage(request, exception):
        return text("You did something wrong!")

    app = Sanic()
    app.blueprint(blueprint)

    request, response = app.test_client.get('/test')
    assert response.status == 500

# Generated at 2022-06-21 23:18:36.353020
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.response import json
    from sanic import Blueprint

    class ExceptionMixin(Blueprint):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """


# Generated at 2022-06-21 23:18:39.077123
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-21 23:18:42.262757
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance, ExceptionMixin)
    assert not isinstance(instance, object)


# Generated at 2022-06-21 23:18:47.033939
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException
    from sanic.sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.models import exceptions_handlers
    from sanic.models.futures import FutureException
    import asyncio

    def request_handler(request: Request) -> HTTPResponse:
        return HTTPResponse(status=200)

    # create a new sanic application
    app = Sanic(__name__)

    # create a new sanic blueprint
    bp = Blueprint("test_bp", url_prefix="/test")

    # create a new sanic request handler

# Generated at 2022-06-21 23:18:56.322749
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    # Initialize Sanic
    app = Sanic('test_ExceptionMixin')
    # Initialize Blueprint
    bp = Blueprint('test_ExceptionMixin')
    # Initialize ExceptionMixin
    test = ExceptionMixin(app, bp)
    # ExceptionMixin should be instance of ExceptionMixin
    assert isinstance(test, ExceptionMixin)
    # ExceptionMixin should be instance of dict
    assert isinstance(test, dict)
    # ExceptionMixin.blueprint should be instance of Blueprint
    assert isinstance(test.blueprint, Blueprint)
    # ExceptionMixin.app should be instance of Sanic
    assert isinstance(test.app, Sanic)


# Generated at 2022-06-21 23:19:02.180437
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest
    class TestExceptionMixin(unittest.TestCase):
        def test_init(self):
            mixin = ExceptionMixin()
            self.assertEqual(mixin._future_exceptions, set())
    unittest.main()


# Generated at 2022-06-21 23:19:05.890808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockedClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.handler = None
            self.exceptions = None

        def _apply_exception_handler(self, handler):
            self.handler = handler

    exceptions = [Exception]
    mc = MockedClass()
    @mc.exception(*exceptions, apply = False)
    def test_handler(request, exception):
        return '123'

    assert test_handler == mc.handler.handler
    assert exceptions == list(mc.handler.exceptions)