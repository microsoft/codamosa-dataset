

# Generated at 2022-06-21 23:09:17.177206
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test_ExceptionMixin", url_prefix="test")
    assert len(bp._future_exceptions) == 0
    assert isinstance(bp._future_exceptions, set)
    

# Generated at 2022-06-21 23:09:26.348388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    blueprint = Blueprint()

    exceptions = (RuntimeError,)
    handler = lambda request: None
    exceptions_not_list = blueprint.exception(*exceptions)(handler)
    assert exceptions_not_list is handler
    assert len(blueprint._future_exceptions) == 1
    assert FutureException(handler, exceptions) in blueprint._future_exceptions

    handler = lambda request: None
    exceptions_list = blueprint.exception([RuntimeError])(handler)
    assert exceptions_list is handler
    assert len(blueprint._future_exceptions) == 2
    assert FutureException(handler, exceptions) in blueprint._future_exceptions

# Generated at 2022-06-21 23:09:35.220565
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import MethodNotAllowed, NotFound

    class NewBlueprint(ExceptionMixin, Blueprint):
        pass

    blueprint = NewBlueprint('test', url_prefix='test')

    @blueprint.exception(MethodNotAllowed)
    def handler(self, request, exception):
        raise NotFound

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler.__name__ == 'handler'

    @blueprint.exception([MethodNotAllowed, NotFound])
    def handler2(self, request, exception):
        raise NotFound

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler.__name__ == 'handler2'


# Generated at 2022-06-21 23:09:38.470797
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        exc = ExceptionMixin()
    except:
        print('TEST CASE ____Constructor____ failed')
    else:
        print('TEST CASE ____Constructor____ passed')


# Generated at 2022-06-21 23:09:44.173941
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Child(ExceptionMixin):
        pass
    c = Child()
    assert isinstance(c._future_exceptions, set) and c._future_exceptions == set()


# Generated at 2022-06-21 23:09:47.764576
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    
    assert TestExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:09:59.251976
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class TestExceptionMixin(ExceptionMixin):

        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    testException = TestExceptionMixin()
    @testException.exception
    def exception_handler():
        pass

    assert len(testException._future_exceptions) == 1
    assert isinstance(list(testException._future_exceptions)[0],
                      FutureException)

# Generated at 2022-06-21 23:10:07.584967
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Base(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    class Child(Base):
        pass

    child = Child()
    child.exception(ValueError)
    assert child._future_exceptions == set()
    child.exception(ValueError, apply=True)
    assert child._future_exceptions != set()

# Generated at 2022-06-21 23:10:09.280491
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin().exception is not None

# Generated at 2022-06-21 23:10:10.115289
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-21 23:10:13.027929
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-21 23:10:15.152525
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception() == ExceptionMixin.exception

# Generated at 2022-06-21 23:10:15.635296
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-21 23:10:18.686572
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('blueprint','')

    def exception_handler(request, exception):
        return ('This is exception handler', 500)

    bp.exception(NameError)(exception_handler)
    # print(bp._future_exceptions)

# Generated at 2022-06-21 23:10:21.556061
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    args = "Hello", "World"
    kwargs = {"apply": True}
    
    if isinstance(args[0], list):
        args = tuple(*args)

    future_exception = FutureException(handler, args)
    ExceptionMixin._future_exceptions.add(future_exception)
    if apply:
        ExceptionMixin._apply_exception_handler(future_exception)
    return handler

# Generated at 2022-06-21 23:10:24.796062
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint1(ExceptionMixin):
        pass

    blueprint = Blueprint1()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:10:27.184413
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint("test_blueprint")                                 # type:  Blueprint
    blueprint.exception(apply=True)(exceptions=Exception)                    # type:  FutureException

# Generated at 2022-06-21 23:10:29.504790
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def handler(request, exception):
        return 'Sanic is awesome'

    actual = handler(None, None)
    excepted = 'Sanic is awesome'
    assert actual == excepted

# Generated at 2022-06-21 23:10:41.020168
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixinTestClass, self).__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            return

    exteptionTest = ExceptionMixinTestClass()
    @exteptionTest.exception(Exception, apply=True)
    def exteptionTest_method(request, exception):
        return

    assert(exteptionTest._future_exceptions != set())
    assert(exteptionTest._future_exceptions
            == set([FutureException(exteptionTest_method, (Exception,))]))

# Generated at 2022-06-21 23:10:43.671949
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    tmp = TestExceptionMixin()


# Generated at 2022-06-21 23:10:54.287140
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    app = Sanic()
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, app, *args, **kwargs):
            self.app = app
            super().__init__(*args, **kwargs)
    mixin = TestExceptionMixin(app)
    @mixin.exception(RuntimeError)
    def handler():
        pass
    assert len(mixin._future_exceptions) == 1

# Generated at 2022-06-21 23:10:59.577833
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def exception(self, *exceptions, apply=True):
            nonlocal apply
            nonlocal exceptions

            if isinstance(exceptions[0], list):
                exceptions = tuple(*exceptions)

            future_exception = FutureException(handler, exceptions)
            self._future_exceptions.add(future_exception)
            if apply:
                self._apply_exception_handler(future_exception)
            return handler

    testExceptionMixin = TestExceptionMixin()
    assert testExceptionMixin.exception([TypeError])


# Generated at 2022-06-21 23:11:00.840490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO
    pass

# Generated at 2022-06-21 23:11:10.857154
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyObj(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            handler.handler('foo')

    my_obj = MyObj()
    assert len(my_obj._future_exceptions) == 0

    errors = []
    @my_obj.exception(ZeroDivisionError)
    def exception_handler(request, exception):
        errors.append(exception)

    exception_handler()

    assert len(errors) == 1
    assert errors[0] == 'foo'

# Generated at 2022-06-21 23:11:18.179001
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BP(ExceptionMixin):
        pass
    bp = BP()
    assert len(bp._future_exceptions) == 0
    @bp.exception(ZeroDivisionError, KeyError, bind=True)
    def handler(self, request, exception):
        print('Exception', exception)

    assert bp._future_exceptions != 0

# Generated at 2022-06-21 23:11:21.267771
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exceptionMixin = ExceptionMixinTest(123, "abc")
    assert exceptionMixin


# Generated at 2022-06-21 23:11:24.637104
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    bp = Blueprint('blueprint1')

    try:
        bp.__init__(bp)
    except NotImplementedError:
        return True
    return False


# Generated at 2022-06-21 23:11:31.003807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self, error, apply):
            self.error = error
            self.apply = apply
            self.exceptions = set()

        def _apply_exception_handler(self, handler):
            self.exceptions.add(handler)

    a = A(None, True)
    @a.exception(Exception)
    def handler(a, b, c):
        return a + b + c

    assert handler(1,2,3) == 6
    assert len(a.exceptions) == 1

# Generated at 2022-06-21 23:11:35.386586
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

    assert A()._future_exceptions == set()


# Generated at 2022-06-21 23:11:40.267047
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    t = TestClass()
    t.exception('test')
    t._future_exceptions.pop().handler('tes')


# Test classes to test of method TestClass._apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-21 23:11:49.196593
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-21 23:11:54.150258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)
    blueprint.exception(list)

    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-21 23:12:02.030966
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Testing for without any exception
    
    # Arrange

    class ExceptionMixin_exception_Test_1:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
    
    
    # Act
    my_exception_mixin = ExceptionMixin_exception_Test_1()
    my_decorator = my_exception_mixin.exception()
    
    
    # Assert
    assert type(my_decorator) == exception_decorator
    
    # Testing for with the exception
    
    # Arrange


# Generated at 2022-06-21 23:12:04.370421
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin=ExceptionMixin()
    assert exception_mixin._future_exceptions==set()


# Generated at 2022-06-21 23:12:04.914487
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-21 23:12:09.910580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class Test(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def abc(self):
            pass

        def _apply_exception_handler(self, handler: Exception):
            pass

    @Test().exception(Exception)
    def handler(request, exception):
        pass

    assert handler == Test._future_exceptions.pop().handler

# Generated at 2022-06-21 23:12:10.822605
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)

# Generated at 2022-06-21 23:12:12.428789
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-21 23:12:13.637057
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()


# Generated at 2022-06-21 23:12:16.658005
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Thing(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    thing = Thing()
    @thing.exception
    def wow(request, Exception):
        pass
    assert len(thing._future_exceptions) == 1

# Generated at 2022-06-21 23:12:36.495428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a blueprint
    bp = Blueprint("name", url_prefix="/prefix")
    # create a request
    request = bp.request("GET", "http://localhsot/prefix")
    # create a response
    response = bp.response("GET", request, bp.wrap_async(lambda: None))
    # create a FutureException
    future_exception = FutureException(response, Exception)
    # set the FutureException for the blueprint
    bp._future_exceptions = set()
    bp._future_exceptions.add(future_exception)
    # assert that the FutureException is set for the blueprint and is valid
    assert bp._future_exceptions[0] == future_exception


# Generated at 2022-06-21 23:12:43.873015
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic import Blueprint
    
    bp = Blueprint('name', 'url_prefix')
    app = bp.app
    assert app._exception_handler == {}
    assert app._future_exceptions == set()

    @bp.exception(ValueError, apply=False)
    def exception_handler(request, exception):
        return 'exception_handler'

    assert app._exception_handler == {}
    assert app._future_exceptions == {FutureException(exception_handler, (ValueError,))}

# Generated at 2022-06-21 23:12:45.328656
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc is not None

# Generated at 2022-06-21 23:12:47.398438
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()

# Generated at 2022-06-21 23:12:49.205889
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    t = TestExceptionMixin()
    assert not t._future_exceptions



# Generated at 2022-06-21 23:12:51.259526
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bluprint = ExceptionMixin()
    assert type(bluprint._future_exceptions) == set
    return True



# Generated at 2022-06-21 23:13:02.536145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test', url_prefix='test')

    class DefaultHandler:
        def __init__(self, request, exception):
            self.request = request
            self.exception = exception

    class MyException(Exception):
        pass

    @blueprint.exception(MyException)
    def handler(request, exception):
        return 'normal handler'

    @blueprint.exception(MyException, status_code=415)
    def handler2(request, exception):
        return 'normal handler2'

    @blueprint.exception(MyException, apply=False)
    def handler3(request, exception):
        return 'normal handler3'

    request = 'request'
    exception = MyException()

    assert blueprint._apply_exception_handler(handler) == DefaultHandler
   

# Generated at 2022-06-21 23:13:12.493266
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp', url_prefix='test')

    # Create future exception
    @bp.exception(Exception)
    def exception_handler(request, exception):
        raise exception

    assert len(bp._future_exceptions) == 1
    future_exception = list(bp._future_exceptions)[0]
    assert future_exception.handler == exception_handler
    assert future_exception.exceptions == (Exception,)
    assert future_exception.kwargs is None

    # Empty future exception
    @bp.exception()
    def empty_handler(request, exception):
        raise exception

    assert len(bp._future_exceptions) == 2
    future_exception = list(bp._future_exceptions)[1]

# Generated at 2022-06-21 23:13:20.787997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.application import Sanic

    app = Sanic("test_ExceptionMixin_exception")
    class T(ExceptionMixin):
        pass
    
    t = T()
    decorated_function = t.exception(Exception)(lambda a, b=None: a * b)
    assert decorated_function.__name__ == "<lambda>"
    assert decorated_function.__closure__[1].cell_contents == Exception
    assert decorated_function.__closure__[2].cell_contents == (t, )
    assert len(t._future_exceptions) == 1



# Generated at 2022-06-21 23:13:31.541475
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest

    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic()
    bp = Blueprint('test', url_prefix='test')

    @bp.exception(IndexError)
    def exc_handler(request, exception):
        pass

    @bp.exception([KeyError, ValueError])
    def exc_handler2(request, exception):
        pass

    app.blueprint(bp)
    with pytest.raises(IndexError):
        app.exception({})
    with pytest.raises(KeyError):
        app.exception({})
    with pytest.raises(ValueError):
        app.exception({})
    # It shouldn't raise error, because it doesn't match exceptions
    app.exception({})

    # Test apply=False, exceptions

# Generated at 2022-06-21 23:14:12.459853
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    class TestExceptionMixin:
        def __init__(self):
            self._future_exceptions = set()
            ExceptionMixin.__init__(self)

    test_class = TestExceptionMixin()

    assert isinstance(test_class, TestExceptionMixin)
    assert type(test_class._future_exceptions) is set
    assert test_class._future_exceptions == set()
    assert isinstance(test_class, Blueprint)
    assert isinstance(test_class, ExceptionMixin)

    test_class._future_exceptions.add(FutureException(None, ()))
    assert isinstance(test_class._future_exceptions, set)
    assert len(test_class._future_exceptions) == 1



# Generated at 2022-06-21 23:14:21.783682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    class TestException(Exception):
        pass

    async def handler(request, exception):
        return exception

    app = Sanic('test_exception_mixin')
    blueprint = Blueprint('test_exception')

    blueprint.exception(TestException)(handler)

    assert len(blueprint._future_exceptions)

    @blueprint.route('/fail')
    def fail(request):
        raise TestException('This view always fails')

    app.blueprint(blueprint)

    request, response = app.test_client.get('/fail')

    assert response.text == 'This view always fails'

# Generated at 2022-06-21 23:14:28.087815
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    import pytest

    bp = Blueprint(__name__)
    @bp.exception(ValueError)
    def handler(request: Request, exception: Exception):
        pass

    with pytest.raises(ValueError):
        raise ValueError('test')



# Generated at 2022-06-21 23:14:40.943056
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Callback:
        def  __init__(self):
            pass

    class Context:
        def __init__(self, callback: Callback):
            self.callback = callback

        def enter(self):
            pass

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    class App:
        def __init__(self):
            self.callback = Callback()
            self.context = Context(self.callback)

        def add_task(self, future):
            pass

    class MyBlueprint(ExceptionMixin):
        def __init__(self, app: App, name: str):
            self.app = app
            self.name = name

# Generated at 2022-06-21 23:14:42.510863
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("test_bp")
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-21 23:14:50.287752
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTester(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self.tuple = ()

        def _apply_exception_handler(self, handler: FutureException):
            self.tuple = handler.errors

    exception_mixin_tester = ExceptionMixinTester(())
    foo = exception_mixin_tester.exception(ValueError)(lambda x: x)
    assert isinstance(foo, type(lambda x: x))
    assert exception_mixin_tester.tuple == (ValueError,)

# Generated at 2022-06-21 23:14:51.508122
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    test = Blueprint(__name__)
    assert test._future_exceptions == set()


# Generated at 2022-06-21 23:14:56.891383
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class MyExc(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    my = MyExc()
    assert my is not None

# Generated at 2022-06-21 23:15:00.206984
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        return

    assert(len(blueprint._future_exceptions) == 1)
    assert(type(blueprint._future_exceptions.pop()) == FutureException)

# Generated at 2022-06-21 23:15:07.905541
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

        def exception_handler_function(self):
            pass

    t = Test()
    # future_exceptions has been added 1 FutureException
    t.exception(Exception)(t.exception_handler_function)
    assert len(t._future_exceptions) == 1

# Generated at 2022-06-21 23:16:19.692186
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self):
            super().__init__()

    inst = Test()
    assert inst._future_exceptions == set()

# Generated at 2022-06-21 23:16:21.321188
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert len(bp._future_exceptions) == 0



# Generated at 2022-06-21 23:16:23.025521
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Model(ExceptionMixin):
        pass
    obj = Model()
    assert obj._future_exceptions == set()


# Generated at 2022-06-21 23:16:26.833045
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
        def _apply_exception_handler(self, handler: FutureException):
            return True
    def test_func(x):
        return x+1
    a = A()
    assert isinstance(a.exception(test_func), types.FunctionType)

# Generated at 2022-06-21 23:16:28.443485
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(), ExceptionMixin)


# Generated at 2022-06-21 23:16:38.937499
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.response import text

    app = Sanic()

    bp = Blueprint('test_bp')

    exception_1 = FutureException(handler=text, exceptions=(ZeroDivisionError,))
    exception_2 = FutureException(handler=text, exceptions=(Exception,))

    bp._future_exceptions = {exception_1, exception_2}

    @bp.exception(Exception, apply=False)
    def handler_1(request, exception):
        return text(exception)

    app.blueprint(bp)

    assert handler_1 in bp._future_exceptions
    assert exception_1 in app.error_handler.blueprint_handlers[bp]

# Generated at 2022-06-21 23:16:42.773833
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    A._apply_exception_handler = lambda self, handler: handler
    a = A()
    @a.exception(ValueError)
    def test_exception(request, exception):
        return 'Error'
    assert a._future_exceptions == {FutureException(test_exception, (ValueError,))}

# Generated at 2022-06-21 23:16:46.393286
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            pass

    try:
        ExceptionMixinTest()
    except Exception as e:
        print("Exception (expected) raised: {}".format(e))
    else:
        raise Exception("Exception not raised")
        

# Generated at 2022-06-21 23:16:49.524321
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            self.x = "Test"

    obj = TestClass()

    # have to have at least one test.
    assert obj.x == "Test"

# Generated at 2022-06-21 23:16:52.557904
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    t = TestExceptionMixin()
    assert not t._future_exceptions