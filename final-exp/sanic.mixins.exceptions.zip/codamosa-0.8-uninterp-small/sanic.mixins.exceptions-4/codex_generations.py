

# Generated at 2022-06-26 03:37:50.243587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(FileNotFoundError)
    def handler():
        pass
    assert len(exception_mixin_1._future_exceptions) == 1

# Generated at 2022-06-26 03:37:56.628429
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = FakeBlueprint()

    @exception_mixin.exception(ValueError, KeyError)
    def handler(self, request, exception):
        pass

    assert len(exception_mixin._future_exceptions) == 1
    assert len(exception_mixin._future_exceptions.pop().exceptions) == 2
    assert exception_mixin._future_exceptions.pop().handler == handler

# Generated at 2022-06-26 03:37:58.268822
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_exception = exception_mixin.exception([], {})
    assert exception_mixin_exception == None

# Generated at 2022-06-26 03:38:00.786322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    try:
        exception_mixin.exception(list(1))
    except:
        pass

# Test for when apply is true

# Generated at 2022-06-26 03:38:05.578869
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Decorator definition for named method test_exception_1 of class ExceptionMixin

# Generated at 2022-06-26 03:38:16.570990
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler():
        return None

    def function_0():
        class decorator:
            def __init__(self, arg):
                self.arg = arg

            def __call__(self, arg_0):
                return self.arg(arg_0)
        return decorator

    @exception_mixin_0.exception()
    def function_1():
        return None

    @exception_mixin_0.exception(exceptions=[])
    def function_2():
        return None

    @exception_mixin_0.exception(exceptions=[])
    def function_3():
        return None

    @exception_mixin_0.exception(exceptions=[])
    def function_4():
        return None

    # Tests for exception

# Generated at 2022-06-26 03:38:18.279755
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception, apply=True)

# Generated at 2022-06-26 03:38:26.367665
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin_instance = exception_mixin.exception(*[Exception])
    exception_mixin_instance(42)
    assert exception_mixin.exception(*[Exception]) is not None
    assert exception_mixin.exception(apply=True) is not None
    exception_mixin_instance = exception_mixin.exception(apply=False)
    exception_mixin_instance(42)

# Generated at 2022-06-26 03:38:30.888831
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler(request, exception):
        return '404'
    exception_mixin_0.exception(AssertionError)(handler)
    result = exception_mixin_0.exception(AssertionError)(handler)
    assert result == handler

# Generated at 2022-06-26 03:38:35.628410
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Setting argument types
    exceptions = True
    apply = True
    # Operation
    handler = exception_mixin_0.exception(exceptions, apply)


# Generated at 2022-06-26 03:38:41.746794
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0.exception(ZeroDivisionError)(lambda: 42 / 0), types.FunctionType)

# Generated at 2022-06-26 03:38:46.744807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_handler_0 = lambda: None
    future_exception_0 = FutureException(exception_handler_0,(RuntimeError(),))
    exception_mixin_0._future_exceptions.add(future_exception_0)


# Generated at 2022-06-26 03:38:52.889924
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # case 1
    future_exception_0: FutureException = None
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:39:04.246262
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    (expected, actual) = (None, None)

    exception_mixin_1 = ExceptionMixin()
    try:
        expected = 0
        actual = exception_mixin_1.exception(1, 2, 3)
    except Exception as e:
        print(e)
    assert expected == actual

    try:
        expected = 1
        actual = exception_mixin_1.exception(2)
    except Exception as e:
        print(e)
    assert expected == actual

    try:
        expected = 2
        actual = exception_mixin_1.exception(3)
    except Exception as e:
        print(e)
    assert expected == actual

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:09.882221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = []
    apply_0 = True
    # assert exception_mixin_0.exception(*exceptions_0, apply=apply_0) == <function decorator at 0x7f16d4b56ef0>
    # TODO: fix decorator returned
    return

# Generated at 2022-06-26 03:39:10.874648
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass # TODO


# Generated at 2022-06-26 03:39:15.994198
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler_fplus_4(request, exc):
        return await gm.func2()


    assert hasattr(exception_mixin_0.exception(ValueError), '__call__')
    assert isinstance(exception_mixin_0.exception(ValueError,
                                                  apply=False)(handler_fplus_4), types.FunctionType)



# Generated at 2022-06-26 03:39:18.252488
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_decorator = exception_mixin_0.exception(TypeError)
    assert my_decorator(my_handler) == my_handler

# Generated at 2022-06-26 03:39:21.628418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    error_code_1 = exception_mixin_1.exception()


# Generated at 2022-06-26 03:39:26.017222
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    type_0 = exception_mixin_0.exception(Exception)(None)
    assert isinstance(type_0, types.FunctionType)
    assert type_0 is not None
    assert type_0.__name__ == "None"
    

# Generated at 2022-06-26 03:39:34.504968
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions is None
    assert exception_mixin_0._future_exceptions == set()
    assert len(exception_mixin_0._future_exceptions) == 0
    exception_mixin_0.exception()


# Generated at 2022-06-26 03:39:40.075010
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def exception_handler():
        pass

    assert len(exception_mixin_1._future_exceptions) == 1
    assert len(exception_mixin_2._future_exceptions) == 0



# Generated at 2022-06-26 03:39:44.243540
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        @exception_mixin_0.exception(Exception)
        def fn_0(arg_0: Exception) -> None:
            pass
    except:
        pass

# Generated at 2022-06-26 03:39:52.648770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test with no argument
    exception_mixin_1 = ExceptionMixin()
    # Test with one argument - excepted to pass
    exception_mixin_2 = ExceptionMixin()
    @exception_mixin_2.exception(NotImplementedError)
    def test():
        return None
    # Test with one argument and one optional parameter - expected to pass
    exception_mixin_3 = ExceptionMixin()
    @exception_mixin_3.exception(NotImplementedError, apply=True)
    def test(x):
        return x * x
    # Test with one argument and two optional parameters - expected to pass
    exception_mixin_4 = ExceptionMixin()

# Generated at 2022-06-26 03:39:56.491022
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # definitions
    exception_mixin_0 = ExceptionMixin()

    # method invocation
    exception_mixin_0.exception()

    assert exception_mixin_0._future_exceptions is not None
    assert exception_mixin_0._future_exceptions == set()

# Generated at 2022-06-26 03:40:08.346109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()
    exception_mixin_8 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handler_0():
        pass

    exception_mixin_1.exception(Exception)(handler_0)

    @exception_mixin_2.exception([Exception])
    def handler_1():
        pass


# Generated at 2022-06-26 03:40:10.487764
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(Exception) != None



# Generated at 2022-06-26 03:40:11.329289
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:40:18.478223
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()
    exception_mixin_8 = ExceptionMixin()
    exception_mixin_9 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def test_case_0(request, exception):
        return 'Expected output'

    @exception_mixin_2.exception(Exception)
    def test_case_1(request, exception):
        return 'Expected output'


# Generated at 2022-06-26 03:40:20.006546
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception()

# Generated at 2022-06-26 03:40:30.205145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # call method exception of class ExceptionMixin
    exception_mixin_0.exception(True)

# Generated at 2022-06-26 03:40:36.456716
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(NameError, TypeError)
    exception_mixin_1.exception([NameError, TypeError])
    exception_mixin_1.exception(NameError, TypeError, apply=False)
    exception_mixin_1.exception([NameError, TypeError], apply=False)


if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()
    print("Everything passed")

# Generated at 2022-06-26 03:40:42.347198
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def test_decorator_0(handler):
        return handler
    def test_decorator_1(handler):
        return handler
    def test_decorator_2(handler):
        return handler
    expected_result_0 = exception_mixin_0.exception(test_decorator_0)
    expected_result_1 = exception_mixin_0.exception(test_decorator_1)
    expected_result_2 = exception_mixin_0.exception(test_decorator_2)
    assert expected_result_0 == test_decorator_0
    assert expected_result_1 == test_decorator_1
    assert expected_result_2 == test_decorator_2


# Generated at 2022-06-26 03:40:54.096864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator_0(handler_0 : callable):
        nonlocal apply
        nonlocal exceptions
        if isinstance(*exceptions_0, list):
            exceptions_0 = tuple(*exceptions_0)
        future_exception_0 = FutureException(handler_0, exceptions_0)
        exception_mixin_0._future_exceptions.add(future_exception_0)
        if apply_0:
            exception_mixin_0._apply_exception_handler(future_exception_0)
        return handler_0

    assert hasattr(exception_mixin_0.exception, '__call__')
    exceptions_0 = ()
    apply_0 = True

# Generated at 2022-06-26 03:40:58.322634
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception("test_ExceptionMixin_exception")
    pass

# Generated at 2022-06-26 03:41:01.014067
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception()

# Generated at 2022-06-26 03:41:05.240151
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Initiate the object
    exception_mixin_0 = ExceptionMixin()

    # Verify if the function raises the expected exceptions
    exception_mixin_0.exception(ValueError, KeyError, apply=True)
    exception_mixin_0.exception(ValueError, KeyError, apply=False)

# Generated at 2022-06-26 03:41:06.731513
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # no exception raised
    exception_mixin_1 = ExceptionMixin()


# Generated at 2022-06-26 03:41:12.605766
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # try:
    #     exception_mixin_1 = ExceptionMixin()
    #     result = exception_mixin_1.exception()
    # except NotADirectoryError as exception:
    #     pass
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_3.exception(Exception)



# Generated at 2022-06-26 03:41:17.252558
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    method_0 = exception_mixin_0.exception()

if __name__ == "__main__":
    __future__.exec_()

# Generated at 2022-06-26 03:41:39.372690
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0(arg_0):
        return arg_0

    def handler_1(arg_0):
        return arg_0

    def handler_2(arg_0):
        return arg_0

    def handler_3(arg_0):
        return arg_0

    def handler_4(arg_0):
        return arg_0

    def handler_5(arg_0):
        return arg_0

    def handler_6(arg_0):
        return arg_0
    handler_0('test_0')
    handler_1((ValueError))
    handler_2((ValueError))
    handler_3((ValueError))
    handler_4((ValueError))
    handler_5((ValueError))
    handler_6((ValueError))
    exception_

# Generated at 2022-06-26 03:41:42.473302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception({}) is not None

# Generated at 2022-06-26 03:41:52.842956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_exception_handler(FutureException("Unknown", ["Unknown"]))
    exception_mixin_0._apply_ex

# Generated at 2022-06-26 03:41:54.655186
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    handler = None
    exceptions = ()
    apply = True
    result = exception_mixin.exception(handler, exceptions, apply)
    assert result == handler


# Generated at 2022-06-26 03:42:04.217893
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from unittest.mock import MagicMock
    from sanic.exceptions import SanicException, ServerError

    def _handler():
        pass

    class FutureExceptionClass(FutureException):
        pass

    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    exception_mixin_0 = ExceptionMixinClass()

    # Test applying an exception handler
    exception_mixin_0.exception(SanicException)(_handler)
    assert(exception_mixin_0.handler.handler == _handler)
    assert(exception_mixin_0.handler.exceptions == (SanicException, ))

    # Test that multiple exception

# Generated at 2022-06-26 03:42:09.571187
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    from types import FunctionType

    @exception_mixin_0.exception(ValueError)
    def handler_0(request, exception):
        return 'ValueError'

    assert type(handler_0) == FunctionType

# Generated at 2022-06-26 03:42:16.407704
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def function_0():
        assert 1 == 1
    exception_mixin_0.exception()(function_0)()
    exception_mixin_0.exception(Exception)(function_0)()
    exception_mixin_0.exception(Exception, Exception)(function_0)()

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:27.762636
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception
    @exception_mixin_0.exception
    def func_1():
        return
    @exception_mixin_0.exception
    def func_2():
        return
    @exception_mixin_0.exception
    def func_3():
        return
    @exception_mixin_0.exception
    def func_4():
        return
    @exception_mixin_0.exception
    @exception_mixin_0.exception
    def func_6():
        return
    @exception_mixin_0.exception
    def func_7():
        return
    @exception_mixin_0.exception
    def func_8():
        return

# Generated at 2022-06-26 03:42:36.245746
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def my_handler():
        return 3*3

    exception_mixin = ExceptionMixin()
    # Try calling function exception with valid param
    exception_mixin.exception(int)(my_handler)

    # Try calling function exception with exception as first param
    exception_mixin.exception([int, str])(my_handler)

    # Try calling function exception with apply as second parameter
    exception_mixin.exception(int, apply=False)(my_handler)

# Generated at 2022-06-26 03:42:41.516076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_0 = ExceptionMixin()
    keyword_0 = NotImplementedError  # noqa
    keyword_1 = FutureException(True, NotImplementedError)  # noqa
    
    # Case 0
    def decorator(handler):
        def not_implemented_error():
            raise NotImplementedError  # noqa
        return not_implemented_error
    decorator_0 = decorator
    decorator_0()
    # Return true
    return True

# Generated at 2022-06-26 03:43:17.018527
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handler(request, exception):
        return '{}'.format(type(exception).__name__)

# Generated at 2022-06-26 03:43:20.076554
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def f():
        return
    exception_mixin_1.exception(list([1, 2, 3])).__code__ = f.__code__
    

# Generated at 2022-06-26 03:43:27.525610
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Setup with parameter object
    exceptions_0 = list()
    kwargs_0 = {'apply': True }
    decorator_0 = exception_mixin_0.exception(exceptions_0, **kwargs_0)

    # Check method name
    try:
        assert decorator_0.__name__ == 'exception'
    except AssertionError:
        print('Expected:', 'exception')
        print('Actual  :', decorator_0.__name__)



# Generated at 2022-06-26 03:43:32.663900
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Set up Test
    example_args = [Exception]
    example_kwargs = {}
    try:
        example_decorator = exception_mixin_0.exception(*example_args, **example_kwargs)
    except:
        assert False, 'Method `exception` of class `ExceptionMixin` threw an exception!'

    # Test Body
    try:
        assert callable(example_decorator), '`exception` should return a callable!'
    except:
        print('Method `exception` of class `ExceptionMixin` did not return a callable!')
        raise


# Generated at 2022-06-26 03:43:36.103239
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception, apply=True)(Exception)

# Generated at 2022-06-26 03:43:41.718411
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = [None]
    apply = True
    handler = None

    def _decorator(handler: object) -> object:
        return handler

    # test_case_0
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(exceptions, apply=apply)(handler)
    assert exception_mixin_0 is not None

# Generated at 2022-06-26 03:43:45.117237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(ValueError)
    def exception_handler(request, exception):
        pass

    future_exception = FutureException(exception_handler, (ValueError,))
    assert exception_mixin._future_exceptions == {future_exception}


# Generated at 2022-06-26 03:43:49.330922
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()


if __name__ == "__main__":
    test_ExceptionMixin_exception()
    test_case_0()

# Generated at 2022-06-26 03:43:54.193571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Default call of method exception of class ExceptionMixin
    exception_mixin_0 = ExceptionMixin()
    try:
        assert callable(exception_mixin_0.exception)
    except:
        assert False
    finally:
        pass

    def decorator(handler):
        pass
    return decorator

# Generated at 2022-06-26 03:43:56.430500
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        assert exception_mixin_0.exception(False, False) == None

# Generated at 2022-06-26 03:45:07.767107
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception()
    def decorated_0():
        pass

    assert isinstance(decorated_0, types.FunctionType)

# Generated at 2022-06-26 03:45:10.389485
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = [Exception]
    apply_0 = True
    assert exception_mixin_0.exception(*exceptions_0, apply=apply_0)

# Generated at 2022-06-26 03:45:12.741805
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    args = [1, 2, 3]
    apply = True
    assert exception_mixin_0.exception(*args, apply=apply)


# Generated at 2022-06-26 03:45:17.461339
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create ExceptionMixin instance
    exception_mixin_0 = ExceptionMixin()

    # Try to call exception method
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        pass
    else:
        raise Exception("Exception is not raised.")

# Generated at 2022-06-26 03:45:26.225401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # initialize the future exceptions to an empty set
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._future_exceptions = set()
    # define an apply function for the decorator
    def _apply_exception_handler(handler: FutureException):
        return
    exception_mixin_1._apply_exception_handler = _apply_exception_handler
    # create the exception handler and add to _future_exceptions
    def exception_handler(request, exception):
        return
    exception_mixin_1._future_exceptions.add(FutureException(exception_handler, [Exception]))
    # when the function is called, it will add the handler to _future_exceptions again
    exception_mixin_1.exception(Exception)(exception_handler)
    # check the length of _future_

# Generated at 2022-06-26 03:45:30.643034
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    # Test case where args are list of exceptions
    @exception_mixin.exception(['a'])
    def test_case_0():
        pass

    # Test case where args is a tuple
    @exception_mixin.exception(('a'))
    def test_case_1():
        pass

    # Test case where args is not a list or tuple
    @exception_mixin.exception('a')
    def test_case_2():
        pass

    # Test case where args is a mix of list and tuple
    @exception_mixin.exception(['a', ('b',)])
    def test_case_3():
        pass



# Generated at 2022-06-26 03:45:36.946446
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(Exception)
    def foo(a, b): return a + b
    assert foo(2, 3) == 5
    assert exception_mixin_0._future_exceptions != None

# Generated at 2022-06-26 03:45:39.679498
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def decorator_0(handler):
        return handler
    exception_mixin_1.exception(decorator_0)


# Generated at 2022-06-26 03:45:43.831825
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # instantiating an empty object of type ExceptionMixin
    exception_mixin = ExceptionMixin()
    # validating the preconditions
    assert exception_mixin._future_exceptions == set()

    def decorator(handler):
        # validating the precondition
        assert exception_mixin._future_exceptions == set()
        return handler

    # validating the postconditions
    assert exception_mixin.exception(decorator) == decorator
    assert exception_mixin._future_exceptions != set()

# Generated at 2022-06-26 03:45:48.095416
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test for default parameters of method exception of class ExceptionMixin
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = [Exception]
    @exception_mixin_0.exception(exceptions_0)
    def handler_0(request, exception):
        return "exception"

