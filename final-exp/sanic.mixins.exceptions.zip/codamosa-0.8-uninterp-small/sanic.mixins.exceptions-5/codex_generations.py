

# Generated at 2022-06-26 03:37:55.197184
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # 1
    assert type(exception_mixin_0.exception).__name__ == 'function'
    # 2
    assert type(exception_mixin_0.exception()).__name__ == 'function'

# Generated at 2022-06-26 03:37:58.067251
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # prepare the operator
    exception_mixin_0.exception(Exception)

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:00.123330
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:04.844171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    assert exception_mixin.exception(Exception)
    assert exception_mixin.exception(Exception, new_exception=True)

    try:
        assert exception_mixin.exception([Exception])
    except TypeError:
        print("test_ExceptionMixin_exception passed successfully.")

# Generated at 2022-06-26 03:38:08.457304
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception()
    decorator_1 = exception_mixin_0.exception()

# call example method exception of class ExceptionMixin

# Generated at 2022-06-26 03:38:15.706449
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = []
    apply_0 = True
    decorator_0 = exception_mixin_0.exception(*exceptions_0, apply=apply_0)
    def handler_func_0(handler):
        handler_0 = handler
        handler_0 = _test_case_0(handler_0)
        return handler_0
    decorator_0(handler_func_0)



# Generated at 2022-06-26 03:38:17.630386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()(int)



# Generated at 2022-06-26 03:38:24.323908
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def exception_handler_0(request):
        return None
    def handler_0():
        return (exception_mixin_0.exception(exception_handler_0))

    # Call decorated method handler_0
    handler_0()

# Generated at 2022-06-26 03:38:29.958775
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    try: 
        exception_mixin_0 = ExceptionMixin()
        exception_mixin_0.exception()
    except:
        pytest.fail("The test case test_ExceptionMixin_exception has failed.")
    else:
        assert 1



# Generated at 2022-06-26 03:38:33.950576
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception, TypeError)

# Generated at 2022-06-26 03:38:40.152251
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:50.532572
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        # Test with only one positional argument
        exception_mixin_1 = exception_mixin_0.exception(Exception)

        # Test with two positional arguments
        exception_mixin_2 = exception_mixin_1.exception(Exception, Exception)

        # Test with a keyword argument
        exception_mixin_3 = exception_mixin_2.exception(Exception, Exception, apply=False)

        # Test with a list as a positional argument
        try:
            exception_mixin_3.exception(list)
        except TypeError:
            pass

    except Exception as e:
        Exception('Unexpected exception raised: {}'.format(e))

# Generated at 2022-06-26 03:38:53.347979
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_1 = ValueError
    exception_2 = ZeroDivisionError
    test_value = exception_mixin_0.exception(exception_1, exception_2)
    assert isinstance(test_value, types.FunctionType) is True


# Generated at 2022-06-26 03:38:59.359861
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = lambda x: None
    exception_mixin_1.exception(None, apply=False)
    assert exception_mixin_1._future_exceptions
    assert len(exception_mixin_1._future_exceptions) == 1

# Generated at 2022-06-26 03:39:02.058280
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def run_0():
        return True

    assert run_0() is True



# Generated at 2022-06-26 03:39:04.440797
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    global_exception_handler_0 = exception_mixin_1.exception(Exception)


# Generated at 2022-06-26 03:39:11.967718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def infocenter_exception_handler(handler, exceptions):
        nonlocal exception_mixin_0
        exception_mixin_0._future_exceptions.add(FutureException(handler=handler, exceptions=exceptions))
        return handler
    def f(x, y, z):
        return x + y + z
    f = infocenter_exception_handler(f, [])
    assert f(1, 2, 3) == 6

# Generated at 2022-06-26 03:39:16.462150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def decorated_func_0(handler):
        return handler

    exception_mixin_0 = ExceptionMixin()
    exceptions_set_0 = {'b', 'a', 'a'}
    apply_0 = True
    decorated_func_1 = exception_mixin_0.exception(exceptions_set_0, apply=apply_0)
    assert decorated_func_0 == decorated_func_1

# Generated at 2022-06-26 03:39:23.897159
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    (future_exception_0, apply_0,) = (None, True)

    def handler_0():
        return exception_mixin_0.__init__
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(handler_0, ())
    exception_mixin_1 = exception_mixin_0.exception(apply=apply_0)

    assert_equal(exception_mixin_1, future_exception_0)

# Generated at 2022-06-26 03:39:25.167364
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert type(exception_mixin.exception) == MethodType


# Generated at 2022-06-26 03:39:35.879171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception(Exception)

    exception_mixin_2 = ExceptionMixin()
    assert exception_mixin_2.exception([Exception])

# Generated at 2022-06-26 03:39:41.030541
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test 1: All correct parameters
    # Expectation: a decorator
    ExceptionMixin.exception(ExceptionMixin, [ZeroDivisionError])(lambda: None)
    # Test 2: Empty exception list
    # Expectation: a decorator
    ExceptionMixin.exception(ExceptionMixin, [])
    # Test 3: No local variable
    # Expectation: a decorator
    ExceptionMixin.exception(ExceptionMixin)



# Generated at 2022-06-26 03:39:42.510038
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(1) is not None

# Generated at 2022-06-26 03:39:52.145896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(
        handler=Exception, exceptions=(Exception,)
    )
    exception_mixin_0._future_exceptions.add(future_exception_0)

    def decorator_0(handler):
        return handler

    future_exception_1 = FutureException(
        handler=decorator_0, exceptions=(Exception,)
    )
    return_value_0 = exception_mixin_0.exception(*(Exception,))
    return_value_1 = exception_mixin_0.exception(*(Exception,), apply=True)
    return_value_2 = exception_mixin_0.exception()
    exception_mixin_0._apply_exception_handler(future_exception_1)



# Generated at 2022-06-26 03:39:55.077958
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def test_handler_0():
        pass
    exception = exception_mixin_0.exception()
    exception(test_handler_0)


# Generated at 2022-06-26 03:40:06.763567
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Input parameters
    thelist_0=[]
    thelist_1=[]
    thelist_2=[]
    thelist_1.append(thelist_0)
    thelist_2.append(thelist_1)
    thelist_2.append('apply')
    thetuple_1=tuple(thelist_0)
    # Output parameters
    theany_0 = None
    theany_1 = None
    theany_2 = None
    thefunction_0 = None
    thefunction_1 = None

    theexception_mixin_0 = ExceptionMixin()
    try:
        thefunction_0 = theexception_mixin_0.exception(*thelist_2)
    except Exception as theerror_0:
        theany_1 = True
        theany_0 = theerror_

# Generated at 2022-06-26 03:40:09.478182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(ValueError)
    def func(arg):
        return arg

    return func

# Generated at 2022-06-26 03:40:12.958400
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def func_0(arg_0, arg_1):
        pass

    assert isinstance(func_0, types.FunctionType)

# Generated at 2022-06-26 03:40:19.198248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 0: no exception handler and no exception
    exception_mixin_0 = ExceptionMixin()
    assert not exception_mixin_0._future_exceptions
    @exception_mixin_0.exception()
    def handler_0():
        pass
    assert exception_mixin_0._future_exceptions
    assert len(exception_mixin_0._future_exceptions) == 1
    assert isinstance(exception_mixin_0._future_exceptions.pop(), FutureException)

    # Case 1: no exception handler, but have exception
    exception_mixin_1 = ExceptionMixin()
    assert not exception_mixin_1._future_exceptions
    @exception_mixin_1.exception(IndexError)
    def handler_1():
        pass
    assert exception_mixin_1._

# Generated at 2022-06-26 03:40:26.586592
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exception_mixin_0 = ExceptionMixin()

    # The decorator
    @exception_mixin_0.exception(ZeroDivisionError, ZeroDivisionError)
    def handler():
        return 1

    exception_mixin_1 = ExceptionMixin()

    # The decorator
    @exception_mixin_1.exception(ZeroDivisionError, ZeroDivisionError)
    def handler_1():
        return 1

    assert id(handler) == id(handler_1)

# Generated at 2022-06-26 03:40:35.391211
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def handler():
        pass
    exception_mixin_1.exception(handler)()

# Generated at 2022-06-26 03:40:41.845344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_0 = ()
    exception_1 = (Exception, )
    exception_2 = (Exception, KeyError, )
    exception_3 = (Exception, KeyError, NameError, )
    exception_4 = (Exception, KeyError, NameError, PermissionError, )
    exception_5 = (Exception, KeyError, NameError, PermissionError, ReferenceError,)
    exception_6 = (Exception, KeyError, NameError, PermissionError, ReferenceError, SyntaxError,)
    exception_7 = (Exception, KeyError, NameError, PermissionError, ReferenceError, SyntaxError, SystemError,)
    exception_8 = (Exception, KeyError, NameError, PermissionError, ReferenceError, SyntaxError, SystemError, TypeError,)

# Generated at 2022-06-26 03:40:51.354126
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Testing method exception of class ExceptionMixin

    @exception_mixin_1.exception(Exception)
    def handler_1(request, exception):
        return True

    assert handler_1(None, None)

    @exception_mixin_1.exception(Exception, apply=True)
    def handler_2(request, exception):
        return True

    assert handler_2(None, None)

    @exception_mixin_1.exception(Exception, apply=False)
    def handler_3(request, exception):
        return True

    assert handler_3(None, None)

# Generated at 2022-06-26 03:40:57.621955
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Test case for method exception of class ExceptionMixin."""
    exception_mixin_0 = ExceptionMixin()
    assert hasattr(exception_mixin_0, '_future_exceptions')
    exception_class_0 = FutureException.from_dict({})
    def function_1(handler):
        def function_2(*args, **kwargs):
            return handlers
        return function_2
    assert exception_mixin_0.exception(exception_class_0)(function_1)().from_dict({}).from_dict({})

# Generated at 2022-06-26 03:40:59.642806
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)(None)
    assert True

# Generated at 2022-06-26 03:41:04.866629
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    handler = exception_mixin_0
    exceptions = [TypeError]
    apply = True
    kwargs = {}

    ret = exception_mixin_0.exception(*exceptions, apply=apply, **kwargs)

# Generated at 2022-06-26 03:41:06.731566
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(10, apply=True)


# Generated at 2022-06-26 03:41:10.781811
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert exception_mixin.exception is not None


# Generated at 2022-06-26 03:41:20.093352
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def f():
        pass
    future_exception_0 = FutureException()
    future_exception_0.handler = f()
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0._apply_exception_handler(future_exception_0)
    exception_mixin_0.exception(future_exception_0)
    #Test the type of the output from the method.
    assert isinstance(exception_mixin_0._future_exceptions, set)

# Generated at 2022-06-26 03:41:23.076684
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = exception_mixin_0.exception(ValueError, IndexError, apply=True)

# Generated at 2022-06-26 03:41:43.424580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = []  # type: List[Exception]
    assert any(
        isinstance(exception_mixin_0.exception(exceptions_0, apply=True),
                   Callable[[Callable[..., Any]], Callable[..., Any]])
        for _ in range(100))


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:46.181642
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert hasattr(exception_mixin, 'exception')
    assert hasattr(exception_mixin.exception, '__call__')

# Generated at 2022-06-26 03:41:56.004062
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_exception_0(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)

    exception_mixin_0 = ExceptionMixin_exception_0()
    assert exception_mixin_0._future_exceptions == set()
    def test_function(handler):
        assert isinstance(handler, FutureException)
        assert handler.handler == handler_0
        assert handler.exceptions == (Exception_0, Exception_1)
        exception_mixin_0._apply_exception_handler(handler)

    class Exception_0(Exception):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)


# Generated at 2022-06-26 03:41:57.596625
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception('', ''))


# Generated at 2022-06-26 03:41:59.197072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_func_handler():
        pass
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(test_func_handler)

# Generated at 2022-06-26 03:42:10.151316
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()
    exception_mixin_0 = ExceptionMixin()
    request_0 = type('', (), {})
    request_0.url = 'http://www.google.com'
    request_1 = type('', (), {})
    request_1.url = 'http://www.google.com'
    request_2 = type('', (), {})
    request_2.url = 'http://www.google.com'
    request_3 = type('', (), {})
    request_3.url = 'http://www.google.com'
    request_4 = type('', (), {})
    request_4.url = 'http://www.google.com'
    exception_mixin_0._apply_exception_handler(FutureException(lambda request, exception: request.url, (Exception, )))
   

# Generated at 2022-06-26 03:42:17.458102
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception(NotImplementedError)
    def handler_0(request):
        return "this is a handler"
    decorator_0(handler_0) # TypeError (missing positional argument)
    decorator_0(handler_0, []) # TypeError (missing positional argument)
    decorator_0(handler_0, (), NotImplementedError) # TypeError (missing positional argument)
    decorator_0(handler_0, (), NotImplementedError, True) # TypeError (missing positional argument)
    handler = decorator_0(handler_0, (), NotImplementedError, True, True) # OK
    assert handler.__name__ == 'handler_0'

# Generated at 2022-06-26 03:42:23.715046
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(IndexError)
    def exception_handler(request, exception):
        return "exception_handler"

    assert exception_mixin_1._future_exceptions
    assert exception_handler(1, 2) == "exception_handler"

# Generated at 2022-06-26 03:42:26.692142
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Fix issue where this test expects an exception to be raised.
    exception_mixin_1 = ExceptionMixin()
    # try:
    exception_mixin_1.exception(ExceptionType)
    # except AttributeError:
    #     pass

# Generated at 2022-06-26 03:42:30.095222
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(apply=False)

# Generated at 2022-06-26 03:43:01.595663
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    def test_exception():
        try:
            raise Exception("error")
        except:
            raise

    exception_mixin.exception(Exception)(test_exception)

# Generated at 2022-06-26 03:43:08.023192
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(NotImplementedError)
    def e(argv):
        pass

    assert isinstance(e, collections.abc.Callable)
    exception_mixin_0 = None



# Generated at 2022-06-26 03:43:18.779540
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test 1: Passing correct parameter and calling the decorator method
    @exception_mixin_0.exception(IndexError, apply=True)
    def test_handler_1(request, exception):
        pass

    # Test 2: Passing incorrect parameter type to constructor method
    # Expected behavior: TypeError
    with pytest.raises(TypeError):
        ExceptionMixin(1)

    # Test 3: Passing incorrect parameter type to decorator method
    # Expected behavior: TypeError
    with pytest.raises(TypeError):
        @exception_mixin_0.exception(1)
        def test_handler_2(request, exception):
            pass

    # Test 4: Passing incorrect parameter type to decorator method
    # Expected behavior: TypeError

# Generated at 2022-06-26 03:43:20.793700
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin.exception, MethodType)
    assert exception_mixin.exception.__name__ == 'exception'

# Generated at 2022-06-26 03:43:21.672060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:43:29.098468
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(IndexError)
    def f():
        pass

    assert(exception_mixin_0._future_exceptions != None)
    assert(len(exception_mixin_0._future_exceptions) == 1)
    assert(exception_mixin_0._future_exceptions == {FutureException(f, (IndexError,))})

    @exception_mixin_0.exception([IndexError])
    def f():
        pass


# Generated at 2022-06-26 03:43:32.728470
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test')
    blueprint.exception(ValueError)(lambda x: x)

# Generated at 2022-06-26 03:43:36.913899
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception(Exception, 'apply', 'apply')

# Generated at 2022-06-26 03:43:41.979113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(int)

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(int, float)

    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception(int, float, "abc")

# Generated at 2022-06-26 03:43:42.850276
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:44:49.713608
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        exception_mixin_0.exception()
    exception_mixin_0._apply_exception_handler = lambda x: 1
    exception_mixin_0.exception( 1, apply= True)

# Generated at 2022-06-26 03:44:52.630171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception = ValueError
    handler = lambda : print("handler")
    a = exception_mixin.exception(exception)(handler)
    assert a == handler

# Generated at 2022-06-26 03:45:02.743866
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = lambda handler: None
    future_exception_0 = FutureException(lambda : None, (None,))
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0.exception(AssertionError)(lambda : None)
    exception_mixin_0.exception(AssertionError)(
        lambda : None)
    # assert exception_mixin_0._future_exceptions == {
    #     FutureException(
    #         <function test_ExceptionMixin_exception.<locals>.<lambda> at 0x7f0b9704b158>,
    #         (None,)), FutureException(
    #             <function test_ExceptionMixin_

# Generated at 2022-06-26 03:45:12.277511
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test case 0
    exception_mixin_0 = ExceptionMixin()
    test_exception_0 = TestException()
    exception_mixin_0.exception(*[test_exception_0])(test_exception_0)
    exception_mixin_0.exception(test_exception_0)(test_exception_0)
    exception_mixin_0.exception(*[test_exception_0])(test_exception_0.__name__)
    exception_mixin_0.exception(test_exception_0)(test_exception_0.__name__)
    exception_mixin_0.exception(*[test_exception_0])(test_exception_0.__str__)

# Generated at 2022-06-26 03:45:22.682012
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Method exception of class ExceptionMixin has 1 positional argument(s) but 2 given
    # exception_mixin_1.exception("test_exception")

    # Method exception of class ExceptionMixin has 1 positional argument(s) but 0 given
    # exception_mixin_1.exception()

    # Method exception of class ExceptionMixin has 1 positional argument(s) but 3 given
    # exception_mixin_1.exception("test_exception", apply=False, name="test_exception_handler")

    # Method exception of class ExceptionMixin has 1 positional argument(s) but 4 given
    # exception_mixin_1.exception("test_exception", apply=False, name="test_exception_handler", test=True)


# Generated at 2022-06-26 03:45:25.241324
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test Exception:
    try:
        assert exception_mixin_0.exception()
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-26 03:45:28.271145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exc = Exception
    def f(x):
        return x
    fn_handle = exception_mixin_0.exception(exc)(f)
    assert fn_handle(x=True) == True
    assert fn_handle(x=False) == False

# Generated at 2022-06-26 03:45:39.224774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    
    # Set up mock
    exception_mixin_0 = ExceptionMixin()
    apply = True
    handler0 = "None"
    exceptions0 = [404]
    handler0 = "None"
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception = lambda *args, **kwargs: handler0(apply=apply, *arguments, **kwargs)
    # Call method
    returned_value = exception_mixin_0.exception(*exceptions0, apply=apply)
    # Check returned value
    returned_value_0 = returned_value
    assert returned_value_0 == handler0

# Generated at 2022-06-26 03:45:40.637678
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert True # TODO: implement your test here


# Generated at 2022-06-26 03:45:45.343991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # This test makes sure the case when "exception_handler" is not a method is handled
    class ExceptionMixin_temp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            if not callable(handler):
                return
            handler.exceptions = (RuntimeError, IOError)
            handler.exception(*handler.exceptions)

    exception_mixin_1 = ExceptionMixin_temp()
    assert exception_mixin_1.exception(RuntimeError, apply=False) == exception_mixin_1.exception(RuntimeError)

    # This test makes sure the case when "exceptions" is empty is handled
    class ExceptionMixin_temp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            handler.exceptions = ()

    exception