

# Generated at 2022-06-26 03:37:52.335813
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()
    assert exception_mixin_0.exception(apply=True)


# Generated at 2022-06-26 03:37:55.409282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(FutureException(exception, "404"))

# Generated at 2022-06-26 03:38:00.052639
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Call method exception
    arg_0 = list
    arg_1 = KeyError
    arg_2 = NotImplementedError
    arg_3 = TypeError
    arg_4 = ValueError
    arg_5 = True
    retval_0 = exception_mixin_0.exception(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    assert retval_0 is not None



# Generated at 2022-06-26 03:38:02.767170
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception)



# Generated at 2022-06-26 03:38:05.243787
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Try to call the method
    try:
        test_case_0()
    except Exception as e:
        # raise e
        pass
    else:
        assert True

# Generated at 2022-06-26 03:38:08.497545
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    f_1 = None
    f_1 = exception_mixin_0.exception(Exception)
    assert f_1



# Generated at 2022-06-26 03:38:17.921954
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    params_0 = []
    params_1 = []
    params_2 = []
    params_3 = []
    params_4 = []
    params_5 = []
    params_6 = []
    params_7 = []
    params_8 = []

    def handler_0(*args, **kwargs):
        return None


# Generated at 2022-06-26 03:38:30.963138
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-26 03:38:42.301406
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(AttributeError, apply=True)
    assert len(exception_mixin_1._future_exceptions) == 1
    assert exception_mixin_1._future_exceptions.pop().handler is None
    exception_mixin_1.exception([ValueError, AttributeError], apply=True)
    assert len(exception_mixin_1._future_exceptions) == 2
    assert exception_mixin_1._future_exceptions.pop().handler is None
    assert exception_mixin_1._future_exceptions.pop().handler is None
    exception_mixin_1.exception([ValueError, AttributeError])
    assert len(exception_mixin_1._future_exceptions) == 0


# Generated at 2022-06-26 03:38:45.922268
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        exception_mixin_0.exception()



# Generated at 2022-06-26 03:38:51.151097
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:38:57.924766
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exceptions = []
    apply = True

    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)


        return handler

    assert decorator(test_ExceptionMixin_exception) == test_ExceptionMixin_exception

# Generated at 2022-06-26 03:38:58.530609
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:39:09.585379
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorator_0(handler_0):
        return handler_0
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(exception_mixin_0, [])
    decorator_0(future_exception_0)
    exception_mixin_0._future_exceptions = {future_exception_0}
    print(exception_mixin_0.exception())
    exceptions_0 = []
    def decorator_1(handler_0):
        return handler_0
    decorator_1(exceptions_0)
    future_exception_1 = FutureException(exception_mixin_0, exceptions_0)
    exception_mixin_0._future_exceptions = {future_exception_1}

# Generated at 2022-06-26 03:39:17.656729
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0, ExceptionMixin)
    assert not hasattr(exception_mixin_0, "_future_exceptions")
    assert exception_mixin_0._future_exceptions is None
    exception_mixin_0._future_exceptions = set()
    assert not hasattr(exception_mixin_0, "_future_exceptions")
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._future_exceptions = {FutureException(None, None)}

# Generated at 2022-06-26 03:39:22.647149
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_exception_mixin_0 = ExceptionMixin()
    test_apply_0 = True
    test_exceptions_0 = [ValueError]
    test_exception_mixin_0.exception(test_exceptions_0, test_apply_0)


# Generated at 2022-06-26 03:39:32.839741
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-26 03:39:40.291060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test for the following case:
    #
    #     This method enables the process of creating a global exception
    #     handler for the current blueprint under question.
    #
    #     :param args: List of Python exceptions to be caught by the handler
    #     :param kwargs: Additional optional arguments to be passed to the
    #         exception handler
    #
    #     :return a decorated method to handle global exceptions for any
    #         route registered under this blueprint.
    #
    exception_mixin_0 = ExceptionMixin()

    assert exception_mixin_0

# Generated at 2022-06-26 03:39:42.440518
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0_exception_0 = exception_mixin_0.exception()

# Generated at 2022-06-26 03:39:51.427917
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    @exception_mixin_0.exception(Exception, apply=False)
    def handler_0(request):
        pass
    assert len(exception_mixin_0._future_exceptions) == 1
    assert isinstance(exception_mixin_0._future_exceptions, set)
    for future_exception in exception_mixin_0._future_exceptions:
        assert isinstance(future_exception, FutureException)
        assert future_exception.exceptions == (Exception,)
        assert future_exception.handler == handler_0


# Generated at 2022-06-26 03:39:57.035822
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_exception_0 = exception_mixin_0.exception()


# Generated at 2022-06-26 03:40:01.183620
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint()
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(KeyError)
    assert exception_mixin_0._future_exceptions
    blueprint.exception(KeyError)
    assert blueprint._future_exceptions

# Generated at 2022-06-26 03:40:07.564601
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_1 = ()
    apply_1 = True
    handler_1 = ()
    result_1 = exception_mixin_1.exception(exception_1, apply=apply_1)(handler_1)
    assert result_1 == handler_1


# Generated at 2022-06-26 03:40:09.725876
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(Exception)


# Generated at 2022-06-26 03:40:14.841903
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    handler_1 = lambda: None
    ret_1 = exception_mixin_1.exception(handler_1)
    
    assert callable(ret_1)
    # TODO implement assert_exception_handler later
    # assert_exception_handler(exception_mixin_1._future_exceptions[0], ret_1, ())

# Generated at 2022-06-26 03:40:18.704076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from typing import Callable

    exception_mixin_0 = ExceptionMixin()

    def decorator(handler: Callable):
        return handler
    # Call method exception of exception_mixin_0
    assert exception_mixin_0.exception(decorator) == decorator

# Generated at 2022-06-26 03:40:22.770158
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_00 = ExceptionMixin()
    exception_mixin_00.exception(RuntimeError, AssertionError)


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:26.622568
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Verify whether calling exception method returns a decorator
    @exception_mixin_0.exception(Exception)
    def exception_handler(request, exception):
        pass
    assert callable(exception_handler)


# Generated at 2022-06-26 03:40:30.067923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception = None
    apply = True
    exceptions = ()
    assert exception_mixin_0.exception(*exceptions, apply=apply)


# Generated at 2022-06-26 03:40:32.829226
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def decorator_0(handler):
        pass
    decorator_0 = exception_mixin_1.exception()
    assert (decorator_0 != None)
    exception_mixin_1._apply_exception_handler = lambda handler: None
    def decorator_1(handler):
        pass
    decorator_1 = exception_mixin_1.exception()
    assert (decorator_1 != None)

# Generated at 2022-06-26 03:40:51.953216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    value_0 = 'ZeroDivisionError'
    value_1 = 'KeyError'
    value_2 = 'ValueError'
    value_3 = 'IndexError'
    value_4 = 'TypeError'
    value_5 = 'AttributeError'
    value_6 = 'RuntimeError'
    value_7 = 'ArithmeticError'
    value_8 = 'OverflowError'
    value_9 = 'ImportError'
    value_10 = 'NameError'
    value_11 = 'UnboundLocalError'
    value_12 = 'IndentationError'
    value_13 = 'TabError'
    value_14 = 'SyntaxError'
    value_15 = 'NotImplementedError'
    value_16 = 'SystemError'
    value_17

# Generated at 2022-06-26 03:40:53.480556
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test Case 0
    test_case_0()

# Generated at 2022-06-26 03:41:04.636354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with open(dir_path + '/test_files/test_ExceptionMixin_exception.txt') as test_context:
        expected_output = test_context.read()
        TestExceptionMixin = type('TestExceptionMixin', (ExceptionMixin, ), {})
        test_exception_mixin_0 = TestExceptionMixin()
        @test_exception_mixin_0.exception(IndexError)
        def test_method_0():
            pass
        assert str(test_exception_mixin_0._future_exceptions) == expected_output

# Generated at 2022-06-26 03:41:06.415737
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:10.741685
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()

# Generated at 2022-06-26 03:41:16.446068
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert len(exception_mixin_0._future_exceptions) == 0
    exception_mixin_0.exception(Exception, apply=True)(lambda exception: None)
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:41:17.709943
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:20.170206
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception_mixin_0.exception()
    def test_handler_0():
        pass
    # No assert



# Generated at 2022-06-26 03:41:21.767537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception)

# Generated at 2022-06-26 03:41:32.344641
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(int, apply=True)
    def f(x, y):
        return x / y
    # some tests
    assert f(1, 2) == 0.5
    try:
        f(1, 0)
    except ZeroDivisionError as err:
        assert str(err) == "division by zero"
    assert exception_mixin_0._future_exceptions != set()
    # test exceptions
    try:
        f(1, "0")
    except TypeError as err:
        assert str(err) == "unsupported operand type(s) for /: 'int' and 'str'"

# Generated at 2022-06-26 03:41:51.702005
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def decorator(handler):
        return handler
    decorator_0 = exception_mixin_1.exception(
        IndexError,
        apply=True,
    )
    assert decorator_0 == decorator

# Generated at 2022-06-26 03:41:59.255875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound, ServerError

    # case 0:
    def exception_handler_0():
        print("exception handler 0")

    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    assert hasattr(exception_mixin_0, 'exception')
    exception_handler_0 = exception_mixin_0.exception(NotFound)(exception_handler_0)
    assert exception_handler_0 == exception_handler_0
    assert exception_mixin_0._future_exceptions == set()

    # case 1:
    def exception_handler_1():
        print("exception handler 1")

    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1._future_exceptions == set()


# Generated at 2022-06-26 03:42:08.152901
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with pytest.raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(None)

    def test_0(handler):
        pass

    # __init__
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0, ExceptionMixin)
    assert exception_mixin_0._future_exceptions == set()

    # exception
    exception_mixin_0.exception(Exception, apply=True)(test_0)
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:42:14.620880
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    def handler_1():
        pass

    exception_mixin_1.exception(Exception)(handler_1)
    # Verifying if the exception handler is correctly added to the set of
    # future exception
    assert len(exception_mixin_1._future_exceptions) == 1

    def handler_2():
        pass

    exception_mixin_1.exception(Exception)(handler_2)
    # Verifying if the exception handler is correctly added to the set of
    # future exception
    assert len(exception_mixin_1._future_exceptions) == 2

# Generated at 2022-06-26 03:42:16.659079
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:42:18.669541
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(ValueError)
    def blueprint_exception_handler_0(request):
        pass


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:27.614599
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(object, (object, ))
    assert exception_mixin_0.exception(object)(object) is not None
    exception_mixin_0._future_exceptions.add(future_exception_0)
    assert exception_mixin_0.exception(object, apply=True)(object) is not None
    assert exception_mixin_0.exception((object, ), apply=False)(object) is not None


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:31.683366
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception()

    except TypeError as e:
        if type(e).__name__ == 'TypeError':
            pass
    else:
        assert False

# Generated at 2022-06-26 03:42:37.810418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    excp = Exception("Generic Exception")
    def handler(request, exception):
        return str(exception)

    response = exception_mixin_0.exception([excp])(handler)(None, excp)
    assert response == "<p>Generic Exception</p>"



# Generated at 2022-06-26 03:42:39.581656
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(None)

# Generated at 2022-06-26 03:43:21.141725
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    example_exceptions_0 = {}
    def example_handler_0():
        raise NotImplementedError
    def example_handler_1():
        raise NotImplementedError
    def example_handler_2():
        raise NotImplementedError
    def example_handler_3():
        raise NotImplementedError
    example_apply_0 = True
    try:
        # STUB START
        pass
        # STUB END
        print('STUBBED')
    except Exception as exc:
        print('FAILED')
        print(exc)
    example_apply_0 = False
    try:
        # STUB START
        pass
        # STUB END
        print('STUBBED')
    except Exception as exc:
        print('FAILED')
        print(exc)

# Generated at 2022-06-26 03:43:26.954923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Define a function handler
    def handler():
        pass

    # Instantiate ExceptionMixin
    exception_mixin_0 = ExceptionMixin()

    # Call method exception
    future_exception_0 = exception_mixin_0.exception(KeyboardInterrupt, apply=True)(handler)

    # Check types of returned values
    assert isinstance(future_exception_0, types.FunctionType)

# Generated at 2022-06-26 03:43:33.598778
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def exception_handler_0():
        pass

    def exception_handler_1():
        pass

    def exception_handler_2():
        pass

    def exception_handler_3():
        pass

    def exception_handler_4():
        pass

    def exception_handler_5():
        pass

    def exception_handler_6():
        pass

    def exception_handler_7():
        pass

    def exception_handler_8():
        pass

    def exception_handler_9():
        pass

    def exception_handler_10():
        pass

    def exception_handler_11():
        pass

    def exception_handler_12():
        pass

    def exception_handler_13():
        pass

    def exception_handler_14():
        pass

    def exception_handler_15():
        pass


# Generated at 2022-06-26 03:43:38.920740
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # method exception of class ExceptionMixin: apply = True
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(apply = True)
    def handler_1(exceptions):
        pass


# Generated at 2022-06-26 03:43:43.207443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        exception_mixin_exception_0 = ExceptionMixin()
        exception_mixin_exception_0.exception(int, str)

    except Exception as e:
        print("Exception occurred in call to ExceptionMixin_exception:")
        print(e)


# Generated at 2022-06-26 03:43:46.915043
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        future_exception_0 = FutureException(handler, (RuntimeError,))
        exception_mixin_0._future_exceptions.add(future_exception_0)
        exception_mixin_0._apply_exception_handler(future_exception_0)
        return handler

    assert exception_mixin_0.exception(RuntimeError)(decorator) == decorator

# Generated at 2022-06-26 03:43:50.453503
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception, apply=False)

# Generated at 2022-06-26 03:43:53.976841
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    def A():
        pass
    try:
        exception_mixin.exception(KeyError)(A)
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:44:01.517569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    nonlocal test_0
    test_0 = None
    def handler():
        nonlocal test_0
        test_0 = "test"

    exception_mixin_0.exception(handler)
    assert exception_mixin_0._future_exceptions == {FutureException(handler, ())}
    assert test_0 is None
    exception_mixin_0.exception(handler, apply=True)
    assert test_0 == "test"

# Generated at 2022-06-26 03:44:06.564459
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    def handler():
        return None
    assert exception_mixin_0.exception(*[ValueError], apply=True)(handler)() is None
    assert exception_mixin_0.exception(*[ValueError], apply=True)(handler)() is None


# Generated at 2022-06-26 03:45:21.650475
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Init an object of ExceptionMixin
    exception_mixin_0 = ExceptionMixin()
    # Get exception callable from exception_mixin_0.
    exception_callable_0 = exception_mixin_0.exception
    # Assign exception_0 to the decorated method.
    exception_0 = exception_callable_0(Exception)
    # Assert exception_0 is not None
    assert exception_0 is not None
    # Assert exception_callable_0 is not exception_0
    assert exception_callable_0 is not exception_0

# Generated at 2022-06-26 03:45:24.539537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler_factory_0():
        pass
    future_exception_0 = exception_mixin_0.exception(handler_factory_0)

# Generated at 2022-06-26 03:45:28.213157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    expected_value_00 = NotImplementedError
    def decorator(handler):
        nonlocal exception_mixin_0
        nonlocal expected_value_00
        expected_value_00 = handler
    exception_mixin_0.exception(ExceptionMixin)(decorator)
    assert expected_value_00 == decorator

# Generated at 2022-06-26 03:45:35.598385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    assert len(exception_mixin_0._future_exceptions) == 0

    @exception_mixin_0.exception(Exception)
    def handler(request, exception):
        return None

    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:45:38.399437
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:45:44.457687
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 0
    exception_mixin_0 = ExceptionMixin()
    expected_exception_handler = None
    expected_exceptions = None
    expected_kwargs = {}
    expected_apply = True
    # Case 1
    exception_mixin_1 = ExceptionMixin()
    expected_exceptions = [Exception0]
    expected_kwargs = {}
    expected_apply = True
    # Case 2
    exception_mixin_2 = ExceptionMixin()
    expected_exceptions = [Exception0]
    expected_kwargs = {'key0': 'value0'}
    expected_apply = True
    # Case 3
    exception_mixin_3 = ExceptionMixin()
    expected_exceptions = [Exception0]
    expected_kwargs = {}
    expected_apply = False
    # Case 4
    exception

# Generated at 2022-06-26 03:45:48.346875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = ['exception']
    apply = True
    exception_mixin_1 = ExceptionMixin()
    test_case_0()
    test_case_1 = exception_mixin_1.exception(exceptions, apply)(handler)


# Generated at 2022-06-26 03:45:58.299861
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(ValueError)
    exception_mixin_1.exception(Exception)
    exception_mixin_1.exception(NameError)
    exception_mixin_1.exception(ZeroDivisionError)
    exception_mixin_1.exception(OSError)
    exception_mixin_1.exception(IndexError)
    exception_mixin_1.exception(KeyError)
    exception_mixin_1.exception(NotImplementedError)
    exception_mixin_1.exception(TypeError)
    exception_mixin_1.exception(SystemError)
    exception_mixin_1.exception(LookupError)
    exception_mixin_1.exception(SyntaxError)


# Generated at 2022-06-26 03:46:03.154436
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()

    @exception_mixin_1.exception(NameError, NameError)
    def exception_handler_1(handler):
        return handler

    @exception_mixin_2.exception([NameError, NameError])
    def exception_handler_2(handler):
        return handler

    @exception_mixin_3.exception([NameError, NameError], apply=False)
    def exception_handler_3(handler):
        return handler

# Generated at 2022-06-26 03:46:09.528218
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(NotFound)
    def exception_mixin_exception_handler_0(request, exception):
        pass

    assert exception_mixin_0.exception
    assert exception_mixin_0._apply_exception_handler
    assert exception_mixin_0._future_exceptions