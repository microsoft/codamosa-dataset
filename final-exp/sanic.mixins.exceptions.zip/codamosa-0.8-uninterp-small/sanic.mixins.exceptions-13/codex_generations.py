

# Generated at 2022-06-26 03:37:58.723508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    func_type_0 = type(exception_mixin_0.exception)
    # Case 1:
    # assert isinstance(exception_mixin_0.exception(), func_type_0)
    # Case 2:
    assert isinstance(exception_mixin_0.exception(*[], apply = True), func_type_0)
    # Case 3:
    assert isinstance(exception_mixin_0.exception(*[exception_mixin_0.exception()], apply = True), func_type_0)
    # Case 4:
    assert isinstance(exception_mixin_0.exception(*[exception_mixin_0.exception()], apply = exception_mixin_0.exception()), func_type_0)

# Generated at 2022-06-26 03:38:02.284826
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    decorator = exception_mixin.exception(Exception)

    @decorator
    def handler():
        return

    assert len(exception_mixin._future_exceptions) == 1



# Generated at 2022-06-26 03:38:06.220364
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        def handler():
            pass
        return handler
    result = exception_mixin_0.exception(decorator(handler))
    assert result is handler

# Generated at 2022-06-26 03:38:17.760965
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test that decorator will set the exception correctly
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(Exception)(print)
    assert isinstance(exception_mixin_1._future_exceptions.pop(),FutureException)

    # Test that exceptions can be a list of exceptions
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception([Exception, ValueError])(print)
    assert exception_mixin_2._future_exceptions.pop().exceptions == (Exception, ValueError)

    # Test that exceptions are passed through
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_3.exception(Exception)(print)
    exception = exception_mixin_3._future_exceptions.pop()

# Generated at 2022-06-26 03:38:25.002089
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(AssertionError)
    def exception_handler_0(**kwargs):
        assert isinstance(kwargs, dict)
        # assert True  # executed


test_ExceptionMixin_exception()


# Generated at 2022-06-26 03:38:33.992466
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exception_mixin_1 = ExceptionMixin()
    # The first input argument of method ExceptionMixin.exception should be of type tuple
    try:
        exception_mixin_1.exception(1)
        assert(False)
    except TypeError:
        assert(True)

    exception_mixin_2 = ExceptionMixin()
    # The first input argument of method ExceptionMixin.exception should be of type tuple
    try:
        exception_mixin_2.exception([1])
        assert(False)
    except TypeError:
        assert(True)

    exception_mixin_3 = ExceptionMixin()

# Generated at 2022-06-26 03:38:35.404314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    e = ExceptionMixin()
    assert e.exception()

# Generated at 2022-06-26 03:38:46.446207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Type of parameter exceptions is <class 'tuple'>.
    exceptions_1 = (IndexError,ValueError,)
    exceptions_2 = (exceptions_1,)
    # Type of parameter exceptions is <class 'tuple'>.
    exceptions_3 = (exceptions_2,)
    # Type of parameter apply is <class 'bool'>.
    apply_4 = True
    # Test 1: exceptions == None
    # Test 2: type of exceptions == list
    # Test 3: type of exceptions == tuple
    # Test 4: apply == True
    # Test 5: apply == False
    # Test 6: type of exceptions is list and apply is True
    # Test 7: type of exceptions is list and apply is False
    # Test 8: type of exceptions is tuple and apply is True
    # Test 9

# Generated at 2022-06-26 03:38:52.367637
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    exception_mixin_0.exception()
    exception_mixin_0.exception(1,2,3)
    exception_mixin_0.exception(1,2,3,apply=False)
    exception_mixin_0.exception(lambda a:a+"a")
    exception_mixin_0.exception(lambda a:a+"a",lambda a:a+"b")



# Generated at 2022-06-26 03:39:03.467698
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import patch

    from sanic.models.futures import FutureException

    exception_mixin_0 = ExceptionMixin()
    
    # create mock
    mock_handler: function = mock_handler.create_mock()
    
    # construct call args
    args_0 = ()
    kwargs_0 = {}
    # apply decorator
    result_0 = exception_mixin_0.exception(*args_0, **kwargs_0)(mock_handler)
    
    assert result_0 is not None
    assert isinstance(exception_mixin_0._future_exceptions, set)
    assert isinstance(exception_mixin_0._future_exceptions[0], FutureException)
    mock_handler.assert_called_once_with(result_0)

# Generated at 2022-06-26 03:39:08.929934
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:39:11.811628
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        return
    try:
        exception_mixin_0.exception(handler)
    except TypeError:
        pass



# Generated at 2022-06-26 03:39:16.130987
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    # Call method exception of class ExceptionMixin
    exception_mixin_0.exception(*[BaseException])
    assert exception_mixin_0._future_exceptions == set()
    assert exception_mixin_0._future_exceptions.__class__ == set

# Generated at 2022-06-26 03:39:26.632308
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def _exception_handler(self, exception):
            pass

    exception_mixin = TestExceptionMixin()

    # Check that there's no exception handlers
    assert exception_mixin._future_exceptions == set()

    # Register an exception handler
    @exception_mixin.exception(Exception)
    async def exception_handler(request, exception):
        pass

    # Check that there's now an exception handler
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert future_exception.handler == exception_handler
    assert future_exception.exceptions == (Exception,)



# Generated at 2022-06-26 03:39:37.134111
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a exception_mixin_0 with initialized attributes
    exception_mixin_0 = ExceptionMixin("31N", __file__, *("46P", "O5"), **{"publish_date": "E2", "rest_path": "L7", "uuid": "M7"})
    # Create a exception_mixin_1 with initialized attributes

# Generated at 2022-06-26 03:39:42.468271
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1._future_exceptions == set()
    nonlocal decorator

    def decorator(handler):
        future_exception_1 = FutureException(handler, None)
        exception_mixin_1._future_exceptions.add(future_exception_1)
        exception_mixin_1._apply_exception_handler(future_exception_1)
        return handler
    
    assert exception_mixin_1.exception() == decorator

# Generated at 2022-06-26 03:39:52.118480
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert not hasattr(exception_mixin_0, "_future_exceptions")
    exception_mixin_0.exception()
    exception_mixin_0.exception(ValueError, apply=True)
    exception_mixin_0.exception(ValueError, apply=True, debug=True)
    exception_mixin_0.exception(ValueError, apply=True, debug=True, user_exception_handler=ValueError)
    exception_mixin_0.exception(ValueError, apply=True, debug=True, user_exception_handler=ValueError, some_arg="hello")
    assert hasattr(exception_mixin_0, "_future_exceptions")
    assert len(exception_mixin_0._future_exceptions) == 2

# Generated at 2022-06-26 03:40:03.521585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Check that the attribute is present
    assert hasattr(exception_mixin_0, '_future_exceptions')

    # Check that the type of the attribute is set
    assert isinstance(exception_mixin_0._future_exceptions, set)

    # Check that the attribute is empty
    assert not exception_mixin_0._future_exceptions

    # Test case 1
    # Test that an error is raised when this method is called by a third
    # party
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        pass
    else:
        raise Exception

    # Test case 2
    # Test method exception with the only parameter being exceptions
    # Check the length of the set
    # Check that the returned decorator is

# Generated at 2022-06-26 03:40:12.488925
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Call method exception of class ExceptionMixin
    # Input parameters:
    #   *args[0] (exceptions) - Type: tuple(Exception)
    #   *args[1] (apply) - Type: bool
    # Output:
    #   handler (Type: method)
    def handler(request, error):
        return error
    exceptions = (Exception, )
    result_handler = exception_mixin_0.exception(*exceptions, apply=True)(handler)
    assert result_handler == handler


if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:14.663262
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # ~~~ Apply the method exception to the object ExceptionMixin ~~~
    exception_mixin_0.exception
    assert True

# Generated at 2022-06-26 03:40:23.128893
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception('Exception'))
    def handler_0(request, exception):
        print(exception)
        return exception


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:29.038196
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Define phantom arguments
    args = []
    # Define phantom keyword arguments
    kwargs = {}

    # Create mock object
    exception_mixin_0 = ExceptionMixin()

    # Call method exception of class ExceptionMixin
    try:
        exception_mixin_0.exception(*args, **kwargs)
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:40:34.061317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(Exception, TypeError)
    exception_mixin_0._future_exceptions.add(future_exception_0)
    def decorator(handler):
        return handler
    def handler():
        pass

    assert(exception_mixin_0.exception(AssertionError)(handler) == handler)

# Generated at 2022-06-26 03:40:36.254703
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        pass
    message_0 = exception_mixin_0.exception(handler)
    print(message_0)

# Generated at 2022-06-26 03:40:39.665069
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception_mixin_0.exception(TypeError, AttributeError)
    def handle_exception(request, exception):
        return text("you misunderestimated")


if __name__ == "__main__":
    exception_mixin_0 = ExceptionMixin()
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:50.046116
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    test_case_0()

    # Act
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ZeroDivisionError)
    zero_division_error_handler = exception_mixin_0._future_exceptions.pop()
    assert isinstance(zero_division_error_handler, FutureException)

    exception_mixin_0.exception(Exception)
    exception_handler = exception_mixin_0._future_exceptions.pop()
    assert isinstance(exception_handler, FutureException)

    exception_mixin_0.exception(ZeroDivisionError)
    zero_division_error_handler_2 = exception_mixin_0._future_exceptions.pop()
    assert isinstance(zero_division_error_handler_2, FutureException)

   

# Generated at 2022-06-26 03:40:56.030212
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_handler_1 = exception_mixin_1.exception(SyntaxError)

    assert len(exception_mixin_1._future_exceptions) == 1
    assert exception_handler_1.__name__ == 'exception_handler_1'
    assert isinstance(exception_handler_1, FunctionType)

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:07.049353
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # method is not called
    exception_mixin_0 = ExceptionMixin()
    # method is not called
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(apply=False)

    # method is called once
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(apply=True)

    # method is called twice
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception(apply=True)

    # method is called thrice
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_3.exception(apply=True)
    exception_mixin_3.exception(apply=False)
    exception_mixin_3.exception(apply=False)

    #

# Generated at 2022-06-26 03:41:09.686855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(int)


# TODO: finish all implementation of ExceptionMixin
# TODO: finish all tests for implementation of ExceptionMixin
# TODO: Implement method _apply_exception_handler of class Exception

# Generated at 2022-06-26 03:41:11.991082
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # None:
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = lambda: None
    exception_mixin_1.exception()


# Generated at 2022-06-26 03:41:17.852554
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(IOError)(exception_mixin_0)

# Generated at 2022-06-26 03:41:20.928297
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def func():
        pass
    def arg():
        pass
    func_0 = exception_mixin_0.exception(arg)
    pass

# Generated at 2022-06-26 03:41:32.555013
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Creating a mock of class ExceptionMixin
    exception_mixin_0 = MagicMock(spec=ExceptionMixin)

    # Creating a mock of method apply_exception_handler of class ExceptionMixin
    apply_exception_handler_0 = MagicMock(name="apply_exception_handler_0")
    exception_mixin_0.apply_exception_handler = apply_exception_handler_0

    # Creating a mock of method handler of the class FutureException
    handler_0 = MagicMock(name="handler_0")

    # Creating a mock of class FutureException
    future_exception_0 = MagicMock(spec=FutureException, return_value = handler_0)

    # Setting up the mock of method handler of the class FutureException to record the input arguments passed to it
    future_exception_0.handler = handler

# Generated at 2022-06-26 03:41:34.778311
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception((Exception,))


# Generated at 2022-06-26 03:41:37.967397
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    def handler(request, exception):
        pass

    exception_mixin_exception_decorator = exception_mixin.exception(ValueError)(handler)
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin_exception_decorator is handler


# Generated at 2022-06-26 03:41:39.560902
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    assert exception_mixin_1.exception(KeyError)

# Generated at 2022-06-26 03:41:48.021471
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator_0(handler_0):
        future_exception_0 = FutureException(handler_0, (Exception,))
        exception_mixin_0._future_exceptions.add(future_exception_0)
        return handler_0
    assert len(exception_mixin_0._future_exceptions) == 0
    assert callable(exception_mixin_0.exception(Exception))
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:41:56.074815
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import ServerError
    import pytest

    @pytest.fixture
    def app():
        app = Sanic('test_Name_exception')

        @app.route('/')
        @app.exception(ServerError)
        def handler(request, exception):
            return text('OK')

        return app

    def test_exception(app):
        request, response = app.test_client.get('/')
        response.text == 'OK'

    # test_exception(app)

    # Select request.app that is set on route registration
    assert app.exception is ExceptionMixin.exception

# Generated at 2022-06-26 03:41:58.618123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0():
        exception_mixin_0.exception
    # call function
    handler_0()

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:02.059828
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()

    def dummy_function(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception)
        if apply:
            exception_mixin_0._apply_exception_handler(future_exception)
        return handler

    def handler():
        pass

# Generated at 2022-06-26 03:42:12.443197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(Exception)
    def function_0():
        return Exception
    
    assert callable(function_0)


# Generated at 2022-06-26 03:42:15.087606
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Test case 0
    catch_exception_0 = False
    try:
        exception_mixin_0 = ExceptionMixin()
    except TypeError:
        catch_exception_0 = True
    assert catch_exception_0 == False

# Generated at 2022-06-26 03:42:19.674158
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        pass
    exception_mixin_0.exception(ValueError)(handler)
    assert True
    
# TEST METHOD exception

# Generated at 2022-06-26 03:42:22.543446
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception('', apply=False)



# Generated at 2022-06-26 03:42:24.965745
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    method = exception_mixin_0.exception

    args = ()
    kwargs = {
        'apply': True
    }
    if method(args, kwargs):
        pass

# Generated at 2022-06-26 03:42:28.398418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        exception_mixin = ExceptionMixin()
        f = lambda: 0
        exception_mixin.exception(Exception)(f)
        assert exception_mixin._future_exceptions
    except:
        assert False


# Generated at 2022-06-26 03:42:30.147997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def exception_handler_0(err):
        pass

    exception_mixin_0.exception(Exception)(exception_handler_0)

# Generated at 2022-06-26 03:42:32.471251
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ValueError, "Value Error", "Another Value Error")


# Generated at 2022-06-26 03:42:39.150872
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception_mixin_0.exception()
    def handler_0(request):
        print("In handler")
    assert len(exception_mixin_0._future_exceptions) == 1
    assert type(exception_mixin_0._future_exceptions.pop()) is FutureException
    assert handler_0.__name__ == "handler_0"


# Generated at 2022-06-26 03:42:44.176951
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    fun_0 = ExceptionMixin.exception
    fun_1 = ExceptionMixin.exception([],[])
    fun_2 = ExceptionMixin.exception([],[])
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:43:00.998430
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def some_handler():
        pass

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(some_handler)
    assert exception_mixin_0._future_exceptions


# Generated at 2022-06-26 03:43:03.357268
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("Expected an exception from 'exception'")


# Generated at 2022-06-26 03:43:05.543096
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(BaseException)

# Generated at 2022-06-26 03:43:07.696583
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception



# Generated at 2022-06-26 03:43:18.432842
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Set up test data
    exception_mixin_0 = ExceptionMixin()

    # Test when apply is True
    future_exception_0 = FutureException(handler=test_ExceptionMixin_exception, exceptions=tuple(RuntimeError))
    exception_mixin_0._future_exceptions.add(future_exception_0)
    assert exception_mixin_0._future_exceptions == {future_exception_0}
    with pytest.raises(NotImplementedError) as exc_0:
        exception_mixin_0._apply_exception_handler(future_exception_0)
        assert exc_0 == NotImplementedError

    # Test when apply is False
    future_exception_1 = FutureException(handler=test_ExceptionMixin_exception)
    exception_mixin_0._

# Generated at 2022-06-26 03:43:20.805221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:43:22.932027
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 03:43:31.161171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler(request, exception):
        return None
    def new_handler():
        handler()
    exceptions_0 = [None, None, None]
    exceptions_0 = tuple(exceptions_0)
    assert exception_mixin_0.exception(*exceptions_0, apply=True)(new_handler) == new_handler
    future_exception_0 = FutureException(handler, exceptions_0)
    future_exception_0.handler = new_handler
    assert exception_mixin_0._future_exceptions == {future_exception_0}
    assert future_exception_0.handler.__closure__[0].cell_contents == handler

# Generated at 2022-06-26 03:43:39.111157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def handler_0(request):
        pass

    @exception_mixin_2.exception(Exception)
    def handler_1(request, foo):
        pass
    
    assert len(exception_mixin_1._future_exceptions) == 1
    assert len(exception_mixin_2._future_exceptions) == 1

# Generated at 2022-06-26 03:43:41.088798
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()



# Generated at 2022-06-26 03:44:13.685485
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception() != None


# Generated at 2022-06-26 03:44:19.355637
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(ZeroDivisionError)
    def handler(request: Request, exception: ZeroDivisionError):
        return text('Something went terribly wrong!')

    assert exception_mixin_0._future_exceptions == {FutureException(handler, (ZeroDivisionError,))}

# Generated at 2022-06-26 03:44:21.814196
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception())

# Generated at 2022-06-26 03:44:23.137939
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(IndexError)

# Generated at 2022-06-26 03:44:34.228244
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class DummyObject:
        pass

    dummy_object_0 = DummyObject()
    dummy_object_1 = DummyObject()
    dummy_object_2 = DummyObject()
    dummy_object_3 = DummyObject()
    dummy_object_4 = DummyObject()

    exceptions_0 = [dummy_object_2, dummy_object_1, dummy_object_0, dummy_object_4, dummy_object_2]
    exceptions_1 = [dummy_object_4, dummy_object_4, dummy_object_3, dummy_object_3, dummy_object_1]
    exceptions_2 = [dummy_object_2, dummy_object_2, dummy_object_1, dummy_object_1, dummy_object_1]

# Generated at 2022-06-26 03:44:42.025910
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    """
    This method enables the process of creating a global exception handler
    for the current blueprint under question.

    :param args: List of Python exceptions to be caught by the handler
    :param kwargs: Additional optional arguments to be passed to the
        exception handler

    :return a decorated method to handle global exceptions for any route
    registered under this blueprint.
    """
    def decorator(handler):
        future_exception = FutureException(handler, ())
        exception_mixin_0._future_exceptions.add(future_exception)
        return handler
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:44:51.988631
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def handle_exception(request, exception):
        pass

    assert len(exception_mixin_1._future_exceptions) == 1
    assert isinstance(exception_mixin_1._future_exceptions, set)
    assert isinstance(list(exception_mixin_1._future_exceptions)[0], FutureException)
    assert list(exception_mixin_1._future_exceptions)[0].handler == handle_exception
    assert list(exception_mixin_1._future_exceptions)[0].exceptions == (Exception,)
    assert list(exception_mixin_1._future_exceptions)[0].kwargs == {}

# Generated at 2022-06-26 03:44:58.168385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    args_0 = object()
    args_1 = object()
    args_2 = object()
    args_3 = object()
    result_0 = exception_mixin_0.exception(args_0, args_1, args_2, args_3)

# Generated at 2022-06-26 03:45:00.960421
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(BaseException)
    def handler():
        return True

    assert True == handler()



# Generated at 2022-06-26 03:45:07.058352
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator_0():
        def handler_0():
            return handler_0
        handler_0 = exception_mixin_0.exception(handler_0)
        try:
            handler_0()
        except TypeError as e:
            print(e)

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:46:14.506294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert isinstance(ExceptionMixin.exception, types.FunctionType)

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:46:15.819517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    t_0 = exception_mixin_0.exception(0)

# Generated at 2022-06-26 03:46:17.288213
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert exception_mixin.exception


# Defines the blueprint to test

# Generated at 2022-06-26 03:46:26.090431
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exception_mixin import ExceptionMixin
    from sanic.models.futures import FutureException
    try:
        class test_handler:
            def __init__(self, name):
                self.name = name
            def __call__(self, *args, **kwargs):
                pass
        exception_mixin = ExceptionMixin()
        test_handler = test_handler("exception_handler")
        exception_mixin.exception(test_handler)
        assert exception_mixin._future_exceptions == set(
            [FutureException(handler=test_handler, exceptions=tuple())])
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 03:46:28.957432
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception = exception_mixin.exception
    assert exception

# Generated at 2022-06-26 03:46:34.339302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test 1: exception method has correct type
    assert isinstance(exception_mixin_1.exception, type(exception_mixin_1.
                                                        exception))

    # Test 2: exception method returns a function
    def test_function():
        pass
    assert isinstance(exception_mixin_1.exception(test_function), type(
        test_function))

# Generated at 2022-06-26 03:46:39.089322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Testing the exception method of class ExceptionMixin
    def handler_1():
        pass

    assert exception_mixin_1.exception(Exception, apply=True)(handler_1)() == handler_1()

    def handler_2():
        pass

    assert exception_mixin_1.exception(Exception, apply=True)(handler_2)() == handler_2()


# Generated at 2022-06-26 03:46:40.309163
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0 = exception_mixin_0.exception(
        type_error, type_error)(handler)

# Generated at 2022-06-26 03:46:49.839048
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def expected_exception_handler(*args):
        return "An error occured."
        # raise Exception("An error occured.")

    args_0 = ExceptionMixin()
    args_1 = [Exception]
    args_2 = {'test':'test'}

    cases = [
        (args_0, args_1, args_2, expected_exception_handler)
    ]

    for case in cases:
        exc_mixin, exceptions, kwargs, expected_output = case
        decorated_handler = exc_mixin.exception(*exceptions, **kwargs)(expected_exception_handler)
        assert callable(decorated_handler)
        assert expected_output == decorated_handler

# Generated at 2022-06-26 03:46:53.849362
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # test exception_mixin_0._apply_exception_handler()
    def handler_0():
        pass
    exceptions_0 = [int, float, str]
    decorator_0 = exception_mixin_0.exception(*exceptions_0)
    assert callable(decorator_0)
    assert len(exception_mixin_0._future_exceptions) == len(exceptions_0)
