

# Generated at 2022-06-26 03:37:52.096846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    nonlocal1 = "not an exception"
    @exception_mixin_0.exception(nonlocal1)
    def exception_handler_1():
        pass
    future_exception_0 = next(iter(exception_mixin_0._future_exceptions))
    assert future_exception_0.handler == exception_handler_1
    assert future_exception_0.exceptions == (nonlocal1,)



# Generated at 2022-06-26 03:37:57.063863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    decorator_1 = exception_mixin_1.exception(list)
    def handler_1(request, exc):
        pass
    handler_1 = decorator_1(handler_1)
    assert handler_1
    assert (exception_mixin_1._future_exceptions ==
            {FutureException(handler_1, (list,))})

# Generated at 2022-06-26 03:37:58.222087
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    # exception_mixin_1.exception()


# Generated at 2022-06-26 03:38:07.082496
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def test_exception_1(*args):
        pass

    @exception_mixin_1.exception([Exception])
    def test_exception_2(*args):
        pass

    @exception_mixin_1.exception(Exception, apply=False)
    def test_exception_3(*args):
        pass

    @exception_mixin_1.exception([Exception], apply=False)
    def test_exception_4(*args):
        pass

    assert len(exception_mixin_1._future_exceptions) == 4

# Generated at 2022-06-26 03:38:14.520205
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = [TypeError]

    def exception_handler(request, exception):
        return "Handler"

    exception_mixin_0 = ExceptionMixin()
    result_0 = exception_mixin_0.exception(*exceptions)(exception_handler)

    assert result_0 == exception_handler
    assert exception_mixin_0._future_exceptions != None

# Generated at 2022-06-26 03:38:21.379138
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # target instance
    exception_mixin = ExceptionMixin()

    # test 0: normal execution
    def _handler_0(request, exception):
        pass
    exception_mixin.exception(Exception, apply=False)(_handler_0)

    # test 1: abnormal execution
    # TypeError: __init__() got an unexpected keyword argument 'apply'
    try:
        exception_mixin.exception(Exception, apply=False)
    except TypeError:
        pass


# Generated at 2022-06-26 03:38:24.781970
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def test_handler(*args):
        pass

    exception_mixin_1 = ExceptionMixin()
    r = exception_mixin_1.exception(ValueError)(test_handler)

    assert r == test_handler

# Generated at 2022-06-26 03:38:31.910149
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception(1)
    except TypeError as e:
        print('Error: Method exception(<argument>) of class ExceptionMixin cannot take none as argument.')
        print(e)
    else:
        print('Success: Method exception(<argument>) of class ExceptionMixin can take none as argument.')

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:36.055136
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception(SystemExit, ZeroDivisionError)
    @decorator_0
    def foo(arg):
        pass
    pass


# Generated at 2022-06-26 03:38:47.708818
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.server import HttpProtocol
    from sanic.response import text
    from sanic.exceptions import NotFound

    app_0 = Sanic('sanic-application')

    @app_0.exception(NotFound)
    def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))

    request, response = app_0.test_client.get('/')
    assert response.text == 'Yep, I totally found the page: http://localhost/'
    request, response = app_0.test_client.get('/', allow_redirects=True)
    assert response.text == 'Yep, I totally found the page: http://localhost/'


# Generated at 2022-06-26 03:38:52.300969
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:58.526821
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import random
    exception_mixin_0 = ExceptionMixin()
    def exception_handler_0(arg_0, arg_1=1): return arg_0 == arg_1
    exception_mixin_0.exception('BaseException', 'BaseException')(exception_handler_0)
    print(exception_mixin_0._future_exceptions)
    print(FutureException)

# Generated at 2022-06-26 03:39:05.247702
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic.exceptions import NotFound

    class B:
        def __init__(self, *args, **kwargs):
            args = []
            kwargs = {}
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    b = B()
    assert b._future_exceptions is not None

    decorate = b.exception(NotFound, apply=True)
    assert decorate is not None



# Generated at 2022-06-26 03:39:08.929696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler(*args, **kwargs):
        pass
    exception_mixin_0.exception(handler)

# Generated at 2022-06-26 03:39:12.953825
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler(request):
        return request
    exception_mixin_0.exception(IndexError, apply=True)(handler)
    exception_mixin_0._apply_exception_handler(FutureException(handler, tuple(IndexError)))
    

# Generated at 2022-06-26 03:39:15.217873
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    assert exception_mixin_0.exception(decorator) == decorator

# Generated at 2022-06-26 03:39:18.971301
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin
    """

    # Initialize a new instance of ExceptionMixin
    exception_mixin = ExceptionMixin()

    # Obtain the value of the returned object from method exception applied
    # to the instance of ExceptionMixin
    exception = exception_mixin.exception()

    # Assert that the type of the return value is function
    assert(type(exception) is type(test_ExceptionMixin_exception))



# Generated at 2022-06-26 03:39:23.081931
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0():
        pass
    exception_mixin_0.exception(handler_0)
    assert True

# Generated at 2022-06-26 03:39:25.464415
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        exception_mixin = ExceptionMixin()
        exception_mixin.exception()
    except Exception as e:
        assert type(e) == NotImplementedError

# Generated at 2022-06-26 03:39:28.821906
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def handler(request, exception):
        return "test"


test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:40.108740
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp_0 = Blueprint('bp_0', url_prefix='/foo/')

    @bp_0.exception(ValueError)
    def handler_0(request, exception):
        pass

    assert len(bp_0._future_exceptions) == 1
    future_exception_0 = bp_0._future_exceptions.pop()
    assert len(future_exception_0.exceptions) == 1
    assert future_exception_0.handler == handler_0
    assert isinstance(future_exception_0.exceptions[0], ValueError)

# Generated at 2022-06-26 03:39:43.039004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception()
    def handler_0():
        pass
    decorator_0(handler_0)

# Generated at 2022-06-26 03:39:50.581843
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(None, [None])
    exception_mixin_0._apply_exception_handler(future_exception_0)
    exception_mixin_0._future_exceptions.add(future_exception_0)
    def foo():
        pass
    exception_mixin_0.exception(foo)

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:52.416188
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(apply = False)

# Generated at 2022-06-26 03:39:56.841278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = None
    kwargs_0 = {}
    kwargs_0['apply'] = True
    future_exception_0 = FutureException(exceptions_0, exceptions_0)
    assert isinstance(exception_mixin_0._future_exceptions, set)


# Generated at 2022-06-26 03:40:05.633071
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    my_handler = lambda: 123
    future_exception_0 = FutureException(my_handler, (123,))
    assert future_exception_0 == FutureException(my_handler, (123,))
    assert not future_exception_0 == FutureException(my_handler, (123, 456))
    my_handler = lambda: 123
    exception_mixin_1.exception(my_handler)
    assert exception_mixin_1._future_exceptions == {FutureException(my_handler, ())}


# Generated at 2022-06-26 03:40:15.430871
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc = Exception()
    ex = ExceptionMixin()
    def decorator(handler):
        nonlocal ex
        future_exception = FutureException(handler, (exc,))
        ex._future_exceptions.add(future_exception)
        return handler

    assert ex._future_exceptions.__len__() == 0
    decorator(test_ExceptionMixin_exception)
    assert ex._future_exceptions.__len__() == 1

    def handler():
        pass
    ex.exception(exc)(handler)
    assert ex._future_exceptions.__len__() == 2
    assert ex._future_exceptions.pop() == FutureException(handler,(exc,))
    assert ex._future_exceptions.pop() == FutureException(test_ExceptionMixin_exception,(exc,))


# Generated at 2022-06-26 03:40:18.989936
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():  # noqa
        pass
    ret = exception_mixin_0.exception(handler)
    assert ret == handler


# Generated at 2022-06-26 03:40:30.295930
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    
    exception_mixin_0.__init__()

    exception_mixin_0_exception_result_0 = exception_mixin_0.exception(exception_mixin_0)
    exception_mixin_0_exception_result_1 = exception_mixin_0.exception(exception_mixin_0, [exception_mixin_0])
    exception_mixin_0_exception_result_2 = exception_mixin_0.exception(exception_mixin_0, [exception_mixin_0], apply=True)
    exception_mixin_0_exception_result_3 = exception_mixin_0.exception(exception_mixin_0, [exception_mixin_0], apply=False)



# Generated at 2022-06-26 03:40:31.211393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

# Generated at 2022-06-26 03:40:43.444048
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Create an instance of a ExceptionMixin
    exception_mixin_0 = ExceptionMixin()

    # Create an instance of a function to be passed to the decorator
    def func_0(handler: FutureException):
        return handler

    def func_1(handler: FutureException):
        print("I'm a decorated function")
        return handler

    # Call method exception of exception_mixin_0
    exception_mixin_0.exception(ZeroDivisionError, apply=True)(func_0)
    exception_mixin_0.exception(ZeroDivisionError, ZeroDivisionError, apply=True)(func_0)
    exception_mixin_0.exception([ZeroDivisionError, ZeroDivisionError], apply=True)(func_0)

# Generated at 2022-06-26 03:40:49.760395
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(exceptions=[ValueError])
    def blueprint_exception(request, exception):
        return "Something went wrong!"

    assert len(exception_mixin_1._future_exceptions) == 1

    assert blueprint_exception.__name__ == "blueprint_exception"

# Generated at 2022-06-26 03:40:52.234995
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin() # noqa

test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:58.698042
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def tester_handler():
        pass
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(apply=False)(tester_handler)

# Generated at 2022-06-26 03:41:07.319970
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Code to test
    assert exception_mixin_0.exception(*[None]) == exception_mixin_0.exception(*[None], apply=True)
    assert exception_mixin_0.exception(*[None]) == exception_mixin_0.exception(*[None, None])
    assert exception_mixin_0.exception(*[None]) == exception_mixin_0.exception(*[None, None, None], apply=True)
    assert exception_mixin_0.exception(*[None]) == exception_mixin_0.exception(*[None, None, None, None])

# Generated at 2022-06-26 03:41:12.836615
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)
    set_0 = set()
    future_exception_0 = FutureException(
        handler=exception_mixin_0.exception, exceptions=(Exception,)
    )
    set_0.add(future_exception_0)


# Generated at 2022-06-26 03:41:16.641656
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0.exception(), types.FunctionType)

# Generated at 2022-06-26 03:41:27.224487
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException()
    future_exception_1 = FutureException()
    future_exception_2 = FutureException()
    future_exception_3 = FutureException()
    future_exception_4 = FutureException()
    future_exception_5 = FutureException()
    future_exception_6 = FutureException()
    future_exception_7 = FutureException()
    future_exception_8 = FutureException()
    future_exception_9 = FutureException()
    future_exception_10 = FutureException()
    future_exception_11 = FutureException()
    future_exception_12 = FutureException()
    future_exception_13 = FutureException()
    future_exception_14 = FutureException()
    future_exception_

# Generated at 2022-06-26 03:41:37.175875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    
    #Test case 1: function decorator returned is defined
    @exception_mixin_1.exception(Exception)
    def testFunc(handler):
        return

    assert callable(testFunc)
    
    #Test case 2: decorator works with a list of exceptions
    @exception_mixin_1.exception([Exception, TypeError])
    def testFunc2(handler):
        return
    
    assert callable(testFunc2)
    
    #Test case 3: apply keyword argument is optional in the decorator
    @exception_mixin_1.exception([Exception, TypeError], apply=False)
    def testFunc3(handler):
        return
    
    assert callable(testFunc3)

# Generated at 2022-06-26 03:41:48.181537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(ExceptionMixin)
    assert len(exception_mixin_1._future_exceptions) == 0
    assert isinstance(exception_mixin_1.exception(ExceptionMixin), FutureException)
    assert len(exception_mixin_1._future_exceptions) == 1
    exception_mixin_1.exception(ExceptionMixin)
    assert len(exception_mixin_1._future_exceptions) == 1
    exception_mixin_1.exception(ExceptionMixin)
    assert len(exception_mixin_1._future_exceptions) == 2
    exception_mixin_1.exception(ExceptionMixin, apply=False)

# Generated at 2022-06-26 03:42:14.352631
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Check that first argument is a list of exceptions
    with pytest.raises(TypeError):
        exception_mixin_0.exception("error")("handler")

    # Check that first argument is not an exception
    with pytest.raises(TypeError):
        exception_mixin_0.exception(Exception)("handler")

    # Check that handler is a callable
    with pytest.raises(TypeError):
        exception_mixin_0.exception([Exception])("not_a_handler")

    # Check that handler is not a decorator
    with pytest.raises(TypeError):
        exception_mixin_0.exception([Exception])("not_a_decorator")

    # Check that function returns a decorator

# Generated at 2022-06-26 03:42:15.830611
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception()
    def exception_handler():
        pass

# Generated at 2022-06-26 03:42:20.058607
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Calling function 'exception' of class 'ExceptionMixin'
    func0 = lambda: exception_mixin_0.exception()

    func0()



# Generated at 2022-06-26 03:42:23.537404
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert (exception_mixin_0.exception(Exception, False))
    return "Test_case_passed"


# Generated at 2022-06-26 03:42:29.468202
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint', url_prefix='test')
    blueprint.exception(KeyError)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(None, (KeyError,))

    blueprint.exception([KeyError, ValueError])

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(None, (KeyError, ValueError))

# Generated at 2022-06-26 03:42:31.786059
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(
        "python_exception_0"
    )


# Generated at 2022-06-26 03:42:38.180745
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    try:
        @exception_mixin_1.exception([IOError, IndexError])
        def exception_handler_1():
            pass
        assert True
    except:
        assert False


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:40.640938
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(
        ['Exception'],
    )
    exception_mixin_1._future_exceptions.__len__()

# Generated at 2022-06-26 03:42:43.566947
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exc_0 = exception_mixin_0.exception(AttributeError)
    exc_0(lambda: None)
    # Calling method exception of class ExceptionMixin


# Generated at 2022-06-26 03:42:48.356018
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set() == ExceptionMixin._future_exceptions.__get__(exception_mixin_0)
    try:
        exception_mixin_0._apply_exception_handler(None)
    except NotImplementedError as e:
        assert e is not None
    #assert exception_mixin_0.exception(ValueError) == 
    assert exception_mixin_0._future_exceptions == set() == ExceptionMixin._future_exceptions.__get__(exception_mixin_0)
    exception_mixin_0.exception(ValueError)(0)
    exception_mixin_0.exception(ValueError)(1)
    assert exception_mixin_0._future_exceptions == set

# Generated at 2022-06-26 03:43:21.522470
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert exception_mixin.exception is not None
    assert exception_mixin.exception('exception') is not None

# Generated at 2022-06-26 03:43:27.409961
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(
            object, object)
    future_exception_0.exceptions = object
    future_exception_0.handler = object
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0._apply_exception_handler(future_exception_0)

# Generated at 2022-06-26 03:43:29.403626
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)
    assert exception_mixin_0._future_exceptions


# Generated at 2022-06-26 03:43:34.530526
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    ValueError
    ValueError
    func_0 = exception_mixin_0.exception(ValueError)(ValueError)
    # Assertion to check if the returned value is a function.
    assert callable(func_0)


# Generated at 2022-06-26 03:43:38.171414
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    test_case_0()

# Generated at 2022-06-26 03:43:45.542537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # TypeError: Expected type 'Tuple[Type[FutureException]], received: None
    # exception_mixin_0.exception()
    # TypeError: Expected type 'Type[FutureException]', received: None
    # exception_mixin_0.exception(None)
    # TypeError: Expected type 'Union[Type[BaseException], Type[BaseException]], received: None
    # exception_mixin_0.exception(None, None)
    # TypeError: Expected type 'Callable[[FutureException], FutureException], received: None
    # exception_mixin_0.exception(None, None, None)

# Generated at 2022-06-26 03:43:56.874289
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()

    # Annotation for attribute exception_mixin_0._future_exceptions

    # Define a list of exceptions for method exception
    exception_exception_0 = list()

    # Define a list of exceptions for method exception
    exception_exception_1 = list()

    # Define a list of exceptions for method exception
    exception_exception_2 = list()

    # Define a list of exceptions for method exception
    exception_exception_3 = list()

    # Define a list of exceptions for method exception
    exception_exception_4 = list()

    # Define a list of exceptions for method exception
    exception_exception_5 = list()

    # Define a list of exceptions for method exception
    exception_exception

# Generated at 2022-06-26 03:44:03.927833
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(Exception)
    exception_mixin_1.exception(Exception, AttributeError)
    exception_mixin_1.exception(Exception)
    exception_mixin_1.exception([Exception, AttributeError])

test_ExceptionMixin_exception()


# Generated at 2022-06-26 03:44:05.265576
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:44:06.929653
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception(0))

# Generated at 2022-06-26 03:45:17.215557
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception([]) is not None

# Generated at 2022-06-26 03:45:21.217712
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    logger_0 = logging.getLogger("sanic.root")
    logger_0.addHandler(logging.StreamHandler())
    exception_mixin_0.exception(logger_0, listen)
    exception_mixin_0.exception(logger_0, listen)

# Generated at 2022-06-26 03:45:22.681941
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Implement this unit test
    raise NotImplementedError



# Generated at 2022-06-26 03:45:26.125832
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    assert decorator == exception_mixin_0.exception("*")("*")
    assert exception_mixin_0._future_exceptions == {
        FutureException("*", "*")}



# Generated at 2022-06-26 03:45:27.303051
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:45:30.234899
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(1)


# Generated at 2022-06-26 03:45:34.852194
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    result = exception_mixin_0.exception(*[], apply=True)

# Generated at 2022-06-26 03:45:38.997621
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    exception_mixin = ExceptionMixin()
    future_exception: FutureException = FutureException(None, None)
    exception_mixin.exception(Exception, apply=False)
    assert exception_mixin._future_exceptions == {future_exception}

# Generated at 2022-06-26 03:45:41.298344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(RuntimeError)
    
    
# test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:45:42.831632
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception()
    pass