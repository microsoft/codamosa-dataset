

# Generated at 2022-06-26 03:37:47.171865
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Call method exception of class ExceptionMixin
    @exception_mixin_0.exception(AttributeError, apply=False)
    def function_0():
        return
    function_0()

# Generated at 2022-06-26 03:37:50.637521
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def decorator(handler):
        return handler

    assert isinstance(exception_mixin_0.exception(None), types.FunctionType)

# Generated at 2022-06-26 03:37:55.354982
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exceptions: Set[FutureException] = set()

    # call the method under test
    result = exception_mixin_0.exception(
        *{0, 1}, apply=False)

    assert ExceptionMixin.exception == result
    assert future_exceptions == exception_mixin_0._future_exceptions

# Generated at 2022-06-26 03:37:57.385420
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions = []
    apply = True
    assert exception_mixin_0.exception(*exceptions, apply=apply) is not None

# Generated at 2022-06-26 03:37:59.692402
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def current_handler(request):
        return

    exception_mixin_0.exception(Exception)(current_handler)
    assert exception_mixin_0._future_exceptions == {FutureException(current_handler, (Exception,))}



# Generated at 2022-06-26 03:38:07.501772
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # classmethod exception must be static method
    @exception_mixin_0.exception(FutureException)
    def exception_fn_0(request):
        """Exception handler"""
        return FutureException
    assert exception_mixin_0._future_exceptions
    assert exception_fn_0.__name__ == "exception_fn_0"
    assert exception_fn_0.__doc__ == "Exception handler"
    assert exception_fn_0.__qualname__ == "ExceptionMixin.exception_fn_0"


# Generated at 2022-06-26 03:38:15.242314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    
    # Test case 0
    # Argument exceptions of type set
    # Argument apply of type bool
    # Return type: Blueprint

    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception({'BadRequest', 'HTTPException'}, apply=True)
    def a_handler_that_handles_all_exceptions():

        return

    a_handler_that_handles_all_exceptions()

# Generated at 2022-06-26 03:38:21.164179
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_2 = ExceptionMixin()

    def exception_handler_1():
        pass

    exception_mixin_2.exception(exception_handler_1)

    if isinstance(exception_mixin_2, ExceptionMixin):
        check_1 = True

    if check_1:
        pass
    else:
        raise Exception('Test Failed')


# Generated at 2022-06-26 03:38:24.921992
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    nonlocal exceptions
    def handler(req, exception):
        pass
    exception_mixin_0.exception(lambda req, exception: handler(req, exception))


# Generated at 2022-06-26 03:38:30.282811
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(KeyError, apply=True) == exception_mixin_0.exception(KeyError, apply=True)

# Generated at 2022-06-26 03:38:35.804736
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception


# Generated at 2022-06-26 03:38:39.674807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    exception_mixin_0 = ExceptionMixin()

    # Act
    f = exception_mixin_0.exception("a", "b")

    # Assert
    assert f("c") == "c"

# Generated at 2022-06-26 03:38:50.740022
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def handler1_1():
        pass
    def handler1_2():
        pass
    def handler1_3():
        pass
    def handler1_4():
        pass
    exception_mixin_1._apply_exception_handler = handler1_1
    exception_mixin_1.exception = handler1_2
    exception_mixin_1.exception(__s)
    exception_mixin_1.exception(__s, apply)
    exception_mixin_1.exception(__s, apply = True)
    exception_mixin_1.exception(__s, apply = False)

# Generated at 2022-06-26 03:38:54.013598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0():
        pass

    exception_mixin_0.exception(handler_0)

# Generated at 2022-06-26 03:38:58.067041
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)
    assert len(exception_mixin_0._future_exceptions) == 1


# Generated at 2022-06-26 03:38:58.667072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:39:02.151515
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handler_0(request, exception : List[Exception]):
        for exp in exception:
            print(exp)



# Generated at 2022-06-26 03:39:13.035693
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()

    def handler():
        pass

    exception_mixin_0.exception(handler)
    assert exception_mixin_0._future_exceptions == {
        FutureException(handler, tuple())
    }

    def handler_1():
        pass

    exception_mixin_0.exception(handler_1)
    assert exception_mixin_0._future_exceptions == {
        FutureException(handler, tuple()),
        FutureException(handler_1, tuple()),
    }

    exception_mixin_0.exception(RuntimeError)(handler_1)

# Generated at 2022-06-26 03:39:15.637862
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def callback_0():
        pass
    exception_mixin_0.exception(callback_0)

# Test case for ExceptionMixin.__init__

# Generated at 2022-06-26 03:39:18.518591
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception
    def handler_0(request, exception):
        return exception

# Generated at 2022-06-26 03:39:26.251503
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_exception_0 = ExceptionMixin()
    handler_0 = lambda: None
    exceptions_0 = ()
    assert isinstance(exception_mixin_exception_0.exception(*exceptions_0)(handler_0), types.FunctionType)


# Generated at 2022-06-26 03:39:32.566340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def default_handler_0():
        # code
        return None

    exception_mixin_0.exception(IndexError, apply=False)(default_handler_0)

    assert exception_mixin_0._future_exceptions == {FutureException(default_handler_0, (IndexError,))}

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:41.806320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.models.futures import FutureException

    test_case_0()
    test_exception_mixin_0 = ExceptionMixin()

    test_handler_0 = "test_handler_0"
    test_exceptions_0 = (ZeroDivisionError, ValueError)
    test_apply_0 = True
    test_func_0 = test_exception_mixin_0.exception(apply=test_apply_0, *test_exceptions_0)(test_handler_0)
    test_result_0 = test_func_0
    test_except_0 = FutureException(test_handler_0, test_exceptions_0)
    test_future_exceptions_0 = set([test_except_0])
    test_case_0 = True
    assert test_result_

# Generated at 2022-06-26 03:39:50.330932
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test type of case 0
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = lambda: None
    assert callable(exception_mixin_1.exception(None))
    assert exception_mixin_1._future_exceptions == set()
    # Test type of case 1
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2._apply_exception_handler = lambda: None
    assert callable(exception_mixin_2.exception(None, apply=None))
    assert exception_mixin_2._future_exceptions == set()

# Generated at 2022-06-26 03:40:00.488119
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def decorator(handler):
        nonlocal apply
        nonlocal exceptions
        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)
        future_exception = FutureException(handler, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception)
        if apply:
            exception_mixin_0._apply_exception_handler(future_exception)
        return handler

    exception_mixin_0 = ExceptionMixin()
    assert (
        set() == exception_mixin_0._future_exceptions
    ), "Failed to create object instance of ExceptionMixin."
    exception(TypeError)
    assert (
        not isinstance(exception_mixin_0._future_exceptions, tuple)
    ), "Failed to create object instance of ExceptionMixin."

# Generated at 2022-06-26 03:40:04.726043
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        exception_mixin_0 = ExceptionMixin()
    except TypeError:
        print("TypeError")

test_ExceptionMixin_exception()


# Generated at 2022-06-26 03:40:08.330211
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass
    # TODO: The method exception is not yet implemented.
    # exception_mixin_0 = ExceptionMixin()
    # assert False == exception_mixin_0.exception(exceptions_0, apply_0)

# Generated at 2022-06-26 03:40:12.636198
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(IndexError, ZeroDivisionError)
    def foo(a, b, c):
        print(a, b, c, "Hello World.")

    assert foo.func_name == 'foo'


# Generated at 2022-06-26 03:40:14.804534
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_obj_0 = ExceptionMixin()
    assert exception_mixin_obj_0.exception == ExceptionMixin.exception

test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:16.168652
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()

# Generated at 2022-06-26 03:40:25.789936
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(RuntimeError)

# Generated at 2022-06-26 03:40:28.677720
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_ExceptionMixin_exception_0()
    test_ExceptionMixin_exception_1()
    test_ExceptionMixin_exception_2()


# Generated at 2022-06-26 03:40:37.619204
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    test_func_0 = exception_mixin_0.exception(Warning)
    test_func_1 = exception_mixin_0.exception(Warning, ValueError)
    test_func_2 = exception_mixin_0.exception([Warning, ValueError])

# The following assert_function(s) are used to print the result of the unit test
# def assert_function(expected, result):
#     assert expected == result, f"Expected: {expected}; Actual: {result}"

# result = exception_mixin_0.exception(Warning, ValueError)
# assert_function(test_func_1, result)

# result = exception_mixin_0.exception([Warning, ValueError])
# assert_function(test_func_2, result)

# Generated at 2022-06-26 03:40:38.642258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception()

# Generated at 2022-06-26 03:40:40.316578
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    exception_mixin_0 = ExceptionMixin()
    
    # When
    exception_mixin_0.exception(list, apply=True)



# Generated at 2022-06-26 03:40:42.587548
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0_exception_0 = exception_mixin_0.exception(lambda a: None)

# Generated at 2022-06-26 03:40:46.289185
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler():
        return Error("exception")
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(handler)


# Generated at 2022-06-26 03:40:50.812543
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(NotImplementedError) is not None
    # Test for when number of arguments is 2
    assert exception_mixin_0.exception(NotImplementedError, True) is not None


# Generated at 2022-06-26 03:40:55.817344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler(request, exception):
        return exception

    # Python exceptions to be caught by the handler
    exceptions = Exception

    future_exception_0 = FutureException(handler, exceptions)
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0._apply_exception_handler(future_exception_0)

# Generated at 2022-06-26 03:41:07.006585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_1(request, exception, *args, **kwargs):
        return exception
    def handler_2(request, exception, *args, **kwargs):
        return exception
    def handler_3(request, exception, *args, **kwargs):
        return exception
    def handler_4(request, exception, *args, **kwargs):
        return exception
    ExceptionMixin._apply_exception_handler = (
        lambda self, handler : None)
    exception_mixin_0.exception(handler_1)
    assert exception_mixin_0._future_exceptions == (
        set([FutureException(handler_1, ())]))
    exception_mixin_0.exception()(handler_2)
    assert exception_mixin_0._future_ex

# Generated at 2022-06-26 03:41:25.153928
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    banner_0 = exception_mixin_0.exception
    exception_mixin_0.exception('', '', '', '')
    exception_mixin_0.exception('', '', '', '', '')
    exception_mixin_0.exception('', '', '')
    exception_mixin_0.exception('', '')
    exception_mixin_0.exception('', '', '')
    exception_mixin_0.exception('', '')
    exception_mixin_0.exception('')



# Generated at 2022-06-26 03:41:28.487014
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(*[], apply=None)        #was: assert exception_mixin_0.exception(*[], **{})

# Generated at 2022-06-26 03:41:33.272890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def exception_handler_test_0(*args, **kwargs):
        a = None
        if a is None:
            raise ValueError
    exception_mixin_0.exception('ValueError                     ', apply=True)(exception_handler_test_0)

# Generated at 2022-06-26 03:41:36.606428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = lambda x: None

    def handler_0(*args, **kwargs):
        """
        Simply prints the arguments to the console

        :param args: List of positional arguments
        :param kwargs: List of keyword arguments
        """
        pass

    exception_mixin_0.exception()(handler_0)
    assert exception_mixin_0._future_exceptions == {FutureException(handler_0, ())}

# Generated at 2022-06-26 03:41:47.115805
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # initialization
    exception_mixin_0 = ExceptionMixin()
    # unit test
    # test case 0
    def tuple(*args, **kwargs):
        assert False
    future_exception_0 = FutureException(tuple, tuple)
    assert future_exception_0.handler == tuple
    assert future_exception_0.exceptions == tuple
    # test case 1
    def tuple(*args, **kwargs):
        assert False
    future_exception_0 = FutureException(tuple, tuple)
    assert future_exception_0.handler == tuple
    assert future_exception_0.exceptions == tuple
    # test case 2
    def tuple(*args, **kwargs):
        assert False
    future_exception_0 = FutureException(tuple, tuple)

# Generated at 2022-06-26 03:41:51.854389
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert True  # TODO: implement your test here


# -----------------------------------------------------------------------------
# Main: Run the tests
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:54.515986
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def f0(x):
        return x

    f1 = exception_mixin_0.exception(FileExistsError, FileNotFoundError)(f0)
    assert f1(True)

# Generated at 2022-06-26 03:41:59.461854
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    #
    # Example for method "exception" (1/2)
    #

    @exception_mixin_0.exception(NameError, ZeroDivisionError)
    def test_func():
        pass

    future_exception_0 = next(iter(exception_mixin_0._future_exceptions))
    assert future_exception_0.handler == test_func
    assert future_exception_0.exceptions == (NameError, ZeroDivisionError)

# Generated at 2022-06-26 03:42:08.578185
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class NewException(Exception):
        def __init__(self,*args,**kwargs):
            super(NewException,self).__init__(self,args,kwargs)
            self.__cause = None

        @property
        def cause(self):
            return self.__cause

        @cause.setter
        def cause(self, value):
            self.__cause = value


    @exception_mixin_0.exception(NewException, apply=False)
    def exception_handler(request, exception):
        return response.html(f'<h1>The {exception} page</h1>')

    assert True

# Generated at 2022-06-26 03:42:15.477780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Example of method exception of class ExceptionMixin

    # Start Class
    exception_mixin_0 = ExceptionMixin()

    # Method exception of class ExceptionMixin
    def decorator(handler):
        nonlocal exceptions
        nonlocal apply

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception)
        if apply:
            exception_mixin_0._apply_exception_handler(future_exception)
        return handler

    assert decorator
    # End Class


# Generated at 2022-06-26 03:42:50.700410
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler(None)
    exception_mixin_0.exception(None)

# Generated at 2022-06-26 03:42:51.582030
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 1


# Generated at 2022-06-26 03:42:53.719434
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception

# Boilerplate for function test_ExceptionMixin_exception

# Generated at 2022-06-26 03:43:03.680371
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(NotFound)
    assert len(exception_mixin_1._future_exceptions) == 1

    test_method = exception_mixin_1.exception()
    test_method = exception_mixin_1.exception(NotFound)
    assert len(exception_mixin_1._future_exceptions) == 1

    exception_mixin_1_exception_0 = exception_mixin_1._future_exceptions.pop()
    assert exception_mixin_1_exception_0._handler == test_method
    assert exception_mixin_1_exception_0._exceptions == (NotFound,)

# Generated at 2022-06-26 03:43:14.380613
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler():
        pass

    exceptions = []

    apply = True

    nonlocal handler
    nonlocal exceptions
    nonlocal apply

    if isinstance(exceptions[0], list):
        exceptions = tuple(*exceptions)

    future_exception = FutureException(handler, exceptions)

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._future_exceptions.add(future_exception)
    if apply:
        exception_mixin_1._apply_exception_handler(future_exception)

    assert exception_mixin_1._future_exceptions == {future_exception}

    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)


# Generated at 2022-06-26 03:43:18.162571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin()

    assert result.exception(list)

    result_1 = ExceptionMixin()

    decorator = result_1.exception(list, set)

    assert decorator



# Generated at 2022-06-26 03:43:23.873650
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ValueError, ValueError, ValueError, ValueError)

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception([BaseException, ValueError, ValueError])

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception([ValueError, ValueError], apply=True)

# Generated at 2022-06-26 03:43:25.932946
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()


# Generated at 2022-06-26 03:43:26.427957
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:43:33.294889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Test for @exception()
    handler_0 = lambda *args, **kwargs: None
    decorator_0 = ExceptionMixin.exception(None)
    handler_0_decorated = decorator_0(handler_0)

    # Test for @exception(int)
    handler_1 = lambda *args, **kwargs: None
    decorator_1 = ExceptionMixin.exception(int)
    handler_1_decorated = decorator_1(handler_1)

    # Test for @exception(int, str)
    handler_2 = lambda *args, **kwargs: None
    decorator_2 = ExceptionMixin.exception(int, str)
    handler_2_decorated = decorator_2(handler_2)

    # Test for @exception(int, str, float)

# Generated at 2022-06-26 03:44:43.523983
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Reduce code duplication in test_ExceptionMixin_exception
    #  and test_Sanic_exception

    @exception_mixin_0.exception(ValueError, IndexError, apply=True)
    def handler():
        return 0

    assert handler.__name__ == "handler"

    # TODO: Check isinstance(handler, types.FunctionType)

    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(ValueError, IndexError)
    def handler():
        return 0

    assert handler.__name__ == "handler"

    # TODO: Check isinstance(handler, types.FunctionType)

    exception_mixin_2 = ExceptionMixin()


# Generated at 2022-06-26 03:44:48.923286
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_handler = lambda *args, **kwargs: None
    future_exception = FutureException(exception_handler, ())
    exception_mixin_0.exception(apply=True)(exception_handler)
    assert exception_mixin_0._future_exceptions == {future_exception}

# Generated at 2022-06-26 03:44:50.487010
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # nothing to do test_case_0 imports ExceptionMixin
    pass

# Generated at 2022-06-26 03:44:52.862848
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0():
        pass
    exception_mixin_0.exception(handler_0)

# Generated at 2022-06-26 03:45:02.868608
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.exceptions import SanicException, ServerError

    @exception_mixin_0.exception(ServerError)
    def test_exception_handler(request, exception):
        pass

    assert len(exception_mixin_0._future_exceptions) == 1, \
        "exception function does not work properly"
    assert len(exception_mixin_0._future_exceptions.pop().exceptions) == 1, \
        "exception function does not work properly"

    with pytest.raises(TypeError):
        @exception_mixin_0.exception()
        def test_exception_2():
            pass


# Generated at 2022-06-26 03:45:04.495861
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: add unit test for method exception of class ExceptionMixin
    pass

# Generated at 2022-06-26 03:45:06.855840
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global exception_mixin_0
    assert hasattr(exception_mixin_0,'exception')


# Generated at 2022-06-26 03:45:08.301615
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: implement assertion
    exception_mixin = ExceptionMixin()
    exception_mixin.exception('a')

# Generated at 2022-06-26 03:45:11.541116
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions = tuple()
    apply = True
    handler_ = lambda: None
    decorator = exception_mixin_0.exception(*exceptions, apply=apply)
    assert handler_ == decorator(handler_)

# Generated at 2022-06-26 03:45:13.555868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler(request, exception):
        return None
    exception_mixin_0.exception(apply=True)(handler)

# Generated at 2022-06-26 03:47:34.009180
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception(Set)
    except NotImplementedError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-26 03:47:37.925396
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Creating an instance of ExceptionMixin
    exception_mixin_0 = ExceptionMixin()

    # Testing if the method exception of class ExceptionMixin is working
    # properly

    # Testing output type
    exception_mixin_0 = ExceptionMixin()

    # Declaring a variable to store the output of the exception method.
    # Output type is a decorator.
    # Source: https://www.python.org/dev/peps/pep-0318/
    exception_0 = exception_mixin_0.exception()

    # Testing if the output and input types are the same
    #assert isinstance(exception_0, exception_mixin_0.exception)
    assert callable(exception_0)

    test_case_0()

# Generated at 2022-06-26 03:47:39.613813
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints.blueprint import Blueprint
    blueprint_0 = Blueprint('blueprint_0',url_prefix='test')
    blueprint_0.exception(int)

# Generated at 2022-06-26 03:47:45.174448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(None, None)
    def func_0(arg_0):
        return None
    exception_mixin_0.exception(TypeError)(func_0)
    exception_mixin_0._future_exceptions = {future_exception_0}
    exception_mixin_0.exception(TypeError, apply=True)(func_0)
    return None

