

# Generated at 2022-06-26 03:37:45.973488
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception)

# Generated at 2022-06-26 03:37:47.809671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(AssertionError)(int) == int

# Generated at 2022-06-26 03:37:49.499353
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True


# Generated at 2022-06-26 03:37:50.560898
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False == False


# Generated at 2022-06-26 03:37:59.213844
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1 is not None

    exception_mixin_2 = ExceptionMixin()
    assert exception_mixin_2 is not None

    exception_mixin_3 = ExceptionMixin()
    assert exception_mixin_3 is not None

    exception_mixin_4 = ExceptionMixin()
    assert exception_mixin_4 is not None

    exception_mixin_5 = ExceptionMixin()
    assert exception_mixin_5 is not None

    exception_mixin_6 = ExceptionMixin()
    assert exception_mixin_6 is not None

    exception_mixin_7 = ExceptionMixin()
    assert exception_mixin_7 is not None

    exception_mixin_8 = ExceptionMixin()
    assert exception_mixin_8 is not None

# Generated at 2022-06-26 03:38:07.895354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage

    exceptions_0 = [InvalidUsage]
    assert hasattr(ExceptionMixin, 'exception'), "hasattr(ExceptionMixin, 'exception') returned False"

    def handler_0(*args, **kwargs):
        pass

    decorator_0 = ExceptionMixin.exception(*exceptions_0, apply=True)
    assert callable(decorator_0), "decorator_0 is not callable"

    decorated_handler_0 = decorator_0(handler_0)
    assert callable(decorated_handler_0), "decorated_handler_0 is not callable"



# Generated at 2022-06-26 03:38:14.519730
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_instance_0 = ExceptionMixin()

    # Testing if the call exception_mixin_instance_0.exception(
    #     base_route='/path') raises TypeError
    with pytest.raises(TypeError):
        exception_mixin_instance_0.exception(
            base_route='/path')



# Generated at 2022-06-26 03:38:17.555148
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def func_x(x):
        ret = x;
        return ret
    # call exception
    b0 = exception_mixin_0.exception(func_x)
    assert b0 == func_x


# Generated at 2022-06-26 03:38:26.679066
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # 1. Arrange
    _exception_mixin_0 = ExceptionMixin()

    # 2. Act
    _exception_mixin_0.exception(1)

    # 3. Assert
    assert _exception_mixin_0._future_exceptions


if __name__ == "__main__":
    print("Test ExceptionMixin testing Coverage: 100%")
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:31.944179
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_0 = ValueError()
    exceptions_0 = [exception_0]
    def handler_0(*args, **kwargs):  # noqa
        pass
    apply_0 = True
    var_0 = exception_mixin_0.exception(*exceptions_0, apply=apply_0)(handler_0)



# Generated at 2022-06-26 03:38:44.137228
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(None, None)
    assert exception_mixin_0._future_exceptions == set()
    assert future_exception_0.exceptions == None
    assert future_exception_0.handler == None
    exception_mixin_0._future_exceptions.add(future_exception_0)
    assert exception_mixin_0._future_exceptions == set([future_exception_0])
    def error_handler(request, exception):
        pass
    error_0 = exception_mixin_0.exception(error_handler)
    assert exception_mixin_0._future_exceptions == set([future_exception_0])
    with pytest.raises(NotImplementedError):
        exception_mixin_

# Generated at 2022-06-26 03:38:46.688552
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:38:52.529668
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Test case 0
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception
    def handler(request, exception):
        return 'exception'

    class HttpException(Exception): pass
    assert exception_mixin_0._apply_exception_handler(FutureException(handler, (HttpException,)))

    try:
        raise HttpException
    except HttpException:
        assert handler('request', 'exception') == 'exception'

# Generated at 2022-06-26 03:38:54.101449
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert hasattr(ExceptionMixin, 'exception'), "Method exception not found."

# Generated at 2022-06-26 03:38:59.690693
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    def handler():
        pass
    exception_mixin_0.exception()(handler)()
    exception_mixin_0.exception()(handler)(apply=True)



# Generated at 2022-06-26 03:39:00.657771
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(IndexError, FileNotFoundError)(print)

# Generated at 2022-06-26 03:39:04.577746
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint_0(ExceptionMixin):
        def exception(self, *args, **kwargs):
            return method

    exception_mixin_0 = Blueprint_0()

    exception_mixin_0.exception(exceptions=0)

    exception_mixin_0.exception(exceptions='0')

    exception_mixin_0.exception(exceptions=0, apply=True)

    exception_mixin_0.exception(exceptions='0', apply=True)

# Generated at 2022-06-26 03:39:15.290092
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic_0(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_0 = Sanic_0()

    def exception_decorator_0(handler):
        nonlocal exception_mixin_0
        nonlocal exceptions_0
        nonlocal apply_0
        future_exception_0 = FutureException(handler, exceptions_0)
        exception_mixin_0._future_exceptions.add(future_exception_0)
        if apply_0:
            exception_mixin_0._apply_exception_handler(future_exception_0)
        return handler

    exceptions_0 = tuple()

    def handler_0():
        pass

   

# Generated at 2022-06-26 03:39:16.290430
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:39:27.950956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def func_0(*args_0):
        return (args_0[0])

    def func_1(*args_1):
        return (args_1[0])

    assert exception_mixin_0.exception(func_0) is func_0
    assert exception_mixin_0.exception(func_1) is func_1
    assert exception_mixin_0.exception(func_0) is not func_1
    assert exception_mixin_0.exception(func_1) is not func_0
    assert exception_mixin_0.exception(func_0) is func_0
    assert exception_mixin_0.exception(func_1) is func_1
    assert exception_mixin_0.exception(func_0)

# Generated at 2022-06-26 03:39:36.690314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(lambda x:0)
    def exception_handler_1(exception):
        # This method is called when the decorated exception is raised
        return "exception"

    assert exception_handler_1(None) == "exception"

# Generated at 2022-06-26 03:39:39.998863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert hasattr(exception_mixin_0, "exception")


if __name__ == '__main__':
    # test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:50.687823
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestCase0:
        def test_case_0(self, *args, **kwargs):
            exceptions = []
            apply = True
            decorator_0 = TestCase0.test_case_0.test_case_0.test_case_0.test_case_0

            def handler_0(*args, **kwargs):
                return lambda: [print(data) for data in enumerate(args)]

            def decorator(handler):
                nonlocal apply
                nonlocal exceptions
                if isinstance(exceptions[0], list):
                    exceptions = tuple(*exceptions)
                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                if apply:
                    self._apply_exception_handler(future_exception)
                return handler


# Generated at 2022-06-26 03:40:00.526526
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    test_exception_0 = Exception()
    test_exception_1 = Exception()
    test_handler_0 = lambda: None
    test_handler_1 = lambda: None
    test_kwargs_0 = {"test_key": "test_val"}

    @exception_mixin_0.exception(
        test_exception_0,
        test_exception_1,
        apply=True,
        **test_kwargs_0
    )
    def test_func_0():
        pass


# Generated at 2022-06-26 03:40:05.158714
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(NotImplementedError)


# Test for method _apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-26 03:40:14.771131
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert hasattr(exception_mixin_0.exception, '__call__') is True

    # Initialize method parameters and execute the test
    args_0: list = [ZeroDivisionError, TypeError]
    kwargs_0: dict = {}
    handler_0 = lambda x: None
    decorator_0 = exception_mixin_0.exception(*args_0, **kwargs_0)(handler_0)
    assert callable(decorator_0) is True
    assert len(exception_mixin_0._future_exceptions) == 2
    assert handler_0 in exception_mixin_0._future_exceptions
    # Execute decorator and check result
    decorator_0(None)

# Generated at 2022-06-26 03:40:16.135172
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    assert exception_mixin_0._future_exceptions is not None

# Generated at 2022-06-26 03:40:27.217596
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    exception_mixin = ExceptionMixin()

    # Test 1: Ensure exception_handler is a function that returns a function.
    try:
        exception_mixin.exception(1)
    except TypeError as e:
        # Function must return a function
        assert str(e) == "exception() missing 1 required positional argument: 'apply'"
    except Exception as e:
        assert False, f"Exception {type(e).__name__} raised."

    # Test 2: Invoke exception_handler with a function
    try:
        exception_mixin.exception(test_case_0)
    except TypeError as e:
        assert False, f"TypeError should not have been raised. {str(e)}"

# Generated at 2022-06-26 03:40:36.417031
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Test case with no arguments
    test_ExceptionMixin = ExceptionMixin()
    exception_mixin_0 = test_ExceptionMixin.exception()

    # Test case with arguments
    exception_mixin_1 = test_ExceptionMixin.exception(Exception)
    exception_mixin_2 = test_ExceptionMixin.exception(Exception, apply=True)
    exception_mixin_3 = test_ExceptionMixin.exception(Exception, apply=True, )
    exception_mixin_4 = test_ExceptionMixin.exception([Exception])
    exception_mixin_5 = test_ExceptionMixin.exception([Exception], apply=True)


test_ExceptionMixin_exception()
test_case_0()

# Generated at 2022-06-26 03:40:41.436009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Add a test for method exception of class ExceptionMixin
    pass

# Generated at 2022-06-26 03:40:54.913307
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def test_method_0():
        nonlocal exception_mixin_0
        # test_method_0 begins here

        def test_inn_method_0():
            nonlocal exception_mixin_0
            exception_mixin_0.exception()

        test_inn_method_0()

    test_method_0()


# Generated at 2022-06-26 03:41:06.940092
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Test case 0
    exception_mixin_0 = ExceptionMixin()
    handler_0 = exception_mixin_0.exception(IndexError)
    # call handler_0 to see if it returns anything back
    # assert if Handler_0 is callable
    assert (callable(handler_0))

    # Test case 1
    exception_mixin_1 = ExceptionMixin()
    handler_1 = exception_mixin_1.exception(IndexError, TypeError)
    # call handler_1 to see if it returns anything back
    # assert if Handler_1 is callable
    assert (callable(handler_1))

    # Test case 2
    exception_mixin_2 = ExceptionMixin()
    handler_2 = exception_mixin_2.exception([IndexError, TypeError])
    # call handler_2 to

# Generated at 2022-06-26 03:41:14.965088
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test with one exception
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(Exception) # noqa
    assert len(exception_mixin_1._future_exceptions) == 1
    future_exception_0 = exception_mixin_1._future_exceptions.pop()
    assert future_exception_0.exceptions == (Exception, )

    # Test with a few exceptions
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception(Exception, RuntimeError, SystemExit) # noqa
    assert len(exception_mixin_2._future_exceptions) == 1
    future_exception_1 = exception_mixin_2._future_exceptions.pop()

# Generated at 2022-06-26 03:41:17.173315
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(None)


# Generated at 2022-06-26 03:41:28.025905
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException(lambda *args, **kwargs: None, Exception())
    future_exception_1 = FutureException(lambda *args, **kwargs: None, Exception())
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0._future_exceptions.add(future_exception_1)
    future_exception_2 = FutureException(lambda *args, **kwargs: None, Exception())
    exception_mixin_0._future_exceptions.add(future_exception_2)
    future_exception_3 = FutureException(lambda *args, **kwargs: None, Exception())

# Generated at 2022-06-26 03:41:30.847830
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    result = exception_mixin_0.exception(*[1])
    asser

# Generated at 2022-06-26 03:41:36.369800
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    def my_handler():
        pass
    exception_mixin_0.exception(Exception)(my_handler)
    assert isinstance(exception_mixin_0, ExceptionMixin)
    assert exception_mixin_0._future_exceptions == {FutureException(my_handler, (Exception,))}

# Generated at 2022-06-26 03:41:37.109770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:41:42.432260
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_list = [5, 5]
    test_dict = {'a': 0}
    test_bool = True
    exception_mixin_0 = ExceptionMixin()
    handler_0 = exception_mixin_0.exception(test_list, apply=test_bool)
    assert handler_0 is not None



# Generated at 2022-06-26 03:41:45.409922
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler(*args, **kwargs):
        return

    exception_mixin_0.exception(list, apply=True)(handler)


# Generated at 2022-06-26 03:42:08.749376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert len(exception_mixin_0._future_exceptions) == 0

    def test_handler_0(request, exception):
        assert request is None
        assert exception is None

    exception_mixin_0.exception(Exception)(test_handler_0)
    assert len(exception_mixin_0._future_exceptions) == 1


# Generated at 2022-06-26 03:42:09.998050
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:42:14.116745
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Constructor test case for class ExceptionMixin
    exception_mixin_0 = ExceptionMixin()

    def handler_function_0(handler_arg_0, *handler_arg_1):
        return handler_arg_0, *handler_arg_1

    assert exception_mixin_0.exception(AttributeError)(handler_function_0) == handler_function_0



# Generated at 2022-06-26 03:42:26.384860
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a class 'ExceptionMixin' for test
    class ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self.func = lambda : None
            self.is_applied = False

        def _apply_exception_handler(self, handler: FutureException):
            self.is_applied = True
            pass

    exception_mixin_0 = ExceptionMixin()

    # Test by cases
    assert exception_mixin_0.exception(ValueError)(exception_mixin_0.func) == exception_mixin_0.func
    assert exception_mixin_0.is_applied

# Generated at 2022-06-26 03:42:30.326899
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    blueprint_0 = Blueprint.constructor({})
    blueprint_0.exception(1, apply=1)
    # TODO: Why is the function called in the first place?
    # TODO: The function should be called only if the decorator is applied to
    # TODO: a function and return the same function

# Generated at 2022-06-26 03:42:36.600245
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    future_exceptions = set()
    assert exception_mixin._future_exceptions is future_exceptions
    future_exception = FutureException(lambda: 1/0, ValueError)
    future_exceptions.add(future_exception)
    assert exception_mixin._future_exceptions is future_exceptions

# Generated at 2022-06-26 03:42:38.117808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()

# Generated at 2022-06-26 03:42:40.876699
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert(exception_mixin_0._future_exceptions == set())
    assert(exception_mixin_0.__class__.__name__ == "ExceptionMixin")

# Generated at 2022-06-26 03:42:49.869905
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    @exception_mixin_1.exception(ValueError)
    def method_0():
        assert 1 == 2

    @exception_mixin_1.exception(TypeError)
    def method_1():
        try:
            method_0()
        except ValueError:
            assert 1 == 1



exception_mixin_1 = ExceptionMixin()
assert exception_mixin_1._future_exceptions == set()

test_ExceptionMixin_exception()

assert exception_mixin_1._future_exceptions == {
    FutureException(method_0, (ValueError,))
}
exception_mixin_1._future_exceptions.clear()

# Generated at 2022-06-26 03:42:56.915193
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    "# This method enables the process of creating a global exception handler"
    "# for the current blueprint under question."

    # ":param args: List of Python exceptions to be caught by the handler"
    # ":param kwargs: Additional optional arguments to be passed to the"
    #     "exception handler"

    # ":return a decorated method to handle global exceptions for any"
    #     "route registered under this blueprint."
    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception_0 = FutureException(handler, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception_0)
        if apply:
            exception_

# Generated at 2022-06-26 03:43:34.359423
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def decorator(handler):
        return handler

    def handler():
        pass
    assert exception_mixin_0.exception(handler) == decorator(handler)
    assert exception_mixin_0.exception(handler, apply=False) == decorator(handler)
    assert exception_mixin_0.exception(handler, NameError, apply=False) == decorator(handler)
    assert exception_mixin_0.exception(handler, NameError, ValueError, apply=False) == decorator(handler)
    # TODO: Fix HTMLGenerator to support conversion of list to tuple
    # assert exception_mixin_0.exception(handler, [NameError, ValueError], apply=False) == decorator(handler)

# Generated at 2022-06-26 03:43:35.853832
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_data_0 = [TypeError("example type error")]
    method_result_0 = exception_mixin_0.exception(exception_data_0, False)

    assert isinstance(method_result_0, types.FunctionType)

# Generated at 2022-06-26 03:43:37.186655
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:43:39.110889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(KeyError, True)  # type: ignore

# Generated at 2022-06-26 03:43:40.791829
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: check
    pass

# Generated at 2022-06-26 03:43:43.273364
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:43:44.607717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    result = exception_mixin_0.exception(1,2)

# Generated at 2022-06-26 03:43:49.330582
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    mock_handler = "mock_handler"
    mock_exceptions = "mock_exceptions"
    assert exception_mixin_0.exception(mock_exceptions, apply=True)(mock_handler) == mock_handler



# Generated at 2022-06-26 03:44:00.195872
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class MyException(Exception):
        pass

    class MyFutureException(FutureException):
        pass

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MyExceptionMixin, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            assert True

    exception_mixin_0 = MyExceptionMixin()
    exception_mixin_0.exception([KeyError, MyException], apply=False)
    exception_mixin_0.exception([MyException], apply=False)
    exception_mixin_0.exception(apply=False)

# Generated at 2022-06-26 03:44:03.227119
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Initialize object of class ExceptionMixin
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(Exception)

# Generated at 2022-06-26 03:45:19.200490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ConnectionError)
    exception_mixin_0.exception(exceptions=(OSError, ConnectionAbortedError), apply=True)
    exception_mixin_0.exception(exceptions=[OSError, ConnectionAbortedError])

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:45:24.043465
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # call method
    @exception_mixin_0.exception()
    def exception_decorator_0():
        exception_decorator_0.__name__

    return None

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:45:30.019100
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()
    exception_mixin_8 = ExceptionMixin()
    exception_mixin_9 = ExceptionMixin()
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception,KeyError)(lambda req, e: None)
    ret_val_0 = exception_mixin_0.exception(Exception,KeyError)(lambda req, e: None)
    ret_val_1 = exception_mixin_1.ex

# Generated at 2022-06-26 03:45:35.089336
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(FutureException)
    exception_mixin_1.exception(Exception)

# Generated at 2022-06-26 03:45:42.478184
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        class SomeSanicApp():
            pass
        sanic_app_0 = SomeSanicApp()
        sanic_app_0.listeners = set()

        class SomeBlueprint():
            def __init__(self):
                self._future_exceptions = set()
            def register(self, *args, **kwargs):
                pass
        blueprint_0 = SomeBlueprint()

        def exception_handler_0(request, exception):
            pass

        blueprint_0.exception = ExceptionMixin.exception
        blueprint_0.exception(IndexError, apply=False)(exception_handler_0)
        assert blueprint_0._future_exceptions
    except Exception as e:
        print(e)

# Generated at 2022-06-26 03:45:47.060325
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with pytest.raises(NotImplementedError, match="^.*_apply_exception_handler.*$"):
        exception_mixin_0 = ExceptionMixin()
        exception_mixin_0.exception()

# Clear exception_mixin_0
try:
    del exception_mixin_0
except NameError:
    pass

# Generated at 2022-06-26 03:45:50.480448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin_exception = exception_mixin.exception(ExpectationNotMet, apply=True)
    assert callable(exception_mixin_exception) == True

# Generated at 2022-06-26 03:45:59.306913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test for when function 'decorator' is called
    def decorator(handler):
        assert False  # Input from user
    # Test for when function 'handler' is called
    def handler(**kwargs):
        if 'args' in kwargs:
            raise Exception(kwargs['args'])
        else:
            raise Exception()
    exception_mixin_0.exception(KeyError, ValueError, apply=True)(handler)
    # Test for when function 'decorator' is called
    def decorator(handler):
        assert False  # Input from user
    # Test for when function 'handler' is called
    def handler(**kwargs):
        if 'args' in kwargs:
            raise Exception(kwargs['args'])

# Generated at 2022-06-26 03:46:06.072071
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Set up test objects
    exception_mixin_0 = ExceptionMixin()

    # Create DomainConstants object
    domain_constants_0 = DomainConstants()

    # Create object of the test class
    test_class_0 = TestClass()

    # Test exception method of class ExceptionMixin
    exception_mixin_0.exception((domain_constants_0,), apply=False)(test_class_0.test_method)
    pass


# Generated at 2022-06-26 03:46:16.513461
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def exception_decorator(handler, apply, exceptions):
        def wrapper(*args, **kwargs):
            return handler(*args, **kwargs)
        return wrapper

    class ExceptionMixin:
        def __init__(self) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            @exception_decorator(handler=exception, apply=apply, exceptions=exceptions)
            def handler(request, *args, **kwargs):
                return True

            return handler

    # testing with a valid case
    exception_mixin = ExceptionMixin()