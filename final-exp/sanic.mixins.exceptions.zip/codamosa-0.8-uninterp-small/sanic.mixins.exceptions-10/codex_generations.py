

# Generated at 2022-06-26 03:37:51.337320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()

# Generated at 2022-06-26 03:37:59.762011
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._future_exceptions = set()

    def exception_mixin_1__apply_exception_handler(future_exception):
        if not isinstance(future_exception, FutureException):
            raise TypeError

    exception_mixin_1._apply_exception_handler = exception_mixin_1__apply_exception_handler

    def handler():
        return None

    exception_mixin_1.exception(handler)()

    if not isinstance(exception_mixin_1._future_exceptions, set):
        raise AssertionError

    set_1 = exception_mixin_1._future_exceptions

    if len(set_1) != 1:
        raise AssertionError

    exception_2 = None


# Generated at 2022-06-26 03:38:01.054781
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception()

# Generated at 2022-06-26 03:38:14.165991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock

    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = MagicMock()
    future_exception_0.exceptions = tuple(str() for _ in range(6))
    future_exception_0.handler = MagicMock()
    future_exception_0.key = tuple(str() for _ in range(5))
    future_exception_0.args = (None,)
    future_exception_0.kwargs = {}
    exception_mixin_0.exception(MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock())(MagicMock())

# Generated at 2022-06-26 03:38:17.853452
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def mock_decorator(handler):
        nonlocal apply
        nonlocal exceptions
        return handler

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception = mock_decorator
    exception_mixin_1.exception(BaseException)


# Generated at 2022-06-26 03:38:21.826415
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception is not None


# Generated at 2022-06-26 03:38:32.240555
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler_0(*args, **kwargs):
        raise NotImplementedError  # noqa

    def handler_1(*args, **kwargs):
        raise NotImplementedError  # noqa

    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handler_0_1(*args, **kwargs):
        raise NotImplementedError  # noqa

    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception([IOError])
    def handler_1_1(*args, **kwargs):
        raise NotImplementedError  # noqa

    assert exception_mixin_0._future_exceptions == set()
    assert exception_mixin_0._future_exceptions != set()

# Generated at 2022-06-26 03:38:42.518794
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Assert if _apply_exception_handler is not called when apply=False
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = lambda x: None
    exception_mixin_0.exception(ValueError, apply=False)(lambda x: x)
    assert len(exception_mixin_0._future_exceptions) == 0

    # Assert if _apply_exception_handler is called when apply=True
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = lambda x: True
    exception_mixin_1.exception(ValueError, apply=True)(lambda x: x)
    assert len(exception_mixin_1._future_exceptions) == 1


# Generated test cases

# Generated at 2022-06-26 03:38:48.814773
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    exception_mixin_1 = ExceptionMixin()
    args_0 = [RuntimeError]
    exception_obj_0 = FutureException(RuntimeError)
    exception_mixin_1._future_exceptions.add(exception_obj_0)

    # act
    with(exception_mixin_1.exception(RuntimeError)):
        pass

# Generated at 2022-06-26 03:38:53.161083
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    cases = [
        (
            [
                [],
                {},
                lambda *args, **kwargs: (args, kwargs),
                None,
                None
            ]
        )
    ]

    for case in cases:
        assert case[-1] == ExceptionMixin().exception(*case[0], **case[1])(case[2])(*case[3], **case[4])

# Generated at 2022-06-26 03:39:02.736983
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def _test(**kwargs):
        exception_mixin_0 = ExceptionMixin()
        return exception_mixin_0.exception(**kwargs)

    def handler(request, exception):
        pass

    def _handler(request):
        pass

    assert _test(exceptions=[None], apply=True)(handler) == handler
    assert _test(exceptions=None, apply=False)(_handler) == _handler

# Generated at 2022-06-26 03:39:04.524183
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()



# Generated at 2022-06-26 03:39:15.254396
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest

    class ExceptionMixin_exception_TestCase(unittest.TestCase):
        def test_exception_DecoratorNotCalled(self):
            # TODO: Implement test
            # self.assertEqual(expected, exception_mixin_0.exception(*exceptions, apply=apply))
            assert False  # TODO: implement your test here

        def test_exception_DecoratorCalled(self):
            # TODO: Implement test
            # self.assertEqual(expected, exception_mixin_0.exception(*exceptions, apply=apply))
            assert False  # TODO: implement your test here


# Generated at 2022-06-26 03:39:19.249734
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_handler_0 = exception_mixin_0.exception('test case', apply=True, exceptions=None)
    assert exception_handler_0 # type: ignore
    assert exception_handler_0.handler

# Generated at 2022-06-26 03:39:24.058169
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    test_exception_0 = None

    with pytest.raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(test_exception_0)

# Generated at 2022-06-26 03:39:30.690945
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin = ExceptionMixin()
    exception_mixin._future_exceptions = set()
    exception_mixin._apply_exception_handler = mocker.MagicMock()
    exceptions = NameError

    # Exercise
    exception_handler = exception_mixin.exception(exceptions)
    exception_handler("test_exception_handler")

    # Verify
    exception_mixin._apply_exception_handler.assert_called_with("test_exception_handler")

# Generated at 2022-06-26 03:39:38.578846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException()
    future_exception_0_0 = FutureException()
    exception_mixin_0._future_exceptions = set()
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0._future_exceptions.add(future_exception_0_0)
    exception_mixin_0.exception(future_exception_0, future_exception_0_0, apply=True)



# Generated at 2022-06-26 03:39:50.257761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create an object and set it up
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._future_exceptions: Set[FutureException] = set()

    # Test case 1: method called with *exception and *apply
    # Expected output:
    #  - exception_mixin_0._future_exceptions is empty set
    #  - result is
    def exception_handler_0(exception):
        print(exception)

    result = exception_mixin_0.exception(exception_handler_0)

    assert exception_mixin_0._future_exceptions == set()
    assert result == exception_handler_0
    print("Test case 1: PASSED")

    # Test case 2: method called with *exception and apply=False
    # Expected output:
    # 

# Generated at 2022-06-26 03:40:00.489584
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    # exception_kwargs_1 = {  }
    exception_exceptions_1 = [  ]
    # exception_apply_1 = True
    exception_return_1 = exception_mixin_1.exception(*exception_exceptions_1)
    assert isinstance(exception_return_1, types.FunctionType)

    # exception_kwargs_2 = {  }
    exception_exceptions_2 = [  ]
    # exception_apply_2 = True
    exception_return_2 = exception_mixin_1.exception(*exception_exceptions_2)
    assert isinstance(exception_return_2, types.FunctionType)

    # exception_kwargs_3 = {  }
    exception_exceptions_3 = [  ]
    # exception

# Generated at 2022-06-26 03:40:12.595025
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unit_test.test_unit_exception_mixin_test.test_case_exception_mixin_test import ExceptionMixinTest
    import inspect, os

    # test case 1: check if the decorated handler is registered in _future_exceptions
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_config_exception_mixin.json"), 'r') as f:
            config = json.load(f)
            exception_mixin_1 = ExceptionMixin()
            exception_mixin_1.exception()(ExceptionMixinTest.exception_handler_0)
            assert exception_mixin_1._future_exceptions == set(config['exception_mixin_1'])
    except Exception as e:
        print

# Generated at 2022-06-26 03:40:21.828570
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # initialization
    exception_mixin_0 = ExceptionMixin()
    args_0 = None
    apply_1 = True
    kwargs_1 = None

    # function call
    decorator_2 = exception_mixin_0.exception(*args_0, apply=apply_1, **kwargs_1)
    # assert statements
    assert True


# Generated at 2022-06-26 03:40:25.138377
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    exception_mixin_0.exception([FutureException])

# Generated at 2022-06-26 03:40:35.049455
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception)
        if apply:
            exception_mixin_0._apply_exception_handler(future_exception)
        return handler

    from random import randrange
    from random import randint
    from random import choice
    from random import shuffle

    # Case 0
    exception_mixin_0.exception()

    # Case 1
    exception_mixin_0.exception("str")

    # Case 2

# Generated at 2022-06-26 03:40:39.729219
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_instance = ExceptionMixin()
    exception_mixin_instance.exception(TypeError, KeyError)

    future_exceptions = exception_mixin_instance._future_exceptions

    assert len(future_exceptions) == 1

    future_exception = next(iter(future_exceptions))

    assert type(future_exception) == FutureException
    assert next(iter(future_exception.exceptions)) == TypeError
    assert next(iter(future_exception.exceptions)) == KeyError

# Generated at 2022-06-26 03:40:48.915719
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test case 0
    exception_mixin_0 = ExceptionMixin()
    def func_0():
        def func_1():
            def func_2():
                pass
            return func_2
        return func_1
    exception_mixin_0.exception((ValueError, ZeroDivisionError), apply=True)(func_0())()
    # test case 1
    exception_mixin_1 = ExceptionMixin()
    def func_3():
        def func_4():
            def func_5():
                pass
            return func_5
        return func_4
    exception_mixin_1.exception([ValueError, ZeroDivisionError], apply=False)(func_3())()

# Generated at 2022-06-26 03:40:53.527611
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    @exception_mixin_0.exception(ZeroDivisionError)
    def exception_handler_0():
        return

    assert exception_mixin_0._future_exceptions == {FutureException(exception_handler_0, (ZeroDivisionError,))}

# Generated at 2022-06-26 03:41:05.291732
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Case 0
    # Test with the following parameters:
    #   *args = {}
    #   **kwargs = {}
    # Expected result:

    # Test with the following parameters:
    #   *args = {}
    #   **kwargs = {"apply": True}
    # Expected result:

    # Test with the following parameters:
    #   *args = {}
    #   **kwargs = {"apply": False}
    # Expected result:

    pass

if __name__ == '__main__':
    test_case_0()

    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:13.260175
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_handler_0 = None
    exceptions_0 = None
    apply_1 = True
    future_exception_0 = None
    apply_0 = True

    def function_0(handler, args, kwargs):
        nonlocal exceptions_0
        nonlocal apply_0
        nonlocal exception_handler_0
        nonlocal future_exception_0
        exception_handler_0 = handler
        future_exception_0 = FutureException(handler, args)

    def function_1(future_exception):
        nonlocal future_exception_0
        nonlocal apply_1
        assert future_exception == future_exception_0

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._future_exceptions = set()
    exception_mixin_0._apply_exception_handler

# Generated at 2022-06-26 03:41:17.709058
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    try:
        exception_mixin.exception(
            *[Exception],
            apply = True
        )
    except Exception as e:
        exception_mixin.__init__()
        pass

# Generated at 2022-06-26 03:41:19.560157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ex_mixin = ExceptionMixin()
    result = ex_mixin.exception(Exception)


# Generated at 2022-06-26 03:41:37.046157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class MockException(Exception):
        pass

    class MockFutureException(FutureException):
        pass

    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return True

    exception_mixin = MockExceptionMixin()

    def decorated_handler():
        pass

    exception_mixin.exception(MockException)(decorated_handler)
    assert exception_mixin._future_exceptions == {MockFutureException(decorated_handler, (MockException,))}

    exception_mixin._future_exceptions.clear()

    exception_mixin.exception(MockException, apply=False)(decorated_handler)
    assert exception_mixin._future_exceptions == {MockFutureException(decorated_handler, (MockException,))}

# Generated at 2022-06-26 03:41:43.877876
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinStub:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = ExceptionMixinStub()

    @exception_mixin.exception(Exception)
    def foo():
        pass
    assert len(exception_mixin._future_exceptions) != 0

# Generated at 2022-06-26 03:41:48.596133
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    try:
        exception_mixin_1.exception(Exception)
    except TypeError:
        pass
    else:
        raise AssertionError("Exception should be raised")

exception_mixin = ExceptionMixin()


# Generated at 2022-06-26 03:41:52.312704
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception(1, 2, 3)
    except NotImplementedError:
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-26 03:41:54.790633
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    class A:
        def __init__(self, *args, **kwargs) -> None:
            pass

    @exception_mixin_0.exception(A)
    def a():
        pass

    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:41:59.564105
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def test_exception_handler(request, exception):
        go_away = True


# Generated at 2022-06-26 03:42:02.525460
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    exception_mixin_0 = ExceptionMixin()
    closure_0 = exception_mixin_0.exception(
        [
            AttributeError,
            RuntimeError
        ]
    )

    # Act
    # Assert
    closure_0()


# Generated at 2022-06-26 03:42:06.838942
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception_mixin.exception(Exception)
    def exception_handler():
        pass

    exception_handler


# Generated at 2022-06-26 03:42:09.340045
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with pytest.raises(NotImplementedError):
        exception_mixin_0 = ExceptionMixin()
        exception_mixin_0.exception(0)

# Generated at 2022-06-26 03:42:11.658315
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test case 0
    print("Test case 0")
    exception_mixin_1.exception(Exception)

# Generated at 2022-06-26 03:42:28.954701
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def foo():
        pass
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(TypeError)(foo)

# Generated at 2022-06-26 03:42:33.684985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    exceptions = ("test_exception", )
    remaining_exceptions = exceptions

    apply = True

    # When
    decorator = ExceptionMixin.exception(None, *exceptions, apply = apply)

    # Then
    assert decorator(None) == None



# Generated at 2022-06-26 03:42:43.635174
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.route import Route
    from types import FunctionType
    from functools import partial

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = lambda exception: exception.handler()

    
    # Case 1: Invalid argument
    try:
        exception_mixin_1.exception('a')  # type: ignore
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == "unexpected type 'str', expected 'Exception'"

    # Case 2: Valid argument
    counter = 0

    def decorator(handler):
        nonlocal counter
        nonlocal exception_mixin_1
        counter += 1

# Generated at 2022-06-26 03:42:46.854299
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def dummy_decorator(handler):
        return handler
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception = dummy_decorator
    exception_mixin_0._future_exceptions = set()
    exception_mixin_0._apply_exception_handler = dummy_decorator

    # call the method
    exception_mixin_0.exception(Set[FutureException])



# Generated at 2022-06-26 03:42:51.170590
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def exception_handler_0():
        pass

    exception_handler_0()
    exception_0 = ExceptionMixin.exception(exception_handler_0)


# Generated at 2022-06-26 03:42:57.531709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print('\nTesting ExceptionMixin.exception')
    exception_mixin = ExceptionMixin()
    argument_exceptions = 1
    argument_apply = True

    def mock_decorator(*args, **kwargs):
        nonlocal mock_decorator
        mock_decorator.called = True

    mock_decorator.called = False
    returned_value = exception_mixin.exception(argument_exceptions,
                                               apply=argument_apply)(mock_decorator)
    assert returned_value == mock_decorator
    assert mock_decorator.called
    # __init__ creates an empty set in self._future_exceptions
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
   

# Generated at 2022-06-26 03:43:01.165684
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    ExceptionMixin.exception(exception_mixin_0)

test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:43:07.936427
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(ValueError)
    def some_handler(self, req, exception):
        return 'some_handler called'

    result = some_handler(exception_mixin_0, 1, ValueError)
    assert result == 'some_handler called'

# Generated at 2022-06-26 03:43:11.288431
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def handler():
        pass
    exception_mixin_1.exception(handler)

test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:43:16.945373
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert not hasattr(exception_mixin_0, '_apply_exception_handler')
    assert not hasattr(exception_mixin_0, 'exception')
    assert hasattr(exception_mixin_0, '_exception')
    assert not hasattr(exception_mixin_0, '_future_exceptions')

# Generated at 2022-06-26 03:43:54.903032
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception(AssertionError)
    except NotImplementedError:
        actual = 2
    else:
        actual = 0
    expected = 2
    msg = "ExceptionMixin.exception(AssertionError) raised NotImplementedError"
    assert actual == expected, msg


# Generated at 2022-06-26 03:44:01.446632
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    myerror = Exception()

    @exception_mixin_0.exception(myerror)
    def exception_handler_0():
        print("exception_handler_0 called")

    if True:
        raise myerror

if __name__ == '__main__':
    test_case_0()

    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:44:09.374209
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert isinstance(exception_mixin_1, ExceptionMixin)
    assert isinstance(exception_mixin_1._future_exceptions, set)
    assert len(exception_mixin_1._future_exceptions) == 0
    # TODO: How to test _apply_exception_handler ?
    # TODO: What about kwargs ?
    exception_mixin_1.exception(ValueError)
    assert len(exception_mixin_1._future_exceptions) == 1
    assert isinstance(exception_mixin_1._future_exceptions.pop(),
                      FutureException)
    # TODO: How to test _apply_exception_handler ?
    # TODO: What about *exceptions ?
    exception_mixin_1._

# Generated at 2022-06-26 03:44:13.515717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    try:
        exception_mixin_1.exception()
    except NotImplementedError:
        pass


test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:44:15.862415
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception_mixin_0.exception()
    def handler():
        pass



# Generated at 2022-06-26 03:44:22.564479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = test_case_0()

# Generated at 2022-06-26 03:44:27.070863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception(): # noqa

    @ExceptionMixin.exception(
        IndexError,
        IndexError,
        apply=True,
    )
    def exception_handler_0():
        pass
    assert True



# Generated at 2022-06-26 03:44:33.991782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    with raises(TypeError):
        exception_mixin_1.exception()
    with raises(TypeError):
        exception_mixin_1.exception([1, 2], [3, 4])
    with raises(TypeError):
        exception_mixin_1.exception([1, 2], 'a')
    with raises(TypeError):
        exception_mixin_1.exception(1, 0, [3, 4])
    with raises(TypeError):
        exception_mixin_1.exception(1, 2, 3, 4)

# Generated at 2022-06-26 03:44:35.435756
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:44:40.344293
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = exception_mixin_0.exception([IOError])
    assert exceptions_0 is not None
    assert exceptions_0.__name__ == "decorator"

# Generated at 2022-06-26 03:45:44.613385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass



# Generated at 2022-06-26 03:45:48.233149
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(None)
    def handler(request): return 0
    # assert handler == 0
    assert handler.exceptions == (None,)



# Generated at 2022-06-26 03:45:58.180451
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Instantiate the class to be tested
    exception_mixin_0 = ExceptionMixin()

    # Create parameters for the decorated function
    exceptions_0: list = []
    args_0 = [exceptions_0]
    kwargs_0 = {}

    # Call the decorated function and create a function to test
    @exception_mixin_0.exception(*args_0, **kwargs_0)
    def test_func_0(handler):
        pass

    # Get the FutureException object created by the decorated function
    future_exception_0: FutureException = exception_mixin_0._future_exceptions.pop()

    # Assert that the handler of the FutureException object is correct
    assert future_exception_0.handler == test_func_0

    # Assert that the exceptions of the FutureException object is correct


# Generated at 2022-06-26 03:46:00.211792
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    try:
        assert exception_mixin_1._future_exceptions.__len__() == 0
    except:
        exception_mixin_1._future_exceptions.clear()


# Generated at 2022-06-26 03:46:05.321773
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Assert the decorator returns a function
    assert callable(exception_mixin_0.exception())
    # Assert the __init__ method adds the expected items to the set
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:46:08.763132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Testing method exception of class ExceptionMixin with arguments ([], {})

    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:46:10.022642
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0 is not None

# Generated at 2022-06-26 03:46:15.136429
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception = 'exception'
    # pytest.raises(NotImplementedError, exception_mixin.exception('exception'))
    with pytest.raises(NotImplementedError):
        exception_mixin.exception('exception')
    assert exception in exception_mixin._future_exceptions.__dict__

# Generated at 2022-06-26 03:46:18.775731
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = MagicMock()

    @exception_mixin_0.exception(Exception)
    def myfunc(arg1, arg2):
        for x in range(arg2):
            yield x * arg1

    assert len(exception_mixin_0._future_exceptions) == 1

    assert exception_mixin_0._apply_exception_handler.call_count == 1

# Generated at 2022-06-26 03:46:23.464717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_0 = ExceptionMixin()

    # Testing correct type
    assert(isinstance(exception_mixin_0.exception(Exception), (FunctionType,
                                                               MethodType)))

