

# Generated at 2022-06-26 03:37:53.995507
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # ExceptionMixin instantiations
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    # ExceptionMixin methods unit tests
    def handler(self, request, exception):
        pass
    def handler(self, request, exception):
        pass
    def handler(self, request, exception):
        pass
    result = exception_mixin_0.exception(handler)
    assert True
    result = exception_mixin_1.exception(handler)
    assert True
    result = exception_mixin_2.exception(handler)
    assert True
    result = exception_mixin_3.exception(handler)

# Generated at 2022-06-26 03:37:59.591914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    try:
        exception_mixin_1.exception(Exception, apply=True)
    except NotImplementedError:
        pass
    exception_mixin_2 = ExceptionMixin()
    try:
        exception_mixin_2.exception(Exception)
    except NotImplementedError:
        pass
    exception_mixin_3 = ExceptionMixin()
    try:
        exception_mixin_3.exception(Exception, apply=False)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 03:38:11.128337
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_exception_default(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = ExceptionMixin_exception_default()
    class MyException(Exception):
        pass
    def foo():
        pass
    class MyFutureException(FutureException):
        pass

    # Test with no argument
    with pytest.raises(SyntaxError):
        exception_mixin.exception()(foo)

    # Test with invalid argument
    with pytest.raises(TypeError):
        exception_mixin.exception(MyException, 'x')(foo)
        exception_mixin.exception(1, MyException)(foo)
        exception_mixin.exception(MyException, 1)(foo)

# Generated at 2022-06-26 03:38:14.796763
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    future_exception_0 = FutureException(ValueError)
    try:
        exception_mixin_0.exception(future_exception_0)
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:38:20.972000
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(list, str, int, tuple, apply=True)
    def handler_0():
        pass

    @exception_mixin_0.exception(list)
    def handler_1():
        pass


if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:23.317584
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert not exception_mixin_0._future_exceptions


# Generated at 2022-06-26 03:38:27.208338
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(Exception)


# Generated at 2022-06-26 03:38:34.859280
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.exceptions import SanicException
    from sanic.request import Request

    class TestException(SanicException):
        status_code = 409
        message = "test_exc_message"

    bp = Blueprint("test", url_prefix="/test")

    @bp.exception(TestException)
    def exc_handler(request: Request, exception):
        assert isinstance(exception, TestException)
        return text("OK")

    @bp.route("/test-exc")
    def test_exc(request: Request):
        raise TestException

    app = Sanic("test")
    app.blueprint(bp)
    app.config.MAX_REQUEST_ARGUMENT_ITEMS = 100
    app.config.MAX_

# Generated at 2022-06-26 03:38:37.679165
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    result = exception_mixin_1.exception(Exception)(None)

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:49.750778
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from Sanic import Blueprint
    from Sanic.request import Request
    from Sanic.response import HTTPResponse
    from Sanic.response import json
    from Sanic.request import RequestParameters
    from Sanic.response import HTTPResponse
    from Sanic.response import text
    from Sanic.response import json
    from Sanic.response import html
    from Sanic.response import redirect
    from Sanic.response import stream
    from Sanic.response import file
    from Sanic.response import file_stream
    from Sanic.exceptions import InvalidUsage
    from Sanic.exceptions import ServerError
    from Sanic.exceptions import RequestTimeout
    from Sanic.exceptions import PayloadTooLarge
    from Sanic.exceptions import FileNotFound
    from Sanic.exceptions import Unauthorized

# Generated at 2022-06-26 03:38:55.293857
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(NameError, ValueError)

    exception_mixin_0.exception(NameError, ValueError, apply=False)

# Generated at 2022-06-26 03:38:58.258464
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception()


# Generated at 2022-06-26 03:39:03.063884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Parameter 'exceptions' must be a list or a tuple, not a str
    try:
        assert exception_mixin_0.exception('str')
    except TypeError:
        # TypeError: Parameter 'exceptions' must be a list or a tuple, not a str
        pass



# Generated at 2022-06-26 03:39:08.746929
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_class = type('exception_class', (ExceptionMixin,), {})

    exception_instance = exception_class()

    @exception_class.exception(Exception)
    def name_err(error):
        return error

    assert str(exception_instance.exception(Exception)) == str(name_err)



# Generated at 2022-06-26 03:39:11.730456
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = exception_mixin_0.exception(ValueError)


# Tests of calling with positional arguments only.

# Generated at 2022-06-26 03:39:13.399544
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception

# Generated at 2022-06-26 03:39:17.686609
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock

    exception_mixin_1 = ExceptionMixin()
    function_mock = Mock(name='handler')
    exception_mixin_1.exception(ValueError)(function_mock)
    assert function_mock in exception_mixin_1._future_exceptions
    assert (FutureException(function_mock, (ValueError,))
            ) in exception_mixin_1._future_exceptions

# Generated at 2022-06-26 03:39:29.247004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def test_case_1():
        exception_mixin_1 = ExceptionMixin()
        def test_handler_1():
            pass
        kwargs_1 = {}
        exceptions_1 = ()
        handler_1 = test_handler_1

# Generated at 2022-06-26 03:39:39.595874
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    # test with custom exceptions
    exception_mixin.exception(IndexError, KeyError)(print)
    assert len(exception_mixin._future_exceptions) == 1

    # test with builtin exceptions
    exception_mixin.exception(ValueError, apply=False)(print)
    assert len(exception_mixin._future_exceptions) == 2

    # test with exception class, not instance
    exception_mixin.exception(PermissionError)(print)
    assert len(exception_mixin._future_exceptions) == 3

    # test with a list of exceptions
    exception_mixin.exception([ValueError, PermissionError])(print)
    assert len(exception_mixin._future_exceptions) == 4

    # test with a tuple of exceptions


# Generated at 2022-06-26 03:39:42.778791
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()

# Generated at 2022-06-26 03:39:48.161408
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mix_in = ExceptionMixin()
    exception_mix_in.exception(Exception)

# Generated at 2022-06-26 03:39:51.367508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin_0 = ExceptionMixin.exception()
    assert isinstance(exception_mixin_0, type)

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:52.892060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(apply=True)

# Generated at 2022-06-26 03:39:55.154756
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    handler_0 = exception_mixin_0.exception()


# Generated at 2022-06-26 03:39:58.442087
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    var_0 = exception_mixin_0.exception('Exception')
    var_1 = exception_mixin_0.exception(['ValueError'])


# Generated at 2022-06-26 03:40:00.726877
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(int)


# Generated at 2022-06-26 03:40:03.888432
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:40:06.709709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # TODO: Implement testing for parameter apply
    # TODO: Implement testing for parameter *exceptions
    return

# Generated at 2022-06-26 03:40:12.760393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # testing if the method raises an exception if the handler is not a function
    with pytest.raises(TypeError):
        exception_mixin_0.exception(TypeError)(1)

    # testing if the method raises an exception if the exceptions are not a list
    with pytest.raises(TypeError):
        exception_mixin_0.exception(TypeError)(lambda: 0)

# Generated at 2022-06-26 03:40:17.467868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException()
    try:
        exception_mixin_0._apply_exception_handler(future_exception_0)
    except NotImplementedError:
        pass
    future_exception_1 = FutureException()
    try:
        exception_mixin_0._apply_exception_handler(future_exception_1)
    except NotImplementedError:
        pass
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:40:28.476345
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert len(exception_mixin_1._future_exceptions) == 0
    assert exception_mixin_1.exception


# Generated at 2022-06-26 03:40:35.314294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def decorator_0(handler_0):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception_0 = FutureException(handler_0, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception_0)
        if apply:
            exception_mixin_0._apply_exception_handler(future_exception_0)
        return handler_0

    assert True

# Generated at 2022-06-26 03:40:38.413984
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    try:
        assert type(exception_mixin_0.exception(decorator)) == type(lambda: None)
    except:
        print("Method exception of class ExceptionMixin threw an exception")

# Generated at 2022-06-26 03:40:40.098018
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_exception_0 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        assert exception_mixin_exception_0.exception()

# Generated at 2022-06-26 03:40:43.237316
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # checking that the decorator returned by exception can be called
    # as a regular Python decorator
    decorated_function = exception_mixin_0.exception(TypeError)(lambda x: x)
    assert decorated_function is None

# Generated at 2022-06-26 03:40:51.990727
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test for an existing method
    assert (exception_mixin_1._apply_exception_handler.__doc__ is not None)

    @exception_mixin_1.exception(ArithmeticError)
    def handle_my_exception():
        pass

    assert len(exception_mixin_1._future_exceptions) == 1
    assert exception_mixin_1._future_exceptions.pop() == FutureException(handle_my_exception, (ArithmeticError,))



# Generated at 2022-06-26 03:40:54.913202
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test case for the default parameter apply = True
    @exception_mixin_0.exception(Exception)
    def handler_0(*args, **kwargs):
        pass


# Generated at 2022-06-26 03:40:59.463852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Initialize arguments with example values
    exceptions = [Exception()]
    apply = False

    future_exception = exception_mixin_1.exception(exceptions=exceptions, apply=apply)

# Generated at 2022-06-26 03:41:05.238220
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    res = exception_mixin.exception(Exception)

    assert res is not None
    assert exception_mixin._future_exceptions is not None
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop() is not None

# Generated at 2022-06-26 03:41:05.909173
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:41:29.847228
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(NameError)
    future_exceptions = getattr(exception_mixin, '_future_exceptions', None)
    assert len(future_exceptions) == 1, "expected 1 but got {}".format(len(future_exceptions))
    for exception in future_exceptions:
        assert exception.handler == None, "expected None but got {}".format(exception.handler)
        assert exception.exceptions == (NameError,), "expected True but got {}".format(exception.exceptions)


# Generated at 2022-06-26 03:41:35.879914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = [TestException, IndexError, TypeError]
    handler_0 = _test_ExceptionMixin_exception()
    future_exception_0 = FutureException(handler_0, tuple(exceptions_0))
    exception_mixin_0._future_exceptions.add(future_exception_0)
    exception_mixin_0._apply_exception_handler(future_exception_0)


# Generated at 2022-06-26 03:41:44.993807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1._future_exceptions==set()
    def f():
        pass
    a=exception_mixin_1.exception()(f)
    assert len(exception_mixin_1._future_exceptions)==1
    assert a() is None
    exception_mixin_2 = ExceptionMixin()
    def f():
        pass
    a=exception_mixin_1.exception(tuple([ValueError]),apply=False)(f)
    assert len(exception_mixin_2._future_exceptions)==1
    assert a() is None


# Generated at 2022-06-26 03:41:55.118954
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Check default value of the parameter apply in method exception
    # Type check
    assert type(exception_mixin_0.exception()()) == FunctionType
    assert type(exception_mixin_0.exception()(object)) == FunctionType
    assert type(exception_mixin_0.exception(Exception)()) == FunctionType
    assert type(exception_mixin_0.exception(Exception)()) == FunctionType
    assert type(exception_mixin_0.exception(Exception)()) == FunctionType
    assert type(exception_mixin_0.exception(Exception)()) == FunctionType
    assert type(exception_mixin_0.exception(Exception)()) == FunctionType

# Generated at 2022-06-26 03:41:57.207554
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_exceptions = [FutureException(None, None)]

    class EMI(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler in test_exceptions

    EMI().exception(test_exceptions)

# Generated at 2022-06-26 03:42:02.204025
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()


# Generated at 2022-06-26 03:42:08.789909
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception()
    assert isinstance(decorator_0, types.FunctionType)
    assert decorator_0.__name__ == 'decorator'
    assert isinstance(exception_mixin_0._future_exceptions, set)

# Generated at 2022-06-26 03:42:09.726639
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(ValueError, NameError)

# Generated at 2022-06-26 03:42:13.273158
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(TypeError, apply=False)
    def func_var_0(*args, **kwargs):
        try:
            return all(*args, **kwargs)
        except TypeError:
            return None



# Generated at 2022-06-26 03:42:19.180864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def no_args(*args, **kwargs):
        return True

    def apply_arg_true(*args, **kwargs):
        return True

    def apply_arg_false(*args, **kwargs):
        return True

    # Test case where no arguments are passed in expect apply to be true
    try:
        assert exception_mixin_0.exception()(no_args)
    except Exception:
        assert False
    
    # Test case with explicit arguments passed, expect apply to be true
    try:
        assert exception_mixin_0.exception(apply=True)(apply_arg_true)
    except Exception:
        assert False
    
    # Test case with explicit arguments passed, expect apply to be false

# Generated at 2022-06-26 03:42:51.437065
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(0)


# Generated at 2022-06-26 03:42:53.264746
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global exception_mixin_0
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()


# Generated at 2022-06-26 03:43:00.951109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def decorator(handler):
        return handler

    exception_mixin_1 = ExceptionMixin()
    decorated_method = exception_mixin_1.exception(decorator)

    try:
        decorated_method(exception_mixin_1.__init__)
        assert True
    except AssertionError:
        assert False, "Unit test for method exception of class ExceptionMixin has failed"

# Generated at 2022-06-26 03:43:04.654416
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(*[1])
    exception_mixin.exception(1)
    exception_mixin.exception(1,2,3)
    exception_mixin.exception(1,2,3,4)
    exception_mixin.exception([1,2,3,4])
    exception_mixin.exception(apply=False)
    exception_mixin.exception(1, 2, 3, apply=False)

# Generated at 2022-06-26 03:43:08.959703
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def function_handler(handler):
        handler.__name__ = 'function_handler'
        return handler
    assert function_handler(exception_mixin_0.exception(IndexError, IndexError, apply=True)) == exception_mixin_0.exception

# Generated at 2022-06-26 03:43:18.336444
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    exception_mixin_0.exception([FutureException])
    exception_mixin_0.exception([FutureException])
    exception_mixin_0.exception([FutureException], apply=False)
    exception_mixin_0.exception([FutureException], apply=False)
    exception_mixin_0.exception([FutureException])
    exception_mixin_0.exception([FutureException])
    exception_mixin_0.exception([FutureException], apply=False)
    exception_mixin_0.exception([FutureException])
    exception_mixin_0.exception([FutureException], apply=False)

# Generated at 2022-06-26 03:43:28.359600
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # TODO: Test not implemented
    # Test to see if the method is called
    # Test to see if object is of type function
    # Test to see if the method receives parameter *exceptions
    # Test to see if the method receives parameter apply=True
    # Test to see if the decorator returns a method
    # Test to see if parameter handler is assign to the decorator method
    # Test to see if exceptions is of type list
    # Test to see if exceptions is of type tuple
    # Test to see if object is of type set
    # Test to see if object is of type FutureException
    # Test to see if apply is of type bool
    # Test to see if the decorator method is called

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 03:43:30.739399
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler_0():
        pass

    exception_mixin_0.exception(Exception)(handler_0)

    assert exception_mixin_0._future_exceptions is not None

# Generated at 2022-06-26 03:43:33.637900
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    received_value = None
    expected_value = None
    # exception_mixin_0 = ExceptionMixin()
    # received_value = exception_mixin_0.exception(None)
    assert received_value == expected_value

# Generated at 2022-06-26 03:43:42.164485
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = mock.Mock()

    @exception_mixin_0.exception('Text', apply=True)
    def handler(request, exception):
        pass

    exception_mixin_0._apply_exception_handler.assert_not_called()
    # assertion: the function handler is not called, since there is no event
    handler(None, None)

# Generated at 2022-06-26 03:44:50.322397
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert not hasattr(exception_mixin_0, "exception")


# Generated at 2022-06-26 03:44:52.084761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Implement the test.
    raise NotImplementedError("Test not implemented.")

# Generated at 2022-06-26 03:45:02.391890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test case for exception method
    class ExceptionMixin0(ExceptionMixin):
        pass

    exception_mixin_0 = ExceptionMixin0()
    assert exception_mixin_0._future_exceptions == set()

    # test decorator
    @exception_mixin_0.exception(exceptions=(RuntimeError,))
    def handler(error):
        assert isinstance(error, RuntimeError)
    assert exception_mixin_0._future_exceptions == {
        FutureException(handler, (RuntimeError,))}

    # test apply
    assert exception_mixin_0._future_exceptions == {
        FutureException(handler, (RuntimeError,))}

    exception_mixin_0._apply_exception_handler(
        FutureException(handler, (RuntimeError,)))
    assert exception_mixin_0._

# Generated at 2022-06-26 03:45:03.644987
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(apply=True)

# Generated at 2022-06-26 03:45:08.743554
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert type(exception_mixin_0.exception(0)) == type(_exception_decorator_0_)
    assert type(exception_mixin_0.exception([0])) == type(_exception_decorator_0_)


# Generated at 2022-06-26 03:45:11.674798
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        exception_mixin_0 = ExceptionMixin()
        def handler():
            pass
        exception_mixin_0.exception(handler)
    except Exception as e:
        assert type(e) == NotImplementedError

# Generated at 2022-06-26 03:45:17.641350
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        pass
    def decorator():
        nonlocal handler
        return handler
    if True:
        future_exception_0 = FutureException(handler, ())
        exception_mixin_0._future_exceptions.add(future_exception_0)
    assert exception_mixin_0.exception(handler) == handler

# Generated at 2022-06-26 03:45:21.311164
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    class Exception_0:
        def __init__(self):
            self.args = ['Exception_0']

    with pytest.raises(NotImplementedError):
        exception_mixin_0.exception()(Exception_0)

# Generated at 2022-06-26 03:45:24.465433
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def handler(request, exception):
        pass

    exception_mixin_0 = ExceptionMixin()
    exceptions = (IndexError, )
    result = exception_mixin_0.exception(*exceptions)(handler)

    assert result == handler

# Generated at 2022-06-26 03:45:26.765236
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handler_0(request, exception):
        return ""

    return 1
