

# Generated at 2022-06-26 03:37:53.546537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:37:56.456647
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception(ExceptionMixin)
    def handler_0():
        return
    handler_0 = decorator_0(handler_0)

# Generated at 2022-06-26 03:38:01.935902
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception), \
        'ExceptionMixin.exception is not callable'
    assert hasattr(ExceptionMixin.exception, '__code__'), \
        'ExceptionMixin.exception does not have __code__ attribute'
    assert hasattr(ExceptionMixin.exception, '__func__'), \
        'ExceptionMixin.exception does not have __func__ attribute'
    assert hasattr(ExceptionMixin.exception, '__closure__'), \
        'ExceptionMixin.exception does not have __closure__ attribute'
    assert hasattr(ExceptionMixin.exception, '__name__'), \
        'ExceptionMixin.exception does not have __name__ attribute'

# Generated at 2022-06-26 03:38:04.547782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception()

# Generated at 2022-06-26 03:38:15.844512
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Check that a method decorator is returned
    assert callable(ExceptionMixin.exception)
    # Check that the method decorator accepts exceptions and **kwargs
    decorator = ExceptionMixin.exception(Exception)
    assert callable(decorator)
    # Check that the method decorator accepts keyword args
    decorator = ExceptionMixin.exception(Exception, apply=False)
    assert callable(decorator)
    # Check that the method decorator accepts exceptions from a list
    decorator = ExceptionMixin.exception(Exception, [FutureWarning])
    assert callable(decorator)
    # Check that the method decorator accepts keyword args and exceptions
    # from a list
    decorator = ExceptionMixin.exception(Exception, [FutureWarning], apply=False)
    assert callable(decorator)

# Generated at 2022-06-26 03:38:17.780086
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception("Exception")


# Generated at 2022-06-26 03:38:27.077967
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    future_exception_1 = FutureException(lambda : None, [])
    exception_mixin_1._future_exceptions.add(future_exception_1)
    assert exception_mixin_1._future_exceptions == {future_exception_1}
    exception_mixin_1._apply_exception_handler(future_exception_1)
    assert exception_mixin_1._future_exceptions == {future_exception_1}

# Generated at 2022-06-26 03:38:33.826173
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_exception_0(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    exception_mixin_exception_0 = ExceptionMixin_exception_0()

    @exception_mixin_exception_0.exception(1,2,3)
    def fun_0(param_0):
        return param_0
    fun_0(exception_mixin_exception_0)



# Generated at 2022-06-26 03:38:35.281861
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()



# Generated at 2022-06-26 03:38:46.261840
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    
    with pytest.raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(FutureException(lambda: None, ()))

    exception_mixin_1 = TestExceptionMixin()

    assert exception_mixin_1._future_exceptions == set()
    
    with pytest.raises(NotImplementedError):
        exception_mixin_1._apply_exception_handler(FutureException(lambda: None, ()))

    assert exception_mixin_1.exception(lambda: None, ()) is not None

    exception_mixin_2 = TestExceptionMixin()

    assert exception_mixin_2._future_exceptions == set()

    with pytest.raises(NotImplementedError):
        exception_mix

# Generated at 2022-06-26 03:38:53.375017
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    test_set = set()
    test_set.add(Exception)
    test_set.add(BaseException)
    assert test_set == set(exception_mixin_0.exception(Exception, BaseException)(lambda handler: 0))
    exception_mixin_0._apply_exception_handler(lambda handler: 1)

# Generated at 2022-06-26 03:38:56.306786
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    try:
        assert exception_mixin.exception
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 03:39:00.657346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert hasattr(exception_mixin_1, 'exception')
    assert callable(getattr(exception_mixin_1, 'exception'))

# Generated at 2022-06-26 03:39:02.513461
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ValueError, apply=True)

# Generated at 2022-06-26 03:39:11.931855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    #case 1, no error
    try:
        @exception_mixin_0.exception(TypeError, ValueError)
        def handler(request, exception):
            print("handling ", exception)

    except TypeError:
        assert True

    except:
        assert False
    else:
        assert True

    #case 2,  error
    try:
        @exception_mixin_0.exception(1, 2)
        def handler(request, exception):
            print("handling ", exception)

    except TypeError:
        assert True
    except:
        assert False
    else:
        assert False

# Generated at 2022-06-26 03:39:19.095512
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    def mock_FutureException(handler, exceptions, name=None, order=None):
        return 'FutureException(handler={}, exceptions={}, name={}, order={})'.format(handler, exceptions, name, order)

    def mock_set_add(item):
        return 'set.add({})'.format(item)

    FutureException_patch = patch('sanic.models.futures.FutureException', mock_FutureException)
    set_add_patch = patch('set.add', mock_set_add)

    with FutureException_patch as mock_FutureException, set_add_patch as mock_set_add:
        # Test case with exception = Exception, apply = False
        result = exception_mixin_1.exception(Exception)(lambda: None)

# Generated at 2022-06-26 03:39:23.303096
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # assertion
    exception_mixin_1 = ExceptionMixin()
    assert_equals(exception_mixin_1.exception, exception_mixin_1._exception)

# Generated at 2022-06-26 03:39:25.938053
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Call ExceptionMixin.exception method of class ExceptionMixin
    future_exception = exception_mixin_0.exception()

# Generated at 2022-06-26 03:39:36.392790
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.utils import sanic_endpoint_test
    from sanic.exceptions import InvalidUsage
    from sanic.models.futures import FutureException
    from functools import partial

    class ExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa


# Generated at 2022-06-26 03:39:41.393426
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def exception_handler_0(request, err):
        return (request, err)

    exception_mixin_0.exception([Exception], apply=True)(exception_handler_0)
    try:
        int("a")
    except Exception as e:
        assert exception_mixin_0._future_exceptions.pop().handler(None, e) == (None, e)


# Generated at 2022-06-26 03:39:52.838669
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_0(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self.x = "abc"
            self.y = "def"
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    
    import typing
    from sanic.models.definitions import FutureException
    
    exception_mixin_0 = ExceptionMixin_0()
    assert exception_mixin_0.x == "abc"

    def decorator(handler):
        return handler
    
    #exception_mixin_0.exception(decorator)

test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:01.342325
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1: ExceptionMixin = ExceptionMixin()

    @exception_mixin_1.exception(NameError)
    def exception_handler_0(request, err):
        return "this is a handler for exception (NameError)"

    @exception_mixin_1.exception([TypeError, ValueError])
    def exception_handler_1(request, err):
        return "this is a handler for exception (TypeError, ValueError)"

    assert exception_handler_0("request", "err") == "this is a handler for exception (NameError)"
    assert exception_handler_1("request", "err") == "this is a handler for exception (TypeError, ValueError)"

# Generated at 2022-06-26 03:40:07.606224
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        exception_mixin_1 = ExceptionMixin()
        exception_mixin_1._future_exceptions = set()
        exception_mixin_1.exception(1, 2)
    except NotImplementedError as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-26 03:40:14.336077
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    if __debug__:
        exception_mixin_0 = ExceptionMixin()
        future_exception_0 = FutureException(exception_mixin_0, Exception)
        exception_mixin_0._future_exceptions.add(future_exception_0)
        exception_mixin_0._apply_exception_handler(future_exception_0)
        exception_mixin_0.exception(Exception)




if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:25.019448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()
    exception_mixin_8 = ExceptionMixin()
    exception_mixin_9 = ExceptionMixin()
    exception_mixin_10 = ExceptionMixin()
    exception_mixin_11 = ExceptionMixin()
    exception_mixin_12 = ExceptionMixin()
    exception_mixin_13 = ExceptionMixin()
    exception_mixin_14 = ExceptionMixin()
    exception_mixin_15 = ExceptionMixin()

# Generated at 2022-06-26 03:40:29.766556
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(request, exception):
        return request, exception
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(ValueError)(handler)
    assert len(exception_mixin_1._future_exceptions) == 1
    assert not exception_mixin_1._future_exceptions.pop().apply

# Generated at 2022-06-26 03:40:34.414241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def func_1(handler):
        pass

    exception_mixin_1.exception(func_1)
    # assert exception_mixin_1._future_exceptions[0].handler == func_1
    # assert exception_mixin_1._future_exception[0].exception == ()



# Generated at 2022-06-26 03:40:36.847305
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exc_handler_1 = ExceptionMixin.exception(exception_mixin_1, None)
    assert callable(exc_handler_1)

# Generated at 2022-06-26 03:40:38.378762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Call method exception of class ExceptionMixin
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:40:41.341091
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from inspect import signature

    exception_mixin_0 = ExceptionMixin()

    assert len(signature(exception_mixin_0.exception).parameters) == 3
    assert len(exception_mixin_0._future_exceptions) == 0

# Unit test to check if ExceptionMixin._apply_exception_handler raises
# an error

# Generated at 2022-06-26 03:40:54.521485
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    values = (
        "hello",
        "world",
    )
    a, b = values
    assert_equal(exception_mixin_0.exception(a, b) is None, True)


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()
    print('done')

# Generated at 2022-06-26 03:41:06.273722
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert len(exception_mixin._future_exceptions) == 0
    assert len(exception_mixin.exception()) == 1
    assert len(exception_mixin._future_exceptions) == 0
    assert len(exception_mixin.exception(apply=False)) == 1
    assert len(exception_mixin._future_exceptions) == 0
    assert len(exception_mixin.exception([''])) == 1
    assert len(exception_mixin._future_exceptions) == 0
    assert len(exception_mixin.exception(['', ...], apply=False)) == 1
    assert len(exception_mixin._future_exceptions) == 0

# Generated at 2022-06-26 03:41:15.772149
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorated_method = exception_mixin_0.exception()
    assert decorated_method is None
    assert exception_mixin_0._future_exceptions is not None
    assert isinstance(exception_mixin_0._future_exceptions, set)
    future_exception_0 = FutureException(None, None)
    exception_mixin_0._future_exceptions.add(future_exception_0)
    decorated_method = exception_mixin_0.exception(None)
    assert decorated_method is None
    assert exception_mixin_0._future_exceptions is not None
    assert isinstance(exception_mixin_0._future_exceptions, set)
    future_exception_1 = FutureException(None, None)
    exception_mixin

# Generated at 2022-06-26 03:41:21.387217
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        pass

    def exception_handler_0(handler):
        assert handler() is None
        return handler

    exception_mixin_0.exception()(handler)
    exception_mixin_0.exception(exception_handler_0)(handler)

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:41:27.930610
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 1: No exception handler applied to the instance
    exception_mixin_1 = ExceptionMixin()
    assert len(exception_mixin_1._future_exceptions) == 0

    # Case 2: Exception handler applied to the instance
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception(ValueError)(print)
    assert len(exception_mixin_2._future_exceptions) == 1

# Generated at 2022-06-26 03:41:37.481336
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    class Exc0(Exception):
        pass
    class Exc1(Exception):
        pass
    assert ExceptionMixin is not None
    def test_case_0(exception_mixin_0):
        def handler0():
            raise Exc0
        exception_mixin_0.exception(Exc0)(handler0)
    def test_case_1(exception_mixin_0):
        def handler1():
            raise Exc1
        exception_mixin_0.exception([Exc1, Exc0])(handler1)
    test_case_0(exception_mixin_0)
    test_case_1(exception_mixin_0)

# Generated at 2022-06-26 03:41:41.862459
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Input Parameters
    exception_mixin_1 = ExceptionMixin()
    exceptions = "value"
    apply = True

    # Invoke method
    result = exception_mixin_1.exception(exceptions, apply)
    assert result is not None

# Generated at 2022-06-26 03:41:52.313881
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_list_0 = []
    def f_0(x, y, z=0, *args, **kwargs):
        return x + y + z
    def f_1(x, y, z=0, *args, **kwargs):
        return x
    try:
        exception_list_0.append(ExceptionMixin)
    except:
        exception_list_0.append(Exception)
    else:
        exception_list_0.append(None)
    try:
        exception_mixin_0.exception([], apply=True)(f_0)
    except:
        exception_list_0.append(Exception)
    else:
        exception_list_0.append(None)

# Generated at 2022-06-26 03:41:59.611956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureException0:
        def __init__(self, handler, exceptions):
            self.handler = handler
            self.exceptions = exceptions

    # Make sure exception is decorated
    mock_app = MagicMock()
    exception_mixin_0 = ExceptionMixin(mock_app)
    mock_render = MagicMock()
    mock_render.__name__ = "mock_render"
    mock_render.__doc__ = "doc mock_render"

    exception_mixin_0.exception(Exception)(mock_render)

    # Make sure there is an exception handler
    assert len(exception_mixin_0._future_exceptions) == 1

    # Make sure the exception handler has the right information
    expected_exception = FutureException0(mock_render, (Exception,))
    actual_exception

# Generated at 2022-06-26 03:42:10.289642
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    exception_mixin_0 = ExceptionMixin()
    def handler_1():
        return 0
    exception_mixin_0.exception("Exception_0")(handler_1)
    exception_mixin_0.exception("Exception_1")(handler_1)
    exception_mixin_0.exception("Exception_0", "Exception_1")(handler_1)
    exception_mixin_0.exception("Exception_0", "Exception_1")(handler_1)
    exception_mixin_0.exception()(handler_1)
    exception_mixin_0.exception()(handler_1)
    exception_mixin_0.exception([ "Exception_0", "Exception_1" ], apply=True)(handler_1)

# Generated at 2022-06-26 03:42:25.449250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:42:29.701014
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        # Setup
        exception_mixin_0 = ExceptionMixin()
        # Action
        res = exception_mixin_0.exception(*[])
        # Verification
        assert res is not None

    except Exception as e:
        print(e)
        raise e


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:38.582997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def function_0(*args, **kwargs):
        nonlocal exception_mixin_0
        return exception_mixin_0.exception(*args, **kwargs)
    
    
    assert function_0(KeyError) is not None
    exception_mixin_1 = ExceptionMixin()
    def function_1(*args, **kwargs):
        nonlocal exception_mixin_1
        return exception_mixin_1.exception(*args, **kwargs)
    
    
    assert function_1(IndexError) is not None

# Generated at 2022-06-26 03:42:46.897017
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception._t_func_param_exception_0 = tuple([Exception])
    exception_mixin_0.exception._t_func_param_apply_1 = bool
    @exception_mixin_0.exception(Exception)  # noqa
    def function_0(self):
        raise Exception  # noqa
    function_0(exception_mixin_0)
    assert exception_mixin_0._future_exceptions.size == 1


# Generated at 2022-06-26 03:42:56.151828
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_0 = ExceptionMixin()

    # Testing
    @exception_mixin_0.exception(Exception)
    def function_0():
        print('Function 0')

    # Unit test for method apply_future_exception of class ExceptionMixin
    def test_ExceptionMixin_apply_future_exception():
        # Setup
        exception_mixin_0 = ExceptionMixin()
        future_exception_0 = exception_mixin_0.exception(Exception)(function_0)

        # Testing
        exception_mixin_0._apply_exception_handler(future_exception_0)

    test_ExceptionMixin_apply_future_exception()

test_ExceptionMixin_exception()
test_case_0()

# Generated at 2022-06-26 03:42:59.884211
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()

    assert a.exception(Exception) == None

# Generated at 2022-06-26 03:43:02.068615
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    exception_mixin_0.exception(NameError, SyntaxError)

    exception_mixin_0.exception([NameError, SyntaxError])

# Generated at 2022-06-26 03:43:05.806435
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(AttributeError, apply=True)

# Generated at 2022-06-26 03:43:12.932913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def f_0(arg):
        pass

    @exception_mixin_0.exception((Exception))
    def f_0():
        pass

    exception_mixin_0._future_exceptions = set()
    exception_mixin_0.exception(Exception).__call__(f_0)
    exception_mixin_0.exception((Exception)).__call__(f_0)

# Generated at 2022-06-26 03:43:15.301923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0.exception(), Callable)

# Generated at 2022-06-26 03:43:50.299467
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(exceptions= [Exception], apply= True)
    def handler():
        pass

if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:43:56.534253
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def func():
        return None
    # testing if the method returns a function
    if(callable(exception_mixin_0.exception(func))):
        print("Method exception of ExceptionMixin returns a function")
    else:
        print("Method exception of ExceptionMixin failed")

if __name__ == '__main__':
    test_ExceptionMixin_exception()
    test_case_0()

# Generated at 2022-06-26 03:44:02.347757
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler

    def handler(test_response, *args):
        raise NotImplementedError

    assert (exception_mixin_0.exception()(handler) == decorator(handler))


# Generated at 2022-06-26 03:44:07.460984
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0.exception(), collections.abc.Callable)
    assert isinstance(exception_mixin_0.exception(), collections.abc.Callable)
    assert isinstance(exception_mixin_0.exception(), collections.abc.Callable)
    assert isinstance(exception_mixin_0.exception(), collections.abc.Callable)

# Generated at 2022-06-26 03:44:11.281615
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create an object
    exception_mixin_0 = ExceptionMixin()

    # Test the method
    try:
        t = ExceptionMixin.exception(exception_mixin_0, IndexError, apply=True)
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:44:18.403180
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == (ValueError,)
            assert handler.handler(ValueError("test error"))
            assert handler.handler.__name__ == "handler"

    exception_mixin_1 = TestExceptionMixin()
    handler = exception_mixin_1.exception(ValueError)[lambda e: e]  # @exception(ValueError)
    assert handler.__name__ == "handler"

# Generated at 2022-06-26 03:44:29.773749
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception = Exception()
    exception_mixin_0 = ExceptionMixin()

    def decorator_0(handler):
        return handler

    def exception_0(*args, **kwargs):
        pass

    def exception_1(*args, **kwargs):
        pass

    def exception_2(*args, **kwargs):
        pass

    def exception_3(*args, **kwargs):
        pass

    def exception_4(*args, **kwargs):
        pass

    def exception_5(*args, **kwargs):
        pass

    def exception_6(*args, **kwargs):
        pass

    def exception_7(*args, **kwargs):
        pass

    def exception_8(*args, **kwargs):
        pass

    def exception_9(*args, **kwargs):
        pass


# Generated at 2022-06-26 03:44:37.614171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert not exception_mixin_1._future_exceptions

    def handler_1():
        pass

    exception_mixin_1.exception(handler_1)

    assert len(exception_mixin_1._future_exceptions) == 1

    def handler_2():
        pass

    exception_mixin_1.exception(handler_2)

    assert len(exception_mixin_1._future_exceptions) == 2

# Generated at 2022-06-26 03:44:40.725170
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(ValueError)
    def handle_value_error(request, exception):
        return

    assert exception_mixin_1.exception
    assert handle_value_error

# Generated at 2022-06-26 03:44:51.576384
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    result_0 = exception_mixin_0.exception(
        *[Exception], *[], **{"apply": True}
    )
    assert isinstance(result_0, types.FunctionType)
    assert len(exception_mixin_0._future_exceptions) == 1
    future_exception_0 = exception_mixin_0._future_exceptions.pop()
    assert future_exception_0.handler == result_0
    assert tuple(future_exception_0.exceptions) == (Exception,)
    result_1 = exception_mixin_0.exception(
        *[Exception], *[], **{"apply": False}
    )
    assert isinstance(result_1, types.FunctionType)

# Generated at 2022-06-26 03:45:59.802065
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception = exception_mixin_0.exception(ArgumentError)
    print(future_exception)
    return future_exception

if __name__ == "__main__":
  test_exception_mixin_0 = test_case_0()
  test_ExceptionMixin_exception_0 = test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:46:03.733886
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_11 = ExceptionMixin()
    exception_mixin_11._apply_exception_handler(exception_mixin_11)

# Generated at 2022-06-26 03:46:10.253909
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        return
    ret = exception_mixin_0.exception(0, apply=True)(handler)
    print(ret)
    if (not (isinstance(exception_mixin_0._future_exceptions, set))):
        print("False positive at line 14")
    if (not (isinstance(ret, function))):
        print("False positive at line 16")


# Generated at 2022-06-26 03:46:16.676416
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator = exception_mixin_0.exception(SystemError, apply=True)
    def handler():
        pass

    decorated_handler = decorator(handler)
    assert decorated_handler == handler
    assert len(exception_mixin_0._future_exceptions) == 1
    future_exception = exception_mixin_0._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (SystemError,)

# Generated at 2022-06-26 03:46:18.459517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    arg_0 = [Exception]
    def _decorator_function_0(): pass
    exception_mixin_0.exception(*arg_0)(_decorator_function_0)

# Generated at 2022-06-26 03:46:29.054365
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_handler_0: FutureException

    @exception_mixin_0.exception(Exception)
    def handle_exception_with_no_apply_0(request, exception):
        return f"Here's an exception: {exception}"

    assert exception_mixin_0._future_exceptions == {exception_handler_0}

    @exception_mixin_0.exception(ValueError, apply=False)
    def handle_exception_with_no_apply_1(request, exception):
        return f"Here's an exception: {exception}"


# Generated at 2022-06-26 03:46:38.246212
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0_exception_0 = exception_mixin_0.exception("exception_mixin_0_exception_0")
    exception_mixin_0_exception_0("exception_mixin_0_exception_0")
    exception_mixin_0_exception_1 = exception_mixin_0.exception("exception_mixin_0_exception_1", [("exception_mixin_0_exception_1_arg_0")])
    exception_mixin_0_exception_1("exception_mixin_0_exception_1")
    exception_mixin_0_exception_2 = exception_mixin_0.exception(["exception_mixin_0_exception_2"])

# Generated at 2022-06-26 03:46:39.898639
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    function_0 = lambda: None
    function_0 = exception_mixin_0.exception(function_0)

# Generated at 2022-06-26 03:46:50.129558
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # obj -> instance of ExceptionMixin class
    obj = ExceptionMixin()
    # 1st arg of exception method
    arg_0 = "test_1"
    # 2nd arg of exception method
    arg_1 = "test_2"
    # 3rd arg of exception method
    arg_2 = "test_3"

    # calling exception method
    try:
        # t1 -> reference variable to decorator
        t1 = obj.exception(arg_0, apply=True)
        # t2 -> reference variable to decorator
        t2 = obj.exception(arg_1, arg_2, apply=True)
    except Exception as e:
        assert False, e


# Generated at 2022-06-26 03:46:52.168149
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(apply=True)
    def handler():
        pass

    handler()