

# Generated at 2022-06-26 03:37:54.561790
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # TODO implement this test
    assert exception_mixin_0 is not None, 'This assertion fails'


# Generated at 2022-06-26 03:37:57.544292
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    decorator_0 = exception_mixin_0.exception(list)
    def handler(request):
        return request.app

    decorator_0(handler)

# Generated at 2022-06-26 03:37:59.648481
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    Exception

# Generated at 2022-06-26 03:38:03.703786
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    try:
        assert test_ExceptionMixin_exception.__annotations__ == {}
    except AssertionError:
        pytest.fail(f"Annotation test for method exception failed for class ExceptionMixin")

# Generated at 2022-06-26 03:38:15.169774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)
    exception_mixin_0.exception(Exception)
    exception_mixin_0.exception(Exception, Exception)
    exception_mixin_0.exception(Exception, apply=True)
    exception_mixin_0.exception([Exception])

# Generated at 2022-06-26 03:38:20.685344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def handler_2():
        pass
    def handler_3():
        pass
    def handler_4():
        pass
    exception_mixin_1.exception(handler_2, handler_3, handler_4)
# Test cases
# test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:24.191133
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def _decorator_function_0(handler):
        return handler
    handler_0 = _decorator_function_0(lambda: _decorator_function_0)

# Generated at 2022-06-26 03:38:28.729276
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def test_function_handler_0():
        pass

    exception_mixin_0.exception(test_function_handler_0)



# Generated at 2022-06-26 03:38:39.878067
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception())
    assert callable(exception_mixin_0.exception(Exception))
    assert callable(exception_mixin_0.exception([Exception]))
    assert callable(exception_mixin_0.exception(Exception, apply=False))
    assert callable(exception_mixin_0.exception([Exception], apply=False))
    assert callable(exception_mixin_0.exception(
        (Exception,), apply=False))

# Generated at 2022-06-26 03:38:46.595896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler0():
        return
    def exceptions0():
        return
    def apply0():
        return
    def return_value0():
        return
    exception_mixin_0.exception(exceptions0(),apply=apply0()).__call__(handler0())
    assert exception_mixin_0.exception(exceptions=exceptions0(),apply=apply0()).__call__(handler0()) == return_value0()

# Generated at 2022-06-26 03:38:51.226269
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception()
    def handler_0():
        pass


# Generated at 2022-06-26 03:38:54.479585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #exception_mixin_0 = ExceptionMixin()
    #decorator_0 = exception_mixin_0.exception()

    print("WTF")

# Generated at 2022-06-26 03:38:58.164409
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()
    exception_mixin_0.exception(apply = False)

# Generated at 2022-06-26 03:39:09.273674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin
    """
    exception_mixin_0 = ExceptionMixin()  # type: ExceptionMixin
    assert exception_mixin_0._future_exceptions == set()

    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()

    @exception_mixin_0.exception(AttributeError, apply=False)
    def exception_handler_0():
        pass
    assert isinstance(exception_handler_0, FutureException)

    @exception_mixin_0.exception([KeyError, AttributeError], apply=False)
    def exception_handler_1():
        pass
    assert isinstance(exception_handler_1, FutureException)
    assert exception_handler_1.handler is exception_

# Generated at 2022-06-26 03:39:17.717359
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()

    assert len(exception_mixin_0._future_exceptions) == 0
    assert len(exception_mixin_1._future_exceptions) == 0

    exception_mixin_0.exception(Exception)
    exception_mixin_0.exception(PermissionError)

    assert len(exception_mixin_0._future_exceptions) == 2
    assert len(exception_mixin_1._future_exceptions) == 0

    exception_mixin_1.exception(Exception)
    exception_mixin_1.exception(PermissionError)

    assert len(exception_mixin_0._future_exceptions) == 2

# Generated at 2022-06-26 03:39:29.247587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception()
    def function_handler_0():
        pass

    @exception_mixin_0.exception()
    def function_handler_1():
        pass

    @exception_mixin_0.exception([])
    def function_handler_2():
        pass

    @exception_mixin_0.exception([])
    def function_handler_3():
        pass


# Generated at 2022-06-26 03:39:32.567478
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception(None))


if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:41.806147
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:39:48.758098
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(IndexError)
    def handler():
        pass

    future_exception_0 = exception_mixin_0._future_exceptions.pop()
    assert isinstance(future_exception_0, FutureException)
    assert len(exception_mixin_0._future_exceptions) == 0



# Generated at 2022-06-26 03:39:50.508896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)
    #  assert(False)
    return

# Generated at 2022-06-26 03:39:59.679150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = MagicMock()

    # Act
    exception_mixin_1.exception(Exception)

    # Assert
    exception_mixin_1._apply_exception_handler.assert_called_once()
    assert len(exception_mixin_1._future_exceptions) == 1

# Generated at 2022-06-26 03:40:11.750666
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class exception_mixin_1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)
            self.exception_handler_invoked = False
            self.future_exceptions_0 = FutureException(self.foo, (KeyError,))


        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler_invoked = True

            # Assert
            assert handler in self._future_exceptions
            assert handler is self.future_exception_0


        def foo(self, *args, **kwargs):
            pass

    exception_mixin_1 = exception_mixin_1()


# Generated at 2022-06-26 03:40:18.651148
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    exception_mixin_0 = ExceptionMixin()


    def f_1():
        pass


    future_exception_0 = FutureException(f_1, ())
    assert issubclass(future_exception_0.__class__, FutureException)

    exception_mixin_0._apply_exception_handler(future_exception_0)
    assert exception_mixin_0._future_exceptions == {future_exception_0}

    def f_2():
        pass


    future_exception_1 = FutureException(f_2, ())
    assert issubclass(future_exception_1.__class__, FutureException)

    exception_mixin_0._apply_exception_handler(future_exception_1)
    assert exception_

# Generated at 2022-06-26 03:40:24.342934
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(ValueError)
    def exception_handler_0(request, exception, *args, **kwargs):
        pass

    exception_mixin_0._apply_exception_handler(exception_handler_0._future_exception)



# Generated at 2022-06-26 03:40:30.625138
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Create a FutureException object and add it to the exceptions set
    # of object exception_mixin_1

    actual_exception = None
    expected_exception = None
    try:
        def handler():
            pass
        exception_mixin_1.exception(IOError)(handler)
    except Exception as e:
        actual_exception = e.__class__.__name__

    assert actual_exception == expected_exception

# Generated at 2022-06-26 03:40:31.829245
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()



# Generated at 2022-06-26 03:40:34.105296
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def decorator_0(handler):
        # Non-local variable 'exceptions' referenced before assignment
        # assert (exceptions is None)
        return handler

    assert (exception_mixin_0.exception() == decorator_0)



# Generated at 2022-06-26 03:40:36.257019
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert type(exception_mixin_0.exception(UnicodeError, apply=True)) == types.FunctionType

# Generated at 2022-06-26 03:40:38.043020
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(Exception)
    def foo(request, e):
        pass

    assert isinstance(foo, types.FunctionType)


# Generated at 2022-06-26 03:40:40.014580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(Exception)
    def function0(arg):
        print(arg)


# Generated at 2022-06-26 03:40:50.084499
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    exception_mixin_0 = ExceptionMixin()

    # Assert
    assert isinstance(exception_mixin_0.exception(), types.FunctionType)

# Generated at 2022-06-26 03:40:56.864067
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception()
    def foo():
        pass
    print(foo)

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:58.685712
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception()

# Generated at 2022-06-26 03:41:07.810074
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_0 = ExceptionMixin()
    arg_0 = "arg_0"
    arg_1 = "arg_1"
    arg_2 = "arg_2"
    arg_3 = "arg_3"
    arg_4 = "arg_4"
    args = (arg_0, arg_1, arg_2, arg_3)
    kwargs = {"arg_4": arg_4}
    # Unit Under Test
    result = exception_mixin_0.exception(*args, **kwargs)
    # Verify
    assert type(result) == types.FunctionType
    assert result(arg_0) == None
    assert result("arg_5") == None

# Generated at 2022-06-26 03:41:09.871529
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Raise exception to display the unit test output
    raise Exception(
        failed_msg(1, '_exception', 'ExceptionMixin.exception'))

# Generated at 2022-06-26 03:41:15.563851
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exp_result = True

    exception_mixin = ExceptionMixin()

    def A():
        return 1

    def B():
        return 2

    def C():
        return 3

    exception_mixin.exception(A)(B)
    result = exception_mixin.exception(A, C)(B) is B
    assert result == exp_result

# Generated at 2022-06-26 03:41:25.926523
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()

    # test_case_0
    exceptions = ()
    apply = True
    handler = exception_mixin_0.exception(*exceptions, apply=apply)

    # test_case_1
    exceptions = ()
    apply = True
    handler = exception_mixin_1.exception(*exceptions, apply=apply)

    # test_case_2
    exceptions = (1, 2, 3)
    apply = True
    handler = exception_mixin_0.exception(*exceptions, apply=apply)

    # test_case_3
    exceptions = (1, 2, 3)
    apply = True
    handler = exception_mixin_1.exception(*exceptions, apply=apply)

    # test_case

# Generated at 2022-06-26 03:41:32.469376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Testing exception_mixin_0
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handle_exception_0(request, exc):
        pass

    # Asserting call exceptions_0set
    assert exception_mixin_0._future_exceptions == {FutureException(handle_exception_0, (Exception,))}

# Generated at 2022-06-26 03:41:39.289123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert isinstance(exception_mixin_1.exception(),
                      types.FunctionType),\
        f"exception() should return a decorated method"

    assert exception_mixin_1.exception(Exception) is not None,\
        f"exception() should create a new FutureException object"
    assert isinstance(list(exception_mixin_1._future_exceptions)[0],
                      FutureException),\
        f"exception() should add the new FutureException object to the " \
        f"set self._future_exceptions"

    exception_mixin_1.exception(Exception)
    assert len(exception_mixin_1._future_exceptions) == 1,\
        f"exception() should not add an existing FutureException"

    exception_

# Generated at 2022-06-26 03:41:49.830086
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def decorator(handler):
        future_exception = FutureException(handler, exceptions)
        exception_mixin_1._future_exceptions.add(future_exception)
        if apply:
            exception_mixin_1._apply_exception_handler(future_exception)
        return handler

    def handler():
        pass

    exceptions = [Exception]
    apply = True

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(exceptions, apply=apply)(handler)
    assert exception_mixin_1._future_exceptions == set([FutureException(handler, exceptions)])
    assert exception_mixin_1._future_exceptions.pop() == FutureException(handler, exceptions)

# Generated at 2022-06-26 03:42:07.014798
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False, "Not implemented."

# Generated at 2022-06-26 03:42:09.493769
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    exception_mixin_0.exception()
    exception_mixin_0.exception.__annotations__

# Generated at 2022-06-26 03:42:17.001203
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def test_exception_handler_0(*exceptions, **kwargs):
        pass
    def test_exception_handler_1(apply=True, *exceptions, **kwargs):
        pass
    def test_exception_handler_2(exceptions=True, *args, **kwargs):
        pass
    def test_exception_handler_3(exceptions=True, apply=True, *args, **kwargs):
        pass

    assert exception_mixin_0.exception(test_exception_handler_0()) == test_exception_handler_0()
    assert exception_mixin_0.exception(test_exception_handler_1()) == test_exception_handler_1()

# Generated at 2022-06-26 03:42:18.945994
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:42:21.970395
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptionMixin = ExceptionMixin()
    assert exceptionMixin.exception(1,2) is not None



# Generated at 2022-06-26 03:42:28.753964
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    nonlocal_0 = {}
    nonlocal_1 = False
    nonlocal_2 = ()
    nonlocal_0 = locals()
    nonlocal_1 = False
    nonlocal_2 = ()
    def function_1(function_2):
        nonlocal_0 = locals()
        nonlocal_1 = False
        nonlocal_2 = ()
        return function_2
    return function_1

# Generated at 2022-06-26 03:42:37.049355
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_case_0():
        exception_mixin_0 = ExceptionMixin()
        def handler_0():
            pass
        exceptions_0 = []
        kwargs_0 = {}
        stack_size_0 = len(inspect.stack())
        try:
            exception_mixin_0.exception(*exceptions_0, **kwargs_0)(handler_0)
        except:
            pass
        assert len(inspect.stack()) - stack_size_0 == 0




# Generated at 2022-06-26 03:42:38.509593
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ValueError)

# Generated at 2022-06-26 03:42:47.784411
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    # Case0: Test for No Exceptions
    exception_mixin.exception()
    exception_mixin.exception(apply=False)

    # Case1: Test for one exception
    exception_mixin.exception(RuntimeError)
    exception_mixin.exception(RuntimeError, apply=False)

    # Case2: Test for multiple exceptions
    exception_mixin.exception(RuntimeError, IndexError)
    exception_mixin.exception(RuntimeError, IndexError, apply=False)

    # Case3: Test for multiple exceptions (via list)
    exception_mixin.exception([RuntimeError, IndexError])
    exception_mixin.exception([RuntimeError, IndexError], apply=False)



# Generated at 2022-06-26 03:42:56.258788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    # Test case 1 : Apply=False
    assert len(exception_mixin_1._future_exceptions) == 0
    @exception_mixin_1.exception(Exception(), apply=False)
    def foo():
        pass
    assert len(exception_mixin_1._future_exceptions) == 1
    # Test case 2 : Apply=True
    exception_mixin_2 = ExceptionMixin()
    assert len(exception_mixin_2._future_exceptions) == 0
    @exception_mixin_2.exception(Exception())
    def foo2():
        pass
    assert len(exception_mixin_2._future_exceptions) == 1

# Generated at 2022-06-26 03:43:29.166171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    handler_0 = int
    assert isinstance(exception_mixin_0.exception(handler_0), types.FunctionType)

# Generated at 2022-06-26 03:43:32.161072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert not exception_mixin_0.exception(Exception)

# Generated at 2022-06-26 03:43:33.996350
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler():
        pass

    assert exception_mixin_0.exception(handler) == handler

# Generated at 2022-06-26 03:43:42.344659
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def __handler__0():
        return 0
    _ = exception_mixin_0.exception(Exception)(__handler__0)
    try:
        assert int(0) == 0
    except:
        pass
    try:
        assert int(0) == 1
    except:
        pass
    try:
        assert int(0) == 2
    except:
        pass

# Generated at 2022-06-26 03:43:48.222039
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    blueprint_0 = Blueprint(
        name="",
        url_prefix=None,
        host=None,
        subdomain=None,
        strict_slashes=None,
        version=None,
        strict_slashes=True,
        stream=None,
        middlewares=None,
        ssl=None,
        static_folder=None,
        static_url_path=None,
        template_folder=None,
        http_methods=None,
        routes_base=None,
    )
    blueprint_0.exception = ExceptionMixin.exception.__get__(
        exception_mixin_0, ExceptionMixin
    )


# Generated at 2022-06-26 03:43:52.060953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(Exception)
    def handler(exception): pass

# Generated at 2022-06-26 03:43:54.712381
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        res = True
    assert (res == True)

# Generated at 2022-06-26 03:43:57.505142
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_exception_mixin = ExceptionMixin()

    def my_handler():
        pass

    test_exception_mixin.exception(my_handler)

    assert test_exception_mixin

# Generated at 2022-06-26 03:44:05.380085
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    exception_mixin_0 = ExceptionMixin()
    app_0 = Sanic()

    def add_exception_handler(handler):
        pass

    app_0.add_exception_handler = add_exception_handler

    @exception_mixin_0.exception
    def handle_exception(exception):
        raise NotImplementedError  # noqa

    handle_exception()


# Test if the exception handler is added

# Generated at 2022-06-26 03:44:08.001925
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(ValueError, KeyError)
    assert exception_mixin_0._future_exceptions.pop().handler == exception_mixin_0.exception.__wrapped__(ValueError, KeyError)

# Generated at 2022-06-26 03:45:25.097852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_inner_exception(test):
        nonlocal test_apply_exception_handler_call_counter
        nonlocal test_exception_0

        test_exception_0 = test
        test_exception_0._future_exceptions = set()

        test_apply_exception_handler_call_counter = 0

        def test_inner_apply_exception_handler(handler: FutureException):
            nonlocal test_exception_0
            nonlocal test_apply_exception_handler_call_counter

            test_apply_exception_handler_call_counter += 1
            test_exception_0._future_exceptions.add(handler)
            return

        test_exception_0._apply_exception_handler = test_inner_apply_exception_handler
        return


# Generated at 2022-06-26 03:45:28.890546
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_0(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler):
            pass

    exception_mixin_0 = ExceptionMixin_0()
    assert exception_mixin_0._future_exceptions == set()
    assert isinstance(exception_mixin_0.exception(), collections.abc.Callable)



# Generated at 2022-06-26 03:45:30.642402
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception()


# Generated at 2022-06-26 03:45:39.929189
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Creating a function to assign as a handler for the blueprint exception
    blueprint_exception_handler = lambda request, exception: request
    blueprint_exception_handler_0 = exception_mixin_0.exception(blueprint_exception_handler)
    # Unit test for checking that if no exception is given as an argument,
    # the blueprint handler will catch all exceptions of the blueprint.
    blueprint_exception_handler_1 = exception_mixin_0.exception()


# Generated at 2022-06-26 03:45:42.194383
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception
    def some_exception_handler():
        pass

    assert len(exception_mixin_1._future_exceptions) == 1

# Generated at 2022-06-26 03:45:48.261817
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    class ExceptionMock(Exception):
        def __init__(self):
            super().__init__()

    @exception_mixin_1.exception(ExceptionMock)
    def test_function_1():
        pass

    exception_mixin_2 = ExceptionMixin()

    @exception_mixin_2.exception(ExceptionMock, apply=False)
    def test_function_2():
        pass



# Generated at 2022-06-26 03:45:50.513489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception


# Generated at 2022-06-26 03:45:59.307688
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 0: No exception is set.
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

    # Case 1: exception is set
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(ValueError)
    def f():
        pass
    assert len(exception_mixin_1._future_exceptions) == 1

    # Case 2: exception is list
    exception_mixin_2 = ExceptionMixin()
    @exception_mixin_2.exception([ValueError])
    def f():
        pass
    assert len(exception_mixin_2._future_exceptions) == 1

    # Case 3: exception is tuple
    exception_mixin_3 = ExceptionMixin()

# Generated at 2022-06-26 03:46:05.776955
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    for i in range(10):
        assert i > -1
        assert i!=0
        assert i!=1
        assert i!=2
        assert i!=3
        assert i!=4
        assert i!=5
        assert i!=6
        assert i!=7
        assert i!=8
        assert i!=9
        assert i!=10

# Generated at 2022-06-26 03:46:16.221221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Test for the case when we do not pass any parameter to the method
    # exception
    @exception_mixin_0.exception()
    def handler_0():
        return

    # Test for the case when we pass one parameter to the method exception
    @exception_mixin_0.exception(Exception)
    def handler_1():
        return

    # Test for the case when we pass two parameters to the method exception
    @exception_mixin_0.exception(Exception, Exception)
    def handler_2():
        return

    # Test for the case when we pass list of values to the method exception
    @exception_mixin_0.exception([Exception])
    def handler_3():
        return

