

# Generated at 2022-06-26 03:37:55.891811
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print('testing method exception for class ExceptionMixin')
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(IndexError, IOError, apply=False)


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:37:58.254606
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions = (RuntimeError,)
    @exception_mixin_0.exception(*exceptions)
    def handler(request, exception):
        pass
    assert isinstance(handler, types.FunctionType)

# Generated at 2022-06-26 03:38:00.785905
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(BaseException)

test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:04.884023
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception)


# Generated at 2022-06-26 03:38:06.742749
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception(0)

# Generated at 2022-06-26 03:38:14.563668
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class SuperClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    super_class = SuperClass()

    @super_class.exception(Exception)
    def catch_all_errors(request, exception):
        return response.text('Oops!')

    assert len(super_class._future_exceptions) == 1



# Generated at 2022-06-26 03:38:16.698863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert set() == exception_mixin_0._future_exceptions
    assert exception_mixin_0.exception(A)


# Generated at 2022-06-26 03:38:20.775337
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)()
    assert len(exception_mixin_0._future_exceptions) == 1


# Generated at 2022-06-26 03:38:23.875729
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def exception_handler(request, exception_name, *args, **kwargs):
        pass
    exception_mixin_0.exception(exception_handler)

# Generated at 2022-06-26 03:38:27.577207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = exception('Exception')
    exception_mixin_0.exception('Exception')



# Generated at 2022-06-26 03:38:34.642927
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(ZeroDivisionError)
    def test_function_1():
        pass

    assert isinstance(test_function_1,
                      types.FunctionType)
    assert isinstance(exception_mixin_1._future_exceptions[0],
                      sanic.models.futures.FutureException)
    assert exception_mixin_1._future_exceptions[0].handler == test_function_1
    assert exception_mixin_1._future_exceptions[0].exceptions == (ZeroDivisionError, )

# Generated at 2022-06-26 03:38:40.193241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # This example is used to show how to use the method exception of class ExceptionMixin
    # Create a instance of class ExceptionMixin
    exception_mixin_0 = ExceptionMixin()
    # Create a decorated method to handle global exceptions for any route registered under this blueprint.
    exception_mixin_0.exception(TypeError)("handler")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 03:38:42.818927
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    v0 = exception_mixin_0.exception(1, True)
    assert callable(v0)
    v1 = exception_mixin_0.exception([1], True)
    assert callable(v1)

# Generated at 2022-06-26 03:38:51.608640
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = MagicMock()
    exception_mixin_0.exception(1, 2, apply=True)(3)
    assert exception_mixin_0._apply_exception_handler.call_count == 1
    assert exception_mixin_0._apply_exception_handler.call_args_list[0][0][0].handler == 3
    assert exception_mixin_0._apply_exception_handler.call_args_list[0][0][0].exceptions == (1, 2)

# Generated at 2022-06-26 03:38:56.444433
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def handler_0(request, exception):
        pass
    exception_mixin_0._apply_exception_handler(exception_mixin_0._future_exceptions.pop())

# Generated at 2022-06-26 03:38:59.786695
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception('Exception')


# Generated at 2022-06-26 03:39:01.376870
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception


# Generated at 2022-06-26 03:39:02.866744
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception(ExceptionMixin, [1], [1], apply=True)

# Generated at 2022-06-26 03:39:04.323803
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:39:05.692101
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:39:11.733030
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    method_0 = lambda : None
    exception_mixin_0.exception(method_0)

# Generated at 2022-06-26 03:39:14.120106
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def decorator(handler):
        return True
    assert exception_mixin_1.exception(decorator) == True

# Generated at 2022-06-26 03:39:17.258097
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(KeyError, apply=True)(lambda err: None)

    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception([KeyError, ValueError], apply=True)(lambda err: None)

# Generated at 2022-06-26 03:39:24.141775
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # execution start here
    def f():
        pass
    exception_mixin_0.exception(ValueError)(f)
    # assertion statement(s)
    return exception_mixin_0._future_exceptions, exception_mixin_0._future_exceptions.pop()

if __name__ == "__main__":
    print(test_ExceptionMixin_exception())

# Generated at 2022-06-26 03:39:27.846473
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import types
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception([])
    assert isinstance(exception_mixin_0._future_exceptions.pop(),
                      FutureException)

# Generated at 2022-06-26 03:39:32.992427
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test with bool value
    bool_test_0 = exception_mixin_0.exception(bool)
    bool_test_0.__name__
    assert bool_test_0.__name__ == "bool"


if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:39:38.127040
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    def decorated_1(handler):
        return handler
    exception_mixin_1.exception(decorated_1)(decorated_1)


if __name__ == "__main__":
    test_ExceptionMixin_exception()
    test_case_0()

# Generated at 2022-06-26 03:39:42.773381
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(ZeroDivisionError)
    def exception_handler_1():
        pass


if __name__ == "__main__":
    import sys

    success = True
    test_case_0()
    test_ExceptionMixin_exception()

    print("%s: " % (__file__), end="")
    if success:
        print("OK")
    else:
        print("ERR")
        sys.exit(1)

# Generated at 2022-06-26 03:39:48.797645
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    isinstance(
        exception_mixin_0.exception(),
        Callable,
        "Method exception of class ExceptionMixin should return a callable",
    )



if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()
    print("Done.")

# Generated at 2022-06-26 03:39:50.257496
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()

# Generated at 2022-06-26 03:40:01.140416
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def func_0(arg_0):
        exception_mixin_0._future_exceptions
    exception_mixin_0.exception(Exception)(func_0)

# Generated at 2022-06-26 03:40:04.545753
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()


# Generated at 2022-06-26 03:40:14.627717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test 1: normal case with param apply is True
    def test_1():
        # from sanic.models.futures import FutureException
        # exception_mixin_1 = ExceptionMixin()
        assert(len(exception_mixin_1._future_exceptions) == 0)
        @exception_mixin_1.exception(Exception)
        def handler(request, exception):
            pass
        assert(len(exception_mixin_1._future_exceptions) == 1)
        exception_mixin_1._apply_exception_handler(exception_mixin_1._future_exceptions.pop())
        assert(len(exception_mixin_1._future_exceptions) == 0)
    test_1()
    
    # Test 2

# Generated at 2022-06-26 03:40:16.499333
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception, apply=False)



# Generated at 2022-06-26 03:40:27.291299
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # should be able to construct ExceptionMixin object
    exception_mixin_3 = ExceptionMixin()
    # create a handler that can catch Exception with traceback
    @exception_mixin_3.exception(Exception)
    def handle_exception(request, error):
        pass
    exception_mixin_3._future_exceptions.add(
        FutureException(handle_exception, (Exception,))
    )
    # should be able to add FutureException to _future_exceptions
    assert len(exception_mixin_3._future_exceptions) == 1
    # should be able to create a new exception handler with a Function
    create_handle_exception_function = exception_mixin_3.exception(Exception)
    @create_handle_exception_function
    def create_handle_exception():
        pass

# Generated at 2022-06-26 03:40:29.290956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()


# Generated at 2022-06-26 03:40:32.304793
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def handler():
        return None

    exception_mixin_0.exception(handler)

    assert exception_mixin_0._future_exceptions



# Generated at 2022-06-26 03:40:34.253864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert type(exception_mixin_0.exception) == types.MethodType

# Generated at 2022-06-26 03:40:36.708143
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(Exception, apply=True)

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:38.513052
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    with pytest.raises(AttributeError):
        exception_mixin_0.exception()



# Generated at 2022-06-26 03:41:02.488812
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # exception_1
    exception_mixin_1 = ExceptionMixin()

    # exception_2
    exception_mixin_2 = ExceptionMixin()

    # exception_3
    exception_mixin_3 = ExceptionMixin()

    # exception_4
    exception_mixin_4 = ExceptionMixin()

    # exception_5
    exception_mixin_5 = ExceptionMixin()

# Generated at 2022-06-26 03:41:10.159241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Define a mock decorator
    decorated = mock.Mock(return_value=lambda x: x)

    # Define a mock handler
    handler = mock.Mock(return_value=None)

    # Define a mock exception
    exception = mock.Mock()

    # Define a mock apply
    apply = mock.Mock()

    # Define a mock ExceptionMixin
    exception_mixin_0 = ExceptionMixin()

    # Patch the decorator
    with mock.patch('sanic.models.exception.decorator', new=decorated):

        # Call the exception method
        exception_mixin_0.exception(exception, apply=apply)(handler)

        # Assert the decorated decorator was called with the correct parameters

# Generated at 2022-06-26 03:41:15.979890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def test1():
        def handler():
            pass
        assert callable(exception_mixin_0.exception(handler))
    test1()


if __name__ == "__main__":
    # Unit test for ExceptionMixin
    unittest.main()

# Generated at 2022-06-26 03:41:26.198139
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    @exception_mixin_1.exception(
        AssertionError,
        AssertionError,
        exc_args={"a"}
    )
    def handler_0(request: type(None), exc: AssertionError):
        raise NotImplementedError  # noqa

    @exception_mixin_2.exception(
        AssertionError,
        ZeroDivisionError,
        TypeError,
        exc_args={"a"}
    )
    def handler_1(request: object, exc: object):
        raise NotImplementedError  # noqa

    for x_ in range(10):
        handler = handler_0
        exception_mixin = exception_mixin_0
        exception_mixin.exception(AssertionError)(handler)


# Generated at 2022-06-26 03:41:30.185190
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(IndexError, ZeroDivisionError, apply=False)
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:41:35.194322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test the return value of function exception in class ExceptionMixin is callable
    assert callable(exception_mixin_1.exception())
    # Test the return value of function exception in class ExceptionMixin is callable
    assert callable(ExceptionMixin.exception(exception_mixin_1))


# Generated at 2022-06-26 03:41:38.046601
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup of the test case
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0 = ExceptionMixin()

    # Unit under test
    function_0 = exception_mixin_0.exception()

    # Assertions
    assert function_0(None) == None

# Generated at 2022-06-26 03:41:49.308669
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.future_exceptions = []

        def _apply_exception_handler(self, handler: FutureException):
            self.future_exceptions.append(handler)

    exception_mixin_0 = TestExceptionMixin()

    def test_function_0(request, response):
        return response

    exception_mixin_0.exception(Exception)(test_function_0)
    assert len(exception_mixin_0.future_exceptions) == 1
    assert len(exception_mixin_0.future_exceptions[0].exception_types) == 1

# Generated at 2022-06-26 03:41:58.118268
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
# No exception raised.
    exception_mixin_0 = ExceptionMixin()
    try:
        @exception_mixin_0.exception(AttributeError, apply=False)
        def handle_method(request, exc):
            pass
    except Exception:
        assert False
# No exception raised.
    exception_mixin_1 = ExceptionMixin()
    try:
        @exception_mixin_1.exception([AttributeError])
        def handle_method(request, exc):
            pass
    except Exception:
        assert False
    try:
        @exception_mixin_1.exception(AttributeError)
        def handle_method(request, exc):
            pass
    except Exception:
        assert False
# No exception raised.
    exception_mixin_2 = ExceptionMixin()

# Generated at 2022-06-26 03:41:58.765586
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:42:36.035393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_0 = ExceptionMixin()

    def handler_0():
        var = 0

    exception_mixin_0.exception(IOError)(handler_0)
    exception_mixin_0.exception(IOError, Exception)(handler_0)

    # Assertion
    assert len(exception_mixin_0._future_exceptions) == 2

# Generated at 2022-06-26 03:42:42.134528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()

    def _handler_0(handler):
        print("handler 0")


    @exception_mixin_1.exception(apply=True)
    def _handler_1(handler):
        print("handler 1")

    @exception_mixin_1.exception(apply=True)
    def _handler_2(handler):
        print("handler 2")

    _handler_0(1)
    _handler_1(2)
    _handler_2(2)


# Generated at 2022-06-26 03:42:47.957230
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()

    def exception_handler_3(exception):
        exception_mixin_3._future_exceptions.add(exception)

    exception_mixin_2._apply_exception_handler = exception_handler_3
    exception_mixin_1._apply_exception_handler = exception_handler_3

    def exception_handler_1():
        pass

    def exception_handler_2():
        pass

    exception1 = exception_mixin_1.exception(exception_handler_1)
    exception2 = exception_mixin_2.exception(exception_handler_2, apply=False)

    assert exception_mixin_2._future_exceptions == set

# Generated at 2022-06-26 03:42:50.319981
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:42:53.149272
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # exception_mixin_0.exception(**{}, **{'exceptions': [GeneratorExit, OSError], 'apply': True})(lambda: None)
    pass

# Generated at 2022-06-26 03:42:57.945617
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler(request):
        return request.args.get('name')

    handler = exception_mixin_0.exception(handler, ValueError)

# Generated at 2022-06-26 03:42:59.654105
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()

# Generated at 2022-06-26 03:43:01.629582
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        assert exception_mixin_0.exception()

# Generated at 2022-06-26 03:43:06.076437
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert type(exception_mixin_0.exception()) is method, "Return value is not of type 'method'"

# Generated at 2022-06-26 03:43:07.077762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False, "unit test failed"


# Generated at 2022-06-26 03:43:46.773624
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0(request, exception): pass
    def handler_1(request, exception): pass
    def handler_2(request, exception): pass
    def handler_3(request, exception): pass
    def handler_4(request, exception): pass
    def handler_5(request, exception): pass
    def handler_6(request, exception): pass
    def handler_7(request, exception): pass
    def handler_8(request, exception): pass
    def handler_9(request, exception): pass
    exception_mixin_0.exception(handler_0)
    exception_mixin_0.exception(handler_1)
    exception_mixin_0.exception(handler_2)
    exception_mixin_0.exception(handler_3)
    exception

# Generated at 2022-06-26 03:43:58.555954
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test for method exception
    try:
        # Test for function exception_handler
        def exception_handler(request, exception):
            error_msg = "has been called"
            assert (error_msg == "has been called")

        exception_mixin_0.exception(exception_handler)
    except Exception as error:
        print(error)
    else:
        # Test for method exception
        try:
            # Test for function exception_handler
            def exception_handler(request, exception):
                error_msg = "has been called"
                assert (error_msg == "has been called")

            exception_mixin_0.exception(exception_handler)
        except Exception as error:
            print(error)

# Generated at 2022-06-26 03:44:08.461322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    exception_mixin_0 = ExceptionMixin()

    assert len(exception_mixin_0._future_exceptions) == 0

    @exception_mixin_0.exception(Exception)
    async def handler_0(request, exception):
        return exception
    exception_mixin_0._apply_exception_handler(FutureException(handler_0, Exception))
    try:
        exception_0 = Exception()
        actual = await handler_0(None, exception_0)
        assert actual is exception_0
    except Exception:
        # If we get an exception here, we should fail
        assert False is True
    finally:
        assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:44:19.631252
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()

    from sanic.views import HTTPMethodView
    class ClassDef(ExceptionMixin, HTTPMethodView):
        def __init__(self):
            ExceptionMixin.__init__(self)

    class_var_0 = ClassDef()
    class_var_1 = ClassDef()
    class_var_2 = ClassDef()

    exception_mixin_1.exception()

# Generated at 2022-06-26 03:44:30.616359
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler_0(*args, **kwargs):
        pass

    def handler_1(*args, **kwargs):
        pass

    def handler_2(*args, **kwargs):
        pass

    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0
    assert exception_mixin_0.exception([_0x0, _0x1], apply=True)(handler_0) is handler_0
    assert exception_mixin_0
    assert handler_0(exception_mixin_0, _0x0, _0x1) == exception_mixin_0
    assert exception_mixin_0._future_exceptions

    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0

# Generated at 2022-06-26 03:44:32.965354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(1)

# Generated at 2022-06-26 03:44:38.587156
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # case 0
    exception_0 = RuntimeError
    kwargs_0 = {}
    args_0 = (exception_0, )
    result_0 = exception_mixin_0.exception(args_0, **kwargs_0)
    assert True


# Generated at 2022-06-26 03:44:41.303733
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 0: Try to create an exception handler
    exception_mixin_0 = ExceptionMixin()
    @exception_mixin_0.exception(Exception)
    def exception_handler():
        pass
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:44:48.166249
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1.exception is not None
    assert exception_mixin_1.exception is not True
    assert exception_mixin_1.exception is not False

test_case_0()
test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:44:50.630355
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(True)
    assert exception_mixin_0._future_exceptions == set([FutureException(True, (True, ))])


# Generated at 2022-06-26 03:46:00.571353
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def _exception_exception_handler_exception_handler_0():
        exception_mixin_0._apply_exception_handler(exceptions[0])
        return
    exceptions = [Exception]
    exception_mixin_0.exception(exceptions)
    assert True

# Generated at 2022-06-26 03:46:11.184270
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()



# class ExceptionMixin:
#     def __init__(self, *args, **kwargs) -> None:
#         self._exception_handlers: List[ExceptionHandler] = []

#     def _apply_exception_handler(self, handler: ExceptionHandler):
#         raise NotImplementedError  # noqa

#     def exception(self, *exceptions):
#         """
#         This method enables the process of creating a global exception
#         handler for the current blueprint under question.

#         :param args: List of Python exceptions to be caught by the handler

#         :return a decorated method to handle global exceptions for any
#         route registered under this blueprint.
#         """

#         if isinstance(exceptions[0], list):
#             exceptions = tuple(*exceptions)

# Generated at 2022-06-26 03:46:12.402008
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception)

# Generated at 2022-06-26 03:46:17.652085
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(AssertionError)
    def handle_exception(request, exception):
        pass

    assert len(exception_mixin_0._future_exceptions) == 1
    assert exception_mixin_0._future_exceptions == {FutureException(handle_exception, (AssertionError,))}

# Generated at 2022-06-26 03:46:22.746593
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = exception_mixin_0.exception(Exception)
    try:
        raise FutureException
    except FutureException as exc:
        pass


# Generated at 2022-06-26 03:46:25.874770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # test with input args: () (tuple), (exceptions=None) (dict), apply=False

# Generated at 2022-06-26 03:46:32.222060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    # exceptions is of type list
    exceptions = [ExceptionType.INVALID_REQUEST, ExceptionType.INVALID_RESPONSE]
    # apply is of type bool with value True
    apply = True
    # handler is of type __builtin__.function
    handler = exception_mixin_1.exception(exceptions, apply=apply)
    # Ensure that the handler method is decorated properly
    assert hasattr(handler, "__wrapped__")


# Generated at 2022-06-26 03:46:39.038753
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test args typing
    exception_mixin_1.exception(Exception, Exception)

    # Test kwargs typing
    exception_mixin_1.exception(Exception, Exception, apply=True)

    def sample_handler(a, b, c=None, **kwargs): 
        return a + b + c

    # Test typing of return value
    sample_handler_type = exception_mixin_1.exception(Exception, Exception)(sample_handler)
    assert callable(sample_handler_type)

# Generated at 2022-06-26 03:46:48.811820
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin

    # Test 1: Calling exception with 1 argument
    exception_mixin_1.exception(AttributeError)

    # Test 2: Calling exception with 1 argument and named argument
    exception_mixin_1.exception(AttributeError, apply=True)

    # Test 3: Calling exception with 1 argument and multiple named arguments
    exception_mixin_1.exception(AttributeError, apply=True, handler="")

    # Test 4: Calling exception with 2 arguments
    exception_mixin_1.exception(AttributeError, AssertionError)

    # Test 5: Calling exception with multiple arguments
    exception_mixin_1.exception(AttributeError, AssertionError, NotImplementedError)

    # Test 6: Calling exception with 1 argument in a list and named argument
    exception_mixin_

# Generated at 2022-06-26 03:46:50.972007
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert isinstance(exception_mixin_1.exception(BaseException), Callable)
