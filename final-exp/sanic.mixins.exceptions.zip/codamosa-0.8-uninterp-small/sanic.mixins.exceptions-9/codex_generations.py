

# Generated at 2022-06-26 03:37:59.217302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0() -> None:
        pass
    def handler_1() -> None:
        pass
    def handler_2() -> None:
        pass
    assert exception_mixin_0.exception(KeyError, IndexError)(handler_0)(None) == handler_0
    assert exception_mixin_0.exception(IndexError)(handler_1)(None) == handler_1
    assert exception_mixin_0.exception(ValueError)(handler_2)(None) == handler_2
    assert exception_mixin_0 == exception_mixin_0
    assert not exception_mixin_0 != exception_mixin_0
    assert hash(exception_mixin_0) == hash(exception_mixin_0)

# Generated at 2022-06-26 03:38:08.775328
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exm_0 = ExceptionMixin()

    @exm_0.exception(apply=False)
    def test_handler():
        return False

    @exm_0.exception({}, apply=False)
    def test_handler_1():
        return False

    assert isinstance(test_handler, types.FunctionType)
    assert isinstance(test_handler_1, types.FunctionType)

    assert test_handler.__name__ == 'test_handler'
    assert test_handler_1.__name__ == 'test_handler_1'

    assert test_handler.__code__
    assert test_handler_1.__code__

    assert len(exm_0._future_exceptions) == 2



# Generated at 2022-06-26 03:38:09.341638
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 1 != 1

# Generated at 2022-06-26 03:38:13.918748
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Test0(ExceptionMixin):
        pass
    @Test0.exception(apply=True)
    def handler_0(request, exception):
        pass
    Test0._apply_exception_handler(handler_0)

# Generated at 2022-06-26 03:38:18.209228
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator(handler):
        return handler
    assert exception_mixin_0.exception(*[IOError, FileNotFoundError])(decorator) == decorator
    assert exception_mixin_0.exception(IOError, FileNotFoundError)(decorator) == decorator



# Generated at 2022-06-26 03:38:26.679314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # initialize args of function exception
    exceptions_2 = [
        'BaseException', 
        'Exception', 
        'GeneratorExit', 
        'SystemExit', 
        'KeyboardInterrupt', 
        'StopAsyncIteration'
    ]
    apply_3 = True

    # Calling method exception of class ExceptionMixin
    exception_mixin_1.exception(exceptions_2, apply_3)

# Generated at 2022-06-26 03:38:29.357552
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception is not None



# Generated at 2022-06-26 03:38:33.950561
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception() == decorator

# Generated at 2022-06-26 03:38:35.023115
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:38:41.633747
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception, apply=True)
    def handler_0(request, exception):
        pass

    # Testing
    assert len(exception_mixin_0._future_exceptions) == 1

    with pytest.raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(exception_mixin_0._future_exceptions.pop())

# Generated at 2022-06-26 03:38:47.708001
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = (Exception, )
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(exceptions)(lambda: "Hello World!")


# Generated at 2022-06-26 03:38:48.628186
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(request, exception):
        pass

 

# Generated at 2022-06-26 03:38:52.560711
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(ZeroDivisionError)
    def func(*args, **kwargs):
        pass

    try:
        func()
    except ZeroDivisionError as e:
        pass
    else:
        raise ZeroDivisionError("ZeroDivisionError should be raised")

# Generated at 2022-06-26 03:38:56.444779
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    # Call method exception on class ExceptionMixin with arguments
    exception_handler_0 = exception_mixin_0.exception(1)

    assert exception_handler_0 is not None

# Generated at 2022-06-26 03:39:03.569837
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def handler_0(handler, *exceptions):
        return handler
    arg_0 = handler_0
    arg_1 = []
    arg_2 = False
    ret_0 = exception_mixin_1.exception(arg_0, arg_1, apply=arg_2)
    ret_1 = exception_mixin_1.exception(arg_0, arg_1, apply=arg_2)
    assert ret_0 is ret_1



# Generated at 2022-06-26 03:39:14.459749
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 0
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()

    # Case 1
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(NotImplementedError)

    # Case 2
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.exception(NotImplementedError, apply=False)

    # Case 3
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_3.exception([NotImplementedError, ImportError])

    # Case 4
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_4.exception([NotImplementedError, ImportError], apply=True)

    # Case 5
    exception_mixin_

# Generated at 2022-06-26 03:39:25.084596
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # test case 1
    def handler1():
        def decorator1(func_to_be_decorated1):
            return func_to_be_decorated1

        return decorator1

    exception_mixin1 = ExceptionMixin()
    exception_mixin1.exception(handler1)

    # test case 2
    def handler2():
        def decorator2(func_to_be_decorated2):
            return func_to_be_decorated2

        return decorator2

    exception_mixin2 = ExceptionMixin()
    exception_mixin2.exception(handler2(), apply=False)

    # test case 3
    def handler3():
        def decorator3(func_to_be_decorated3):
            return func_to_be_decorated3

        return

# Generated at 2022-06-26 03:39:26.939275
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception()


# Generated at 2022-06-26 03:39:37.331920
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    arg_0_0: int = int()
    arg_0_1: int = int()
    arg_0_2: int = int()
    arg_0_3: int = int()
    arg_0_4: int = int()
    arg_0_5: int = int()
    arg_0_6: int = int()
    arg_0_7: int = int()
    arg_0_8: int = int()
    arg_0_9: int = int()
    arg_0_10: int = int()
    arg_0_11: int = int()
    arg_0_12: int = int()
    arg_0_13: int = int()
    arg_0_14: int = int()
    arg_0_15

# Generated at 2022-06-26 03:39:43.547406
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(*args, **kwargs):
        pass

    exception_mixin_0 = ExceptionMixin()

    assert (
        type(
            exception_mixin_0.exception(
                [Exception], apply=True)(handler)
        )
        is
        type(handler)
    )
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:39:50.144192
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    assert exception_mixin_1._future_exceptions == set()
    assert exception_mixin_2._future_exceptions == set()

# Generated at 2022-06-26 03:39:57.043250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # :param args: List of Python exceptions to be caught by the handler
    # :param kwargs: Additional optional arguments to be passed to the
    #     exception handler
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(Exception, NameError)
    def custom_error_pages(request, exc):
        return "Internal Server Error", 500
    assert custom_error_pages(request=None, exc=None) == ("Internal Server Error", 500)


# Generated at 2022-06-26 03:39:59.925078
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    # call the method
    exception = exception_mixin.exception('Exception')
    # check
    assert exception is not None
    assert callable(exception)

# Generated at 2022-06-26 03:40:06.899196
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from functools import partial

    exception_mixin_0 = ExceptionMixin()
    exceptions_variable_0 = [Exception, TypeError]
    handler_variable_0 = partial(partial, print, end="")
    @exception_mixin_0.exception(*exceptions_variable_0, apply=True)
    def test_function_0():
        handler_variable_0()



# Generated at 2022-06-26 03:40:11.795452
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # with the following declaration, no exception is raised
    exception_mixin_0.exception()

    @exception_mixin_0.exception
    def handler_0():
        pass
    # check exception
    # assert handler_0 in exception_mixin_0._future_exceptions

# Generated at 2022-06-26 03:40:15.046009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    # exception_mixin_1.exception(TypeError, IndexError, AttributeError, apply = True)
    exception_mixin_1.exception([TypeError, IndexError, AttributeError], apply = True)

# Generated at 2022-06-26 03:40:22.811193
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exception_mixin import ExceptionMixin
    from unittest.mock import Mock

    exception_mixin_0 = ExceptionMixin()
    handler_0 = Mock()
    apply_0 = Mock()

    @exception_mixin_0.exception(handler=handler_0, apply=apply_0)
    def exception_handler_0(handler: Mock, apply: Mock):
        pass

    exception_handler_0()

    handler_0.assert_called_once()
    apply_0.assert_called_once()



# Generated at 2022-06-26 03:40:27.341666
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert (exception_mixin_0._future_exceptions==set())
    pass


if __name__ == "__main__":
    test_case_0()
    # Unit test for method exception of class ExceptionMixin
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:30.159532
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # case 0
    test_case_0()

    # case 1
    test_case_1()

    # case 2
    test_case_2()

# Generated at 2022-06-26 03:40:34.720150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.route('/test_url_param/<param>', methods=['GET', 'HEAD'], uri_as_first_arg=False)
    except RuntimeError as exception_arg_0:
        print('RuntimeError:', str(exception_arg_0))


# Generated at 2022-06-26 03:40:47.582195
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    b = []
    def exe0(a, b=b):
        exception_mixin_0.__init__()
        b.append(a)
    b.append(0)
    exception_mixin_0.exception(1, True)(exe0)

# Generated at 2022-06-26 03:40:57.369691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    class Exception:
        def with_items(self, *item_names):
            return self

        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, f):
            return f

    from sanic import Blueprint

    blueprint_0 = Blueprint('blueprint_0', url_prefix='blueprint_0')

    class AttributeWrapper:
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, f):
            return f

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    exception_mixin_0.exception(Exception)
    exception_mixin_

# Generated at 2022-06-26 03:41:07.696077
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert 0 == len(exception_mixin_0._future_exceptions)

    @exception_mixin_0.exception(ZeroDivisionError, FileNotFoundError)
    def handler_0():
        print("Caught!")

    assert 1 == len(exception_mixin_0._future_exceptions)
    assert len(exception_mixin_0._future_exceptions) == 1

    @exception_mixin_0.exception(ZeroDivisionError, KeyError, apply=False)
    def handler_1():
        print("Caught!")
    assert 2 == len(exception_mixin_0._future_exceptions)


# Generated at 2022-06-26 03:41:08.870458
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception()

# Generated at 2022-06-26 03:41:16.985569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a new ExceptionMixin() instance
    exception_mixin_0 = ExceptionMixin()
    # create a dummy list
    exceptions_1 = []
    # create a dummy boolean
    apply_1 = True
    # create a dummy function
    handler_1 = lambda: None
    # call method exception of class ExceptionMixin
    exception_mixin_0.exception(*exceptions_1, apply=apply_1)(handler_1)
    # assert that exception_mixin_0._future_exceptions is not empty
    assert len(exception_mixin_0._future_exceptions) > 0

# Generated at 2022-06-26 03:41:22.204342
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Parameter initialization
    exceptions = [BaseException]
    decorator = exception_mixin_0.exception(exceptions)
    assert(len(exception_mixin_0._future_exceptions) == 1)
    exceptions = [BaseException]
    decorator = exception_mixin_0.exception(exceptions)
    assert(len(exception_mixin_0._future_exceptions) == 1)

# Generated at 2022-06-26 03:41:33.753346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    print(exception_mixin_0._future_exceptions)
    with pytest.raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(None)
    with pytest.raises(TypeError):
        exception_mixin_0.exception(None)()
    with pytest.raises(TypeError):
        exception_mixin_0.exception()(None)
    def dummy_handler(request, exception, *args, **kwargs):
        pass
    exception_mixin_0.exception()(dummy_handler)
    assert isinstance(exception_mixin_0._future_exceptions, set)
    assert len(exception_mixin_0._future_exceptions) == 1

# Generated at 2022-06-26 03:41:36.507535
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_handler_0 = FutureException(None, None)

    exception_mixin_0 = ExceptionMixin()

    assert exception_mixin_0._apply_exception_handler(exception_handler_0) is None


# Generated at 2022-06-26 03:41:39.523113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_function_0 = FutureException(func_0, [])
    @exception_mixin_0.exception()
    def func_0():
        pass
    def func_0():
        pass

    @exception_mixin_0.exception([], apply=False)
    def func_1():
        pass
    def func_1():
        pass


# Generated at 2022-06-26 03:41:45.752548
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0, ExceptionMixin)
    exception_mixin_0.exception(list(range(2)))
    exception_mixin_0.exception(list(range(3)))
    exception_mixin_0.exception(list(range(4)))

# Generated at 2022-06-26 03:42:03.461152
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Arrange
    exception_mixin_2 = ExceptionMixin()

    # Act
    result_1 = exception_mixin_2.exception(ZeroDivisionError, apply=False)

    # Assert
    assert result_1 is None


# Generated at 2022-06-26 03:42:11.611422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print('Test: exception of class ExceptionMixin')

    # initialization
    exception_mixin_0 = ExceptionMixin()

    # method test
    def decorator(handler):
        assert handler == None
        return None

    assert exception_mixin_0.exception(None) == decorator


if __name__ == '__main__':
    test_case_0()

    # Unit test for method exception of class ExceptionMixin
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:42:18.291718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.functions import Function
    from sanic.models.view import View
    from unittest import mock
    import pytest
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(asyncio.TimeoutError)
    async def exception_handler(request, exception):
        pass

    @exception_mixin.exception(RuntimeError, apply=False)
    def exception_handler_2(request, exception):
        pass

    @exception_mixin.exception([asyncio.TimeoutError])
    def exception_handler_3(request, exception):
        pass

    print(exception_mixin._future_exceptions)

# Generated at 2022-06-26 03:42:28.503809
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # (exception_mixin_0)

    # Mock declaration
    class exception_mixin_0_mock:
        @staticmethod
        def _apply_exception_handler(handler: FutureException):
            pass

    exception_mixin_0 = exception_mixin_0_mock()

    # Code to test with coverage
    @exception_mixin_0.exception(Exception)
    def handler_0(request, exception):
        """
        This function is a handler for exception for the purpose of
        testing `exception` method of class `ExceptionMixin`.

        :param request: The request to handle exception for
        :param exception: The exception to handle

        :return:
        """
        pass



# Generated at 2022-06-26 03:42:37.739898
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # call method exception of class ExceptionMixin
    exception_mixin_1 = ExceptionMixin()
    test_variable_0 = exception_mixin_1._exception_method
    assert isinstance(test_variable_0, FutureException) is True
    # Test that when the method is called incorrectly and we are expecting an exception
    # the exception will be raised.
    with pytest.raises(TypeError, match=r'.* must be .*, not .*'):
        call_in_0 = exception_mixin_1.exception()
        exception_mixin_1._exception_method(call_in_0)

# Generated at 2022-06-26 03:42:41.650324
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def handler(*args, **kwargs):
        return 'foo'

    exception_mixin_1 = ExceptionMixin()

    exception_mixin_1.exception(IOError)

    exceptioned = False

    try:
        exception_mixin_1._apply_exception_handler(handler)
    except IOError:
        exceptioned = True

    assert exceptioned


# Generated at 2022-06-26 03:42:51.545835
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    # Test 1
    def exception_handler_1(request, exception):
        return exception.args[0]

    exception_mixin_1.exception(ValueError)(exception_handler_1)

    # Test 2
    def exception_handler_2(request, exception):
        return exception.args[0]

    mixin_2 = exception_mixin_1.exception(Exception, apply=False)
    mixin_2(exception_handler_2)

    # Test 3
    def exception_handler_3(request, exception):
        return exception.args[0]

    exception_mixin_1.exception([ValueError, Exception])(exception_handler_3)

# Generated at 2022-06-26 03:42:53.095923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(404)

# Generated at 2022-06-26 03:42:53.940978
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

# Generated at 2022-06-26 03:42:59.137761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(1.2)
    exception_mixin_0.exception(1.2)

# Generated at 2022-06-26 03:43:31.893550
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()


# Generated at 2022-06-26 03:43:33.771927
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert issubclass(exception_mixin_0.exception(),
                      types.FunctionType)

# Generated at 2022-06-26 03:43:41.275991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    future_exception_0 = FutureException()
    try:
        exception_mixin_0._future_exceptions.add(future_exception_0)
        exception_mixin_0._apply_exception_handler(future_exception_0)
    except NotImplementedError:
        pass
    assert True

# Generated at 2022-06-26 03:43:43.664234
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception('Exception')
    except NotImplementedError:
        return 0

    return 1

# Generated at 2022-06-26 03:43:46.240039
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._future_exceptions.add()
    exception_mixin_0._future_exceptions.add(FutureException())
    exceptions = [exception_mixin_0]
    assert exception_mixin_0.exception(exceptions) == True

# Generated at 2022-06-26 03:43:49.291516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()


# Generated at 2022-06-26 03:43:53.227018
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    kwargs = {}
    exception_mixin_0.exception("ZeroDivisionError", apply = True, **kwargs) # noqa

# Generated at 2022-06-26 03:43:57.087532
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0._future_exceptions == set()
    with raises(NotImplementedError):
        exception_mixin_0._apply_exception_handler(
            FutureException(None, None)
        )
    assert exception_mixin_0.exception(Exception) is not None

# Generated at 2022-06-26 03:44:03.958894
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def foo():
        pass

    def foo2(*args):
        pass

    def foo3(**kwargs):
        pass

    @exception_mixin_0.exception(apply=False)
    def func_0(arg_0: FutureException) -> FutureException:
        pass

    @exception_mixin_0.exception(apply=True)
    def func_1(arg_0: FutureException) -> FutureException:
        pass

    @exception_mixin_0.exception()
    def func_2(arg_0: FutureException) -> FutureException:
        pass

    @exception_mixin_0.exception(foo())
    def func_3(arg_0: FutureException) -> FutureException:
        pass


# Generated at 2022-06-26 03:44:06.830594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = [KeyError]
    apply_0 = True
    handler = ExceptionMixin.exception(exception_mixin_0, exceptions_0, apply=apply_0)

# Generated at 2022-06-26 03:45:23.500231
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._future_exceptions = [
        FutureException(method, 404),
        FutureException(method, 400),
        FutureException(method2, 404),
        FutureException(method2, 400)
    ]
    @exception_mixin_0.exception(404)
    def method():
        return "handler"

    @exception_mixin_0.exception(404)
    def method2():
        return "handler2"

    assert len(exception_mixin_0._future_exceptions) == 4
    assert exception_mixin_0._future_exceptions[0].handler == \
        exception_mixin_0._future_exceptions[2].handler
    assert exception_mixin_0._future_exceptions[1].handler

# Generated at 2022-06-26 03:45:28.917047
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(Exception)
    def test_method(request):
        return

    # Testing if exception successfully decorated.
    # This is the recommended way to test exceptions in the current context
    assert len(exception_mixin._future_exceptions) == 1

    # Testing if the exception function can be used like a decorator
    @exception_mixin.exception(Exception)
    def second_test_method(request):
        return

    assert len(exception_mixin._future_exceptions) == 2


# Generated at 2022-06-26 03:45:38.748737
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator_0(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        exception_mixin_0._future_exceptions.add(future_exception)
        if apply:
            exception_mixin_0._apply_exception_handler(future_exception)
        return handler

    exception_mixin_0.exception(decorator_0)



# Generated at 2022-06-26 03:45:44.592159
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test Plan:
    # 1) Test for object creation
    # 2) Test for method return value
    # 3) Test for method __call__ method
    # 4) Test for method __call__ method

    # Test case 1: Test for object creation

    exception_mixin = ExceptionMixin()

    # Test case 2: Test for method return value
    # This is a decorator so the return value should be a function
    assert callable(exception_mixin._exception())

    # Test case 3: Test for method __call__ method
    # The decorator should take an exception handler and return the same
    # handler unchanged

    # Define a sample exception handler
    def handler():
        pass

    # Call the decorator with the exception handler
    decorated_handler = exception_mixin.exception(handler)

    # Check that the decorated handler

# Generated at 2022-06-26 03:45:54.568372
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global exception_mixin_0

    exception_mixin_0 = ExceptionMixin()

    ret_val = exception_mixin_0.exception(RuntimeError)
    assert ret_val
    #     assert (not 'future_exceptions' in dir(ret_val)), "Expected 'future_exceptions' in dir(ret_val)"
    #     assert (not '_future_exceptions' in dir(ret_val)), "Expected '_future_exceptions' in dir(ret_val)"
    #     assert (not 'decorator' in dir(ret_val)), "Expected 'decorator' in dir(ret_val)"
    #     assert (not 'exceptions' in dir(ret_val)), "Expected 'exceptions' in dir(ret_val)"
    #     assert (not 'handler' in dir(

# Generated at 2022-06-26 03:45:59.024479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    with pytest.raises(NotImplementedError):
        exception_mixin_1._apply_exception_handler(exception_mixin_1._future_exceptions.pop())

    exception_mixin_1.exception(exception_mixin_1._future_exceptions.pop())

# Generated at 2022-06-26 03:46:01.032233
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(404)

# Generated at 2022-06-26 03:46:11.557599
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def dummy_handler():
        return None

    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1._apply_exception_handler = lambda handler: handler.handler()
    exception_mixin_1._future_exceptions = set()

    assert len(exception_mixin_1._future_exceptions) == 0
    exception_mixin_1.exception(ValueError, ZeroDivisionError)(dummy_handler)()
    assert len(exception_mixin_1._future_exceptions) == 1

    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2._apply_exception_handler = lambda handler: handler.handler()
    exception_mixin_2._future_exceptions = set()


# Generated at 2022-06-26 03:46:14.030754
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert isinstance(ExceptionMixin().exception, collections.Callable)

# Generated at 2022-06-26 03:46:15.558325
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception("1")