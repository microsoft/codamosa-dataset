

# Generated at 2022-06-26 03:37:58.723256
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Test method with positional argument, keyword argument and returned value
    exception_mixin_1 = ExceptionMixin()
    @exception_mixin_1.exception(RuntimeError)
    def handler_1():
        return None
    str_1 = 'result of method exception(RuntimeError)'
    assert str(handler_1) == str_1

    # Test method with default argument
    exception_mixin_2 = ExceptionMixin()
    @exception_mixin_2.exception(RuntimeError, apply=False)
    def handler_2():
        return None
    str_2 = 'result of method exception(RuntimeError, apply=False)'
    assert str(handler_2) == str_2

    # Test method with bool argument
    exception_mixin_3 = ExceptionMixin()
    def handler_3():
        return None

# Generated at 2022-06-26 03:38:00.464347
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(NotImplementedError)


# Generated at 2022-06-26 03:38:02.839073
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:38:05.584443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler_0(handler, exception_0):
        pass
    handler_0 = exception_mixin_0.exception(handler_0)

# Generated at 2022-06-26 03:38:16.572060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    assert exception_mixin_0._future_exceptions == set()
    assert exception_mixin_0._apply_exception_handler == NotImplementedError  # noqa

    # STEP 1
    # [
    #     ('future exception', 'handler', ('exception', )),
    # ]

    # STEP 2
    # [
    #     ('future exception', 'handler', ('exception', )),
    #     ('future exception', 'handler', ('Exception', )),
    # ]

    # STEP 3
    # [
    #     ('future exception', 'handler', ('exception', )),
    #     ('future exception', 'handler', ('Exception', )),
    #     ('future exception', 'handler', ('exception', )),
    # ]

    # STEP 4

# Generated at 2022-06-26 03:38:20.630970
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_0 = TypeError()
    exception_mixin_0.exception(exception_0, apply=True)



# Generated at 2022-06-26 03:38:31.386008
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(ZeroDivisionError)
    def zero_division_error_decorator(handler):
        raise ZeroDivisionError()
    try:
        zero_division_error_decorator(None)
    except ZeroDivisionError as e:
        print(e)

    @exception_mixin_1.exception([ZeroDivisionError, IndexError])
    def multi_exception_decorator(handler):
        raise IndexError()
    try:
        multi_exception_decorator(None)
    except IndexError as e:
        print(e)

if __name__ == "__main__":
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:40.346910
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception()
    except NotImplementedError:
        pass
    else:
        print('Failed to raise NotImplementedError')
    try:
        foo_bar_0 = exception_mixin_0.exception()
    except Exception as e:
        print(e)
    else:
        print('foo_bar_0:', foo_bar_0)


if __name__ == '__main__':
    test_case_0()
    test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:38:44.014633
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(exception):
        return
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0._apply_exception_handler = lambda handler: None
    result = exception_mixin_0.exception(handler)
    assert result(NameError)

# Generated at 2022-06-26 03:38:45.446107
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    return True



# Generated at 2022-06-26 03:38:55.283000
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test exception_mixin_0.exception(*args, apply=True)

    # def handler(request, exception): pass
    def handler(request, exception):
        pass
    kwargs = {}
    ex_0 = exception_mixin_0.exception(handler)
    assert ex_0(handler) == handler



# Generated at 2022-06-26 03:39:01.261674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_0 = {}
    apply_0 = True

    def handler_0():
        pass

    @exception_mixin_0.exception(exceptions_0, apply=apply_0)
    def dec_0():
        pass

    dec_0()

# Generated at 2022-06-26 03:39:05.689291
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    bp = Blueprint('test_bp', url_prefix='/test_bp')

    @bp.exception([ValueError])
    def handler(request, exception):
        return 'Exception was caught!'

    app.blueprint(bp)
    assert handler in bp._apply_exception_handler.kwargs['handler']
    assert Exception in bp._apply_exception_handler.kwargs['exceptions']

    client = app.test_client(app)
    response = client.get('/test_bp/')
    print(response.text)
    #assert response.status == 404

# Generated at 2022-06-26 03:39:10.196514
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def decorator_0():
        def handler():
            pass
        return exception_mixin_0.exception(KeyError, ValueError)(handler)
    assert decorator_0()



# Generated at 2022-06-26 03:39:16.590428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import datetime
    import pytest
    import sanic
    from sanic.models.futures import FutureException
    from types import GeneratorType
    from typing import Callable, List, Set

    from sanic.models.exceptions import ExceptionMixin

    exception_mixin_0 = ExceptionMixin()

    exception_mixin_0.exception(AttributeError, ValueError)(lambda: None)
    exception_mixin_0.exception(ValueError, local=True)(lambda: None)

    exception_mixin_0.exception([AttributeError, ValueError])(lambda: None)

# Generated at 2022-06-26 03:39:21.171787
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Function excpetion_mixin_0.exception returned type: function
    # Function returned type: function
    assert(isinstance(exception_mixin_0.exception(), types.FunctionType))

# Generated at 2022-06-26 03:39:27.709188
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception()
    def func1(x, y, z=0):
        pass

    @exception_mixin_0.exception(apply=False)
    def func2(x, y, z=0):
        pass

    @exception_mixin_0.exception(apply=True)
    def func3(x, y, z=0):
        pass


# Generated at 2022-06-26 03:39:32.233463
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(Exception)
    def example_function():
        return None
    
    assert len(exception_mixin_0._future_exceptions) == 1
    assert isinstance(exception_mixin_0._future_exceptions.pop(), FutureException)

# Generated at 2022-06-26 03:39:34.703924
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()

    def handler():
        pass
    exceptions_1 = (AssertionError, AttributeError)
    exceptio

# Generated at 2022-06-26 03:39:38.578889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    foo_0 = exception_mixin_1.exception((BaseException,), True)(lambda : '\x80')
    assert isinstance(foo_0, function)


# Generated at 2022-06-26 03:39:46.699475
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:39:48.602298
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.exception(ValueError, foo=42, apply=True)

# Generated at 2022-06-26 03:39:51.178358
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    def decorator(handler):
        return handler
    exceptions = Exception
    result = exception_mixin_1.exception(exceptions)
    assert result(input) is input

# Generated at 2022-06-26 03:39:53.353180
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_exception_0 = globals()["ExceptionMixin"]()

    # exception_mixin_exception_0.exception()
    assert False



# Generated at 2022-06-26 03:39:56.802511
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    def decorator_0(handler):
        return FutureException(handler, tuple())

    _ = exception_mixin_0.exception(*[Exception], apply=True)(decorator_0)

# Generated at 2022-06-26 03:40:08.625770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    
    def test_case_0():
        exception_mixin_0 = ExceptionMixin()
        handler_0 = test_case_0
        args = [handler_0]
        kwargs = {}
        actual_return = exception_mixin_0.exception(*args, **kwargs)
        expected_return = NULL

    def test_case_1():
        exception_mixin_0 = ExceptionMixin()
        handler_0 = test_case_0
        args = [handler_0]
        kwargs = {}
        actual_return = exception_mixin_0.exception(*args, **kwargs)
        expected_return = NULL

    def test_case_2():
        exception_mixin_0 = ExceptionMixin()
        handler_0 = test_case_0
        args = [handler_0]

# Generated at 2022-06-26 03:40:11.795358
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    assert hasattr(exception_mixin_1, 'exception')
    assert callable(exception_mixin_1.exception)


# Generated at 2022-06-26 03:40:17.547299
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert callable(exception_mixin_0.exception),\
        'Callable attribute assignment failure'

    exception_mixin_0.exception()


# Testing Class: Blueprint
from typing import (
    Any,
    Optional,
)

from sanic.app import Sanic
from sanic.blueprints import Blueprint
from sanic.config import Config
from sanic.request import Request
from sanic.response import HTTPResponse, Response
from sanic.router import Router
from sanic.websocket import WebSocketProtocol


# Generated at 2022-06-26 03:40:19.405647
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception(TypeError, ValueError, AssertionError)

# Generated at 2022-06-26 03:40:24.420506
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    test_exception_0 = Exception()

    @exception_mixin_1.exception(test_exception_0)
    def handler_exception_test_0(test_exception_1):
        pass

# Generated at 2022-06-26 03:40:35.768901
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    global exception_handler_0
    exception_handler_0 = False
    def exception_handler_0():
        exception_handler_0 = True
    exception_mixin_0.exception(exception_handler_0)

test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:40:37.129955
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:40:38.897509
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        assert exception_mixin_0.exception()(None) is None
    except NotImplementedError:
        pass

# Generated at 2022-06-26 03:40:45.933445
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    exceptions = None
    def decorator(handler):
        nonlocal exceptions
        future_exception = FutureException(handler, exceptions)
        return future_exception
    future_exception_0 = exception_mixin_1.exception(exceptions)
    future_exception_1 = decorator(exceptions)
    assert future_exception_0 == future_exception_1

# This test case is to test whether the global exception handler for the current blueprint under question.

# Generated at 2022-06-26 03:40:53.211118
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test_0
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.__init__()
    # test_1
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_1.__init__()
    # test_2
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_2.__init__()


if __name__ == '__main__':
    test_case_0()
    print("[*] All tests done.")

# Generated at 2022-06-26 03:40:59.031686
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    
    # Call method exception of class ExceptionMixin
    exception_mixin.exception(0)
    exception_mixin.exception(0, apply=False)

# Generated at 2022-06-26 03:41:05.152442
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exceptions_1 = []
    apply_2 = True

    def handler_3():
        pass

    # Call method
    result = exception_mixin_0.exception(*exceptions_1, apply=apply_2)(handler_3)
    assert result(exception_mixin_0) == handler_3

# Generated at 2022-06-26 03:41:07.452093
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    excpt_mixin_0 = exception_mixin_0.exception(apply=True)
    excpt_mixin_0({})

# Generated at 2022-06-26 03:41:11.121031
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert exception_mixin_0.exception is not None


# Generated at 2022-06-26 03:41:12.578251
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_case_0()


##########################
#  Class: FutureException
##########################


# Generated at 2022-06-26 03:41:30.244190
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(Exception)


# Generated at 2022-06-26 03:41:33.231669
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        test_case_0()
    except Exception as ex:
        print("exception test failed")

# Test print output from exception method of class ExceptionMixin

# Generated at 2022-06-26 03:41:33.792381
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-26 03:41:37.567002
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    exception_mixin_1 = ExceptionMixin()

    @exception_mixin_1.exception(Exception)
    def handler():
        pass

    # act
    m = exception_mixin_1._future_exceptions

    # assert
    assert (len(m) == 1)

    assert (isinstance(m.pop(), FutureException) == True)

# Generated at 2022-06-26 03:41:39.487287
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception()



# Generated at 2022-06-26 03:41:41.862080
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    raise NotImplementedError  # noqa

# Generated at 2022-06-26 03:41:43.990510
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception = Exception('exception')
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(exception)

# Generated at 2022-06-26 03:41:53.158426
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Testing if a method exists in a class
    if hasattr(exception_mixin_0, 'exception'):
        # Testing if the return type of a method is a function
        if callable(getattr(exception_mixin_0, 'exception')):
            # Calling the method with the appropriate parameters
            try:
                exception_mixin_0.exception()
            except Exception as e:
                # Raises an exception if the method call provided parameters
                # that the method was not expecting
                if(str(e) == "exception() takes exactly 1 argument (0 given)"):
                    assert True
                else:
                    assert False



# Generated at 2022-06-26 03:41:55.824564
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()

    class TestException(Exception):
        pass

    def test_func(*args, **kwargs):
        return TestException()

    result_0 = exception_mixin_0.exception(TestException)(test_func)
    assert result_0 == test_func
    assert len(exception_mixin_0._future_exceptions) == 1


# Generated at 2022-06-26 03:41:59.111528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_handler():
        pass

    exceptions = [Exception]
    apply = True
    exception_mixin = ExceptionMixin()
    var = exception_mixin.exception(*exceptions, apply=apply)(test_handler)
    assert var == test_handler
    assert exception_mixin._future_exceptions == {
        FutureException(test_handler, tuple(Exception))}

# Generated at 2022-06-26 03:42:31.609168
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Method call
    exception_mixin_0.exception()

# Generated at 2022-06-26 03:42:41.746107
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    def handler():
        return 0
    def apply(handler_0):
        return 0
    future_exception_0 = FutureException(handler, tuple())
    exception_mixin_0._apply_exception_handler(handler_0)
    return_value_0 = exception_mixin_0.exception(tuple())
    return_value_0 = exception_mixin_0.exception(tuple(), apply=apply(handler_0))
    return_value_0 = exception_mixin_0.exception(tuple(), apply=True)
    future_exception_0 = FutureException(handler, tuple())
    return_value_0 = exception_mixin_0.exception(tuple(), apply=apply(handler_0))

# Generated at 2022-06-26 03:42:52.348567
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class MockExceptionMixin(ExceptionMixin):

        def __init__(self):
            super().__init__()
            self.call_count = 0

        def _apply_exception_handler(self, handler: FutureException):
            self.call_count += 1

    mock_exception_mixin = MockExceptionMixin()
    mock_exception_mixin.exception(Exception)
    assert mock_exception_mixin.call_count == 1
    assert len(mock_exception_mixin._future_exceptions) == 1

    mock_exception_mixin.exception(Exception)
    assert mock_exception_mixin.call_count == 1
    assert len(mock_exception_mixin._future_exceptions) == 1


# Generated at 2022-06-26 03:42:58.038224
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_1 = ExceptionMixin()
    exception_mixin_2 = ExceptionMixin()
    exception_mixin_3 = ExceptionMixin()
    exception_mixin_4 = ExceptionMixin()
    exception_mixin_5 = ExceptionMixin()
    exception_mixin_6 = ExceptionMixin()
    exception_mixin_7 = ExceptionMixin()
    exception_mixin_8 = ExceptionMixin()
    exception_mixin_9 = ExceptionMixin()
    exception_mixin_10 = ExceptionMixin()
    exception_mixin_11 = ExceptionMixin()
    exception_mixin_12 = ExceptionMixin()
    exception_mixin_13 = ExceptionMixin()
    exception_mixin_14 = ExceptionMixin()
    exception_mix

# Generated at 2022-06-26 03:43:05.352706
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views.view import View
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse, redirect
    from sanic.exceptions import NotFound, ServerError
    
    # Setup
    @exception_mixin_0.exception(NotFound)
    def exception_test0(request: Request, exception: Exception):
        return redirect('/index', code=302)
    
    @exception_mixin_0.exception(ServerError)
    def exception_test1(request: Request, exception: Exception):
        return redirect('/index', code=302)
    

# Generated at 2022-06-26 03:43:14.496677
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError

    # from unittest import TestCase, mock

    def test_mixin_exception(app):
        @app.exception(ServerError)
        def test(request, exception):
            return text("ok")

        return test

    app = Sanic("test_Sanic_exception")
    app.blueprint(ExceptionMixin())
    app.route("/test", methods=["GET", "POST"])(test_mixin_exception(app))

    request, response = app.test_client.get("/test")
    assert response.text == "ok"
    assert response.status == 500

# Generated at 2022-06-26 03:43:25.701413
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    assert not hasattr(exception_mixin_0, "_future_exceptions")
    exception_mixin_1 = ExceptionMixin()
    assert not hasattr(exception_mixin_1, "_future_exceptions")
    exception_mixin_2 = ExceptionMixin()
    assert not hasattr(exception_mixin_2, "_future_exceptions")
    exception_mixin_2._apply_exception_handler(exception_mixin_1)
    exception_mixin_3 = ExceptionMixin()
    assert not hasattr(exception_mixin_3, "_future_exceptions")
    exception_mixin_4 = ExceptionMixin()
    assert not hasattr(exception_mixin_4, "_future_exceptions")
    exception_mixin

# Generated at 2022-06-26 03:43:29.369267
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    # Test exception_mixin_0.exception()
    with pytest.raises(NotImplementedError) as e_info:
        test_future_exception_0 = FutureException(None, None)
        exception_mixin_0.exception(test_future_exception_0)

# Generated at 2022-06-26 03:43:37.993053
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_2 = ExceptionMixin()

    exception_mixin_2.exception(apply=True, exceptions=hashlib.sha1)

    exception_mixin_3 = ExceptionMixin()

    exception_mixin_3.exception(apply=True, exceptions=hashlib.sha1)

    exception_mixin_4 = ExceptionMixin()

    exception_mixin_4.exception(apply=True, exceptions=[hashlib.sha1])

# Generated at 2022-06-26 03:43:46.267250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Stub for exception
    exception_mixin_0 = ExceptionMixin()
    class DummyClass:
        def dummy_method(self):
            pass
    dummy_class_0 = DummyClass()
    class DummyClass:
        def dummy_method(self):
            pass
    dummy_class_1 = DummyClass()
    dummy_class_1.dummy_attribute = 0
    dummy_class_2 = DummyClass()
    dummy_class_2.dummy_attribute = 0
    dummy_class_2.dummy_attribute_1 = 0
    dummy_class_3 = DummyClass()
    dummy_class_3.dummy_attribute = 0
    dummy_class_3.dummy_attribute_1 = 0
    dummy_class_3.dummy_attribute_2 = 0
    dummy_ex

# Generated at 2022-06-26 03:45:01.017109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc = "ValueError"
    exception_mixin_0 = ExceptionMixin()

    @exception_mixin_0.exception(exc)
    def decorator_0(handler):
        assert callable(handler)
    decorator_0("test_value")

# class Blueprint(UrlPrefixMixin, ExceptionMixin, ResourcefulRouterMixin, RouteRegistrarMixin, SanicLocal, BlueprintSetupState):

# Generated at 2022-06-26 03:45:03.643808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_1 = ExceptionMixin()
    with pytest.raises(NotImplementedError):
        exception_mixin_1._apply_exception_handler()


# Generated at 2022-06-26 03:45:07.284828
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception('a')


test_ExceptionMixin_exception()

# Generated at 2022-06-26 03:45:08.995248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    exception_mixin_0.exception(KeyError, True)


# Generated at 2022-06-26 03:45:17.982479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise handler.exception

        @exception(Exception)
        async def handler(self, request, exception):
            raise Exception('An Exception occurred')

    exception_mixin = TestExceptionMixin()
    with pytest.raises(Exception) as exception_info:
        exception_mixin.handler('request', 'exception')
    expected = 'An Exception occurred'
    assert expected == str(exception_info.value)

# Generated at 2022-06-26 03:45:20.382999
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    method_name = "exception"
    exception_mixin = ExceptionMixin()
    assert not hasattr(exception_mixin, method_name)



# Generated at 2022-06-26 03:45:28.446038
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        assert issubclass(ExceptionMixin, object)
    except AssertionError as e:
        print(e)
    try:
        assert issubclass(ExceptionMixin, ExceptionMixin)
    except AssertionError as e:
        print(e)
    try:
        assert issubclass(ExceptionMixin, object)
    except AssertionError as e:
        print(e)
    try:
        assert issubclass(ExceptionMixin, object)
    except AssertionError as e:
        print(e)
    try:
        assert issubclass(ExceptionMixin, ExceptionMixin)
    except AssertionError as e:
        print(e)

# Generated at 2022-06-26 03:45:30.488078
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert not exception_mixin._future_exceptions

# Generated at 2022-06-26 03:45:37.587428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def catch_request_exceptions(request):
        pass
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    exception_mixin_0 = ExceptionMixin()
    assert isinstance(exception_mixin_0.exception(NotFound, ServerError)(catch_request_exceptions), types.FunctionType)

# Generated at 2022-06-26 03:45:41.100046
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin_0 = ExceptionMixin()
    try:
        exception_mixin_0.exception((type(None),), apply=True)(lambda: None)
    except TypeError as e:
        print(e)
    else:
        print('OK!')
