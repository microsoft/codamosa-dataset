

# Generated at 2022-06-24 04:05:59.489490
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin

# Generated at 2022-06-24 04:06:07.598058
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  from sanic.printer import log
  import logging
  logger = logging.getLogger()
  logger.setLevel(logging.DEBUG)
  # add the handler to the logger
  logger.addHandler(log)
  
  class ExceptionMixin_Test(ExceptionMixin):
    def __init__(self, *args, **kwargs) -> None:
      self._future_exceptions: Set[FutureException] = set()
    def _apply_exception_handler(self, handler: FutureException):
      test = handler.handler(None)
      print("Test: "+test)
      return

  ExceptionMixin_Test().exception("test1","test2")("test message")

test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:06:09.643394
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(1)

    em = ExceptionMixin()
    assert em._future_exceptions is not None

# Generated at 2022-06-24 04:06:14.917278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import json as json_response

    bp = Blueprint('test_bp')
    @bp.exception(TypeError)
    def type_error(request, exception):
        return json_response({'status': 'error', 'message': str(exception)})

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:06:16.069968
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc is not None

# Generated at 2022-06-24 04:06:22.099252
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MySanicApplication(ExceptionMixin):
        pass
    app = MySanicApplication()
    @app.exception(Exception, apply=True)
    def test(request, exception):
        pass
    assert len(app._future_exceptions) == 1


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:06:24.279754
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance._future_exceptions, set)


# Generated at 2022-06-24 04:06:33.014876
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.sanic import Sanic
    from sanic.blueprints import Blueprint

    def my_handler(*args, **kwargs):
        pass

    app = Sanic(__name__)
    blueprint = Blueprint('asd', url_prefix='/blue')
    blueprint.exception(NotImplementedError, 404, apply=False)(my_handler)

    # Test that a blueprint has a set of future exceptions
    assert isinstance(blueprint._future_exceptions, set)

    # Test that the exception decorator actually adds to the set of future exceptions
    assert len(blueprint._future_exceptions) == 1

    # Test that a Sanic object created without a blueprint has no future exceptions
    assert len(app._future_exceptions) == 0



# Generated at 2022-06-24 04:06:41.007191
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    foo_exception = Exception
    bar_exception = Exception

    def exception_handler(request, exception):
        return exception.args

    app = Sanic()
    blueprint = Blueprint(app, url_prefix='test')

    @blueprint.exception([foo_exception, bar_exception])
    def handle_exception(request, exception):
        return exception.args

    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:06:49.768274
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.endpoint import Endpoint

    bp = Blueprint('test_bp', url_prefix='test')
    class_1 = bp.__class__
    class_2 = ExceptionMixin.__class__
    class_3 = Endpoint.__class__
    class_4 = Blueprint.__class__

    assert issubclass(class_1, class_3)
    assert issubclass(class_1, class_4)
    assert issubclass(class_1, class_2)
    assert issubclass(class_2, class_3)
    assert issubclass(class_2, class_4)

# Generated at 2022-06-24 04:06:50.235953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:06:54.782068
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler):
            raise NotImplementedError

    handler, exceptions = None, None
    test_exception_mixin = TestExceptionMixin()
    exception_decorator = test_exception_mixin.exception(handler, *exceptions)
    assert exception_decorator == handler

# Generated at 2022-06-24 04:07:03.329126
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # create a class inheriting from ExceptionMixin
    class C(ExceptionMixin):
        pass

    # create an instance of this class
    c = C()
    # call method exception of ExceptionMixin
    exception = c.exception

    # test that this method returns a decorated method
    @exception(KeyError)
    def gh(a):
        return a

    # test that the decorator is correctly applied on the decorated method
    assert gh(22) == 22
    assert gh(xyz=22) == 22

    # test that the decorated method has not been called yet

# Generated at 2022-06-24 04:07:07.368712
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    @ExceptionMixin.exception(Exception)
    def except_handler(request, exception: Exception):
        return 'exception'

    # Act
    result = except_handler('arg1', 'arg2')

    # Assert
    assert result == 'exception'

# Generated at 2022-06-24 04:07:11.828901
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # pylint: disable=unused-variable
    class TestExceptionMixin(ExceptionMixin):
        pass

    exception = TestExceptionMixin()
    assert exception._future_exceptions == set()

# Generated at 2022-06-24 04:07:14.896118
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()


# Generated at 2022-06-24 04:07:21.898706
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint("test_bp")
    bp2 = Blueprint("test_bp2", ExceptionMixin)

    assert isinstance(bp._future_exceptions, set) is False
    assert isinstance(bp2._future_exceptions, set) is True
    assert bp2._future_exceptions == set()

    exception = FutureException(handler=None, exceptions=None)

    assert exception in bp._future_exceptions is False
    assert exception in bp2._future_exceptions is False


# Generated at 2022-06-24 04:07:27.285514
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    dummyExceptionMixin = DummyExceptionMixin()
    print(dummyExceptionMixin.__dict__)
    pass

#test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:07:36.211838
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.server import Sanic

    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self.handlers: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self.handlers.add(handler)

    app = Sanic("test_ExceptionMixin_exception")
    exception_mixin_test = ExceptionMixinTest(app)
    exception_mixin_test.exception(ValueError)(None)
    exception_mixin_test.exception(ValueError, apply=False)(None)
    assert len(exception_mixin_test.handlers) == 1
    exception_mixin_test.ex

# Generated at 2022-06-24 04:07:37.275081
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin, ExceptionMixin)


# Generated at 2022-06-24 04:07:41.037183
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    app = Sanic('sanic-session')
    test_mixin = ExceptionMixin()
    assert (test_mixin._future_exceptions) == set()


# Generated at 2022-06-24 04:07:48.665139
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Parent:
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    class Child(ExceptionMixin, Parent):
        pass

    child = Child()

    assert child._future_exceptions == set()
    # Use method exception of class ExceptionMixin
    exception_handler = child.exception(Exception)
    exception = FutureException(exception_handler, (Exception, ))
    child._future_exceptions.add(exception)
    child._apply_exception_handler(exception)
    assert child._future_exceptions == {exception}
    assert child.handler == exception

# Generated at 2022-06-24 04:07:53.711151
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MockExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = MockExceptionMixin()
    assert exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:07:58.897346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptionObj = ExceptionMixin()
    def handler():
        return 0

    exceptionObj.exception(Exception)(handler)
    apply_exception = exceptionObj._apply_exception_handler
    assert len(exceptionObj._future_exceptions) == 1
    exceptionObj._apply_exception_handler = lambda x: None
    exceptionObj.exception(Exception, apply=False)(handler)
    exceptionObj._apply_exception_handler = apply_exception
    assert len(exceptionObj._future_exceptions) == 2

# Generated at 2022-06-24 04:08:04.144884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @TestExceptionMixin.exception()
    def handlerFunc():
        pass

    test_ExceptionMixin = TestExceptionMixin()
    assert test_ExceptionMixin._future_exceptions

# Generated at 2022-06-24 04:08:04.712709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:07.961148
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    sanic.Sanic().blueprint



# Generated at 2022-06-24 04:08:15.554828
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint("abc", url_prefix="abc")
    bp._future_exceptions = set()
    assert bp._future_exceptions == set()
    exceptions1 = [SanicException, Exception]
    exceptions2 = [Exception]
    exception_handler = lambda *args, **kwargs: None
    exception = bp.exception(exceptions1)(exception_handler)
    exception_2 = bp.exception(exceptions2)(exception_handler)
    future_exception1 = FutureException(exception, exceptions1)
    future_exception2 = FutureException(exception_2, exceptions2)
    assert bp._future_exceptions == {future_exception1, future_exception2}

# Generated at 2022-06-24 04:08:16.795214
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mix = ExceptionMixin()
    assert isinstance(mix._future_exceptions, set)

# Generated at 2022-06-24 04:08:26.503913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TmpError(Exception):
        pass
    class Test:
        def __init__(self):
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)
    @Test.exception(TmpError)
    def a():
        pass
    assert type(Test()._future_exceptions.pop()) == FutureException
    assert issubclass(Test()._future_exceptions.pop()._exceptions[0], Exception)
    assert Test()._future_exceptions.pop()._handler() is None

# --------------------------------------------------------------------------- #
#                                                                             #
#   END OF FILE                                                               #
#                                                                             #
# --------------------------------------------------------------------------- #

# Generated at 2022-06-24 04:08:36.879674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.app import Sanic
    from sanic.models.futures import FutureException
    from sanic.views import HTTPMethodView

    class TestExceptionExceptionMixin(HTTPMethodView):

        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        @staticmethod
        def _apply_exception_handler(handler: FutureException):
            pass

        def get(self, request):
            return 'hello'

    class FakeBluePrint(ExceptionMixin):

        def register(self, *args, **kwargs):
            return kwargs['view'](), kwargs['uri']

    app = Sanic('test_ExceptionMixin_exception')
    fake_bp = FakeBluePrint('test_exception')


# Generated at 2022-06-24 04:08:41.534479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # make exception_mixin
    exception_mixin = ExceptionMixin()
    # make actual
    actual = exception_mixin.exception(ValueError)
    # make expected
    def decorator(handler):
        future_exception = FutureException(handler, (ValueError,))
        return handler
    # assert actual is expected
    assert actual == decorator

# Generated at 2022-06-24 04:08:47.017805
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    # All the future_exceptions have a handler, exceptios, and kwargs attribute
    # So, they should all be instance of FutureException class
    # That's why the assert condition is FutureException(None, None)
    assert ExceptionMixin().exception()(None) == FutureException(None, None)

# Generated at 2022-06-24 04:08:51.569552
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    # create an instance of ExceptionMixin to test
    exceptionMixinInstance = ExceptionMixin()
    
    # check results of constructor
    assert isinstance(exceptionMixinInstance, ExceptionMixin)
    assert exceptionMixinInstance._future_exceptions == set()
    assert exceptionMixinInstance._apply_exception_handler == NotImplemented


# Generated at 2022-06-24 04:08:58.003763
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    blueprint = Blueprint("exception test")
    blueprint._apply_exception_handler = lambda x: print(x)

    @blueprint.exception(Exception)
    async def test_exception(request, exception):
        return HTTPResponse(body="test handler")

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions == {
        FutureException(test_exception, (Exception,))
    }

# Generated at 2022-06-24 04:09:00.782030
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class TestExceptionMixin(ExceptionMixin):
        pass

    ex = TestExceptionMixin()
    assert ex._future_exceptions == set()


# Generated at 2022-06-24 04:09:10.542223
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.routes = []

        def add_route(self, route):
            self.routes.append(route)

    try:
        exception_mixin = TestExceptionMixin()
        @exception_mixin.exception()
        def exception_handler():
            pass

        assert(exception_handler.exception)
    except:
        assert(False)

    try:
        exception_mixin = TestExceptionMixin()
        @exception_mixin.exception()
        def exception_handler():
            pass

        exception_mixin.add_route("test")
        assert(exception_handler.exception)
    except:
        assert(False)


# Generated at 2022-06-24 04:09:11.695427
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:09:20.102780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    exception_mixin = TestExceptionMixin()
    assert exception_mixin is not None
    assert len(exception_mixin._future_exceptions) == 0

    # Test the global exception
    @exception_mixin.exception(Exception)
    def exception_handler():
        print("exception happened")
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert future_exception.handler is exception_handler
    assert len(future_exception.exceptions) == 1
    assert Exception in future_exception.exceptions

    # Test the global exception for specific exceptions

# Generated at 2022-06-24 04:09:25.903472
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    mixin=TestExceptionMixin()
    fun=mixin.exception(Exception)(lambda *args: None)
    assert len(mixin._future_exceptions) == 1
    future_exception=mixin._future_exceptions.pop()
    assert len(future_exception.exceptions) == 1
    assert future_exception.handler == fun

# Generated at 2022-06-24 04:09:31.666466
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint('test', url_prefix='test')

    @bp.listener('before_server_start')
    def before_server_start_handler(sanic, loop):
        print(sanic, loop)

    @bp.exception(Exception)
    def handler(request, exception):
        print(request, exception)

    assert len(bp.exception_handlers) == 1

    @bp.exception(Exception, Exception)
    def handler(request, exception):
        print(request, exception)

    assert len(bp.exception_handlers) == 2

# Generated at 2022-06-24 04:09:36.657101
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler):
            pass
    a = A()
    obj = a._future_exceptions
    assert isinstance(obj, set)

# Generated at 2022-06-24 04:09:39.083346
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test', url_prefix='test')

    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:09:42.620649
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    exception_mixin = TestExceptionMixin()
    assert exception_mixin
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:09:45.048412
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import ExceptionMixin
    mixin = ExceptionMixin()
    assert isinstance(mixin, ExceptionMixin)

# Generated at 2022-06-24 04:09:48.443386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    @bp.exception(ZeroDivisionError)
    def handle_exception(self, request_help, exception):
        return 'Exception'
    assert(handle_exception(None, None, ZeroDivisionError) == 'Exception')
    assert(handle_exception(None, None, LookupError) is None)

# Generated at 2022-06-24 04:09:51.639685
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:56.686315
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import RequestTimeout
    bp = Blueprint('bp')
    
    @bp.exception(RequestTimeout)
    def timeout(request, exception):
        return text('timeout')

    app = Sanic('sanic')
    app.blueprint(bp)
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'timeout'

# Generated at 2022-06-24 04:10:01.057637
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test:
        def __init__(self, *args, **kwargs):
            return

    assert ExceptionMixin.__init__(Test())

# Generated at 2022-06-24 04:10:05.820286
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc_mixin = ExceptionMixin()
    assert isinstance(exc_mixin, ExceptionMixin)
    exception_list = [1,2]
    def _handler():
        pass
    _handler = exc_mixin.exception(exception_list)(_handler)
    assert isinstance(_handler, FunctionType)
    assert len(exc_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:10:12.122558
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixinException(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    @TestExceptionMixinException.exception([IndexError])
    def handler(*args):
        raise IndexError('index error')


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:10:13.994725
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert len(instance._future_exceptions) == 0



# Generated at 2022-06-24 04:10:23.301676
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.models.futures import FutureException

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='/test')

    @blueprint.route('/1', methods=HTTP_METHODS, apply=False)
    def test_1(self, request):
        return 'test_1'

    @blueprint.route('/2', methods=HTTP_METHODS, apply=False)
    def test_2(self, request):
        return 'test_2'

    @blueprint.exception(Exception)
    def exception_handler_1(self, request, exception):
        return 'exception_1'


# Generated at 2022-06-24 04:10:24.321848
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert 1 == 1



# Generated at 2022-06-24 04:10:31.841299
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint("/test")

    @blueprint.exception(Exception, NotImplementedError)
    def _(request, exception):
        pass

    try:
        assert _ in blueprint._future_exceptions
    except:
        assert False

    try:
        assert Exception in _.exceptions
    except:
        assert False

    try:
        assert NotImplementedError in _.exceptions
    except:
        assert False

# Generated at 2022-06-24 04:10:36.437074
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyException(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    my_exception = MyException()
    assert my_exception
    assert my_exception._future_exceptions
    assert isinstance(my_exception._future_exceptions, set)


# Generated at 2022-06-24 04:10:37.846830
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert getattr(ExceptionMixin, "exception", None) is not None

# Generated at 2022-06-24 04:10:39.588303
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:10:44.023269
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mixin = _ExceptionMixin()
    # def func(a,b,c):
    #     pass
    mixin.exception(KeyError, 404, apply=False)(func)

# Generated at 2022-06-24 04:10:45.013442
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    return em

# Generated at 2022-06-24 04:10:47.416225
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin, object):
        def __init__(self):
            ExceptionMixin.__init__(self)

    ExceptionMixinTest()


# Generated at 2022-06-24 04:10:57.554278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_ExceptionMixin_obj = TestExceptionMixin()

    assert len(test_ExceptionMixin_obj._future_exceptions) == 0

    @test_ExceptionMixin_obj.exception(ValueError)
    def test_exception_decorator():
        print("Test")
        assert len(test_ExceptionMixin_obj._future_exceptions) == 1

    test_exception_decorator()

    @test_ExceptionMixin_obj.exception([ValueError, KeyError])
    def test_exception_decorator_list():
        print("Test")
        assert len(test_ExceptionMixin_obj._future_exceptions) == 2

# Generated at 2022-06-24 04:10:59.147281
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert isinstance(e,ExceptionMixin)


# Generated at 2022-06-24 04:11:03.388371
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert True
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()
    assert mixin._future_exceptions not in 'set'


# Generated at 2022-06-24 04:11:10.539247
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_(ExceptionMixin):
        def __init__(self):
            self.test = None

    def test_function(*args):
        self.test = args

    em = ExceptionMixin_()
    em.exception('a', 'b', 'c', apply=False)(test_function)
    test_dict = {'a', 'b', 'c'}
    assert em._future_exceptions.pop().exceptions == test_dict

# Generated at 2022-06-24 04:11:11.031996
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:14.133020
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__( *args, **kwargs)

    a = A()
    assert isinstance(a, ExceptionMixin)
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:11:15.589972
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
    except Exception as e:
        raise e

# Generated at 2022-06-24 04:11:19.590929
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint(name='', url_prefix='', version='')
    assert isinstance(bp, ExceptionMixin)
    # Test _future_exceptions attribute
    assert isinstance(bp._future_exceptions, set)



# Generated at 2022-06-24 04:11:23.120877
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:11:29.021534
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    blueprint = Blueprint()
    def handler():
        pass
    # this value is the same because there is no __init__ method in the class Blueprint
    # that would change this value
    assert blueprint._future_exceptions == set()
    assert blueprint.exception(Exception)(handler) == handler
    assert blueprint._future_exceptions == {FutureException(handler, (Exception,))}

# Generated at 2022-06-24 04:11:30.679557
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Implement Unit test
    pass

# Generated at 2022-06-24 04:11:39.962728
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):

        def __init__(self):
            self.x = set()
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self.x.add(handler)

    a = A()
    assert a.x == set()

    @a.exception(apply=False)
    async def handle_error(req, res, exc):
        return res

    assert a.x == set()

    handle_error_1 = a.exception(Exception)(handle_error)
    assert a.x == {FutureException(handle_error_1, (Exception,))}

    @a.exception(Exception, apply=False)
    async def handle_error_2(req, res, exc):
        return res


# Generated at 2022-06-24 04:11:44.020317
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    new_ExceptionMixin = ExceptionMixin()
    assert isinstance(new_ExceptionMixin, ExceptionMixin)
    assert new_ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:51.268684
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinChild(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    exception_mixin_child = ExceptionMixinChild()

    @exception_mixin_child.exception(AttributeError, apply=True)
    def except_test(request, error):
        return error

    assert len(exception_mixin_child._future_exceptions) == 1
    deco = exception_mixin_child._future_exceptions.pop()
    assert type(deco.handler) == types.FunctionType
    assert deco.exceptions == (AttributeError,)

# Generated at 2022-06-24 04:11:52.232766
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint

# Generated at 2022-06-24 04:11:56.809649
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    exception_mixin = TestExceptionMixin()
    assert type(exception_mixin._future_exceptions) == set
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:11:57.995100
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()

# Generated at 2022-06-24 04:11:59.701509
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionmixin = ExceptionMixin()
    assert exceptionmixin._future_exceptions == set()


# Generated at 2022-06-24 04:12:08.721798
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import ServerError
    from sanic.response import text
    app = Sanic()

    class Foo(ExceptionMixin):
        pass
    foo = Foo()

    # test that all exception handlers get added
    # to self._future_exceptions
    @foo.exception(ZeroDivisionError)
    def zero_division_error(request, exception):
        return text('divided by zero')

    @foo.exception(RuntimeError)
    def runtime_error(request, exception):
        return text('RuntimeError')

    @foo.exception(ServerError)
    def server_error_handlers(request, exception):
        return text('ServerError')

    @app.exception(ServerError)
    def server_error_handler(request, exception):
        return text

# Generated at 2022-06-24 04:12:11.131690
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    This method tests the constructor of class ExceptionMixin, it asserts that the sample object is not None
    """

    a = ExceptionMixin()
    assert (a._future_exceptions is not None)


# Generated at 2022-06-24 04:12:12.601015
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Noop:
        pass
    exception_mixin = ExceptionMixin()
    assert exception_mixin == Noop()

# Generated at 2022-06-24 04:12:19.655793
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exceptions_mixin = ExceptionMixinTest()
    assert len(exceptions_mixin._future_exceptions) == 0

    @exceptions_mixin.exception(Exception)
    def handler(request, exception):
        pass

    assert len(exceptions_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:12:24.289113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeExceptionMixin:
        def _apply_exception_handler(self, handler: FutureException):
            pass
    fakeExceptionMixin = FakeExceptionMixin()
    assert isinstance(fakeExceptionMixin, ExceptionMixin)

    future_exception_handler = fakeExceptionMixin.exception('test')
    assert callable(future_exception_handler)

# Generated at 2022-06-24 04:12:26.189119
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test = ExceptionMixin()
    test._apply_exception_handler = lambda x: x
    assert test.exception is not None

# Generated at 2022-06-24 04:12:33.028182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        pass

    dummy_exception_mixin = DummyExceptionMixin()

    @dummy_exception_mixin.exception(Exception)
    def ex(request, exception):
        return True

    assert mock.call(ex(None, None))

    @dummy_exception_mixin.exception(Exception, apply=True)
    def ex2(request, exception):
        return True

    assert mock.call(ex(None, None))

    @dummy_exception_mixin.exception([Exception])
    def ex3(request, exception):
        return True

    assert mock.call(ex(None, None))

# Generated at 2022-06-24 04:12:40.117433
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin.exception(ServerError)(lambda: None) == (lambda: None)

# Generated at 2022-06-24 04:12:41.921256
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:12:46.456300
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test', url_prefix='test', version='test')

    @bp.exception([Exception])
    def test(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == test
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:12:47.311095
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin().__init__()

# Generated at 2022-06-24 04:12:48.159181
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()

# Generated at 2022-06-24 04:12:59.038395
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._future_exceptions.add(1)
            self._future_exceptions.add(2)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class MockBlueprint(Blueprint):
        def __init__(self, *args, **kwargs) -> None:
            self.exception_handlers = []

        def error(self, request: Request, exception: Exception):
            pass

    blueprint = Mock

# Generated at 2022-06-24 04:13:04.684187
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    app = Sanic(__name__)

    @app.route('/')
    async def handler(request):
        return request.app.name

    request, response = app.test_client.get('/')

    assert response.text == '__main__'

# Generated at 2022-06-24 04:13:14.095901
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    class MyHTTPMethodView(HTTPMethodView, ExceptionMixin):
        def get(self, request):
            raise ValueError("Just a test exception")

    blueprint = Blueprint("blueprint", url_prefix='/exception')
    blueprint.add_route(MyHTTPMethodView.as_view(), "/")

    app = Sanic("test_ExceptionMixin")
    app.blueprint(blueprint)
    request, response = app.test_client.get("/exception/")
    assert response.status == 500





# Generated at 2022-06-24 04:13:19.756283
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.futures import FutureException
    assert issubclass(ExceptionMixin, FutureException)
    assert isinstance(ExceptionMixin, type)
    assert callable(ExceptionMixin)
    object1 = ExceptionMixin()
    assert object1 is not None


# Generated at 2022-06-24 04:13:20.346802
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:13:28.535994
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.init_args = args
            self.init_kwargs = kwargs
            self.future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self.future_exceptions.add(handler)

    test_obj = ExceptionMixinTest('foo', bar='baz')

    assert test_obj.init_args == ('foo',)
    assert test_obj.init_kwargs == {'bar': 'baz'}


# Generated at 2022-06-24 04:13:33.334091
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    app = Sanic(__name__)
    bp = Blueprint("test_bp")
    #  test _future_exceptions
    assert bp._future_exceptions == set()
    # test exception
    bp.exception(NotFound)
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-24 04:13:40.409204
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # GIVEN
    class testExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin = testExceptionMixin()

    # WHEN
    def handler():
        pass

    test_mixin.exception(IOError)(handler)
    exception = test_mixin._future_exceptions.pop()

    # THEN
    assert exception.handler is handler
    assert exception.exceptions == (IOError,)

# Generated at 2022-06-24 04:13:44.538895
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BPMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    A = BPMixin()
    assert isinstance(A, BPMixin)




# Generated at 2022-06-24 04:13:46.018627
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-24 04:13:51.744709
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
    a = A()
    print(issubclass(A, ExceptionMixin))
    print(isinstance(a, ExceptionMixin))
    assert issubclass(A, ExceptionMixin)
    assert isinstance(a, ExceptionMixin)
# test_ExceptionMixin()



# Generated at 2022-06-24 04:13:59.605534
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Create mock of class to check if exception handler is added
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exception_handler = -1

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler

    mock_obj = MockExceptionMixin()
    assert (mock_obj._future_exceptions == set())
    assert (mock_obj.exception_handler == -1)


# Generated at 2022-06-24 04:14:02.637378
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinImplement(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    em = ExceptionMixinImplement()
    assert not em._future_exceptions

# Generated at 2022-06-24 04:14:05.246491
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintTest(ExceptionMixin):
        pass
    bp = BlueprintTest()
    assert isinstance(bp.exception(Exception), types.FunctionType)

# Generated at 2022-06-24 04:14:07.407839
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert isinstance(bp, ExceptionMixin)


# Generated at 2022-06-24 04:14:13.213791
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(cls, *args, **kwargs):
            cls._future_exceptions = set()
            cls._apply_exception_handler = mock.Mock()
    ex_test = ExceptionMixinTest()
    assert ex_test._future_exceptions == set()
    assert ex_test._apply_exception_handler is not None


# Generated at 2022-06-24 04:14:18.533612
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinSubClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    exception_mixin = ExceptionMixinSubClass()
    exception_subclass = exception_mixin.exception(Exception)
    exception_subclass(lambda a: a)
    assert exception_mixin.handler.handler(1) == 1

# Generated at 2022-06-24 04:14:21.420770
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    emx = ExceptionMixin()
    assert emx._future_exceptions == set()

# Generated at 2022-06-24 04:14:22.953680
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    app = Application()
    assert(app._future_exceptions == set())

# Generated at 2022-06-24 04:14:26.960020
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin_1 = ExceptionMixin()
    assert exception_mixin_1._future_exceptions == set()
    exception_mixin_2 = ExceptionMixin(1, 2, 3)
    assert exception_mixin_2._future_exceptions == set()


# Generated at 2022-06-24 04:14:30.075822
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("ExceptionMixin")
    assert blueprint


# Generated at 2022-06-24 04:14:32.033389
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert type(exception) == ExceptionMixin


# Generated at 2022-06-24 04:14:40.114182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.exceptions import SanicException
    from sanic.models.handlers import Handler

    def asd():
        bp = Blueprint(name='a')

        @bp.exception(ValueError)
        async def test(request, exception):
            raise ValueError

        assert len(bp.futures['exceptions']) == 1
        assert isinstance(bp.futures['exceptions'][0], FutureException)
        assert isinstance(bp.futures['exceptions'][0].handler, Handler)
        assert bp.futures['exceptions'][0].handler.function == test
        assert bp.futures['exceptions'][0].exceptions == [ValueError]


# Generated at 2022-06-24 04:14:40.699181
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:14:44.150634
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    @TestClass.exception(NameError)
    def handler(request, exception):
        pass

    assert isinstance(TestClass()._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:14:46.308817
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    Test :class:`ExceptionMixin` constructor
    """
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:14:47.709473
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:14:51.637059
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    exception_mixin = TestExceptionMixin()

    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(exception_mixin._future_exceptions, set)

# Generated at 2022-06-24 04:14:55.325854
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    app = Blueprint("test_ExceptionMixin_exception")
    app.exception(Exception)(lambda x: x)
    assert len(app._future_exceptions) == 1

# Generated at 2022-06-24 04:15:03.791575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    app = Sanic()

    @app.exception(ZeroDivisionError)
    def div_error(request, exception):
        return 'divided by zero'

    assert hasattr(app, '_future_exceptions') and isinstance(app._future_exceptions, set)

    assert len(app._future_exceptions) == 1
    assert div_error in app._future_exceptions

    future_exception = next(iter(app._future_exceptions))
    assert future_exception.handler is div_error
    assert future_exception.exceptions is (ZeroDivisionError, )
    return



# Generated at 2022-06-24 04:15:08.620793
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception = (ValueError, KeyError)

    @exception_mixin.exception(exception)
    def handler():
        pass

    assert exception_mixin._future_exceptions
    assert len(exception_mixin._future_exceptions) == 1
    assert isinstance(exception_mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:15:09.429521
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-24 04:15:20.100407
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    This method tests the method exception in class ExceptionMixin
    """
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.utils import sanic_endpoint_test

    blueprint = Blueprint(__name__, url_prefix='/test')

    @blueprint.exception(Exception)
    def handler(request, exception):
        return text('Internal server error', 500)

    app = Sanic('test_ExceptionMixin_exception')
    blueprint.register(app, url_prefix='/test')

    @app.route('/test', methods=['GET'])
    async def test(request):
        raise ServerError('Test server error')

    request, response = sanic_endpoint_test(app)
    assert response.status == 500

# Generated at 2022-06-24 04:15:29.266826
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Unit test for method exception of class ExceptionMixin"""
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_class = TestExceptionMixin()

    @test_class.exception(ValueError)
    def test_handler(request, exception):
        """docstring for test_handler"""
        print("Catch exception:", exception)

    assert test_class._future_exceptions is not None
    assert len(test_class._future_exceptions) == 1


# Generated at 2022-06-24 04:15:31.243746
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass(ExceptionMixin):
        pass
    a = MyClass()
    a.exception(test_ExceptionMixin_exception)

# Generated at 2022-06-24 04:15:32.965062
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    obj = Test()
    assert obj._future_exceptions == set()

# Generated at 2022-06-24 04:15:44.840032
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import empty
    import pytest

    app = Sanic(__name__)
    bp = Blueprint('test_exception')

    @bp.exception(ServerError)
    def ignore_exception(request, exception):
        return empty()

    @bp.exception(ServerError)
    def ignore_exception_2(request, exception):
        return empty()

    @app.exception(ServerError)
    def ignore_exception_global(request, exception):
        return empty()

    @app.route('/1')
    async def handler(request):
        raise ServerError("Foo", status_code=500)

    app.blueprint(bp)
    request,

# Generated at 2022-06-24 04:15:47.840800
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            pass

    test = TestExceptionMixin()
    assert isinstance(test._future_exceptions, set)

# Generated at 2022-06-24 04:15:50.417341
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Create an instance of ExceptionMixin class
    mixin = ExceptionMixin()
    assert mixin != None
    assert isinstance(mixin, ExceptionMixin)


# Generated at 2022-06-24 04:15:55.709473
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # docstring = ExceptionMixin().exception.__doc__
    # expected = True
    # assert expected == True
    from sanic.blueprints import Blueprint
    from sanic.response import text

    bp = Blueprint('test_ExceptionMixin_exception')

    @bp.exception([IndexError, AttributeError])
    def handler(request, exception):
        return text('Internal server error - ' + str(exception), 500)

    @bp.route('/1')
    def handler(request):
        pass

    assert True