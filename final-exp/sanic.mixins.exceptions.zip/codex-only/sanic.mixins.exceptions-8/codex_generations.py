

# Generated at 2022-06-24 04:05:46.950559
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True == True

# Generated at 2022-06-24 04:05:48.568538
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def handler():
        return 'This is a handler'

    assert handler() == 'That is a handler'

# Generated at 2022-06-24 04:05:56.000425
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic.models.endpoint import Endpoint

    bp = Blueprint("test_bp", url_prefix="test", strict_slashes=True)
    en = Endpoint("test_en")
    bp._exception_handler = ExceptionMixin.exception(bp, Exception)(bp._exception_handler) # noqa
    bp._exception_handler(None, en, None, None)
    assert bp._future_exceptions



# Generated at 2022-06-24 04:05:58.489465
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test_bp', url_prefix='test')
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-24 04:06:02.684732
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint("TestBlueprint", url_prefix="TestBlueprint")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:06:04.447042
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert isinstance(e._future_exceptions, set)



# Generated at 2022-06-24 04:06:08.909807
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em is not None

# Generated at 2022-06-24 04:06:17.713239
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    import sys
    import pytest
    from unittest.mock import patch

    class DummyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    app = Sanic('test_exception_mixin')
    dummy_mixin = DummyExceptionMixin()

    @dummy_mixin.exception(ValueError)
    def func():
        pass

    assert hasattr(func, '__exception_handler')
    assert isinstance(func.__exception_handler[0], FutureException)
    assert FutureException(func, (ValueError,)) in dummy_mixin._future_exceptions

    # Test for Exception
    func_exception = func.__exception_handler[0]
    assert func_exception.exception

# Generated at 2022-06-24 04:06:24.325323
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import RequestTimeout
    from sanic.response import text  # noqa

    bp = Blueprint(__name__)

    @bp.exception(RequestTimeout)
    async def handle_exception(request, exception):
        return text("Error", status=500)

    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:06:27.293313
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_handler = exception_mixin.exception(Exception)
    assert exception_handler.__name__ == 'handler'

# Generated at 2022-06-24 04:06:34.295072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExeptionMixinImplement(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    exeption_mixin_implement = ExeptionMixinImplement()

    @exeption_mixin_implement.exception(Exception)
    def excep_handler(request, exception):
        return {'test': 1}

    assert len(exeption_mixin_implement._future_exceptions) == 1
    assert list(
        map(
            lambda x: x.handler(request=None, exception=None),
            exeption_mixin_implement._future_exceptions)) == [{'test': 1}]

# Generated at 2022-06-24 04:06:36.301464
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Case 1: ExceptionMixin().
    assert ExceptionMixin().__init__() == NotImplementedError

# Generated at 2022-06-24 04:06:40.398961
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    _test_future_exceptions.clear()
    fm = FutureExceptionMixin()
    assert fm._future_exceptions == set()


# Generated at 2022-06-24 04:06:43.504442
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.models.blueprints import Blueprint

    app = Sanic('MyApp')
    blueprint = Blueprint('TestBlueprint')
    assert isinstance(blueprint, ExceptionMixin)

# Generated at 2022-06-24 04:06:49.467549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    @sanic_app.exception(ZeroDivisionError)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    client = sanic_app.test_client

    # 会触发 ZeroDivisionError 的异常
    request, response = client.get('/')

    assert response.text == 'Internal Server Error'
    assert response.status == 500



# Generated at 2022-06-24 04:06:50.166640
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: to be implemented
    pass

# Generated at 2022-06-24 04:06:54.949784
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from unittest.mock import Mock
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint('test_bp')

    def exception_handler(_req, _exc):
        return _exc

    bp.exception(NotFound, apply=True)(exception_handler)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == exception_handler



# Generated at 2022-06-24 04:07:01.191907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMock(ExceptionMixin):
        def test(self):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            handler.handler()

    mixin = ExceptionMixinMock()
    mixin.exception(Exception)(mixin.test)

# Generated at 2022-06-24 04:07:01.907182
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:07:06.682503
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    obj = TestExceptionMixin()
    assert(isinstance(obj._future_exceptions, set))
    assert(len(obj._future_exceptions) == 0)


# Generated at 2022-06-24 04:07:08.561707
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin

# Unit for testing method 'exception' of class ExceptionMixin

# Generated at 2022-06-24 04:07:12.338775
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintStub(ExceptionMixin):
        pass

    blueprint = BlueprintStub()

    @blueprint.exception(ZeroDivisionError)
    def exception_handler_zero(request, exception):
        return 'except_zero'

    assert len(blueprint._future_exceptions) == 1



# Generated at 2022-06-24 04:07:13.989986
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin
    assert mixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:18.336306
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handle_exception():
        pass
    
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = ExceptionMixinTest()
    test.exception(ValueError, ApplyError)(handle_exception)
    print(test._future_exceptions)

# Generated at 2022-06-24 04:07:22.848730
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Tester(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions is (RuntimeError, IndexError)

    t = Tester()
    @t.exception([RuntimeError, IndexError])
    def f(request, e):
        pass
    assert t._future_exceptions

# Generated at 2022-06-24 04:07:24.442182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global apply
    global exceptions
    apply = True
    exceptions = (Exception,)
    assert apply == True
    assert exceptions == (Exception,)

# Generated at 2022-06-24 04:07:32.542590
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = TestExceptionMixin()

    # decorator function of method exception
    decorator = exception_mixin.exception(Exception)

    # handler decorated by decorator
    @decorator
    def handler(request, exception):
        pass

    future_exception = FutureException(handler, (Exception))
    assert future_exception in exception_mixin._future_exceptions

# Generated at 2022-06-24 04:07:34.986231
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	exception_mixin = ExceptionMixin()
	assert isinstance(exception_mixin,ExceptionMixin)
	assert isinstance(exception_mixin._future_exceptions,set)


# Generated at 2022-06-24 04:07:45.382493
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import Aborter
    from sanic.handlers import ErrorHandler
    from sanic.request import Request
    from sanic.response import HTTPResponse, json
    from sanic import Sanic


# Generated at 2022-06-24 04:07:46.124803
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions

# Generated at 2022-06-24 04:07:47.980572
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    @Blueprint.exception(ValueError)
    def error_handler(request, exception):
        return exception

    assert error_handler(None, "Sample Exception") == "Sample Exception"

# Generated at 2022-06-24 04:07:49.279381
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert instance._future_exceptions == set()

# Generated at 2022-06-24 04:07:54.304030
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    def decorator(handler):
        return handler

    exceptionMixin = ExceptionMixin(A)
    exceptionMixin.exception(Val)

# Generated at 2022-06-24 04:08:00.455679
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler:FutureException):
            pass

    t = TExceptionMixin()
    assert t._future_exceptions is not None


# Generated at 2022-06-24 04:08:02.854913
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return 'Test'

    assert Test().exception(ValueError)('test_ExceptionMixin')() == 'Test'

# Generated at 2022-06-24 04:08:08.946884
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    TestExceptionMixin()


if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:08:12.660582
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mock():
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()
        def _apply_exception_handler(self, handler):
            pass
    mock = Mock()
    @mock.exception(arg)
    def catch(request, exception):
        pass
    future_exception = FutureException(catch, (arg,))
    mock._future_exceptions.add(future_exception)
    assert mock._future_exceptions == {future_exception}

# Generated at 2022-06-24 04:08:20.795049
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.exceptions import NotFound, Forbidden

    app = Sanic(__name__)

    bp = Blueprint("user", url_prefix="/user")

    @bp.exception([NotFound, Forbidden])
    def custom_error_handler(request, exception):
        return text(
            "Exception: {}".format(exception),
            status=getattr(exception, "status_code", 500),
        )

    @bp.route("/")
    async def index(request):
        raise NotFound

    app.blueprint(bp)

    _, response = app.test_client.get("/user/")
    assert response.status == 404


# Generated at 2022-06-24 04:08:23.282270
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    helper_class = type('HelperClass', (ExceptionMixin,), {})
    helper_instance = helper_class()
    assert isinstance(helper_instance._future_exceptions, set)

# Generated at 2022-06-24 04:08:28.597702
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionClass(ExceptionMixin):
        pass
    
    class ExceptionClass2(ExceptionMixin):
        _future_exceptions = {FutureException(TypeError, "This is an error")}
        
        def _apply_exception_handler(self, handler):
            pass
    assert ExceptionClass()._future_exceptions == set()
    assert ExceptionClass2()._future_exceptions == {FutureException(TypeError, "This is an error")}

test_ExceptionMixin()

# Generated at 2022-06-24 04:08:31.846419
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # prepare the test data
    try:
        # call the function to test
        exception_mixin = ExceptionMixin()
    except Exception as e:
        # log the exception
        pytest.fail(str(e))


# Generated at 2022-06-24 04:08:35.458442
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    instance = TestExceptionMixin()
    assert len(instance._future_exceptions) == 0



# Generated at 2022-06-24 04:08:44.981065
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from validator_collection import validators
    import re

    @ExceptionMixin.exception(ZeroDivisionError)
    def zero_division_exception_handler(request, exception):
        return text("You caused a zero division exception.")

    blueprint = Blueprint("test_blueprint")
    blueprint.exception(ZeroDivisionError)(
        zero_division_exception_handler
    ) # should pass

    app = Sanic("test_server")

    @app.route("/")
    async def handler(request):
        raise ZeroDivisionError("Request caused zero division error.")

    app.blueprint(blueprint)
    request, response = app.test_client.get("/")


# Generated at 2022-06-24 04:08:47.673857
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert "_future_exceptions" in blueprint.__dict__
    assert type(blueprint.__dict__.get('_future_exceptions')) == set


# Generated at 2022-06-24 04:08:51.557027
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert isinstance(obj._future_exceptions, set)
    

# Generated at 2022-06-24 04:08:55.738081
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Template:
        def __init__(self):
            self._future_exceptions = []
        def add_exception(self, future_exception):
            self._future_exceptions.append(future_exception)
    exm = ExceptionMixin()
    exm.exception(Exception)(Template.add_exception)

# Generated at 2022-06-24 04:08:57.272402
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    client = ExceptionMixin()
    assert len(client._future_exceptions) == 0


# Generated at 2022-06-24 04:08:59.126918
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert isinstance(em, ExceptionMixin) is True

# Generated at 2022-06-24 04:09:01.047459
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass
    assert A()._future_exceptions == set()

# Generated at 2022-06-24 04:09:02.120016
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #TODO: Implement test
    pass

# Generated at 2022-06-24 04:09:05.494149
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Foo(ExceptionMixin):
        def __init__(self):
            pass
    foo = Foo()
    assert foo._future_exceptions == set()
    assert foo.__dict__['_future_exceptions'] == set()


# Generated at 2022-06-24 04:09:13.292018
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_exception = Exception
    my_message = 'my message'
    my_blueprint = ExceptionMixin()
    my_blueprint.exception(my_exception)(lambda request, exception, message=None: request)
    my_blueprint.exception(my_exception)(lambda request, exception, message=None: exception)
    my_blueprint.exception(my_exception)(lambda request, exception, message=None: message)

    assert True


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:09:16.419321
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class B(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    b = B()
    assert b._future_exceptions == set()
    assert b._blueprint_name is None

# Generated at 2022-06-24 04:09:22.338382
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

    try:
        ExceptionMixin()
    except TypeError:
        try:
            TestExceptionMixin()
        except:
            assert False
    else:
        assert False

# Unit test case for method exception

# Generated at 2022-06-24 04:09:27.508356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #
    # Intentionally fail this test by not implementing the method
    # _apply_exception_handler
    #
    class DummyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
 
    dummyClass = DummyClass()
    with pytest.raises(NotImplementedError):
        dummyClass.exception()



# Generated at 2022-06-24 04:09:30.986228
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            
    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-24 04:09:40.612574
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureException:
        def __init__(self, handler, exceptions):
            self.handler = handler
            self.exceptions = exceptions
            self.applied = False

        def apply_to(self, blueprint):
            self.applied = True

    class Blueprint:
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            handler.apply_to(handler)

    blueprint = Blueprint()
    blueprint.exception(Exception)(lambda x: x)
    assert any(future_exception.applied for future_exception in blueprint._future_exceptions)


# Generated at 2022-06-24 04:09:50.537111
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic(__name__)

    @app.route('/')
    def index(request):
        return json({"message": "Hello World!"})

    class POTest(Blueprint, ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    po = POTest("test_ExceptionMixin_exception")
    po.exception(KeyError)(lambda request, exception:
                           json({"Exception": str(exception)}))
    app.blueprint(po)
    request, response = app.test_client.get("/test_ExceptionMixin_exception")
    assert response.status == 404


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:09:53.031512
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super(A, self).__init__()

    a = A()
    assert len(a._future_exceptions) == 0



# Generated at 2022-06-24 04:09:53.827478
# Unit test for constructor of class ExceptionMixin

# Generated at 2022-06-24 04:10:00.843934
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test on class ExceptionMixin
    def _apply_exception_handler(self, handler: FutureException):
        return handler

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    test_ExceptionMixin = TestExceptionMixin()
    test_ExceptionMixin._apply_exception_handler = _apply_exception_handler

    # Test default case
    @test_ExceptionMixin.exception()
    def test():
        return 1

    assert test == 1

    # Test on class TestExceptionMixin
    def _apply_exception_handler(self: TestExceptionMixin, handler: FutureException):
        return handler.handler_func

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

       

# Generated at 2022-06-24 04:10:04.742411
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @A.exception(AssertionError)
    def foo():
        pass

    assert foo in list(A().exception_handlers)

# Generated at 2022-06-24 04:10:07.118666
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin._future_exceptions, set)


# Generated at 2022-06-24 04:10:13.787373
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_exception = Exception('test')
    test_app = Sanic('test_sanic')
    test_route = test_app.route('/test')(lambda: 5/0)
    test_app.exception(test_exception)(lambda r, e: 'test_exception')
    test_app.run()
    print(test_app.exception(test_exception)(lambda r, e: 'test_exception'))

#test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:10:23.105272
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinClass(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    def funct1():
        return 1

    def funct2():
        return 2

    def funct3():
        return 3

    exception_mixin = ExceptionMixinClass()

    # Test when only one exception is passed
    @exception_mixin.exception(NotImplementedError)
    def test_exception_handler1():
        pass

    assert(len(exception_mixin._future_exceptions)) == 1
    test_exception_list = list(exception_mixin._future_exceptions)[0]
    assert(test_exception_list._exceptions == (NotImplementedError,))

# Generated at 2022-06-24 04:10:24.524130
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:10:36.089490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic()

    @app.get("/")
    def handler(request):
        return 0

    blueprint = Blueprint('test_bp')
    blueprint.exception(ValueError)(handler)

    blueprint.register(app, url_prefix='/bp')
    app.blueprint(blueprint)

    assert blueprint.exception_handler_order == Blueprint.exception_handler_order

    request, response = app.test_client.get('/')
    assert response.status == 200

    request, response = app.test_client.get('/bp')
    assert response.status == 200

    request, response = app.test_client.get('/bp/error')
    assert response.status == 200

# Generated at 2022-06-24 04:10:41.591042
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler
    exception_blueprint = Blueprint("ExceptionMixin").exception(TypeError)

    # Check that creating a Blueprint with exception handler works
    assert isinstance(exception_blueprint, Blueprint)

    # Sanity check that the list of exceptions is empty
    assert set() == exception_blueprint._future_exceptions


# Generated at 2022-06-24 04:10:50.660401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.futures import FutureException

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, future_exception: FutureException):
            pass

    # Case 1: add an exception handler with single exception
    my_exception_handler = MyExceptionMixin()
    assert 0 == len(my_exception_handler._future_exceptions)
    my_exception_handler.exception(ValueError)(Sanic.exception)
    assert 1 == len(my_exception_handler._future_exceptions)

    # Case 2: add an exception handler with multiple exceptions
    my_exception_handler_2 = MyExceptionMixin()

# Generated at 2022-06-24 04:10:52.028071
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em
    assert isinstance(em, ExceptionMixin)


# Generated at 2022-06-24 04:11:02.785328
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.response import text
    from sanic.exceptions import NotFound

    bp = Blueprint('test_bp')
    app = Sanic('test_sanic')

    class H(ExceptionMixin):
        def __init__(self):
            # from pudb import set_trace;set_trace()
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            # from pudb import set_trace;set_trace()
            ...
            # app.exception(handler, *(handler.exceptions))

    h = H()

    @h.exception(NotFound)
    def f_handler(request, exception):
        return text(str(exception))


# Generated at 2022-06-24 04:11:04.149108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:05.923161
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert hasattr(ExceptionMixin,"__init__")
    assert callable(ExceptionMixin.__init__)


# Generated at 2022-06-24 04:11:08.647767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:10.036370
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass  # TODO


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:11:11.143848
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)



# Generated at 2022-06-24 04:11:12.859877
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    exception_mixin = TestExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:19.369981
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # init with only pos args
    mixin_without_args_kwargs = ExceptionMixin()
    assert mixin_without_args_kwargs is not None

    # init with pos args and kwargs
    mixin_with_args_kwargs = ExceptionMixin(1, 2, a = 3, b = 4)
    assert mixin_with_args_kwargs is not None


# Generated at 2022-06-24 04:11:24.717101
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    
    class BB(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            
    b = BB()
    assert b._future_exceptions == set()
    
    

# Generated at 2022-06-24 04:11:26.595131
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        pass
    
    @Test().exception(Exception)
    def handler(request, exception):
        return response



# Generated at 2022-06-24 04:11:32.755393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def _decorator(handler):
        return handler
    
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return

    _exception_mixin = _ExceptionMixin()
    handler = _exception_mixin.exception('a', 'b', apply=False)(_decorator)
    handler()

# Generated at 2022-06-24 04:11:36.432671
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Temp(ExceptionMixin, object):
        pass

    # constructor
    Temp()

# Generated at 2022-06-24 04:11:44.551588
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class app:
        def __init__(self, *args, **kwargs):
            self.exception = set()

        def exception_handler(self, handler, exceptions):
            self.exception.add(FutureException(handler, exceptions))

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
            self.app = app()

        def _apply_exception_handler(self, exception):
            self.app.exception_handler(exception.handler, exception.exceptions)

    test = TestExceptionMixin()
    exception_handler = test.exception([Exception])
    assert test._future_exceptions == set()
    exception_handler(Exception)
    assert test._future_ex

# Generated at 2022-06-24 04:11:48.634601
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    f = ExceptionMixin(args,kwargs)
    assert f.hasattr('_future_exceptions')


# Generated at 2022-06-24 04:11:52.571455
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    args = (1, 1, 'a', 1)
    obj = ExceptionMixin()
    obj.exception("A", "B", "C")
    obj.exception("A", "B", "C")
    assert obj._future_exceptions
    assert len(obj._future_exceptions) > 0
    assert len(obj._future_exceptions) < 3
    obj.exception("D", "E")
    assert len(obj._future_exceptions)>2

# Generated at 2022-06-24 04:11:55.846252
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass:
        ExceptionMixin
    test_class = TestClass()
    print(type(test_class._future_exceptions))
    assert isinstance(test_class._future_exceptions, set)


# Generated at 2022-06-24 04:11:58.451048
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exm = ExceptionMixin()
    assert len(exm._future_exceptions) == 0


# Generated at 2022-06-24 04:11:59.045037
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:59.981756
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:12:05.913263
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Test case 1: test class attributes initialize correctly
    mixin = ExceptionMixin()
    assert not mixin._future_exceptions
    # Test case 2: test invalid input
    with pytest.raises(TypeError):
        mixin = ExceptionMixin(1,2,3)


# Generated at 2022-06-24 04:12:14.061081
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError
    from sanic.handlers import ErrorHandler

    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            # For convenience, the mapping from exceptions to handlers is
            # located in an instance of sanic.handlers.ErrorHandler.
            error_handler = self.app.error_handler
            # The handler is called with various arguments passed to the
            # exception decorator.
            error_handler.add(handler.exceptions, handler.handler,
                              **handler.kwargs)

    # Create an instance of A
    a = A()

    # Create an error handler object
    error_handler = Error

# Generated at 2022-06-24 04:12:21.657617
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint

    class TestBlueprint(ExceptionMixin, Blueprint):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self)
            Blueprint.__init__(self, *args, **kwargs)

    bp = TestBlueprint("test_blueprint")
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 0


# Generated at 2022-06-24 04:12:27.693896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    
    class TestSanic:
        pass
    test_sanic = TestSanic()

    from sanic.exceptions import exceptions
    
    test_exceptions = set(exceptions)

    from .blueprint_unit_test import test_blueprint
    test_blueprint.exception(*exceptions)(lambda : print("Error"))

    assert test_blueprint._future_exceptions == test_exceptions

# Generated at 2022-06-24 04:12:33.749175
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    t = test_ExceptionMixin()
    @t.exception([IOError])
    def test(request, exception):
        pass
    t._apply_exception_handler(FutureException(test, [IOError]))

    assert t._future_exceptions[0].handler(None, None) == None

# Generated at 2022-06-24 04:12:43.677087
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.futures import FutureException
    from asyncio import sleep
    app = Sanic(__name__)
    ExceptionMixin.__init__(app)

    assert app._future_exceptions == set()
    @app.exception(Exception)
    def handler(request, exception):
        return text('Exception: {}'.format(exception), 500)

    assert app._future_exceptions == set([FutureException(handler, (Exception,))])

    @app.route('/1')
    async def handler(*args):
        1 / 0

    request, response = app.test_client.get('/1')
    assert response.text == 'Exception: division by zero'

# Generated at 2022-06-24 04:12:47.311055
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class MExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.val = handler.exceptions

    a = MExceptionMixin()
    @a.exception(TypeError, ValueError)
    def test(request, exc):
        print('test')

    assert len(a._future_exceptions) == 1
    assert a._future_exceptions == {FutureException(test, (TypeError, ValueError))}

# Generated at 2022-06-24 04:12:53.257787
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin._apply_exception_handler == NotImplemented

# Generated at 2022-06-24 04:12:54.685793
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:13:03.073480
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
            self.exception = handler.exception
            self.handler_method = handler.handler_method

    test_class_obj = TestClass()
    exception_values = [ValueError]
    decorator = test_class_obj.exception(*exception_values)

    @decorator
    def test_handler():
        return None

    test_handler()
    assert test_class_obj.handler.exception == exception_values
    assert test_class_obj.handler_method == test_handler

# Generated at 2022-06-24 04:13:04.939105
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print("Testing ExceptionMixin initialization.")
    em = ExceptionMixin()
    assert len(em._future_exceptions) == 0


# Generated at 2022-06-24 04:13:13.671147
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert exception_mixin
    assert exception_mixin._future_exceptions

    exception_mixin = ExceptionMixin(1, 2, 3)
    assert exception_mixin._future_exceptions

    def test_handler():
        return True
    assert exception_mixin.exception

    with pytest.raises(NotImplementedError):
        exception_mixin._apply_exception_handler(None)

    exception_mixin.exception(ApplyError)
    exception_mixin.exception(NotImplementedError, apply=False)
    exception_mixin.exception(test_handler)

# Generated at 2022-06-24 04:13:25.070019
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    Unit test for method exception of class ExceptionMixin
    '''

    # Mocks

    # Test data
    apply = True
    exceptions = "exception_1"
    handler = "handler_1"

    # Expected value
    expected_value = FutureException(handler, exceptions)

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)

        def get_future_exceptions(self):
            return self._future_exceptions

    # Test of method
    mixin = TestExceptionMixin()
    mixin.exception(exceptions, apply=apply)(handler)

    # Check

# Generated at 2022-06-24 04:13:33.101502
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic import Sanic
    from sanic.models.futures import FutureException
    from sanic.exceptions import SanicException
    app = Sanic()
    exc_mixin = ExceptionMixin()

    @app.exception(SanicException)
    def handler(request, exception):
        raise exception

    def handler(request, exception):
        raise exception

    with pytest.raises(NotImplementedError):
        exc_mixin._apply_exception_handler(FutureException(handler, SanicException))

    exc_mixin.exception(SanicException)
    exc_mixin.exception(SanicException)
    assert(len(exc_mixin._future_exceptions) == 1)

# Generated at 2022-06-24 04:13:43.233405
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.sanic import Sanic

    app1 = Sanic('test_app')

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            app1.error_handler.add(handler.exceptions, handler.handler)

    t = TestExceptionMixin()
    assert hasattr(t, '_future_exceptions')
    assert bool(t._future_exceptions) is False
    assert hasattr(t, '_apply_exception_handler')

    @t.exception(ValueError, ZeroDivisionError, apply=True)
    def handler1(request, exception):
        return response.text('internal server error')

    assert bool(t._future_exceptions) is True

# Generated at 2022-06-24 04:13:48.160449
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    new_test = TestExceptionMixin()
    assert isinstance(new_test, ExceptionMixin)
    assert set() == new_test._future_exceptions


# Generated at 2022-06-24 04:13:56.101651
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    my_exception_handler = ExceptionMixin()
    bp = Blueprint('test', url_prefix='/test')
    my_exception_handler._apply_exception_handler = bp.exception()
    @bp.exception(ValueError)
    def error_handler(request: Request, exception: ValueError):
        return HTTPResponse(
            status=500,
            content_type="text/html",
            body=str(exception))
    
    assert error_handler
    assert bp.error_handler_spec

# Generated at 2022-06-24 04:13:57.755581
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_exception_mixin = ExceptionMixin()
    assert test_exception_mixin is not None

# Generated at 2022-06-24 04:14:00.775635
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
 
    class FakeSanic(ExceptionMixin):
        pass

    sanic = FakeSanic()

    assert sanic._future_exceptions == set()

# Generated at 2022-06-24 04:14:01.640303
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()



# Generated at 2022-06-24 04:14:06.741253
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    # assert a._future_exceptions == set()
    if a._future_exceptions == set():
        print('Constructor of class ExceptionMixin works')
        return True
    else:
        print('Constructor of class ExceptionMixin does not work')
        return False


# Generated at 2022-06-24 04:14:11.369707
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global_exception = ExceptionMixin()

    global_exception.exception(Exception, SomeException, apply=True)
    # expect True
    assert global_exception._future_exceptions == {FutureException(Exception, SomeException)}
    # expect True
    assert global_exception._apply_exception_handler(FutureException(Exception, SomeException))

# Generated at 2022-06-24 04:14:13.153781
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        em = ExceptionMixin()
    except:
        assert False
    assert True


# Generated at 2022-06-24 04:14:16.647583
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    s = Sanic(__name__)
    assert s._future_exceptions == set()



# Generated at 2022-06-24 04:14:18.311548
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:14:23.802201
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def say_hello(self):
            return "hello"

    bp = Blueprint("test_exception_mixin")
    expected_string = "hello"
    assert bp.say_hello() == expected_string


# Generated at 2022-06-24 04:14:32.934033
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    bp = Blueprint()

    if bp._future_exceptions:
        assert False, "Test failed"

    @bp.exception([OSError])
    def handler(request):
        pass

    if not bp._future_exceptions:
        assert False, "Test failed"

    for future_exception in bp._future_exceptions:
        if not isinstance(future_exception, FutureException):
            assert False, "Test failed"

# Generated at 2022-06-24 04:14:34.714514
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin();
    assert exception_mixin._future_exceptions == set();



# Generated at 2022-06-24 04:14:39.861282
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        assert ExceptionMixin(None) == None
    except NotImplementedError as e:
        print("Not implemented: " + str(e))
        assert True


# Generated at 2022-06-24 04:14:41.861965
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()
    assert exc._future_exceptions is not None


# Generated at 2022-06-24 04:14:45.569722
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    exceptionMixin = MockExceptionMixin()
    assert exceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:56.128078
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic.blueprints import Blueprint
    from io import StringIO
    from sys import stdout, exc_info

    app = Blueprint('test_ExceptionMixin_exception', url_prefix='/test')

    # helper method to capture print output
    def capture_print(action: str, *args, **kwargs):
        captured = StringIO()
        stdout = sys.stdout
        sys.stdout = captured
        try:
            action(*args, **kwargs)
        except:
            exc_type, exc_value, exc_traceback = exc_info()
            print(exc_type, exc_value, exc_traceback)
        finally:
            sys.stdout = stdout
        captured.seek(0)
        return captured.read()

    # test1,

# Generated at 2022-06-24 04:14:59.419227
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return
    
    a_obj = A()

    @a_obj.exception()
    def exception_handler():
        pass

    assert len(a_obj._future_exceptions) == 1

# Generated at 2022-06-24 04:15:01.219560
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em
    assert em._future_exceptions


# Generated at 2022-06-24 04:15:05.570053
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin():
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    obj = TestExceptionMixin()
    if obj._future_exceptions:
        print('Unit test for constructor of class ExceptionMixin  failed')
        return False

    return True


# Generated at 2022-06-24 04:15:08.072195
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    exception_mixin = ExceptionMixin('', '', None)

    # Act
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:08.548082
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:15:10.844689
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic

    app = Sanic()
    assert app._future_exceptions == set()  # noqa: WPS437

# Generated at 2022-06-24 04:15:12.447247
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:15:14.382136
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert len(exception_mixin._future_exceptions) == 0


# Generated at 2022-06-24 04:15:25.283610
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import Forbidden, RequestTimeout
    from sanic.request import Request
    from sanic.response import HTTPResponse


    class Foo(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            if hasattr(self, 'exception'):
                self.exception = handler.handler
            else:
                setattr(self, 'exception', handler.handler)


    foo = Foo()


    @foo.exception(Forbidden)
    def handler(*args, **kwargs):
        pass

    assert isinstance(foo.exception, type(handler))

    # test to make sure that a global exception handler is applied if
    # apply is set to True
    foo_ = Foo()

# Generated at 2022-06-24 04:15:27.735770
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class _(ExceptionMixin):
        def __init__(self):
            super().__init__()

    assert _()._future_exceptions == set()

# Generated at 2022-06-24 04:15:34.211788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_excepions: Set[FutureException] = set()

    dummy_class = DummyClass()
    mixin = ExceptionMixin()

    assert mixin._future_exceptions != dummy_class._future_exceptions

    @mixin.exception(None)
    def handle_exception(self, request, exception):
        return str(exception)

    assert len(mixin._future_exceptions) == 1
    assert dummy_class._future_exceptions != mixin._future_exceptions

# Generated at 2022-06-24 04:15:43.259592
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_ExceptionMixin_exception")
    blueprint_exception = bp.exception(Exception)
    blueprint_handler = blueprint_exception(lambda request, exception: None)
    app_exception = app.exception(Exception)
    app_handler = app_exception(lambda request, exception: None)
    assert blueprint_handler is not None
    assert app_handler is not None


# Generated at 2022-06-24 04:15:44.162056
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  em = ExceptionMixin()
  assert em

# Generated at 2022-06-24 04:15:45.685496
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin()._future_exceptions,set)

# Generated at 2022-06-24 04:15:48.430863
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    _future_exceptions: Set[FutureException] = set()
    assert len(_future_exceptions) == 0

# Unit tests for _apply_exception_handler of class ExceptionMixin