

# Generated at 2022-06-24 04:05:51.103763
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert len(ExceptionMixin._future_exceptions) == 0

# Generated at 2022-06-24 04:05:58.170923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin is not None

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        return exception

    assert len(test_exception_mixin._future_exceptions) == 1



# Generated at 2022-06-24 04:06:04.586956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        async def _apply_exception_handler(self, handler: FutureException):
            pass

    test = A()
    assert len(test._future_exceptions) == 0

    @test.exception(Exception)
    async def test_exception(request, exception):
        return 'A'

    assert len(test._future_exceptions) == 1

# Generated at 2022-06-24 04:06:09.490847
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:06:11.738387
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(1)

# Generated at 2022-06-24 04:06:15.686724
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # 返回函数内部变量
    def a(arg1, arg2):
        return arg1, arg2

    f = ExceptionMixin()
    assert f._future_exceptions == set()
    assert f.exception(KeyError, apply=True)(a)(1,2) == (1,2)

# Generated at 2022-06-24 04:06:22.687105
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    _future_exceptions: Set[FutureException] = set()
    _future_exceptions.add(FutureException(print, (Exception,)))
    em = ExceptionMixin()
    em._future_exceptions = _future_exceptions
    test_handler = em.exception(Exception)
    assert em._future_exceptions == _future_exceptions
    assert test_handler(Exception)

# Generated at 2022-06-24 04:06:26.691321
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    TestExceptionMixin()

# Generated at 2022-06-24 04:06:33.599671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic.response
    import sanic.blueprints
    import sanic.server
    import sanic
    import functools

    @sanic.blueprints.Blueprint.exception(Exception)
    @sanic.blueprints.Blueprint.route("/")
    def route_handler(request):
        raise Exception("Exception raised")

    app = sanic.Sanic(__name__)
    app.blueprint(route_handler)
    _, response = app.test_client.get("/")

    assert response.status == 500
    assert response.text == "Exception raised"

    @sanic.blueprints.Blueprint.exception(Exception)
    @sanici.blueprints.Blueprint.route("/")
    def route_handler(request):
        raise Exception("Exception raised")


# Generated at 2022-06-24 04:06:42.842212
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SimpleExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(SimpleExceptionMixin, self).__init__(*args, **kwargs)
            self.tag = 'sanic_mixins'

        def _apply_exception_handler(self, handler: FutureException):
            return '{} {}'.format(self.tag, handler)

    test_obj = SimpleExceptionMixin()
    assert test_obj.exception([Exception]) == test_obj._apply_exception_handler(FutureException(test_obj.exception, [Exception]))

# Generated at 2022-06-24 04:06:49.851528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    def handler():
        return "handler"
    #exception = ExceptionMixin.exception(handler, LookupError)
    exception = ExceptionMixin.exception(LookupError)(handler)
    assert exception is handler, "The function returned from exception method is not the same"
    #test exception on Blueprint class
    app = Blueprint("app", url_prefix='app')
    exception = app.exception(LookupError)(handler)
    assert exception is handler, "The function returned from exception method is not the same"

# Generated at 2022-06-24 04:06:51.537863
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    abc = ExceptionMixin()
    print(abc)

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:06:54.504123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # Given an instance of Blueprint
    blueprint = Blueprint('TestBlueprint', url_prefix='/bp')

    # When the method exception is called without parameter
    decorator = blueprint.exception()

    # Then, decorator should be defined
    assert decorator is not None



# Generated at 2022-06-24 04:07:03.242237
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class AutoVivification(dict):
        """Implementation of perl's autovivification feature."""

        def __getitem__(self, item):
            try:
                return dict.__getitem__(self, item)
            except KeyError:
                value = self[item] = type(self)()
                return value

    def check_Empty_data():
        blueprint = blueprintClass()
        assert blueprint._future_exceptions == set()

    blueprintClass = type('TestClass', (ExceptionMixin,), dict())

    # Call test functions
    check_Empty_data()

# Generated at 2022-06-24 04:07:05.969071
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestException(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    TestException()

# Generated at 2022-06-24 04:07:06.950591
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(1, 2), ExceptionMixin) == True

# Generated at 2022-06-24 04:07:07.940767
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin() is not None

# Generated at 2022-06-24 04:07:12.711575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinDemo(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixinDemo, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    demo = ExceptionMixinDemo()
    @demo.exception(NotImplementedError)
    def handler():
        pass
    assert len(demo._future_exceptions) == 1



# Generated at 2022-06-24 04:07:23.595436
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic(__name__)

    @ExceptionMixin.exception(IndexError)
    def index_error(request, exception):
        return json({"code": 500, "msg": exception.args[0]})

    @ExceptionMixin.exception(ServerError)
    def server_error(request, exception):
        return json({"code": 500, "msg": exception.args[0]})

    ExceptionMixin._apply_exception_handler = lambda x, y: x

    @app.route('/')
    def route(request):
        raise IndexError('A server error occurred while fulfilling '
                         'the request')

    _, response = app.test_client.get('/')

# Generated at 2022-06-24 04:07:29.664338
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
        def __init__(self):
            super().__init__()
    
    tester = ExceptionMixinTester()
    assert tester.__dict__["_future_exceptions"] == set()



# Generated at 2022-06-24 04:07:34.421210
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinTest(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            assert handler is future_exception

    exception_mixin_test = ExceptionMixinTest()

    @exception_mixin_test.exception(Exception)
    def exception_handler():
        pass

    future_exception, = exception_mixin_test._future_exceptions

# Generated at 2022-06-24 04:07:42.892592
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    obj = A()

    @obj.exception(Exception)
    def handler():
        pass

    assert len(obj._future_exceptions) == 1

    @obj.exception([Exception])
    def handler2():
        pass

    assert len(obj._future_exceptions) == 2



# Generated at 2022-06-24 04:07:50.985973
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint("test_ExceptionMixin_exception")

    @blueprint.exception(ApplyException)
    async def handler(request, exception):
        assert isinstance(exception, ApplyException)
        assert isinstance(exception, SanicException)

    @blueprint.exception([ApplyException])
    async def handler_list(request, exception):
        assert isinstance(exception, ApplyException)
        assert isinstance(exception, SanicException)

    with pytest.raises(ApplyException):
        raise ApplyException()



# Generated at 2022-06-24 04:07:55.630035
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            super(TestExceptionMixin, self).__init__()

    ins = TestExceptionMixin()
    assert len(ins._future_exceptions) == 0
    assert isinstance(ins._future_exceptions, set)

# Generated at 2022-06-24 04:08:02.576586
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    mixin = ExceptionMixinTest()

    @mixin.exception(IndexError)
    def index_error(request, exception):
        return 'index_error'

    @mixin.exception(ValueError)
    def value_error(request, exception):
        return 'value_error'

    @mixin.exception([KeyError, TypeError])
    def key_error(request, exception):
        return 'key_error'

    assert len(mixin._future_exceptions) == 3


# Generated at 2022-06-24 04:08:04.262120
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert(m._future_exceptions == set())

# Generated at 2022-06-24 04:08:12.711423
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.router import Router
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import text

    class TestMethodView(HTTPMethodView):
        def get(self, request):
            return text('OK')

    # Constructor
    router = Router()
    exception_mixin = ExceptionMixin()

    # case 1: not specify arguments
    assert exception_mixin._future_exceptions == set()

    # case 2: not specify dict arguments
    exception_mixin = ExceptionMixin()



# Generated at 2022-06-24 04:08:15.034336
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    x = TestExceptionMixin()
    assert x._future_exceptions == set()


# Generated at 2022-06-24 04:08:20.729724
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return handler

    examix = ExceptionMixinTest()
    @examix.exception(Exception)
    def test_handler(request, exception):
        print("i am test handler")

    assert len(examix._future_exceptions) == 1
    assert examix._future_exceptions.pop().handler == test_handler
    print("test pass")

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:08:25.584630
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    a = A()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:08:31.619629
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyApp(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    app = MyApp()

    assert len(app._future_exceptions) == 0
    assert app.exception
    assert len(app._future_exceptions) == 1

# Generated at 2022-06-24 04:08:35.410145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint('test_bp')

    assert hasattr(bp, 'exception')
    assert callable(bp.exception)

# Generated at 2022-06-24 04:08:44.981780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinFixture(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = ExceptionMixinFixture()
    handlers = []

    @exception_mixin.exception(RuntimeError, apply=False)
    def handler():
        pass

    handlers.append(handler)

    @exception_mixin.exception([RuntimeError, IOError], apply=False)
    def handler2():
        pass

    handlers.append(handler2)

    @exception_mixin.exception(apply=False)
    def handler3():
        pass

    handlers.append(handler3)

    assert len(exception_mixin._future_exceptions) == 3
    assert callable(exception_mixin._future_exceptions.pop()) in handlers

# Generated at 2022-06-24 04:08:45.644742
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:08:48.786999
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    instance = ExceptionTest()
    assert len(instance._future_exceptions)==0

# Generated at 2022-06-24 04:08:51.933814
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass

    a = A()
    assert a._future_exceptions == set()

# Generated at 2022-06-24 04:08:57.704136
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        
        def _apply_exception_handler(self, handler):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert test_exception_mixin._future_exceptions != set()
    assert test_exception_mixin._future_exceptions.__iter__()[0].handler == test_handler

# Generated at 2022-06-24 04:08:59.179743
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions is not None


# Generated at 2022-06-24 04:09:04.897814
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint('')

    @blueprint.exception(ZeroDivisionError)
    def exception_handler(request, exception):
        return 'Error: {}'.format(exception)

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(exception_handler, (ZeroDivisionError,))

# Generated at 2022-06-24 04:09:13.508506
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test_bp')

    test_get_passed = False
    @blueprint.exception(NotFound)
    async def test_get(request, exception):
        nonlocal test_get_passed
        test_get_passed = True
        assert exception.status_code == 404

    blueprint.add_route(test_get, '/test', methods=['GET'])
    app.blueprint(blueprint)
    request, response = app.test_client.get(
        '/test',
        headers={'accept': 'application/json'}
    )

    assert response.status == 404

# Generated at 2022-06-24 04:09:19.499124
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import time
    import asyncio
    from sanic import Blueprint
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureException
    
    bp = Blueprint('test')
    
    @bp.exception(NotFound)
    def notfound_exception(request, exception):
        return 'notfound'
    
    # TODO: mock application methods and bluepint.register()
    # TODO: mock add_exception_handler()
    # TODO: mock add_route()

# Generated at 2022-06-24 04:09:27.901388
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    Test __init__()
    """
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler

    app = Sanic("hello world")
    # pass the app to create_blueprint()
    bp = Blueprint("test_bp", url_prefix="/test_bp", host="test.org",
        version="test", strict_slashes=True, app=app)

    # create an instance of ErrorHandler
    handler = ErrorHandler(app)
    # assert the _future_exceptions attribute equals to _future_exceptions of
    # its app instance's error_handler
    assert bp._future_exceptions == handler._future_exceptions


# Generated at 2022-06-24 04:09:39.498501
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.bp import Blueprint
    blueprint = Blueprint('test', '/v1')
    blueprint1 = Blueprint('test1', '/v2')
    blueprint2 = Blueprint('test2', '/v3')
    blueprint1.exception(Exception)(lambda x, y, z: 1)
    blueprint2.exception(Exception)(lambda x, y, z: 1)
    blueprint1.exception(ValueError, apply=False)(lambda x, y, z: 1)
    blueprint2.exception(ValueError, apply=False)(lambda x, y, z: 1)
    assert len(blueprint1._future_exceptions) == 2
    assert len(blueprint2._future_exceptions) == 2
    assert not blueprint._future_exceptions
    assert not blueprint.handler_ordered.exception_handlers
    assert not blueprint1

# Generated at 2022-06-24 04:09:42.580631
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Mixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
    assert Mixin()

# Generated at 2022-06-24 04:09:48.228844
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_exception_Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp")
    ExceptionMixin_exception_Test.exception(bp)
    assert ExceptionMixin_exception_Test(bp)._future_exceptions != set()

# Generated at 2022-06-24 04:09:54.883458
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

    tc = TestExceptionMixin()
    print(tc)


# Generated at 2022-06-24 04:09:58.971076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = [1,2,3]
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self,*args, **kwargs):
            super(TestExceptionMixin,self).__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            assert handler in self._future_exceptions
    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(a)
    def test_handler():
        return 1
    assert test_handler() == 1

# Generated at 2022-06-24 04:10:06.106052
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler
    mixin = MyExceptionMixin()
    fake_handler = lambda _: _
    mixin.exception(Exception)(fake_handler)
    assert len(mixin._future_exceptions) == 1
    assert all(isinstance(exception, FutureException) for exception in mixin._future_exceptions)

# Generated at 2022-06-24 04:10:11.269172
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()
    assert a.exception()

    from sanic.response import json
    @a.exception(Exception)
    def handler(request, exception):
        return json({'error': "Error message"}, status=500)

    assert handler(1, Exception) == {'error': "Error message"}

# Generated at 2022-06-24 04:10:18.437500
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Negative test case 1: no parameter
    with pytest.raises(TypeError):
        exception_mixin = ExceptionMixin()
    # Negative test case 2: one parameter
    with pytest.raises(TypeError):
        exception_mixin = ExceptionMixin(1, {})
    # Negative test case 3: wrong parameter
    with pytest.raises(TypeError):
        exception_mixin = ExceptionMixin("test", {})


# Generated at 2022-06-24 04:10:19.369432
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False, "Test not implemented"

# Generated at 2022-06-24 04:10:20.965566
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:10:22.506471
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Mixin(ExceptionMixin):
        pass
    assert Mixin()._future_exceptions == set()

# Generated at 2022-06-24 04:10:27.539234
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mixin(ExceptionMixin):
        def __init__(self):
            self._app = None

    mixin = Mixin()
    assert len(mixin._future_exceptions) == 0
    assert mixin._app is None



# Generated at 2022-06-24 04:10:33.456338
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        __slots__ = ('_future_exceptions')

        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = A()
    @a.exception(Exception)
    def except_handler(x, y, z=2):
        return x + y + z

    assert except_handler('a', 'b', 2) == 'ab' + str(2)

# Generated at 2022-06-24 04:10:36.331736
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    service = {}
    blueprint = Blueprint("test_blupprint", url_prefix="test")
    blueprint.exception(Exception)(lambda a: a)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:10:37.707731
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()


# Generated at 2022-06-24 04:10:47.215124
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert not hasattr(exception_mixin, "_future_exceptions")
    assert not hasattr(exception_mixin, "_exception_handlers")
    exception_mixin.__init__()
    assert hasattr(exception_mixin, "_future_exceptions")
    assert not hasattr(exception_mixin, "_exception_handlers")
    @exception_mixin.exception(Exception)
    async def a():
        return "do it"

    assert hasattr(exception_mixin, "_future_exceptions")
    assert hasattr(exception_mixin, "_exception_handlers")
    # Now it's time to check if a was added to exception_mixin._exception_handlers properly

# Generated at 2022-06-24 04:10:52.532050
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.future import FutureException
    from sanic.models.blueprint import Blueprint
    test_blueprint  = Blueprint('')
    assert test_blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:11:03.868254
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    from sanic.response import json

    app = Sanic()

    bp = Blueprint('test_bp')

    # decorated function for method exception
    @bp.exception(ZeroDivisionError)
    def exception_handler(request, exception):
        return json({'error': str(exception)})

    # make sure exception handler is in place
    assert bp._future_exceptions

    # make sure exception handler is still there after running method
    # exception again
    @bp.exception(ZeroDivisionError)
    def exception_handler_2(request, exception):
        return json({'error': str(exception)})

    assert bp._future_exceptions

    @bp.route('/test')
    async def test(request):
        return 1 / 0

    app.blue

# Generated at 2022-06-24 04:11:04.989976
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:11:10.805651
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    mixin = ExceptionMixin()
    assert isinstance(mixin._future_exceptions, set)
    assert len(mixin._future_exceptions) == 0
    bp = Blueprint(name="test")
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 0
    bp1 = Blueprint(name="test")
    assert bp1._future_exceptions is not bp._future_exceptions



# Generated at 2022-06-24 04:11:15.751785
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.route import RouteModel
    from sanic.models.futures import Future, FutureException
    from sanic.models.http import HTTPModel
    class FakeException(Exception):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    class FakeBluePrint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.routes = []
    bp = FakeBluePrint()
    def fake_handler(*args, **kwargs):
        print('inside handler')
        return 'handler returned'
    exceptions = [FakeException]
    f_exception = FutureException(fake_handler, exceptions)

# Generated at 2022-06-24 04:11:18.123178
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:11:19.493869
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Unit test of function exception in class ExceptionMixin

# Generated at 2022-06-24 04:11:27.365404
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    app = Sanic('test_ExceptionMixin')
    @app.listener('before_server_start')
    async def before_server_start(app, loop):
        pass
    @app.listener('after_server_start')
    async def after_server_start(app, loop):
        pass
    @app.listener('before_server_stop')
    async def before_server_stop(app, loop):
        pass
    @app.listener('after_server_stop')
    async def after_server_stop(app, loop):
        pass


# Generated at 2022-06-24 04:11:32.803626
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(A, self).__init__(*args, **kwargs)
    a = A()
    assert isinstance(a, ExceptionMixin)
    assert isinstance(a._future_exceptions, set)
    raise NotImplementedError



# Generated at 2022-06-24 04:11:35.933393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass
    # fixme

# Generated at 2022-06-24 04:11:42.846192
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('blueprint')

    # Case 1: apply = True
    @blueprint.exception(Exception, apply=True)
    def exception_handler(request, exception):
        pass

    expected = set([FutureException(exception_handler, (Exception,))])
    assert blueprint._future_exceptions == expected

    # Case 2: apply = False
    @blueprint.exception(Exception, apply=False)
    def exception_handler2(request, exception):
        pass

    expected.add(FutureException(exception_handler2, (Exception,)))
    assert blueprint._future_exceptions == expected

# Generated at 2022-06-24 04:11:46.582021
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def dummy_handler1(*args, **kwargs):
        pass

    def dummy_handler2(*args, **kwargs):
        pass

    exc_mixin = ExceptionMixin()
    exc_mixin.exception(dummy_handler1)
    exc_mixin.exception([dummy_handler2])
    assert dummy_handler1 in exc_mixin._future_exceptions
    assert dummy_handler2 in exc_mixin._future_exceptions

# Generated at 2022-06-24 04:11:48.171407
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_instance = TestClass()
    assert len(test_instance._future_exceptions) == 0



# Generated at 2022-06-24 04:11:48.735688
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:50.451300
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
    except Exception as e:
        assert True



# Generated at 2022-06-24 04:11:54.320278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    def test_handler(request, exc):
        return "Works"
    bp = Blueprint("test", url_prefix="test")
    bp.exception(ServerError)(test_handler)

# Generated at 2022-06-24 04:11:57.457098
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BluePrint(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    BluePrint()

# Generated at 2022-06-24 04:12:02.977894
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import HTTPResponse

    class test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            super()._apply_exception_handler(handler)

    test = test_ExceptionMixin()
    handler = test.exception(ValueError)(lambda req: HTTPResponse('no error',status=200))
    assert handler.expect_exception == (ValueError,)

# Generated at 2022-06-24 04:12:04.570796
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()
    assert obj._exception_handler is None

# Generated at 2022-06-24 04:12:12.437664
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound

    app = Blueprint('my_blueprint')
    @app.exception(NotFound)
    def handler(request, exception):
        return text("Exception handling")
    
    # Unit test for constructor of class ExceptionMixin
    @app.route('/test_handler')
    async def test_handler(request):
        return text("Exception handling") 
    


# Generated at 2022-06-24 04:12:14.665772
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:12:24.927443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('bp', url_prefix='/test')
    bp2 = Blueprint('bp2', url_prefix='/test')
    @bp.exception(apply=False)
    def handler(request, *args, **kwargs):
        pass

    assert handler in bp._future_exceptions

    @bp.exception([TypeError, SanicException, BaseException], apply=False)
    def handler2(request, exception, *args, **kwargs):
        pass

    assert handler2 in bp._future_exceptions
    assert handler2.exception_classes == (TypeError, SanicException, BaseException)


# Generated at 2022-06-24 04:12:33.107790
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        # method _apply_exception_handler will not be tested here
        def _apply_exception_handler(self, handler: FutureException):
            pass
    t_instance = TestExceptionMixin()
    assert t_instance._future_exceptions
    assert not t_instance._future_exceptions
    
    def handler1():
        raise Exception('My exception')
    
    t_instance.exception(IOError)(handler1)
    assert len(t_instance._future_exceptions) == 1
    assert handler1 in t_instance._future_exceptions
    
    def handler2():
        raise Exception('My exception')
        
    t_instance.exception(IOError, apply=False)(handler2)
    assert len(t_instance._future_exceptions) == 2


# Generated at 2022-06-24 04:12:44.194929
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.server import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    # define blueprint
    blueprint = Blueprint('test_sanic')
    blueprint.config = {"ERROR_HANDLER": False, "PATH": "/test_sanic"}

    # define server
    app = Sanic()
    app.config.BLUEPRINTS_ROOT_PATH = ""

    # define request and response
    request = Request('GET', '/example_route', version=1.1)
    response = HTTPResponse()

    # define exceptions
    ZeroDivisionError = ZeroDivisionError
    ValueError = ValueError

    # define decorator
    def decorator(handler):
        nonlocal apply
        nonlocal exceptions


# Generated at 2022-06-24 04:12:45.705569
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert (ExceptionMixin()._future_exceptions == set())


# Generated at 2022-06-24 04:12:48.445511
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert None
    # b = Blueprint('b')
    # @b.exception(Exception)
    # async def handler(r,e):
    #     pass


# Generated at 2022-06-24 04:12:49.092519
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:12:57.133906
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView

    @ExceptionMixin.exception(Exception)
    def exception_handler(request, exception):
        return response.text('Internal server error', 500)

    class MyView(HTTPMethodView, ExceptionMixin):
        @exception_handler
        async def get(self):
            pass

    app = Sanic()
    app.add_route(MyView.as_view(), '/')

    request, response = app.test_client.get('/')
    assert response.status == 500

# Generated at 2022-06-24 04:12:57.728894
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:13:02.727254
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    import sanic.blueprints
    blueprint = sanic.blueprints.Blueprint(__name__)

    # When
    @blueprint.exception(IndexError)
    def handler(request, exception):
        raise NotImplementedError

    # Then
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:13:08.035923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json
    from sanic.models.user_models import User

    user = User()
    user._future_exceptions = set()

    @user.exception(Exception)
    def handle_exception(request, exception):
        return json({'status': 'error'})

    assert len(user._future_exceptions) == 1

    @user.exception((Exception, ValueError))
    def handle_multiple_exceptions(request, exception):
        return json({'status': 'error'})

    assert len(user._future_exceptions) == 2

# Generated at 2022-06-24 04:13:15.285979
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin')

    bp = Blueprint('test_ExceptionMixin', url_prefix='test_ExceptionMixin')

    @bp.exception(SanicException)
    def ignore_handler(request, exception):
        return text('Hello')

    @bp.exception(SanicException, SanicException)
    def ignore_handler_list(request, exception):
        return text('Hello')

    @bp.exception()
    def ignore_handler_empty(request, exception):
        return text('Hello')

    app.blueprint(bp)

    # assert 2 < len(bp._exception_handlers)
    # assert 2 < len(bp._exception_

# Generated at 2022-06-24 04:13:19.761821
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test None input
    exceptions = None

    # Test invalid input
    exceptions = 123

    # Test valid input
    exceptions = (Exception, )

    # Test lambda function
    def exception_handler(request, exception):
        return 'Exception raised: {}'.format(exception)

    mixin = ExceptionMixin()
    mixin.exception(exceptions)(exception_handler)


# Generated at 2022-06-24 04:13:26.747846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            pass

        def _apply_exception_handler(self, handler):
            assert callable(handler)

    testExceptionMixin = TestExceptionMixin()

    @testExceptionMixin.exception(Exception)
    def test(request, exception):
        pass

    @testExceptionMixin.exception([Exception])
    def test1(request, exception):
        pass

    @testExceptionMixin.exception(Exception, apply=False)
    def test2(request, exception):
        pass

# Generated at 2022-06-24 04:13:32.479496
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintMock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

    # test for exception without arguments
    def test_decorator():
        pass

    instance = BlueprintMock()
    assert len(instance._future_exceptions) == 0
    assert test_decorator == instance.exception()(test_decorator)
    assert len(instance._future_exceptions) == 1

# Generated at 2022-06-24 04:13:34.817981
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    blueprint = Blueprint("test")
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:13:37.212098
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    '''
    Test the constructor of class ExceptionMixin
    '''
    er = ExceptionMixin()
    assert er._future_exceptions == set()

# Generated at 2022-06-24 04:13:39.497738
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        ExceptionMixin.exception(ExceptionMixin)
    except NotImplementedError:
        return True
    return False


# Generated at 2022-06-24 04:13:47.837659
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException

    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            def wrapper(*args, **kwargs):
                return handler(*args, **kwargs)

            return wrapper

    exception_mixin = _ExceptionMixin()
    future_exception = exception_mixin.exception(SanicException)(
        lambda *args, **kwargs: None)
    assert future_exception in exception_mixin._future_exceptions



# Generated at 2022-06-24 04:13:49.733220
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m=ExceptionMixin()
    assert isinstance(m,ExceptionMixin)



# Generated at 2022-06-24 04:13:59.875054
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class SanicMock(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = SanicMock()

    @app.exception(ZeroDivisionError)
    def error_one(request, exception):
        pass

    @app.exception(ZeroDivisionError, FileNotFoundError)
    def error_two(request, exception):
        pass

    @app.exception([ZeroDivisionError, FileNotFoundError])
    def error_three(request, exception):
        pass

    expected_one = FutureException(error_one, (ZeroDivisionError, ))
    expected_two = FutureException(error_two, (ZeroDivisionError, FileNotFoundError))

# Generated at 2022-06-24 04:14:03.035963
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.testing import LogTestCase

    class Test(ExceptionMixin):

        async def _apply_exception_handler(self, handler: FutureException):
                pass

    test = Test()
    assert test._future_exceptions == set()



# Generated at 2022-06-24 04:14:12.818016
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import RequestTimeout

    class A:
        def __init__(self):
            self.b = B()

    class B(ExceptionMixin):
        def __init__(self):
            super().__init__()

    @A.b.exception(RequestTimeout)
    def test_exception_handler(request, exception):
        return text('Exception: ' + exception.__class__.__name__)

    app = Sanic('test_exception_handler')
    app.blueprint(A.b)

    request, response = app.test_client.get('test')
    assert response.text == 'Exception: RequestTimeout'


# Generated at 2022-06-24 04:14:18.129648
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("test", url_prefix="/test", strict_slashes=True)
    blueprint.error(None, apply=False)
    blueprint.exception(None, apply=False)
    blueprint.add_route(None, None, None, apply=False)
    blueprint.middleware(None, apply=False)
    assert blueprint._future_exceptions is not None

# Generated at 2022-06-24 04:14:25.840009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, response

    app = Sanic('test_ExceptionMixin_exception')
    my_exception = Exception("My custom exception")

    @app.exception(Exception)
    async def handle_exception(request, exception):
        return response.text("Got exception: " + str(exception))

    @app.exception(Exception)
    async def handle_custom_exception(request, exception):
        return response.text("Got custom exception: " + str(exception))

    @app.route("/a")
    def handler_a(request):
        raise Exception("This is a exception")

    @app.route("/b")
    def handler_b(request):
        raise my_exception

    request, response = app.test_client.get('/a')
    assert response.status

# Generated at 2022-06-24 04:14:27.944142
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


# Generated at 2022-06-24 04:14:37.894120
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            self.future_exception = handler

    my_exception_mixin = TestExceptionMixin()
    exception_handler = my_exception_mixin.exception(MyException)
    exception_handler(lambda error: True)
    assert my_exception_mixin.future_exception._handler(MyException())
    assert my_exception_mixin.future_exception._exceptions == (MyException,)
    my_exception_mixin = TestExceptionMixin()
    exception_handler = my_ex

# Generated at 2022-06-24 04:14:46.731390
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import abort
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class TestBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self._handle_request = handler

        @staticmethod
        async def fake_handler(request: Request):
            raise abort(404)

        async def handle_request(self, request):
            await self.fake_handler(request)

    blueprint = TestBlueprint('test', url_prefix='/t')
    blueprint.add_route(blueprint.fake_handler, '/f')

    @blueprint.exception(Abort)
    async def handler(request, exception):
        return HTTPResponse('test')

   

# Generated at 2022-06-24 04:14:57.570128
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print("Apply Exception Handler")

    my_mixin = MyExceptionMixin()

    @my_mixin.exception(apply=False)
    def test(request, exception):
        print("Test")
    
    @my_mixin.exception(apply=True)
    def test1(request, exception):
        print("Test1")

    assert len(my_mixin._future_exceptions) == 2

    assert hasattr(test, '__exception')
    assert hasattr(test1, '__exception')

    test(None, None)
    test1(None, None)

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:15:00.146776
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    _model = ExceptionMixin()
    assert hasattr(_model, '_future_exceptions')
    assert isinstance(_model._future_exceptions, set)



# Generated at 2022-06-24 04:15:01.884941
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert exception
    assert exception._future_exceptions == set()


# Generated at 2022-06-24 04:15:02.883938
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:04.491109
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin is not None

# Generated at 2022-06-24 04:15:09.004586
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo:
        def __init__(self):
            pass
        def method_exception(self, handler):
            return handler
    
    foo = Foo()
    foo.method_exception = ExceptionMixin.exception(foo.method_exception, 'abc', apply=True)
    assert foo.method_exception.__name__ == 'method_exception'

# Generated at 2022-06-24 04:15:11.292612
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)


# Generated at 2022-06-24 04:15:13.875563
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # GIVEN
    instance = ExceptionMixin()
    # WHEN
    # THEN
    assert instance._future_exceptions is not None


# Generated at 2022-06-24 04:15:24.978569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    bp = Blueprint('TestExceptionMixin')

    @bp.exception(Exception, apply=True)
    def test_handler(request, exception):
        return "OK"

    @bp.route('/', methods=['GET'])
    def test(request):
        raise Exception

    bp.register_with_blueprint(app, url_prefix='/v1/test')

    _, response = app.test_client.get('/v1/test/')
    assert response.text == 'OK'

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:15:29.892827
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Mixed(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    mixed = Mixed()
    assert mixed._future_exceptions == set()


# Generated at 2022-06-24 04:15:35.114813
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_class(ExceptionMixin):
        pass
    test_instance = test_class()
    assert isinstance(test_instance, test_class)
    assert test_instance._future_exceptions == set()


# Generated at 2022-06-24 04:15:42.976883
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            print('Implement exception handler')

    test = ExceptionMixinTest()
    @test.exception(KeyError)
    def test_handler(request, exception):
        pass

    assert len(test._future_exceptions) == 1
    assert test._future_exceptions.pop().handler is test_handler

# Generated at 2022-06-24 04:15:48.765033
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(name='bp', url_prefix='/bp')
    for t in bp.test_cases:    # type: ignore
        assert t.apply_exception_handler(FutureException(Exception, Exception)) == None
        assert t.apply_exception_handler(FutureException(Exception, Exception, Exception)) == None
        assert t.apply_exception_handler(FutureException(Exception, Exception, Exception, Exception)) == None

# Generated at 2022-06-24 04:15:57.386973
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        
        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = ExceptionMixinTestClass()
    def test_case(a):
        def test_exception_handler(a):
            @a.exception(IndexError)
            def test_exception(request, exception):
                print('test exception')
            pass
        test_exception_handler(a)