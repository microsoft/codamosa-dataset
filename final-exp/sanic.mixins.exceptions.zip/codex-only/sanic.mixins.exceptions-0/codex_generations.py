

# Generated at 2022-06-24 04:05:53.744186
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc = ExceptionMixin()
    @exc.exception(AssertionError)
    def handler():
        return "do something"

    assert handler == list(exc._future_exceptions)[0].handler
    assert AssertionError in list(exc._future_exceptions)[0].exceptions
    assert None == list(exc._future_exceptions)[0].args
    assert None == list(exc._future_exceptions)[0].kwargs

    @exc.exception(AssertionError, apply=False)
    def handler():
        return "do something"

    assert handler == list(exc._future_exceptions)[1].handler
    assert AssertionError in list(exc._future_exceptions)[1].exceptions
    assert None == list(exc._future_exceptions)[1].args

# Generated at 2022-06-24 04:06:00.450236
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import HTTPResponse

    bp = Blueprint("Test_ExceptionMixin")

    @bp.exception(Exception)
    def handle_exception(request, exception):
        return HTTPResponse("Error", status=500)

    route = bp.exception(Exception)(lambda *args: None)
    assert route.__closure__ is not None
    assert len(route.__closure__) == 1

    route = bp.exception([RuntimeError, ZeroDivisionError])(lambda *args: None)
    assert route.__closure__ is not None
    assert len(route.__closure__) == 1

# Generated at 2022-06-24 04:06:02.915102
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert len(obj._future_exceptions) == 0

# Generated at 2022-06-24 04:06:05.722294
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    f = FutureException(None, None)
    d = {f}
    b = Blueprint("test", url_prefix="/test", strict_slashes=False, future_exceptions=d)



# Generated at 2022-06-24 04:06:09.525594
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert isinstance(a, ExceptionMixin)


# Generated at 2022-06-24 04:06:13.439074
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint()
    assert bp._future_exceptions == set()
    assert isinstance(bp._future_exceptions, set)



# Generated at 2022-06-24 04:06:21.081564
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class FakeExceptionMixin:
        def __init__(self):
            self.fake_future_exception = set()

        def _apply_exception_handler(self, fake_future_exception):
            self.fake_future_exception.add(fake_future_exception)

    fake_ExceptionMixin = FakeExceptionMixin()
    test_ExceptionMixin = ExceptionMixin()
    assert test_ExceptionMixin is not None
    assert type(test_ExceptionMixin._future_exceptions) is set


# Generated at 2022-06-24 04:06:28.888184
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    class TestException(Exception):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    # act
    test_exception_mixin.exception(TestException)(lambda: "handler")

    # assert
    assert (
        test_exception_mixin._future_exceptions ==
        {FutureException(lambda: "handler", (TestException,))}
    )


# Generated at 2022-06-24 04:06:36.714619
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound, ServerError
    from sanic.response import text
    from sanic.models.futures import FutureException

    exception_bp = Blueprint("exception_bp")

    @exception_bp.exception(NotFound)
    def exception_handler(request, exception):
        return text("You are not supposed to be here!")

    @exception_bp.exception(ServerError)
    def exception_handler_2(request, exception, code=500):
        return text("There was a problem!", status=code)

    assert isinstance(exception_bp._future_exceptions, set)
    set_of_FutureException = set()
    future_exception = FutureException(exception_handler, NotFound)

# Generated at 2022-06-24 04:06:45.994780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    # case1
    assert TestExceptionMixin().exception(KeyError)

    # case2
    assert TestExceptionMixin().exception(KeyError, apply=False)

    # case3
    assert TestExceptionMixin().exception([KeyError])

    # case4
    assert TestExceptionMixin().exception([KeyError], apply=False)

# Generated at 2022-06-24 04:06:49.969077
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def handle_exception(request, exception):
        return 1

    assert hasattr(handle_exception, "exception")
    assert callable(handle_exception)
    assert handle_exception(None, None) == 1


# Generated at 2022-06-24 04:06:50.469099
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-24 04:06:57.150284
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import text

    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(Exception)
    def handler(request, exception):
        return text('Internal server error', 500)

    @blueprint.exception(Exception, apply=False)
    def handler_with_apply_false(request, exception):
        return text('Internal server error', 500)

    @blueprint.exception([ValueError, ZeroDivisionError])
    def handler_with_different_exception(request, exception):
        return text('Internal server error', 500)


# Generated at 2022-06-24 04:07:00.138488
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    _ = MyExceptionMixin()

# Generated at 2022-06-24 04:07:11.288855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBlueprint:
        def __init__(self):
            self._future_exceptions = set()
            self._apply_exception_handler = MagicMock()

    fake_blueprint = FakeBlueprint()
    fake_handler = MagicMock()

    exception_mixin = ExceptionMixin()

    decorator = exception_mixin.exception(Exception)(fake_handler)
    assert decorator is fake_handler
    assert len(exception_mixin._future_exceptions) == 1
    assert any(decorator is fake_handler for decorator, _ in exception_mixin._future_exceptions)
    exception_mixin._apply_exception_handler.assert_called_once()

    exception_mixin = FakeBlueprint()
    decorator = exception_mixin.exception([Exception])(fake_handler)


# Generated at 2022-06-24 04:07:14.619757
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin, ExceptionMixin)

# Generated at 2022-06-24 04:07:21.969449
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class NewException(Exception):
        pass

    class NewExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    class NewBlueprint(NewExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(NewBlueprint, self).__init__()

    bp = NewBlueprint()
    @bp.exception([NewException])
    def error_handler(request, exception):
        return 'Internal server error'

    assert bp._future_exceptions is not None
    assert NewException in bp._future_exceptions

# Generated at 2022-06-24 04:07:25.168028
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    blueprint1 = Blueprint()
    assert blueprint1._future_exceptions
#-----------------------------------------------------------------------------------------------------------

# Generated at 2022-06-24 04:07:35.248504
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Preconditions
    from unittest.mock import MagicMock

    from sanic.models.futures import FutureException

    apply = True
    exceptions = (MagicMock, Exception)
    handler = MagicMock()

    exception_mixin = ExceptionMixin()
    exception_mixin.logger.warning = MagicMock()

    # Test steps
    exception = exception_mixin.exception(*exceptions, apply=apply)
    exception_handler = exception(handler)

    # Postconditions
    assert callable(exception_handler)
    assert isinstance(
        exception_handler,
        types.MethodType
    ) is True
    assert exception_mixin._future_exceptions == {
        FutureException(handler, exceptions)
    }
    exception_mixin.logger.warning.assert_not_

# Generated at 2022-06-24 04:07:39.610218
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class a:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    def handler(self, request, exception):
        return request, exception

    @a.exception(Exception, apply=True)
    def handler(self, request, exception):
        return request, exception

    future_exception = FutureException(handler, (Exception,))
    assert a._future_exceptions == {future_exception}

# Generated at 2022-06-24 04:07:47.056600
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint:
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            self._future_exceptions.add(handler)

    class TestException(Exception):
        pass

    @Blueprint.exception(apply=True)
    def handler(request, exception):
        return 'OK'

    assert len(Blueprint._future_exceptions) == 1
    exception = next(iter(Blueprint._future_exceptions))
    assert exception.handler == handler

# Generated at 2022-06-24 04:07:47.673798
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:07:53.796079
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('test_bp', url_prefix='/test')

    @bp.exception(SanicException)
    def test_exception_handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    exception_handler = bp._future_exceptions.pop()
    assert exception_handler.handler == test_exception_handler
    assert exception_handler.args[0] == SanicException

# Generated at 2022-06-24 04:07:56.169914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass

    x = A()
    assert len(x._future_exceptions) == 0
    assert x.exception(ValueError, apply=False)

# Generated at 2022-06-24 04:08:01.511963
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.models.futures import FutureException
    from sanic.models import Blueprint
    
    router = Router()
    blueprint = Blueprint(name="blueprint", router=router)
    blueprint.exception([ServerError])(lambda request, exception: json({"status": "global exception"}))
    blueprint._apply_exception_handler(FutureException(lambda request, exception: json({"status": "global exception"}), (ServerError,)))

# Generated at 2022-06-24 04:08:04.709596
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BluePrint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    bp = BluePrint()
    assert isinstance(bp._future_exceptions, set)
    assert not bp._future_exceptions


# Generated at 2022-06-24 04:08:08.826319
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class FakeBlueprint(ExceptionMixin):
        pass
    # check that super constructor is called correctly
    test_exception_mixin = FakeBlueprint()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:08:13.455470
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp')

    bp.exception(Exception)(print)

    assert bp._future_exceptions
    assert [] == list(bp._future_exceptions)

# Generated at 2022-06-24 04:08:17.545452
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

    assert isinstance(TestExceptionMixin(), ExceptionMixin)


# Generated at 2022-06-24 04:08:19.229505
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert isinstance(e._future_exceptions, set)
    assert len(e._future_exceptions) == 0

# Generated at 2022-06-24 04:08:22.942354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    exc_list = [Exception, ValueError]
    bp.exception(*exc_list)(None)
    assert isinstance(bp._future_exceptions.pop(), FutureException)
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:08:32.816239
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    isExceptions = False
    isHandler = False
    isApply = False
    isExceptionsInArgs = False
    isApplyInArgs = False
    testObject = ExceptionMixin()

    def handler():
        pass

    def decorator(args):
        nonlocal isExceptions
        nonlocal isHandler
        nonlocal isApply
        nonlocal isExceptionsInArgs
        nonlocal isApplyInArgs

        if isinstance(args, tuple):
            isExceptions = True
        elif callable(args):
            isHandler = True
        elif isinstance(args, bool):
            isApply = True
        elif isinstance(args, list):
            isExceptionsInArgs = True
        elif isinstance(args, FutureException):
            isApplyInArgs = True
        return handler

    testFunction = testObject.exception

# Generated at 2022-06-24 04:08:42.400591
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.was_called = False

        def _apply_exception_handler(self, handler):
            assert handler.exceptions == (RuntimeError,)
            assert handler.handler == handler_method
            self.was_called = True

    def handler_method(self):
        pass

    test = TestClass()

    @test.exception(RuntimeError)
    def handler_method(self):
        pass

    assert test.was_called

# Generated at 2022-06-24 04:08:53.142439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException

    class ExceptionMixin_MockObject(ExceptionMixin):
        """ This module is used to test ExceptionMixin class """

        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            """
            This function is used to check if function exception returns the
            correcct response.

            :param handler:
            :return:
            """
            # Simulate the case where the decorator is used with default param
            # apply=True
            # The function _apply_exception_handler should be called

# Generated at 2022-06-24 04:08:56.280736
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_class = type("TestClass", (ExceptionMixin,), {})
    instance = test_class()

    assert isinstance(instance, ExceptionMixin)

# Generated at 2022-06-24 04:09:07.330335
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bluprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = Bluprint()
    assert len(bp._future_exceptions) == 0

    @bp.exception(BaseException)
    def global_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 1


###############################################################################
# Tests for method apply_future_exception of class Blueprint
###############################################################################

from sanic.blueprints import Blueprint
from sanic.router import Route
from sanic.response import HTTPResponse
from sanic.views import HTTPMethodView



# Generated at 2022-06-24 04:09:08.864183
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:09:14.622267
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    app = Sanic("test_ExceptionMixin_exception")
    class B(ExceptionMixin):
        pass
    b = B()
    @b.exception(ValueError)
    def func(request, exception):
        print("func")

    assert len(b._future_exceptions) == 1
    item = list(b._future_exceptions)[0]
    assert item._exceptions == (ValueError,)
    assert item._handler == func

# Generated at 2022-06-24 04:09:22.792272
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.log import logger
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.server import HttpProtocol
    from sanic.routing import RouteExists, RouteReset
    from sanic.exceptions import (
        ServerError, Abort, InvalidUsage, NotFound,
        PayloadTooLarge, RequestTimeout, Unauthorized)

    exceptions = (NotFound, InvalidUsage, PayloadTooLarge, RequestTimeout,
                  Unauthorized, ServerError)


# Generated at 2022-06-24 04:09:30.946444
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import BlueprintModel
    from sanic.handler import Handler
    from sanic.exceptions import ServerError
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class TestHandler(Handler):
        async def default(self, request: Request, *args, **kwargs):
            return

    test_handler = TestHandler()
    blueprint = BlueprintModel(
        name="test_blueprint",
        url_prefix="/testurl",
        host="testhost",
        strict_slashes=True,
        version="v1",
    )

    blueprint.add_route(
        uri="/test_endpoint",
        handler=test_handler.default,
        methods=["PUT"],
    )


# Generated at 2022-06-24 04:09:42.051028
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.exceptions import SanicHandlerException
    from sanic.models.exception_handler import ExceptionHandler
    from sanic.models.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception', url_prefix="/test1")

    class ExceptionMixin_test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()
            self.exception_handlers = set()

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handlers.add(handler.handler)

    em_test = ExceptionMixin_test()


# Generated at 2022-06-24 04:09:48.539802
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:09:56.695927
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Future:
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exc = ExceptionMixin()

    @exc.exception(Exception)
    def handler(request, exception):
        return '%s', exception

    assert isinstance(handler, FutureException)

    assert len(exc._future_exceptions) > 0
    assert FutureException in type(handler).__bases__

# Generated at 2022-06-24 04:10:07.535066
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    test_name = 'test'
    route_name = 'route_name'
    option_a = 'option_a'
    option_b = 'option_b'
    host = 'host'

    blueprint = Blueprint(test_name, host)

    @blueprint.route(route_name, host=host)
    def test_route(request):
        pass

    assert blueprint._future_exceptions == set()

    # Test exception method
    @blueprint.exception(Exception)
    def exceptionHandler(request, exception):
        print(exception)

    future_exception = FutureException(exceptionHandler, (Exception,))
    assert blueprint._future_exceptions == set([future_exception])
    blueprint._exception_handler(Exception, None)

    # Test exception method


# Generated at 2022-06-24 04:10:10.200219
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    b = Blueprint(__name__)
    assert b._future_exceptions == set()

# Generated at 2022-06-24 04:10:19.234748
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import text
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_exception', url_prefix='test_exception')
    @bp.exception(Exception)
    def exception_handler(request, exception):
        return text(exception.__class__.__name__, status=500)

    app = Sanic('test-exception')
    app.blueprint(bp)
    @app.route('/')
    def hello(request):
        raise Exception('Some exception')
    request, response = app.test_client.get('/')
    assert response.status == 500
    assert response.text == 'Exception'



# Generated at 2022-06-24 04:10:22.543437
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    @ExceptionMixin.exception(ZeroDivisionError)
    def division_by_zero(request, exception):
        pass

    assert division_by_zero.future_exception.exceptions

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:10:27.538856
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
        Test method ExceptionMixin.exception
    """
    @TestBlueprint.exception(Exception)
    def test_handler(request, exception):
        pass
    TestBlueprint.exception(Exception)(test_handler)()

# Generated at 2022-06-24 04:10:30.350250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    This method validates that ``exception()`` method works
    '''
    mix_in_object = ExceptionMixin()
    mix_in_object.exception(Exception)

# Generated at 2022-06-24 04:10:37.997256
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create exceptions
    exceptions = RuntimeError, ValueError
    # Check if the exceptions are caught by handler
    expected_exceptions = ValueError, RuntimeError

    # Create a FutureException object with the handler and the exceptions
    # FutureException is a class that stores information about the exception
    # handler and the exceptions
    future_exception = FutureException(handler, exceptions)

    # Check if the list of exceptions is set in the __init__ method of the class
    assert future_exception._exceptions == expected_exceptions

    # Check if the handler is set in the __init__ method of the class
    assert future_exception._handler == handler

# Generated at 2022-06-24 04:10:40.084854
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin_instance = ExceptionMixin()
    assert exception_mixin_instance._future_exceptions == set()



# Generated at 2022-06-24 04:10:44.716992
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    # Test with Sanic object
    app = Sanic()
    assert isinstance(app, Sanic)

    # Test with Blueprint object
    bp = Blueprint("test_bp", url_prefix='test1')
    assert isinstance(bp, Blueprint)


# Generated at 2022-06-24 04:10:50.965150
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-24 04:10:55.447889
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
    exception_mixin = TestExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:10:57.121774
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj is not None, "Object constructed successfully"



# Generated at 2022-06-24 04:11:05.170842
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions_model import UrlDispatchError
    from sanic.models.blueprints import SanicBlueprint

    test_blueprint = SanicBlueprint('test', url_prefix='/test')
    test_blueprint2 = SanicBlueprint('test2', url_prefix='/test2')

    @test_blueprint.exception(UrlDispatchError)
    async def error_handler(r, e):
        pass

    assert len(test_blueprint._future_exceptions) == 1
    assert len(test_blueprint2._future_exceptions) == 0

# Generated at 2022-06-24 04:11:07.506132
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass

    m = Test()
    assert len(m._future_exceptions) == 0
    assert isinstance(m._future_exceptions, set)

# Generated at 2022-06-24 04:11:08.817286
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:11:09.876161
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:11:19.446762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.exceptions import ServerError

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')

    @bp.exception(ServerError)
    def handler_raised_server_error(request, exception):
        return json({'error': 'server error'}, status=500)

    @bp.exception(ValueError)
    def handler_raised_value_error(request, exception):
        return json({'error': 'value error'}, status=400)

    app.blueprint(bp)

    request, response = app.test_client.get('/')
    assert response.status == 500


# Generated at 2022-06-24 04:11:19.909726
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 1 == 1

# Generated at 2022-06-24 04:11:24.388320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorator(handler):
        pass
    a = ExceptionMixin()
    decorator = a.exception(1, 2, list=("a", "b"), apply=True)
    assert decorator == decorator

# Generated at 2022-06-24 04:11:26.546060
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()

    A()

# Generated at 2022-06-24 04:11:32.366476
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MixinA(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MixinA, self).__init__(*args, **kwargs)
    mixin = MixinA()
    f = mixin._future_exceptions
    assert len(f) == 0

# Generated at 2022-06-24 04:11:36.461657
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m._future_exceptions == set()


# Generated at 2022-06-24 04:11:44.056346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        _future_exceptions = set()
        def _apply_exception_handler(self, handler):
            handler()

    a: ExceptionMixin = A()
    a.exception(Exception, apply=False)
    assert len(a._future_exceptions) == 0, "Should not add to _future_exceptions, because apply=False"

    test = False
    @a.exception(Exception, apply=True)
    def exception_handler(requests):
        nonlocal test
        test = True
    assert len(a._future_exceptions) == 1, "Should add to _future_exceptions, because apply=True"
    assert test == True, "Should apply the exception_handler, because apply=True"

# Generated at 2022-06-24 04:11:47.903576
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint_exception(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    blue_exception = blueprint_exception()
    blue_exception.exception(ValueError, apply=True)
    assert len(blue_exception._future_exceptions) == 1

# Generated at 2022-06-24 04:11:49.757633
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass
    assert isinstance(A(), ExceptionMixin)


# Generated at 2022-06-24 04:11:52.095340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:55.957821
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest.mock
    from sanic.blueprints import Blueprint

    bp = Blueprint('test', url_prefix='test')
    assert bp._future_exceptions == set()
    assert bp._apply_exception_handler == unittest.mock.ANY


# Generated at 2022-06-24 04:11:59.337944
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint('','','', None)
    decorator = blueprint.exception(Exception)
    method_handler = lambda: 1
    assert decorator(method_handler) == method_handler

# Generated at 2022-06-24 04:12:07.029837
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

    import pytest

    ExceptionMixinTest().exception(Exception)()
    ExceptionMixinTest().exception([Exception])()
    ExceptionMixinTest().exception(Exception, apply=False)()
    ExceptionMixinTest().exception([Exception, NotImplementedError])()

    with pytest.raises(NotImplementedError):
        ExceptionMixinTest().exception([Exception, NotImplementedError], apply=True)()

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:12:11.456076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(request,exception):
        return request,exception
    class ExceptionMixin_test(ExceptionMixin):
        pass
    exception_mixin_test = ExceptionMixin_test()
    exception_mixin_test.exception(TypeError,IndexError,apply=True)(handler)
    assert exception_mixin_test._future_exceptions
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-24 04:12:18.025972
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    class FakeSanic(ExceptionMixin):
        def __init__(self, exception_handler):
            self.web_app: sanic.Sanic = sanic.Sanic()
            self.web_app.error_handler_spec = {}
            self.web_app.exception(*exception_handler[0].exceptions)(
                exception_handler[0].handler
            )

    fake_sanic = FakeSanic([FutureException(lambda _: "", (Exception,))])
    assert fake_sanic.web_app.error_handler_spec[Exception] == (
        lambda _, __: "",
    )

# Generated at 2022-06-24 04:12:27.392307
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.router import RouteExists

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    app = Sanic()
    bp = TestExceptionMixin()

    @bp.exception(Exception)
    def test_handler(request, exception):
        pass

    # Test adding exception and the existence of the handler
    assert len(bp._future_exceptions) == 1
    handler = bp._future_exceptions.pop()
    assert handler.handler == test_handler
    assert handler.exceptions == (Exception,)

    # Test adding multiple exceptions and the existence of the handler
    @bp.exception((ValueError, TypeError))
    def test_handler2(request, exception):
        pass


# Generated at 2022-06-24 04:12:30.576664
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return None

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:12:32.427034
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # ExceptionMixin expected to initialize empty set
    result = ExceptionMixin()._future_exceptions
    assert result == set()

# Generated at 2022-06-24 04:12:35.306996
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    bp = Sanic("test_ExceptionMixin")
    assert bp._future_exceptions == set()



# Generated at 2022-06-24 04:12:41.378879
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    mixin = MyMixin()
    @mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert issubclass(mixin.handler.exceptions[0], Exception)
    assert mixin.handler.handler == exception_handler

# Generated at 2022-06-24 04:12:50.148787
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class ErrorHandler(Exception):
        pass

    class ErrorHTTPMethodView(HTTPMethodView, ExceptionMixin):
        pass

    class ErrorBlueprint(Blueprint, ExceptionMixin):
        pass

    class ErrorSanic(Sanic, ExceptionMixin):
        pass

    @ErrorHandler.exception
    def exception_handler(request, exception):
        return text('Exception handler')

    @ErrorHTTPMethodView.exception(ErrorHandler)
    def http_method_view_exception_handler(request, exception):
        return text('HTTP Method View Exception Handler')


# Generated at 2022-06-24 04:12:52.627820
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SomeClass:
        pass

    obj = SomeClass()

    ExceptionMixin.__init__(obj)
    ExceptionMixin.exception(obj)

# Generated at 2022-06-24 04:12:57.688739
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Adapter(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    assert Adapter()._future_exceptions == set()


# Generated at 2022-06-24 04:12:59.741167
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	exception_mixin = ExceptionMixin()
	assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:13:05.649868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import FutureMixin
    from sanic.blueprints.blueprint import Blueprint

    blueprint = Blueprint('testException')
    blueprint_exception = blueprint.exception([FutureMixin], apply=True)
    blueprint_exception(lambda x: x + 1)

    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:13:14.330461
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class bp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
        pass
    obj = bp()

    @obj.exception(apply=True)
    def handler():
        pass

    assert obj.handler is not None
    assert len(obj._future_exceptions) == 1


# Generated at 2022-06-24 04:13:25.015398
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a fake class which inherit from ExceptionMixin
    class FakeExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(FakeExceptionMixin, self).__init__()

    fake_exception_mixin = FakeExceptionMixin()

    # Create a fake function
    def fake_handler(*args, **kwargs):
        print("I am fake_handler")

    fake_exception_mixin._future_exceptions.add(FutureException(fake_handler, []))
    fake_exception_mixin._future_exceptions.add(FutureException(fake_handler, [Exception]))
    assert len(fake_exception_mixin._future_exceptions) == 2
    for element in fake_exception_mixin._future_exceptions:
        assert callable(element.function)

# Generated at 2022-06-24 04:13:27.550605
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Example(ExceptionMixin):
        pass
    e = Example()
    assert type(e) == Example
    assert e._future_exceptions == set()


# Generated at 2022-06-24 04:13:30.142378
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test():
        return 'test'
    exceptions = [Exception]
    args = (exceptions, True)
    mixin = ExceptionMixin()
    mixin.exception(*args)(test)()

# Generated at 2022-06-24 04:13:31.630581
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptions = ExceptionMixin()
    assert isinstance(exceptions, ExceptionMixin)


# Generated at 2022-06-24 04:13:34.465033
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    test = Test()
    assert hasattr(test, '_future_exceptions')
    assert type(test._future_exceptions) is set

# Generated at 2022-06-24 04:13:36.482909
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass

    t = ExceptionMixinTest()

# Generated at 2022-06-24 04:13:37.833578
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Check whether the method exception of class ExceptionMixin is working properly
    pass

# Generated at 2022-06-24 04:13:48.717150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    bp = Blueprint('bp', version=2, url_prefix='/test')

    # Test with a single exception.
    @bp.exception(ServerError)
    def handler_001(request, exception):
        assert exception.status_code == 500
        return 'OK'

    # Test with a list of exceptions.
    @bp.exception([ServerError, AttributeError])
    def handler_002(request, exception):
        assert exception.status_code == 500
        return 'OK'

    # Test with a single exception and additional arguments.
    @bp.exception(ServerError, apply=False)
    def handler_003(request, exception):
        assert exception.status_code == 500
        return 'OK'

    # Test with a

# Generated at 2022-06-24 04:13:53.872729
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_object = ExceptionMixinTest()
    assert isinstance(test_object, ExceptionMixin)
    assert hasattr(test_object, '_future_exceptions')
    assert isinstance(test_object._future_exceptions, Set)


# Generated at 2022-06-24 04:13:58.880779
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        exception_mixin = ExceptionMixin()
    except:
        assert False

    # Check that _future_handler of ExceptionMixin is initialized correctly
    assert len(exception_mixin._future_exceptions) == 0


# Generated at 2022-06-24 04:14:01.680837
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return

    emt = ExceptionMixinTest()
    assert emt._future_exceptions == set()


# Generated at 2022-06-24 04:14:04.423406
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    a = A()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:14:07.011776
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    blueprint = Blueprint(__name__)

    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:14:10.473704
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinObject(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    obj = ExceptionMixinObject()
    assert isinstance(obj, ExceptionMixin)


# Generated at 2022-06-24 04:14:11.867742
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	assert len(ExceptionMixin()._future_exceptions)==0


# Generated at 2022-06-24 04:14:14.050322
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BlueprintExceptionMixin(ExceptionMixin): pass
    assert BlueprintExceptionMixin(1, 2)._future_exceptions == set()

# Generated at 2022-06-24 04:14:16.029478
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    my_exception = ExceptionMixin()
    assert my_exception._future_exceptions == set()

# Generated at 2022-06-24 04:14:23.216609
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    obj = A()
    assert obj._future_exceptions == set()

    @obj.exception(IndexError)
    def handler(request, exception):
        pass

    assert len(obj._future_exceptions) == 1
    assert obj._future_exceptions == {FutureException(handler, (IndexError,))}

# Generated at 2022-06-24 04:14:35.079675
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Set up the environment for the test
    class BP(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.test_exception_value = None
            self._apply_exception_handler_called = False

        def _apply_exception_handler(self, handler: FutureException) -> None:
            self.test_exception_value = handler.__dict__
            self._apply_exception_handler_called = True

        def test_exception(self):
            return self.exception(Exception)

    bp = BP()

    # Get the exception method of the class BP
    exception = bp.test_exception()

    # Define the handler
    @exception
    def handler(request, exception):
        raise RuntimeError

    # Check the result

# Generated at 2022-06-24 04:14:45.844376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BpClass(ExceptionMixin):

        def __init__(self):
            self.handler1 = None
            self.handler2 = None
            self.handler3 = None
            self.exceptions1 = None
            self.exceptions2 = None
            self.exceptions3 = None
            self.args1 = {}
            self.args2 = {}
            self.args3 = {}
            self.apply1 = None
            self.apply2 = None
            self.apply3 = None

        def _apply_exception_handler(self, handler):
            if handler.handler == self.handler1:
                self.exceptions1 = handler.exceptions
                self.args1 = handler.args
                self.apply1 = True
            elif handler.handler == self.handler2:
                self.exceptions2 = handler.ex

# Generated at 2022-06-24 04:14:46.993941
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions is N

# Generated at 2022-06-24 04:14:52.371998
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(AttributeError)
    def attribute_handler(request, exception_handler):
        return exception_handler(request, exception)
    assert attribute_handler

    @ExceptionMixin.exception(IndexError, apply=False)
    def index_handler(request, exception_handler):
        return exception_handler(request, exception)
    assert index_handler

# Generated at 2022-06-24 04:15:01.598608
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global get_handler

    class MyException(Exception):
        def __init__(self, *args, **kwargs):
            pass
    
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    
    blueprint = MyExceptionMixin()
    blueprint._apply_exception_handler = apply_exception_handler_stub
    
    def get_handler(exception):
        return exception.handler
    
    def test_handler(request):
        return 'handler'
    
    blueprint.exception(MyException)(test_handler)
    
    assert get_handler(MyException) == 'handler'

# Generated at 2022-06-24 04:15:05.412998
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()
    result = exceptionMixin._future_exceptions
    assert isinstance(result, set)


# Generated at 2022-06-24 04:15:08.217071
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.exceptions import ExceptionMixin

    a = ExceptionMixin()

    # Checking if all instance variables are initialised
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:15:10.855706
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_function = test_exception_mixin.exception(Exception)(lambda x: x)
    assert test_function is not None, "Not return a function"



# Generated at 2022-06-24 04:15:12.789774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 1 == 1



# Generated at 2022-06-24 04:15:15.077563
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_set = ExceptionMixin()

    @exception_set.exception(Exception)
    def exception(request, exception):
        return exception

    assert True



# Generated at 2022-06-24 04:15:16.050152
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-24 04:15:20.512400
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('exception', url_prefix='tests')


    @blueprint.exception(ValueError)
    def exception_handler(request, exception):
        print(exception)

    assert blueprint._future_exceptions == {FutureException(exception_handler, ValueError)}

# Generated at 2022-06-24 04:15:28.498386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @A.exception(ValueError)
    def handler(request, exception):
        pass

    @A.exception(ValueError)
    def handler2(request, exception):
        pass

    a = A()
    assert len(a._future_exceptions) == 2
    assert (handler, (ValueError,)) in a._future_exceptions



# Generated at 2022-06-24 04:15:31.563433
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert True
    # _future_exceptions = set()
    # assert ExceptionMixin._future_exceptions == set()
    # _future_exceptions = set()
    # assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:35.549266
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # Create Blueprint object
    blueprint = Blueprint(name = "test_exception", url_prefix = "test")
    # Create mock method for decorator
    @blueprint.exception(exceptions = ValueError, apply = True)
    def handler(request, exception):
        return request, exception
    # Test assertion
    assert blueprint._future_exceptions != None


# Generated at 2022-06-24 04:15:38.420279
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Generated at 2022-06-24 04:15:41.246818
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:15:50.650596
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic import Sanic

    app = Sanic("test_ExceptionMixin")
    # Test the constructor of the ExceptionMixin class
    bp = Blueprint("test_ExceptionMixin", url_prefix='test')
    for i in range(10):
        assert i == len(bp._future_exceptions)
        bp.exception(Exception)(lambda request, exception: None)
        assert i + 1 == len(bp._future_exceptions)
    app.blueprint(bp)

    # Test the global exception of the ExceptionMixin class
    bp = Blueprint("test_ExceptionMixin", url_prefix='test')
    bp.exception(Exception)(lambda request, exception: None)
    app.blueprint(bp)
    response, status_code = app.handle_request