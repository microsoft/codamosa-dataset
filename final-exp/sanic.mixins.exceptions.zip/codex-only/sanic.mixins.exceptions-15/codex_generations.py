

# Generated at 2022-06-24 04:06:02.643569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bp1(ExceptionMixin): pass
    
    @Bp1.exception(Exception)
    def exception_handle(req, exception):
        return exception
    
    bp = Bp1()
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)
    assert type(bp.exception_handle) == function

# Generated at 2022-06-24 04:06:08.749317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTester(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            assert handler._exceptions == (ValueError,)
            assert handler._url != ''

    tester = ExceptionMixinTester()
    @tester.exception(ValueError)
    def foo():
        pass



# Generated at 2022-06-24 04:06:17.713763
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class One(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__instance = None

        @property
        def _instance(self):
            return self.__instance

        @_instance.setter
        def _instance(self, val):
            self.__instance = val

    @One.exception(KeyError)
    def key_error(request, exception):
        pass

    @One.exception(KeyError, apply=False)
    def key_error_apply_false(request, exception):
        pass

    @One.exception(KeyError, apply=False)
    def key_error_apply_false_2(request, exception):
        pass


# Generated at 2022-06-24 04:06:23.975989
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from tests.test_test import assert_all_in

    blueprint = Blueprint("name", "url_prefix", host='test')
    blueprint.exception(Exception)
    blueprint.exception(ValueError)
    blueprint.exception([ValueError, TypeError])
    blueprint._apply_exception_handler = lambda e: e

    assert_all_in(
        repr(blueprint),
        ["Exception", "ValueError", "TypeError"])

# Generated at 2022-06-24 04:06:32.599763
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            exception = handler.exception
            handler = handler.handler
            handler(exception)
    class TestException(Exception):
        pass
    class ExceptionsTest(unittest.TestCase):
        def test_exception(self):
            exceptions = []
            def exception(e):
                exceptions.append(e)
            t = TestExceptionMixin()
            t.exception(TestException)(exception)
            # This will pass the test, otherwise it will throw an error
            t._apply_exceptions()
            self.assertIsInstance(exceptions[0], TestException)
    unittest.main()


# Generated at 2022-06-24 04:06:41.337199
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    exceptions = ('error', 'exception')

    class MyClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    my_class = MyClass()

    # Act
    @my_class.exception(*exceptions)
    def decorated_function(*args, **kwargs):
        pass

    # Assert
    assert my_class._future_exceptions
    my_class._future_exceptions.pop().apply()

# Generated at 2022-06-24 04:06:41.684505
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-24 04:06:45.434396
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        exception_mixin = ExceptionMixin()
        future_exceptions = exception_mixin._future_exceptions
        assert len(future_exceptions) == 0
    except:
        assert False


# Generated at 2022-06-24 04:06:47.481752
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    temp = ExceptionMixin()
    assert isinstance(temp, ExceptionMixin)
    assert temp._future_exceptions == set()

# Generated at 2022-06-24 04:06:54.426429
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.test_method_exception = True

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == test_handler
            assert handler.exceptions[0] == Exception
            assert handler.kwargs == {'test' : 'test_kwargs'}
            assert len(self._future_exceptions) == 1
            self.test_method_exception = False

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception, test='test_kwargs')
    def test_handler():
        pass
    assert test_exception_mix

# Generated at 2022-06-24 04:07:00.073210
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)
    assert hasattr(bp, 'exception')
    assert hasattr(bp.exception, '__call__')

# Generated at 2022-06-24 04:07:09.133042
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def my_exception_handler():
        pass

    expected_result = set(FutureException(my_exception_handler, (Exception, )))
    my_class = MyClass()
    my_class.exception(Exception)(my_exception_handler)
    assert my_class._future_exceptions == expected_result

# Generated at 2022-06-24 04:07:16.743948
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = TestExceptionMixin()
    def test_handler(request, exception):
        return 'test_handler'

    @test.exception(ZeroDivisionError, apply=False)
    def test_handler(request, exception):
        return 'test_handler'

    assert len(test._future_exceptions) == 1
    assert next(iter({handler for handler in test._future_exceptions})).handler == test_handler

# Generated at 2022-06-24 04:07:24.999334
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    class TestExceptionMixin(ExceptionMixin, unittest.TestCase):
        def __init__(self, methodName):
            unittest.TestCase.__init__(self, methodName)
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            self.assertEqual(handler._exceptions, (Exception,))
            self.assertEqual(handler._handler(), True)

        def test_exception(self):
            @self.exception(Exception)
            def test_handler():
                return True

    unittest.main()

# Generated at 2022-06-24 04:07:32.297602
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = TestExceptionMixin()

    @app.exception(ZeroDivisionError)
    def handler():
        return "Handled"

    assert isinstance(handler, FutureException)

    @app.exception([ZeroDivisionError])
    def handler_list():
        return "Handled"

    assert isinstance(handler_list, FutureException)

# Generated at 2022-06-24 04:07:34.023045
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass
    a=A()
    assert len(a._future_exceptions)==0


# Generated at 2022-06-24 04:07:36.042647
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test:
        def __init__(self, **kwargs):
            pass

    test = Test(**{})

    assert isinstance(test, ExceptionMixin)



# Generated at 2022-06-24 04:07:39.026743
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:07:40.249769
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp is not None


# Generated at 2022-06-24 04:07:47.907332
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @Foo().exception(ZeroDivisionError)
    def zero_division(request, exception):
        pass

    future_exceptions = getattr(Foo, '_future_exceptions')
    set_future_exceptions: set()
    assert set_future_exceptions == future_exceptions
    assert issubclass(ZeroDivisionError, set_future_exceptions.exceptions[0])
    assert zero_division == set_future_exceptions.handler

# Generated at 2022-06-24 04:07:50.799732
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest

    class TestExceptionMixin(unittest.TestCase):
        def test_exception_mixin(self):
            pass

    unittest.main()

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:07:58.729024
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(s):
            pass

        def _apply_exception_handler(s, handler):
            pass

    from pprint import pprint
    dummy = DummyExceptionMixin()
    @dummy.exception(Exception)
    def handler(a, b, c, a_handler_arg=3):
        pass
    future_exception = dummy._future_exceptions.pop()
    assert len(dummy._future_exceptions) == 0
    assert future_exception.exception_handler == handler
    assert future_exception.exception_types == (Exception,)
    assert future_exception.kwargs == {'a_handler_arg': 3}

    pprint(future_exception.__dict__)

# Generated at 2022-06-24 04:07:59.947182
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:08:02.548956
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    b = Blueprint()
    assert b._future_exceptions


# Generated at 2022-06-24 04:08:13.106816
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest.mock as mock

    @mock.patch.object(
        ExceptionMixin, '_future_exceptions', properties=mock.PropertyMock()
    )
    def __test(mock_future_exceptions, exceptions, kwargs):
        mock_future_exceptions.add.return_value = None
        mock_future_exceptions.pop.return_value = None
        mock_future_exceptions.clear.return_value = None
        mock_future_exceptions.isdisjoint.return_value = False
        mock_future_exceptions.__contains__.return_value = False
        mock_future_exceptions.__iand__.return_value = True
        kwargs.setdefault('apply', True)


# Generated at 2022-06-24 04:08:14.435104
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_exc = ExceptionMixin()
    assert test_exc

# Generated at 2022-06-24 04:08:15.821197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception = ExceptionMixin()
    assert exception is not None
    assert callable(exception.exception)

# Generated at 2022-06-24 04:08:21.454070
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_func():
        raise Exception("test exception")
    mixin = ExceptionMixin()

    @mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    try:
        test_func()
    except Exception:
        for future_exception in mixin._future_exceptions:
            assert future_exception.exceptions == (Exception,)
            assert future_exception.handler == test_handler

# Generated at 2022-06-24 04:08:27.359702
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import NotFound

    app = Sanic(__name__)

    @app.exception(NotFound)
    def ignore_404s(request, exception):
        return response.json({"code": 404})

    if __name__ == "__main__":
        app.run(host="0.0.0.0", port=8000, debug=True)

# Generated at 2022-06-24 04:08:28.751833
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
   assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:08:38.470125
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    future_exceptions = set()
    is_apply = True
    args = "args"
    kwargs = "kwargs"

    class testExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class testHandler:
        def __init__(self, *args, **kwargs):
            pass

    class testFuture:
        def __init__(self, handler, exceptions):
            pass

    ExceptionMixin.__init__ = MagicMock(return_value=None)
    ExceptionMixin._apply_exception_handler = MagicMock(
        return_value=None
    )
    testExceptionMixin.__init__ = MagicMock(return_value=None)

# Generated at 2022-06-24 04:08:47.266388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
        
    def test_handler(*args, **kwargs):
        pass
        
    exception_mixin = TestExceptionMixin()
    assert exception_mixin._future_exceptions == set()
    handler = exception_mixin.exception(Exception)(test_handler)
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = FutureException(handler, (Exception,))
    assert future_exception in exception_mixin._future_exceptions

# Generated at 2022-06-24 04:08:52.642260
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def exception_handler(request, exception):
        print("hello")

    # ExceptionMixin is a Mixin class, so it can't be directly tested
    # The only way to test it is to define a class inherited from it
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    test = Test()
    exception_function = test.exception(ZeroDivisionError)(exception_handler)

# Generated at 2022-06-24 04:08:59.174865
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    app = Sanic('test_ExceptionMixin')
 
    assert not app.blueprints
    assert not app._future_exceptions

    Blueprint = Blueprint

    blueprint = Blueprint('test_blueprint', url_prefix='/blueprint')

    assert not blueprint.routes
    assert not blueprint._future_exceptions

    assert not app.blueprints
    assert not app._future_exceptions

# Generated at 2022-06-24 04:09:02.821828
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic.models.route import Route

    bp = Blueprint(name="Test")

    assert bp._future_exceptions == set()
    assert isinstance(bp, Route)


# Generated at 2022-06-24 04:09:12.671758
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler):
            pass

    test = TestExceptionMixin()

    # test for success method exception
    def test_1():
        test.exception(Exception)(lambda exc: print("hello"))

    # test for failure method exception
    def test_2():
        test.exception([Exception, KeyError])(lambda exc: print("hello"))
        test.exception(Exception, KeyError)(lambda exc: print("hello"))
        test.exception(KeyError)(lambda exc: print("hello"))

    test_1()
    with pytest.raises(Exception):
        test_2()

# Generated at 2022-06-24 04:09:15.292547
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('blueprint', url_prefix='/blueprint')
    assert isinstance(blueprint._future_exceptions, set)



# Generated at 2022-06-24 04:09:25.985565
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.blueprints import Group
    from sanic.models.futures import FutureException

    bp = Blueprint('test_exception', url_prefix='/test_prefix')
    groups = [Group('prefix_group_1'), Group('prefix_group_2')]
    grouped_bp = Blueprint('test_exception_grouped', url_prefix='/test_prefix_grouped', groups=groups)

    exception1 = FutureException(lambda exc: None, (IndexError, ValueError))
    exception2 = FutureException(lambda exc: None, (RuntimeError,))

    # assert ExceptionMixin class
    assert hasattr(ExceptionMixin, '__init__')
    assert hasattr(ExceptionMixin, '_apply_exception_handler')

# Generated at 2022-06-24 04:09:29.515716
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinObj(ExceptionMixin):
        pass
    
    obj = ExceptionMixinObj()

    @obj.exception(KeyError, apply=True)
    def handler():
        return 10

    assert handler() == 10 
    assert not obj._future_exceptions
    assert obj._apply_exception_handler(handler) == None

# Generated at 2022-06-24 04:09:37.416451
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        @property
        def _blueprint(self):
            class _Blueprint:
                add_exception_handler = Mock()

            return _Blueprint()

    blueprint = Blueprint()
    blueprint.exception(ValueError)(Mock())
    assert blueprint._blueprint.add_exception_handler.called
    blueprint._future_exceptions.clear()
    blueprint.exception(ValueError, apply=False)(Mock())
    assert not blueprint._blueprint.add_exception_handler.called

# Generated at 2022-06-24 04:09:38.155904
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Add your unit test logic here
    pass

# Generated at 2022-06-24 04:09:44.997398
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            self.handler = handler

    test_mixin = TestExceptionMixin()
    @test_mixin.exception(KeyError)
    def exception_handler():
        pass

    assert test_mixin.handler and\
        isinstance(test_mixin.handler, FutureException)
    assert test_mixin.handler.exceptions == (KeyError,)

# Generated at 2022-06-24 04:09:53.828695
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass

    class ExceptionMixinStub(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exception_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler

    exception_mixin = ExceptionMixinStub()

    # Test passing an exception as the parameter
    @exception_mixin.exception(MyException)
    def exception_handler(_, __):
        pass
    assert isinstance(exception_mixin.exception_handler, FutureException)
    assert exception_mixin.exception_handler.handler is exception_handler

# Generated at 2022-06-24 04:09:54.329282
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert True

# Generated at 2022-06-24 04:09:55.554928
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:09:58.471171
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class AExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass
    am = AExceptionMixin()
    assert isinstance(am, AExceptionMixin)
    assert isinstance(am, ExceptionMixin)
    assert isinstance(am._future_exceptions, Set)
    assert not am._future_exceptions

# Generated at 2022-06-24 04:10:00.919121
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  em = ExceptionMixin()
  assert type(em._future_exceptions) == set


# Generated at 2022-06-24 04:10:02.976121
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:10:08.896015
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    t = TestExceptionMixin()
    t.exception(ValueError)(1)
    t.exception([ValueError,RuntimeError])(1)

# Generated at 2022-06-24 04:10:14.674906
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    class MyException(Exception):
        pass
    
    class TestExceptionMixin(ExceptionMixin, unittest.TestCase):
        def test_exception(self):
            def dummy():
                raise MyException('dummy')
            self.exception(MyException)(dummy)()
    TestExceptionMixin('test_exception').test_exception()

# Generated at 2022-06-24 04:10:21.419254
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create mock object
    blueprint = Mock()
    blueprint._future_exceptions = set()
    blueprint._apply_exception_handler = Mock()
    
    # run test

# Generated at 2022-06-24 04:10:24.979492
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.exceptions import SanicException
    from sanic.exceptions import ServerError, RequestTimeout
    bp = Blueprint("test")
    @bp.exception(ServerError, RequestTimeout)
    def test(request, exception):
        return ""
    assert(isinstance(test.__exceptions__, tuple))

# Generated at 2022-06-24 04:10:29.187757
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = ExceptionMixin()
    blueprint.__class__ = Blueprint
    #TODO: Test actual exception
    #TODO: Test mixin with route



# Generated at 2022-06-24 04:10:32.221708
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:10:36.475946
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint(name="test", url_prefix="/test")

    @blueprint.exception([RuntimeError])
    async def runtime_error_handler(request, error):
        return json({"error": None}, status=500)

    assert blueprint._future_exceptions
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)



# Generated at 2022-06-24 04:10:40.613173
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(A, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    x = A()
    @x.exception(ZeroDivisionError)
    def handler():
        return 1

    assert len(x._future_exceptions) == 1

# Generated at 2022-06-24 04:10:44.716628
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError
    assert TestExceptionMixin()

# Generated at 2022-06-24 04:10:46.012481
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert isinstance(em, ExceptionMixin)
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:10:51.629201
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprint import Blueprint
    from sanic.response import text

    bp = Blueprint("test_bp", url_prefix="/test_bp")

    @bp.exception(Exception)
    def handler_exception(request, exception):
        return text("Exception happened", 500)

    assert len(bp._future_exceptions) == 1

    handler = list(bp._future_exceptions)[0]
    assert handler.exceptions[0] == Exception
    assert handler.handler(None, None) == text("Exception happened", 500)

# Generated at 2022-06-24 04:10:59.103224
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockException(Exception):
        pass

    class MockExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    mock_mixin = MockExceptionMixin()
    exception_handler = mock_mixin.exception(MockException)

    assert exception_handler

    with pytest.raises(MockException):
        exception_handler(MockException())

# Generated at 2022-06-24 04:11:03.023730
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    s = Sanic()

# Generated at 2022-06-24 04:11:04.857144
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mi = ExceptionMixin()
    assert EmptySetError == EmptySetError

# Generated at 2022-06-24 04:11:09.571617
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from unittest import mock
    import pytest

    blueprint = Blueprint()
    blueprint.exception = mock.Mock(wraps=blueprint.exception)

    @blueprint.exception(Exception)
    def test():
        pass

    assert isinstance(blueprint._future_exceptions, set)
    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)
    assert blueprint.exception.call_count == 1

# Generated at 2022-06-24 04:11:10.063599
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:13.195197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    e = A()
    e.exception(Exception, apply=False)(Exception)
    assert isinstance(e._future_exceptions.pop(), FutureException)



# Generated at 2022-06-24 04:11:19.844210
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        @ExceptionMixin.exception(RuntimeError)
        def cb(request, exception):
            pass

    mixin = TestExceptionMixin()
    assert mixin._future_exceptions == set()

    mixin.cb(None)
    assert len(mixin._future_exceptions) == 1

    assert isinstance(mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:11:23.192533
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert isinstance(e._future_exceptions, set)

# Generated at 2022-06-24 04:11:25.007460
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mix_in = ExceptionMixin()
    assert mix_in._future_exceptions == set()

# Generated at 2022-06-24 04:11:29.594374
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = Blueprint('test', url_prefix='/test')
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:11:32.980205
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    try:
        @exception(Exception)
        def handler(request, exception):
            return text('I caught an exception')

        # raise ValueError
        # raise Exception
    except Exception as e:
        pass

# Generated at 2022-06-24 04:11:39.920490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    class MyBlueprint(Blueprint):
        pass
    myBlueprint = MyBlueprint('test_bp', url_prefix='test_bp')
    
    def HttpExceptionHandler(request, exception):
        assert True
    myBlueprint.exception(HttpException)(HttpExceptionHandler)

    def test_handler(request):
        raise HttpException()
    myBlueprint.add_route(test_handler, '/')
    assert myBlueprint.routes[0].exception_handlers == set([FutureException(HttpExceptionHandler, (HttpException,))])

# Generated at 2022-06-24 04:11:42.265879
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin, ExceptionMixin)
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:48.559633
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions = set()
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return handler
            
    t = Test()
    a = 1
    t.exception(a)

# Generated at 2022-06-24 04:11:55.682368
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test for ExceptionMixin.exception method
    """
    from sanic.models.blueprint import Blueprint
    from sanic.models.sanic import Sanic
    from sanic.models.exception import ServerError

    ExceptionMixin_obj = ExceptionMixin()
    blueprint = Blueprint(__name__, url_prefix = '/test_exception', version = '1')
    app = Sanic(__name__)
    ExceptionMixin_obj.exception((ServerError,), apply = True)(blueprint)
    assert ServerError in blueprint.exception_handlers



# Generated at 2022-06-24 04:11:57.358987
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:12:03.538076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BP(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    bp = BP()
    @bp.exception(Exception)
    def test(request, exception):
        pass

    assert len(bp._future_exceptions) == 1

    future_exception = bp._future_exceptions.pop()
    assert future_exception.handler == test
    assert future_exception.exceptions == (Exception, )

# Generated at 2022-06-24 04:12:09.622426
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = MockExceptionMixin()

    @exception_mixin.exception(IndexError, apply=True)
    def handler():
        pass

    future_exception = FutureException(handler, (IndexError,))
    assert exception_mixin._future_exceptions == {future_exception}

# Generated at 2022-06-24 04:12:11.414115
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin == exception_mixin


# Generated at 2022-06-24 04:12:12.622896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    # act 
    # assert
    return


# Generated at 2022-06-24 04:12:23.716467
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.server.exceptions import InvalidUsage, PayloadTooLarge
    bp = Blueprint('test_ExceptionMixin_exception_bp', url_prefix='test_ExceptionMixin_exception')

    @bp.exception(InvalidUsage, PayloadTooLarge)
    async def handler(request, exception):
        return json({"result": "exception_handler_ok"}, status=400)

    app = bp.create_app()
    request, response = app.test_client.get('/test_ExceptionMixin_exception')
    assert response.json["result"] == "exception_handler_ok"

# Generated at 2022-06-24 04:12:24.674844
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert(ExceptionMixin)

# Generated at 2022-06-24 04:12:28.641682
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        m = ExceptionMixin()
    except Exception as e:
        assert False, "ExceptionMixin init failed"

    assert m._future_exceptions == set(), "future_exceptions not set"


# Generated at 2022-06-24 04:12:33.289960
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import inspect
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(None, None, url_prefix="/")

    @blueprint.exception(IncorrectParameterError)
    def exception_handler(request, exception):
        assert True
    assert hasattr(blueprint, "exception")
    assert inspect.ismethod(blueprint.exception)

# Generated at 2022-06-24 04:12:35.359305
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-24 04:12:36.819833
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert not hasattr(ExceptionMixin(), "_future_exceptions")



# Generated at 2022-06-24 04:12:43.226233
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Initialize ExceptionMixin
    excp = ExceptionMixin()
    # Apply the decorator
    @excp.exception(apply=True)
    def deco():
        raise NotImplementedError
    # Get the FutureException object
    future_excp = excp._future_exceptions.pop()
    assert future_excp.exception_handler is deco
    assert future_excp.exceptions == (Exception,)

# Generated at 2022-06-24 04:12:50.329468
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        class TestExceptionMixin(ExceptionMixin):
            def __init__(self, *args, **kwargs) -> None:
                super().__init__(*args, **kwargs)

            def _apply_exception_handler(self, handler: FutureException):
                handler.handler(self, None)

        test_exception = TestExceptionMixin()
        exception_list = [Exception]

        @test_exception.exception(*exception_list)
        def exception_handler(request: Request, exc: Exception):
            assert isinstance(exc, Exception)
    except Exception as ex:
        print(ex)
        assert False


# Generated at 2022-06-24 04:12:57.355013
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    a = A()
    @a.exception(ValueError)
    def handler(request, exception):
        pass
    assert a._future_exceptions == {FutureException(handler, (ValueError,))}
    @a.exception([IndexError, KeyError])
    def handler2(request, exception):
        pass
    assert a._future_exceptions == {FutureException(handler, (ValueError,)), FutureException(handler2, (IndexError, KeyError))}

# Generated at 2022-06-24 04:13:00.939084
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert isinstance(em, ExceptionMixin), "Test case 1 failed."

    em = ExceptionMixin(1, 2, 3, a=4, b=2)
    assert isinstance(em, ExceptionMixin), "Test case 2 failed."



# Generated at 2022-06-24 04:13:09.750314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.exceptions import NotFound

    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self.app = Sanic()

        def _apply_exception_handler(self, handler: FutureException):
            self.app.exception(handler.exceptions)(handler.handler)

    class TestException(Exception):
        pass

    class TestRequest(Request):
        def __init__(self, app:Sanic, *args, **kwargs) -> None:
            super().__init__(app, *args, **kwargs)
            self.kwargs = {"test": "mytest"}

    test_class = TestClass()


# Generated at 2022-06-24 04:13:18.748361
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    
    app = Sanic('test_exception_mixin')
    blueprint = Blueprint('test_exception', url_prefix='/test_exception')
    
    @blueprint.exception(ServerError, apply=True)
    def error_handler(request, exception):
        return HTTPResponse('Internal Server Error', status=500)
    
    app.blueprint(blueprint)
    
    request, response = app.test_client.get('/test_exception')
    print(request)
    print(response.status)
    
if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:13:22.861046
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  from test_utils import MockClass
  from  sanic.models.futures import FutureException 
  from unittest import mock
  from test_utils import MockClass

  a = MockClass({},ExceptionMixin)
  assert a._future_exceptions == set()



# Generated at 2022-06-24 04:13:24.726965
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin, ExceptionMixin)


# Generated at 2022-06-24 04:13:32.236058
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    import sanic.models.functions as func

    bp = Blueprint("test")

    @bp.exception(func.Exception)
    @bp.exception(func.Exception, func.Exception)
    @bp.exception(func.Exception, apply=False)
    @bp.exception([func.Exception, func.Exception])
    @bp.exception([func.Exception, func.Exception, func.Exception], apply=False)
    def handler(request, exception):
        return request, exception

    assert isinstance(handler, func.types.FunctionType)
    assert len(bp._future_exceptions) == 5


# Generated at 2022-06-24 04:13:38.321038
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class cls(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @cls.exception(IndexError)
    def fja(request, exception):
        pass

    assert len(cls._future_exceptions) == 1

    handler = cls._future_exceptions.pop()
    assert handler.exceptions[0] == IndexError
    assert handler.handler == fja

# Generated at 2022-06-24 04:13:41.890582
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    em_obj = MockExceptionMixin()
    assert em_obj._future_exceptions == set()

# Generated at 2022-06-24 04:13:45.188257
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler
    @blueprint.exception(Exception)
    def exception_handler(_, __):
        pass

# Generated at 2022-06-24 04:13:47.255409
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()

    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:13:52.869162
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Excep(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError
    instance = Excep()
    @instance.exception(Exception, apply=True)
    def function():
        return "DONE"
    assert type(function) == functions.FunctionType
    assert instance._future_exceptions == {FutureException(function, (Exception,))}

# Generated at 2022-06-24 04:13:55.191097
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert isinstance(bp, ExceptionMixin)
    return bp


# Generated at 2022-06-24 04:13:56.999886
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:13:59.099195
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        assert(ExceptionMixin())

# Generated at 2022-06-24 04:13:59.978424
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True


# Generated at 2022-06-24 04:14:03.213958
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:14:04.659010
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:14:14.994427
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    blueprint = Blueprint(__name__)
    exception_1 = Exception("Test Exception 1")
    exception_2 = Exception("Test Exception 2")
    future_exception_1 = FutureException(None, exception_1)
    future_exception_2 = FutureException(None, exception_2)
    assert blueprint._future_exceptions == set()
    blueprint.exception(Exception("Test Exception"))

    blueprint.exception(Exception("Test Exception"))
    assert blueprint._future_exceptions == {future_exception_1}
    blueprint.exception(Exception("Test Exception 2"))
    assert blueprint._future_exceptions == {future_exception_1, future_exception_2}



# Generated at 2022-06-24 04:14:17.913674
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class B(ExceptionMixin):
        pass

    # Test if the exception mixin is initializing as it should be
    b = B()
    assert b._future_exceptions == set()

# Generated at 2022-06-24 04:14:22.058711
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert type(bp) == ExceptionMixin

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:14:22.694002
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ...

# Generated at 2022-06-24 04:14:29.189521
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.exception import ExceptionMixin

    class Something(ExceptionMixin):
        pass

    something = Something()
    assert something._future_exceptions == set()

    @something.exception(Exception)
    def test(request, exception):
        return 'Ok'

    assert isinstance(something._future_exceptions, set)
    assert len(something._future_exceptions) == 1
    assert (test, (Exception,)) in something._future_exceptions
    # Apply test
    something._exceptions[(test, (Exception,))]



# Generated at 2022-06-24 04:14:36.168848
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    from sanic import Blueprint
    bp = Blueprint(__name__)
    assert isinstance(bp, ExceptionMixin)

    assert len(bp._future_exceptions) == 0

    def test_function():
        return "test_function"

    bp.exception(test_function, apply=False)(test_function)
    fut_exp = FutureException(test_function, (test_function,))
    assert fut_exp in bp._future_exceptions

# Generated at 2022-06-24 04:14:39.988961
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        pass
    sanic = Sanic()
    f = sanic.exception(Exception)
    assert isinstance(f, FunctionType)



# Generated at 2022-06-24 04:14:48.422348
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint as _Blueprint
    from sanic.response import text
    from sanic.exceptions import NotFound, ServerError
    from sanic.models.futures import FutureException
    from sanic.models.futures import FutureExceptionHandler
    from sanic.exceptions import NotFound
    import pytest
    import asyncio
    import sys

    app = Sanic('test_ExceptionMixin')
    app.config.KEEP_ALIVE = False
    bp = _Blueprint(name="test_ExceptionMixin_exception_bp")
    # setup

    def test_handler(request, exception):
        return text('Exception handler was called!')

    @bp.route('/exception')
    def exception_function(request):
        raise NotFound

   

# Generated at 2022-06-24 04:14:49.451498
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Generated at 2022-06-24 04:14:53.408508
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin(): # noqa
    from sanic.blueprints import Blueprint
    exceptionMixin = ExceptionMixin()
    assert hasattr(exceptionMixin, '_future_exceptions') == True
    assert exceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:57.075462
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    test_class = TestClass()
    assert isinstance(test_class._future_exceptions, Set)


# Generated at 2022-06-24 04:14:58.566847
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """ExceptionMixin():
    constructor of ExceptionMixin Class
    """
    ExceptionMixin()


# Generated at 2022-06-24 04:15:08.164696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock
    from time import time
    from datetime import datetime, timedelta
    from sanic.models.futures import FutureException
    from sanic.response import json

    app = Sanic('test_ExceptionMixin_exception')

    blueprint = Blueprint('test_bp', url_prefix='/test', version='2')

    @blueprint.exception(ZeroDivisionError)
    async def custom_500(request, exception):
        return json({'status': exception.__class__.__name__, 'status_code': 500})

    request, response = app.test_client.get('/test/v2/t1')

# Generated at 2022-06-24 04:15:11.802386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # given
    class __ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exception_mixin = __ExceptionMixin()
    # when
    @exception_mixin.exception(Exception)
    def handler():
        return 1
    # then
    future_exception = FutureException(
        handler, (Exception,)
    )
    assert exception_mixin._future_exceptions
    assert future_exception in exception_mixin._future_exceptions

# Generated at 2022-06-24 04:15:22.499699
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()
    # TODO I don't know why I have to add this... It can be inferred
    # from the class without having to do it.
    # assert isinstance(em, ExceptionMixin)

# call method exception of ExceptionMixin class
# def test_exception():
#     from sanic import Sanic
#     from sanic.exceptions import NotFound
#     from sanic.response import text

#     app = Sanic()
#     exception = ExceptionMixin.exception(NotFound)
#     @app.route('/')
#     @exception
#     async def handler(request):
#         return text('I am the person handling the exception')
#     request, response = app.test_client.get('/')
#     assert response

# Generated at 2022-06-24 04:15:30.071889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin
    class TestExceptionMixin:
        pass
    @TestExceptionMixin.exception(Exception, ValueError)
    async def test_exception(request, exception):
        pass
    assert TestExceptionMixin.exception.__name__ == 'decorator'
    assert test_exception.__name__ == 'test_exception'
    assert TestExceptionMixin._future_exceptions.pop().handler.__name__ == 'test_exception'
    assert TestExceptionMixin._future_exceptions.pop().handler.__name__ == 'test_exception'

# Generated at 2022-06-24 04:15:36.892087
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.mixins.exceptions import BlueprintExceptionMixin
    from sanic.blueprints import Blueprint

    # GIVEN: an object of class ExceptionMixin
    bp = BlueprintExceptionMixin(Blueprint(name='foo'))

    # WHEN: constructor is called
    # THEN: object should be initialised as expected
    assert bp._future_exceptions is not None
    assert len(bp._future_exceptions) == 0



# Generated at 2022-06-24 04:15:47.382545
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    This unit test is about the method exception of class ExceptionMixin. It asserts that
    the output is supposed to be returned. It asserts that the output from the decorated
    function is supposed to be returned.
    """
    # Arrange
    from typing import Callable, TypeVar
    from unittest.mock import Mock
    from sanic import Sanic
    from sanic.exceptions import NotFound, ServerError
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint

    T = TypeVar("T", bound=Callable)
    mock_app = Sanic(__name__)
    mock_obj = Mock()
    mock_obj.__name__ = 'cur_object'


# Generated at 2022-06-24 04:15:50.738491
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    assert isinstance(TestExceptionMixin(), ExceptionMixin)


# Generated at 2022-06-24 04:15:51.952633
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin()._future_exceptions, set)


# Generated at 2022-06-24 04:15:56.256331
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def _handler(request, exception):
        pass
    blueprint: ExceptionMixin = ExceptionMixin()
    blueprint.exception(IndexError, TypeError)(_handler)

    future_exception: FutureException = blueprint._future_exceptions.pop()
    assert future_exception.exceptions == (IndexError, TypeError)
    assert future_exception.handler == _handler