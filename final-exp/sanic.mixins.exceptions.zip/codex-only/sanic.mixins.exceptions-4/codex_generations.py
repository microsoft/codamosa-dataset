

# Generated at 2022-06-24 04:05:53.744162
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(exception_mixin._future_exceptions, set)


# Generated at 2022-06-24 04:05:57.218219
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Obj(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Obj, self).__init__(*args, **kwargs)
            self._apply_exception_handler = mock.MagicMock()

    obj = Obj()
    errors = {404, 400}
    for error in errors:
        handler = mock.MagicMock()
        obj.exception(error)(handler)
        assert exception_handler in obj._future_exceptions
        assert obj._apply_exception_handler.call_count == len(errors)

# Generated at 2022-06-24 04:05:59.283899
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()
    assert mixin.__init__ is not None

# Generated at 2022-06-24 04:06:03.754821
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    blueprint = Blueprint('test')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:06:09.190013
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:06:14.549262
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ch:
        def h(self):
            return 1
    c = ch()
    decorator = c.exception(IOError, KeyError)
    assert decorator is c.h
    assert len(c._future_exceptions) == 1
    assert c._future_exceptions.pop() == FutureException(c.h, (IOError, KeyError))

# Generated at 2022-06-24 04:06:18.712880
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()
    test = TestClass()
    assert hasattr(test, "_future_exceptions")
    assert test._future_exceptions == set()



# Generated at 2022-06-24 04:06:28.177081
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = BLUEPRINT
    class TestException(Exception):
        pass

    @bp.exception([TestException])
    def test_exception(request, exception):
        print(f'test_exception: {exception}')

    assert isinstance(bp, ExceptionMixin)
    assert len(bp._future_exceptions) == 1

    future_exception = bp._future_exceptions.pop()
    assert future_exception.exceptions == (TestException,)
    assert future_exception.handler == test_exception

    assert bp.error_handlers == {}
    assert len(bp.error_handler_spec) == 0
    assert len(bp.error_handler_spec) == 0


# Generated at 2022-06-24 04:06:35.005592
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock, call
    blueprint = MagicMock(ExceptionMixin)
    exceptions = [ZeroDivisionError, ArithmeticError]
    apply = True
    result = blueprint.exception(*exceptions, apply=apply)
    assert result(1) == 1

    blueprint.apply_exception_handler.assert_has_calls([call(FutureException(1, exceptions))])
    blueprint.future_exceptions.assert_has_calls([call(FutureException(1, exceptions))])

    assert blueprint.future_exceptions.add.call_count == 1
    assert blueprint.future_exceptions.add.call_args == call(FutureException(1, exceptions))

# Generated at 2022-06-24 04:06:45.818696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test case 1
    set_expected = {
        FutureException(
            handler = 'handler',
            exceptions = tuple(['exception'])
        )
    }
    set_future_exceptions = set()
    a = ExceptionMixin()
    def handler():
        print('handler')
        return 'handler'
    a.exception(['exception'])(handler)
    assert a._future_exceptions == set_expected

    # test case 2
    set_expected = {
        FutureException(
            handler = 'handler1',
            exceptions = tuple(['ex1', 'ex2'])
        ),
        FutureException(
            handler = 'handler2',
            exceptions = tuple(['ex3', 'ex4'])
        )
    }
    set_future_exceptions = set()
    a = ExceptionMix

# Generated at 2022-06-24 04:06:51.538421
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test exception
    class blueprint(ExceptionMixin):
        def __init__(self, exception):
            super(blueprint, self).__init__()
            self.exception = exception

        def _apply_exception_handler(self, handler: FutureException):
            self.exception(5)

    @blueprint.exception(None)
    def test_exception(request, exception):
        return exception
    blueprint(test_exception)

    assert test_exception(5) == 5

# Generated at 2022-06-24 04:06:53.691692
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:00.777501
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    mixin = ExceptionMixinTest()
    assert isinstance(mixin, ExceptionMixin) is True
    assert isinstance(mixin._future_exceptions, set) is True


# Generated at 2022-06-24 04:07:11.329958
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic import Sanic
    from sanic.models.futures import FutureException

    class B(Blueprint, ExceptionMixin):
        pass

    app = Sanic('test_exception_blueprint')
    b = B('test_exception_blueprint', url_prefix='test_exception_blueprint')
    assert b._future_exceptions == set()

    @app.exception(Exception)
    def handler(request, exception):
        return text('error')

    # test case 1: normal case
    b._exception_handlers = app.exception_handlers
    b._apply_exception_handler(FutureException(handler, [Exception]))
    assert b._future_exceptions == set()
    assert len(b._exception_handlers) == 1



# Generated at 2022-06-24 04:07:18.916110
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # ExceptionMixin._apply_exception_handler has not been realized yet.
    # So, we can only test whether ExceptionMixin.exception will add FutureException
    # to _future_exceptions
    def handler1(*args, **kwargs):
        pass

    def handler2(*args, **kwargs):
        pass

    exception_mixin = ExceptionMixin()
    future_exceptions = exception_mixin._future_exceptions
    assert(len(future_exceptions) == 0)
    exception_mixin.exception(Exception)(handler1)
    assert(len(future_exceptions) == 1)
    exception_mixin.exception(Exception)(handler2)
    assert(len(future_exceptions) == 2)

# Generated at 2022-06-24 04:07:26.834302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Router:
        def exception(*args, **kwargs):
            return args[1]

    router1 = Router()
    ExceptionMixin.__bases__ = (router1.__class__,)
    ex_mixin = ExceptionMixin()

    @ex_mixin.exception(Exception, apply=False)
    def handler1(*args, **kwargs):
        pass

    assert(ex_mixin._future_exceptions ==
           set([FutureException(handler1, (Exception,))]))
    assert(router1.exception(None, FutureException(handler1, (Exception,)))
           == (Exception,))

# Generated at 2022-06-24 04:07:31.518852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @blp.exception([Exception])
    def handler(request, exception):
        print(exception)

if __name__ == '__main__':
    print('test ExceptionMixin')
    from sanic.blueprints import Blueprint
    blp = Blueprint('blp', url_prefix='blp')
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:07:37.844890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestBlp (ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    blp = TestBlp()
    @blp.exception(BaseException)
    def test(request, exception):
        return exception

    assert callable(test)

# Generated at 2022-06-24 04:07:48.315043
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class TestException(SanicException):
        def __init__(self, message, status_code=404):
            super().__init__(message, status_code)

    blueprint = Blueprint('test_bp')
    test_exception = TestException('test exception')

    try:
        @blueprint.exception(test_exception, apply=False)
        def error_handler(request: Request, exception: TestException):
            return HTTPResponse(exception.message, status=exception.status_code)
    except Exception as e:
        print(e)
        pytest.fail('Should not raise exception')

# Generated at 2022-06-24 04:07:49.123854
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin



# Generated at 2022-06-24 04:07:52.160893
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


# Generated at 2022-06-24 04:07:57.311165
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp', url_prefix='test')
    sanic_app = Sanic('test_sanic')
    bp.init_app(sanic_app)

    assert isinstance(bp, ExceptionMixin)
    assert isinstance(bp, Blueprint)
    assert bp.name == 'test_bp'
    assert bp.url_prefix == 'test'

# Generated at 2022-06-24 04:08:02.905923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeApp:
        def __init__(self):
            self.exception_handler_order = []
            self.exception_handler_order.append(Exception)

    class ExceptionMixinTest:
        @staticmethod
        def _apply_exception_handler(handler: FutureException):
            return handler

    exception_mixin = ExceptionMixinTest()
    app = FakeApp()
    exception_mixin.exception(Exception)(app)
    assert exception_mixin._future_exceptions
    assert len(exception_mixin._future_exceptions) == 1
    assert app.exception_handler_order
    assert len(app.exception_handler_order) == 2

# Generated at 2022-06-24 04:08:07.437921
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test = TestExceptionMixin()
    assert isinstance(test._future_exceptions, set)
    for exception in test._future_exceptions:
        assert isinstance(exception, FutureException)


# Generated at 2022-06-24 04:08:09.539014
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__+'test')
    assert isinstance(blueprint,ExceptionMixin)


# Generated at 2022-06-24 04:08:11.229801
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        instance = ExceptionMixin()
        instance = ExceptionMixin()
    except NameError:
        assert True
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-24 04:08:12.855177
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('blueprint')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:08:16.599530
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    import pytest
    from pytest import raises
    from sanic.blueprints import Blueprint

    b = Blueprint(__name__)

    with raises(NotImplementedError):
        b._apply_exception_handler(FutureException)


# Generated at 2022-06-24 04:08:20.721868
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint.init_from_dict({
        'name': 'blueprint_test',
        'view_functions': {},
    })

    assert isinstance(blueprint, Blueprint)
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:08:24.805181
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    #Test object creation
    class test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(test,self).__init__(*args, **kwargs)
    obj = test()
    print(isinstance(obj._future_exceptions, set))
    assert True

# Generated at 2022-06-24 04:08:30.977800
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    test_blueprint = Blueprint("Test", url_prefix="/test")
    assert test_blueprint._future_exceptions == set()

# This test will run by invoking the unittest module
if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-24 04:08:33.198582
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:08:40.872221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import ServerError, SanicException

    class HandleError(HTTPMethodView):
        def options(self, request: Request):
            return HTTPResponse(
                b"Returned when options is used on the url", status=200
            )

        def get(self, request: Request):
            return HTTPResponse(
                b"Returned when get is used on the url", status=200
            )

    bp = Blueprint("Test ExceptionMixin", url_prefix="test")

    class MyError(Exception):
        def __init__(self, message, errors):
            super().__init

# Generated at 2022-06-24 04:08:41.482509
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:52.486656
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_ExceptionMixin')

    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, app):
            super().__init__()
            self.app = app

        def _apply_exception_handler(self, handler: FutureException):
            self.app.error_handler.add(handler.exceptions, handler.handler)

    test_exception = ExceptionMixinTest(app)

    @test_exception.exception(KeyError)
    async def k_error(request, exception):
        return json({'exception': str(exception)}, status=500)

    @app.route('/')
    async def handler(request):
        raise KeyError('foo')

    request, response = app.test

# Generated at 2022-06-24 04:08:57.037527
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    TestExceptionMixin().exception()

# Generated at 2022-06-24 04:08:58.549744
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    EM = ExceptionMixin()
    assert EM._future_exceptions == set()

# Generated at 2022-06-24 04:08:59.231376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:08.785107
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.exceptions import NotFound, ServerError

    bp = Blueprint("tests_exception_mixin", url_prefix='/test')

    @bp.exception(NotFound)
    def ignore_404(request, exception):
        return json({"status": "failed", "reason": "resource not found"})

    @bp.exception(ServerError)
    def server_error_handler(request, exception):
        return json({"status": "failed", "reason": "internal server error"})

    app = Sanic()
    app.blueprint(bp)

    request, response = app.test_client.get('/test/non_existing_link')

# Generated at 2022-06-24 04:09:17.659052
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import mock
    class Dummy_ExceptionMixin(ExceptionMixin):
        pass

    dummy_ExceptionMixin = Dummy_ExceptionMixin()

    def dummy_decorator(func):
        ...

    with mock.patch.object(dummy_ExceptionMixin,
                            '_apply_exception_handler',
                            return_value = True) as mock_apply_exception_handler:
        with mock.patch('sanic.blueprints.FutureException',
                        return_value = FutureException('handler1', ['exception'])) as mock_FutureException:
            mock_exception = dummy_ExceptionMixin.exception('exception')
            assert mock_exception == dummy_decorator
            
            assert len(dummy_ExceptionMixin._future_exceptions) == 1
            assert dummy_ExceptionMix

# Generated at 2022-06-24 04:09:27.247838
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import functools
    import inspect
    import types
    import warnings

    from sanic.blueprints import Blueprint

    class TestExceptionMixin_exception(unittest.TestCase):

        def test_exception_handler(self):
            def exception(handler):
                def decorator(f):
                    @functools.wraps(f)
                    def wrapper(*args, **kwargs):
                        try:
                            return f(*args, **kwargs)
                        except Exception as e:
                            return handler(e)
                    return wrapper
                return decorator

            def run():
                warnings.warn('e')
                raise Exception('test')

            @exception(lambda e: 'exception test')
            def test():
                run()

            self.assertEqual(test(), 'exception test')

# Generated at 2022-06-24 04:09:35.407815
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from unittest import TestCase

    # Constructor test
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)

    # Test whitelist
    exception_mixin.exception('*')
    exception_mixin.exception(Exception)

    # Test blacklist
    exception_mixin.exception('!*')
    exception_mixin.exception('!Exception')
    assert True


if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:09:39.192358
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, a):
            super().__init__()
            self.a = a
    a = A(1)
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:09:47.776137
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self):
            self._future_exceptions = set()
        
        def _apply_exception_handler(self, handler: FutureException):
            print(handler)
            return
    
    a = A()
    exceptions = [Exception]
    apply = True

    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        a._future_exceptions.add(future_exception)
        if apply:
            a._apply_exception_handler(future_exception)
        return handler

    def test():
        print('test')

    print(a._future_exceptions)
    decorator(test)
   

# Generated at 2022-06-24 04:09:56.639630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # prepare
    from sanic.exceptions import ServerError

    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    # test
    test_object = TestClass()
    @test_object.exception(ServerError)
    def exeption_handeler(request, exception):
        raise NotImplementedError

    # verify
    assert len(test_object._future_exceptions) == 1

# Generated at 2022-06-24 04:10:00.323609
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()

    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:10:00.920552
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:10:05.947871
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # This is a unit test for the method exception of class ExceptionMixin
    # This method is normal and returns a decorator.
    @ExceptionMixin.exception(ValueError)
    def ex_handler(request, exception):
        pass
    # The value returned should be of function type and must be a decorator.
    assert type(ex_handler) == types.FunctionType
    assert callable(ex_handler)



# Generated at 2022-06-24 04:10:12.122341
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class S(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler._exceptions == {ValueError}
            assert handler._handler == func

    s = S()
    @s.exception(ValueError)
    def func(a):
        return a

    s._future_exceptions.pop()

# Generated at 2022-06-24 04:10:16.571168
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    bp = Blueprint(name="test", url_prefix="/test")
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-24 04:10:22.702157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = TestExceptionMixin()

    @exception_mixin.exception(Exception)
    def handler(request):
        pass

    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert future_exception.handler is handler
    assert future_exception.exceptions == (Exception,)

# Generated at 2022-06-24 04:10:30.621551
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BaseClass(ExceptionMixin):
        def __init__(self):
            pass
    @BaseClass.exception(ZeroDivisionError, apply=False)
    def my_handler():
        return ""
    assert len(BaseClass._future_exceptions) == 0
    # TODO: figure out a way to test that the decorated function will
    #  be added to the _applied_exception_handlers list
    assert BaseClass._apply_exception_handler == None

# Generated at 2022-06-24 04:10:39.466336
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest.mock
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = Sanic('test_ExceptionMixin')
    test_mixin = TestExceptionMixin()
    bp = Blueprint('test_ExceptionMixin', url_prefix='/foo')
    test_mixin.exception(IndexError)(lambda request, exc: None)
    assert len(test_mixin._future_exceptions) == 1
    test_mixin.exception([IndexError, KeyError])(lambda request, exc: None)
    assert len(test_mixin._future_exceptions) == 2

# Generated at 2022-06-24 04:10:46.590788
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_Test(ExceptionMixin):
        def testfunc(self, apply=True):
            @self.exception(Exception, ValueError, apply=apply)
            def handle_exception(request, exception):
                return text(
                    "inside handle_exception", status=getattr(exception, "code", 500)
                )

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin=ExceptionMixin_Test()
    test_mixin.testfunc(apply=True)

# Generated at 2022-06-24 04:10:52.242529
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_ExceptionMixin', url_prefix='test')
    assert isinstance(bp, ExceptionMixin)

# Generated at 2022-06-24 04:11:00.255812
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Base(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class Child(Base):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    Child()
    
test_ExceptionMixin()

# Generated at 2022-06-24 04:11:01.060047
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    _ = ExceptionMixin()

# Generated at 2022-06-24 04:11:09.480670
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    s = Sanic()
    assert isinstance(s, ExceptionMixin)
    assert isinstance(s, Sanic)

    assert s._future_exceptions == set()

    @s.exception(ZeroDivisionError)
    def handler(request, exception):
        pass

    assert len(s._future_exceptions) == 1
    future_exception = s._future_exceptions.pop()
    assert isinstance(future_exception, FutureException)
    assert future_exception.handler == handler
    assert future_exception.exceptions == (ZeroDivisionError,)

    # test exception can be a list

# Generated at 2022-06-24 04:11:14.339375
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints.blueprint import Blueprint as Blueprint_exception
    from sanic.app import Sanic
    exception_blueprint = Blueprint_exception("exception_blueprint")
    app = Sanic("exception_blueprint_method_exception")
    @exception_blueprint.exception(Exception)
    async def d(request, exception):
        pass

    assert len(exception_blueprint._future_exceptions) == 1
    assert exception_blueprint.exception is ExceptionMixin.exception

# Generated at 2022-06-24 04:11:15.334035
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    raise NotImplementedError


# Generated at 2022-06-24 04:11:19.319738
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            pass

    a = A()

    @a.exception(Exception)
    def handler(request, exception):
        return

    assert handler == a._future_exceptions.pop().handler

# Generated at 2022-06-24 04:11:27.381991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test', url_prefix='test')
    assert bp._future_exceptions == set()
    assert bp.exception(Exception)
    assert bp._future_exceptions != set()
    assert len(bp._future_exceptions) == 1
    assert ('<class \'Exception\'>',) in bp._future_exceptions

    def exception_handler(request, exception):
        pass

    assert bp.exception(Exception)(exception_handler).__name__ == 'exception_handler'

# Generated at 2022-06-24 04:11:32.206424
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  from sanic import Sanic
  from sanic.models import ExceptionMixin

  class TestExceptionMixin(Sanic, ExceptionMixin):
    def handle(self, request, exceptions):
      pass

  assert isinstance(TestExceptionMixin(), ExceptionMixin)


# Generated at 2022-06-24 04:11:34.689509
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:37.146468
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    # check that the object initialize correctly
    assert a.__class__.__name__ == "ExceptionMixin"


# Generated at 2022-06-24 04:11:42.211863
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    blueprint = ExceptionMixin()

    # Act
    blueprint.__init__()

    # Assert
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:11:45.261404
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass
    a = A()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:11:54.986216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from unittest.mock import Mock

    blueprint = Blueprint(name='test')

    @blueprint.exception(ServerError)
    def server_error_handler(request, exception):
        return 'Error'

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.__len__() == 1
    assert blueprint._future_exceptions.__contains__(
        FutureException(server_error_handler, (ServerError,)))

    app = Mock()
    blueprint.register(app)

    @blueprint.route('/')
    def route_handler(request):
        raise ServerError('Error')

    request, response = app.make_response.call_args[0]
    assert response.status == 500
    assert response

# Generated at 2022-06-24 04:12:05.337085
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    ExceptionMixin: Unit tests for method exception of class ExceptionMixin
    """
    import unittest
    import types
    from sanic.exceptions import HandleRequestTimeout

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mixin = ExceptionMixinTest()
    callable = lambda request: "OK"
    # Test if the method exception returns a new decorator.
    # Test if the decorated method is added to the list of
    # future exceptions.
    assert len(mixin._future_exceptions) == 0
    decorated = mixin.exception(HandleRequestTimeout)(callable)
    assert len(mixin._future_exceptions) == 1
    # Test if the decorator returns the same callable object.
    assert decorated == call

# Generated at 2022-06-24 04:12:16.295567
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.config import LOGGING
    from sanic.exceptions import InvalidUsage
    from sanic.handlers import ErrorHandler
    from sanic.log import create_logger

    class ExceptionMixinTester(Blueprint, ExceptionMixin):
        pass

    logger = create_logger(LOGGING)
    app = Sanic(__name__)
    blueprint = ExceptionMixinTester('test_ExceptionMixin', url_prefix='test')

    @blueprint.exception(apply=True)
    def handler(request, exception):
        return text('hi')

    assert isinstance(ErrorHandler.exception_handlers, dict)
    assert len(ErrorHandler.exception_handlers) == 1


# Generated at 2022-06-24 04:12:25.249347
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage

    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return handler

    mock = MockExceptionMixin()
    mock.exception(InvalidUsage)(lambda x, y: None)
    if len(mock._future_exceptions) == 0:
        raise AssertionError("The length of mock._future_exceptions is zero")

    mock = MockExceptionMixin()
    mock.exception(InvalidUsage)(lambda x, y: None)
    mock.exception([InvalidUsage])(lambda x, y: None)
    if len(mock._future_exceptions) == 0:
        raise AssertionError("The length of mock._future_exceptions is zero")

    mock = MockExceptionMixin()

# Generated at 2022-06-24 04:12:33.394070
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sys
    import inspect

    class _ExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    from sanic.exceptions import NotFound

    @_ExceptionMixin().exception(NotFound)
    def handler(request, exception):
        return text("Something went terribly wrong!", status=200)

    assert hasattr(_ExceptionMixin(), "_future_exceptions")
    assert isinstance(_ExceptionMixin()._future_exceptions, set)
    assert len(_ExceptionMixin()._future_exceptions) == 0
    assert hasattr(_ExceptionMixin(), "exception")
    assert inspect.ismethod(_ExceptionMixin().exception)

    # handler is the function created by decorator
    assert hasattr(handler, "__name__")

# Generated at 2022-06-24 04:12:35.879743
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert isinstance(obj, ExceptionMixin)
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:12:39.035769
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Sanic(ExceptionMixin):
        def __init__(self):
            super().__init__()

    assert isinstance(Sanic(), ExceptionMixin)


# Generated at 2022-06-24 04:12:40.921906
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:12:45.273754
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound

    app = Sanic('test_exception_mixin')

    @app.exception(NotFound)
    def test_exception_mixin(request, exception):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.status == 404
    assert response.text == 'OK'

# Generated at 2022-06-24 04:12:49.118634
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    from sanic import Blueprint
    from sanic.router import Route
    import pytest

    bp = Blueprint("bp", url_prefix="/test")
    # Act
    @bp.exception(Exception)
    def handler(request, exception):
        return "exception on blueprint"

    # Assert
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:12:51.182314
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    temp = TestExceptionMixin()



# Generated at 2022-06-24 04:12:58.476651
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ModelForExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    model = ModelForExceptionMixin()
    @model.exception(TypeError)
    def exception(request, exception):
        return None
    assert isinstance(model._future_exceptions.pop(), FutureException)
    assert exception.__name__ == 'exception'
    assert model.exception.__name__ == 'exception'
    assert exception.__name__ == model.exception.__name__

# Generated at 2022-06-24 04:13:02.461536
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	e = ExceptionMixin()
	assert e._future_exceptions == set()

# Generated at 2022-06-24 04:13:09.443696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test")

    # test: type of return value is right or not
    def decorator(handler):
        if type(handler) is int:
            return 5
        else:
            return 1

    bp.exception = ExceptionMixin.exception
    assert bp.exception(5)(5) == 5

    # test: type of exceptions is "list" or not
    def exception_decorator(exceptions, apply=True):
        if type(exceptions) is list:
            return "exceptions is list"
        else:
            return "exceptions is not list"

    bp.exception = exception_decorator
    assert bp.exception([1, 2, 3]) == "exceptions is list"

# Generated at 2022-06-24 04:13:17.290429
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException

    class SomeClass(ExceptionMixin):
        pass

    @SomeClass.exception(Exception)
    def exception_handler(request, exception):
        pass

    class MyException(SanicException):
        pass

    assert FutureException(exception_handler, (Exception, )) in SomeClass._future_exceptions
    assert FutureException(exception_handler, (Exception,)) in SomeClass._future_exceptions
    assert FutureException(exception_handler, (Exception, MyException)) in SomeClass._future_exceptions

# Generated at 2022-06-24 04:13:19.785167
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    app = Blueprint(__name__)

    @app.exception(ZeroDivisionError)
    def zero_division(request, exception):
        pass

# Generated at 2022-06-24 04:13:22.144332
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    app = ExceptionMixin()
    assert isinstance(app, ExceptionMixin)
    assert isinstance(app._future_exceptions, set)


# Generated at 2022-06-24 04:13:27.737689
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('sd', url_prefix='/sd')
    blueprint._future_exceptions = set()

    def exception_handler(request, exception):
        pass

    blueprint._future_exceptions.add(
        FutureException(exception_handler, ('Exception',))
    )
    assert blueprint.exception('Exception')(exception_handler) == exception_handler
    assert isinstance(blueprint, ExceptionMixin)

# Generated at 2022-06-24 04:13:32.509208
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    def test_function(request, *args, **kwargs):
        return text("")

    bp = Blueprint('test_blueprint')
    assert not bp._future_exceptions
    bp.exception(Exception)(test_function)
    assert len(bp._future_exceptions) == 1



# Generated at 2022-06-24 04:13:43.398337
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import SanicException, ServerError
    import asyncio
    import pytest

    app = Sanic("test_sanic_app")
    app.config.KEEP_ALIVE = False

    bp = Blueprint("test_bp")

    @bp.exception(TypeError, apply=True)
    def handle_exception(request, exception):
        return text("Type Error!", status=200)

    @bp.route("/handle_exception")
    def handle_exception_handler(request):
        raise TypeError()

    app.blueprint(bp)


# Generated at 2022-06-24 04:13:52.434487
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_ExceptionMixin = ExceptionMixin()

# Generated at 2022-06-24 04:14:02.297570
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint

    bp = Blueprint('test', url_prefix='test2')

    @bp.exception
    async def handle_exception(request, exception):
        """Handle exceptions"""
        pass

    assert len(bp._exception_handlers) == 1
    assert bp._exception_handlers[0].handler == handle_exception
    assert bp._exception_handlers[0].exceptions == ()

    @bp.exception(TypeError, ZeroDivisionError)
    async def handle_exception_2(request, exception):
        """Handle exceptions"""
        pass

    assert len(bp._exception_handlers) == 2
    assert bp._exception_handlers[1].handler == handle_exception_2
    assert bp._exception_hand

# Generated at 2022-06-24 04:14:04.495574
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint("test", url_prefix ="/test")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:14:15.242207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMother(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_mother = ExceptionMixinMother()

    @exception_mixin_mother.exception(KeyError)
    def test_handler_without_param(request, error):
        assert isinstance(error, KeyError)

    @exception_mixin_mother.exception(KeyError)
    def test_handler_with_params(request, error, text):
        assert isinstance(error, KeyError)
        assert text == "test"

    assert len(exception_mixin_mother._future_exceptions) == 3

    # test for wrapped exception handler with params
    wrapped_handler_with_params = exception_mixin_mother._future_exceptions.pop()
    wrapped

# Generated at 2022-06-24 04:14:18.290411
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test')
    assert hasattr(bp, '_future_exceptions')
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-24 04:14:25.880625
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TempExceptionMixin(ExceptionMixin):
        pass
    class TempExceptionMixin2(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    
    test1 = TempExceptionMixin()
    test2 = TempExceptionMixin2()
    assert test1._future_exceptions == set()
    assert test2._future_exceptions == set()


# Generated at 2022-06-24 04:14:33.624448
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    # Create instance of a class that inherits from ExceptionMixin
    class Bp(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Bp, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    instance = Bp()

    # Check if _future_exceptions is set
    assert (instance._future_exceptions == set())

# Generated at 2022-06-24 04:14:37.460346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)

    # test invalid input
    assert exception_mixin.exception()

    # test valid input
    assert exception_mixin.exception(apply=True)
    assert exception_mixin.exception([Exception])
    assert exception_mixin.exception([Exception], apply=True)

# Generated at 2022-06-24 04:14:44.059605
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import NotFound

    app = Sanic(__name__)

    @app.exception(NotFound)
    def test(request, exception):
        return response.text('Not found', status=exception.status_code)

    @app.route('/foo')
    def test(request):
        return 'This is a test'

    request, response = app.test_client.get('/foo/bar')
    assert response.text == 'Not found'
    assert response.status == 404



# Generated at 2022-06-24 04:14:46.844780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTester(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    ExceptionMixinTester().exception(Exception, "foo")(None) == None


# Generated at 2022-06-24 04:14:47.322066
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin

# Generated at 2022-06-24 04:14:48.258345
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Generated at 2022-06-24 04:14:55.709266
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException, ServerError
    from sanic.blueprints import Blueprint

    blueprint = Blueprint()
    @blueprint.exception(SanicException)
    def sanic_exception_handler(request, exception):
        pass

    @blueprint.exception(SanicException)
    @blueprint.exception(ServerError)
    def server_error_handler(request, exception):
        pass

    assert len(list(blueprint._future_exceptions)) == 2

# Generated at 2022-06-24 04:14:57.909669
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin_obj = ExceptionMixin()
    assert exception_mixin_obj._future_exceptions == set()


# Generated at 2022-06-24 04:15:05.005045
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.exceptions = set()
            self.handler = ""
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    test = ExceptionMixinTest()
    test.exception(Exception)(lambda: "")
    handler = test.handler
    assert handler is not None
    assert len(test._future_exceptions) == 1
    assert handler in test._future_exceptions


# Generated at 2022-06-24 04:15:06.193413
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
    except:
        raise AssertionError

# Generated at 2022-06-24 04:15:09.840253
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic

    app = Sanic('test_app')
    # Test if properties are set correctly
    app._future_exceptions = set()

    # Test if constructor does not raise error
    assert isinstance(ExceptionMixin(app), ExceptionMixin)



# Generated at 2022-06-24 04:15:20.332718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.handlers import ErrorHandler
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureException

    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.app = Sanic()
            self.app.error_handler = ErrorHandler()

        def _apply_exception_handler(self, handler: FutureException):
            handler.register(self.app)

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"status": 200, "msg": "hello"})


# Generated at 2022-06-24 04:15:27.589217
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass(ExceptionMixin):
        def __init__(self):
            super(MyClass, self).__init__()

        def _apply_exception_handler(self, handler):
            pass

        def handler(self):
            pass

    my_class = MyClass()
    my_class.exception(TypeError, apply=True)(my_class.handler)
    assert len(my_class._future_exceptions) == 1
    assert len(list(my_class._future_exceptions)[0].exceptions) == 1

# Generated at 2022-06-24 04:15:35.250169
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic import Sanic
    from sanic.exceptions import ServerError

    app = Sanic("test_ExceptionMixin_exception")

    @app.exception(ServerError)
    async def handler(request, exception):
        print(exception)

    @app.route("/handler")
    async def handler_test(request):
        return "handler_test"

    assert len(app.listeners["after_server_start"]) == 0
    assert len(app.listeners["before_server_stop"]) == 0
    assert len(app.listeners["after_server_stop"]) == 0
    assert len(app.listeners["before_server_start"]) == 0
    assert len(app.listeners["before_server_start"]) == 0

# Generated at 2022-06-24 04:15:39.387789
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_val = type('test', (ExceptionMixin,), {})()
    assert test_val._future_exceptions == set()



# Generated at 2022-06-24 04:15:44.331431
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin("arg1", "arg2")
    print("Testing class constructor of ExceptionMixin ...")
    assert em._future_exceptions == set()
    print("success!")

if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:15:50.738860
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Before used by Sanic Blueprint
    from sanic.blueprints import Blueprint
    try:
        Blueprint.exception
    except AttributeError as e:
        assert True
    else:
        assert False

    from sanic.helpers import inject_order
    assert "_exception" not in Blueprint.__dict__

    Blueprint = inject_order(ExceptionMixin)(Blueprint)

    # After used by Sanic Blueprint
    assert "exception" in Blueprint.__dict__
    assert "_exception" in Blueprint.__dict__