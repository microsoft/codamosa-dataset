

# Generated at 2022-06-24 04:05:56.397675
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest:
        def __init__(self) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    exceptionMixinTest = ExceptionMixinTest()
    assert issubclass(ExceptionMixinTest, ExceptionMixin)


# Generated at 2022-06-24 04:05:58.122178
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:06:05.157103
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException, NotFound

    class B:
        pass

    dummy = B()

    assert isinstance(dummy, B)
    assert not isinstance(dummy, ExceptionMixin)

    dummy.exception(SanicException)(print)(123)
    dummy.exception(NotFound)(print)("abcde")

    assert len(dummy._future_exceptions) == 2

# Generated at 2022-06-24 04:06:07.324157
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance, ExceptionMixin)
    assert instance._future_exceptions == set()


# Generated at 2022-06-24 04:06:10.517355
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass

    e = ExceptionMixinTest()
    assert isinstance(e, ExceptionMixin)
    assert not isinstance(e, object)
    assert e._future_exceptions == set()



# Generated at 2022-06-24 04:06:20.513107
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest

    from sanic import Blueprint
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient, create_server

    from sanic_restful_resources.sanic import ExceptionMixin

    app = Blueprint(__name__)
    app.mixin(ExceptionMixin)

    @app.exception(IndexError)
    def exception_handler(request, exception):
        return json({"exception": str(exception)}, 500)

    class CustomClient(SanicTestClient):
        def _check_exception_handler(self, app, request, uri, exception):
            response = app.handle_request(request, write_callback=lambda x: None)
            _, status_code, body = response
            assert status_code == 500


# Generated at 2022-06-24 04:06:23.453726
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    exception_mixin = ExceptionMixin()

    # Assert
    assert isinstance(exception_mixin, ExceptionMixin)



# Generated at 2022-06-24 04:06:28.334828
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    ExceptionMixin_test = TestExceptionMixin()
    assert ExceptionMixin_test._future_exceptions == set()


# Generated at 2022-06-24 04:06:32.035736
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class TestException(Exception):
        pass

    blue = Blueprint('test_exception')

    @blue.exception(TestException)
    def test_func(request, exception):
        return request, exception

    assert test_func in blue._future_exceptions

# Generated at 2022-06-24 04:06:35.727248
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    em = ExceptionMixin_test()

    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:06:41.728775
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SampleException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            super().__init__(*args, **kwargs)

    assert SampleException()._future_exceptions == set()


# Generated at 2022-06-24 04:06:46.233821
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print('ExceptionMixin_test OK')

    ExceptionMixin_test().exception('a')

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:06:54.333808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Example:
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            return

        def exception(self, *exceptions, apply=True):
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions

                if isinstance(exceptions[0], list):
                    exceptions = tuple(*exceptions)

                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                if apply:
                    self._apply_exception_handler(future_exception)
                return handler

            return decorator

    obj = Example()

    @obj.exception(Exception)
    async def exception_handler(request, exception):
        return response.text('Internal server error', 500)



# Generated at 2022-06-24 04:06:57.074920
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:07:01.706194
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test = TestExceptionMixin()
    assert len(test._future_exceptions) == 0
    local_exceptions = [Exception, KeyError]
    @test.exception(*local_exceptions)
    def some_handler():
        pass
    assert len(test._future_exceptions) == 1
    future_exception = FutureException(some_handler, local_exceptions)
    assert future_exception in test._future_exceptions

# Generated at 2022-06-24 04:07:11.772466
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            nonlocal test_ExceptionMixin_exception_handler
            test_ExceptionMixin_exception_handler = handler

    def handler(request, exception):
        return 'HELLO'

    exception_mixin = TestExceptionMixin()
    exception_mixin.exception(Exception, apply=True)(handler)

    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.args == (Exception,)
    assert future_exception.kwargs == {}

    assert test_ExceptionMixin_exception_handler is future_exception

# Generated at 2022-06-24 04:07:19.904240
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:27.789635
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(Exception):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def apply_exception_handler(self, handler):
            self.handlers.append(handler)
            handler.func()

    class Blueprint:
        def __init__(self):
            self.exception_handlers = {}

    class Request:
        pass

    class Response:
        pass

    # Arrange
    test_abstract_class = TestExceptionMixin()
    test_abstract_class.handlers = []
    test_route = Blueprint()
    test_request = Request()
    test_response = Response()
    test_exception = TestException


# Generated at 2022-06-24 04:07:31.701919
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Create a new ExceptionMixin object
    exceptionMixin = ExceptionMixin()
    # Check if the constructor return None
    assert exceptionMixin is not None

# Generated at 2022-06-24 04:07:39.574904
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    class testExceptionMixin(ExceptionMixin, Blueprint):
        pass

    test_exception_mixin = testExceptionMixin()

    @test_exception_mixin.exception(Exception, apply=True)
    async def test_handler(request, exception):
        return text(exception)

    assert test_handler.__name__ == "test_handler"
    assert test_handler.__doc__ is None
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions == {FutureException(test_handler, (Exception,))}

# Generated at 2022-06-24 04:07:42.750057
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:07:45.141509
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptions = ExceptionMixin()
    assert exceptions._future_exceptions == set()

# Generated at 2022-06-24 04:07:52.788316
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a dummy class that inherits ExceptionMixin
    class DummyClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            nonlocal handler_called
            handler_called = True
        
    # create an instance of DummyClass
    dummy_exception_mixin = DummyClass()

    # simulate decorating the handler and passing it to the decorator
    handler = lambda: None
    handler_called = False  # used to verify that the handler is called in decorator
    exception_handler = dummy_exception_mixin.exception(Exception)

    exception_handler(handler)

    # verify that the handler is called
    assert handler_called

# Generated at 2022-06-24 04:07:59.532177
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    @Blueprint.exception(apply=False)
    async def exception_handler(request, exception):
        return response.text('Exception: %s' % exception)

    app = App(__name__)
    bp = Blueprint('test_bp', url_prefix='test')

    @bp.route('/')
    @bp.exception(apply=False)
    async def handler(request):
        raise Exception('exception')

    bp.register(app)
    app.exception(Exception)(exception_handler)
    request, response = app.test_client.get('/test/')

    assert response.text == 'Exception: exception'

# Generated at 2022-06-24 04:08:02.854515
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)
    assert ExceptionMixin.__init__.__annotations__ == {'return': None}
    assert ExceptionMixin.__init__.__defaults__ == ()
    assert ExceptionMixin.__init__.__kwdefaults__ == {}



# Generated at 2022-06-24 04:08:04.610326
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        pass

    t = TestClass()
    assert t._future_exceptions == set()
#



# Generated at 2022-06-24 04:08:06.175439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:09.693077
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException

    @ExceptionMixin.exception(SanicException)
    def _exception(request, exception):
        return "exception"

    assert _exception is not None

# Generated at 2022-06-24 04:08:17.105282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicException

    # Define a global exception handler for blueprint
    global_exception_list = []
    def global_exception_handler(request, exception):
        global_exception_list.append((request, exception))

    global_exception = FutureException(global_exception_handler, [SanicException])

    # Define a normal exception handler
    def normal_exception_handler(request, exception):
        pass

    normal_exception = FutureException(normal_exception_handler, [SanicException])

    # Define a class ExceptionMixin
    class ExceptionMixin_test(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()


# Generated at 2022-06-24 04:08:20.479180
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    m = ExceptionMixinTester()
    assert m._future_exceptions == set()

# Generated at 2022-06-24 04:08:22.268922
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    blueprint = Blueprint('example')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:08:25.321508
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class T(ExceptionMixin):
        pass
    t = T()
    assert isinstance(t, ExceptionMixin)

# Generated at 2022-06-24 04:08:32.239357
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint')
    blueprint._future_exceptions = set()
    blueprint._exceptions = set()
    blueprint.exception('test_exception')('test_handler')
    assert blueprint._future_exceptions == set()
    assert blueprint._exceptions == {FutureException('test_handler', ('test_exception',))}


# Generated at 2022-06-24 04:08:39.733696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from unittest.mock import Mock
    import pytest
    @pytest.mark.asyncio
    async def mock_exceptions(*args, **kwargs):
        nonlocal func
        while True:
            try:
                await func(*args, **kwargs)
            except Exception as e:
                print(e)

    def exception_handler():
        pass

    func = Mock()
    em = ExceptionMixin()
    em.exception = mock_exceptions
    em.exception(exception_handler)
    assert(isinstance(em._future_exceptions.pop(), FutureException))

# Generated at 2022-06-24 04:08:43.593345
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTests(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    test = ExceptionMixinTests()
    assert test



# Generated at 2022-06-24 04:08:46.883428
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class x(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return NotImplementedError  # noqa

    print(x().exception(Exception))

# Generated at 2022-06-24 04:08:53.915505
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print ('exception handler is applied')

    @testClass.exception(NameError)
    def handler(request, exception):
        print ('exception handler is called')

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:09:02.955634
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(Exception):
        pass
    test_exception = TestException()

    class Test:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()
            self.test_result = None

        def test(self):
            self.test_result = True

        def _apply_exception_handler(self, handler: FutureException):
            handler(self, test_exception)

    test = Test()
    
    def decorated_handler(self, *args, **kwargs):
        self.test_result = False

    test.exception(TestException)(decorated_handler)
    assert test.test_result == True
    assert len(test._future_exceptions) == 1

# Generated at 2022-06-24 04:09:03.424752
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:09:06.585622
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def some_exception_handler():
        return None
    assert type(some_exception_handler) is FutureException

# Generated at 2022-06-24 04:09:16.610885
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import _DefaultHandler

    # Note: Basically the process of creating a global exception handler for the
    #       current blueprint under question. Simply this method enables the
    #       process of creating a global exception handler for the current
    #       blueprint under question.
    #
    # Args:
    #   exceptions: List of Python exceptions to be caught by the handler
    #
    # Returns:
    #   A decorated method to handle global exceptions for any route registered
    #   under this blueprint.
    #
    # Example:
    #   @bp.exception(app.exception('Exception'))
    #   async def root(request, exception):
    #       pass
    bp = ExceptionMixin()
    # Append one default exception
    bp.exception('Exception')()

# Generated at 2022-06-24 04:09:19.399875
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    var = ExceptionMixin()
    assert var._future_exceptions == set()


# Generated at 2022-06-24 04:09:20.372550
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em

# Generated at 2022-06-24 04:09:29.156386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    expected1 = FutureException(None, None)

    class DummyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    expected2 = DummyClass()
    # applying decorator to a function
    @expected2.exception(None)
    def handler():
        pass
    assert expected1 in expected2._future_exceptions

    # applying decorator to a method
    class DummyClass2(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass


# Generated at 2022-06-24 04:09:34.704193
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    @A.exception(Exception)
    def _test_method(request, exception):
        # Just return exception
        return str(exception)

    a = A()
    assert _test_method()

# Generated at 2022-06-24 04:09:35.815274
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin is not None

# Generated at 2022-06-24 04:09:45.493807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    
    @testExceptionMixin.exception(Exception, apply=False)
    def test_exception_handler(request, exception):
        raise NotImplementedError  # noqa

    @testExceptionMixin.exception([Exception], apply=True)
    def test_exception_handler_1(request, exception):
        raise NotImplementedError  # noqa

    @testExceptionMixin.exception(Exception, apply=True)
    def test_exception_handler_2(request, exception):
        raise NotImplementedError  # noqa

   

# Generated at 2022-06-24 04:09:54.205879
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            print("Applying exception handler: " + handler.name)

    class TestException(Exception):
        pass

    # When
    test_instance = TestExceptionMixin()
    test_instance.exception(IndexError, TestException)(print)
    test_instance.exception(KeyError)(print)

    # Then
    assert test_instance._future_exceptions
    assert len(test_instance._future_exceptions) == 2
    assert test_instance._future_exceptions != len(test_instance._future_exceptions)

    # ...cleanup
    test_instance._future_exceptions.clear()

# Generated at 2022-06-24 04:10:01.882570
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
     import unittest
     from sanic.eventloop import EventLoop, handle_events
     from sanic.exceptions import SanicException
     from sanic.response import HTTPResponse
     from sanic.router import Router
     from sanic.server import HttpProtocol, sansio_exception_handler
     from sanic.testing import SanicTestClient, create_server
     from sanic import Sanic
     from sanic.blueprints import Blueprint
     from sanic.views import HTTPMethodView

     class CustomException(SanicException):
          pass

     class TestExceptionMixin(ExceptionMixin):

        @staticmethod
        def _apply_exception_handler(future_exception: FutureException):
            app.error_handler.add(future_exception.exception, future_exception.handler)

       

# Generated at 2022-06-24 04:10:05.818947
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

    t = TestExceptionMixin()
    assert t._future_exceptions == set()


# Generated at 2022-06-24 04:10:10.421132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mixin = ExceptionMixin()
    def dummy_handler():
        pass

    @mixin.exception(Exception)
    def dummy_handler():
        pass

    assert dummy_handler in {x.handler for x in mixin._future_exceptions}

# Generated at 2022-06-24 04:10:12.805564
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ConcreteClass(ExceptionMixin):
        pass
    concrete = ConcreteClass()
    assert concrete._future_exceptions == set()


# Generated at 2022-06-24 04:10:13.444286
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:10:14.971517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    e = ExceptionMixin()
    assert(e.exception() is None)



# Generated at 2022-06-24 04:10:23.502495
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from Sanic import Blueprint
    from scope.fixtures import app

    bp = Blueprint("bp", url_prefix="/bp")
    
    @bp.exception(Exception)
    def handler1(request, exception):
        return "handler1"
    
    @bp.exception(Exception, apply=False)
    def handler2(request, exception):
        return "handler2"
    
    app.blueprint(bp)
    res = app.test_client.get("/bp/handle")

    assert res.text == "handler1"



# Generated at 2022-06-24 04:10:35.672231
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            print('apply handler')
            print(handler.exceptions)

    a = A()

    @a.exception(IndexError)
    def index_handler(request, exception):
        print(exception)

    @a.exception([IndexError, KeyError])
    def index_key_handler(request, exception):
        print(exception)

    assert len(a._future_exceptions) == 2

    for exception in a._future_exceptions:
        assert type(exception) is FutureException
        assert len(exception.exceptions) == 1

    a._future_exceptions.clear()

# Generated at 2022-06-24 04:10:39.663589
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Temp(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Temp, self).__init__(*args, **kwargs)
    try:
        Temp()
    except TypeError:
        return False
    return True


# Generated at 2022-06-24 04:10:42.507770
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception = TestExceptionMixin()
    assert test_exception._future_exceptions == set()

# Generated at 2022-06-24 04:10:48.261323
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class objectTest1(ExceptionMixin):
        def __init__(self):
            super().__init__()
        def _apply_exception_handler(self, handler: FutureException):
            return 'Success'
    def _decorator(handler):
        return 'Success'
    Obj = objectTest1()
    assert Obj.exception(Exception,apply=True)(_decorator) == 'Success'
    assert Obj._future_exceptions.pop().handler == _decorator

# Generated at 2022-06-24 04:10:55.740628
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    app = Sanic("test_ExceptionMixin_exception")

    @app.exception(Exception)
    def handler(request, exception):
        return text("Exception was called")

    @app.exception(BaseException)
    def handler(request, exception):
        return text("Exception was called")

    request, response = app.test_client.get("/")
    assert response.text == "Exception was called"

# Generated at 2022-06-24 04:10:59.473872
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exception import FutureException, FutureHandler

    blueprint = Blueprint('test', url_prefix='/test')
    future_handler = blueprint.exception(ValueError, apply=False)

    assert future_handler is not None
    assert blueprint._future_exceptions is not None
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:11:04.876069
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints.blueprint import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint('test_bp')
    assert bp._future_exceptions == set()

    future_exception = FutureException(lambda: None, Exception)
    bp._future_exceptions.add(future_exception)
    assert bp._future_exceptions == {future_exception}


# Generated at 2022-06-24 04:11:10.746643
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinExample(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self.exceptions = 0

        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions += 1

    obj = ExceptionMixinExample()
    assert obj.exceptions == 0

    @obj.exception(Exception)
    def handler(req, exception, *args, **kwargs):
        pass

    assert len(obj._future_exceptions) == 1
    assert obj.exceptions == 1

# Generated at 2022-06-24 04:11:16.275427
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic.models.middleware import MiddlewareMixin
    from sanic.models.route import Route

    class B(MiddlewareMixin, ExceptionMixin, Blueprint):
        pass

    b = B(name="login", url_prefix="/login")
    assert b.name == "login"
    assert b.url_prefix == "/login"
    assert b._middleware_stack == []
    assert b._route_stack == {}
    assert b._future_exceptions == set()


# Generated at 2022-06-24 04:11:19.258944
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    te = TestExceptionMixin()
    assert te._future_exceptions == set()

# Generated at 2022-06-24 04:11:26.595316
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class ExceptionMixinImplement(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.arg_count = len(args)
            super(ExceptionMixinImplement, self).__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    e = ExceptionMixinImplement('a','b','c')
    assert e.arg_count == 3
    assert e._future_exceptions == set()



# Generated at 2022-06-24 04:11:29.218048
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    assert ExceptionMixin._future_exceptions is not None

# Generated at 2022-06-24 04:11:39.376823
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    import sanic

    bp = Blueprint('test_exception_bp')

    @bp.exception(NotFound, name='my-custom-name')
    def exception_handler(request, exception_):
        return HTTPResponse("Oh no! I caught an exception :(")

    @bp.exception(NotFound, apply=False)
    def exception_handler_2(request, exception_):
        return HTTPResponse("Oh no! I caught an exception :(")

    @bp.route('/test')
    def handler(request: Request):
        return HTTPResponse('OK')


# Generated at 2022-06-24 04:11:40.403971
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(1)

# Generated at 2022-06-24 04:11:51.044188
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = ()
    apply = True
    handler = "handle"

    future_exception = FutureException(handler, exceptions)

    future_exception2 = FutureException(handler, exceptions)

    expected_future_exceptions = {future_exception}
    expected_future_exceptions2 = {future_exception, future_exception2}

    class ExceptionMixinClass(ExceptionMixin):
        _future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = ExceptionMixinClass()

    @test_exception_mixin.exception(*exceptions, apply=apply)
    def decorator(handler):
        pass

    decorator(handler)

    assert test_

# Generated at 2022-06-24 04:11:57.677281
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    assert a._future_exceptions == set()

    @a.exception(Exception)
    def handler(self):
        return self

    assert type(handler) == types.FunctionType
    assert len(a._future_exceptions) == 1

    future_exception = a._future_exceptions.pop()
    assert future_exception.exception == Exception
    assert future_exception.handler == handler

# Generated at 2022-06-24 04:12:03.174286
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    from .testing import assert_raises

    @Blueprint.exception(Exception)
    def exception_handler(request, exception):
        return exception

    blueprint = Blueprint()
    assert_raises(
        NotImplementedError,
        blueprint._apply_exception_handler(FutureException(exception_handler, Exception))
    )

# Generated at 2022-06-24 04:12:11.852171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    obj = MyExceptionMixin()

    def f_handler(request, exception=None, **kwargs):
        return exception

    obj.exception(Exception)(f_handler)

    # list instead of tuple
    def f_handler(request, exception=None, **kwargs):
        return exception

    obj.exception([Exception])(f_handler)

    def f_handler(request, exception=None, **kwargs):
        return exception

    obj.exception(Exception, arg1=None)(f_handler)

    def f_handler(request, exception=None, **kwargs):
        return exception


# Generated at 2022-06-24 04:12:17.542528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint("sanic", host="localhost", port="1337")
    blueprint.exception(Exception)
    blueprint.exception(Exception)
    blueprint.exception(IndexError)
    blueprint.exception([Exception, IndexError])
    blueprint.exception(Exception, apply=False)

    assert len(blueprint._future_exceptions) == 3

# Generated at 2022-06-24 04:12:22.914294
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from angelos.document.base import Document
    from sanic.blueprint import Blueprint
    from sanic.exceptions import ServerError

    blueprint = Blueprint("blah", url_prefix = "/blah")
    blueprint.exception(ServerError)(lambda: True)

    doc = Document(blueprint)
    
    assert doc._future_exceptions
    assert next(iter(doc._future_exceptions)).handler

# Generated at 2022-06-24 04:12:24.284259
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(1, 2, 3)

# Generated at 2022-06-24 04:12:27.185083
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Foo(ExceptionMixin):
        pass
    # Given
    f = Foo()

    # Then
    assert isinstance(f._future_exceptions, set)
    assert f._future_exceptions == set()


# Generated at 2022-06-24 04:12:34.975217
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    from unittest.mock import patch

    @patch('sanic.blueprints.Blueprint._apply_exception_handler')
    def test(mock_apply_exception_handler):
        apply = True
        exceptions = (Exception, )

        bp = Blueprint('testbp')

        class TestView(HTTPMethodView, ExceptionMixin):
            pass

        view = TestView()

        result = view.exception(*exceptions, apply=apply)
        handler = result(lambda *args, **kwargs: None)

        mock_apply_exception_handler.assert_called_once_with(
            FutureException(handler, exceptions)
        )


# Generated at 2022-06-24 04:12:40.670857
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint('test_app', url_prefix = 'test_app')
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(ValueError)(print)
    blueprint.exception(Exception)(print)
    blueprint.exception(ValueError, Exception)(print)
    blueprint.exception(ValueError, Exception)(print)


# Generated at 2022-06-24 04:12:42.871033
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    obj = TestExceptionMixin()
    assert len(obj._future_exceptions) == 0


# Generated at 2022-06-24 04:12:47.090168
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint_relationship_definition = BlueprintMixin()
    blueprint_exception_definition = ExceptionMixin()
    blueprint_relationship_definition.__bases__ += (blueprint_exception_definition,)
    blueprint_relationship_definition.__init__()
    assert blueprint_relationship_definition.__class__.__bases__  == (BlueprintMixin, ExceptionMixin)


# Generated at 2022-06-24 04:12:53.402810
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    b = Blueprint('test_bp', url_prefix='/test_bp', version='test')

    @b.exception(ValueError)
    def handle_value_error(request, exception):
        # Default handler for ValueError
        return response.text(
                'Internal server error', status=500)

    # Check if the test blueprint has an exception handler added to it
    assert len(b._future_exceptions) == 1

# Generated at 2022-06-24 04:12:54.826670
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a

# Unit Tests for method exception()

# Generated at 2022-06-24 04:12:59.609134
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models import exception_mixin_fixture_data
    mixin = exception_mixin_fixture_data.exception_mixin
    assert mixin.exception
    assert isinstance(mixin.exception, MethodType)

# Generated at 2022-06-24 04:13:08.955838
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # initialize a class that inherits from ExceptionMixin
    class E1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    e1 = E1()

    # add exception handler for ZeroDivisionError
    @e1.exception(ZeroDivisionError)
    def zero_division(*args, **kwargs):
        print('ZeroDivisionError')
        return True

    # add another exception handler for ZeroDivisionError
    @e1.exception(ZeroDivisionError)
    def zero_division2(*args, **kwargs):
        print('ZeroDivisionError2')
        return True

    # check if the two exception handlers are added
    assert len(e1._future_exceptions) == 2

    # check if

# Generated at 2022-06-24 04:13:17.693863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
        
        def _apply_exception_handler(self, handler: FutureException):
            print("future_exception:", handler)
    
    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        print("exception_handler")


test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:13:20.988736
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert callable(ExceptionMixin)

# Generated at 2022-06-24 04:13:24.603037
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    em = TestExceptionMixin()

    assert isinstance(em, TestExceptionMixin)
    assert isinstance(em, ExceptionMixin)
    assert isinstance(em._future_exceptions, set)

# Generated at 2022-06-24 04:13:26.738353
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    ex_obj = Blueprint(name="sample")
    assert isinstance(ex_obj, ExceptionMixin)

# Generated at 2022-06-24 04:13:32.311261
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .test_exception_mixin import TestExceptionMixin

    instance = TestExceptionMixin()

    def some_function():
        return None

    def decorator(handler):
        return handler

    assert decorator == instance.exception(ValueError)(decorator)

    assert 2 == len(instance._future_exceptions)
    assert some_function == instance.exception([ValueError, KeyError])(some_function)

    assert 3 == len(instance._future_exceptions)



# Generated at 2022-06-24 04:13:43.276084
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(Exception)
    def handler(request, exception):
        return text('I am the exception message.', status=418)

    @blueprint.exception(Exception, apply=False)
    def handler2(request, exception):
        return text('I am the exception message.', status=418)

    # test that registering a handler returns the correct handler
    assert handler == blueprint._future_exceptions.pop().handler

    # test that registering a handler with apply=False returns the correct handler
    assert handler2 == blueprint._future_exceptions.pop().handler

    # test that registering a handler adds a future exception object to
    # the set of future exceptions

# Generated at 2022-06-24 04:13:53.872575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.route import Route

    class TestException(Exception):
        pass

    class TestObject(ExceptionMixin):
        def __init__(self, route):
            self.route = route
            self.registered_exceptions = set()

        def _apply_exception_handler(self, handler):
            self.registered_exceptions.add(handler)

    route = Route(method='GET', uri='/')
    obj = TestObject(route)

    @obj.exception(Exception)
    def exception_handler(request, exception):
        return exception

    assert obj.registered_exceptions == set()
    test_exception = TestException()
    exception_handler(None, test_exception)

# Generated at 2022-06-24 04:14:01.864846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    tm = TestExceptionMixin()
    # Act
    @tm.exception([ValueError], apply=True)
    def test_handler(request, exception):
        pass
    # Assert
    assert len(tm._future_exceptions) == 1
    assert len(tm._future_exceptions.pop().exceptions) == 1

# Generated at 2022-06-24 04:14:02.465240
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:14:03.003311
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:14:14.002109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    import asyncio

    blueprint = Blueprint("blueprint", url_prefix="/blueprint")
    blueprint.exception(SanicException)(lambda a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z: None) # noqa
    blueprint.exception(SanicException, [asyncio], apply=False)(lambda a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z: None) # noqa

# Generated at 2022-06-24 04:14:20.745565
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test1 = TestExceptionMixin()
    test2 = TestExceptionMixin()
    @test1.exception(IndexError)
    def index_error_handler(request, exception):
        pass
    @test2.exception(IndexError)
    def index_error_handler(request, exception):
        pass
    assert test1._future_exceptions == {FutureException(index_error_handler, (IndexError,))}
    assert test1._future_exceptions != test2._future_exceptions

# Generated at 2022-06-24 04:14:23.696689
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Tester(ExceptionMixin, object):
        pass
    t = Tester('Tester')
    assert not t._future_exceptions


# Generated at 2022-06-24 04:14:30.632358
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('user', url_prefix='/user')

    @bp.exception(ValueError)
    def error_handler(request, exception):
        response = json({
            "error": str(exception)
        })
        response.status_code = 400
        return response

    assert bp.exception_functions == {ValueError: error_handler}

# Generated at 2022-06-24 04:14:34.373420
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:14:35.157867
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert(isinstance(ExceptionMixin, type))

# Generated at 2022-06-24 04:14:45.245665
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    mock_exception_mixin = MockExceptionMixin()
    assert mock_exception_mixin._future_exceptions == set()

    exceptions = [Exception]
    def test_handler():
        pass

    mock_exception_mixin.exception(exceptions)(test_handler)
    assert len(mock_exception_mixin._future_exceptions) == 1
    assert isinstance(list(mock_exception_mixin._future_exceptions)[0], FutureException)

# Generated at 2022-06-24 04:14:55.862474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.exceptions import SanicException, ServerError
    from mock import MagicMock

    blueprint = Blueprint("test")

    def exception_handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    @blueprint.exception(SanicException)
    def another_exception_handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert blueprint.exception(ServerError)(exception_handler) is not None

    blueprint._apply_exception_handler = MagicMock()
    blueprint.exception(ServerError, apply=False)(exception_handler)
    blueprint._apply_exception_handler.assert_not_called()

# Generated at 2022-06-24 04:15:00.542926
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        raise NotImplementedError
    except NotImplementedError:
        ex1 = ExceptionMixin()
        ex1
    # TODO: Actually test something
    # assert True


# Generated at 2022-06-24 04:15:04.552139
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    object = ExceptionMixin(None)
    assert object._future_exceptions == set()

# Generated at 2022-06-24 04:15:08.429162
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixinClass, self).__init__(*args, **kwargs)
    obj = ExceptionMixinClass()
    assert isinstance(obj, ExceptionMixin) == True


# Generated at 2022-06-24 04:15:08.978077
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-24 04:15:10.960851
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert hasattr(exception_mixin, '_future_exceptions')

# Generated at 2022-06-24 04:15:12.939738
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class MyExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == None

# Generated at 2022-06-24 04:15:15.267757
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert type(em._future_exceptions) == set


# Generated at 2022-06-24 04:15:16.960121
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:15:19.113506
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:29.453689
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class foo(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(foo, self).__init__(self, *args, **kwargs)

    class bar:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a = foo()
    if len(a._future_exceptions) != 0:
        raise AssertionError
    if len(a.exception.__closure__) != 1:
        raise AssertionError
    if not callable(a.exception.__closure__[0].cell_contents):
        raise AssertionError
    if (a.exception.__closure__[0].cell_contents.__name__ != 'decorator'):
        raise Ass

# Generated at 2022-06-24 04:15:34.040235
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
    except NameError as e:
        print(e)


# Generated at 2022-06-24 04:15:43.419404
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler):
            print('apply exception handler')

    exmixtest = ExceptionMixinTest()
    @exmixtest.exception(TypeError)
    def test(request):
        return request

    assert test.__name__ == 'test'
    assert hasattr(exmixtest, '_future_exceptions')


# Generated at 2022-06-24 04:15:48.090402
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    app = Sanic(name="test_exception")
    class test_ExceptionMixin_exception(ExceptionMixin):
        pass
    obj = test_ExceptionMixin_exception()
    assert obj._future_exceptions == set()
    obj.exception(Exception)(Exception)
    assert obj._future_exceptions != set()

# Generated at 2022-06-24 04:15:48.671393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:15:55.042810
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_class(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
    test_object = test_class()
    # test attributes of the object after calling constructor
    assert test_object._future_exceptions == set()