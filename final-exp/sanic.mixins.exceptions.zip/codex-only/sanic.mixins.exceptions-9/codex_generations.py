

# Generated at 2022-06-24 04:06:01.449762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint('test')

    @bp.exception(Exception)
    def test(request, exception):
        return str(exception)

    @bp.exception(Exception, apply=False)
    def test_1(request, exception):
        return str(exception)

    assert test.__name__ == 'test'
    assert bp._future_exceptions
    assert len(bp._future_exceptions) == 2
    assert bp._future_exceptions == {
        FutureException(test, (Exception, )),
        FutureException(test_1, (Exception, ))
    }

# Generated at 2022-06-24 04:06:04.447429
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    errMsg = "Input needs to be of type 'ExceptionMixin'"
    ExcepMix = ExceptionMixin()
    assert type(ExcepMix) is ExceptionMixin, errMsg


# Generated at 2022-06-24 04:06:08.345057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class C(ExceptionMixin):
        pass

    c = C()
    assert len(c._future_exceptions) == 0
    c.exception(Exception)(lambda _: None)
    assert len(c._future_exceptions) == 0

# Generated at 2022-06-24 04:06:14.172918
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test_ExceptionMixin_exception')
    ExceptionMixin.__init__(bp)
    @bp.exception(Exception)
    async def handle_error(request, exception):
        return response.text('fail')
    assert len(bp._future_exceptions) != 0
    assert bp._future_exceptions != None
    assert (list(bp._future_exceptions)[0].__name__ == 'handle_error')
    assert (list(bp._future_exceptions)[0].exceptions == (Exception, ))
    assert bp._apply_exception_handler != None

# Generated at 2022-06-24 04:06:25.643835
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_sanic')
    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(Exception)
    def handler(request, exception):
        print('I caught an exception')

    @blueprint.get('/')
    def handler_get(request):
        return text('I am a get request!')

    @blueprint.post('/')
    def handler_post(request):
        return text('I am a post request!')

    @blueprint.delete('/')
    def handler_delete(request):
        return text('I am a delete request!')

    @blueprint.exception(Exception)
    def handler_exception(request, exception):
        return text('I am a exception request!')

# Generated at 2022-06-24 04:06:32.869238
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.response import HTTPResponse
    from tests.test_models.test_exceptions.test_exception_handlers import exception_handler

    bp = Blueprint("bp_to_test")
    future_ex = FutureException(exception_handler, HTTPResponse)

    assert isinstance(bp.exception(HTTPResponse, apply=True)(exception_handler), type(exception_handler))
    assert(future_ex in bp._future_exceptions)
    assert(future_ex in bp._exception_handlers)

# Generated at 2022-06-24 04:06:35.005919
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        _future_exceptions: Set[FutureException]

    test = TestExceptionMixin()
    assert type(test._future_exceptions) is set

# Generated at 2022-06-24 04:06:43.270307
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.exceptions import SanicException
    blueprint = Blueprint('some blueprint')

    @blueprint.exception(SanicException)
    def some_handler(request, exception):
        return "Hello World"

    future_exception = FutureException(some_handler, (SanicException,))

    assert blueprint._future_exceptions == {future_exception}
    assert blueprint.exception_handlers == {SanicException: some_handler}

# Generated at 2022-06-24 04:06:46.472635
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class dummy_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    assert dummy_ExceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:06:48.328099
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert type(e) == ExceptionMixin
    assert type(e._future_exceptions) == set
    e.__init__

# Generated at 2022-06-24 04:06:54.147896
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        @property
        def future_exceptions(self):
            return self._future_exceptions

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin.future_exceptions == set()


# Generated at 2022-06-24 04:06:57.221229
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = TestExceptionMixin()

    # When
    @exception_mixin.exception(ValueError, KeyError)
    def handle_exception():
        pass

    # Then



# Generated at 2022-06-24 04:07:06.053410
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureException:
        def __init__(self, handler, exceptions):
            self.handler = handler
            self.exceptions = exceptions

    class ExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    class FutureSanic:
        def _apply_exception_handler(self, handler: FutureException):
            pass

    SANIC = FutureSanic()
    EXCEPTIONMIXIN = ExceptionMixin()
    EXCEPTIONMIXIN.exception(ValueError, ZeroDivisionError, apply=False)(EXCEPTIONMIXIN._apply_exception_handler)
    assert SANIC._future_exceptions[-1].exceptions == (ValueError, ZeroDivisionError)


# Generated at 2022-06-24 04:07:06.748504
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()


# Generated at 2022-06-24 04:07:07.729595
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)

# Generated at 2022-06-24 04:07:10.096989
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with app.test_request_context():
        class TestExceptionMixin(ExceptionMixin):
            pass
        test_instance = TestExceptionMixin()
        assert test_instance._future_exceptions == set()

# Generated at 2022-06-24 04:07:11.336253
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test = ExceptionMixin()
    test._future_exceptions = set()
    test.exception(Exception)

# Generated at 2022-06-24 04:07:11.823478
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:07:15.605515
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert (type(mixin._future_exceptions) == type(set()))

# Generated at 2022-06-24 04:07:22.483223
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.future import FutureHandler
    from sanic.models.base import SanicModel
    from sanic.models.blueprint import BlueprintMixin

    class TestModel(SanicModel, FutureHandler, BlueprintMixin, ExceptionMixin):
        pass

    tm = TestModel()
    assert tm._future_exceptions == set()



# Generated at 2022-06-24 04:07:27.252787
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin')
    blueprint = Blueprint('test_ExceptionMixin')

    assert len(blueprint._future_exceptions) == 0
    assert isinstance(blueprint, ExceptionMixin) == True
    assert isinstance(app, ExceptionMixin) == False

# Generated at 2022-06-24 04:07:31.611082
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    async def handler(request, exception):
        return text("foo")
    blueprint = Blueprint("test_bp", url_prefix="test")

    blueprint.exception(Exception, apply=True)(handler)

    assert blueprint._future_exceptions

# Generated at 2022-06-24 04:07:39.909867
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        _apply_exception_handler = None

        def __init__(self):
            ExceptionMixin.__init__(self)

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception('a', 'b')
    def test_handler():
        return "test"

    assert test_exception_mixin._future_exceptions is not None
    assert len(test_exception_mixin._future_exceptions) == 1

    future_exception = test_exception_mixin._future_exceptions.pop()

    assert future_exception is not None
    assert len(future_exception[1]) == 2
    assert 'a' in future_exception[1]
    assert 'b' in future_exception

# Generated at 2022-06-24 04:07:41.856381
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert hasattr(ExceptionMixin, "_init_")

# Generated at 2022-06-24 04:07:46.516476
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = TestExceptionMixin()
    assert hasattr(test, '_future_exceptions')

# Generated at 2022-06-24 04:07:52.033064
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Dummy(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)

    d = Dummy()

    @d.exception(Exception)
    def dummy_func(req, res):
        return True

    assert isinstance(dummy_func, types.FunctionType)

test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:07:56.064341
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    node = TestException()
    assert isinstance(node, TestException)
    assert isinstance(node, ExceptionMixin)
    assert node._future_exceptions == set()


# Generated at 2022-06-24 04:08:00.638493
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from unittest import TestCase
    class ExceptionMixinTest(TestCase):
        def test_constructor(self):
            blueprint = Blueprint('')
            assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:08:08.104524
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def __init__(self, exceptions: Set[FutureException], collection):
            super().__init__()
            self._future_exceptions = exceptions
            self._collection = collection

        def _apply_exception_handler(self, handler: FutureException):
            self._collection.add(handler)

    exceptions = set()
    collection = set()
    sanic = Sanic(exceptions, collection)

    @sanic.exception(IndexError, KeyError)
    def handler(request, exception):
        pass

    assert len(exceptions) == 2
    assert len(collection) == 0
    exceptions.clear()

    @sanic.exception([IndexError, KeyError], apply=False)
    def handler(request, exception):
        pass

    assert len(exceptions) == 2


# Generated at 2022-06-24 04:08:08.546527
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:10.024882
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    b = ExceptionMixin()
    assert b._future_exceptions == set()

# Generated at 2022-06-24 04:08:11.613438
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert not exception_mixin._future_exceptions

# Generated at 2022-06-24 04:08:17.641255
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self):
            pass
        def exception(self, *exception,apply=True):
            return ["a", "b", "c"]

    class B(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    def decorator(handler):
        return handler

    a = A()
    assert a.exception("a", "b", "c") == ["a", "b", "c"]
    b = B()
    assert b.exception() == decorator

# Generated at 2022-06-24 04:08:19.299448
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e is not None
    assert e._future_exceptions is not None


# Generated at 2022-06-24 04:08:25.641965
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            pass

    app = Sanic(__name__)
    app.add_route(MyView.as_view(), '/')
    router = app.router.routes_all[0].handler

    @router.exception([Exception, ValueError])
    def _exception_handler(request, exception):
        pass

    assert len(router.future_exceptions) == 1
    assert router.future_exceptions[0].handler == _exception_handler
    assert router.future_exceptions[0].exceptions == (ValueError, Exception)

# Generated at 2022-06-24 04:08:36.284038
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #CHECK: on_exception(Exception)

    #CODE:
    class Blueprint(ExceptionMixin):
        routes = []

        @staticmethod
        def register_route(route):
            Blueprint.routes.append(route)

        @staticmethod
        def add_exception_handler(handler):
            Blueprint.routes[0].add_exception_handler(handler)

    @Blueprint.exception(Exception)
    def a(a, b=1):
        pass

    #POST-CONDITIONS:
    assert len(Blueprint.routes) == 1
    assert Blueprint.routes[0].name == 'a'
    assert isinstance(Blueprint.routes[0].exception_handlers, list)

# Generated at 2022-06-24 04:08:40.563847
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test if we can create a global exception handler
    # for the blueprint

    future_exception = FutureException(None, [RuntimeError])
    blueprint = ExceptionMixin()
    blueprint._future_exceptions.add(future_exception)

    assert blueprint._future_exceptions == set([future_exception])

# Generated at 2022-06-24 04:08:42.501507
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  em = ExceptionMixin()
  assert em._future_exceptions == set()


# Generated at 2022-06-24 04:08:44.308641
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:08:46.344554
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:08:52.532293
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @TestClass.exception(ValueError)
    def handler():
        pass

    test_class = TestClass()

    assert len(test_class._future_exceptions) == 1
    for item in test_class._future_exceptions:
        assert item.exception is ValueError
        assert item.handler is handler
        assert item.args is None

# Generated at 2022-06-24 04:08:57.036226
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError
    dummy_object = DummyClass()
    assert dummy_object._future_exceptions == set()

# Generated at 2022-06-24 04:09:07.694744
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_class(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def f():
        pass

    test_ExceptionMixin = test_class()
    exceptions = ValueError
    apply = True

    @test_ExceptionMixin.exception(exceptions, apply)
    def handler():
        pass

    assert hasattr(test_ExceptionMixin, '_future_exceptions')
    assert isinstance(test_ExceptionMixin._future_exceptions, set)
    assert test_ExceptionMixin._future_exceptions
    for exception in test_ExceptionMixin._future_exceptions:
        assert isinstance(exception, FutureException)

# Generated at 2022-06-24 04:09:16.723582
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixin:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """

            def decorator(handler):
                nonlocal apply
                nonlocal exceptions


# Generated at 2022-06-24 04:09:27.063066
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # context
    class _ExceptionMixin(ExceptionMixin):
        def __init_(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    exceptionmixin = _ExceptionMixin()
    
    # target
    from functools import partial
    exception = partial(exceptionmixin.exception)

    # test
    @exception(Exception('test'))
    def handler(request, exception):
        print(exception)

    exceptionmixin.exception(Exception('test'), apply=False)(handler)
    exceptionmixin.exception(Exception('test'))(handler)

    print(len(exceptionmixin._future_exceptions))

# Generated at 2022-06-24 04:09:27.646806
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:09:34.094055
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Act
    exception_mixin = ExceptionMixinImpl()

    # Assert
    assert exception_mixin is not None


# Generated at 2022-06-24 04:09:36.875517
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:09:37.527118
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:40.240578
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ExceptionMixin.exception = ExceptionMixin.exception(Exception)
    with pytest.raises(NotImplementedError):
        ExceptionMixin(Exception)

# Generated at 2022-06-24 04:09:49.780618
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # enable the process of creating a global exception
    # handler for the current blueprint under question

    class MyException(Exception):
        pass

    # test1: if isinstance(exception[0], list)
    bp = Blueprint("bp")
    @bp.exception([MyException])  # noqa
    def my_func1(request, exception):
        pass

    assert len(bp._future_exceptions) == 1

    # test2: not isinstance(exception[0], list)
    bp = Blueprint("bp")
    @bp.exception(MyException)  # noqa
    def my_func2(request, exception):
        pass

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:09:53.758825
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def handler(request, error):
        pass

    assert isinstance(ExceptionMixin.exception, object)

# Generated at 2022-06-24 04:09:56.875084
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """This test module is used for test method exception of
    class ExceptionMixin"""
    from sanic.models.exception import ExceptionMixin
    from sanic import Blueprint

    em = ExceptionMixin(Blueprint('test', url_prefix='test'))
    em.exception(apply=False)(print)

# Generated at 2022-06-24 04:10:02.603317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    def foo():
        pass
    app = Sanic('test_ExceptionMixin_exception')
    blueprint = app.blueprint('name')
    blueprint.exception(foo)([])

# Generated at 2022-06-24 04:10:08.344489
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from unittest.mock import patch
    from sanic.views import HTTPMethodView

    class MyHTTPMethodView(HTTPMethodView, ExceptionMixin):
        pass

    with patch.object(MyHTTPMethodView, '_apply_exception_handler'):
        MyHTTPMethodView('args', 'kwargs')


# Generated at 2022-06-24 04:10:11.907087
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # To do: create a mock class extend ExceptionMixin
    # and implement method _apply_exception_handler to
    # verify that method exception of class ExceptionMixin
    # works as expected.
    pass

# Generated at 2022-06-24 04:10:18.872864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_ExceptionMixin = TestExceptionMixin()
    @test_ExceptionMixin.exception(BaseException)
    def callback(exception):
        pass

    assert callback
    assert len(test_ExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-24 04:10:21.851903
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
    exceptionMixinObject = ExceptionMixinClass()
    assert exceptionMixinObject.__init__()


# Generated at 2022-06-24 04:10:25.943794
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return 1

    a = A()
    assert a.exception(Exception)(1) == 1
    assert len(a._future_exceptions) == 1

# Generated at 2022-06-24 04:10:28.037539
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class E(ExceptionMixin):
        pass
    ExceptionMixin()
    E()

# Generated at 2022-06-24 04:10:30.407605
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exMixin = ExceptionMixin()
    assert isinstance(exMixin._future_exceptions, set)


# Generated at 2022-06-24 04:10:35.590739
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ZeroDivisionError)
    def test_exception(request, error):
        return f"{error} was raised"

    assert issubclass(test_exception, ExceptionMixin)
    assert test_exception(1, ZeroDivisionError()) == "division by zero was raised"



# Generated at 2022-06-24 04:10:40.084432
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    _ExceptionMixin = ExceptionMixin()
    # test case 1:
    def f1():
        _ExceptionMixin.exception(Exception)(lambda x: 0)
    assert f1() == None
    # test case 2:
    with pytest.raises(TypeError):
        _ExceptionMixin.exception()



# Generated at 2022-06-24 04:10:43.129160
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()
    assert isinstance(x, ExceptionMixin)
    assert isinstance(x._future_exceptions, set)
    assert x._future_exceptions == set()


# Generated at 2022-06-24 04:10:47.171017
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Application(ExceptionMixin):
        _future_exceptions: Set[FutureException]
        def __init__(self):
            super().__init__()

    app = Application()
    assert isinstance(app, ExceptionMixin)
    assert len(app._future_exceptions) == 0


# Generated at 2022-06-24 04:10:47.676968
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:10:57.800813
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from sanic import Blueprint
    from sanic.response import text

    class TestException(Exception):
        pass

    class ExceptionMixinTests(unittest.TestCase):
        def test_exception_handler(self):
            bp = Blueprint("bp")
            test_app = bp.app
            @bp.route("/")
            def handler(request):
                raise TestException("Test")

            @bp.exception(TestException)
            def handle_exception(request, exception):
                return text("Exception handled")

            request, response = test_app.test_client.get("/")
            self.assertEqual(response.text, "Exception handled")

    unittest.main()

# Generated at 2022-06-24 04:11:04.109543
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')

    @bp.exception(Exception)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == app.error_handler.blueprint_handlers[bp]

# Generated at 2022-06-24 04:11:07.365340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

# Generated at 2022-06-24 04:11:08.743759
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()
    assert exceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:11:16.004385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.response import text

    class ExceptionTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

        def foo(self):
            pass

    ex = ExceptionTest()

    def handler(request, exception):
        return text("hello")

    # we can use ExceptionTest.exception to create a FutureException handler
    # and add it to the set of FutureExceptions of ExceptionTest
    ex.exception([Exception])(handler)

    assert len(ex._future_exceptions) == 1

    future_exception = ex._future_exceptions.pop()

    # this is the FutureException handler created by ExceptionTest.exception,
    # whose

# Generated at 2022-06-24 04:11:20.431786
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    test_ExceptionMixin = TestExceptionMixin()
    
    assert len(test_ExceptionMixin._future_exceptions) == 0


# Generated at 2022-06-24 04:11:23.264446
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:24.618498
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    cls = ExceptionMixin()
    assert isinstance(cls._future_exceptions, set)

# Generated at 2022-06-24 04:11:25.974296
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:11:34.278248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test", url_prefix="/test")

    async def test_exception_handler(request, exception):
        pass

    # Test decorator
    bp.exception(test_exception_handler)

    # Test exceptions
    bp.exception(test_exception_handler, exceptions=[Exception])

    # Test global
    bp.exception(test_exception_handler, apply=False)

    # Test single exception
    bp.exception(Exception)(test_exception_handler)

    # Test multiple exceptions
    bp.exception(Exception, ValueError)(test_exception_handler)

# Generated at 2022-06-24 04:11:39.247298
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic

    # CASE 1: test single exception
    bp = sanic.Blueprint('test_bp')
    @bp.exception(TypeError, apply=True)
    def exc1(request, exception):
        return 0

    # CASE 2: test multiple exceptions
    @bp.exception([TypeError, NameError], apply=True)
    def exc2(request, exception):
        return 0

# Generated at 2022-06-24 04:11:44.435674
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    ExceptionMixinTest()

# Generated at 2022-06-24 04:11:45.769669
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()

    #assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:49.293761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    args = [404]
    kwargs = {'apply': True}
    decorator = ExceptionMixin(args, kwargs).exception(*args, **kwargs)
    def handler():
        print('bla bla')
    assert decorator(handler) == handler

# Generated at 2022-06-24 04:11:54.950760
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        pass

    x = TestClass()
    x.exception(Exception)(lambda: 1)

    expected = {FutureException(lambda: 1, (Exception,))}
    assert x._future_exceptions == expected

# Generated at 2022-06-24 04:12:05.303770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Source: tests/test_exceptions.py
    """
    from sanic import Sanic
    from sanic.exceptions import SanicException

    app = Sanic('test_exception_handler')

    @app.exception(SanicException)
    def handler1(request, exception):
        return text('Exception handler 1')

    @app.exception(SanicException)
    def handler2(request, exception):
        return text('Exception handler 2')

    app.register_listener(handler1, 'before_server_start')

    @app.route('/')
    def handler3(request):
        raise SanicException('omg')

    @app.route('/test')
    async def handler4(request):
        raise NotImplementedError()


# Generated at 2022-06-24 04:12:09.798306
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    test = ExceptionMixin()
    test._future_exceptions == set()


# Generated at 2022-06-24 04:12:11.613844
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert (exception_mixin._future_exceptions == set())



# Generated at 2022-06-24 04:12:18.526453
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test', url_prefix='/test')
    blueprint.ERROR_HANDLER_EXCEPTION_TYPES = (Exception, )
    assert blueprint.ERROR_HANDLER_EXCEPTION_TYPES == (Exception, )

    @blueprint.errorhandler(Exception)
    def errhandler(e):
        return None

    assert errhandler == blueprint.exceptions.pop()

# Generated at 2022-06-24 04:12:22.310623
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints.blueprint import Blueprint
    class DummyBlueprint(Blueprint, ExceptionMixin):
        pass
    bp = DummyBlueprint('DummyBlueprint')
    assert isinstance(bp.__dict__.get('_future_exceptions'), set)

# Generated at 2022-06-24 04:12:33.438432
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Test1, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()
    test1 = Test1()
    # Test method exception with apply = true
    def exception1_handler(request, exception):
        return f"Hi"
    future_exception1 = test1.exception(Exception, apply=True)(exception1_handler)
    assert future_exception1 is exception1_handler
    assert future_exception1(123, Exception()) == "Hi"
    assert future_exception1(123, Exception()) == "Hi"
    # Test method exception with apply = false
    def exception2_handler(request, exception):
        return

# Generated at 2022-06-24 04:12:41.379384
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.response import text

    class TestException(Exception):
        pass

    app = Sanic("test_ExceptionMixin_exception")

    @app.exception(TestException)
    def test(request, exception):
        return text("ok")

    @app.route("/")
    def handler(request):
        raise TestException

    _, response = app.test_client.get("/")
    assert response.text == "ok"

# Generated at 2022-06-24 04:12:49.331889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test if the blueprint is properly registered
    """
    from sanic.app import Sanic

    class SimpleException(Exception):
        """Simple Exception for Unit Testing Purpose"""

    class ExceptionBluePrint(ExceptionMixin):
        """Blueprint For Testing Exception"""

        def __init__(self, *args, **kwargs) -> None:
            self.registered_blueprint = None
            try:
                self.registered_blueprint = kwargs.pop("registered_blueprint")
            except KeyError:
                pass

        def _apply_exception_handler(self, handler: FutureException):
            self.registered_blueprint.exception(handler.handler,
                                                *handler.exceptions)

    app = Sanic("test_ExceptionMixin_exception")


# Generated at 2022-06-24 04:12:54.584077
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    class TestExceptionMixin(Blueprint, ExceptionMixin):
        def __init__(self):
            Blueprint.__init__(self)
            ExceptionMixin.__init__(self)
    test = TestExceptionMixin()
    assert repr(test) == "Blueprint('blueprint')"


# Unit tests for exception method.

# Generated at 2022-06-24 04:13:01.550366
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Obj(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return True

        def execpt_handler(self, *args, **kwargs):
            return True

    obj = Obj()
    @obj.exception(IndexError)
    def except_2(self, *args, **kwargs):
        return True
    except_2(obj, [1, 2, 3], a=1)
    #assert True

# Generated at 2022-06-24 04:13:07.610408
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler):
            pass

    obj = MyClass()
    assert obj._future_exceptions == set()

    def handler(request, exception):
        return response

    decorated_handler = obj.exception(exceptions, apply=True)(handler)
    assert obj._future_exceptions != set()
    assert decorated_handler == handler

# Generated at 2022-06-24 04:13:10.179745
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    Blueprint.name = 'test'
    b = Blueprint()
    assert isinstance(b._future_exceptions, set)
    assert len(b._future_exceptions) == 0


# Generated at 2022-06-24 04:13:16.235311
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create mock object for class Sanic
    mock_sanic_app = mock.Mock()
    mock_sanic_app._future_exceptions = set()
    mock_sanic_app._exception_handler = mock.Mock()

    # Create mock object for class Blueprint
    mock_blueprint = mock.Mock()
    mock_blueprint._apply_exception_handler = mock.Mock()
    mock_blueprint._sanic = mock_sanic_app
    mock_blueprint._future_exceptions = set()

    # Test: exception is callable function
    assert callable(mock_blueprint.exception)

    # Test: exception is decorator
    @mock_blueprint.exception()
    def handler():
        print('Handler')

    assert handler.__name__ == 'handler'

   

# Generated at 2022-06-24 04:13:19.871364
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler):
            pass

    t = TestExceptionMixin()

    assert isinstance(t, ExceptionMixin)
    assert isinstance(t._future_exceptions, set)


# Generated at 2022-06-24 04:13:24.588728
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            ExceptionMixin.__init__(self)

    view = MyView()
    assert view._future_exceptions == set()

# Generated at 2022-06-24 04:13:25.194691
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:13:30.659463
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def func_impl(self):
            pass

        def _apply_exception_handler(self, handler):
            pass

    test_obj = TestExceptionMixin()
    assert isinstance(test_obj, ExceptionMixin)
    assert test_obj._future_exceptions == set()
    assert callable(test_obj.exception)
    assert callable(test_obj.func_impl)


# Generated at 2022-06-24 04:13:31.144308
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:13:37.018563
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def handler(request, exception):
        return
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:13:44.439978
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()
            self.exception_set = []

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_set.append(handler.handler)

    a = A()
    a.exception(ZeroDivisionError)(hand)
    assert a.exception_set[0] == hand
    assert a._future_exceptions.pop() == FutureException(hand, (ZeroDivisionError,))


# Generated at 2022-06-24 04:13:46.716056
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()
    assert x
    return "test_ExceptionMixin Passed"


# Generated at 2022-06-24 04:13:48.260516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    expect = True
    # result = ExceptionMixin.exception()
    # assert result == expect

# Generated at 2022-06-24 04:13:52.951848
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    @Test_ExceptionMixin.exception(index_error)
    def f():
        pass
    
    assert isinstance(Test_ExceptionMixin().exception(index_error), types.FunctionType)

# Generated at 2022-06-24 04:13:57.070686
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # FIXME: this unit test is incomplete, covering only the path in which the
    # decorated method is called
    class A(ExceptionMixin):
        pass
    a = A()
    mock_handler = Mock()
    a.exception(Exception)(mock_handler)
    assert mock_handler in a._future_exceptions

# Generated at 2022-06-24 04:14:00.771146
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints.blueprint import ExceptionMixin

    ex = ExceptionMixin()
    assert ex._future_exceptions == set()

# Unit tests for method _apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-24 04:14:07.023019
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest
    from sanic.app import Sanic

    class CustomExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(CustomExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class MyTest(unittest.TestCase):
        def test(self):
            app = Sanic('test_ExceptionMixin')
            m = CustomExceptionMixin(app)
            self.assertEqual(m._future_exceptions, set())
    unittest.main()


# Generated at 2022-06-24 04:14:17.257143
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler
    from sanic.exceptions import SanicException

    app = Sanic()
    app.error_handler = ErrorHandler()

    # Testing for class Blueprint
    blueprint = Blueprint('blueprint')
    assert blueprint._future_exceptions == set()

    # Testing for class Sanic
    assert app._future_exceptions == set()

    # Testing for class SanicException
    assert SanicException._headers == {}
    assert SanicException._status_code == 500

    # Testing for class ErrorHandler
    assert app.error_handler._future_exceptions == set()

    # Testing_for class FutureException
    def handler(*args, **kwargs):
        pass

# Generated at 2022-06-24 04:14:21.884461
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test1(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    test = test1()
    assert test._future_exceptions == set()

# Generated at 2022-06-24 04:14:29.991767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.views import HTTPMethodView
    app = Sanic('test_ExceptionMixin_exception')

    class SimpleView(HTTPMethodView):
        def get_exception(self, request, *args, **kwargs):
            raise ValueError

    blueprint = Blueprint('test_exception', url_prefix='exception')
    blueprint.add_route(SimpleView.as_view(), '/')

    @app.exception(ValueError)
    def handle_exception(request, exception):
        return text("Oops! Something went wrong.")

    assert len(blueprint.exceptions) == 0
    assert len(app.exceptions) == 1
    
    app.blueprint(blueprint)
    assert len(blueprint.exceptions)

# Generated at 2022-06-24 04:14:34.591827
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.http import HttpRequest, HttpResponse
    from sanic.models.route import Route
    from sanic.models.exceptions import add_exception_handler

    test_bp = Blueprint(__name__)

    @test_bp.exception(Exception)
    def handler(request: HttpRequest, exception: Exception) -> HttpResponse:
        print(request.name)
        print(exception.args)

    add_exception_handler(Exception, handler)

# Generated at 2022-06-24 04:14:39.144313
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    client = ExceptionMixin()
    assert isinstance(client, ExceptionMixin)
    assert isinstance(client._future_exceptions, set)

# Generated at 2022-06-24 04:14:45.688229
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert "hello" in handler.handler
            assert "world" in handler.handler
            assert 10 in handler.handler

    with TestExceptionMixin() as e_mixin:
        @e_mixin.exception(apply=False)
        def handler(reqeust, exception):
            yield "hello"
            yield "world"
            yield 10


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:14:47.151375
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()



# Generated at 2022-06-24 04:14:49.301283
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()
    A()


# Generated at 2022-06-24 04:14:52.006272
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    bp = Blueprint("TEST")
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:14:57.718991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    ex_mixin = _ExceptionMixin()
    ex_mixin.exception([Exception])
    assert len(ex_mixin._future_exceptions) > 0
    assert Exception in ex_mixin._future_exceptions.pop().exceptions


# Generated at 2022-06-24 04:15:01.886137
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ob = ExceptionMixin()

    # test if correct exceptions are passed to the decorator
    assert len(ob._future_exceptions) == 0
    @ob.exception(Exception)
    def ex(request, exception):
        assert isinstance(exception, Exception)

    assert len(ob._future_exceptions) == 1

# Generated at 2022-06-24 04:15:07.365973
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class myBlueprint(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException) -> None:
            pass

    bp = myBlueprint()

    @bp.exception([TypeError])
    def test_handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:15:11.500817
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    test_exception_mixin =  TestExceptionMixin()
    assert type(test_exception_mixin._future_exceptions) is set


# Generated at 2022-06-24 04:15:13.073767
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:15:13.648847
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:15:17.806859
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:15:25.946320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class UnitTestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exceptions = []

        def _apply_exception_handler(self, handler):
            self.exceptions.append(handler)

    unit_test_resp = UnitTestClass()
    unit_test_resp.exception(IndexError, KeyError, apply=False)

    assert len(unit_test_resp._future_exceptions) == 1
    assert len(unit_test_resp.exceptions) == 0

# Generated at 2022-06-24 04:15:32.800645
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return None

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:15:37.346248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    value = 1

    @ExceptionMixin.exception(apply=False)
    def handler():
        nonlocal value
        value = 0

    assert value == 1
    handler()
    assert value == 0



# Generated at 2022-06-24 04:15:43.747073
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.router import Router
    from sanic.app import Sanic
    from sanic.blueprint import Blueprint
    blueprint = Blueprint.create()
    router = Router()
    blueprint.router = router
    app = Sanic()
    blueprint.register(None, None, None)
    app.blueprints = set()
    app.blueprints.add(blueprint)
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:15:44.291215
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:15:47.210639
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert isinstance(ex, ExceptionMixin)
    assert isinstance(ex._future_exceptions, Set)
    assert ex._future_exceptions == set()


# Generated at 2022-06-24 04:15:55.178960
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self, *args, **kwargs):
            pass
        def method(*args):
            pass
    class B(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self.func = [None]
            self._future_exceptions: Set[FutureException] = set()
            ExceptionMixin.__init__(self, *args, **kwargs)

        def method(*args):
            pass

        def _apply_exception_handler(self, handler):
            self.func[0] = handler

    b = B()
    b.exception([RuntimeError], apply=True)(A.method)
    assert len(b._future_exceptions) == 1
