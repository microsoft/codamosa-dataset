

# Generated at 2022-06-24 04:05:56.203265
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()



# Generated at 2022-06-24 04:05:58.627019
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test', url_prefix='test_bp')
    blueprint.exception(Exception)(print)
    assert blueprint._future_exceptions

# Generated at 2022-06-24 04:06:08.345226
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic, Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint("test_bp")

    # Creates the blueprint and app instance
    @bp.exception(NotFound)
    def handler_404(request, exception):
        return response.text("Yeah, not found", status=exception.status_code)

    app = Sanic("exception_test_app")
    app.blueprint(bp, url_prefix="/app")

    # Adds a view on the app
    @app.route("/")
    def handler_root(request):
        return response.text("Yeah")

    # Adds a view on the app
    @app.route("/route")
    def handler_route(request):
        return response.text("Yeah, route")

    # Adds a view on the blueprint

# Generated at 2022-06-24 04:06:10.352934
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    exception_mixin = ExceptionMixin()

    # Assert
    assert exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:06:12.546603
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # type: () -> None
    from sanic.blueprints import Blueprint

    blueprint_test = Blueprint(name='test-exception', url_prefix='/test')
    assert blueprint_test._future_exceptions == set()

# Generated at 2022-06-24 04:06:16.401516
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    blueprint = Blueprint('test_blueprint')
    assert isinstance(blueprint, ExceptionMixin)
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:06:19.176075
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint(__name__)
    blueprint.exception(1)

# Generated at 2022-06-24 04:06:21.060625
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    __exception_mixin = ExceptionMixin()
    assert __exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:06:24.541462
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_class(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    instance = test_class()
    assert(instance._future_exceptions == set())


# Generated at 2022-06-24 04:06:29.462809
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ParentClass:
        def __init__(self, *args, **kwargs) -> None:
            pass

    def _apply_exception_handler(self, handler: FutureException):
        pass

    parent_class = ParentClass()
    exception_mixin = ExceptionMixin()
    exception_mixin._apply_exception_handler = MethodType(_apply_exception_handler, exception_mixin)
    exception_mixin.__init__(parent_class)

    assert(exception_mixin._future_exceptions == set())

# Generated at 2022-06-24 04:06:31.994597
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:06:33.054526
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:06:33.672241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:06:44.369284
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

        def my_exception_handler(self, request, e):
            pass

    my_exception_mixin = MyExceptionMixin()
    assert len(my_exception_mixin._future_exceptions) == 0

    my_exception_mixin.exception('Exception')(my_exception_mixin.my_exception_handler)
    assert len(my_exception_mixin._future_exceptions) == 1
    assert my_exception_mixin.handler.handler == my_exception_mixin.my_exception_handler

# Generated at 2022-06-24 04:06:53.104612
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyObject(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)
            self.a = 1

        def _apply_exception_handler(self, handler: FutureException):
            return

    dummy_instance: DummyObject = DummyObject()
    assert len(dummy_instance._future_exceptions) == 0
    dummy_instance.exception(ZeroDivisionError)(lambda x: print(x))
    assert len(dummy_instance._future_exceptions) == 1
    assert dummy_instance._future_exceptions.pop().handler(ZeroDivisionError) == dummy_instance.a

    dummy_instance2: DummyObject = DummyObject()

# Generated at 2022-06-24 04:06:57.073505
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert isinstance(bp._future_exceptions, set)


# Generated at 2022-06-24 04:07:02.471555
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class testExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test = testExceptionMixin()
    assert type(test._future_exceptions) == set



# Generated at 2022-06-24 04:07:04.389313
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin == exception_mixin


# Generated at 2022-06-24 04:07:07.575404
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    a = A()

    @a.exception(Exception)
    def handle(e):
        pass

    assert len(a._future_exceptions) == 1

# Generated at 2022-06-24 04:07:13.395680
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixing:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    def decorator(handler):
        nonlocal exceptions

        future_exception = FutureException(handler, exceptions)
        self._future_exceptions.add(future_exception)
        return handler

    test_exception_mixin = TestExceptionMixing()
    test_exception_mixin.exception(Exception)(decorator)

# Generated at 2022-06-24 04:07:17.180809
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class EX(ExceptionMixin):
        pass
    with pytest.raises(NotImplementedError):
        EX()._apply_exception_handler(None)


# Generated at 2022-06-24 04:07:23.844537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    my_object = TestExceptionMixin()

    @my_object.exception(Exception)
    def my_handler(*args, **kwargs):
        pass

    assert my_handler in my_object._future_exceptions

# Generated at 2022-06-24 04:07:27.464411
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:07:36.327536
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Fake_ExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(Fake_ExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    fake_mixin = Fake_ExceptionMixin()

    exceptions = (ValueError, TypeError)
    handler = lambda x: x

    assert len(fake_mixin._future_exceptions) == 0
    fake_mixin.exception(exceptions)(handler)
    assert len(fake_mixin._future_exceptions) == 1
    exception_handler = fake_mixin._future_exceptions.pop()
    assert exception_handler.callback == handler
    assert exception_handler.exceptions == exceptions

if __name__ == '__main__':
    import pytest
    pytest

# Generated at 2022-06-24 04:07:37.636598
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:07:40.285500
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test = TestExceptionMixin()
    assert not test._future_exceptions

# Generated at 2022-06-24 04:07:46.187081
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    class MyBlueprint(ExceptionMixin, Blueprint):
        pass

    bp = MyBlueprint('test', url_prefix='/test/')
    assert bp.url_prefix == '/test/'
    assert bp._future_exceptions == set()


# Unit test done for method exception of class ExceptionMixin

# Generated at 2022-06-24 04:07:47.527893
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert not obj._future_exceptions

# Generated at 2022-06-24 04:07:49.883804
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class Mixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mix = Mixin()
    assert mix._future_exceptions == set()


# Generated at 2022-06-24 04:07:53.061888
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    assert TestException()._future_exceptions == set()

# Utilities for testing exception()


# Generated at 2022-06-24 04:07:57.202111
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class B(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            self._apply_exception_handler = lambda handler: "a"
    b = B()
    assert b.exception(list, use_range_force=123) == b.exception.__wrapped__


# Generated at 2022-06-24 04:08:00.746866
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Empty dictionary created to call class's constructor
    d = {}
    try:
        b = ExceptionMixin(d)
        assert True
    except:
        assert False


# Generated at 2022-06-24 04:08:08.201869
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
        #def _apply_exception_handler(self, handler: FutureException):
        #    raise NotImplementedError  # noqa
            
    myemo = MyExceptionMixin()
    @myemo.exception(Exception, apply=False)
    def handler():
        pass
    assert isinstance(handler, types.FunctionType)
    assert len(myemo._future_exceptions) == 1
    exception_lst = []
    for he in myemo._future_exceptions:
        exception_lst.append(he._exceptions)
    assert exception_lst[0] == (Exception,)

# Generated at 2022-06-24 04:08:18.757556
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    class TestException(Exception):
        pass

    @TestClass.exception(TestException)
    def exception_handler1(request: Request, exception: Exception):
        pass

    @TestClass.exception([TestException])
    def exception_handler2(request: Request, exception: TestException):
        pass

    @TestClass.exception(TestException)
    def exception_handler3(request: Request, exception: TestException,
                           kwarg1, kwarg2, kwarg3):
        pass

    assert 1 == len(TestClass._future_exceptions)
    assert exception_handler1 in TestClass._future_exceptions
    assert exception_handler2 not in TestClass._future_ex

# Generated at 2022-06-24 04:08:21.356565
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a.__class__.__name__ == ExceptionMixin.__name__
    assert a._future_exceptions == set()

# Generated at 2022-06-24 04:08:22.671876
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bd = ExceptionMixin()
    assert bd._future_exceptions == set()

# Generated at 2022-06-24 04:08:24.447841
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:27.844308
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('blueprint')
    blueprint._future_exceptions = blueprint._future_exceptions

    assert blueprint.__class__.__name__ == 'Blueprint'
    assert blueprint._future_exceptions is not None

# Generated at 2022-06-24 04:08:30.412003
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """Test if ExceptionMixin can be created
    """
    exception_m = ExceptionMixin()
    assert isinstance(exception_m, ExceptionMixin)


# Generated at 2022-06-24 04:08:36.284487
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    future_assertion = ExceptionMixin()
    # check if the hash set is initialized
    if future_assertion._future_exceptions:
        assert True
    elif future_assertion._future_exceptions == set():
        assert True
    else:
        assert False


# Generated at 2022-06-24 04:08:39.335130
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorator(handler):
        return handler

    test_instance = ExceptionMixin()
    test_result = test_instance.exception(Exception)(decorator)
    assert decorator == test_result

# Generated at 2022-06-24 04:08:44.796708
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_exception(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = test_exception()
    assert len(test._future_exceptions) == 0

# Generated at 2022-06-24 04:08:49.213461
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest
    class TestExceptionMixin(unittest.TestCase):
        def test_init(self):
            from sanic.blueprints import Blueprint
            bp = Blueprint('test')
            self.assertIsInstance(bp._future_exceptions, set)

    unittest.main()

# Generated at 2022-06-24 04:08:54.638674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinSubclass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)
    ExceptionMixinSubclass().exception(Exception, ZeroDivisionError)(lambda x: x)
    assert len(ExceptionMixinSubclass()._future_exceptions) == 1

# Generated at 2022-06-24 04:08:57.392339
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return

    mixin = TestExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-24 04:08:58.446825
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


# Generated at 2022-06-24 04:09:04.209253
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
        
        def _apply_exception_handler(self, handler:FutureException):
            pass
    fakeExMixin = FakeExceptionMixin()
    @fakeExMixin.exception()
    def exception(request, exception):
        pass
    assert fakeExMixin._future_exceptions

# Generated at 2022-06-24 04:09:05.570985
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert isinstance(a._future_exceptions, set)

# Generated at 2022-06-24 04:09:10.827490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_handler(exception):
        pass

    my_exception_mixin = ExceptionMixin()
    my_exception_mixin.exception(test_handler)
    assert len(my_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:09:12.701877
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Check if method returns decorator
    from sanic import Blueprint
    from unittest.mock import MagicMock
    bp = Blueprint('bp')
    @bp.exception(*[])
    def test():
        pass
    assert test.__name__ == 'test'
    assert isinstance(bp._future_exceptions[0], FutureException)


# Generated at 2022-06-24 04:09:16.107948
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def test_method(req, resp, exc):
        return resp

    assert len(ExceptionMixin._future_exceptions) == 0
    test_method()
    assert len(ExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-24 04:09:18.926500
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:09:21.441419
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print('Unit test for constructor of class ExceptionMixin')
    e = ExceptionMixin()
    print('Passed!')
    print('---------------------------')
    return


# Generated at 2022-06-24 04:09:29.977304
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprints
    import unittest

    # Create a testclass that inherits from ExceptionMixin
    class TestClass(ExceptionMixin, Blueprints):
        def __init__(self):
            super().__init__(__name__)
            self.exceptions = []

        def _apply_exception_handler(self, handler):
            self.exceptions.append(handler)

        def add_route(self, uri, view_func, *args, **kwargs):
            pass

    def view_func(request, url_var):
        pass

    instance = TestClass()
    instance.blueprint(url_prefix="/test_path")(TestClass.exception(ValueError, apply=False)(view_func))


# Generated at 2022-06-24 04:09:37.902267
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test_bp')
    @bp.exception(ZeroDivisionError)
    def handler(request, exception):
        return request
    @bp.route('/')
    def index(request):
        return 1/0
    assert bp.handlers[0].exceptions[0] == ZeroDivisionError
    assert len(bp.handlers[0].exceptions) == 1
    assert bp.exception == ExceptionMixin.exception

# Generated at 2022-06-24 04:09:39.799461
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_mixin = ExceptionMixin()
    assert(isinstance(test_mixin,ExceptionMixin))

# Generated at 2022-06-24 04:09:45.574962
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic.blueprints

    class my_blueprints(ExceptionMixin, sanic.blueprints.Blueprint):
        pass

    # create a blueprint
    my_blueprint = my_blueprints("test_ExceptionMixin_exception")

    # define a exception handler
    @my_blueprint.exception(Exception)
    def default_exception_handler(request, exception):
        return text("internal server error", 500)

    assert len(my_blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:09:48.371478
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    def test_function(a):
        return a
    app = Sanic()
    app.exception(ValueError)(test_function)

# Generated at 2022-06-24 04:09:51.642145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-24 04:09:54.025108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    bp = sanic.Blueprint('test_bp')
    bp.exception(Exception)
    assert bp._future_exceptions
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-24 04:09:57.788649
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_blueprint')

    @blueprint.exception()
    def handler_exception(request, exception):
        pass

    blueprint._apply_exception_handler = lambda x: x  # noqa
    blueprint.exception()(handler_exception)
    assert len(blueprint._future_exceptions) == 2

# Generated at 2022-06-24 04:09:59.999025
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('test_bp')
    bp.exception(SanicException)(lambda x: True)

    assert bp._future_exceptions

# Generated at 2022-06-24 04:10:01.285327
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert isinstance(exception, ExceptionMixin)

# Generated at 2022-06-24 04:10:03.023362
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:10:13.279458
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # mock class ExceptionMixin
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(MockExceptionMixin, self).__init__(*args, **kwargs)
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler):
            return
        def clean_exception_handlers(self):
            return

    # create object MockExceptionMixin
    mock_exception_mixin = MockExceptionMixin()

    # test exception method of class MockExceptionMixin
    @mock_exception_mixin.exception(TypeError)
    def bad_function():
        return
    exception = mock_exception_mixin._future_exceptions.pop()
    exception_handler = exception.handler
    exception_args

# Generated at 2022-06-24 04:10:16.160480
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:10:20.815638
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Class that inherit ExceptionMixin
    class Test(ExceptionMixin):
        pass
    # Instance of class Test
    test = Test()

    # Check object attributes
    # _future_exceptions
    assert isinstance(test._future_exceptions, set)


# Generated at 2022-06-24 04:10:23.765920
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    This test is for testing the constructor of the class ExceptionMixin
    """

    # Arrange (nothing to do)
    # Act
    exceptionMixin = ExceptionMixin()
    # Assert (nothing to do)
    assert exceptionMixin != None



# Generated at 2022-06-24 04:10:24.761853
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin() is not None

# Generated at 2022-06-24 04:10:28.091956
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass

    a = A()
    assert type(a._future_exceptions) is set

# Generated at 2022-06-24 04:10:33.544500
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            # Handler should be the method created in decorator
            assert callable(handler)
            # Handler should contain the list of exceptions
            assert len(handler._exceptions) == 1
            assert handler._exceptions[0] is Exception

    blueprint = MockBlueprint()
    blueprint.exception(Exception)

# Generated at 2022-06-24 04:10:40.326641
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin(): # noqa
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage
    from sanic.response import text

    bp = Blueprint('test_bp')
    @bp.exception(Exception)
    def handle_exception(request, exception):
        return text('internal error', 500)

    @bp.get('/1')
    def handler1(request):
        raise InvalidUsage('invalid usage')

    @bp.get('/2')
    def handler2(request):
        raise Exception



# Generated at 2022-06-24 04:10:41.924430
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:10:45.706388
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)
    assert bp.__class__.__bases__[0].__name__ == "ExceptionMixin"
    #assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:10:47.701509
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    excnew = ExceptionMixin()
    assert excnew._future_exceptions == set()

#Unit test for _apply_exception_handler

# Generated at 2022-06-24 04:10:52.742838
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass

    assert ExceptionMixinTest.__init__.__doc__ == 'Initialize self.  See help(type(self)) for accurate signature.'


# Generated at 2022-06-24 04:10:54.696780
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    object = ExceptionMixin()
    assert len(object._future_exceptions) == 0
    assert type(object._future_exceptions) is set

# Generated at 2022-06-24 04:10:57.052961
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
    except Exception as e:
        print("Exception occurs because of " + str(e))
    else:
        print("No exception occurs")


# Generated at 2022-06-24 04:10:58.302209
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:11:00.716412
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def f():
        return 1

    epm = ExceptionMixin()
    assert f == epm.exception(1)(f)

# Generated at 2022-06-24 04:11:04.782092
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from sanic_openapi import doc
    blueprint = Blueprint("exception_mixin_test")

    assert blueprint.__class__ ==  ExceptionMixin.__bases__[0]

    assert blueprint._future_exceptions != None
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:11:07.684942
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:11:10.118216
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class obj(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    obj()
    obj()._future_exceptions


# Generated at 2022-06-24 04:11:12.294634
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:11:18.424740
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    app = Sanic('test_exception')
    bp = Blueprint("test_bluerpint_exception")

    @bp.exception(Exception)
    def handler(self, request, exception):
        assert request == 1
        assert exception == 2

    @app.blueprint(bp)
    def setup_bp(app):
        from sanic.response import text
        pass

    client = app.test_client
    _, response = client.get('/test_bluerpint_exception')
    assert response.status == 500

# Generated at 2022-06-24 04:11:25.002999
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        
        def __init__(self):
            super(Test, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            handler.handler()

    @Test().exception(BaseException)
    def inner_function():
        print("I am here")

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:11:34.677576
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    def a_handler():pass
    def b_handler():pass
    def c_handler():pass

    em = MyExceptionMixin()

    em.exception(Exception)(a_handler)
    em.exception([Exception, KeyError])(b_handler)
    em.exception(KeyError, apply=False)(c_handler)

    future_exceptions = em._future_exceptions

    assert future_exceptions == {
        FutureException(a_handler, (Exception, )),
        FutureException(b_handler, (Exception, KeyError)),
        FutureException(c_handler, (KeyError, )),
    }

# Generated at 2022-06-24 04:11:43.322072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    import sanic.exceptions

    class TestException(Exception):
        def __init__(self, message='') -> None:
            self.message = message
    
    blueprint = Blueprint('error', url_prefix='/error')

    blueprint.exception(sanic.exceptions.ServerError,
                         sanic.exceptions.NotFound,
                         apply=True)(lambda request, exception:
                            response.text('Error: {}'.format(exception),
                                          status=500))

    blueprint.exception(TestException,
                        apply=True)(lambda request, exception:
                            response.text('Error: {}'.format(exception.message),
                                          status=500))

    app = Sanic('error')
    app.blueprint(blueprint)


# Generated at 2022-06-24 04:11:47.966821
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class testExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(testExceptionMixin, self).__init__(*args, **kwargs)

  

# Generated at 2022-06-24 04:11:51.910377
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test:
        def __init__(self, *args, **kwargs):
            assert(isinstance(args,tuple))
            assert(isinstance(kwargs,dict))
    em=Test(1,2,3,4,5,hello="world")
    return em


# Generated at 2022-06-24 04:11:52.734754
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(), ExceptionMixin)

# Generated at 2022-06-24 04:11:57.264691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic import Sanic
    my_app = Sanic(__name__)
    my_app.blueprint(exception_mixin_bp)
    @my_app.route("/")
    async def handler(request):
        return response.json({"hello": "world"})
    run_simple(my_app,debug=True)

# Generated at 2022-06-24 04:12:00.987635
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Base:
        pass

    class Derive(ExceptionMixin):
        pass

    assert Derive._apply_exception_handler.__code__ == ExceptionMixin._apply_exception_handler.__code__

# Generated at 2022-06-24 04:12:02.317161
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:12:07.229870
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class new_class(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    new_obj = new_class()
    @new_obj.exception("test")
    def test(request):
        return "test"
    assert isinstance(test, types.FunctionType)

# Generated at 2022-06-24 04:12:12.958363
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_obj = TestExceptionMixin()
    assert len(exception_mixin_obj._future_exceptions) == 0

    @exception_mixin_obj.exception()
    def test_func(request):
        pass

    assert len(exception_mixin_obj._future_exceptions) == 1
    assert isinstance(exception_mixin_obj._future_exceptions.pop(),
                      FutureException)

# Generated at 2022-06-24 04:12:21.336282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    from sanic.exceptions import SanicException

    app = Sanic(__name__)

    class FakeExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

    exception_mixin_obj = FakeExceptionMixin()

    @exception_mixin_obj.exception(SanicException)
    async def fake_exception_handler(request, exception):
        return True

    assert len(exception_mixin_obj._future_exceptions) == 1

# Generated at 2022-06-24 04:12:26.856934
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Expects the decorated handler to be a parameter in return of
    method exception of class ExceptionMixin
    """

    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    obj = TestClass()
    @obj.exception()
    def handler(err):
        return "handler"

    assert(handler == handler)

# Generated at 2022-06-24 04:12:28.844348
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exctest = ExceptionMixin()
    assert exctest._future_exceptions is not None


# Generated at 2022-06-24 04:12:34.252387
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint('Test')
    bp._future_exceptions = set()
    try:
        bp._future_exceptions.add(FutureException())
    except TypeError as e:
        assert 'is not a FutureException' in str(e)
    else:
        raise AssertionError

# Generated at 2022-06-24 04:12:36.139688
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(1, 2, 3)._future_exceptions, set)


# Generated at 2022-06-24 04:12:39.341448
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        # Test for the initialization of the object
        obj = ExceptionMixin()
        assert obj
    except Exception:
        assert False


# Generated at 2022-06-24 04:12:42.359185
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    bp = Blueprint("test_blueprint_exception_mixin")
    print("Test case for ExceptionMixin")
    bp.exception(Exception)
    print("Done")


# Generated at 2022-06-24 04:12:45.655601
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    a = A()
    assert a._future_exceptions == set()


# Unit tests for function exception of class ExceptionMixin

# Generated at 2022-06-24 04:12:48.217206
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SanicBlueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            pass

    obj = SanicBlueprint()



# Generated at 2022-06-24 04:12:49.776031
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    b = ExceptionMixin()
    assert b._future_exceptions == set()

# Generated at 2022-06-24 04:12:57.725258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyTest(ExceptionMixin):
        def __init__(self):
            self.future_exceptions = []

        def _apply_exception_handler(self, handler: FutureException):
            self.future_exceptions.append(handler)

    @MyTest().exception()
    def foo():
        return "bar"

    assert foo() == "bar"

    @MyTest().exception([KeyError])
    def foo():
        raise KeyError()

    try:
        foo()
        assert False
    except KeyError:
        assert True

# test  parameter apply

# Generated at 2022-06-24 04:13:04.222991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            try:
                raise ValueError('test')
            except ValueError:
                handler.handle(local.request, local.response)
    test_exceptionmixin = TestExceptionMixin()
    count = 0
    @test_exceptionmixin.exception(ValueError)
    def handler(request, exception):
        nonlocal count
        count += 1
        assert request
        assert exception
    assert count == 1

# Generated at 2022-06-24 04:13:11.451549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    testExceptionMixin = TestExceptionMixin()
    @testExceptionMixin.exception(IndexError)
    def index_handler():
        return 'index'
    assert testExceptionMixin._future_exceptions.pop().handler() == 'index'

# Generated at 2022-06-24 04:13:16.547915
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic()
    @app.route("/")
    @app.exception(Exception, apply=True)
    def handler(request, exc):
        return json({"error": str(exc)})
    request, response = app.test_client.get("/")
    assert response.json.get("error") == "exception"

# Generated at 2022-06-24 04:13:19.064532
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyExceptionMixin(ExceptionMixin):
        pass
    dummy = DummyExceptionMixin()
    assert isinstance(dummy, DummyExceptionMixin)


# Generated at 2022-06-24 04:13:22.494483
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    '''
    Test if the constructor for ExceptionMixin is operational
    '''
    from sanic.app import Sanic
    app = Sanic('test_ExceptionMixin')
    assert isinstance(app, ExceptionMixin)


# Generated at 2022-06-24 04:13:29.152997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    class TestApp(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.app = Blueprint(*args, **kwargs)
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    x = TestApp('bpprint')

    def handler(*args, **kwargs):
        pass
    x.exception(ZeroDivisionError)(handler)

# Generated at 2022-06-24 04:13:35.267673
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint, SanicException
    class MyBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = MyBlueprint()
    @bp.exception(SanicException)
    def handler(request, exception):
        return request, exception

    assert len(bp._future_exceptions) == 1

    future_exception = next(iter(bp._future_exceptions))
    assert future_exception.handler == handler
    assert future_exception.exceptions == (SanicException, )

# Generated at 2022-06-24 04:13:45.394669
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    import unittest
    from sanic import Blueprint, exceptions

    app = sanic.Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_ExceptionMixin_exception")

    # Test for ExceptionMixin
    class TestExceptionMixin_exception(unittest.TestCase):
        def test_exception(self):
            nonlocal app
            nonlocal bp
            nonlocal exceptions

            # Test for ExceptionMixin.exception()
            @bp.exception(exceptions.InvalidUsage)
            def test_exception_ExceptionMixin_exception(
                request, exception, args, kwargs
            ):
                return "invalid usage"


# Generated at 2022-06-24 04:13:52.901666
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test that exception raises a NotImplementedError:
    try:
        mixin = ExceptionMixin()
        mixin.exception()
        print("ExceptionMixin_exception test: FAILED\n")
        return
    except NotImplementedError as error:
        print("ExceptionMixin_exception test: PASSED")
        print("Exception type:", type(error), "\n")
    except Exception as exception:
        print("ExceptionMixin_exception test \
            has raised an unespected exception:", exception, "\n")
        return


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:13:55.799199
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    instance = Blueprint(name="name", url_prefix="/")
    assert isinstance(instance._future_exceptions, set)

# Generated at 2022-06-24 04:14:04.907625
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic import response
    import pytest
    from threading import Event
    pytest.mark.parametrize('apply', [True, False])
    @Blueprint.exception(RuntimeError, apply=apply)
    def handler(request, exception):
        return response.text('Internal Server Error')
    @Blueprint.route('/normal')
    def handler(request):
        return response.text('OK')
    @Blueprint.route('/runtime_error')
    def handler(request):
        raise RuntimeError('runtime')
    app = Sanic('test_ExceptionMixin_exception')
    Blueprint.register(app, url_prefix='/bp')
    app.blueprint(Blueprint)
    request, response = app.test_

# Generated at 2022-06-24 04:14:13.850668
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  em = ExceptionMixin()
  def exc_hand(handler):
    return handler
  em.exception(exc_hand)
  assert len(em._future_exceptions) == 1
  em._future_exceptions.clear()

  em.exception([exc_hand])
  assert len(em._future_exceptions) == 1
  em._future_exceptions.clear()

  em.exception([])
  assert len(em._future_exceptions) == 0
  em._future_exceptions.clear()

  em.exception()
  assert len(em._future_exceptions) == 0
  em._future_exceptions.clear()


# Generated at 2022-06-24 04:14:16.001321
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    blueprint = Blueprint("example")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:14:24.166851
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from typing import Iterator
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.exceptions import NotFound

    bp = Blueprint()

    @bp.exception([NotFound])
    def error_handler(request, exception):
        return response.text(exception.__class__.__name__, status=exception.status_code)

    @bp.route("/")
    async def test(request):
        return response.text("OK")

    bp.register(bp, url_prefix="/")

    request, response = bp.create_request_response()
    assert request.url == "/"
    response = bp.handle_request(request)
    assert response.text == "OK"

    request, response = bp.create_request

# Generated at 2022-06-24 04:14:32.141139
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockFuture:
        def __init__(self):    
            self._future_exceptions: Set[Exception] = set()

        def _apply_exception_handler(self, handler: Exception):
            raise NotImplementedError 

    mock_future = MockFuture()
    assert len(mock_future._future_exceptions) == 0
    def test_handler():
        pass
   
    mock_future.exception()(test_handler)

# Generated at 2022-06-24 04:14:37.185024
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    from sanic.app import Sanic
    from sanic.handlers import ErrorHandler
    try:
        @Test.exception(Exception)
        def handler(self, exception):
            pass
    except:
        pass
    app = Sanic()
    app.error_handler = ErrorHandler(app)
    app.blueprint(Test())

# Generated at 2022-06-24 04:14:44.517807
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    test_mixin = TestExceptionMixin()
    assert isinstance(test_mixin, ExceptionMixin)


# Generated at 2022-06-24 04:14:47.575203
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException) -> None:
            print(handler)

    FakeMixin().exception(list(()), apply=True)(print)

# Generated at 2022-06-24 04:14:51.901593
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mock_exception_mixin = MockExceptionMixin()

    assert mock_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:59.196967
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprints import SanicBlueprint

    class Foo: pass
    foo = Foo()

    SanicBlueprint.exception = ExceptionMixin.exception
    bp = SanicBlueprint('test', 'test', url_prefix='test')

    def handler(*args): pass

    bp.exception(ValueError, Foo)(handler)
    assert len(bp._future_exceptions) == 1
    assert type(bp._future_exceptions.pop()) == FutureException

# Generated at 2022-06-24 04:15:01.410580
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert isinstance(obj, ExceptionMixin)
    assert isinstance(obj._future_exceptions, set)

# Generated at 2022-06-24 04:15:03.161234
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert isinstance(mixin._future_exceptions, set)


# Generated at 2022-06-24 04:15:05.249147
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:15:09.618447
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.exceptions import SanicException

    blueprint = Blueprint('b')

    @blueprint.exception(SanicException)
    def test_handler(request, exception):
        return "Exception is handled"

    assert blueprint._future_exceptions == {
        FutureException(test_handler, (SanicException,))
    }

# Generated at 2022-06-24 04:15:15.288239
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin


# Generated at 2022-06-24 04:15:20.511480
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Orm(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Orm, self).__init__(*args, **kwargs)

    o = Orm()
    o.exception(AttributeError)
    o._apply_exception_handler(AttributeError)
    assert(o._future_exceptions == {AttributeError})

# Generated at 2022-06-24 04:15:27.575681
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    from sanic.models.route import Route
    from unittest import TestCase

    class testing(TestCase):
        def __init__(self):
            super(testing, self).__init__()
            self.test = ExceptionMixin()

        def test_constructor(self):
            self.assertIsInstance(self.test._future_exceptions, set)
            self.assertEqual(self.test._future_exceptions, set())

    test = testing()
    test.test_constructor()

# Unit tests for  applying exception handler

# Generated at 2022-06-24 04:15:31.503095
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('name', url_prefix='/blueprint')
    bp.exception(Exception, apply=True)(lambda x: x)
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:15:34.760132
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    blueprint = Blueprint("test_ExceptionMixin")
    assert blueprint._future_exceptions == set()
    assert blueprint.exception(ValueError)

# Generated at 2022-06-24 04:15:41.994581
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create blueprint and add exception handler
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return handler

    blueprint = Blueprint()
    blueprint.exception(Exception)(lambda req, exc: None)

    # assert
    assert blueprint._future_exceptions.pop().handler(None, None) is None



# Generated at 2022-06-24 04:15:44.848216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

    ExceptionMixin_Test()

# Generated at 2022-06-24 04:15:47.120196
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test(ExceptionMixin):
        pass

    test()
    AssertionError
    TypeError
    # test.exception()

# Generated at 2022-06-24 04:15:55.620845
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestException(Exception):
        pass

    class SanicException:
        def __init__(self):
            self.app = None

    class BlueprintException(ExceptionMixin, SanicException):
        def _apply_exception_handler(self, handler):
            self.app = handler

        def add(self, blueprint):
            self.app = blueprint

        def route(self, url):
            def decorator(handler):
                def wrapper(*args, **kwargs):
                    # print("wrapper: ", handler(*args, **kwargs))
                    return handler(*args, **kwargs)
                return wrapper
            return decorator

    blueprint_exception = BlueprintException()

    @blueprint_exception.exception(TestException)
    def handler_exception(request, exception):
        return "hello"
