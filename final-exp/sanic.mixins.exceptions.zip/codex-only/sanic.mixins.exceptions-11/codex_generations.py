

# Generated at 2022-06-24 04:06:05.388344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    class Test(ExceptionMixin):
        def __init__(self):
            super().__init__()
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.args == exceptions
            assert handler.handler(test_msg) == test_msg
    test_msg = "This is a test exception."
    test_args = [test_msg]
    test_handler = lambda *args, **kwargs: args[0]
    test_exceptions = [test_msg]
    test_instance = Test()
    test_instance.exception(test_exceptions)(test_handler)(*test_args)

# Generated at 2022-06-24 04:06:13.367015
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_obj = ExceptionMixin()
    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        test_obj._future_exceptions.add(future_exception)
        if apply:
            test_obj._apply_exception_handler(future_exception)
        return handler

    def handler():
        pass

    test_obj.exception(handler)
    # TODO: assert values

# Generated at 2022-06-24 04:06:15.011759
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:06:18.712960
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    bp = Blueprint('', 'bp')

    bp._future_exceptions = None
    bp.__init__()

    assert bp._future_exceptions == set()



# Generated at 2022-06-24 04:06:23.781522
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    x = Sanic("test_app")
    x.add_task(1)
    x.add_task(2)
    x.add_task(3)
    assert x._task_registry.__len__() == 3
    x.clear_task_registry()
    assert x._task_registry.__len__() == 0

# Generated at 2022-06-24 04:06:30.010685
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.futures import FutureExceptionHandler

    class TestException(Exception):
        pass

    class TestBlueprint(Blueprint):
        pass

    TestBlueprint.exception(TestException)

    assert TestBlueprint.exception == ExceptionMixin.exception

    test_blueprint = TestBlueprint()

    assert isinstance(test_blueprint, ExceptionMixin)
    assert isinstance(test_blueprint, Blueprint)

    assert len(test_blueprint._future_exceptions) == 0

    @test_blueprint.exception(TestException)
    def handler(*args, **kwargs):
        pass

    assert len(test_blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:06:34.601157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(name="test_exception")
    future_exception = FutureException(lambda: None, [RuntimeError])
    bp._future_exceptions = {future_exception}

    def exception_handler():
        print()
    bp.exception(RuntimeError)(exception_handler)
    assert bp._future_exceptions == {future_exception, FutureException(exception_handler, [RuntimeError])}

# Generated at 2022-06-24 04:06:40.963524
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import sanic
    app = sanic.Sanic('test')
    blueprint = sanic.Blueprint('test2')
    blueprint2 = sanic.Blueprint('test3')
    app.blueprint(blueprint)
    app.blueprint(blueprint2)
    assert blueprint._future_exceptions == set()
    assert blueprint2._future_exceptions == set()



# Generated at 2022-06-24 04:06:43.304168
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    a = Test()
    assert isinstance(a._future_exceptions, set)

# Generated at 2022-06-24 04:06:48.194537
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    test_mixin = TestExceptionMixin()
    assert test_mixin
    assert len(test_mixin._future_exceptions) == 0


# Generated at 2022-06-24 04:06:52.756931
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    @ExceptionMixin
    class TestException(ExceptionMixin):
        pass

    # init
    test = TestException()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:06:54.638305
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    blueprint = Blueprint('test', url_prefix='test')
    blueprint.exception(Exception, apply=False)
    assert blueprint._future_exceptions != None

# Generated at 2022-06-24 04:07:03.747330
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest:
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = ExceptionMixinTest()
    func = lambda x: x+1
    @test.exception(Exception)
    def decorated_func(x):
        return func(x)

    assert decorated_func(1) == 2
    assert decorated_func.__name__ == "decorated_func"
    assert decorated_func.__doc__ == func.__doc__
    assert decorated_func.__module__ == func.__module__

# Generated at 2022-06-24 04:07:13.396691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    errors = {
        "InvalidUsage": "<class 'sanic.exceptions.InvalidUsage'>",
        "ServerError": "<class 'sanic.exceptions.ServerError'>",
        "NotFound": "<class 'sanic.exceptions.NotFound'>",
        "RequestTimeout": "<class 'sanic.exceptions.RequestTimeout'>"
    }

    from sanic.blueprints import Blueprint
    bp = Blueprint("test_ExceptionMixin_exception")
    @bp.exception(errors["InvalidUsage"])
    def exception_handler_InvalidUsage(request, exception):
        return response.text("OK")

    @bp.exception(errors["ServerError"])
    def exception_handler_ServerError(request, exception):
        return response.text("OK")


# Generated at 2022-06-24 04:07:16.803955
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin(1, 2, 3)._future_exceptions == set(), \
    "future_exceptions should be empty at the time of initialization"

# Generated at 2022-06-24 04:07:19.756695
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()


# Generated at 2022-06-24 04:07:25.611966
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView

    class HttpMethodView(HTTPMethodView, ExceptionMixin):
        def __init__(self):
            super(HttpMethodView, self).__init__()

    view = HttpMethodView()
    view.exception(Exception)(lambda request, exception: None)

    assert len(view._future_exceptions) == 1



# Generated at 2022-06-24 04:07:27.014020
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:07:35.990186
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from unittest.mock import Mock
    m = Mock()
    m.str = 'mock object'
    m.exception = ExceptionMixin.exception
    m.__init__ = lambda _: None
    handler = Mock()
    exception_type = TypeError
    m.exception(exception_type)(handler)
    assert handler.call_count == 0
    expected_future_exception = FutureException(handler, (exception_type,))
    assert m._future_exceptions == {expected_future_exception}
    assert m._apply_exception_handler.call_count == 0
    m.exception(exception_type)()
    assert m._apply_exception_handler.call_count == 1
    assert m._apply_exception

# Generated at 2022-06-24 04:07:46.327359
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.route import Route

    # Create Blueprint
    blueprint = Blueprint(name='test_exception_blueprint', url_prefix='/test_exception_blueprint')

    # Create first exception handler
    @blueprint.exception([Exception, IndexError])
    def handle_exception(request, exception):
        pass

    # Create second exception handler
    @blueprint.exception([ValueError])
    def handle_exception_2(request, exception):
        pass

    # Assert that both exception handlers are registered
    assert len(blueprint._future_exceptions) == 2

    # Assert that the first exception handler has the correct name
    assert blueprint._future_exceptions[0].handler.__name__ == "handle_exception"

    # An exception handler with

# Generated at 2022-06-24 04:07:49.757361
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_class(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()
    test = test_class()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:07:51.304650
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # s:ExceptionMixin = ExceptionMixin()
    # assert s._future_exceptions is not None
    pass

# Generated at 2022-06-24 04:07:58.324731
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            app = self.app = None
            self.routes = []
            self.exception(Exception)(lambda a: a)
            self.exception(Exception, apply=False)(lambda a: a)
            assert len(self._future_exceptions) == 2

    try:
        A()
    except AssertionError:
        print("test_ExceptionMixin_exception failure")


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:08:00.537254
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:08:01.045475
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin

# Generated at 2022-06-24 04:08:04.666566
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin = TestExceptionMixin()
    @test_mixin.exception(ValueError)
    def test_func():
        raise ValueError()
    with pytest.raises(ValueError):
        test_func()

# Generated at 2022-06-24 04:08:06.530985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO:
    pass

# Generated at 2022-06-24 04:08:07.833163
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False  # TODO: implement your test here


# Generated at 2022-06-24 04:08:11.484704
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockBlueprint(ExceptionMixin):

        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    mock_blueprint = MockBlueprint()
    assert not len(mock_blueprint._future_exceptions)


# Generated at 2022-06-24 04:08:14.170668
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BM(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    bm = BM()
    assert bm._future_exceptions == set()

# Generated at 2022-06-24 04:08:15.559541
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert ex._future_exceptions == set()


# Generated at 2022-06-24 04:08:17.042396
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ext = ExceptionMixin()
    assert ext._future_exceptions == set()


# Generated at 2022-06-24 04:08:18.461520
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin().exception()
    assert isinstance(result, types.FunctionType) == True

# Generated at 2022-06-24 04:08:28.502598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockSanic:
        def __init__(self):
            self.blueprint = []
            self.exception = []

        def register_listener(self, handler, event):
            self.exception.append((handler, event))
            return handler

        def register_blueprint(self, blueprint, **options):
            self.blueprint.append((blueprint, options))
            return blueprint

    # Test 1: Test if exception is registred correctly
    blueprint = ExceptionMixin()
    blueprint.name = "test"
    app = MockSanic()
    blueprint.register(app)
    assert len(app.blueprint) == 1
    assert len(app.exception) == 0
    blueprint.exception([Exception])(lambda request, exception: None)
    assert len(app.blueprint) == 1

# Generated at 2022-06-24 04:08:29.901733
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:08:35.922527
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestApp(ExceptionMixin):
        pass

    test = TestApp()

    # If the class is implemented correctly,
    # test.future_exceptions should be empty
    assert len(test._future_exceptions) == 0

# Generated at 2022-06-24 04:08:40.960972
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    This test is testing the constructing of class ExceptionMixin
    """
    assert ExceptionMixin.__name__ == 'ExceptionMixin'
    assert ExceptionMixin.__init__.__doc__ == 'Test if the constructor has a keyword argument: __init__(*args, **kwargs)'
    test = ExceptionMixin()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:08:46.398987
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    e = ExceptionMixin()
    assert type(e) == ExceptionMixin
    assert e._future_exceptions == set()

    def handler():
        pass
    assert e.exception(handler) == handler
    assert type(e._future_exceptions) == set
    assert e._apply_exception_handler == NotImplemented

# Generated at 2022-06-24 04:08:48.687969
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	assert ExceptionMixin()._future_exceptions != None
	assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:08:53.700186
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    assert MyExceptionMixin()

# Generated at 2022-06-24 04:09:00.120903
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Init
    class Blueprint(ExceptionMixin):
        pass
    bp = Blueprint()
    
    # exception function return function decorator
    def decorator(handler):
        pass
    assert(callable(bp.exception(decorator)) == True)
    
    # exception function return function decorator with parameters
    def decorator(handler):
        pass
    assert(callable(bp.exception(decorator, True, False)) == True)
    
    # exception function return function decorator with list of exceptions
    def decorator(handler):
        pass
    assert(callable(bp.exception([decorator])) == True)

# Generated at 2022-06-24 04:09:04.944378
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    obj = A()
    assert isinstance(obj, ExceptionMixin)


# Generated at 2022-06-24 04:09:11.403819
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.response import stream, text

    app = Sanic(__name__)

    @app.route("/")
    def handler(request):
        raise RuntimeError("exception")

    @app.exception(Exception)
    def handler_exception(request, exception):
        return text("An error occured")

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.body.decode() == "An error occured"

# Generated at 2022-06-24 04:09:17.448665
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Count(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.count = 0
        def boom(self):
            raise Exception('foo')
        def increase(self):
            self.count += 1

    count = Count()
    # assert that count has str representation of 1
    assert str(count) == '1'
    # assert num of exception handlers is 0
    assert len(count._future_exceptions) == 0
    # try to run boom, increase should not be called
    try:
        count.boom()
    except:
        pass
    assert count.count == 0
    # call exception to add a handler
    @count.exception(Exception)
    def handler(request, exception):
        count.increase()

# Generated at 2022-06-24 04:09:18.634448
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert type(ExceptionMixin)

# Generated at 2022-06-24 04:09:21.538438
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint

    bp = Blueprint('test_bp')

    assert isinstance(bp, ExceptionMixin)
    assert isinstance(bp._future_exceptions, set)



# Generated at 2022-06-24 04:09:27.978057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic.blueprints import Blueprint

    bp = Blueprint("test", url_prefix="/test")
    bp.handler = Mock()
    bp.exception(Exception)(lambda e: e)
    bp.handler.assert_called_once_with(bp, bp._future_exceptions.pop())

    bp.handler.reset_mock()
    bp.exception([Exception])(lambda e: e)
    bp.handler.assert_called_once_with(bp, bp._future_exceptions.pop())

# Generated at 2022-06-24 04:09:37.002530
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  from sanic.blueprints import Blueprint

  bp = Blueprint("blah")
  bp.exception(KeyError)(lambda r, e: "ok")

  # test that handler is applied by default
  assert "exception_handler" in bp._sanic_config
  assert bp._sanic_config["exception_handler"] == "blah.handle_exception"

  # test that handler is not applied if asked not to
  bp = Blueprint("blah")
  bp.exception(KeyError, apply=False)(lambda r, e: "ok")
  assert "exception_handler" not in bp._sanic_config
  assert bp._future_exceptions

  # test that handler is applied if asked to
  bp = Blueprint("blah")

# Generated at 2022-06-24 04:09:38.061244
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint is not None


# Generated at 2022-06-24 04:09:48.804024
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_obj(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return

    obj = ExceptionMixin_obj()
    # test ExceptionMixin_obj.exception
    assert len(obj._future_exceptions) == 0
    assert obj._apply_exception_handler(FutureException(lambda x: x, (ValueError, Exception))) == None
    obj.exception(ValueError, Exception)
    assert len(obj._future_exceptions) == 1
    obj.exception(ValueError, Exception, apply=False)
    assert len(obj._future_exceptions) == 2
    obj.exception([ValueError, Exception])


# Generated at 2022-06-24 04:09:58.104926
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    my_blueprint = Blueprint("my_blueprint", url_prefix="/my_blueprint")
    assert my_blueprint.name == "my_blueprint"
    assert my_blueprint.url_prefix == "/my_blueprint"
    assert isinstance(my_blueprint.request, Blueprint)
    assert isinstance(my_blueprint.websocket, Blueprint)
    assert my_blueprint.error_handler_spec == {}
    assert my_blueprint.error_handler_handlers == {}
    assert my_blueprint.error_handler_exceptions == set()
    assert my_blueprint.exception(Exception, apply=False)




# Generated at 2022-06-24 04:10:04.573580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        # Creating an object of class ExceptionMixin
        obj = ExceptionMixin()
        # Creating an exception handler
        def exceptionhandler(request, exception):
            print("At the Exception Handler")
            return response.text("Exception Caught")
        # Calling exception method on the object
        obj.exception(IndexError)(exceptionhandler)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 04:10:05.152909
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:10:09.287944
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class App:
        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    app = App()
    app.route = ExceptionMixin()
    assert(app.route._future_exceptions == set())


# Generated at 2022-06-24 04:10:12.015716
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass
    exc = ExceptionMixinTest()
    assert exc._future_exceptions == set()

# Generated at 2022-06-24 04:10:13.496242
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception()
    def handler():
        pass

# Generated at 2022-06-24 04:10:19.015474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test", url_prefix="tests", host="tests")
    blueprint.exception([1,2,3])
    assert len(blueprint._future_exceptions) == 1
    blueprint.exception([1,2,3])
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:10:21.333494
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert type(exception_mixin) == ExceptionMixin
    assert exception_mixin._future_exceptions is not None


# Generated at 2022-06-24 04:10:27.273536
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-24 04:10:29.240529
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.exceptions import ExceptionMixin
    exception = ExceptionMixin()
    assert exception is not None

# Generated at 2022-06-24 04:10:32.254499
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  mixin = ExceptionMixin()
  assert len(mixin._future_exceptions) == 0

# Generated at 2022-06-24 04:10:37.914057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self,handler):
            print(handler)

    testclass = TestClass()
    testclass.get('/',exceptions=(BaseException,))(print)

# Generated at 2022-06-24 04:10:39.189255
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()

# Generated at 2022-06-24 04:10:39.703703
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:10:42.514230
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        pass
    x = MyExceptionMixin()
    assert isinstance(x._future_exceptions, set)


# Generated at 2022-06-24 04:10:50.462308
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock
    class A(ExceptionMixin):
        def __init__(self, a):
            if a == 'test':
                self.future_exceptions.add(FutureException(a, 1))
            self.apply_exception_handler= MagicMock()
    a = A('test')
    a.exception(2, apply=False)
    a.exception(2, apply=True)
    assert len(a._future_exceptions) == 2
    assert type(a._future_exceptions).__name__ == 'set'
    assert type(a._future_exceptions.__iter__().__next__()).__name__ == 'FutureException'

# Generated at 2022-06-24 04:10:52.401551
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert issubclass(ExceptionMixin, object)
    try:
        ExceptionMixin()
    except TypeError:
        pytest.fail("TypeError raised")

# Generated at 2022-06-24 04:11:01.022808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print("Testing method exception of class ExceptionMixin")

    # Test: creation of a ExceptionMixin with __init__
    exceptions_mixin = ExceptionMixin()

    # Test: creation of a exception
    def exception_handler(request, exception):
        print("Exception Caught - exception handler")

    exceptions_mixin.exception(exception_handler)

    try:
        # Test: function exception with a exception
        raise Exception("Exception raised")
    except:
        # Test: function exception with a exception
        exception_handler("request", "exception")


# Generated at 2022-06-24 04:11:06.550421
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self)
    # class has no constructor
    exception_mixin = TestExceptionMixin()
    assert isinstance(exception_mixin, TestExceptionMixin)
    assert exception_mixin._future_exceptions is not None
    assert exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:11:13.297134
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testExceptionHandlerMixin(ExceptionMixin):
        def _apply_exception_handler(self,handler: FutureException):
            assert id(self) == id(handler.future_blueprint), "Same ID expected"

    class testExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert id(self) == id(handler.future_blueprint), "Same ID expected"
            assert id(self) != id(future_blueprint), "Distinct ID expected"

    class BP(Sanic):
        future_blueprint = testExceptionHandlerMixin()
        future_blueprint2 = testExceptionMixin()

    testBP = BP()

    @testBP.future_blueprint.exception([BaseException])
    async def FutureHandler(request, error):
        pass

   

# Generated at 2022-06-24 04:11:23.047294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print('test_ExceptionMixin_exception')
            return None

    bp = Blueprint()
    bp.exception(ZeroDivisionError)(lambda x: x)
    assert len(bp._future_exceptions) == 1
    bp.exception(ZeroDivisionError, ValueError)(lambda x:x)
    assert len(bp._future_exceptions) == 2
    bp.exception(ZeroDivisionError, ValueError)(lambda x:x, apply=False)
    assert len(bp._future_exceptions) == 2

# Generated at 2022-06-24 04:11:24.966435
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint('bp_exception_mixin', url_prefix='/test')
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:11:30.112400
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass
    x = ExceptionMixinTest()
    assert x._future_exceptions == set()


# Generated at 2022-06-24 04:11:31.699046
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    assert issubclass(ExceptionMixin, Blueprint)

# Generated at 2022-06-24 04:11:40.838939
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    original_value = ExceptionMixin.__init__

    def mock_init(self, *args, **kwargs):
        return None

    ExceptionMixin.__init__ = mock_init
    
    original_value_2 = ExceptionMixin._apply_exception_handler
    ExceptionMixin._apply_exception_handler = lambda x: None

    from sanic.blueprints import Blueprint
    
    blueprint = Blueprint("mock")

    def mock_handler():
        return "mock_handler"

    blueprint.exception(Exception, apply=True)(mock_handler)()

    assert blueprint._future_exceptions == {
        FutureException(handler=mock_handler, exceptions=(Exception,))
    }

    ExceptionMixin.__init__ = original_value
    ExceptionMixin._apply_exception_handler = original_value_

# Generated at 2022-06-24 04:11:46.281136
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

    app = TestExceptionMixin()

    assert len(app._future_exceptions) == 0



# Generated at 2022-06-24 04:11:48.317457
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    assert exception_mixin.exception
    assert exception_mixin._apply_exception_handler

# Generated at 2022-06-24 04:11:57.871103
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Run 1: args=Exception, kwargs={}, apply=True
    test_ExceptionMixin = TestExceptionMixin()
    exceptions = Exception()
    kwargs = {}
    apply = True
    decorated_decorator = test_ExceptionMixin.exception(exceptions, apply=apply)
    assert decorated_decorator.__name__ == 'decorator'
    handler = lambda: print('dummy')
    decorated_handler = decorated_decorator(handler)
    assert decorated_handler == handler

# Generated at 2022-06-24 04:11:59.936907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    f = ExceptionMixin()

    assert f._future_exceptions == set()
    assert f.exception == ExceptionMixin.exception

# Generated at 2022-06-24 04:12:06.925026
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = DummyExceptionMixin()
    assert exception_mixin._future_exceptions == set()

    @exception_mixin.exception([ValueError])
    def handler(request, exception):
        return exception

    assert exception_mixin._future_exceptions == {
        FutureException(handler, (ValueError,))
    }

# Generated at 2022-06-24 04:12:12.086291
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    mock_mixin = MockExceptionMixin()
    assert isinstance(mock_mixin, MockExceptionMixin)
    assert isinstance(mock_mixin, ExceptionMixin)
    assert isinstance(mock_mixin._future_exceptions, set)


# Generated at 2022-06-24 04:12:23.383058
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic()

    app.blueprint(name='BpException')

    @app.register_blueprint(name='BpException')
    def bp_exception():
        def decorator(f):
            def decorated_function():
                return f
            return decorated_function

        @decorator
        def get_exception():
            return json({'exception': 'test'})

        @decorator
        def post_exception():
            return json({'exception': 'test'})

        @decorator
        def delete_exception():
            return json({'exception': 'test'})

        @decorator
        def get_exception_with_id(id):
            return json({'id': id})

# Generated at 2022-06-24 04:12:27.017132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test", url_prefix="/test")

    @bp.exception(Exception)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-24 04:12:30.838027
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = A()
    handler = a.exception(Exception)
    assert isinstance(handler, types.FunctionType)

# Generated at 2022-06-24 04:12:39.290543
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test/1')

    @blueprint.exception(Exception)
    def test(request, exception):
        return "Test for exception"

    assert len(blueprint._future_exceptions) == 1

    future_exception = blueprint._future_exceptions.pop()
    assert issubclass(future_exception.exceptions[0], Exception)
    assert inspect.isfunction(future_exception.handler)

    assert test(None, None) == "Test for exception"

# Generated at 2022-06-24 04:12:40.325264
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # TODO: implement unit test
    pass

# Generated at 2022-06-24 04:12:42.124087
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions is not None
    

# Generated at 2022-06-24 04:12:45.626960
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)

    @blueprint.exception(Exception)
    def handler(request, exception):
        pass

    assert blueprint._future_exceptions == {
        FutureException(handler, (Exception,))}

# Generated at 2022-06-24 04:12:48.786924
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint

    blueprint = Blueprint()

    # Verify attributes are created in constructor
    assert blueprint._future_exceptions
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:12:59.434540
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintStub:
        def __init__(self):
            self.exception_callback = None

    blueprint_stub = BlueprintStub()
    exception_mixin = ExceptionMixin()

    def handler():
        pass

    exception_mixin._apply_exception_handler = lambda future_exception: \
        blueprint_stub.exception_callback(future_exception)
    decorated_handler = exception_mixin.exception(FileNotFoundError)(handler)

    # Check if register_exception_handler() has called during
    # exception_mixin.exception()
    assert(decorated_handler is handler)
    assert(len(exception_mixin._future_exceptions) == 1)
    future_exceptions = list(exception_mixin._future_exceptions)

# Generated at 2022-06-24 04:13:00.022944
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:13:02.266352
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin



# Generated at 2022-06-24 04:13:04.078634
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    test=Test()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:13:13.128590
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    bp = Blueprint('test', url_prefix='/test')
    new_exception = bp.exception(NotFound)(lambda request: '404')
    assert str(new_exception) == '<function Blueprint.exception.<locals>.decorator.<locals>.handler at 0x000002577FDE8D90>'
    assert bp.exception_css == {NotFound}
    assert bp.exception_handlers == {NotFound: new_exception}

# Generated at 2022-06-24 04:13:18.735943
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest.mock
    from sanic.blueprints.exceptions import ExceptionMixin
    expr = ExceptionMixin(**{})
    exception = unittest.mock.Mock(spec=Exception)
    expr.exception(exception)
    expr.exception(exception, apply=False)

# Generated at 2022-06-24 04:13:21.305931
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models import blueprint
    blueprint.ExceptionMixin()

# Generated at 2022-06-24 04:13:25.575612
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    future_exceptions = set()
    exception_mixin = ExceptionMixin()
    exception_mixin._future_exceptions = future_exceptions
    decorator = exception_mixin.exception(NotImplementedError, apply=True)
    def handler():
        return None
    decorator(handler)
    assert len(future_exceptions) == 1

# Generated at 2022-06-24 04:13:32.638964
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import InvalidUsage
    from sanic.views import HTTPMethodView

    # Create blueprint and mixin
    blueprint = Blueprint('test_blueprint', url_prefix='/blueprint')
    blueprint.exception(InvalidUsage)(lambda request, exception: 'OK')

    # Create application and route
    sanic_app = Sanic('test_sanic_exception_mixin_1')
    sanic_app.blueprint(blueprint)

    # Assert that exception handler is added
    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1



# Generated at 2022-06-24 04:13:35.026168
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Foo(ExceptionMixin):
        pass

    f = Foo()

    assert f._future_exceptions == set()


# Generated at 2022-06-24 04:13:40.310973
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Create an instance of exceptionMixin
    exception_mixin = ExceptionMixin()
    # We expect a set with no items
    assert hasattr(exception_mixin, "_future_exceptions")
    assert isinstance(exception_mixin._future_exceptions, set)
    assert len(exception_mixin._future_exceptions) == 0

# Generated at 2022-06-24 04:13:43.120635
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        new_object = ExceptionMixin()
        new_object._apply_exception_handler("apply")


# Generated at 2022-06-24 04:13:53.406997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _TestModel(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return None

    test_obj = _TestModel()
    assert isinstance(test_obj.exception(valueerror), collections.abc.Callable)
    assert isinstance(test_obj.exception(valueerror, apply=False), collections.abc.Callable)
    assert isinstance(test_obj.exception([ioerror, exception]), collections.abc.Callable)
    assert isinstance(test_obj.exception([ioerror, exception], apply=False), collections.abc.Callable)


if __name__ == '__main__':
    import pytest

    pytest.main

# Generated at 2022-06-24 04:13:55.683975
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert len(em._future_exceptions) == 0


# Generated at 2022-06-24 04:14:00.906435
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blueprint = Blueprint('blueprint')

    blueprint._future_exceptions = set()
    blueprint._apply_exception_handler = lambda x: x

    # call exception method
    @blueprint.exception(Exception)
    def exception_handler():
        pass

    # check exception_handler is added in set _future_exceptions
    assert exception_handler in blueprint._future_exceptions

# Generated at 2022-06-24 04:14:08.183835
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Sanic/Blueprint ExceptionMixin class exception method unit test.

    Return a decorated method to handle global exceptions
    for any route registered under this blueprint.

    :return: None
    """

    from sanic import Blueprint

    from sanic_openapi import base

    class BlueprintMixinExceptionHandler(base.BlueprintMixin,
                                         ExceptionMixin):
        pass

    blueprint = BlueprintMixinExceptionHandler(Blueprint)
    blueprint.exception(KeyError)(lambda request, exception: 1)
    blueprint.exception((KeyError,))(lambda request, exception: 1)
    blueprint.exception([KeyError])(lambda request, exception: 1)
    blueprint.exception(TypeError)(lambda request, exception: 1)
    blueprint.exception(AssertionError)(lambda request, exception: 1)
    blueprint.exception

# Generated at 2022-06-24 04:14:09.171763
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	em = ExceptionMixin()

# Generated at 2022-06-24 04:14:10.174280
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert(ExceptionMixin)

# Generated at 2022-06-24 04:14:11.972856
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()

    assert em
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:14:18.445205
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    mixin = ExceptionMixin(blueprint=Blueprint(url_prefix='mixin'))

    from sanic.models.futures import FutureException
    assert mixin._future_exceptions == set()
    assert issubclass(mixin._future_exceptions.__class__, set)
    assert issubclass(mixin._future_exceptions.__class__, set)
    assert issubclass(mixin._future_exceptions.__class__.__base__, object)

# Generated at 2022-06-24 04:14:20.795105
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass


# Generated at 2022-06-24 04:14:23.323146
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint as BP
    b = BP('/a')
    assert b._future_exceptions == set()


# Generated at 2022-06-24 04:14:26.582323
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    obj = ExceptionMixin()
    assert(obj._future_exceptions == set())

# Generated at 2022-06-24 04:14:30.240219
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyClass(ExceptionMixin):
        pass
    dummyclass = DummyClass()
    assert isinstance(dummyclass._future_exceptions, set)


# Generated at 2022-06-24 04:14:35.968973
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    m = TMixin()
    @m.exception(RuntimeError)
    async def test1(request, exception, *args, **kwargs):
        pass

# Generated at 2022-06-24 04:14:45.916086
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert type(handler) is FutureException

    exceptions = [IndexError, KeyError]
    testExceptionMixin = TestExceptionMixin()
    @testExceptionMixin.exception(*exceptions)
    def exceptionTestHandler():
        return 42
    assert exceptionTestHandler() == 42
    assert type(testExceptionMixin._future_exceptions) is set
    assert len(testExceptionMixin._future_exceptions) == 1
    assert list(testExceptionMixin._future_exceptions)[0].handler == exceptionTestHandler

# Generated at 2022-06-24 04:14:49.561710
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test_bp")
    @bp.exception(ZeroDivisionError)
    def catch_handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)



# Generated at 2022-06-24 04:14:52.690278
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_exception_mixin = ExceptionMixin()
    assert isinstance(test_exception_mixin._future_exceptions, set)


# Generated at 2022-06-24 04:15:03.027168
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import CompositionView

    blueprint = CompositionView()

    async def handler():
        pass

    blueprint.exception(
        ValueError, KeyError, apply=True)(handler)

    exception_handler = blueprint._future_exceptions.pop()

    assert exception_handler.handler is handler
    assert exception_handler.exceptions == (ValueError, KeyError)

    # second test
    blueprint = CompositionView()

    async def handler2():
        pass

    blueprint.exception([ValueError, KeyError], apply=True)(handler2)

    exception_handler = blueprint._future_exceptions.pop()

    assert exception_handler.handler is handler2
    assert exception_handler.exceptions == (ValueError, KeyError)

    # third test
    blueprint = CompositionView()

    async def handler3():
        pass

# Generated at 2022-06-24 04:15:06.193482
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin.exception(ExceptionMixin, Exception)
    assert type(result) == types.FunctionType

# Unit tests for method _apply_exception_handler of class ExceptionMixin

# Generated at 2022-06-24 04:15:14.035977
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert(isinstance(handler, FutureException))
            assert(len(handler.exceptions) == 1)
            assert(handler.exceptions[0] == SanicException)

    test_mixin = TestExceptionMixin()

    @test_mixin.exception(SanicException)
    def exception_handler(request, exception):
        assert(exception is None)

    assert(len(test_mixin._future_exceptions) == 1)

# Generated at 2022-06-24 04:15:25.158466
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.views import HTTPMethodView
    from sanic.response import text

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_bp', url_prefix='test')
    class_view = HTTPMethodView.as_view('test_class_view')
    exc_mixin = ExceptionMixin()

    @class_view
    async def get(self, request):
        return text('I am get method')

    @class_view.exception(Exception)
    async def get_exception(self, request, exception):
        pass

    bp.add_route(class_view, '/')
    app.blueprint(bp)
    req, res = app.test_client.get('/')

   

# Generated at 2022-06-24 04:15:34.050374
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = _ExceptionMixin()

    def decorator(handler):
        return handler

    assert len(exception_mixin._future_exceptions) == 0

    @exception_mixin.exception(ValueError)
    def handler():
        pass

    assert len(exception_mixin._future_exceptions) == 1

    exception_mixin.exception = decorator

    @exception_mixin.exception(ValueError)
    def handler():
        pass

    assert len(exception_mixin._future_exceptions) == 2



# Generated at 2022-06-24 04:15:46.020612
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  from sanic.Blueprint import Blueprint
  from sanic.models.futures import FutureException
  from sanic.request import Request
  from sanic.response import HTTPResponse
  
  app = Blueprint.app
  bp = Blueprint('test_bp', url_prefix='test')
  @bp.exception(Exception)
  def my_exception_handler(request, exception):
    return HTTPResponse(body="Exception", status=500)


  def test_bp(request):
    return HTTPResponse(body="Exception", status=500)
  
  app.add_route(test_bp, '/test')
  request, response = app.test_client.get('/test')
  assert response.status == 500
  assert response.body == b'Exception'

# Generated at 2022-06-24 04:15:46.556760
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:15:47.122153
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True == True

# Generated at 2022-06-24 04:15:49.615032
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test(ExceptionMixin):
        def __init__(self):
            return super().__init__()
    assert ExceptionMixin(test()._future_exceptions) == {set()}

# Generated at 2022-06-24 04:15:53.928413
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:15:58.677752
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = Blueprint('test', url_prefix='/bp')
    bp.exception(ZeroDivisionError)(lambda e: e)
    bp.exception(ZeroDivisionError, apply=False)(lambda e: e)
    assert len(bp._future_exceptions) == 2
    assert all(type(e) is FutureException for e in bp._future_exceptions)