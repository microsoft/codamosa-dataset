

# Generated at 2022-06-24 04:05:56.706812
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = Blueprint("test_bp", url_prefix='/v1/test')
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:05:58.814948
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    test = Test()
    assert len(test._future_exceptions) == 0



# Generated at 2022-06-24 04:06:01.685596
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    bp = Blueprint("blueprint-test")
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:06:04.719099
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        object = ExceptionMixin()
        object._apply_exception_handler('handler')
    assert object._future_exceptions == set()

# Generated at 2022-06-24 04:06:11.019549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin:
        def __init__(self):
            self._future_exceptions = set()

        async def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = MockExceptionMixin()
    exception_mixin.exception()

# Generated at 2022-06-24 04:06:12.642622
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e1 = ExceptionMixin()
    assert len(e1._future_exceptions) == 0
    assert e1._future_exceptions == set()

# Generated at 2022-06-24 04:06:16.491422
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestingExceptionClass(ExceptionMixin):
        pass
    obj = TestingExceptionClass()
    assert obj._future_exceptions == set()
    assert obj._future_exceptions == set()

# Generated at 2022-06-24 04:06:27.308607
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test case 1
    @Blueprint.exception(apply=False)
    def test():
        return {'key':'value'}

    # test case 2
    @Blueprint.exception(apply=False)
    def test_1(request):
        return {'key':'value'}

    # test case 3
    def test_2():
        return {'key':'value'}

    @Blueprint.exception(apply=False)
    def test_3():
        return {'key':'value'}

    def test_4():
        return {'key':'value'}

    @Blueprint.exception(apply=False, exceptions=(ValueError,))
    def test_5():
        return {'key':'value'}

    # test case 6

# Generated at 2022-06-24 04:06:29.666705
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TempExceptionMixin(ExceptionMixin): pass
    obj = TempExceptionMixin()
    assert obj.__init__
    assert obj._future_exceptions


# Generated at 2022-06-24 04:06:36.592408
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.models.futures import FutureException

    app = Sanic(__name__)

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            app.handle_exception(Exception)(self._apply_exception_handler)

        def _apply_exception_handler(self, handler: FutureException):
            app.handle_exception(handler.exceptions)(handler.handler)

    myExceptionMixin = MyExceptionMixin()

    @myExceptionMixin.exception(Exception)
    def my_custome_exception_handler(request, exception):
        return "An Error Occurred"

    assert my_custome_exception_

# Generated at 2022-06-24 04:06:45.185985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self,handler: FutureException):
            assert True
    exceptionmixin = ExceptionMixinClass()
    @exceptionmixin.exception(Exception)
    def handler(*args, **kwargs):
        assert True
    handler(1,2,3)
    assert len(exceptionmixin._future_exceptions) == 1

# Generated at 2022-06-24 04:06:53.565906
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case1: test exception to pass
    case1_class = ExceptionMixin()
    @case1_class.exception(Exception)
    def handle_exception(request, exception):
        return result("it works")

    assert hasattr(case1_class, handle_exception)
    # Case2: test exception to fail
    case2_class = ExceptionMixin()
    with pytest.raises(TypeError):
        @case2_class.exception({})
        def handle_exception(request, exception):
            return result("it works")

    # Case3: test exception to failure
    case3_class = ExceptionMixin()

# Generated at 2022-06-24 04:06:59.422660
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SampleClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()

    SampleClass()


# Generated at 2022-06-24 04:07:11.201915
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMock(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()
            
        def _apply_exception_handler(self, handler: FutureException):
            return None

    mock = ExceptionMock()

    def decorator1(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        mock._future_exceptions.add(future_exception)
        mock._apply_exception_handler(future_exception)
        return handler

    try:
        mock.exception([IndexError, KeyError])(decorator1)
    except:
        assert False

# Generated at 2022-06-24 04:07:18.765295
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # DECLARE
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    my_exception_mixin = ExceptionMixinClass()

    # DO
    @my_exception_mixin.exception(Exception)
    def example_exception_handler(request, exception: Exception):
        pass

    # ASSERT
    for future_exception in my_exception_mixin._future_exceptions:
        assert future_exception._exceptions == (Exception,)
        assert future_exception._handler == example_exception_handler

# Generated at 2022-06-24 04:07:23.804742
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_app.app import Sanic

    app = Sanic("test_ExceptionMixin_exception")

    blueprint = Blueprint("test_ExceptionMixin_exception", url_prefix="test")
    blueprint.exception(Exception)(lambda request: "ok")

    assert blueprint.exception.__name__ == "exception"
    assert blueprint.exception.__qualname__ == "ExceptionMixin.exception"

# Generated at 2022-06-24 04:07:28.567530
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinObject(ExceptionMixin):
        pass
    exc_object = ExceptionMixinObject()
    assert hasattr(exc_object, "_future_exceptions")

# Generated at 2022-06-24 04:07:33.176275
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    test = TestExceptionMixin()
    assert not test._future_exceptions



# Generated at 2022-06-24 04:07:34.603963
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert not a
    a = ExceptionMixin(2, 3)
    assert not a

# Generated at 2022-06-24 04:07:43.662233
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class SimpleBlueprint(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # When
    blueprint = SimpleBlueprint()

    @blueprint.exception(RuntimeError)
    def handle_exception(request, exception):
        pass

    # Then
    exceptions = [future_exception.exception for future_exception in blueprint._future_exceptions]
    assert exceptions == [RuntimeError]
    assert handle_exception in [future_exception.handler for future_exception in blueprint._future_exceptions]


# Generated at 2022-06-24 04:07:50.628588
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyError(Exception):
        def __init__(self, message):
            self.message = message

    class ExceptionMixinImpl(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            handler.handler(MyError('test'))

    exceptionMixin = ExceptionMixinImpl()
    @exceptionMixin.exception(apply=False)
    def exception_handler(request, exception):
        print(exception)

    exceptionMixin._apply_exception_handler(list(exceptionMixin._future_exceptions)[0])

# Generated at 2022-06-24 04:07:58.864401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import os
    import sys

    # set current directory to the root of the repository
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    import sanic.blueprints

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = sanic.blueprints.Blueprint('test', url_prefix='/test')
    t = TestExceptionMixin()
    t.exception(Exception)(print)
    assert isinstance(t._future_exceptions, set)
    assert len(t._future_exceptions) == 1

# Generated at 2022-06-24 04:08:03.663528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    @Blueprint.exception(TypeError)
    async def handle_type_error(request, error):
        return text("type error!")

    b = Blueprint('blueprint', url_prefix='/api/v1')
    b.exception(TypeError)(handle_type_error)

    assert b._future_exceptions == set([
        FutureException(handle_type_error, (TypeError,), {})
    ])

    assert b.exception._handled_exceptions == set([
        FutureException(handle_type_error, (TypeError,), {})
    ])

# Generated at 2022-06-24 04:08:14.294329
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a class which inherits from ExceptionMixin and contains constructor
    class ExInit(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    # create a list with parameters which will be passed to the decorator
    exceptions = [Exception, KeyError]

    # create a decorated method
    def handler(request, exception):
        return 'Exception handler'

    # create a decorated method
    def handler2(request, exception):
        return 'Exception handler2'

    # create a object of ExInit class
    test = ExInit()

    # test exception method with a decorated method of hanlder
    handler_decorated_method = test.exception(*exceptions)(handler)
    assert handler_decorated_method == handler

    # test exception method with a decorated method

# Generated at 2022-06-24 04:08:15.972215
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test = TestExceptionMixin()
    assert test._future_exceptions == set()

# Generated at 2022-06-24 04:08:18.017262
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    te = Test()
    assert isinstance(te._future_exceptions, set)

# Generated at 2022-06-24 04:08:25.136019
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self._exception_handler = self.not_implemented_error
    a = A()
    # test the case when there is the only one exception
    @a.exception(IndexError)
    def exception_handler(request, exception):
        return 'function exception_handler'
    #assert a._future_exceptions == {FutureException(exception_handler, (IndexError,))}
    #assert a._exception_handler == exception_handler
    # test the case when there are some exceptions
    @a.exception(IndexError, FileNotFoundError)
    def exception_handler(request, exception):
        return 'function exception_handler'
    #assert a._future_ex

# Generated at 2022-06-24 04:08:26.617838
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin

# Generated at 2022-06-24 04:08:32.072874
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__)

    @blueprint.exception(NameError)
    def handler(request, exception):
        return text('Name error')

    assert type(handler) is types.FunctionType
    assert blueprint._future_exceptions is not None

    # TODO: test for method _apply_exception_handler

# Generated at 2022-06-24 04:08:38.174490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass(ExceptionMixin):
        pass
    c = MyClass()
    lst = [1, 2, 3]
    decorator = c.exception(lst, apply=False)
    def func():
        print('test_ExceptionMixin_exception')
    decorator(func)
    assert c._future_exceptions == {FutureException(func, tuple(lst))}
    assert c._apply_exception_handler('mock') == NotImplementedError

# Generated at 2022-06-24 04:08:44.520598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass
    def decorator(handler):
        return handler
    _exceptions = (Exception, )

    class mock:
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler):
            pass

    my_mock = mock()
    my_mock.exception(exceptions=_exceptions)(decorator)('')

    assert my_mock._future_exceptions == {FutureException(decorator, _exceptions)}

# Generated at 2022-06-24 04:08:54.655308
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Route():
        def get(self, request, x):
            pass

    class Blueprint(ExceptionMixin):
        def __init__(self, name, url_prefix):
            super().__init__()
            self.routes = [Route()]
            self.name = name
            self.url_prefix = url_prefix

        def add_route(self, route, **kwargs):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = Blueprint('name', 'url_prefix')

    def exception_handler():
        pass

    blueprint.exception(Exception)(exception_handler)

    for future_exception in blueprint._future_exceptions:
        assert future_exception.handler == exception_handler
        assert future_exception.exceptions == (Exception,)

# Generated at 2022-06-24 04:09:01.304610
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest

    class TestExceptionMixin(ExceptionMixin):
        pass

    exception_mixin = TestExceptionMixin()
    assert isinstance(exception_mixin._future_exceptions, set)

    def handler_exception(request):
        return "handler_exception"

    assert exception_mixin.exception(ValueError) == handler_exception

    new_future_exception = FutureException(handler_exception, (ValueError,))
    exception_mixin._apply_exception_handler(new_future_exception)



# Generated at 2022-06-24 04:09:03.651142
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handle_exception(*args):
        pass

    blueprint = blueprint_factory()
    blueprint.exception(ZeroDivisionError)(handle_exception)

    assert blueprint._future_exceptions



# Generated at 2022-06-24 04:09:04.765117
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Generated at 2022-06-24 04:09:10.739121
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    class ExceptionMixinTestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Act
    exception_mixin_test_class = ExceptionMixinTestClass()

    # Assert
    assert isinstance(exception_mixin_test_class, ExceptionMixin)
    assert isinstance(exception_mixin_test_class._future_exceptions, set)


# Generated at 2022-06-24 04:09:12.270804
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # obj = ExceptionMixin()
    # assert obj.exception()
    assert True

# Generated at 2022-06-24 04:09:18.200461
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.method import Method

    def exception_handler(request, exception):
        print(f'Exception: {exception}')
        return 'exception_handler'


    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(ValueError, apply=True)
    def exception_handler(request, exception):
        print(f'Exception: {exception}')
        return 'exception_handler'

    assert exception_mixin._future_exceptions



# Generated at 2022-06-24 04:09:21.059247
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint1(ExceptionMixin):
        bp = Blueprint('test', 'test')

    blueprint = Blueprint1()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:09:22.541504
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExMixIn = ExceptionMixin()
    assert ExMixIn._future_exceptions is not None

# Generated at 2022-06-24 04:09:25.347768
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    app = Sanic('test_sanic')

    handler = lambda request, exception: None
    future_exception = FutureException(handler, Exception)

    assert future_exception in app.exception(Exception)(handler)

# Generated at 2022-06-24 04:09:32.806344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint
    from sanic.response import json
    from sanic.exceptions import ServerError

    class FooException(Exception):
        pass

    class BarException(Exception):
        pass

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_ExceptionMixin_exception")

    @bp.exception([FooException, BarException])
    def handler(request, exception):
        return json({"error": str(exception)}, status=500)

    @app.listener("before_server_start")
    def attach(app, loop):
        app.blueprint(bp)

    @app.route("/")
    def normal(request):
        return json({"status": "OK"})


# Generated at 2022-06-24 04:09:41.025092
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    bp = Blueprint()
    bp.exception(Exception)

    assert bp._future_exceptions
    assert isinstance(bp._future_exceptions.pop(), FutureException)

    bp.exception([Exception])

    assert bp._future_exceptions
    assert isinstance(bp._future_exceptions.pop(), FutureException)

    bp.exception([Exception], apply=False)

    assert bp._future_exceptions
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:09:45.575887
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()
    assert e.__init__ is ExceptionMixin.__init__
    assert e.__init__.__code__.co_varnames == ('self', '*args', '**kwargs')


# Generated at 2022-06-24 04:09:46.873344
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        em = ExceptionMixin()
        em.__init__()
        assert em is not None
        assert em._future_exceptions is not None
    except:
        assert False


# Generated at 2022-06-24 04:09:47.478476
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:56.361144
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # the function mock_exception is used to replace the decorator function in the method exception
    def mock_exception(*args):
        return args

    # the function mock_handler is used to replace the handler function in the method exception
    def mock_handler():
        return 1

    # method exception is used to return the decorator function
    m = MethodView()
    m.exception = ExceptionMixin.exception
    assert (mock_handler, ) == m.exception()(mock_handler)


# Generated at 2022-06-24 04:10:01.378561
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:10:03.875550
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with BluePrint(__name__) as bp:
        assert bp._future_exceptions == set()



# Generated at 2022-06-24 04:10:06.199547
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.bp import Blueprint
    blueprint = Blueprint("name")
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:10:17.572328
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockBlueprint:
        def __init__(self):
            self._exception_handler_record = []

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handler_record.append(handler)

        def handler(self):
            pass

    @MockBlueprint.exception(Exception)
    def my_handler(self):
        assert True

    @MockBlueprint.exception([Exception])
    def my_list_handler(self):
        assert True

    mock_blueprint = MockBlueprint()

    assert mock_blueprint._exception_handler_record == []

    my_handler(mock_blueprint)
    my_list_handler(mock_blueprint)

    assert mock_blueprint._exception_handler_record[0].handler == my_handler

# Generated at 2022-06-24 04:10:22.620668
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
            
    res = TestClass()
    
    assert isinstance(res._future_exceptions, set)
    
    

# Generated at 2022-06-24 04:10:27.539382
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print('test_ExceptionMixin_exception')
            assert isinstance(handler, FutureException)

    ExceptionMixin()

# Generated at 2022-06-24 04:10:30.776514
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    bp = Blueprint("ExceptionMixin")

    assert hasattr(bp, "_future_exceptions")
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:10:39.889142
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #Arrange
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.handlers import ErrorHandler
    from sanic.models.exceptions import SanicException
    from sanic.models.futures import FutureException
    from sanic.request import Request

    blueprint = Blueprint(__name__, url_prefix='/test')
    blueprint._apply_exception_handler = ErrorHandler._apply_exception_handler
    blueprint.exception(SanicException)

# Generated at 2022-06-24 04:10:43.374986
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    #########################
    ExceptionMixin_test()  # noqa
    #########################

# Generated at 2022-06-24 04:10:48.965721
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class UnitTest(Blueprint, ExceptionMixin):
        pass

    blueprint = UnitTest("test")
    @blueprint.exception(IndexError, apply=False)
    def handler(request, exception):
        pass
    assert hasattr(handler, "exception")
    assert hasattr(handler, "exceptions")
    assert handler.exception == (IndexError,)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:10:50.995677
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """Ensure that the constructor of class ExceptionMixin works as expected"""
    instance = mock.Mock(spec=ExceptionMixin)
    assert instance._future_exceptions is not None

# Generated at 2022-06-24 04:10:52.454415
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin() 
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:10:57.864520
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return handler

    @ExceptionMixinTest.exception(None)
    def handler():
        return "handler"

    assert ExceptionMixinTest._future_exceptions == {FutureException(handler, (None,))}

# Generated at 2022-06-24 04:11:07.175456
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #get exceptionMixin object
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    blueprint = Blueprint()
    #get decorator
    decorator = blueprint.exception(Exception)
    #get handler
    def handler(request, exception):
        return exception

    #call decorator
    decorator_handler = decorator(handler)
    # check FutureException
    future_exception = FutureException(decorator_handler, (Exception,))

    assert len(blueprint._future_exceptions) == 1
    assert future_exception in blueprint._future_exceptions

# Generated at 2022-06-24 04:11:12.050394
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
      def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
      def _apply_exception_handler(self, handler: FutureException):
        pass

    test = ExceptionMixinTester()
    # I don't know how to test this because I don't know how
    # to ensure that the __init__ function does what it's supposed to do.
    assert test

# Generated at 2022-06-24 04:11:13.498454
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    exception = ExceptionMixin(Blueprint)
    assert exception._future_exceptions == set()

# Generated at 2022-06-24 04:11:19.005035
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()
    
    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin._future_exceptions = set()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:11:21.642385
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:30.119225
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # assert method exception works

    # create a blueprint instance
    bp = Blueprint('main', url_prefix='')

    # if setting apply to False, 
    # then it should not apply the exception handler 
    # to the blueprint instance
    def handler():
        return None
    bp.exception(Exception, apply=False)(handler)
    assert hasattr(bp, 'exception_handler_params') == False

    # if setting apply to True, 
    # then it should apply the exception handler 
    # to the blueprint instance
    def handler():
        return None
    bp.exception(Exception, apply=True)(handler)
    assert hasattr(bp, 'exception_handler_params') == True

# Generated at 2022-06-24 04:11:32.140349
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    future_exceptions: Set[FutureException] = set()
    try:
        ExceptionMixin.__init__(future_exceptions)
    except:
        raise ExceptionMixin()



# Generated at 2022-06-24 04:11:36.432905
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test', url_prefix='test')

    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:11:37.379061
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()

# Generated at 2022-06-24 04:11:41.241763
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass


# Generated at 2022-06-24 04:11:45.597542
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint("my_blueprint", url_prefix="test", strict_slashes=True)
    assert isinstance(blueprint, ExceptionMixin)
    assert isinstance(blueprint._future_exceptions, set)


# Generated at 2022-06-24 04:11:48.371518
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_object = ExceptionMixin()
    assert test_object is not None
    

# Generated at 2022-06-24 04:11:54.137498
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    app = Sanic("test_ExceptionMixin")
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
    blueprint = TestExceptionMixin()
    blueprint = TestExceptionMixin()
    blueprint2 = Blueprint("test_ExceptionMixin")
    blueprint2 = Blueprint("test_ExceptionMixin")

# Generated at 2022-06-24 04:11:57.205956
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    app = Blueprint()
    assert isinstance(app._future_exceptions, set)


# Generated at 2022-06-24 04:11:58.585908
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert exception._future_exceptions == set()

# Generated at 2022-06-24 04:12:02.182089
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        pass
    with pytest.raises(NotImplementedError) as e:
        Blueprint()._apply_exception_handler(None)
    assert '_apply_exception_handler' in str(e.value)


# Generated at 2022-06-24 04:12:08.866252
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_obj = TestExceptionMixin()
    # check test_obj.exception is a decorator
    assert test_obj.exception()(None) is None

    # check test_obj._future_exceptions
    assert len(test_obj._future_exceptions) == 1

    @test_obj.exception()
    def test_func():
        pass
    # check test_obj._future_exceptions
    assert len(test_obj._future_exceptions) == 2

# Generated at 2022-06-24 04:12:09.997190
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:12:13.319868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Dummy:
        def dummy_func(self):
            pass
    dummy_object = Dummy()
    ExceptionMixin.__init__(dummy_object)
    dummy_object.exception(dummy_object.dummy_func)



# Generated at 2022-06-24 04:12:15.417154
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()
    assert isinstance(x, ExceptionMixin)


# Generated at 2022-06-24 04:12:23.568024
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic import SanicException
    app = Sanic(__name__)
    blue1 = Blueprint('test_exception')

    @blue1.exception(SanicException)
    def handler(request, exception):
        return text('An error occurred!')

    app.blueprint(blue1)

    @app.route('/test')
    def test(request):
        raise SanicException('test')

    request, response = app.test_client.get(url_for('test'))
    assert response.text == 'An error occurred!'

# Generated at 2022-06-24 04:12:28.525089
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            return

    route_blueprint = Blueprint()
    @route_blueprint.exception(BaseException)
    def exception_handler(request, exception):
        return "Exception handler."

    assert len(route_blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:12:32.076732
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test1(ExceptionMixin):
        pass
    t1 = Test1()
    assert t1._future_exceptions == set()


# Generated at 2022-06-24 04:12:34.111980
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:12:37.930320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint("test", url_prefix="test")

    @bp.exception(IndexError)
    def handler(req, ex):
        pass

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:12:43.627540
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    class ExceptionMixin_class(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = Sanic()
    blueprint = ExceptionMixin_class()

    @blueprint.exception(Exception)
    def exception_method(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:12:51.780562
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    expected_exceptions = [ValueError, FileNotFoundError]
    expected_handler = lambda request, exception: None

    mixin = ExceptionMixinImpl()
    mixin.exception(*expected_exceptions)(expected_handler)

    assert len(mixin._future_exceptions) == 1
    assert type(mixin._future_exceptions.pop()) == FutureException
    assert mixin._future_exceptions.pop().exceptions == tuple(
        expected_exceptions)
    assert mixin._future_exceptions.pop().handler == expected_handler

# Generated at 2022-06-24 04:13:02.827218
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestingExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    # Test case 1: decorate a handler without parameters
    def handler_test_case_1():
        raise Exception()

    @TestingExceptionMixin().exception(Exception)
    def handler_test_case_1():
        raise Exception()

    assert handler_test_case_1.__name__ == 'handler_test_case_1'

    # Test case 2: decorate a handler with receiving parameters
    def handler_test_case_2(request):
        raise Exception()


# Generated at 2022-06-24 04:13:06.063053
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:13:08.805831
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # create a blueprint and test constructor
    blueprint = ExceptionMixin()

    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:13:15.404593
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixinTester, self).__init__()

    exception_mixin = ExceptionMixinTester()
    assert isinstance(exception_mixin, ExceptionMixinTester)


# Generated at 2022-06-24 04:13:16.617619
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m._future_exceptions == set()


# Generated at 2022-06-24 04:13:21.218919
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    emt = ExceptionMixinTest()

    @emt.exception(ValueError)
    def handler(request, exception):
        pass

    assert len(emt._future_exceptions) == 1

# Generated at 2022-06-24 04:13:26.251174
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def handler():
        pass

    test = Test()
    assert handler not in test._future_exceptions

    test.exception(Exception)(handler)
    assert handler in test._future_exceptions

    test.exception([Exception])(handler)
    assert handler in test._future_exceptions

# Generated at 2022-06-24 04:13:29.676958
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class App(ExceptionMixin):
        pass
    app = App()
    # test if exception being registered by calling the decorator
    # on an dummy handler function
    app.exception([TypeError, ValueError])(lambda: None)
    assert app._future_exceptions

# Generated at 2022-06-24 04:13:36.784585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    sys.path.append('../')
    from sanic import Sanic

    app = Sanic('test_ExceptionMixin_exception')
    excm = ExceptionMixin()
    excm._future_exceptions = set()
    excm.exception(ValueError)
    assert len(excm._future_exceptions) == 1
    error = ValueError()
    excm._apply_exception_handler(excm._future_exceptions[0])
    excm.exception(ValueError)
    assert len(excm._future_exceptions) == 2
    error = ValueError()
    excm._apply_exception_handler(excm._future_exceptions[0])


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:13:41.995470
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException  # noqa
    from sanic.models.exceptions import ExceptionMixin
    def test_function():
        pass
    
    EM = ExceptionMixin()
    assert isinstance(EM._future_exceptions, set)

    assert EM._apply_exception_handler(FutureException(test_function, {})) is None


# Generated at 2022-06-24 04:13:44.429295
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.server import HttpProtocol

    e = HttpProtocol(None)
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:13:46.335268
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
  try:
    ExceptionMixin()
  except:
    assert False
  assert True


# Generated at 2022-06-24 04:13:49.106602
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions = set()
    assert TestClass()

# Generated at 2022-06-24 04:13:51.380946
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint()
    assert blueprint._future_exceptions == set()

# test _apply_exception_handler method of class ExceptionMixin

# Generated at 2022-06-24 04:13:53.454666
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert isinstance(obj, ExceptionMixin)
    assert isinstance(obj._future_exceptions, set)


# Generated at 2022-06-24 04:13:55.722954
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:04.724216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.models.futures import FutureException
    from sanic.models.exception_handlers import response_exception_handler

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')
    bp._apply_exception_handler = response_exception_handler

    @bp.route('/')
    def handler(request):
        raise ServerError('boom!')

    @bp.exception(Exception)
    def handler1(request, exception):
        return json({'error': 'An exception raised'})


# Generated at 2022-06-24 04:14:08.526701
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    assert isinstance(a._future_exceptions, set)


# Generated at 2022-06-24 04:14:15.684605
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinUnitTest(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()

    test_exception_mixin = ExceptionMixinUnitTest()
    @test_exception_mixin.exception(Exception)
    def exception_handler():
        return 0
    assert exception_handler() == 0
    future_exception = FutureException(exception_handler, Exception)
    assert future_exception in test_exception_mixin._future_exceptions

# Generated at 2022-06-24 04:14:17.019398
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()


# Generated at 2022-06-24 04:14:27.801060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    import sanic
    from sanic.models import exceptions as future_exceptions

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *, app=None, route_prefix=None, strict_slashes=None):
            assert app == 'App'
            assert route_prefix == 'prefix'
            assert strict_slashes == 'strict'
            super().__init__()

        def _apply_exception_handler(self, handler: future_exceptions.FutureException):
            assert handler == 'FutureException'

    # Act
    TestExceptionMixin(app='App', route_prefix='prefix', strict_slashes='strict')

    # Assert
    # No assert needed; if we got here, no exceptions occurred

# Generated at 2022-06-24 04:14:30.741812
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_decorator = ExceptionMixin.exception
    assert isinstance(exception_decorator, types.MethodType)
    assert callable(exception_decorator)

# Generated at 2022-06-24 04:14:39.166210
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    app = Sanic()
    bp = Blueprint('bp1',url_prefix='test')
    assert not bp._future_exceptions
    bp2 = Blueprint('bp2',url_prefix='test2')
    assert not bp2._future_exceptions
    bp.exception()
    bp.exception()
    bp2.exception()
    assert len(bp._future_exceptions) == 2
    assert len(bp2._future_exceptions) == 1
    bp.exception(Exception)
    bp.exception(Exception)
    bp.exception(Exception)
    bp2.exception(Exception)
    assert len(bp._future_exceptions) == 3

# Generated at 2022-06-24 04:14:41.146424
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    bp = Blueprint("test_bp", url_prefix="/")
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:14:42.089054
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint

# Generated at 2022-06-24 04:14:43.520671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ExceptionMixin.__init__(self, *args, **kwargs)


# Generated at 2022-06-24 04:14:45.849868
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixin, self).__init__()
    a = A()
    assert isinstance(a, ExceptionMixin)


# Generated at 2022-06-24 04:14:46.717143
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == None

# Generated at 2022-06-24 04:14:50.355975
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # test_ExceptionMixin:__init__
    try:
        test = ExceptionMixin()
        test._future_exceptions
        test
    except Exception as error:
        print("FAILED")
        print(error)
        return
    print("PASSED")

# Generated at 2022-06-24 04:14:58.058153
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(ZeroDivisionError)
    async def handler_1(request, exception):
        assert request
        assert exception
        return 'ok'

    assert blueprint._future_exceptions

    @blueprint.exception([ZeroDivisionError, IndexError], apply=True)
    def handler_2(request, exception):
        assert request
        assert exception
        return 'ok'

    assert blueprint._future_exceptions

# Generated at 2022-06-24 04:14:59.837742
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ins = ExceptionMixin()
    assert ins is not None
    assert ins._future_exceptions is not None

# Generated at 2022-06-24 04:15:00.444543
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:15:12.105750
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # GIVEN
    # Create a blueprint called bp
    bp = Blueprint(__name__)
    # Create class A
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)
    # Create instance a of class A
    a = A()
    print(a)
    # WHEN
    # Add decorator @a.exception
    @a.exception(ZeroDivisionError, AttributeError)
    def handler(self, request, exception):
        print(exception)
    # THEN
    # Check that a._future_exceptions is not empty and is a set
    assert a._future_exceptions != set()

# Generated at 2022-06-24 04:15:14.081210
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert not hasattr(ExceptionMixin(), '_future_exceptions')
    assert hasattr(ExceptionMixin(), '_future_exceptions')

# Generated at 2022-06-24 04:15:25.211324
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Raise NotImplementedError
    class test_ExceptionMixin(ExceptionMixin):
        def __init__(self,*args,**kwargs) -> None:
            self._future_exceptions:Set[FutureException] = set()
    
    # Instantiation
    t = test_ExceptionMixin()

    # # Raise NotImplementedError
    # def _apply_exception_handler(self, handler: FutureException):
    #     raise NotImplementedError  # noqa

    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        if isinstance(exceptions[0], list):
            exceptions = tuple(*exceptions)

        future_exception = FutureException(handler, exceptions)
        t._future_exceptions.add(future_exception)
        if apply:
            t._apply_ex

# Generated at 2022-06-24 04:15:25.926000
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True == True

# Generated at 2022-06-24 04:15:29.381662
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:33.773490
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exMixin = ExceptionMixin()
    assert exMixin

# Generated at 2022-06-24 04:15:34.387320
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:15:46.246571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound, ServerError

    @ExceptionMixin.exception(NotFound)
    async def exception_handler(request, exception):
        return response.json("not found", status=exception.status_code)

    assert {exception_handler} == ExceptionMixin._future_exceptions
    assert exception_handler.exceptions == (NotFound,)

    @ExceptionMixin.exception([NotFound, ServerError])
    async def exception_handler(request, exception):
        return response.json("not found", status=exception.status_code)

    assert {exception_handler} == ExceptionMixin._future_exceptions
    assert exception_handler.exceptions == (NotFound, ServerError)


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:15:48.671393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def test(request, exception):
        return exception
    assert test.__name__ == 'test'


# Generated at 2022-06-24 04:15:58.999173
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            print(handler, handler.handler, handler.exceptions)

    test = TestExceptionMixin()
    @test.exception([TypeError, IndexError])
    def handle_exception():
        pass
    @test.exception(TypeError)
    def handle_exception2():
        pass

    assert isinstance(test._future_exceptions, set)
    assert len(test._future_exceptions) == 2
    for handler in test._future_exceptions:
        assert isinstance(handler, FutureException)