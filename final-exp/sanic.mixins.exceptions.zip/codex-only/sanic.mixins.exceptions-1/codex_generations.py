

# Generated at 2022-06-24 04:05:53.744119
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Request(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    x = Request()
    assert(isinstance(x._future_exceptions, set))


# Generated at 2022-06-24 04:05:59.242517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest

    @ExceptionMixin.exception(RuntimeError)
    def handler(request, exception):
        pass

    assert type(handler) == types.FunctionType
    assert handler.__name__ == 'handler'
    assert handler.__qualname__ == 'handler'
    assert type(handler.__doc__) is str
    assert handler.__module__ == '__main__'
    assert handler.__defaults__ is None
    assert handler.__closure__ is None
    assert handler.__code__.co_varnames == ('request', 'exception')
    assert handler.__code__.co_argcount == 2
    assert handler.__annotations__ == {}



# Generated at 2022-06-24 04:06:05.482019
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass
    my_sanic = Sanic()
    @my_sanic.exception()
    def valid_exception_handler():
        pass

    assert len(my_sanic._future_exceptions) == 1
    assert Sanic._future_exceptions is not None
    assert Sanic._future_exceptions.__doc__ == 'Set[FutureException]'

# Generated at 2022-06-24 04:06:09.755627
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Assert that class ExceptionMixin returns the expected result if constructor is called without arguments
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:06:12.355483
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()



# Generated at 2022-06-24 04:06:16.680472
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from shapely.geometry import Point
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint("test")
    app = Sanic("test_sanic_blueprint")

    @bp.route("/")
    def handler(request):
        return Point([6, 6]).wkt

    app.blueprint(bp)

    app.run()

# Generated at 2022-06-24 04:06:21.447367
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExampleExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    exem = ExampleExceptionMixin()
    assert exem._future_exceptions == set()



# Generated at 2022-06-24 04:06:26.821090
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.definitions import Blueprint
    from sanic.models.futures import ExceptionFuture
    from sanic.models.futures import FutureException
    import mock

    blueprint = Blueprint(__name__)

    futures = ExceptionFuture(blueprint)
    future_exception = FutureException(None, None)

    assert isinstance(futures, ExceptionFuture)
    assert isinstance(future_exception, FutureException)


# Generated at 2022-06-24 04:06:29.858990
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SanicExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # Launch testing for constructor of class ExceptionMixin
    SanicExceptionMixin()

# Generated at 2022-06-24 04:06:32.605805
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Foo(ExceptionMixin):
        pass

    foo_instance = Foo()
    assert foo_instance._future_exceptions == set()


# Generated at 2022-06-24 04:06:36.018974
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models import FutureException
    from sanic.blueprints import Blueprint

    app = Sanic()
    blueprint = Blueprint('exception_mixin')

    @blueprint.exception(apply=False)
    def test(request, exception):
        pass

    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:06:47.735858
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception('NameError')
    def nameError(request, exception):
        print('NameError')
        print(exception)
    @ExceptionMixin.exception('TypeError')
    def typeError(request, exception):
        print('TypeError')
        print(exception)
    try:
        raise NameError('MyNameError')
    except NameError as e:
        nameError(None, e)
    try:
        raise TypeError('MyTypeError')
    except TypeError as e:
        typeError(None, e)
    try:
        raise ValueError('MyValueError')
    except ValueError as e:
        nameError(None, e)


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:06:54.320693
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import json
    from sanic.exceptions import NotFound
    global_exceptions = Blueprint.exception(*[Exception, NotFound])

    @global_exceptions(lambda e: json({"status": "error", "error": e.args[0]}))
    async def catched(request):
        pass
    
    assert catched.__name__ == "catched"

# Generated at 2022-06-24 04:07:01.066566
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_future_exception = FutureException(Exception, Exception)
    test_future_exceptions = set()
    test_future_exceptions.add(test_future_exception)
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
        def _apply_exception_handler(self, handler):
            assert handler == test_future_exception
    p = TestExceptionMixin()
    @p.exception(test_future_exception)
    def test():
        pass
    test()
    assert p._future_exceptions == test_future_exceptions
    p = TestExceptionMixin()
    @p.exception(test_future_exception, apply = False)
    def test():
        pass
    test()
    assert p._future_ex

# Generated at 2022-06-24 04:07:11.376330
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('bp')
    try:
        bp.exception()
    except TypeError as e:
        assert str(e) == 'Exception handler is not callable'
    else:
        assert False, "exception() didn't find unexcepted argument"

    try:
        bp.exception(TypeError)("String is not callable")
    except TypeError as e:
        assert str(e) == 'Exception handler is not callable'
    else:
        assert False, "exception() didn't find unexcepted argument"

    #
    # Test expected behavior
    #
    @bp.exception(TypeError)
    def handler():
        pass

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:07:11.857120
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:07:15.604510
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:21.349630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):

        def __init__(self):
            super().__init__()

        # method to apply exception handler
        def _apply_exception_handler(self, handler: FutureException):
            assert True

    test = Test()
    test.exception()

# Generated at 2022-06-24 04:07:32.260706
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_exception(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = ExceptionMixin_exception()
    assert type(a.exception()) == types.FunctionType
    assert len(a._future_exceptions) == 0

    def test_exception():
        pass

    a.exception(Exception)(test_exception)
    assert len(a._future_exceptions) == 1
    assert len(a._future_exceptions.pop().exceptions) == 1
    assert set(['Exception']).issubset(set(dir(Exception)))

    def test_exception2(request):
        pass

    a.exception(NotImplementedError, Exception)(test_exception2)

# Generated at 2022-06-24 04:07:34.830581
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    pass

# Generated at 2022-06-24 04:07:40.307662
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint('bp', url_prefix='/bp')

    async def handler(request, exception):
        return exception

    @bp.exception(Exception)
    def catch_errors(request, exception):
        return exception

    app = Sanic('test_blueprint_exception')
    bp.register(app, url_prefix='/bp')

    @app.route('/test')
    async def index(request):
        raise ValueError

    request, response = app.test_client.get('/test')
    assert response.status == 500

    @app.exception(Exception)
    async def handler(request, exception):
        return exception

    request, response = app.test_client.get('/test')

# Generated at 2022-06-24 04:07:44.111620
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic

    app = Sanic()
    excm = ExceptionMixin(app)
    assert excm._future_exceptions == set()


# Generated at 2022-06-24 04:07:46.231672
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions is not None
    assert type(obj._future_exceptions) is set


# Generated at 2022-06-24 04:07:49.059741
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert type(exception_mixin) == ExceptionMixin
    assert type(exception_mixin._future_exceptions) == set


# Generated at 2022-06-24 04:07:49.576516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:07:58.490943
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint('test_bp')

    # test non-list type
    assert_raises(
        Exception,
        lambda: bp.exception(list))

    # test apply=True
    @bp.exception(Exception, apply=True)
    def test_handler():
        pass

    # test apply=False
    @bp.exception(Exception, apply=False)
    def test_handler2():
        pass

    # test value error
    assert_raises(
        ValueError,
        lambda: bp.exception(Exception()))

    # test type error
    assert_raises(
        TypeError,
        lambda: bp.exception(None))

# Generated at 2022-06-24 04:08:07.050394
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import exception

    class Dummy(ExceptionMixin):
        pass

    dummy = Dummy()
    assert dummy._future_exceptions == set()

    @dummy.exception(ValueError)
    def handler(request, exception):
        pass

    assert len(dummy._future_exceptions) == 1
    assert dummy._future_exceptions.pop() == exception(handler, (ValueError,))

    @dummy.exception(ValueError, apply=False)
    def handler(request, exception):
        pass

    assert len(dummy._future_exceptions) == 1
    assert dummy._future_exceptions.pop() == exception(handler, (ValueError,))


# Generated at 2022-06-24 04:08:14.864103
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # GIVEN
    class MyMock(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._apply_exception_handler = Mock()

    mock = MyMock()

    # WHEN
    @mock.exception(StandardError)
    def a_raise(*args, **kwargs):
        raise StandardError('Boom!')

    # THEN
    assert len(mock._future_exceptions) == 1
    assert mock._apply_exception_handler.called



# Generated at 2022-06-24 04:08:17.104331
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc
    assert isinstance(exc, ExceptionMixin)
    assert isinstance(exc._future_exceptions, Set)


# Generated at 2022-06-24 04:08:17.642030
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-24 04:08:18.743444
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert(em._future_exceptions == set())

# Generated at 2022-06-24 04:08:28.850655
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import mock

    from sanic.exceptions import SanicException

    from .utils import MockRequest

    class CustomError(SanicException):
        pass

    class ExceptionMixinTest(ExceptionMixin):
        @property
        def routes(self):
            return {MockRequest(path="/"): None}

        @property
        def _error_handler(self):
            return "mock_error_handler"

        def exception_handler(self, request, exception):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handler = handler.handler

    exception_mixin_test = ExceptionMixinTest()


# Generated at 2022-06-24 04:08:36.617102
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('app')
    bp = Blueprint('bp')

    @bp.exception(Exception)
    def bp_exception_handler(request, exception):
        assert request == 'request'
        assert exception == 'exception'
        return 'bp_exception_handler'

    @app.exception(ZeroDivisionError)
    def app_exception_handler(request, exception):
        assert request == 'request'
        assert exception == 'exception'
        return 'app_exception_handler'

    bp_matched_handler, app_matched_handler = bp._find_exception_handler(Exception)
    assert bp_matched_handler('request', 'exception') == 'bp_exception_handler'

    app_

# Generated at 2022-06-24 04:08:40.105924
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
   """
   Testing the constructor of class ExceptionMixin
   :return:
   """
   em = ExceptionMixin()
   assert len(em._future_exceptions)==0
   assert type(em._future_exceptions)==set

# Generated at 2022-06-24 04:08:48.731661
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic.blueprints import Blueprint

    bp = Blueprint('test_exception', url_prefix='test_exception')

    # Catchall Exception
    @bp.exception
    def handle_exception(request, exception):
        assert isinstance(request, Request.__class__)
        assert isinstance(exception, Exception)

    # Exception Handler
    @bp.exception(Exception, apply=True)
    def handle_exception(request, exception):
        pass

    # Exception Handler with args
    @bp.exception(Exception, apply=True, exception_arg='test')
    def handle_exception_args(request, exception, exception_arg):
        assert exception_arg == 'test'

    # Exception Handler with mixed args and kwargs

# Generated at 2022-06-24 04:08:55.999393
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()
            self.test_future_exceptions = self._future_exceptions

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @TestExceptionMixin().exception(1)
    def test(handler):
        return handler
    

    future_exception = FutureException(test, (1,))
    assert future_exception in TestExceptionMixin().test_future_exceptions

# Generated at 2022-06-24 04:09:05.259782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic.blueprints
    import sanic.request
    import sanic.response
    import sanic.router

    class HandleRequest(sanic.response.HTTPResponse):
        def __init__(self, request):
            super().__init__(status=200, text="hello world")

        def text(self):
            return self.body

    class HandleRequestTest(sanic.blueprints.Blueprint):
        url_prefix = "test"

        def __init__(self):
            super().__init__(url_prefix=self.url_prefix)
            self.add_route(self.handle_request, 'test', methods=['GET', 'POST'])

        async def handle_request(self, request):
            return HandleRequest(request)


# Generated at 2022-06-24 04:09:13.746113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.server import HttpProtocol

    # type: (ExceptionMixin, Request, HTTPResponse) -> HTTPResponse

    @Blueprint.exception(ZeroDivisionError)
    def handler():
        return HTTPResponse("test")

    blueprint = Blueprint("test", url_prefix="/test")

    blueprint.add_route(CompositionView(), "/test")

    http_protocol = HttpProtocol(None, None, None, None)


# Generated at 2022-06-24 04:09:22.154756
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol

    blueprint = Blueprint(__name__, url_prefix="", strict_slashes=True)
    ws_protocol = WebSocketProtocol()
    ws_protocol.blueprint = blueprint

    @blueprint.exception(TypeError, NameError)
    @ws_protocol.exception(TypeError, NameError)
    def default_handler(request, exception):
        return text("You hit a {}".format(exception))

    assert len(blueprint._future_exceptions) == 1
    assert len(ws_protocol._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:09:23.994771
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint

    bp = Blueprint("test", url_prefix="test")
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:09:33.431378
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args):
            super(MyExceptionMixin, self).__init__(*args)
        def _apply_exception_handler(self, handler):
            pass
    class MyBlueprint(MyExceptionMixin):
        def __init__(self):
            super(MyBlueprint, self).__init__()
    my_blueprint = MyBlueprint()
    @my_blueprint.exception(ValueError, KeyError)
    def handler():
        pass
    assert len(my_blueprint._future_exceptions) == 1
    assert my_blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-24 04:09:34.095040
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
	pass

# Generated at 2022-06-24 04:09:44.577232
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.blueprints import Route
    bp = Blueprint("test_bp")
    assert bp._future_exceptions == set()
    assert bp._blueprint_name == "test_bp"
    assert bp._host == None
    assert bp._host_matching == False
    assert bp._url_prefix == None
    assert bp._strict_slashes == False
    assert bp._routes == []
    assert bp._routes_names == {}
    assert bp._routes_all == {}
    assert bp._routes_filters == {}
    assert bp._routes_frozen == False
    assert bp._routes_exception_handlers == {}
    assert bp._routes_global

# Generated at 2022-06-24 04:09:52.056811
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            ExceptionMixin.__init__(self, *args, **kwargs)
    emm = ExceptionMixinMock(1, 2, 3, 4, f='f', g='g')
    assert emm.args == (1, 2, 3, 4)
    assert emm.kwargs == {'f': 'f', 'g': 'g'}
    assert len(emm._future_exceptions) == 0


# Generated at 2022-06-24 04:09:52.637876
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-24 04:09:58.510860
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #test paramerter is not list
    excpetion_list = [TypeError, ValueError]
    exception_mixin = ExceptionMixin(excpetion_list)
    handler = exception_mixin.exception(TypeError, ValueError)
    result = exception_mixin._future_exceptions
    assert result == {handler}
    #test paramerter is list
    exception_mixin = ExceptionMixin([TypeError, ValueError])
    handler = exception_mixin.exception(TypeError, ValueError)
    result = exception_mixin._future_exceptions
    assert result == {handler}

# Generated at 2022-06-24 04:10:00.556161
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert isinstance(e._future_exceptions, set)

# Generated at 2022-06-24 04:10:03.780552
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MExceptionMixin(ExceptionMixin):
        pass
    
    exception_mixin = MExceptionMixin()
    assert isinstance(exception_mixin, MExceptionMixin)

# Generated at 2022-06-24 04:10:06.085847
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    parent = ExceptionMixin()
    assert not hasattr(parent,'_future_exceptions')
# unit test for factory function decorator of method exception

# Generated at 2022-06-24 04:10:09.177519
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    bp = Blueprint(__name__)
    assert not bp._future_exceptions
    assert bp.__init__

# Generated at 2022-06-24 04:10:19.774378
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    exception_mixin = MyExceptionMixin()
    # test ExceptionMixin with one  args
    @exception_mixin.exception(Exception)
    def test_ExceptionMixin_exception():
        assert True
    test_ExceptionMixin_exception()
    # test ExceptionMixin with more then one args
    @exception_mixin.exception(Exception, IndexError)
    def test_ExceptionMixin_exception():
        assert True
    test_ExceptionMixin_exception()
    # test ExceptionMixin without apply
    @exception_mixin.exception(Exception, apply=False)
    def test_ExceptionMixin_exception():
        assert True
    test

# Generated at 2022-06-24 04:10:25.327571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Base(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    base = Base()
    @base.exception(exceptions=(ValueError,))
    def test_handler():
        pass

    assert hasattr(base, '_future_exceptions')
    assert len(base._future_exceptions) == 1
    assert type(base._future_exceptions.pop()) is FutureException
    assert test_handler() is None


# Generated at 2022-06-24 04:10:31.200940
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixinInit(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    obj = TestExceptionMixinInit()
    assert isinstance(obj, ExceptionMixin)
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:10:32.962542
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m._future_exceptions == set()


# Generated at 2022-06-24 04:10:36.566661
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Object(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    
    obj = Object()
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:10:46.466103
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import text
    # create an ExceptionMixin object 
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    a = A()
    # create a handler to handle exceptions
    def handler(request, exception):
        return text('Internal server error', 500)
    # create a future exception
    future_exception = FutureException(handler, ())
    # assert that a is empty before adding a future exception
    assert set() == a._future_exceptions
    # assert that a returns the result of calling handler when calling
    # _apply_exception_handler with a future exception
    assert handler(None, None) == a._apply_exception_handler(future_exception)
    # assert that the set of future exceptions

# Generated at 2022-06-24 04:10:47.937774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(apply=True)
    def handle_error():
        return True

# Generated at 2022-06-24 04:10:57.481951
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

    bp = Blueprint('bp', url_prefix='/bp')

    @exception_mixin.exception(SanicException, apply=False)
    def handler(request, exception):
        return text('An exception occurred: {}'.format(exception))

    @bp.route('/')
    def home(request):
        raise SanicException("You're on your own!")

    assert handler.__name__ == 'handler'
    assert handler.__doc__ is None

# Generated at 2022-06-24 04:11:05.314155
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(apply=False)
    def test_exception_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert (test_exception_mixin._future_exceptions.pop() \
            .handler) == test_exception_handler

# Generated at 2022-06-24 04:11:06.605189
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()
    assert isinstance(x, ExceptionMixin)

# Generated at 2022-06-24 04:11:11.216601
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp')

    @bp.exception(Exception)
    def handler_test(request, exception):
        return str(exception)

    with pytest.raises(Exception) as exc_info:
        bp._apply_exception_handler(list(bp._future_exceptions)[0])

    assert exc_info.value.args[0] == 'Oops! Something went wrong'

# Generated at 2022-06-24 04:11:15.855890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints.blueprint import Blueprint

    blueprint = Blueprint(__name__, url_prefix='test')
    blueprint.exception(Exception)(lambda request, exception: print(exception))
    blueprint.exception(KeyError, ValueError, apply=False)(
        lambda request, exception: print(exception)
    )

    # we will test the case when their is exceptions added to blueprint
    # when blueprint is initialised
    blueprint_exceptions = blueprint._future_exceptions
    blueprint_registered_exception_1 = blueprint_exceptions.pop()
    blueprint_registered_exception_2 = blueprint_exceptions.pop()
    assert blueprint_registered_exception_1.exception is Exception
    assert blueprint_registered_exception_2.exception is (KeyError, ValueError)

# Generated at 2022-06-24 04:11:18.476333
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyClass(ExceptionMixin):
        pass
    inst = DummyClass()
    assert inst._future_exceptions == set()

# Generated at 2022-06-24 04:11:19.574064
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin

# Generated at 2022-06-24 04:11:20.825418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-24 04:11:25.210304
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(*args):
        pass
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test = TestExceptionMixin()
    test.exception(ValueError)(handler)
    assert len(test._future_exceptions) == 1

# Generated at 2022-06-24 04:11:34.697112
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    app = Sanic("test_ExceptionMixin_exception")

    class ExceptionMixinImplementation(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            app.exception(*handler.args, **handler.kwargs)(handler.handler)

    exceptions_mixin_implementation = ExceptionMixinImplementation()

    exceptions_mixin_implementation.exception([Exception])(
        lambda e: "Exception {}".format(e)
    )

    @app.route("/")
    async def test(request):
        raise Exception

    request, response = app.test_client.get("/")

    assert response.status == 500
    assert response.text == "Exception {}".format(Exception)



# Generated at 2022-06-24 04:11:41.681853
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    test_ExceptionMixin_exception is a unit test of ExceptionMixin class
    
    :return: None
    """
    from unittest.mock import Mock
    test_class = ExceptionMixin(args=None)
    test_class._future_exceptions = set()
    test_class._apply_exception_handler = Mock()
    test_class.exception(Exception)(lambda: None)
    # assert test_class._future_exceptions
    # assert test_class._apply_exception_handler
    # assert 
    print(test_class._future_exceptions, test_class._apply_exception_handler)

# Generated at 2022-06-24 04:11:48.783310
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create an instance of class ExceptionMixin
    self = ExceptionMixin()

    # Set attribute of the class
    self._future_exceptions = set()

    # Create a variable for holding a future exception
    future_exception = FutureException(None, None)

    # Set attribute of the class
    self._future_exceptions.add(future_exception)
    self._apply_exception_handler(future_exception)

    # Call method exception of class ExceptionMixin
    self.exception()

# Generated at 2022-06-24 04:11:56.481777
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    app = Sanic()

    bp = Blueprint('authorize')

    @bp.exception(Exception)
    def on_server_error(request, exception):
        return 'Something wrong'

    app.blueprint(bp)

    assert app.exception_handler.handlers == {Exception: on_server_error}

# Generated at 2022-06-24 04:12:06.654084
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a fake object
    class FakeServer(ExceptionMixin):
        def __init__(self):
            super(FakeServer, self).__init__()

    # create a fake application
    app = FakeServer()

    # create a sample handler for the exception
    def handler(request, exception):
        pass

    # assertion for the broken code
    assert next((FutureException(handler, (IndexError,))), None) is None

    # create a future exception for the application
    FutureException(handler, (IndexError,))
    FutureException(handler, (AttributeError,))

    # assertion for the future exception
    assert len(app._future_exceptions) == 2

    # assertion for the future exception in the set
    assert next((FutureException(handler, (AttributeError,))), None) is not None

# Generated at 2022-06-24 04:12:08.836179
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception()
    def foo(e):
        print(f'foo with exception: {e}')

    ExceptionMixin.exception(apply=False)(foo)(Exception('test'))

# Generated at 2022-06-24 04:12:12.844756
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = TestExceptionMixin()
    assert isinstance(test._future_exceptions, set)

# Generated at 2022-06-24 04:12:20.574553
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinDerived(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.added_handler = False

        def _apply_exception_handler(self, handler):
            self.added_handler = True
    exception_mixin = ExceptionMixinDerived()

    @exception_mixin.exception(ZeroDivisionError)
    def handler_zero_division(request, exception):
        pass

    assert(exception_mixin.added_handler)

# Generated at 2022-06-24 04:12:22.278453
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a

# Unittest for method apply_exception_handler

# Generated at 2022-06-24 04:12:24.237417
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc = ExceptionMixin()
    exc.exception(Exception, apply=True)("handler")
    print(exc._future_exceptions)


# Generated at 2022-06-24 04:12:25.811882
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc
    # __repr__ can't be tested here

# Generated at 2022-06-24 04:12:29.046710
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.mocks import MockRequest, MockResponse

    obj = ExceptionMixin()
    assert obj._future_exceptions == set()
    assert obj.exception is not None
    assert obj._apply_exception_handler is not None
    assert obj.exception is not None

# Generated at 2022-06-24 04:12:29.687978
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:12:34.708961
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    t_ExceptionMixin = TExceptionMixin()
    @t_ExceptionMixin.exception(RuntimeError)
    def test_handler(arg1, arg2):
        pass
    assert len(t_ExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-24 04:12:40.426406
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # constructor normal
    class ExceptionMixin:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    assert type(ExceptionMixin) == object
    assert type(ExceptionMixin) is not None
    assert type(ExceptionMixin) is ExceptionMixin


# Generated at 2022-06-24 04:12:43.841686
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()
    assert isinstance(test_exception_mixin._future_exceptions, set)



# Generated at 2022-06-24 04:12:51.969820
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # # Arrange
    # create object
    class StubExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    stub_test = StubExceptionMixin()
    # # act
    # Unit test for method exception of class ExceptionMixin
    def test_ExceptionMixin_exception():
        # # Arrange
        # create object
        class StubExceptionMixin(ExceptionMixin):
            def __init__(self, *args, **kwargs):
                super().__init__(self, *args, **kwargs)

            def _apply_exception_handler(self, handler):
                pass

        stub_test = StubExceptionMixin()

# Generated at 2022-06-24 04:12:58.382845
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.handler_called = False
        def _apply_exception_handler(self, handler: FutureException):
            self.handler_called = True
    test = Test()
    @test.exception(Exception)
    def handler(request, exception):
        pass
    assert test.handler_called == True
    

# Generated at 2022-06-24 04:13:07.484404
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    exception_mixin_test = ExceptionMixinTest()

    @exception_mixin_test.exception(Exception, ValueError)
    def errorhandler(request, exception):
        return text('An exception has been raised')

    for future_exception in exception_mixin_test._future_exceptions:
        assert future_exception.handler == errorhandler
        for exception in future_exception.exceptions:
            assert exception in (Exception, ValueError)

# Generated at 2022-06-24 04:13:14.472938
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    import pytest
    app = Sanic("test_ExceptionMixin_exception")
    blueprint = Blueprint("test_ExceptionMixin_exception")
    test_ExceptionMixin_exception = ExceptionMixin()
    test_ExceptionMixin_exception.blueprint = blueprint
    test_ExceptionMixin_exception.app = app
    try:
        @test_ExceptionMixin_exception.exception(Exception)
        def handler(request, exception):
            assert(exception == "test")
        handler("test")
    except TypeError as e:
        pytest.fail("test_ExceptionMixin_exception::test failed with exception "
                    + str(e))

# Generated at 2022-06-24 04:13:25.007933
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test the case apply = True
    test_class = Mock(ExceptionMixin)
    test_class.__init__ = lambda self: None
    test_class._apply_exception_handler = lambda x: None
    test_exception = ExceptionMixin.exception(test_class)
    assert type(test_exception) == types.FunctionType
    test_exception(lambda: None)
    assert True

    # Test the case apply = False
    test_class = Mock(ExceptionMixin)
    test_class.__init__ = lambda self: None
    test_class._apply_exception_handler = lambda x: None
    test_exception = ExceptionMixin.exception(test_class, apply=False)
    assert type(test_exception) == types.FunctionType
    test_exception(lambda: None)

# Generated at 2022-06-24 04:13:27.879430
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    TestExceptionMixin()


# Generated at 2022-06-24 04:13:33.770201
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BluePrint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

        def _get_exception_handler(self):
            return self._future_exceptions

    @BluePrint.exception([BaseException, ValueError])
    async def handler(request, exception):
        pass

    bp = BluePrint()
    bp._apply_exception_handler(FutureException(handler,[BaseException, ValueError]))
    assert len(bp._get_exception_handler()) == 1



# Generated at 2022-06-24 04:13:44.333310
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bp(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()
            self._exception_handlers = set()
            self._error_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            nonlocal apply_exception_handler
            apply_exception_handler = handler

        @ExceptionMixin.exception(1, apply=False)
        def handler_no_apply(self, *args, **kwargs):
            pass

        @ExceptionMixin.exception([1, 2], apply=True)
        def handler_apply(self, *args, **kwargs):
            pass

    bp = Bp()
    assert len(bp._future_exceptions) == 2

# Generated at 2022-06-24 04:13:47.339411
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import ExceptionMixin as exc_mix
    em = exc_mix()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:13:50.466709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    instance = TestExceptionMixin()
    instance.exception(ValueError)
    assert len(instance._future_exceptions) == 1

# Generated at 2022-06-24 04:14:00.452109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class Test_ExceptionMixin(ExceptionMixin):

        def __init__(self, *args, **kwargs) -> None:
            super(Test_ExceptionMixin, self).__init__()
            self.test_result = False

        def _apply_exception_handler(self, handler):
            self.test_result = True

    test_ExceptionMixin = Test_ExceptionMixin()
    test_ExceptionMixin.exception(Exception)(lambda: None)
    assert test_ExceptionMixin.test_result == True
    assert len(test_ExceptionMixin._future_exceptions) == 1
    assert isinstance(test_ExceptionMixin._future_exceptions.pop(), FutureException)
    test_ExceptionMixin.exception(Exception, apply=False)(lambda: None)

# Generated at 2022-06-24 04:14:02.122634
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        em = ExceptionMixin()
        em.exception(ValueError)
        em.exception(Exception)
    except Exception as e:
        raise AssertionError(f'Unexpected exception {str(e)}')

# Generated at 2022-06-24 04:14:03.466696
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:14:08.477384
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('exception_test_mixin')
    blueprint.exception(OSError)(None)
    blueprint_exception = blueprint.get_future_exceptions()[0]
    assert blueprint_exception.exception == (OSError,)


# Generated at 2022-06-24 04:14:18.534611
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a class which inherits from ExceptionMixin
    # and has no implementation of method _apply_exception_handler()
    class _Example(_SanicBlueprint, ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(_Example, self).__init__(*args, **kwargs)

    example=_Example("test")

    @example.get("/test")
    def test(request):
        return text("test")

    # create a global exception handler
    @example.exception([IndexError])
    def error_handler(request, exception):
        return response.text("Dies ist ein Fehler", 500)

    # create a request

# Generated at 2022-06-24 04:14:24.834498
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint()
    blueprint.exception(ValueError)(print)
    blueprint.exception(TypeError, KeyError, apply=False)(print)
    blueprint.exception(NameError, apply=False)(print)
    assert len(blueprint._future_exceptions) == 3

# Generated at 2022-06-24 04:14:28.645164
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin is not None
    assert exception_mixin._future_exceptions is not None

# Generated at 2022-06-24 04:14:38.316195
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class AException(Exception):
        pass

    class BException(Exception):
        pass

    class CException(Exception):
        pass

    def handler(*args, **kwargs):
        pass

    class A:
        def __init__(self):
            self.__apply_exception_handler = False

        def _apply_exception_handler(self, handler: FutureException):
            assert handler._old_handler == handler
            assert handler.args == (AException, BException)
            self.__apply_exception_handler = True

    a = A()
    a.__dict__.update(ExceptionMixin().__dict__)
    assert a._future_exceptions == set()
    assert a.__apply_exception_handler == False

    # Apply decorator
    a.exception(AException, BException)(handler)

# Generated at 2022-06-24 04:14:44.925132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

            self._future_exceptions = [FutureException(ZeroDivisionError, ZeroDivisionError)]
            self.args = args
            self.kwargs = kwargs

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_ExceptionMixin = TestExceptionMixin()
    test_ExceptionMixin.exception(KeyError, apply=True)(KeyError)

# Generated at 2022-06-24 04:14:49.665373
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage
    from sanic.response import text
    from types import MethodType
    # Create an instance of the class
    blueprint = Blueprint(__name__, url_prefix='/v1')

    @blueprint.exception(InvalidUsage)
    def custom_error_handler(request, exception):
        return text(str(exception), status=400)
    assert isinstance(blueprint, ExceptionMixin)

# Generated at 2022-06-24 04:15:00.293905
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin:
        def __init__(self):
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler: FutureException):
            pass
    ins = TestExceptionMixin()
    ins = ExceptionMixin.__init__(ins)
    class TestException:
        def __init__(self):
            pass
        def test(self):
            return 1
    excp = TestException.__init__(TestException)

    @ins.exception(excp)
    def test(request: Request, exc: excp):
        return "test"
    print(test('', ''))
    assert 'test'==test('', '')

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:15:07.607344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock

    blueprint_mock = Mock()
    blueprint_mock.name = 'test_blueprint'

    arg_mock = Mock()
    arg_mock.__name__ = 'test_function'

    exception_mixin = ExceptionMixin()
    exception_mixin.add_exception_handler = Mock()

    exception_handler = exception_mixin.exception(ValueError)(arg_mock)
    exception_handler(blueprint_mock, None, lambda: None)

    assert exception_mixin.add_exception_handler.mock.called

# Generated at 2022-06-24 04:15:11.989334
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        mixin = ExceptionMixin()
        if type(mixin) == ExceptionMixin:
            assert True
        else:
            assert False
    except AssertionError:
        raise AssertionError("Expected True, but got False")
    except Exception:
        raise AssertionError("Expected True, but got error")


# Generated at 2022-06-24 04:15:20.360864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import unittest.mock
    mock_handler = unittest.mock.MagicMock()
    mock_future_exception = unittest.mock.MagicMock()
    mixin = ExceptionMixin()
    mixin._apply_exception_handler = unittest.mock.MagicMock()
    return_value = mixin.exception(mock_handler)
    return_value()
    mixin._apply_exception_handler.assert_called_once_with(
        mock_future_exception)
    return True


# Generated at 2022-06-24 04:15:23.514616
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass
    b = Blueprint()
    @b.exception(Exception)
    def handle(request, exception):
        pass
    assert len(b._future_exceptions) == 1

# Generated at 2022-06-24 04:15:27.115767
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    assert ExceptionMixinTest._future_exceptions == set()

# Generated at 2022-06-24 04:15:31.166630
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            # do nothing
            pass

    assert TestExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-24 04:15:33.983211
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    Exception mixin for blueprint and route.
    """
    exception_mixin = ExceptionMixin()
    expected_result = set()
    assert exception_mixin._future_exceptions == expected_result



# Generated at 2022-06-24 04:15:45.943489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MySanic(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(MySanic, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass
        
        # Unit test for method exception of class MySanic
        def test_MySanic__apply_exception_handler(self):
            try:
                assert 0
            except:
                raise AssertionError("AssertionError")


    @mock.patch('sanic.models.futures.FutureException')
    def test_exception(sanic_app, FutureException_mock):
        sanic_app.Sanic(MySanic)

# Generated at 2022-06-24 04:15:51.992232
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Mock Class
    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(args, kwargs)
            self.called = False
            self.apply = False

        def _apply_exception_handler(self, handler: FutureException):
            self.called = True
            self.apply = True

    obj = ExceptionMixinMock()
    obj.exception(apply=True)

    assert obj.called
    assert obj.apply