

# Generated at 2022-06-24 04:05:58.124983
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    class MockBlueprint(Blueprint, ExceptionMixin):
        pass

    app = Sanic("test_ExceptionMixin")
    blueprint = MockBlueprint("test_ExceptionMixin", url_prefix="/test")

    assert(not blueprint._future_exceptions)

    @blueprint.exception(Exception)
    async def handler():
        pass

    assert(blueprint._future_exceptions)
    assert(len(blueprint._future_exceptions) == 1)
    assert(blueprint._future_exceptions.pop().handler == handler)



# Generated at 2022-06-24 04:06:03.865972
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)

    test = ExceptionMixinTest()

    expected_exception = FutureException(lambda request,exception: None, Exception)
    @test.exception(Exception)
    def handler():
        return None
    
    assert expected_exception in test._future_exceptions
    assert expected_exception.handler == handler

# Generated at 2022-06-24 04:06:09.457580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test", url_prefix="/test")

# Generated at 2022-06-24 04:06:11.826566
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin._future_exceptions, set)

# Generated at 2022-06-24 04:06:12.886304
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:06:23.976676
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a blueprint
    blueprint = Blueprint(__name__, url_prefix='/blueprint')

    # Create a decorator
    decorator = blueprint.exception(404, apply=True)

    # Create a view
    @blueprint.route('/test-view/')
    @decorator
    async def view(request):
        pass

    # Generate test Sanic app
    sanic_app = Sanic('test_ExceptionMixin_exception')
    sanic_app.blueprint(blueprint)

    # Test if the decorator is set properly
    assert decorator

    # Test if the view is registered properly
    assert sanic_app.router.routes_all['GET'][0][2] is view

    # Test if the exception handler is set properly

# Generated at 2022-06-24 04:06:31.287910
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol

    bp = Blueprint('simple_exception', url_prefix='exceptions', version=1)

    @bp.exception(ZeroDivisionError)
    def zero_division_handler(request, exception):
        return text('You tried to divide by zero!', 400)

    assert len(bp._future_exceptions) == 1

    @bp.route('/test')
    async def handler(request):
        return text('I am a teapot', 418)

    app = Sanic('test_ExceptionMixin_exception')
    bp.register(app, route=app.add_route)

    request, response = app.test_client.get('/exceptions/test')
    assert response.status == 418

    request, response

# Generated at 2022-06-24 04:06:33.925930
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_blueprint", url_prefix="/test")
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:06:44.270157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    app = Sanic(__name__)

    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__)
    blueprint.exception(ZeroDivisionError)((lambda request: print('Thanks')))

    @app.exception(ZeroDivisionError)
    def error_handler(request, exception):
        print('got it')
        return response.text('ZeroDivisionError')

    @app.route('/')
    def handler(request):
        return 1 / 0

    blueprint._apply_exception_handler(blueprint._future_exceptions.pop())

    app.blueprint(blueprint)
    app.run()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:06:47.830411
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """Test for the initialisation of the SANIC class."""
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:06:55.744482
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    bp = Blueprint("bp")
    app = Sanic(__name__)

    @bp.exception(Exception)
    def handler(request, exception):
        return "OK"

    @bp.route("/")
    async def test_exception(request):
        raise Exception

    # for issue #2536
    app.blueprint(bp)
    assert bp._apply_exception_handler(bp._future_exceptions.pop()) is None

    with app.test_client() as client:
        response = client.get("/")
        assert response.text == "OK"

# Generated at 2022-06-24 04:07:01.273272
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Tests whether blueprint may attach exceptions to itself"""

    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @Blueprint.exception(Exception)
    def handler(*args):
        pass

    assert len(Blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:07:10.393517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()

            self._future_exceptions: Set[FutureException] = set()
            self._future_exceptions.add(future_exception)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    def _apply_exception_handler(self, handler: FutureException):
        raise NotImplementedError  # noqa

    testclass = TestClass()

    @testclass.exception(Exception)
    def function(handler):
        return handler

    func = function(None)



# Generated at 2022-06-24 04:07:20.693035
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic:
        def add_exception_handler(self, handler, *args):
            # Sanic._add_exception_handler = handler
            print(handler)

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, sanic):
            super().__init__()
            self.sanic = sanic

        def _apply_exception_handler(self, handler):
            self.sanic.add_exception_handler(handler, *handler.exceptions)

    t = TestExceptionMixin(Sanic())

    @t.exception(ValueError)
    def throw_error(request, exception):
        print(exception, request)

    print(t._future_exceptions)

# Generated at 2022-06-24 04:07:24.892134
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exception_mixin = TestExceptionMixin()
    exception_mixin.exception(Exception)
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop().handler == Exception

# Generated at 2022-06-24 04:07:27.207706
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)



# Generated at 2022-06-24 04:07:31.911868
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # This is how we create a new class
    class ExceptionMixinTest(ExceptionMixin):
        pass

    # We use the __init__ method of ExceptionMixin
    exception_mixin = ExceptionMixinTest()

    # As result, the variables is empty
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:38.445749
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic import Blueprint, Sanic
    from unittest.mock import MagicMock

    app = Sanic('test_exception')
    blueprint = Blueprint('test_exception', url_prefix='test')
    blueprint._apply_exception_handler = MagicMock()

    @blueprint.exception(Exception)
    async def handler(request, exception):
        pass

    blueprint.exception(Exception, apply=False)(handler)


    assert blueprint._future_exceptions is not None
    assert len(blueprint._future_exceptions) == 2

# Generated at 2022-06-24 04:07:43.078802
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ClassUnderTest(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    c = ClassUnderTest()
    assert isinstance(c._future_exceptions, set)


# Generated at 2022-06-24 04:07:45.852012
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # new object from class
    obj1 = ExceptionMixin()
    # check object has been created or not
    assert obj1 is not None


# Generated at 2022-06-24 04:07:51.749120
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExampleExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    with pytest.raises(TypeError):
        ExampleExceptionMixin().exception(1,2)(print)

    with pytest.raises(NotImplementedError):
        ExampleExceptionMixin().exception(ValueError)(print)

# Generated at 2022-06-24 04:07:54.091999
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('exception_blueprint', url_prefix='/exception_blueprint')
    assert blueprint._future_exceptions


# Generated at 2022-06-24 04:07:57.162664
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint()

    @bp.exception(Exception)
    def exception_handler(request, exception):
        return "exception_handler"

    assert len(bp._future_exceptions) == 1
    exception_handler(None, ValueError)

# Generated at 2022-06-24 04:08:05.146241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    app = Sanic('test_ExceptionMixin_exception')

    class testExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    mixin = testExceptionMixin()
    exception_handler = mixin.exception(ValueError, apply=False)
    @exception_handler
    def test():
        raise ValueError('test_exception')
    app.exception(ValueError)(test)

    with pytest.raises(ValueError):
        app.test_client.get('/')

# Generated at 2022-06-24 04:08:08.670421
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # given
    exceptmix = ExceptionMixin()
    # then
    assert len(exceptmix._future_exceptions) == 0


# Generated at 2022-06-24 04:08:10.422262
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    data = ExceptionMixin()
    assert data._future_exceptions is not None
    # TODO assert true for data._future_exceptions



# Generated at 2022-06-24 04:08:11.866023
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert ex._future_exceptions is not None


# Generated at 2022-06-24 04:08:12.830038
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m

# Generated at 2022-06-24 04:08:14.126766
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    interface = ExceptionMixin()

    assert isinstance(interface, ExceptionMixin)

# Generated at 2022-06-24 04:08:17.984245
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = (ZeroDivisionError,)
    apply = True
    handler = lambda: None
    
    exception_mixin = ExceptionMixin()
    assert len(exception_mixin._future_exceptions) == 0
    exception_mixin.exception()(handler)
    assert len(exception_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:08:20.727625
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    test_class = TestExceptionMixin()
    def f(exc):
        pass

    test_class.exception(Exception)(f)

# Generated at 2022-06-24 04:08:24.405819
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # give the test an instance of ExceptionMixin, which will not fail
    exception_mixin = ExceptionMixin()

    # make sure the constructor of ExceptionMixin is empty, and thus does not fail
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:08:29.399573
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class MyException(Exception):
        pass

    class Blueprint(ExceptionMixin):
        pass

    @Blueprint.exception(MyException)
    def handler(request, exception):
        return exception

    blueprint = Blueprint()
    assert isinstance(next(iter(blueprint._future_exceptions)), FutureException)



# Generated at 2022-06-24 04:08:30.777957
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test = ExceptionMixin("asdf")
    assert test._future_exceptions == set()



# Generated at 2022-06-24 04:08:33.198259
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:08:34.796550
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(), ExceptionMixin)


# Generated at 2022-06-24 04:08:44.599221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBP:
        def _apply_exception_handler(self, handler):
            fakeBP._apply_exception_handler = handler
            assert handler == future_exception

        def _route(self, handler, uri, methods=frozenset({'GET'})):
            fakeBP._route = handler
            assert methods == frozenset(('GET', 'POST', 'PUT'))
            assert uri == '/'

    class FakeBPApp:
        def exception(self, *exceptions, **options):
            fakeBPApp.exception = exceptions
            assert 'GET' in options['methods']

    fakeBP = FakeBP()
    fakeBPApp = FakeBPApp()
    bp = ExceptionMixin()
    bp.app = fakeBPApp

# Generated at 2022-06-24 04:08:52.578674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)

    foo = Foo()
    @foo.exception(TypeError, apply=True)
    def handler(request, exception):
        return "ok"
    assert len(foo._future_exceptions) == 1
    assert len(foo._future_exceptions) == foo.get_future_exceptions()





# Generated at 2022-06-24 04:09:03.135874
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(MyClass, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handlers == (MyException1, MyException2)
            assert handler.exceptions == (MyException1, MyException2)
            assert handler.kwargs == {'arg1': 'test'}


    class MyException1(Exception):
        def __init__(self, *args, **kwargs):
            super.__init__(*args, **kwargs)


    class MyException2(Exception):
        def __init__(self, *args, **kwargs):
            super.__init__(*args, **kwargs)



# Generated at 2022-06-24 04:09:12.497670
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self):
            self.route = 5
            self.url_prefix = 'thong'
            self.name = 'vs'
            self.host = 'hong'
            self.static_folder = 'nam'
            self.template_folder = 'quynh'
        
        def register_route(self, handler, uri, methods, host=None):
            return 1

        def register_exception(self, handler, exception):
            return 2

        def _apply_exception_handler(self, handler):
            return 3

    @Blueprint.exception(BaseException)
    def handler(request, exception):
        return exception

    blueprint = Blueprint()
    # case 1: pass normal test
    assert blueprint.exception(BaseException)(handler) == handler
   

# Generated at 2022-06-24 04:09:15.165806
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SampleException(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
    a = SampleException()
    assert len(a._future_exceptions) == 0

# Generated at 2022-06-24 04:09:21.204328
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    ff = ExceptionMixin()
    assert len(ff._future_exceptions) == 0, 'the length of the set must be zero'

    @ff.exception(apply=True)
    def func(request, err):
        print(request, err)

    assert len(ff._future_exceptions) == 1, 'the length of the set must be one'


# Generated at 2022-06-24 04:09:22.894998
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert isinstance(a,ExceptionMixin)


# Generated at 2022-06-24 04:09:31.725820
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
    test = TestExceptionMixin()
    assert len(test._future_exceptions) == 0
    assert test.exception(None) is None
    assert len(test._future_exceptions) == 1
    assert test.exception(None) is None
    # test.exception(None, apply=False)
    # assert len(test._future_exceptions) == 2
    # test.exception(None)
    # assert len(test._future_exceptions) == 3
    # assert test.exception(None) is None
    # assert len(test._future_exceptions) == 4

# Generated at 2022-06-24 04:09:40.146537
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound
    from sanic.models.futures import FutureException

    class Resource(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Resource, self).__init__(*args, **kwargs)

    def exception_handler(request, exception):
        return exception.args[0]

    resource = Resource()
    resource.exception(NotFound)(exception_handler)

    assert resource._future_exceptions == set([FutureException(exception_handler, (NotFound,))])



# Generated at 2022-06-24 04:09:48.479094
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic.models.futures import FutureException

    function_1 = Mock()
    function_2 = Mock()
    function_3 = Mock()
    exceptions_1 = ('sanic.exceptions.NotFound',)
    exceptions_2 = ('sanic.exceptions.ServerError',)
    exceptions_3 = ('sanic.exceptions.FooError',)

    em = ExceptionMixin()
    em.exception(*exceptions_1)(function_1)
    em.exception(*exceptions_2)(function_2)
    em.exception(*exceptions_3)(function_3)

    assert len(em._future_exceptions) == 3
    assert all( isinstance(e, FutureException) for e in em._future_exceptions)


# Generated at 2022-06-24 04:09:58.455716
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import text
    from sanic.blueprints import Blueprint
    from sanic.models import URLSpec

    blueprint = Blueprint(__name__)

    #Test case for blueprint exception
    blueprint.exception(ValueError)(lambda request, exception: response.text(
        "Oops! I did it again."))

    #Test case for blueprint exception with list of exceptions
    blueprint.exception([AttributeError, KeyError])(lambda request, exception: response.text(
        "Oops! I did it again."))

    @blueprint.route("/")
    def handler(request):
        raise ValueError("Bad request!")

    app = Sanic(__name__)
    app.blueprint(blueprint)


# Generated at 2022-06-24 04:10:01.654937
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import sanic
    a=sanic.Blueprint('a',url_prefix='/')
    a.__init__()
    assert len(a._future_exceptions) == 0

# Generated at 2022-06-24 04:10:06.434805
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints.blueprint import Blueprint
    app = Blueprint.create_app('testing')
    TestingExceptionMixin = Blueprint('testing_ExceptionMixin', url_prefix='test')
    assert not hasattr(TestingExceptionMixin, '_future_exceptions')
    TestingExceptionMixin.init_app(app)
    assert TestingExceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:10:17.811153
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    define_route_header = (
        '@blueprint.route("/test", methods=["GET", "POST"])'
    )

    exception_mixin = ExceptionMixin()
    blueprint = Blueprint("some_name")
    blueprint._apply_exception_handler = Mock()
    blueprint.route = Mock()

    # Define a function to be exception handler
    def exception_handler(request, exception):
        pass

    # exception with default argument
    exception_mixin.exception(Exception)(exception_handler)
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert future_exception.handler == exception_handler
    assert future_exception.exceptions == (Exception,)

# Generated at 2022-06-24 04:10:20.772716
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from ...app.blueprints import Blueprint

    # test 1
    bp = Blueprint("test_sanic_bp_1", url_prefix="/test")
    assert type(bp._future_exceptions) is set


# Generated at 2022-06-24 04:10:23.867819
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    em = ExceptionMixin()
    assert em.exception is ExceptionMixin.exception
    assert em.exception.__name__ == 'exception'
    assert em.exception.__qualname__ == 'ExceptionMixin.exception'
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:10:27.131762
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print('\n')
    x = ExceptionMixin()
    assert x._future_exceptions == set()


# Generated at 2022-06-24 04:10:35.087438
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    @obj.exception(Exception)
    def my_handler():
        print("Hello world!!")
    assert isinstance(obj, ExceptionMixin) is True
    assert isinstance(obj._future_exceptions, set) is True
    assert type(obj._future_exceptions) is set
    assert isinstance(obj._future_exceptions.pop(), FutureException) is True
    assert type(obj._future_exceptions.pop()) is FutureException
    assert callable(obj._future_exceptions.pop().handler) is True

# Generated at 2022-06-24 04:10:37.246459
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test", url_prefix="/test")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:10:37.847896
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()

# Generated at 2022-06-24 04:10:46.674320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBlueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions = set()


    blueprint = FakeBlueprint()

    @blueprint.exception(ZeroDivisionError)
    def zero_division_handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    future_exception = list(blueprint._future_exceptions)[0]
    assert isinstance(future_exception, FutureException)
    assert future_exception.handler == zero_division_handler
    assert future_exception.exceptions == (ZeroDivisionError,)

# Generated at 2022-06-24 04:10:56.306716
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class Test(Blueprint):
        def _apply_exception_handler(self, handler: FutureException):
            True

        @exception()
        def test(self):
            raise SanicException

    app = Sanic('test')
    test = Test('test', url_prefix='/test')
    exception = test._future_exceptions.pop()
    assert exception.handler == test.test
    assert exception.exceptions == (SanicException,)

# Generated at 2022-06-24 04:10:57.904995
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def test_handler():
        return True

    assert test_handler() is True

# Generated at 2022-06-24 04:11:03.388688
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    instance = TestExceptionMixin()

    assert isinstance(instance, ExceptionMixin)
    assert isinstance(instance._future_exceptions, set)
    assert isinstance(instance._future_exceptions, Set)


# Generated at 2022-06-24 04:11:12.490278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass

    class MyException2(Exception):
        pass

    class MyException3(Exception):
        pass

    class MyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass


    my_class = MyClass()
    @my_class.exception(MyException)
    def my_handler(request, exception):
        pass

    assert len(my_class._future_exceptions) == 1
    assert isinstance(my_class._future_exceptions.pop(), FutureException)
    assert my_class._future_exceptions == set()

# Generated at 2022-06-24 04:11:15.487223
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:11:17.498226
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin

# Generated at 2022-06-24 04:11:19.248181
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        pass

    assert MyExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-24 04:11:26.282594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.exceptions import SanicException
    bp = ExceptionMixin()

    @bp.exception(exceptions=SanicException)
    def handler(request, exception):
        return 'exception handler'

    f = FutureException(handler, (SanicException,))
    assert bp._future_exceptions == {f}
    assert bp._apply_exception_handler.__name__ == '_apply_exception_handler'


# Generated at 2022-06-24 04:11:33.459800
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import sanic

    class myException(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler._handler, sanic.exceptions.ServerError)

    exception1 = myException()
    exception1.exception(sanic.exceptions.ServerError, apply=True)(sanic.exceptions.ServerError)

# Generated at 2022-06-24 04:11:37.578011
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    exception_set = blueprint._future_exceptions
    assert exception_set is not None

if __name__ == '__main__':
    test_ExceptionMixin()

# Generated at 2022-06-24 04:11:46.470316
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    def test_handler():
        return "test handler"

    testExceptionMixin_instance = testExceptionMixin()
    @testExceptionMixin_instance.exception(Exception)
    def test_handler():
        return "test handler"

    assert test_handler() == "test handler"
#

# Generated at 2022-06-24 04:11:49.952767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    test_mixin: ExceptionMixin = ExceptionMixin()

    # Act
    test_mixin.exception(Exception)

    # Assert
    assert len(test_mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:11:51.709548
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    class DummyClass(ExceptionMixin):
        pass

    @DummyClass.exception(Exception)
    def handler():
        pass

    dummy = DummyClass()
    assert dummy._future_exceptions

# Generated at 2022-06-24 04:12:00.545439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class FuturesMixin:
        def __init__(self) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class ExceptionMixin(FuturesMixin):
        def __init__(self) -> None:
            super().__init__()

        def exception(self, *exceptions, apply=True):
            #  Arrange
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions

                if isinstance(exceptions[0], list):
                    exceptions = tuple(*exceptions)

                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                if apply:
                    self._apply_exception

# Generated at 2022-06-24 04:12:04.587753
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exc_mixin = TestExceptionMixin()
    exc_mixin.exception(ValueError)(lambda request: 'ValueError')
    assert len(exc_mixin._future_exceptions)==1

# Generated at 2022-06-24 04:12:13.021841
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TempExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == 1
            assert handler.exceptions == (1,)

    t = TempExceptionMixin()
    t.exception(1)(1)
    assert len(t._future_exceptions) == 1
    assert t._future_exceptions.pop().handler == 1
    t.exception([1])(1)
    assert len(t._future_exceptions) == 1
    assert t._future_exceptions.pop().handler == 1

# Generated at 2022-06-24 04:12:22.442722
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin(object):
        def __init__(self,*args, **kwargs )->None:
            self._future_exceptions: Set[FutureException] = set()
            
        def _apply_exception_handler(self,handler:FutureException):
            raise NotImplementedError #noqa

    obj_exception_mixin = ExceptionMixin()
    vali_tuple = (1,2)
    vali_list = (1,2)
    handler = "s"
    result =  obj_exception_mixin.exception(vali_tuple,vali_list,apply=True)
    assert result(handler)

# Generated at 2022-06-24 04:12:26.105284
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # expect to run successfully:
    class MockExceptionMixin(ExceptionMixin):
        pass

    ex = MockExceptionMixin()
    ex.exception(Exception)
    
    # expect to run successfully:
    ex = MockExceptionMixin()
    ex.exception([Exception])


# Generated at 2022-06-24 04:12:29.331414
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception = TestExceptionMixin()
    assert test_exception._future_exceptions == set()



# Generated at 2022-06-24 04:12:36.884656
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Unit test for method exception of class ExceptionMixin"""
    class MyClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def handler():
        pass

    myClass = MyClass()
    assert handler == myClass.exception()(handler)

    myClass = MyClass()
    assert handler == myClass.exception('123')(handler)

    myClass = MyClass()
    assert handler == myClass.exception(('123', '234'))(handler)

    myClass = MyClass()
    assert handler == myClass.exception(('123', '234'), apply=False)(handler)

# Generated at 2022-06-24 04:12:41.627983
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    import sanic
    # Act
    exception_mixin = ExceptionMixin()
    # Assert
    assert isinstance(exception_mixin, sanic.models.futures.ExceptionMixin)
    assert exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:12:49.539108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class F:
        def f(self,
              *exceptions,
              apply=True):
            '''
            This method enables the process of creating a global exception
            handler for the current blueprint under question.
    
            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler
    
            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            '''
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions
    
                if isinstance(exceptions[0], list):
                    exceptions = tuple(*exceptions)
    
                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                if apply:
                    self._apply_

# Generated at 2022-06-24 04:12:53.642711
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # initialize a blueprint object
    blueprint = Blueprint(name="test", url_prefix='/v1')
    def test_error_handler():
        pass

    # call method exception
    blueprint.exception(test_error_handler())
    assert blueprint._future_exceptions

# Generated at 2022-06-24 04:12:57.734070
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        em = ExceptionMixin()
        print(em._future_exceptions)
    except Exception as e:
        print(e)


test_ExceptionMixin()

# Generated at 2022-06-24 04:13:01.629796
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class CustomException(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    blueprint_exception = CustomException()
    blueprint_exception.exception(Exception)(lambda x: True)
    assert len(blueprint_exception._future_exceptions) == 1

# Generated at 2022-06-24 04:13:05.908132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock

    class SUT(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    sut = SUT()
    # define the mock method
    m = MagicMock()
    # call the exception method with the mock method as argument
    sut.exception()(m)
    m.assert_called_once()

# Generated at 2022-06-24 04:13:07.809623
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-24 04:13:11.801894
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        class test(ExceptionMixin):
            def __init__(self, *args, **kwargs):
                self._future_exceptions: Set[FutureException] = set()

            def _apply_exception_handler(self, handler: FutureException):
                raise NotImplementedError  # noqa

# Generated at 2022-06-24 04:13:13.532624
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError, AttributeError)
    def handler():
        pass
    assert len(ExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-24 04:13:18.446233
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint(__name__, url_prefix='/abc')
    handler = ExceptionMixin.exception(
        blueprint, [
            TypeError, None, TypeError, None])
    assert handler(1) == 1
    assert type(handler) == function

# Generated at 2022-06-24 04:13:21.417937
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Base:
        pass

    class ExceptionMixinTest(ExceptionMixin, Base):
        pass

    assert isinstance(ExceptionMixinTest(), ExceptionMixin)
    assert isinstance(ExceptionMixinTest(), Base)

# Generated at 2022-06-24 04:13:23.452933
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyException(ExceptionMixin):
        def __init__():
            ExceptionMixin.__init__()
            # Rest of init

    MyException()

# Generated at 2022-06-24 04:13:28.210092
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mixin = TestExceptionMixin()
    assert isinstance(mixin, TestExceptionMixin)
    assert isinstance(mixin, ExceptionMixin)
    assert len(mixin._future_exceptions) == 0


# Generated at 2022-06-24 04:13:35.994862
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.views import HTTPMethodView

    # Create a blueprint
    bp = Blueprint('test', __name__, url_prefix='/test')

    # Define a custom exception
    class MyBaseException(BaseException):
        pass

    # Define a handler for the custom exception
    @bp.exception(MyBaseException)
    def foo(request, exception):
        return response.text('OK')

    # Declare a new instance of the HTTPMethodView
    class FooView(HTTPMethodView):
        def get(self, request):
            raise MyBaseException

    # Register the view with the blueprint
    bp.add_route(FooView.as_view(), '/foo')

    # Create a new instance of the sanic app
    app = Sanic

# Generated at 2022-06-24 04:13:37.534584
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e = ExceptionMixin()
    assert e._future_exceptions == set()

# Generated at 2022-06-24 04:13:40.209577
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test', url_prefix='/test')
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:13:43.446366
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = ExceptionMixin()
    blueprint.exception(KeyError, apply=True)(ExceptionMixin._apply_exception_handler)
    assert isinstance(blueprint._future_exceptions, set)

# Generated at 2022-06-24 04:13:47.594061
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    app = Sanic('test_ExceptionMixin')
    request, response = Mock(), Mock()

    #_future_exceptions should be empty
    assert len(app._future_exceptions) == 0



# Generated at 2022-06-24 04:13:50.996857
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    Create an instance of the ExceptionMixin class and check that the
    _future_exception set is empty
    """
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Unit tests for method exception

# Generated at 2022-06-24 04:13:56.664186
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ClassImplementedExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return 0
    object_test = ClassImplementedExceptionMixin()

# Generated at 2022-06-24 04:13:58.880011
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        pass

    instance = TestClass()
    assert isinstance(instance, ExceptionMixin)
    assert instance._future_exceptions == set()

# Generated at 2022-06-24 04:14:05.103950
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test", url_prefix="/test")
    assert bp.__class__.__name__ == 'Blueprint'

    # negative test: no any exception
    @bp.exception()
    def exception_handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 0

    # positive test: exceptions=None
    @bp.exception(exceptions=None)
    def exception_handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:14:09.273407
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    This unit test unit testing constructor of class ExceptionMixin.
    :return:
    """
    # print("Unit test for constructor of class ExceptionMixin")
    e1 = ExceptionMixin()
    assert isinstance(e1._future_exceptions, set)


# Generated at 2022-06-24 04:14:15.638125
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.exceptions import ServerError

    def test_handler(request, exception):
        return text("")

    test_bp = Blueprint("test_bp", url_prefix='test_bp')
    test_bp.exception([ServerError])(test_handler)
    test_bp._apply_exception_handler = lambda x: x

    assert len(test_bp._future_exceptions) == 1

# Generated at 2022-06-24 04:14:17.624282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Fake :
        pass
    f = Fake()
    f.exception = ExceptionMixin.exception
    f.exception()

# Generated at 2022-06-24 04:14:19.841433
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        exceptionMixin = ExceptionMixin()
    except Exception as e:
        print("Class ExceptionMixin constructor throws an exception", e)


# Generated at 2022-06-24 04:14:28.326544
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureException(metaclass=ABCMeta):
        def __init__(self, *args):
            pass

    class OneException(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            assert handler == self.handler

        def handler(self, exception):
            return exception

    obj = OneException()
    assert isinstance(obj.exception(ValueError), functools.partial)
    obj.exception(ValueError)(obj.handler)
    assert obj.handler(1) == 1

# Generated at 2022-06-24 04:14:31.065072
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    from sanic.constants import HTTP_METHODS

    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:14:39.185169
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    def g(a):
        return a

    a = ExceptionMixin()
    print("_future_exception before set: [{}]"
          .format(a._future_exceptions))

    # future_exception is set for test_ExceptionMixin
    future_exception = FutureException(g, Exception)
    a._future_exceptions.add(future_exception)
    print("_future_exception after set: [{}]"
          .format(a._future_exceptions))

    # test _apply_exception_handler
    try:
        a._apply_exception_handler(future_exception)
    except NotImplementedError as e:
        print("Error: [{}]".format(e))


if __name__ == "__main__":
    test_ExceptionMixin()

# Generated at 2022-06-24 04:14:43.697671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass

    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            ...

    blueprint = Blueprint()

    @blueprint.exception(MyException)
    def handler(request, exception):
        ...

    assert blueprint._future_exceptions == {FutureException(handler, (MyException,))}

# Generated at 2022-06-24 04:14:45.608547
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)


# Generated at 2022-06-24 04:14:47.367502
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.server_factory import ServerFactory
    sf = ServerFactory()
    sf.futures.append(None)
    assert ExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:14:49.152853
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    exceptionMixin = ExceptionMixin()
    assert exceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:51.851399
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    _ExceptionMixin = ExceptionMixin()
    _ExceptionMixin.exception(TypeError)
    assert _ExceptionMixin._future_exceptions != set()

# Generated at 2022-06-24 04:14:56.778980
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    mixin_test = ExceptionMixinTest()
    assert type(mixin_test) is ExceptionMixinTest
    assert mixin_test._future_exceptions == set()

# Generated at 2022-06-24 04:15:04.347046
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(ZeroDivisionError)
    def test_exception_handler(request, exception):
        print(f'{exception}')

    assert(
        test_exception_mixin._future_exceptions ==
        {
            FutureException(test_exception_handler, (ZeroDivisionError,))
        }
    )

# Generated at 2022-06-24 04:15:05.619885
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    myException = ExceptionMixin()
    assert myException


# Generated at 2022-06-24 04:15:08.429088
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SampleClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    sample_class = SampleClass()

    assert sample_class._future_exceptions == set()

# Generated at 2022-06-24 04:15:10.726318
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class TestClass(ExceptionMixin):
        pass

    test_instance = TestClass()
    assert isinstance(test_instance, TestMixin)

# Generated at 2022-06-24 04:15:13.416358
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:15:16.018386
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyApp:
        pass
    bp = ExceptionMixin(DummyApp)
    assert bp._future_exceptions == set()
    assert isinstance(bp, ExceptionMixin)


# Generated at 2022-06-24 04:15:20.119197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    a.exception(Exception)
    assert type(a._future_exceptions.pop()) == FutureException


# Generated at 2022-06-24 04:15:25.202159
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass

    a = A()
    assert len(a._future_exceptions) == 0

    def func1():
        pass

    a.exception(Exception)(func1)
    assert len(a._future_exceptions) == 1

    ret_func1 = a.exception(Exception)(func1)
    assert ret_func1 == func1

# Generated at 2022-06-24 04:15:30.130855
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class TestException(ExceptionMixin):
        def __init__(self):
            super(TestException, self).__init__()

    test_exp = TestException()

    assert(test_exp._future_exceptions == set())


# Generated at 2022-06-24 04:15:36.829959
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    class FakeException(Exception):
        pass

    class FakeException2(Exception):
        pass

    def future_handler(*args, **kwargs):
        return None

    blueprint = Blueprint(__name__)
    future_exception = FutureException(future_handler, (FakeException,))
    future_exception2 = FutureException(future_handler, (FakeException2,))

    blueprint._future_exceptions.add(future_exception)
    blueprint._future_exceptions.add(future_exception2)

    assert len(blueprint._future_exceptions) == 2
    assert future_exception in blueprint._future_exceptions
    assert future_exception2 in blueprint._future_exceptions


# Generated at 2022-06-24 04:15:47.392875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.handlers import add_handler
    from sanic.models.sanic import Sanic
    from sanic.utils import sanic_endpoint_test

    class Exception1(Exception):
        pass

    class Exception2(Exception):
        pass

    class Exception3(Exception):
        pass

    def exception_handler(request, exception):
        return text('I caught exception: %s' % type(exception).__name__)

    app = Sanic(name=__name__)
    bp = Blueprint(name='my_blueprint')

    @bp.exception(Exception1, Exception2)
    def bp_exception_handler(request, exception):
        return text('I caught exception: %s' % type(exception).__name__)

   

# Generated at 2022-06-24 04:15:49.963903
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class _ExceptionMixin(ExceptionMixin):
        pass
    fut = _ExceptionMixin()
    assert fut._future_exceptions == set()


# Generated at 2022-06-24 04:15:59.274922
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self.future_exceptions = set()

        # Unit test for method _apply_exception_handler of class ExceptionMixin
        def _apply_exception_handler(self, handler: FutureException):
            self.future_exceptions.add(handler)

    # Create test instance
    test_instance = TestExceptionMixin()

    # Add try except to create future_exception
    try:
        1 / 0
    except Exception:
        future_exception = FutureException(Exception, Exception)

    # Add future_exception of the try except block to the global variable