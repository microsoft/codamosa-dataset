

# Generated at 2022-06-24 04:06:01.450950
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class _BluPrint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass


    bp = _BluPrint()
    @bp.exception(Exception)
    def handler(request, exception):
        return
    assert bp._future_exceptions
    assert len(bp._future_exceptions) == 1


test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:06:07.839108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExampleExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(ExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return

    @ExampleExceptionMixin.exception(Exception)
    def test_handler(request, error):
        return error

    assert len(ExampleExceptionMixin._future_exceptions) == 1
    assert test_handler(None, None) is None

# Generated at 2022-06-24 04:06:15.491859
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    import asyncio

    # setup
    app = Sanic("test_ExceptionMixin_exception")
    blueprint = Blueprint("test_bp")
    f_exc, f_exc_handler = None, None

    # test
    @blueprint.exception(Exception)
    async def exception_handler(request, exception):
        nonlocal f_exc_handler
        f_exc_handler(request, exception)

    async def test_route(request):
        raise Exception("test")

    @app.listener("before_server_start")
    def before_server_start(app, loop):
        nonlocal f_exc_handler
        f_exc = blueprint._future_exceptions.pop()
        f_exc_handler = f_exc.handler

        app

# Generated at 2022-06-24 04:06:24.321298
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.models.exceptions import exception
    from sanic.models.bases import ExceptionMixin

    class exception_class(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return True

    app = Sanic(__name__)
    blueprint = Blueprint('test_bp', url_prefix='/bp')

    @blueprint.exception(ServerError)
    def handle_exception(request, exception):
        return json({'exception': str(exception)})

    app.register_blueprint(blueprint)


# Generated at 2022-06-24 04:06:31.492862
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyCurrentBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return None

    my_blueprint_1 = MyCurrentBlueprint()

    @my_blueprint_1.exception(Exception)
    def handler(exc):
        return True

    @my_blueprint_1.exception(Exception)
    def handler_1(exc):
        return True

    assert len(my_blueprint_1._future_exceptions) == 2
    for fe in my_blueprint_1._future_exceptions:
        assert fe.expect_exception == (Exception,)
        assert fe.handler(NameError)


# Generated at 2022-06-24 04:06:32.497652
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj

# Generated at 2022-06-24 04:06:43.843665
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_ExceptionMixin', url_prefix='test_ExceptionMixin')

    @app.exception(404)
    def test_app_exception_handler(request, exception):
        raise NotImplementedError

    @bp.exception(404)
    def test_bp_exception_handler(request, exception):
        raise NotImplementedError

    @app.get('/test1')
    def handler(request):
        return text('OK')

    @bp.get('/test2')
    def handler2(request):
        return text('OK')


# Generated at 2022-06-24 04:06:50.235513
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    testExceptionMixin = TestExceptionMixin()

    def test_handler():
        pass

    testExceptionMixin.exception(TypeError, apply=False)(test_handler)

    assert len(testExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-24 04:06:51.741108
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()



# Generated at 2022-06-24 04:06:52.504079
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin() != None


# Generated at 2022-06-24 04:06:54.542380
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Test blueprint blueprint when blueprint is not None
    blueprint = Blueprint('test_module', '/test')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:07:02.676324
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # default params
    try:
        exception_mixin_inst = ExceptionMixin()
        exception_mixin_inst.exception(Exception)
    except Exception as error:
        assert error.message == 'NotImplementedError'

    # apply is True
    try:
        exception_mixin_inst.exception(Exception, apply=False)
        exception_mixin_inst.exception(Exception, apply=True)
    except Exception as error:
        assert error.message == 'NotImplementedError'

# Generated at 2022-06-24 04:07:07.665100
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            raise NotImplementedError  # noqa

    dummyExceptionMixin = DummyExceptionMixin()
    assert dummyExceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:12.943460
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    
    assert A._future_exceptions == set()
    assert A()._future_exceptions == set()

# Generated at 2022-06-24 04:07:17.134793
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class SanicTest(ExceptionMixin):
        pass
    obj = SanicTest(2)
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:07:21.534636
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass

    test_class = A()

    test_class.exception(ValueError)(print)
    assert len(test_class._future_exceptions) == 1
    assert test_class._future_exceptions.pop().handler == print

# Generated at 2022-06-24 04:07:24.039665
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # create a dummy class
    class Dummy(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    dummy = Dummy()


# Generated at 2022-06-24 04:07:31.233861
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinImpl(ExceptionMixin):
        def __init__(self, x):
            ExceptionMixin.__init__(self)
            self.x = x

        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    exc_mixin = ExceptionMixinImpl(2)
    assert exc_mixin.x == 2


# Generated at 2022-06-24 04:07:39.821698
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  # Test1: test normal case
  AppTest = Sanic('test_ExceptionMixin_exception')
  @AppTest.exception(Exception)
  def test(request, exception):
      pass
  assert len(AppTest.error_handler.handlers) == 1
  exception_handler = AppTest.error_handler.handlers[Exception][0]['func']
  assert exception_handler == test

  # Test2: test ExceptionMixin
  class ExceptionMixinTest(ExceptionMixin):
      def _apply_exception_handler(self, handler):
          pass

  exception_mixin_app_test = ExceptionMixinTest()
  @exception_mixin_app_test.exception(Exception)
  def  test_exception_mixin_app(request, exception):
      pass

# Generated at 2022-06-24 04:07:47.800451
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound
    from sanic import Blueprint
    import unittest.mock as mock

    bp = Blueprint.create("test_exception")
    exc_handler_patcher = mock.patch.object(bp, "_apply_exception_handler")
    mock_handler = mock.Mock()

    @bp.exception(NotFound)
    def handler(request, exception):
        mock_handler(request, exception)

    assert handler in bp._future_exceptions
    assert exc_handler_patcher.called
    mock_handler.assert_not_called()

# Generated at 2022-06-24 04:07:53.731258
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    from sanic.models.interfaces import IBlueprint
    from sanic.app import Sanic

    class MockExceptionMixin(ExceptionMixin, IBlueprint, Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__()

    assert MockExceptionMixin()._future_exceptions == set()

    bl = Blueprint()
    assert isinstance(bl, Blueprint)
    assert isinstance(bl, IBlueprint)
    assert isinstance(bl, ExceptionMixin)
    assert isinstance(bl, Sanic)

    assert bl._future_exceptions == set()



# Generated at 2022-06-24 04:07:55.799485
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        pass
    assert isinstance(ExceptionMixinTest(),ExceptionMixin)


# Generated at 2022-06-24 04:07:58.117964
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint("test_exception_mixin")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:08:04.096649
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exception_handler import ExceptionHandler

    bp = Blueprint('test_blueprint', url_prefix='/')
    future_exception = FutureException(ExceptionHandler(), (Exception,))
    bp._future_exceptions = {future_exception}
    bp._apply_exception_handler = lambda *args: None

    @bp.exception(Exception)
    def handler():
        pass

# Generated at 2022-06-24 04:08:10.498577
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    blueprint = Blueprint('test', url_prefix='blueprint')
    try:
        @blueprint.exception(Exception)
        def exception_handler_test(request, exception):
            pass
    except NotImplementedError:
        pass
    assert blueprint._future_exceptions is not None
    assert type(blueprint._future_exceptions) is set
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:08:14.101216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint('test', 'test', url_prefix='/test')

    @bp.exception(IndexError)
    def test(request, exception):
        return 'test'

    assert len(bp._future_exceptions) > 0

# Generated at 2022-06-24 04:08:15.679747
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Exception(ExceptionMixin):
        pass
    assert Exception._future_exceptions == set()

# Generated at 2022-06-24 04:08:22.186701
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    test ExceptionMixin function exception()
    """
    class TestExceptionMixin(ExceptionMixin):
        get_list_ = []
        def _apply_exception_handler(self, handler: FutureException):
            self.get_list_.append(handler)
    test_class = TestExceptionMixin()
    @test_class.exception(IndexError)
    def test_handler(request, exc):
        print('get IndexError')
    assert test_class.get_list_[0].handler == test_handler
    assert test_class.get_list_[0].exceptions[0] == IndexError

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:08:31.434304
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.global_exception = None
        def _apply_exception_handler(self, handler: FutureException):
            self.global_exception = handler
    mixin = TestExceptionMixin()

    def handler(request):  # noqa
        return "hi"

    # Test if exception can be added to _future_exceptions
    mixin.exception(ValueError)(handler)
    assert isinstance(mixin._future_exceptions.pop(), FutureException)

    # Test if global exception is applied correctly
    mixin.exception(ValueError, apply=True)(handler)

# Generated at 2022-06-24 04:08:37.614557
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self):
            self.exception_handler = None

        def _apply_exception_handler(self, handler):
            self.exception_handler = handler

    blueprint = Blueprint()

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert blueprint.exception_handler is exception_handler

# Generated at 2022-06-24 04:08:45.323540
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from functools import partial

    def handler1():
        pass

    def handler2():
        pass

    future_exception_1 = FutureException(handler1, (KeyError, ))
    future_exception_2 = FutureException(handler2, (KeyError, ))

    blueprint = Blueprint(name='TestBlueprint')
    blueprint._future_exceptions = {future_exception_1, future_exception_2}

    assert future_exception_1 in blueprint._future_exceptions
    assert future_exception_2 in blueprint._future_exceptions



# Generated at 2022-06-24 04:08:52.394182
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from unittest import TestCase

    class UnitTest(TestCase):
        def setUp(self):
            self.bp = Blueprint('bp', url_prefix='bp')

        def test_init(self):
            self.assertIsInstance(self.bp, Blueprint)
            self.assertIsInstance(self.bp, ExceptionMixin)
            self.assertIsInstance(self.bp._future_exceptions, set)
            self.assertEqual(self.bp._future_exceptions, set())


# Generated at 2022-06-24 04:09:03.135848
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class ExampleBlueprint(Blueprint, ExceptionMixin):
        pass

    class ExampleParentBlueprint(Blueprint, ExceptionMixin):
        pass

    example_parent_blueprint = ExampleParentBlueprint(url_prefix='parent')
    example_blueprint = ExampleBlueprint(url_prefix='example')
    parent_blueprint_exceptions = example_parent_blueprint._future_exceptions
    blueprint_exceptions = example_blueprint._future_exceptions

    @example_parent_blueprint.exception(IndexError)
    def parent_index_error_handler(request, exception):
        return 'index error handled by parent'

    @example_blueprint.exception(IndexError, ValueError)
    def index_error_handler(request, exception):
        return 'index error handled by blueprint'

# Generated at 2022-06-24 04:09:06.967471
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    blueprint = Blueprint('blueprint')
    assert blueprint._future_exceptions == set()
# Test whether the function `exception` does meet the requirement.

# Generated at 2022-06-24 04:09:09.506470
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test = ExceptionMixin()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:09:14.195863
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__, url_prefix='blueprint')
    assert(isinstance(bp, ExceptionMixin))
    assert(bp._future_exceptions == set())



# Generated at 2022-06-24 04:09:22.510007
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BP(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        @staticmethod
        def _apply_exception_handler(handler):
            return handler

    bp = BP()
    def handler1():
        return 'handler1'

    def handler2():
        return 'handler2'

    assert bp.exception([])(handler1) == 'handler1'
    assert bp._future_exceptions == {FutureException(handler1,())}
    assert bp.exception([])() == handler2
    assert bp._future_exceptions == {FutureException(handler1,()), FutureException(handler2, ())}
    bp._future_exceptions.clear()
    assert bp.exception

# Generated at 2022-06-24 04:09:26.031212
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    b1 = Blueprint("test_mixin_exception")
    mixin = ExceptionMixin()
    b1.add_mixin(mixin)
    assert(len(b1._future_exceptions) == 0)


# Generated at 2022-06-24 04:09:28.975021
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:09:31.553021
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = ExceptionMixin()
    blueprint.exception(Exception)(lambda request, exception: None)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:09:32.597657
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em is not None

# Generated at 2022-06-24 04:09:43.351302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.exceptions import abort

    blueprint = Blueprint(__name__)

    @blueprint.exception(Exception, apply=False)
    def error_handler(request, exception):
        return request, exception

    @blueprint.route('/')
    def handler(request):
        abort(404)

    assert issubclass(handler.__blueprint__, ExceptionMixin)
    assert issubclass(handler.__blueprint__, Blueprint)
    assert handler.__blueprint__.__exception_handlers__
    assert handler.__blueprint__.__exception_handlers__[0].handler(None, None)
    assert handler.__blueprint__.__exception_handlers__[0].exception_types[0]

# Generated at 2022-06-24 04:09:44.416173
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em

# Generated at 2022-06-24 04:09:45.949897
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert (ExceptionMixin()._future_exceptions) == set()


# Generated at 2022-06-24 04:09:49.125436
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ExceptionMixin()


# Unit tests for method 'exception' of class ExceptionMixin

# Generated at 2022-06-24 04:09:54.274834
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    assert isinstance(TestExceptionMixin(), ExceptionMixin)

# Generated at 2022-06-24 04:09:57.715682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # *args and **kwargs is used because we don't know what the method will receive
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return None

    exception_mixin_test = ExceptionMixinTest()
    exception_mixin_test.exception(apply=False)

# Generated at 2022-06-24 04:10:05.193484
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinChild(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    emc = ExceptionMixinChild()
    emc.exception(KeyError)
    emc.exception(IndexError, KeyError)
    emc.exception([ValueError, KeyError])

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:10:16.723933
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BP(ExceptionMixin):
        pass

    @BP.exception(ValueError)
    def handler(self, exc, *args, **kwargs):
        return "handler"

    assert len(BP()._future_exceptions) == 1
    assert BP()._future_exceptions.pop().handler == handler

    @BP.exception([ValueError, KeyError])
    def handler2(self, exc, *args, **kwargs):
        return "handler"

    assert len(BP()._future_exceptions) == 1
    assert BP()._future_exceptions.pop().handler == handler2

    with pytest.raises(TypeError):
        @BP.exception(ValueError, apply=False)
        def handler3(self, exc, *args, **kwargs):
            return "handler"

# Generated at 2022-06-24 04:10:17.332216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:10:22.096560
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .blueprint import Blueprint

    bp = Blueprint('hello', __name__, 'hello')
    bp.exception(Exception, ZeroDivisionError)(print)

    # call_exception method for Blueprint class
    fut = FutureException(print, (Exception, ZeroDivisionError))
    bp._future_exceptions.add(fut)
    assert fut in bp._future_exceptions



# Generated at 2022-06-24 04:10:25.876239
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    
    @ExceptionMixin.exception(NotFound)
    def handler(request, exception):
        pass

    bp = Blueprint("test", url_prefix="/test")

    assert bp.exception(NotFound) == handler

    bp.exception(NotFound)(handler)

# Generated at 2022-06-24 04:10:32.120585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    sanic_app = Sanic('test_blueprint_exception')
    blueprint = Blueprint('test_module')

    blueprint.exception(Exception)(lambda request, exception:
                                   dict(status='fail',
                                        message=exception))

    blueprint.exception([ValueError, ArithmeticError])(lambda
                                                       request,
                                                       exception:
                                                       dict(status='fail',
                                                            message=exception))

    @blueprint.route('/')
    async def bp(request):
        1 / 0
        return text('OK')

    sanic_app.blueprint(blueprint)
    request, response = sanic_app.test_client.get('/')
    assert response.status == 500

    request, response = sanic_app.test_client.get('/fail')
   

# Generated at 2022-06-24 04:10:36.380181
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception = ExceptionMixin()
    @exception.exception([IndexError])
    def f():
        pass
    assert len(exception._future_exceptions) == 1
    assert len(exception._future_exceptions) > 0
    assert exception._future_exceptions == {
        FutureException(f, (IndexError,))
    }

# Generated at 2022-06-24 04:10:40.520750
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    kwargs = {'user_id': 1}

    def decorator(handler):
        future_exception = FutureException(handler, kwargs)
        print(future_exception)

    em = ExceptionMixin()
    em._apply_exception_handler = decorator
    em.exception(**kwargs)

# Generated at 2022-06-24 04:10:41.494926
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em is not None

# Generated at 2022-06-24 04:10:42.885736
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert (ExceptionMixin()._future_exceptions == set())


# Generated at 2022-06-24 04:10:45.112994
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    bp = Blueprint('test_bp')
    assert isinstance(bp, ExceptionMixin)

# Generated at 2022-06-24 04:10:50.658213
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Class1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    @Class1.exception(Exception, Exception, kwargs=None)
    async def handle(request: Request, exception: Exception):
        return exception

    assert type(handle)==exception
    assert handle.__name__=='handle'

# Generated at 2022-06-24 04:10:56.472984
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class User(Model):
        pass

    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    testexceptionmixin = TestExceptionMixin()

    def decorator(handler):
        pass

    testexceptionmixin.exception(User.DoesNotExist, apply=False)(decorator)

# Generated at 2022-06-24 04:10:58.599106
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self):
            super().__init__()

    try:
        test = Test()
    except Exception:
        assert False


# Generated at 2022-06-24 04:11:02.190636
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    GIVEN a ExceptionMixin class
    WHEN a new ExceptionMixin object is created
    THEN verify the attributes are initialised correctly
    """
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:11:03.665277
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_ExceptionMixin(ExceptionMixin):
        pass

    assert ExceptionMixin
    assert test_ExceptionMixin

# Generated at 2022-06-24 04:11:11.612499
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import MethodNotAllowed, InvalidUsage

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    test_exception_mixin = TestExceptionMixin()

    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(MethodNotAllowed, InvalidUsage)
    def global_exception(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

    @test_exception_mixin.exception([])
    def global_exception(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1


# Generated at 2022-06-24 04:11:17.922238
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    assert len(testExceptionMixin()._future_exceptions) == 0
    testExceptionMixin().exception(Exception)(print)
    assert len(testExceptionMixin()._future_exceptions) == 1

# Generated at 2022-06-24 04:11:19.947541
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(exception_mixin._future_exceptions, Set)

# Generated at 2022-06-24 04:11:22.547084
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:11:24.755998
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert isinstance(em, ExceptionMixin)
    assert isinstance(em._future_exceptions, Set)

# Generated at 2022-06-24 04:11:29.351557
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()

# Generated at 2022-06-24 04:11:30.681240
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:11:34.209213
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin._future_exceptions == set()
    obj = ExceptionMixin()
    assert obj._future_exceptions == set()
    @obj.exception
    def test():
        print(1)
    assert obj._future_exceptions == {FutureException(test, ())}

# Generated at 2022-06-24 04:11:37.057100
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin._future_exceptions == set()
    assert ExceptionMixin.exception(1, apply=True)
    assert ExceptionMixin.exception(1, apply=True)(1)

# Generated at 2022-06-24 04:11:44.999260
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print("_apply_exception_handler: %s" % handler.handler)

    testExceptionMixin = TestExceptionMixin()
    testExceptionMixin.exception(Exception, apply=False)(lambda req, resp, err: req)
    assert len(testExceptionMixin._future_exceptions) == 1


# Generated at 2022-06-24 04:11:47.403402
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()
    assert isinstance(TestClass(), ExceptionMixin)

# Generated at 2022-06-24 04:11:50.633989
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler):
            pass

    test_ex_mixin = TestExceptionMixin()

    assert test_ex_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:11:51.457387
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-24 04:12:00.360843
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint

    from unittest.mock import MagicMock


# Generated at 2022-06-24 04:12:02.457798
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin(1, 2, 3)



# Generated at 2022-06-24 04:12:11.097209
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.views import HTTPMethodView

    class _(ExceptionMixin, Blueprint):
        pass

    @_(apply=False)
    @_._exception([Exception])
    def _():
        pass

    assert len(_._future_exceptions) == 1
    exception: FutureException = _._future_exceptions.pop()

    assert exception.handler == _
    assert exception.exceptions == [Exception]

    @_(apply=False)
    @_._exception(Exception)
    def _():
        pass

    assert len(_._future_exceptions) == 1
    exception: FutureException = _._future_exceptions.pop()

    assert exception.handler == _
    assert exception.exceptions == [Exception]

# Generated at 2022-06-24 04:12:16.445558
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestingExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestingExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    TestingExceptionMixin()


# Generated at 2022-06-24 04:12:21.337574
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin.__init__.__doc__ is not None
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(exception_mixin._future_exceptions, set)
    assert len(exception_mixin._future_exceptions) == 0


# Generated at 2022-06-24 04:12:25.384734
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # test case 1
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()
            assert self._future_exceptions == set()

    # test case 2
    TestExceptionMixin()

# unit test for function _apply_exception_handler of ExceptionMixin

# Generated at 2022-06-24 04:12:26.934978
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin is not None


# Generated at 2022-06-24 04:12:29.169314
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExampleExceptionMixin(ExceptionMixin):
        pass

    example = ExampleExceptionMixin()

    assert example._future_exceptions == set()


# Generated at 2022-06-24 04:12:35.253096
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    with pytest.raises(NotImplementedError):
        ExceptionMixin()._apply_exception_handler(None)
    
    # Test ExceptionMixin instance and _future_exceptions data structure
    instance = ExceptionMixin()
    assert(type(instance._future_exceptions) == set)
    assert(len(instance._future_exceptions) == 0)
    assert(type(instance._apply_exception_handler) == NotImplementedError)


# Generated at 2022-06-24 04:12:42.521748
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin:
        def __init__(self, *args, **kwargs):
            cls = ExceptionMixin
            cls.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    import inspect
    testexceptionmixin = TestExceptionMixin()
    assert inspect.ismethod(testexceptionmixin.exception) == True
    def exception_handler(self, *args):
        pass

# Generated at 2022-06-24 04:12:51.012361
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self, *args, **kwargs):
            self.exception_list = []
        def _apply_exception_handler(self, handler: 'ExceptionMixin'):
            self.exception_list.append(handler)

    a = A()
    @a.exception(Exception, Exception)
    def foo(self):
        pass
    @a.exception([Exception, Exception], apply=False)
    def bar(self):
        pass
    @a.exception([Exception, Exception])
    def baz(self):
        pass
    @a.exception(Exception, Exception, apply=False)
    def qux(self):
        pass
    assert hasattr(a, '_future_exceptions')
    assert len(a.exception_list) == 2

# Generated at 2022-06-24 04:12:59.074438
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    @MyExceptionMixin.exception()
    def my_handler():
        return "test"

    assert isinstance(my_handler, FutureException)

    MyExceptionMixin.exception(list([ValueError, TypeError]))(my_handler)
    assert isinstance(my_handler, FutureException)
    assert isinstance(my_handler._exceptions, tuple)
    assert len(my_handler._exceptions) == 2

# Generated at 2022-06-24 04:13:03.144594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test for ExceptionMixin
    """
    bp = Blueprint("bp")
    assert bp.exception(ValueError)

# Generated at 2022-06-24 04:13:05.289569
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Test no argument is passed
    with pytest.raises(TypeError):
        ExceptionMixin()

    # Test required argument is passed
    assert ExceptionMixin(1) is not None

# Generated at 2022-06-24 04:13:11.571266
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Tmp:
        def __init__(self):
            pass

        @ExceptionMixin.exception(ValueError)
        def handler(self, request, exception):
            pass
    t = Tmp()
    f = t._future_exceptions.pop()
    assert issubclass(f.exception, ValueError)
    assert f.handler == t.handler

# Generated at 2022-06-24 04:13:13.358604
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Arrange
    obj = ExceptionMixin()

    # Act
    obj.__init__()

    # Assert
    assert obj._future_exceptions == set()


# Generated at 2022-06-24 04:13:16.711176
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        ...

    blueprint = Blueprint()
    blueprint.exception(Exception)

# Generated at 2022-06-24 04:13:18.781311
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        pass
    exception_mixin = Blueprint()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:13:24.932167
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    
    class A(ExceptionMixin):

        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler):
            self.handler = handler

    a = A()
    @a.exception(KeyError, apply=True)
    def ex_handler(request, exception):
        return 'exception handled'

    # testing correct method exception worked
    assert a.handler == FutureException(ex_handler, (KeyError,))

# Generated at 2022-06-24 04:13:27.076650
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    instance = ExceptionMixin()
    assert isinstance(instance, ExceptionMixin)
    assert hasattr(instance, '_future_exceptions')

# Generated at 2022-06-24 04:13:28.779312
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = BlueprintMixin('/test_url')
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:13:30.635861
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = None
    blueprint_exceptions = ExceptionMixin(blueprint)
    assert blueprint_exceptions._future_exceptions == set()


# Generated at 2022-06-24 04:13:31.551586
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # depricated
    assert True

# Generated at 2022-06-24 04:13:32.925672
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:13:41.745394
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_ExceptionMixin_exception", url_prefix='/test_ExceptionMixin_exception')
    @bp.exception(ZeroDivisionError)
    def zero_division_handler(request, exception):
        return text("zero_division_handler")
    
    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)

    request, response = app.test_client.get('/test_ExceptionMixin_exception/')
    assert response.status == 200
    assert response.text == 'zero_division_handler'

# Generated at 2022-06-24 04:13:46.294148
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinSubclass(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    e = ExceptionMixinSubclass()
    @e.exception(RuntimeError)
    def exception_handler():
        pass
    assert len(e._future_exceptions) == 1

# Generated at 2022-06-24 04:13:47.352411
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    executor.execute(ExceptionMixin, globals())

# Generated at 2022-06-24 04:13:49.211796
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m.__init__() is None
    assert m._future_exceptions == set()


# Generated at 2022-06-24 04:13:52.785640
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestException(ExceptionMixin):
        def __init__(self):
            super().__init__()

    t = TestException()
    assert isinstance(t._future_exceptions, set)
    # Unit test for _apply_exception_handler function of class ExceptionMixin

# Generated at 2022-06-24 04:13:56.589992
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    tmix = TestExceptionMixin()
    tmix.exception(Exception)
    assert tmix._future_exceptions.pop().handler is None
    assert len(tmix._future_exceptions) is 0

# Generated at 2022-06-24 04:13:58.973218
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:14:02.957062
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    @ExceptionMixin.route("/")
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    assert TestExceptionMixin()._future_exceptions == set()


# Generated at 2022-06-24 04:14:10.771699
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorated_method(request, exception):
        pass
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            result = handler.exception_class
            decorated_method(handler.handler, result)
        def set_route(self, _):
            pass
    mixin = MockExceptionMixin()
    mixin.exception(ZeroDivisionError)(decorated_method)
    assert decorated_method.__closure__[0].cell_contents == ZeroDivisionError

# Generated at 2022-06-24 04:14:12.168989
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptions = ExceptionMixin()
    assert isinstance(exceptions, ExceptionMixin)

# Generated at 2022-06-24 04:14:14.369062
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class EventSource(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    ExceptionMixin()
    EventSource()

# Generated at 2022-06-24 04:14:18.321460
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def exception_handler(err, req, res, params):
        return res.status(500).text(str(err))

    assert isinstance(exception_handler, function)
    assert isinstance(exception_handler, collections.Callable)



# Generated at 2022-06-24 04:14:20.224793
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-24 04:14:22.742586
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    Test for constructor of class ExceptionMixin
    """
    mixin = ExceptionMixin()
    assert mixin.__init__() == None

# Generated at 2022-06-24 04:14:29.000794
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def handler(request, exc):
        return True

    assert any(
        future_exception.handler is handler
        and future_exception.exceptions == (Exception,)
        for future_exception
        in test_exception_mixin._future_exceptions
    )

# Generated at 2022-06-24 04:14:38.555962
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound, ServerError

    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.app = Blueprint("exception_test", url_prefix="/test2")

        def _apply_exception_handler(self, handler):
            nonlocal app
            app.error_handler.add(handler.exceptions, handler.handler)

    app = Sanic("exception_test")

    @app.route("/test1")
    def test1(request):
        raise NotFound

    @app.route("/test2/test1")
    def test2(request):
        raise ServerError

   

# Generated at 2022-06-24 04:14:45.489643
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint as BP
    blueprint = BP('/test')

    blueprint.exception(IndexError)(lambda *_, **__: None)

    assert blueprint._future_exceptions == {
        FutureException(lambda *_, **__: None, (IndexError,))
    }

    blueprint.exception([IndexError, TypeError])(lambda *_, **__: None)

    assert blueprint._future_exceptions == {
        FutureException(lambda *_, **__: None, (IndexError,)),
        FutureException(lambda *_, **__: None, (TypeError,)),
    }

# Generated at 2022-06-24 04:14:45.815197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:14:49.183371
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    from sanic.models.future import FutureBlueprint

    def test_decorated_function():
        pass

    handler = test_decorated_function
    exceptions = (Exception,)
    apply = True

    app = Sanic('test_sanic')
    test_blueprint = FutureBlueprint('test', None)
    test_blueprint.exception(handler,*exceptions,apply=apply)

    assert len(test_blueprint._future_exceptions) == 1
    assert type(test_blueprint._future_exceptions.pop()) == FutureException

# Generated at 2022-06-24 04:14:53.995592
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert len(self._future_exceptions) == 1

    mixin = TestExceptionMixin()

    @mixin.exception(IndexError)
    def handler(request, exception):
        pass

# Generated at 2022-06-24 04:14:56.019929
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    ex = ExceptionMixin()
    assert isinstance(ex, ExceptionMixin)


# Generated at 2022-06-24 04:15:00.212738
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    a = Test()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:15:03.415856
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class Requests:
        pass
    req = Requests()

    # When
    @req.exception(Exception, apply=True)
    def my_handler(request, exception):
        return 'Exception handled'

    # Then
    assert my_handler.handler == 'Exception handled'
    assert my_handler.exceptions == (Exception,)


# Generated at 2022-06-24 04:15:06.713860
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test:
        def __init__(self):
            ExceptionMixin.__init__(self)

    test = Test()
    assert isinstance(test, ExceptionMixin)
    assert isinstance(test._future_exceptions, set)

# Generated at 2022-06-24 04:15:12.808422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class T(ExceptionMixin):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    assert len(T(1, 2, 3)._future_exceptions) == 0

    @T(1, 2, 3).exception(Exception)
    def f():
        return 1

    assert len(T(1, 2, 3)._future_exceptions) == 1
    assert f() == 1

# Generated at 2022-06-24 04:15:14.382183
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-24 04:15:16.591878
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    t = type('Test', (ExceptionMixin,), {})()
    assert t._future_exceptions == set()

# Generated at 2022-06-24 04:15:18.088737
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()

# Generated at 2022-06-24 04:15:20.121823
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:27.396388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic.exceptions

    class ExceptionMixinMock(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = ExceptionMixinMock()

    def exception_handler(*args, **kwargs):
        pass

    test_exception_mixin.exception(ValueError)(exception_handler)
    future_exception = FutureException(exception_handler, ValueError)
    assert future_exception in test_exception_mixin._future_exceptions

# Generated at 2022-06-24 04:15:30.053726
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()


# Generated at 2022-06-24 04:15:37.147682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    exc = ExceptionMixin()

    class TestException(Exception):
        pass

    # act
    @exc.exception([TestException])
    def handler(request, exception):
        pass

    # assert
    assert handler == exc._future_exceptions.pop().handler

    # arrange
    exceptions = None

    # act
    @exc.exception(TestException)
    def handler(request, exception):
        pass

    # assert
    assert handler == exc._future_exceptions.pop().handler

# Generated at 2022-06-24 04:15:39.206233
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic_auth.__main__ import ExceptionMixin
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)

# Generated at 2022-06-24 04:15:41.964043
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    test = Test()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:15:51.384895
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic:
        def add_route(self, handler, *args, **kwargs):
            pass

        def exception(self, handler, *args, **kwargs):
            pass

    class Blueprint:
        def __init__(self):
            self.websocket_routes = {}
            self.routes = {}
            self.host_name = None
            self.host_pattern = None
            
        class Register:
            def _apply_route(self, request_handler, uri, host, methods,
                                strict_slashes, stream, register,
                                provide_automatic_options):
                pass
    bp = Blueprint()
    bp.sanic_app = Sanic()

# Generated at 2022-06-24 04:15:59.305009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    global_blp = Blueprint(None, url_prefix=None)

    # global_blp.url_prefix = global_blp.name = 'global'
    @global_blp.exception(ValueError)
    def handler_ValueError(request, exception):
        print("global_blp catch value error: ", exception)

    @global_blp.exception(Exception)
    def handler_Exception(request, exception):
        print("global_blp catch exception: ", exception)

    @global_blp.exception(Exception, ValueError)
    def handler_Exception_ValueError(request, exception):
        print("global_blp catch exception and value error: ", exception)
