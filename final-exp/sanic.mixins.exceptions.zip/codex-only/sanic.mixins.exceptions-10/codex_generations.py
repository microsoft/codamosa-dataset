

# Generated at 2022-06-24 04:05:58.307102
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlankExceptionMixin(ExceptionMixin):
        pass
    bm = BlankExceptionMixin
    @bm.exception(Exception)
    def handle_exception(request, exception):
        pass

    assert bm._future_exceptions

# Generated at 2022-06-24 04:06:08.052232
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockSanic:
        def add_exception_handler(self, *args, **kwargs):
            pass

    class MockSanicBlueprint:
        def __init__(self, name, *args, **kwargs):
            self.name = name
            self.sanic = MockSanic()

    cls = create_autospec(ExceptionMixin, spec_set=True, instance=True)
    cls.__init__ = lambda *args: None
    cls._future_exceptions = set()
    cls._apply_exception_handler = lambda *args: None
    retval = cls.exception(Exception)(lambda *args, **kwargs: "Exception handler")
    assert retval("Exception handler")
    assert len(cls._future_exceptions) == 1

    cls = create_autos

# Generated at 2022-06-24 04:06:10.322520
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test = TestExceptionMixin()

    # test if future_exceptions is set correctly
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:06:15.770906
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Router:
        def add_exception_handler(self, exception: FutureException) -> None:
            return None
    
    class Sanic:
        def __init__(self):
            self.router = Router()

    class BluePrint:
        pass

    blueprint = BluePrint()
    blueprint.sanic_app = Sanic()

    blueprint.exception(Exception)(Exception)

    blueprint._apply_exception_handler(Exception)

# Generated at 2022-06-24 04:06:19.501687
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:06:27.473071
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            print('apply handler')
            pass

    class MyClass(MyMixin):
        pass

    @MyClass.exception(Exception)
    def my_handler():
        print('my_handler')
        pass

    assert len(MyClass()._future_exceptions) == 1
    assert MyClass()._future_exceptions.pop() == FutureException(my_handler, Exception)


# Generated at 2022-06-24 04:06:30.525078
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self):
            pass
    
    DummyExceptionMixin().exception(Exception)
    DummyExceptionMixin().exception(Exception, ValueError)

# Generated at 2022-06-24 04:06:36.592536
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import response
    from sanic.exceptions import ServerError
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.server import HttpProtocol
    from sanic.response import HTTPResponse
    app = Sanic(__name__)
    # define new blueprint
    test_bp = Blueprint(__name__)
    @test_bp.exception(ServerError)
    def handler_exception(request: Request, exception: Exception) -> HTTPResponse:
        return response.text("ServerError")
    @test_bp.exception([ServerError,])
    def handler_exception2(request: Request, exception: Exception) -> HTTPResponse:
        return response.text("ServerError")
    

# Generated at 2022-06-24 04:06:48.471102
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.models.futures import FutureException

    class MockException(Exception):
        pass

    class MockTypeError(TypeError):
        pass

    blueprint = Blueprint('test',url_prefix='test')

    @blueprint.exception(MockException)
    def mock_exception(request, exception):
        return request

    @blueprint.exception([MockException, MockTypeError])
    def multiple_exceptions(request, exception):
        return request

    @blueprint.exception(MockTypeError)
    def mock_type_error(request, exception):
        return request

    # assert each exception handler is added as a FutureException to the blueprint

# Generated at 2022-06-24 04:06:56.431054
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.request import Request
    from sanic.response import text
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint
    from sanic.models.futures import Future

    blueprint = Blueprint('test_ExceptionMixin_exception',url_prefix='test_ExceptionMixin_exception')
    @blueprint.exception([InvalidUsage])
    def handler_exception(request: Request, exception: Future):
        return text(f'Got exception: {exception}')

    @blueprint.route('/test_ExceptionMixin_exception')
    def exception_test_route(request: Request):
        raise InvalidUsage('testing')

    assert blueprint.name == 'test_ExceptionMixin_exception'
    assert blueprint.url_prefix == '/test_ExceptionMixin_exception'
   

# Generated at 2022-06-24 04:07:03.581495
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import json
    app = Sanic('test_exception_mixin')
    bp1 = Blueprint('test_bp', url_prefix='test')
    @bp1.exception([ValueError])
    def handler(request, exception):
        return json({'test': 'result'}, status=200)
    bp1._apply_exception_handler(bp1._future_exceptions.pop())
    app.blueprint(bp1)
    test_client = app.test_client
    @app.route("/test_bp/test", methods=["GET"])
    def handler(request):
        raise ValueError()
    request, response = test_client.get("/test_bp/test")

# Generated at 2022-06-24 04:07:06.751248
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixin_test(ExceptionMixin):
        pass
    test_ExceptionMixin = ExceptionMixin_test()
    assert test_ExceptionMixin._future_exceptions == set()


# Generated at 2022-06-24 04:07:07.469542
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:07:11.375549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.response import HTTPResponse

    blueprint = Blueprint(__name__)

    @blueprint.exception()
    def index():
        return HTTPResponse('yey')


    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:07:15.418148
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(name='test', url_prefix='test')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:07:24.776867
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        pass

    class TestExceptions:
        pass

    # Test initial state
    t = TestClass()
    assert t._future_exceptions == set()

    # Test decorator
    @t.exception(apply=False)
    def decorated_handler(*args, **kwargs):
        pass

    future_exception = FutureException(decorated_handler, ())
    assert t._future_exceptions == {future_exception}

    # Test decorator, with args
    @t.exception(TestExceptions, apply=False)
    def decorated_handler_with_args(*args, **kwargs):
        pass

    future_exception_with_args = FutureException(decorated_handler_with_args, (TestExceptions,))

# Generated at 2022-06-24 04:07:30.189840
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView, ExceptionMixin):
        def get(self, request):
            pass
        def post(self, request):
            pass
    my_view = MyView()
    my_view.exception()



# Generated at 2022-06-24 04:07:32.767541
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    
    @test_object.exception(ValueError)
    def handler():
        pass

    assert len(test_object._future_exceptions) == 1


# Generated at 2022-06-24 04:07:40.035427
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            nonlocal test_exception_mixin_mock_apply_exception_handler
            super(TestExceptionMixin, self).__init__()
            self._apply_exception_handler = test_exception_mixin_mock_apply_exception_handler()

    def test_exception_mixin_mock_apply_exception_handler():
        apply_exception_handler_invocations = 0
        def apply_exception_handler(future_exception):
            nonlocal apply_exception_handler_invocations
            apply_exception_handler_invocations += 1
        return apply_exception_handler
    
    em = TestExceptionMixin()
    em.exception(Exception)

# Generated at 2022-06-24 04:07:47.407114
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
        
        @exception(IndexError, KeyError, apply=False)
        def handler1(self, request, exception):
            pass

    a = A()
    assert len(a._future_exceptions) == 1
    assert a._future_exceptions.pop().handler == a.handler1
    assert a.handler1.__name__ == 'handler1'   # handler1 name must not be change

# Generated at 2022-06-24 04:07:49.454965
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class BaseException(ExceptionMixin):
        pass

    base_exception = BaseException()
    assert base_exception._future_exceptions == set()


# Generated at 2022-06-24 04:07:51.426861
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Request(ExceptionMixin):
        pass

    request_1 = Request()

    assert request_1._future_exceptions == set()

# Generated at 2022-06-24 04:07:52.682716
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert set() == ExceptionMixin()._future_exceptions


# Generated at 2022-06-24 04:07:54.990998
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_class(ExceptionMixin):
        pass
    test = test_class()
    assert isinstance(test._future_exceptions, set)


# Generated at 2022-06-24 04:07:56.471834
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:07:57.903067
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc_mixin = ExceptionMixin()
    assert exc_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:08:02.877632
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionM(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            # self._future_exceptions: Set[FutureException] = set()
            pass
    m = ExceptionM()
    assert m._future_exceptions == set()

# Generated at 2022-06-24 04:08:09.739223
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()
            self._future_exceptions.add(FutureException(None, (None,)))

    exception = _ExceptionMixin()
    assert exception._future_exceptions.pop()

# Unit tests for exception decorator of class ExceptionMixin

# Generated at 2022-06-24 04:08:11.296069
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions == set()


# Generated at 2022-06-24 04:08:15.079413
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test = TestExceptionMixin()
    
    @test.exception()
    def test_exception():
        return test

    assert isinstance(test_exception, types.FunctionType)
    assert test._future_exceptions is not None

# Generated at 2022-06-24 04:08:16.328731
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        pass
    assert Test()


# Generated at 2022-06-24 04:08:19.252371
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    t = Test()
    assert t._future_exceptions == set()


# Generated at 2022-06-24 04:08:24.799600
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.router import RouteExists

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    test = TestExceptionMixin()
    assert len(test._future_exceptions) == 0
    @test.exception()
    def test_exception_handler(req, res):
        pass
    assert len(test._future_exceptions) == 1
    # raise RouteExists
    test.exception()(RouteExists)
    assert len(test._future_exceptions) == 2

# Generated at 2022-06-24 04:08:31.667872
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
        def _apply_exception_handler(self, handler: FutureException):
            print("apply exception handler:")
            print(handler.handler)
            print(handler.exceptions)
    myExceptionMixin = MyExceptionMixin()
    @myExceptionMixin.exception(IOError)
    def handler(request, exception):
        print("handle exception")
        print(exception)
    handler(None, IOError())

# Generated at 2022-06-24 04:08:36.083950
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_ExceptionMixin(ExceptionMixin):
        _apply_exception_handler = None

    e = test_ExceptionMixin()

    @e.exception(Exception)
    def b(request, exception):
        pass

# Generated at 2022-06-24 04:08:38.322218
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # test constructor
    exception_mixin = ExceptionMixin()

    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:08:41.289250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test', url_prefix='test')
    blueprint.exception(Exception)('handler')
    assert blueprint._future_exceptions


# Generated at 2022-06-24 04:08:45.923229
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():   
    from sanic.blueprints import Blueprint
    class test(ExceptionMixin, Blueprint):
        pass
    bp = test('bp')
    @bp.exception(exceptions = [])
    def handler():
        pass
    assert bp._future_exceptions != set()

# Generated at 2022-06-24 04:08:48.639597
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def exception_handler(request, exception):
        print("Caught exception:")
        print(exception)
    pass

# Generated at 2022-06-24 04:08:52.808833
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def global_handler(request, exception):
        return response.text('I am the global exception handler', 500)

# Generated at 2022-06-24 04:09:00.335808
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert(handler.handler == handle_test)

    def handle_test(*args, **kwargs):
        pass

    test_exception_mixin = TestExceptionMixin()
    # Act
    test_exception_mixin.exception(int)(handle_test)
    # Assert
    assert(len(test_exception_mixin._future_exceptions) == 1)

# Generated at 2022-06-24 04:09:07.293547
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)
    bp.exception(Exception)(raise_exception)
    bp.exception([Exception])(raise_exception)
    bp.exception(Exception, Exception)(raise_exception)
    bp.exception([Exception], Exception)(raise_exception)
    bp.exception(Exception, [Exception])(raise_exception)
    bp.exception([Exception], [Exception])(raise_exception)

# Generated at 2022-06-24 04:09:13.147976
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    @bp.exception(Exception)
    def errorhandler(request, exception):
        pass
    assert bp._future_exceptions == {FutureException(errorhandler,(Exception,))}
    assert bp._future_exceptions.pop() == FutureException(errorhandler,(Exception,))
    try:
        bp._apply_exception_handler({})
    except NotImplementedError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-24 04:09:16.304415
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    foo = ExceptionMixinTest()
    assert isinstance(foo._future_exceptions, Set)

# Generated at 2022-06-24 04:09:26.815733
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    blueprint = Blueprint('test_exception_mixin')
    assert hasattr(blueprint, 'exception')
    assert blueprint.exception
    assert len(blueprint._future_exceptions) == 0

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        assert isinstance(request, dict)
        assert issubclass(exception.__class__, Exception)

    assert callable(exception_handler)
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop()

# Generated at 2022-06-24 04:09:32.244013
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint', url_prefix='test')
    assert callable(blueprint.exception)
    assert isinstance(blueprint.exception, classmethod)

    def view():
        pass

    blueprint.exception(Exception)(view)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-24 04:09:32.975016
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:36.173861
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test:
        def __init__(self, *args, **kwargs):
            pass
    
    obj = Test()
    assert isinstance(obj, Test)

# Generated at 2022-06-24 04:09:41.684387
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print('')
    print('')
    print('---------------------------------------')
    print('Testing ExceptionMixin_exception')
    print('---------------------------------------')
    class Test_ExceptionMixin(ExceptionMixin):
        pass

    ex = Test_ExceptionMixin()
    #ex._future_exceptions = set()

    exceptions = (Exception, RuntimeError)
    ex.exception(exceptions)

# Generated at 2022-06-24 04:09:51.493408
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from pytest import raises
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Blueprint(None)
    @app.exception(SanicException)
    def handler(request: Request, exception: SanicException):
        return HTTPResponse(
            status=exception.status_code, text=str(exception), content_type="text/html"
        )
    assert app.error_handler_spec == {}
    app.error_handler(handler)
    assert app.error_handler_spec == {SanicException: handler}
    with raises(AttributeError):
        app.exception(SanicException)

# Generated at 2022-06-24 04:09:55.640189
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exceptions = [Exception, TypeError] # type: ignore
    test = TestExceptionMixin()
    assert test._future_exceptions == set()
    assert test.exception(exceptions) == test.exception(exceptions)
    assert test._future_exceptions != set()

# Generated at 2022-06-24 04:09:58.938933
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ClassUnderTest(ExceptionMixin):
        pass

    @ClassUnderTest.exception(Exception)
    def test_handler():
        pass

    c = ClassUnderTest()
    c._apply_exception_handler = lambda x: None

    assert len(c._future_exceptions) == 1
    f = c._future_exceptions.pop()
    assert f.handler == test_handler
    assert f.exceptions == (Exception,)

# Generated at 2022-06-24 04:10:07.690467
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint(__name__, url_prefix='exception_test')
    test_case = [
        1,
        2,
    ]

    @bp.exception(test_case, apply=False)
    def exception_handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 2
    assert ExceptionMixin._apply_exception_handler.__name__ is not "notdefined"
    assert ExceptionMixin._apply_exception_handler.__name__ is not "exception_handler"
    assert ExceptionMixin._apply_exception_handler.__name__ is not "test_ExceptionMixin_exception"
    assert ExceptionMixin._apply_exception_handler.__name__ is not "__init__"
    assert ExceptionMixin._

# Generated at 2022-06-24 04:10:12.488537
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    exception_mixin = MockExceptionMixin()
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:10:14.139170
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp

# Generated at 2022-06-24 04:10:20.096526
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint(None, None, None)
    blueprint.add_exception_handler(AttributeError, lambda a: a)
    blueprint.add_exception_handler(KeyError, lambda a: a)
    blueprint.add_exception_handler(TypeError, lambda a: a)
    handler = lambda x: x
    future_exception = FutureException(handler, (AttributeError, KeyError, TypeError))
    assert future_exception in blueprint._future_exceptions

# Generated at 2022-06-24 04:10:21.623397
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert isinstance(obj,ExceptionMixin)


# Generated at 2022-06-24 04:10:28.962590
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sys
    from sanic.blueprints.exception_mixin import ExceptionMixin

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler

    # test when apply=False
    test_object = TestExceptionMixin()
    test_object.exception(SystemExit)(sys.exit)
    assert test_object._future_exceptions
    for future_exception in test_object._future_exceptions:
        if future_exception.handler == sys.exit:
            assert not future_exception.applied

    # test when apply=True
    test_object = TestExceptionMixin()
    test_object.exception(SystemExit, apply=True)(sys.exit)
    assert test_object._future_exceptions

# Generated at 2022-06-24 04:10:29.621391
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()

# Generated at 2022-06-24 04:10:32.419904
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        pass
    blueprint = Blueprint()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:10:33.683271
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()



# Generated at 2022-06-24 04:10:34.636268
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()._future_exceptions == set()

# Generated at 2022-06-24 04:10:43.377241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Dummy:
        pass

    dummy = Dummy()
    dummy.__init__()

    assert dummy._future_exceptions == set()

    @dummy.exception(list)
    def real_decorator_return(handler):
        return handler

    assert type(real_decorator_return) == function

    def handler_to_be_decorated(request, *args, **kwargs):
        pass

    my_new_handler = real_decorator_return(handler_to_be_decorated)
    assert my_new_handler == handler_to_be_decorated

    assert dummy._future_exceptions != set()


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:10:48.646297
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError
    from sanic.blueprints import Blueprint

    blu = Blueprint('test_blu')
    assert blu._future_exceptions == set()

    @blu.exception(ServerError)
    def func(request, exception):
        pass

    assert len(blu._future_exceptions) == 1
    assert isinstance(list(blu._future_exceptions)[0].handler, types.FunctionType)

# Generated at 2022-06-24 04:10:54.045265
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler():
        pass

    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print("Test_exception")
            print(handler)

    test = Test()
    test.exception(Exception, apply=False)(handler)

# Generated at 2022-06-24 04:10:55.352872
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()
    assert isinstance(exceptionMixin, object)

# Generated at 2022-06-24 04:11:05.901495
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    from ..utils import MethodTestCase

    class MyMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class MyBlueprint(MyMixin, Blueprint):
        pass

    blueprint = MyBlueprint()

    @blueprint.exception(Exception)
    def handle_exception(request, exception):
        return 'exception_response'

    assert len(blueprint._future_exceptions) == 1
    handler = next(iter(blueprint._future_exceptions))
    assert handler.handler == handle_exception
    assert Exception in handler.exceptions

    # with MethodTestCase(blueprint) as test_case:
        # test_case.assert_

# Generated at 2022-06-24 04:11:09.979630
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    empty_blueprint = Blueprint("test", url_prefix="/test")
    assert empty_blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:11:12.441391
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    empty_set = set()
    mixin = ExceptionMixinClass()
    assert(mixin._future_exceptions == empty_set)


# Generated at 2022-06-24 04:11:15.437281
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTester(ExceptionMixin):
        pass
    return ExceptionMixinTester()

# Generated at 2022-06-24 04:11:18.081381
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception()
    def handler(request, exception):
        pass

    assert handler.handler == handler
    assert handler.exceptions == ()

# Generated at 2022-06-24 04:11:26.074076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = _ExceptionMixin()
    exception_mixin.exception(Exception, NotImplementedError)
    assert len(exception_mixin._future_exceptions) == 1
    assert len(exception_mixin._future_exceptions.pop().handlers) == 2

# Generated at 2022-06-24 04:11:32.338147
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    class ExceptionMixin(object):
        def __init__(self, *args, **kwargs):
            pass

    blueprint = Blueprint(__name__)
    assert blueprint._future_exceptions is not None
    assert blueprint.exception is not None



# Generated at 2022-06-24 04:11:40.439713
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinChild(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixinChild, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return True

    exception_mixin_child = ExceptionMixinChild()

    @exception_mixin_child.exception(Exception, apply=True)
    def global_exception_handler(request, exception):
        return "exception"

    assert len(exception_mixin_child._future_exceptions) == 1
    assert exception_mixin_child._future_exceptions.pop().callable == global_exception_handler
    assert global_exception_handler(1, 1) == "exception"

# Generated at 2022-06-24 04:11:43.688428
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    bp = Blueprint('bp')
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:11:48.333668
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixinClass(ExceptionMixin):
        pass
    test_exception_mixin = TestExceptionMixinClass()
    assert len(test_exception_mixin._future_exceptions) == 0

# Generated at 2022-06-24 04:11:55.467683
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            #handler.apply()
            return True

    test = TestExceptionMixin()
    assert len(test._future_exceptions) == 0
    assert test.exception(TypeError)(lambda x: x) is not None
    assert len(test._future_exceptions) == 1

# Generated at 2022-06-24 04:11:57.727961
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin()


# Generated at 2022-06-24 04:11:59.233562
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    x = ExceptionMixin()
    assert x._future_exceptions == set()


# Generated at 2022-06-24 04:12:08.353017
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_motor.base.model_mixin import MotorModelMixin

    class TestModel(MotorModelMixin, ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            self._exception_handlers = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handlers.add(handler)

    @TestModel.exception(TypeError)
    def exception_handler(self, exception, **kwargs):
        return (exception, kwargs)

    assert len(TestModel._future_exceptions) == 1
    assert len(TestModel._exception_handlers) == 1


# Generated at 2022-06-24 04:12:14.255572
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    my_exception_mixin = MyExceptionMixin()

    @my_exception_mixin.exception(ValueError, IndexError)
    def exception_handler(request, exception):
        print(request)
        print(exception)

    assert exception_handler in my_exception_mixin._future_exceptions
    assert exception_handler not in my_exception_mixin._exception_handlers
    return

# Generated at 2022-06-24 04:12:20.261654
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic()
    # exception handler
    @app.exception(InvalidUsage)
    def exception_handler(request, exception):
        return text(exception)
    # route
    @app.get("/")
    def handler(request):
        raise InvalidUsage("No!")
    # fire get request
    request, response = app.test_client.get('/')
    assert response.text == "No!"

# Generated at 2022-06-24 04:12:21.962664
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    c = ExceptionMixin()
    assert c._future_exceptions == set()


# Generated at 2022-06-24 04:12:25.303727
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)

    @blueprint.exception(ZeroDivisionError)
    def exception_handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1



# Generated at 2022-06-24 04:12:30.798582
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_test:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class Test_ExceptionMixin(ExceptionMixin, ExceptionMixin_test):
        def test(self):
            pass

    test=Test_ExceptionMixin()
    test.exception(Exception)(Exception)

# Generated at 2022-06-24 04:12:32.751273
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert len(obj._future_exceptions) == 0


# Generated at 2022-06-24 04:12:43.889479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    import unittest

    class TestExceptionMixin(Blueprint, ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass
    test = TestExceptionMixin('test')

    @test.exception(ValueError)
    def value_handler(request: Request, exc: ValueError) -> HTTPResponse:
        raise ValueError

    @test.exception(TypeError)
    def type_handler(request: Request, exc: TypeError) -> HTTPResponse:
        raise TypeError


# Generated at 2022-06-24 04:12:45.698501
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()


# Generated at 2022-06-24 04:12:52.005893
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_exception_mixin(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    a = test_exception_mixin()
    @a.exception(ValueError)
    async def test(request, exc):
        print(exc)
    test(None, ValueError())

# Generated at 2022-06-24 04:12:53.783806
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()



# Generated at 2022-06-24 04:12:57.880482
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class MyExceptionClass(ExceptionMixin):
        pass

    instance = MyExceptionClass()

    assert type(instance._future_exceptions) == set


# Generated at 2022-06-24 04:13:00.290341
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    assert ExceptionMixin()._future_exceptions == set([]), \
        "ExceptionMixin.__init__ fails to initialize empty set of future exceptions"



# Generated at 2022-06-24 04:13:01.976956
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    m = ExceptionMixin()
    assert m._future_exceptions == set()


# Generated at 2022-06-24 04:13:02.862489
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    new_exception_mixin = ExceptionMixin()

# Generated at 2022-06-24 04:13:04.972653
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class NewExceptionMixin(ExceptionMixin):
        pass

    exm = NewExceptionMixin()
    assert isinstance(exm._future_exceptions, set)

# Generated at 2022-06-24 04:13:10.096939
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    bp = Blueprint(__name__, url_prefix="")
    assert bp._future_exceptions == set()

# Generated at 2022-06-24 04:13:11.736693
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    e1 = ExceptionMixin()
    assert e1._future_exceptions == set()


# Generated at 2022-06-24 04:13:15.888832
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    dummy_exception_mixin = DummyExceptionMixin()
    assert isinstance(dummy_exception_mixin._future_exceptions, set)


# Generated at 2022-06-24 04:13:25.813727
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints.blueprint import Blueprint
    from sanic.models.futures import FutureException
    from unittest import mock

    blueprint = Blueprint(None)
    _apply_exception_handler = mock.MagicMock()

    blueprint._apply_exception_handler = _apply_exception_handler

    def decorator(handler):
        return handler

    blueprint._apply_exception_handler.return_value = decorator

    blueprint.exception(Exception, apply=False)()
    blueprint.exception([Exception], apply=True)()

    exception_handler = _apply_exception_handler.call_args[0][0]
    exception_handler_2 = _apply_exception_handler.call_args[1][0][0]

    assert isinstance(exception_handler, FutureException)

# Generated at 2022-06-24 04:13:27.370677
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert isinstance(obj._future_exceptions, set)


# Generated at 2022-06-24 04:13:31.818271
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bp(ExceptionMixin):
        def __init__(self):
            super().__init__()

    @Bp.exception(Exception)
    def handle_bad_request(request, exception):
        return text('Bad request', 400)

    bp = Bp()
    # TypeError: 'Exception' object is not iterable
    assert bp.exception(Exception)

# Generated at 2022-06-24 04:13:35.560547
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
    TestExceptionMixin()


# Generated at 2022-06-24 04:13:43.434236
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.sanic_blueprint import SanicBlueprint

    class Test(ExceptionMixin):
        def __init__(self):
            super().__init__()

    def test_fun_decorator(test_fun):
        return test_fun

    t = Test()

    @t.exception(test_fun_decorator)
    def test():
        return True

    assert type(t.test()) == FutureException
    assert len(t._future_exceptions) == 1

# Generated at 2022-06-24 04:13:45.381154
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    obj = ExceptionMixin()
    assert obj is not None

# Generated at 2022-06-24 04:13:48.134768
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test_Class(ExceptionMixin):
        pass
    assert test_Class()
    assert test_Class()._future_exceptions == set()


# Generated at 2022-06-24 04:13:54.014260
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    my_exception_mixin = MyExceptionMixin()

    assert type(my_exception_mixin) is MyExceptionMixin
    assert hasattr(my_exception_mixin, '_future_exceptions')
    assert my_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:13:58.213296
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Case 1: Construct an object ExceptionMixin
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()
    return


# Generated at 2022-06-24 04:14:07.940560
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMock(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exception_mixin_mock = ExceptionMixinMock()
    @exception_mixin_mock.exception(ValueError, apply=True)
    def test_handler():
        pass
    assert len(exception_mixin_mock._future_exceptions) == 1
    future_exception = exception_mixin_mock._future_exceptions.pop()
    assert len(future_exception.exceptions) == 1
    assert future_exception.exceptions[0] == ValueError
    assert future_exception.handler == test_handler

# Generated at 2022-06-24 04:14:16.302038
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    assert TestMixin()._future_exceptions == set()
    assert TestMixin(1)._future_exceptions == set()
    assert TestMixin(1,2,3)._future_exceptions == set()
    assert TestMixin(1,2,3,x=1)._future_exceptions == set()
    assert TestMixin(1,2,3,x=3,y=4)._future_exceptions == set()


# Generated at 2022-06-24 04:14:21.772174
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print("Testing ExceptionMixin")
    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin, ExceptionMixin)
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:26.759738
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for the method exception of class ExceptionMixin

    :return:
    """
    # Initial variables
    test_obj = ExceptionMixin()
    test_exception_handler = Exception

    # Test positive
    test_obj.exception(test_exception_handler)
    test_obj.exception(test_exception_handler, apply=False)
    assert test_obj._future_exceptions != None

# Generated at 2022-06-24 04:14:36.209454
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    assert issubclass(ExceptionMixin, object)
    assert hasattr(ExceptionMixin, "exception")
    assert callable(ExceptionMixin.exception)

    result = ExceptionMixin()
    assert callable(result.exception)
    assert isinstance(result._future_exceptions, set)
    assert len(result._future_exceptions) == 0

    handledExceptions = [Exception]
    indexes = [1, 2]
    assert callable(result.exception(*handledExceptions))
    assert len(result._future_exceptions) == 1
    assert result._future_exceptions[0] == FutureException(None, tuple(handledExceptions))
    assert callable(result.exception(*handledExceptions, **{"apply": True}))

# Generated at 2022-06-24 04:14:39.014761
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin(1, 2, 3)
    assert type(em).__name__ == "ExceptionMixin"

# Generated at 2022-06-24 04:14:41.726577
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Foo(ExceptionMixin):
        pass
    foo = Foo()
    # assert foo._future_exceptions == set()
    # assert foo._apply_exception_handler() == NotImplementedError

# Generated at 2022-06-24 04:14:46.994256
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint("blueprint", url_prefix="/test")

    @bp.exception(Exception, apply=True)
    def handler(request, exception):
        assert exception is Exception

    app = Sanic("sanic-blueprint-exception")
    app.blueprint(bp)

    with pytest.raises(Exception):
        app.handle_request(
            "GET", "/test/route", "127.0.0.1", None, {}
        )

# Generated at 2022-06-24 04:14:51.533206
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Dummy:
        def __init__(self):
            self._future_exceptions = set()
    dummy = Dummy()
    dummy2 = ExceptionMixin(dummy)
    dummy2.__init__()
    assert dummy2._future_exceptions == set()


# Generated at 2022-06-24 04:14:53.832977
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exp_mixin = ExceptionMixin()
    assert exp_mixin._future_exceptions == set()


import unittest


# Generated at 2022-06-24 04:14:54.898235
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: implement
    pass

# Generated at 2022-06-24 04:15:03.484598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_ExceptionMixin_exception", url_prefix="/")
    @bp.exception([Exception])
    def handler(request, exception):
        return request, exception
    app.blueprint(bp)
    @app.route("/exc")
    def exc(request):
        raise Exception("test_ExceptionMixin_exception")
    request, response = app.test_client.get("/exc")
    assert response.status == 500
    assert "test_ExceptionMixin_exception" in str(response.body)

# Generated at 2022-06-24 04:15:12.563816
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    class BlueprintMock(Blueprint, ExceptionMixin):
        def __init__(self):
            self.name = 'bp_mock'
            Blueprint.__init__(self, self.name)
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            print('Apply...')

    bp_mock = BlueprintMock()
    future_exceptions = bp_mock._future_exceptions
    assert len(future_exceptions) == 0

    decorator = bp_mock.exception()
    print('@decorator:')
    @decorator
    def handler():
        print('Handler...')

    assert len(future_exceptions) == 1

# Generated at 2022-06-24 04:15:20.695619
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # https://github.com/hugapi/hug/blob/master/hug/exceptions.py
    class _NorwegianBlue(ExceptionMixin):pass
    # so the problem is it get instance:
    # _NorwegianBlue(exceptions=(ValueError,))
    # which is obvious has no attribute apply_exception_handler
    # print(_NorwegianBlue(exceptions=(ValueError,)).exception((ValueError,)))
    # print(ExceptionMixin.exception(None, (ValueError,)))
    # print(ExceptionMixin.exception.__code__.co_varnames)
    # print(ExceptionMixin.exception.__code__.co_argcount)
    # print([_.strip() for _ in ExceptionMixin.exception.__code__.co_varnames[:ExceptionMixin.

# Generated at 2022-06-24 04:15:25.334673
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    class_obj = ExceptionMixinClass()

    # Test if FutureMixin.__init__ initializes future_exceptions to set()
    assert class_obj._future_exceptions == set()



# Generated at 2022-06-24 04:15:34.390987
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    The test checks wether the constructor of the exception class works
    """
    from sanic import Blueprint
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import ServerError
    import asyncio

    app = Sanic(__name__)

    # Define Blueprint
    bp = Blueprint('test_bp', version='0.1', url_prefix='/test_bp')

    # Define Exception Handler
    @bp.exception(ServerError)
    def handler(request, exception):
        return text(str(exception))

    # Create route and register blueprint
    @app.route('/test')
    async def test(request):
        raise ServerError("Test Error", status_code=500)

    app.blueprint(bp)

    # Testing

# Generated at 2022-06-24 04:15:38.106830
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exc = ExceptionMixin()
    assert exc._future_exceptions == set()

# test apply exception handler

# Generated at 2022-06-24 04:15:45.557564
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class App(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
        def _apply_exception_handler(self, handler):
            assert handler.receivers == (Exception,)
            assert handler.kwargs == {'key': 'value'}
            assert handler.handler(Exception()) == 'test'
    app = App()
    @app.exception(Exception)
    def test(request, exception):
        return 'test'
    assert app._future_exceptions

# Generated at 2022-06-24 04:15:53.381339
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._future_exceptions.add(FutureException(handler, NameError))
            self._future_exceptions.add(FutureException(handler, ValueError))

        def _apply_exception_handler(self, handler: FutureException):
            pass
        
    def handler(*args, **kwargs):
        pass

    exception_mixin = MockExceptionMixin()
    assert exception_mixin._future_exceptions == set([FutureException(handler, NameError), FutureException(handler, ValueError)])

# Generated at 2022-06-24 04:15:57.764293
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """
    -Testing if ExceptionMixin.__init__() works as expected
    """

    # Initialize ExceptionMixin
    dummy_exception = ExceptionMixin()

    # Check that it really is an ExceptionMixin class
    assert isinstance(dummy_exception, ExceptionMixin)
