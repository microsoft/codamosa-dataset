

# Generated at 2022-06-24 04:06:02.021326
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    assert not hasattr(bp, '_future_exceptions')
    future_exceptions = bp.exception('a')
    assert hasattr(bp, '_future_exceptions')
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.__contains__(future_exceptions)

# Generated at 2022-06-24 04:06:08.260855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mybp(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @Mybp.exception(ValueError)
    async def exception_handler(request, exception):
        pass

    bp = Mybp()
    bp.exception_handler(None, None)
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-24 04:06:14.717770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            print("Apply exception handler")

    test_obj = TestClass()
    assert test_obj._future_exceptions == set()
    # Set the handler to be empty
    test_obj.exception("Exception")(None)
    assert len(test_obj._future_exceptions) == 1


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:06:16.991605
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprints import Blueprint
    blueprint = Blueprint('test_ExceptionMixin')
    blueprint.exception(Exception)(None)

# Generated at 2022-06-24 04:06:21.136279
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_class(ExceptionMixin):
        pass

    test_class_instance = test_class()
    test_class_instance.exception(RuntimeError)(print)
    assert len(test_class_instance._future_exceptions) == 1

# Generated at 2022-06-24 04:06:25.990425
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Blueprint(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    bprint = Blueprint()
    assert bprint._future_exceptions == set()


# Generated at 2022-06-24 04:06:29.590750
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_exception', url_prefix='test/')

    # This test checks that the decorator for exception raises an error in case
    # the user does not specify an exception handler.
    with pytest.raises(TypeError):
        @bp.exception()
        def handler():
            return None



# Generated at 2022-06-24 04:06:32.220911
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:06:34.926414
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    blueprint = Blueprint("test", url_prefix="/test")
    assert blueprint._future_exceptions == set()



# Generated at 2022-06-24 04:06:36.889270
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = ExceptionMixin()
    assert blueprint._future_exceptions == set()


# Generated at 2022-06-24 04:06:40.941187
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class blueprint(ExceptionMixin):
        def __init__(self):
            super().__init__()

    blue = blueprint()
    assert isinstance(blue._future_exceptions, set)


# Generated at 2022-06-24 04:06:42.858347
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint('test', url_prefix=URL_PREFIX)
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:06:48.830652
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    my_ExceptionMixin = ExceptionMixin()
    # Testing Private Values
    try:
        print(my_ExceptionMixin._future_exceptions)
    except AttributeError:
        print('AttributeError: future_exceptions')
    # Testing Public Values
    try:
        print(my_ExceptionMixin.exception())
    except AttributeError:
        print('AttributeError: exception')

test_ExceptionMixin()

# Generated at 2022-06-24 04:06:50.031944
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception = ExceptionMixin()
    assert type(exception) == ExceptionMixin


# Generated at 2022-06-24 04:06:56.702858
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._called_apply_exception_handler = False
            super(ExceptionMixinMock, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            self._called_apply_exception_handler = True

    @ExceptionMixinMock.exception(Exception)
    def handler_exception(request, exception):
        pass

    assert len(ExceptionMixinMock._future_exceptions) == 1
    future = ExceptionMixinMock._future_exceptions.pop()
    assert future.handler == handler_exception
    assert future.exceptions == (Exception,)

# Generated at 2022-06-24 04:06:59.689163
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(name="exception")
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:07:08.704000
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    class Handler:
        def __call__(self, *args, **kwargs):
            pass

    exception_mixin_test = ExceptionMixinTest()
    assert len(exception_mixin_test._future_exceptions) == 0
    handler = Handler()
    exception_mixin_test.exception(ZeroDivisionError, apply=False)(handler)
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-24 04:07:13.064428
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = Test()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:07:20.306015
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinExtension(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            ExceptionMixinExtension.function_handler = handler

    handler = lambda request, exception: True
    extension = ExceptionMixinExtension()
    extension.exception(KeyError)(handler)
    assert ExceptionMixinExtension.function_handler.handler is handler
    assert ExceptionMixinExtension.function_handler.exceptions == (KeyError,)

# Generated at 2022-06-24 04:07:28.558630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json

    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return json(
                "test_ExceptionMixin_exception",
                headers={"test_key_exception_mixin_apply_exception_handler": "test_header"},
            )

    exception_mixin = ExceptionMixinTest()
    test_key_exception_mixin_obj = "test_ExceptionMixin_exception"

    @exception_mixin.exception(ValueError)
    def exception_handler():
        return json(
            {"test_key_exception_mixin_exception_handler": "test_ExceptionMixin_exception"},
            headers={test_key_exception_mixin_obj: "test_header"},
        )

   

# Generated at 2022-06-24 04:07:32.337167
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class test(ExceptionMixin):
        """testing mixin"""
        def __init__(self):
            """constructor"""
            super().__init__()
    tester = test()
    assert tester._future_exceptions == set()


# Generated at 2022-06-24 04:07:34.394771
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    inst = TestExceptionMixin()
    assert inst._future_exceptions == set()
    
test_ExceptionMixin()


# Generated at 2022-06-24 04:07:40.057722
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def fun():
        class testExceptionMixin(ExceptionMixin):
            def _apply_exception_handler(self, handler: FutureException):
                pass
        return testExceptionMixin
    obj = fun()()
    try:
        obj.exception()
    except NotImplementedError:
        pass

# Generated at 2022-06-24 04:07:45.995561
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json

    bp = Blueprint('test', url_prefix='/test')

    @bp.exception(Exception)
    def exception_handler(request, exception):
        return json({'error': str(exception)}, 500)

    assert len(bp._future_exceptions) == 1



# Generated at 2022-06-24 04:07:52.821972
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import unittest
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic import Sanic

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return

    class TestExceptionMixinTestCase(unittest.TestCase):
        def test_constructor(self):
            test_ExceptionMixin = TestExceptionMixin()

            assert isinstance(test_ExceptionMixin, ExceptionMixin)
            assert isinstance(test_ExceptionMixin._future_exceptions, set)
            assert test_ExceptionMixin._future_exceptions == set()

    unittest.main()

# Generated at 2022-06-24 04:07:54.780108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert callable(ExceptionMixin.exception)

# Unit test to check if there is an attribute called _future_exceptions of class ExceptionMixin

# Generated at 2022-06-24 04:07:58.324503
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():  # noqa
    def dummy_handler(request, exception):
        pass

    class TestException(Exception):
        pass

    exception_mixin = ExceptionMixin()
    dummy_handler = exception_mixin.exception(TestException)(dummy_handler)
    assert dummy_handler.exceptions == (TestException,)
    assert dummy_handler.apply == True

# Generated at 2022-06-24 04:08:00.885163
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    tm = TestExceptionMixin()
    assert tm._future_exceptions == set()

# Generated at 2022-06-24 04:08:02.528754
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert isinstance(ExceptionMixin(1,2),ExceptionMixin)


# Generated at 2022-06-24 04:08:06.306013
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.blueprint import Blueprint
    blueprint1 = Blueprint("test", url_prefix="/test")
    assert len(blueprint1._future_exceptions)==0

# Generated at 2022-06-24 04:08:07.255775
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
	assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:08:11.911760
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = Blueprint()
    @bp.exception(ValueError)
    def handler(request, exception):
        print(f'Handling exception of {exception}')
    print(bp._future_exceptions)
test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:08:18.242591
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.apply = False

        def _apply_exception_handler(self, handler: FutureException):
            assert handler == FutureException(exception_handler, tuple())
            self.apply = True
    test_class = TestClass()

    assert test_class.apply == False
    @test_class.exception()
    def exception_handler():
        pass

    assert test_class.apply == True

# Generated at 2022-06-24 04:08:24.814778
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = TestExceptionMixin()

    @a.exception(TypeError)
    def test(request, error):
        return 'test'

    assert len(a._future_exceptions) == 1

    for fe in a._future_exceptions:
        assert fe.handler() == 'test'

    @a.exception([TypeError, ValueError])
    def test2(request, error):
        return 'test2'

    assert len(a._future_exceptions) == 2

    for fe in a._future_exceptions:
        assert fe.handler() in ['test', 'test2']

# Generated at 2022-06-24 04:08:31.187781
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()
            self._apply_exception_handler(None)

    class A:
        pass
    a = A()
    exception_mixin = MyExceptionMixin()
    exception_mixin.exception(AttributeError)(a.test)
    assert isinstance(exception_mixin._future_exceptions, set)
    assert isinstance(exception_mixin._future_exceptions, set)
    assert isinstance(exception_mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-24 04:08:34.986531
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result=ExceptionMixin()
    func_test=lambda request,exception: None
    
    result.exception(Exception)(func_test)

# Generated at 2022-06-24 04:08:35.602549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:37.421842
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test = ExceptionMixin()
    assert test._future_exceptions == set()


# Generated at 2022-06-24 04:08:39.692037
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    bp = Blueprint()
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:08:40.713812
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions ==  set()

# Generated at 2022-06-24 04:08:42.651120
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    args = tuple()
    kwargs = dict()
    ExceptionMixin(*args, **kwargs)


# Generated at 2022-06-24 04:08:43.587993
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:08:53.876062
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    method_name = "exampleMethod"
    exception_list = [Exception, TypeError]
    apply_exception_handler_patch = patch.object(ExceptionMixin, "_apply_exception_handler")
    apply_exception_handler_mock = apply_exception_handler_patch.start()

    exception_mixin = ExceptionMixin()
    result = exception_mixin.exception(exception_list)(getattr(ExceptionMixin, method_name))

    # Test for method exception
    assert result == getattr(exception_mixin, method_name)

    # Test for set attribute _future_exception
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.copy().pop()
    assert callable(future_exception.handler)

# Generated at 2022-06-24 04:08:59.586403
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTestCase(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    emtc = ExceptionMixinTestCase()
    assert isinstance(emtc, ExceptionMixinTestCase)
    assert isinstance(emtc._future_exceptions, Set)


# Generated at 2022-06-24 04:09:03.748864
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestSanicBlueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    test = TestSanicBlueprint()
    assert test._future_exceptions == set()

# Generated at 2022-06-24 04:09:11.173784
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class ExpectionB(SanicException):
        pass

    class ExpectionA(SanicException):
        pass

    class ExpectionC(SanicException):
        pass

    @blueprint.exception(ExpectionA, apply=True)
    def handler(request, exception):
        return exception

    blueprint = Blueprint('blueprint')

    assert len(blueprint._future_exceptions) == 1

    blueprint.exception([ExpectionB, ExpectionC])(handler)
    assert len(blueprint._future_exceptions) == 3

# Generated at 2022-06-24 04:09:18.269401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a=ExceptionMixin()
    b=Exception('a')
    c=Exception('b')
    d=Exception('c')
    @a.exception(b,c)
    def f(x,y,z):
        print('hello')
    @a.exception(d,c)
    def f1(x,y,z):
        print('hello, world')
    if f==a._future_exceptions[0] and f1==a._future_exceptions[1]:
        print('success')
    else:
        print('failure')
    

test_ExceptionMixin_exception()



# Generated at 2022-06-24 04:09:23.271333
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # import
    from sanic.blueprints import Blueprint

    # init
    exceptions = (Exception,)
    bp = Blueprint("test_exception", url_prefix='/test_exception')

    @bp.exception(exceptions)
    def test_exception_handler(request, exception):
        pass

    # assert
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions[0] == FutureException(
        test_exception_handler, exceptions
    )

# Generated at 2022-06-24 04:09:23.741175
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:25.390662
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    blueprint = Blueprint('test_bp')
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:09:27.835096
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass

    obj = TestExceptionMixin()
    assert len(obj._future_exceptions) == 0


# Generated at 2022-06-24 04:09:31.607264
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @MyExceptionMixin.exception()
    def handler(request, exception):
        pass

# Generated at 2022-06-24 04:09:35.308191
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(AssertionError)
    def handler():
        return "handler"

    try:
        assert 0 == 1
    except AssertionError:
        handler()

# Generated at 2022-06-24 04:09:38.658907
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test_exceptionmixin = TestExceptionMixin()
    assert isinstance(test_exceptionmixin, TestExceptionMixin)



# Generated at 2022-06-24 04:09:42.968441
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    Blue = Blueprint()
    Blue.exception(ValueError)(6)

# Generated at 2022-06-24 04:09:43.615132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:09:52.869310
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    class TestException(Exception):
        pass

    class SomeOtherException(Exception):
        pass

    test_exception_mixin = TestExceptionMixin()

    # Act
    @test_exception_mixin.exception(TestException, apply=False)
    def test_function():
        raise TestException

    # Assert
    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(list(test_exception_mixin._future_exceptions)[0], FutureException)

    @test_exception_mixin.exception([TestException, SomeOtherException])
    def another_test_function():
        raise SomeOtherException

# Generated at 2022-06-24 04:09:57.492607
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mock(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    Mock().exception(apply=False, *[TypeError])

# Generated at 2022-06-24 04:10:07.582241
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Sanic
    from sanic.models.futures import FutureException

    exception_mixin = ExceptionMixin()
    assert isinstance(exception_mixin._future_exceptions, set)

    exceptions = [
        IOError,
        ZeroDivisionError,
        IndexError,
        TypeError,
        Exception
    ]

    # test exception() decorator
    @exception_mixin.exception(*exceptions)
    def handler():
        pass

    assert isinstance(exception_mixin._future_exceptions, set)
    assert len(exception_mixin._future_exceptions) == 1
    test_future_exception = exception_mixin._future_exceptions.pop()

# Generated at 2022-06-24 04:10:10.680011
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.blueprints import Blueprint

    my_blueprint = Blueprint("my_blueprint")
    assert isinstance(my_blueprint._future_exceptions, set)

# Generated at 2022-06-24 04:10:11.746574
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exceptionMixin = ExceptionMixin()

# Generated at 2022-06-24 04:10:15.803832
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .test_blueprint import Blueprint
    blueprint = Blueprint(__name__)
    blueprint.exception(Exception)
    blueprint.exception([Exception])
    blueprint.exception([Exception], apply=False)
    blueprint.exception(Exception, apply=False)

# Generated at 2022-06-24 04:10:23.606340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic
    from sanic.exceptions import SanicException

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_exception_exception_bp")

    @app.exception(SanicException)
    def handle_exception(request, exception):
        pass

    @bp.exception(SanicException)
    def handle_exception(request, exception):
        pass

    assert len(app.error_handler.handlers) == 1, "global exception handler"
    assert (
        len(bp.error_handler.handlers)
        == 1
    ), "blueprint exception handler should be preserved"

# Generated at 2022-06-24 04:10:25.518491
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    import sanic.blueprints as ex
    ex.ExceptionMixin(ex)

# Unit test of method exception()

# Generated at 2022-06-24 04:10:30.151891
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class DummyClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    dummy_class = DummyClass()
    assert isinstance(dummy_class, ExceptionMixin)

# Generated at 2022-06-24 04:10:35.385474
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinStub(ExceptionMixin):
        def __init__(self, *args):
            super().__init__(*args)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    stub = ExceptionMixinStub()
    assert stub._future_exceptions == set()

# Generated at 2022-06-24 04:10:38.616671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp")
    bp.exception(Exception)

# Test ExceptionMixin._apply_exception_handler

# Generated at 2022-06-24 04:10:41.736213
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class App(ExceptionMixin):
        def __init__(self):
            self.asdfasdf = 123

    app = App()
    assert isinstance(app._future_exceptions, set)

# Generated at 2022-06-24 04:10:50.771567
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.application import Sanic
    import sanic.blueprints

    sanic_app = Sanic('TestApp')
    # test exception
    def test_exception():
        raise Exception('Test Exception')
    # test exception handler
    def exception_handler(request: Request, exception: Exception):
        return text('Error handler for exception {}'.format(exception))

    # test with True apply
    bp = sanic.blueprints.Blueprint('TestBlueprint', url_prefix='/bp', version=1)
    bp.exception(test_exception, apply=True)(exception_handler)
    assert len(bp._future_exceptions) == 1
    assert len(sanic_app.error_handlers) == 1
    assert sanic_app.error_handlers[Exception] == exception_handler

    #

# Generated at 2022-06-24 04:10:58.720712
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 1
    args = [Exception]
    apply = True
    exceptions = (Exception)
    handler = print
    fut = FutureException(handler, exceptions)

    mixin = ExceptionMixin()
    mixin._future_exceptions.add(fut)
    mixin._apply_exception_handler = mock.MagicMock()
    mixin.exception(*args, apply=apply)(handler)
    assert len(mixin._future_exceptions) == 2
    assert handler in [e.handler for e in mixin._future_exceptions]



# Generated at 2022-06-24 04:11:02.001538
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin is not None

# Generated at 2022-06-24 04:11:06.801880
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given the below code constructs
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    blueprint_obj = Blueprint()

    @blueprint_obj.exception(Exception)
    def exception_handler(request, exception):
        pass

    # When
    handler_list = blueprint_obj._future_exceptions
    
    # Then
    assert len(handler_list) == 1

# Generated at 2022-06-24 04:11:14.272386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BluePrintExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(BluePrintExceptionMixin, self).__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            handler.handle_exception

    # Verify if all exception handlers are added to the future exceptions set
    bp = BluePrintExceptionMixin()
    @bp.exception(ValueError)
    def handle_exception():
        pass
    @bp.exception(ValueError)
    def handle_exception_2():
        pass
    assert (len(bp._future_exceptions) == 2)

    # Verify if all exception handlers are added to the future exceptions set
    bp = BluePrintExceptionMixin()

# Generated at 2022-06-24 04:11:16.565286
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(request, exception):
        pass
    exception_mixin = ExceptionMixin()
    assert exception_mixin.exception(handler)

# Generated at 2022-06-24 04:11:20.522931
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint(__name__)

    @bp.exception(Exception)
    def handler(request, exception):
        return text('An internal error occurred')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-24 04:11:26.177927
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    exception_mixin_test = ExceptionMixinTest()
    assert exception_mixin_test._future_exceptions == set()
    assert exception_mixin_test.exception(ValueError, Exception) != None
    exception_mixin_test.exception()



# Generated at 2022-06-24 04:11:32.121223
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    ex_mixin = ExMixin()
    def foo():
        print('foo')
    ex_mixin.exception(TypeError)(foo)

# Generated at 2022-06-24 04:11:34.579448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with pytest.raises(NotImplementedError):
        # do something involving ExceptionMixin.exception()
        # the following line is arbitrary
        ExceptionMixin().exception()

# Generated at 2022-06-24 04:11:36.643149
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    a = ExceptionMixin()
    assert isinstance(a, ExceptionMixin)
    assert a._future_exceptions == set()



# Generated at 2022-06-24 04:11:42.846862
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

    class ExceptionMixinSubClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # print("ExceptionMixinSubClass Init")

    ExceptionMixinSubClassSubClass = ExceptionMixinSubClass(None, None)

    # testing 
    ExceptionMixinSubClassSubClass2 = ExceptionMixinSubClass()

    assert ExceptionMixinSubClassSubClass._future_exceptions is not None
    assert ExceptionMixinSubClassSubClass2._future_exceptions is not None



# Generated at 2022-06-24 04:11:47.752708
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    bp = Blueprint('foo', url_prefix='/')
    assert issubclass(bp.__class__, ExceptionMixin)
    assert isinstance(bp._future_exceptions, set)


# Generated at 2022-06-24 04:11:51.922352
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    b = Blueprint(__name__)

    history = []
    @b.exception([KeyError])
    def handler(request, exception):
        history.append(exception)
    
    try:
        raise KeyError("test")
    except KeyError as e:
        b.handle_request(None, e)

    assert history == [KeyError("test")]


# Generated at 2022-06-24 04:12:01.767855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprint import Blueprint

    bp = Blueprint('test_bp', url_prefix='test')
    assert bp._future_exceptions == set()
    assert bp.exception(Exception)(lambda x: x)
    assert bp._future_exceptions == {FutureException(lambda x: x, (Exception, ))}

    bp = Blueprint('test_bp', url_prefix='test')
    assert bp._future_exceptions == set()
    assert bp.exception(Exception, apply=False)(lambda x: x)
    bp._apply_exception_handler(FutureException(lambda x: x, (Exception, )))
    assert bp._future_exceptions == {FutureException(lambda x: x, (Exception, ))}

    bp = Blueprint('test_bp', url_prefix='test')
    b

# Generated at 2022-06-24 04:12:04.043281
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    _bl = ExceptionMixin()
    _bl._future_exceptions = set()
    @_bl.exception(KeyError)
    def _handler():
        pass


# Generated at 2022-06-24 04:12:12.707163
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
	from sanic.blueprints import Blueprint
	from sanic.exceptions import SanicException
	from sanic.response import json
	from unittest import mock
	import asyncio

	app = mock.MagicMock()

	bp = Blueprint("test_exception", url_prefix="/test_exception", version="v1")
	bp.add_exception(SanicException, json)

	@bp.route("/")
	def handler(request):
		raise SanicException("This is a test", status_code=404)

	app.blueprint(bp, strict_slashes=True)

	request, _ = app.test_client.get("/v1/test_exception/")

	assert request.status == 404
	assert request.json == {"message": "This is a test"}

# Generated at 2022-06-24 04:12:15.147973
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    try:
        ExceptionMixin()
        assert True
    except:
        assert False


# Generated at 2022-06-24 04:12:19.438643
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    exc = ExceptionMixin()
    # When
    exc.exception(KeyError)
    # Then
    assert len(exc._future_exceptions) == 1
    assert exc._future_exceptions == {FutureException(exceptions=(KeyError,))}

# Generated at 2022-06-24 04:12:22.756869
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_obj = ExceptionMixin()
    assert test_obj is not None

# Generated at 2022-06-24 04:12:32.274854
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception = TestExceptionMixin()
    exception_handler = test_exception.exception(KeyError, '[a,b,c]')(lambda *args, **kwargs: exception_handler())
    assert exception_handler == test_exception._future_exceptions.pop().handler
    assert test_exception._future_exceptions == set()

# Generated at 2022-06-24 04:12:35.987775
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    emt = ExceptionMixinTest()
    assert emt._future_exceptions == set()



# Generated at 2022-06-24 04:12:46.384089
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # given
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json
    from sanic import Sanic

    app = Sanic()
    bp = Blueprint("my_bp", url_prefix="/prefix")

    @bp.exception(NotFound)
    def ignore_404s(request, exception):
        return json({"status": 404, "reason": "not found"})

    bp.error(NotFound)(ignore_404s)

    @app.route("/1")
    async def handler1(request):
        raise NotFound()

    @bp.route("/2")
    async def handler2(request):
        raise NotFound()

    app.blueprint(bp)

    # when

# Generated at 2022-06-24 04:12:53.229806
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest

    from sanic import Sanic, Blueprint

    from sanic_openapi.example import add_example

    
    class TestExceptionMixin(unittest.TestCase):
        def setUp(self):
            self.app = Sanic(__name__)
            self.blueprint = Blueprint('test', url_prefix='/blueprint')

        def test_exception(self):
            @self.blueprint.exception(Exception, apply=True)
            def handler(request, exception):
                add_example('handler', handler)
                
            self.assertIn(handler, self.blueprint.handlers[Exception])
            self.assertTrue(self.blueprint._apply_exception_handler)
            self.assertIn(handler, self.app.error_handler.handlers[Exception])

    unittest

# Generated at 2022-06-24 04:12:58.562571
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    blueprint = Blueprint(__name__)
    blueprint.__class__ = type(
        'TestBlueprint',
        (ExceptionMixin, Blueprint),
        {'__init__': ExceptionMixin.__init__}
    )
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:13:08.798354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException, FutureRoute
    from sanic.exceptions import SanicException
    from functools import partial

    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._routes = set([])

        def add_route(self, uri: str, methods: list, handler):
            self._routes.add(FutureRoute(uri, methods, handler))

        def _apply_exception_handler(self, handler: FutureException):
            for route in self._routes:
                if handler.match(route.exceptions):
                    route.set_exception_handler(handler.handler)

    exception_mixin = Exception

# Generated at 2022-06-24 04:13:13.926297
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    print("Test for ExceptionMixin")
    t = ExceptionMixin()
    assert t._future_exceptions == set()
    assert type(t._future_exceptions) == set

# Generated at 2022-06-24 04:13:24.961097
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test for normal initialization
    try:
        class Test(ExceptionMixin):
            def __init__(self, *args, **kwargs) -> None:
                ExceptionMixin.__init__(self, *args, **kwargs)
            def _apply_exception_handler(self, handler: FutureException):
                return handler
    except:
        raise AssertionError('ExceptionMixin class initialization failed!')

    # test for normal output
    testclass = Test()
    def decorator(handler):
        return handler
    decorator = testclass.exception(decorator)
    assert callable(decorator)

    # test for abnormal output
    try:
        testclass.exception()
    except TypeError:
        pass
    else:
        raise AssertionError('ExceptionMixin class exception method failed!')

# Generated at 2022-06-24 04:13:26.748772
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_context = ExceptionMixin()
    assert type(test_context._future_exceptions) is set


# Generated at 2022-06-24 04:13:33.951266
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.models.futures import FutureException
    from .Futures import Futures

    futures = Futures()

    # Ensure that the instance of ExceptionMixin is created
    futures.__init__()

    # Ensure that the futures exceptions is a set
    assert isinstance(futures._future_exceptions, set)

    # Ensure that the futures exceptions is empty
    assert len(futures._future_exceptions) == 0

    # Add a future exception to the futures class
    futures._future_exceptions.add(FutureException(None, None))

    # Ensure that the future exceptions contains one object
    assert len(futures._future_exceptions) == 1


# Generated at 2022-06-24 04:13:36.382373
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class A(ExceptionMixin):
        pass
    a = A()
    assert a._future_exceptions == set()


# Generated at 2022-06-24 04:13:46.129198
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinMock(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
            self.exceptions = handler.exceptions

    class Handler1:
        def __init__(self):
            self.called = False

        def __call__(self, request, exception):
            self.called = True

    class Handler2:
        def __init__(self):
            self.called = False

        def __call__(self, request, exception, foo=None):
            self.called = True

    class Exception1(Exception):
        pass

    class Exception2(Exception):
        pass

    def test():
        # Test with empty
        handler1 = Handler1()
        exception_mixin = ExceptionMixin()

        handler_decorated = exception_mix

# Generated at 2022-06-24 04:13:49.734005
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    # Unit test to check if constructor creates a empty set
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions != []
    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:13:52.762356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert exception_mixin.__init__()
    assert exception_mixin._apply_exception_handler()
    assert exception_mixin.exception()


# Generated at 2022-06-24 04:13:56.896847
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass
    test = Test()
    assert isinstance(test, Test)

# Generated at 2022-06-24 04:14:01.268254
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(list)
    def handler(self) -> object:
        """ Exception handler method """
        return None
    assert handler.__name__ == "handler"
    assert isinstance(handler, FutureException)


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-24 04:14:04.898904
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:14:07.062936
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    bp = ExceptionMixin()
    assert bp._future_exceptions == set()


# Generated at 2022-06-24 04:14:17.257322
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic.response import json
    from sanic import Sanic
    from sanic.views import HTTPMethodView

    class CustomView(ExceptionMixin, HTTPMethodView):
        def get(self, request):
            return json({'message': 'test'})

    def exception_handler(request, exception):
        return json({'message': 'fail'}, status=500)

    app = Sanic(__name__)
    CustomView.exception(ValueError)(exception_handler)
    app.add_route(CustomView.as_view(), '/')
    request, response = app.test_client.get('/')
    assert response.status == 200
    with pytest.raises(ValueError):
        raise ValueError
    request, response = app.test_client.get('/')

# Generated at 2022-06-24 04:14:17.965506
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-24 04:14:24.241688
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    class MockExceptionMixin(ExceptionMixin):
        pass
    # Try to initialize an instance of the class ExceptionMixin
    mock_exception_mixin = MockExceptionMixin()
    # Verify that the private attribute _future_exceptions is created with the expected value
    assert mock_exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:24.781937
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-24 04:14:32.513687
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == (ZeroDivisionError, TypeError)
            return None
    
    exceptMixin = TestExceptionMixin()
    
    @exceptMixin.exception(ZeroDivisionError, TypeError)
    def handler(request, exception):
        return None
    
    handler(None, None)

# Generated at 2022-06-24 04:14:35.277498
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("test")
    blueprint.exception(Exception)(lambda request, exception: "hello")


# Generated at 2022-06-24 04:14:38.883778
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin.__init__(ExceptionMixin(), 'args', 'kwargs') is None


# Generated at 2022-06-24 04:14:41.235993
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin(): 
    # Simple unit test to test constructor of class ExceptionMixin
    exception_mixin = ExceptionMixin()

    assert exception_mixin._future_exceptions == set()


# Generated at 2022-06-24 04:14:45.961971
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blueprint = Blueprint(__name__)

    @blueprint.exception(Exception)
    def handler(request, exception):
        return "This is a global exception handler for exceptions."

    assert blueprint._future_exceptions != set()

    for i in blueprint._future_exceptions:
        assert i._errors == (Exception,)
        assert i._handler.__name__ == 'handler'

# Generated at 2022-06-24 04:14:48.378403
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    app = Blueprint('test', url_prefix='test')

    def exception_handler(request, exception):
        return 1/0

    app.exception(ZeroDivisionError)(exception_handler)

# Generated at 2022-06-24 04:14:59.394902
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test that method exception of class ExceptionMixin is a decorator
    # by manually checking if the return value of exception is a decorator.

    # 1- Create a fake blueprint named 'bp' and check if it has a method
    #    'apply_exception_handler'
    # 2- Use the blueprint 'bp' to create a fake class 'C', where the class
    #    'C' inherits from ExceptionMixin.
    # 3- Manually apply the method exception on the class 'C'
    # 3- Check if the method exception returns a decorator by checking if
    #    the return value of @exception has a method __call__

    class bp:
        def apply_exception_handler(self, handler):
            pass


# Generated at 2022-06-24 04:15:01.933240
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():

  # Instance of class ExceptionMixin
  exc = ExceptionMixin()

  # Check attribute _future_exceptions
  assert hasattr(exc, "_future_exceptions")


# Generated at 2022-06-24 04:15:07.406416
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mixin = MyExceptionMixin()

    def exception_handler(request, exception):
        pass

    assert len(mixin._future_exceptions) == 0
    mixin.exception(ZeroDivisionError)(exception_handler)
    assert len(mixin._future_exceptions) == 1

# Generated at 2022-06-24 04:15:13.272401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
   from sanic.blueprints import Blueprint

   bp = Blueprint.new('test', url_prefix='test')

# Generated at 2022-06-24 04:15:19.451278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Example(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    example = Example()
    @example.exception(ZeroDivisionError)
    def handle_exception():
        print('handle exception')

    assert len(example._future_exceptions) == 1
    handle_exception()

# Generated at 2022-06-24 04:15:28.287551
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class EMI(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    emi = EMI()
    emi.exception(Exception)(1)
    emi.exception([ValueError, NameError])(2)
    emi.exception(Exception, apply=False)(3)
    assert len(emi._future_exceptions) == 3
    for fe in emi._future_exceptions:
        assert isinstance(fe, FutureException)
        assert fe.handler in [1, 2, 3]
        assert fe.exception in [Exception, ValueError, NameError]

# Generated at 2022-06-24 04:15:32.303878
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception = TestExceptionMixin()
    assert isinstance(test_exception._future_exceptions, set)
    assert test_exception.exception(ValueError)

# Generated at 2022-06-24 04:15:34.179988
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    test_ExceptionMixin = ExceptionMixin()
    assert test_ExceptionMixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:38.319685
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    from sanic import Blueprint
    blueprint = Blueprint("test")

    # exception should have initialized with an empty list
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-24 04:15:41.151505
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    exception_mixin = ExceptionMixin()
    assert exception_mixin is not None

# Generated at 2022-06-24 04:15:44.690310
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    """Unit test for constructor of class ExceptionMixin

    Tests:
        - instantiate ExceptionMixin
        - correct instance variables are initialized
    """
    from sanic import Sanic

    sanic_app = Sanic()
    exception_mixin = ExceptionMixin()

    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:46.945950
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    em = ExceptionMixin()
    assert em._future_exceptions is not None
    assert len(em._future_exceptions) == 0


# Generated at 2022-06-24 04:15:48.287897
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

# Generated at 2022-06-24 04:15:52.262243
# Unit test for constructor of class ExceptionMixin
def test_ExceptionMixin():
    assert ExceptionMixin._future_exceptions is not None
    assert len(ExceptionMixin._future_exceptions) is 0

# Generated at 2022-06-24 04:16:00.062699
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException
    from sanic.handlers import ErrorHandler
    from sanic.response import text

    class TestExceptionMixin(ExceptionMixin):

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.error_handler = ErrorHandler(self)

        def _apply_exception_handler(self, handler: FutureException):
            self.error_handler.add(
                handler, self, reraise=True
            )

        def get_error_handler(self, request, exception):
            """Returns the error handler to be used for the given exception.

            :param request: Sanic request
            :param exception: Exception object to be handled
            :return: ErrorHandler instance, if found, else None
            """
           