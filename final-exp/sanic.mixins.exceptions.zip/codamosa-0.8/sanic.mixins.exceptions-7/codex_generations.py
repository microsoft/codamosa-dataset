

# Generated at 2022-06-12 08:59:02.149580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SanicBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    blueprint = SanicBlueprint()
    blueprint.exception(Exception)
    assert str(blueprint) == "exception(Exception)"



# Generated at 2022-06-12 08:59:04.296725
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()
    assert a._future_exceptions == set()
    assert a.exception(Exception) != None
    assert a._future_exceptions != set()

# Generated at 2022-06-12 08:59:13.925753
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestingExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
    
    testing_exception_mixin = TestingExceptionMixin()
    def handler():
        pass
    testing_exception_mixin.exception(NotImplementedError)(handler)

    assert testing_exception_mixin.__dict__['_future_exceptions'] == set(
        [
            FutureException(handler, (NotImplementedError,))
        ]
    )
    assert testing_exception_mixin.__dict__.get('_apply_exception_handler', None) is None


# Generated at 2022-06-12 08:59:22.845811
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock
    from sanic.blueprints import Blueprint

    class BlueprintWithExceptionMixin(ExceptionMixin, Blueprint):
        pass

    blueprint = BlueprintWithExceptionMixin("test")
    blueprint._apply_exception_handler = MagicMock()
    blueprint._apply_exception_handler.return_value = None
    blueprint._apply_exception_handler.__name__ = "exception"

    def exc_handler():
        pass

    blueprint.exception(Exception, apply=False)(exc_handler)
    assert blueprint._future_exceptions

    blueprint.exception(Exception)(exc_handler)
    assert blueprint._future_exceptions

    blueprint._apply_exception_handler.assert_called_once()

# Generated at 2022-06-12 08:59:29.014314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint("test")
    blueprint.exception(ValueError)(print)
    blueprint.exception(ValueError)(print)
    blueprint.exception(ValueError)(print)
    blueprint.exception(ValueError)(print)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-12 08:59:31.709404
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ex_handler = ExceptionMixin()
    @ex_handler.exception(ValueError)
    def func():
        pass
    assert len(ex_handler._future_exceptions) == 1

# Generated at 2022-06-12 08:59:35.960933
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = [Exception]
    testing_object = ExceptionMixin()
    assert testing_object._future_exceptions == set() # noqa
    def handler(*args, **kwargs):
        print("Exception handler")
    decorated_function = testing_object.exception(*exceptions)(handler)
    assert testing_object._future_exceptions == set() # noqa
    decorated_function("Hello")

# Generated at 2022-06-12 08:59:43.582611
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBlueprint():
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    new_blueprint = FakeBlueprint()
    new_blueprint._apply_exception_handler(None)

    assert new_blueprint._future_exceptions == set()

    @new_blueprint.exception(ValueError)
    def my_handler(request, exception):
        pass

    assert type(new_blueprint._future_exceptions) == set
    assert len(new_blueprint._future_exceptions) == 1

    @new_blueprint.exception(KeyError, apply=False)
    def my_handler(request, exception):
        pass


# Generated at 2022-06-12 08:59:54.029208
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json
    from sanic_openapi import doc
    import pytest
    
    @doc.consumes(doc.Integer(name="a"))
    @doc.consumes(doc.Integer(name="b"))
    @doc.produces(doc.Integer(name="Result"))
    async def handler(request, a: int, b: int) -> int:
        return a + b

    class OpenAPIBlupper(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            @handler
            def handler_func(request, exception: Exception) -> int:
                return 0

    app = Sanic()


# Generated at 2022-06-12 09:00:04.945177
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.models import future
    from sanic.models.futures import FutureException
    from sanic.views import HTTPMethodView

    class ExceptionClass(Exception):
        pass

    @expect(FutureException)
    async def exception_handler(request, exception):
        pass

    blueprint = Blueprint(__name__, url_prefix='/exception')

    blueprint.exception(ExceptionClass)(exception_handler)

    @blueprint.route('/test')
    async def test(request):
        raise ExceptionClass()

    app = Sanic(__name__)
    app.blueprint(blueprint)

    assert _call_route(app, '/exception/test') == HTTPMethodView.empty_body
   

# Generated at 2022-06-12 09:00:11.146283
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class mp(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    @mp.exception(Exception)
    def testexc_handler(request, exception):
        return exception

    @mp.exception([Exception, ValueError])
    def testexc_handler2(request, exception):
        return exception

    assert issubclass(testexc_handler.exceptions, Exception)
    assert issubclass(testexc_handler2.exceptions, Exception)
    assert issubclass(testexc_handler2.exceptions, ValueError)


test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:00:17.433144
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_subclass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    instance = ExceptionMixin_subclass()

    @instance.exception(Exception)
    def func():
        pass

    assert(type(instance._future_exceptions.pop()) == FutureException)
    assert(func.__name__ == 'func')

# Generated at 2022-06-12 09:00:18.019365
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:00:25.281419
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        pass

    dummy_exception_mixin = DummyExceptionMixin()
    assert dummy_exception_mixin._future_exceptions == set()

    # Add a first exception
    def test_exception_first(request, exception):
        pass
    dummy_exception_mixin.exception(Exception)(test_exception_first)
    assert len(dummy_exception_mixin._future_exceptions) == 1
    assert dummy_exception_mixin._future_exceptions == \
        {
            FutureException(test_exception_first, (Exception, ))
        }

    # Add a second exception
    def test_exception_second(request, exception):
        pass

# Generated at 2022-06-12 09:00:33.029305
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .models.api import Api

    api = Api()

    @api.exception((ValueError,))
    def handler1(request, exception):
        return exception.args

    assert handler1.__name__ == "handler1"

    @api.exception([ValueError])
    def handler2(request, exception):
        return exception.args

    assert handler2.__name__ == "handler2"

    assert next(iter(api._future_exceptions)).handler is handler1

    assert next(iter(api._future_exceptions)).handler is handler2

# Generated at 2022-06-12 09:00:39.070033
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin
    :return:
    """
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler):
            return handler

    # test_exception_mixin_exception_1
    ExceptionMixinTest.exception("TestException", apply=False)

# Generated at 2022-06-12 09:00:44.272096
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print(handler)
    test_obj = TestExceptionMixin()

    @test_obj.exception(TypeError, ValueError)
    def on_error(request, exception):
        pass
    assert len(test_obj._future_exceptions) == 1

# Generated at 2022-06-12 09:00:47.210551
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class TestClass(ExceptionMixin):
        pass
    exception = TestClass()

    # When & Then
    assert exception.exception is TestClass.exception


# Generated at 2022-06-12 09:00:55.958250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super(TestClass, self).__init__()
            self.result = []
        @ExceptionMixin.exception(Exception, apply=True)
        def test_exception(self, **kwargs):
            self.result.append(kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == 'test_exception'
            assert handler.exceptions[0] == Exception
    test = TestClass()
    test.test_exception({"1":"1"})
    assert test.result == [{"1":"1"}]


# Generated at 2022-06-12 09:01:06.832926
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest:
        def __init__(self, *args, **kwargs):
            assert isinstance(args, tuple)
            assert isinstance(kwargs, dict)
            self._future_exceptions = {FutureException(None, 'test')}
            self.logger = kwargs.get('logger', None)

        def _apply_exception_handler(self, handler):
            self.logger = handler

        def exception(self, *args, **kwargs):
            apply = kwargs.get('apply', True)
            nonlocal args
            exceptions = args[0]
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions
                nonlocal self
                if isinstance(exceptions, list):
                    exceptions = tuple(*exceptions)

# Generated at 2022-06-12 09:01:18.578142
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            handler.apply()

    blueprint = TestExceptionMixin()

    @blueprint.exception(IndexError)
    def exception_handler(request, exception):
        return "Exception handled"

    assert len(blueprint._future_exceptions) == 1
    exception = blueprint._future_exceptions.pop()

    assert exception.handler() == "Exception handled"
    assert isinstance(exception.exceptions, tuple)
    assert exception.exceptions == (IndexError,)

# Generated at 2022-06-12 09:01:23.643278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    emt = ExceptionMixinTest()
    # test exception
    @emt.exception(ValueError)
    def a_func():
        pass
    assert len(emt._future_exceptions) == 1


# Generated at 2022-06-12 09:01:26.136473
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test_bp', url_prefix='/test_bp')
    assert hasattr(bp, 'exception')
    assert callable(bp.exception)

# Generated at 2022-06-12 09:01:30.485246
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    assert repr(bp.exception()) == repr(bp.exception)
    assert repr(bp.exception(HTTPException)) == repr(bp.exception)
    assert repr(bp.exception(HTTPException, apply=False)) == repr(bp.exception)
    assert repr(bp.exception([HTTPException, NotFound])) == repr(bp.exception)

# Generated at 2022-06-12 09:01:32.110159
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_obj = TestExceptionMixin()
    test_obj.exception(ValueError)

# Generated at 2022-06-12 09:01:41.595724
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler):
            return True
    
    # _apply_exception_handler is not used
    a = A()
    assert len(a._future_exceptions) == 0
    a.exception(Exception,'a')
    assert len(a._future_exceptions) == 1

    # _apply_exception_handler is not used
    a = A()
    assert len(a._future_exceptions) == 0
    a.exception(Exception,'a',apply=False)
    assert len(a._future_exceptions) == 1

    # _apply_exception_handler is used
    a = A()
   

# Generated at 2022-06-12 09:01:42.817450
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:53.214126
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin')
    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        pass

    # This is the set of exceptions
    assert(blueprint._future_exceptions)

    # This is the handler
    assert(blueprint._future_exceptions.pop()
           .handler.__name__ == 'handler')

    # This is the exception
    assert(blueprint._future_exceptions.pop()
           .exceptions == (SanicException,))

    # This is the empty set of exceptions
    assert(not blueprint._future_exceptions)


# Generated at 2022-06-12 09:02:02.152490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    app = Sanic(__name__)
    blueprint = app.blueprint(__name__)
    blueprint.exception(Exception)(Exception)
    blueprint.exception(Exception)(Exception)
    blueprint.exception(Exception)(Exception)
    blueprint.exception(Exception)(Exception)

    assert blueprint, "Can't create blueprint"
    assert blueprint.exception, "Can't create exception handler"
    assert blueprint.exception.__func__, "Can't create exception handler"
    assert blueprint.exception.__func__.__call__, "Can't create exception handler"
    assert blueprint.exception.__func__.__call__.__func__, "Can't create exception handler"

# Generated at 2022-06-12 09:02:07.145238
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage
    from sanic.app import Sanic

    def handler(request, exception):
        return json({'status': 400, 'message': str(exception)})

    app = Sanic("test_ExceptionMixin_exception")

    app.blueprint(ExceptionMixin)

    @app.exception(InvalidUsage)
    def handle_exception(request, exception):
        return json({'status': 400, 'message': 'bad request'})
    app.run(debug=True)

# Generated at 2022-06-12 09:02:21.048317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.util.log import log_to_file
    from sanic import Sanic
    from sanic.exceptions import NotFound

    log_to_file("tests.log", "logs")
    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint("test_bp", url_prefix="/test/bp")
    @bp.exception(NotFound)
    def _handle_exception(request, exception):
        return text("You are looking for something that cannot be found.")

    app.blueprint(bp)

    @app.route('/test/bp/test_get')
    async def test_get(request):
        # This route does not exist
        await request.app.get('/test/bp/404')

# Generated at 2022-06-12 09:02:25.817478
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def handler():
        pass
    
    exceptions = [None]
    fEx = FutureException(handler, exceptions)
    fExMixin = ExceptionMixin()
    fExMixin._future_exceptions.add(fEx)
    fExMixin._apply_exception_handler(fEx)
    assert fEx in fExMixin._future_exceptions
    
    

# Generated at 2022-06-12 09:02:33.468313
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('blueprint', url_prefix="/test")
    blueprint.exception(ValueError)
    blueprint.exception(ZeroDivisionError)
    
    assert(
        len(blueprint._future_exceptions) == 2 and
        (
            type(list(blueprint._future_exceptions)[0].exceptions[0]) == ValueError 
            and 
            type(list(blueprint._future_exceptions)[1].exceptions[0]) == ZeroDivisionError
        )
    )

# Generated at 2022-06-12 09:02:43.569914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic import Sanic
    from sanic.models.futures import FutureException

    app = Sanic(__name__)
    temp = app

    @app.exception(NotFound)
    def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))
    assert len(app._future_exceptions) == 1
    assert app._future_exceptions == {FutureException(ignore_404s, NotFound)}

    @app.get("/")
    async def handler1(request):
        return text("OK")

    request, _ = app.test_client.get("/")
    assert request.status == 200

    request, _ = app.test_client.get

# Generated at 2022-06-12 09:02:47.956639
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from .testing import SanicTestClient
    from sanic import Sanic
    from sanic.exceptions import NotFound, Unauthorized, ServerError

    app = Sanic()

    @app.exception(NotFound)
    async def ignore_404s(request, exception):
        return response.text('Got a 404')


# Generated at 2022-06-12 09:02:55.583970
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.models import FutureException
    from sanic.response import text

    app = Sanic(name="test_ExceptionMixin_exception")

    bp = Blueprint("test_ExceptionMixin_exception")

    @bp.exception(NotFound)
    def not_found(request, exception):
        return text("Not found", status=404)

    app.blueprint(bp)

    request, response = app.test_client.get("/")

    assert response.status == 404
    assert response.text == "Not found"

    assert len(bp._future_exceptions) == 1
    future_exception = bp._future_exceptions.pop()


# Generated at 2022-06-12 09:02:58.961779
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test", url_prefix='test')
    @bp.exception(Exception)
    def test_handler(request, exception):
        return "OK"
    

# Generated at 2022-06-12 09:03:03.502989
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_rest.blueprints import BaseBlueprint
    class Blueprint(ExceptionMixin, BaseBlueprint):
        pass

    @Blueprint.exception
    def foo():
        pass

    Blueprint._apply_exception_handler = lambda _: None

    assert len(Blueprint._future_exceptions) == 1

    future_exception, = Blueprint._future_exceptions
    assert future_exception._handler == foo

    expected_exceptions = (Exception,)
    assert future_exception._exceptions == expected_exceptions

# Generated at 2022-06-12 09:03:07.605875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BluePrint(ExceptionMixin):
        pass
    x = BluePrint()
    x.exception(Exception, ValueError, lambda req, res, e: None)()
    x.exception([Exception, ValueError], lambda req, res, e: None)()
    assert len(x._future_exceptions) == 2

# Generated at 2022-06-12 09:03:14.488921
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @sanic.blueprint.blueprint('/test')
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            handler.handler()

    test = Test()

    @test.exception(NameError)
    def test_handler():
        print('basic exception handler')

    assert len(test._future_exceptions) == 1, 'the length of future_exception is not 1'
    assert isinstance(test._future_exceptions, set)
    test._future_exceptions.remove(test._future_exceptions.pop())


# Generated at 2022-06-12 09:03:30.139163
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()
            self.register_route = None
            self.handler = None
            self.excep_type_list = None
            self.apply = None

        def register_route(self, route):
            self.route = route

        def _apply_exception_handler(self, handler):
            self.handler = handler
            self.excep_type_list = handler.excep_type_list
            self.apply = True

    class TestHandler:
        def __init__(self):
            self.applied = None

        def __call__(self, request, exception):
            self.request = request
            self.exception = exception
            self.applied = True


# Generated at 2022-06-12 09:03:35.432846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('sanic-test')
    bp = Blueprint('my-blueprint')

    @bp.exception(Exception)
    def handler(request, exception):
        return "inside handler"

    assert len(bp._future_exceptions) == 1
    assert handler.__name__ == 'handler'

# Generated at 2022-06-12 09:03:36.227898
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False, 'Not Implemented'

# Generated at 2022-06-12 09:03:39.673190
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @test.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test._future_exceptions) == 1

# Generated at 2022-06-12 09:03:45.108046
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    @Test().exception(Exception)
    def func():
        pass
    
    # The function in the decorator should be handler
    assert func == Test._future_exceptions.pop().handler
    # the exception should be Exception
    assert tuple(Test._future_exceptions.pop().exceptions)[0] == Exception

# Generated at 2022-06-12 09:03:50.620048
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BP(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = BP()
    exceptions = (Exception, SystemExit)
    mock_func = lambda: None
    future_exception = FutureException(mock_func, exceptions)

    result = bp.exception(*exceptions, apply=False)(mock_func)
    assert result == mock_func
    assert future_exception in bp._future_exceptions

# Generated at 2022-06-12 09:03:57.104185
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    te = TestExceptionMixin()
    assert te._future_exceptions == set()
    assert set(te.exception()) == {set([])}
    assert te._future_exceptions == set()
    assert set(te.exception(apply=False)) == {set([])}
    assert te._future_exceptions == set()
    assert set(te.exception(Exception)) == {set([Exception()])}
    assert te._future_exceptions == set()
    assert set(te.exception(Exception, apply=False)) == {set([Exception()])}
    assert te._future_exceptions == set()


# Generated at 2022-06-12 09:04:02.528360
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__)
    blueprint.exception(Exception)(print)
    future_exception = FutureException(print, Exception)
    assert len(blueprint._future_exceptions) == 1
    assert future_exception in blueprint._future_exceptions



# Generated at 2022-06-12 09:04:08.614527
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptions(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    me = MyExceptions()
    assert len(me._future_exceptions) == 0

    @me.exception(KeyError, ValueError)
    def exc_handler():
        pass

    assert len(me._future_exceptions) == 1

    @me.exception(IOError)
    def exc_handler_1():
        pass

    assert len(me._future_exceptions) == 2

# Generated at 2022-06-12 09:04:14.227928
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Exception(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Exception, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    @Exception.exception(Exception)
    def handler():
        print("Exception handler")

    assert handler.__name__ == "handler"

    assert len(Exception._future_exceptions) == 1
    assert handler in Exception._future_exceptions
    assert Exception in handler._exceptions

# Generated at 2022-06-12 09:04:34.476069
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BpMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return "return object"

    bm = BpMixin()
    new_object = bm.exception("test")
    assert "return object" == new_object("test")

# Generated at 2022-06-12 09:04:42.113320
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    future_exception = FutureException(None, None)
    blueprint_exception_mixin = ExceptionMixin()
    blueprint_exception_mixin._future_exceptions = set()
    blueprint_exception_mixin._future_exceptions.add(future_exception)
    assert future_exception in blueprint_exception_mixin._future_exceptions

    # test for decorator
    @blueprint_exception_mixin.exception(Exception)
    def inner_func(request):
        return HTTPResponse('OK')
    request = Request('GET', '/')
    assert inner_func(request).body == b'OK'

    # test for decorator with apply is True


# Generated at 2022-06-12 09:04:46.538073
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(IndexError, ZeroDivisionError)
    def handle_error(request, exception):
        pass
    mixin = ExceptionMixin()
    request = mock.MagicMock()
    mixin._apply_exception_handler = mock.MagicMock()
    handle_error(request, IndexError())
    handle_error(request, ZeroDivisionError())
    assert len(mixin._future_exceptions) == 1
    assert mixin._apply_exception_handler.call_count == 1
    assert handle_error(request, KeyError()) == None

# Generated at 2022-06-12 09:04:54.430004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse

    @Blueprint.exception(Exception)
    def handler(request, exception):
        return HTTPResponse("Internal server error", status=500)

    @Blueprint.get("/")
    def index(request):
        1 / 0

    blueprint = Blueprint("test", "/", strict_slashes=True)
    blueprint.add_exception_handler(handler)
    blueprint.add_route(index, "/")
    blueprint
    url = blueprint.url_for("index")
    request, response = blueprint.handle_request(Request.from_uri(url))

    assert response.status == 500

# Generated at 2022-06-12 09:04:58.985755
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

    bp = MyClass()
    bp.exception(ValueError)(print)
    assert isinstance(bp._future_exceptions.pop(), FutureException)

    bp = MyClass()
    bp.exception([ValueError, AttributeError])(print)
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 09:05:04.522004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    m = ExceptionMixin()
    # When
    @m.exception(TypeError)
    def handler(request, exc):
        pass
    # Then
    assert isinstance(handler, types.FunctionType)

# Generated at 2022-06-12 09:05:11.929883
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_exception')

    @bp.exception(Exception)
    def handler1(request, exception):
        return text('OK')

    @bp.exception([ValueError])
    def handler2(request, exception):
        return text('OK')

    @app.route('/')
    def index(request):
        raise ValueError('Raising an error')

    app.blueprint(bp)
    request, response = app.test_client.get('/')
    assert response.text == 'OK'



# Generated at 2022-06-12 09:05:17.344450
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # - Unit test for ExceptionMixin.exception() by checking that
    #   it raises an exception when it is called with a non-callable
    #   parameter handler. 
    # - It should raise a TypeError exception.
    @ExceptionMixin.exception(handler=12)
    def handler(request, exception):
        assert request is None
        assert exception is None

    with pytest.raises(TypeError):
        handler(None, None)

# Generated at 2022-06-12 09:05:19.980164
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    ExceptionMixinTest()

# Generated at 2022-06-12 09:05:28.839580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import abort

    class MyException(Exception):
        pass

    error_return = {}

    def exception_handler(request, exception):
        error_return['exception'] = exception
        error_return['msg'] = 'exception handled by blueprint'
        abort(500)

    blueprint = Blueprint('test', url_prefix='/test')
    blueprint.exception(MyException)(exception_handler)
    assert len(blueprint._future_exceptions) == 1

    app = Sanic('test_exception')
    app.blueprint(blueprint)

    @app.route('/test')
    def test_exception(request):
        raise MyException


# Generated at 2022-06-12 09:06:03.594982
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    t = Test_ExceptionMixin()
    @t.exception(Exception)
    def handler(x):
        pass

# Generated at 2022-06-12 09:06:11.679837
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return

    # test with 1 exception
    exception_mixin = TestExceptionMixin()
    @exception_mixin.exception(Exception)
    def handler_function(request, exception):
        return "exception"

    assert len(exception_mixin._future_exceptions) == 1
    assert isinstance(exception_mixin._future_exceptions.pop(), FutureException)

    # test with many exceptions
    @exception_mixin.exception(Exception, ValueError)
    def handler_function(request, exception):
        return "exception"

    assert len

# Generated at 2022-06-12 09:06:16.385343
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test', url_prefix='test')
    app.blueprint(bp)
    @bp.exception(Exception)
    def fail(request, exception):
        assert True

    @bp.listener('before_server_start')
    def before_server_start(sanic, loop):
        assert True
        app.stop()

    app.run(debug=True)
    assert Router._exception_handler

# Generated at 2022-06-12 09:06:23.299630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Set up mocks
    class BlueprintStub:
        pass

    class RequestStub:
        pass

    class SanicMock:
        def make_response(self, *args, **kwargs):
            pass

    # Instantiate object
    mixin = ExceptionMixin()

    # Create a list of excpetions
    exceptions = [Exception, TypeError]

    # Create a handler
    def handler(request: RequestStub, exception):
        pass

    decorated_handler = mixin.exception(*exceptions, apply=False)(handler)
    assert decorated_handler == handler

    # Create an exception
    new_exception = Exception(message="test")

    # Call a handler
    request = RequestStub()
    SanicMock().make_response(decorated_handler(request, new_exception))

# Generated at 2022-06-12 09:06:26.671580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test_bp', url_prefix='test')
    @bp.exception([ValueError, KeyError])
    def ex(request, exception):
        1/0
    assert ex == bp._future_exceptions.pop().handler
    assert bp._future_exceptions == set()

# Generated at 2022-06-12 09:06:34.047892
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Testcase No.1 - Test exception method
    te = TestExceptionMixin()
    exception_handler = te.exception(Exception('Something wrong again'))
    assert (
        len(te._future_exceptions) == 1
    )  # exception method can throw exceptions and can store them
    assert (
        len(te._future_exceptions) == 1
    )  # exception method can throw exceptions and can store them

    # Testcase No.2 - Test exception method
    te = TestExceptionMixin()
    exception_handler = te.exception([Exception('Something wrong again')])
    assert (
        len(te._future_exceptions) == 1
    )  # exception method can throw exceptions

# Generated at 2022-06-12 09:06:40.145094
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint("test_ExceptionMixin_exception", url_prefix="test")

    @app.exception(Exception)
    def handle_exception(request, exception):
        print("Handle exception")

    @app.exception(Exception)
    @bp.exception(Exception)
    def handle_exception(request, exception):
        print("Handle exception")

    assert app.exception_handler._future_exceptions is not None
    assert bp.exception_handler._future_exceptions is not None

    assert (Exception,) in app.exception_handler._future_exceptions
    assert (Exception,) in bp.exception_handler._future_exceptions

# Generated at 2022-06-12 09:06:40.876626
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:06:45.810580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()

    @mixin.exception(Exception)
    def exception_handler(request, exception):
        # The handler is just always going to return a 500 response
        return text("Something went wrong!")

    assert len(mixin._future_exceptions) == 1
    assert isinstance(mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 09:06:47.787089
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        pass

    ex_mixin_test = ExceptionMixinTest()
    assert ex_mixin_test._future_exceptions == set()

# Generated at 2022-06-12 09:07:59.140081
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(Exception)
    def example(request, exception):
        pass

    assert example in list(bp._future_exceptions)

    @bp.exception([Exception, Exception])
    def example(request, exception):
        pass

    assert example in list(bp._future_exceptions)

    @bp.exception(Exception, apply=False)
    def example(request, exception):
        pass

    assert example in list(bp._future_exceptions)

    @bp.exception([Exception, Exception], apply=False)
    def example(request, exception):
        pass

    assert example in list(bp._future_exceptions)

# Generated at 2022-06-12 09:08:00.948474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def exception_handler(request, exception):
        return exception
    assert exception_handler(Exception) is not None

# Generated at 2022-06-12 09:08:09.019165
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import text

    bp = Blueprint("test", url_prefix="test")

    @bp.exception(Exception)
    def handler1(request, exception):
        assert isinstance(request, Request)
        assert isinstance(exception, Exception)
        return text("OK")

    @bp.exception(Exception)
    def handler2(request, exception):
        return text("OK2")

    assert bp.exception._future_exceptions

    assert bp.exception._future_exceptions.size() == 2

    @bp.route("/", methods=["GET"])
    def handler(request):
        raise Exception


# Generated at 2022-06-12 09:08:12.529239
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Create object Blueprint
    bp = Blueprint()

    # Create exception handler
    @bp.exception(Exception)
    def except_handler(request, exception):
        pass

    # Check attribute future_exceptions
    assert len(bp._future_exceptions) == 1

# Test for ExceptionMixin

# Generated at 2022-06-12 09:08:12.934433
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:08:14.424743
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def handler():
        pass
    assert isinstance(handler, function)
    assert callable(handler) is True

# Generated at 2022-06-12 09:08:19.760764
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Preparation
    from sanic.models.futures import ExceptionHandler
    from sanic.models.blueprints import Blueprint
    from sanic import Sanic

    # Create exception handler
    def error_handler(request, exception):
        return "error handling!!!"

    # create a blueprint
    blueprint = Blueprint("test")

    # register exception handler
    blueprint.exception([Exception])(error_handler)

    sanic = Sanic(blueprint)

    # Assertion
    # The exception handler should be added to future_exceptions
    # of blueprint
    assert isinstance(blueprint._future_exceptions.pop(),
                      ExceptionHandler)
    assert blueprint._exception_handlers == []

# Generated at 2022-06-12 09:08:20.185580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:08:25.269591
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from unittest.mock import Mock

    from sanic.blueprints import Blueprint

    bp = Blueprint("name")

    bp.exception(KeyError)(Mock())

    future_exception = FutureException(Mock, (KeyError, ))

    assert future_exception in bp._future_exceptions

    @bp.exception(KeyError, apply=False)
    def exception(request, exception):
        pass

    future_exception = FutureException(exception, (KeyError, ))

    assert future_exception in bp._future_exceptions
    assert exception not in bp.error_handler

# Generated at 2022-06-12 09:08:26.796549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception
    def test_handler():
        return 0

    assert test_handler() == 0