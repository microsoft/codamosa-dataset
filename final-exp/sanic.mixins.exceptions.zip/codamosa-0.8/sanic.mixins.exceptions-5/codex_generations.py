

# Generated at 2022-06-12 08:59:03.271682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    @a.exception(Exception)
    def h(r, e):
        return 1, {}
    assert h() == (1, {})
    assert next(iter(a._future_exceptions)).exceptions == (Exception,)
    assert next(iter(a._future_exceptions)).handler() == (1, {})


# Generated at 2022-06-12 08:59:09.710023
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_exception', url_prefix='exception')

    @bp.exception(ServerError)
    def exception_handler(request, exception):
        assert type(request) is Request
        assert type(exception) is ServerError

    assert bp.error_handler.keys() == {500}

    @bp.route('/')
    def index(request):
        raise ServerError("Oops!", status_code=500)

    request, response = bp.create_request_and_response(url='/', method='GET')
    response = bp.handle_request(request)
    assert response.status == 500

    request, response = bp.create_request_and_response(url='/', method='GET')

# Generated at 2022-06-12 08:59:17.305282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    class FakeException(Exception):
        pass

    class FakeBlueprint(Blueprint, ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)
            Blueprint.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @FakeBlueprint.exception(FakeException)
    def handle_all_errors(request, exception):
        pass
    assert True

# Generated at 2022-06-12 08:59:22.320370
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import os
    import sys
    import inspect
    from bedframe.helpers import load_module
    namespace = {}
    sys.path.append("./test")
    load_module(os.path.join(os.path.dirname(
        inspect.getfile(test_ExceptionMixin_exception)), "ExceptionMixin.py"), namespace)
    mixin = namespace["ExceptionMixin"]
    mixin_obj = mixin()
    assert namespace["Mixin"]._func1.__name__ == "func1"
    assert "Mixin" in namespace
    namespace["Mixin"]._func1()
    assert namespace["Mixin"]._func2.__name__ == "func2"
    assert namespace["Mixin"]._func2() == [2, 3, 5, 7]

# Generated at 2022-06-12 08:59:25.772697
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 08:59:31.233501
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__, version='v1')

    @blueprint.exception(Exception)
    def handler(request, exception):
        return "no error handler for {}".format(type(exception).__name__)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-12 08:59:36.652309
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest:
        def __init__(self):
            self.exceptions = set()
            self.handler = None
            self.is_apply_exception_handler = False
            self.is_decorator_called = False

        @property
        def future_exceptions(self):
            return self.exceptions

        def _apply_exception_handler(self, handler):
            self.is_apply_exception_handler = True
            self.handler = handler

    def test_handler():
        pass

    ExceptionMixinTest.exception = ExceptionMixin.exception
    exception_mixin = ExceptionMixinTest()
    exception_mixin.exception([Exception, IndexError])(test_handler)

    # Check that the decorator is called
    assert exception_mixin.is_decorator_called

# Generated at 2022-06-12 08:59:43.455910
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.handlers import ErrorHandler
    from sanic.exceptions import SanicException
    from sanic.response import HTTPResponse

    class SubException(SanicException):
        def __init__(self, msg):
            super(SubException, self).__init__(msg)

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self.app.error_handler.add(handler.exceptions, handler.handler)

    blueprint = Blueprint('test', url_prefix='/test')

# Generated at 2022-06-12 08:59:51.973913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.app import Sanic

    app = Sanic('test_ExceptionMixin_exception')

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            @app.exception(handler.exception_types)
            def handler_wrapper(request, exception):
                handler(request, exception)

    MyExceptionMixin().exception(Exception, apply=True)(lambda request, exception: None)
    assert len(app.error_handler.keys()) == 1


# Generated at 2022-06-12 09:00:02.525294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptions = ['ZeroDivisionError']
    apply = True

    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Blueprint, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = Blueprint()  # type: ignore

    @bp.exception(exceptions, apply)
    def handler(request, exception):
        pass

    # check if future exception is saved in _future_exceptions
    assert len(bp._future_exceptions) == 1

    # check future_exception's attributes
    future_exception = bp._future_exceptions.pop()
    assert isinstance(future_exception.exception, tuple)

# Generated at 2022-06-12 09:00:04.995089
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:00:10.726106
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.exceptions import NotFound
    import json
    import pytest

    blue = Blueprint("exception")
    @blue.exception(NotFound)
    def handle(request, exception):
        return text("Exceptions!")

    @blue.route("/exception")
    def test(request):
        raise NotFound

    # @blue.route("/exception/<a>")
    # async def async_test(request, a):
    #     raise NotFound({"response": a})

    # a = json.dumps({"response": "exception"})
    app = blue.create_app()
    request, response = app.test_client.get("/exception") # noqa

# Generated at 2022-06-12 09:00:15.628809
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    m = ExceptionMixin()
    # Act
    @m.exception()
    def handler():
        return None
    assert handler is not None
    # Assert

# Generated at 2022-06-12 09:00:24.048186
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import json
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.models.futures import FutureException
    from unittest import mock
    import pytest

    bp = Blueprint("test_sanic_bp_exception", url_prefix="test")
    @bp.listener("before_server_start")
    async def before_server_start(app, loop):
        pass

    @bp.exception(SanicException, apply=False)
    def handler(request: Request, exception: SanicException):
        return json({"exception": True})


# Generated at 2022-06-12 09:00:30.560396
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.exceptions import SanicException

    bp = Blueprint(__name__)
    bp.exception(SanicException)(lambda : None)
    bp._apply_exception_handler(FutureException(lambda : None, (SanicException,)))
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:00:41.920008
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)
    
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    exception_mixin1 = ExceptionMixin1()
    @exception_mixin1.exception(1, 2, 3)
    def test_method1():
        print("test_method1")
    
    @exception_mixin1.exception([1, 2, 3], [1, 2, 3])
    def test_method2():
        print("test_method2")
    
    assert len(exception_mixin1._future_exceptions) == 2

# Generated at 2022-06-12 09:00:52.182672
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestResponse():
        def __init__(self):
            self.content = None

    class TestRequest():
        def __init__(self):
            self.app = None
            self.headers = None

    class TestSanic():
        def __init__(self):
            self.blueprints = {}

    class TestExceptionMixin(ExceptionMixin):
        def error_handler(self, request, exception):
            response = TestResponse()
            response.content = b'I am Exception handler'
            return response

        def set_exception_handler(self):
            self.exception(Exception)(self.error_handler)

    class TestBlueprint:
        def __init__(self, name):
            self.name = name
            self.exception_handlers = {}

    #Test
    test_blueprint = TestBlue

# Generated at 2022-06-12 09:00:54.966531
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert True
    A().exception(ValueError, apply=True)(lambda x: x)

# Generated at 2022-06-12 09:01:00.336507
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.models.branches import Branch
    from sanic.models.exceptions import ExceptionModel

    bp = Blueprint("bp", host='', version='1.0.0', preserve_path=False)
    branch = Branch(
            "GET",
            "/",
            [],
            [],
            {},
            "default",
            "default",
            '',
            ExceptionModel([]),
            True,
            False,
            False
        )
    branch.exceptions = []

    def decorator(handler):
        return handler

    func_exception = bp.exception(Exception)
    assert isinstance(func_exception, decorator)
    branch.exceptions.append(func_exception)

# Generated at 2022-06-12 09:01:01.240155
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:11.509767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: Exception):
            pass

    class TestExceptionMixin2(ExceptionMixin):

        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: Exception):
            pass

    fut_exp = FutureException()

    TestExceptionMixin = TestExceptionMixin1()
    TestExceptionMixin._future_exceptions.add(fut_exp)
    assert fut_exp in TestExceptionMixin._future_ex

# Generated at 2022-06-12 09:01:18.993113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test')

    class DummyRequest:
        pass

    class DummyResponse:
        pass

    def error_handler(request, exception):
        return DummyResponse()

    @bp.exception(Exception)
    def error_handler(request, exception):
        return DummyResponse()

    assert bp.error_handler_list != []
    request = DummyRequest()
    response = error_handler(request, Exception('error'))
    assert response is DummyResponse()

# Generated at 2022-06-12 09:01:28.272608
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.exceptions import SanicException

    blueprint = Blueprint("test", url_prefix="test")

    @blueprint.exception(apply=False)
    def handler1(request, exception):
        assert exception.__class__ in blueprint._future_exceptions.pop().exceptions
        assert exception.__class__ == SanicException
        assert request.path == "/test"

    @blueprint.exception(SanicException, apply=False)
    def handler2(request, exception):
        assert exception.__class__ in blueprint._future_exceptions.pop().exceptions
        assert exception.__class__ == SanicException
        assert request.path == "/test"


# Generated at 2022-06-12 09:01:32.562543
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(DummyExceptionMixin, self).__init__()
            self._future_exceptions: Set[FutureException] = set()

    dummy_exception_mixin = DummyExceptionMixin()
    dummy_exception_mixin.exception(Exception)(print)
    assert len(dummy_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:01:40.315264
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    a=A()
    # if test_decorator function is requested, call test function
    # if test_decorator is a decorator, call test_decorator()
    # this is a decorator
    test_decorator=a.exception(ValueError)
    @test_decorator
    def test(request, exception):
        return "test"
    assert test



# Generated at 2022-06-12 09:01:46.241892
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(Exception):
        pass
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._apply_exception_handler = Mock()
        def future_exceptions(self):
            return self._future_exceptions
    
    # test exception
    def test_exception_handler():
        pass
    
    test_exception_mixin = TestExceptionMixin()
    test_exception_handler = Mock()
    test_exceptions = [TestException, TypeError]
    test_exception_handler.side_effect = test_exception_handler
    test_exception_handler = test_exception_mixin.exception(*test_exceptions)(test_exception_handler)
    test_exception_handler()

    # test

# Generated at 2022-06-12 09:01:51.021117
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def test_exception_handler(request, exception):
        pass

    test_exception_mixin = TestExceptionMixin()
    assert (
        test_exception_mixin.exception(list(Exception))
        == test_exception_handler
    )

# Generated at 2022-06-12 09:01:56.669988
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    sanic_app = Sanic("test_ExceptionMixin_exception")
    blueprint = Blueprint("test_bp", url_prefix="test_ExceptionMixin_exception")

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        return text("Exception")

    sanic_app.blueprint(blueprint)
    request, response = sanic_app.asgi_client.get("/exception")
    assert response.status == 200



# Generated at 2022-06-12 09:01:59.662615
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test method exception of class ExceptionMixin
    """

    f = ExceptionMixin()

    @f.exception(apply=False)
    def test_handler():
        return 1

    assert isinstance(test_handler, function)

# Generated at 2022-06-12 09:02:01.789756
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert isinstance(
        ExceptionMixin().exception(Exception, ValueError, AssertionError)(print),
        print
    )

# Generated at 2022-06-12 09:02:18.293575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Unit test for method exception
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            self._apply_exception_handler = apply
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    test = TestExceptionMixin()
    with pytest.raises(TypeError):
        test.exception()
    @test.exception(Exception)
    def test1():
        pass
    assert len(test._future_exceptions) == 1
    assert test._future_exceptions.pop().exceptions == (Exception,)

# Generated at 2022-06-12 09:02:26.762238
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass
    class MyException1(Exception):
        pass
    class MyException2(Exception):
        pass
    class MyException3(Exception):
        pass

    from sanic.blueprints import SanicBlueprint
    from sanic.exceptions import NotFound
    _blueprint = SanicBlueprint('my_blueprint')

    @_blueprint.exception(MyException1, NotFound)
    def my_handler(request, exception):
        return response.text("Exception raised")

    assert len(_blueprint._future_exceptions) == 2
    assert len(_blueprint._exception_handlers) == 2

    @_blueprint.exception(MyException2, _apply=False)
    def my_handler(request, exception):
        return response.text("Exception raised")

    assert len

# Generated at 2022-06-12 09:02:36.059843
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class FakeRequest:
        def __init__(self):
            pass

    class FakeBlueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

            self.exception_handlers: List[Tuple[
                FutureException, Callable]] = []

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handlers.append(handler)

    fake = FakeBlueprint()
    @fake.exception()
    def handler(request: FakeRequest, exception):
        pass

    fake_request = FakeRequest()

    assert len(fake.exception_handlers) == 1
    assert len(fake._future_exceptions) == 1

# Generated at 2022-06-12 09:02:42.229544
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('foo', url_prefix='/')
    assert len(bp._future_exceptions) == 0

    @bp.exception
    def handle_exception(request, exception):
        return exception

    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions, set)

# Generated at 2022-06-12 09:02:46.199350
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test', url_prefix='test')
    blueprint.exception(Exception)(Exception)

    assert blueprint._apply_exception_handler
    assert blueprint._future_exceptions

    app = Sanic('test_app')
    app.blueprint(blueprint)
    app.exception(Exception)(Exception)

    assert app._apply_exception_handler
    assert app._future_exceptions

# Generated at 2022-06-12 09:02:54.948740
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixin_child(ExceptionMixin):
        def __init__(self):
            self.arg = False
            self.kwarg = False

        def _apply_exception_handler(self, handler):
            self.arg = handler.args
            self.kwarg = handler.kwargs

    class ExceptionType(Exception):
        pass

    class TestExceptionMixin_exception:

        mixin_child = ExceptionMixin_child()

        def handler(*args, **kwargs):
            return 'handler'

        def test_exception_handler_is_returned_and_saved(self):
            self.assertEqual(
                self.mixin_child.exception(ExceptionType)(self.handler)(),
                'handler'
            )


# Generated at 2022-06-12 09:02:58.660755
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint(ExceptionMixin):
        pass

    blueprint = blueprint(None, None)
    blueprint._apply_exception_handler = None

    @blueprint.exception()
    def handler():
        pass

    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-12 09:03:02.282295
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    app = Sanic()
    bp = Blueprint('test_bp')

    @bp.exception([RuntimeError, Exception, ZeroDivisionError])
    def ignore_runtime_exception(request, exception):
        assert True

    app.blueprint(bp)

    # check exceptions

# Generated at 2022-06-12 09:03:03.836178
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception()
    def excep():
        pass
    assert callable(excep)


# Generated at 2022-06-12 09:03:12.465977
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            print("test _apply_exception_handler")

    class TestException(Exception):
        pass

    test = TestExceptionMixin()
    @test.exception(TestException)
    def test_exception(request, exception):
        print("test test_exception")
        assert isinstance(exception, TestException)
        print("end test test_exception")

    print("start test test_exception")
    try:
        raise TestException()
    except TestException:
        test_exception(None, TestException())

# Generated at 2022-06-12 09:03:35.215010
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def test_it():
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(test_exception_mixin.test_it)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions == set([FutureException(test_exception_mixin.test_it, ())])

# Generated at 2022-06-12 09:03:41.371596
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest.mock
    from sanic.exceptions import ServerError
    from sanic.routing import RoutingMiddleware
    from sanic.blueprints import Blueprint

    bp = Blueprint('test', url_prefix='/test')
    mid = RoutingMiddleware(None, bp)
    default_exception = unittest.mock.Mock()
    mid.add_global_exception_handler(ServerError, default_exception)

# Generated at 2022-06-12 09:03:42.232229
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-12 09:03:50.834121
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest

    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    # Create an app
    @Sanic.exception(Exception)
    def exception_handler(request, exception):
        return f"Got exception {exception}"

    app = Sanic()
    app.blueprint(exception_handler)

    @Sanic.exception(Exception)
    def exception_handler_another(request, exception):
        return f"Got another exception {exception}"

    app.blueprint(exception_handler_another)

    # Register a blueprint without app
    blueprint = Blueprint("test")
    blueprint.exception(Exception)(exception_handler)
    blueprint.exception(Exception)(exception_handler_another)

    # Register a blueprint with app

# Generated at 2022-06-12 09:03:53.574682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_bp')

    @bp.exception(ValueError)
    async def handler(request, exception):
        return text('global')

    bp.init_app(app)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == {FutureException(
        handler,
        (ValueError,)
    )}

# Generated at 2022-06-12 09:03:57.964729
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass

    bp = Blueprint()
    # Test case:
    #   - pass a decorated method to handler
    #   - a list of exceptions passed to the decorator
    #   - check the number of exception added to _future_exceptions
    assert len(bp._future_exceptions) == 0
    @bp.exception([Exception])
    def handle_my_exception(req, ex):
        pass
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:03:59.898025
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Should be implemented
    with pytest.raises(NotImplementedError):
        ExceptionMixin().exception()

# Generated at 2022-06-12 09:04:07.675517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.bases import BaseRequest
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import HTTPResponse


# Generated at 2022-06-12 09:04:14.499004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinTest(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class DecoratorTest(ExceptionMixinTest):
        pass

    decorator_test = DecoratorTest()

    @decorator_test.exception(ValueError, apply=False)
    def test_function():
        raise ValueError

    @decorator_test.exception([ValueError], apply=False)
    def test_function():
        raise ValueError

    @decorator_test.exception([ValueError])
    def test_function():
        raise ValueError

    with pytest.raises(ValueError):
        test_function()

    with pytest.raises(ValueError):
        test_function()


# Generated at 2022-06-12 09:04:17.073241
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        pass
    a = A()
    assert not hasattr(a, '_future_exceptions')
    # TODO: implement more tests
    # assert callable(ExceptionMixin.exception(a, IOError))

# Generated at 2022-06-12 09:04:55.292214
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.models.funcs import Funcs

    @pytest.fixture
    def cls_foo(self):
        self.a = 1
        self.b = 2
        self.c = 3

    @pytest.fixture
    def cls_bar(self):
        self.x = 1
        self.y = 2
        self.z = 3

    @pytest.fixture
    def cls_baz(self):
        self.z = 1
        self.a = 2
        self.t = 3

    cls_foo = Funcs(cls_foo)
    cls_bar = Funcs(cls_bar)
    cls_baz = Funcs(cls_baz)


# Generated at 2022-06-12 09:05:01.490884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler):
            return

    test = TestClass()
    assert test._future_exceptions == set()

    @test.exception(Exception)
    def exception_handler(request, exception):
        return 'exception handler'

    future_exception = FutureException(exception_handler, (Exception,))
    assert test._future_exceptions == {future_exception}
    assert test._future_exceptions == test._future_exceptions



# Generated at 2022-06-12 09:05:06.363190
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptMix(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions[0] == ZeroDivisionError


    except_mix = ExceptMix()
    @except_mix.exception(ZeroDivisionError)
    def divided_by_zero(request, exception):
        raise ZeroDivisionError

    divided_by_zero(1)

# Generated at 2022-06-12 09:05:13.724516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test method exception of class ExceptionMixin
    """
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self.exception_handler = None
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler


    test_exception_mixin = TestExceptionMixin()
    decorated_function = test_exception_mixin.exception(IndexError)(lambda x: x + 1)
    assert decorated_function(0) == 1

    assert len(test_exception_mixin._future_exceptions) == 1
    future_exception = next(iter(test_exception_mixin._future_exceptions))
    assert future_ex

# Generated at 2022-06-12 09:05:20.585082
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test_instance = Test()
    future_exception = test_instance.exception(Exception, apply=True)(lambda: 1)
    assert future_exception == 1
    assert test_instance._future_exceptions == {
        FutureException(future_exception, (Exception,))
    }

# Generated at 2022-06-12 09:05:29.398557
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.route import Route

    class ExceptionMixinTest(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            handler.apply()

    class RouteTest(Route):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    route = RouteTest('/test')
    exception_mixin = ExceptionMixinTest()
    def handler(request, exception):
        raise exception

    # add exception handler and apply
    exception_mixin.exception(Exception)(handler)
    assert len(exception_mixin._future_exceptions) == 1
    assert hasattr(exception_mixin, 'exception_handler')
    assert exception_mixin.exception_handler is handler
    # remove exception handler (to

# Generated at 2022-06-12 09:05:31.323384
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    blueprint = ExceptionMixin()
    blueprint.exception(Exception)


# Generated at 2022-06-12 09:05:36.605194
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    ExceptionMixin.exception - should add a method to the Blueprint
    future_exceptions set, in order to be processed by the Blueprint
    or the Route after registering the route.
    """
    from sanic.models.blueprint import Blueprint
    blueprint = Blueprint("Unit test")
    blueprint.exception(ValueError)(lambda r, e: None)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-12 09:05:40.513438
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    app = Sanic('test_ExceptionMixin_exception')
    # ExceptionMixin.exception should not raise an error when being called
    exceptional_class = type('ExceptionalClass', (ExceptionMixin,), {})
    exceptional_instance = exceptional_class()
    handler = exceptional_instance.exception(Exception)(Exception)
    assert handler == Exception

# Generated at 2022-06-12 09:05:43.660807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    et = ExceptionTest()
    exception_test_method = et.exception(Exception)
    exception_test_method(57)

# Generated at 2022-06-12 09:06:52.172826
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    mock = ExceptionMixinMock()

    @mock.exception(Exception)
    def test_exception(request, exception):
        pass

    assert len(mock._future_exceptions) == 1
    test_exception.apply(None)



# Generated at 2022-06-12 09:06:58.869742
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from typing import Set
    import sys

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')
    bp.exception(Exception)(lambda request, exception: 'OK')
    app.register_blueprint(bp)
    @app.route('/test_ExceptionMixin_exception')
    def handler(request):
        raise Exception('OK')
    request, response = app.test_client.get('/test_ExceptionMixin_exception')
    assert response.text == 'OK'

    assert len(bp._future_exceptions) == 1
    assert type(bp._future_exceptions) == set

# Generated at 2022-06-12 09:07:07.828099
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic
    from sanic.response import json
    from sanic.exceptions import ServerError
    from sanic.models.futures import FutureException
    import pytest

    app = Sanic('test_ExceptionMixin')
    bp = Blueprint('test_bp')

    @bp.route('/')
    async def handler(request):
        return json({'test': 'true'})

    @bp.exception(ServerError)
    async def exception_handler(request, exception):
        return json({'exception': 'true'}, status=500)

    app.blueprint(bp)
    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json['test'] == 'true'


# Generated at 2022-06-12 09:07:12.803406
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    app = Sanic(__name__)

    @app.listener('before_server_start')
    async def before_server_start(app, loop):
        @app.exception(ZeroDivisionError)
        def handler(request, exception):
            return text('Division by zero.')

    assert app.exception_handlers[Exception] is not None
    assert app.exception_handlers[ZeroDivisionError] is not None

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'Division by zero.'

# Generated at 2022-06-12 09:07:18.589826
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint('test_exception',url_prefix='test_exception')
    @bp.exception()
    def test_handler (request, exception): 
        return None

    assert len(bp._future_exceptions) == 1 

    for i in range(len(bp._future_exceptions)):
        future_exception = bp._future_exceptions.pop()
        assert future_exception.handler == test_handler
        assert future_exception.exceptions == Exception
        assert future_exception.kwargs == {}

# Generated at 2022-06-12 09:07:21.704754
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def handler_exception_value_error():
        print("Exception ")


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:07:28.474843
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.flag = True

        def _apply_exception_handler(self, handler: FutureException):
            self.flag = False

    myexceptionmixin = MyExceptionMixin()
    assert myexceptionmixin.flag == True

    @myexceptionmixin.exception(ValueError, ZeroDivisionError, key='value')
    def handler():
        return 1

    assert myexceptionmixin.flag == False
    assert handler() == 1

# Generated at 2022-06-12 09:07:31.832667
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    expected_future_exceptions = {FutureException}

    # testing object of class ExceptionMixin
    exception_mixin = ExceptionMixin()

    # testing exception method
    exception_mixin.exception(*expected_future_exceptions)

    # testing future_exceptions
    assert exception_mixin._future_exceptions == expected_future_exceptions

# Generated at 2022-06-12 09:07:33.733621
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    TestExceptionMixin().exception("exceptions", apply=True)

# Generated at 2022-06-12 09:07:37.002213
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ExceptionMixin_instance = ExceptionMixin()

    def decorator(handler):
        assert handler == 'handler'
        return 'decorator'
    returned_value = ExceptionMixin_instance.exception(handler=decorator)
    assert returned_value == 'decorator'